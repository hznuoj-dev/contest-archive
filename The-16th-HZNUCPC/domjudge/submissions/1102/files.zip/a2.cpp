#include <iostream>
#include <algorithm>
#include <stack>
#include <map>
#include <cstring>
#define qcin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define endl '\n'
#define int long long
/*
1
2
1 1 1 
2 2 1
*/
using namespace std;
const int N=4e2;
int a[N][N];
int q[N][N];
struct node{
	int x;
	int y;
}b[N];//ji lu hei dian 
signed main(){
	int t;cin>>t;
	
	while(t--){
		memset(a,0,sizeof a);
		memset(q,0,sizeof q);
		int n;cin>>n;
		int ans=0,sum=0,x,c,y,black=1;
		for(int i=1;i<=n;i++){//shuru dian 
			cin>>x>>y>>c;
			a[x][y]=c;
			
			if(c==1) 
			{
				b[black].x=x;
				b[black].y=y;
				black++;
			}
	}
		//chu li shu ju
		black--;
		//cout<<black<<endl;
		for(int i=1;i<=black;i++)
		{
			if(b[i].x==1&&(b[i].y==1||b[i].y==361)||b[i].x==361&&(b[i].y==1||b[i].y==361)) sum=2;
			else if(b[i].x==1&&(b[i].y!=1||b[i].y!=361)||b[i].x==361&&(b[i].y!=1||b[i].y!=361)) sum=3;
			else sum=4;
			if(a[b[i].x-1][b[i].y]==1||a[b[i].x-1][b[i].y]==2) sum--;
			//cout<<sum<<endl;
			if(a[b[i].x+1][b[i].y]==1||a[b[i].x+1][b[i].y]==2) sum--;
				//cout<<sum<<endl;
			if(a[b[i].x][b[i].y-1]==1||a[b[i].x][b[i].y-1]==2) sum--;
				//cout<<sum<<endl;
			 if(a[b[i].x][b[i].y+1]==1||a[b[i].x][b[i].y+1]==2) sum--;
			//	cout<<sum<<endl;
			ans+=sum;
		}
		cout<<ans<<endl;
	}
	return 0;
}