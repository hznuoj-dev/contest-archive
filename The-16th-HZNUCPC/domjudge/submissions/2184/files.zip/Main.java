import java.io.*;
import java.util.*;
import java.math.*;
public class Main {
  public static void main(String[] args){
	  InputStream inputStream = System.in;
	  OutputStream outputStream = System.out;
	  InputReader in = new InputReader(inputStream);
	  PrintWriter out = new PrintWriter(outputStream);
	  TaskA solver = new TaskA();
	  solver.solve(1,in,out);
	  out.close();
  }
  
  static class TaskA{
	  public void solve(int testNumber,InputReader in,PrintWriter out){
		  int n = in.nextInt();
		  int ans = n * (n-1) / 2;
		  int [][] a = new int[n][2];
		  a[0][0] = in.nextInt();
		  a[0][1] = in.nextInt();
		  a[1][0] = in.nextInt();
		  a[1][1] = in.nextInt();
		  for(int i = 2;i < n;i++){
			  a[i][0] = in.nextInt();
			  a[i][1] = in.nextInt();
			  for(int j = 1;j < i;j++){
				  for(int k = 0;k < j;k++){
					  double b = (a[i][0] - a[j][0]) * 1.0 /(a[i][1] - a[j][1]);
					  double c = (a[k][0] - a[j][0]) * 1.0 /(a[k][1] - a[j][1]);
					  if(b == c)
						  ans -= 2;
				  }
			  }
		  }
		  if(ans < 3)
			  out.println(0);
		  else
			  out.println(ans);
	  }
  }
  
  static class InputReader{
	  public BufferedReader reader;
	  public StringTokenizer tokenizer;
	  public InputReader(InputStream stream){
		  reader = new BufferedReader(new InputStreamReader(stream),32768);
		  tokenizer = null;
	  }
	  boolean hasNext()
	  {
		 while(tokenizer == null || !tokenizer.hasMoreTokens())
		 {
			 try
			 {
				 tokenizer = new StringTokenizer(reader.readLine());
			 }catch(Exception e)
			 {
				 return false;
			 }
		 }
		 return true;
	  }
	  public String next(){
		  while(tokenizer == null || !tokenizer.hasMoreTokens()){
			  try{
				  tokenizer = new StringTokenizer(reader.readLine());
			  }catch(IOException e){
				  throw new RuntimeException(e);
			  }
		  }
		  return tokenizer.nextToken();
	  }
	  public String nextLine()
	  {
		  String str = null;
		  try
		  {
			  str = reader.readLine();
		  }catch(IOException e){
			  e.printStackTrace();
		  }
		  return str;
	  }
	  public int nextInt(){
		  return Integer.parseInt(next());
	  }
	  public double nextDouble(){
		  return Double.parseDouble(next());
	  }
	  public long nextLong(){
		  return Long.parseLong(next());
	  }
	  public BigInteger nextBigInteger(){
		  return new BigInteger(next());
	  }
	  public BigDecimal nextBigDecimal(){
		  return new BigDecimal(next());
	  }
  }
}
