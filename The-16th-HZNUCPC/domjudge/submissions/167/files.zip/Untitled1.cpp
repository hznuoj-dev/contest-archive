#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;
typedef long long ll;

int gcd(int a,int b){return b==0?a:gcd(b,a%b);
}

void solve(){
	ll n,m;
	cin>>n>>m;
	if(gcd(n,m)>1)cout<<"NO"<<endl;
	else cout<<"YES"<<endl;
	
	system("pause");
}

int main(){
	
	int t = 1;
	//cin >> t
	while(t--){
		solve();
	}
	
	return 0;
}