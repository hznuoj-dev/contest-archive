#include <bits/stdc++.h>
#define ln '\n'

const int N = 1005;
int f[N];
inline int find(int x) { return f[x] == x ? x : f[x] = find(f[x]); }

inline void solve() {
	int n, m;
	std::cin >> n >> m;
	std::vector<int>u(m), v(m), w(m);
	for(int i = 0; i < m; i++)
		std::cin >> u[i] >> v[i] >> w[i];
	if(n == m - 1) { 
		std::vector<int>cnt(n + 1);
		for(int i = 0; i < m; i++)
			cnt[w[i]]++;
		for(int i = 0; i < n; i++)
			if(!cnt[i]) return std::cout << i << ln, void();
	} else {
		int ans = 0;
		for(int j = 0; j < m; j++) {
			for(int i = 1; i <= n; i++) f[i] = i;
			int tot = n;
			for(int i = 0; i < m; i++) 
				if(j != i){
					int x = find(u[i]), y = find(v[i]);
					if(x != y) f[y] = x, tot--; 
				}
			if(tot == 1) {
				int tmp = 0;
				std::vector<int>cnt(n + 1);
				for(int i = 0; i < m; i++)
					cnt[w[i]]+=(j != i);
				for(int i = 0; i < n; i++)
					if(!cnt[i]) {
						tmp = i;
						break;
					}
				ans = std::max(ans, tmp);
			}
		}
		return std::cout << ans << ln, void();
	}
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);

	solve();
	return 0;
}