#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
typedef long long LL;
using namespace std;
typedef pair<int,int> PII;
const int N=1e9+7;
LL res=0;
LL gcd(LL x,LL y){
    return y?gcd(y,x%y):x;
    }
int main(){
    LL n,m;
    scanf("%lld%lld",&n,&m);
    if(n<=m){
        printf("NO");
        return 0;
    }
    LL p=gcd(n,m);
    if(p!=1){
        printf("NO");
    }else{
        printf("YES");
    }
}
