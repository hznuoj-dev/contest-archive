#include<bits/stdc++.h>
using namespace std;

int a[30][30];
int main(){
	int t;
	cin>>t;
	while(t--){
		int n,x,y,z,flag=0,sum=0;
		cin>>n;
		queue<pair<int,int>> q;
		pair<int,int> p;
		for(int i=1;i<=n;i++){
			cin>>x>>y>>z;
			a[x][y]=z;
			if(z==1){
				p.first=x;p.second=y;
				q.push(p);
			}
		}
		while(!q.empty()){
			x=q.front().first;y=q.front().second;
			q.pop();
			if(y+1<=19&&a[x][y+1]==0) sum++;
			if(x+1<=19&&a[x+1][y]==0) sum++;
			if(y-1>=1&&a[x][y-1]==0) sum++;
			if(x-1>=1&&a[x-1][y]==0) sum++;
		}
		cout<<sum<<endl;
		memset(a,0,sizeof(a));
	}
	return 0;
}