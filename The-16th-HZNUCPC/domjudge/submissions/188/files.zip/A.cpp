#include<bits/stdc++.h>
using namespace std;
const int N=30;
const int M=400;
int a[N][N];
typedef struct node{
	int x,y,c;
}node;
node p[M]; 
int dx[]={1,0,-1,0};
int dy[]={0,1,0,-1};
void solve(){
	int n;scanf("%d",&n);
	for(int i=0;i<=20;i++)for(int j=0;j<=20;j++)a[i][j]=0;
	
	for(int i=1;i<=n;i++){
		scanf("%d %d %d",&p[i].x,&p[i].y,&p[i].c);
		a[p[i].x][p[i].y]=p[i].c;
	}int ans=0;
	for(int i=1;i<=n;i++){
		a[0][i]=3;
		a[20][i]=3;
		a[i][0]=3;
		a[i][20]=3;
	}
	for(int i=1;i<=n;i++){
		if(p[i].c==2)continue;
		//int x=p[i].x,y=p[i].y;
		for(int j=0;j<4;j++){
			int x=p[i].x+dx[j],y=p[i].y+dy[j];
			if(a[x][y]==0)ans++;
		}
	}printf("%d\n",ans);
}
signed main(){
	int t;scanf("%d",&t);
	while(t--) solve();
}
