#include<bits/stdc++.h>

#define ll long long

using namespace std;

int dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int s[25][25];
bool vis[25][25];

int dfs(int x,int y){
	int ans=0;
	vis[x][y]=1;
	for(int i=0;i<4;i++)
	{
		int tx=dir[i][0]+x;
		int ty=dir[i][1]+y;
		if(tx>=1&&tx<=19&&ty>=1&&ty<=19&&s[tx][ty]==0)
		{
			ans++;
		}
	}
	return ans;
}

int main()
{
	int T;
	while(~scanf("%d",&T))
	{
		while(T--)
		{
			memset(vis,0,sizeof(vis));
			memset(s,0,sizeof(s));
			int n;
			int res=0;
			scanf("%d",&n);
			for(int i=0;i<n;i++)
			{
				int x,y,z;
				scanf("%d %d %d",&x,&y,&z);
				if(s[x][y]!=0)
				{
					continue;
				}
				s[x][y]=z;
				int sum=0;
				for(int i=0;i<4;i++)
				{
					int tx=dir[i][0]+x;
					int ty=dir[i][1]+y;
					if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
					{
						if(s[tx][ty]!=0)
						{
							if(dfs(tx,ty)==0)
							{
								s[tx][ty]=0;
								sum++;
							}
						}
						else
						{
							sum++;
						}
					}
				}
				if(sum==0)
				{
					s[x][y]=0;
				}
			}
			for(int i=1;i<=19;i++)
			{
				for(int j=1;j<=19;j++)
				{
					if(s[i][j]==1)
					{
						res+=dfs(i,j);
					}
				}
			}
			printf("%d\n",res);
//			for(int i=1;i<=19;i++)
//			{
//				for(int j=1;j<=19;j++)
//				{
//					cout<<s[i][j]<<" ";
//				}
//				cout<<endl;
//			}
		}
	}
	return 0;
}
