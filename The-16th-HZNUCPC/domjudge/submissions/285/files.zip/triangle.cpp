#include<bits/stdc++.h>
using namespace std;
#define ll long long

struct node{
	ll x,y;
}a[105];
ll ans=0;
int n,i,j,k;
int read()	{
	int fw = 1, x = 0;
	char c = getchar();
	while (c < '0' || c > '9')	{
		if (c == '-')	fw = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9')	{
		x = (x << 1) + (x << 3) + c - '0';
		c = getchar();
	}
	return fw * x;
}
int gcd(int x,int y){
	if(x%y) return gcd(y,x%y);
	return y;
}
bool gx(node a,node b,node c){
	ll x1=b.x-a.x,x2=c.x-a.x,y1=b.y-a.y,y2=c.y-a.y;
	return x1*y2-x2*y1;
}
ll cal(node a,node b){
	if(a.x==b.x) return abs(b.y-a.y);
	if(a.y==b.y) return abs(b.x-a.x);
	return gcd(abs(a.x-b.x),abs(a.y-b.y));
}
int main(){
	n=read();
	for(i=1;i<=n;++i) a[i]=(node){read(),read()};
	for(i=1;i<n-1;++i)
	    for(j=i+1;j<n;++j)
	        for(k=j+1;k<=n;++k){
	        	if(!gx(a[i],a[j],a[k])) continue;
	        	ans=max(ans,cal(a[i],a[j])+cal(a[j],a[k])+cal(a[k],a[i]));
			}
	printf("%lld\n",ans);
	return 0;
}