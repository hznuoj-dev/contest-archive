#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=1e9+7;
vector<pair<int,int>> vp;
float s(int x1,int y1,int x2,int y2,int x3,int y3){
	return abs(float((y2-y1)*(x3-x1)-(y3-y1)*(x2-x1))/2);
}
void solve() {
//cerr<<s(2,2,3,3,2,4)<<endl;
	int n;
	cin>>n;
	float res=0;
	vp.push_back({1,2});
	for(int i=1;i<=n;i++){
		float x,y;
		cin>>x>>y;
		vp.push_back({x,y});
	}
	for(int i=1;i<=n;i++){
		
		for(int j=1;j<=n;j++){
			if(j==i) continue;
			for(int k=1;k<=n;k++){
				if(k==i||k==j) continue;
				res=max(res,s(vp[i].first,vp[i].second,vp[j].first,vp[j].second,vp[k].first,vp[k].second));
				if(res==3) cout<<i<<" "<<j<<" "<<k<<endl;
			}
		}
	}
	
	cout<<res<<endl;
}

int main() {
	int t=1;
//	cin>>t;
	while(t--) {
		solve();
	}
}