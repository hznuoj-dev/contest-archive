#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
typedef long long ll;
using namespace std;
const int N=1e5+10;
char s1[N],s2[N];
int n;ll c1[30],c2[30],c[30][30],ans;
void work(int a,int b,int w) {
	int t1=0,t2=0;
	For(i,0,25) t1+=!c1[i],t2+=!c2[i];
	For(i,0,25) For(j,0,25) if(c[i][j]) {
		int t3=t1,t4=t2;
		if(i!=j) {
			if(c1[i]==1) --t3;
			if(!c1[j]) ++t3;
			if(c2[j]==1) --t4;
			if(!c2[i]) ++t4;
		}
		if(t3==t4) {
			if(i==a && j==b) ans+=w*(w-1)/2;
			else ans+=w*c[i][j];
		}
	}
}
int main() {
#ifdef LOCAL
    freopen(".in","r",stdin);
#endif
    ios::sync_with_stdio(0); cin.tie(0);
    cin>>s1+1>>s2+1; n=strlen(s1+1);
    For(i,1,n) {
    	s1[i]-='a';
    	s2[i]-='a';
    	++c1[s1[i]]; ++c2[s2[i]];
    	++c[s1[i]][s2[i]];
	}
	For(i,0,25) For(j,0,25) if(c[i][j]) {
		--c1[i]; --c2[j]; ++c1[j]; ++c2[i];
		work(i,j,c[i][j]);
		c1[i]++; c2[j]++; c1[j]--; c2[i]--;
	}
	cout<<ans;
}
