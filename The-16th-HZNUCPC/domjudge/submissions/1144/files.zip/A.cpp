#include<bits/stdc++.h>

using namespace std;

#define int long long
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

using ll = long long;

const int N = 1e5+10;
const int M = 1e9+7;

using PII = pair<int,int>;

int dx[4]={1,0,-1,0},dy[4]={0,1,0,-1};
set<PII> st;
map<PII,int> mp;

void solve(){
	int n;
	cin>>n;
	
	ll ans=0;
	
	while(n--){
		int x,y,c;
		cin>>x>>y>>c;
		
		
		if(c==1){
			if(mp.count({x,y})){
				ans-=mp[{x,y}];
			}
			
			for(int i=0;i<4;i++){
				int a=x+dx[i],b=y+dy[i];
				
				if(a>=1 && a<=19 && b>=1 && b<=19){
					if(!st.count({a,b})){
						ans++;
						mp[{a,b}]++;
					}
				}
			}
			
			st.insert({x,y});
		}
		else if(c==2){
			st.insert({x,y});
		}
	}
	
	cout<<ans<<endl;
}

signed main(){
	IOS;
	
	int t;
	cin>>t;
	//t=1;
	
	while(t--){
		solve();
	}
	
	return 0;
}