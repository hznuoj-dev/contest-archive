#include <iostream>
#include <cstring>
#include <stdlib.h>

using namespace std;
using ll = long long;

int pos[20][20];
void dfs(int x, int y,int num)
{
	if(x<=19&&x>=1&&y>=1&&y<=19)
	{
		if(pos[x][y]==1)
	{	
		
		pos[x][y]=num;
		dfs(x+1,y,num);
		dfs(x,y-1,num);
		dfs(x-1,y,num);
		dfs(x,y+1,num);
		return;
	}
	else
	return;
	}
	return;
	
	
}


int cmp(const void* a, const void* b) {
	return *(int*)a - *(int*)b;
}

int main()
{
	int i,j,k,l;
	int n,m,x,y,c,sum = 0,count = 2;
	cin >> n;
	for(i=1;i<=n;i++)
	{
		for (j = 1; j < 20; j++) {
			for (k = 1; k < 20; k++) {
				pos[j][k] = 0;
			}
		}
		sum = 0;
		count = 2;
		cin >> m;
		for(j=1;j<=m;j++)
		{
			cin >>x >> y >> c;
			if(c==1)
			{
				pos[x][y]=1;
				
			}
			else
			{
				pos[x][y]=-1;
			}
			
		}	
			for(j=1;j<=19;j++)
		{
			for(k=1;k<=19;k++)
			{
				if(pos[j][k]==1)
				{
					dfs(j,k,count);
					count++;
				}
			}
			
		}
		
		/*for(j=1;j<=19;j++)
		{
			for(k=1;k<=19;k++)
			{
			cout << pos[j][k] << " ";
			}
			cout << endl;
		}
		*/
		
		int cnt = 0;
		
		for (j = 1; j < 20; j++) {
			for (k = 1; k < 20; k++) {
				if (pos[j][k] == 0) {
					int op[4] = {0}, cnt1 = 0,b = 0, cnt2 = 0;
					if (pos[j + 1][k] > 1 && j + 1 < 20) {
						op[cnt2] = pos[j + 1][k];
						cnt2 ++;
					}
					if (pos[j - 1][k] > 1 && j - 1 > 0) {
						op[cnt2] = pos[j - 1][k];
						cnt2 ++;
					}
					if (pos[j][k + 1] > 1 && k + 1 < 20) {
						op[cnt2] = pos[j][k + 1];
						cnt2 ++;
					}
					if (pos[j][k - 1] > 1 && k - 1 > 0) {
						op[cnt2] = pos[j][k - 1];
						cnt2 ++;
					}
					if (cnt2 == 0) {
						continue;
					}
					/*for (cnt1 = 0; cnt1 < cnt2; cnt1 ++) {
						cout << op[cnt1] << " ";
					}
					cout << endl;*/
					if (cnt2 == 1) {
						cnt++;
						continue;
					}
					if (cnt2 == 2) {
						if (op[0] == op[1]) {
							cnt++;
						} else {
							cnt += 2;
						}
						continue;
					}
					qsort(op, cnt2, sizeof (int), cmp);
					cnt++;
					for (cnt1 = 1; cnt1 < cnt2; cnt1++) {
						if (op[cnt1] != op[cnt1 - 1]) {
							cnt++;
						}
					}
					
				}
				
			}
		}
		cout << cnt << endl;
	}
	return 0;
}

