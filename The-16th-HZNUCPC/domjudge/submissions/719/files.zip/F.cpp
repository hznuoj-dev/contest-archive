#include<bits/stdc++.h>

#define all(a) a.begin(),a.end()
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define pb push_back
#define fi first
#define se second
#define quick ios.sync_with_stdio(false);cout.tie(0);cin.tie(0);

typedef long long ll;
typedef unsigned long long ull;
//typedef pair<ll,ll> PLL;

using namespace std;

ll n,m;

//int mp[30][30];

void solve(){
	cin>>n>>m;
	if(m == 1){
		cout<<"YES\n";
		return ;
	}
	if(n%2 == 0){
		cout<<"NO\n"; 
		return ;
	}
	if(m >= n){
		cout<<"NO\n";
	}else{
		ll i = 2;
		int flag = 0;
		for(i = 2;i*i<=n;++i){
			if(n%i == 0){
				flag = 1;
				break;
			}
		}
		if(flag == 0){
			i = n;
		}
		if(m<i){
			cout<<"YES\n";
			return ;
		}else{
			cout<<"NO\n";
			return ;
		}
	}
}

int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
