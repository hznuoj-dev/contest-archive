#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=30;
int f[N][N],flag[N][N];
int ans=0;
void cz(int i,int j){
	if(flag[i][j])return;
	if(!flag[i+1][j]&&!f[i+1][j])ans++;
	if(!flag[i-1][j]&&!f[i-1][j])ans++;
	if(!flag[i][j+1]&&!f[i][j+1])ans++;
	if(!flag[i][j-1]&&!f[i][j-1])ans++;
	return;
}
void solve(){
	int n;cin>>n;
	ans=0;
	memset(f,0,sizeof(f));
	memset(flag,0,sizeof(flag));
	for(int i=0;i<=20;i++)for(int j=0;j<=20;j++){
		if(i==0||j==0||i==20||j==20)flag[i][j]=1;
		else flag[i][j]=0;
	}
	for(int i=1;i<=n;i++){
		int a,b,k;cin>>a>>b>>k;
		if(k==1)f[a][b]=1;
		else flag[a][b]=1;
	}
	for(int i=1;i<=19;i++)for(int j=1;j<=19;j++){
		if(f[i][j])cz(i,j);
	}
	cout<<ans<<'\n';
	return;
}
signed main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int n;cin>>n;
	while(n--)solve();
	return 0;
}