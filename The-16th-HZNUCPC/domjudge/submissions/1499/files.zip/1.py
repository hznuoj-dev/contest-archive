t = int(input())
for _ in range(t):
    a = [[0]*21 for i in range(21)]
    r = 0
    l = []
    n = int(input())
    for i in range(n):
        x, y, c = map(int, input().split())
        a[x][y] = c
        l.append([x, y])
    # for x in range(1,20):
    #     for y in range(20):
    #         if a[x][y] == 0 and (a[x][y+1]==1 or a[x+1][y]==1 or (y>0 and a[x][y-1]==1) or (x>0 and a[x-1][y]==1)):
    #             r += 1
    for x, y in l:
        if y < 20 and a[x][y+1] == 0:
            r += 1
        if x < 20 and a[x+1][x] == 0:
            r += 1
        if y > 1 and a[x][y-1] == 0:
            r += 1
        if x > 1 and a[x-1][y] == 0:
            r += 1
    print(r)
