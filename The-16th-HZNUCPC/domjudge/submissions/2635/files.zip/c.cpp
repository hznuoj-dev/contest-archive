#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int> PII;
const int MOD=1e9+7;

int cnt[30][2];
int st[10];

signed main(){
	string s1,s2;
	cin>>s1>>s2;
	int n=s1.size();
	for(int i=0;i<n;i++){
		cnt[s1[i]-'a'][0]++;
		cnt[s2[i]-'a'][1]++;
	}
	int cha=0;
	for(int i=0;i<26;i++){
		cha+=(cnt[i][0]>0);
		cha-=(cnt[i][1]>0);
	}
	map<int,int> m;
	for(int i=0;i<n;i++){
		int x=0;
		if(s1[i]==s2[i]){
		}else{
			if(cnt[s2[i]-'a'][0]==0){
				x++;
			}
			if(cnt[s1[i]-'a'][1]==0){
				x--;
			}
			if(cnt[s1[i]-'a'][0]==1){
				x--;
			}
			if(cnt[s2[i]-'a'][1]==1){
				x++;
			}
		}
		m[x]++;
	}
	int res=0;
	for(int i=-2;i<=2;i++){
		int j=-(cha+i);
		if(!m.count(i)||!m.count(j)) continue;
		if(st[i+5]||st[j+5]) continue;
		st[j+5]=1;
		st[i+5]=1;

		if(i==j){
			res=(res+(m[i]*(m[i]-1)/2)%MOD)%MOD;
		}else{
			res+=((m[i]%MOD)*m[j])%MOD;
		}
	}
	cout<<res<<endl;
	return 0;
}