#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
char s1[100010];
char s2[100010];
ll s[21][21];
int main()
{
    /*//cin>>s1>>s2;
    ll n,m;
    cin>>n>>m;
    while(n%m!=0){
        m=n%m;
        if(m==1)break;
    }
    if(m==1)cout<<"YES"<<endl;
    else cout<<"NO"<<endl;*/
    ll t,x,y,c;
    cin>>t;
    while(t--){
        ll n;
        ll ans=0;
        memset(s,0,sizeof s);
        cin>>n;
        while(n--){
            cin>>x>>y>>c;
            s[x][y]=c;
        }
        for(ll i=1;i<=19;i++){
            for(ll j=1;j<=19;j++){
                if(s[i][j]==0){
                    if(s[i+1][j]==1){
                        ans++;
                    }
                    if(s[i-1][j]==1){
                        ans++;
                    }
                    if(s[i][j+1]==1){
                        ans++;
                    }
                    if(s[i][j-1]==1){
                        ans++;
                    }
                }
            }
        }
        cout<<ans<<endl;
    }


    return 0;
}
