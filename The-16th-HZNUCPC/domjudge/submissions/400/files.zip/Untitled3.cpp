#include <bits/stdc++.h>
using namespace std;
#define int long long
int n, a[105], b[105], sum;
int mgcd(int a, int b) {return b ? mgcd(b, a % b) : a;}
signed main() {
	scanf("%lld", &n);
	for (int i = 1; i <= n; ++ i)
		scanf("%lld%lld", &a[i], &b[i]);
	for (int i = 1; i <= n; ++ i)
		for (int j = i + 1; j <= n; ++ j)
			for (int k = j + 1; k <= n; ++ k) {
				int ans = mgcd(abs(a[i] - a[j]), abs(b[i] - b[j])) + mgcd(abs(a[i] - a[k]), abs(b[i] - b[k])) + mgcd(abs(a[j] - a[k]), abs(b[j] - b[k]));
				sum = max(sum, ans);
			}
	printf("%lld", sum);
	return 0;
}