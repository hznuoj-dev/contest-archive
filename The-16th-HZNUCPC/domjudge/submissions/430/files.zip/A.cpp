#include<bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(),(a).end;
using namespace std;

int n;
int g[105][105];

void solve()
{
	cin >> n;
	for(int i = 0; i <= 22; i++)
		for(int j = 0; j <= 22; j++) 
			g[i][j] = -1;
	
	vector<array<int, 2>> v;
	for(int i = 1; i <= n; i++)
	{
		int x, y, op;
		cin >> x >> y >> op;
		g[x][y] = 1;
		if(op == 1) v.push_back({x, y});
	}
	
	ll ans = 0;
	for(auto &[x, y] : v)
	{
		if(y - 1 && g[x][y - 1] == -1) ans++;
		if(y + 1 <= 19 && g[x][y + 1] == -1) ans++;
		if(x - 1 && g[x - 1][y] == -1) ans++;
		if(x + 1 <= 19 && g[x + 1][y] == -1) ans++;
	}
	
	cout << ans << '\n';
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
	cin >> t;
	while(t--) solve();
	return 0;
}
/*
1
2
1 1 1
2 2 1
*/
/*
1
2
10 9 1
10 10 1
*/