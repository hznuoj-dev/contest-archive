#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int f=0;
int main(){
	ll n,m;
	scanf("%lld %lld",&n,&m);
	if(n==1){
		cout<<"YES"<<endl;
		return 0;
	}
	ll t=m;
	while(m){
		if(m==1){
			f=1;
			break;
		}
		m=n%m;
	}
	if(f==1){
		printf("YES\n");
		
	}
	else{
		printf("NO\n");
	}
}