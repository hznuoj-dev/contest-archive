#include <bits/stdc++.h>
#define all(x) (x).begin(),(x).end()

using namespace std;

const int N = 120;

int a[N][N];
bool st[N][N];

int dx[5] = {0, 0, 1, -1};
int dy[5] = {1, -1, 0, 0};

bool check(int x, int y)
{
	return x < 1 || x > 19 || y < 1 || y > 19;
}

void solve()
{
	memset(a, 0, sizeof a);
	memset(st, 0, sizeof st);
	int n;
	cin >> n;
	for(int i = 1; i <= n; i ++)
	{
		int xx, yy, cc;
		cin >> xx >> yy >> cc;
		a[xx][yy] = cc;
	}
	
	int ans = 0;
	for(int i = 1; i <= 19; i ++)
	{
		for(int j = 1; j <= 19; j ++)
		{
			if(!a[i][j] || a[i][j] == 2)
				continue;
			for(int k = 0; k < 4; k ++)
			{
				int x = i + dx[k], y = j + dy[k];
				if(check(x, y) || a[x][y])
					continue;
			//	cout << x << " ++ " << y << endl;
				ans ++;
			}
		}
	}
	
	cout << ans << endl;
}

signed main()
{
    int t = 1;
    cin >> t;
    while (t -- ) solve();
}
