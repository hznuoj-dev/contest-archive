#include<stdio.h>
#include<math.h>
int main()
{
	long long n,m;
	long long i,j=1;
	while(j!=0)
	{	
		scanf("%lld %lld",&n,&m);
		if(n==1 && m==2)
		{
			printf("YES");
		}
		
		if(m==2 && n==2)
		{
			printf("NO");
		}
		else
		{
			if(m>n && m!=1 && m!=2)
			{
				printf("NO");
			}
			if(m<n && m!=1 && m!=2)
			for(i=0;i<100000;i++)
				{
					if(n%m==0)
		        {
					printf("NO");
					break;
				}
					if(m==2 && n%2==0)
					{
						printf("NO");
						break;
					}
					if(m==2 && n%2!=0)
					{							
						printf("YES");
						break;
					}
					if(m>2 && n%m!=0)
					{
						m=m-1;          
					}
				}						
			}
						
   		j++;	
		}
	}