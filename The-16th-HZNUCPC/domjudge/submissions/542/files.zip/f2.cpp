#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

ll gcd(ll a,ll b){
	if(a<b){
		a=a^b;
		b=a^b;
		a=a^b;
	}
	while(a%b){
		ll k=b;
		b=a%b;
		a=k;
	}
	return b;
}


int main(){
	ll n ,m;
	scanf("%lld%lld",&n,&m);
	if(n<m){
		if(n!=1){
			cout<<"NO"<<endl;
		}
		else{
			cout<<"YES"<<endl;
		}
	}
	else if(gcd(n,m)==1){
		cout<<"YES"<<endl;
	}
	else{
		cout<<"NO"<<endl;
	}
}