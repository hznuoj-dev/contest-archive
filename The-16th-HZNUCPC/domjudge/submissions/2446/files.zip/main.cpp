#include <iostream>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;
typedef long long ll;

ll n, m, x=0;

int main()
{
    cin >> n >> m;
    for(int i = 2;i <= sqrt(n)+1;i++)
    {
        if(n % i == 0)
        {
            x = i;
            break;
        }
    }
    if(x==0)
        x=n;
    if(m==1){
    cout<<"YES";
    return 0;
    }
    if(x <= m)
    cout << "NO";
    else
    cout << "YES";
    return 0;
}