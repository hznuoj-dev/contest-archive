t=int(input())
for times in range(t):
    blacklst=list()
    lst=[[0 for i in range(21)]for j in range(21)]
    n=int(input())
    #设定边界
    for i in range(len(lst)):
        for j in range(len(lst[i])):
            if i==0 or i==20 or j==0 or j==20:
                lst[i][j]=2
    for i in range(n):
        temp=list(map(int,input().split()))
        lst[temp[0]][temp[1]]=temp[2]
        if temp[2]==1:
            blacklst.append(temp)
    ans=0
    for i in range(len(blacklst)):
        if(lst[blacklst[i][0]-1][blacklst[i][1]]==0):
            ans+=1
        if(lst[blacklst[i][0]+1][blacklst[i][1]]==0):
            ans+=1
        if(lst[blacklst[i][0]][blacklst[i][1]-1]==0):
            ans+=1
        if(lst[blacklst[i][0]][blacklst[i][1]+1]==0):
            ans+=1
    print(ans)
        
