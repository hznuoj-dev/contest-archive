#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
i64 gcd(i64 a,i64 b){
	return b>0?gcd(b,a%b):a;
}
void solve(){
	int n;
	cin >> n;

	vector<array<int,2>>p(n);
	for(int i = 0; i < n; i ++){
		int x , y;
		cin >> x >> y;
		p[i][0] = x, p[i][1] = y;
	}

	i64 cnt_m=0;
	for(int i = 0; i < n; i ++){
		for(int j = i + 1; j < n; j ++){
			for(int k = j + 1; k < n; k ++){
				if(!(p[k][1]-p[i][1])*(p[k][0]-p[j][0])==(p[k][0]-p[i][0])*(p[k][1]-p[j][1]))
					continue;
				i64 cnt=gcd(abs(p[i][0]-p[j][0]),abs(p[i][1]-p[j][1]));
				cnt+=gcd(abs(p[i][0]-p[k][0]),abs(p[i][1]-p[k][1]));
				cnt+=gcd(abs(p[k][0]-p[j][0]),abs(p[k][1]-p[j][1]));
				//cnt-=3;
				cnt_m=max(cnt_m,cnt);
			}
		}
	}
	cout<<cnt_m<<endl;
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int T=1;
	//cin >> T;

	while(T --)
		solve();
	return 0;
}
