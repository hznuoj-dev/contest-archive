#include <bits/stdc++.h>
#define ll long long
using namespace std;

bool check(ll n,ll m){		//n vote
	if(m == 1) return true;
	ll ans = n % m;
	if(ans == 0) return false;
//	cout << ans << endl;
	return check(n, ans); 
}



int main(){
	ll n,m;
	while(cin>>n>>m){
		if (check(n, m)) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}
