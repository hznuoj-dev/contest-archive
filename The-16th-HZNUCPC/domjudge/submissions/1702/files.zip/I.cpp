#include <bits/stdc++.h>

#define dbg(x...) \
    do { \
        std::cout << #x << " -> "; \
        err(x); \
    } while (0)

void err() {
    std::cout << std::endl;
}

template<class T, class... Ts>
void err(T arg, Ts &... args) {
    std::cout << arg << ' ';
    err(args...);
}

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using i128 = __int128;

void run(int tCase) {
    std::string s;
    std::cin >> s;
    int n = s.length();
    //odd
    auto match = [&](std::pair<int, int> p1, std::pair<int, int> p2) {
        if (p1 == p2) return true;
        std::swap(p1.first, p1.second);
        return p1 == p2;
    };
    int ans = 0;
    for (int i = 0; i < n; ++i) {
        int mid = s[i] - 'a';
        std::vector<std::pair<int, int>> v;
        for (int j = 1; i - j >= 0 and i + j < n; ++j) {
            int l = i - j, r = i + j;
            if (s[l] != s[r]) {
                if (v.size() == 2) break;
                v.emplace_back(s[l] - 'a', s[r] - 'a');
            }
            if (v.size() == 0) {
                ans = std::max(ans, j * 2 + 1);
            } else if (v.size() == 1) {
                if (v[0].first == mid or v[0].second == mid) {
                    ans = std::max(ans, j * 2 + 1);
                }
            } else {
                if (match(v[0], v[1])) {
                    ans = std::max(ans, j * 2 + 1);
                }
            }
        }
    }
    for (int i = 0; i + 1 < n; ++i) {
        std::vector<std::pair<int, int>> v;
        for (int j = 0; i - j >= 0 and i + j + 1 < n; ++j) {
            int l = i - j, r = i + j + 1;
            if (s[l] != s[r]) {
                if (v.size() == 2) break;
                v.emplace_back(s[l] - 'a', s[r] - 'a');
            }
            if (v.size() == 0) {
                ans = std::max(ans, (j + 1) * 2);
            } else if (v.size() == 2) {
                if (match(v[0], v[1])) {
                    ans = std::max(ans, (j + 1) * 2);
                }
            }
        }
    }
    std::cout << ans << '\n';
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int T = 1;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        run(t);
    }
    return 0;
}