#include<iostream>
using namespace std;
int main()
{
	int n,m;
	cin>>n>>m;
	if(n<=m)
	cout<<"NO"<<endl;
	else if(n==1||m==1)
	cout<<"YES"<<endl;
	else if(n%2==0)
	cout<<"NO"<<endl;
	else
	{
		if(n%m==0||n%(m-1)==0)
		cout<<"NO"<<endl;
		else
		cout<<"YES"<<endl;
	}
	return 0;
}