#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve(){
	ll a,b;
	cin>>a>>b;
	cout<<(__gcd(a,b)==1?"YES":"NO")<<'\n';
}
int main(){
	ios::sync_with_stdio(0);
	int T=1;
//	cin>>T;
	while(T--){
		solve();
	}
}