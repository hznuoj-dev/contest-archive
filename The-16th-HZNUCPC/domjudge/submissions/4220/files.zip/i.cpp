#include<iostream>
#include <cstring>
#include<cstdio>

using namespace std;

char s[10010];
unsigned long f1[10010],p1[10010];
unsigned long f2[10010],p2[10010];



int main(){
	int  t;
	cin>>t;
	while(t--){
		int n=strlen(s+1);
		scanf("%s",s+1);
		p1[0]=1;
		p2[0]=1;
		for(int i=1;i<=n;i++){
			f1[i]=f1[i-1]*131+(s[i]-'a'+1);
			p1[i]=p1[i-1]*131;
		}
		for(int i=n;i>=1;i--){
			f2[i]=f2[i-1]*131+(s[i]-'a'+1);
			p2[i]=p2[i]*131;
		}
		int max0=-100;
		
		for(int i=1;i<=n;i++){
			int r1=1;
			while((f1[i]-f1[i-r1-1]*p1[r1+1])==(f2[i+r1]-f2[i-1]*p1[r1+1])){
				r1=r1*2;
			}
			while((f1[i]-f1[i-r1-1]*p1[r1+1])!=(f2[i+r1]-f2[i-1]*p1[r1+1])) r1--;
			

			int r2=1;
			while((f1[i-1]-f1[i-r2-1]*p1[r2+1])==(f2[i+r2]-f2[i-1]*p1[r2+1])){
				r2=r2*2;
			}
			while((f1[i-1]-f1[i-r2-1]*p1[r2+1])!=(f2[i+r2]-f2[i-1]*p1[r2+1])) r2--;

			max0=max(max0,r1);
			max0=max(max0,r2);
		}
		cout<<max0<<endl;
	}
}