#include<iostream>
using namespace std;
int main(){

	long long n,m;
	cin >> n >> m;
	if(m == 1){
		cout << "YES";
	}
	else{
		if(n <= m){
			cout << "NO";
		}
		else{
		if(n % 2 == 0){
			cout << "NO";
		}
		else{
			long long da = 1e9;
			for(int i = 2; i*i <= n; i++){
				if(n % i == 0){
					da = i;
					break;
				}
			}
			long long x = min(n / 2 , m - 1);
			if(da <= x) cout<<"NO";
			else cout<<"YES";	
			}
		}
	}
	
}