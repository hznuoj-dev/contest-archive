

m,n = map(int,input().split())
flag = 0
if m == 0 or n == 0:
    print('NO')
elif m == 1:
    print('YES')

elif m<=n:
    print('NO')

else:
    while(n):
        if n==1:
            flag = 1
            print("YES")
            break
        n=m%n
    if flag == 0:
        print("NO")