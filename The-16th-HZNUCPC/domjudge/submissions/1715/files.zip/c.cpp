#include <iostream>
#include <vector>
#include <string>
using namespace std;
using ll = long long;
using pll = pair<ll, ll>;
const int mod=1e9+7;

int a[30][30];
int es[30],et[30];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
   string s,t;
   cin>>s>>t;
   int len=s.length();
   for(int i=0;i<len;i++){
       a[s[i]-'a'][t[i]-'a']++;
       es[s[i]-'a']++;
       et[t[i]-'a']++;
   }
   int ns=0,nt=0;
   for(int i=0;i<26;i++){
        if(es[i])ns++;
        if(et[i])nt++;
   }
   
   ll ans=0;
   for(int i=0;i<len;i++){
        int x=s[i]-'a';
        int y=t[i]-'a';
        es[x]--;
        et[y]--;
        if(es[x]==0)ns--;
        if(et[y]==0)nt--;
        es[y]++;
        et[x]++;
        if(es[y]==1)ns++;
        if(et[x]==1)nt++;
        a[x][y]--;
        for(int j=0;j<26;j++){
            for(int k=0;k<26;k++){
                if(es[j]==0||et[k]==0)continue;
                if(j==k){
                    if(ns==nt)ans+=a[j][k];
                    continue;
                }
                int ss=ns,tt=nt;
                if(es[j]==1)ss--;
                if(es[k]==0)ss++;
                if(et[k]==1)tt--;
                if(et[j]==0)tt++;
                if(ss==tt)ans+=a[j][k];
            }
        }
        es[y]--;
        et[y]++;
        if(es[y]==0)ns--;
        if(et[y]==1)nt++;
        es[x]++;
        et[x]--;
        if(es[x]==1)ns++;
        if(et[x]==0)nt--;
        a[x][y]++;
   }
   ans/=2;
   ans%=mod;
   cout<<ans<<'\n';
}