#include <iostream>
#include <cstdio>
#include <bits/stdc++.h>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;
typedef long long ll;

ll n, m;
ll k=0;
bool e=0;
int main()
{
   cin>>n>>m;
   while(m!=1)
   {
if(n%m==0) {cout<<"NO";return 0;}
m--;



   }
   cout<<"YES";
   return 0;
}