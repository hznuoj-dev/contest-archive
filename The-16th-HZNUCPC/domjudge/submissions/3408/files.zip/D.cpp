#include <bits/stdc++.h>
#define ll int
#define Ma 1000005
#define mod 1000000007
#define N 26
#define PLL pair<ll,ll>
#define ls p<<1
#define rs p<<1|1
#define inf 1e9
using namespace std;

ll n,m,x;
ll pp[Ma];


struct node{
	ll ti,l,r,num;
	bool operator <(const node &A)const{
		if (ti==A.ti)
			return num<A.num;
		return ti<A.ti;
	}
}a[Ma];
ll tot=0,cnt=0;

struct segtree
{
	ll l,r,ma,mi,add;
}t[Ma<<2];

void build(ll p,ll l,ll r)
{
	t[p].l=l,t[p].r=r,t[p].ma=t[p].mi=t[p].add=inf;
	if (l==r)
		return;
	ll mid=(l+r)>>1;
	build(ls,l,mid),build(rs,mid+1,r);
	return;
}

void up(ll p)
{
	//if (t[p].add==inf)
	t[p].ma=min(t[p].ma,max(t[ls].ma,t[rs].ma));
	t[p].mi=min(t[ls].mi,t[rs].mi);
	return;
}

void spread(ll p)
{
	if (t[p].add!=inf)
	{
		t[ls].ma=min(t[ls].ma,t[p].add);
		t[rs].ma=min(t[rs].ma,t[p].add);
		t[ls].mi=min(t[ls].mi,t[p].add);
		t[rs].mi=min(t[rs].mi,t[p].add);
		t[ls].add=min(t[ls].add,t[p].add);
		t[rs].add=min(t[rs].add,t[p].add);
		t[p].add=inf;
	}
	return;
}

void change(ll p,ll l,ll r,ll d)
{
	if (l<=t[p].l&&t[p].r<=r)
	{
		t[p].ma=min(t[p].ma,d);
		t[p].mi=min(t[p].mi,d);
		t[p].add=min(t[p].add,d);
		return;
	}
	spread(p);
	ll mid=(t[p].l+t[p].r)>>1;
	if (l<=mid&&t[ls].ma>d) change(ls,l,r,d);
	if (r>mid&&t[rs].ma>d) change(rs,l,r,d);
	up(p);
	return;
}

ll ask(ll p,ll l,ll r)
{
	if (l<=t[p].l&&t[p].r<=r) return t[p].mi;
	spread(p);
	ll mid=(t[p].l+t[p].r)>>1;
	ll val=inf;
	if (l<=mid) val=min(val,ask(ls,l,r));
	if (r>mid) val=min(val,ask(rs,l,r));
	return val;
}

ll ans[Ma];

void sol()
{
	scanf("%d%d%d",&n,&m,&x);
	for (ll i=1;i<=n;i++)
		tot++,scanf("%d%d%d",&a[tot].ti,&a[tot].l,&a[tot].r),pp[++cnt]=a[tot].l,pp[++cnt]=a[tot].r;
	for (ll i=1;i<=m;i++)
		tot++,scanf("%d%d",&a[tot].ti,&a[tot].l),pp[++cnt]=a[tot].l,a[tot].r=a[tot].l,a[tot].num=i;
	pp[++cnt]=x;
	
	sort(pp+1,pp+cnt+1);
	sort(a+1,a+tot+1);
	cnt=unique(pp+1,pp+cnt+1)-(pp+1);
	build(1,1,cnt);
	//printf("cnt=%d pma=%d\n",cnt,pp[cnt]);
	change(1,cnt,cnt,0);
	//printf("OK:%d\n",ask(1,cnt,cnt));
	for (ll i=1;i<=tot;i++)
	{
		if (a[i].num)
		{
			ll l=lower_bound(pp+1,pp+cnt+1,a[i].l)-pp,r=lower_bound(pp+1,pp+cnt+1,a[i].r)-pp;
			//printf("go l=%d r=%d\n",pp[l],pp[r]);
			ll w=ask(1,l,r);
			if (w==inf)
				ans[a[i].num]=-1;
			else
				ans[a[i].num]=w;
		}
		else
		{
			ll l=lower_bound(pp+1,pp+cnt+1,a[i].l)-pp,r=lower_bound(pp+1,pp+cnt+1,a[i].r)-pp;
			//printf("change l=%d r=%d\n",pp[l],pp[r]);
			ll w=ask(1,l,r)+1;
			//printf("w=%d\n",w);
			change(1,l,r,w);
		}
	}
	for (ll i=1;i<=m;i++)
		printf("%d\n",ans[i]);
	return;
}

int main ()
{
	sol();
	return 0;
}