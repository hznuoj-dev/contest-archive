#include<bits/stdc++.h>

using namespace std;


typedef long long ll;



int x[20][20];
int gox[4]={-1,1,0,0};
int goy[4]={0,0,1,-1};
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n;
        int cnt=0;
        memset(x,0,sizeof(x));
        scanf("%d",&n);
        while(n--){
            int a,b,v;
            scanf("%d%d%d",&a,&b,&v);
            x[a][b] = v;
        }
        for(int i=1;i<=19;i++){
            for(int j=1;j<=19;j++){
                if(x[i][j]==1){
                    for(int q = 0;q<4;q++){
                        int goa = i+gox[q];
                        int gob = j+goy[q];
                        if(goa<1||goa>19||gob<1||gob>19)
                            continue;
                        if(x[goa][gob]==2)
                            continue;
                        if(x[goa][gob] == 0){
                            cnt++;
                        }
                    }
                }
            }
        }
        printf("%d\n",cnt);
    }
}
