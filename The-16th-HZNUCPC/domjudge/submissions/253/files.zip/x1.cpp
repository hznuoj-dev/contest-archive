#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=300005;
LL mod=1e9+7;
int a[105],b[105];
LL cx(LL x1,LL y1,LL x2,LL y2){
	return x1*y2-x2*y1;
}
LL cal(LL x,LL y){
	x=abs(x),y=abs(y);
	return __gcd(x,y);
}
int main(){
#ifndef ONLINE_JUDGE
	//freopen("in.txt","r",stdin);
#endif
	int _;
	scanf("%d",&_);
	while(_--){
		int n;
		scanf("%d",&n);
		set<pair<int,int>> s1,s2;
		for (int i=1;i<=n;i++) {
			int x,y,c;
			scanf("%d%d%d",&x,&y,&c);
			if (c==1) s1.insert({x,y});
			else s2.insert({x,y});
		}
		int dx[4]={-1,1,0,0};
		int dy[4]={0,0,-1,1};
		int ans=0;
		for (auto p:s1) {
			int x=p.first;
			int y=p.second;
			for(int i=0;i<4;i++){
				int nx=x+dx[i], ny=y+dy[i];
				if (nx>=1 and nx<=19 and ny>=1 and ny<=19) {
					if (!s1.count({nx,ny}) && !s2.count({nx,ny}))
 						ans++;
			 	}
			}
		}
		printf("%d\n",ans);
	}
    return 0;
}