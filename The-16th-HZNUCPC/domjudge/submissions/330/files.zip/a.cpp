#include <bits/stdc++.h>
using namespace std;
using i64 = long long;

void solve(){
	int n;
	cin >> n;

	vector<vector<int>> g(22, vector<int>(22));
	while(n --){
		int x,y,z;
		cin >> x >> y >> z;
		g[x][y] = z;
	}


	int tx[] = {0,0,1,-1};
	int ty[] = {1,-1,0,0};

	i64 ans = 0;
	auto check = [&](int x, int y){
		if(g[x][y] == 0){
			for(int i = 0; i < 4; i ++){
				int X = x + tx[i], Y = y + ty[i];
				if(g[X][Y] == 1){
					ans ++;
				}
			}
		}
	};
	for(int i = 1; i <= 19; i ++){
		for(int j = 1; j <= 19; j ++){
			check(i,j);
			//cout << ans << '\n';
		}
	}

	cout << ans << '\n';
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int T;
	cin >> T;

	while(T --)
		solve();
	return 0;
}
