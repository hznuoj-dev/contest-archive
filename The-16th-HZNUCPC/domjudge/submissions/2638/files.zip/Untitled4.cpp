#include<iostream>
#include<cstring>
#include<algorithm>
#include<cmath>

#define read(x) scanf("%d", &x)
#define readll(x) scanf("%lld", &x)
#define out(x) printf("%d", x)

#define X first
#define Y second

using namespace std;

const int N = 110, inf = 0x3f3f3f3f;

const double eps = 1e-6;

typedef long long LL;

typedef pair<LL, LL> PLL;

PLL w[N];
int n;

LL gcd(LL a, LL b){
	return b ? gcd(b, a % b) : a;
}

int main(){
	read(n);
	for(int i = 1; i <= n; i++){
		LL x, y;
		readll(x), readll(y);
		w[i] = {x, y};
	}
	
	LL res = 0;
	for(int i = 1; i <= n; i++){
		for(int j = i + 1; j <= n; j++){
			for(int k = j + 1; k <= n; k++){
				LL cnt1 = 0, cnt2 = 0, cnt3 = 0;
				double k1 = inf, k2 = inf, k3 = inf;
				if(w[i].X == w[j].X){
					cnt1 = abs(w[i].Y - w[j].Y);
				}else{
					k1 = (w[i].Y - w[j].Y) * 1.0 / (w[i].X - w[j].X);
					cnt1 = gcd(abs(w[i].X - w[j].X), abs(w[i].Y - w[j].Y));
				}
				
				if(w[j].X == w[k].X){
					cnt2 = abs(w[j].Y - w[k].Y);
				}else{
					k2 = (w[j].Y - w[k].Y) * 1.0 / (w[j].X - w[k].X);
					cnt2 = gcd(abs(w[j].X - w[k].X), abs(w[j].Y - w[k].Y));
				}
				
				if(w[i].X == w[k].X){
					cnt3 = abs(w[i].Y - w[k].Y);
				}else{
					k3 = (w[k].Y - w[i].Y) * 1.0 / (w[k].X - w[i].X);
					cnt3 = gcd(abs(w[i].X - w[k].X), abs(w[i].Y - w[k].Y));
				}
				
				if(abs(k1 - k2) <= eps && abs(k2 - k3) <= eps && abs(k1 - k3) <= eps) continue;
				
				res = max(res, cnt1 + cnt2 + cnt3);
//				cout << i << " " << j << " " << k << endl;
//				cout << abs(w[i].X - w[j].X) << " " << abs(w[i].Y - w[j].Y) << endl;
//				cout << abs(w[j].X - w[k].X) << " " << abs(w[j].Y - w[k].Y) << endl;
//				cout << abs(w[i].X - w[k].X) << " " << abs(w[i].Y - w[k].Y) << endl;
//				cout << cnt1 << " " << cnt2 << " " << cnt3 << endl;
//				cout << endl;  
			}
		}
	}
	
	printf("%lld", res);
	return 0;
}