#include<bits/stdc++.h>

using namespace std;

#define ios ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define ll long long

int gcd(int a, int b)
{
	while(b^=a^=b^=a%=b);
	return a;
}

struct Stu{
	int x, y;
}f[300];


int dis(Stu a, Stu b)
{
	return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}


bool isok(Stu a, Stu b, Stu c)
{
	int s1 = dis(a, b), s2 = dis(a, c), s3 = dis(b, c);
	return min(s1, min(s2, s3)) + (s1 + s2 + s3 - min(s1, min(s2, s3)) - max(s1, max(s2, s3))) > max(s1, max(s2, s3));
	
}


ll add(Stu a, Stu b)
{
	int cnt = 0;
	if(a.x == b.x) cnt += abs(a.x - b.x);
	
	int fz = a.y - b.y, fm = a.x - b.x;
	if(fz == 0) cnt += abs(a.y - b.y);
	
	int _gcd = gcd(fz, fm);
	fz /= _gcd, fm /= _gcd;
	fz = abs(fz), fm = abs(fm);
	if(fz < fm)
		cnt = cnt + (max(a.x, b.x) - min(a.x, b.x)) * fz / fm + 1;
	else
		cnt = cnt + (max(a.y, b.y) - min(a.y, b.y)) * fm / fz + 1;
//	cout << cnt << endl;
	return cnt;
}

int main()
{
	ios;
	int n; cin >> n;
	for(int i = 1; i <= n; i++) cin >> f[i].x >> f[i].y;
	ll ma = 0;
	
	for(int i = 1; i <= n; i++)
	{
		for(int j = i + 1; j <= n; j++)
		{
			for(int k = j + 1; k <= n; k++)
			{
				if(isok(f[i],f[j],f[k]))
				{
//					cout << i << " " << j << " " << k << endl;
					ll cnt = add(f[i], f[j]) + add(f[i], f[k]) + add(f[j], f[k]) - 3;
					ma = max(0LL, max(ma, cnt));
//					cout << cnt << endl;
				}
			}
		}
	}
	cout << ma << endl;
	
//	cout << isok(f[1], f[2], f[3]) << endl;
	return 0;
}

