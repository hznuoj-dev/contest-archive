#include <iostream>
using namespace std;
int main()
{
    long long int n,m,l,s;
    cin>>n>>m;
    while(m>2)
    {
    	if(n%m==0)
    	{
    		cout<<"NO";
    		break;
		}
		m=n%m;
	}
	if(m==1||n%m!=0)cout<<"YES";
	else cout<<"NO";
    return 0;
}