import java.util.Arrays;
import java.util.Scanner;

public class Main
{
	static boolean boo=false;
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) 
		{
			long piao = sc.nextLong();
			long ren = sc.nextLong();
			digui(piao,ren);
			System.out.println(boo?"YES":"NO");
			 boo=false;
		}
	}

	private static void digui(long piao, long ren)
	{
		if(ren==1)
		{
			boo=true;
			return ;
		}
		if(ren==0)
		{
			boo=false;
			return;
		}
		digui(piao,piao%ren);
	}
}
