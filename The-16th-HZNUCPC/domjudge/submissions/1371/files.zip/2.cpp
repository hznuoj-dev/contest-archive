#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
const int maxn=200;
struct point{
	ll x,y;
}a[maxn];
ll gcd(ll a,ll b)
{
	return a%b==0?b:gcd(b,a%b);
}
signed main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i].x>>a[i].y;
	ll ans=0;
	for(int i=1;i<=n;i++)
	for(int j=i+1;j<=n;j++)
	for(int k=j+1;k<=n;k++)
	{
		if((a[j].y-a[i].y)*(a[k].x-a[i].x)==(a[j].x-a[i].x)*(a[k].y-a[i].y))
		continue;
		
		int a1=abs(a[j].y-a[i].y);
		int a2=abs(a[j].x-a[i].x);
		int b1=abs(a[k].y-a[i].y);
		int b2=abs(a[k].x-a[i].x);
		int c1=abs(a[j].y-a[k].y);
		int c2=abs(a[j].x-a[k].x);
		int cnt=0;
		if(a1==0)
		cnt+=a2-1;
		if(a2==0)
		cnt+=a1-1;
		
		if(b1==0)
		cnt+=b2-1;
		if(b2==0)
		cnt+=b1-1;
		
		if(c1==0)
		cnt+=c2-1;
		if(c2==0)
		cnt+=c1-1;
		if(a1!=0&&a2!=0)
		cnt+=gcd(a1,a2)-1;
		if(b1!=0&&b2!=0)
		cnt+=gcd(b1,b2)-1;
		if(c1!=0&&c2!=0)
		cnt+=gcd(c1,c2)-1;
		ans=max(ans,cnt+3);
	}
	cout<<ans<<'\n';
}