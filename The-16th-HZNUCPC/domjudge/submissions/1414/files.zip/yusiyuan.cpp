#include<iostream>
#include<cstring>
#include<algorithm>

#define read(x) scanf("%d", &x)
#define readll(x) scanf("%lld", &x)
#define out(x) printf("%d", x)
#define out(x) printf("%lld", x)

using namespace std;

typedef long long LL;

const int N = 30;

LL n, m;

int main(){
	readll(n), readll(m);
	if(m == 1 || n == 1) puts("YES");
	else{
		bool f = 0;
		if(n % m == 1){
			f = 1;
		}
		else{
			while(n % m != 0){
				m = n % m;
				if(n % m == 1){
					f = 1;
					break;
				}
			}
		}
		
		if(f) puts("YES");
		else puts("NO");
	}
	return 0;
}

//int main(){
//	readll(n),readll(m);
//	LL x,y;
//	x=n;
//	y=m;
//	if(n%m==0){
//		puts("No");
//		return 0;
//	}
//	while(x%y){
//		n=x,m=y;
//		if(n%m==0){
//			puts("No");
//			return 0;
//		}
//		x=n/m;
//		y=n%m;
//		n=x,m=y;
//		if(n<m){
//			puts("No");
//			return 0;
//		}
//	}
//	return 0;
//}