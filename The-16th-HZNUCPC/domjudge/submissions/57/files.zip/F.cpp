#include<bits/stdc++.h>
using namespace std;
int main(){
    long long  a,b;
    scanf("%lld%lld",&a,&b);
    while(b!=1&&b!=0){
        b=a%b;
    }
    if(b==0){
        printf("NO\n");
    }else{
        printf("YES\n");
    }
    return 0;
}