#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int>pii;
const int N = 1e5 + 10;

struct Edge{
	int v, w;
};

vector<Edge> e[N];

int color[N], vis[N], ok = 1, tot;

vector<int> p[N][2];

void dfs(int u, int f){
	if(vis[u]){
		if(color[u] != f) ok = 0;
		return;
	}
	vis[u] = 1;
	color[u] = f;
	p[tot][f].push_back(u);
	for(int i = 0; i < e[u].size(); i++){
		int v = e[u][i].v, w = e[u][i].w;
		dfs(v, f ^ w);
	}
}

int ans[N], w[N];
int dp[N], pre[N];

void kaibai(){
	int n, q, m;
	cin >> n >> q >> m;
	for(int i = 0, u, v, w; i < m; i++){
		cin >> w >> u >> v;
		e[u].push_back({v, w});
		e[v].push_back({u, w});
	}
	for(int i = 1; i <= n; i++){
		if(!vis[i]){
			tot++;
			dfs(i, 0);
		}
	}
	if(!ok){
		cout << "NO\n";
		return;
	}
	for(int i = 1; i <= n; i++){
		if(p[i][1].size() < p[i][0].size()){
			ans[i] = 1;
		}
		w[i] = abs((int)p[i][1].size() - (int)p[i][0].size());
		q -= p[i][ans[i]].size();
	}
	if(q < 0){
		cout << "NO\n";
		return;
	}
	dp[0] = 1;
	for(int i = 1; i <= n; i++){
		if(!w[i]) continue;
		for(int j = q - w[i]; j >= 0; j--){
			if(dp[j] && !dp[j + w[i]]){
				dp[j + w[i]] = 1;
				pre[j + w[i]] = i;
			}
		}
		if(dp[q]) break;
	}
	if(!dp[q]){
		cout << "NO\n";
		return;
	}
	while(true){
		int pp = pre[q];
		if(!pp) break;
		ans[pp] ^= 1;
		q -= w[pp];
	}
	cout << "YES\n";
	for(int i = 1; i <= tot; i++){
		for(int j : p[i][ans[i]]){
			cout << j << ' ';
		}	
	}
}

int main(void){
	int T=1;
	ios::sync_with_stdio(false);
//	cin >> T;
	while(T--){
		kaibai();
	}
}