#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll sum[12][12],st,output;
ll xl,yu,xr,yd,j;
ll n,m,q;
struct aa
{
	ll y;ll x;
	bool operator<(const aa &a)const
	{
		return sum[y][x]>sum[a.y][a.x];
	}
	
};
set<aa>arr;
ll cal(ll bas,ll x)
{
	return (bas+10-x)/10;
}
void solve(){  
   cin>>n>>m>>q;
   //n=1000;m=1000;q=10000;
   for(ll i=1;i<=n;i++)for(ll j=1;j<=m;j++)cin>>st,sum[i%10][j%10]+=st;
   while(q--)
   {
   	  /////////cin>>j>>xl>>yu>>xr>>yd>>st;
   	  cin>>j>>yu>>xl>>yd>>xr>>st;
   	  //if(q)j=1;else j=2;
      //yu=xl=1;yd=xr=1000;st=1;
   	  if(j==1)
   	  {
   	  	  for(ll i=0;i<10;i++)for(ll j=0;j<10;j++)
   	  	  {
   	  	  	sum[i][j]+=1ll*(cal(xr,j)-cal(xl-1,j))*(cal(yd,i)-cal(yu-1,i))*st;
		}
	  }
	  else
	  {
	  	//for(ll i=0;i<10;i++)
		 // {
		  //for(ll j=0;j<10;j++)cout<<sum[i][j]<<" ";cout<<'\n';
	//}
	  	output=0;arr.clear();
	  	  for(ll i=0;i<10;i++)for(ll j=0;j<10;j++)
	  	  {
	  	  	output+=sum[i][j];
	  	  	if(1ll*(cal(xr,j)-cal(xl-1,j))*(cal(yd,i)-cal(yu-1,i))>0)arr.insert({i,j});
		 }
		 for(auto k:arr)
		 {
		 	if(!st)break;
		 	output+=sum[k.y][k.x];
		 	//cout<<k.y<<"*"<<k.x<<"*"<<sum[k.y][k.x]<<'\n';
		 	st--;
		 }
		 cout<<output<<'\n';
	  }
   }
}

int main(){
	//freopen("1.in","r",stdin);
	ll t=1;//std::cin>>t;
	while( t-- )
		solve();
}