#include<stdio.h>
int main(){
	int t,n,ii,jj,l,sum;
	int s[21][21];
	scanf("%d",&t);
	for (int i=1;i<=t;i++){
		scanf("%d",&n);
		sum=0;
		int count1=0,count2=0;
		
		for (int j=0;j<20;j++){
			for (int k=0;k<20;k++){
				s[j][k]=0;
			}
		}
		for (int j=1;j<=n;j++){
			scanf("%d %d %d",&ii,&jj,&l);
			if (l==1){
				s[ii][jj]=2;
				count1++;
			}else{
				s[ii][jj]=1;
				count2++;
			}
			
			if (l==1){
   			if (s[ii-1][jj]==0&&ii-1>=0){
				s[ii-1][jj]=1;
			}
            
        	if (s[ii+1][jj]==0&&ii+1<=19){
        	s[ii+1][jj]=1;
		}
            
        	if (s[ii][jj-1]==0&&jj-1>=0){
        	s[ii][jj-1]=1;
		}
            
        	if (s[ii][jj+1]==0&&jj+1<=19){
        	s[ii][jj+1]=1;
		}         
	}
		}
		for (int j=0;j<20;j++){
			for (int k=0;k<20;k++){
				sum+=s[j][k];
			}
		}
		printf("%d",sum-count1*2);
	}
	return 0;
}