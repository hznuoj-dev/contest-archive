#include <bits/stdc++.h>
#define int int64_t
#define endl '\n'
using namespace std;
const int MAX = 7e5+10;
#define pb push_back

int nodes[MAX];
int fat[MAX];

int root(int x) {
	if (fat[x] == x) return x;
	return fat[x] = root(fat[x]); 
}

void merge(int x, int y) {
	x = root(x);
	y = root(y);
	if (x != y) {
		nodes[y] += nodes[x];
		fat[x] =y;
	}
}

vector<int> a[MAX];
int b[MAX] = {0};
int c[MAX] = {0};
bool dp[MAX] = {0};
int pre[MAX] = {0};
int now[MAX] = {0};
int cnt = 0;

void solve() {
	int n, m, q;
	cin >> n >> q >> m;
	for (int i = 1; i <= n; i++) {
		fat[i] = i;
		nodes[i] = 1;
	}
	for (int i = n + 1; i <= n * 2; i++) {
		fat[i] = i;
		nodes[i] = 0;
	}
	for (int i = 0; i < m; i++) {
		int k, a, b;
		cin >> k >> a >> b;
		if (k == 0) {
			merge(a, b);
		} else {
			merge(a + n, b);
		}
	}
	for (int i = 1; i <= n; i++) {
		if (root(i) == root(i + n)) {
			cout << "NO" << endl;
			return;
		}
	}
	for (int i = 1; i <= n; i++) {
		if (root(i) == i) {
			a[nodes[i]].pb(i);
		}
	}
	for (int i = 1; i <= n; i++) {
		int len = a[i].size();
		vector<int> vec = a[i];
		a[i].clear();
		while (len) {
			int k = vec.back();
			vec.pop_back();
			for (int j = (len + 1) / 2; j > 1; j--) {
				int kk = vec.back();
				vec.pop_back();
				merge(kk, k);
			}
			a[(len + 1) / 2 * i].pb(k);
			len >>= 1;
		}
	}
	for (int i = 1; i <= n; i++) {
		while (a[i].size()) {
			b[cnt] = i;
			c[cnt] = a[i].back();
			cnt++;
			a[i].pop_back();
		}
	}
	dp[0] = true;
	pre[0] = 0;
	for (int i = 0; i < cnt; i++) {
		for (int j = q; j >= b[i]; j--) {
			if (dp[j-b[i]]) {
				dp[j] = true;
				pre[j] = j-b[i];
				now[j] = c[i];
			}
		}
	}
	if (dp[q]) {
		cout << "YES" << endl;
		int x = q;
		set<int> res;
		while (x) {
			res.insert(now[x]);
			x = pre[x];
		}
		for (int i = 1; i <= n; i++) {
			if (res.count(root(i))) {
				cout << i << ' ';
			}
		}
		cout << endl;
	} else {
		cout << "NO" << endl;
	}
}

int32_t main() {
	cin.tie(0);
	cout.tie(0);
	ios::sync_with_stdio(false);
	solve();
	return 0;
}







