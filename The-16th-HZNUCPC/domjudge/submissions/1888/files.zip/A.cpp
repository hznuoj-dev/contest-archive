#include<iostream>
#include<cstring>
using namespace std;
int mp[20][20];

int f(int i, int j){
	int cnt=0;
	if((i-1>=1&&mp[i-1][j]==0)||(i+1<=19&&mp[i+1][j]==0)||(j-1>=1&&mp[i][j-1]==0)||(j+1<=19&&mp[i][j+1]==0)){
		if(i-1>=1&&mp[i-1][j]==0) cnt++;
		if(i+1<=19&&mp[i+1][j]==0) cnt++;
		if(j-1>=1&&mp[i][j-1]==0) cnt++;
		if(j+1<=19&&mp[i][j+1]==0) cnt++;
	}
	else if((i-1<1||mp[i-1][j]==2)&&(i+1>19||mp[i+1][j]==2)&&(j-1<1||mp[i][j-1]==2)&&(j+1>19||mp[i][j+1]==2)){
		return cnt;
	}
	else{
		if(mp[i-1][j]==1) f(i-1,j);
		else if(mp[i+1][j]==1) f(i+1,j);
		else if(mp[i][j-1]==1) f(i,j-1);
		else if(mp[i][j+1]==1) f(i,j+1);
	}
	return cnt;
}

int main(){
	int T;
	int ans=0;
	scanf("%d",&T);
	memset(mp,0,sizeof(mp));
	while(T--){
		memset(mp,0,sizeof(mp));
		int n,x,y,c;
		int a=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%d%d%d",&x,&y,&c);
			mp[x][y]=c;
		}
		for(int i = 1;i<=19;i++){
			for(int j = 1;j<=19;j++){
				if(mp[i][j]==1)//black
				{
					ans+=f(i,j);
				}
			}
		}
		printf("%d",ans);
	}
return 0;
}