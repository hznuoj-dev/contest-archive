#include <iostream>
#include <cstdio>
#include <bits/stdc++.h>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;



int main()
{
    int long long n,m;
    cin>>n>>m;
    while(1){
        if(n%m==0){
            cout<<"NO";
            break;
        }
        if(n%m==1){
            cout<<"YES";
            break;
        }
        if(n%(n%m)!=0)
            m=n%m;
    }
    return 0;
}