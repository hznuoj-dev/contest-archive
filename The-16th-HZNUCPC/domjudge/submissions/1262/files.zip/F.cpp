#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
    ll n,m,a,b;
    cin>>n>>m;
    if(m==1)cout<<"YES"<<endl;
    else if(n<=m||n%m==0){
		cout<<"NO"<<endl;
		return 0;
    }else{
    	for(ll i=2;i*i<=m;i++){
    		if(n%i==0){
    			cout<<"NO"<<endl;
    			return 0;
			}
		}
	}
    cout<<"YES"<<endl;
    return 0;
}
