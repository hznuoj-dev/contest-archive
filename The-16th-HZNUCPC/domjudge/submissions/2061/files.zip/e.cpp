#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll x[101][2]={0};
map<ll,ll>mp[101];
ll y[101][101]={0};
ll f(ll a,ll b){
	ll u,v;
	u=abs(x[a][0]-x[b][0]);
	v=abs(x[a][1]-x[b][1]);
	return  __gcd(u,v)-1;
}
void solve()
{
    ll ans=0;
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>x[i][0]>>x[i][1];
		for(int j=0;j<i;j++){
			y[i][j]=f(j,i);
		}
	}
	/*for(int i=0;i<n;i++){
		for(int j=0;j<i;j++){
			cout<<y[i][j]<<" ";
		}
		cout<<"\n";
	}*/
	for(int i=0;i<n;i++){
		for(int j=0;j<i;j++){
			ll temp=y[i][j];
			for(int k=i+1;k<n;k++){
				ll temp2=temp+y[k][j]+y[k][i];
				if(temp2>ans)ans=temp2;
			}
		}
	}
    cout<<ans+3;
}
int main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	ll t=1;
	//cin>>t;
	while(t--)
	{
		solve();
		cout<<'\n';
	}
}