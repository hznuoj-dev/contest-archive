#include <bits/stdc++.h>
using namespace std;
typedef pair<int,int> PII;
struct Node{
	int x, y;
}a[1010];
int dx[5] = {0, 1, 0, -1};
int dy[5] = {1, 0, -1, 0};
map<PII,int> mp;

bool check(int x, int y)
{
	return (x>=1 && x<=19 && y>=1 && y<=19);
}
int main(){
	int t;
	scanf("%d",&t);
	while(t --){
		int n, cnt=0;
		scanf("%d",&n);
		int x, y, c;
		for(int i=1; i<=n; i++){
			scanf("%d%d%d",&x,&y,&c);
			mp[{x,y}] = c;		
		}
		for(int i=1; i<=19; i++)
		{
			for(int j=1; j<=19; j++){
				if(mp[{i, j}]==1){
					for(int k=0; k<4; k++){
						int xx=i+dx[k], yy=j+dy[k];
						if(check(xx,yy) && mp[{xx,yy}]==0){
							cnt ++;
						}
					}
				}
			}
		}
		mp.clear();
		printf("%d\n",cnt);
	}
	
	
	return 0;
}
