#include<iostream>
#include<vector>
#include<string>
#include<cmath>
#include<unordered_map>
#include<algorithm>
using namespace std;
typedef long long LL;
#define int long long
const int P = 1e9 + 7;
signed main()
{
	cin.tie(0);cout.tie(0);
	ios::sync_with_stdio(false);
	string a,b;
	cin>>a>>b;
	vector<int> ca(26,0),cb(26,0);
	int n = a.size();
	for(int i = 0;i<n;++i) ++ca[a[i]- 97];
	for(int i = 0;i<n;++i) ++cb[b[i]- 97];
	int diff = 0;
	for(int i =0;i<26;++i)
	{
		if(ca[i]) ++diff;
		if(cb[i]) --diff;
	}
	vector<vector<int>> cnt(26,vector<int>(26,0));
	for(int i = 0;i<n;++i)
		++cnt[a[i]- 97][b[i] - 97];
	LL r1 = 0,r2 = 0;
	for(int i = 0;i<26;++i)
		for(int j = 0;j<26;++j)
		{
			if(!cnt[i][j]) continue;
			for(int p = 0;p<26;++p)
				for(int q = 0;q<26;++q)
				{
					if(!cnt[p][q]) continue;
					if(i == p && cnt[i][j] + cnt[i][q] < 2) continue;
					if(j == q && cnt[i][j] + cnt[p][j] < 2) continue;
					int d = diff;
					if(ca[i] == 1) --d;
					if(cb[i] == 0) --d;
					if(cb[j] == 1) ++d;
					if(ca[j] == 0) ++d;
					--ca[i],++cb[i];
					--cb[j],++ca[j];
					if(ca[p] == 1) --d;
					if(cb[p] == 0) --d;
					if(cb[q] == 1) ++d;
					if(ca[q] == 0) ++d;
					++ca[i],--cb[i];
					++cb[j],--ca[j];
					if(!d) 
					{
						if(i == p && j == q) 
							r1 += cnt[i][j] * (cnt[i][j] - 1) / 2;
						else r2 += cnt[i][j] * cnt[p][q];
//						cout << i << ' ' << j << ' ' << p <<' ' << q <<'\n';
//						cout << res<<endl;
					}
					
				}
		}
		cout << (r1 + r2 /2) % P;
}
