#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
signed main()
{
    ios::sync_with_stdio(0);

    ll n,m;
    cin>>n>>m;
    if(m==1||n==1){
        cout<<"YES"<<endl;
        return 0;
    }
    if(m>=n){
        cout<<"NO"<<endl;
        return 0;
    }
    for(ll i=2;i<=min(1000000ll+10,m);i++){
        if(n%i==0) {
            cout<<"NO"<<endl;
            return 0;
        }
    }
    cout<<"YES"<<endl;
}
