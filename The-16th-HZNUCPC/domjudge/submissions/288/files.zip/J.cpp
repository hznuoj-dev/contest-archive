#include<bits/stdc++.h>

#define ll long long

using namespace std;

const int maxn=1024;

int s[maxn][maxn];
int ss[maxn];
bool vis[maxn];
vector<int>v;

bool cmp(int x,int y){
	return x<y;
}
int main()
{
	int n,m;
	while(~scanf("%d %d",&n,&m))
	{
		memset(s,0x3f,sizeof(s));
		memset(vis,0,sizeof(vis));
		memset(ss,0x3f,sizeof(ss));
		v.clear();
		while(m--)
		{
			int a,b,x;
			scanf("%d %d %d",&a,&b,&x);
			s[a][b]=min(s[a][b],x);
			s[b][a]=min(s[b][a],x);
		}
		int minn=INT_MAX;
		int id=1;
		int t=0;
		while(t<n)
		{
			minn=INT_MAX;
			vis[id]=1;
			t++;
			for(int i=1;i<=n;i++)
			{
				if(vis[i]==0)
				{
					ss[i]=min(ss[i],s[id][i]);
					if(ss[i]<minn)
					{
						minn=ss[i];
						id=i;
					}
				}
			}
			v.push_back(minn);
		}
		int len=v.size();
		id=-1;
		sort(v.begin(),v.end(),cmp);
		for(int i=0;i<len;i++)
		{
			if(v[i]!=i)
			{
				id=i;
				break;
			}
		}
		if(id==-1)
		{
			id=len;
		}
		printf("%d\n",id);
	}
	return 0;
}
