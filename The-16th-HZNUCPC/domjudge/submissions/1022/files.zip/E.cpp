#include <bits/stdc++.h>

#define dbg(x...) \
    do { \
        std::cout << #x << " -> "; \
        err(x); \
    } while (0)

void err() {
    std::cout << std::endl;
}

template<class T, class... Ts>
void err(T arg, Ts &... args) {
    std::cout << arg << ' ';
    err(args...);
}

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using i128 = __int128;

void run(int tCase) {
    int n;
    std::cin >> n;
    using p = std::pair<int, int>;
    std::vector<p> v(n);
    for (auto &[x, y]: v) {
        std::cin >> x >> y;
    }
    auto in_a_line = [&](int i, int j, int k) {
        int dx1 = v[i].first - v[j].first;
        int dx2 = v[i].first - v[k].first;
        int dy1 = v[i].second - v[j].second;
        int dy2 = v[i].second - v[k].second;
        return 1ll * dy2 * dx1 == 1ll * dx2 * dy1;
    };
    auto calc = [&](int i, int j) {
        int dx = v[i].first - v[j].first;
        dx = std::abs(dx);
        int dy = v[i].second - v[j].second;
        dy = std::abs(dy);
        return std::gcd(dx, dy);
    };
    ll ans = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            for (int k = j + 1; k < n; ++k) {
                if (in_a_line(i, j, k)) continue;
                ll t = 0;
                t += calc(i, j);
                t += calc(j, k);
                t += calc(i, k);
                ans = std::max(ans, t);
            }
        }
    }
    std::cout << ans << '\n';
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int T = 1;
//    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        run(t);
    }
    return 0;
}