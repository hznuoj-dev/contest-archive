#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long int n,m;
	cin >> n >> m;
	cout << __gcd(n,m) << endl;
	if (__gcd(n,m)==1)cout << "YES" << endl;else cout << "NO" << endl;	
	return 0;
}