#include<bits/stdc++.h>
using namespace std;

int n;
int x[110],y[110];
int maxn;
int ans=0;
int cnt=0;

int main()
{
	
	cin >> n;
	
	for(int i=1;i<=n;i++)	cin >> x[i] >> y[i];
	
	maxn=0;
	
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i!=j)
				for(int k=1;k<=n;k++)
				{
					if(j!=k && i!=k)
					{
						cnt=0;
						int a1=x[i],a2=x[j],a3=x[k];
						int b1=y[i],b2=y[j],b3=y[k];
						int c1=abs(a1-a2),c2=abs(a2-a3),c3=abs(a1-a3);
						int d1=abs(b1-b2),d2=abs(b2-b3),d3=abs(b1-b3);
//						cout << a1 << ' ' << a2 << ' ' << a3 << ' ' << b1 << ' ' << b2 << ' ' << b3 << endl;
						if(c1==0||c2==0||d1==0||d2==0){
							if(c1==0){
								if(c2==0){
									if(d1==d2)
									continue;
								}
							}else if(d1==0){
								if(d2==0){
									if(c1==c2)
									continue;
								}
							}
						}
						if(c1*d2!=c2*d1)
						{
							cnt=0;
							if(a1==a2)
							{
								cnt+=max(abs(b1-b2)-1,0);	
							}
							else if(b1==b2)
							{
								cnt+=max(abs(a1-a2)-1,0);
							}
							else 
							{
								int cnt1=abs(a1-a2);
								int cnt2=abs(b1-b2);
								if(cnt1 >= cnt2)
								{
									if(cnt1%cnt2==0)
									{
										cnt+=max(cnt2-1,0);
									}
								}
								if(cnt1 < cnt2)
								{
									if(cnt2%cnt1==0)
									{
										cnt+=max(cnt1-1,0);
									}
								}
							}
							if(a3==a2)
							{
								cnt+=max(abs(b3-b2)-1,0);	
							}
							else if(b3==b2)
							{
								cnt+=max(abs(a3-a2)-1,0);
							}
							else 
							{
								int cnt1=abs(a3-a2);
								int cnt2=abs(b3-b2);
								if(cnt1 >= cnt2)
								{
									if(cnt1%cnt2==0)
									{
										cnt+=max(cnt2-1,0);
									}
								}
								if(cnt1 < cnt2)
								{
									if(cnt2%cnt1==0)
									{
										cnt+=max(cnt1-1,0);
									}
								}
							}
							if(a1==a3)
							{
								cnt+=max(abs(b1-b3)-1,0);	
							}
							else if(b1==b3)
							{
								cnt+=max(abs(a1-a3)-1,0);
							}
							else 
							{
								int cnt1=abs(a1-a3);
								int cnt2=abs(b1-b3);
								if(cnt1 >= cnt2)
								{
									if(cnt1%cnt2==0)
									{
										cnt+=max(cnt2-1,0);
									}
								}
								if(cnt1 < cnt2)
								{
									if(cnt2%cnt1==0)
									{
										cnt+=max(cnt1-1,0);
									}
								}
							}
							cnt+=3;
							maxn=max(maxn,cnt);
						}
						maxn=max(maxn,cnt);
					}
				}
		}
	}
	cout<<maxn<<'\n';
	
	return 0;
}