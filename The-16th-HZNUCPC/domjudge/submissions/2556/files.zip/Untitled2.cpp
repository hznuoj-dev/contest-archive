#include<bits/stdc++.h>
using namespace std;

int l,cnt[10010][26];
string ss;
char s[10010];

int check2(int a,int b){
	int res=0;
	for(int i=1;i<=a && i+b<l;++i){
		if(s[i+b]!=s[a-i]) return res;
		res=i+b-(a-i)+1;
	}
	return res;
}

int check(int a,int b,char c,char ned){//printf("%d %d\n",a,b);
	int res=0;
	for(int i=1;i<=a && i+b<l;++i){
		if(s[a-i]!=s[b+i]){
			if((c==s[a-i] && ned==s[b+i]) || (c==s[b+i] && ned==s[a-i])) return check2(a-i,b+i);
			else return 0;
		}
		if((a!=i && cnt[a-i-1][ned-'a']==0) && cnt[b+i][ned-'a']==cnt[l-1][ned-'a']) return 0;
		res=0;
	}
	return res;
}

int main(){
//	freopen("data.in","r",stdin);
	int T,ans,a,b;
	scanf("%d",&T);
	while(T--){
		cin>>ss;
		l=0;
		for(int i=0;i<26;++i) cnt[0][i]=0;
		s[l++]='*';
		for(int i=0;i<ss.length();++i){
			for(int j=0;j<26;++j) cnt[l][j]=cnt[l-1][j];
			++cnt[l][ss[i]-'a'];
			s[l++]=ss[i];
			for(int j=0;j<26;++j) cnt[l][j]=cnt[l-1][j];
			s[l++]='*';
		}
		ans=1;
//		for(int i=0;i<l;++i) printf("%c",s[i]);puts("");
		for(int i=1;i<l;++i){
			for(int j=1;j<=i && i+j<l;++j){
				if(s[i-j]!=s[i+j]){
					a=check(i-j,i+j,s[i-j],s[i+j]);
					b=check(i-j,i+j,s[i+j],s[i-j]);
					//printf("%d: %d %d\n",i,a,b);
					ans=max(ans,(max(a,b)));
					break;
				}
				else ans=max(ans,2*j+1);
			}
		}
		ans/=2;
		printf("%d\n",ans==1?0:ans);
	}
	return 0;
}