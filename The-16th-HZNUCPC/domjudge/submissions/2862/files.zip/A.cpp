#include<bits/stdc++.h>
#define endl '\n'
typedef long long ll;
using namespace std;
const int N =1e5+10,mod=1e9+7;
int n;
ll P = 23331;
string s;
ll hx[N<<1], res, rhx[N<<1];
ll p1[N<<1];
ll get1(int l, int r) {
	return (hx[r] - hx[l-1] * p1[r-l+1] % mod + mod) % mod ;
}
ll get2(int l, int r) {
	return (rhx[r] - rhx[l-1] * p1[r-l+1] % mod + mod) % mod ;
}
bool check(int l, int r) {
	if(get1(l, r) == get2(l, r)) return true;
	return false;
}

void init() {
	hx[0]=rhx[0] = 1; p1[0] = 1;
	for(ll i = 1; i <= n; i++) {
		(p1[i] = p1[i-1] * P) %= mod;
		(hx[i] = hx[i-1] * P + s[i-1]) %= mod;
		(rhx[i] = hx[i-1] * P + s[n-i]) %= mod;
	}
}

void solve() {
	cin >> s;
	n = s.size();
	//init();
	s=" "+s;
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		int l = i, r = i, temp = s[i];
		while(l>0 && r<=n && s[l]==s[r] ) {
			l--, r++;
		}
		ans = max(ans, r - l - 1);
		if(l==0 || r>n) {
			continue ;
		}
		
		
		int c1 = s[l], c2 = s[r];
		l--, r++;
		while(l>0 && r<=n && s[l]==s[r] ) {
			l--, r++;
		}
		if(temp == c1 || temp == c2) {
			ans = max(ans, r - l - 1);
		}
		if(l==0 || r>n) {
			continue ;
		}
		
		
		int c3 = s[l], c4 = s[r];
		int cnt = 1;
		while(l-cnt>0 && r+cnt<=n && s[l-cnt]==s[r+cnt] ) {
			cnt++;
		}
		cnt--;
		//cout << i << " " << cnt << endl; //
		if(c1==c4&&c2==c3||c1==c3&&c2==c4) {
			ans = max(ans, r-l+1 + 2*cnt);
		}
	}
	//cout << "--" << ans << " ";
	for(int i=1;i<n;i++)
	{
		int l = i, r = i+1;
		while(l>0 && r<=n && s[l]==s[r] ) {
			l--, r++;
		}
		ans = max(ans, r - l - 1);
		if(l==0 || r>n) {
			continue ;
		}
		int c1 = s[l], c2 = s[r];
		l--, r++;
		while(l>0 && r<=n && s[l]==s[r] ) {
			l--, r++;
		}
		if(l==0 || r>n) {
			continue ;
		}
		int c3 = s[l], c4 = s[r];
		int cnt = 1;
		while(l-cnt>0 && r+cnt<=n && s[l-cnt]==s[r+cnt] ) {
			cnt++;
		}
		cnt--; //
		if(c1==c4&&c2==c3||c1==c3&&c2==c4) {
			ans = max(ans, r-l+1 + 2*cnt);
		}
	}
	if(ans != 1) cout << ans << endl;
	else cout << 0 << endl;
}

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int _t = 1;
	cin >> _t;
	while(_t--) {
		solve() ;
	}
}