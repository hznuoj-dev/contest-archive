#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	ll n,m;
	scanf("%lld%lld",&n,&m);
	if(n == 1 || m == 1 || n % m == 1){ 
		cout << "YES" << endl;
		return 0;
	}else{
		if(n%m==0 || m > n){
			cout<<"NO" << endl;       
			return 0;
		}    
		while(1){
			//cout<<m<<endl;
			ll c = n % m;
			m = c;
			if(m == 0){
				cout << "NO" << endl;
				return 0;
			}
			if(m == 1 && n % 2 == 1){
				cout << "YES" << endl;
				return 0;
			}
		}
	}
	
	return 0;
}

	