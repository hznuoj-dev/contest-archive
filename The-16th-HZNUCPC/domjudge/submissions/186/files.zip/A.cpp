#include<bits/stdc++.h>

#define all(a) a.begin(),a.end()
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define pb push_back
#define fi first
#define se second
#define quick ios.sync_with_stdio(false);cout.tie(0);cin.tie(0);

typedef long long ll;
typedef unsigned long long ull;
//typedef pair<ll,ll> PLL;

using namespace std;

ll n,m;

int mp[30][30];

void solve(){
	cin>>n;
	rep(i,0,30)rep(j,0,30)mp[i][j]=0;
	rep(i,0,n){
		ll x,y,c;cin>>x>>y>>c;
		mp[x][y]=c;
	}
	ll ans=0;
	rep(i,0,30)rep(j,0,30){
		if(mp[i][j]==1){
			if(i-1>=1&&mp[i-1][j]==0)ans++;
			if(i+1<=19&&mp[i+1][j]==0)ans++;
			if(j-1>=1&&mp[i][j-1]==0)ans++;
			if(j+1<=19&&mp[i][j+1]==0)ans++;
		}
	}
	cout<<ans<<endl;
}

int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
