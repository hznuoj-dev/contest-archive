#include <bits/stdc++.h>
using namespace std;
  
int main(){
	long long  pre[]={2,3,5,7,11,13,17,19,23,29,31,37,41,2};
    long long  n , m ;
    cin >> n >> m;
    if(m >= n){
    	cout << "NO";
    	return 0 ;
	}else if(m==1){
		cout << "YES";
	}
	else{
		for(int i = 0 ; i <=13;i++ ){
			if(n % pre[i] == 0 && pre[i] != n&& m >= pre[i] ){
				cout << "NO";
				return 0 ;
			}
		}
		cout << "YES";
		
	}
    
    
}