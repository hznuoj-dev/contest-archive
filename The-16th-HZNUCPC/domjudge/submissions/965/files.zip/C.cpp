#include <bits/stdc++.h>
using namespace std;
using ll = long long;

ll dp[30][30];

int main (){
    cin.tie(0)->sync_with_stdio(0);
    string s1, s2;
    cin >> s1 >> s2;
    int n = s1.size();
    int n1 = 0, n2 = 0;
    std::vector<int> v1(30), v2(30);
    for (auto i : s1)
        v1[i - 'a']++;
    for (auto i : s2)
        v2[i - 'a']++;
    for (int i = 0; i < n; ++i) {
        dp[s1[i] - 'a'][s2[i] - 'a']++;
    }
    auto f = [&](char a, char b, char c, char d) {
        v1[a]--, v1[b]++;
        v2[b]--, v2[a]++;
        v1[c]--, v1[d]++;
        v2[d]--, v2[c]++;
        int n1 = 0, n2 = 0;
        for (int i = 0; i < 26; i++)
        {
            n1 += v1[i] > 0;
            n2 += v2[i] > 0;
        }
        v1[b]--, v1[a]++;
        v2[a]--, v2[b]++;
        v1[d]--, v1[c]++;
        v2[c]--, v2[d]++;
        return n1 == n2;
    };
    ll ans = 0;
    for (int i = 0; i < 26; ++i){
        for (int j = 0; j < 26; ++j){
            for (int a = 0; a < 26; ++a) {
                for (int b = 0; b < 26; ++b) {
                    if (i == a &&j == b) {
                        ll x = dp[i][j];
                        if (f(i, j, a, b))
                            ans += x * (x - 1);
                    } else {
                        ll x = dp[i][j], y = dp[a][b];
                        if (f(i, j, a, b))
                            ans += x * y;
                    }
                }
            }
        }
    }
    const int P = 1E9 +7;
    const int iv2 = (P+1) / 2;
    cout << ans  %  P  * iv2 % P;

}

