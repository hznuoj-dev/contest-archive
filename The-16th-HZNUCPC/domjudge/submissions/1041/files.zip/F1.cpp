#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ios::sync_with_stdio(false);
	ll n,m;
	cin>>n>>m;
	if(m==1||n==1) {
		cout<<"YES\n";
		return 0;
	}
	if(n%2==1) {
		ll k=-1;
		for(ll i=2;i*i<=n;i++) {
			if(n%i==0) {
				k=i;
				break;	
			}
		}
		if(k==-1) {
			k=n;
		}
		if(m<k) {
			cout<<"YES\n";
		} else {
			cout<<"NO\n";
		}
	} else {
		cout<<"NO\n";
	}
}