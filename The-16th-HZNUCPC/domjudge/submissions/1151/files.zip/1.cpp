#include<iostream>
#include<vector>
#include<cmath>
#include<algorithm>
using namespace std;
typedef long long LL;
signed main()
{
	cin.tie(0);cout.tie(0);
	ios::sync_with_stdio(false);
	LL n,m;
	cin>>n>>m;
	if(m == 1) 
	{
		cout << "YES";
		return 0;
	}
	if(n % 2 == 0)
	{
		cout << "NO";
		return 0;
	}
	int t = -1;
	int ed = sqrt(n);
	for(int i = 2;i<=ed;++i)
		if(n % i == 0) 
		{
			t = i;
			break;
		}
	if(t == -1 || t > m) cout << "YES";
	else cout << "NO";
}
