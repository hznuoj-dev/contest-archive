#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
const int maxn=1e5+10;
int infact[maxn];
int fact[maxn];
const int mod=1e9+7;
int qpow(int a,int b)
{
	int ret=1;
	while(b)
	{
		if(b&1)
		ret=ret*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ret;
}
int luc(int a,int b)
{
	return fact[b]*infact[a]%mod*infact[b-a]%mod;
}
int mpa[maxn];
int mpb[maxn];
map<pair<char,char>,int>mp;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
//	infact[1]=1;
//	fact[1]=1;
//	for(int i=2;i<maxn;i++)
//	{
//		fact[i]=fact[i-1]*i%mod;
//		infact[i]=infact[i-1]*qpow(i,mod-2)%mod;
//	}
	int inv2=qpow(2,mod-2);
	string a;
	string b;
	cin>>a;
	cin>>b;
	int n=a.size();
	a='#'+a;
	b='#'+b;
	set<char>s1,s2;
	for(int i=1;i<=n;i++)
	{
		s1.insert(a[i]);
		s2.insert(b[i]);
		mpa[a[i]]++;
		mpb[b[i]]++;
		mp[pair<char,char>(a[i],b[i])]++;
	}
	int goal=s1.size()-s2.size();
//	if(goal<0)
//	{
//	swap(a,b);
//	for(int i='a';i<='z';i++)
//	{
//		int t=mpa[i];
//		mpa[i]=mpb[i];
//		mpb[i]=t;
//	}
//	goal=-goal;	
//	}
	int ret=0;
	for(char i1='a';i1<='z';i1++)
	for(char j1='a';j1<='z';j1++)
	{
		for(char i2='a';i2<='z';i2++)
		for(char j2='a';j2<='z';j2++)
		{
			if(mpa[i1]==1&&i1==i2||mpa[i1]==0||mpa[i2]==0||mpb[j1]==0||mpb[j2]==0)
			continue;
//			cout<<i1<<' '<<mpa[i1]<<' '<<j1<<' '<<mpb[j1]<<"????\n";
//			cout<<i2<<' '<<mpa[i2]<<' '<<j2<<' '<<mpb[j2]<<"????\n";
			int ans=0;
			if(mpa[i1]==1&&(mpb[i1]==0))//a 1 b no
			ans-=2;
			else if(mpa[i1]!=1&&!(mpb[i1]==0))//a 1 b yes
			ans-=0;
			else if(mpa[i1]!=1&&(mpb[i1]==0))//a 2 b no
			ans-=1;
			else
			ans-=0;
			mpa[i1]--;
			mpb[i1]++;
			if(mpb[j1]==1&&(mpa[j1]==0))//a 1 b no
			ans+=2;
			else if(mpb[j1]!=1&&!(mpa[j1]==0))//a 1 b yes
			ans+=0;
			else if(mpb[j1]!=1&&(mpa[j1]==0))//a 2 b no
			ans+=1;
			else
			ans+=0;
			mpa[j1]++;
			mpb[j1]--;
			if(mpa[i2]==1&&(mpb[i2]==0))//a 1 b no
			ans-=2;
			else if(mpa[i2]!=1&&!(mpb[i2]==0))//a 1 b yes
			ans-=1;
			else if(mpa[i2]!=1&&(mpb[i2]==0))//a 2 b no
			ans-=1;
			else
			ans-=0;
			mpa[i2]--;
			mpb[i2]++;
			if(mpb[j2]==1&&(mpa[j2]==0))//a 1 b no
			ans+=2;
			else if(mpb[j2]!=1&&!(mpa[j2]==0))//a 1 b yes
			ans+=1;
			else if(mpb[j2]!=1&&(mpa[j2]==0))//a 2 b no
			ans+=1;
			else
			ans+=0;
			mpa[j2]++;
			mpb[j2]--;
			//recover
			mpa[i1]++;
			mpb[i1]--;
			
			mpa[j1]--;
			mpb[j1]++;
			
			mpa[i2]++;
			mpb[i2]--;
			
			mpa[j2]--;
			mpb[j2]++;
			if(-ans==goal)
			{
				if(i1!=i2||j1!=j2)
				ret=(ret+mp[pair<char,char>(i1,j1)]*mp[pair<char,char>(i2,j2)])%mod;
				else
				ret=(ret+mp[pair<char,char>(i1,j1)]*(mp[pair<char,char>(i2,j2)]-1)%mod*inv2)%mod;
			}
			
		}
	}
	cout<<ret;
}