#include<bits/stdc++.h>
using namespace std;
int n,x[110],y[110];
long long ans;
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%d%d",&x[i],&y[i]);
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			for(int k=j+1;k<=n;k++)
			{
				int xa=x[k]-x[i],xb=x[j]-x[i],xc=x[k]-x[j];
				int ya=y[k]-y[i],yb=y[j]-y[i],yc=y[k]-y[j];
				if(1ll*xa*yb==1ll*ya*xb)continue;
				ans=max(ans,1ll*__gcd(abs(xa),abs(ya))+1ll*__gcd(abs(xb),abs(yb))+1ll*__gcd(abs(xc),abs(yc)));
			}
	printf("%lld\n",ans);
	return 0;
}