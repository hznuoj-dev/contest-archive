#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int>PII;
#define pb push_back
void solve(){
    int n,m;
    cin>>n>>m;
    if(m>=n){
        cout<<"NO"<<endl;
    }else{
        if(n%2==0){
            if(m==1)cout<<"YES"<<endl;
            else cout<<"NO"<<endl;
        }else{
            for(int i=2;i*i<=n&&i<=m;i++){
                if(n%i==0){
                    cout<<"NO"<<endl;
                    return ;
                }
            }
            cout<<"YES"<<endl;
        }
    }
    return ;
} 
signed main(){
    int t=1;
    while(t--){
        solve();
    }
    return 0;
}