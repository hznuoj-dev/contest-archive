#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
const ll N=1005;
ll t,n,x[400],y[400],c[400];
bool is[21][21],vis[21][21];
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>t;
    while(t--)
    {
        memset(is,0,sizeof is);
        memset(vis,0,sizeof vis);
        cin>>n;
        for(ll i=1;i<=n;++i)
        {
            cin>>x[i]>>y[i]>>c[i];
            is[x[i]][y[i]]=1;
        }
        ll ans=0;
        for(ll i=1;i<=n;++i)
        {
            if(c[i]==1)
            {
                if(x[i]-1>=1)
                {
                    if(is[x[i]-1][y[i]]==0)++ans;
                }
                if(x[i]+1<=19)
                {
                    if(is[x[i]+1][y[i]]==0)++ans;
                }
                if(y[i]-1>=1)
                {
                    if(is[x[i]][y[i]-1]==0)++ans;
                }
                if(y[i]+1<=19)
                {
                    if(is[x[i]][y[i]+1]==0)++ans;
                }
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}
