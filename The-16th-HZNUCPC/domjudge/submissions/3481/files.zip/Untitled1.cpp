#include<bits/stdc++.h>
using namespace std;
const int N=3e5+7;
const int INF=0x3f3f3f3f;
vector<int>vec;
map<int,int>mp;
int n,m,x,tot;
struct seg{
	int l,r;
	bool operator <(const seg o1)const{
		return r>o1.r;
	}
};
struct{
	int s,t;
	int val;
	int lazy;
}d[N << 2];
void build(int s,int t,int id)
{
	d[id].s = s;
	d[id].t = t;
	d[id].lazy =d[id].val= INF;
	if(s == t){
		d[id].lazy =d[id].val= INF;
		return;
	}
	int mid = s + t>>1;
	build(s,mid,id << 1);
	build(mid + 1,t,id << 1|1);
}
void pushdown(int id)
{
	if(d[id].s == d[id].t || d[id].lazy == INF)return;
	int lz = d[id].lazy;
	d[id].lazy = INF;
	d[id << 1].lazy = min(lz,d[id << 1].lazy);
	d[id << 1|1].lazy = min(lz,d[id << 1|1].lazy);
	d[id << 1].val = min(lz,d[id << 1].val);
	d[id << 1|1].val = min(lz,d[id << 1|1].val);
}
void update(int l,int r,int k,int id)
{
	if(d[id].s > r || d[id].t < l)return;
	if(l <= d[id].s && r>= d[id].t){
//		cout << d[id].s  <<' '<< d[id].t<<'\n';
		d[id].lazy = min(d[id].lazy,k);
		d[id].val = min(d[id].val,k);
		return;
	}
	pushdown(id);
	update(l,r,k,id << 1);
	update(l,r,k,id<< 1 | 1);
	d[id].val = min(d[id<<1].val,d[id<<1|1].val);
}
int query(int l,int r,int id)
{
	if(d[id].s > r || d[id].t < l)return INF;
	if(l <= d[id].s &&r >= d[id].t){
//		cout << "val"<<d[id].val << '\n';
		return d[id].val;
	}
	pushdown(id);
	return min(query(l,r,id << 1),query(l,r,id << 1 | 1));
}
int ans[N];
vector<seg>U[N];
vector<pair<int,int>>Q[N];
signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n>>m>>x;
	vec.push_back(x);
	for(int i=1;i<=n;i++){
		int t,l,r;cin>>t>>l>>r;
		U[t].push_back({l,r});
		vec.push_back(l);vec.push_back(r);
	}
	for(int i=1;i<=m;i++){
		int t,pos;cin>>t>>pos;
		vec.push_back(pos);
		Q[t].push_back({pos,i});
	}
	vec.push_back(-1);
	sort(vec.begin(),vec.end());
	tot=unique(vec.begin(),vec.end())-vec.begin();tot--;
	build(1,tot,1);
	update(tot,tot,0,1);
//	cout << "tot" << tot<<'\n';
	for(int i=1;i<=tot;i++)mp[vec[i]]=i;
	for(int i=1e5;i>=1;i--){
		sort(U[i].begin(),U[i].end());
		for(auto v:U[i]){
			int l=mp[v.l],r=mp[v.r];
			int val=query(r,r,1);
//			cout << "l:r:val:" << l << ' ' << r << ' ' << val << '\n';
			update(l,r,val+1,1);
		}
		for(auto v:Q[i]){
			int id=mp[v.first];
			ans[v.second]=query(id,id,1);
//			cout <<"ans"<<ans[v.second] << '\n';
		}
	}
	for(int i=1;i<=m;i++){
		if(ans[i]>=INF)cout<<"-1\n";
		else cout<<ans[i]<<"\n";
	}
	return 0;
}
/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5
*/