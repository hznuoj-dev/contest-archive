#include <iostream>
#include <cstdio>
#include <bits/stdc++.h>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;



int main()
{
    int long long n,m;
    cin>>n>>m;
    bool judge = 0;
    for(int i=2;i<=m,sqrt(n);i++){
        if(n % i == 0)
        {
            judge = 1;
            break;
        }
    }
    if(judge)
        cout<<"NO";
        else
        cout<<"YES";
    return 0;
}