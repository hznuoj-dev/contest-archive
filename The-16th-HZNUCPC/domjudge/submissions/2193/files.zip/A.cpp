#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod=1e9+7;
int q[100005];
void solve(){
	string s,ss;
	cin>>s>>ss;
	int len=s.length();
	int cnt=0;
	int sum=0;
	for(int i=0;i<len;i++){
		
		if(s[i]!=ss[i]){
			sum++;
		}else{
			if(sum){
				q[cnt++]=sum;
			}
			sum=0;
			q[cnt++]=1;
		}
	}
	int ans=0;
	for(int i=0;i<cnt;i++){
		if(q[i]>1){
			ans+=1;
		}
		ans+=i;
		ans%=mod;
	}
	cout<<ans<<endl;
}
signed main(){
//	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}