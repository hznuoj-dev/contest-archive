#include<bits/stdc++.h>

#define ll long long

using namespace std;

int dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int s[25][25];

int main()
{
	int T;
	while(~scanf("%d",&T))
	{
		while(T--)
		{
			memset(s,0,sizeof(s));
			int n;
			int res=0;
			scanf("%d",&n);
			for(int i=0;i<n;i++)
			{
				int x,y,z;
				scanf("%d %d %d",&x,&y,&z);
				if(s[x][y]==1)
				{
					res--;
				}
				s[x][y]=2;
				if(z==1)
				{
					for(int j=0;j<4;j++)
					{
						int tx=x+dir[j][0];
						int ty=y+dir[j][1];
						if(tx>=1&&tx<=19&&ty>=1&&ty<=19&&s[tx][ty]!=2)
						{
							res++;
							s[tx][ty]=1;
						}
					}
				}
			}
			printf("%d\n",res);
//			for(int i=1;i<=19;i++)
//			{
//				for(int j=1;j<=19;j++)
//				{
//					cout<<s[i][j]<<" ";
//				}
//				cout<<endl;
//			}
		}
	}
	return 0;
}
