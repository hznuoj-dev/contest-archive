#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 2e5 + 10, Mo = 1e9 + 7;
char s[N], s1[N];
int len, f[30], f1[30], g[30][30], sum, x, y, cnt, cnt1;
signed main(){
	scanf("%s", s + 1);
	scanf("%s", s1 + 1);
	len = strlen(s + 1);
	for (int i = 1; i <= len; i++) {
		f[s[i] - 'a']++; 
		if (f[s[i] - 'a'] == 1) cnt++;
		f1[s1[i] - 'a']++;
		if (f1[s1[i] - 'a'] == 1) cnt1++;
		g[s[i] - 'a'][s1[i] - 'a']++;
	}
	for (int i1 = 0; i1 < 26; i1++)
		for (int i2 = i1; i2 < 26; i2++)
			for (int j1 = 0; j1 < 26; j1++)
				for (int j2 = j1; j2 < 26; j2++) {
					if(i1==i2&&j1==j2)
					{
						if(g[i1][j1]<2)continue;
					}
					else
					{
						if(g[i1][j1]<1||g[i1][j2]<1)continue;
					}
					x = cnt, y = cnt1;
					if (i1 != i2) {
						if (f[i1] == 1) x--;
						if (f[i2] == 1) x--;
						if (f1[i1] == 0) y++;
						if (f1[i2] == 0) y++;
					}
					else {
						if (i1 == i2 && f[i1] == 2) x--;
						if (i1 == i2 && f1[i1] == 0) y++;
					}
					if (j1 != j2) {
						if (f1[j1] == 1) y--;
						if (f1[j2] == 1) y--;
						if (f[j1] == 0) x++;
						if (f[j2] == 0) x++;
					}
					else {
						if (j1 == j2 && f1[j1] == 2) y--;
						if (j1 == j2 && f[j2] == 0) x++;
					}
					if (y != x) continue;
					if (i1 == i2 && j1 == j2) {
						sum = (sum + 1LL * g[i1][j1] * (g[i1][j1] - 1) / 2 % Mo) % Mo;
					}
					else sum = (sum + 1LL * g[i1][j1] * g[i2][j2] % Mo) % Mo;
				}
	printf("%lld\n", sum);
}