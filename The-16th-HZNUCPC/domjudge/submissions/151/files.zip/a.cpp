#include <bits/stdc++.h>
using namespace std;

typedef pair<int, int> pii;
vector<pii> v;
int e[22][22];
int main() {
    int T;
    cin >> T;
    while(T--) {
        memset(e, 0, sizeof(e));
        v.clear();
        int n; cin >> n;
        for(int i = 1; i <= n; i++) {
            int a, b, c; scanf("%d%d%d", &a, &b, &c);
            if(c == 1) v.push_back({a, b});
            e[a][b] = 1;
        }
        int ans = 0;
        for(int i = 0; i < v.size(); i++) {
            int x = v[i].first; int y = v[i].second;
            ans += 4;
            if(x - 1 < 1) ans--;
            if(y - 1 < 1) ans--;
            if(x + 1 > 19) ans--;
            if(y + 1 > 19) ans--;
            if(e[x-1][y]) ans--;
            if(e[x][y-1]) ans--;
            if(e[x+1][y]) ans--;
            if(e[x][y+1]) ans--;
        }
        cout << ans << endl;
    }
}
