#include<iostream>
using namespace std;
int main(){
	long long n,m;
	cin >> n >> m;
	string res="NO";
	if(m==1||n==1) res="YES";
	else{
		long long temp=n%m;
		while(temp!=0){
			n=m;
			m=temp;
			temp=n%m;
		}
		if(m==1)res="YES";
	}
	cout << res << endl;
			
}
	