#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define db double
const int N=1e4+10;
int T;
int st[30][30];
struct zc{
	int x,y,z;
}d[N];int n;
void run()
{memset(st,0,sizeof st);
   cin>>n;
for(int i=1;i<=n;i++){
	int a,b,w;
	cin>>a>>b>>w;
	st[a][b]=1;
	d[i].x=a,d[i].y=b,d[i].z=w;
}int ans=0;
for(int i=1;i<=n;i++){
	if(d[i].z==2)continue;
	if(st[d[i].x+1][d[i].y]==0)ans++,st[d[i].x+1][d[i].y]=1;
	if(st[d[i].x-1][d[i].y]==0)ans++,st[d[i].x-1][d[i].y]=1;
	if(st[d[i].x][d[i].y+1]==0)ans++,st[d[i].x][d[i].y+1]=1;
	if(st[d[i].x][d[i].y-1]==0)ans++,st[d[i].x][d[i].y-1]=1;
}
	cout<<ans<<"\n";
	
}
signed  main()
{ios::sync_with_stdio(false);
cin.tie(0);cout.tie(0);
	for(cin>>T;T--;)
	{
		run();
		
	}
return 0;
}