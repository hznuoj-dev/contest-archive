#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long n,m;
	cin>>n>>m;
	if(m==1||n==1)
	{
		cout<<"YES\n";
	}else
	{
		if(n<=m)cout<<"NO\n";
		else if(n%2==0)cout<<"NO\n";
		else
		{
			for(int i=2;i<=sqrt(n);i++)
			{
				if(n%i==0&&(n/i<=m||i<=m))
				{
					cout<<"NO\n";
					return 0;
				}
			}
			cout<<"YES\n";
		}
		
	}
	return 0;
}