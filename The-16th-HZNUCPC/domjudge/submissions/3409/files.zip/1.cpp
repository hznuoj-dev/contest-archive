#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=1e9+7,M=1e6+5;
ll up,down,x[30],y[30],g[M];
ll mp[20];
void solve()
{
	string a,b;
	cin>>a>>b;
	ll ans=0;
	int len=a.size();
	for(int i=0;i<a.size();i++)
	{
		x[a[i]-'a']++;
		if(x[a[i]-'a']==1) up++;
		
	}
	for(int i=0;i<b.size();i++)
	{
		y[b[i]-'a']++;
		if(y[b[i]-'a']==1) down++;
		
	}
	for(int i=0;i<len;i++)
	{
		int x1[30],y1[30];
		for(int i=0;i<=25;i++)x1[i]=x[i],y1[i]=y[i];
		int m1,m2;
		m1=a[i]-'a';m2=b[i]-'a';
		if(x1[m1]==1){
			x1[m1]--;
			g[i]--;
		}
		if(x1[m2]==0){
			x1[m2]++;
			g[i]++;
		}
		if(y1[m2]==1){
			y1[m2]--;
			g[i]++;
		}
		if(y1[m1]==0){
			g[i]--;
			y1[m1]++;
		}
		mp[g[i]+10]++;
	}
//	for(int i=0;i<len;i++) printf("%lld ",g[i]);
//	for(int i=8;i<=12;i++) printf("%lld ",mp[i]);
	int cha=up-down;
	if(cha==4)
	{
		ll k=mp[-2+10];
		ans=(k*(k-1))/2;
	}else if(cha==3)
	{
		ans=mp[-2+10]*mp[-1+10];
	}else if(cha==2)
	{
		//cout<<mp[8];
		ll k=mp[-1+10];
		ans=mp[-2+10]*mp[0+10]%mod+(k*(k-1))/2;
	}else if(cha==1)
	{
		ans=mp[-1+10]*mp[0+10]%mod+mp[-2+10]*mp[1+10]%mod;
	}else if(cha==0)
	{
		ans=mp[1+10]*mp[-1+10]%mod+mp[2+10]*mp[-2+10]%mod+(mp[0+10]*(mp[0+10]-1))/2;
	}else if(cha==-1)
	{
		ans=mp[1+10]*mp[0+10]%mod+mp[2+10]*mp[-1+10]%mod;
	}else if(cha==-2)
	{
		ans=mp[2+10]*mp[0+10]%mod+mp[1+10]*(mp[1+10]-1)/2;
	}else if(cha==-3)
	{
		ans=mp[1+10]*mp[2+10];
	}else if(cha==-4)
	{
		ans=mp[2+10]*(mp[2+10]-1)/2;
	}else ans=0;
	ans=((ans%mod)+mod)%mod;
	printf("%lld\n",ans);
}
int main()
{
	int t=1;
	//scanf("%d",&t);
	while(t--) solve();
	return 0;
}