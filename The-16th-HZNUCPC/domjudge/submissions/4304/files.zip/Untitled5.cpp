#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
typedef pair<int,int> pii;
const int mod =1e9+7;
ll jiecheng (int a)
{
	ll res =1;
for(int i=a;i>=1;i--)
{
	res=res*i%mod;
}
return res;
}
ll jiecheng1 (int a)
{
	ll res =1;
	res =res*a%mod;
	res=res*(a-1)%mod;
	return res;
}
string s1,s2;
unordered_map<char,int> st1,st2;
int a[10];
signed main()
{
	Acode;
	cin >> s1 >> s2;
	s1 = ' ' + s1;
	s2 = ' ' + s2;
	int len = s1.size();
	int ans=0;
	int ans1=0;
	for(int i = 1;i < len;i++)
	{
		st1[s1[i]]++;
		st2[s2[i]]++;
		if(s1[i]==s2[i]) 
		ans++;
		else 
		ans1++;
	}
	int si1 = st1.size();
	int si2 = st2.size();
	int x=abs(si1-si2);
	if(abs(si1 - si2) > 4){
		cout << 0;
		return 0;
	}
	//cout<<"----"<<ans<<endl;
cout<<jiecheng(len)/jiecheng1(len-ans1);
	return 0;
}
