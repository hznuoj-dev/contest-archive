#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<string>
#include<cctype>
#include<vector>
#include<set>
using namespace std;
#define debug(a) cout<<#a<<"="<<a<<"\n";
#define rep(i,a,b) for(int i=(a),__##i##__=(b);i<=__##i##__;i++)
#define dwn(i,a,b) for(int i=(a),__##i##__=(b);i>=__##i##__;i--)
#define int ll
typedef long long ll;
typedef unsigned long long ull;
int cs1[30],cs2[30];

signed main()
{
	string s1;
	string s2;
	cin>>s1;
	cin>>s2;
	rep(i,0,s1.size()-1)
	{
		cs1[s1[i]-'a']++;
		cs2[s2[i]-'a']++;
	}
	int cnt1=0;
	int cnt2=0;
	rep(i,0,25)
	{
		if(cs1[i]) cnt1++;
		if(cs2[i]) cnt2++;
	}
	int qk1=0;//上不变，下不变
	int qk2=0;
	int qk3=0;
	int qk5=0;
	int qk4=0;

	rep(i,0,s1.size()-1)
	{
		if(s1[i]==s2[i])
		{
			qk1++;
			continue;
		}
		if(cs1[s1[i]-'a']==1 && cs2[s1[i]-'a']==0 && cs2[s2[i]-'a']==1 &&  cs1[s2[i]-'a']==0)//本身是唯一，交换后也是唯一
		{
			qk1++;
			continue;
		}
		if(cs1[s1[i]-'a']==1 && cs2[s1[i]-'a']>0 && cs2[s2[i]-'a']==1 &&  cs1[s2[i]-'a']>0)//本身是唯一，交换后都不唯一
		{
			qk1++;
			continue;
		}
		if(cs1[s1[i]-'a']>1 && cs2[s1[i]-'a']==0 && cs2[s2[i]-'a']>1 &&  cs1[s2[i]-'a']==0)//本身不唯一，交换后唯一
		{
			qk1++;
			continue;
		}
		if(cs1[s1[i]-'a']>1 && cs2[s1[i]-'a']>0 && cs2[s2[i]-'a']>1 &&  cs1[s2[i]-'a']>0)//本身不唯一，交换后唯一
		{
			qk1++;
			continue;
		}

		if(cs1[s1[i]-'a']>1 && cs2[s1[i]-'a']==0 )//上面不唯一，到了下面成为唯一,下面不唯一到了上面不唯一或下面唯一，到了上面也唯一
		{
			if(cs2[s2[i]-'a']==1&&cs1[s1[i]-'a']==0)
			{
				qk2++;
			}
			if(cs2[s2[i]-'a']>1&&cs1[s1[i]-'a']>0)
			{
				qk2++;
			}
		}


		if(cs2[s2[i]-'a']>1 && cs1[s2[i]-'a']==0 )//相反
		{
			if(cs1[s1[i]-'a']==1&&cs2[s2[i]-'a']==0)
			{
				qk3++;
			}
			if(cs1[s1[i]-'a']>1&&cs2[s2[i]-'a']>0)
			{
				qk3++;
			}
		}

		if(cs1[s1[i]-'a']==1 && cs2[s1[i]-'a']==0 && cs2[s2[i]-'a']>1 && cs1[s1[i]-'a'] > 0)
		{
			qk4++;
		}

		if(cs2[s2[i]-'a']==1 && cs1[s2[i]-'a']==0 && cs1[s1[i]-'a']>1 && cs2[s2[i]-'a'] > 0)
		{
			qk5++;
		}

	}
	int ans=0;
	if(cnt1-cnt2==0)
	{
		ans=qk1*(qk1-1)/2+qk2*qk3+qk4*qk5;
	}
	if(cnt1-cnt2==1)
	{
		ans=qk2*qk1+qk4*qk3;
	}
	if(cnt1-cnt2==2)
	{
		ans=qk2*(qk2-1)/2+qk4*qk1;
	}
	if(cnt1-cnt2==-1)
	{
		ans=qk3*qk1+qk5*qk2;
	}
	if(cnt1-cnt2==-2)
	{
		ans=qk3*(qk3-1)+qk5*qk1;
	}
	if(cnt1-cnt2==3)
	{
		ans=qk4*qk2;
	}
	if(cnt1-cnt2==-3)
	{
		ans=qk5*qk3;
	}
	if(cnt1-cnt2==4)
	{
		ans=qk4*(qk4-1)/2;
	}
	if(cnt1-cnt2==-4)
	{
		ans=qk5*(qk5-1)/2;
	}

	cout<<ans<<"\n";

	return 0;
}