#include<iostream>
using namespace std;
int main()
{
	long long m,n;
	cin>>n>>m;
	if((n-m)%2==0)
	cout<<"YES"<<endl;
	else
	cout<<"NO"<<endl;
}