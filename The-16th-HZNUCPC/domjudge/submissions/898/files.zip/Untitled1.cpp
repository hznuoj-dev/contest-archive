#include<bits/stdc++.h>
#define int long long
using namespace std;

int n,m;
bool check(int x){
	for(int i=2;i<=sqrt(x);i++){
		if(x%i==0){
			return false;
		}
	}
	return true;
}
void solve(){
	int k;
	while(cin >> n >> m){
		int f=0;
		if(n<=m&&n!=1){
			cout<<"NO"<<endl;
			continue;
		}
		if(check(n)||m==1){
			cout<<"YES"<<endl;
		}else cout<<"NO"<<endl;
		
	}
	
}

signed main(){
//	int T;cin >> T;while(T--){
		solve();
//	}
	return 0;
}