#include<bits/stdc++.h>
using ll =long long ;
ll n,m,k;
int main() {
	std::cin>>n>>m;
	bool flag=true;
	for(ll i=2; i*i<=n; i++)
		if(n%i==0)flag=false;
	if(flag||m==1)puts("YES");
	else puts("NO");
	return 0;
}