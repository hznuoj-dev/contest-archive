#include<bits/stdc++.h>
using namespace std;
signed main(){
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	int cnt=0;
	string s1,s2;
	cin>>s1>>s2;
	int len=s1.size();
	for(int i=0;i<len;i++){
		if(s1[i]==s2[i]) cnt++;
	}
	if(cnt==len){
		cout<<len*(len-1)/2;
	}else if(cnt==0){
		if(len==2) cout<<1;
		else cout<<2;
	}else{
		int x=len-cnt;
		if(x==1){
			cout<<cnt;
		}else{
			cout<<cnt*2;
		}
	}
}