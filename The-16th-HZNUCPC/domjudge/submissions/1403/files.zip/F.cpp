#include<bits/stdc++.h>
#define int long long
using namespace std;
using ll = long long;
void solve() {
	ll n,m;
	cin>>n>>m;
	if(n==1||m==1){
		cout<<"YES";
		return;
	}
	if(m>=n){
		cout<<"NO";
		return;
	}
	else{
		ll a = 1;
		for(int i = 2;i*i<=n;i++){
			if(n%i==0){
				a = i;
				break;
			}
		}
		if(m>=a&&a!=1){
			cout<<"NO";
		}
		else cout<<"YES\n";
	}
}
signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}
