#include <bits/stdc++.h>
using namespace std;

int main()
{
	long long n,m,p,q,a,b;
	int flag=0;
	cin >> n >> m;
	p=n;
	q=m;
	if(m==1)
	{
		cout << "YES";
	}
	else
	{
	   int x=__gcd(n,m);
     if(x==1)
     {
     	flag=1;
	 }
	 else
	 {
		cout << "NO";
	 }
	 
	 
	 if(flag==1)
	 {
	 	if(p%2==0)
	 	{
	 		a=p%q;
	 		if(a%2==0)
	 		{
			
	 		cout<<"NO";
	     	}
	 		else
	 		{
	 			cout<<"YES";
			 }
		}
		else
		{
			cout<<"YES";
		}
	 }
   }
   return 0;
}