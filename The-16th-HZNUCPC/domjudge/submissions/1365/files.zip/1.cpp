#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define debug(x) cerr<<#x<<" "<<x<<"\n"

const int maxn=25;
const int dx[]={0,0,1,-1};
const int dy[]={1,-1,0,0};

int G[maxn][maxn];

void _solve(){
    int n;cin>>n;
    memset(G,0,sizeof(G));
    for(int i=0;i<n;i++){
        int x,y,c;cin>>x>>y>>c;
        G[x][y]=c;
    }
    int ans=0;
    for(int i=1;i<20;i++){
        for(int j=1;j<20;j++){
            if(G[i][j]) continue;
            for(int k=0;k<4;k++){
                int X=i+dx[k];
                int Y=j+dy[k];
                if(X>=1&&X<20&&Y>=1&&Y<20){
                    if(G[X][Y]==1) ans++;
                }
            }
        }
    }
    cout<<ans<<"\n";
}

int main(){
    ios::sync_with_stdio(false);

    int T;cin>>T;while(T--)
    _solve();
}
