#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n, m;
int main() {
	cin >> n >> m;
	if(m == 1) puts("Yes");
	else if(m >= n) puts("No");
	else {
		ll f = n;
		for(ll i = 2; i * i <= n; i++)
			if(n % i == 0) {
				f = i;
				break;
			}
		if(f <= m) puts("No");
		else puts("Yes");
	}
	return 0;
}