#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
const int maxn=5e3+5;
const ll p=233;
const ll mod1=1e9+7;
const ll mod2=998244353;
ll h1[maxn],h2[maxn],p1[maxn],p2[maxn];
int n;
//void init(){
//	p1[0]=p2[0]=1;
//	for(int i=1;i<maxn;i++){
//		p1[i]=p1[i-1]*p%mod1;
//		p2[i]=p2[i-1]*p%mod2;
//	}
//}
//ll get_h1(int l,int r){
//	return (h1[r]-h1[l-1]*p1[r-l+1]%mod1+mod1)%mod1;
//}
//ll get_h2(int l,int r){
//	return (h2[r]-h2[l-1]*p2[r-l+1]%mod2+mod2)%mod2;
//}
//pll get_h(int l,int r){
//	return { get_h1(l,r),get_h2(l,r) };
//}
char s[maxn];
int ans=0;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
//		init();
		ans=0;
		cin>>s+1;
		int len=strlen(s+1);
//		for(int i=1;i<=len;i++){
//			h1[i]=(h1[i-1]*p%mod1+(s[i]-'a'+1))%mod1;
//			h2[i]=(h2[i-1]*p%mod2+(s[i]-'a'+1))%mod2;
//		}
		for(int i=1;i<=len;i++)
		{
			int mid;
			int l,cnt,st,ed;
			int pos1,pos2;
//			odd
			if(s[i]==s[i+2] && i+2<=len)
			{
				mid=i+1;
				l=0,cnt=0,st=mid,ed=mid;
				pos1=-1,pos2=-1;
				while(cnt<3 && st>=1 && ed<=len){
					if(s[st]==s[ed]){
						if(st==mid)  l++;
						else l+=2;
						st--;
						ed++;
						ans=max(ans,l);
//						cout<<"odd---st=ed-------ans="<<ans<<endl;
						continue;
					}
					else{
						cnt++;
						if(pos1==-1)  pos1=st;
						else  pos2=st;
						if(cnt<=2)  l+=2;
						st--;
						ed++;
						ans=max(ans,l);
//						cout<<"odd---st!=ed-------ans="<<ans<<endl;
					}
				}
//				cout<<"odd----mid="<<mid<<"---pos1="<<pos1<<"---pos2="<<pos2<<endl;
				if(s[pos1]==s[2*mid-pos2] && s[pos2]==s[2*mid-pos1]){
					ans=max(ans,l);
				}
				else if(s[mid]==s[2*mid-pos1] || s[mid]==s[pos1]){
					ans=max(ans,2*mid-2*pos1-1);
				}
				else{
					if(pos1==-1)  ans=len;
					else  ans=2*mid-2*pos1-1;
				}
//				cout<<"odd-------ans="<<ans<<endl;
			}
//			even
			if(s[i]==s[i+1] && i+1<=len){
				mid=i;
				l=0,cnt=0,st=i,ed=i+1;
				pos1=-1,pos2=-1;
				while(cnt<=2 && st>=1 && ed<=len){
					if(s[st]==s[ed]){
						l+=2;
						st--;
						ed++;
						ans=max(ans,l);
//						cout<<"st=ed-------ans="<<ans<<endl;
						continue;
					}
					else{
						cnt++;
						if(pos1==-1)  pos1=st;
						else  pos2=st;
						if(cnt<=2)  l+=2;
						st--;
						ed++;
						ans=max(ans,l);
//						cout<<"st!=ed-------ans="<<ans<<endl;
					}
				}
				if(s[pos2]==s[2*mid+1-pos2] && s[pos2]==s[pos1]){
					ans=max(ans,l);
				}
//				cout<<"even-------ans="<<ans<<endl;
			}
		}	
		cout<<ans<<endl;	
	}
}