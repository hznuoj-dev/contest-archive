#include<bits/stdc++.h>
using namespace std;
int main(){
	long long int n,m;
	cin>>n>>m;
	if(n%m==0){
		cout<<"NO";
	}
	else {
		cout<<"YES";
	}
}
