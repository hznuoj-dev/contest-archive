#include<bits/stdc++.h>
using namespace std;
const int N=1e5+1000;
//const int inf = 1e5;
int n,q,m;
int fa[N*3],sz[N*3];
int find(int x) {
	return fa[x]==x?x:fa[x]=find(fa[x]);
}
void uni(int x,int y) {
	int fx=find(x),fy=find(y);
	if(fx==fy)return;
	sz[fy]+=sz[fx];
	sz[fx]=0;
	fa[fx]=fy;
}
bool flag=true;
struct node {
	int ff,val,valn;
};
vector<node>mess;
bitset<N>dp[N];
bool vis[N*3],good[N*3];
int main() {
//	cout<<sizeof(dp)/1024/1024/8<<'\n';
	ios::sync_with_stdio(false);
//	srand(time(NULL));
	cin>>n>>q>>m;
//	n = 1e5, q = rand() % n + 1, m = rand() % inf + 1;
//	n = 1e5 , m = 0, q = 1e5;
	for(int i=1; i<=n*2; i++) {
		fa[i]=i;
		if(i<=n)sz[i]=1;
		else sz[i]=0;
	}
	for(int i=1,k,a,b; i<=m; i++) {
		cin>>k>>a>>b;

//		k = rand() % 2;
//		a = rand() % n + 1;
//		b = rand() % n + 1;
		
		if(!flag)continue;
		if(k==0) {
			//a b  a+n b+n
			if(find(a)==find(b+n) || find(b)==find(a+n)) {
				flag=false;
			} else {
				uni(a,b);
				uni(a+n,b+n);
			}
		} else {
			//a b+n  b a+n
			if(find(a)==find(b) || find(a+n)==find(b+n)) {
				flag=false;
			} else {
				uni(a,b+n);
				uni(b,a+n);
			}
		}
	}
	if(flag) {
		for(int i=1; i<=n; i++) {
			if(!vis[find(i)]) {
			//cout<<i<<' '<<find(i)<<' '<<sz[find(i)]<<' '<<sz[find(i+n)]<<'\n';	
				mess.push_back({i,sz[find(i)],sz[find(i+n)]});
				vis[find(i)]=vis[find(i+n)]=true;
			}
		}
		int tot=mess.size();
//		for(int i=0;i<tot;i++){
//			cout<<mess[i].ff<<' '<<sz[find(mess[i].ff)]<<' '<<sz[find(mess[i].ff+n)]<<'\n';
//		}
//		for(int i=0;i<=tot;i++){
//			dp[i].reset();
//		}
		dp[0][0]=1;
		for(int i=1;i<=tot;i++){
			//i-1
			dp[i]|=(dp[i-1]<<mess[i-1].val);
			dp[i]|=(dp[i-1]<<mess[i-1].valn);
		}
		if(dp[tot][q]){
			cout<<"YES\n";
			int mq=q;
			for(int i=tot-1;i>=0;i--){
				if(mq-mess[i].val>=0 && dp[i][mq-mess[i].val]){
					//ans[i]=find(mess[i].ff);
					good[find(mess[i].ff)]=true;
					mq-=mess[i].val;
				}else if(mq-mess[i].valn>=0 && dp[i][mq-mess[i].valn]){
					//ans[i]=find(mess[i].ff+n);
					good[find(mess[i].ff+n)]=true;
					mq-=mess[i].valn;
				}
			}
			for(int i=1;i<=n;i++){
				if(good[find(i)]){
					cout<<i<<' ';
				}
			}
			cout<<'\n';
		}else{
			cout<<"NO\n";
		}
	} else {
		cout<<"NO\n";
	}
	return 0;
}