#include <bits/stdc++.h>
using namespace std;

const int kMaxN = 5005;
char s[kMaxN];

int main() {
	ios::sync_with_stdio(false);
	
	int T;
	cin >> T;
	while (T--) {
		cin >> (s + 1);
		int n = strlen(s + 1);
		
		int ans = 0;
		// even
		for (int mid = 1; mid < n; ++mid) {
			int len = 1;
			// [mid - len + 1, mid + len]
			vector<pair<char, char>> tmp;
			while (mid - len + 1 >= 1 && mid + len <= n) {
				int lhs = mid - len + 1, rhs = mid + len;
				if (s[lhs] != s[rhs]) {
					tmp.push_back(make_pair(s[lhs], s[rhs]));
				}
				if (tmp.size() == 0) {
					ans = max(ans, len * 2);
				} else if (tmp.size() == 2) {
					if (tmp[0].first == tmp[1].first && tmp[0].second == tmp[1].second) {
						ans = max(ans, len * 2);
					}
					if (tmp[0].first == tmp[1].second && tmp[0].second == tmp[1].first) {
						ans = max(ans, len * 2);
					}
				}
				++len;
			}
		}
		
		// odd
		for (int mid = 2; mid < n; ++mid) {
			int len = 1;
			// [mid - len, md + len]
			vector<pair<char, char>> tmp;
			while (mid - len >= 1 && mid + len <= n) {
				int lhs = mid - len, rhs = mid + len;
				if (s[lhs] != s[rhs]) {
					tmp.push_back(make_pair(s[lhs], s[rhs]));
				}
				if (tmp.size() == 0) {
					ans = max(ans, len * 2 + 1);
				} else if (tmp.size() == 2) {
					if (tmp[0].first == tmp[1].first && tmp[0].second == tmp[1].second) {
						ans = max(ans, len * 2 + 1);
					}
					if (tmp[0].first == tmp[1].second && tmp[0].second == tmp[1].first) {
						ans = max(ans, len * 2 + 1);
					}
				} else if (tmp.size() == 1) {
					if (tmp[0].first == s[mid] || tmp[0].second == s[mid]) {
						ans = max(ans, len * 2 + 1);
					}
				}
				++len;
			}
		}
		
		cout << ans << "\n";
	}
	
	
	return 0;
}