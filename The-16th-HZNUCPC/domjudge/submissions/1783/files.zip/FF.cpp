#include <bits/stdc++.h>

using namespace std;
const int N = 1e9+7;

int main(){
	long long n,m,f=1;
	cin>>n>>m;
	while(m!=1){
		if(n%m==0){
			f=0;
			break;
		}
		m--;
	}
	if(f==1){
		cout<<"YES";
	}
	else {
		cout<<"NO";
	}
	return 0;
} 