#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	int t;
	cin>>t;
	while(t--){
		char a[10010],s[10010];
		scanf("%s",a);
		int len=0,lena=strlen(a);
		s[0]='#';
		for(int i=0;i<lena;i++){
			len++;
			s[len]=a[i];
			len++;
			s[len]='#';
		}
		ll ans=0;
		for(int i=0;i<lena*2+1;i++){
			int l=i-1,r=i+1;
			ll res1=1,res2=1;
			int f=0;
			char ll,rr;
			while(l>=0&&r<=lena*2){
				if(s[l]==s[r]&&f==0) res1+=2,res2+=2;
				else if(s[l]==s[r]&&f==1) res2+=2;
				else if(s[l]==s[r]&&f==2) res2+=2;
				else if(s[l]!=s[r]&&f==0){
					f=1;
					ll=s[l];
					rr=s[r];
					res2+=2;
				}
				else if(s[l]!=s[r]&&f==1){
					if(ll==s[r]&&rr==s[l]) res2+=2,f=2;
					else break;
				}
				else if(s[l]!=s[r]&&f==2) break;
				l--;
				r++;
			}
			if(f==2) ans=max(ans,res2);
			else ans=max(ans,res1);
		}
		if(ans/2<2)
		cout<<0<<endl;
		else
		cout<<ans/2<<endl;
	}
	return 0;
}