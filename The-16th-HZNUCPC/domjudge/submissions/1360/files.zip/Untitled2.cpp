#include<bits/stdc++.h>
using namespace std;
#define dzs ios::sync_with_stdio(false);cin.tie(nullptr),cout.tie(nullptr)
typedef long long ll;
int main()
{
	ll n,m;
	int flag=1;
	cin>>n>>m;
	if(n<=m&&n>1)flag=0;
	while(n%m!=0&&n%m!=1&&flag)
	{
		m=n%m;
	}
	if(flag&&n%m==1||m==1)cout<<"YES";
	else cout<<"NO";
} 