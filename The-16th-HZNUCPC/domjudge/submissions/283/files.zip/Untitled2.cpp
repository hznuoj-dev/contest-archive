#include<cstdio>

long long gcd(long long a,long long b){
	return (a%b)?gcd(b,a%b):b;
}

int main(){
//	freopen("data.in","r",stdin);
	long long n,m;
	scanf("%lld%lld",&n,&m);
	if(n==1 || (gcd(n,m)==1 && n>m)) puts("YES");
	else puts("NO");
	return 0;
}