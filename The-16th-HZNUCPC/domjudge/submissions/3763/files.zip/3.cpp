#include<bits/stdc++.h>
const int N=1e5+10;
const int inf=0x3f3f3f3f;
using namespace std;
struct node
{
	int t,l,r;
}a[N];
struct Node
{
	int t,x,id;
}b[N];
bool cmp(node x,node y)
{
	return x.t==y.t?x.r>y.r:x.t>y.t;
}
bool Cmp(Node x,Node y)
{
	return x.t>y.t;
}
int n,m,x,ans[N];
int cnt,c[N<<2];
int tr[N<<4],tag[N<<4];
#define ls (nw<<1)
#define rs (ls+1)
#define mid (l+r>>1)
void build(int nw,int l,int r)
{
	if(l==r)
	{
		if(r==x)tr[nw]=0;
		else tr[nw]=inf;
		return;
	}
	build(ls,l,mid);
	build(rs,mid+1,r);
}
void down(int nw,int l,int r)
{
	if(tag[nw])
	{
		if(l==r)
			tr[nw]=min(tr[nw],tag[nw]);
		else
		{
			if(tag[ls])tag[ls]=min(tag[ls],tag[nw]);
			else tag[ls]=tag[nw];
			if(tag[rs])tag[rs]=min(tag[rs],tag[nw]);
			else tag[rs]=tag[nw];
		}
		tag[nw]=0;
	}
}
int query(int nw,int l,int r,int k)
{
	down(nw,l,r);
	if(l==r)return tr[nw];
	if(k<=mid)return query(ls,l,mid,k);
	else return query(rs,mid+1,r,k);
}
void update(int nw,int l,int r,int ql,int qr,int k)
{
	down(nw,l,r);
	if(ql<=l&&r<=qr)
	{
		tag[nw]=k;
		return;
	}
	if(ql<=mid)
		update(ls,l,mid,ql,qr,k);
	if(qr>mid)
		update(rs,mid+1,r,ql,qr,k);
}
int main()
{
	scanf("%d%d%d",&n,&m,&x);
	c[++cnt]=x;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&a[i].t,&a[i].l,&a[i].r);
		c[++cnt]=a[i].l;
		c[++cnt]=a[i].r;
	}
	sort(a+1,a+1+n,cmp);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&b[i].t,&b[i].x);
		b[i].id=i;
		c[++cnt]=b[i].x;
	}
	sort(b+1,b+1+m,Cmp);
	sort(c+1,c+1+cnt);
	cnt=unique(c+1,c+1+cnt)-c-1;
	x=lower_bound(c+1,c+1+cnt,x)-c;
	build(1,1,cnt);
	for(int i=1,j=1;i<=m;i++)
	{
		while(j<=n&&a[j].t>=b[i].t)
		{
			int l=lower_bound(c+1,c+1+cnt,a[j].l)-c;
			int r=lower_bound(c+1,c+1+cnt,a[j].r)-c;
			update(1,1,cnt,l,r,query(1,1,cnt,r)+1);
			j++;
		}
		int y=lower_bound(c+1,c+1+cnt,b[i].x)-c;
		ans[b[i].id]=query(1,1,cnt,y);
	}
	for(int i=1;i<=m;i++)
		printf("%d\n",ans[i]==inf?-1:ans[i]);
	return 0;
}