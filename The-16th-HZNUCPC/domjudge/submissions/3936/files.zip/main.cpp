#include <iostream>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;
typedef long long ll;

const int N = 110;
int n;
struct node
{
    int x, y;
}no[N];
int p[4];
ll M = 0;
bool v[N];

ll dcm(int a, int b)
{
    if(b > a)
    return dcm(b, a);
    if(!a)
        return b;
    else if(!b)
        return a;
    int yu = a % b;
    while(yu)
    {
        a = b;
        b = yu;
        yu = a % b;
    }
    return (ll)b;
}

void dfs(int u)
{
    if(u == 3)
    {
        ll a, b;
        ll cnt = 0;
        double k1 = (no[p[2]].y - no[p[1]].y) * 1.0 / (no[p[2]].x - no[p[1]].x);
        double k2 = (no[p[1]].y - no[p[0]].y) * 1.0 / (no[p[1]].x - no[p[0]].x);
        bool judge = 0;
        if(fabs(k1 - k2) < 1e-12)
        {
            cnt = 0;
            judge = 1;
        }
        for(int i = 0;i < 3 && !judge;i++)
        {
            a = abs(no[p[(i + 1) % 3]].x - no[p[i]].x);
            b = abs(no[p[(i + 1) % 3]].y - no[p[i]].y);
            if(!a && !b)
            {
                cnt = 0;
                break;
            }
            cnt += dcm(a, b);
        }
        M = max(M, cnt);
    }
    else
    {
        for(int i = 1;i <= n;i++)
        {
            if(!v[i] && i > p[u - 1])
            {
                v[i] = 1;
                p[u] = i;
                dfs(u + 1);
                v[i] = 0;
            }
        }
    }
}

int main()
{
    cin >> n;
    for(int i = 1;i <= n;i++)
    {
        cin >> no[i].x >> no[i].y;
    }
    dfs(0);
    cout << M;
    return 0;
}