#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
unordered_map<LL, LL> res;


void f(LL n){
    for(LL i = 2; i <= n / i; i++) {
        while(n % i == 0) {
            res[i]++;
            n /= i;
        }
    }
    if(n > 1) res[n]++;
}
bool sol(LL b) {
        unordered_map<LL, LL>::iterator it;
        for(it = res.begin(); it != res.end(); it++) {
            LL x = it -> first;
            if(x <= b) return false;
        }
        return true;
}
int main() {
    LL a, b;
    cin >> a >> b;
    if(a == 1 || b == 1) {
        cout << "YES" << endl;
    } else if(a <= b){
        cout << "NO" << endl;
    } else {
        f(a);
        if(sol(b)) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }
}
