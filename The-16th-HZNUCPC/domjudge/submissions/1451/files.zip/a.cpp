#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ct(x) cout<<x<<'\n'
#define dg(x)  cout<<#x<<'='<<x<<'\n';
#define pii  pair<int,int> 
#define N 350000
#define double long double
#define ios ios::sync_with_stdio(0),cin.tie(0),cout.tie(0)


/*
1
2
1 1 1
2 2 1

6

1
2
10 9 1 
10 10 1

6
*/
int n=19;
int ans=0;
int vis[21][21]{};

int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};

void dfs(int x,int y){
	if(vis[x][y])
	return;
	if(x<1||x>n||y<1||y>n)
	return;
	vis[x][y]=2;
	int co=0;
	for(int i=0;i<4;i++){
		int xx= x+dx[i];
		int yy= y+dy[i];
		if(vis[xx][yy]==1)
		co++;
		dfs(xx,yy);
	}
	
	ans+=co;
}


void solve(){
	ans=0;
  memset(vis,0,sizeof(vis));
   int m;cin>>m;
   
   while(m--){
   	int x,y,t;cin>>x>>y>>t;
   	if(t==1)
   	vis[x][y]=1;
   	else
   	vis[x][y]=2;
   }
   
   for(int i=1;i<=19;i++)
    for(int j=1;j<=19;j++){
    	dfs(i,j);
	}
	
	ct(ans);
}

signed main(){
	ios;
	int t=1;
	 cin>>t;
	while(t--)
	solve();
	return 0;
}