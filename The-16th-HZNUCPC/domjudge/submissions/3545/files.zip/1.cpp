#include <bits/stdc++.h>
using namespace std;
using ll =long long ;
uint64_t n,m,k,cnt,sum;
void solve(){
	cin >> n;
	cin>> m;
	k = 0;
	if(n==1) {
	cout<<"YES"<<endl;
	return ;
	}
	if (m>=n){
		cout <<"NO"<<endl;
			return;
	}
	for(int i = 2;i<=(ll)sqrt(n)&&i<=m;i++){
		if (n%i==0) {
			cout <<"NO"<<endl;
			return;
		}
	}
	cout<<"YES"<<endl;
}
int main(){
	solve();
}