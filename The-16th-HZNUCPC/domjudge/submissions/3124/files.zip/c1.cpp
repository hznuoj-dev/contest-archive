#include "bits/stdc++.h"
using namespace std;
int ah[30],bh[30];
void getHash(const string& w,int* a) {
	for(int i = 0; i < w.size(); i++) {
		a[w[i] - 'a'] ++;
	}
}
int main() {
	string a1;
	string a2;
	cin >> a1 >> a2;
	getHash(a1,ah);
	getHash(a2,bh);
	set<char> s1(a1.begin(),a1.end())
	,s2(a2.begin(),a2.end());

	long long ans = 0;
	for(int p1 = 0; p1 < a1.size() - 1; p1++) {

		for(int p2 = p1 + 1; p2 < a1.size(); p2 ++) {

			// -
			ah[a1[p1] - 'a']--;
			ah[a1[p2] - 'a']--;
			bh[a2[p1] - 'a']--;
			bh[a2[p2] - 'a']--;

			if(ah[a1[p1] - 'a'] == 0) {
				s1.erase(a1[p1]);
			}
			if(ah[a1[p2] - 'a'] == 0) {
				s1.erase(a1[p2]);
			}
			if(bh[a2[p1] - 'a'] == 0) {
				s2.erase(a2[p1]);
			}
			if(bh[a2[p2] - 'a'] == 0) {
				s2.erase(a2[p2]);
			}

			// +
			ah[a2[p1] - 'a']++;
			ah[a2[p2] - 'a']++;
			bh[a1[p1] - 'a']++;
			bh[a1[p2] - 'a']++;
			s1.insert(a2[p1]);
			s1.insert(a2[p2]);
			s2.insert(a1[p1]);
			s2.insert(a1[p2]);


			if(s1.size() == s2.size()) {
				ans ++;
			}

			// -
			ah[a1[p1] - 'a']++;
			ah[a1[p2] - 'a']++;
			bh[a2[p1] - 'a']++;
			bh[a2[p2] - 'a']++;
			s1.insert(a1[p1]);
			s1.insert(a1[p2]);
			s2.insert(a2[p1]);
			s2.insert(a2[p2]);


			// +
			ah[a2[p1] - 'a']--;
			ah[a2[p2] - 'a']--;
			bh[a1[p1] - 'a']--;
			bh[a1[p2] - 'a']--;

			if(ah[a2[p1] - 'a'] == 0) {
				s1.erase(a2[p1]);
			}
			if(ah[a2[p2] - 'a'] == 0) {
				s1.erase(a2[p2]);
			}
			if(bh[a1[p1] - 'a'] == 0) {
				s2.erase(a1[p1]);
			}
			if(bh[a1[p2] - 'a'] == 0) {
				s2.erase(a1[p2]);
			}
		}
	}
	printf("%d",ans % (1000000000 + 7));
}