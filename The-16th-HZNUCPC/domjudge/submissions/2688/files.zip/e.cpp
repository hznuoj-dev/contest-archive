#include<bits/stdc++.h>
using namespace std;
const int N=110;
int x[N],y[N];
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>x[i]>>y[i];
	}
	int ans=3;
	int mx=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int k=1;k<=n;k++)
			{
				if(i!=j && i!=k && j!=k)
				{ 	
					mx=max(mx,__gcd(abs(x[i]-x[j]),abs(y[i]-y[j]))+__gcd(abs(x[i]-x[k]),abs(y[i]-y[k]))+__gcd(abs(x[j]-x[k]),abs(y[j]-y[k])));
//					mx=max(mx,a+b+c);
				}
			}
		}
	}
	cout<<mx<<endl;
	return 0;
}