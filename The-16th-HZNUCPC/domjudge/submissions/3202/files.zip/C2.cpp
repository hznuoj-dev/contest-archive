#include <bits/stdc++.h>
#define int long long
using namespace std;
int n;
typedef pair<int, int> PII;
string s, t;
int l[26], r[26];

signed main()
{
	ios::sync_with_stdio(0);
	
	cin.tie(0);
	
	cin >> s >> t;
	map<PII, int> mp;
	n = s.size();
	for(int i = 0 ; i < n ; i ++) {
		mp[{s[i] - 'a', t[i]- 'a'}] ++;
		l[s[i] - 'a'] ++;
		r[t[i] - 'a'] ++;
	}
	
	double res = 0;
	for(int i = 0 ; i < 26 ; i ++)
	{
		for(int j = 0 ; j < 26 ; j ++)
		{
			for(int k = 0 ; k < 26 ; k ++)
			{
				for(int u = 0 ; u < 26 ; u ++)
				{
					if(mp.count({i,j}) == 0 || mp.count({k, u}) == 0) continue;
					if(i == k && j == u && mp[{i,j}] <= 1) continue;
					l[i] --;
					l[j] ++;
					r[i] ++;
					r[j] --;
					l[k] --;
					r[k] ++;
					l[u] ++;
					r[u] --;
					int x = 0, y = 0;
					bool ok = true;
					for(int v = 0 ; v < 26 ; v ++) {
						if(l[v]) x ++;
						if(r[v]) y ++;
					}
					if(x != y) ok = false;
					//cout << i << ' ' << j << ' ' << k << ' '<< u << ' ' << ok << endl;
					if(ok && i == k && j == u) {
						if(mp[{i, j}] >= 2) {
							res += 1. * mp[{i, j}] * (mp[{i, j}] - 1) / 2;
						}
					}
					else if(ok){
						res += 1. * mp[{i, j}] * mp[{k, u}] / 2;
						cout << res << endl;
						//cout << i << ' ' << j << ' ' << k << ' '<< u << endl;
					}
					l[i] ++;
					l[j] --;
					r[i] --;
					r[j] ++;
					l[k] ++;
					r[k] --;
					l[u] --;
					r[u] ++;
				}
			}
		}
	}
	
	cout << (int)res % (int)(1e9+7) << endl;
	
}   
