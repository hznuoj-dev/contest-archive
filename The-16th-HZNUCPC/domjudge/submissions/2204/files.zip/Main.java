import java.util.*;
import java.io.*;
public class Main {
	static long max_sum;
	static Scanner in = new Scanner(System.in);
	public static void main(String[] args)  {
		int n=in.nextInt();
		max_sum=0;
		nod[]all=new nod[101];
		for(int i=1;i<=n;i++)
		{
			long x=in.nextLong(),y=in.nextLong();
			all[i]=new nod(x,y);
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=i+1;j<=n;j++)//Math.abs(all[i].y-all[j].y)     Math.abs(all[k].y-all[j].y)
			{
				for(int k=j+1;k<=n;k++)
				{
					long l=(all[i].x-all[j].x)*(all[k].y-all[j].y),p=(all[k].x-all[j].x)*(all[i].y-all[j].y) ;
					if(all[i].x==all[j].x&&all[j].x==all[k].x || all[i].y==all[j].y&&all[j].y==all[k].y)continue;
					else if(l==p)continue;
					max_sum=Math.max(max_sum, get_s(all[i],all[j],all[k]));
				}
			}
		}
		System.out.println(max_sum);
	}
	static long get_s(nod a,nod b,nod c)
	{
		long i=0,j=0,k=0;
		if(a.x-b.x==0||a.y-b.y==0)
		{
			if(a.x-b.x==0)i=Math.abs(a.y-b.y);
			else i=Math.abs(a.x-b.x);
		}else i=gcd(Math.abs(a.x-b.x),Math.abs(a.y-b.y));
		
		if(a.x-c.x==0||a.y-c.y==0)
		{
			if(a.x-c.x==0)j=Math.abs(a.y-c.y);
			else j=Math.abs(a.x-c.x);
		}else j=gcd(Math.abs(a.x-c.x),Math.abs(a.y-c.y));
		
		if(c.x-b.x==0||c.y-b.y==0)
		{
			if(b.x-c.x==0)k=Math.abs(b.y-c.y);
			else k=Math.abs(b.x-c.x);
		}else k=gcd(Math.abs(c.x-b.x),Math.abs(c.y-b.y));
		
		return i+j+k;
	}
	static long gcd(long a,long b)
	{
		return b==0?a:gcd(b,a%b);
	}
	static class nod
	{
		long x,y;
		nod(long x,long y)
		{
			this.x=x;
			this.y=y;
		}
	}
}
