#include<bits/stdc++.h>

#define debug(a) cout<<#a<<" "<<a<<endl

using namespace std;

bool check(char l,char r,char x,char y){
	int ans = 0;
	if(x == l && r == y){
		ans |= 1;
	}else if(l == y && x == r){
		ans |= 1;
	}
	return ans;
}

void solve()
{
	string s;
	cin>>s;
	
	int n = s.length();
	s = " " + s;
	
	int ans = 0;
	
	int len = 0;
	int flag = 0;
	char prel,prer;
	int prelen;
	for(int i=1;i<=n;++i){
		flag = 0;
		for(int j=1;j<=n;++j){
			if(i-j<=0 || i+j > n){
//				ans = max(ans,(j-1)*2+1);
				break;
			}
			if(s[i-j] == s[i+j]){
				if(flag = 0 || flag == 2)	ans = max(ans,j*2+1);
			}else{
				flag++;
				if(flag == 1){
					prel = s[i-j];
					prer = s[i+j];
					prelen = j-1;
					ans = max(ans,(j-1)*2+1);
				}
				if(flag == 2){
					if(check(prel,prer,s[i-j],s[i+j])){
//						cout<<i<<" "<<j<<'\n';
						ans = max(ans,j*2+1);
						continue;
					}else{
						ans = max(ans,prelen*2+1);
						break;
					}
				}
				if(flag == 3){
					ans = max(ans,(j-1)*2+1);
					break;
				}
			}
		}
	}
	
//	cout<<ans<<'\n';
//	ans = 0;
	
	for(int i=1;i<=n;++i){
		flag = 0;
		for(int j=1;j<=n;++j){
			if(i-j<=0 || i+j > n){
//				ans = max(ans,(j-1)*2+1);
				break;
			}
			if(s[i-j] == s[i+j]){
				ans = max(ans,j*2+1);
			}else{
				if(flag) break;
				if(s[i] == s[i-j] || s[i] == s[i+j]){
					ans = max(ans,j*2+1);
					flag ++;
				}else{
					break;
				}
			}
		}
	}
	
//	cout<<ans<<'\n';
//	ans = 0;
//	ans = 0;
	
//	cout<<s[3]<<s[6]<<'\n';
	
	for(int i=1;i<=n;++i){
		flag = 0;
//		if(s[i] != s[i+1]) continue;
		for(int j=0;j<=n;++j){
//			cout<<i<<" "<<j<<endl;
				
			if(i-j<=0 || i+1+j > n){
//				ans = max(ans,(j-1)*2+2);

				break;
			}
			if(s[i-j] == s[i+j+1]){
				if(flag == 0 || flag == 2) ans = max(ans,j*2+2);
			}else{
				flag++;
				if(flag == 1){
					prel = s[i-j];
					prer = s[i+j+1];
					prelen = j-1;
					ans = max(ans,prelen*2+2);
				}
				if(flag == 2){
					if(check(prel,prer,s[i-j],s[i+j+1])){
						ans = max(ans,j*2+2);
//						debug(ans);
//						debug(i);
//						debug(j);
						continue;
					}else{
						ans = max(ans,prelen*2+2);
						flag = 0;
						if(i == 4 && j == 1){
//							debug(114514);
						}
						break;
					}
				}
				if(flag == 3){
					ans = max(ans,(j-1)*2+2);
					flag = 0;
					break;
				}
			}
		}
	}
	
	ans = ans == 1 ? ans = 0 : ans;
	cout<<ans<<'\n';
}
/*
4
abccab
ihi
stfgfiut
palindrome

1
baaabaaa
*/
int main()
{
	cin.sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}

