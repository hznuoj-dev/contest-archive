#include <stdio.h>	

int work(int n){
	int x,y,c;
	int x1[4] = {0,0,-1,1};
	int y1[4] = {1,-1,0,0};
	int stone[21][21]={0};
	int sum=0;
	
	for (int j=1;j<=n;j++){
			scanf("%d %d %d",&x,&y,&c);
			stone[x][y] = c;
		}
	
	for (int i=1 ;i<=19;i++){
		for (int j=1 ;j<=19;j++){
			if (stone[i][j] == 1)
				for (int t = 0;t<=3;t++){
					x = i+x1[t];
					y = j+y1[t];
					if (1<=x&& x<=19 && 1<=y && y<=19 && stone[x][y] == 0){
						sum += 1;
					}
				}
		}
	}
	return sum;
}

		
int main(void){
	int T,n,sum;
	
	scanf("%d",&T);
	for (int i=1;i<=T;i++){
		scanf("%d",&n);
		sum = work(n);
		printf("%d\n",sum);
	}
}

