#include<iostream>
#include<cassert>
#define int long long
#define endl '\n'
using namespace std;
const int N=109;
int dta[N][2];
int ans;
int gcd(int a,int b){return b==0?a:gcd(b,a%b);}
void solve(int i,int j,int k){
	int s;
	int x1,y1,x2,y2;
	x1=dta[j][0]-dta[i][0];
	x2=dta[k][0]-dta[i][0];
	y1=dta[j][1]-dta[i][1];
	y2=dta[k][1]-dta[i][1];
	s=x1*y2-x2*y1;
	if(s<0)
		s=-s;
	if(s==0)
		return;
	int e=0;
	x1=abs(dta[j][0]-dta[i][0]);
	y1=abs(dta[j][1]-dta[i][1]);
	e+=gcd(x1,y1);
	x1=abs(dta[k][0]-dta[i][0]);
	y1=abs(dta[k][1]-dta[i][1]);
	e+=gcd(x1,y1);
	x1=abs(dta[j][0]-dta[k][0]);
	y1=abs(dta[j][1]-dta[k][1]);
	e+=gcd(x1,y1);
	//int n=s+2-e;
	//cout<<i<<' '<<j<<' '<<k<<' '<<s<<' '<<e<<' '<<n<<endl;
	//assert(n%2==0);
	//n/=2;
	if(e>ans)
		ans=e;
}
signed main(void){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	ans=0;
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>dta[i][0]>>dta[i][1];
	for(int i=0;i<n;i++)
		for(int j=i+1;j<n;j++)
			for(int k=j+1;k<n;k++)
				solve(i,j,k);
	cout<<ans<<endl;
	
	return 0;
}
