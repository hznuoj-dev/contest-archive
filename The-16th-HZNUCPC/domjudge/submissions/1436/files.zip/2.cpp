#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#define maxn 5010
#define ll long long
using namespace std;

int n;
char s[maxn];

void work() { 
	cin >> s + 1;
	n = strlen(s + 1); 
	int ans = 0; 
	for (int k = 2; k < n; ++k) {
		vector<pair<int, int>> vec;
		int l = k, r = k; 
		while (l >= 1 && r <= n) { 
			if (s[l] != s[r]) vec.emplace_back(l, r);
			if (!vec.size()) ans = max(ans, r - l + 1); 
			if (vec.size() == 2) {
				pair<int, int> x = vec[0], y = vec[1];
				if (s[x.first] == s[y.second] && s[x.second] == s[y.first])
					ans = max(ans, r - l + 1); 
				if (s[x.first] == s[y.first] && s[x.second] == s[y.second])
					ans = max(ans, r - l + 1);
			}
			if (vec.size() > 2) break;
			--l, ++r;
		}
	}
	for (int k = 1; k < n; ++k) { 
		vector<pair<int, int>> vec;
		int l = k, r = k + 1; 
		while (l >= 1 && k <= n) { 
			if (s[l] != s[r]) vec.emplace_back(l, r);
			if (!vec.size()) ans = max(ans, r - l + 1); 
			if (vec.size() == 2) {
				pair<int, int> x = vec[0], y = vec[1];
				if (s[x.first] == s[y.second] && s[x.second] == s[y.first])
					ans = max(ans, r - l + 1); 
				if (s[x.first] == s[y.first] && s[x.second] == s[y.second])
					ans = max(ans, r - l + 1);
			}
			--l, ++r;
		}
	}
	if (ans == 1) ans = 0;
	cout << ans << "\n";
}

int main() { 
	ios::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr); 
	
	int T; cin >> T;
	while (T--) work(); 
	return 0; 
} 