#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;
#define quick_cin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define rep1(i,a,n) for(int i=(a);i<(n);++i)
#define rep2(i,a,n) for(int i=(a);i<=(n);++i)
#define per1(i,n,a) for(int i=(n);i>(a);--i)
#define per2(i,n,a) for(int i=(n);i>=(a);--i)
#define endl "\n"
typedef long long LL;
#define int LL
int n,m;
signed main ()
{
	quick_cin();
	
	cin>>n>>m;
	if(n%m)cout<<"YES";
	else cout<<"NO";
	return 0;
}