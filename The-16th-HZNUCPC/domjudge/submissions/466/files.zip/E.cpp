#include<bits/stdc++.h>
using namespace std;
#define int long long
int n;
int x[105], y[105];
int dfs(int a, int b){
	int g = __gcd(a, b);
	if(g == 1)return 1;
	return g * dfs(a / g, b / g);
}
int calc(int a, int b){
	int A = abs(x[a] - x[b]);
	int B = abs(y[a] - y[b]);
	return dfs(A, B);
}
signed main() {
	scanf("%lld", &n);
	for (int i = 1; i <= n; i++)
		scanf("%lld%lld", &x[i], &y[i]);
		int ans = 0;
	for (int i = 1; i < n; i++)
		for (int j = i + 1; j < n; j++) {
			for (int k = j + 1; k <= n; k++) {
				if((y[k] - y[i]) * (x[j] - x[i]) == (y[j] - y[i]) * (x[k] - x[i]))continue;
				ans = max(ans, calc(i, j) + calc(i, k) + calc(j, k));
			}
		}
	cout<<ans<<endl;
}