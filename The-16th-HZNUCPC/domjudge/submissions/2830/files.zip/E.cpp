#include<iostream>
#include<cmath>
using namespace std;
double a,b,c,maxa,maxb,maxc,maxp;
long long res,n,x[100010],y[100010];
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>x[i]>>y[i];
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int h=j+1;h<=n;h++)
			{
				 a=sqrt((pow(1.0*(x[i]-x[j]),2)+pow((y[i]-y[j])*1.0,2))*1.0);
			     b=sqrt((pow(1.0*(x[j]-x[h]),2)+pow((y[j]-y[h])*1.0,2))*1.0);
				 c=sqrt((pow(1.0*(x[i]-x[h]),2)+pow((y[i]-y[h])*1.0,2))*1.0);
				double p=(a+b+c)*1.0/2;
				long long ans=(long long)sqrt(p*(p-a)*(p-b)*(p-c));
				res=max(res,ans);
			}
		}
	}
	cout<<res;
	return 0;
}