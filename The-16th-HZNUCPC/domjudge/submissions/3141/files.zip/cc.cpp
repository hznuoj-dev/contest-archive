#include<bits/stdc++.h>
#define PII pair<int,int>
#define F first
#define S second
#define LL long long
using namespace std;

const int N = 1e5 + 10,mod = 1e9 + 7;

int zia[27],zib[27],cnt1,cnt2;
int op[100],oop[100];
int a[N],b[N];
int main(){
	LL ans=0;
	char a1[N],b1[N];
	cin>>a1>>b1;
	int n=strlen(a1);
	for(int i=0;i<n;i++){
		a[i]=a1[i]-'a'+1;
		b[i]=b1[i]-'a'+1;
	}
	for(int i=0;i<n;i++){
		zia[a[i]]++;
		zib[b[i]]++;
	}
	for(int i=1;i<=26;i++){
		if(zia[i]>0)cnt1++;
		if(zib[i]>0)cnt2++;
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			int flag[10]={0};
			if(zia[b[i]]==0){
				flag[1]=1;
				cnt1++;
			}
			if(zib[a[i]]==0){
				flag[2]=1;
				cnt2++;
			}
			zia[a[i]]--,zia[b[i]]++;
			zib[a[i]]++,zib[b[i]]--;
			if(zia[a[i]]==0){
				flag[3]=1;
				cnt1--;
			}
			if(zib[b[i]]==0){
				flag[4]=1;
				cnt2--;
			}
			if(zia[b[j]]==0){
				flag[5]=1;
				cnt1++;
			}
			if(zib[a[j]]==0){
				flag[6]=1;
				cnt2++;
			}
			zia[a[j]]--,zia[b[j]]++;
			zib[a[j]]++,zib[b[j]]--;
			if(zia[a[j]]==0){
				flag[7]=1;
				cnt1--;
			}
			if(zib[b[j]]==0){
				flag[8]=1;
				cnt2--;
			}
			if(cnt1==cnt2)ans++;
			if(flag[1]==1)cnt1--;
			if(flag[2]==1)cnt2--;
			if(flag[3]==1)cnt1++;
			if(flag[4]==1)cnt2++;
			if(flag[5]==1)cnt1--;
			if(flag[6]==1)cnt2--;
			if(flag[7]==1)cnt1++;
			if(flag[8]==1)cnt2++;
			zia[a[i]]++,zia[b[i]]--;
			zib[a[i]]--,zib[b[i]]++;
			zia[a[j]]++,zia[b[j]]--;
			zib[a[j]]--,zib[b[j]]++;			
		}
	}
	cout<<ans%mod;
	return 0;
}