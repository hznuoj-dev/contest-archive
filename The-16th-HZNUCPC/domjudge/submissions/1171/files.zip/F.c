#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,sum,flag=0;
	int i;
	while(scanf("%d %d",&n,&m)!=EOF)
	{
		if(n%m==0)
		{
			flag=2;
		}
		else
		{
			for(i=0;i<100000;i++)
			{
				if(n%m!=0 && m>2)
				{
					m--;
				}
				if(n%m!=0 && m<=2)
				{
					flag=1;
					break;
				}
			}
		}
		if(flag==2)
		{
			printf("NO");
		}
		if(flag==1)
		{
			printf("YES");
		}
	}
}