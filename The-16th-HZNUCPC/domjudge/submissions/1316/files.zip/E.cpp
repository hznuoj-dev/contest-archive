#include<bits/stdc++.h>
using namespace std;
pair<long long,long long>z[200];
int main()
{
	long long n,cnt=1,maxx=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		long long x,y;
		cin>>x>>y;
		z[i]={x,y};
	}
	for(long long i=1;i<=n;i++)
	{
		for(long long j=i+1;j<=n;j++)
		{
			for(long long k=j+1;k<=n;k++)
			{
				long long s=__gcd(abs(z[i].first-z[j].first),abs(z[i].second-z[j].second))+__gcd(abs(z[i].first-z[k].first),abs(z[i].second-z[k].second))+__gcd(abs(z[k].first-z[j].first),abs(z[k].second-z[j].second));
				maxx=max(maxx,s);
			}
		}
	}
	cout<<maxx<<endl;
}