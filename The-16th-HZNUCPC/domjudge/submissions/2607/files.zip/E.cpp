#include <bits/stdc++.h>
#define int long long
using namespace std;
int n;
typedef pair<int,int> PII;
PII a[110];
map<PII, int> mp;
signed main()
{
	ios::sync_with_stdio(0);
	
	cin.tie(0);
	
	cin >> n;
	set<PII> all;
	int uu = 0;
	for(int i = 0 ; i < n ; i ++) {
		int x, y; cin >> x >> y;
		a[i] = {x, y};
	}
	
	for(int i = 0 ; i < n ; i ++)
	{
		for(int j = i + 1 ; j < n ; j ++)
		{
			int x1 = a[i].first, y1 = a[i].second;
			int x2 = a[j].first, y2 = a[j].second;
			x2 -= x1;
			y2 -= y1;
			x2 = abs(x2);
			y2 = abs(y2);
			mp[{i,j}] = __gcd(x2 ,y2) - 1;
			mp[{j,i}] = __gcd(x2 ,y2) - 1;
		}
	}
	
	int res = 0;
	for(int i = 0 ; i < n ; i ++)
	{
		for(int j = i + 1 ; j < n ; j ++)
		{
			for(int k = j + 1 ; k < n ; k ++)
			{
				int x1 = a[i].first, y1 = a[i].second;
				int x2 = a[j].first, y2 = a[j].second;	
				int x3 = a[k].first, y3 = a[k].second;
				if((y3 - y1) * (x2 - x1) != (y2 - y1) * (x3 - x1)) {
					res = max(res, mp[{i, j}] + mp[{j, k}] + mp[{k, i}] + 3);
				}
			}
		}
	}
	
	cout << res << endl;
}   
