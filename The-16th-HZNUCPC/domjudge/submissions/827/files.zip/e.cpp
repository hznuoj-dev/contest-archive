#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
typedef long long ll;
using namespace std;
const int N=110;
int n;
struct nd {
	ll x,y;
	nd operator-(const nd b)const{
		return {x-b.x,y-b.y};
	}
}a[N];
ll cr(nd a,nd b) {
	return a.x*b.y-a.y*b.x;
}
ll calc(nd a) {
	ll x=abs(a.x),y=abs(a.y);
	return __gcd(x,y);
}
int main() {
#ifdef LOCAL
    freopen(".in","r",stdin);
#endif
    ios::sync_with_stdio(0); cin.tie(0);
	cin>>n;
	For(i,1,n) cin>>a[i].x>>a[i].y;
	ll ans=0;
	For(i,1,n) For(j,i+1,n) For(k,j+1,n) {
		if(!cr(a[j]-a[i],a[k]-a[i])) continue;
		ans=max(ans,calc(a[i]-a[j])+calc(a[i]-a[k])+calc(a[j]-a[k]));
	}
	cout<<ans;
}