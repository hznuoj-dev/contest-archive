#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;
using ll = long long;
using pll = pair<ll, ll>;
bool line(pll a, pll b, pll c)
{
    if ((a.second - b.second) * (a.first - c.first) == (a.first - b.first) * (a.second - c.second))
    {
        return true;
    }
    return false;
}
ll gcd(ll a, ll b)
{
    if (b == 0)
        return a;
    return gcd(b, a % b);
}
ll len(pll a, pll b)
{
    ll x = abs(a.first - b.first);
    ll y = abs(a.second - b.second);
    ll g = gcd(x, y);
    ll tot = (x + 1) * (y + 1) - g - 1;
    tot /= 2;
    return g;
}
ll check(pll a, pll b, pll c)
{
    // ll up = max({a.second, b.second, c.second});
    // ll down = min({a.second, b.second, c.second});
    // ll left = min({a.first, b.first, c.first});
    // ll right = max({a.first, b.first, c.first});
    // ll x = right - left + 1, y = up - down + 1;
    // ll tot = x * y;
    ll res = len(a, b) + len(a, c) + len(b, c);
    return res;
}
int main()
{
    int n;
    cin >> n;
    vector<pll> a(n);
    for (auto &[i, j] : a)
    {
        cin >> i >> j;
    }
    ll mx = 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = i + 1; j < n; j++)
        {
            for (int k = j + 1; k < n; k++)
            {
                if (line(a[i], a[j], a[k]))
                    continue;
                mx = max(mx, check(a[i], a[j], a[k]));
            }
        }
    }
    cout << mx << '\n';
}
