#include<iostream>
#include<algorithm>
using namespace std;
int q[22][22];

int main()
{
	long long t,i,j,k,sum,n,x,y;
	for(i=1;i<=19;i++)
	{
		q[0][i]=-1;
		q[i][0]=-1;
		q[i][20]=-1;
		q[20][i]=-1;
	}
	cin>>t;
	while(t--)
	{
		for(i=1;i<=19;i++)
		for(j=1;j<=19;j++)
		{
			q[i][j]=0;
		}
	sum=0;
		cin>>n;
		for(i=1;i<=n;i++)
		{
			cin>>x>>y>>k;
			if(k==1){
			q[x][y]=1;
			}
			else q[x][y]=2;
		}
	for(i=1;i<=19;i++)
	 for(j=1;j<=19;j++)
	 {
	 	if(q[i][j]==1)
	 	{
	 		if(q[i][j+1]==0){ sum++;}
	 			if(q[i+1][j]==0){ sum++;}
	 				if(q[i][j-1]==0){ sum++;}
	 					if(q[i-1][j]==0){ sum++;}
		 }
	 }cout<<sum<<endl;
	}
	return 0;
}