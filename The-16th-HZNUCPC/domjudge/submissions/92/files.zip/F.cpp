#include<iostream>
using namespace std;
int main(){
	int n,m;
	cin>>n>>m;
	if(n==1) cout<<"YES"<<endl;
	if(m>n/2) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	return 0;
}