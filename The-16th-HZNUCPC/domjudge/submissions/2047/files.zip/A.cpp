#include<bits/stdc++.h>
using namespace std;
int main(){
    int a[21][21]={1},c;
    int t,n,i,he,j;
    for(i=0;i<21;i++)
    {for(j=0;j<21;j++)
    {a[i][j]=1;
	} 
	}
    scanf("%d",&t);
    while(t--)
    {scanf("%d",&n);
    int x,y;
    he=0;
    for(i=1;i<=n;i++)
    {scanf("%d %d %d",&x,&y,&c);
	
	if(c==1)
	he=he+a[x-1][y]+a[x][y-1]+a[x][y+1]+a[x+1][y];
	a[x-1][y]=0;a[x][y-1]=0;a[x][y+1]=0;a[x+1][y]=0;a[x][y]=-1;}
printf("%d\n",he);
	
	
	
    
	}
    return 0;
	}
