#include<bits/stdc++.h>
using namespace std;
long long n,m,flag=0;
int main()
{
	scanf("%lld%lld",&n,&m);
	long long tmp=sqrt(m);
	if(m<=1000000)
		tmp=m;
	for(int i=2;i<=tmp;i++)
	{
		if(n%i==0)
		{
			flag=1;
			break;
		}
	}
	if(flag)
		cout<<"NO"<<endl;
	else
		cout<<"YES"<<endl;
//	if(n==1||m==1)
//	{
//		cout<<"YES"<<endl;
//		return 0;
//	}
//	if(n<=m)
//	{
//		cout<<"NO"<<endl;
//		return 0;
//	}
//	while(m)
//	{
//		cout << n<< " "<<m <<endl;
//		if(m==1)
//			break;
//		if(n%m==0)
//		{
//			cout<<"NO"<<endl;
//			return 0;
//		}
//		m=n%m;
//		
//	}
//	cout<<"YES"<<endl;
	return 0;
}