#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll mid=1e9+7;
bool solve(ll r,ll n){
	for(int i=2;i*i<=n;i++){
		if(n%i==0){
			while(n%i==0)n/=i;
			if(i<=r) return false;
		}
	}
	if(n>1){
		if(n<=r) return false;
	}
	return true;
	
}
int main(){
	ll n,m;
	cin>>n>>m;
	if(solve(m,n)) cout<<"YES";
	else cout<<"NO";
}