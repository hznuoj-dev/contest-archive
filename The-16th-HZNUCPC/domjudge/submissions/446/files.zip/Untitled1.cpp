#include<bits/stdc++.h>
//#define int long long
//#define mid (l+r>>1)
using namespace std;
typedef long long ll;
const int N=400;
int a[N],b[N],c[N];
int vis[N][N];
int main(){


	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		memset(vis,0,sizeof(vis));
		for(int i=1;i<=n;i++){
			int x;
			cin>>a[i]>>b[i]>>c[i];
			vis[a[i]][b[i]]=x+1;
		}
		int sum=0;
		for(int i=1;i<=n;i++){
			if(c[i]==2)continue;
			int x=a[i],y=b[i];
			if(x-1>0&&y>0&&x-1<=19&&y<=19){
				sum++;
			}
			if(x>0&&y-1>0&&x<=19&&y-1<=19){
				sum++;
			}
			if(x+1>0&&y>0&&x+1<=19&&y<=19){
				sum++;
			}
			if(x>0&&y+1>0&&x<=19&&y+1<=19){
				sum++;
			}
			if(vis[x-1][y])sum--;
			if(vis[x][y-1])sum--;
			if(vis[x+1][y])sum--;
			if(vis[x][y+1])sum--;
		//	cout<<sum<<endl;
		}
		cout<<sum<<endl;
	}
	return 0;	
}