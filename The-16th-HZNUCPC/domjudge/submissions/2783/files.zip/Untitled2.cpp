#include<bits/stdc++.h>
#define hor(i,l,r) for(int i=l;i<=r;i++)
#define inf 0x7fffffff
#define ls p<<1
#define rs p<<1|1
#define mid ((l+r)>>1)
using namespace std;
template<typename T> void rd(T &x){
    int f=1;x=0;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c))x=x*10+c-48,c=getchar();x*=f;
}const int N=2e5+10;
struct sgt{
	struct node{
		int min,tag;
	}t[8*N];
	void up(int p){
		t[p].min=min(t[ls].min,t[rs].min);
	}void mo(int p,int v){
		t[p].min=min(t[p].min,v);
		t[p].tag=min(t[p].tag,v);
	}
	void down(int p){
		if(t[p].tag==inf)return;
		mo(ls,t[p].tag);mo(rs,t[p].tag);
		t[p].tag=inf;
	}void build(int p,int l,int r){
		t[p].min=inf;t[p].tag=inf;if(l==r) return;
		build(ls,l,mid);build(rs,mid+1,r);
	}void modify(int p,int l,int r,int L,int R,int _){
		if(L<=l&&r<=R) return mo(p,_);
		down(p);
		if(L<=mid)modify(ls,l,mid,L,R,_);
		if(R>mid)modify(rs,mid+1,r,L,R,_);up(p);
	}void _modify(int p,int l,int r,int P,int _){
		if(l==r) return (void)(t[p].min=_);
		down(p);
		if(P<=mid)_modify(ls,l,mid,P,_);
		else _modify(rs,mid+1,r,P,_);up(p);
	}int query(int p,int l,int r,int L,int R){
	//	printf("%d %d %d %d %d\n",p,l,r,L,R);
		if(L<=l&&r<=R) return t[p].min;int ans=inf;
		down(p);
		if(L<=mid) ans=min(ans,query(ls,l,mid,L,R));
		if(R>mid) ans=min(ans,query(rs,mid+1,r,L,R));
		return ans;
	}
}T;
struct que{
	int op,l,r,t,id;
}q[N];
int b[2*N],cnt,n,m,x,Ans[N];
bool cmp(que a,que b){
	if(a.t==b.t){
		if(a.op==b.op){	
			int adis,bdis;
			if(a.l<=x&&x<=a.r) adis=0;
			else if(a.r<=x) adis=x-a.r;
			else adis=a.l-x;
			if(b.l<=x&&x<=b.r) bdis=0;
			else if(b.r<=x) bdis=x-b.r;
			else bdis=b.l-x;
			return adis<bdis;
		}
		return a.op>b.op;
	}
	return a.t>b.t;
}
int sc(int x){
	return (lower_bound(b+1,b+cnt+1,x)-b);
}int main(){
	scanf("%d%d%d",&n,&m,&x);
	hor(i,1,n){
		scanf("%d%d%d",&q[i].t,&q[i].l,&q[i].r),q[i].op=1;q[i].id=i;
		b[++cnt]=q[i].l;b[++cnt]=q[i].r;
	}hor(i,1,m) scanf("%d%d",&q[i+n].t,&q[i+n].l),q[i+n].op=0,b[++cnt]=q[i+n].l,q[i+n].id=i;
	sort(q+1,q+n+m+1,cmp);sort(b+1,b+cnt+1);cnt=unique(b+1,b+cnt+1)-b-1;
///	puts("lrher tql");
	T.build(1,1,n+cnt);
	T._modify(1,1,n+cnt,n+x,0);
//	puts("lrher tql");
	hor(i,1,n+m){
	//	printf("%d\n",i);
		if(q[i].op){
			q[i].l=sc(q[i].l);q[i].r=sc(q[i].r);
			int len=T.query(1,1,n+cnt,n+q[i].l,n+q[i].r);
			if(len==inf) continue;
			T._modify(1,1,n+cnt,q[i].id,len+1);
			T.modify(1,1,n+cnt,n+q[i].l,n+q[i].r,len+1);
		}else{
			q[i].l=sc(q[i].l);
			Ans[q[i].id]=T.query(1,1,n+cnt,n+q[i].l,n+q[i].l);
			if(Ans[q[i].id]==inf) Ans[q[i].id]=-1;
		}
	//	hor(i,1,n+cnt) printf("%d ",T.query(1,1,n+cnt,i,i));printf("\n");
	}hor(i,1,m) printf("%d\n",Ans[i]);
}