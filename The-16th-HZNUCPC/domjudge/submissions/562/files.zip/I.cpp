#include<bits/stdc++.h>
using namespace std;
int T;
string S;
int L[27],R[27];
int main(){
	ios::sync_with_stdio(false);
	cin>>T;
	while(T--){
		cin>>S;
		int n=S.length();
		for(int i=0;i<26;++i) L[i]=n+1,R[i]=-1;
		for(int i=0;i<n;++i) L[S[i]-'a']=min(L[S[i]-'a'],i),R[S[i]-'a']=i;
		int ans=0;
		for(int i=1;i<n;++i){
			int l=i,r=i+1;
			int len=0;
			while(l>=1&&r<=n){
				len+=2;
				if(S[l-1]!=S[r-1]) break ;
				ans=max(ans,len);--l;++r;
			}
			int pl=l,pr=r;
			--l;++r;
			bool f=0;
//			printf("i:%d,pl:%d,pr:%d\n",i,pl,pr);
			while(l>=1&&r<=n){
				len+=2;
				if(f==0&&S[l-1]!=S[r-1]&&(S[l-1]==S[pl-1]||S[l-1]==S[pr-1])&&(S[r-1]==S[pl-1]||S[r-1]==S[pr-1])){
					ans=max(ans,len);f=1 ;
				}
				else if(S[l-1]!=S[r-1]) break ;
				--l;++r;if(f) ans=max(ans,len);
			}
		}
		for(int i=1;i<=n;++i){
			int l=i,r=i;
			int len=-1;
			while(l>=1&&r<=n){
				len+=2;
				if(S[l-1]!=S[r-1]) break ;
				ans=max(ans,len);--l;++r;
			}
			int pl=l,pr=r;
			--l;++r;
			bool f=0;
			while(l>=1&&r<=n){
				len+=2;
				if(f==0&&S[l-1]!=S[r-1]&&(S[l-1]==S[pl-1]||S[l-1]==S[pr-1])&&(S[r-1]==S[pl-1]||S[r-1]==S[pr-1])){
					ans=max(ans,len);f=1 ;
				}
				else if(S[l-1]!=S[r-1]) break ;
				--l;++r;if(f) ans=max(ans,len);
			}
		}
		cout<<(ans==1?0:ans)<<"\n";
	}
}