#include<bits/stdc++.h>
using namespace std;
//#define int long long 
typedef long long ll;

const int N = 2e5+7;
ll n,ans;
struct node{
	ll x,y;
}a[107];

ll cal(int i,int j){
	return __gcd(abs(a[i].x-a[j].x),abs(a[i].y-a[j].y));
}

bool check(int i,int j,int k){
	ll ax = a[j].x - a[i].x;
	ll ay = a[j].y - a[i].y;
	ll bx = a[k].x - a[i].x;
	ll by = a[k].y - a[i].x;
	
	ll t = ax * by - ay * bx;
	if (t == 0){
		return false;
	}
	return true;
}

void solve(){
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i].x>>a[i].y;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				if(check(i,j,k)){
					ans=max(ans,cal(i,j)+cal(j,k)+cal(k,i));
				}
			}
		}
	}
	cout<<ans<<'\n';
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	int t = 1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}