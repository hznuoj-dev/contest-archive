#include<bits/stdc++.h>
using namespace std;
#define int long long

signed main()
{
	int n,m;
	cin>>n>>m;
	int flag=1;
	if(m==1||n==1)
	{
		cout<<"YES"<<endl;;
		return 0;
	}
	while(m>1)
	{
		int tmp=n%m;
		if(tmp==m||tmp==0)
		{
			flag=0;
			break;
		}
		m=tmp;
	}
	if(flag)cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	return 0;
}