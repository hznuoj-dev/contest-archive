#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
long long n , m ,x , last_time;
const int N = 1e5 + 10;
vector<pair<long long,long long>> vec[N];
long long dfs(int nowt , int l , int r , int p){
	long long ans = 1e9;
	for(int i = nowt ; i <= last_time;i++){
		for(auto j : vec[i]){
			if(j.second < l || j.first > r) continue;
			if(p <= j.second && p >= j.first) return 1; 
			else ans = min(ans, dfs(nowt + 1,j.first , j.second,p)+1);
		}
	}
	return ans;
}
int main(){
	cin >> n >> m >> x;
	for(long long i = 1 , t , l , r ; i <= n;i++){
		cin >> t >> l >> r;
		vec[t].push_back({l , r});
		last_time = max(last_time , t);
	}
	for(long long i = 1 , c, p ; i <= m ;i++){
		cin >> c >> p;
		if(p == x) cout << 1 << endl;
		else{
		
			long long ans = dfs(c , p , p ,x);
			if(ans == 1e9) cout << -1 << endl;
			else cout << dfs(c , p , p , x) << endl;
		}
	}
}
