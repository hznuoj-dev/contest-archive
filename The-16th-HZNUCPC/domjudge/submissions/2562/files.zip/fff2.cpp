#include <bits/stdc++.h>
using namespace std;
const int N=1000,M=N*2;
int e[M], ne[M], h[N], w[M], idx;
#define ll long long 
#define int long long

ll qpow(ll a,ll b,ll p)
{
	ll sum=1;
	while(b)
	{
		if(b&1)
		sum*=a%p;
		b>>=1;
		a*=a%p;
	}
	return sum;
}

void add(int a,int b,int c){
	e[idx]=b;w[idx]=c;ne[idx]=h[a];h[a]=idx++;
}

signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	
int n,m;
cin>>n>>m;
if(m==1)
cout<<"YES";
else 
{
	if(n==1)
	cout<<"YES";
	else if(n%2==0)
	cout<<"NO";
	else  if(n>m)
	{
		int flag=0;
		for(int i=3;i<=100;i+=2)
		{
			if(n%i==0)
			{
				flag=i;
				break;
			}
		}
		if(flag==0)
		{
			if(m>=n)
			cout<<"NO";
			else
			cout<<"YES";
		}
		
		else
	{
			if(m>=flag)
		cout<<"NO";
		else
		cout<<"YES";
	}
	}
	else if(n==m)
	cout<<"NO";
	else if(m>n)
	{
		cout<<"NO";
	}
}
	
	return 0;
}