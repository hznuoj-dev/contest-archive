#include <bits/stdc++.h>
using namespace std;
using ll =long long ;
ll n,m,k,cnt,sum;
struct pos{
	ll l,r,sum;
	
};
void solve(){
	cin >> n;
	cin >>m;
	//ll k = __gcd(n,m);
	m = min(n,m);
	while(m>1){
		m=n%m;
	}
	if (m==1) {
		cout <<"YES" <<endl;
	}
	else cout <<"NO"<<endl;
}
int main(){
	ll t;
	//cin >> t;
	//while(t--)
	solve();
}