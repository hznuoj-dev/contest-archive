#include<bits/stdc++.h>
#define fi first
#define se second
#define int long long
using namespace std;
int n,m,q;
int N,M;
struct bit{
	int tr[110][110];
	void upd1(int x,int y,int k){
		while(y<=M){
			tr[x][y]+=k;y+=y&-y;
		}
	}
	void upd2(int x,int y,int k){
		while(x<=N){
			upd1(x,y,k);
			x+=x&-x;
		}
	}
	int qry1(int x,int y){
		int ret=0;
		while(y){
			ret+=tr[x][y];y-=y&-y;
		}
		return ret;
	}
	int qry2(int x,int y){
		int ret=0;
		while(x){
			ret+=qry1(x,y);x-=x&-x;
		}
		return ret;
	}
}t1[10][10],t2[10][10],t3[10][10],t4[10][10];
// t1 : 1
// t2 : x1
// t3 : y1
// t4 : x1y1
int a[1010][1010];
void Upd(int X,int Y,int k){
	for(int i=0;i<10;++i){
		for(int j=0;j<10;++j){
			int p=X/10+1,q=Y/10+1;
			if(X%10>i) ++p;
			if(Y%10>j) ++q;
			t1[i][j].upd2(p,q,k);
			t2[i][j].upd2(p,q,k*p);
			t3[i][j].upd2(p,q,k*q);
			t4[i][j].upd2(p,q,k*p*q);
		}
	}
}
int sum[10][10];
void Qry(int X,int Y,int k){
	if(X<0||Y<0)return ;
	for(int i=0;i<10;++i){
		for(int j=0;j<10;++j){
			int p=X/10+1,q=Y/10+1;
			if(X%10<i) --p;
			if(Y%10<j) --q;
			int v1=t1[i][j].qry2(p,q),v2=t2[i][j].qry2(p,q),v3=t3[i][j].qry2(p,q),v4=t4[i][j].qry2(p,q);
			int res=(p*q+p+q+1)*v1+(-q-1)*v2+(-p-1)*v3+v4;
			sum[i][j]+=res*k;
		}
	}
}
signed main(){
//	freopen("2.in","r",stdin);
	ios::sync_with_stdio(false);
	cin>>n>>m>>q;
	N=(n+9)/10+1,M=(m+9)/10+1;
	for(int i=0;i<n;++i){
		for(int j=0;j<m;++j) cin>>a[i][j];
	}
	for(int i=0;i<n;++i){
		for(int j=0;j<m;++j){
			t4[i%10][j%10].upd2(i/10+1,j/10+1,a[i][j]);
		}
//		printf("\n");
	}
	for(int i=1;i<=q;++i){
		int op,x1,y1,x2,y2,c;
		cin>>op>>x1>>y1>>x2>>y2>>c;
		x1--;y1--;x2--;y2--;
		if(op==1){
			Upd(x1,y1,c);
			Upd(x1,y2+1,-c);
			Upd(x2+1,y1,-c);
			Upd(x2+1,y2+1,c);
		}
		else{
			memset(sum,0,sizeof(sum));
			Qry(x2,y2,1);
			Qry(x1-1,y2,-1);
			Qry(x2,y1-1,-1);
			Qry(x1-1,y1-1,1);
			vector<int>su;
			for(int i=0;i<10;++i) for(int j=0;j<10;++j) su.push_back(sum[i][j]);
			sort(su.begin(),su.end());reverse(su.begin(),su.end());
			long long ans=0;
//			for(int i:su) printf("%d ",i);printf("\n");
//			c=0;
			for(int i=0;i<c&&i<su.size();++i) (ans+=(su[i]<<1));
			for(int i=c;i<su.size();++i) ans+=su[i];
			cout<<ans<<"\n";
		}
	}
}