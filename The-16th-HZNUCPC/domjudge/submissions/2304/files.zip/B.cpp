#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9 +7;
const int N = 1e3 +7;
ll t,n,m,s;

inline void run(){
   cin >> n >>m;
   if(n==1||m==1) cout<<"YES"<<'\n';
   if(n<=m) cout<<"NO"<<'\n';
   else
   {
   		ll k=n%m;
   		while(k)
   		{
   			if(k==1)
   			{
   				cout<<"YES"<<'\n';
   				return;
			}
   			if(n%k==0)
   			{
   				cout<<"NO"<<'\n';
				return;	
			}
			k=n%k;
		}
   }
}
int main()
{
//      int T;
//      for(cin >>T;T--;)
	    run();
}
