#include<bits/stdc++.h>
using namespace std;
int xd(int a,int b,int c,int d)
{
	int ds=0;
	int xc,yc;
	xc=abs(a-c);
	yc=abs(b-d);
	ds=__gcd(xc,yc)-1;
	return ds;
}
int pd(double a,double b,double c,double d,double e,double f)
{
	if((d-b)/(c-a)==(d-f)/(c-e))
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
	
int main() {
	int d;
	cin>>d;
	int x[101]={0};
	int y[101]={0};
	int i,j,k;
	for(i=1;i<=d;i++)
	{
		cin>>x[i]>>y[i];
	}
	int ma=0;
	for(i=3;i<=d;i++)
	{
		for(j=2;j<i;j++)
		{
			for(k=1;k<j;k++)
			{
				if(pd(x[i],y[i],x[j],y[j],x[k],y[k])==1)
				{
					ma=max(xd(x[i],y[i],x[j],y[j])+xd(x[i],y[i],x[k],y[k])+xd(x[j],y[j],x[k],y[k])+3,ma);
				}
				
			}
		}
	}
	cout<<ma;
	
	
}