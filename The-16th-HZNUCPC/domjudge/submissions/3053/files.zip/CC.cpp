#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod=1e9+7;
int k1[26]={},k2[26]={};
int check(){
	int sum=0;
	for(int i=0;i<26;++i){
		if(k1[i])++sum;
		if(k2[i])--sum;
	}
	if(sum==0)return 1;
	else return 0;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
    string a,b;cin>>a>>b;
    int n=a.size();
    int p[26][26]={0};
    int px[26][26]={false};
    int ans=0;
    for(int i=0;i<n;++i){
    	k1[a[i]-'a']++;
    	k2[b[i]-'a']++;
	}
    for(int i=0;i<n;++i){
    	if(px[a[i]-'a'][b[i]-'a']){
    		px[a[i]-'a'][b[i]-'a']++;
    		continue;
		}
    	k1[a[i]-'a']--;
    	k2[a[i]-'a']++;
		k2[b[i]-'a']--;
		k2[a[i]-'a']++;
    	int sum=0;
    	for(int j=i+1;j<n;++j){
    		k1[a[j]-'a']--;
    		k2[a[j]-'a']++;
			k2[b[j]-'a']--;
			k1[b[j]-'a']++;
    		if(check())++sum;
    		k1[a[j]-'a']++;
    		k2[a[j]-'a']--;
			k2[b[j]-'a']++;
			k1[b[j]-'a']--;
		}
		px[a[i]-'a'][b[i]-'a']++;
		p[a[i]-'a'][b[i]-'a']=sum;
		k1[a[i]-'a']++;
    	k2[a[i]-'a']--;
		k2[b[i]-'a']++;
		k2[a[i]-'a']--;
	}
	for(int i=0;i<26;++i){
		for(int j=0;j<26;++j){
			if(px[i][j]==0)continue;
			int tt=px[i][j];
			ans+=(px[i][j]*p[i][j])%mod;
			if(px[i][j]>2)ans-=tt*(tt-1)/2;
		}
	}
	cout<<ans%mod;
	return 0;
}
