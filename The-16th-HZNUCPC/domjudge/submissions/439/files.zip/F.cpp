#include <bits/stdc++.h>
#define int long long
using namespace std;

int n, m;
typedef pair<int,int> PII;
PII a[110];

signed main()
{
	ios::sync_with_stdio(0);
	
	cin.tie(0);
	cin >> n >> m;
	
	while (m != 1){
		if (n % m == 0){
			cout << "NO" << endl;
			return 0;
		}
		
		m = n % m;
//					cout << n << ' ' << m << endl;
	}
	
	cout << "YES" << endl;
	return 0;
}