#include<stdio.h>
#include<math.h>
int pandaun(double a,double b,double c){//input bianchang a>b>c
	if(fabs(a+b)>c&&fabs(a+c)>b&&fabs(b+c)>a&&fabs(a-b)<c&&fabs(a-c)<b&&fabs(b-c)<a){
		return 1;
	}
	return 0;
}
int main(){
	int n;
	scanf("%d",&n);
	int a[n][2];
	int i,j,k,judge,q=0;
	double c1,c2,c3,s=0,t=0,p;
	for(i=0;i<n;i++){
		scanf("%d %d",&a[i][0],&a[i][1]);
	}
	for(i=0;i<n-2;i++){
		for(j=i+1;j<n-1;j++){
			for(k=j+1;k<n;k++){
				c1=sqrt((a[i][0]-a[j][0])*(a[i][0]-a[j][0])+(a[i][1]-a[j][1])*(a[i][1]-a[j][1]));
				c2=sqrt((a[i][0]-a[k][0])*(a[i][0]-a[k][0])+(a[i][1]-a[k][1])*(a[i][1]-a[k][1]));
				c3=sqrt((a[j][0]-a[k][0])*(a[j][0]-a[k][0])+(a[j][1]-a[k][1])*(a[j][1]-a[k][1]));
				judge=pandaun(c1,c2,c3);
				if(judge==1){
				    p=(c1+c2+c3)/2.0;
					s=sqrt(p*(p-c1)*(p-c2)*(p-c3));
					if(s>t)t=s;
				}
			}
		}
	}
	printf("%.0f",t);
	return 0;
}