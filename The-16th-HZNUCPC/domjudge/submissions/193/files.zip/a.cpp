#include<iostream>
#include<cstring>
#include<algorithm>
#include<stack>
#include<queue>
#define endl '\n'
using namespace std;
const int N=1e6+10,INF=2e9;
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int,int> PII;
PII a[362];
int b[20][20];
int sol(int x,int y){
	int res=0;
	int dx[4]={0,0,1,-1},dy[4]={1,-1,0,0};
	for(int i=0;i<4;i++){
		int xx=x+dx[i],yy=y+dy[i];
		if(xx<1||xx>19||yy<1||yy>19||b[xx][yy])continue;
		cout<<xx<<' '<<yy<<endl,res++;
	}
	return res;
} 
void solve(void){
	memset(b,0,sizeof b);
	int n,res=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		int c;
		cin>>a[i].first>>a[i].second>>c;
		b[a[i].first][a[i].second]=1;
	}
	for(int i=1;i<=n;i++){
		res+=sol(a[i].first,a[i].second);
	}
	cout<<res<<endl;
}
int main(void){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int TT;
	TT=1;
	cin>>TT;
	while(TT--){
		solve();
	}
	return 0;
}