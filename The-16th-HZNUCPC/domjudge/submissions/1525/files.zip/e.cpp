#include <bits/stdc++.h>

using namespace std;
const int N = 22;
double x[N],y[N];

int main()
{
	int n;
	cin >> n;
	for (int i=1;i<=n;i++)
	{
		cin >> x[i] >> y[i];
	}
	int res  = 0;
	for (int i=1;i<=n;i++)
	{
		for (int j=i+1;j<=n;j++)
		{
			for (int k=j+1;k<=n;k++)
			{
				/*
				double ll = sqrt((x[j]-x[k])*(x[j]-x[k]) + (y[j]-y[k])*(y[j]-y[k]));
				double kk = (y[j]-y[k])/(x[j]-x[k]);
				double b = -(y[j]-y[k])/(x[j]-x[k])*x[i] + y[i];
				double b1 = -(y[j]-y[k])/(x[j]-x[k])*x[j] + y[j];
				double h = (b-b1)/sqrt(kk*kk+1);
				h = fabs(h);
				int sum = 0.5*ll*h;
				res = max(res, sum);
				*/
				double k1 = (y[i]-y[j])/(x[i]-x[j]);
				double k2 = (y[i]-y[k])/(x[i]-x[k]);
				double k3 = (y[j]-y[k])/(x[j]-x[k]);
				if (k1==k2 || k1==k3 || k2==k3) continue;
				int sum = 0;
				sum += (int)min(abs(x[i]-x[j]),abs(y[i]-y[j])) - 1;
				sum += (int)min(abs(x[i]-x[k]),abs(y[i]-y[k])) - 1;
				sum += (int)min(abs(x[j]-x[k]),abs(y[j]-y[k])) - 1;
				res = max(res, sum+3);
			}
		}
	}
	cout << res;
	
	return 0;
}