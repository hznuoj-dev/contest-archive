package zime;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		int prime[]=new int[10000000+5];
		boolean isp[]=new boolean[10000000+5];
		isp[0]=true;
		isp[1]=true;
		int cnt=0;
		for(int i=2;i<=10000000;i++){
			if(!isp[i]){
				prime[cnt++]=i;
			}
			for(int j=0;j<=cnt&&i*prime[j]<=10000000;j++){
				isp[i*prime[j]]=true;
				if(i%prime[j]==0)break;
			}
		}
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
			long n=sc.nextLong();
			long m=sc.nextLong();
			int p=0;
			if(n==1||m==1){
				System.out.println("YES");
				continue;
			}
			if(n<=m){
				System.out.println("NO");
				continue;
			}
			for(int i=0;i<cnt;i++){
				if(n%prime[i]==0){
					p=prime[i];
					break;
				}
			}
			if(p>m)System.out.println("YES");
			else System.out.println("NO");
		}
	}

}
