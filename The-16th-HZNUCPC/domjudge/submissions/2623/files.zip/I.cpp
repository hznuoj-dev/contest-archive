#include<bits/stdc++.h>
using namespace std;
using ll=long long;
using ull=unsigned long long;
const int N=1e4+5;
ull hs1[N],hs2[N];
ull kpow[N];
ull gethash1(int l,int r){
	return hs1[r]-hs1[l-1]*kpow[r-l+1];
}
ull gethash2(int l,int r){
	return hs2[l]-hs2[r+1]*kpow[r-l+1];
}
int ch[N][26],pam_cnt,last,fail[N],len[N],pos[N];
char s[N];
int n;
int maxlen[N];
int pre[N][26],nx[N][26];
int cpos[26];
void pam_init(){
	for(int i=0;i<=pam_cnt;++i){
		memset(ch[i],0,sizeof ch[i]);
		len[i]=fail[i]=0;
	}
	pam_cnt=1;last=0;fail[0]=1;fail[1]=1;len[1]=-1;
}
int getfail(int x,int i){
	while(i-len[x]-1<0||s[i-len[x]-1]!=s[i])x=fail[x];
	return x;
}
void extend(int c,int i){
	int f=getfail(last,i);
	if(!ch[f][c]){
		int p=++pam_cnt;
		pos[p]=i;
		len[p]=len[f]+2;
		int q=getfail(fail[f],i);
		fail[p]=ch[q][c];
		ch[f][c]=p;
	}
	last=ch[f][c];
}
void work(){
	scanf("%s",s+1);
	n=strlen(s+1);
	for(int i=1;i<=n;++i){
		hs1[i]=hs1[i-1]*13331+s[i];
	}
	hs2[n+1]=0;
	for(int i=n;i;--i){
		hs2[i]=hs2[i+1]*13331+s[i];
	}
	for(int i=1;i<=n+1;++i){
		memset(pre[i],0,sizeof pre[i]);
		memset(nx[i],0,sizeof nx[i]);
	}
	memset(cpos,0,sizeof cpos);
	for(int i=1;i<=n;++i){
		for(int j=0;j<26;++j){
			pre[i][j]=cpos[j];
		}
		cpos[s[i]-'a']=i;
	}
	memset(cpos,0,sizeof cpos);
	for(int i=n;i;--i){
		for(int j=0;j<26;++j){
			nx[i][j]=cpos[j];
		}
		cpos[s[i]-'a']=i;
	}
	pam_init();
	for(int i=1;i<=n;++i){
		extend(s[i]-'a',i);
		maxlen[i]=len[last];
	}
	int ans=0;
	for(int i=1;i<=n;++i){
		int L=i-maxlen[i]+1,R=i;
		if(R-L+1>=2)ans=max(ans,R-L+1);
		if(L==1||R==n)continue;
		int cl=s[L-1]-'a';
		int p=R+1,l=R+2,r=n;
		while(l<=r){
			int mid=l+r>>1;
			int slen=mid-R-1;
			if(L-2<slen||gethash1(R+2,mid)!=gethash2(L-1-slen,L-1-1))r=mid-1;
			else p=mid,l=mid+1;
		}
		int q=p+1;
		
//		printf("[%d,%d]\n",L,R);
//		printf("p=%d q=%d\n",p,q);
		if(q>n)continue;
		if(s[q]!=s[L-1])continue;
		int q1=L-(q-R);
		if(s[R+1]==s[q1]){
			int p=q,l=q+1,r=n;
			while(l<=r){
				int mid=l+r>>1;
				int slen=mid-q;
				if(q1-1<slen||gethash1(q+1,mid)!=gethash2(q1-slen,q1-1))r=mid-1;
				else p=mid,l=mid+1;
			}
			ans=max(ans,R-L+1+2*(p-R));
		}
	}
	printf("%d\n",ans);
}

int main() {
	kpow[0]=1;
	for(int i=1;i<N;++i){
		kpow[i]=kpow[i-1]*13331;
	}
	int T;scanf("%d",&T);
	while(T--)work();
}
/*

1
ccxyxazyxbghgaxyzbxydc

1000
abccab
ihi
stfgfiut
palindrome
ccxyxazyxbghgaxyzbxydc
*/