#include<bits/stdc++.h>
using namespace std;
#define int long long
#define ll long long
const int N=2e3;

//bool ss(int x){
//	if(x==0||x==1){
//		return false;
//	}
//	for(int i=2;i*i<=x;i++){
//		if(x%i==0){
//			return false;
//		}
//	}
//	return true;
//}
int dir[4][2]={{0,1},{0,-1},{-1,0},{1,0}};
signed main(){
	ll n,m;
	while(cin>>n>>m){
		if(m==1){
			cout<<"YES"<<endl;
			continue;
		}
		if(n<=m){
			cout<<"NO"<<endl;
		}else{
			if(n%2==0){
				cout<<"NO"<<endl;
			}else{
				int vis=-1;
				for(int i=3;i*i<=n;i+=2){
					if(n%i==0){
						vis=i;
						break;
					}
				}
				if(vis!=-1){
					if(m>=vis){
						cout<<"NO"<<endl;
					}else{
						cout<<"YES"<<endl;
					}
				}else{
					cout<<"YES"<<endl;
				}
			}
		}
	}
	return 0;
}