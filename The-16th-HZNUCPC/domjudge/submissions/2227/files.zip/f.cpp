#include "bits/stdc++.h"
using namespace std;
long long a,b,c,d,e,f;
int nb(int x){
	for(int i=2;i<x;i++){
		if(x%i==0){
			return -1;
			break;
		}
	}
}
int main(){
	while(cin>>a>>b){
		long long k=b;
		if(nb(a)==-1){
			cout<<"NO"<<endl;
		}else{
			cout<<"YES"<<endl;
		}
		
}
	return 0;
}