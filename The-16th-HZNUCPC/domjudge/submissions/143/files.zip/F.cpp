#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll gcd(ll x, ll y)
{
	if(y == 0) return x;
	else return gcd(y, x % y);
}
int main()
{
	ll x, y, g;
	cin >> x >> y;
	if(y > x) y = x;
	g = min((ll)(sqrt(x)), y);
	bool bb =true;
	if(gcd(x, y) > 1)bb = false;
	for(int i = 2; i <= g && bb; i ++){
		if(x % i == 0) bb = false;
	}
	if(bb)puts("YES");
	else puts("NO");
}