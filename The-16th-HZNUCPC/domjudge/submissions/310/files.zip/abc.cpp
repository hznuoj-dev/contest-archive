#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using pt = complex<long long>;
/*
#define x real()
#define y imag()
#define int ll
int point_covered(pt a, pt b) {
	assert(a != b);
	if (a.x == b.x) {
		return abs(a.y - b.y) - 1;
	}
	if (a.y == b.y) {
		return abs(a.x - b.x) - 1;
	}
	
	return __gcd(abs(a.y - b.y), abs(a.x - b.x)) - 1;
}

int cross(pt a, pt b) {
	return a.x * b.y - a.y * b.x;
}

int same_line(pt a, pt b, pt c) {
	return cross(b - a, c - a) == 0;
}
*/
int a[105][105];
int dx[] = {1, -1, 0, 0};
int dy[] = {0, 0, 1, -1};
void solve() {
	for (int i = 0; i < 19; ++i) {
		for (int j = 0; j < 19; ++j) {
			a[i][j] = 0;
		}
	}
	int n;
	cin >> n;
	vector<pair<int, int> > candidate;
	while (n--) {
		int x, y, c;
		cin >> x >> y >> c;
		x--, y--;
		a[x][y] = c;
		if (c == 1) {
			candidate.emplace_back(x, y);
		}
		
	}
	
	int res = 0;
	for (auto [x, y] : candidate) {
		for (int i = 0; i < 4; ++i) {
			int nx = x + dx[i];
			int ny = y + dy[i];
			if (nx >= 0 && ny >= 0 && nx < 19 && ny < 19) {
				if (a[nx][ny] == 0) {
					res++;
				}
			}
		}
	}
	cout << res << "\n";
	
}

signed main() {

	int t;
	cin >> t;
	while (t--) {
		solve();
	}
	
}


/*
1
2
1 1 1
2 2 1

1
2
10 9 1
10 10 1
*/