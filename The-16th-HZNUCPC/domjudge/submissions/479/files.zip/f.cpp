#include<bits/stdc++.h>
using namespace std;
#define ll long long
bool check(ll x){
	if(x==1) return 1;
	for(ll i=2;i*i<=x;i++) if(x%i==0) return 0;
	return 1;
}
int main(){
	ll a,b; scanf("%lld%lld",&a,&b);
	if(a<=b) puts("NO");
	else if(check(a)) puts("YES");
	else puts("NO");
}
