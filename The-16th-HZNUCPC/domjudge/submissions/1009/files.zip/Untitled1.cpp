#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int maxn=1e6+10;
int ma[30][30];
void solve(){
	int n,m,ans=0;
	cin>>n>>m;
	if(n<m&&n!=1) cout<<"NO\n";
	else if(n==1||m==1) cout<<"YES\n";
	else if(n%m==0) cout<<"NO\n";
	else{
		while(m!=0&&m!=1){
			m=(n%m);
		}
		if(m==1) cout<<"YES\n";
		else cout<<"NO\n";
	}
	
}
signed main(){
	int T;
	solve();
	
	
	return 0;
} 