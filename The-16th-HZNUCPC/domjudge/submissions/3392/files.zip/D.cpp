#include<bits/stdc++.h>
//#define int long long
#define ll long long
#define vi vector<int>
#define pb push_back

using namespace std;
const int mod = 1e9 + 7;
const int INF = 0x3f3f3f3f;
const int N = 3e5 + 10;
int tr[N<<4], lazy[N << 4];
void push(int o) {
	if (lazy[o] < INF) {
		tr[o * 2] = min(tr[o * 2], lazy[o]);
		tr[o * 2 + 1] = min(tr[o * 2 + 1], lazy[o]);
		lazy[o * 2] = min(lazy[2 * o], lazy[o]);
		lazy[o * 2 + 1] = min(lazy[2 * o + 1], lazy[o]);
		lazy[o] = INF;
	}
}
void upd(int p, int x, int o, int l, int r) {
	if (l == r) {
		tr[o] = x;
		return;
	}
	int mid = (l + r) / 2;
	if (p <= mid) upd(p, x, o * 2, l, mid);
	else upd(p, x, o * 2 + 1, mid + 1, r);
	tr[o] = min(tr[o * 2], tr[o * 2 + 1]);
}
void update(int L, int R, int x, int o, int l, int r) {
	if (L <= l && r <= R) {
		tr[o] = min(tr[o], x);
		lazy[o] = min(lazy[o], x);
		return;
	}
	push(o);
	int mid = (l + r) / 2;
	if (L <= mid) update(L, R, x, o * 2, l, mid);
	if (R > mid) update(L, R, x, o * 2 + 1, mid + 1, r);
	tr[o] = min(tr[o * 2], tr[o * 2 + 1]);
}
int que(int p, int o, int l, int r) {
	if (l == r) {
		return tr[o];
	}
	push(o);
	int mid = (l + r) / 2;
	if (p <= mid) return que(p, o * 2, l, mid);
	else return que(p, o * 2 + 1, mid + 1, r);
}
int rque(int L, int R, int o, int l, int r) {
	if (L <= l && r <= R) {
		return tr[o];
	} else if(r < L || l > R) {
		return INF;	
	}
	push(o);
	int mid = (l + r) / 2;
	return min(rque(L, R, o * 2, l, mid), rque(L, R, o * 2 + 1, mid + 1, r));
}
using pii = pair<int, int>;
void solve() {
	memset(tr, 0x3f, sizeof tr);
	memset(lazy, 0x3f, sizeof lazy);
	int n, m, x;
	cin >> n >> m >> x;
	vector<int> v;
	vector<vector<pair<int, int>>> w(N);
	for (int i = 0; i < n; ++ i) {
		int t, l, r;
		cin >> t >> l >> r;
		v.push_back(l);
		v.push_back(r);
		w[t].push_back({l, r});
	}
	vector<int> ans(m);
	vector<vector<pair<int, int>>> q(N);
	for (int i = 0; i < m; ++ i) {
		int c, p;
		cin >> c >> p;
		v.push_back(p);
		q[c].push_back({p, i});
	}
	sort(v.begin(), v.end());
	v.erase(unique(v.begin(), v.end()), v.end());
	int M = v.size();
	auto get = [&](int X) {
		return distance(v.begin(), lower_bound(v.begin(), v.end(), X)) + 1;
	};
	x = get(x);
	upd(x, 0, 1, 1, M);
	for (int t = N - 1; t; -- t) {
		sort(w[t].begin(), w[t].end(), [&](const pii &a, const pii &b) {
			if (a.second == b.second) return a.first < b.first;
			return a.second > b.second;	
		});
		for (auto [l, r] : w[t]) {
			l = get(l), r = get(r);
			if (l < r) 
			update(l, r, rque(l, r, 1, 1, M) + 1, 1, 1, M);
		}
		for (auto &[p, i] : q[t]) {
			p = get(p);
			ans[i] = que(p, 1, 	1, M);
		}
//		cout << t << '\n';
//		for (int i = 1; i <= M ; ++ i ) cout << que(i, 1, 1, M) << ' ';
//		cout << '\n';
	}
	for (auto &x : ans) {
		if (x <= INF / 2) cout << x << '\n';
		else cout << -1 << '\n';
	}
}
signed main() {
	int t;
	t = 1;
	while (t --) solve();
	return 0;
}
/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5


*/