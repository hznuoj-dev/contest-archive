#include <bits/stdc++.h>
#define M 100005
#define mod 998244353
using namespace std;
template<class T,class... A> void odn(T&& x, A&&... a) {cout<<x; (int[]){(cout<<' '<<a,0)...}; cout<<'\n';}
char A[M],B[M];
int cnta[30],cntb[30],cnt[900],link[30][30];
long long ans;
struct hzl{
    int a,b;
}ll[900];
int check(int a,int b){
    int cnt1=0,cnt2=0;
    cnta[ll[a].a]--;
    cnta[ll[a].b]++;
    cntb[ll[a].a]++;
    cntb[ll[a].b]--;
    cnta[ll[b].a]--;
    cnta[ll[b].b]++;
    cntb[ll[b].a]++;
    cntb[ll[b].b]--;
    for(int i=1;i<=26;i++){
        if(cnta[i])cnt1++;
        if(cntb[i])cnt2++;
    }
    cnta[ll[a].a]++;
    cnta[ll[a].b]--;
    cntb[ll[a].a]--;
    cntb[ll[a].b]++;
    cnta[ll[b].a]++;
    cnta[ll[b].b]--;
    cntb[ll[b].a]--;
    cntb[ll[b].b]++;
    
    if(cnt1==cnt2)return 1;
    return 0; 
}
signed main() {
    //freopen("i", "r", stdin);
    scanf("%s",A+1);
    scanf("%s",B+1);
    int n=strlen(A+1),num=0;
    for(int i=1;i<=26;i++)
        for(int j=1;j<=26;j++){
            link[i][j]=++num;
            ll[num].a=i;
            ll[num].b=j;
        }
    for(int i=1;i<=n;i++){
        cnta[A[i]-'a'+1]++;
        cntb[B[i]-'a'+1]++;
        cnt[link[A[i]-'a'+1][B[i]-'a'+1]]++;
    }
    for(int i=1;i<=num;i++){
        if(!cnt[i])continue;
        for(int j=i+1;j<=num;j++){
            if(!cnt[j])continue;
            if(check(i,j)){
                ans+=1LL*cnt[i]*cnt[j]%mod;
            }
        }
    }
    for(int i=1;i<=num;i++){
        if(cnt[i]<2)continue;
        if(check(i,i))ans+=1LL*cnt[i]*(cnt[i]-1)/2%mod;
    }
    printf("%lld\n",ans%mod);
    //cin.tie(0)->sync_with_stdio(0);
    //odn(1,2);
    return 0;
}