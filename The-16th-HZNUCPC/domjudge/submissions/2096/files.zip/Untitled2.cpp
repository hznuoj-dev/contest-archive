#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::synbc_with_stdio(flase);cin.tie(0);cout.tie(0)
signed main()
{
	int n,m;
	cin>>n>>m;
	if(n==1||m==1)cout<<"YES"<<endl;
	else{
		int p=n%m;
		if(p==0){
			cout<<"NO"<<endl;
		}
		else{
			if(m%p==0)cout<<"NO"<<endl;
			else cout<<"YES"<<endl;
		}
	}
	return 0;
}