#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e5+10;
pair<int,int>a[N],b[N];
int dx[4]={0,1,0,-1};
int dy[4]={1,0,-1,0};

bool check(int x,int y)
{
	if(x>=1&&x<=19&&y>=1&&y<=19)return true;
	return false;
}
signed main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		map<pair<int,int>,bool>p;
		int cnt=0;
		int tot=0;
		for(int i=1;i<=n;i++)
		{
			int x,y,z;
			cin>>x>>y>>z;
			if(z==1)a[++cnt]={x,y};
			else b[++tot]={x,y};
			p[{x,y}]=1;
		}
		int ans=0;
		for(int i=1;i<=cnt;i++)
		{
			for(int j=0;j<4;j++)
			{
				int x=a[i].first+dx[j];
				int y=a[i].second+dy[j];
				if(!p[{x,y}]&&check(x,y))
				{
					ans++;	//cout<<x<<" "<<y<<endl;
				}
			
			}
		}	
		cout<<ans<<endl;
	}
	
}