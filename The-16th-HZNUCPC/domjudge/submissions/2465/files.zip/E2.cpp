#include<bits/stdc++.h>
using namespace std;
#define int long long
int x[105],y[105],l=0;
struct node{
	int x,y;
};
int count(int x1,int y1,int x2,int y2) {
	int ax=max(abs(x1-x2),abs(y1-y2));
	int in=min(abs(x1-x2),abs(y1-y2));
	if(in==0) return ax+1;
	if(ax%in==0&&in!=1) return in+1;
	return 2;
}
signed main() {
	//cout<<count(0,0,6,2)<<endl;
	int n;
	cin>>n;
	map<node,int> v;
	for(int i=0; i<n; i++) {
		int a,b;
		cin>>a>>b;
		if(!v[{a,b}]){
			x[l]=a;x[l++]=b;
			v[{a,b}]=1;
		}
	}
	int ans=0;
	if(l<2) {
		cout<<0<<endl;return 0;
	}
	for(int i=0; i<l; i++) {
		for(int j=0; j<l; j++) {
			for(int k=0; k<l; k++) {
				if(i==j||i==k||j==k) continue;
				if((x[i]==x[j]&&x[j]==x[k])||(y[i]==y[j]&&y[j]==y[k])) continue;
				int k1=(y[i]-y[j])*(x[i]-x[k]),k2=(y[i]-y[k])*(x[i]-x[j]);
				if(k1==k2 && (((x[j]-x[k]) ==0) && ((x[i]-x[j])==0)) || ((y[i]-y[j])==0) && ((y[j]-y[k])==0)) continue;
				int sum=count(x[i],y[i],x[j],y[j])+count(x[i],y[i],x[k],y[k])+count(x[k],y[k],x[j],y[j])-3;
				ans=max(ans,sum);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
