#include <bits/stdc++.h>
using namespace std;

const int N = 2e5 + 10;

int n, q, m;
int p[N];
int siz[N];
int c[N];
int g[N];
int re;
bool f = true;
int find(int x)
{
    if(x == p[x]) return x;
    return p[x] = find(p[x]);
}

void get(int op, int a, int b){
    if(op == 0)
    {
        int x = find(a);
        int y = find(b);
        if(x != y){
        p[x] = y;
        siz[y] += siz[x];
        }
        x = find(a + n);
        y = find(b + n);
         if(x != y){
        p[x] = y;
        siz[y] += siz[x];
        }
    }
    else{
         int x = find(a + n);
        int y = find(b);
        if(x != y){
        p[x] = y;
        siz[y] += siz[x];
        }
        x = find(a);
        y = find(b + n);
         if(x != y){
        p[x] = y;
        siz[y] += siz[x];
        }
    }
}

int dp[N];
int pre[N];
int ff[N];
int main(){

    scanf("%d%d%d", &n, &q, &m);
    for (int i = 1; i <= n + n; i ++) p[i] = i;
    for (int i = 1; i <= n; i ++) siz[i] = 1;

    while(m --)
    {
        int op, a, b;
        scanf("%d%d%d", &op, &a, &b);
        get(op, a, b);
    }
    for (int i = 1; i <= n; i ++)
    {
        if(find(i) == find(i + n))
        {
            f = false;
        }
    }
    if(f == false)
    {
        puts("NO");
    }
    else{

        vector<pair<int,int>>pos;
        for (int i = 1; i <= n; i ++){
            {
                if(find(i) != i) continue;
                if(c[siz[i]] == 0)
                {
                    g[++re] = siz[i];
                }
                c[siz[i]]++;
            }
        }

        for (int i = 1; i <= re; i ++)
        {
            int num = c[g[i]];
            int val = g[i];
            int tmp = 1;
            while(tmp <= num)
            {
         //      cout << tmp <<" " << num <<" "<<val * tmp <<" " << val <<'\n';
                pos.push_back({val * tmp, val});
                num -= tmp;
                tmp *= 2;
            }
            if(num)
            {
                pos.push_back({val * num, val});
            }
        }
        dp[0] = 1;
        for (int i = pos.size() - 1; i >= 0; i --)
        {
         //   cout << pos[i].first <<" " << pos[i].second << '\n';
            for (int j = q; j >= pos[i].first; j --)
            {
                if(!dp[j - pos[i].first]) continue;
                pre[j] = i;
                dp[j] |= dp[j - pos[i].first];
            }
        }

        if(!dp[q])
        {
            puts("NO");

        }
        else{
             int qq = q;
            vector<int>ret;
            while(qq)
            {
                int tt = pre[qq];
                ff[pos[tt].second] += pos[tt].first;
                qq -= pos[tt].first;
            }
          //  cout <<"!"<< " "<< qq << '\n';
            for (int i = 1; i <= n; i ++)
            {


         //       cout << i <<" " << find(i) <<"  " << ff[siz[find(i)]] << '\n';
                if(ff[siz[find(i)]] >= 1)
                {
                    ff[siz[find(i)]]--;
                    ret.push_back(i);

                }
            }
            puts("YES");
            for (int i = 0; i < ret.size(); i ++)
            {

                printf("%d%c", ret[i], " \n"[i == ret.size() - 1]);
            }
        }

    }
}
