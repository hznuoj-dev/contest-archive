#include <bits/stdc++.h>
using namespace std;

int g(int j , int k)
{
	
	int t = j%k;
	if(t == 1) return 1;
	if(t == 0) return 0;
	return g(j,t) ;
}
int main(){
	long n,m;
	cin>>n>>m;
	if(m == 1)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	if(g(n,m))
	{
		cout<<"YES"<<endl;
	}else
	{
		cout<<"NO"<<endl;
	}
	return 0;
}