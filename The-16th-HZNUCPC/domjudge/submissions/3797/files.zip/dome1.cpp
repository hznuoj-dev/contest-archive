#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod =1e9+7; 
const char c[26]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cout<<"hello hahahah!"<<endl;
    return 0;
}