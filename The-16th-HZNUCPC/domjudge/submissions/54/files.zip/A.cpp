#include <bits/stdc++.h>

#define dbg(x...) \
    do { \
        std::cout << #x << " -> "; \
        err(x); \
    } while (0)

void err() {
    std::cout << std::endl;
}

template<class T, class... Ts>
void err(T arg, Ts &... args) {
    std::cout << arg << ' ';
    err(args...);
}

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using i128 = __int128;

void run(int tCase) {
    int n;
    std::cin >> n;
    std::vector<std::vector<int>> a(19, std::vector(19, 0));
    std::vector<std::pair<int, int>> ps(n);
    for (auto &[x, y]: ps) {
        int c;
        std::cin >> x >> y >> c;
        x--, y--;
        a[x][y] = c;
    }
    int dx[4] = {0, 0, 1, -1};
    int dy[4] = {1, -1, 0, 0};
    auto valid = [&](int i, int j) {
        if (i < 0 or i > 18) return false;
        if (j < 0 or j > 18) return false;
        return true;
    };
    int ans = 0;
    for (auto [x, y]: ps) {
        for (int i = 0; i < 4; ++i) {
            int fx = x + dx[i];
            int fy = y + dy[i];
            if (valid(fx, fy) and a[x][y] != a[fx][fy]) ans++;
        }
    }
    std::cout << ans << '\n';
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int T = 1;
    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        run(t);
    }
    return 0;
}