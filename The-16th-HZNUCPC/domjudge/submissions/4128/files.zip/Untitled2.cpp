#include<bits/stdc++.h>
using namespace std;
#define rep(i,l,r) for(int i=(l);i<=(r);i++)
#define int long long
#define endl '\n'
const int N=50100;
int T;
char ch[N];
signed main(){
	cin>>T;
	while(T--){
		cin>>(ch+1);
		int len=strlen(ch+1);
		int ans=0;
		string s="@#";
		rep(i,1,len)s+=ch[i],s+="#";
		len=s.size()-1;
		rep(i,1,len){
			int ll=1;int cc=0;
			char ca,cb;
			while(i-ll>0&&i+ll<=len){
				if(s[i-ll]!=s[i+ll]){
					if(cc==2)break;
					else if(cc==1){
						char mn=min(s[i-ll],s[i+ll]),mx=max(s[i-ll],s[i+ll]);
						if(mn!=ca||mx!=cb)break;
						cc++;
					}
					else if(cc==0){
						ca=min(s[i-ll],s[i+ll]),cb=max(s[i-ll],s[i+ll]);
						cc++;ans=max(ans,ll-1);
					}
				}
				ll++;
			}
			if(cc==1)continue;
			ans=max(ans,ll-1);
		}
		if(ans<2)cout<<0<<endl;
		else cout<<ans<<endl;
	}
	return 0;
}