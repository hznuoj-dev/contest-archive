#include<bits/stdc++.h>
#define endl '\n'
typedef long long ll;
using namespace std;
const int N =1e2+10;

ll x[N],y[N];
ll check(ll x1,ll y1,ll x2,ll y2)
{
	if(x1==x2)
	return max(y1,y2)-min(y1,y2)+1;
	if(y1==y2)
	return max(x1,x2)-min(x1,x2)+1; 
	ll ky=abs(y1-y2);
	ll kx=abs(x1-x2);
	kx/=__gcd(kx,ky);
	ll num=max(x1,x2)-min(x1,x2);
	return num/kx+(num%kx==0);
}
int check1(ll x1,ll y1,ll x2,ll y2,ll x3,ll y3)
{
	if(x1==x2&&x2==x3)
	return 1;
	if(y1==y2&&y2==y3)
	return 1;
	if((y2-y1)*(x3-x1)==(y3-y1)*(x2-x1))
	return 1;
	
	return 0; 
}
void solve() {
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>x[i]>>y[i];
	ll ans=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				ll temp=0;
				if(check1(x[i],y[i],x[j],y[j],x[k],y[k]))
				continue;
//				cout<<i<<' '<<j<<" "<<k<<'\n';
				temp+=check(x[i],y[i],x[j],y[j]);
				temp+=check(x[k],y[k],x[j],y[j]);
				temp+=check(x[i],y[i],x[k],y[k]);
				ans=max(ans,temp-3);
			}
		}
	}
	cout<<ans<<'\n';
}

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int _t = 1;
//	cin >> _t;
	while(_t--) {
		solve() ;
	}
}