#include<bits/stdc++.h>
using namespace std;
struct stone{
	int x,y,type;
};
void solve(){
	int n,ans=0;
	cin>>n;
	set<pair<int,int> >s;
	vector<stone> a(n);
	for(int i=0;i<n;i++){
		cin>>a[i].x>>a[i].y>>a[i].type;
		s.insert({a[i].x,a[i].y});
	}
	for(int i=0;i<n;i++){
		if(a[i].type==1){   
			if(a[i].x>1)
				if(s.find({a[i].x-1,a[i].y})==s.end())ans++;
			if(a[i].x<19)
				if(s.find({a[i].x+1,a[i].y})==s.end())ans++;
			if(a[i].y>1)
				if(s.find({a[i].x,a[i].y-1})==s.end())ans++;
			if(a[i].y<19)
				if(s.find({a[i].x,a[i].y+1})==s.end())ans++;
		}
	}
	cout<<ans<<'\n';
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int t;
	cin>>t;
	while(t--)
		solve();
}