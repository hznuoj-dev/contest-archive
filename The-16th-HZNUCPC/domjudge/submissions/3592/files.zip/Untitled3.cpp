#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::synbc_with_stdio(flase);cin.tie(0);cout.tie(0)
const int N=2e5+5;
pair<int,int> s[N];
bool ch(pair<int,int> q,pair<int,int> p,pair<int,int> t){
	int a=q.first;
	int b=q.second;
	int x=p.first;
	int y=p.second;
	int f=t.first;
	int g=t.second;
	double aa=sqrt((x-a)*(x-a)+(y-b)*(y-b));
	double bb=sqrt((x-f)*(x-f)+(y-g)*(y-g));
	double cc=sqrt((a-f)*(a-f)+(b-g)*(b-g));
	if(aa+bb>cc&&aa+cc>bb&&bb+cc>aa){
		return true;
	}
	else{
		return false;
	}
}
int check(pair<int,int> q,pair<int,int> p,pair<int,int> t){
	int ans1=0;
	int a=q.first;
	int b=q.second;
	int x=p.first;
	int y=p.second;
	int f=t.first;
	int g=t.second;
//	cout<<a<<" "<<b<<" "<<x<<" "<<y<<" "<<f<<" "<<g<<endl;
//	if(a==1&&b==1&&x==3&&y==3&&f==2&&g==4){
		if(abs(a-x)%abs(b-y)==0||abs(b-y)%abs(a-x)==0){
			int minn=min(abs(a-x),abs(b-y));
			ans1+=minn-1;
//			cout<<minn<<endl;
		}
		
		if(abs(f-x)%abs(g-y)==0||abs(g-y)%abs(f-x)==0){
			int minn=min(abs(f-x),abs(g-y));
			ans1+=minn-1;
//			cout<<minn<<endl;
		}
		if(abs(a-f)%abs(b-g)==0||abs(b-g)%abs(a-f)==0){
			int minn=min(abs(a-f),abs(b-g));
			ans1+=minn-1;
//			cout<<minn<<endl;
		}	
//	}
	
	return ans1+3;
}
void solve(){
	int n;cin>>n;
	for(int i=0;i<n;i++){
		cin>>s[i].first;
		cin>>s[i].second;
	}
	int maxn=0;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			for(int k=j+1;k<n;k++){
//				if()
				if(ch(s[i],s[j],s[k])){
//					cout<<"===="<<endl;
//					cout<<s[i].first<<" "<<s[i].second<<endl;
//					cout<<s[j].first<<" "<<s[j].second<<endl;
//					cout<<s[k].first<<" "<<s[k].second<<endl;
//					cout<<check(s[i],s[j],s[k])<<endl;
//					cout<<endl;
					maxn=max(maxn,check(s[i],s[j],s[k]));
				}
			}
		}
	}
	cout<<maxn<<endl;
}
signed main(){
//	IOS;
	solve();
	return 0;
}