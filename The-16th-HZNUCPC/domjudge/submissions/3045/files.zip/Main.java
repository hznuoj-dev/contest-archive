import java.util.ArrayList;
import java.util.Scanner;
class pos
{
	double x;
	double y;
	pos(double x,double y)
	{
		this.x=x;
		this.y=y;
	}
}
public class Main {
	public static long cnt=0;
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n =sc.nextInt();
		pos [] shu = new pos[n];
		for(int x=0;x<n;x++)
			shu[x]=new pos(sc.nextInt(),sc.nextInt());
		long ans=0;
		for(int x=0;x<n;x++)
			for(int y=x+1;y<n;y++)
				for(int z=y+1;z<n;z++)
					if(can(shu[x],shu[y],shu[z]))
					{
						cnt=3;
						pos a = shu[x];
						pos b = shu[y];
						pos c = shu[z];	
						cnt+=add(a,b);
						cnt+=add(c,b);
						cnt+=add(a,c);
						ans=Math.max(ans, cnt);
					}
		System.out.println(ans);
	}
	public static boolean can (pos a ,pos b ,pos c)
	{
		if(a.x-b.x==b.x-c.x && a.x-b.x==0) return false;
		double k1 = (a.y-b.y)/(a.x-b.x);
		double k2 = (a.y-c.y)/(a.x-c.x);
		if(k1 == k2) return false ;
		return true;
	}
	public static int  add (pos a ,pos b)
	{
		if(a.x-b.x==0) return (int)Math.abs((a.y-b.y))-1;
		if(a.y-b.y==0) return (int)Math.abs((a.x-b.x))-1;
		int gys=gys(Math.abs(a.x-b.x),Math.abs(a.y-b.y));
		double x1=Math.abs(a.x-b.x)/gys;
		double y1=Math.abs(a.y-b.y)/gys;
		return (int) Math.min(Math.abs(a.x-b.x)/x1,Math.abs(a.y-b.y)/y1)-1;
	}
	private static int gys(double d, double e) {
		// TODO Auto-generated method stub
		int a=(int)d;
		int b=(int)e;
		int c=a%b;
		while(c!=0){
			a=b;
			b=c;
			c=a%b;
		}
		return b;
	}
}