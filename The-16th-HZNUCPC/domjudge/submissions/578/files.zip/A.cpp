#include<bits/stdc++.h>
#define endl '\n'
typedef long long ll;
using namespace std;
const int N =1e2+10;

ll n, m;
int v[N][N];
void solve() {
	cin >> n;
	int r = 19, c = 19;
	for(int i=0; i<=r+1; i++) {
		for(int j=0; j<=c+1; j++) {
			v[i][j] = 0;
		}
	}
	while(n--) {
		int x, y, z;
		cin >> x >> y >> z;
		v[x][y] = z;
	}
	int ans = 0;
	for(int i=1; i<=r; i++) {
		for(int j=1; j<=c; j++) {
			if(v[i][j]==1) {
				if(!v[i-1][j]&&i-1>0) v[i-1][j] = 2, ans ++;
				if(!v[i][j-1]&&j-1>0) v[i][j-1] = 2, ans ++;
				if(!v[i+1][j]&&i+1<20) v[i+1][j] = 2, ans ++;
				if(!v[i][j+1]&&j+1<20) v[i][j+1] = 2, ans ++;
			}
		}
	}
	cout << ans << endl;
	
}

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int _t = 1;
	cin >> _t;
	while(_t--) {
		solve() ;
	}
}