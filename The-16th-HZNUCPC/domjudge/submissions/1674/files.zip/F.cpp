#include<bits/stdc++.h>
using namespace std;
#define int long long 
int n,m,k;
pair<int,int>s[2005];
int dir[4][2]={1,0,0,1,-1,0,0,-1};
int check(int x){
	if(x==0||x==1){
		return 0;
	}
	for(int i=2;i<sqrt(x);i++){
		if(x%i==0){
			return 0;
		}
	}
	return 1;
}
void solve(){
	while(cin>>n>>m){
		int f=0;
		if(m==1||n==1){
			cout<<"YES"<<endl;
			continue;
		}
		if(m-n==1){
			cout<<"YES"<<endl;
			continue;
		} 
		if(n<=m){
			cout<<"NO"<<endl;
			continue;
		}
		if(check(n)){
			cout<<"YES"<<endl;
			continue;
		}
		while(1){
			if(m==1){
				f=1;
				break;
			}
			if(n%m==0){
				break;
			}
			m-=n%m;
		}
		if(f==1){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
	}
}
signed main(){
	solve();
	return 0;
}