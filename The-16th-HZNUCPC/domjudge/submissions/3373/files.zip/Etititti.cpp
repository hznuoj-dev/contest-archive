#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define me(a,b) memeset(a,b,sizeof a);
struct node {
	int x;
	int y;
	double k;
} s[150];
int i,j,k,numx1,numy1,numx2,numy2,numx3,numy3,sum;
int gys(int x,int y){
	int num=max(x,y);
	for(int i=2;i<=sqrt(num);i++){
		if(x%i==0&&y%i==0) return i;
	}
	return 1;
}
signed main() {
	IOS
	int n;
	while(cin>>n) {
		for(i=0; i<n; i++) {
			cin>>s[i].x>>s[i].y;
			s[i].x+=1e9+5;
			s[i].y+=1e9+5;
			s[i].k=s[i].x-s[i].y;
		}
		int max1=0;
		for(i=0;i<n;i++){
			for(j=i+1;j<n;j++){
				for(k=j+1;k<n;k++){
					if(s[i].k!=s[j].k||s[i].k!=s[k].k||s[j].k!=s[k].k){
						numx1=abs(s[i].x-s[j].x);
						numy1=abs(s[i].y-s[j].y);
						numx2=abs(s[i].x-s[k].x);
						numy2=abs(s[i].y-s[k].y);
						numx3=abs(s[j].x-s[k].x);
						numy3=abs(s[j].y-s[k].y);
						sum=0;
						sum+=numx1/gys(numx1,numy1);
						sum+=numx2/gys(numx2,numy2);
						sum+=numx3/gys(numx3,numy3);
						max1=max(sum,max1);
					}else continue; 					
				}
			}
		}
		cout<<max1<<endl; 
	}
	return 0;
}