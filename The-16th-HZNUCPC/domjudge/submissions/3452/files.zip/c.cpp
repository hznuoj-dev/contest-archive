#include <bits/stdc++.h>
using namespace std;

typedef long long LL;

typedef pair<LL, LL> pii;

vector<pii> pt;
struct node {
    pii a;
    pii b;
    pii c;
};
int n;
LL a, b;
vector<node> e;

double getedge(pii a, pii b) {
    double t1 = 1.0 * (a.first - b.first);
    double t2 = 1.0 * (a.second - b.second);
    double ans = sqrt((t1 * t1) + (t2 * t2));
    return ans;
}

LL f (pii x, pii  y) {
    LL fz, fm, gc;
    //x, y
    fm = fabs(x.first - y.first);
    fz = fabs(x.second - y.second);
    if(fm == 0) return max(0LL, fz - 1);
    if(fz == 0) return max(0LL, fm - 1);
    gc = __gcd(fz, fm);

    fm = fm / gc;
    fz = fz / gc;
    if(gc == 1) return 0;
    LL yy = fabs(x.first - y.first);
    return max(0LL, yy / fm - 1);
}
int main() {

    cin >> n;
    for(int i = 1; i <= n; i ++) {
        cin >> a >> b;
        pt.push_back({a, b});
    }
    for(int i = 0; i < n; i++) {
        for(int j = i + 1; j < n; j++) {
            for(int k = j + 1; k < n; k++) {
                double x = getedge(pt[i], pt[j]);
                double y = getedge(pt[i], pt[k]);
                double z = getedge(pt[j], pt[k]);
                if(x > 0 && y > 0 && z > 0 && x + y > z && x + z > y && z + y > x) {
                    e.push_back({pt[i], pt[j], pt[k]});
                }
            }
        }
    }

    LL ans = 0;
    for(int i = 0; i < (int)e.size(); i++) {
        pii x = e[i].a;
        pii y = e[i].b;
        pii z = e[i].c;
        LL tt = 0;
        tt += f(x, y);
        tt += f(x, z);
        tt += f(y, z);
        tt += 3;
        if(ans < tt) ans = tt;
    }
    cout << ans << endl;
}
