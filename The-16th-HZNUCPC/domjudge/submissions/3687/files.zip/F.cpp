#include <bits/stdc++.h>
#define ll long long

using namespace std;

int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}

int main(){
	int n,m;
	
	
	cin>>n>>m;
	if(gcd(n,m)==1)cout<<"YES";
	else cout<<"NO";
}