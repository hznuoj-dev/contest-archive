#include<bits/stdc++.h>
using namespace std;
int a[400][400],x[400],y[400],c[400];
int jisuan(int i,int j)
{
	int ans=0;
	if(i-1>0&&!a[i-1][j])
		ans++;
	if(i+1<=19&&!a[i+1][j])
		ans++;
	if(j-1>0&&!a[i][j-1])
		ans++;
	if(j+1<=19&!a[i][j+1])
		ans++;
	return ans;
}
int main()
{
	int t;
	cin>>t;
	while(t--){
		int n;
		long long ans=0;
		cin>>n;
		for(int i=0;i<n;i++){
			cin>>x[i]>>y[i]>>c[i];
			a[x[i]][y[i]]=1;
		}
		for(int i=0;i<n;i++){
			if(c[i]==1){
				ans+=jisuan(x[i],y[i]);
			}
		}
		cout<<ans<<endl;
	}
}