package oj;

import java.io.*;
import java.lang.reflect.Array;
import java.util.Arrays;

public class Main {
	static StreamTokenizer st=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
	static BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
	static int map[][];
	static int dx[]={1,-1,0,0};
	static int dy[]={0,0,1,-1};
	static int ans;
	public static void main(String[] args) throws IOException {
		int T=nextInt();
		for(int i=0;i<T;i++){
			int n=nextInt();
			map=new int[19][19];
			ans=0;
			for(int j=0;j<n;j++){
				int x=nextInt();
				int y=nextInt();
				int c=nextInt();
				map[x][y]=c;
			}
//			for(int j[]:map){
//				System.out.println(Arrays.toString(j));
//			}
			for(int j=0;j<19;j++){
				for(int k=0;k<19;k++){
					if(map[j][k]==1){
						dfs(j,k);
					}
				}
			}
			System.out.println(ans);
		}
		
	}
	
	private static void dfs(int x,int y){
		if(x+1>=0&&x+1<19&&y>=0&&y<19&&map[x+1][y]==0){
			map[x+1][y]=5;
			ans++;
		}
		if(x-1>=0&&x-1<19&&y>=0&&y<19&&map[x-1][y]==0){
			map[x-1][y]=5;
			ans++;
		}
		if(x>=0&&x<19&&y-1>=0&&y-1<19&&map[x][y-1]==0){
			map[x][y-1]=5;
			ans++;
		}
		if(x>=0&&x<19&&y+1>=0&&y+1<19&&map[x][y+1]==0){
			map[x][y+1]=5;
			ans++;
		}
	}
private static int nextInt() throws IOException{
		st.nextToken();
		return (int)st.nval;
	}
	private static String next() throws IOException{
		st.nextToken();
		return st.sval;
	}
}
