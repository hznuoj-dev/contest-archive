#include<iostream>
#include<math.h>
using namespace std;
long long zui(long long b,long long c)
{
	long long k,i=2;
	for(i=2;i<=sqrt(b);i++)
	{
		if(b%i==0)
		k=i;
		break;
	}
	if(c<k)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
long long ss(long long a)
{
	long long i=2;
	for(i=2;i<=sqrt(a)+1;i++)
	{
		if(a%i==0)
		 return 0;
	}
	return 1;
}
int main()
{
	long long n,m;
	cin>>n>>m;
	if(n==1 || m==1)
	{
		cout<<"YES"<<endl;
	}
	else
	{
		if((ss(n) && n>m) || (m==2 && n%2==1 && n>m)||(zui(n,m)==1))
		{
			cout<<"YES"<<endl;
		}
		else
		{
			cout<<"NO"<<endl;
		}	
	}
	
	return 0;
}