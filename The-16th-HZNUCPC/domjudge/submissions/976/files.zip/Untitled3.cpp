#include<iostream>

using namespace std;
int dx[5]={0,0,0,1,-1},dy[5]={0,1,-1,0,0};
int main(){
	int t;
	scanf("%d",&t);
	
	while(t --)
	{
		int a[21][21];
		for(int i = 1;i <= 20;i ++ ){
			for(int j = 1;j <= 20;j ++){
				a[i][j] = 0;
			}
		} 
		int n;
		scanf("%d",&n);
		for(int i = 1;i <= n;i ++){
			int x,y,z;
			scanf("%d%d%d",&x,&y,&z);
			a[x][y] = z;
		}
		int ans=0;
		for(int i = 1;i <= 19;i ++){
			for(int j = 1;j <= 19;j ++){
				if(a[i][j] == 1){
					for(int k=1;k<=4;k++){
						int x=dx[k]+i,y=dy[k]+j;
						if(x<1||x>19||y<1||y>19)continue;
						if(a[x][y]==0&&a[x][y]!=2&&a[x][y]!=1){
							ans++;
						}
					}
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}