#include "bits/stdc++.h"
using namespace std;
const int N =25;
int a[N][N],t,n;
int main(){
	while(cin >> t){
		while(t --){
			cin >> n;
			memset(a, 0, sizeof(a));
			for(int i = 0;i < n;i ++){
				int x,y,c;
				cin >> x >> y >> c;
				a[x][y] = c;
			}
			long long cnt = 0;
			for(int i = 1; i < 20; i ++){
				for(int j = 1; j < 20; j ++){
					if(a[i][j] == 1){
						if(j - 1 > 0 && a[i][j - 1] == 0){
							cnt ++;
						}
						if(j + 1 < 20 && a[i][j + 1] == 0){
							cnt ++;
						}
						if(i - 1 > 0 && a[i - 1][j] == 0){
							cnt ++;
						}
						if(i + 1 < 20 && a[i + 1][j] == 0){
							cnt ++;
						}
					}
				}
			}
			cout << cnt << endl;
		}
	}
	return 0;
}
