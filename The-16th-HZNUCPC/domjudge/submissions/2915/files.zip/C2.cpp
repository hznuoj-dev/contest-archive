#include <bits/stdc++.h>

using namespace std;
using LL = long long;

constexpr int N = 1e5 + 7;
const LL mod = 1e9+7;

LL sw[30][30];

signed main()
{
	string a, b;
	cin >> a >> b;
	
	vector<int> ca(26, 0), cb(26, 0);
	
	for (auto x : a) ca[x - 'a'] ++ ;
	for (auto x : b) cb[x - 'a'] ++ ;
	int suma=0,sumb=0;
	
	for(int i=0;i<26;i++)if(ca[i])suma++;
	for(int i=0;i<26;i++)if(cb[i])sumb++;
	
	int size = a.size();
	for(int i=0;i<size;i++)
	{
		int x = a[i]-'a';
		int y = b[i]-'a';
		sw[x][y]++;
	}
			
	
	LL ans = 0;
	for(int i=0;i<26*26;i++)
	{
		for(int j=i;j<26*26;j++)
		{
			int x1=i/26,y1=i%26;
			int x2=j/26,y2=j%26;
			if(sw[x1][y1]==0 || sw[x2][y2]==0)continue;
			
			int sum_a=0,sum_b=0;
			if(i!=j)
			{
				ca[x1]--,ca[x2]--,ca[y1]++,ca[y2]++;
				cb[x1]++,cb[x2]++,cb[y1]--,cb[y2]--;
				for(int k=0;k<26;k++)if(ca[k])sum_a++;
				for(int k=0;k<26;k++)if(cb[k])sum_b++;
				ca[x1]++,ca[x2]++,ca[y1]--,ca[y2]--;
				cb[x1]--,cb[x2]--,cb[y1]++,cb[y2]++;
				
				if(sum_a == sum_b)ans = (sw[x1][y1]*sw[x2][y2]%mod + ans)%mod;
			}else if(i==j)
			{
				if(sw[x1][y1]<2)continue;
				
				ca[x1]--,ca[x2]--,ca[y1]++,ca[y2]++;
				cb[x1]++,cb[x2]++,cb[y1]--,cb[y2]--;
				for(int k=0;k<26;k++)if(ca[k])sum_a++;
				for(int k=0;k<26;k++)if(cb[k])sum_b++;
				ca[x1]++,ca[x2]++,ca[y1]--,ca[y2]--;
				cb[x1]--,cb[x2]--,cb[y1]++,cb[y2]++;
				
				if(sum_a == sum_b)ans = (sw[x1][y1]*(sw[x2][y2]-1)/2%mod + ans)%mod;
			}
			
		}
	}
	
	cout<<ans<<endl;
	
}