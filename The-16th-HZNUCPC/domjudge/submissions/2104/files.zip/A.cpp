#include<bits/stdc++.h>
using namespace std;

struct stone{
	bool black,white,puts;
};
stone s[20][20];



int main(){
	int n,m,x,y,z,sum;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&m);
		sum=0;
		for(int j=1;j<=m;j++){
			scanf("%d%d%d",&x,&y,&z);
			if(z==1){
				s[x][y].black=true;
			}
			else {
				s[x][y].white=true;
			}
		}
		for(x=1;x<=19;x++){
			for(y=1;y<=19;y++){
				if(s[x][y].black){
					if(x==1){
						if(y==1){
							if(s[x][y+1].black==false&&s[x][y+1].white==false&&s[x][y+1].puts==false){
								sum++;
								
							}
							if(s[x+1][y].black==false&&s[x+1][y].white==false&&s[x+1][y].puts==false){
								sum++;
								
							}
						}
						else if(y==19){
							if(s[x][y-1].black==false&&s[x][y-1].white==false&&s[x][y-1].puts==false){
								sum++;
							
							}
							if(s[x+1][y].black==false&&s[x+1][y].white==false&&s[x+1][y].puts==false){
								sum++;
							
							}
						}
						else{
							if(s[x][y-1].black==false&&s[x][y-1].white==false&&s[x][y-1].puts==false){
								sum++;
								
							}
							if(s[x+1][y].black==false&&s[x+1][y].white==false&&s[x+1][y].puts==false){
								sum++;
							
							}
							if(s[x][y+1].black==false&&s[x][y+1].white==false&&s[x][y+1].puts==false){
								sum++;
							
							}
						}
					}
					else if(x==19){
						if(y==1){
							if(s[x][y+1].black==false&&s[x][y+1].white==false&&s[x][y+1].puts==false){
								sum++;
								
							}
							if(s[x-1][y].black==false&&s[x-1][y].white==false&&s[x-1][y].puts==false){
								sum++;
								
							}
						}
						else if(y==19){
							if(s[x][y-1].black==false&&s[x][y-1].white==false&&s[x][y-1].puts==false){
								sum++;
							
							}
							if(s[x-1][y].black==false&&s[x-1][y].white==false&&s[x-1][y].puts==false){
								sum++;
								
							}
						}
						else{
							if(s[x][y-1].black==false&&s[x][y-1].white==false&&s[x][y-1].puts==false){
								sum++;
								
							}
							if(s[x+1][y].black==false&&s[x+1][y].white==false&&s[x+1][y].puts==false){
								sum++;
								
							}
							if(s[x][y+1].black==false&&s[x][y+1].white==false&&s[x][y+1].puts==false){
								sum++;
								
							}
						}
					}
					else {//�ձ���� 
						if(y==1){
							if(s[x][y+1].black==false&&s[x][y+1].white==false&&s[x][y+1].puts==false){
								sum++;
							
							}
							if(s[x-1][y].black==false&&s[x-1][y].white==false&&s[x-1][y].puts==false){
								sum++;
							
							}
							if(s[x+1][y].black==false&&s[x+1][y].white==false&&s[x+1][y].puts==false){
								sum++;
							
							}
						}
						else if(y==19){
							if(s[x][y-1].black==false&&s[x][y-1].white==false&&s[x][y-1].puts==false){
								sum++;
								
							}
							if(s[x-1][y].black==false&&s[x-1][y].white==false&&s[x-1][y].puts==false){
								sum++;
							
							}
							if(s[x+1][y].black==false&&s[x+1][y].white==false&&s[x+1][y].puts==false){
								sum++;
							
							}
						}
						else{
							if(s[x][y-1].black==false&&s[x][y-1].white==false&&s[x][y-1].puts==false){
								sum++;
							
							}
							if(s[x+1][y].black==false&&s[x+1][y].white==false&&s[x+1][y].puts==false){
								sum++;
							
							}
							if(s[x][y+1].black==false&&s[x][y+1].white==false&&s[x][y+1].puts==false){
								sum++;
							
							}
							if(s[x-1][y].black==false&&s[x-1][y].white==false&&s[x-1][y].puts==false){
								sum++;
							
							}
						}
					}
				}
			}
		}
		printf("%d\n",sum);
		for(x=1;x<=19;x++){
			for(y=1;y<=19;y++){
				s[x][y].black=false;
				s[x][y].puts=false;
				s[x][y].white=false;
			}
		}
	}
}
