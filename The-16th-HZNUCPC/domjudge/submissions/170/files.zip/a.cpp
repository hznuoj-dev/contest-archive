#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define MOD 1000000007;
ll getc(ll n){
	ll res=n*(n-1)/2;
	return res;
}
void solve(){
	string a,b;
	cin>>a>>b;
	bool pd=false;
	ll same=0,diff=0;
	for(int i=0;i<a.size();i++){
		if(a[i]!=b[i]){
			pd=true;
			diff++;
		}else{
			same++;
		}
	}
	if(pd){
		ll res=same%MOD;
		res=res*(diff)%MOD;
		cout<<res;
	}else{
		ll res=getc(same);
		cout<<res;
	}
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	solve();
	return 0;
}