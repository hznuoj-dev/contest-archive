#include <bits/stdc++.h>
using namespace std;
#define ll long long
int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};
void solve(){
   ll n,m;
   cin>>n>>m;
   if(n==1)
   {
       cout<<"YES\n";
       return ;
   }
   ll s=0;
   ll k=sqrt(n);
   for(ll i=2;i<=k;i++)
   {
       if(n%i==0)
       {
           s=i;
           break;
       }
   }
   if(s==0) s=n;
//    cout<<s<<"\n";
   if(m>=s)
   {
       cout<<"NO\n";
   }
   else cout<<"YES\n";
    
}
int main(){
    int t=1;
    // ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    // scanf("%d",&t);
    t=1;
    while (t--)
    {
        solve();
    }
    return 0;
}