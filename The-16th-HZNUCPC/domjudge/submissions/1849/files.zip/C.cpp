#include<bits/stdc++.h>
#define int long long
#define rep(i,a,n) for(int i=a;i<n;i++)
#define per(i,a,n) for(int i=n-1;i>=a;i--)
#define fi first 
#define se second
#define pb push_back
#define endl '\n'
#define pii pair<int,int> 
#define vii vector<pair<int,int> >

using namespace std;
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
int g[22][22];
int dx[]={1,-1,0,0},dy[]={0,0,-1,1};
pii p[110];
pii get(pii a,pii b){
	if(a.fi==b.fi) return {0,1};
	if(a.se==b.se) return {1,0};
	int dx=a.fi-b.fi;
	int dy=a.se-b.se;
	if(dx*dy>0){
		int d=gcd(dx,dy);
		return {dx/d,dy/d};
	}else{
		int d=gcd(dx,dy);
		return {-dx/d,dy/d};
	}
}
int getn(pii a,pii b){
	if(a.fi==b.fi) return abs(a.se-b.se)-1;
	if(a.se==b.se) return abs(a.fi-b.fi)-1;
	int dx=abs(a.fi-b.fi),dy=abs(a.se-b.se);
	return gcd(dx,dy)-1;
}map<pii,int> mp;int cnt[26][2];
void solve(){
	string a,b;cin>>a>>b;
	int sz=a.size();
	rep(i,0,sz){
		cnt[a[i]-'a'][0]++;
		cnt[b[i]-'a'][1]++;
		pii p={a[i]-'a',b[i]-'a'};
		mp[p]++;
	}int ans=0;
	rep(i,0,26){
		rep(j,0,26){
			rep(k,0,26){
				rep(l,0,26){
					if(i==k&&j==l){
						int v=mp[{i,j}];
						int w=v*(v-1)/2;
						if(w<=0) continue;
						int cnta=0,cntb=0;
						cnt[i][0]--;cnt[k][0]--;
						cnt[j][0]++;cnt[l][0]++;
						cnt[j][1]--;cnt[l][1]--;
						cnt[i][1]++;cnt[k][1]++;
						rep(i,0,26) if(cnt[i][0]>0) cnta++;
						rep(i,0,26) if(cnt[i][1]>0) cntb++;
						if(cnta==cntb) ans+=w;
						cnt[i][0]++;cnt[k][0]++;
						cnt[j][0]--;cnt[l][0]--;
						cnt[j][1]++;cnt[l][1]++;
						cnt[i][1]--;cnt[k][1]--;
					}else{
						int w=mp[{i,j}]*mp[{k,l}];
						if(w<=0) continue;
						if(!i&&!j&&k==1&&!l){
							//cout<<"???"<<w<<endl;
						}
						int cnta=0,cntb=0;
						cnt[i][0]--;cnt[k][0]--;
						cnt[j][0]++;cnt[l][0]++;
						cnt[j][1]--;cnt[l][1]--;
						cnt[i][1]++;cnt[k][1]++;
						if(!i&&!j&&k==1&&!l){
							//cout<<"Sa"<<endl;
							rep(i,0,26){
								//cout<<cnt[i][0]<<" \n"[i==25];
							}
							rep(i,0,26){
								//cout<<cnt[i][1]<<" \n"[i==25];
							}
						}
						rep(i,0,26) if(cnt[i][0]>0) cnta++;
						rep(i,0,26) if(cnt[i][1]>0) cntb++;
						if(cnta==cntb) ans+=w/2;
						cnt[i][0]++;cnt[k][0]++;
						cnt[j][0]--;cnt[l][0]--;
						cnt[j][1]++;cnt[l][1]++;
						cnt[i][1]--;cnt[k][1]--;
					}
				}
			}
		}
	}cout<<ans<<endl;
}
signed main(){
	int t=1;//cin>>t;
	while(t--){
		solve();
	}
	return 0;
}