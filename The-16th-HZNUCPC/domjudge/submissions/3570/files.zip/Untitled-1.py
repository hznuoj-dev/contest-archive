import sys
input = lambda: sys.stdin.readline().strip()
sys.setrecursionlimit(60000)
def func():
    n,q,m = map(int,input().split())
    has = [[[],[]] for _ in range(n+1)]
    for _ in range(m):
        a = list(map(int,input().split()))
        if a[0] == 0:
            has[a[1]][0].append(a[2])
            has[a[2]][0].append(a[1])
        else:
            has[a[1]][1].append(a[2])
            has[a[2]][1].append(a[1])
    rep = [0]*(n+1)
    rep[1] = 1
    res = [1]
    while res:
        p = res.pop()
        if has[p][0]:
            for i in has[p][0]:
                if rep[i] == 0:
                    rep[i] = rep[p]
                    res.append(i)
                if rep[i] != rep[p]:return False
        if has[p][1]:
            for i in has[p][1]:
                if rep[i] == 0:
                    rep[i] = 3-rep[p]
                    res.append(i)
                if rep[i] == rep[p]:return False
    left = []
    right = []
    lin = []
    for i in range(1,n+1):
        if rep[i] == 0:
            lin.append(i)
        elif rep[i] == 1:
            left.append(i)
        else:
            right.append(i)
    if len(left) <= q and len(lin) >= q-len(left):
        for _ in range(q-len(left)):
            left.append(lin.pop())
        return left
    elif len(right) <= q and len(lin) >= q-len(right):
        for _ in range(q-len(right)):
            right.append(lin.pop())
        return right
    else:
        return False

res = func()
if res == False:
    print('NO')
else:
    print('YES')
    s = ''
    for i in res:
        s += str(i)+' '
    print(s)

