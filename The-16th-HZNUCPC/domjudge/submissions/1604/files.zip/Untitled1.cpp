#include <bits/stdc++.h>
using namespace std;
#define M 100005
#define ll long long
const int mod=1e9+7;
char A[M],B[M];
int Count[2][30];
int cnt[30][30];
int cntA,cntB;
ll check(int ai,int aj,int bi,int bj){
	if(ai==aj&&bi==bj&&cnt[ai][bi]<2)return 0;
	if(cnt[ai][bi]==0)return 0;
	if(cnt[aj][bj]==0)return 0;
	Count[0][ai]--;
	Count[0][aj]--;
	Count[0][bi]++;
	Count[0][bj]++;
	int newa=0;
	for(int i=0;i<26;i++)if(Count[0][i]>0)newa++;
	Count[1][ai]++;
	Count[1][aj]++;
	Count[1][bi]--;
	Count[1][bj]--;
	
	int newb=0;
	for(int i=0;i<26;i++)if(Count[1][i]>0)newb++;
	Count[0][ai]++;
	Count[0][aj]++;
	Count[0][bi]--;
	Count[0][bj]--;
	Count[1][ai]--;
	Count[1][aj]--;
	Count[1][bi]++;
	Count[1][bj]++;
	if(newa!=newb)return 0;
	else {
		if(ai==aj&&bi==bj)return 1ll*cnt[ai][bi]*(cnt[ai][bi]-1)/2;
		else return 1ll*cnt[ai][bi]*cnt[aj][bj];
	}
}
int main(){
	scanf("%s%s",A+1,B+1);
	int len=strlen(A+1);
	for(int i=1;i<=len;i++){
		if(Count[0][A[i]-'a']==0)cntA++;
		if(Count[1][B[i]-'a']==0)cntB++;
		Count[0][A[i]-'a']++;
		Count[1][B[i]-'a']++;
		cnt[A[i]-'a'][B[i]-'a']++;
	}
	ll ans=0;
	for(int ai=0;ai<26;ai++)
		for(int aj=ai;aj<26;aj++)
			for(int bi=0;bi<26;bi++)
				for(int bj=0;bj<26;bj++){
					if(ai==aj&&bi>bj)continue;
					ans=(ans+check(ai,aj,bi,bj)%mod)%mod;	
				}
	printf("%lld\n",ans);
	return 0;
}