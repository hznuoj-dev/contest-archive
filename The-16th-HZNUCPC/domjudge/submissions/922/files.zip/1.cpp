#include<bits/stdc++.h>
using namespace std;
#define int long long
#define aa first
#define bb second
pair<int, int> p[102];
int n;
int is_triangle(int i, int j, int k) {
    if ((p[j].bb - p[i].bb) * (p[k].aa - p[i].aa) == (p[k].bb - p[i].bb) * (p[j].aa - p[i].aa)) return 0;
    return 1;
}
int check(int p1, int p2) {
    int x = p[p1].aa - p[p2].aa;
    int y = p[p1].bb - p[p2].bb;
    return __gcd(abs(x), abs(y));
}
void solve(){
    int n;  cin>>n;
    for (int i = 1; i <= n; i ++ ) {
        cin >> p[i].aa >> p[i].bb;
    }
    int maxm = 0;
    for (int i = 1; i <= n; i ++ ) {
        for (int j = i + 1; j <= n; j ++ ) {
            for (int k = j + 1; k <= n; k ++) {
                if (is_triangle(i, j, k) == 0) continue;
                maxm = max(maxm, check(i,j) + check(i,k) + check(j,k));
            }
        }
    }
    cout << maxm << '\n';
}
signed main(){
    int T = 1;
    while(T--){
        solve();
    }
    return 0;
}


