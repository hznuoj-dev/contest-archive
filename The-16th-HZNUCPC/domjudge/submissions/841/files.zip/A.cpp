#include<bits/stdc++.h>
using namespace std;
#define N 25
typedef pair<int, int> pii;
int a[N][N];
int cnt[N][N];
int dx[4] = {0, 0, -1, 1};
int dy[4] = {-1, 1, 0, 0};
int ans = 0;
int idx = 0;
int n;

void init() {
	for (int i = 1; i <= 19; i++) {
		for (int j = 1; j <= 19; j++) {
			a[i][j] = 0;
			cnt[i][j] = 0;
		}
	}
	ans = 0;
	idx = 0;
}

void bfs(int i, int j) {
	queue<pii> q;
	q.push(pii{i, j});
	cnt[i][j] = ++idx;
	while (q.size()) {
		int x = q.front().first, y = q.front().second;
		q.pop();
		for (int i = 0; i < 4; i++) {
			int xx = x + dx[i], yy = y + dy[i];
			if (a[xx][yy] != 1) continue; // not black
			if (cnt[xx][yy] > 0) continue; // have been visited
			if (xx < 1 || xx > 19 || yy < 1 || yy > 19) continue; //invalid
			cnt[xx][yy] = idx;
			q.push(pii{xx, yy});
		}
	}
}

void solve() {
	init();
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		int x, y, c;
		scanf("%d%d%d", &x, &y, &c);
		a[x][y] = c;
		if (c == 2) {
			cnt[x][y] = -1;
		}
	}
	for (int i = 1; i <= 19; i++) {
		for (int j = 1; j <= 19; j++) {
			if (a[i][j] == 1) {
				bfs(i, j);
			}
		}
	}
	
	//debug
//	for (int i = 1; i <= 19; i++){
//		for (int j = 1; j <= 19; j++) {
//			cout << cnt[i][j] << " ";
//		}
//		cout << endl;
//	}
	
	for (int i = 1; i <= 19; i++) {
		for (int j = 1; j <= 19; j++) {
			if (a[i][j] == 0) {
				set<int> se;
				for (int k = 0; k < 4; k++) {
					int x = i + dx[k], y = j + dy[k];
					if (x < 1 || x > 19 || y < 1 || y > 19) continue; //invalid
					if (a[x][y] != 1) continue; //not black
					
					// debug
//					cout << "node: " << x << " " << y << endl;
					se.insert(cnt[x][y]);
				}
				ans += se.size();
			}
		}
	}
	printf("%d\n", ans);
}


int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		solve();
	}
	return 0;
}