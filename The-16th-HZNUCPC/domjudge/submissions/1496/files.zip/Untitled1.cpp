#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
typedef long long ll;
int main(){
ll n,m,f=0;
cin>>n>>m;
ll x=sqrt(n);
if(n==1||m==1){
	cout<<"YES"<<endl;
	return 0;
}
if(n<=m&&n>=2){
    cout<<"NO"<<endl;
	return 0;
}
for(ll i=2;i<=x;i++)
{
	if(n%i==0&&i<=m)
	{
		f=1;
		break;
	}
	if(i>m)
	break;
}
if(f) cout<<"NO"<<endl;
else cout<<"YES"<<endl;
return 0;
}