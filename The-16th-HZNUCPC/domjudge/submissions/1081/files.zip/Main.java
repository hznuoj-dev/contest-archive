import java.util.*;
import java.io.*;
import java.math.*;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		long n = in.nextLong();
		long m = in.nextLong();
		int cnt = 1;
		for(int i=2;i<=Math.sqrt(n);i++){
			if(n%i==0){
				cnt = i;
				break;
			}
		}
		if(cnt<=m&&cnt>1||n<=m){
			System.out.println("NO");
		}
		else{System.out.println("YES");}
		
	}
}
