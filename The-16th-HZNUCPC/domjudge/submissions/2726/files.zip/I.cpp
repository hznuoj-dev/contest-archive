#include<bits/stdc++.h>
using namespace std;
#define pb push_back
const int M=5e3+10;
int T,n;
bool f[M][M];
char a[M];
char v[M][M][2];
int main()
{
	scanf("%d",&T);
	while(T--){
		scanf("%s",a+1);
		n=strlen(a+1);
//		vector<vector<vector<char>>> v(n+1,vector<vector<char>>(n+1,vector<char>(4)));
		for(int i=1;i<=n;i++) f[i][i]=1,f[i][i-1]=1;
		for(int i=1;i<n;i++)
			if(a[i]==a[i+1]) f[i][i+1]=1;
		int ans=0;
		for(int len=3;len<=n;len++)
			for(int i=1;i+len-1<=n;i++)
			{
//				f[i][i+len-1]=f[i+1][i+len-2]&&a[i]==a[i+len-1];
				int j=i+len-1;
				if(f[i+1][j-1]&&a[i]==a[j]) f[i][j]=1;
//				printf("%d %d %d\n",i,j,f[i][j]);
				if(f[i][j]) ans=max(ans,j-i+1);
			}
			
		for(int len=2;len<=n;len++)
			for(int i=1;i+len-1<=n;i++)
			{
				int j=i+len-1;
				if(a[i]==a[j]) v[i][j][0]=v[i+1][j-1][0],v[i][j][1]=v[i+1][j-1][1];
				else if(f[i+1][j-1]||i+1>=j-1) v[i][j][0]=a[i],v[i][j][1]=a[j];
//				printf("%d %d:",i,j);
//				if(v[i][j].size()) printf("%c %c\n",v[i][j][0],v[i][j][1]);
//				else puts("");
			}
		for(int len=3;len<=n;len++)
			for(int i=1;i+len-1<=n;i++)
			{
				int j=i+len-1;
//				printf("%d %d\n",i+1,j-1);
				if(i+1==j-1)
				{
					if(a[i+1]==a[i]||a[i+1]==a[j]) ans=max(ans,3);
					continue;
				}
				if(v[i+1][j-1][0]!=0)
				{
//					printf("%d %d %c %c\n",i,j,v[i][j][0],v[i][j][1]);
					if(a[i]==v[i+1][j-1][0]&&a[j]==v[i+1][j-1][1]||
						a[i]==v[i+1][j-1][1]&&a[j]==v[i+1][j-1][0])
							ans=max(ans,j-i+1);
				}
			}
		printf("%d\n",ans);
		for(int i=1;i<=n;i++)
			for(int j=i;j<=n;j++) f[i][j]=0,v[i][j][0]=v[i][j][1]=0;
	}
}
/*
11
abccab
ihi
stfgfiut
palindrome
absssab
bbsaa
cffddfcf
bbc
*/