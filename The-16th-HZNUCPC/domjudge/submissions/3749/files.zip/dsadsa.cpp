#include<iostream>
using namespace std;
#include<cmath>	

const double MIN =0.0000001;
struct Point{
	int px;
	int py; 
}point[105];

double k[10000][2];
int b0[10000];
int binf[10000];

int main()
{
	int n,cntk0=0,cntk=0,cnt=0,cntb0=0,cntinf=0;
	double kk,bb;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>point[i].px>>point[i].py;
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){ 
			if(point[j].px==point[i].px&&point[j].py==point[i].py){
				continue;
			}
			else if(point[j].px==point[i].px){
				int flag=0;
				for(int q=0;q<cntb0;q++){
					if(point[i].px==b0[cntb0]){
						flag=1;
						break;
					}
				}
				if(flag==0){
					b0[cntb0]=point[i].px;
				    cntb0++;
				}
				//cout<<"k=0"<<endl;
			}else if(point[j].py==point[i].py){
				int flag=0;
				for(int q=0;q<cntinf;q++){
					if(point[i].py==binf[cntinf]){
						flag=1;
						break;
					}
				}
				if(flag==0){
					binf[cntinf]=point[i].py;
				    cntinf++;
				}
				//cout<<"kwuqqiadjsa"<<endl;
			}else{
				int flag=0;
				kk=1.0*(point[j].py-point[i].py)/(point[j].px-point[i].px);
				bb=1.0*point[i].py-kk*point[i].px;
				//cout<<"kk["<<i<<","<<j<<"]=="<<kk<<endl;
				//cout<<"bb["<<i<<","<<j<<"]=="<<bb<<endl;
				for(int q=0;q<cnt;q++){
					if(fabs(kk-k[q][0])<MIN&&fabs(bb-k[q][1])<MIN){
						flag=1;
						break;
					}
				}
				if(flag==0){
					k[cnt][0]=kk;
					k[cnt][1]=bb;
				    cnt++;
				}
			}
		}
	}
	int sum = cnt+cntb0+cntinf;
	if(sum == 1||sum==2){
		sum=0;
	}
	cout<<sum<<endl;
}