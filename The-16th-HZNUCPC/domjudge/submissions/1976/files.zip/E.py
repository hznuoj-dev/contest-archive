import math
def getLen(p1,p2):
    lst=[p1,p2]
    lst.sort(key= lambda c:c[0])
    p1=lst[0]
    p2=lst[-1]
    if p2[0]-p1[0]==0:
        return abs(p2[1]-p1[1])-1
    k=(p2[1]-p1[1])*1.0/(p2[0]-p1[0])
    l=0
    for i in range(p1[0]+1,p2[0]):
        if i*k*1.0%1==0:
            l+=1
    return l

def check(points):#判断三角形
    d1,d2,d3=points[0],points[1],points[2]
    #斜率
    k1 = (d1[1]-d2[1])*1.0/(d1[0]-d2[0])
    k2 = (d3[1]-d2[1])*1.0/(d3[0]-d2[0])
    if k1==k2:
        return False
    #三边关系
    l1 = pow(d1[1]-d2[1],2)+pow(d1[0]-d2[0],2)
    l2 = pow(d3[1]-d2[1],2)+pow(d3[0]-d2[0],2)
    l3 = pow(d1[1]-d3[1],2)+pow(d1[0]-d3[0],2)
    if l1+l2<l3 or l1+l3<l2 or l3+l2<l1:
        return False
    return True

n=int(input())
lst=list()
for i in range(n):
    lst.append(list(map(int,input().split())))
maxl=0
lenlist=list()
for i in range(len(lst)-1):
    for j in range(i+1,len(lst)):
        temp=getLen(lst[i],lst[j])
        if temp>maxl:
            maxl=temp
            lenlist=[lst[i],lst[j]]
maxl2=0
for i in range(len(lst)):
    if lst[i] in lenlist:
        continue
    if(check(lenlist+[lst[i]])==False):
        continue
    maxl2=getLen(lenlist[0],lst[i])+getLen(lenlist[1],lst[i])
print(maxl+maxl2+3)
    
