#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

typedef long long ll;

const ll mod = 1e9 + 7;

ll ksm(ll a, ll b) {
	ll ans = 1;
	while (b) {
		if (b & 1) ans = ans * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return ans;
}

void solve() {
	string a, b;
	cin >> a >> b;
	int n = a.size();
	a = " " + a;b = " " + b;
	map<array<int, 2>, int> mp;
	array<int, 26> cnta{}, cntb{};
	for (int i = 1; i <= n; ++i) {
		array<int, 2> x = {a[i] - 'a', b[i] - 'a'};
		cnta[a[i] - 'a']++;
		cntb[b[i] - 'a']++;
		mp[x]++;
	}
	
	ll ans = 0;
	for (int i = 0; i < 26; ++i) {
		for (int j = 0;j < 26; ++j) {
			for (int k = 0; k < 26; ++k) {
				for (int w = 0; w < 26; ++w) {
					if (mp[{i, j}] == 0 || mp[{k, w}] == 0) continue;
					array<int, 26> cntaa = cnta, cntbb = cntb;
					cntaa[i]--;
					cntaa[j]++;
					cntbb[i]++;
					cntbb[j]--;
					
					cntaa[w]++;
					cntaa[k]--;
					cntbb[w]--;
					cntbb[k]++;
					
					int sza = 0, szb = 0;
					for (int x = 0; x < 26; ++x) {
						if (cntaa[x]) sza++;
						if (cntbb[x]) szb++;
					}
					
					if (sza != szb) continue;
					
					if (i == k && j == w) {
						ans = (ans + ((mp[{i, j}] - 1) * mp[{k, w}]) % mod) % mod;
					} else {
						ans = (ans + mp[{i, j}] * mp[{k, w}] % mod) % mod;	
					}	
				}
			}
		}
	}
	cout << ans * ksm(2, mod - 2) % mod << '\n';
}

int main() {	
	ios;
	int t = 1;
	while (t--) {
		solve();
	}
	return 0;
}