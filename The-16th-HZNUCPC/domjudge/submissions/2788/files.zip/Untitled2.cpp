#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod = 1e9+7;
signed main()
{
	int n,m;              

	while(cin >> n >> m)
	{
		if(n == 1 || m == 1)
		{
			cout << "YES" << endl;
			continue;
		}
		if(n > m){
			if(n % 2 != 0 && n % m != 0){
				cout << "YES" << endl;
				continue;
			}else{
				if(n % m == 0)
				{
					cout << "NO" << endl;
					continue;
				}
				else
				{
					if(m % 2 == 0)
					{
						cout << "NO" << endl;
						continue;
					}
					else
					{
						cout << "YES" << endl;
						continue;
					}
				}
			}
		}else{
			cout << "NO" << endl;
			continue;
		}
	}
	return 0;
}
