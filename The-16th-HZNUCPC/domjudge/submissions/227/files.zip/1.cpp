#include<bits/stdc++.h>
using namespace std;
#define int long long
const int lib[][2] = {
    {0 ,1},{1 , 0}, {0, - 1}, {-1 , 0}
};
int mp[25][25];

void solve(){
    int n;  cin>>n;
    memset(mp, 0x3f,sizeof(mp));
    int ans = 0;
    for(int i = 1; i <= n; i++){
        int x,y,c;
        cin >> x >> y >>c;
        mp[x][y] = c;
    }
    for(int i = 1;i <= 19;i++){
        for(int j = 1;j <= 19;j++){
            if(mp[i][j] == 1){
                for(int k = 0;k < 4;k++){
                    int tx = i + lib[k][0];
                    int ty = j + lib[k][1];
                    if(tx <= 19 && tx >0 && ty <= 19 && ty > 0){
                        ans += mp[tx][ty] > 2;
                    }
                }
            }
        }
    }
    cout << ans << '\n';
}
signed main(){
    int T;  cin>>T;
    while(T--){
        solve();
    }
    return 0;
}


