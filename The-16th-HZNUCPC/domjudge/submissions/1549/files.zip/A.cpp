#include<bits/stdc++.h>
using namespace std;
#define int long long
struct ll{
	double x,y;
}q[105];

void solve(){
	int x,y;
	cin>>x>>y;
	if(x==1||y==1){
		cout<<"YES"<<endl;
		return ;
	}
	if(x%y==0){
		cout<<"NO"<<endl;
		return;
	}
	
	cout<<"YES"<<endl;
	
}
signed main(){
//	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}