#include<bits/stdc++.h>
#define endl '\n'
typedef long long ll;
using namespace std;
const int N =1e5+10,mod=1e9+7;

ll dp[28][28];
int mp1[299],mp2[200];
ll ksm(ll x, ll y ) {
	ll res = 1;
	while(y) {
		if(y&1) {
			(res *= x) %= mod;
		}
		( x *= x) %= mod;
		y >>= 1;
	}
	return res % mod;
}
void solve() {
	int n;
	string s1,s2;
	cin>>s1>>s2;
	for(auto v:s1)
	mp1[v-'a']++;
	for(auto v:s2)
	mp2[v-'a']++;
	n=s1.size();
	s1=" "+s1;
	s2=" "+s2;
	set<int>t1,t2;
	for(int i=1;i<=n;i++)
	{
		dp[s1[i]-'a'][s2[i]-'a']++;
	}
	ll ans1=0,ans2=0;
	for(int c1=0;c1<26;c1++)
	{
		for(int c2=0;c2<26;c2++)
		{
			for(int h1=0;h1<26;h1++)
			{
				for(int h2=0;h2<26;h2++)
				{
					
					if(dp[c1][c2]==0||dp[h1][h2]==0)
					continue;
					int flag=1;
					
					mp1[c1]--,mp1[c2]++;
					mp2[c2]--,mp2[c1]++;
					mp1[h1]--,mp1[h2]++;
					mp2[h2]--,mp2[h1]++;
					
					int sz1=0,sz2=0;
					for(int k=0;k<26;k++)
					{
						sz1+=(mp1[k]!=0);
						sz2+=(mp2[k]!=0);
					}
					if(sz1!=sz2)
					flag=0;
						
					mp1[c1]++,mp1[c2]--;
					mp2[c2]++,mp2[c1]--;
					mp1[h1]++,mp1[h2]--;
					mp2[h2]++,mp2[h1]--;
					
					if(flag)
					{
						if(c1==h1&&c2==h2)
							ans1=(ans1+dp[c1][c2]*(dp[c1][c2]-1)/2ll)%mod;
						else
							ans2=(ans2+dp[c1][c2]*dp[h1][h2])%mod;
					}
				}
			}
		}
	}
	cout<<(ans1+ans2*ksm(2, mod-2)%mod)%mod<<'\n';
}

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int _t = 1;
//	cin >> _t;
	while(_t--) {
		solve() ;
	}
}