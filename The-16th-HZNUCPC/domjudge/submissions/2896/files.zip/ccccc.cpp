#include<bits/stdc++.h>

using namespace std;
#define int long long 
#define eb emplace_back
#define pii pair<int, int> 
#define pcc pair<char, char> 
#define endl '\n'
int dr[4] = {1, 0, -1, 0};
int dc[4] = {0, 1, 0, -1};
const int MOD = 1e9 + 7;
int qmi(int a,int b) {
	int res=1;
	for(; b; b>>=1,a=a*a%MOD)
		if(b&1)res=res*a%MOD;
	return res;
}
void run() {
	string a, b;
	cin >> a >> b;
	map<pii, int> mp;
	for (int i = 0; i < a.size(); i++) {
		mp[pii(a[i] - 'a', b[i] - 'a')]++;
	}
	vector<int> cnta(30, 0), cntb(30, 0);
	for (auto x : a) cnta[x - 'a']++;
	for (auto x : b) cntb[x - 'a']++;

	int ans = 0;
	for (int i = 0; i < 26; i++) {
		for (int j = 0; j < 26; j++) {
			pii fst = pii(i, j);
			if (mp[fst] == 0) continue;
			for (int ii = 0; ii < 26; ii++) {
				for (int jj = 0; jj < 26; jj++) {
					pii sec = pii(ii, jj);
					if (mp[sec] == 0) continue;
					vector<int> tmpa = cnta, tmpb = cntb;
					tmpa[fst.first]--;
					tmpa[fst.second]++;
					tmpb[fst.first]++;
					tmpb[fst.second]--;

					tmpa[sec.first]--;
					tmpa[sec.second]++;
					tmpb[sec.first]++;
					tmpb[sec.second]--;
					vector<int> alla, allb;
					for (int k = 0; k < 30; k++) {
						alla.eb(tmpa[k]);
						allb.eb(tmpb[k]);
					}
					sort(alla.begin(), alla.end());
					sort(allb.begin(), allb.end());
					if (alla == allb) {
//						cout << fst.first << ' ' << fst.second << ' ' << sec.first << ' ' << sec.second << ' ' <<  mp[fst] * mp[sec]<< endl;
						if (fst == sec) ans = (ans + mp[fst] * (mp[sec] - 1) % MOD) % MOD;
						else ans = (ans + mp[fst] * mp[sec] % MOD) % MOD;
					}
				}
			}
		}
	}
	cout << ans * qmi(2, MOD - 2) % MOD << endl;
	
	


	return;
}
/*
aaaa
aaaa

abca
aaaa

*/
signed main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int T = 1;
	// cin >> T;
	while (T--) {
		run();
	}



	return 0;
}