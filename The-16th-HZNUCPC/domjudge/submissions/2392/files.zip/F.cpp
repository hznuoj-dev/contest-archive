#include<iostream>
#include<cstring>
using namespace std;
typedef long long ll;
int mp[20][20];

int main(){
	ll n,m;
	cin>>n>>m;
	if(m>=n) cout<<"NO";
	else if(m == 1||n == 1) cout<<"YES";
	else if(n%2==0) cout<<"NO";
	else if(n%m == 0) cout<<"NO";
	else cout<<"YES";
}