#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int x[110],y[110];
ll s[110][110];
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int T=1;
//	cin>>T;
	while(T--){
		int n;cin>>n;
		ll sum=0;
		for(int i=1;i<=n;i++){
			cin>>x[i]>>y[i];
		}
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				int a=abs(x[i]-x[j]);
				int b=abs(y[i]-y[j]);
				int m=__gcd(a,b);
				s[i][j]=m+1;
				//cout<<i<<' '<<j<<' '<<s[i][j]<<"\n";
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				for(int k=j+1;k<=n;k++){
					if(((y[j]-y[i])*(x[k]-x[i]))!=((y[k]-y[i])*(x[j]-x[i]))){
						sum=max(sum,s[i][k]+s[i][j]+s[j][k]);
					}
				}
			}
		}
		if(sum!=0)cout<<sum-3;
		else cout<<sum;
	}
	return 0;
}











