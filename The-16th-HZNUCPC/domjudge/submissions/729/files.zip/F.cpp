#include "bits/stdc++.h"
using namespace std;
#define LL long long
bool solve(LL n,LL m){
	if(m == 1 || n == 1){
		return true;
	}
	else if (n % m == 0){
		return false;
	}
	if (n <= m){
		return false;
	}
	else {
		LL k = n % m;
		LL a = n / m;
		if (n - (m - k)*(a) > (m - k) * a){
			return solve(n,n % m); 
		}
		else{
			return false;
		}
	}
}
int main(){
	LL n,m;
	cin >> n >> m;
	if(solve(n,m)){
		printf("YES\n");
	}else{
		printf("NO\n");
	}
}
