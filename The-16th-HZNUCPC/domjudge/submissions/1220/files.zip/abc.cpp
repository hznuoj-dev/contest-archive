#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using pt = complex<long long>;
/*
#define x real()
#define y imag()

int point_covered(pt a, pt b) {
	assert(a != b);
	if (a.x == b.x) {
		return abs(a.y - b.y) - 1;
	}
	if (a.y == b.y) {
		return abs(a.x - b.x) - 1;
	}
	
	return __gcd(abs(a.y - b.y), abs(a.x - b.x)) - 1;
}

int cross(pt a, pt b) {
	return a.x * b.y - a.y * b.x;
}

int same_line(pt a, pt b, pt c) {
	return cross(b - a, c - a) == 0;
}
*/
#define int ll
int mat[26][26];
int cnt1[26], cnt2[26];
const int MOD = 1e9 + 7;
void solve() {
	string a, b;
	cin >> a >> b;
	int n = a.size();
	for (auto c : a) {
		cnt1[c - 'a']++;
	}
	for (auto c : b) {
		cnt2[c - 'a']++;
	}
	
	for (int i = 0; i < n; ++i) {
		int c1 = a[i] - 'a', c2 = b[i] - 'a';
		mat[c1][c2]++;
	}
	int res =0 ;
	for (int i = 0; i < n; ++i) {
		int c1 = a[i] - 'a', c2 = b[i] - 'a';
		mat[c1][c2]--;
		cnt1[c1]--, cnt2[c2]--;
		cnt1[c2]++, cnt2[c1]++;
		
		int t1 = 0, t2 = 0;
		for (int j = 0; j < 26; ++j) {
			t1 += cnt1[j] != 0;
			t2 += cnt2[j] != 0;
		
		}
	
			for (int j = 0; j < 26; ++j) {
				for (int k = 0; k < 26; ++k) {
					if (!mat[j][k]) continue;
					if (j == k) {
						if (t1 == t2) {
							(res += mat[j][k]) %= MOD;
							continue;
						}
					}
					int nt1 = t1, nt2 = t2;
					if (cnt1[j] == 1) {
						nt1--;
					} 
					if (cnt1[k] == 0) {
						nt1++;
					}
					
					if (cnt2[k] == 1) {
						nt2--;
					} 
					if (cnt2[j] == 0) {
						nt2++;
					}
					if (nt1 == nt2) {
						
					
						(res += mat[j][k]) %= MOD;
					}	
				}
			}
		
		
//		printf("at %d: %d\n", i, res);
		cnt1[c1]++, cnt2[c2]++;
		cnt1[c2]--, cnt2[c1]--;

	}
	cout << res << "\n";

}

signed main() {

	solve();
	
}


/*
aaaa
aaaa

abca
aaaa
*/