#include <bits/stdc++.h>
#define int long long
#define endl '\n'
using namespace std;
typedef unsigned long long ull;
const int N=2e5+10;
const int mod=1e9+7;

void run()
{
	int n,m,x=-1;
	
	cin >> n >> m;
	if(n==1 || m==1)
	{
		cout << "YES";
		return;
	}
	if(n<=m)
	{
		cout << "NO";
		return;
	}
	
	for(int i=2;i<=sqrt(n);i++)
	{
		if(n%i==0)
		{
			x=i;
			break;
		}
	}
	if(x==-1)
		cout << "YES";
	else
	{
		if(x>m)
			cout << "YES";
		else
			cout << "NO";
	}
}

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

