#include<bits/stdc++.h>
using namespace std;
#define int long long
int x[105];
int y[105];
int n,m;

double xielv(int a,int b){
	if(y[a] - y[b]!=0)return (x[a] - x[b])*1.0 / (y[a] - y[b]);
	return -1;
}

int check(int a,int b,int c){
	double k1 = xielv(a,b);
	double k2 = xielv(b,c);
	double k3 = xielv(a,c);
	if(k1==k2&&k1==k3&&k2==k3)return -1;
	int abx=abs(x[a]-x[b]);
	int aby=abs(y[a]-y[b]);
	int res=3;
	int cc=__gcd(abx,aby);
	if(min(abx,aby)==0){
		res+=max(abx,aby)-1;
	}else{
		res+=cc-1;
	}
	int acx=abs(x[a]-x[c]);
	int acy=abs(y[a]-y[c]);
	cc=__gcd(acx,acy);
	if(min(acx,acy)==0){
		res+=max(acx,acy)-1;
	}else{
		res+=cc-1;
	}
	int bcx=abs(x[b]-x[c]);
	int bcy=abs(y[b]-y[c]);
	cc=__gcd(bcx,bcy);
	if(min(bcx,bcy)==0){
		res+=max(bcx,bcy)-1;
	}else{
		res+=cc-1;
	}
	return res;
}

void solve(){
	while(cin >> n){
		for(int i = 1 ; i <= n ; i++){
			cin >> x[i] >> y[i];
			x[i]+=1e9;
			y[i]+=1e9;
		}
		int maxn = 0;
		for(int i = 1;  i <= n ; i ++){
			for(int j = i + 1 ; j <= n ; j ++){
				for(int k = j + 1 ; k <= n ; k ++){
					int t = check(i,j,k);
//					cout<<i<<" "<<j<<" "<<k<<" "<<t<<endl;
					if(t > maxn){
						maxn = t;
					}
				}
			}
		}
		cout<< maxn <<endl;
	}
}

signed main(){
//	int T;cin >> T;while(T--){
		solve();
//	}
	return 0;
}
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1