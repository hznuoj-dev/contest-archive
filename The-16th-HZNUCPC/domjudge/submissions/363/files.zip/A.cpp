#include<bits/stdc++.h>
#define endl '\n'
using namespace std;

int T, n;

int tongji(int i, int j, vector<vector<int>> &w) {
	int count = 0;
	if (i - 1 >= 1 && w[i - 1][j] == 0) {
		++count;
	}
	if (j - 1 >= 1 && w[i][j - 1] == 0) {
		++count;
	}
	if (i + 1 <= 19 && w[i + 1][j] == 0) {
		++count;
	}
	if (j + 1 <= 19 && w[i][j + 1] == 0) {
		++count;
	}
	return count;
}

int main() {
	cin >> T;
	while (T--) {
		cin >> n;
		vector<vector<int> > w(20, vector<int>(20, 0));
		for (int i = 1, x, y, c; i <= n; ++i) {
			cin >> x >> y >> c;
			w[x][y] = c;
		} 
		int ans = 0;
		for (int i = 1; i <= 19; ++i) {
			for (int j = 1; j <= 19; ++j) {
				if (w[i][j] == 1) {
					ans += tongji(i, j, w);
				}
			}
		}
		cout << ans << endl;
	}
	return 0;
}