#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll,ll> PII;
inline bool check(PII a,PII b,PII c){
	a={a.first-c.first,a.second-c.second};
	b={b.first-c.first,b.second-c.second};
	return a.first*b.second!=b.first*a.second;
}
inline ll count(PII a,PII b){
	PII c={abs(a.first-b.first),abs(a.second-b.second)};
	return __gcd(c.first,c.second);
}
int main(){
	ll n,m=0;cin>>n;
	vector<PII> a(n);
	for(ll i=0;i<n;i++)cin>>a[i].first>>a[i].second;
	for(ll i=0;i<n-2;i++)
		for(ll j=i+1;j<n-1;j++)
			for(ll k=j+1;k<n;k++)
				if(check(a[i],a[j],a[k]))
					m=max(m,count(a[i],a[j])+count(a[j],a[k])+count(a[k],a[i]));
	cout<<m;
}