#include<bits/stdc++.h>
using namespace std;
const int N = 110;
struct nod{
	int x, y;
}no[N];
int l[105][105];
void solve(){
	long long n, m;
	cin >> n;
	for(int i = 1; i <= n; i++){
		cin >> no[i].x >> no[i].y;
	}
	int ans = 0;
	for(int i = 1; i <= n; i++){
		for(int j = i + 1; j <= n; j++){
			int a = no[i].x - no[j].x;
			int b = no[i].y - no[j].y;
			int gcd = __gcd(a, b);
			l[i][j] = l[j][i] = abs(gcd) - 1;
//			cout << l[i][j] << "\n";
		}
	}
	for(int i = 1; i <= n; i++){
		for(int j = i + 1; j <= n; j++){
			for(int k = j + 1; k <= n; k++){
				ans = max(ans, l[i][j] + l[j][k] + l[i][k]);
			}
		}
	}
	cout << ans + 3 << "\n";
}
int main(){
	int t = 1;
//	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
