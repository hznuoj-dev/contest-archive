#include<bits/stdc++.h>
using namespace std;
int T,ans;

signed main(){
	cin >> T;
	while (T--) {
		ans=0;
		string s;
		cin>>s;
		s=' '+s;
		int len=s.size()-1;
		for(int i=2;i<=len;i++){
			int l,r;
			l=r=i;
			bool flag=true;
			bool first=false;
			while(l-1>=1&&r+1<=len){
				l--;r++;
				if(s[l]!=s[r]&&!first){
					first=true;
					bool mid=false;
					if(s[r]==s[i]||s[l]==s[i]){
						ans=max(ans,r-l+1);
						mid=true;
					}
					for(int j=1;j<=len;j++){
						if(r+j<=len&&l-j>=1&&s[r+j]!=s[l-j]){
							if(s[r+j]==s[l]&&s[l-j]==s[r]||s[l-j]==s[l]&&s[r]==s[r+j]){
								l=l-j;
								r=r+j;
								ans=max(ans,r-l+1);
							}
							else flag=false;
							break;
						}
						else if(r+j>len||l-j<1){
							flag=false;
							break;
						}
						else if(s[r+j]==s[l-j]&&mid)ans=max(ans,r+j-(l-j)+1);
					}
				}
				else if(s[l]!=s[r]){
					ans=max(ans,r-l-1);
					break;
				}
				else{
					ans=max(ans,r-l+1);
					continue;
				}
				if(!flag){	
					break;
				}
			}
		}
		for(int i=1;i<=len;i++){
			int l,r;
			l=i+1,r=i;
			bool flag=true;
			bool first=false;
			while(l-1>=1&&r+1<=len){
				l--;r++;
				if(s[l]!=s[r]&&!first){
					first=true;
					for(int j=1;j<=len;j++){
						if(r+j<=len&&l-j>=1&&s[r+j]!=s[l-j]){
							if(s[r+j]==s[l]&&s[l-j]==s[r]||s[l-j]==s[l]&&s[r]==s[r+j]){
								l=l-j;
								r=r+j;
								ans=max(ans,r-l+1);
							}
							else flag=false;
							break;
						}
						else if(r+j>len||l-j<1){
							flag=false;
							break;
						}
					}
				}
				else if(s[l]!=s[r]){
					ans=max(ans,r-l-1);
					break;
				}
				else{
					ans=max(ans,r-l+1);
					continue;
				}
				if(!flag){	
					break;
				}
			}
		}
		if(ans==1)ans=0;
		cout<<ans<<'\n';
	}
}
/*
6
abccab
ihi
stfgfiut
palindrome
i
aaa
*/