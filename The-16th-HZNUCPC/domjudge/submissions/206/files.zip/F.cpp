#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long n,m,flag=0;
	scanf("%lld%lld",&n,&m);
	while(m)
	{
		if(m==1)
			break;
		if(n%m==0)
		{
			cout<<"NO"<<endl;
			return 0;
		}
		m=n%m;
		
	}
	cout<<"YES"<<endl;
	return 0;
}