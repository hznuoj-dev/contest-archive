#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main() {
	ll n, m;
	cin >> n >> m;
	if (n == 1) {
		cout << "YES" << endl;
		return 0;
	}
	if (n <= m) {
		cout << "NO" << endl;
		return 0;
	}
	vector<int> v;
	for (ll i = 2; i * i <= n; i++) {
		if (n % i == 0) {
			v.push_back(i);
			break;
		}
	}
	if (v.empty() || m < v[0]) {
		cout << "YES" << endl;
	} else {
		cout << "NO" << endl;
	}
	return 0;
}