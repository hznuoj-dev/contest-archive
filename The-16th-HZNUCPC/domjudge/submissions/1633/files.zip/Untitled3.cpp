#include<bits/stdc++.h>
using namespace std;
int mp[20][20];//地图
int dd[20][20];//存储有无走过
int dirx[4]={0,1,0,-1};
int diry[4]={1,0,-1,0};
int sum;
void bfs(int x,int y)
{
	int t=0,w=0;
//	dd[][]
//	dd[][]
	mp[x][y]=1;
		for(int i=0;i<4;i++)
		{
			int dx=x+dirx[i];
			int dy=y+diry[i];
			if(mp[dx][dy]!=1&&dx>0&&dy>0&&dy<20&&dx<20)
			{
				if(mp[dx][dy]==0)
				{
					sum++;
				}
			}
			
			
		}
	
}
int main()
{
	int t,n,x,y,z,c;
	scanf("%d",&t);		
	while(t--){
		
		sum=0;
		scanf("%d",&n);
		memset(mp,0,sizeof(mp));
		for(int i=1;i<=n;i++)
		{
			scanf("%d%d%d",&x,&y,&c);	
			mp[x][y]=c;
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<19;j++)
			{
				if(mp[i][j]==1)
				bfs(i,j);
			}
			
		}
		printf("%d\n",sum);
//		for(int i=1;i<=19;i++)
//		{
//			for(int j=1;j<19;j++)
//			printf("%d ",mp[i][j]);
//			printf("%d\n",mp[i][19]);
//		}
		
		
		
	}
  return 0;
}
