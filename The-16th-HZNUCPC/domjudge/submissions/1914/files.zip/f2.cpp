#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
#define int long long
signed main(){
	int n,m;
	scanf("%lld %lld",&n,&m);
	int flag=0;
	if(m==1){
		printf("YES\n");
	}else if(n==1){
		printf("YES\n");
	}else if(n<=m){
		printf("NO\n");
	}else{
		int k=-1;
		for(int i=2;i<=sqrt(n);i++){
			if(n%i==0){
				k=i;
				break;
			}
		}		
		if(k==-1){
			printf("YES\n");
		}else if(k<=m){
			printf("NO\n");
		}else{
			printf("YES\n");
		}
	}
	return 0;
} 
