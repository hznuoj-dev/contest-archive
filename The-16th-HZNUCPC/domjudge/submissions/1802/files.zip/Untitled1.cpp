#include<bits/stdc++.h>

#define ll long long

using namespace std;



int main(){
	ll n,m;
	cin>>n>>m;
	if(__gcd(n,m)==1)cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	return 0;
}