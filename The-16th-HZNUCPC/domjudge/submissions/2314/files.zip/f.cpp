#include "bits/stdc++.h"
using namespace std;
long long a,b,c,d,e,f;
int nb(int x){
	for(int i=2;i<x;i++){
		if(x%i==0){
			return -1;
			break;
		}
	}
	return 0;
}
int main(){
	while(cin>>a>>b){
		long long k=b;
		if((nb(a)==0&&a!=b)||(a==1||b==1)){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
		
}
	return 0;
}