#include<bits/stdc++.h>
using namespace std;
#define int long long 
int n,m;
map<int,int>mp;
void solve(){
	while(cin>>n>>m){
		mp.clear();
		if(n==1||m==1||n-m==1){
			cout<<"YES"<<endl;
			continue;
		}
		if(n<=m){
			cout<<"NO"<<endl;
			continue;
		}
		int f=0;
		for(int i=1;i*i<=n;i++){
			if(n%i==0){
				mp[n/i]++;
				mp[i]++;
			}
		}
		while(1){
			if(m==1){
				break;
			}
			if(mp[m]){
				f=1;
				break;
			}
			m=n%m;
		}
		if(f==0)cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
}
signed main(){
	solve();
	return 0;
}