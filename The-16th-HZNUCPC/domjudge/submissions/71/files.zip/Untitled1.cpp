#include <bits/stdc++.h>
using namespace std;
int mark[505][505];
int ox[]={0,0,1,-1};
int oy[]={1,-1,0,0};
int check(int x,int y){
	if(mark[x][y]!=1)return 0;
	int cnt=0;
	for(int i=0;i<4;i++){
		int tx=x+ox[i],ty=y+oy[i];
		if(mark[tx][ty]==0&&tx>0&&ty>0&&tx<20&&ty<20)cnt++;
	}
	return cnt;
}
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int n;
		scanf("%d",&n);
		memset(mark,0,sizeof(mark));
		for(int i=1;i<=n;i++){
			int x,y,z;
			scanf("%d %d %d",&x,&y,&z);
			mark[x][y]=z;
		}
		int ans=0;
		
		for(int i=1;i<=19;i++)
			for(int j=1;j<=19;j++){
				ans+=check(i,j);
			}
		printf("%d\n",ans);
	}
	
	return 0;
}