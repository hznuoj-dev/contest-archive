#include<bits/stdc++.h>
using namespace std;
int ans,i,l,l1,r1,l2,r2,T,n,j;
char s[5002];
void upd(int x){if(x>ans)ans=x;}
int main(){
	scanf("%d",&T);
	for (;T--;){
		scanf("%s",s+1);
		n=strlen(s+1);
		ans=0;
		for (i=1;i<=n;i++){
			l1=r1=l2=r2=-1;
			for (j=1;j<=min(i-1,n-i);j++){//odd
				if (s[i-j]!=s[i+j]){
					if (l1==-1) l1=i-j,r1=i+j;
					else if (l2==-1) l2=i-j,r2=i+j;
					else break;
				}
				if (l1==-1) upd(j*2+1);
				else if (l2==-1){
					if (s[i]==s[l1] || s[i]==s[r1]) upd(j*2+1);
				}else if (s[l1]==s[l2] && s[r1]==s[r2] || s[l2]==s[r1] && s[l1]==s[r2]) upd(j*2+1);
			}
			l1=r1=l2=r2=-1;
			for (j=1;j<=min(i,n-i);j++){//even
				if (s[i-j+1]!=s[i+j]){
					if (l1==-1) l1=i-j+1,r1=i+j;
					else if (l2==-1) l2=i-j+1,r2=i+j;
					else break;
				}
				if (l1==-1) upd(j*2);
				else if (l2==-1){
				}else if (s[l1]==s[l2] && s[r1]==s[r2] || s[l2]==s[r1] && s[l1]==s[r2]) upd(j*2);
			}
		}
		printf("%d\n",ans);
	}
}
/*
4
abccab
ihi
stfgfiut
palindrome
*/