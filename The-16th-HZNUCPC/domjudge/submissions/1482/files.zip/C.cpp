#include<bits/stdc++.h>

using namespace std;
#define int long long

int mp[30][30];
string s1, s2;
int n;
int mod = 1e9+7;
int num1[30], num2[30];
int sz1, sz2;

int check(int c1, int c2, int d1, int d2){
	int t1[30], t2[30];
	for(int i = 0 ; i < 30; i ++){
		t1[i] = num1[i];
		t2[i] = num2[i];
	}
	int tmp1 = sz1, tmp2 = sz2;
	if(t1[c1] == 1) tmp1 --;
	t1[c1] --;
	if(t1[c2] == 0) tmp1 ++;
	t1[c2] ++;
	
	if(t1[d1] == 1) tmp1 --;
	t1[d1] --;
	if(t1[d2] == 0) tmp1 ++;
	t1[d2] ++;
	
	if(t2[c2] == 1) tmp2 --;
	t2[c2] --;
	if(t2[c1] == 0) tmp2 ++;
	t2[c1] ++;
	
	if(t2[d2] == 1) tmp2 --;
	t2[d2] --;
	if(t2[d1] == 0) tmp2 ++;
	t2[d1] ++;
	return tmp1 == tmp2;
}

signed main(){
	ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
	cin >> s1 >> s2;
	n = s1.size();
	for(int i = 0 ;i < n ; i ++){
		num1[s1[i] - 'a'] ++;
		num2[s2[i] - 'a'] ++;
		mp[s1[i] - 'a'][s2[i] - 'a'] ++;
	}
	for(int i = 0 ; i < 29; i ++) {
		sz1 += num1[i] != 0;
		sz2 += num2[i] != 0;
	}
	int ans = 0;
	for(int c1 = 0 ; c1 < 26; c1 ++){
		for(int c2 = 0; c2 < 26; c2 ++){
			for(int d1 = 0; d1 < 26; d1 ++){
				for(int d2 = 0; d2 < 26; d2 ++){
					if(!check(c1, c2, d1, d2)) continue;
//					if(mp[c1][c2] && mp[d1][d2])cout << c1 << " " << c2 << " " << d1 << " " << d2 << '\n';
					if(c1 == d1 && c2 == d2){
						int s = mp[c1][c2];
						ans += s * (s - 1);
					}else{
						ans += mp[c1][c2] * mp[d1][d2];
					}
				}
			}
		}
	}
//	cout << check(0, 0, 1, 1);
	cout << (ans / 2) % mod;
}