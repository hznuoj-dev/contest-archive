#include <bits/stdc++.h>

typedef long long int ll;

int n;

int board[50][50];

bool vis[50][50];

bool avai[50][50];

void dfs(int x, int y, int col){
	vis[x][y] = true;
	if(x > 1){
		if(0 == board[x - 1][y]){
			avai[x - 1][y] = true;
		}else if(col == board[x - 1][y] && !vis[x - 1][y]){
			dfs(x - 1, y, col);
		}
	}
	if(x < 19){
		if(0 == board[x + 1][y]){
			avai[x + 1][y] = true;
		}else if(col == board[x + 1][y] && !vis[x + 1][y]){
			dfs(x + 1, y, col);
		}
	}
	if(y > 1){
		if(0 == board[x][y - 1]){
			avai[x][y - 1]= true;
		}else if(col == board[x][y - 1] && !vis[x][y - 1]){
			dfs(x, y - 1, col);
		}
	}
	if(y < 19){
		if(0 == board[x][y + 1]){
			avai[x][y + 1] = true;
		}else if(col == board[x][y + 1] && !vis[x][y + 1]){
			dfs(x, y + 1, col);
		}
	}
}

void erase(int x, int y){
	board[x][y] = 0;
	if(x > 1){
		if(2 == board[x - 1][y]){
			erase(x - 1, y);
		}
	}
	if(x < 19){
		if(2 == board[x + 1][y]){
			erase(x + 1, y);
		}
	}
	if(y > 1){
		if(2 == board[x][y - 1]){
			erase(x, y - 1);
		}
	}
	if(y < 19){
		if(2 == board[x][y + 1]){
			erase(x, y + 1);
		}
	}
}

int main(){
	int T;
	for(scanf("%d", &T); T > 0; T--){
		scanf("%d", &n);
		int i, j, k;
		for(i = 1; i <= 19; i++){
			for(j = 1; j <= 19; j++){
				board[i][j] = 0;
				vis[i][j] = false;
			}
		}
		
		int x, y;
		for( ; n > 0; n--){
			scanf("%d%d", &x, &y);
			scanf("%d", &board[x][y]);
		}
		
		for(i = 1; i <= 19; i++){
			for(j = 1; j <= 19; j++){
				if(2 == board[i][j] && !vis[i][j]){
					int k, t;
					for(k = 1; k <= 19; k++){
						for(t = 1; t <= 19; t++){
							avai[k][t] = false;
						}
					}
					dfs(i, j, 2);
					bool b = false;
					for(k = 1; k <= 19; k++){
						for(t = 1; t <= 19; t++){
							b = b || avai[k][t];
						}
					}
					if(!b){
						erase(i, j);
					}
				}
			}
		}
		
		int ans = 0;
		for(i = 1; i <= 19; i++){
			for(j = 1; j <= 19; j++){
				if(1 == board[i][j] && !vis[i][j]){
					int k, t;
					for(k = 1; k <= 19; k++){
						for(t = 1; t <= 19; t++){
							avai[k][t] = false;
						}
					}
					dfs(i, j, 1);
					for(k = 1; k <= 19; k++){
						for(t = 1; t <= 19; t++){
							if(avai[k][t]){
								ans++;
							}
						}
					}
				}
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}
