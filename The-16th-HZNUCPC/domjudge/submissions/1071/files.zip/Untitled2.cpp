#include<bits/stdc++.h>
using namespace std;

long long x[105];
long long y[105];


int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);

	long long n,m;
	cin>>n>>m;
	int f=0;
	if(m==1)
	{
		cout<<"YES\n";
		return 0;
	}
	if(m>=n||n%m==0)
	{
		cout<<"NO\n";
		return 0;
	}
	if(n%m==1)
	{
		cout<<"YES\n";
		return 0;
	}
	if(n%2==0)
	{
		cout<<"NO\n";
		return 0;
	}
	long long cnt=m;
	long long last=-1;
	while(true)
	{
		cnt=n%cnt;
		if(cnt==1)
		{
			f=1;
			break;
		}
		else if(cnt==0)
		{
			f=0;
			break;
		}
	}
	if(f)cout<<"YES\n";
	else cout<<"NO\n";
	
	return 0;
}