#include<bits/stdc++.h>

using namespace std;


#define int long long
const int N = 1e2 + 10;

int x[N], y[N];

int get(int i, int j) {
	int tx = abs(x[i] - x[j]), ty = abs(y[i] - y[j]);
	int tt = __gcd(tx, ty);
	return tt;
}

signed main() {
	//cout << __gcd(0, 7) << '\n';
	int n; 
	cin >> n;
	for (int i = 1; i <= n ; i ++)
		cin >> x[i] >> y[i];
	int res = 0;
	for (int i = 1; i <= n; i ++)
		for (int j = i + 1; j <= n; j ++)
			for (int k = j + 1; k <= n; k ++) {
				int t = 0;
				t += get(i, j);
				t += get(i, k);
				t += get(j, k);
				//t += 3;
				res = max(res, t);
			}
	cout << res << '\n';
	
			
	
}