#include "bits/stdc++.h"
typedef long long int ll;
using namespace std;
const ll mod = 1E9+7;
 
  

// void solve2(){
//     int n ;
//     cin >> n;
//     vector<int> v(n), v2(n);
//     vector<int> cnt1(26), cnt2(26);
//     vector<int> diff(26), sameChar(26);
//     for(int i =0 ; i <n;i++) {
//         cin >> v[i];
//         // cnt[v[i] - 'a'] ++;
//     }
//     for(int i =0 ; i <n;i++) {
//         cin >> v2[i];
//         // cnt[v[i] - 'a']--;
//     }

//     int same = 0;


//     for(int i =0 ; i <n;i++){
//         if(v[i] == v2[i]) {
//             same++;
//             sameChar[i]++;
//         }
//         cnt1[v[i] - 'a']++;
//         cnt2[v2[i] - 'a']++;
//     }
//     for(int i = 0; i < 26;i++) {
//         diff[i] = (cnt1[i] - cnt2[i]);
//     }

//     for(int i = 0; i < 26; i++) {
//         if(diff[i] == 0) {
//             ans += sameChar[i] + 
//             continue;
//         }
//         else {
            
//         }

//     }



//     return ;


// }

const int N = 26;
int arr[N][N];

    void print(vector<int> &v){
        for(int i = 0 ; i < 26;i++) {
            cout << v[i] <<" \n"[i==25];
        }
    }

void solve (){
    string s1, s2;
    cin >> s1 >> s2;
    int n = s1.size();
    vector<int> v(n), v2(n), cnt1(26), cnt2(26);
    ll ans = 0;
    map<pair<int,int>, int> mp;
    char c;
    for(int i =0 ; i <n;i++) {
        
         
        v[i] = s1[i]-'a';
        cnt1[v[i]]++;
        // cnt[v[i] - 'a'] ++;
    }
    for(int i =0 ; i <n;i++) {
  
        v2[i] = s2[i] -'a';
        cnt2[v2[i]]++;
    }
 
    

    for(int i = 0; i < n;i++) {
        //mp[{v[i], v2[i]}]++;
        arr[v[i]][v2[i]]++;
    }
    vector< pair < pair<int,int>, int > > vv;
     for(int i =0 ; i <26;i++) {
        for(int j =0 ; j <26;j++) {
            if(arr[i][j] == 0) continue;
            pair<pair<int,int>, int > x = make_pair(make_pair(i,j),  arr[i][j]);
            // vv.push_back({{i,j}, arr[i][j]});
            vv.push_back( x);
            
        }
    }


 
    int m = vv.size();
    for(int i =0 ; i < m;i++) {
        for(int j = i; j < m;j++) {
            // cout << i <<" "<< j <<" ans: "<< ans  << endl;
            // swap 1 
            auto [x,y] = vv[i].first ;
            
            auto [x2, y2] = vv[j].first ;


            if(i == j) {
                if(vv[i].second == 1) {
                    continue;
                }

            }
            // print(cnt1);
            // print(cnt2);
            cnt1[x]--;
            cnt1[y] ++;
            cnt1[x2]--;
            cnt1[y2]++;

            cnt2[x] ++;
            cnt2[y] --;
            cnt2[x2]++;
            cnt2[y2]--;


            
            int ok = 0;
            // cout << (char)(x+'a') <<" " << (char)(y+'a') <<" -- "<< (char)(x2+'a') <<" " << (char)(y2+'a') << endl;
            // print(cnt1);
            // print(cnt2);
            // cout <<""<< endl;

            for(int k = 0 ; k < 26;k++){
                if(cnt1[k] != 0 && cnt1[k] == cnt2[k]) {
                    ok = 1;
                    break;
                }
            }
            if(ok) {
                if(i == j) {
                    // cout <<"OK1" <<endl;
                    ans += ((ll )vv[i].second * (vv[j].second -1) ) / 2;
                }
                else{
                    // cout <<"OK2" <<endl;
                    ans += (ll )vv[i].second * vv[j].second;
                }
                ans %= mod ;    
            }

            cnt2[x]--;
            cnt2[y] ++;
            cnt2[x2]--;
            cnt2[y2]++;

            cnt1[x] ++;
            cnt1[y] --;
            cnt1[x2]++;
            cnt1[y2]--;

        }
    }
    cout << ans << endl;

}



int main (){
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    int t = 1;
    // cin >> t;
    while (t--){
        solve();
    }

    return 0;
}


/*

ccccccaaaab
ccccccbbbba

*/