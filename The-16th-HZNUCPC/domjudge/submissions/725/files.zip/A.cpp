#include<bits/stdc++.h>
using namespace std;

#define int long long

const int N = 2e3 +10, inf = 1e17, mod = 1e9 +7;

int n, m, k, x, y, ans;
char s[N], p[N];

int v[N];

void dfs(int x,int y){
    if(x%y==0){
        return;
    }
    if(x%y==1){
        ans = 1;
        return;
    }
    dfs(x,x%y);
}

void run(){
    cin>>n>>m;
    ans = 0;
    dfs(n,m);
    if(ans == 1|| m==1)cout<<"YES\n";
    else cout<<"NO\n";
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int T;
    // for(cin>>T;T>0;T--)
    run();return 0;
}
