#pragma GCC optimize(2)
#pragma GCC optimize(1)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long n,m;
	cin>>n>>m;
	if(n<=m)
	{
		cout<<"NO"<<endl;
		return 0;
	}
	else
	{
		while(n%m!=1&&n%m!=0)
		{
			m=n%m;
		}
		if(n%m)
		{
			cout<<"YES"<<endl;
		}
		else
		{
			cout<<"NO"<<endl;
		}
	}
}