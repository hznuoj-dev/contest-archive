#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define me(a,b) memeset(a,b,sizeof a);
int n,m;
signed main() {
	IOS
	cin>>n>>m;
		if(m==1||n==1){
			cout<<"YES"<<endl;
		}else{
			while(m>0){
				if(m==1)break;
				m=n%m;
			}
			if(m==1)cout<<"YES"<<endl;
			else cout<<"NO"<<endl;
		}
	
	return 0;
}