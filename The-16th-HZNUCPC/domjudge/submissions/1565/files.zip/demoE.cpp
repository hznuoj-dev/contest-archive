#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=110;
ll x[N],y[N];
ll n;
ll max(ll a,ll b){
    if(a>b)return a;
    else return b;
}
ll  gcd(ll a,ll b)
{
    return b? gcd(b,a%b):a;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>x[i]>>y[i];
    }
    int ans=0;
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            for(int k=j+1;k<n;k++){
                ll x1=x[i],x2=x[j],x3=x[k];
                ll y1=y[i],y2=y[j],y3=y[k];
                ll len1=(x1-x2)*(x1-x2)+(y1-y2)*(y1-y2);
                ll len2=(x1-x3)*(x1-x3)+(y1-y3)*(y1-y3);
                ll len3=(x2-x3)*(x2-x3)+(y2-y3)*(y2-y3);
                if(len1+len2>=len3 && len1+len3>=len2){
                    ll res=0;
                    ll gcd1=gcd(abs(x1-x2),abs(y1-y2));
                    res+=gcd1;
                    ll gcd2=gcd(abs(x1-x3),abs(y1-y3));
                    res+=gcd2;
                    ll gcd3=gcd(abs(x3-x2),abs(y3-y2));
                    res+=gcd3;
                    ans=max(ans,res);
                    
                }
            }
        }
    }
    cout<<ans<<endl;
    return 0;
}