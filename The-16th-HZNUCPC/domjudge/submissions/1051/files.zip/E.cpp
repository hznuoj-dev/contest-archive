#include<bits/stdc++.h>
#define int long long
using namespace std;
struct node{
	int x,y;
}p[200];
int check(int p1,int p2,int p3){
	int ans=0;
	if((p[p3].x-p[p1].x)*(p[p3].y-p[p2].y)==(p[p3].x-p[p2].x)*(p[p3].y-p[p1].y))
	{
		return 0; 
	}
	ans=ans+abs(__gcd(p[p3].x-p[p2].x,p[p3].y-p[p2].y))-1;
	ans=ans+abs(__gcd(p[p3].x-p[p1].x,p[p3].y-p[p1].y))-1;
	ans=ans+abs(__gcd(p[p1].x-p[p2].x,p[p1].y-p[p2].y))-1;
	ans+=3ll;
	return ans;
}
void solve(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>p[i].x>>p[i].y;
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				ans=max(ans,check(i,j,k));
			}
		}
	}
	cout<<ans<<'\n';
}
signed main(){
	int t;
	t=1;
	while(t--){
		solve();
	}
}