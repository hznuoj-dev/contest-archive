#include<iostream>
#include<cstring>
#include<algorithm>
#include<stack>
#include<queue>
#include<cmath>
#define endl '\n'
using namespace std;
const int N=1e6+10,INF=2e9;
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int,int> PII; 
struct node{
	double x,y;
};
struct node a[N];
double f(node x,node y){
	return (x.y-y.y)/(x.x-y.x);
}
int gcd(int a,int b){
	if(a<b) swap(a,b); 
	if(b==0) return a;
	else return gcd(b,a%b);
}
int cal(node x,node y){
	int xx=x.x,yy=y.y,xy=x.y,yx=y.x;
	return gcd(abs(yy-xy),abs(yx-xx))+1;
}
int judge(node x,node y,node z){
	int t=0;
	if(f(x,y)==f(x,z)) return -1;
	t=cal(x,y)+cal(y,z)+cal(x,z);
	return t-3;
}
void solve(void){
	int n,ans=0;
	cin>>n;
	for(int i=0;i<n;i++) cin>>a[i].x>>a[i].y;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			for(int k=j+1;k<n;k++){
				int t;
				t=judge(a[i],a[j],a[k]);
				if(t!=-1) ans=max(ans,t);
			}
		}
	}
	cout<<ans;
}
int main(void){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int TT;
	TT=1;
	//cin>>TT;
	while(TT--){
		solve();
	}
	return 0;
}