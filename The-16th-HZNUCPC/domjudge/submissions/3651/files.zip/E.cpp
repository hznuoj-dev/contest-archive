#include <iostream>
#include<cmath>
using namespace std;
typedef long long ll;
const int N = 105;
double x[N],y[N],a[N];
double b;
ll q[N][N];
ll gcd(ll a,ll b){
	if(!b)return a;
	return gcd(b,a%b);
}
ll fabs(ll a){
	if(a<0)return -a;
	return a;
}
ll jisuan(ll x1,ll y1,ll x2,ll y2){
	x2-=x1,y2-=y1;x2=fabs(x2);y2=fabs(y2);
	double k = 1.0*x2/y2;
	ll t=gcd(x2,y2);
	double xx=1.0*x2/t,yy=1.0*y2/t;
	double dw=sqrt(1.0*xx*xx+1.0*yy*yy);
	double l=sqrt(1.0*y2*y2+1.0*x2*x2);
	ll num=l/dw-1;
//	if(x1==1)cout<<l<<" yy "<<dw<<endl;
	return num;
}
ll max(ll a,ll b){
	return a>b?a:b;
}
bool check(int i,int j,int k){
	if((x[i]-x[j])/(y[i]-y[j])!=(x[i]-x[k])/(y[i]-y[k]))return 0;
	return 1;
}
ll maxx=-1;
int main()
{
	int n;
	cin >> n;
	for(int i = 1; i <= n; i++)
	{
		cin>>x[i]>>y[i];
	}
	for(int i = 1; i <= n; i++)
	{
		for(int j = i + 1;j <= n;j ++){
			q[i][j]=q[j][i]=jisuan(x[i],y[i],x[j],y[j]);
		}
	}
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=n;j++)cout<<q[i][j]<<' ';
//		cout<<endl;
//	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				if(check(i,j,k))continue;
				else{
					maxx=max(maxx,q[i][j]+q[i][k]+q[k][j]+3);
				}
			}
		}
	}
	cout<<maxx;
	return 0;
}