#include<bits/stdc++.h>
using namespace std;

const int maxn = 5e3+5;
int n; //original length
char s[maxn];
char ss[maxn*2];

void init() {
	for (int i = 1; i <= 2 * n + 10; i++) {
		ss[i] = ' ';
	}
}
int f(int x, int len) {
	if(ss[x] == '#') return (len)/2;
	return len/2;
}
char dif[10];
void solve(){
	scanf("%s", s + 1);
	n = strlen(s + 1);
	init();
	int l = 1;
	ss[l++] = '#';
	for(int i = 1;i <= strlen(s + 1); i++) {
		ss[l++] = s[i];
		ss[l++] = '#';
	}
	int ans=0;
	for(int c = 1;c < l;c++){
		//printf("%c\n", ss[c]);
		// debug
		//puts("here is the ss: ");
		//puts(ss + 1);
		int x = 1;
		int diff = 0;
		int tmp = 1;
		int ttmp;
		int flag = 0;
		while(1){
			if(c - x <= 0 || c + x >= l) {
				if (diff != 1){
					ttmp = f(c, tmp);
					if(ttmp != 1) {
						ans = max(ans, ttmp);
					}
				}
				else{
					if(flag){
						ans = max(ans, tmp/2);
					}
				}
				break;
			}
			tmp += 2;
			if(ss[c - x] != ss[c + x]) {
				diff++;
				if(diff == 1) {
					if(ss[c] == ss[c - x] || ss[c] == ss[c + x]){
						flag = 1;
						ttmp = f(c, tmp+2);
						if(ttmp != 1) ans = max(ans, ttmp);
					}
					else{
						ttmp = f(c, tmp - 2);
						if(ttmp != 1) ans = max(ans, ttmp);
					}
					dif[1] = ss[c - x];
					dif[2] = ss[c + x];
				}
				if(diff == 2) {
					dif[0] = ss[c-x];
					dif[3] = ss[c+x];
					if(dif[1] == dif[3] && dif[2] == dif[0]) {
						ttmp = f(c,tmp);
						if(ttmp != 1) ans = max(ans, ttmp);
					}
					else{
						if(flag){
							ans = max(ans, tmp/2-1);
						}
						break;
					}
				}
				if(diff == 3) {
					ttmp = f(c,tmp-2);
					if(ttmp != 1) ans = max(ans, ttmp);
					break;
				}
			}
			x++;
		}
	}
	printf("%d\n", ans);
	
}
int main() {
	int t;
	scanf("%d", &t);
	while(t--){
		solve();
	}
}