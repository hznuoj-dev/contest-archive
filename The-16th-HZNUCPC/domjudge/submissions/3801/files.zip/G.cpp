#include<bits/stdc++.h>
using namespace std;
#define N 100010
#define rep(i,l,r) for(int i=(l);i<=(r);i++)
using ll =long long ;

int n,fa[N],m,goods,sz[N];
int Find(int x){return fa[x]==x?x:fa[x]=Find(fa[x]);}
vector<pair<int,int>> e;
vector<int> g[N];
void merge(int u,int v){
    int px=Find(u),py=Find(v);
    if(px==py)return;
    fa[px]=py;
    sz[py]+=sz[px];
}

bool vis[N];vector<int> xxx[N];
int cnt[2],col[N],a[N],b[N],pp;
void dfs(int u,int x){
    xxx[pp].push_back(u);
    col[u]=x;
    cnt[col[u]]+=sz[u];
    vis[u]=1;
    for(int v:g[u]){
        if(vis[v]==0)dfs(v,x^1);
        else{
            if(col[v]==x){
                puts("NO");
                exit(0);
            }
        }
    }
}

//bitset<100010> tmp,dp[100010],gg,h,f;

int choose[N];

int c[N],w[N],t[N],CNT[N];
vector<int> _in[N];
int dp[450][N];
vector<int> yyy[N];
void solve(){
    scanf("%d%d%d",&n,&goods,&m);
    rep(i,1,n)fa[i]=i,sz[i]=1;
    rep(i,1,m){
        int o,u,v;
        scanf("%d%d%d",&o,&u,&v);
        if(o==0){
            merge(u,v);
        }else{
            e.push_back({u,v});
        }
    }
    for(auto [u,v]:e){
        if(Find(u)==Find(v)){
            puts("NO");
            return;
        }
        g[Find(u)].push_back(Find(v));
        g[Find(v)].push_back(Find(u));
        //printf("%d %d\n",Find(u),Find(v));
    }
    rep(i,1,n)_in[Find(i)].push_back(i);
    m=0;
    rep(i,1,n){
        if(Find(i)!=i)continue;
        if(vis[i])continue;
        cnt[0]=cnt[1]=0;
    pp=i;
        dfs(i,0);
        a[++m]=cnt[0];
        b[m]=cnt[1];
        c[m]=i;

        //for(int u:xxx[i])printf("%d ",u);puts("");
    }
    int sum=0;
    rep(i,1,m)if(a[i]<b[i])choose[i]=0,sum+=a[i],w[i]=b[i]-a[i];else choose[i]=1,sum+=b[i],w[i]=a[i]-b[i];
    sum=goods-sum;
    if(sum<0){puts("NO");return;}

    vector<pair<int,int>> tmp;
    rep(i,1,m)tmp.push_back({w[i],i});
    sort(tmp.begin(),tmp.end());
    int T=1;t[1]=(*tmp.begin()).first;CNT[1]=1;yyy[t[1]].push_back((*tmp.begin()).second);
    auto it=tmp.begin();++it;
    for(;it!=tmp.end();++it){
        int x=(*it).first,y=(*it).second;

        if(x==t[T])++CNT[T],yyy[t[T]].push_back(y);
    else{
        ++T;
        t[T]=x;
        yyy[t[T]].push_back(y);
        CNT[T]=1;
    }
    }
    rep(i,1,T){
        //printf("%d %d %d\n",i,t[i],CNT[i]);
        //printf("%d\n",(int)yyy[t[i]].size());
    }

    memset(dp,-1,sizeof(dp));
    dp[0][0]=0;
    rep(i,1,T){
        rep(j,0,T)if(dp[i-1][j]!=-1){
            rep(k,0,CNT[i]){
                dp[i][j+k*t[i]]=k;
            }
        }
    }
    if(dp[T][sum]==0){puts("NO");return;}
    else{
        puts("YES");
        for(int i=T,j=sum;i>0;){
            int k=dp[i][j];
            auto it=yyy[t[i]].begin();
            for(int o=1;o<=k;++o){
                assert(it!=yyy[t[i]].end());
                choose[(*it)]^=1;
                ++it;
            }

            --i,j-=k*t[i];
        }
    }

    rep(i,1,m){
                for(int u:xxx[c[i]])if(col[u]==choose[i]){
                    for(int x:_in[u])printf("%d ",x);
                }
    }
}

int main() {
    //freopen("in.txt","r",stdin);
    int t=1;
    while(t--)solve();
	return 0;
}
