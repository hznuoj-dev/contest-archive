#include<bits/stdc++.h>
using namespace std;

long long x[105];
long long y[105];

long long gcd(long long a,long long b)
{
	return b==0?a:gcd(b,a%b);
}

long long cal(int a,int b)
{
	int xx=abs(x[a]-x[b]);
	int yy=abs(y[a]-y[b]);
	if(xx==0)
	{
		return yy-1;
	}
	if(yy==0)
	{
		return xx-1;
	}
	if(yy%xx==0)
	{
		return xx-1;
	}
	int g=gcd(xx,yy);
	return max(0,xx/g-1);
}

double side(int a,int b)
{
	long long xx=abs(x[a]-x[b]);
	long long yy=abs(y[a]-y[b]);
	return sqrt(xx*xx+yy*yy);
}

bool san(int a,int b,int c)
{
	double aa=side(a,b);
	double bb=side(b,c);
	double cc=side(a,c);
	if(aa+bb>cc||aa+cc>bb||bb+cc>aa)
	{
		return true;
	}
	return false;
}

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	
	long long n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>x[i]>>y[i];
	}
	long long ans=0;
	for(int i=1;i<n-1;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				if(san(i,j,k))
				{	
//					cout<<i<<" "<<j<<" "<<k<<"\n";
//					cout<<cal(i,j)<<" "<<cal(i,k)<<" "<<cal(j,k)<<"\n";
					ans=max(ans,cal(i,j)+cal(i,k)+cal(j,k)+3);
				}
			}
		}
	}
	cout<<ans<<"\n";
	
	
}