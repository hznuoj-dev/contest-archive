#include<bits/stdc++.h>
using namespace std;
struct BUS{
	int t,l,r;
}a[100050];
struct TANG{
	int t,p,id;
}c[100050];
struct T{
	int mi,ad,l,r;
}t[2000050];
int n,m,x,b[1000050],ans[100050];
bool cmp1(BUS a,BUS b)
{
	if(a.t!=b.t)return a.t>b.t;
	return a.r>b.r;
//	return a.t>b.t;
}
bool cmp2(TANG a,TANG b)
{
	return a.t>b.t;
}
void build(int l,int r,int p)
{
	t[p].l=l;
	t[p].r=r;
	t[p].mi=1000000;
	if(l<r)
	{
		int mid=(l+r)/2;
		build(l,mid,2*p);
		build(mid+1,r,2*p+1);
	}
}
void down(int p)
{
	if(t[p].ad==0)return;
	t[2*p].ad=t[p].ad;
	t[2*p].mi=t[p].ad;
	t[2*p+1].ad=t[p].ad;
	t[2*p+1].mi=t[p].ad;
	t[p].ad=0;
}
int query(int x,int p)
{
	down(p);
	if(t[p].l==t[p].r)
	{
		return t[p].mi;
	}
	int mid=(t[p].l+t[p].r)/2;
	if(x<=mid)return query(x,2*p);
	return query(x,2*p+1);
}
int getPos(int x,int p)
{
	down(p);
	if(t[p].l==t[p].r)return t[p].l;
	if(t[2*p].mi<=x)return getPos(x,2*p);
	return getPos(x,2*p+1);
}
void update(int l,int r,int x,int p)
{
	if(l>r)return;
	down(p);
	if(l==t[p].l&&r==t[p].r)
	{
		t[p].mi=t[p].ad=x;
		return;
	}
	int mid=(t[p].l+t[p].r)/2;
	if(r<=mid)update(l,r,x,2*p);
	else if(l>mid)update(l,r,x,2*p+1);
	else update(l,mid,x,2*p),update(mid+1,r,x,2*p+1);
	t[p].mi=min(t[2*p].mi,t[2*p+1].mi);
}
int main(){
	srand(time(NULL));
	int alb=rand()%7;
	assert(alb!=0);
	cin>>n>>m>>x;
	b[++b[0]]=x;
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&a[i].t,&a[i].l,&a[i].r);
		b[++b[0]]=a[i].l;
		b[++b[0]]=a[i].r;
	}
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d",&c[i].t,&c[i].p);
		b[++b[0]]=c[i].p;
		c[i].id=i;
	}
	sort(b+1,b+b[0]+1);
	b[0]=unique(b+1,b+b[0]+1)-b-1;
	x=lower_bound(b+1,b+b[0]+1,x)-b;
	for(int i=1;i<=n;i++)
	{
		a[i].l=lower_bound(b+1,b+b[0]+1,a[i].l)-b;
		a[i].r=lower_bound(b+1,b+b[0]+1,a[i].r)-b;
	}
	for(int i=1;i<=m;i++)
	{
		c[i].p=lower_bound(b+1,b+b[0]+1,c[i].p)-b;
	}
	build(1,b[0],1);
//	for(int i=1;i<=b[0];i++)printf("%d ",query(i,1));
//	puts("");
	update(b[0],b[0],0,1);
//	for(int i=1;i<=b[0];i++)printf("%d ",query(i,1));
//	puts("");
	int bp=1;
	int tp=1;
	sort(a+1,a+n+1,cmp1);
	sort(c+1,c+m+1,cmp2);
	for(int i=100000;i;i--)
	{
		while(bp<=n&&a[bp].t>=i)
		{
			int mi=query(a[bp].r,1);
			if(mi>n)
			{
				bp++;
				continue;
			}
			int pos=getPos(mi,1);
			update(a[bp].l,pos-1,mi+1,1);
//			printf("UPD: %d %d %d\n",a[bp].l,pos-1,mi+1);
			bp++;
		}
		while(tp<=m&&c[tp].t>=i)
		{
			ans[c[tp].id]=query(c[tp].p,1);
			tp++;
//			for(int i=1;i<=b[0];i++)printf("%d ",query(i,1));
//			puts("");
		}
	}
	for(int i=1;i<=m;i++)if(ans[i]>n)ans[i]=-1;
	for(int i=1;i<=m;i++)printf("%d\n",ans[i]);
	return 0;
}
