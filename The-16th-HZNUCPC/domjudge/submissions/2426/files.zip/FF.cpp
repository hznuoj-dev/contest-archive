#include<iostream>
#include<cstdio>
#include<cstring>
#include<cstdlib>
#include<string>
#include<cctype>
#include<vector>
#include<set>
using namespace std;
#define debug(a) cout<<#a<<"="<<a<<"\n";
#define rep(i,a,b) for(int i=(a),__##i##__=(b);i<=__##i##__;i++)
#define dwn(i,a,b) for(int i=(a),__##i##__=(b);i>=__##i##__;i--)
#define int ll
typedef long long ll;
typedef unsigned long long ull;
signed main()
{
	int n;
	int m;
	cin>>n>>m;
	if(m==1)
	{
		cout<<"YES\n";
		return 0;	
	}
	if(n%2 && n%m != 0)cout<<"YES\n";
	else cout<<"NO\n";
	return 0;
}
