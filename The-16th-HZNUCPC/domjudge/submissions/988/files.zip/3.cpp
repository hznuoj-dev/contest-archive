#include<bits/stdc++.h>
using namespace std;
#define int long long

void solve(){
    int n, m;  cin>>n>>m;
    if(n==1){
        cout<<"YES\n";
    }else if(m==1){
        cout<<"YES\n";
    }else{
        int t = 0;
        for(int i = 2 ; i*i <= n; i++){
            if(n%i==0){
                t = i;
                break;
            }
        }
        if(t==0){
            t = n;
        }
        if(t > m){
            cout<<"YES\n";
        }else{
            cout<<"NO\n";
        }
    }
}
signed main(){
    int T=1;  //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}


