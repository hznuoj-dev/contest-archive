#include<iostream>
#include<utility>
#include<algorithm>
#include<vector>
#include<map>
#define int __int128
#define endl '\n'
using namespace std;
const int N=100009;
typedef pair<int,int>pii;
signed n,m;
pii dta[N];
map<vector<pii>,int>mp;
int gcd(int a,int b)
{
	return b==0?a:gcd(b,a%b);
}
vector<pii> minpre(vector<pii>&a)
{
	int i=0,j=1,k=0,t,n=a.size();
	while(i<n&&j<n&&k<n)
		if(a[(i+k)%n]!=a[(j+k)%n])
		{
//			cout<<i<<" "<<j<<" "<<k<<endl;
			if(a[(i+k)%n]>a[(j+k)%n])
				i+=k+1;
			else
				j+=k+1;
			if(i==j)j++;
			k=0;
		}
		else
			k++;
	if(i>j)swap(i,j);
	vector<pii>vec;
	for(int u=i; u<i+n; u++)
		vec.push_back(a[u%n]);
	return vec;
}
signed main(void)
{
	//freopen("in.txt","r",stdin);
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin>>n;
	vector<pii>vec;
	vector<pii>vec2;
	__int128 x1,y1,x2,y2,v1,v2,g;
	signed x,y;
	for(int i=0; i<n; i++)
	{
		cin>>m;
		for(int j=0; j<m; j++)
		{
			cin>>x>>y;
			dta[j]=pii(x,y);
		}
		vec.clear();
		for(int j=0; j<m; j++)
		{

			x1=dta[(j+1)%n].first-dta[j].first;
			y1=dta[(j+1)%n].second-dta[j].second;
			x2=dta[(j+2)%n].first-dta[(j+1)%n].first;
			y2=dta[(j+2)%n].second-dta[(j+1)%n].second;
			v1=x1*x2+y1*y2;
			int op=v1>0?1:-1;
			v1=v1*v1;
			v2=(x1*x1+y1*y1)*(x2*x2+y2*y2);
			g=gcd(v1,v2);
			v1/=g;
			v2/=g;
			v1*=op;
			vec.emplace_back(v1,v2);

		}
		vec2=minpre(vec);
		cout<<(long long)mp[vec2]<<endl;
		mp[vec2]++;
		
	//	for(auto [x,y]:vec2)
	//		cout<<x<<" "<<y<<endl;
		//	cout<<endl;
		
	}

	return 0;
}
