#include<bits/stdc++.h>

using namespace std;

#define int long long
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

using ll = long long;

const int N = 1e5+10;
const int M = 1e9+7;

void solve(){
	ll n,m;
	cin>>n>>m;
	
	if(!(n%m)&&m!=1){
		cout<<"NO\n";
	}
	else{
		int x=m;
		
		while(n%x!=0){
			x=n%x;
//			if(n%x==0){
//				cout<<"NO\n";
//				break;
		//}
		
		
		}
		
		if(x==1) cout<<"YES\n";
		else cout<<"NO\n";
	}
}

signed main(){
	IOS;
	
	int t;
	//cin>>t;
	t=1;
	
	while(t--){
		solve();
	}
	
	return 0;
}