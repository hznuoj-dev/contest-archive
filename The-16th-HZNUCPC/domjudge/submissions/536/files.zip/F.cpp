#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
// #define DEBUG

int main() {
	
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);

	ll n,m;
	cin>>n>>m;

	if(n==1||m==1) cout<<"YES\n";
	else if(n<=m) cout<<"NO\n";
	else{
		while (m!=1&&m!=0){
			m=n%m;
		}
		if (m==1){
			cout<<"YES\n";
		}
		else{
			cout<<"NO\n";
		}
	}

    return 0;
}