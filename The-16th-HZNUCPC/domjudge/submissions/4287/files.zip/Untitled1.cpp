#include <bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 10;
struct node	{
	int l, r, t;
}a[maxn];
struct n1	{
	int c, p, id, ans;
}pp[maxn];
int w[maxn], w1[maxn], c[maxn], p[maxn];
bool cmp(node x, node y)	{
	return x.t < y.t;
}
bool cmp1(n1 x, n1 y)	{
	return x.c < y.c;
}
int main()	{
	//memset(w, 0x3f, sizeof(w));
	int n, m, x;
	scanf("%d%d%d", &n, &m, &x);
	for (int i = 1; i <= n; i++)	{
		scanf("%d%d%d", &a[i].t, &a[i].l, &a[i].r);
	}
	for (int i = 1; i <= m; i++)	{
		scanf("%d%d", &pp[i].c, &pp[i].p);
		pp[i].id = i;
	}
	sort(pp + 1, pp + m + 1, cmp1);
	sort(a + 1, a + n + 1, cmp);
	w[n + 1] = x, w[n + 2] = 0x3f3f3f3f;
	int p = n, q = m;
	a[n + 1].t = a[n].t;
	while (pp[q].c > a[n].t)	pp[q].ans = -1, q--;
	while (p)	{
		do	{
			if (w[p + 1] > a[p].r)	w[p] = min(w[p], (int)(1e9 + 10));
			int k = upper_bound(w + 1, w + n + 3, a[p].r) - w - 1;
			w[p] = (w[p] == 0 ? a[p].l : min(w[p], a[p].l));
			w1[p] = w1[k] + 1;
			--p;
		}	while(a[p].t == a[p + 1].t && p >= 1);
		if (w[p + 1] >= w[p + 2])	w[p + 1] = w[p + 2], w1[p + 1] = w1[p + 2];
		while (pp[q].c > a[p].t && q > 0)	{
			int k = upper_bound(w + 1, w + n + 2, pp[q].p) - w - 1;
			if (k <= p)	pp[q].ans = -1;
			else	pp[q].ans = w1[k];
			//printf("%d %d %d\n", p, pp[q].id, k);
			q--;
		}
	}
	int out[maxn];
	for (int i = 1; i <= m; i++)	out[pp[i].id] = pp[i].ans;
	for (int i = 1; i <= m; i++)
		printf("%d\n", out[i]);
}