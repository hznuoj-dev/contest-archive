#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef long double ll2;
const ll mode = 1e9 + 7;
const ll N = 1e6 + 7;
ll t, n, x[N], y[N],m;
void solve(){
	
return;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
    cin>>n>>m;
    if(n==1||m==1){
    	cout<<"YES";
	}else if(n>m&&n&1==1){
		for(ll i=2;i<=min(m,10000000ll);i++){
			if(n%i==0){
				cout<<"NO";
				return 0;
			}
		}
		cout<<"YES";
	}else{
		cout<<"NO";
	}
return 0;
}