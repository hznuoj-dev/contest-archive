#include<bits/stdc++.h>
using namespace std;
#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const int maxn=1e5+10;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
#define int long long

string s1,s2;
int da[30],db[30];
int lk[30][30];
int qpow(int x,int y){
	int ans=1;
	while(y){
		if(y%2)ans=(ans*x)%mod;
		y>>=1;
		x=x*x%mod;
	}
	return ans;
}
void resolve(){
	int sum1=0,sum2=0,sum=0;
	cin>>s1;
	cin>>s2;
	s1=' '+s1;
	s2=' '+s2;
	int n=s1.length()-1;
	for(int i=1;i<=n;i++){
		lk[s1[i]-'a'][s2[i]-'a']++;
		da[s1[i]-'a']++;
		if(da[s1[i]-'a']==1)sum1++;
		db[s2[i]-'a']++;
		if(db[s2[i]-'a']==1)sum2++;
	}
	for(int l1=0;l1<26;l1++){
		for(int r1=0;r1<26;r1++){
			if(lk[l1][r1]<=0)continue;
			for(int l2=l1;l2<26;l2++){
				for(int r2=r1;r2<26;r2++){
					if(lk[l2][r2]<=0||(l1==l2&&r1==r2&&lk[l1][r1]<=1))continue;
					if(l1==l2&&r1==r2){
						
						da[l1]--,da[l2]--,db[r1]--,db[r2]--;
						da[r1]++,da[r2]++,db[l1]++,db[l2]++;
						sum1=sum2=0;
						for(int i=0;i<26;i++){
							if(da[i])sum1++;
							if(db[i])sum2++;
						}
						if(sum1==sum2){
							//cout<<l1<<" "<<l2<<" "<<r1<<" "<<r2<<endl;
							sum=(sum+lk[l1][r1]*(lk[l1][r1]-1)%mod*qpow(2,mod-2)%mod)%mod;
							//cout<<sum<<endl;
						}
						da[l1]++,da[l2]++,db[r1]++,db[r2]++;
						da[r1]--,da[r2]--,db[l1]--,db[l2]--;
					}
					else{
						da[l1]--,da[l2]--,db[r1]--,db[r2]--;
						da[r1]++,da[r2]++,db[l1]++,db[l2]++;
						sum1=sum2=0;
						for(int i=0;i<26;i++){
							if(da[i])sum1++;
							if(db[i])sum2++;
						}
						if(sum1==sum2){
							//cout<<l1<<" * "<<l2<<" "<<r1<<" "<<r2<<endl;
							sum=(sum+lk[l1][r1]*lk[l2][r2]%mod)%mod;
							//cout<<sum<<endl;
						}
						da[l1]++,da[l2]++,db[r1]++,db[r2]++;
						da[r1]--,da[r2]--,db[l1]--,db[l2]--;
					}
				}
			}
		}
	}
	cout<<sum<<endl;
}
signed main(){
	fast;
	int _=1;
	//cin>>_;
	while(_--){
		resolve();
	}
}