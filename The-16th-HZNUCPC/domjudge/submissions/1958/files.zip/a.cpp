#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
using namespace std;
const int n=19,N=30,dx[4]={0,0,1,-1},dy[]={1,-1,0,0};
int m,a[N][N];
void work() {
	cin>>m;
	For(i,1,n) For(j,1,n) a[i][j]=-1;
	while(m--) {
		int x,y,w;
		cin>>x>>y>>w;
		a[x][y]=w;
	}
	int ans=0;
	For(i,1,n) For(j,1,n) if(a[i][j]==1) {
		For(k,0,3) {
			int x2=i+dx[k],y2=j+dy[k];
			if(a[x2][y2]==-1)++ans;
		}
	}
	cout<<ans<<"\n";
}
int main() {
#ifdef LOCAL
    freopen(".in","r",stdin);
#endif
    ios::sync_with_stdio(0); cin.tie(0);
    int T;cin>>T;
	while(T--) work();
}