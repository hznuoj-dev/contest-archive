#include <bits/stdc++.h>

#define dbg(x...) \
    do { \
        std::cout << #x << " -> "; \
        err(x); \
    } while (0)

void err() {
    std::cout << std::endl;
}

template<class T, class... Ts>
void err(T arg, Ts &... args) {
    std::cout << arg << ' ';
    err(args...);
}

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using i128 = __int128;

void run(int tCase) {
    int n;
    std::cin >> n;
    using p = std::pair<int, int>;
    std::vector<p> v(n);
    for (auto &[x, y]: v) {
        std::cin >> x >> y;
    }
    auto line = [&](int i, int j) {
        int dx = v[i].first - v[j].first;
        int dy = v[i].second - v[j].second;
        int g = std::gcd(dx, dy);
        dx /= g, dy /= g;
        if (dx < 0) {
            dx *= -1;
            dy *= -1;
        }
        return std::make_pair(dx, dy);
    };
    auto calc = [&](int i, int j) {
        int dx = v[i].first - v[j].first;
        int dy = v[i].second - v[j].second;
        int g = std::gcd(dx, dy);
        return std::abs(g);
    };
    int ans = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            if (v[i] == v[j]) continue;
            for (int k = j + 1; k < n; ++k) {
                if (v[i] == v[k] or v[j] == v[k]) continue;
                if (line(i, j) == line(i, k)) continue;
                int t = 0;
                t += calc(i, j);
                t += calc(j, k);
                t += calc(i, k);
                ans = std::max(ans, t);
            }
        }
    }
    std::cout << ans << '\n';
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int T = 1;
//    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        run(t);
    }
    return 0;
}