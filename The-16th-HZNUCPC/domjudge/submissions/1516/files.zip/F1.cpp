#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll n,m;
bool check(ll a)
{
    if(a==1  ||  m==1)return true;
    if(a<=m)return false;

    for(ll i=2;i*i<=a;i++)
    {
        while(a%i==0)
        {
            if(i<=m)return false;
            a=a/i;
        }
    }
    if(a!=1&&a<=m)return false;
    return true;
}
int main()
{
    scanf("%lld%lld",&n,&m);
    if(check(n))
    {
        printf("YES\n");
    }
    else
    {
        printf("NO\n");
    }
}
