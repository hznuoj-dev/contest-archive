#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
struct DSU
{
    vector<int>f,siz;
    DSU (int n):f(n),siz(n,1) {iota(f.begin(),f.end(),0); }
    int leader (int x)
    {
        while (x != f[x])
        {
            x = f[x] = f[f[x]];
        }
        return x;
    }
    bool same (int x,int y)
    {
        return leader(x) == leader(y);
    }
    bool merge (int x,int y)
    {
        x = leader(x);
        y = leader(y);
        if (x == y) return false;
        if (x < y)
            f[y] = x;
        else
            f[x] = y;
        return true;
    }
    int size(int x) { return siz[leader(x)];}
};
vector<int>ha[maxn],co[maxn];
int dp[maxn];
pii pre[maxn];
struct node
{
    int sz,ct;
}p[maxn];
int main ()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    //cin >> tt;
    while (tt--)
    {
        int n,m,q;
        cin >> n >> q >> m;
        DSU g(n*2+1);
        int pd = 1;
        for (int i = 1; i <= m; ++i)
        {
            int op,a,b;
            cin >> op >> a >> b;
            if (op == 0)
            {
                if (!g.same(a,b+n) && !g.same(a+n,b))
                {
                    g.merge(a,b);
                    g.merge(a+n,b+n);
                }
                else
                {
                    pd = 0;
                }
            }
            else
            {
                if (!g.same(a+n,b+n) && !g.same(a,b))
                {
                    g.merge(a+n,b);
                    g.merge(a,b+n);
                }
                else
                {
                    pd = 0;
                }
            }
        }
        if (pd)
        {
            for (int i = 1; i <= n; ++i)
            {
                ha[g.leader(i)].push_back(i);
            }
            int tot = 0;
            for (int i = 1; i <= n; ++i)
            {
                if (ha[i].size() > 0)
                {
                    int sz = ha[i].size();
                    co[sz].push_back(i);
                }
            }
            dp[0] = 1;
            int gs = 0;
            for (int i = 1; i <= n; ++i)
            {
                int ns = co[i].size();
                int ne = 1;
                while (ne <= ns)
                {
                    ns -= ne;
                    p[++gs] = {i,ne};
                    ne *= 2;
                }
                if (ns > 0)
                {
                    p[++gs] = {i,ns};
                }
            }
            for (int i = 1; i <= gs; ++i)
            {
                int gx = p[i].ct * p[i].sz;
                for (int j = q; j >= gx; --j)
                {
                    if (dp[j-gx])
                    {
                        dp[j] = 1;
                        pre[j] = {j-gx,i};
                    }
                }
            }
            if (dp[q])
            {
                cout << "YES\n";
                while (q > 0)
                {
                    int np = pre[q].second;
                    q = pre[q].first;
                    for (int i = 1; i <= p[np].ct; ++i)
                    {
                        int pp = co[p[np].sz].back();
                        co[p[np].sz].pop_back();
                        for (auto it:ha[pp])
                        {
                            cout << it << ' ';
                        }
                    }
                }
                cout << "\n";
            }
            else
            {
                cout << "NO\n";
            }
        }
        else{
            cout << "NO\n";
        }
    }

}
/*
4 2 4
1 1 3
1 2 4
0 3 4
0 1 2
*/
