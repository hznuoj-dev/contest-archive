#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,k;
	while(cin>>n>>m){
//		bool flag =true;
//		if(n<m)flag =false;
//		while(m!=1){
//			if(n%m==0){
//				flag = false;
//				break;
//			}
//			k= n%m;
//			m=  k%m;
//	
//		}
		if(n%2 == m%2 ||m==1||n==1){
			cout <<"YES"<<endl;
		}else{
			cout <<"NO"<<endl;
		}
	}
	return 0;
}