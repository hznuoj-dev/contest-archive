
import java.util.*;
public class Main 
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
//		int t=30;
//		while (t-->0)
//		{
//			Random x=new Random();
//			long y=-1;
//			long z=-1;
//			while(y<=0||z<=0)
//			{
//				y=x.nextInt(1000);
//				z=x.nextInt(1000);
////			}
//			System.out.println(y+" "+z);
//			long n=y;
//			long m=z;
//			int f=0;
//			while(m>=1)
//			{
//				if(m>=n)
//				{
//					f=1;
//					break;
//				}
//				if(n%m==0)
//				{
//					f=1;
//					break;
//				}
//				else
//				{
//					m=n%m;
//				}
//			}
//			System.out.println(m==1||n==1||f==0?"YES":"NO");
//		}
				long n=sc.nextLong();
				long m=sc.nextLong();
				int f=0;
				while(m>=1)
				{
					if(m>=n)
					{
						f=1;
						break;
					}
					if(n%m==0)
					{
						f=1;
						break;
					}
					else
					{
						m=n%m;
					}
				}
				System.out.println(f==0||m==1||n==1?"YES":"NO");	
	}	
	
}