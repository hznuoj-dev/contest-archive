#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
const int mod=1e9+7;
#define int long long
string s1,s2;
int vis1[30],vis2[30];
int len;
int cnt1=0,cnt2=0;
typedef pair<int,int>P;
int a[30][30];
vector<P>g;
signed main(){
	cin>>s1>>s2;
	int n=s1.size();
	for(int i=0;i<n;i++){
		if(!vis1[s1[i]-'a']){
			cnt1++;	
		}
		vis1[s1[i]-'a']++;
	}
	for(int i=0;i<n;i++){
		if(!vis2[s2[i]-'a']){
			cnt2++;	
		}
		vis2[s2[i]-'a']++;
	}	
	for(int i=0;i<n;i++){
		a[s1[i]-'a'][s2[i]-'a']++;
	} 
	if(abs(cnt1-cnt2)>=5){
		printf("0\n");
	}else{
		for(int i=0;i<=25;i++){
			for(int j=0;j<=25;j++){
				g.push_back({i,j});
			}
		}
		int ans=0;
		for(int i=0;i<g.size();i++){
			for(int j=i;j<g.size();j++){
				int c1=cnt1,c2=cnt2;
				int a1=g[i].first;
				int a2=g[i].second;
				int b1=g[j].first;
				int b2=g[j].second;
				
				if(!a[a1][a2]||!a[b1][b2]) continue;
				//c1
				if(vis1[a1]==1){
					c1--;
				}
				vis1[a1]--;
				if(vis1[b1]==1){
					c1--;
				}
				vis1[b1]--;
				if(!vis1[a2]){
					c1++;
				}
				vis1[a2]++;
				if(!vis1[b2]){
					c1++;
				}
				vis1[b2]++;
				
				vis1[a1]++,vis1[b1]++,vis1[a2]--,vis1[b2]--;
				
				//c2
				if(vis2[a2]==1){
					c2--;
				}
				vis2[a2]--;
				if(vis2[b2]==1){
					c2--;
				}
				vis2[b2]--;
				if(!vis2[a1]){
					c2++;
				}
				vis2[a1]++;
				if(!vis2[b1]){
					c2++;
				}
				vis1[b1]++;
				
				vis2[a2]++,vis2[b2]++,vis2[a1]--,vis1[b1]--;
				
				if(c1==c2){
					if(i==j) ans=(ans+a[a1][a2]*(a[a1][a2]-1)/2%mod)%mod;
					else ans=(ans+a[a1][a2]*a[b1][b2]%mod)%mod;
				}
				//cout<<a1<<" "<<a2<<" "<<b1<<" "<<b2<<" "<<ans<<endl;
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
}
