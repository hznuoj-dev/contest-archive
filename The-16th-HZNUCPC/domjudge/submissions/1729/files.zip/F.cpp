#include<iostream>
#include<cstring>
using namespace std;
int main(){
	long long n,m;
	cin>>n>>m;
	while(m>1){
		m=n%m;
	}
	if(m==0)puts("NO");
	else cout<<"YES";
	return 0;
}