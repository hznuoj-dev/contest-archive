#include<bits/stdc++.h>
using namespace std;
int a[20][20];
int dx[]={0,-1,0,1},dy[]={1,0,-1,0};
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n,ans=0;
		cin>>n;
		for(int i=1;i<=n;i++){
			int x,y,c;
			cin>>x>>y>>c;
			if(c==1){
				if(a[x][y]==1) ans--;
				a[x][y]=2;
				for(int j=0;j<4;j++){
					if((a[x+dx[j]][y+dy[j]]==0||a[x+dx[j]][y+dy[j]]==1)&&x+dx[j]>=1&&x+dx[j]<=19&&y+dy[j]>=1&&y+dy[j]<=19) ans+=1,a[x+dx[j]][y+dy[j]]=1;
				}
			}else if(c==2){
				if(a[x][y]==1) ans--;
				a[x][y]=3;
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}