#include <iostream>
using namespace std;

long long ispre[20000000];
long long pre[10000000];
int main(){
	long long  ep = 1;
	for(long long  i = 2 ;i<=20000000;i++){
		if(ispre[i]==0){
			pre[ep] = i ;
			ep++ ;
			for(long long j = i;j <=20000000;j+=i){
				ispre[j] = 1 ;
			}
		}
	}
	int m , n;
	cin>> n >> m ;
	if(m >= n &&(n!=1 && m !=1)){
		cout << "NO";
		return 0 ;
	}else if (m==1||n==1){
		cout << "YES";
		return 0 ;
	}else{
		for(long long i = 1 ; i <ep ; i ++){
			if(n %pre[i]==0 &&pre[i]!=n && m >= pre[i]){
				cout <<"NO";
				return 0;
			}else{
				cout << "YES";
				return 0 ;
			}
			
		}
	}

}