#include<bits/stdc++.h>

using namespace std;

const int N = 20;

pair<int, int> pxy[4] = {{1, 0}, {0, 1}, {0, -1}, {-1, 0}};

int mp[N][N], v[N][N], p[400];

bool check(int x, int y) {
	if (mp[x][y] == 1 && x >= 1 && x <= 19 && y >= 1 && y <= 19)
		return 1;
	else return 0;
}
bool check2(int x, int y) {   //shifoubeichi
	for (auto [dx, dy] : pxy) {
		int xx = x + dx, yy = y + dy;
		if (xx < 1 || xx > 19 || yy < 1 || yy > 19) continue;
		if (mp[xx][yy] == 0) return false;
	}
	return true;
}

void dfs(int i, int j, int cnt) {
	v[i][j] = cnt;
	for (auto [dx, dy] : pxy) {
		if (check(i + dx, j + dy) && v[i + dx][j + dy] == 0) 
			dfs(i + dx, j + dy, cnt);
	}
}

signed main() {
	int t;
	cin >> t;
	while (t --) {
		memset(mp, 0, sizeof mp);
		memset(v, 0, sizeof v);	
		memset(p, 0, sizeof p);	
		int n; cin >> n;
		for (int i = 1; i <= n; i ++) {
			int x, y, w;
			cin >> x >> y >> w;
			mp[x][y] = w;
		}
		int cnt = 0;
		for (int i = 1; i <= 19; i ++) {
			for (int j = 1; j <= 19; j ++) {
				if (!v[i][j] && mp[i][j] == 1) 
					dfs(i, j, ++cnt);
			}
		}
		for (int i = 1; i <= 19; i ++) {
			for (int j = 1; j <= 19; j ++) {
				if (v[i][j]) 
					if (!check2(i, j)) 
						p[v[i][j]] = 1;//meibeichi
			}
		}
//		for (int i = 1; i <= 19; i ++) {
//			for (int j = 1; j <= 19; j ++) {
//				cout << p[v[i][j]] << ' ';
//			}
//			cout << '\n';
//		}
		int sum = 0;
		for (int i = 1; i <= 19; i ++) {
			for (int j = 1; j <= 19; j ++) {
				if (mp[i][j] == 1 && p[v[i][j]] == 1) 
				//cout << i << ' ' << j << '\n';
					for (auto [dx, dy] : pxy) {
						int x = i + dx, y = j + dy;
						if (x < 1 || x > 19 || y < 1 || y > 19) continue;
						if (mp[x][y] == 0) {
							//cout << i << ' ' << j << ' ' << x << ' ' << y << '\n';
							sum ++; 
						}
					}
			}
		}
		cout << sum << '\n';
	}
	
}
/*
1
2
1 1 1 
2 2 1
*/