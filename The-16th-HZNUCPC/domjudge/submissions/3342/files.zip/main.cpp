#include<bits/stdc++.h>
#define ft first
#define sd second
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
#define rep(i,a,b) for(ll i=a;i<=b;++i)
using namespace std;
string s;
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin>>t;
    while(t--){
        string s;
        cin>>s;
        int n=s.length();
        s=' '+s;
        vector<int>ji(n+1);
        vector<int>ou(n+1);
        // cal ji
        vector<int>cnt(27);
        int shipei;
        rep(i,1,n){
            int jishu=0;
            shipei=0;
            rep(i,0,26) cnt[i]=0;
            int l=i,r=i;
         //   cout<<l<<" "<<r<<endl;
            while(1){
                l--,r++;
                if(l<1||r>n) break;
           //    cout<<l<<":"<<r<<endl;

                int sl=s[l]-'a';
                int sr=s[r]-'a';
                cnt[sl]++;
            //    cout<<cnt[sl]<<" "<<cnt[sr]<<endl;
                if(cnt[sl]&1) jishu++;
                else jishu--;
                cnt[sr]++;
                if(cnt[sr]&1) jishu++;
                else jishu--;

          //      cout<<jishu<<endl;

                if(s[l]!=s[r]) shipei++;
                if(shipei==0) ji[i]=max(ji[i],r-l+1);
                if(shipei==2&&jishu==0) ji[i]=max(ji[i],r-l+1);
                if(jishu==2&&shipei==1){
                    if(cnt[s[i]-'a']&1) ji[i]=max(ji[i],r-l+1);
                }
                if(l==1||r==n||shipei>2) break;
            }
        }
        rep(i,1,n-1){
            int jishu=0;
            shipei=0;
            rep(i,0,26) cnt[i]=0;
            int l=i,r=i+1;
             int sl=s[l]-'a';
            int sr=s[r]-'a';
            cnt[sl]++;
               if(cnt[sl]&1) jishu++;
                else jishu--;
                cnt[sr]++;
                if(cnt[sr]&1) jishu++;
                else jishu--;
            if(s[l]!=s[r]) shipei++;
            while(1){
                l--,r++;
                 if(l<1||r>n) break;
                 sl=s[l]-'a';
                sr=s[r]-'a';
                cnt[sl]++;
               if(cnt[sl]&1) jishu++;
                else jishu--;
                cnt[sr]++;
                if(cnt[sr]&1) jishu++;
                else jishu--;

                if(s[l]!=s[r]) shipei++;
                if(shipei==0) ou[i]=max(ou[i],r-l+1);
                if(shipei==2&&jishu==0) ou[i]=max(ou[i],r-l+1);
                if(l==1||r==n||shipei>2) break;
            }
        }
        int ans=0;
        rep(i,1,n) {
            ans=max(ans,ji[i]);
   //     cout<<ji[i]<<" ";
        }
        rep(i,1,n-1){
        ans=max(ou[i],ans);
        }
    cout<<ans<<"\n";
    }
}
