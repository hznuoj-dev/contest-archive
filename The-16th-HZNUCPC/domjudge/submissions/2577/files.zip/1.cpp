#include<bits/stdc++.h>
using namespace std;
#define int long long
#define aa first
#define bb second
const int mod = 1000000007;
int n;
int h1[30], h2[30];
map<pair<char, char>, int> mp;
int kd1, kd2;
int Qpow(int x, int k) {
    int res = 1;
    while (k) {
        if (k % 2) res = (res * x) % mod;
        x = (x * x) % mod;
        k >>= 1;
    }
    return res;
}
void solve(){
    string s1,s2;
    cin >> s1 >> s2;
    n = s1.length();
    for (auto v: s1) {
        if (h1[v - 'a'] == 0) kd1 ++;
        h1[v - 'a'] ++;
    }
    for (auto v: s2) {
        if (h2[v - 'a'] == 0) kd2 ++;
        h2[v - 'a'] ++;
    }

    for (int i = 0; i < s1.length(); i ++ ) {
        mp[{s1[i], s2[i]}] ++;
    }
    int res = 0LL;
    for (int a1 = 0; a1 <= 25; a1 ++ ) {
        for (int a2 = 0; a2 <= 25; a2 ++ ) {
            for (int b1 = 0; b1 <= 25; b1 ++ ) {
                for (int b2 = 0; b2 <= 25; b2 ++ ) {
                    if (h1[a1] == 0 || h1[a2 ] == 0 || h2[b1 ] == 0 || h2[b2 ] == 0) continue;

                    char ca1 = a1 + 'a', ca2 = a2 + 'a', cb1 = b1 + 'a', cb2 = b2 + 'a';
                    if (mp[{ca1, cb1}] == 0 || mp[{ca2, cb2}] == 0) continue;
                    int temp;

                    if (a1 == a2 && b1 == b2) {
                        temp = mp[{ca1, cb1}] * (mp[{ca1, cb1}] - 1) % mod;
                    } else {
                        temp = mp[{ca1, cb1}] * mp[{ca2, cb2}] % mod;
                    }

                    int ht1[30], ht2[30], kdt1 = kd1, kdt2 = kd2;

                    memcpy(ht1, h1, sizeof h1);
                    memcpy(ht2, h2, sizeof h2);

                    ht1[a1] --;
                    ht2[a1] ++;
                    if (ht1[a1] == 0) kdt1 --;
                    if (ht2[a1] == 1) kdt2 ++;
                    ht1[a2] --;
                    ht2[a2] ++;
                    if (ht1[a2 ] == 0) kdt1 --;
                    if (ht2[a2 ] == 1) kdt2 ++;
                    ht2[b1 ] --;
                    ht1[b1 ] ++;
                    if (ht2[b1 ] == 0) kdt2 --;
                    if (ht1[b1 ] == 1) kdt1 ++;
                    ht2[b2 ] --;
                    ht1[b2 ] ++;
                    if (ht2[b2 ] == 0) kdt2 --;
                    if (ht1[b2] == 1) kdt1 ++;

                    if (kdt1 == kdt2) {
                        res = (res + temp) % mod;
                    }
                }
            }
        }
    }
    cout << res * Qpow(2, mod - 2) % mod << '\n';
}
signed main(){
    int T = 1;
    solve();
    return 0;
}

//aaaaaaaaaaaaaaeweqweabbbbbbbbbbbbb
//aaaaaaaaaaaaaaaaaaaaabbbbbbbbbbbbb
