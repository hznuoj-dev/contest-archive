#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mode = 1e9 + 7;
const ll N = 1e6 + 7;
ll t, n, a[N],m;
string s1,s2;
void solve(){
	
return;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
//    cin>>t;
//    while(t != 0){
//    	t--;
//    	solve();
//	}
	cin>>s1>>s2;
	ll ts=s1[s1.size()-1]-'0';
	if((s1.size()==1&&s1[s1.size()-1]-'0'==1)||(s2.size()==1&&s2[s2.size()-1]-'0'=='1')||(ts&1==1&&s1>s2)){
		cout<<"YES";
	}else{
		cout<<"NO";
	}
	
return 0;
}