#include<bits/stdc++.h>
#define int long long
#define rep(i,a,n) for(int i=a;i<n;i++)
#define per(i,a,n) for(int i=n-1;i>=a;i--)
#define fi first 
#define se second
#define pb push_back
#define endl '\n'
#define pair<int,int> pii
#define vii vector<pair<int,int>>

using namespace std;
int g[22][22];
int dx[]={1,-1,0,0},dy[]={0,0,-1,1};
void solve(){
	int n;cin>>n;
	rep(i,1,n+1){
		int t;
		int x,y;cin>>x>>y>>t;
		if(t==1) g[x][y]=1;
		else g[x][y]=2;
	}
	int ans=0;
	rep(i,1,20){
		rep(j,1,20){
			if(g[i][j]==1){
				rep(k,0,4){
					int x=i+dx[k];int y=j+dy[k];
					if(x>=1&&x<=19&&y>=1&&y<=19&&g[x][y]==0){
						ans++;
					}
				}
			}
		}
	}cout<<ans<<endl;
}
signed main(){
	int t;cin>>t;
	while(t--){
		solve();
	}
	return 0;
}