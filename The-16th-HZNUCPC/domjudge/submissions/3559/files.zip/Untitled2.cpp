#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;
typedef long long ll;

string s;

int J(int l){

	int MAx=0;
	string rem=s;
	
	//jishu
	for(int i=1;i<l-1;i++){
		
		int cnt=1;
		int flag=0;
		
		for(int j=1;i-j>=0&&i+j<=l;j++){
			if(s[i-j]==s[i+j]){
				cnt+=2;
			}
			else{
				if(i-j-1>=0&&i+j+1<=l&&flag==0){
					if(s[i-j-1]==s[i+j]&&s[i+j+1]==s[i-j]){
						cnt+=4;
						flag=1;
						j++;
					}
				}
			}
		}
		
		if(cnt==1){
			cnt = 0;
		}
		
		MAx=max(MAx,cnt);
		
	}
	
	//oushu
	for(int i=1;i<l-1;i++){
		
		int cnt=2;
		int flag=0;
		
		for(int j=1;i-j>=0&&i+1+j<=l-1;j++){
			if(s[i-j]==s[i+1+j]&&s[i]==s[i+1]){
				cnt+=2;
			}
			else if(s[i]==s[i+1]){
				if(i-j-1 >= 0 && i+1+j+1<=l && flag == 0){
					if(s[i-j-1]==s[i+1+j]&&s[i+1+j+1]==s[i-j]){
						cnt+=4;
						flag=1;
						j++;
					}
				}
			}
		}
		
		if(cnt==2){
			cnt = 0;
		}
		
		
		MAx=max(MAx,cnt);
		
	}
	
	for(int i=1;i<l;i++){
		if(s[i-1]==s[i]){
			MAx=max(2,MAx);
			break;
		}
	}
	
	
	return MAx;
	
}

void solve(){
	
	bool f=1;
	
	cin>>s;
	
	int l=s.length();
	
	if(l==1){
		f=0;
	}else{
		
		cout<<J(l);
		
	}
	

	
	//system("pause");
}

int main(){
	
	int t = 1;
	cin >> t;
	while(t--){
		solve();
	}
	
	return 0;
}