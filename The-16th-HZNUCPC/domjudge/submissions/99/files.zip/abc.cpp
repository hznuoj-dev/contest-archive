#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using pt = complex<long long>;
#define x real()
#define y imag()
#define int ll
int point_covered(pt a, pt b) {
	assert(a != b);
	if (a.x == b.x) {
		return abs(a.y - b.y) - 1;
	}
	if (a.y == b.y) {
		return abs(a.x - b.x) - 1;
	}
	
	return __gcd(abs(a.y - b.y), abs(a.x - b.x)) - 1;
}

int cross(pt a, pt b) {
	return a.x * b.y - a.y * b.x;
}

int same_line(pt a, pt b, pt c) {
	return cross(b - a, c - a) == 0;
}

signed main() {
	int n;
	cin >> n;
	vector<pt> a(n);
	for (int i = 0; i < n; ++i) {
		int _x, _y;
		cin >> _x >> _y;
		a[i] = {_x, _y};
	}
	int res = 0;
	for (int i = 0; i < n; ++i) {
		for (int j = i + 1; j < n; ++j) {
			for (int k = j + 1; k < n; ++k) {
				if (a[i] == a[j] || a[i] == a[k] || a[j] == a[k]) continue;
				if (!same_line(a[i], a[j], a[k])) {
					int cnt = 3 + point_covered(a[i], a[j])
						+ point_covered(a[j], a[k])
						+ point_covered(a[i], a[k]);
					res = max(res, cnt);
				}
			}
		}
	}
	cout << res << "\n";
}

/*
4
0 0
1 1
2 4
4 2

4
1 1
2 2
3 3
2 4
*/