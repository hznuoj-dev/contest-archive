#include <bits/stdc++.h>
#define endl '\n' 

using namespace std;

int dx[] = {1, -1, 0, 0};
int dy[] = {0, 0, 1, -1};

signed main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	
	int T;
	cin >> T;
	
	while (T--){
		int n;
		std::cin >> n;
		int mp[25][25];
		memset(mp, 0, sizeof (mp));
		for (int i = 0;i < n; i++) {
			int x, y, c;
			std::cin >> x >> y >> c;
			mp[x][y] = c;
		}
		int ans = 0;
		for (int i = 1; i <= 19; i++) {
			for (int j = 1; j <= 19; j++) {
				if (mp[i][j] != 1) continue;
				for (int k = 0; k < 4; k ++) {
					int xx = dx[k] + i;
					int yy = dy[k] + j;
					if (xx < 1 || xx > 19 || yy < 1 || yy > 19 || mp[xx][yy]) continue;
					ans++;
				}		
			}
		}
		std::cout << ans << "\n";
	}
	
	return 0;
}