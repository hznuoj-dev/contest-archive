#include<bits/stdc++.h>
using namespace std;

int main()
{
	long long n,m;
	cin>>n>>m;
	if(m==1||n==1)
	{
		cout<<"YES";
		return 0;
	}
	
	long long temp;
	while (true)
	{
		temp = n%m;
		if (temp == 1){
			cout<<"YES";
			break;
		}
		if(temp == 0){
			cout<<"NO";
			break;
		}
		m  = temp;
	}
	return 0;
}