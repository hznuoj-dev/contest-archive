package oj;

import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		long caipan = in.nextLong();
		long num = in.nextLong();
		long m = Math.max(caipan, num) % Math.min(caipan,num);
		boolean f = true;
		if(num == 1 || caipan == 1){
			f = false;
			System.out.println("YES");
		}
		while(f){
			if(m == 0){
				System.out.println("NO");
				break;
			}else if(m == 1){
				System.out.println("YES");
				break;
			}else if(m > 1){
				m = Math.max(caipan, num) % m;
		    }
	    }
	}
}
