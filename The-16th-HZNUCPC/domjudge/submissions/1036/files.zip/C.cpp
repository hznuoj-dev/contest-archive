#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int maxn = 1e5 + 10;

ll n, m, w[26][26][26][26], e[26][26], cnt1[26], cnt2[26];

const ll mod = 1e9 + 7;

ll ksm(ll x, ll y){
	ll res = 1;
	while(y){
		if(y & 1) res = res * x % mod;
		y >>= 1;
		x = x * x % mod;
	}
	return res;
}

ll inv(ll x){
	return ksm(x, mod-2);
}

ll mul(ll x, ll y){
	return x * y % mod;
}

ll add(ll x, ll y){
	return (x + y) % mod;
}

string s1, s2;

int main() {
	ios::sync_with_stdio(false);
	
	ll INV2 = inv(2);
	
	cin >> s1 >> s2;
	int len = s1.length();
	set<int> sa, sb;
	for(int i = 0; i < len; i++){
		int c1 = s1[i] - 'a';
		int c2 = s2[i] - 'a';
		for(int j = 0; j < 26; j++){
			for(int k = 0; k < 26; k++){
				w[c1][c2][j][k] = add(w[c1][c2][j][k], e[j][k]);
			}
		}
		sa.insert(c1);
		sb.insert(c2);
		cnt1[c1]++;
		cnt2[c2]++;
		e[c1][c2]++;
	}
	int siz_a = sa.size();
	int siz_b = sb.size();
	ll ans = 0;
	for(int a = 0; a < 26; a++){
		for(int b = 0; b < 26; b++){
			for(int c = 0; c < 26; c++){
				for(int d = 0; d < 26; d++){
//					if(a == c && b == d) continue;
					int tmp_siz_a = siz_a, tmp_siz_b = siz_b;
					
					cnt1[a]--;
					if(cnt1[a] == 0) tmp_siz_a--;
					if(cnt1[b] == 0) tmp_siz_a++;
					cnt1[b]++;
					
					cnt1[c]--;
					if(cnt1[c] == 0) tmp_siz_a--;
					if(cnt1[d] == 0) tmp_siz_a++;
					cnt1[d]++;
					
					cnt2[b]--;
					if(cnt2[b] == 0) tmp_siz_b--;
					if(cnt2[a] == 0) tmp_siz_b++;
					cnt2[a]++;
					
					cnt2[d]--;
					if(cnt2[d] == 0) tmp_siz_b--;
					if(cnt2[c] == 0) tmp_siz_b++;
					cnt2[c]++;
					
					if(tmp_siz_b == tmp_siz_a){
//						if(a == c && b == d){
//							if(e[a][b] >= 2){
//								ans = add(ans, e[a][b] * (e[a][b]));
//							}
//						}
//						else 
						ans = add(ans, w[a][b][c][d]);
					}
					
					cnt1[a]++;
					cnt1[b]--;
					cnt1[c]++;
					cnt1[d]--;
					
					cnt2[a]--;
					cnt2[b]++;
					cnt2[c]--;
					cnt2[d]++;
				}
			}
		}
	}
//	for(int a = 0; a < 26; a++){
//		for(int b = 0; b < 26; b++){
//			if(e[a][b] <= 1) continue;
//			int tmp_a = siz_a, tmp_b
//			if(cnt1[a])
//			ll tot = e[a][b] * (e[a][b] - 1) % mod * INV2 % mod;
//			ans = add(ans, tot);
//		}
//	}
	cout << ans << '\n';
	
	return 0;
}