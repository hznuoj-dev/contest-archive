#include <bits/stdc++.h>
#define lc ls[p]
#define rc rs[p]
using namespace std;
const int maxn=3e5+5,maxm=maxn<<1;
int n,m,L,rt,ans[maxn];
struct ad{
	int t,l,r;
	bool operator<(const ad&c)const{return t>c.t||t==c.t&&r>c.r;}
}a[maxn];
struct st{
	int t,x,id;
	bool operator<(const st&c)const{return t>c.t;}
}b[maxn];
struct seg{
	int num,ls[maxm],rs[maxm],mi[maxm],lz[maxm];
	void build(int&p,int l,int r){
		p=++num;mi[p]=2e9;lz[p]=2e9;
		if (l==r) return;
		int mid=(l+r)>>1;
		build(lc,l,mid);build(rc,mid+1,r);
	}
	void pushdown(int p){
		if (lz[p]<2e9){
			lz[lc]=min(lz[p],lz[lc]);mi[lc]=min(mi[lc],lz[p]);
			lz[rc]=min(lz[p],lz[rc]);mi[rc]=min(mi[rc],lz[p]);
			lz[p]=2e9;
		}
	}
	void update(int p,int l,int r,int x,int y,int z){
		if (x<=l&&r<=y){
			mi[p]=min(mi[p],z);
			lz[p]=min(lz[p],z);
			return;
		}
		int mid=(l+r)>>1;
		pushdown(p);
		if (x<=mid) update(lc,l,mid,x,y,z);
		if (y>mid) update(rc,mid+1,r,x,y,z);	
	}
	int query(int p,int l,int r,int x){
		if (l==r){return mi[p];}
		int mid=(l+r)>>1;
		pushdown(p);
		if (x<=mid) return query(lc,l,mid,x);
		return query(rc,mid+1,r,x);
	}
}T;
inline void solve() {
	scanf("%d%d%d",&n,&m,&L);
	vector<int> p;
	for (int i=1;i<=n;++i) scanf("%d%d%d",&a[i].t,&a[i].l,&a[i].r);
	for (int i=1;i<=m;++i) {scanf("%d%d",&b[i].t,&b[i].x);b[i].id=i;}
	
	for (int i = 1; i <= n; i++) p.push_back(a[i].l), p.push_back(a[i].r);
	for (int i = 1; i <= m; i++) p.push_back(b[i].x);

	sort(p.begin(), p.end());
	p.erase(unique(p.begin(), p.end()), p.end());
	
	for(int i = 1; i <=n ; i++) 
		a[i].l = lower_bound(p.begin(), p.end(), a[i].l) - p.begin() + 1,
		a[i].r = lower_bound(p.begin(), p.end(), a[i].r) - p.begin() + 1;
	for(int i = 1; i <=m ; i++) 
		b[i].x = lower_bound(p.begin(), p.end(), b[i].x) - p.begin() + 1;
	L=p.size();
	sort(a+1,a+1+n);
	sort(b+1,b+1+m);
	T.build(rt,1,L);
	T.update(rt,1,L,L,L,0);
	int j=1;
	while (b[j].t>a[1].t){
		ans[b[j].id]=T.query(rt,1,L,b[j].x);
		++j;
	}
	for (int i=1;i<=n;++i){
		int t=T.query(rt,1,L,a[i].r);
		if (t<2e9){
			T.update(rt,1,L,a[i].l,a[i].r,t+1);
		}
		while (b[j].t<=a[i].t&&b[j].t>a[i+1].t){
			ans[b[j].id]=T.query(rt,1,L,b[j].x);
			++j;
		}
	}
	while (j<=m) ans[b[j].id]=T.query(rt,1,L,b[j].x),++j;
	for (int i=1;i<=m;++i) printf("%d\n",ans[i]==2e9?-1:ans[i]);
}

int main(){
	solve();
	return 0;
}