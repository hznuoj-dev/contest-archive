#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll check(ll x){
	if(x==1) return 1;
	for(ll i=2;i*i<=x;i++) if(x%i==0) return i;
	return 1e12+5;
}
int main(){
	ll a,b; scanf("%lld%lld",&a,&b);
	if(b==1||a==1) puts("YES");
	else if(a<=b) puts("NO");
	else if(b<check(a)) puts("YES");
	else puts("NO");
}
