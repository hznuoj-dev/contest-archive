#include<bits/stdc++.h>
using namespace std;
const int N = 22;
int n;
bool st[N][N];

struct Node{
	int x,y;
};

int dx[] = {-1,0,1,0};
int dy[] = {0,1,0,-1};

void solve(){
	memset(st,false,sizeof st);
	cin>>n;
	vector<Node> vec; 
	for(int i=0;i<n;i++){
		int x,y,c;cin>>x>>y>>c;
		st[x][y] = true;
		if(c==1)vec.push_back({x,y});
	}
	int res = 0;
	for(int i=0;i<(int)vec.size();i++){
		auto [x,y] = vec[i];
		for(int j=0;j<4;j++){
			int u = x + dx[j] , v = y + dy[j];
			if(u>=1&&u<=19&&v>=1&&v<=19&&!st[u][v])
				res++;
		} 
	}
	cout << res << endl; 
}

int main(){
	int t;cin>>t;
	while(t--)solve(); 
	return 0;
}
