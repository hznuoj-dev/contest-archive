#include <bits/stdc++.h>
#define ln '\n'

int main() {
	long long a, b;
	std::cin >> a >> b;
	std::cout << (std::__gcd(a, b) == 1 ? "YES\n" : "NO\n");
}