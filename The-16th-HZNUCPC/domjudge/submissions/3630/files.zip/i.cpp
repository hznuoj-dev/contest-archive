#include <bits/stdc++.h>
using namespace std;
using i64 = long long;

void solve(){
	string s;cin>>s;
	int ans=1;
	for(int i=1;i<s.size()-1;i++){
		int m=1,m0=1;
		int f=1;
		int a,b;
		for(int j=1;i+j<s.size()&&i-j>=0;j++){
			if(s[i-j]==s[i+j])
				m+=2;	
			else if(f==1&&i+j+1<s.size()&&i-j-1>=0){
				f++;
				a=s[i-j];
				b=s[i+j];
				m0=m;
				m+=2;
			}
			else if(f==2){
				if(a==s[i-j]&&b==s[i+j]||a==s[i+j]&&b==s[i-j])
					m+=2;
				else{
					if(s[i]==s[i-j]||s[i]==s[i+j])
						m+=2;
					m=m0;
					break;
				}	
				f++;
			}
			else if(s[i]==s[i-j]||s[i]==s[i+j])
				m+=2;
			else
				break;
		}
		
		ans=max(ans,m);
	}
	for(int i=0;i<s.size()-1;i++){
		int m=1,m0=1;
		if(s[i]!=s[i+1])
			continue;
		m=2,m0=2;
		int f=1;
		int a,b;
		for(int j=1;j+i+1<s.size()&&i-j>=0;j++){
			if(s[i-j]==s[i+1+j])
				m+=2;
			else if(f==1&&i+j+2<s.size()&&i-j-1>=0){
				f++;
				a=s[i-j];
				b=s[i+1+j];
				m0=m;
				m+=2;
			}
			else if(f==2){
				if(a==s[i-j]&&b==s[i+1+j]||a==s[i+1+j]&&b==s[i-j])
					m+=2;
				else{
					m=m0;
					break;
				}
				f++;
			}
			else
				break;
		}
		ans=max(ans,m);
	}
	if(ans==1)
		ans=0;
	cout<<ans<<endl;
}	
	


int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int T=1;
	cin >> T;

	while(T --)
		solve();
	return 0;
}
