#include <iostream>
using namespace std;
int main()
{
    long long int n,m,l;
    cin>>n>>m;
    while(1)
    {
    	l=n%m;
    	if(l==0)
    	{
    		cout<<"NO";
    		break;
		}
    	else if(l==1)
    	{
    		cout<<"YES";
    		break;
		}
		else
		{
			m=l;
		}
	}
	
    return 0;
}