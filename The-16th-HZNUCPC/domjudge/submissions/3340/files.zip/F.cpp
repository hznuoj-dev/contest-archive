#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll min(ll x, ll y){
	if(x < y) return x;
	return y;
}
bool is_prime(ll x,ll m){
	ll len = min(sqrt(x), m);
	for (ll i=2;i <= len;i++){
		if (x%i==0){
			return false;
		}
	}
	return true;
}
int main(){
	ll  n,m;
	while(cin>>n>>m){
		if(n > m && is_prime(n, m)){
			cout << "YES" << endl;
		}else{
			cout << "N0" << endl;
		}
	}
	return 0;
}
