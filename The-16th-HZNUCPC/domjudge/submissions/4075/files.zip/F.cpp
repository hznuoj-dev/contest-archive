#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
signed main(){
	while(cin>>n>>m){
		if(n==1||m==1){
			cout<<"NO"<<endl;
		}else {
			int f=0;
			int t=m;
			while(m){
				if(n%m==1){
					f=1;
					break;
				}
				m=n%m;
				if(m==t){
					break;
				}
				t=m;
			}
			if(f)cout<<"YES"<<endl;
			else cout<<"NO"<<endl;
		}
	}
	return 0;
}