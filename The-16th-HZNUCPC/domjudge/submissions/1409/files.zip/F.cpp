#include <bits/stdc++.h>
#define ll long long

using namespace std;


int main(){
	ll n,m;
	cin>>n>>m;
	if(n%2)cout<<"Yes";
	else cout<<"No";
	
	
}