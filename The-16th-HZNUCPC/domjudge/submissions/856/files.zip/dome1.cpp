#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    ll n,m;
    cin>>n>>m;
    if(m==1) 
    {
        cout<<"YES"<<endl;
        return 0;
    }
    while(1)
    {
        m=n%m;
        if(m==1) 
        {
            cout<<"YES"<<endl;
            break;
        }
        if(m==0)
        {
            cout<<"NO"<<endl;
            break;
        }
    }
    return 0;
}