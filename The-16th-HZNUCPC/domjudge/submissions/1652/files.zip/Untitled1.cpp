#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 7;
int n,m;
struct node {
	int x,y;
}a[110];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int T;
	T = 1;
	while(T --){
		cin >> n;
		for(int i = 0; i < n ; i ++){
			cin >> a[i].x >> a[i].y;
		}
		int ans = 0;
		for(int i = 0; i < n - 2; i ++)
			for(int j = i + 1; j < n - 1; j ++)
				for(int k = j + 1; k < n; k ++){
					/*int xy, ny, dy;
					pair<int,int> v[3];
					v[0] = make_pair(a[i].y, i);
					v[1] = make_pair(a[j].y, j);
					v[2] = make_pair(a[k].y, k);
					sort(v, v + 3);
					ny = v[0].second;
					dy = v[1].second;
					xy = v[2].second;
					node k[3] = {a[i].x - a[j].x, a[i].y - a[j].y};*/
					int res  = 0;
					int u[3] = {i, j, k};
					for(int p = 0; p < 2; p ++)
						for(int q = p + 1; q < 3; q ++){
							node k;
							k.x = abs(a[u[p]].x - a[u[q]].x);
							k.y = abs(a[u[p]].y - a[u[q]].y);
							int w = __gcd(k.x,k.y);
							if(k.x && k.y)res += abs((k.x + (k.x / w) - 1)/ (k.x / w)) + 1;
							else if(k.x) res += k.x + 1;
							else res += k.y + 1;
						}
					res -= 3;
					ans = max(res,ans);
				}
		cout << ans << endl;
	}
}