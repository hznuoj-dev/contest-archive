#include<bits/stdc++.h>
using namespace std;
#define N 100010
#define rep(i,l,r) for(int i=(l);i<=(r);i++)
using ll =long long ;

int n,fa[N],m,goods,sz[N];
int Find(int x){return fa[x]==x?x:fa[x]=Find(fa[x]);}
vector<pair<int,int>> e;
vector<int> g[N];
void merge(int u,int v){
    int px=Find(u),py=Find(v);
    if(px==py)return;
    fa[px]=py;
    sz[py]+=sz[px];
}

bool vis[N];vector<int> xxx[N];
int cnt[2],col[N],a[N],b[N],pp;
void dfs(int u,int x){
    xxx[pp].push_back(u);
    col[u]=x;
    cnt[col[u]]+=sz[u];
    vis[u]=1;
    for(int v:g[u]){
        if(vis[v]==0)dfs(v,x^1);
        else{
            if(col[v]==x){
                puts("NO");
                exit(0);
            }
        }
    }
}

bitset<100001> tmp,dp[100001],gg,h,f;

int c[N];
vector<int> _in[N];
void solve(){
    scanf("%d%d%d",&n,&goods,&m);
    rep(i,1,n)fa[i]=i,sz[i]=1;
    rep(i,1,m){
        int o,u,v;
        scanf("%d%d%d",&o,&u,&v);
        if(o==0){
            merge(u,v);
        }else{
            e.push_back({u,v});
        }
    }
    for(auto [u,v]:e){
        if(Find(u)==Find(v)){
            puts("NO");
            return;
        }
        g[Find(u)].push_back(Find(v));
        //printf("%d %d\n",Find(u),Find(v));
    }
    rep(i,1,n)_in[Find(i)].push_back(i);
    m=0;
    rep(i,1,n){
        if(Find(i)!=i)continue;
        if(vis[i])continue;
        cnt[0]=cnt[1]=0;
    pp=i;
        dfs(i,0);
        a[++m]=cnt[0];
        b[m]=cnt[1];
        c[m]=i;

        //for(int u:xxx[i])printf("%d ",u);puts("");
    }
    //rep(i,1,m)printf("%d %d\n",a[i],b[i]);
    f[0]=1,dp[0]=f;
    rep(i,1,m){
        gg=(f<<a[i]);
        h=(f<<b[i]);
        f|=gg,f|=h;
        dp[i]=f;
    }
    if(f[goods]==0)puts("NO");
    else{
        puts("YES");
        //rep(i,1,n)if(f[i]==1)printf("%d ",i);puts("");
        int cur=goods;
        for(int i=m;i>=1;--i){
                //printf("cur=%d\n",cur);
        if(cur==0)break;
            if(cur-a[i]>=0&&dp[i-1][cur-a[i]]==1){
                //printf("%d ",a[i]);
                for(int u:xxx[c[i]])if(col[u]==0){
                        for(int x:_in[u])printf("%d ",x);
                }
                cur-=a[i];
            }else if(cur-b[i]>=0&&dp[i-1][cur-b[i]]==1){
                //printf("%d ",b[i]);
                cur-=b[i];
                for(int u:xxx[c[i]])if(col[u]==1){
                    for(int x:_in[u])printf("%d ",x);
                }
            }else{
                //exit(0);
                assert(0);
            }
        }


    }
}

int main() {
    //freopen("in.txt","r",stdin);
    int t=1;
    while(t--)solve();
	return 0;
}
