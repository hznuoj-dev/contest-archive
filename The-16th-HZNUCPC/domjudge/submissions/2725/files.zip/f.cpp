#include<iostream>
#include<algorithm>
using namespace std;
const int MAXN=110;
int A[MAXN][MAXN],F[MAXN][MAXN],N;
int dfs(int x,int y)
{
	if (F[x][y] == -1)
	{
		if (x == N)F[x][y] = A[x][y];
		else F[x][y] = A[x][y]+max(dfs(x+1,y),dfs(x+1,y+1));
	}
	return F[x][y];
}
int main()
{
	cin >> N;
	for (int i = 1;i<=N;i++)
	{
		for (int j =1;j)
	}
}
