#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,k,t;
	while(cin>>n>>m){
		k= m;
		if(n==1 ||m==1){
			cout <<"YES"<<endl;
		}else if(n <m){
			cout <<"NO"<<endl;
			
		}else{
			while(k>1){
				long long t;
				t = n%k;
//				cout <<"more ticks"<<t<<endl;
				k = t;
			}
//			cout <<"k is:"<<k<<endl;
			if(k==1){
				cout <<"YES"<<endl;
			}else{
				cout <<"NO"<<endl;
			}
		}
		
	}
	return 0;
}