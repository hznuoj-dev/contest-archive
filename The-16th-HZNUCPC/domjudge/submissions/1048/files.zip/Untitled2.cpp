#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
//	int t;
//	cin>>t;
//	while(t--){
		ll n,m,x;
		cin>>n>>m;
		if(n<=m) cout<<"NO\n";
		else{
			int flag=0;
			while(1){
				x=n%m;
				if(x==1){
					flag=1;break;
				}
				else if(x==0){
					break;
				}
				else{
					m=x;
				}
			}
			if(flag) cout<<"YES\n";
			else cout<<"NO\n";
		}
//	}
	return 0;
}