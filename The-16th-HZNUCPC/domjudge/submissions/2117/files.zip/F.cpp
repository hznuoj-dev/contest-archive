#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,k,t;
	while(cin>>n>>m){
		k= m;
		bool flag = true;
		if(n==1||m==1){
			flag = true;
		}else{
			if(n<m){
				flag =false;
			}
			while(k!=1 &&flag){
				t = n%k;
				if(k==0 || t==0){
					flag = false;
					break;
				}
				t= t%k;
				k = t;

			}
		}
		
		if(flag){
			cout <<"YES"<<endl;
		}else{
			cout <<"NO"<<endl;
		}
		
	}
	return 0;
}