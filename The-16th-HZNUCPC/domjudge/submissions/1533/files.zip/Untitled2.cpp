#include<bits/stdc++.h>
using namespace std;
#define dzs ios::sync_with_stdio(false);cin.tie(nullptr),cout.tie(nullptr)
typedef long long ll;
int main()
{
	int t=1;
	while(t--)
	{
		ll n,m;
		cin>>n>>m;
		while(1)
		{
			m=n%m;
			if(m==1)
			{
				cout<<"YES"<<endl;
				break;
			}
			if(m==0)
			{
				cout<<"NO"<<endl;
				break;
			}
		}
	}
} 