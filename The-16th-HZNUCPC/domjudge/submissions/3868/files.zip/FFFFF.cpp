#include<iostream>
#include<string>
using namespace std;
#define mol 10000007
void swap(char &a,char &b)
{
	char t;
	t=a;
	a=b;
	b=t;
}
int main()
{
	string s1;
	string s2;
	cin>>s1>>s2;
	int i,j;
	int cnt=0;
	for(i=0;i<s1.size();i++)
	{
		for(j=0;j<s1.size();j++)
		{
			if(i==j)
			continue;	
			string s3=s1;
			string s4=s2;
			swap(s1[i],s2[i]);
			swap(s1[j],s2[j]);
			if((s1==s3&&s2==s4)||(s2==s3&&s1==s4))
			{
				cnt++;
				cnt%=mol;
			}
			swap(s1[i],s2[j]);
			swap(s1[j],s2[j]);
		}
	}
	cout<<cnt<<endl;
	return 0;
}