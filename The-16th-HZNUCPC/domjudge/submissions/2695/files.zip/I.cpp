#include<bits/stdc++.h>
using namespace std;
using ll=long long;
bool pan(char a,char b,char c,char d)
{
	if(a==d&&b==c) return true;
	return false;
}
bool check(char a,char b,char c,char d)
{
	if(pan(b,a,c,d)) return true;
	if(pan(c,b,a,d)) return true;
	if(pan(d,b,c,a)) return true;
	if(pan(a,c,b,d)) return true;
	if(pan(a,d,c,b)) return true;
	if(pan(a,b,d,c)) return true;
	return false;
}
void solve()
{
	string s;
	cin>>s;
	int len=0,n=s.length();
	//jishu
	s="?"+s;
	for(int i=1;i<=n;i++){
		char a,b,c,d;
		a=b=c=d='?';
		int cot=1;
		bool p=false;
		for(int j=1;i-j>0&&i+j<=n;j++){
			if(s[i-j]==s[i+j]) {
				cot+=2;
			}
			else if(b=='?') b=s[i-j],c=s[i+j];
			else if(a=='?'){
				a=s[i-j],d=s[i+j];
				if(!check(a,b,c,d)) break;
//				cout<<a<<" "<<b<<" "<<c<<" "<<d<<"\n";//------------------------------				
				cot+=4;
				len=max(len,cot);
			}
			else break;
			if(b=='?') 	len=max(len,cot);
			else if(check(a,b,c,d)) len=max(len,cot);
		}
	}
	for(int i=2;i<=n;i++){
		char a,b,c,d;
		a=b=c=d='?';
		int cot=0;
		for(int j=1;i-j>0&&i+j-1<=n;j++){
			if(s[i-j]==s[i+j-1]) {
				cot+=2;
			}
			else if(b=='?') b=s[i-j],c=s[i+j-1];
			else if(a=='?'){
				a=s[i-j],d=s[i+j-1];
				if(!check(a,b,c,d)) break;
//				cout<<a<<" "<<b<<" "<<c<<" "<<d<<"\n";//------------------------------
				cot+=4;
				len=max(len,cot);
			}
			else break;
			if(b=='?') 	len=max(len,cot);
			else if(check(a,b,c,d)) len=max(len,cot);
		}				
	}
	if(len==1) len=0;
	cout<<len<<"\n";
}
int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	int tt;
	cin>>tt;
	while(tt--){
		solve();
	}
}