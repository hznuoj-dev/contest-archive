#include "bits/stdc++.h"
using namespace std;
int x[105],y[105],p[105][105];
#define L long long
void cal(int i,int j) {

	if(x[i] == x[j]) {
		int maxy = max(y[i],y[j]);
		int miny = min(y[i],y[j]);
		p[i][j] = p[j][i] = maxy -miny + 1;
		return;
	}

	int minx = min(x[i],x[j]);
	int minxindex = (minx == x[i]) ? i : j;
	int maxx = max(x[i],x[j]);

	L B = y[i] - y[j];
	L A = x[i] - x[j];

	for(int _x = minx; _x<= maxx; _x++) {
		if(((L)B*(_x - x[minxindex]) + (L)y[minxindex] * A) % A == 0) {
			++p[i][j];
			++p[j][i];
		}
	}
}
int main() {
	int n;
	cin >> n;
	for(int i = 0; i<n; i ++) {
		cin >> x[i] >> y[i];
	}
	for(int i = 0; i < n; i ++) {
		for(int j = i + 1; j < n; j ++) {
			cal(i,j);
//			printf("%d %d %d\n",i,j,p[i][j]);
		}
	}
	int ans = 0;
	for(int i = 0; i < n; i ++) {
		for(int j = i + 1; j < n; j ++) {
			for(int z = j + 1; z < n; z++) {
				if((y[j] - y[i]) *(x[z] - x[j]) != (y[z] - y[j])*(x[j] - x[i])) {
					ans = max(p[i][j] + p[i][z] + p[j][z],ans);
				}
			}
		}
	}
	printf("%d",max(ans - 3,0));
}
