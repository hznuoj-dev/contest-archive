#include<iostream>
#include<cstring>
#include<algorithm>

#define read(x) scanf("%d", &x)
#define out(x) printf("%d", x)

using namespace std;

typedef long long LL;

const int N = 30;

int w[N][N];
int n;

int main(){
	int t;
	read(t);
	
	while(t--){
		int n;
		memset(w, 0, sizeof w);
		read(n);
		int cnt = 0;
		for(int i = 1; i <= n; i++){
			int x, y, p;
			read(x), read(y), read(p);
			w[x][y] = p;
		}
		
		int dx[] = {0, 0, 1, -1}, dy[] = {1, -1, 0, 0};
		
		for(int i = 1; i <= 19; i++){
			for(int k = 1; k <= 19; k++){
				if(w[i][k] == 1){
					for(int j = 0; j < 4; j++){
						int mx = i + dx[j], my = k + dy[j];

						if(w[mx][my] == 0) {
							cnt ++;
							w[mx][my] = 2;
						}
					}
				}
			}
			
		}
		
		out(cnt);
		
	}
	return 0;
}