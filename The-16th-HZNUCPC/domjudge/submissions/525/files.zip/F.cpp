#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+10;

int main()
{
	ll n,m;
	scanf("%lld%lld",&n,&m);
	ll k=n;
	for(ll i=2;i*i<=n;i++){
		if(n%i==0){
			k=i;
			break;
		}
	}
	if(k<=m&&n!=1)
		printf("NO\n");
	else
		printf("YES\n");	
	return 0;	
}
