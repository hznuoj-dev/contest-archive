#include <bits/stdc++.h>
using namespace std;
const int N=1e5+10,M=N*2;
int e[M], ne[M], h[N], w[M], idx;
#define ll long long 
#define int long long
int a[N],b[N];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
string s1,s2;
int ans=0;
cin >> s1 >> s2;
int lenth1=s1.size(),lenth2=s2.size();
s1=" "+s1,s2=" "+s2;
	for (int i=2;i<=lenth1;i++)
	{
		if(s1[i]!=s1[i-1])
			a[i]=a[i-1]+1;
		if(s2[i]!=s2[i-1])
	     	b[i]=b[i-1]+1;
	}
	for(int i=1;i<lenth1;i++)
	for(int j=2+i-1;j<=lenth1;j++)
	{
	if(abs(i-j)!=1)
	{
			int count1=0,count2=0;
		count1+=a[i-1]+a[j-1]-a[i+1]+a[lenth1-j+1];
	 if(b[i]!=a[i-1])
	 count1++;
	 for (int i=1;i<=100000000000;i++)
	 {
	 	cout << 666 << endl;
	 }
	}
	}
	return 0;
}