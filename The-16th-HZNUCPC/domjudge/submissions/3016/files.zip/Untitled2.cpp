#include<bits/stdc++.h>
using namespace std;

int l;
string ss;
char s[10010];

int check2(int a,int b){
	int res=b-a+1;
	for(int i=1;i<=a && i+b<l;++i){
		if(s[i+b]!=s[a-i]) return res;
		res=i+b-(a-i)+1;
	}
	return res;
}

int check(int a,int b,char c,char ned){
	for(int i=1;i<=a && i+b<l;++i){
		if(s[a-i]!=s[b+i]){
			if((c==s[a-i] && ned==s[b+i]) || (c==s[b+i] && ned==s[a-i])) return check2(a-i,b+i);
			else return 0;
		}
	}
	return 0;
}

int main(){
//	freopen("data.in","r",stdin);
	int T,ans,a;
	scanf("%d",&T);
	while(T--){
		cin>>ss;
		l=0;
		s[l++]='*';
		for(int i=0;i<ss.length();++i){
			s[l++]=ss[i];
			s[l++]='*';
		}
		ans=1;
	//	for(int i=0;i<l;++i) printf("%c",s[i]);puts("");
		for(int i=1;i<l;++i){
			for(int j=1;j<=i && i+j<l;++j){
				if(s[i-j]!=s[i+j]){
					a=check(i-j,i+j,s[i-j],s[i+j]);
					ans=max(ans,a);
					if(s[i-j]==s[i] || s[i+j]==s[i]){
						a=check2(i-j,i+j);
						ans=max(ans,a);
					}
					break;
				}else ans=max(ans,2*j+1);
			}//printf("%d %d\n",i,ans);
		}
		ans/=2;
		printf("%d\n",ans==1?0:ans);
	}
	return 0;
}
/*
*a*b*c*c*a*b*
1 3
2 0
2 3
3 0
3 3
4 0
4 3
5 0
5 3
6 13
6 13
7 0
7 13
8 0
8 13
9 0
9 13
10 0
10 13
11 13
12 13
6
*i*h*i*
1 3
2 0
2 3
3 7
4 0
4 7
5 7
6 7
3
*s*t*f*g*f*i*u*t*
1 3
2 0
2 3
3 0
3 3
4 0
4 3
5 0
5 3
6 0
6 3
7 0
7 7
8 0
8 7
9 0
9 7
10 0
10 7
11 0
11 7
12 0
12 7
13 0
13 7
14 0
14 7
15 7
16 7
3
*p*a*l*i*n*d*r*o*m*e*
1 3
2 0
2 3
3 0
3 3
4 0
4 3
5 0
5 3
6 0
6 3
7 0
7 3
8 0
8 3
9 0
9 3
10 0
10 3
11 0
11 3
12 0
12 3
13 0
13 3
14 0
14 3
15 0
15 3
16 0
16 3
17 0
17 3
18 0
18 3
19 3
20 3
0
[Finished in 1.2s]
*/