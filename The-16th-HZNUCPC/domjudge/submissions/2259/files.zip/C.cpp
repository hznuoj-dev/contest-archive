#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define N 200005
#define mod 1000000007
typedef pair<int, int> pii;
ll cntb[30]; // count char in a
ll cnta[30]; // count char in b
ll ans;
char a[N], b[N];
int ca, cb;
int n;
map<pair<int, int>, ll>mp;
int judge(pii l1, pii l2) {
	int cg = 0;
	
	cnta[l1.first]--;
	if(cnta[l1.first]==0)cg--;
	cnta[l1.second]++;
	if(cnta[l1.second]==1)cg++;
	
	cntb[l1.second]--;
	if(cntb[l1.second]==0)cg++;
	cntb[l1.first]++;
	if(cntb[l1.first]==1)cg--;
	
	cnta[l2.first]--;
	if(cnta[l2.first]==0)cg--;
	cnta[l2.second]++;
	if(cnta[l2.second]==1)cg++;
	
	cntb[l2.second]--;
	if(cntb[l2.second]==0)cg++;
	cntb[l2.first]++;
	if(cntb[l2.first]==1)cg--;
	
	cnta[l1.first]++;
	cnta[l1.second]--;
	cntb[l1.second]++;
	cntb[l1.first]--;
	
	cnta[l2.first]++;
	cnta[l2.second]--;
	cntb[l2.second]++;
	cntb[l2.first]--;
	return cg;
}
int main() {
	scanf("%s", a + 1);
	scanf("%s", b + 1);
	n = strlen(a + 1);
	for (int i = 1; i <= n; i++) {
		int u = a[i] - 'a';
		if(cnta[u] == 0) ca++;
		cnta[u]++;
	}
	for (int i = 1; i <= n; i++) {
		int u = b[i] - 'a';
		if(cntb[u] == 0) cb++;
		cntb[u]++;
	}
	for (int i = 1; i <= n; i++) {
		mp[pii(a[i] - 'a', b[i] - 'a')]++;
	}
	ans = 0;
	//printf("%d %d\n", ca, cb);
	for (auto it: mp) {
		for (auto it2: mp) {
			if(it>it2)continue;
			if(it.first == it2.first && it.second == 1) continue;
			//printf("%d\n", judge(it.first, it2.first));
			//printf("%c-%c %c-%c\n", it.first.first+'a', it.first.second+'a', it2.first.first+'a', it2.first.second+'a');
			if(ca+judge(it.first, it2.first) == cb) {
				if(it.first == it2.first){
					ans += 1ll * it.second * (it.second - 1)/2;
				}
				else ans += 1ll * it.second * it2.second;
				ans %= mod;
			}
				
		}
	}
	printf("%lld", ans);
	return 0;
}