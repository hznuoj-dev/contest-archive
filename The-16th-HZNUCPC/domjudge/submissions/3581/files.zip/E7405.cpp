#include<bits/stdc++.h>
using namespace std;
#define int long long 
int n,m;
pair<int ,int >s[2005];
int check(double x1,double y1,double x2,double y2,double x3,double y3){
	if(!x1&&!x2&&!x3)return 0;
	if(!y1&&!y2&&!y3)return 0;
	if(x1&&x2&&x3&&y1&&y2&&y3&&y1/x1==y2/x2&&y1/x1==y3/x3&&y2/x2==y3/x3)return 0;
	return 1;
}
int su(int x1,int y1,int x2,int y2,int x3,int y3){
	int sum=0;
	if(!x1){
		sum+=abs(y1)-1;
	}else if(!y1){
		sum+=abs(x1)-1;
	}else{
		int q=__gcd(abs(x1),abs(y1));
		sum+=abs(x1)/q-1;
	}
	if(!x2){
		sum+=abs(y2)-1;
	}else if(!y2){
		sum+=abs(x2)-1;
	}else{
		int q=__gcd(abs(x2),abs(y2));
		sum+=abs(x2)/q-1;
	}
	if(!x3){
		sum+=abs(y3)-1;
	}else if(!y3){
		sum+=abs(x3)-1;
	}else{
		int q=__gcd(abs(x3),abs(y3));
		sum+=abs(x3)/q-1;
	}
	return sum;
}
void solve(){
	while(cin>>n){
		for(int i=0;i<n;i++){
			int x,y;
			cin>>x>>y;
			s[i]={x,y};
		}
		int f=0;
		int ans =0;
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				for(int k=0;k<n;k++){
					if(j==i||j==k||i==k) continue;
					double x1=s[i].first-s[j].first;
					double y1=s[i].second-s[j].second;
					double x2=s[j].first-s[k].first;
					double y2=s[j].second-s[k].second;
					double x3=s[k].first-s[i].first;
					double y3=s[k].second-s[i].second;
					if(check(x1,y1,x2,y2,x3,y3)==0)continue;
					f=1;
					ans=max(ans,su(x1,y1,x2,y2,x3,y3));
				}
			}
		}
		if(f==0){
			cout<<0<<endl;
		}else{
			cout<<ans+3<<endl;
		}
		
	}
	
}
signed main(){
	solve();
	return 0;
}