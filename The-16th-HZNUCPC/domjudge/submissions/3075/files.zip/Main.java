import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		long n = s.nextLong();
		long m = s.nextLong();
		int k = 0;
		while (true)
		{
			long h = n % m;
			if (h == 0)
			{
				k = 1;
				break;
			}
			if (h == 1)
			{
				break;
			}
			long j = m - h;
			long piao=n/m;
			if (n-j*piao >= j *piao)
			{	
				m = h;
			}
			else
			{
				m = j;
			}
		}
		if (m == 1 && k == 0)
			System.out.print("YES\r\n");
		else
			System.out.print("NO\r\n");
	}
}
