#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=100005;
LL mod=1e9+7;

char s[N];
int n;
pair<int,int> g[3];
int main(){
	int _;
	scanf("%d",&_);
	while(_--){
		scanf("%s",s + 1);
		n = strlen(s + 1);
	
		int ans = 0;
		for (int i = 1; i <= n; i ++) {	
			auto solve = [&](int l, int r) {
				int sz = 0;
				int odd = -1;
				if (l == r) {
					odd = l;
				}
				while (r <= n && l >= 1) {
					if (s[l] != s[r]) {
						g[sz++] = {l, r};
					}
					if (sz == 3) {
						// [l, r]
						break;
					}
					r ++; l --;
				}	
				l ++, r --;
			//	printf("l=%d,r=%d, %d\n",l,r,sz);
				
				if (sz >= 2) {
					bool can = 0;
					if (s[g[0].first] == s[g[1].first] and s[g[0].second] == s[g[1].second])
						can = 1;
					if (s[g[0].first] == s[g[1].second] and s[g[0].second] == s[g[1].first])
						can = 1;						
					if (can) {
						ans = max(ans, r - l + 1);
					}
				}
				
				{	
					int lb = l, rb = r;
					if (sz >= 1) {
						lb = g[0].first + 1, rb = g[0].second - 1;
					} 
					if (lb != rb) ans = max(ans, rb - lb + 1);
				}
				
				if (odd != -1 && sz >= 1) {
					int lb = l, rb = r;
					if (sz >= 2) {
						lb = g[1].first + 1, rb = g[1].second - 1;
					}
				//	printf("%d %d\n", lb, rb);
					if (s[odd] == s[g[0].first] || s[odd] == s[g[0].second])
						ans = max(ans, rb - lb + 1);
				}
			};
			solve(i, i);
			if (i + 1 <= n) solve(i, i + 1);
		}
		
		printf("%d\n", ans);
	}
    return 0;
}