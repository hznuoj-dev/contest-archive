#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod = 1e9+7;
signed main()
{
	int n,m;              

	while(cin >> n >> m)
	{
		if(m > n){
			m -= n;
		}
		if(m == 1 || n == 1){
			cout << "YES" << endl;
			continue;
		}
		if(m == n && m % 2 == 1){
			cout << "YES" << endl;
			continue;
		}
		while(m > 1)
		{
			m = n % m;
		}
		if(m == 0)
		{
			cout << "NO" << endl;
		}
		else
		{
			cout << "YES" << endl;
		}
	}
	return 0;
}
