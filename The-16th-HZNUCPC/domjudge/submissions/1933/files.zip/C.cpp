#include<bits/stdc++.h>
#define endl '\n'
using namespace std;

typedef long long ll;
const ll N = 1e5 + 7;
const ll mod = 1e9 + 7;
ll _,n, num1[30], num2[30], cnt1, dif[30], add[30];
string s1, s2;

ll qpow(ll x, ll y){
	ll res = 1;
	while (y){
		if (y % 2)res = res * x % mod;
		y /= 2;
		x = x * x % mod;
	}
	return res;
}

void solve(){
	cin >> s1 >> s2;
	n = s1.size();
	s1 = " " + s1;
	s2 = " " + s2;
	ll mul = qpow(2, mod - 2);
	for (int i = 1; i <= n; i++){
		num1[s1[i] - 'a']++;
		num2[s2[i] - 'a']++;
		if (s1[i] == s2[i])cnt1++;
		else{
			dif[s1[i] - 'a']++;
			add[s2[i] - 'a']++;
		}
	}
	ll ans = 0, flag = 1;
	for (int i = 0; i < 26; i++){
		if (abs(num1[i] - num2[i]) > 2)continue;
		if (num1[i] == num2[i] && flag){
			ans = (ans + cnt1 * (cnt1 - 1) % mod * mul % mod) %mod;
			flag = 0;
		}
		if (num1[i] == num2[i] + 1)ans = (ans + dif[i] * cnt1 % mod * mul % mod) % mod;
		if (num1[i] == num2[i] + 2)ans = (ans + dif[i] * (dif[i] - 1) % mod * mul % mod) % mod;
		if (num1[i] == num2[i] - 1)ans = (ans + add[i] * cnt1 % mod * mul % mod) % mod;
		if (num1[i] == num2[i] - 2)ans = (ans + add[i] * (add[i] - 1) % mod * mul % mod) % mod;
		//cout << ans << endl;
	}
	cout << ans << endl;
}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	//cin >> _;
	_ = 1;
	while(_--)solve();
}