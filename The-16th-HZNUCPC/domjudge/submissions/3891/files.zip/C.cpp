#include<bits/stdc++.h>
#define ll long long
#define int long long
#define PII pair<int,int>
using namespace std;
int cnt1[27],cnt2[27],C[27],D[27];
const int mod=1e9+7;
vector<int> p;
void solve(){
	string str1,str2;
	cin >> str1 >> str2;
	set<char> A,B;
	int n=str1.size();
	int d;
	for(int i=0;i<n;i++){
		A.insert(str1[i]);
		B.insert(str2[i]);
	}
	d = abs((int)A.size()-(int)B.size());
	int a=A.size(),b=B.size();
	if(A.size()<B.size()){
		swap(str1,str2);
		swap(a,b);
	}
	for(int i=0;i<n;i++){
		cnt1[str1[i]-'a']++;
		cnt2[str2[i]-'a']++;
	}
	for(int i=0;i<n;i++){
		if(str1[i]==str2[i] || cnt1[str1[i]-'a']>=3 && cnt2[str1[i]-'a']>=3
		&& cnt1[str2[i]-'a']>=3 && cnt2[str2[i]-'a'] >=3){
			continue;
		}
		p.push_back(i);
	}
	memcpy(C,cnt1,sizeof(cnt1));
	memcpy(D,cnt2,sizeof(cnt2));
	int res=n-p.size();
	ll ans=0;
	int x,y;
	for(int i=0;i<p.size();i++){
		x=a,y=b;
		if(cnt1[str1[p[i]]-'a']==1){
			x--;
		}
		if(cnt1[str2[p[i]]-'a']==0){
			x++;
		}
		if(cnt2[str2[p[i]]-'a']==1){
			y--;
		}
		if(cnt2[str1[p[i]]-'a']==0){
			y++;
		}
		if(x==y){
//			cout << "work " << p[i] << " " << res << endl;
			ans=(ans+res)%mod;
		}
		for(int j=i+1;j<p.size();j++){
			memcpy(cnt1,C,sizeof(C));
			memcpy(cnt2,D,sizeof(D));
			x=a,y=b;
			if(cnt1[str1[p[i]]-'a']==1) x--;
			if(cnt2[str2[p[i]]-'a']==1) y--;
			if(cnt1[str2[p[i]]-'a']==0) x++;
			if(cnt2[str1[p[i]]-'a']==0) y++;
			cnt1[str1[p[i]]-'a']--;cnt1[str2[p[i]]-'a']++;
			cnt2[str2[p[i]]-'a']--;cnt2[str1[p[i]]-'a']++;
			if(cnt1[str1[p[j]]-'a']==1) x--;
			if(cnt2[str2[p[j]]-'a']==1) y--;
			if(cnt1[str2[p[j]]-'a']==0) x++;
			if(cnt2[str1[p[j]]-'a']==0) y++;
			if(x==y){
				ans=(ans+1)%mod;
//				cout << "w " << p[i] <<" " << p[j] << endl;
			}
		}
	}
	if(d==0) ans = (ans+res*(res-1)/2)%mod;
	cout << ans << endl;
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}
