import java.util.Scanner;
public class Main {
	public static int [] wayx ={1,-1, 0, 0};
	public static int [] wayy ={0,0, 1, -1};
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int turn = sc.nextInt();
		for(int t=0;t<turn;t++)
		{
			int n =sc.nextInt();
			int [][] map = new int [20][20];
			for(int x=0;x<n;x++)
			    map[sc.nextInt()][sc.nextInt()]=sc.nextInt()+1;
			int cnt=0;
			for(int x=1;x<=19;x++)
				for(int y=1;y<=19;y++)
					if(map[x][y]==2)
						for(int z=0;z<4;z++)
						{
							int xx = x+wayx[z];
							int yy = y+wayy[z];
							if(xx>=1 && xx<=19 && yy>=1 && yy<=19 &&map[xx][yy]==0)
								cnt++;
						}
			System.out.println(cnt);
		}	
	}
}