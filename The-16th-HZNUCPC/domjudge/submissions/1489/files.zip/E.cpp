#include <bits/stdc++.h>
using namespace std;

const int N = 1e2 + 5;
pair<int, int> P[N];

int gcd(int, int);
int W(int, int);
//bool check();

int ans;
int n;
int main() {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		scanf("%d%d", &P[i].first, &P[i].second);
		
	}
//	if (!check()) {
//		printf("0");
//		return 0;
//	}
	
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			for (int k = j + 1; k <= n; k++) {
				if (P[j].first != P[i].first && P[k].first != P[j].first) {
					long double rat1 = 1.0 * (P[j].second - P[i].second) / (P[j].first - P[i].first);
					long double rat2 = 1.0 * (P[k].second - P[j].second) / (P[k].first - P[j].first);
					if (rat1 == rat2) {
						continue;
					}
					ans = max(ans, W(i, j) + W(j, k) + W(i, k));
				} else {
					if(P[j].first == P[i].first && P[i].first == P[k].first){
						continue;
					}else{
						ans = max(ans, W(i, j) + W(j, k) + W(i, k));
					}
				}
			}
		}
	}
	cout << max(ans - 3, 0);
	return 0;
}

int gcd(int a, int b) {
	if (b == 0) {
		return a;
	}
	return gcd(b, a % b);
}

int W(int ind, int jnd) {
	int xdif = abs(P[ind].first - P[jnd].first);
	int ydif = abs(P[ind].second - P[jnd].second);
	return gcd(xdif, ydif) + 1;
}
