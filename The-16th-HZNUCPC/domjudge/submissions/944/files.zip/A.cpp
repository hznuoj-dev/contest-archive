#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 1e5 + 10;
const double PI = acos(-1);
int flag[25][25];
struct ty{
	int x, y;
}a[1000];
void solve() {
	int n;
	cin >> n;
	memset(flag, 0, sizeof flag);
	for (int i = 1; i <= n; i++) {
		int x, y, z;
		cin >> x >> y >> z;
		a[i].x = x;
		a[i].y = y;
		if (z == 1) {
			flag[x + 1][y]++;
			flag[x - 1][y]++;
			flag[x][y + 1]++;
			flag[x][y - 1]++;
		}
	}
	for (int i = 1; i <= n; i++) {
		flag[a[i].x][a[i].y] = 0;
	}
	int ans = 0;
	for (int i = 1; i <= 19; i++) {
		for (int j = 1; j <= 19; j++) {
			ans += flag[i][j];
		}
	}
//	for (int i = 0; i <= 20; i++) {
//		for (int j = 0; j <= 20; j++) {
//			cout << flag[i][j];
//		}
//		cout << "\n";
//	}
	cout << ans << "\n";
}
int main() {
	int t;
	cin >> t;
	while (t--) solve();
	return 0;
}