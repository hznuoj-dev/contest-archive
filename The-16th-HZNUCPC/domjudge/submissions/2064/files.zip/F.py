n,m=map(int,input().split())
flag=False
if m==1:
    print('Yes')
elif n==1:
    print('YES')
elif m>=n:
    print('NO')
elif n%m==0:
    print('NO')
    # for i in range(2,n//2):
    #     if i>=n:
    #         flag=True
    #         break
    #     if n%i==0:
    #         flag=True
    #         break
    # if flag:
    #     print('NO')
    # else:
    #     print('YES')
else:
    print('YES')