#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int mod=1e9+7;
string a,b;
ll num=1;
ll dp[100005];
int main(){
	cin>>a>>b;
	int lens = a.length();
	a = " " + a;
	b = " " + b;
//	for(int i=1;i<=lens/2;i++){
//		if(a[i]!=b[i]&&a[lens-i+1]!=b[lens-i+1]){
//			break;
//		}else if(a[i]==b[i]||a[lens-i+1]==b[lens-i+1]){
//			num=(num+lens-i)%mod;
//		}
//	}
//	cout<<num;
	dp[0] = 1;
	for(int i = 1; i <= lens; i++) {
		if(a[i] == b[i]) {
			dp[i] = (dp[i - 1] + 1) % mod;
		} else {
			dp[i] = max(dp[i], dp[i - 1]);
		}
	}
//	if(a == b) {
//		ll sums = 0;
//		for(int i = 1; i <= lens - 1; i++) {
//			sums = (sums + i) % mod;
//		}
//		cout << sums % mod;
//		return 0;
//	}
	cout << (dp[lens] + lens >> 1) % mod;
	return 0;
}
//aaaa
//aaaa
//1234
//abca
//aaaa
//21
//