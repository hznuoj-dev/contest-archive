#include<bits/stdc++.h>
#define int long long
#define rep(i,a,n) for(int i=a;i<n;i++)
#define per(i,a,n) for(int i=n-1;i>=a;i--)
#define fi first 
#define se second
#define pb push_back
#define endl '\n'
#define pii pair<int,int> 
#define vii vector<pair<int,int> >

using namespace std;
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
int g[22][22];
int dx[]={1,-1,0,0},dy[]={0,0,-1,1};
pii p[110];
pii get(pii a,pii b){
	if(a.fi==b.fi) return {0,1};
	if(a.se==b.se) return {1,0};
	int dx=a.fi-b.fi;
	int dy=a.se-b.se;
	if(dx*dy>0){
		int d=gcd(dx,dy);
		return {dx/d,dy/d};
	}else{
		int d=gcd(dx,dy);
		return {-dx/d,dy/d};
	}
}
int getn(pii a,pii b){
	if(a.fi==b.fi) return abs(a.se-b.se)-1;
	if(a.se==b.se) return abs(a.fi-b.fi)-1;
	int dx=abs(a.fi-b.fi),dy=abs(a.se-b.se);
	return gcd(dx,dy)-1;
}
void solve(){
	int n;cin>>n;
	rep(i,1,n+1){
		cin>>p[i].fi>>p[i].se;
	}
	int ans=0;
	rep(i,1,n+1){
		rep(j,i,n+1){
			rep(k,j,n+1){
				pii xl[3];int now=0;
				if(p[i]==p[j]) continue;
				if(p[j]==p[k]) continue;
				if(p[k]==p[i]) continue;
				xl[0]=get(p[i],p[j]);
				xl[1]=get(p[i],p[k]);
				if(xl[0]==xl[1]) continue;
				now+=getn(p[i],p[j]);
				now+=getn(p[j],p[k]);
				now+=getn(p[k],p[i]);
				now+=3;
				ans=max(ans,now);
			}
		}
	}cout<<ans<<endl;
}
signed main(){
	int t=1;//cin>>t;
	while(t--){
		solve();
	}
	return 0;
}