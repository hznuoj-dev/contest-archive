#include<bits/stdc++.h>
using namespace std;
#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const int maxn=2e5+10;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;

int n,q,m;
int head[100010],to[200010],nxt[200010],val[200010],cnt,col[200010];
int cl1,cl0;
int flag=1;
int ai[100010],bi[100010],ci[100010],p;
vector<int>vec[100010];
void add(int u,int v,int vl){
	to[cnt]=v;
	val[cnt]=vl;
	nxt[cnt]=head[u];
	head[u]=cnt;
	cnt++;
}
void dfs(int x,int u){
	vec[x].push_back(u);
	if(flag==0)return;
	for(int i=head[u];i!=-1;i=nxt[i]){
		int v=to[i];
		if(val[i]==0){
			if(col[v]!=-1){
				if(col[v]!=col[u]){
					flag=0;
					break;
				}
			}
			else{
				col[v]=col[u];
				if(col[v]==1)cl1++;
				else cl0++;
				dfs(x,v);
			}
		}
		else{
			if(col[v]!=-1){
				if(col[v]==col[u]){
					flag=0;
					break;
				}
			}
			else{
				col[v]=1-col[u];
				if(col[v]==1)cl1++;
				else cl0++;
				dfs(x,v);
			}
		}
	}
}
int cflag=0;
void dfs2(int i,int tmp){
	if(tmp==0)cflag=1;
	if(cflag==1||tmp<=0)return;
	if(i>p)return;
	ci[i]=1;
	//cout<<"this is 1:"<<i<<endl;
	dfs2(i+1,tmp-bi[i]);
	if(cflag==1||tmp<=0)return;
	ci[i]=0;
	//cout<<"this is 0:"<<i<<endl;
	dfs2(i+1,tmp);
}
void resolve(){
	memset(head,-1,sizeof(head));
	memset(col,-1,sizeof(col));
	cin>>n>>q>>m;
	p=0;
	while(m--){
		int u,v,k;
		cin>>k>>u>>v;
		add(u,v,k);
		add(v,u,k);
	}
	for(int i=1;i<=n;i++){
		if(col[i]!=-1)continue;
		cl1=1,cl0=0;
		col[i]=1;
		p++;
		dfs(p,i);
		ai[p]=min(cl1,cl0);
		bi[p]=max(cl1,cl0);
		if(cl1<cl0){
			for(auto j:vec[p]){
				col[j]=1-col[j];
			}
		}
	}
	//for(int i=1;i<=n;i++)cout<<col[i]<<" ";
	//cout<<endl;
	int sum=0;
	if(flag==1){
		for(int i=1;i<=p;i++)sum+=ai[i],bi[i]-=ai[i];
		if(sum>q){
			flag=0;
		}
		else{
			dfs2(1,q-sum);
			if(cflag==0)flag=0;
		}
	}
	if(!flag)cout<<"NO"<<endl;
	else{
		cout<<"YES"<<endl;
		vector<int>ans;
		for(int i=1;i<=p;i++){
			//cout<<ci[i]<<" * ";
			for(auto j:vec[i]){
				if(col[j]==ci[i])ans.push_back(j);
			}
		}
		//cout<<endl;
		sort(ans.begin(),ans.end());
		for(auto i:ans){
			cout<<i<<" ";
		}
		cout<<endl;
	}
}
signed main(){
	fast;
	int _=1;
	//cin>>_;
	while(_--){
		resolve();
	}
}
/*
13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13
*/