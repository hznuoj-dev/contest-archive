#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,k,t;
	while(cin>>n>>m){
		if(m==1){
			cout <<"YES"<<endl;
		}else{
			if(n%m==0){
				cout <<"NO"<<endl;
			}else{
				cout <<"YES"<<endl;
			}
		}
		
	}
	return 0;
}