#include<bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(0);cin.tie(nullptr);cout.tie(nullptr)
#define fi first
#define se second
#define pb push_back
#define eb emplace_back
#define int long long
#define endl '\n'
#define yes "YES\n"
#define no "NO\n"
const int inf = 0x3f3f3f3f;
const int mod = 1e9 +7;

int fpow(int x,int y){
	int ans = 1;
	while(y){
		if(y&1) ans = ans*x%mod;
		x = x*x%mod;
		y >>= 1;
	}
	return ans%mod;
}

void solve(){
	int n,m;
	cin >> n >> m;
	if(m == 1) cout << "YES";
	else{
		while(1){
			if(n%m == 0){
				cout << "NO";
				return ;
			}
			m = n%m;
			if(m == 0){
				cout << "NO";
				return ;
			}
			if(m == 1){
				cout << "YES";
				return ;
			}
		}
	}
	
}
/*
10000000000 153
*/
signed main(){
	IOS;
	int  T = 1;
	//cin >> T;
	while(T--) solve();
	return 0;
}