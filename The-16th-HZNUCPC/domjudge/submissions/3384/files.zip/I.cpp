#include<bits/stdc++.h>
using namespace std;
int getRes(const string& s){
	vector<vector<int>>dp(s.size()+1,vector<int>(s.size()+1));
	int result=0;
	for(int i=0;i<=s.size();i++)dp[i][i]=1;
	for(int i=s.size()-1;i>0;i--){
		for(int j=i+1;j<=s.size();j++){
			if(s[i-1]==s[j-1])dp[i][j]=dp[i+1][j-1]+2;
			else dp[i][j]=1;
			result=max(result,dp[i][j]);
		}
	}
	return result;;
}
int main(){
	int t;
	cin>>t;
	while(t--){
		string s;
		cin>>s;
		int result=getRes(s);
		if(result==1)result=0;
		cout<<result<<endl;
	}
}