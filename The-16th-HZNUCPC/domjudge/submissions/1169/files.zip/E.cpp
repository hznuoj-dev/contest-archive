#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
const int N = 110;
vector<pair<ll,ll>> all(N), a;
ll n, ans;
ll check() {
	if((a[0].first - a[1].first) * (a[1].second - a[2].second) == (a[1].first - a[2].first) * (a[0].second - a[1].second)) return 0;
	ll s1, s2, s3;
	s1 = __gcd(abs(a[0].first - a[1].first), abs(a[0].second - a[1].second)) - 1;
	s2 = __gcd(abs(a[0].first - a[2].first), abs(a[0].second - a[2].second)) - 1;
	s3 = __gcd(abs(a[1].first - a[2].first), abs(a[1].second - a[2].second)) - 1;
	return s1 + s2 + s3 + 3;
}
void dfs(int u,int x){
	if(u == 3) {
		ll x = check();
		if(x != 0) ans = max(x, ans);
		return;
	}
	if(x >= n) return;
	a.push_back(all[x]);
	dfs(u + 1, x + 1);
	a.pop_back();
	dfs(u, x + 1);
}
void solve()
{
	cin >> n;

	for(int i = 0; i < n; i++) {
		cin >> all[i].first >> all[i].second;
	}
	dfs(0, 0);
	cout << ans << "\n";
}

int main()
{
	IOS
	int T = 1;
//	cin >> T;
	while(T--) 
		solve();	
	return 0;
}