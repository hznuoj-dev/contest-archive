#include<iostream>
using namespace std;
int main(){
	long long n,m;
	cin >> n >> m;
	string res="NO";
	if(m==1||n==1) res="YES";
	else{
		long long k=m;
		while(k>1){
			k=n%k;
		}
		if(k==0)res="NO";
		else res="YES";
	}
	cout << res << endl;
			
}
	