#include<bits/stdc++.h>

using namespace std;

#define ios ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define ll long long

int main()
{
	ios;
	ll n, m; cin >> n >> m;
	if(n == 1 && m == 1)
	{
		cout << "YES\n";
		return 0;	
	}
	while(n % m > 1)
	{
		m = n % m;
	}
	m = n % m;
	if(m == 1) cout << "YES\n";
	else cout << "NO\n";
	return 0;
}

