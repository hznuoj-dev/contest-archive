#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll mod = 1e9+7;
const ll N = 1e6+10;
const ll seed = 2333;
const ll b = 233;

ll gcd(ll a,ll b){
    return b==0?a:gcd(b,a%b);
}
map<ll,ll> mp;
ll x[N],y[N];
ll tx[N],ty[N];
ll getha(ll pos,ll n){

    for(ll i=0;i<n;i++){
        ll id = (i+pos)%n;
        tx[i] = x[id] - x[pos];
        ty[i] = y[id] - y[pos];
    }
    //cout<<"==="<<endl;
    for(int i=0;i<n;i++){
        //cout<<tx[i]<<' '<<ty[i]<<endl;
    }
    ll x0 = tx[1],y0 = ty[1];
    for(ll i=0;i<n;i++){
        ll ttx = tx[i],tty = ty[i];
        tx[i] = ttx*x0 + tty*y0;
        ty[i] = ttx*y0 - tty*x0;
    }
    ll g = 0;
    for(ll i=0;i<n;i++){
        g = gcd(g,abs(tx[i]));
        g = gcd(g,abs(ty[i]));
    }
    for(ll i = 0;i<n;i++){
        tx[i] /= g;
        ty[i] /= g;
    }
    ll res = 0;
    //cout<<"----"<<endl;
    for(ll i=0;i<n;i++){
        //cout<<tx[i]<<' '<<ty[i]<<endl;
        res = res*seed + tx[i];
        res = res*seed + ty[i];
    }
    //cout<<"==="<<endl;
    return res;
}

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);


    ll t;
    cin>>t;
    while(t--){
        ll n;
        ll ha;
        cin>>n;
        ll ans = 0;
        for(ll i=0;i<n;i++){
            cin>>x[i]>>y[i];
        }
        ll minlen = 0x7fffffffffffffff;
        for(ll i=0;i<n;i++){
            minlen = min(minlen,(x[i]-x[(i+1)%n])*(x[i]-x[(i+1)%n])+(y[i]-y[(i+1)%n])*(y[i]-y[(i+1)%n]));
        }
        bool tag = 0;
        for(ll i=0;i<n;i++){
            ll len = (x[i]-x[(i+1)%n])*(x[i]-x[(i+1)%n])+(y[i]-y[(i+1)%n])*(y[i]-y[(i+1)%n]);
            //cout<<"len "<<len<<endl;
            if(len==minlen){
                ha = getha(i,n);
                if(mp.count(ha)) {
                        tag = 1;
                        break;
                }
            }
        }
        //cout<<"rev"<<endl;
        reverse(x,x+n),reverse(y,y+n);
        for(ll i=0;i<n;i++) y[i] = -y[i];
        for(ll i=0;i<n&&!tag;i++){
            ll len = (x[i]-x[(i+1)%n])*(x[i]-x[(i+1)%n])+(y[i]-y[(i+1)%n])*(y[i]-y[(i+1)%n]);
            if(len==minlen){
                ha = getha(i,n);
                if(mp.count(ha)) {
                        tag = 1;
                        break;
                }
            }
        }

        cout<<mp[ha]<<endl;
        mp[ha]++;

    }
}

