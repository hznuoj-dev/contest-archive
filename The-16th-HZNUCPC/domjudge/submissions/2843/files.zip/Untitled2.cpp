#include<bits/stdc++.h>
using namespace std;
#define For(i,l,r) for(int i=(l);i<=(r);i++)
#define mkp make_pair
#define mod 1000000007
const int N=100005;
char a[N],b[N];
int n,ans;
map<char,int>mpa,mpb;
map<pair<char,char>,int>mp;
signed main(){
	scanf("%s",a+1);
	scanf("%s",b+1);
	n=strlen(a+1);
	For(i,1,n){
		mpa[a[i]]++;
		mpb[b[i]]++;
		mp[make_pair(a[i],b[i])]++;
	}
	for(char i='a';i<='z';i++){
		for(char j='a';j<='z';j++){
			for(char k='a';k<='z';k++){
				for(char h='a';h<='z';h++){
					if(!mp.count(mkp(i,j))||!mp.count(mkp(k,h)))continue;
//					cout<<i<<' '<<j<<' '<<k<<' '<<h<<':';
					mpa[i]--,mpb[j]--;
					mpa[j]++,mpb[i]++;
					mpa[k]--,mpb[h]--;
					mpa[h]++,mpb[k]++;
					int cnta=0,cntb=0,tmp=ans;
					for(char c='a';c<='z';c++){
						if(mpa[c]>0)cnta++;
						if(mpb[c]>0)cntb++;
						if(mpa[c]<0)goto lrher;
						if(mpb[c]<0)goto lrher;
					}
					if(cnta!=cntb)goto lrher;
					if(i==k&&j==h){
						ans+=mp[mkp(i,j)]*(mp[mkp(k,h)]-1);
						ans%=mod;
					}else{
						ans+=(mp[mkp(i,j)]*mp[mkp(k,h)]);
						ans%=mod;
					}
//					cout<<ans-tmp<<endl;
					lrher:;
					mpa[i]++,mpb[j]++;
					mpa[j]--,mpb[i]--;
					mpa[k]++,mpb[h]++;
					mpa[h]--,mpb[k]--;
				}
			}
		}
	}
	cout<<ans/2;
	return 0;
}