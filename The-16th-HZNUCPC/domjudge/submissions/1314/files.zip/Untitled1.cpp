#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 1e6 + 10;
const double PI = acos(-1);
int a[MAX], cnt;
void check(ll n) {
	cnt = 0;
	for (int i = 2; i <= sqrt(n); i++) {
		if (n % i == 0) {
			a[++cnt] = i;
			a[++cnt] = n / i;
		}
	}
}
void solve() {
	ll n, m;
	cin >> n >> m;
	if (m == 1 || n == 1) {
		cout << "YES\n";
		return ;
	}
	if (n <= m) {
		cout << "NO\n";
		return ;
	}
	check(n);
	for (int i = 1; i <= cnt; i++) {
		if (a[i] <= m) {
			cout << "NO\n";
			return ;
		}
	}
	cout << "YES\n";
}
int main() {
	solve();
	return 0;
}