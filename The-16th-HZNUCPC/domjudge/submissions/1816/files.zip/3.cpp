#include <stdio.h>

bool back(int j,int k);
bool back(int j,int k)
{
	int t = j%k;
	if(t == 1) return true;
	if(t == 0) return false;
	back(j,t);
}
int main(){
	int n,m;
	scanf("%d %d",&n,&m);
	if(m == 1)
	{
		printf("YES");
		return 0;
	}
	if(back(n,m))
	{
		printf("YES");
	}else
	{
		printf("NO");
	}
	return 0;
}