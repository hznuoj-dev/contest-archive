#include<bits/stdc++.h>
#define int long long
using namespace std;

double x[105];
double y[105];
int n,m;

double xielv(int a,int b){
	if(y[a] - y[b]!=0)return (x[a] - x[b]) / (y[a] - y[b]);
	return 0;
}

double check(int a,int b,int c){
	double k1 = xielv(a,b);
	double k2 = xielv(b,c);
	double k3 = xielv(a,c);
	if(k1==k2&&k1==k3&&k2==k3)return -1;
	int abx=abs(x[a]-x[b]);
	int aby=abs(y[a]-y[b]);
	int res=3;
	if(min(abx,aby)==0){
		res+=max(abx,aby)-1;
	}else if(max(abx,aby)%min(abx,aby)==0){
		res+=min(abx,aby)-1;
	}
	int acx=abs(x[a]-x[c]);
	int acy=abs(y[a]-y[c]);
	if(min(acx,acy)==0){
		res+=max(acx,acy)-1;
	}else if(max(acx,acy)%min(acx,acy)==0){
		res+=min(acx,acy)-1;
	}
	int bcx=abs(x[b]-x[c]);
	int bcy=abs(y[b]-y[c]);
	if(min(bcx,bcy)==0){
		res+=max(bcx,bcy)-1;
	}else if(max(bcx,bcy)%min(bcx,bcy)==0){
		res+=min(bcx,bcy)-1;
	}
	return res;
}

void solve(){
	while(cin >> n){
		for(int i = 1 ; i <= n ; i++){
			cin >> x[i] >> y[i];
		}
		int maxn = 0;
		for(int i = 1;  i <= n ; i ++){
			for(int j = i + 1 ; j <= n ; j ++){
				for(int k = j + 1 ; k <= n ; k ++){
					double t = check(i,j,k);
//					cout<<i<<" "<<j<<" "<<k<<" "<<t<<endl;
					if(t > maxn){
						maxn = t;
					}
				}
			}
		}
		cout<< maxn <<endl;
	}
}

signed main(){
//	int T;cin >> T;while(T--){
		solve();
//	}
	return 0;
}