#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,ans;
	cin>>n>>m;
	if(m==1){
		cout<<"YES"<<'\n';
		return 0;
	}
//	if(n==1){
//		cout<<"NO"<<'\n';
//		return 0;
//	}
	while(m){
//	cout<<n<<" "<<m<<'\n';   
		ans=n%m;
		m=ans;
//		cout<<ans<<'\n';
		if(ans==1){
			cout<<"YES"<<'\n';
			return 0;
		}
		}
	cout<<"NO"<<'\n';
}