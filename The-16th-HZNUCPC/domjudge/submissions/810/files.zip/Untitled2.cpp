#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
typedef long long ll;
int sum,T,n;ll m;
ll x[1000],y[1000],k1,k2,k3;
long long gcd(long long a,long long b)
{
return a%b==0?b:gcd(b,a%b);
}
int main(){
	
  scanf("%d",&n);
for (int i=1;i<=n;i++)
    {
	scanf("%lld%lld",&x[i],&y[i]);
	}
for (int i=1;i<=n-2;i++)
  for (int j=i+1;j<=n-1;j++)
    for (int k=j+1;k<=n;k++)
      {
      if (x[i]==x[j]) k1=mod;else k1=(y[i]-y[j]+0.0)/(x[i]-x[j]);
      if (x[i]==x[k]) k2=mod;else k2=(y[i]-y[k]+0.0)/(x[i]-x[k]);
      if (x[j]==x[k]) k3=mod;else k2=(y[j]-y[k]+0.0)/(x[j]-x[k]);
      if (k1!=k2&&k1!=k2&&k2!=k3)
        {
        m=max(gcd(abs(x[i]-x[j]),abs(y[i]-y[j]))+gcd(abs(x[i]-x[k]),abs(y[i]-y[k]))+gcd(abs(x[k]-x[j]),abs(y[k]-y[j])),m);
		}
	  }
cout<<m<<endl;


}