#include<bits/stdc++.h>
using namespace std;
pair<long long,long long>z[200];
int main()
{
	long long n,cnt=1,maxx=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		long long x,y;
		cin>>x>>y;
		z[i]={x,y};
	}
	for(long long i=1;i<=n;i++)
	{
		for(long long j=i+1;j<=n;j++)
		{
			for(long long k=j+1;k<=n;k++)
			{
				long long a,b,c;
				double aa,bb,cc;
				aa=sqrt(1.0*abs(z[i].first-z[j].first)*abs(z[i].first-z[j].first)+1.0*abs(z[i].second-z[j].second)*abs(z[i].second-z[j].second));
				bb=sqrt(1.0*abs(z[i].first-z[k].first)*abs(z[i].first-z[k].first)+1.0*abs(z[i].second-z[k].second)*abs(z[i].second-z[k].second));
				cc=sqrt(1.0*abs(z[k].first-z[j].first)*abs(z[k].first-z[j].first)+1.0*abs(z[k].second-z[j].second)*abs(z[k].second-z[j].second));
				
				
				if(abs(z[i].first-z[j].first)==0)a=abs(z[i].second-z[j].second);
				else if(abs(z[i].second-z[j].second)==0)a=abs(z[i].first-z[j].first);
				else a=__gcd(abs(z[i].first-z[j].first),abs(z[i].second-z[j].second));
				
				if(abs(z[i].first-z[k].first)==0)b=abs(z[i].second-z[k].second);
				else if(abs(z[i].second-z[k].second)==0)b=abs(z[i].first-z[k].first);
				else b=__gcd(abs(z[i].first-z[k].first),abs(z[i].second-z[k].second));
				
				if(abs(z[k].first-z[j].first)==0)c=abs(z[k].second-z[j].second);
				else if(abs(z[k].second-z[j].second)==0)c=abs(z[k].first-z[j].first);
				else c=__gcd(abs(z[k].first-z[j].first),abs(z[k].second-z[j].second));
				long long s;
				if(aa+bb<=cc||bb+cc<=aa||aa+cc<=bb)s=0;
				else s=a+b+c;
				maxx=max(maxx,s);
			}
		}
	}
	cout<<maxx<<endl;
}