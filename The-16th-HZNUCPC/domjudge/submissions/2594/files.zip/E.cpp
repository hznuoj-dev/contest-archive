#include<bits/stdc++.h>


#define int long long
#define endl '\n'
using namespace std;


struct num {
	int x,y;
};


int n,x,y;

int dx[]= {-1,1,0,0};
int dy[]= {0,0,-1,1};
int inf=1e18;
num a[110];

int ds(num a1,num a2)
{
	a1.x-=a2.x;
	a1.y-=a2.y;
	a2={0,0};
	if(a1.x<0)a1.x=-a1.x;
	if(a1.y<0)a1.y=-a1.y;
	if(a1.x==0)return a1.y;
	if(a1.y==0)return a1.x;
	int k=__gcd(a1.x,a1.y);	
	return k;
}

double zx(num a,num b)
{
	return sqrt((a.x-b.x)*(a.x-b.x)+(a.y-b.y)*(a.y-b.y));
}
int yx(num a1,num a2,num a3)
{
	double b1=zx(a1,a2);
	double b2=zx(a1,a3);
	double b3=zx(a3,a2);
	
	if(b1+b2<=b3)return 0;
	if(b1+b3<=b2)return 0;
	if(b3+b2<=b1)return 0;
	
	if(a1.x==a2.x&&a1.y==a2.y)return 0;
	if(a2.x==a3.x&&a2.y==a3.y)return 0;
	if(a1.x==a3.x&&a1.y==a3.y)return 0;
	
	if(a1.x==a2.x&&a2.x==a3.x)return 0;
	if(a1.y==a2.y&&a2.y==a3.y)return 0;
//	cout<<ds(a1,a2)<<endl;ds(a1,a3)+ds(a2,a3)
	return ds(a1,a2)+ds(a1,a3)+ds(a2,a3);
	
}



void slove() {
	cin>>n;

	for(int i=1; i<=n; i++) {
		cin>>a[i].x>>a[i].y;
	}

	int mx=0;
	for(int i=1; i<=n; i++)
		for(int j=i+1; j<=n; j++)
			for(int k=j+1; k<=n; k++) {
				mx=max(mx,yx(a[i],a[j],a[k]));
			}

	cout<<mx<<endl;

}

signed main() {
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);

	int t=1;
//	cin>>t;

	while(t--) {
		slove();
	}
}