#include<bits/stdc++.h>
using namespace std;

long long x[110],y[110];
long long mx=0;
bool is(int a,int b,int c)//�жϵ�a,b,c�Ƿ���ͬһֱ��
{
    //(x[b]-x[a])/(y[b]-y[a])==(x[c]-x[b])/(y[c]-y[b])
    if ((x[b]-x[a])*(y[c]-y[b])==(x[c]-x[b])*(y[b]-y[a]))return 0;
    else return 1;
}
long long cal(int a,int b,int c)
{
	long long val=0;
	long long gab=__gcd(abs(y[a]-y[b]),abs(x[a]-x[b]));
	long long gac=__gcd(abs(y[a]-y[c]),abs(x[a]-x[c]));
	long long gbc=__gcd(abs(y[c]-y[b]),abs(x[c]-x[b]));
	if(x[a]==x[b])
	{
		val+=abs(x[a]-x[b])+1;
	}
	else val+=abs(x[a]-x[b])/(abs(x[a]-x[b])/gab);
	if(x[a]==x[c])
	{
		val+=abs(x[a]-x[c])+1;
	}
	else val+=abs(x[a]-x[c])/(abs(x[a]-x[c])/gac);
	if(x[b]==x[c])
	{
		val+=abs(x[c]-x[b])+1;
	}
	else val+=abs(x[c]-x[b])/(abs(x[c]-x[b])/gbc);
	return val;
	
}
int n;
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)cin>>x[i]>>y[i];
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				if(is(i,j,k))mx=max(mx,cal(i,j,k));
			}
		}
	}
	cout<<mx<<"\n";
	return 0;
}

