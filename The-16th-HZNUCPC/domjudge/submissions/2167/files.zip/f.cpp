#include<bits/stdc++.h>
using namespace std;

int main(){
	long long n,m;
	while(scanf("%lld %lld",&n,&m)!=EOF){
		if(m==1){
			printf("YES\n");
			continue;
		}
		if(n<=m){
			printf("NO\n");
			continue;
		}
		long long ans=n;
		for(int i=2;i<=sqrt(n);i++){
			if(n%i==0){
				ans=i;
				break;
			}
		}
		if(ans>m){
			printf("YES\n");
		}else{
			printf("NO\n");
		}
	}
	return 0;
}
