#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll,ll>pii;
#define x first
#define y second
const ll N=110;
pii a[N];
bool check(pii a,pii b,pii c) {
	return (a.y-b.y)*(a.x-c.x)!=(a.y-c.y)*(a.x-b.x);
}
ll calc(pii a,pii b) {
	ll x=abs(a.x-b.x),y=abs(a.y-b.y);
	return __gcd(x,y);
}
ll solve(pii a,pii b,pii c) {
	return calc(a,b)+calc(a,c)+calc(b,c);
}
int main() {
	ll n,res=0;
	scanf("%lld",&n);
	for(ll i=1,x,y; i<=n; i++) {
		scanf("%lld%lld%",&x,&y);
		a[i]= {x,y};
	}
	for(ll i=1; i<=n; i++) {
		for(ll j=i+1; j<=n; j++) {
			for(ll k=1; k<=n; k++) {
				if(check(a[i],a[j],a[k])) {
					res=max(res,solve(a[i],a[j],a[k]));
				}
			}
		}
	}
	printf("%lld\n",res);
}