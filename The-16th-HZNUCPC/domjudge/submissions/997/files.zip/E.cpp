#include<bits/stdc++.h>
using namespace std;

int gcd(int x, int y){
	return y == 0 ? x : gcd(y, x % y);
}
int main(){
//	printf("%d %d\n", gcd(5, 0), gcd(0, 5));
//	return 0;
	int n;
	scanf("%d", &n);
	int xx[102], yy[102];
	for(int i=0; i< n; i++) {
		scanf("%d%d", &xx[i], &yy[i]);
	}
	int maxn = 0;
	for(int i=0; i < n; i++) {
		for(int j = i + 1; j< n; j++) {
			for(int k = j + 1; k < n; k++) {	
//				printf("%d %d\n", xx[i], yy[i]);
				int ans = 0;
				if (xx[j] - xx[i] == 0 && xx[k] - xx[i] == 0)
					continue;
				if ((yy[j] - yy[i]) * 1.0 / (xx[j] - xx[i]) == 
					(yy[k] - yy[i]) * 1.0 / (xx[k] - xx[i]))
					continue;
				int x1 = abs(xx[j] - xx[i]);
				int y1 = abs(yy[j] - yy[i]);
				int g1 = gcd(x1, y1);
				ans += g1;
				int x2 = abs(xx[k] - xx[i]);
				int y2 = abs(yy[k] - yy[i]);
				int g2 = gcd(x2, y2);
				ans += g2;
				int x3 = abs(xx[k] - xx[j]);
				int y3 = abs(yy[k] - yy[j]);
				int g3 = gcd(x3, y3);
				ans += g3;
				maxn = max(maxn, ans);
//				printf("%d %d %d\n", g1, g2, g3);
			}
		}
	}
	printf("%d\n", maxn);
}