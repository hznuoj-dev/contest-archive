#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=300005;
string a, b;
int c[26][26];
int aa[26], bb[26];
const int MOD = 1e9 + 7;
const int inv2 = (MOD+1)/2;
int v1 = 0, v2 = 0, k1, k2;
inline void dela(int x) {
	aa[x]--;
	if(aa[x] == 0) --k1;
}
inline void delb(int x) {
	bb[x]--;
	if(bb[x] == 0) --k2;
}
inline void adda(int x) {
	if(aa[x] == 0) ++k1;
	aa[x]++;
}
inline void addb(int x) {
	if(bb[x] == 0) ++k2;
	bb[x]++;
}
int main(){
#ifndef ONLINE_JUDGE
	//freopen("in.txt","r",stdin);
#endif
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	cin >> a >> b;
	for (int i = 0; i < a.size(); ++i) {
		aa[a[i]-'a']++;
		bb[b[i]-'a']++;
		c[a[i]-'a'][b[i]-'a']++;
	}
	
	for (int i = 0; i < 26; ++i) if(aa[i]) ++v1;
	for (int i = 0; i < 26; ++i) if(bb[i]) ++v2;
	
	LL ans = 0;
	for (int i = 0; i < 26; ++i) {
		for (int j = 0; j < 26; ++j) {
			for (int x = 0; x < 26; ++x) {
				for (int y = 0; y < 26; ++y) {
					if(i == x && j == y) {
						if(c[i][j] <= 1) continue;
						else {
							k1 = v1, k2 = v2;
							dela(i);
							dela(x);
							delb(j);
							delb(y);
							adda(j);
							adda(y);
							addb(i);
							addb(x);
							if(k1 == k2) {
								ans = (ans + c[i][j] * 1LL *(c[i][j]-1) % MOD) % MOD;
							}
							adda(i);
							adda(x);
							addb(j);
							addb(y);
							dela(j);
							dela(y);
							delb(i);
							delb(x);
						}
					}
					else {
						if(c[i][j] == 0 || c[x][y] == 0) continue;
						else {
							k1 = v1, k2 = v2;
							dela(i);
							dela(x);
							delb(j);
							delb(y);
							adda(j);
							adda(y);
							addb(i);
							addb(x);
							if(k1 == k2) {
								ans = (ans + c[i][j] * 1LL * c[x][y] % MOD) % MOD;
							}
							adda(i);
							adda(x);
							addb(j);
							addb(y);
							dela(j);
							dela(y);
							delb(i);
							delb(x);
						}
					}
				}
			}
		}
	}
	printf("%lld\n", ans * inv2 % MOD);
    return 0;
}