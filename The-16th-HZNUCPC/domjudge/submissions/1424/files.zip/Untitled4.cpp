#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mod = 1e9 + 7;
int p[27], q[27];
ll mp[27][27];
int main()	{
	ll ans = 0;
	string a, b;
	cin >> a >> b;
	int len = a.size();
	for (int i = 0; i < len; i++)	{
		p[a[i] - 'a']++, q[b[i] - 'a']++;
		mp[a[i] - 'a'][b[i] - 'a']++;
	}
	for (int ii = 0; ii <= 675; ii++)	{
		for (int jj = ii; jj <= 675; jj++)	
				{
					int i = ii / 26, j = ii % 26, k = jj / 26, w = jj % 26;
					if (mp[i][j] == 0 || mp[k][w] == 0)	continue;
					if (i == k && j == w && mp[i][j] <= 1)	continue;	
					//printf("%d %d %d %d\n", i, j, k, w);
					p[i]--, p[k]--, p[j]++, p[w]++;
					q[i]++, q[k]++, q[j]--, q[w]--;
					int cnt1 = 0, cnt2 = 0;
					for (int pp = 0; pp < 26; pp++)	{
						if (p[pp] != 0)	cnt1++;
						if (q[pp] != 0)	cnt2++;
					}
					//printf("%d %d\n", cnt1, cnt2);
					if (cnt1 == cnt2)	{
						if (i == k && j == w)	{
							ans += mp[i][j] * (mp[i][j] - 1) / 2 % mod;
						}	else	{
							ans += mp[i][j] * mp[k][w] % mod;
						}
					}
					p[i]++, p[k]++, p[j]--, p[w]--;
					q[i]--, q[k]--, q[j]++, q[w]++;
				}
	}
	printf("%lld\n", ans);
}