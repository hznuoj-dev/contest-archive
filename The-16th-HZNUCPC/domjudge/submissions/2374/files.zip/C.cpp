#include <bits/stdc++.h>
using namespace std;

// #define DEBUG

const int maxn = 1e5 + 5;
const long long mod = 1e9 + 7;

string s1, s2;
long long set1, set2, cnt1[30], cnt2[30];
vector<int> id;
long long t1[5], t2[5];
long long ans, hid;

void f() {
	for (int i = 0; i < 4; i++) {
		printf("%d ", cnt1[i]);
	}
	puts("");
	for (int i = 0; i < 4; i++) {
		printf("%d ", cnt2[i]);
	}
	puts("");
}

int main() {
	cin >> s1 >> s2;
	for (char c : s1) {
		if (cnt1[c - 'a']++ == 0) set1++;
	}
	for (char c : s2) {
		if (cnt2[c - 'a']++ == 0) set2++;
	}
	for (int i = 0; i < s1.size(); i++) {
		if (cnt1[s1[i] - 'a'] < 3 || cnt1[s2[i] - 'a'] < 3 ||
			cnt2[s1[i] - 'a'] < 3 || cnt2[s2[i] - 'a'] < 3) {
			id.emplace_back(i);
			// cerr << i << endl;
		}
		else hid++;
	}
	// f();
	if (set1 == set2) {
		ans += hid * (hid - 1) / 2;
		ans %= mod;
	}
	for (int i : id) {
		if (cnt1[s1[i] - 'a']-- == 1) set1--;
		if (cnt1[s2[i] - 'a']++ == 0) set1++;
		if (cnt2[s1[i] - 'a']++ == 0) set2++;
		if (cnt2[s2[i] - 'a']-- == 1) set2--;

		if (set1 == set2) {
			ans += hid;
			ans %= mod;
		}

		for (int j : id) {
			if (j <= i) continue;

			if (cnt1[s1[j] - 'a']-- == 1) set1--;
			if (cnt1[s2[j] - 'a']++ == 0) set1++;
			if (cnt2[s1[j] - 'a']++ == 0) set2++;
			if (cnt2[s2[j] - 'a']-- == 1) set2--;

			// printf("\n%d %d:\n", i, j);
			// f();

			if (set1 == set2) {
				ans++;
				ans %= mod;
			}

			if (cnt1[s1[j] - 'a']++ == 0) set1++;
			if (cnt1[s2[j] - 'a']-- == 1) set1--;
			if (cnt2[s1[j] - 'a']-- == 1) set2--;
			if (cnt2[s2[j] - 'a']++ == 0) set2++;
			// f();
		}

		if (cnt1[s1[i] - 'a']++ == 0) set1++;
		if (cnt1[s2[i] - 'a']-- == 1) set1--;
		if (cnt2[s1[i] - 'a']-- == 1) set2--;
		if (cnt2[s2[i] - 'a']++ == 0) set2++;
	}
	/*
	for (int i = -2; i <= 2; i++) {
		for (int j = -2; j <= i; j++) {
			if (i + j == set2 - set1) {
				if (i == j) {
					ans += t[i] * (t[i] - 1) / 2;
					ans %= mod;
				}
				else {
					ans += t[i] * t[j];
					ans %= mod;
				}
			}
		}
	}
	*/
	printf("%lld\n", ans);
    return 0;
}