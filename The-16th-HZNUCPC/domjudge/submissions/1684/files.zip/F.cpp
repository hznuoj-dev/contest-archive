#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m;
	while(cin>>n>>m){
		bool flag =true;
		if(n<=m)flag =false;
		while(m!=1){
			if(n%m==0){
				flag = false;
				break;
			}
			m= n%m;
			
			
			
		}
		if(flag){
			cout <<"YES"<<endl;
		}else{
			cout <<"NO"<<endl;
		}
	}
	return 0;
}