#include<bits/stdc++.h>
using namespace std;
#define int long long 
int n,m,k;
int s[25][25];
int dir[4][2]={1,0,0,1,-1,0,0,-1};
int check(int x,int y){
	int sum=0;
	for(int i=0;i<4;i++){
		int tx=dir[i][0]+x;
		int ty=dir[i][1]+y;
		if(tx>0&&ty>0&&tx<=19&&ty<=19){
			if(s[tx][ty]==0){
				sum++;
			}
		}
	}
	return sum;
}
void solve(){
	cin>>n;
	memset(s,0,sizeof(s));
	for(int i=0;i<n;i++){
		int x;int y;int q;
		cin>>x>>y>>q;
		if(q==1){
			s[x][y]=1;	
		}else{
			s[x][y]=2;
		}
	}
	int ans =0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(s[i][j]==1){
				int asd=check(i,j);
				ans +=asd;
			}
		}
	}
	cout<<ans<<endl;
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--){
		solve();
	}
//	solve();
	return 0;
}