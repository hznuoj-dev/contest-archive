#include<iostream>
using namespace std;
long long a,b; 
int main()
{
	long long n,m;
	cin>>n>>m;
while(1)
{
	if(m==1){
	cout<<"YES";
	break;}
	if(m==n%m||n%m==0){
	cout<<"NO";
	break;}
	else m=n%m;
	
}
	return 0;
}