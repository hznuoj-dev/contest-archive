#include<bits/stdc++.h>
#define int long long
using namespace std;
const int mod = 1e9+7;
signed main()
{
	int n,m;

	while(cin >> n >> m)
	{
		int flag = 0;
		for(int i = m-1;i >= 2;i--)
		{
			if(n % i == 0)
			{
				flag = 1;
				break;
			}
		}
		if(flag == 1)
		{
			cout << "NO" << endl;
		}
		else
		{
			cout << "YES" << endl;
		}
	}
	return 0;
}
