#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
const int mod = 1e9 + 7; 
const int N = 2e5 + 7;
i64 fac[N], inv[N], facinv[N];
i64 Mode(i64 a, i64 b){
	i64 sum = 1;
	i64 mode = mod;
	while(b){
		if(b & 1){
			sum = (sum * a) % mode;
			b --;
		}
		b /= 2;
		a = a * a % mode;
	}
	return sum;
}
void init(){
	fac[0] = inv[0] = facinv[0] = 1;
	fac[1] = inv[1] = facinv[1] = 1;
	for(int i = 2; i < N;  ++ i){
		fac[i] = fac[i - 1] * i % mod;
		inv[i] = mod - (mod / i * inv[mod % i] % mod);
		facinv[i] = facinv[i - 1] * inv[i] % mod;
	}
}
i64 c(int n, int k){
	if(k > n)	return 0;
	return fac[n] * facinv[k] % mod * facinv[n - k] % mod;
}

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	
	init();
	string s,t;
	cin >> s >> t;

	// map<char, int> mps;
	// map<char, int> mpt;

	// set<char>ss, st;
	// for(auto x : s){
	// 	mps[x] ++;
	// 	ss.insert(x);
	// }
	// for(auto x : t){
	// 	mpt[x] ++;
	// 	st.insert(x);
	// }

	// if(ss.size() > st.size()){
	// 	swap(s,t);
	// 	swap(mps, mpt);
	// 	swap(ss, st);
	// }
	// int idx0 = 0, idx1 = 0, idx2 = 0, idx3 = 0, idx4 = 0;
	// i64 ans = 0;
	// for(int i = 0; i < s.size(); i ++){
	// 	if(s[i] == t[i] || (mps[s[i]] == 1 && mpt[t[i]] == 1 && s[i] != t[i])){
	// 		idx0 ++;
	// 	}
	// 	if(ss.count(t[i]) == 0 && mps[s[i]] > 1 && mpt[t[i]] > 1){
	// 		idx1 ++;
	// 	}
	// 	if(mpt[t[i]] == 1 && ss.count(t[i]) == 0 && mps[s[i]] > 1){
	// 		idx2 ++;
	// 	}	
	// }
	// //cout << idx0 << " " << idx1 << " " << idx2 << '\n';
	// if(ss.size() == st.size()){
	// 	//cout << ss.size() << " " << st.size() << '\n';
	// 	ans += c(idx0, 2) % mod;
	// }
	// else if(ss.size() + 1 == st.size()){
	// 	ans += (idx0*idx1) % mod;
	// }
	// else if(ss.size() + 2 == st.size()){
	// 	ans += (idx0 * idx2) % mod;
	// }
	vector<vector<int>> g(27, vector<int>(27));
	for(int i = 0; i < s.size(); i ++){
		g[s[i] - 'a'][t[i] - 'a'] ++;
	}
	set<char>ss, st;
	vector<int> tots(26), tott(26);
	for(auto x : s){
		tots[x - 'a'] ++;
		ss.insert(x);
	}
	for(auto x : t){
		tott[x - 'a'] ++;
		st.insert(x);
	}

	i64 ans = 0;
	for(int i = 0; i < 26; i ++){
		for(int j = 0; j < 26; j ++){
			int cnt = 0;
			if(g[i][j] > 0){
				cnt = g[i][j];
				tots[i] --;
				tots[j] ++;
				tott[i] ++;
				tott[j] --;
				g[i][j] --;
				for(int x = i; x < 26; x ++){
					for(int y = j; y < 26; y ++){
						int res = 0;
						if(g[x][y] > 0){
							res = g[x][y];
							tots[x] --;
							tots[y] ++;
							tott[x] ++;
							tott[y] --;
							g[x][y] --;
							int a = 0, b = 0;
							for(int k = 0; k < 26; k ++){
								if(tots[k] > 0) a ++;
								if(tott[k] > 0) b ++;
							}
							if(a == b){
								if(i == x && y == j){
									ans = (ans + c(cnt, 2)) % mod;
								}
								else{
									ans = (ans + (res * cnt) % mod) % mod;
								}
							}
							tots[x] ++;
							tots[y] --;
							tott[x] --;
							tott[y] ++;
							g[x][y] ++;
							//cout << i << " " << j << " " << x << " " << y << " " << ans << '\n';
						}
					}
				}
				tots[i] ++;
				tots[j] --;
				tott[i] --;
				tott[j] ++;
				g[i][j] ++;
			}
		}
	}

	cout << ans << '\n';

	return 0;
}
