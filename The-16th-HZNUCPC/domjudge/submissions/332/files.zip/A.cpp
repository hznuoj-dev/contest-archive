#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
const int N = 30;
int g[N][N];
ll n, ans = 0;
vector<pair<int,int>> allb;

void solve()
{
	allb.clear();
	ans = 0;
	memset(g, 0, sizeof g);
	cin >> n;
	while(n --) {
		int x, y, c;
		cin >> x >> y >> c;
		g[x][y] = c;
		if(c == 1) allb.push_back({x, y});
	}
	pair<int,int> mv[4] = {{1, 0}, {-1, 0}, {0, -1}, {0, 1}};
	for(int i = 0; i < allb.size(); i++) {
		for(int j = 0; j < 4; j++) {
			int xx = allb[i].first + mv[j].first, yy = allb[i].second + mv[j].second;
			if(xx < 1 || xx > 19 || yy < 1 || yy > 19) continue;
			if(g[xx][yy] == 0) {
			ans ++;
			}
		}
	}
	cout << ans << "\n";
}

int main()
{
	IOS
	int T = 1;
	cin >> T;
	while(T--) 
		solve();	
	return 0;
}