#include<bits/stdc++.h>
//#define int long long
//#define mid (l+r>>1)
using namespace std;
typedef long long ll;
int x[105],y[105];

int main(){
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d%d",&x[i],&y[i]);
	}
	ll ans=0;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			for(int k=j+1;k<n;k++){
				if(y[i]==y[j]&&y[j]==y[k]
				||abs( (double)(x[i]-x[j])/(y[i]-y[j])-(double)(x[i]-x[k])/(y[i]-y[k]) )<0.00001){
					continue;
				}
				int s1,s2,s3;
				
				s1=__gcd(abs(x[i]-x[j]),abs(y[i]-y[j]));
				
				s2=__gcd(abs(x[i]-x[k]),abs(y[i]-y[k]));
				
				s3=__gcd(abs(x[j]-x[k]),abs(y[j]-y[k]));
				ans=max(ans,(ll)s1+s2+s3);
			}
		}
	}
	
	printf("%lld\n",ans);
	return 0;	
}