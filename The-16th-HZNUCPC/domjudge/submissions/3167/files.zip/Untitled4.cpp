#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
	int n,m;

	while(cin >> n >> m) {
		if(n == 1 || m == 1)
		{
			cout << "YES" << endl;
			continue;
		}
		if(n % 2 == 1)
		{
			cout << "YES" << endl;
		}
		else
		{
			if(m == 2 && n % 2 == 0)
			{
				cout << "NO" << endl;
			}
			else
			{
				if(n % 3 == 1)
				{
					cout<< "YES" << endl;	
				}
				else
				{
					cout << "NO" << endl;
				}
			}
		}
	}
	return 0;
}