#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 7;
int n;
int a[20][20],b[20][20];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int T;
	T = 1;
	cin >> T;
	while(T --){
		int x,y,z;
		int n;
		cin>>n;
		for(int i=1;i<=19;i++)
			for(int j=1;j<=19;j++) a[i][j]=0,b[i][j]=0;
		for(int i=1;i<=n;i++)
		{
			cin>>x>>y>>z;
			a[x][y]=z;
		}
		int ans=0;
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(!a[i][j])
				{
					int ok=0;
					if(j-1>=1&&a[i][j-1]==1) ok++;
					if(i-1>=1&&a[i-1][j]==1) ok++;
					if(i+1<20&&a[i+1][j]==1) ok++;
					if(j+1<20&&a[i][j+1]==1) ok++;
					if(ok&&!b[i][j])
					{
						b[i][j]=1;
						ans+=ok;
					}
				}
			}
		}
		cout<<ans<<endl;
		
	}
}