#include<bits/stdc++.h>
#define ll long long

bool dfs ( ll n, ll m ) {
	if ( m == 1 ) return true;
	ll nxt = n % m;
	if ( nxt == 0 ) return false;
	return dfs ( n, nxt );
}

signed main() {
	ll n, m;
	scanf ( "%lld%lld", &n, &m );
	if ( n < m ) return puts ( "NO" ), 0;
	puts ( dfs ( n, m ) ? "YES" : "NO" );
}