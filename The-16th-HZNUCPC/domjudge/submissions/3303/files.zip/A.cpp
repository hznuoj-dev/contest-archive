#include<iostream>
#include<cmath>
using namespace std;
long long maxx,maxy,minx=1000000009,miny=1000000009;
long long res,n,x[100010],y[100010];
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>x[i]>>y[i];
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int h=j+1;h<=n;h++)
	{   if(abs(((y[i]-y[j])*1.0/(x[i]-x[j])*1.0))==abs(((y[h]-y[j])*1.0/(x[h]-x[j])*1.0)))continue;
				maxx=0,maxy=0,minx=1000000009,miny=1000000009;
				maxx=max(maxx,x[i]);
				maxx=max(maxx,x[j]);
				maxx=max(maxx,x[h]);
				maxy=max(maxy,y[i]);
				maxy=max(maxy,y[j]);
				maxy=max(maxy,y[h]);
				minx=min(minx,x[i]);
				minx=min(minx,x[j]);
				minx=min(minx,x[h]);
				miny=min(miny,y[i]);
				miny=min(miny,y[j]);
				miny=min(miny,y[h]);
				long long mianji=(maxx-minx)*(maxy-miny);
			//	cout<<mianji<<endl;
				double max1=abs(x[i]-x[j])*1.0*abs(y[i]-y[j])/2;
				double max2=abs(x[h]-x[j])*1.0*abs(y[h]-y[j])/2;
				double max3=abs(x[i]-x[h])*1.0*abs(y[i]-y[h])/2;
				mianji=mianji-max1-max2-max3;
				res=max(res,mianji);
			}
		}
	}

	cout<<res;
	return 0;
}