#include<iostream>
using namespace std;

struct  dian{
	long long x,y;
}a[110];


long long gcd(long long a,long long b){
	long long c;
	if(a<b){
		b+=a;
		a=b-a;
		b-=a;
	}
	while(a%b!=0){
		c=a%b;
		a=b;
		b=c;
	}
	return b;
}

long long maxs=0,sum=0;

int main()
{
	long long n,o,p,q;
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld%lld",&a[i].x,&a[i].y);
	}
	for(int i=1;i<=n-2;i++){
	    for(int j=i+1;j<=n-1;j++){
	    	for(int k=j+1;k<=n;k++){
	    		if((a[i].x-a[j].x)*(a[j].y-a[k].y)==(a[j].x-a[k].x)*(a[i].y-a[j].y))continue;
	    		if(a[i].x-a[j].x!=0&&a[i].y-a[j].y!=0)o=gcd(abs(a[i].x-a[j].x),abs(a[i].y-a[j].y))-1;
	    		else o=abs(a[i].x-a[j].x)+abs(a[i].y-a[j].y)-1;
	    		if(a[i].x-a[k].x!=0&&a[i].y-a[k].y!=0)p=gcd(abs(a[i].x-a[k].x),abs(a[i].y-a[k].y))-1;
	    		else p=abs(a[i].x-a[k].x)+abs(a[i].y-a[k].y)-1;
	    		if(a[j].x-a[k].x!=0&&a[j].y-a[k].y!=0)q=gcd(abs(a[k].x-a[j].x),abs(a[k].y-a[j].y))-1;
	    		else q=abs(a[k].x-a[j].x)+abs(a[k].y-a[j].y)-1;
	    		sum=o+p+q;
	    		maxs=max(sum,maxs);
			}
		}
    }
    printf("%lld",maxs+3);
	return 0;
}

