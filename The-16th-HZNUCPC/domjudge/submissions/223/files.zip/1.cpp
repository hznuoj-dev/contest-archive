#include<bits/stdc++.h>
using namespace std;
#define ll long long
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	ll n,m;
	cin>>n>>m;
	while(n%m!=1&&n%m!=0)
	{
		m=n%m;
	}
	if(n%m==1)
	cout<<"YES\n";
	else if(n%m==0)
	cout<<"NO\n";	
}