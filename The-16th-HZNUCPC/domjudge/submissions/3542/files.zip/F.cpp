#include <bits/stdc++.h>

#define ll long long

using namespace std;

ll n,m;//ncai,mxuan

int main(){
	cin>>n>>m;
	if(n==1 || m==1 || n%m==1) cout<<"YES"<<endl; 
	else if(n<=m || __gcd(n,m)!=1) cout<<"NO"<<endl;
	else if(n&1 && __gcd(n,m)==1) cout<<"NO"<<endl;
	else if(n&1) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	
	
	return 0;
}

