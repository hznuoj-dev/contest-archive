#include <stdio.h>
#include <string.h>
typedef struct black
{
	int x1;
	int y1;
}black;
int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};
int main()
{
	int arr[25][25];
	int option=0;
	scanf("%d",&option);
	while(option--)
	{
		memset(arr,0xff,sizeof(arr));
		int ans=0;
		black arr1[400]={0};
		int k=0;
		
		int num=0;
		scanf("%d",&num);

		while(num--)
		{
			int x,y,c=0;
			scanf("%d %d %d",&x,&y,&c);
			if (c==2)
			{
				arr[x][y]=0;	
			}
			else   //c=1
			{
				arr1[k].x1=x;
				arr1[k].y1=y;
				arr[x][y]=1;
				k++;
			}
		}
		for (int i=0;i<k;i++)
		{
			int nowx=arr1[i].x1;
			int nowy=arr1[i].y1;
			for (int j=0;j<4;j++)
			{
				int nowx1=nowx+dx[j];
				int nowy1=nowy+dy[j];
				if (nowx1>=1 && nowx1<=19 && nowy1>=1 && nowy1<= 19 && arr[nowx1][nowy1]==-1)
				{
					ans++;
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0; 
}

