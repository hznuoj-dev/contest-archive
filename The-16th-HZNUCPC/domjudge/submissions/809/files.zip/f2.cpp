#include <bits/stdc++.h>
using namespace std;
const int N=1000,M=N*2;
int e[M], ne[M], h[N], w[M], idx;
#define ll long long 
//#define int long long

ll qpow(ll a,ll b,ll p)
{
	ll sum=1;
	while(b)
	{
		if(b&1)
		sum*=a%p;
		b>>=1;
		a*=a%p;
	}
	return sum;
}

void add(int a,int b,int c){
	e[idx]=b;w[idx]=c;ne[idx]=h[a];h[a]=idx++;
}

int g[N][N];
bool st[N][N];

signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int m,n;
	cin>>m>>n;
	if(n==1)
	cout<<"YES"<<endl;
	else if(n==2)
	{
		if(m%2==0)
		cout<<"NO";
		else
		cout<<"YES";
	}
	else
	{
		if(m%2==0)
		cout<<"NO"<<endl;
		else 
	{
	   if(n/2-1!=1)
	   cout<<"YES"<<endl;
	   else
	   cout<<"NO"<<endl;
	}
	}

	return 0;
}