#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve(){
    ll n,m;
    cin>>n>>m;

    if(n==1||m==1)cout<<"YES\n";
    else {
        if(n<=m)cout<<"NO\n";
        else {
        	ll op=1;
        	for(ll i=2;i<=sqrt(n);i++){
        		if(n%i==0){
        			if(i<=m)op=0;
				}
			}
			if(op)cout<<"YES\n";
			else cout<<"NO\n";
		}
    }
}



int main(){
    ios::sync_with_stdio(false);
    int T=1;
    //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}
