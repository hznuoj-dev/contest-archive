#include <bits/stdc++.h>
#define int int64_t
#define endl '\n'
using namespace std;

void solve() {
	int n, m;
	cin >> n >> m;
	if(m == 1 or n == 1) {
		cout << "YES\n";
		return;
	}
	int x = n;
	for(int i = 2; i <= n / i; ++ i) {
		if(n % i == 0) {
			x = i;
			break;
		}
	}
	if(x <= m) {
		cout << "NO\n";
		return;
	}
	else {
		cout << "YES\n";
		return;
	}
}

int32_t main() {
	cin.tie(0);
	cout.tie(0);
	ios::sync_with_stdio(false);
	
	solve();
	
	return 0;
}