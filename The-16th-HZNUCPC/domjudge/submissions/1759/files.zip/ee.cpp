#include<bits/stdc++.h>
typedef long long ll;
#define int long long
const ll N=5e3+7;
const ll mod =1e9+7;
const double eps=1e-6;
using namespace std;
vector<pair<int,int>> a;
void slove(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int x,y;
		cin>>x>>y;
		a.push_back({x,y});
	}
	int maxn=0;
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			for(int p=0;p<n;p++)
			{
				if(i==j||j==p||i==p) continue;
				int a1=a[j].first-a[i].first,b1=a[j].second-a[i].second;
				int a2=a[j].first-a[p].first,b2=a[j].second-a[p].second;
				if(a1*b2==a2*b1) continue;	
					int p1=__gcd(abs(a[i].first-a[j].first),abs(a[i].second-a[j].second));
					int p2=__gcd(abs(a[i].first-a[p].first),abs(a[i].second-a[p].second));
					int p3=__gcd(abs(a[j].first-a[p].first),abs(a[j].second-a[p].second));
					maxn=max(maxn,p1+p2+p3);			
			}
		}
	}
	cout<<maxn;
}
signed main(){
	slove();
}
