#include <bits/stdc++.h>
#define ll long long

using namespace std;


int main(){
	ll n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"YES";
		return 0;
	}
	for(int i=m;i>0;i--){
		if(n%i==0){
			cout << "NO";
			break;
		}
		if(m==1) cout << "YES";
	}
}