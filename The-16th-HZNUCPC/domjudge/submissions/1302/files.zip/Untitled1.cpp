
#include <iostream>
using namespace std;
int main(){
	int a[21][21];
	for(int i=0;i<21;i++){
		for(int j=0;j<21;j++){
			a[i][j]=0;
		}
	}
  	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		for(int i=0;i<n;i++){
			int ai,bi,ci;
			cin>>ai>>bi>>ci;
			if(ci==1){
				a[ai][bi]=1;
			}else if(ci==2){
				a[ai][bi]=2;
			}
	}
	int sum=0;  
	for(int i=1;i<20;i++){
		for(int j=1;j<20;j++){
			if(a[i][j]==1){
				if(a[i-1][j]==0){
					sum++;
					a[i-1][j]=-1;
				}
				if(a[i+1][j]==0)
				{
					sum++;
					a[i+1][j]=-1;
				}
				if(a[i][j-1]==0){
					sum++;
					a[i][j-1]=-1;
				}
				if(a[i][j+1]==0){
					sum++;
					a[i][j+1]=-1;
				}
		}
	}	
}
cout<<sum<<endl;
}
}