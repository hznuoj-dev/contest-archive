#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+10;
int n;
ll a[N],b[N];
char s1[N],s2[N];
ll x[40][40];
ll ksm(ll a,ll b,ll mod)
{
	ll res=1;
	while(b)
	{
		if(b&1) res=res*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return res%mod;
}
int main()
{
	cin>>s1+1;
	ll ans=0;
	n=strlen(s1+1);
	cin>>s2+1;
	set<char> S1,S2;
	for(int i=1;i<=n;i++)
	{
		a[s1[i]-'a']++;
		b[s2[i]-'a']++;
		S1.insert(s1[i]);S2.insert(s2[i]);
		x[s1[i]-'a'][s2[i]-'a']++;
	}
	ll mod=1e9+7;
	int numa=S1.size();
	int numb=S2.size();
	for(int i=0;i<=26;i++)
	{
		for(int j=0;j<=26;j++)
		{
			for(int ii=0;ii<=26;ii++)
			{
				for(int jj=0;jj<=26;jj++)
				{
					// s1 shiqu i  get ii
					int flag1=0,flag2=0,flag3=0,flag4=0;
					int suma=numa,sumb=numb;
					int k1=x[i][ii];int k2=x[j][jj];
					
					int ai=a[i],aj=a[j],aii=a[ii],ajj=a[jj];
					int bi=b[i],bj=b[j],bii=b[ii],bjj=b[jj];
					a[i]-=k1;
					if(a[i]==0) suma--;
					a[j]-=k2;
					if(a[j]==0) suma--;
					
					b[ii]-=k1;
					if(b[ii]==0) sumb--;
					b[jj]-=k2;
					if(b[jj]==0) sumb--;
					
					a[ii]+=k1;
					if(a[ii]==k1) suma++;
					a[jj]+=k2;
					if(a[jj]==k2) suma++;
					
					b[i]+=k1;
					if(b[i]==k1) sumb++;
					b[j]+=k2;
					if(b[j]==k2) sumb++;
					
					if(suma==sumb)
					{
						if(i==j&&ii==jj)  ans=(ans+k1*(k1-1)%mod)%mod;
						else  ans=(ans+k1*k2)%mod;
					}
					b[i]=bi,b[ii]=bii,b[j]=bj,b[jj]=bjj;
					a[i]=ai,a[ii]=aii,a[j]=aj,a[jj]=ajj;
				}
			}
		}
	}

	printf("%lld\n",(ans*ksm(2,mod-2,mod))%mod);
}
