#include <bits/stdc++.h>
using namespace std;

int main(){
	long long n,m;
	int f=1;
	scanf("%lld%lld",&n,&m);
	if(n==1||m==1)printf("YES");
    else if(n<=m)printf("NO");
    else {
    	for(int i=2;i<=m&&i*i<=n;i++){
    		if(n%i==0){
    			f=0;
    			break;
			}
		}
		if(f)printf("YES");
		else printf("NO");
	}
	return 0;
}