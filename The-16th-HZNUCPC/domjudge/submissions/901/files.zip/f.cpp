#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=1e5+10,mod=1e9+7;
char s[N],t[N];
ll n,m;
bool check(ll x) {
	return n/x>n%(x+m-x-1)/(m-x);
}
void solve() {
	scanf("%lld%lld",&n,&m);
	if(n%m==0) {
		puts("NO");
		return ;
	}
	vector<ll>v;
	for(ll i=2; i*i<=n; i++) {
		if(n%i==0) {
			v.push_back(n/i);
			v.push_back(i);
		}
	}
	v.push_back(n);
	sort(v.begin(),v.end());
	for(auto x:v) {
		if(x>m) {
			break;
		}
		if(check(x)) {
			puts("NO");
			return ;
		}
	}
	puts("YES");
}
int main() {
	solve();
}