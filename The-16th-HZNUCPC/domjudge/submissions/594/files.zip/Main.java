import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		Scanner s= new Scanner(System.in);
		int[][] f = new int[20][20];
		int n = s.nextInt();
		while (n-- > 0) {
			int t = s.nextInt();
			int ans = 0;
			while (t-- > 0){
				int x = s.nextInt(),y = s.nextInt(),c = s.nextInt();
				
				if (f[x][y] != 0) {
					ans--;
					f[x][y] = c; 
					//System.out.println(ans);
				}
				f[x][y] = c;
				//if(y == 10) System.out.println("f="+f[x][y - 1]);
				if (c == 1) {
					if (f[x - 1][y] == 0) {
						f[x - 1][y] = 2;
						ans++;
						
					}
					if (f[x + 1][y] == 0 && x != 19) {
						f[x + 1][y] = 2;
						ans++;
					}
					if (f[x][y - 1] == 0) {
						f[x][y - 1] = 2;
						//System.out.println("x="+(y - 1));
						ans++;
					}
					if (f[x][y + 1] == 0 && y != 19) {
						f[x][y + 1] = 2;
						ans++;
					}
				}
				
			}
			System.out.println(ans);
		}
	}

}
