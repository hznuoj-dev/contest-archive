package project1;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;
import java.math.BigInteger;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class name2 {
	static int[][] position;
	public static void main(String[] args) throws IOException{
		PrintWriter out = new PrintWriter(System.out);
//		StreamTokenizer in = new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in)));
//		in.nextToken();int n = (int) in.nval;
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		position = new int[n][2];
		for(int i=0;i<n;i++){
//			in.nextToken();int x = (int) in.nval;
//			in.nextToken();int y = (int) in.nval;
			position[i][0] = sc.nextInt();
			position[i][1] = sc.nextInt();
		}
		int sum = n*(n-1)/2;
//		Set<Double> K = new Socket<>(); 
		ArrayList<Double> lists = new ArrayList<>();
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				if(j!=i){
					double yy = position[j][1]-position[i][1];
					double xx = position[j][0]-position[i][0];
					double k = yy/xx;
//					out.print(k+" ");out.flush();
					if(!lists.contains(k)){
						lists.add(k);
					}else{
						sum--;
					}
				}
			}
		}
		if(sum<3){
			out.print(0);
			out.flush();
		}else{
			out.print(sum);
			out.flush();
		}
		
	}

}
