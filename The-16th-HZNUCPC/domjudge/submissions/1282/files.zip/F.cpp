#include<iostream>
using namespace std;
int main(){

	long long n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"YES";
	}
	else{
		if(n<=m){
			cout<<"NO";
		}
		else{
		if(n%2==0){
			cout<<"NO";
		}
		else{
			int da=-1;
			for(int i=2;i*i<=n;i++){
				if(n%i==0){
					da=i;
					break;
				}
			}
			if(da<=m) cout<<"NO";
			else cout<<"YES";	
			}
		}
	}
	
}