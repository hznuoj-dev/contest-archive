#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mod 1000000007

ll dic[1000]={0};
ll num[2];
ll num0[2][26];
void solve(){
	ll ans=0;
	ll k1,k2,k;
	ll a,b,c,d;
    string c1,c2;
    cin>>c1>>c2;
    for(int i=0;i<c1.size();i++){
    	a=c1[i]-'a';
    	b=c2[i]-'a';
    	dic[a*26+b]++;
    	if(++num0[0][a]==1) num[0]++;
    	if(++num0[1][b]==1) num[1]++;
	}
	
	for(int i=0;i<26*26;i++){
    	for(int j=i;j<26*26;j++){
    		if(i==j){
    			k=(dic[i]-1)*dic[j]/2;
    			
			}
			else{
				k=dic[i]*dic[j];
			}
			k%=mod;
			if(k==0) continue;
			
			a=i/26;
			b=i%26;
			c=j/26;
			d=j%26;
			if(--num0[0][a]==0) num[0]--;
			if(--num0[0][c]==0) num[0]--;
			if(--num0[1][b]==0) num[1]--;
			if(--num0[1][d]==0) num[1]--;
			
			if(++num0[0][b]==1) num[0]++;
			if(++num0[0][d]==1) num[0]++;
			if(++num0[1][a]==1) num[1]++;
			if(++num0[1][c]==1) num[1]++;
			
			if(num[0]==num[1]){
				ans+=k;
				ans%=mod;
			//	cout<<k<<'\n';
			}
			if(--num0[0][b]==0) num[0]--;
			if(--num0[0][d]==0) num[0]--;
			if(--num0[1][a]==0) num[1]--;
			if(--num0[1][c]==0) num[1]--;
			
			if(++num0[0][a]==1) num[0]++;
			if(++num0[0][c]==1) num[0]++;
			if(++num0[1][b]==1) num[1]++;
			if(++num0[1][d]==1) num[1]++;
		}
	}
	cout<<ans<<'\n';
	
	
    
}



int main(){
    ios::sync_with_stdio(false);
    int T=1;
    //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}
