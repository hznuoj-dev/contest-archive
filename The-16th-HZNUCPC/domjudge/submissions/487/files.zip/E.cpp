#include<bits/stdc++.h>
using namespace std;
int n;
long long x[101],y[101],ans[101][101],aans;
int gcd(long long xx,long long yy)
{
	if(xx%yy==0)
	  return yy;
	return(yy,xx%yy);
}
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	  cin>>x[i]>>y[i];
	for(int i=1;i<=n;i++)
	  for(int j=i+1;j<=n;j++)
	    ans[i][j]=gcd(abs(x[i]-x[j]),abs(y[i]-y[j]))-1;
	for(int i=1;i<=n;i++)
	  for(int j=i+1;j<=n;j++)
	    for(int k=j+1;k<=n;k++)
	    {
	    	aans=max(aans,ans[i][j]+ans[j][k]+ans[i][k]+3);
		}
	cout<<aans;
	return 0;
}