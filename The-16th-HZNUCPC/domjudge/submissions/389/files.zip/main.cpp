#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const ll N = 1e6 + 10;

int dir[][2] = {1,0,0,1,-1,0,0,-1};
int x[N],y[N],op[N];
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        set<pair<int,int> > st;
        for(int i=1;i<=n;i++){
            cin>>x[i]>>y[i]>>op[i];
            st.insert({x[i],y[i]});
        }
        int ans = 0;
        for(int i=1;i<=n;i++){
            for(int k=0;k<4;k++){
                int xx = x[i]+dir[k][0];
                int yy = y[i]+dir[k][1];
                if(xx<1||yy<1||xx>19||yy>19) continue;
                if(st.count({xx,yy})) continue;
                ans ++;
            }   
        }
        cout<<ans<<endl;
    }
}