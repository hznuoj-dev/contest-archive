#include<bits/stdc++.h>
#define int long long
using namespace std;
int x[1000];
int y[1000];
signed main()
{
	int n;
	cin >> n;
	for(int i = 1; i <= n; i++)
	{
		cin >> x[i] >> y[i];
	}
	int ans = 0;
	for(int i = 1 ;i <= n; i++)
	{
		for(int j = i + 1; j <= n ;j++)
		{
			for(int k = j + 1; k <= n; k++)
			{
				if(x[i] == x[j]&&x[i] == x[k])continue;
				if((x[k] - x[i])*(y[j] - y[i]) == (x[j] - x[i])*(y[k]-y[i]))continue;
				int nowa = __gcd(abs(x[i]-x[j]),abs(y[i]-y[j]));
				nowa += __gcd(abs(x[k]-x[j]),abs(y[k]-y[j]));
				nowa += __gcd(abs(x[i]-x[k]),abs(y[i]-y[k]));
				ans = max(ans,nowa);
			}
		}
	}
	cout << ans << endl;
}