#include<bits/stdc++.h>
using namespace std;

const int N=3e5+5;
const int inf=1e9;

int ads[N<<2];
int l[N<<2],r[N<<2];
void Build(int L,int R,int rt)
{
	l[rt]=L , r[rt]=R;
	ads[rt]=inf;
	if(L==R)return;
	
	int mid=L+R>>1;
	Build(L,mid,rt<<1) , Build(mid+1,R,rt<<1|1);
}
int chaxun(int L,int R,int rt)
{
	if(l[rt]==r[rt])return ads[rt];
	
	int mid=l[rt]+r[rt]>>1;
	int res=inf;
	if(L<=mid)res=min(res,chaxun(L,R,rt<<1));
	if(R>mid)res=min(res,chaxun(L,R,rt<<1|1));
	return res;
}

void ddxg(int x,int rt,int C)
{
	if(l[rt]==r[rt])
	{
		ads[rt]=C;
		return;
	}
	int mid=l[rt]+r[rt]>>1;
	if(x<=mid)ddxg(x,rt<<1,C);
	else ddxg(x,rt<<1|1,C);
}



int n,m,x;
struct P
{
	int l,r;
};
vector<P>vp[100005];
vector<int>vv;

struct Q
{
	int id;
	int p;
};
vector<Q>vq[100005];

int ans[100005];
int dp[N];
int main()
{
	ios::sync_with_stdio(0);
	cin>>n>>m>>x;
	for(int i=1;i<=n;++i)
	{
		int tt,ll,rr;
		cin>>tt>>ll>>rr;
		vp[tt].push_back({ll,rr});
		
		vv.push_back(ll) , vv.push_back(rr);
	}
	for(int i=1;i<=m;++i)
	{
		int cc,pp;
		cin>>cc>>pp;
		vq[cc].push_back({i,pp});
		
		vv.push_back(pp);
	}
	
	vv.push_back(x) , vv.push_back(1);
	sort(vv.begin(),vv.end());
	vv.erase(unique(vv.begin(),vv.end()),vv.end());
	
	for(int tt=1;tt<=100000;++tt)
	{
		for(auto &ele:vp[tt])
		{
			ele.l=lower_bound(vv.begin(),vv.end(),ele.l)-vv.begin()+1;
			ele.r=lower_bound(vv.begin(),vv.end(),ele.r)-vv.begin()+1;
			
			//cout<<"che:"<<tt<<" "<<ele.l<<","<<ele.r<<"\n";
		}
		
		for(auto &ele:vq[tt])
		{
			ele.p=lower_bound(vv.begin(),vv.end(),ele.p)-vv.begin()+1;
			
			//cout<<"wen:"<<tt<<" "<<ele.p<<"\n";
		}
	}
	x=lower_bound(vv.begin(),vv.end(),x)-vv.begin()+1;
	
	Build(1,vv.size(),1);
	for(int i=1;i<=x;++i)dp[i]=inf;
	assert(x==vv.size());
	ddxg(x,1,0) , dp[x]=0;
	
	//cout<<"\n\n";
	
	//int flg=1;
	for(int myt=100000;myt>=1;--myt)
	{
		for(auto lr:vp[myt])
		{
			int ll=lr.l , rr=lr.r;
			//if(flg)cout<<"!!!!!!!!!!!"<<ll<<"\n" , flg=0;
			
			int val=chaxun(1,rr,1)+1;
			if(val<dp[ll])
			{
				ddxg(ll,1,val) , dp[ll]=val;
			}
			
//			for(int i=1;i<=x;++i)
//			{
//				cout<<"dp["<<i<<"]="<<chaxun(1,i,1)<<"\n";
//			}
			
			//cout<<"!!!\n";
		}
		
		for(auto qq:vq[myt])
		{
			int id=qq.id , pp=qq.p;
			
			ans[id]=chaxun(1,pp,1);
		}
	}
	
	for(int i=1;i<=m;++i)
	{
		if(ans[i]==inf)cout<<"-1\n";
		else assert(ans[i]<=n) , cout<<ans[i]<<"\n";
	}
	return 0;
}


/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5
*/