//#include<iostream>
//#include<algorithm>
//#include<vector>
//using namespace std;
//const int N = 400;
//int n;
//int num[N][N];
//int way[4][2] = {{-1 , 0} ,{1 , 0} , {0 , 1} , {0 , -1}};
//vector<pair<int,int>> a1;
//int main(){
//    int T;
//    cin >> T;
//    while(T--){
//		cin >> n;
//		int n1 , n2 , ans = 0;
//		a1.clear();
//		for(int i = 1 ; i <= 19 ; i++)
//			for(int j = 1 ; j <= 19 ; j++)
//				num[i][j] = 0;
//		for(int i = 1 , x ,y , c ; i <= n ; i++){
//			cin >> x >> y >> c;
//			num[x][y] = 1;
//			if(c == 1) a1.push_back({x , y});
//		}
//		for(int i = 0 ; i < a1.size();i++){
//			int x = a1[i].first;
//			int y = a1[i].first;
//			for(int j = 0 ; j < 4 ; j++){ 
//				int xx = x + way[j][0];
//				int yy = y + way[j][1];
//				if(num[xx][yy] || xx <= 0 || yy <= 0 || xx > 19 || yy > 19) continue;
//				ans++;
//			}
//		}
//		cout << ans << endl;
//    }
//}



#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
const int N = 110;
pair<long long,long long> num[N];
double di(pair<long long,long long> &a , pair<long long,long long>&b){
	return sqrt((a.first - b.first) * (a.first - b.first) + (a.second - b.second) * (a.second - b.second));
}
int main(){
	int n;
	cin >> n;
	for(int i = 1 , x , y ; i<=n;i++){
		cin >> x >> y;
		num[i] = {x , y};
	}
	long long ans = 0;
	for(int i = 1 ; i <= n;i++){
		for(int j = i + 1 ; j <= n ; j++){
			for(int k = j + 1 ; k <= n;k++){
				double s1 = di(num[i] , num[j]) , s2 = di(num[i] , num[k]) , s3 = di(num[j] , num[k]);
				if(max(s1 , max(s2 , s3)) >= (s1 + s2 + s3 - max(s1 , max(s2 , s3)))) continue;
				ans = max(ans , __gcd(abs(num[i].first - num[j].first) , abs(num[i].second - num[j].second)) + __gcd(abs(num[i].first - num[k].first) , abs(num[i].second - num[k].second)) + __gcd(abs(num[k].first - num[j].first) , abs(num[k].second - num[j].second)));
			}
		}
	}
	cout << ans << endl;
}