#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=110;
pair<int,int>a[N];


signed main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].first>>a[i].second;
	}
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j)continue;
			for(int k=1;k<=n;k++)
			{
				if(i==k||j==k)continue;
				int dx=abs(a[i].first-a[j].first);
				int dy=abs(a[i].second-a[j].second);
				int x=__gcd(dx,dy);
				int mx=x+1;
				dx=abs(a[j].first-a[k].first);
				dy=abs(a[j].second-a[k].second);
				x=__gcd(dx,dy);
				mx+=x+1;
				dx=abs(a[i].first-a[k].first);
				dy=abs(a[i].second-a[k].second);
				x=__gcd(dx,dy);
				mx+=x+1;
				mx-=3;
				ans=max(ans,mx);
			}
		}
	}
	cout<<ans<<endl;
}