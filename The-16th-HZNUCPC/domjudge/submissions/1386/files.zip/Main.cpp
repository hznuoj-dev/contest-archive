#include<bits/stdc++.h>
int main(){
	long long n,m;
	std::cin>>n>>m;
	long long cnt = 1;
	for(long long i=2;i<=sqrt(n);i++){
		if(n%i==0){
			cnt=i;
			break;
		}
	}
	if(cnt<=m&&cnt>1||n<=m){
		std::cout<<"NO"<<std::endl;
	}
	else{std::cout<<"YES"<<std::endl;}
} 
