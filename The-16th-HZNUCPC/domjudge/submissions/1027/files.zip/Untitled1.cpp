#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define db double
const int inf=1e14;
const int N=1e4+10;
int T;
int st[1000][1000];
struct zc{
	int x,y,z;
}d[N];
void run()
{int n;
cin>>n;
for(int i=1;i<=n;i++){
	int a,b,w;
	cin>>a>>b>>w;
	st[a][b]=1;
	d[i].x=a,d[i].y=b,d[i].z=w;
}int ans=0;
for(int i=1;i<=n;i++){
	if(d[i].z==2)continue;
	if(st[d[i].x+1][d[i].y]==0)ans++,st[d[i].x+1][d[i].y]=1;
	if(st[d[i].x-1][d[i].y]==0)ans++,st[d[i].x-1][d[i].y]=1;
	if(st[d[i].x][d[i].y+1]==0)ans++,st[d[i].x][d[i].y+1]=1;
	if(st[d[i].x][d[i].y-1]==0)ans++,st[d[i].x][d[i].y-1]=1;
}
	cout<<ans<<"\n";
	
}
signed  main()
{
	for(cin>>T;T--;)
	{
		run();
		
	}
return 0;
}