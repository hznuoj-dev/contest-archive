#include<bits/stdc++.h>
using namespace std;
#define ll long long 
ll xd(ll a,ll b,ll c,ll d)
{
	ll ds=0;
	ll xc,yc;
	xc=abs(a-c);
	yc=abs(b-d);
	ds=__gcd(xc,yc)-1;
	return ds;
}
int pd(ll a,ll b,ll c,ll d,ll e,ll f)
{
	if((1.0*(d-b))/(1.0*(c-a))==(1.0*(d-f))/(1.0*(c-e)))
	{
		return 0;
	}
	else
	{
		return 1;
	}
}
	
int main() {
	int d;
	cin>>d;
	ll x[101]={0};
	ll y[101]={0};
	ll i,j,k;
	for(i=1;i<=d;i++)
	{
		cin>>x[i]>>y[i];
	}
	ll ma=0;
	for(i=3;i<=d;i++)
	{
		for(j=2;j<i;j++)
		{
			for(k=1;k<j;k++)
			{
				if(pd(x[i],y[i],x[j],y[j],x[k],y[k])==1)
				{
					ma=max(xd(x[i],y[i],x[j],y[j])+xd(x[i],y[i],x[k],y[k])+xd(x[j],y[j],x[k],y[k])+3,ma);
				}
				
			}
		}
	}
	cout<<ma;
	
	
}