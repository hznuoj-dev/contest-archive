#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int P=1e9+7;
const int N=200000+7;
int n,m,k;
vector<int> G[N];
bool vis[N];
int top,S[N];
int fa[N],w[N];
int find(int u){
	return fa[u]==u?u:fa[u]=find(fa[u]);
}
void merge(int u,int v){
	int fu=find(u),fv=find(v);
	if(fu!=fv){
		fa[fu]=fv;
		w[fv]+=w[fu];
	}
}
bool dfs(int u){
	if(vis[u^1])return 0;
	if(vis[u])return 1;
	vis[u]=1;
	S[top++]=u;
	for(auto v:G[u])
		if(!dfs(v))
			return 0;
	return 1;
}
int from[N],dp[2][N];
bool twosat(int n){
	for(int i=0;i<n;i+=2){
		if(vis[i]||vis[i^1])continue;
		top=0;
		if(!dfs(i)){
			while(top)vis[S[--top]]=0;
			if(!dfs(i^1))return 0;
		}
	}
	map<int,int> sz;
	set<int> in,notin;
	for(int i=0;i<N;i++){
		fa[i]=i;
		w[i]=vis[i]^(i&1);
	}
	for(int i=0;i<n;i++){
		for(auto j:G[i]){
			merge(i,j);
		}
	}
	for(int i=0;i<n;i++){
		sz[find(i)]++;
	}
	for(int i=0;i<n;i+=2){
		if(!notin.count(find(i))){
			in.insert(find(i));
			notin.insert(find(i^1));
		}else{
			in.insert(find(i^1));
		}
	}
	vector<int> col(in.size());
	vector<pair<int,int>> val_p;
	map<int,vector<int>> val_from;
	for(auto i:in){
		res+=mp[i]-w[i];
		val_p.push_back({i,w[i]-mp[i]+w[i]});
		val_from[w[i]-mp[i]+w[i]].push_back(i);
	}
	vector<int> new_item;
	for(auto [x,ve]:val_from){
		int y=ve.size();
		for(int i=0;i<=20;i++){
			if(y>=(1<<i)){
				new_item.push_back(1<<i);
				y-=1<<i;
			}
		}
		if(y)new_item.push_back(y);
	}
	vector<vector<int>> dp(new_item.size()+1,vector<int>(q+1,0)),from=dp;
	for(int i=1;i<=new_item.size();i++){
		for(int j=q;j>=new_item[i];j--){
			if(dp[i-1][j-new_item[i]]){
				dp[i][j]=dp[i-1][j-new_item[i]]
				from[i][j]=j-new_item[i];
			}
			if(dp[i-1][j]){
				dp[i][j]=dp[i-1][j];
				from[i][j]=j;
			}
		}
	}
	if(dp[new_item.size()+1][q]){
		vector<int> use_val;
		int tmp_n=n,tmp_q=q;
		while(tmp_n>0){
			int ww=tmp_q-from[tmp_n][tmp_q];
			if(ww)use_val.push_back(ww);
			tmp_q=from[tmp_n][tmp_q];
			tmp_n--;
		}
		for(auto x:use_val){
			cout<<"WTF!\n";
		}
		return 1;
	}else{
		return 0;
	}
}
void solve(){
	cin>>n>>k>>m;
	for(int i=1,c,u,v;i<=m;i++){
		cin>>c>>u>>v;
		u=u*2-2;v=v*2-2;
		G[u].push_back(v^c);
		G[1^u].push_back(1^v^c);
	}
	if(twosat(2*n)){
		cout<<"YES\n";
	}else{
		cout<<"NO\n";
	}
}
int main(){
	ios::sync_with_stdio(0);
	int T=1;
//	cin>>T;
	while(T--){
		solve();
	}
}
/*
4 2 4
1 1 3
1 2 4 
0 3 4
0 1 2

13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13

2 1 2
1 1 2
0 2 1
*/