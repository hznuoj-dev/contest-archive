#include<bits/stdc++.h>


#define int long long
#define endl '\n'
using namespace std;



int n,x,y;

int f[30][30];

int dx[]= {-1,1,0,0};
int dy[]= {0,0,-1,1};


int m;
void slove() {
cin	 >> n >> m;
	if(m==1){
		cout << "YES\n";
	}else{
		if(n%2==0){
					cout << "NO\n";
		}else{
					cout << "YES\n";
		}
	}
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	int t=1;
//	cin>>t;

	while(t--) {
		slove();
	}
}
