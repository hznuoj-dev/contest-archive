#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int N = 1e6 + 7;


void solve() {
	int n, m;
	cin >> n >> m;
	for (int i = 2; i <= min((long long)sqrt(n), m); i ++ ){
		if (n % i == 0){
			cout << "NO\n";
			return;
		}
	}
	cout << "YES\n";
}
signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int Case = 1;
//	cin >> Case;
	while (Case -- ) {
		solve();
	}
	return 0;
}