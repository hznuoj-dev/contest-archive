#include <bits/stdc++.h>
using namespace std;
int n;
long long ans,tmp,x[110],y[110];
int main() {
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%lld%lld",&x[i],&y[i]);
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				tmp=__gcd(abs(x[j]-x[i]),abs(y[j]-y[i]))+__gcd(abs(x[j]-x[k]),abs(y[j]-y[k]))+__gcd(abs(x[k]-x[i]),abs(y[k]-y[i]));
				if((x[j]-x[i])*(y[k]-y[i])!=(x[k]-x[i])*(y[j]-y[i]))ans=max(ans,tmp);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
