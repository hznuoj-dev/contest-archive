#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 40;
int n;
int mp[N][N];
const int mx[4] = {0, 1, 0, -1}, my[4] = {1, 0, -1, 0};
void solve() {
	scanf("%d", &n);
	int ans = 0;
	memset(mp, 0, sizeof mp);
	for (int i = 1, x, y, c; i <= n; i++) {
		scanf("%d%d%d", &x, &y, &c);
		mp[x][y] = c;
	}
	for (int i = 1; i <= 19; i++)
		for (int j = 1; j <= 19; j++) if (mp[i][j] == 1) {
			for (int k = 0; k < 4; k++) {
				int xx = i+mx[k], yy = j+my[k];
				if (xx >= 1 && xx <= 19 && yy >= 1 && yy <= 19 && mp[xx][yy] == 0) ans++;
			}
		}
	cout << ans << endl;
}

signed main() {
	int T;
	scanf("%d", &T);
	while (T--) solve();
}
