#include <bits/stdc++.h>

using namespace std;
using ll=long long;


int main(){
	ll n,m;
	cin>>n>>m;
	if(n<=m){
		cout<<"No";
		return 0;
	}
	for(ll i=2;i*i<=n&&i<=m;i++){
		if(n%i==0){
			cout<<"No";
			return 0;
		}
	}
	cout<<"Yes";
	return 0;
}