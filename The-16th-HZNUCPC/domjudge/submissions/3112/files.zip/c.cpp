#include<bits/stdc++.h>
using namespace std;
const int mod = 1e9+7;
int count(string s){
	set<char> ss;
	for(int i=0;i<s.size();i++)ss.insert(s[i]);
	return ss.size();
}
int main(){
	string a,b;cin>>a>>b;
	vector<int> m(26*26),ac(26),bc(26);
	int n=a.size(),an=0,bn=0;
	long long ans=0;
	for(int i=0;i<n;i++){
		m[(a[i]-'a')*26+b[i]-'a']++;
		ac[a[i]-'a']++;
		bc[b[i]-'a']++;
	}
	for(int i=0;i<26;i++){
		if(ac[i])an++;
		if(bc[i])bn++;
	}
	for(int i=0;i<26*26;i++){
		if(m[i]){
//			cout<<i<<' ';
			m[i]--;
			int ai=i/26,bi=i%26;
			ac[ai]--,bc[bi]--;
			if(!ac[ai])an--;
			if(!bc[bi])bn--;
			if(!ac[bi])an++;
			if(!bc[ai])bn++;
			ac[bi]++,bc[ai]++;
			if(abs(an-bn)<=2){
				for(int j=i;j<26*26;j++){
					int ai=j/26,bi=j%26;
					if(m[j]&&ac[ai]&&bc[bi]){
//						cout<<j<<',';
						ac[ai]--,bc[bi]--;
						if(!ac[ai])an--;
						if(!bc[bi])bn--;
						if(!ac[bi])an++;
						if(!bc[ai])bn++;
						ac[bi]++,bc[ai]++;
						if(an==bn){
							if(i==j){
//								cout<<"+"<<(m[i])*(m[i]+1)/2<<endl;
								ans=(ans+(m[i])*(m[i]+1)/2)%mod;
							}else{
//								cout<<"+"<<(m[i]+1)*(m[j])<<endl;
								ans=(ans+(m[i]+1)*(m[j]))%mod;
							}
						}
						ac[bi]--,bc[ai]--;
						if(!ac[bi])an--;
						if(!bc[ai])bn--;
						if(!ac[ai])an++;
						if(!bc[bi])bn++;
						ac[ai]++,bc[bi]++;
					}
				}
			}
			ac[bi]--,bc[ai]--;
			if(!ac[bi])an--;
			if(!bc[ai])bn--;
			if(!ac[ai])an++;
			if(!bc[bi])bn++;
			ac[ai]++,bc[bi]++;
			m[i]++;
		}
	}
	cout<<ans;
}