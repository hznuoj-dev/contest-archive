#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;
typedef long long ll;


void solve(){
	ll pre,n=0,m=0;
	cin>>n>>m;
	if(n==1||m==1){
		cout<<"YES"<<"\n";
		return;
	}
	
	while(n%m!=0){
		m=n%m;
		if(m==0){
			cout<<"NO"<<"\n";
			return;
		}
		
	}
	if(m==1)cout<<"YES"<<"\n";
	else cout<<"NO"<<"\n";
	
	
	
//	system("pause");
}

int main(){
	
	int t = 1;
	//cin >> t
	while(t--){
		solve();
	}
	
	return 0;
}