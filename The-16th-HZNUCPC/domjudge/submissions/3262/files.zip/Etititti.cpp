#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define me(a,b) memeset(a,b,sizeof a);
struct node {
	int x;
	int y;
	double k;
} s[150];
map<double,int>mp;
int gys(int x,int y){
	int num=max(x,y);
	for(int i=2;i<=sqrt(num);i++){
		if(x%i==0&&y%i==0) return i;
	}
	return 1;
}
signed main() {
	IOS
	int n;
	while(cin>>n) {
		int f=0;
		int maxx=0;
		mp.clear();
		for(int i=0; i<n; i++) {
			cin>>s[i].x>>s[i].y;
			s[i].x+=1e9+5;
			s[i].y+=1e9+5;
			s[i].k=s[i].x-s[i].y;
		}
		int max1=0;
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				for(int k=j+1;k<n;k++){
					if(s[i].k!=s[j].k||s[i].k!=s[k].k||s[j].k!=s[k].k){
						int numx1=abs(s[i].x-s[j].x);
						int numy1=abs(s[i].y-s[j].y);
						int numx2=abs(s[i].x-s[k].x);
						int numy2=abs(s[i].y-s[k].y);
						int numx3=abs(s[j].x-s[k].x);
						int numy3=abs(s[j].y-s[k].y);
						int sum=0;
						int sum1=numx1/gys(numx1,numy1);
						int sum2=numx2/gys(numx2,numy2);
						int sum3=numx3/gys(numx3,numy3);
						sum=sum1+sum2+sum3;
						f=1;
//						cout<<numx1<<" "<<numy1<<" "<<numx2<<" "<<numy2<<" "<<numx3<<" "<<numy3<<endl;
//						cout<<sum<<endl;
						max1=max(sum,max1);
					}else continue; 
				}
			}
		}
		if(max1!=0)cout<<max1<<endl; 
		else cout<<0<<endl;
	}
	return 0;
}