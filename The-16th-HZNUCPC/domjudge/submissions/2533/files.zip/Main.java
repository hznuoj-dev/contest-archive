
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.*;
public class Main
{
	public static BigInteger zero=new BigInteger("0");
	public static BigInteger one=new BigInteger("1");
	public static BigInteger two=new BigInteger("2");
	public static SecureRandom  random=new SecureRandom();
	public static BigInteger rho(BigInteger n)
	{
		BigInteger divisor;
		BigInteger c=new BigInteger(n.bitCount(),random);
		BigInteger x=new BigInteger(n.bitCount(),random);
		BigInteger xx=x;
		if(n.mod(two).compareTo(zero)==0)return two;
		do
		{
			x=x.multiply(x).mod(n).add(c).mod(n);
			xx=xx.multiply(xx).mod(n).add(c).mod(n);
			xx=xx.multiply(xx).mod(n).add(c).mod(n);
			divisor=x.subtract(xx).gcd(n);
		}
		while(divisor.compareTo(one)==0);
		return divisor;
	}
	public static ArrayList<BigInteger>list;
	public static void factor(BigInteger n)
	{
		if(n.compareTo(one)==0)return ;
		if(n.isProbablePrime(64))
		{
			list.add(n);
			return;
		}
		BigInteger divisor=rho(n);
		factor(divisor);
		factor(n.divide(divisor));
	}
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		list=new ArrayList<>();
		BigInteger n=sc.nextBigInteger(),m=sc.nextBigInteger();
		if(n.compareTo(one)==0||m.compareTo(one)==0)System.out.println("YES");
		else
		{
		if(n.compareTo(m)<=0)System.out.println("NO");
		else
		{
			factor(n);
			if(list.size()==1)System.out.println("YES");
			else System.out.println("NO");
		}
		}
		
		
		
	}
}