#include<bits/stdc++.h>

using namespace std;

bool Prime(long long a){
	long long x=sqrt(a);
	if(a<=1)return false;
	if(a==2)return true;
	for(int i=2;i<=x;i++){
		if(a%i==0)return false;
	}
	return true;
}
signed main(){
	long long a,b;
	cin >> a >> b ;
	if(a>b){
		if(b==1)cout << "YES" << endl;
		else if(Prime(a)){
			cout << "YES" << endl;
		}else cout << "NO" << endl;
	}else{
		cout << "NO" << endl;
	}
	return 0;
}