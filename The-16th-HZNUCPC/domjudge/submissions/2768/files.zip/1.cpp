#include <bits/stdc++.h>
using namespace std;
using ll =long long ;
uint64_t n,m,k,cnt,sum;
//struct pos{
//	ll l,r,sum;
//	
//};
//int f(int n,int m){
//	m=n%m;
//	
//	if(m==0)
//		return 0;
//	for(int i=m;i<=n-2;i--)
//		if(f(n,i)==0)return 0;
//	return 1;
//}
void solve(){
	cin >> n;
	cin>> m;
	k = 0;
	for(int i = 2;i<=(ll)sqrt(n)&&i<=m;i++){
		if (n%i==0) {
			printf("NO\n");
			return ;
//			k=i;
//			break;
		}
	}
	printf("YES\n");
//	ll flag = 0;
//	if ((k==0&&m<n)||(m<k)||n==1||m==1) flag = 1;
//	if (flag) cout<<"YES";
//	else cout<<"NO";
}
int main(){
	uint64_t t;
	//cin >> t;
	//while(t--)
	solve();
}