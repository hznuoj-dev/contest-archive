//#include <iostream>
#include<bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'

int mp[20][20];
int n;
int sum;

void check(int x,int y) {
	if(x - 1 >= 1 && mp[x - 1][y] == 0)sum ++;
	if(x + 1 <= 19 && mp[x + 1][y] == 0)sum ++;
	if(y - 1 >= 1 && mp[x][y - 1] == 0)sum ++;
	if(y + 1 <= 19 && mp[x][y + 1] == 0)sum ++;
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	int t;
	cin >> t;
	while(t -- ) {
		cin >> n;
		sum = 0;
		for(int i = 1 ; i <= 19 ; i ++ )
			for(int j = 1 ; j <= 19 ; j ++ )
				mp[i][j] = 0;

		for(int i = 1 ; i <= n ; i ++ ) {
			int a,b,c;
			cin >> a>> b >> c;
			mp[a][b] = c;
		}
		
//		for(int i = 1 ; i<= 19 ; i ++ )
//		{
//			for(int j = 1 ; j <= 19 ; j ++ )
//			cout<<mp[i][j]<<" ";
//			cout<<endl;
//		}
//		cout<<endl;

		for(int i = 1 ; i <= 19 ; i ++ ) {
			for(int j = 1 ; j <= 19 ; j ++ ) {
				if(mp[i][j]==1)check(i,j);
			}
		}

//		for(int i = 1 ; i <= 19 ; i ++ ) {
//			for(int j = 1 ; j <= 19 ; j ++ ) {
//				if(mp[i][j]==3)sum ++;
//			}
//		}
//		
//		for(int i = 1 ; i<= 19 ; i ++ )
//		{
//			for(int j = 1 ; j <= 19 ; j ++ )
//			cout<<mp[i][j]<<" ";
//			cout<<endl;
//		}

		cout<<sum<<endl;
	}





	return 0;
}