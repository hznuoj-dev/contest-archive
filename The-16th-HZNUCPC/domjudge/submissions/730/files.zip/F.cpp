#include<iostream>
#include<set>
#include<cmath>
#define int long long

using namespace std;

int n, t, x, y, c, m;
set<int> aa;

signed main () {
	cin >> n >> m;
	int flag = 1;
	if (n == 1) {
		cout << "YES\n";
		return 0;
	}
	int N = n;
	for (int i = 2; i <= sqrt(N) + 1; i++) {
		while (n % i == 0) {
			n /= i;
			aa.insert(i);
		}
		if (n == 1) break;
	}
	if (n != 1) aa.insert(n);
	if (m >= *(aa.begin())) cout << "NO\n";
	else cout << "YES\n";
	return 0;
}