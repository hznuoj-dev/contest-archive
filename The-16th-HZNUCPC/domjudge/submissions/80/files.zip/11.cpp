#include<bits/stdc++.h>
using namespace std;
#define int long long
int x[500],y[500],c[500];
int vis[500][500];
int bianx[4]={1,0,0,-1};
int biany[4]={0,1,-1,0};
signed main(){
	int t,n;
	scanf("%lld",&t);	
	while(t--){
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				vis[i][j]=0;
			}
		}
		
		int sum=0;
		scanf("%lld",&n);
		for(int i=1;i<=n;i++){
			scanf("%lld%lld%lld",&x[i],&y[i],&c[i]);
			vis[x[i]][y[i]]=1;
		}
		int newx,newy;
		for(int i=1;i<=n;i++){
			if(c[i]==1){
				for(int j=0;j<4;j++){
					newx=x[i]+bianx[j];
					newy=y[i]+biany[j];
					if(newx>=1&&newx<=19&&newy>=1&&newy<=19&&vis[newx][newy]!=1){
						sum++;
					}	
					
				}
				
			}
			
		}
		printf("%lld\n",sum);
	}
	
	return 0;
}