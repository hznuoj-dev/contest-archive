#include<bits/stdc++.h>

using namespace std;
#define int long long


signed main(){
	ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
	int n, m;
	cin >> n >> m;
	int f = 0;
	for(int i = 2; i * i <= n && i <= m ; i ++){
		if(n % i == 0){
			f = 1;
			break;
		}
	}
	if(f){
		cout << "NO\n";
	}else{
		cout << "YES\n";
	}
}