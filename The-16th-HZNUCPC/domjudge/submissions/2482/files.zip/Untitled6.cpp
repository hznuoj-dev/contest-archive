#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
int main(){
	string s1,s2;
	cin>>s1>>s2;
	int ans=0;
	for(int i=0;i<s1.size();i++){
		if(s1[i]!=s2[i]){
			ans++;
		}
	}
	if(ans>2) cout<<0<<endl;
	else{
		if(ans==2){
			cout<<(s1.size()-2)*2<<endl;
		}else if(ans==1){
			cout<<(s1.size()-1)<<endl;
		}else{
			long long sum=1;
			for(int i=1;i<s1.size();i++){
				sum*=i;
				sum%=mod;
			}
			cout<<sum<<endl;
		}
	}
	
	
	return 0;
}