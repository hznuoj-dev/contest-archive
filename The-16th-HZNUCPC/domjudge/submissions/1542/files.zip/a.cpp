#include<bits/stdc++.h>
using namespace std;
const int N = 1e5+5;
int k[500][500];
long long n,m;

int main(){
	while(cin >> n >> m){
		if(m==1 ||n==1){
			cout <<"YES\n";
			continue;
		}else if(n%2==0){
			cout <<"NO\n";
			continue;
		}
		while(n%m!=0){
			m=n%m;
		}
		if(m>1)cout << "NO\n";
		else cout << "YES\n";
	}
	return 0;
}         
