#include<bits/stdc++.h>
using namespace std;
long long n,m;
int main() {
	cin>>n>>m;
	if(m==1){
		cout<<"YES"<<endl;
	}
	else if(n!=1&&n<m){
		cout<<"NO"<<endl;
	}else if(n%m==0){
		cout<<"NO"<<endl;
	}else if((n%m)%2==0&&n%2==0){
		cout<<"NO"<<endl;
	}else{
		cout<<"YES"<<endl;
	}
	return 0;
}