#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
const ll N=1005;
ll n,m,f[N];
ll find(ll x)
{
    if(x==f[x])return x;
    return f[x]=find(f[x]);
}
struct node
{
    ll u,v,w;
}e[N<<1];
bool car(node x,node y)
{
    return x.w<y.w;
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>n>>m;
    for(ll i=1;i<=n;++i)f[i]=i;
    for(ll i=1;i<=m;++i)
    {
        cin>>e[i].u>>e[i].v>>e[i].w;
    }
    sort(e+1,e+1+m,car);
    ll fa=-1;
    for(ll i=1;i<=m;++i)
    {
        ll u=find(e[i].u),v=find(e[i].v);
        if(u==v)continue;
        if(e[i].w==fa+1)
        {
            ++fa;
            f[u]=v;
        }
        else if(e[i].w>fa+1)break;
    }
    cout<<fa+1<<endl;
    return 0;
}
