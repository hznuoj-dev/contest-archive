#include <bits/stdc++.h>
using namespace std;
double k,b,x[105],y[105],s,maxs=0.0;
const int INF=0x3f3f3f3f;
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>x[i]>>y[i];
	}
	for(int i=1;i<=n-2;i++)
	{
		
		for(int j=1;j<n;j++)
		{
				double maxx=-INF,maxy=-INF,minx=INF,miny=INF;
			if(x[i]-x[j] == 0)//k��ֱ 
			{
				k=0;
			}
			else
			{
				k=(y[i]-y[j])/(x[i]-x[j]);
			 }
				b=y[i]-k*x[i];
				maxx=max(x[i],x[j]);
				minx=min(x[i],x[j]);
				maxy=max(y[i],y[j]);
				 miny=min(y[i],y[j]);
			 for(int l=1;l<=n-2;l++)
				{	//�ж�l�Ƿ���� 
				maxx=max(maxx,x[l]);
				minx=min(minx,x[l]);
				maxy=min(maxy,y[l]);
				miny=min(miny,y[l]);
					if(y[l]==k*x[l]+b)
					{
						//���
						s=(maxy-miny)*(maxx-minx);
						s-=abs((y[1]-y[2])*(x[1]-x[2])/2);
						s-=abs((y[1]-y[3])*(x[1]-x[3])/2); 
						s-=abs((y[2]-y[3])*(x[2]-x[3])/2);
						maxs=max(s,maxs);
						cout<<"s:"<<s<<endl;
					 } 
					 else continue;
				}	
		}
	 } 
	 cout<<abs(maxs);
//	k=(y[4]-y[1])/(x[4]-x[1]);
//	b=y[4]-k*x[4];
//	if(y[2]==k*x[2]+b && y[3] == k*x[3]+b)cout<<0;
	return 0;
}

