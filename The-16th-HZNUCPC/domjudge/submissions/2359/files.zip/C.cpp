#include <bits/stdc++.h>
#define ll long long
#define int long long
#define endl '\n' 

using namespace std;

const int mod = 1e9 + 7;

ll qmi(ll a, ll b) {
	ll ans = 1ll, base = a;
	while(b) {
		if (b & 1ll) ans = ans * base % mod;
		b >>= 1ll;
		base = base * base % mod;
	}	
	return ans;
}

ll inv(ll a) {
	return qmi(a, mod - 2);	
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(NULL);
	
	string  a, b;
	cin >> a >> b;
	
	int n = a.length();
	
	set<char> aset, bset; 
	map<char, int> amp, bmp;
	
	int same = 0;
	
	for (int i = 0; i < n; i++) {
		aset.insert(a[i]);
		bset.insert(b[i]);
		amp[a[i]]++;
		bmp[b[i]]++;
	}
	
	if ((int)aset.size() < (int)bset.size()) {
		swap(a, b);
		swap(aset, bset);
		swap(amp, bmp);
	}
	
	int asize = aset.size(), bsize = bset.size();
	int one = 0, two = 0;
	int ans = 0;
	if (asize - 4 > bsize) {
		std::cout << 0 << "\n";
		return 0;
	}
	for (int i = 0; i < n; i++) {
		if (a[i] == b[i]) {
			same++;
		}
		else {
			int cnt = 0, snt = 0;
			if (amp[a[i]] == 1) cnt--;
			if (amp[b[i]] == 0) cnt++;
			if (bmp[b[i]] == 1) snt--;
			if (bmp[a[i]] == 0) snt++; 
			if (snt - cnt == 1) one++;
			if (snt - cnt == 2) two++;
			if (snt - cnt == 0) same++;
			//std::cout << "snt = " << snt << "\n" << cnt << "\n";
		}
	}
	//std::cout << same << "\n" << one << "\n" << two << "\n";
	if (asize == bsize) {
		ans = (ll)(same * ((same - 1 + mod) % mod) % mod) * inv(2ll) % mod;
		std::cout << ans << "\n";
		return 0;
	}
	if (asize - bsize == 1) {
		ans = (ll)same * one % mod;
	}
	else if (asize - bsize == 2) {
		ans = (ll)same * two % mod;
		ans = (ans + (one * ((one - 1 + mod) % mod) % mod) * inv(2ll) % mod) % mod;
	}
	else if (asize - bsize == 3) {
		ans = (ll)one * two % mod;
	}
	else if (asize - bsize == 4) {
		ans = (ll)(two * ((two - 1 + mod) % mod) % mod) * inv(2ll) % mod;
	}
	std::cout << ans << "\n";
	return 0;
}