def is_pld(st):
    if st == st[::-1]:
        return True
    else:
        return False
def listswap(sd):
    st=[]+sd
    curr=[0]
    for i in range(len(st)-1):
        for j in range(i+1,len(st)):
            st=[]+sd
            st[i],st[j]=st[j],st[i]
            if is_pld(st):
                curr.append(len(st))
    return max(curr)

def is_slic(li):

    
    cur=[0]
    for j in range(len(li) - 1):
        for k in range(j, len(li)):
            tmplst = li[j:k+1]
            cur.append(listswap(tmplst))
    return max(cur)

T = int(input())

for i in range(T):
    s = list(input())       
    u=is_slic(s)
    if u==1:
        print("0")
    else:
        print(u)

