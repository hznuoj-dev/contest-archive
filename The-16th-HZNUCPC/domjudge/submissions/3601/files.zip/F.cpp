#include<bits/stdc++.h>

using namespace std;

#define ios ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define int long long

inline int gcd(int a, int b)
{
	while(b^=a^=b^=a%=b);
	return a;
}
int n, m;
int flag1, flag2;

void wa()
{
	if(n == 1 || m == 1) cout << "YES\n";
	else if(n <= m) cout << "NO\n";
	else
	{
		int ans = gcd(n, m);
		if(ans == 1) cout << "YES\n";	
		else cout << "NO\n";
	}
	return ;
}

signed main()
{
	ios;
	cin >> n >> m;
//	vio();


	wa();
	
	return 0;
}

