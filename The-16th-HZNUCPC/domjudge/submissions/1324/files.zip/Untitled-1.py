import sys
input = lambda: sys.stdin.readline().strip()
def func(n,m):
    i = 2
    cnt = []
    while i<=n//i:
        if n%i == 0:
            cnt.append(i)
            while n%i == 0:
                n//=i
        i += 1
    if n> 1:cnt.append(n)
    for i in cnt:
        if 2<=i<=m:return False
    return True
n,m = map(int,input().split())
if func(n,m):print('YES')
else:print('NO')
