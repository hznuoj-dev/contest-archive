#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int N = 20 + 7;

void solve() {
	int vis[N][N] = {};
	
	int n; cin >> n;
	vector<pair<int, int> > ver;
	for (int i = 1; i <= n; ++ i) {
		int x, y, w; cin >> x >> y >> w;
		vis[x][y] = w;
		if (w == 1) ver.push_back({x, y});
	}
	
	int ans = 0;
	int mi[] = {-1, 0, 0, 1}, mj[] = {0, -1, 1, 0};
	for (auto [x, y] : ver) {
		for (int i = 0; i < 4; ++ i) {
			int X = x + mi[i], Y = y + mj[i];
			if (X < 1 || Y < 1 || X > 19 || Y > 19) continue;
			if (vis[X][Y] == 0) ++ ans;
		}
	}
	cout << ans << endl;
}
signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	
	freopen("1.in", "r", stdin);
	int Case = 1;
	cin >> Case;
	while (Case -- ) {
		solve();
	}
	return 0;
}