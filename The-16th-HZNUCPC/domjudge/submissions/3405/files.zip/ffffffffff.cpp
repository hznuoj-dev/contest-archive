#include<bits/stdc++.h>
using namespace std;
void solve(){
	long long n,m;
	cin>>n>>m;
	if(n==1||m==1){
		cout<<"YES"<<'\n';
		return;
	}
	if(m==2&&n%2==1){
		cout<<"YES"<<'\n';
		return;
	}
	if(n%2==0){
		cout<<"NO"<<'\n';
		return;
	}
	for(int i=2;i<m;i++){
		if(n%i==0){
			cout<<"NO"<<'\n';
			return;
		}
	}
	cout<<"YES"<<'\n';
	return;
//	if(n%2==0||n<=m){
//		cout<<"NO"<<'\n';
//	}else {
//		
//	}
//	int flag=1;
//	for(int i=2;i<=m;i++){
//		if(n%i==0){
//			flag=0;
//			break;
//		}
//	}
//	if(flag) cout<<"YES"<<endl;
//	else cout<<"NO"<<endl;
//	while(m!=1&&m!=0&&n>m){
//		long long kk=n/m;
//		m=n-kk*m;
//
//	}
//	if(m==1||n==1){
//		cout<<"YES"<<endl;
//	}else{
//		cout<<"NO"<<endl;
//	}
//	return;
}
int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
