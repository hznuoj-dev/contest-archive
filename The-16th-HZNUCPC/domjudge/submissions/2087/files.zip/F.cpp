#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long int i,j,x,n,m,st,min;
    scanf("%lld%lld",&n,&m);
    
    if(m>=n)
    {
    	printf("NO");
	}
	else
	{
		st = int(sqrt(n));
		min = m<st?m:st;
		for(j=2;j<=min;j++)
		{
			if(n%j==0)
			{
//				printf("NO");
//				j=-1;
				break;
			}
		}
		
		if(j>min)
			printf("YES");
		else
			printf("NO");
	}
}