import java.util.*;

public class Main {
	static long N;
	static long M;

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			N = sc.nextLong();
			M = sc.nextLong();
			if ((N == 1 || M == 1)) {
				System.out.println("YES");
			} else {
				if (M > N) {
					System.out.println("NO");
				} else {
					long mod = M % N;
					if (mod == 0)
						System.out.println("NO");
					else {
						while (mod != 1) {
							mod = N % mod;
							if (mod == 0) {
								System.out.println("NO");
								break;
							}
						}
						if (mod == 1)
							System.out.println("YES");
					}
				}
			}
		}
	}
}

