#include<bits/stdc++.h>

#define ll long long

using namespace std;

int main()
{
	string s1,s2;
	while(cin>>s1>>s2)
	{
		int r=-1,l=INT_MAX;
		bool key=false;
		ll res=0;
		for(int i=0;i<s1.length();i++)
		{
			if(s1[i]!=s2[i])
			{
				key=true;
				r=max(i,r);
				l=min(i,l);
			}
		}
		int t=s.length()-(r-l+1);
		if(key)
		{
			if(r!=l)
			{
				res++;
			}
			t++;
		}
		for(int i=1;i<t;i++)
		{
			res+=i;
			res%=1000000007;
		}
		cout<<res<<endl;
	}
	return 0;
}
