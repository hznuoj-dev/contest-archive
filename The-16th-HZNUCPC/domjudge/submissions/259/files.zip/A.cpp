#include<bits/stdc++.h>
using namespace std;
using ll=long long ;
int s[21][21];
int check(int x,int y)
{
	int res=0;
	if(s[x+1][y]==0) res++;
	if(s[x-1][y]==0) res++;
	if(s[x][y+1]==0) res++;
	if(s[x][y-1]==0) res++;
	return res; 
}
void solve()
{
	memset(s,0,sizeof s);
	int n;
	cin>>n;
	for(int i=0;i<=20;i++) s[0][i]=3,s[i][0]=3,s[20][i]=3,s[i][20]=3;
	for(int i=1;i<=n;i++){
		int x,y,c;
		cin>>x>>y>>c;//1 b 2 w
		s[x][y]=c;
	}
	int ans=0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(s[i][j]==1){
				ans+=check(i,j);	
			}
		}
	}
	cout<<ans<<"\n";
}
int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	int tt;
	cin>>tt;
	while(tt--){
		solve();
	}
	return 0;
}