#include<bits/stdc++.h>
using namespace std;
#define ll long long
int x[102];
int y[102];
bool f(int a,int b,int c)
{
	if((x[a]-x[b])*(y[a]-y[c])==(x[a]-x[c])*(y[a]-y[b]))
		return 1;
	return 0;	
}
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&x[i],&y[i]);
	}
	int ans=0;
	int ans_1=0;
	bool flag=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			int X=abs(x[i]-x[j]);
			int Y=abs(y[i]-y[j]);
			ans_1=__gcd(X,Y)-1;
			for(int k=j+1;k<=n;k++)
			{
				if(f(i,j,k))
					continue;
				flag=1;
				int X1=abs(x[k]-x[j]);
				int Y1=abs(y[k]-y[j]);
				ans_1=ans_1+__gcd(X1,Y1)-1;
				int X2=abs(x[k]-x[i]);
				int Y2=abs(y[k]-y[i]);
				ans_1=ans_1+__gcd(X2,Y2)-1;
				ans=max(ans,ans_1);
			}
		}
	}
	if(flag)cout<<3+ans;
	else cout<<0;
}