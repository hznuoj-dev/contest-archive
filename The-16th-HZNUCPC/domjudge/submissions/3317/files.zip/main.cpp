#include <iostream>
using namespace std;
long long  m,n,i;
bool flag=true;
int main(int argc, char** argv) {
	cin>>n>>m;
	i=n%m;
	if(m==1||n==1){
		printf("YES");
		flag=false;
	}
	if(m>=n){
		printf("NO");
		flag=false;
	}
	while(flag){
		if(i==1){
			printf("YES");
			break;
		}
		else if(i==0){
			printf("NO");
			break;
		}
		i=n%i;
	}
	return 0;
}