#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e6+5;
const int M=1e3+5;
int n,m,k,c,t;
int cs[N];
int az[4][2] = {{1,0},{0,1},{-1,0},{0,-1}};
long long ans;
//int s[N];
string str,a;
int vis[25][25],vss[25][25];
struct node{
	int x,y,z;
}s[N];
signed main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin >> k;
	while (k --){
		cin >> n;
		int sv;
		for (int i=0;i<=20;i++){
			for (int j=0;j<=20;j++){
				vis[i][j] = 0;
//				vss[i][j] = 0;
			}
		}
		for (int i=1;i<=n;i++){
			cin >> c >> t >> sv;
			vis[c][t] = sv;
			s[i] = {c,t,sv};
		}
		int x,y;
		ans = 0;
		for (int i=1;i<=n;i++){
			if (s[i].z == 2) continue;
			x = s[i].x; y = s[i].y;
			for (int j=0;j<4;j++){
				int xx = x + az[j][0];
				int yy = y + az[j][1];
				if (xx >= 1 && xx <= 19 && yy >= 1 && yy <= 19){
					if (!vis[xx][yy]){
						ans ++;
					}
				}
			}
		}
		cout << ans << endl;
	}
}