#include <iostream>
using namespace std;
long a,b;
int main() {
	cin >> a >> b;
if(a==1||b==1)cout << "YES" << endl;
else if(a % 2 == 1)cout << "YES" << endl;
else cout << "NO" << endl;
}
