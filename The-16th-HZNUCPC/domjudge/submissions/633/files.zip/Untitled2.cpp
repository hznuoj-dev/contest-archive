#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 35;

int n,m;

int g[N][N];
bool vis[N][N];
int dir[4][2] = {0,1,1,0,0,-1,-1,0};


void solve(){
	cin >> n;
	memset(g,0,sizeof g);
	for(int i = 1 ; i <= n ; i ++){
		int a,b,c;
		cin >> a >> b >> c;
		g[a][b] = c;
	}
	int ans = 0;
	for(int i = 0 ; i <= 25 ; i ++){
		for(int j = 0 ; j <= 25 ; j ++){
			if(g[i][j] == 1){
				for(int k = 0 ; k < 4 ; k ++){
					int tx = i + dir[k][0];
					int ty = j + dir[k][1];
					if(tx < 1 || tx > 19 || ty < 1 || ty > 19)continue;
					if(g[tx][ty]==0){
						ans ++;
					}
				}
			}
		}
	}
	cout << ans << endl;
	
}

signed main(){
	int T;cin >> T;while(T--){
		solve();
	}
	return 0;
}