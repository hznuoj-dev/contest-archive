#include <bits/stdc++.h>

using namespace std;
#define int long long
#define endl '\n'

void solve() {
    string s;
    cin >> s;
    int n = s.length();
    int res = 0;
    auto calc = [&](int l, int r) {
        int wpos = -1, wl = -1;
        bool flag = false;
        while (l >= 0 && r < n) {
            // cout << l << "," << r << endl;
            if (s[l] != s[r]) {
                if (flag) break;
                if (wpos < 0) {
                    wpos = r;
                    wl = l;
                }else {
                    if ((s[wl] == s[r] && s[wpos] == s[l]) || (s[wl] == s[l] && s[wpos] == s[r]))
                        flag = true;
                    else  {
                        // cout << "NMSL" << endl;
                        break;
                    }
                }
            }
            if (wpos < 0 || flag) res = max(res, r - l + 1);
            l--,r++;
        }
        // cout << "res: " << res << endl;
    };
    auto calc2 = [&](int i) {
        int l = i - 1, r = i + 1;
        bool flag = false;
        while (l >= 0 && r < n) {
            // cout << l << "," << r << endl;
            if (s[l] != s[r]) {
                if (flag) break;
                if (s[l] == s[i] || s[r] == s[i]) {
                    flag = true;
                }else {
                    break;
                }
            }
            if (flag) res = max(res, r - l + 1);
            l--,r++;
        }
        // cout << "res: " << res << endl;
    };
    for (int i = 0; i < n; ++i) {
        // cout << "===========" << endl;
        calc(i, i);
        calc2(i);
        // cout << "+++++++++" << endl;
        if (i + 1 < n) calc(i, i + 1);
        // cout << i << ":" << res << endl;
    }
    cout << (res == 1 ? 0 : res) << endl;
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    int T;
    cin >> T;
    while (T--)
    {solve(); }
#ifdef DEBUG
    cerr << setprecision(2) << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}