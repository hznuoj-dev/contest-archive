#include <bits/stdc++.h>
using namespace std;
const int N=1e6+10;


int main()
{	
	long long n,m;cin>>n>>m;

	int flag=1;

	while(m>1){
		m=n%m;
		if(m==0){
			flag=0;
			break;
		}
	}

	if(flag)puts("YES");
	else puts("NO");
	
	return 0;
}