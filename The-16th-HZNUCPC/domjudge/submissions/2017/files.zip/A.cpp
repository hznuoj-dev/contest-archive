#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define IO ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
const ll mode=1e9+7;
const int maxn=1e5+10;
//---------------------------

ll x,y;
void solve()
{
    cin>>x>>y;

    if (x==1||y==1)
    {
        cout<<"YES"<<endl;
        return;
    }

    for (ll i = 2;i<=x/i;i++)
        if (x%i==0)
    {
        if (i<=y || x/i<=y)
        {
            cout<<"NO"<<endl;
            return;
        }
    }

    if (x<=y)
    {
            cout<<"NO"<<endl;
            return;
    }

    cout<<"YES"<<endl;
    return;
}
int main()
{
    IO;
    int tn=1;
    //cin>>tn;
    while(tn--)
    {
        solve();
    }
    return 0;
}
