#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;
#define quick_cin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define rep1(i,a,n) for(int i=(a);i<(n);++i)
#define rep2(i,a,n) for(int i=(a);i<=(n);++i)
#define per1(i,n,a) for(int i=(n);i>(a);--i)
#define per2(i,n,a) for(int i=(n);i>=(a);--i)
#define endl "\n"

#define dbug(a) cout<<(a)
#define dbug2(a,b) cout<<(a)<<" "<<(b)<<"\n"
#define dbug3(a,b,c) cout<<(a)<<" "<<(b)<<" "<<(c)<<"\n"
typedef long long LL;
typedef unsigned long long ULL;
#define int LL
typedef double dob;
typedef pair<int,int> PII;

int n,m;
void dfs(int n,int m)
{
	m=n%m;
	if(m>1)dfs(n,m);
	else if(m==1)
	{
		dbug("YES");
		return ;
	}
	else if(m==0)
	{
		dbug("NO");
		return ;
	}
	
}
signed main ()
{
	quick_cin();
	cin>>n>>m;


	if(n==1)
	{
		dbug("YES");
		return 0;
	}
	dfs(n,m);
	return 0;
}