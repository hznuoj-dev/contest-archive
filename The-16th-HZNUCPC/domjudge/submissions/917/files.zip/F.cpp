#include<bits/stdc++.h>
using namespace std;
int main(){
    int n,m,k;
	scanf("%d %d",&n,&m);
	k=m;
    while(k!=1)
    {k=n%k;
    if(k==1){printf("YES");break;
    }
    else if(k==0)
    {printf("NO");break;
    
	}
	}
}
	


