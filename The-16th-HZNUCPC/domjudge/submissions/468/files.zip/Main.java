package zime;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
			int n=sc.nextInt();
			while(n-->0){
				int m=sc.nextInt();
				int a[][]=new int[21][21];
				for(int i=1;i<=m;i++)
				{
					int x=sc.nextInt();
					int y=sc.nextInt();
					a[x][y]=sc.nextInt();    
				}
				int sum=0;
				for(int i=1;i<=19;i++)
				{
					for(int j=1;j<=19;j++)
					{
						if(a[i][j]==1){
//							if(i==0&&j==0)
//							{
//								if(a[i][j+1]==0)
//								{
//									sum++;
//									a[i][j+1]=-1;
//								}
//								if(a[i+1][j]==0)
//								{
//									sum++;
//									a[i+1][j]=-1;
//								}
//							}
//							else if(i==0&&j==18)
//							{
//								if(a[i+1][j]==0)
//								{
//									sum++;
//									a[i+1][j]=-1;
//								}
//								if(a[i][j-1]==0)
//								{
//									sum++;
//									a[i][j-1]=-1;
//								}
//							}
//							else if(i==18&&j==18)
//							{
//								if(a[i-1][j]==0)
//								{
//									sum++;
//									a[i-1][j]=-1;
//								}
//								if(a[i][j-1]==0)
//								{
//									sum++;
//									a[i][j-1]=-1;
//								}
//							}
//							else if(i==18&&j==0)
//							{
//								if(a[i-1][j]==0)
//								{
//									sum++;
//									a[i-1][j]=-1;
//								}
//								if(a[i][j+1]==0)
//								{
//									sum++;
//									a[i][j+1]=-1;
//								}
//							}
//							else if(i==0)
//							{
//								if(a[i][j+1]==0)
//								{
//									sum++;
//									a[i][j+1]=-1;
//								}
//								if(a[i][j-1]==0)
//								{
//									sum++;
//									a[i][j-1]=-1;
//								}
//								if(a[i+1][j]==0)
//								{
//									sum++;
//									a[i+1][j]=-1;
//								}
//								
//							}
//							else if(i==18)
//							{
//								if(a[i][j+1]==0)
//								{
//									sum++;
//									a[i][j+1]=-1;
//								}
//								if(a[i][j-1]==0)
//								{
//									sum++;
//									a[i][j-1]=-1;
//								}
//								if(a[i-1][j]==0)
//								{
//									sum++;
//									a[i-1][j]=-1;
//								}
//							}
//							else if(j==18)
//							{
//								if(a[i+1][j]==0)
//								{
//									sum++;
//									a[i+1][j]=-1;
//								}
//								if(a[i][j-1]==0)
//								{
//									sum++;
//									a[i][j-1]=-1;
//								}
//								if(a[i-1][j]==0)
//								{
//									sum++;
//									a[i-1][j]=-1;
//								}
//							}
//							else if(j==0)
//							{
//								if(a[i+1][j]==0)
//								{
//									sum++;
//									a[i+1][j]=-1;
//								}
//								if(a[i][j+1]==0)
//								{
//									sum++;
//									a[i][j+1]=-1;
//								}
//								if(a[i-1][j]==0)
//								{
//									sum++;
//									a[i-1][j]=-1;
//								}
//							}
//							else
							{
								if(a[i+1][j]==0)
								{
									sum++;
									a[i+1][j]=-1;
								}
								if(a[i][j+1]==0)
								{
									sum++;
									a[i][j+1]=-1;
								}
								if(a[i][j-1]==0)
								{
									sum++;
									a[i][j-1]=-1;
								}
								if(a[i-1][j]==0)
								{
									sum++;
									a[i-1][j]=-1;
								}
							}
						}
					}
				}
				System.out.println(sum);
			}
		}

	}

}
