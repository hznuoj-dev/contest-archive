#include<bits/stdc++.h>
using namespace std;

const double eps=1e-8;
int sgn(double x) {
	if(fabs(x)<eps) return 0;
	else return x<0?-1:1; 
}
struct Point {
	double x,y;
	Point() {}
	Point(double x,double y) :x(x),y(y) {}
	Point operator +(Point B) {
		return Point(x+B.x , y+B.y);
	}
	Point operator -(Point B) {
		return Point(x-B.x,y-B.y);
	}
	bool operator ==(Point B) {
		return sgn(x-B.x)==0 && sgn(y-B.y)==0;
	}
	bool operator<(Point B) {
		return sgn(x-B.x)<0||(sgn(x-B.x)==0&&sgn(y-B.y)<0);
	}
	
};
double Cross(Point A,Point B) {
	return A.x*B.x-A.y*B.y;
}
double Dot(Point A,Point B) {
	return A.x*B.x+B.y*A.y;
}
double Len(Point A) {
	return sqrt(Dot(A,A));
}

double Angle(Point A,Point B ){
	return acos(Dot(A,B)/Len(A)/Len(B));
}

int Cov(Point *p,int n,Point* ch) {
	sort(p,p+n);
	n=unique(p,p+n)-p;
	int v=0;
	for(int i=0;i<n;i++) {
		while(v>1&&sgn(Cross(ch[v-1]-ch[v-2],p[i]-ch[v-2]))<=0) {
			v--;
		}
		ch[v++]=p[i];
	}
	int j=v;
	for(int i=n-2;i>=0;i--) {
		while(v>j&&sgn(Cross(ch[v-1]-ch[v-2],p[i]-ch[v-2]))<=0) {
			v--;
		}
		ch[v++]=p[i];
	}
	if(n>1) v--;
	return v;
} 

int n;
int m;
Point ori[100005];
Point cov[100005];
int num_m;


map<double,int> cal() {
	map<double,int> mp;
	for(int i=0;i<num_m;i++) {
		Point pre,nxt;
		if(i==0) {
			pre=cov[num_m-1];
		} else {
			pre=cov[i-1];
		}
		if(i==num_m-1) {
			nxt=cov[0];
		} else {
			nxt=cov[i+1];
		}
		double ag=Angle(pre-cov[i],nxt-cov[i]);
		mp[ag]=i;
	}
	int pos=23333;
	for(auto x:mp) {
		if(pos==23333) {
			mp[x.first]=0;
			pos=1;
		} else {
			mp[x.first]=++pos;
		}
	}
	return mp;
}

int main() {
	ios::sync_with_stdio(false);cin.tie(0);
	cin>>n;
	map<map<double,int>,int> mp;
	for(int i=1;i<=n;i++) {
		cin>>m;
		for(int j=0;j<m;j++) {
			cin>>ori[j].x>>ori[j].y;
			cov[j].x=cov[j].y=0;
		}
		num_m=Cov(ori,m,cov);
		map<double,int> AG=cal();
		
		
//		for(auto x:AG) {
//			cout<<x.first<<' '<<x.second<<endl;
//		}
		
		cout<<mp[AG]<<'\n';
		mp[AG]++;
	}
}

/*
2
4
0 1
1 1
1 0
0 0
4
0 1
1 0
0 -1
-1 0

3
3
0 4
4 0
0 0
3
0 5
4 0
0 0
3
-4 8
4 8
4 0

*/
