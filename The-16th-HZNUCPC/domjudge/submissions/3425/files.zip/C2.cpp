#include<bits/stdc++.h>
using namespace std;
typedef pair<int, int> PII;
#define int long long
#define pb push_back
#define rep(i, a, n) for(int i = a; i <= n; i++)
#define per(i, a, n) for(int i = n; i >= a; i--)
#define x first
#define y second
int f1[128], f2[128];
int mp[128][128];
const int mod = 1e9 + 7;
void solve() {
	string a, b; cin >> a >> b;
	int n = a.length();
	rep(i, 0, n - 1){
		f1[a[i]] += 1;
		f2[b[i]] += 1;
	}
	int gap = 0;
	rep(i, 'a', 'z'){
		if(f1[i] > 0 && f2[i] == 0) gap++;
		if(f2[i] > 0 && f1[i] == 0) gap--;
	}
/**
abca
aaaa
**/
	int ans = 0;
	per(i, 0, n - 1){
		int t1 = f1[a[i]], t2 = f2[b[i]], t3 = f1[b[i]], t4 = f2[a[i]];
		f1[a[i]]--; f1[b[i]]++;
		f2[b[i]]--; f2[a[i]]++;
		int pre = 0;
		int x = 0, y = 0, z = 0, q = 0;
		if(t1 == 0 && f1[a[i]] > 0){
			gap++; pre++;
		}
		if(t1 > 0 && f1[a[i]] == 0){
			gap--; pre--;
		}
		if(t3 == 0 && f1[b[i]] > 0){
			gap++; pre++;
		}
		if(t3 > 0 && f1[b[i]] == 0){
			gap--; pre--;
		}
		if(t2 == 0 && f2[b[i]] > 0){
			gap--; pre--;
		}
		if(t2 > 0 && f2[b[i]] == 0){
			gap++; pre++;
		}
		if(t4 == 0 && f2[a[i]] > 0){
			gap--; pre--;
		}
		if(t4 > 0 && f2[a[i]] == 0){
			gap++; pre++;
		}
		rep(j, 'a', 'z'){
			rep(k, 'a', 'z'){
				int t1 = f1[j], t2 = f2[k], t3 = f1[k], t4 = f2[j];
				int x = 0, y = 0, z = 0, q = 0, pre = 0;
				f1[j]--; f1[k]++;
				f2[k]--; f2[j]++;
				if(t1 == 0 && f1[j] > 0){
					gap++; pre++;
				}
				if(t1 > 0 && f1[j] == 0){
					gap--; pre--;
				}
				if(t3 == 0 && f1[k] > 0){
					gap++; pre++;
				}
				if(t3 > 0 && f1[k] == 0){
					gap--; pre--;
				}
				if(t2 == 0 && f2[k] > 0){
					gap--; pre--;
				}
				if(t2 > 0 && f2[k] == 0){
					gap++; pre++;
				}
				if(t4 == 0 && f2[j] > 0){
					gap--; pre--;
				}
				if(t4 > 0 && f2[j] == 0){
					gap++; pre++;
				}
				if(gap == 0){
					ans = (ans + mp[j][k]) % mod;
				}
				gap -= pre;
				f1[j]++; f1[k]--;
				f2[k]++; f2[j]--;
			}
		}
		gap -= pre;
		f1[a[i]]++; f1[b[i]]--;
		f2[b[i]]++; f2[a[i]]--;
		mp[a[i]][b[i]]++;
	}
	cout << ans << '\n';
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	solve();
}