# include "bits/stdc++.h"
using namespace std;
# define int long long


signed main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);
	int n, m;
	while(cin >> n >> m){
		if(m == 1 || n == 1){
			cout << "YES\n";
			continue;
		}
		if(n <= m){
			cout << "NO\n";
			continue;
		}
		if(n % m == 0){
			cout << "NO\n";
		}else{
			cout << "YES\n";
		}
		
	}
	
	return 0;
}