#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
using namespace std;
const int n=19,N=30,dx[4]={0,0,1,-1},dy[]={1,-1,0,0};
int m,a[N][N],vis[N][N];
vector<int>b,c;
void dfs(int x,int y) {
	vis[x][y]=1; b.push_back(x); c.push_back(y);
	For(i,0,3) {
		int x2=x+dx[i],y2=y+dy[i];
		if(vis[x2][y2] || a[x2][y2]!=a[x][y]) continue;
		dfs(x2,y2);
	}
}
void doit(int w) {
	For(i,1,n) For(j,1,n) if(a[i][j]==w && !vis[i][j]) {
		dfs(i,j);
		int flag=0;
		For(i,0,b.size()-1) {
			int x=b[i],y=c[i];
			For(i,0,3) {
				int x2=x+dx[i],y2=y+dy[i];
				if(a[x2][y2]==-1) flag=1;
			}
		}
		if(!flag) {
			For(i,0,b.size()-1) {
				int x=b[i],y=c[i];
				a[x][y]=-1;
			}
		}
		b.clear(); c.clear();
	}
	memset(vis,0,sizeof(vis));
}
int vis2[N][N];
void doit2(int w) {
	int ans=0;
	For(i,1,n) For(j,1,n) if(a[i][j]==w && !vis[i][j]) {
		dfs(i,j);
		For(i,0,b.size()-1) {
			int x=b[i],y=c[i];
			For(i,0,3) {
				int x2=x+dx[i],y2=y+dy[i];
				if(!vis2[x2][y2] && a[x2][y2]==-1) vis2[x2][y2]=1,++ans;
			}
		}
		For(i,0,b.size()-1) {
			int x=b[i],y=c[i];
			For(i,0,3) {
				int x2=x+dx[i],y2=y+dy[i];
				vis2[x2][y2]=0;
			}
		}
		b.clear(); c.clear();
	}
	memset(vis,0,sizeof(vis));
	cout<<ans<<"\n";
}
void work() {
	cin>>m;
	For(i,1,n) For(j,1,n) a[i][j]=-1;
	while(m--) {
		int x,y,w;
		cin>>x>>y>>w;
		a[x][y]=w;
		doit(3-w); doit(w); 
	}
	doit2(1);
}
int main() {
#ifdef LOCAL
    freopen(".in","r",stdin);
#endif
    ios::sync_with_stdio(0); cin.tie(0);
    int T;cin>>T;
	while(T--) work();
}