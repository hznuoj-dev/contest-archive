#include<bits/stdc++.h>
using namespace std;
int main()
{
    char c1[500005],x;
    
	unsigned long long int n,i,j,sum,sa,sb;
	sa=0;
	sb=0;
	sum=0;
	scanf("%s",c1);
	getchar();
	for(i=0;c1[i]!='\0';i++)
	{
		scanf("%c",&x);
		if(x==c1[i])
		{
			sa=sa+1;
		}
		else
		{
			sb=sb+1;
		}
	}
	if(sa<=1)
	{
		printf("0");
	}
	else
	{
		if(sa==2)
		{
			sum=sb*sa%1000000007;
		}
		else
		{
			sum=(((sa-1)*sa/2%1000000007)+sb*sa%1000000007)%1000000007;
		}
		printf("%llu",sum);
	}
}