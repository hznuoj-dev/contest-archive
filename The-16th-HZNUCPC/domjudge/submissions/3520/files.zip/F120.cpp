#include<bits/stdc++.h>
using namespace std;
#define int long long 
int n,m;
void solve(){
	while(cin>>n>>m){
		if(n%m==0&&m!=1){
			cout<<"NO"<<endl;
		}	else{
			cout<<"YES"<<endl;
		}
		
	}
}
signed main(){
	solve();
	return 0;
}