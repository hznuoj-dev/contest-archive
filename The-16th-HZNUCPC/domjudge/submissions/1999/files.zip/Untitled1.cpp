#include<bits/stdc++.h>
using namespace std;
//#define int long long 
typedef long long ll;

const int N=2e5+7,MOD=1e9+7;
int ans,c[31];
string s;

void solve(){
	ans=0;
	cin>>s;
	for(int i=0;i<s.size();i++){
		bool flag=true;
		int cnt=0;
		memset(c,0,sizeof(c));
		for(int jl=i-1,jr=i+1;jl>=0&&jr<s.size();jl--,jr++){
			if(s[jl]==s[jr]){
				if(flag) ans=max(ans,jr-jl+1);
			}else{
				cnt++;
				if(cnt==1){
					if(s[jl]==s[i]||s[jr]==s[i]){
						flag=true;
						ans=max(ans,jr-jl+1);
					}else{
						flag=false;
					}
					c[s[jl]-'a']++;
					c[s[jr]-'a']++;
				}else if(cnt==2){
					if(c[s[jl]-'a']==1&&c[s[jr]-'a']==1){
						flag=true;
						ans=max(ans,jr-jl+1);
					}else{
						break;
					}
				}else{
					break;
				}
			}
		}
	}
	for(int i=0;i+1<s.size();i++){
		bool flag=true;
		int cnt=0;
		memset(c,0,sizeof(c));
		for(int jl=i,jr=i+1;jl>=0&&jr<s.size();jl--,jr++){
			if(s[jl]==s[jr]){
				if(flag) ans=max(ans,jr-jl+1);
			}else{
				cnt++;
				if(cnt==1){
					flag=false;
					c[s[jl]-'a']++;
					c[s[jr]-'a']++;
				}else if(cnt==2){
					if(c[s[jl]-'a']==1&&c[s[jr]-'a']==1){
						flag=true;
						ans=max(ans,jr-jl+1);
					}else{
						break;
					}
				}else{
					break;
				}
			}
		}
	}
	cout<<ans<<'\n';
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	int t = 1;
	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}