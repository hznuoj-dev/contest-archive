
#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
signed main (){
	ios::sync_with_stdio(0); cin.tie(0);cout.tie(0);
	int n,m; cin>>n>>m; bool flag=true;
	if(n<=m){
		cout<<"NO\n";
		return 0;
	}else{
		for(int i=2;i*i<=n;i++){
			if(n%i==0&&i<=m){
	//			cout<<i<<' '<<'\n';
				flag=false;
				break;
			}
		}
		if(!flag) cout<<"NO\n";
		else cout<<"YES\n";
	}
	return 0;
}

/*
#include<bits/stdc++.h>
using namespace std;
signed main (){
	ios::sync_with_stdio(0); cin.tie(0);cout.tie(0);
	int n,m; cin>>n>>m; bool flag=true;
	while(){
		if(n%m==0){
			flag=false;
			break;
		}else{
			m=n%m;
			
		}
	}
	
	
	
	
	
	
	if(!flag) cout<<"NO\n";
	else cout<<"YES\n";
	
	return 0;
}
*/