#include<bits/stdc++.h>
#define LL long long
using namespace std;
struct Node{
	int x,y;
}a[105];
int n;
int Gcd(int x,int y) {
	if (y==0) return x;
	return Gcd(y,x%y);
}
int main()
{
	scanf("%d",&n); LL ans=0;
	for (int i=1; i<=n; i++) scanf("%d%d",&a[i].x,&a[i].y);
	for (int i=1; i<=n; i++)
	 for (int j=i+1; j<=n; j++)
	  for (int k=j+1; k<=n; k++)
	   {
	   	int dx_1=a[i].x-a[j].x,dy_1=a[i].y-a[j].y;
	   	double k1=(double)dy_1/dx_1;
	   	int dx_2=a[i].x-a[k].x,dy_2=a[i].y-a[k].y;
	   	double k2=(double)dy_2/dx_2;
	   	int dx_3=a[k].x-a[j].x,dy_3=a[k].y-a[j].y;
	   	double k3=(double)dy_3/dx_3;
	   	if (k1==k2||k1==k3||k2==k3) continue;
	   	LL sum=Gcd(abs(dx_1),abs(dy_1))+Gcd(abs(dx_2),abs(dy_2))+Gcd(abs(dx_3),abs(dy_3));
	   	ans=max(ans,sum);
	   }
	printf("%lld",ans);
	return 0;
}