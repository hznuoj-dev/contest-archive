#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
int vis[21][21];
int vis1[21][21];
int main ()
{
    int tt;
    cin>>tt;
    while(tt--){
        int n;
        cin>>n;
        memset(vis,0,sizeof(vis));
        memset(vis1,0,sizeof(vis1));
        for(int i=0;i<=20;i++){
            vis[i][0]=1;
            vis[0][i]=1;
            vis[20][i]=1;
            vis[i][20]=1;
        }
        for(int i=1;i<=n;i++){
            int x,y,c;
            cin>>x>>y>>c;
            vis[x][y]=c;
        }
        for(int x=1;x<=19;x++){
            for(int y=1;y<=19;y++){
            if(vis[x][y]==2){
                if(vis[x+1][y]==1&&vis[x][y+1]==1&&vis[x-1][y]==1&&vis[x][y-1]==1){
                    vis[x][y]=0;
                }
            }
            else if(vis[x][y]==1){
                vis1[x][y-1]++;
                vis1[x][y+1]++;
                vis1[x-1][y]++;
                vis1[x+1][y]++;
            }
            }
        }
        int ans;
        ans=0;
        for(int i=1;i<=19;i++){
            for(int j=1;j<=19;j++){
                if(vis[i][j]==0)ans+=vis1[i][j];
            }
        }
        cout<<ans<<'\n';
    }
}
