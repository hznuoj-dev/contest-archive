#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=100010;
int a[N];
int main(){
	ll n,m;
	scanf("%lld%lld",&n,&m);
	if(n == 1 || m == 1 ){ 
		cout << "YES" << endl;
		return 0;
	}
	int cnt =0;
	for(int i=2;i<=m/i;i++){
		if(n%i==0){
			a[cnt++]=i;
			while(m%i==0){
				m/=i;
			}
		}
	}
	if(m>1) a[cnt++]=m;
	for(int i=0;i<cnt;i++){
		if(n%a[i]==0){
			puts("NO");
			return 0;
		}
	}
	puts("YES");
	return 0;
}

	