#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define MOD 1000000007;
const int N=30;
int a[N][N];
int dx[4]={0,1,-1,0},dy[4]={-1,0,0,1};
void solve(){
	memset(a,0,sizeof a);
	int n;
	cin>>n;
	int ans=0;
	for(int i=1;i<=n;i++)
	{
		int x,y,c;
		cin>>x>>y>>c;
		a[x][y]=c;
	}
	for(int i=1;i<=19;i++)
	{
		for(int j=1;j<=19;j++)
		{
			if(a[i][j]==1)
			{
				for(int p=0;p<4;p++)
				{
					int ux=i+dx[p],uy=j+dy[p];
					if(ux>=1&ux<=19&&uy>=1&&uy<=19&&a[ux][uy]==0) ans++;
				}
			}
		}
	}
	cout<<ans<<endl;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	int t;
	cin>>t;
	while(t--)
	{
		solve();
	}
	return 0;
}