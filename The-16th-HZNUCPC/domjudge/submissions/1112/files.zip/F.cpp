#include<bits/stdc++.h>


#define int long long
#define endl '\n'
using namespace std;



int n,x,y;

int f[30][30];

int dx[]= {-1,1,0,0};
int dy[]= {0,0,-1,1};

const int N=1e6+10;
int primes[N],cnt=0;
bool st[N];
int ola(int n=1e6)
{
	st[1]=0;
	
	for(int i=2;i<=n;i++)
	{
		if(!st[i])primes[cnt++]=i;
		for(int j=0;primes[j]<=n/i;j++)
		{
			st[i*primes[j]]=true;
			if(i%primes[j]==0)break;
		}
	}
}


int m;
void slove() {
	
	ola();
	cin	 >> n >> m;
	
	for(int i=0;i<cnt;i++)
	{
		if(n%primes[i]==0)
		{
			if(m<primes[i])
			{
				cout << "YES\n";
			}
			else
			{
				cout << "NO\n";
			}
			return;
		}
	}
	
	
	if(m<n)
		{
			cout << "YES\n";
		}
		else
		{
				cout << "NO\n";
		}
	
	
//	if(m==1){
//		cout << "YES\n";
//	}else{
//		if(n%2==0){
//					cout << "NO\n";
//		}else{
//					cout << "YES\n";
//		}
//	}
//if(n%m==0){
//	cout << "NO\n";
//}else{
//	cout << "YES\n";
//}


}


signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	int t=1;
//	cin>>t;

	while(t--) {
		slove();
	}
}
