#include <bits/stdc++.h>
using namespace std;
using ll = long long;
int ___ = cin.tie(0)->sync_with_stdio(0);
int pre[30][3010];


void solve() {
    string s;
    cin >> s;
    int n = s.size();
    int ans = -1;
    std::vector<int> vl(30, 1E9), vr(30, -1);
    for (int i = 0; i < n; i++){
        int c = s[i] - 'a';
        if (vl[c] == -1)
            vl[c] = i;
        vr[c] = i;
    }
    auto in = [&](int x) {
        return 0 <= x && x < n;
    };
    /*
    auto has = [&](char c, int l, int r) {
        if (vl[c - 'a'] < l || vr[c - 'a'] > r)
            return true;
        return false;
    };*/
    auto has = [&](char c, int l, int r) {
        l = max(l, 0);
        r = min(r, n - 1);
        l++, r++;
        return (pre[c - 'a'][r] - pre[c - 'a'][l - 1]) > 0;
    };
    auto check = [](char a, char b, char c, char d) {
        return a == d && b == c;
    };

    for (int i = 0; i < n; i++) {
        ///// std::cout << "i = " << i << "\n";
        ///// std::cout << "odd\n";
        // odd
        {
            std::vector<int> p;
            for (int j = 0; j <= n; j++) {
                if (i - j < 0 || i + j >= n) {
                    while (p.size() < 3)
                        p.push_back(j);
                    break;
                } else {
                    if (s[i - j] != s[i + j]) {
                        p.push_back(j);
                    }
                }
            }

            ///// for (auto pi : p)
            /////     std::cout << pi << ' ';
            ///// std::cout << '\n';
            auto setp = [&](int u) {
                ///// std::cout << "set p = " << u << '\n';
                ans = std::max(ans, p[u] * 2 - 1);
                ///// std::cout << "set = " << p[u] * 2 - 1 << '\n';
            };
            setp(0);
            if (in(i - p[0]) && in(i + p[0])) {
                /*
                if (has(s[i - p[0]], i - p[0], i + p[0]))
                    setp(1);
                if (has(s[i + p[0]], i - p[0], i + p[0]))
                    setp(1);
                */

                for (int j = p[1] - 1; j > p[0]; j--) {
                    bool flag = s[i - p[0]] == s[i - j] || s[i - p[0]] == s[i + j];
                    flag = flag || s[i + p[0]] == s[i - j] || s[i + p[0]] == s[i + j];
                    if (flag) {
                        ///// std::cout << "set j = " << j << '\n';
                        ans = std::max(ans, j * 2 - 1);
                    }
                }
                if (s[i] == s[i - p[0]] || s[i] == s[i + p[0]]) {
                    setp(1);
                    ////// std::cout << s[i - p[0]] << s[i] << s[i + p[0]] << '\n';
                }
                if (in(i - p[1]) && in(i + p[1])) {
                    char a = s[i - p[1]] - 'a';
                    char b = s[i - p[0]] - 'a';
                    char c = s[i + p[0]] - 'a';
                    char d = s[i + p[1]] - 'a';
                    if (check(a, b, c, d))
                        setp(2);
                    if (check(b, a, c, d))
                        setp(2);
                    if (check(c, b, a, d))
                        setp(2);
                    if (check(a, d, c, b))
                        setp(2);
                    if (check(a, b, d, c))
                        setp(2);
                }
            }
        }
        // even
        ///// std::cout << "even\n";
        {
            std::vector<int> p;
            for (int j = 0; j <= n; j++) {
                if (i - j < 0 || i + j + 1 >= n) {
                    while (p.size() < 3)
                        p.push_back(j);
                    break;
                } else {
                    if (s[i - j] != s[i + j + 1]) {
                        p.push_back(j);
                    }
                }
            }

            ///// for (auto pi : p)
                ///// std::cout << pi << ' ';
            ///// std::cout << '\n';

            auto setp = [&](int u) {
                ///// std::cout << "set p = " << u << '\n';
                ans = std::max(ans, p[u] * 2);
                ///// std::cout << "set = " << p[u] * 2 << '\n';
            };
            setp(0);
            if (in(i - p[0]) && in(i + p[0] + 1)) {
                /*
                if (has(s[i - p[0]], i - p[0], i + p[0] +1))
                    setp(1);
                if (has(s[i + p[0] + 1], i - p[0], i + p[0] + 1))
                    setp(1);
                    */
                for (int j = p[1] - 1; j > p[0]; j--) {
                    bool flag = s[i - p[0]] == s[i - j] || s[i - p[0]] == s[i + j + 1];
                    flag = flag || s[i + p[0] + 1] == s[i - j] || s[i + p[0] + 1] == s[i + j + 1];
                    if (flag) {
                        ///// std::cout << "set j = " << j << '\n';
                        ans = std::max(ans, j * 2);
                    }
                }
                if (in(i - p[1]) && in(i + p[1] + 1)) {
                    char a = s[i - p[1]] - 'a';
                    char b = s[i - p[0]] - 'a';
                    char c = s[i + p[0] + 1] - 'a';
                    char d = s[i + p[1] + 1] - 'a';
                    ///// std::cout << int(a)  << ' ' << int(b) << ' ' << int(c) << ' ' << int(d) <<'\n';
                    if (check(a, b, c, d))
                        setp(2);
                    if (check(b, a, c, d))
                        setp(2);
                    if (check(c, b, a, d))
                        setp(2);
                    if (check(a, d, c, b))
                        setp(2);
                    if (check(a, b, d, c))
                        setp(2);
                }
            }
        }
        ///// std::cout << '\n';
    }
    std::cout << (ans == 1 ? 0 : ans) << '\n';
    ///// std::cout << "ans = " << ans << '\n';
}

int main (){
    int T;
    cin >> T;
    while(T --){
            solve();
            // abccab

    }

}


// abccaba
