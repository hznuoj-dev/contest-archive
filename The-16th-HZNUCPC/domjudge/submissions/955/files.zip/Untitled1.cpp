#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
    int t;
    cin>>t;
    int n,x,y,c;
    while(t--)
    {
    	int m[21][21]={0};
    	cin>>n;
    	for(int i=0;i<n;i++)
    	{
    		cin>>x>>y>>c;
    		if(c==1){
    			m[x][y]=1;
    			if(m[x+1][y]==0)
    			m[x+1][y]=2;
    			if(m[x-1][y]==0)
    			m[x-1][y]=2;
    			if(m[x][y+1]==0)
    			m[x][y+1]=2;
    			if(m[x][y-1]==0)
    			m[x][y-1]=2;
			}
			else{
				m[x][y]=-1;
			}
		}
		int ans=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(m[i][j]==1){
					if(i+1<=19&&m[i+1][j]==2)
	    			ans++;
	    			if(i-1>=1&&m[i-1][j]==2)
	    			ans++;
	    			if(j+1<=19&&m[i][j+1]==2)
	    			ans++;
	    			if(j-1>=1&&m[i][j-1]==2)
	    			ans++;
				}
			}
		}
		cout<<ans<<endl;
	}
    
    return 0;
}
