#include <bits/stdc++.h>
using namespace std;

const int N = 1e2 + 5;
pair<int, int> P[N];

int gcd(int, int);
int W(int, int);
//bool check();

int ans;
int n;
int main() {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		scanf("%d%d", &P[i].first, &P[i].second);
		
	}
	
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			for (int k = j + 1; k <= n; k++) {
				int xdif1 = abs(P[k].first - P[j].first);
				int xdif2 = abs(P[j].first - P[i].first);
				
				int ydif1 = abs(P[k].second - P[j].second);
				int ydif2 = abs(P[j].second - P[i].second);
				
				if ((long long) xdif1 * ydif2 * 1ll != (long long) ydif1 * xdif2 * 1ll) {
					ans = max(ans, W(i, j) + W(j, k) + W(i, k));
//					printf("%d %d %d %d\n", i, j, W(i, j), W(j, k));
				}
				if (xdif1 + xdif2 != 0 && xdif1 * xdif2 == 0 && !(ydif1 == 0 && ydif2 == 0)) {
					ans = max(ans, W(i, j) + W(j, k) + W(i, k));
				}
				if (ydif1 + ydif2 != 0 && ydif1 * ydif2 == 0 && !(xdif1 == 0 && xdif2 == 0)) {
					ans = max(ans, W(i, j) + W(j, k) + W(i, k));
				}
//					
// 4
// 2 5
// 4 9
// 7 29
// 13 37
// 3 30 31 32
//				if (P[j].first != P[i].first && P[k].first != P[j].first) {
////					long double rat1 = 1.0 * (P[j].second - P[i].second) / (P[j].first - P[i].first);
////					long double rat2 = 1.0 * (P[k].second - P[j].second) / (P[k].first - P[j].first);
////					if (rat1 == rat2) {
////						continue;
////					}
//					ans = max(ans, W(i, j) + W(j, k) + W(i, k));
//				} else {
//					if(P[j].first == P[i].first && P[i].first == P[k].first ||
//					   P[j].second == P[i].second && P[i].second == P[k].second) {
//						continue;
//					}else{
//						ans = max(ans, W(i, j) + W(j, k) + W(i, k));
//					}
//				}
			}
		}
	}
	cout << max(ans - 3, 0);
	return 0;
}

int gcd(int a, int b) {
	if (b == 0) {
		return a;
	}
	return gcd(b, a % b);
}

int W(int ind, int jnd) {
	int xdif = abs(P[ind].first - P[jnd].first);
	int ydif = abs(P[ind].second - P[jnd].second);
	return gcd(xdif, ydif) + 1;
}
