#include<bits/stdc++.h>
using namespace std;
long long  n,m;
int k;
int main(){
	cin>>n>>m;
	if(n==1) cout<<"YES";
	else for(int i=2;i<=sqrt(n);i++){
		if(n%i==0) {
			k=i;
			break;
		}
	}
	if(k==0) cout<<"YES";
	else if(m>=k) cout<<"NO";
	else cout<<"YES";
	return 0;
}