#include<iostream>
#include<cstring>
using namespace std;
typedef long long ll;
int mp[20][20];

int main(){
	ll n,m;
	int flag=1;
	cin>>n>>m;
	if(m>=n) cout<<"NO";
	else if(m == 1||n == 1) cout<<"YES";
	else if(n%2==0) cout<<"NO";
	else if(n%m == 0) cout<<"NO";
	else{
		while(m>1){
			m--;
			if(n%m == 0) flag = 0;
		}
		if(flag) cout<<"YES";
		else cout<<"NO";
	}
}