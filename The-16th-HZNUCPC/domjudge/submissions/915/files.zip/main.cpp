#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll mod = 1e9+7;
ll cnt[2][30];
ll tmp[2][30];
ll op[30][30];
ll qpow(ll a,ll b){
    ll ans = 1;
    while(b){
        if(b&1) ans = ans*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return ans;
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    string s1,s2;
    cin>>s1>>s2;
    for(auto x:s1) cnt[0][x-'a']++;
    for(auto x:s2) cnt[1][x-'a']++;
    for(ll i=0;i<s1.length();i++){
        op[s1[i]-'a'][s2[i]-'a']++;
    }
    ll ans = 0;
    for(ll i1=0;i1<26;i1++){
        for(ll i2 =0;i2<26;i2++){
            for(ll j1=0;j1<26;j1++){
                for(ll j2=0;j2<26;j2++){
                    ll c1 = op[i1][i2];
                    ll c2 = op[j1][j2];
                    for(ll k=0;k<26;k++){
                        tmp[0][k] = cnt[0][k];
                        tmp[1][k] = cnt[1][k];
                    }
                    tmp[0][i1]--;
                    tmp[0][i2]++;
                    tmp[0][j1]--;
                    tmp[0][j2]++;
                    tmp[1][i1]++;
                    tmp[1][i2]--;
                    tmp[1][j1]++;
                    tmp[1][j2]--;
                    ll cnt1 = 0,cnt2 = 0;
                    for(ll k=0;k<26;k++){
                        if(tmp[0][k]) cnt1++;
                        if(tmp[1][k]) cnt2++;
                    }
                    if(cnt1!=cnt2) continue;
                    if(i1==j1&&i2==j2){
                        ans += c1*(c1-1);
                    }else {
                        ans += c1*c2;
                    }
                    ans %=mod;
                }
            }
        }
    }
    ans = ans*qpow(2,mod-2)%mod;
    cout<<ans<<endl;
}
