#include<bits/stdc++.h>

using namespace std;

const int maxn = 2e5 + 10;
using ll = long long;
bool vis[30][30];
int g[30][30];
int dx[4] = {0, 0, 1, -1}, dy[4] = {1, -1, 0, 0};
void solve() {
	for (int i = 1; i <= 19; i++) {
		for (int j = 1; j <= 19; j++) {
			vis[i][j] = false;
			g[i][j] = 0;
		}
	}
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		int x, y, val;
		scanf("%d%d%d", &x, &y, &val);
		g[x][y] = val;
	}
	auto check = [&](int x, int y) {
		if (x <= 0 || x > 19 || y <= 0 || y > 19) return false;
		if (g[x][y] != 0) return false;
		return true;	
	};
	int ans = 0;
	for (int i = 1; i <= 19; i++) {
		for (int j = 1; j <= 19; j++) {
			int now_x = i, now_y = j;
			if (g[now_x][now_y] != 1) continue;
			for (int k = 0; k < 4; k++) {
				int new_x = now_x + dx[k], new_y = now_y + dy[k];
				if (check(new_x, new_y)) {
//					cout << new_x << " " << new_y << endl;
					ans++;
//					vis[new_x][new_y] = true;
				}
			}
		}
	}
	printf("%d\n", ans);
}
int main() {
	int T;
	scanf("%d", &T);
	while (T--)
	solve();
	return 0;
}