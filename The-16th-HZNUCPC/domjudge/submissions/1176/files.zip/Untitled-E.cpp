#include <bits/stdc++.h>
using namespace std;
#define rep(a,b,c) for(int a=b;a<=c;a++)
#define per(a,b,c) for(int a=b;a>=c;a--)
#define output(a,b,c) cout<<a<<" "<<b<<" "<<c<<"\n"
#define ft first
#define sd second

typedef long long LL;
typedef unsigned long long ULL;

typedef pair<int,int> PII;
typedef pair<LL,LL> PLL;

const int N=1e5+5,M=5*N;

PLL p[105];

LL gcd(LL x, LL y){
    return (y==0)?x:gcd(y,x%y);
}

LL jud(LL x0,LL y0,LL x1,LL y1,LL x2,LL y2){
	LL dx1=abs(x1-x0),dy1=abs(y1-y0);
	LL dx2=abs(x2-x0),dy2=abs(y2-y0);
	LL dx3=abs(x2-x1),dy3=abs(y2-y1);
	if(dx2*dy1==dx1*dy2){
		return 0;
	}else{
		return gcd(dx1,dy1)+gcd(dx2,dy2)+gcd(dx3,dy3);
	}
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);

    int n;cin>>n;
    rep(i,1,n){
    	cin>>p[i].ft>>p[i].sd;
	}LL ans=0;
	rep(i,1,n-2){
		rep(j,i+1,n-1){
			rep(k,j+1,n){
				LL x0=p[i].ft,y0=p[i].sd;
				LL x1=p[j].ft,y1=p[j].sd;
				LL x2=p[k].ft,y2=p[k].sd;
				//output(x0,x1,x2);
				
				//output(y0,y1,y2);
				
				ans=max(ans,jud(x0,y0,x1,y1,x2,y2));
				
				
			}
		}
	}
	cout<<ans;


    return 0;
}