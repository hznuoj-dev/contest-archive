#include "bits/stdc++.h"
typedef long long int ll;
using namespace std;
 
const int N = 25;
int arr[N+1][N+1];
    
void solve(){
    int n;
    cin >> n;
    vector<pair<int,int>> v(n);
    for(int i = 0 ; i< n;i++) {
        cin >> v[i].first >> v[i].second ;
    }
    ll ans = 0;
    for(int i = 0; i < n;i++) {
        for(int j = i+1; j < n;j++) {
            for(int k = j+1; k < n;k++) {
                auto [x1, y1] = v[i];
                auto [x2, y2] = v[j];
                auto [x3, y3] = v[k]; 
                auto dx1 = x2 - x1, dx2 = x3 - x1, dx3 = x3 - x2 ;
                auto dy1 = y2 - y1, dy2 = y3 - y1, dy3 = y3 - y2 ;
                
                if(dx1 * dy2 == dx2 * dy1) {
                    continue;
                }
                ll k1 = __gcd(abs(dx1),abs(dy1));
                ll k2 = __gcd(abs(dx2),abs(dy2));
                ll k3 = __gcd(abs(dx3),abs(dy3));
                // cout << " k1 + k2 + k3: " <<   k1 + k2 + k3 << endl;

                ans=  max(ans, k1 + k2 + k3);


            }
        }
    }
    cout << ans << endl;
     


    return ;


}



int main (){
    int t = 1;
    // cin >> t;
    while (t--){
        solve();
    }

    return 0;
}
/*

1 2
10 9 1
10 10 1
 
*/