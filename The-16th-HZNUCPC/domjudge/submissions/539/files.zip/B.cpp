#include <stdio.h>
#include <math.h>
int main() {
	long long int a, b;
	scanf("%lld %lld", &a, &b);
	if (b == 1) {
		printf("YES\n");
		return 0;
	}
	if (a <= b) {
		printf("NO\n");
		return 0;
	}
	if (a % 2 == 0) {
		printf("NO\n");
		return 0;
	}
	long long int n, x, i;
	x = fmin(sqrt(a), b);
	for (i = 3; i <= x; i++) {
		if (a % i == 0) {
			printf("NO\n");
			return 0;
		}
	}
	printf("YES\n");
	return 0;
}