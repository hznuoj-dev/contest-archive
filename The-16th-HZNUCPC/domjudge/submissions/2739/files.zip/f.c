#include <stdio.h>
#include <stdlib.h>
int sushu(int x);
int main(void) {
	int n,m;
	scanf("%d %d",&n,&m);
	if(n==0)
	{
		printf("NO");
	}
	else 
	{
		if(m==1)
		{
		printf("YES");
		}
		if((m>1&&m<=1000000000000)&&(n>=1&&n<=1000000000000))
		{
			{
				sushu(n);
				if((sushu(n))==0)
				{
					printf("NO");
				}
				if((sushu(n))==1)
				{
					if(n==m)
					{
						printf("NO");
					}
					if(n!=m)
					{
						printf("YES");
					}
		   		}
			}
		}
		if(m>1000000000000&&n>1000000000000)
		{
			printf("NO");
		}
	}
	return 0;
}

int sushu(int x){
	int flag;
	if(x==1)
	{
		flag=1;
	}
	if(x==2)
	{
		flag=1;
	}
	if(x>2)
	{
		for(int i=3;i<x;i++)
		{
			if(x%i==0)
			{
				flag=0;
				break;
			}
			else flag=1;
		}
	}
	return flag;
}

