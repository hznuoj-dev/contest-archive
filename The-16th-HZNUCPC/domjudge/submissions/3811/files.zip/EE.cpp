#include<bits/stdc++.h>
using namespace std;


struct point
{
	int x = 0;
	int y = 0;	
};


bool cmp(point a, point b)
{
	return a.x < b.x;
}


bool allowed(point a, point b, point c)
{
	if ((b.y - a.y) / (b.x - a.x) == (c.y - a.y) / (c.x - a.x))
	{
		return 0;
	}
	return 1;
}

int gcd(int a, int b)
{
	if (a == 0 || b == 0)
	{
		return max(a, b);
	}
	while(a!=b){
		if(a>b){
			a=a%b;
		}
		else if(a<b){
			b=b%a;
		}
		else {
			break;
		}
	}
	return a;
}



int main()
{
	int n = 0;
	cin >> n;
	point arr[105]{};
	for (int i = 0; i < n; i++)
	{
		scanf("%d%d", &arr[i].x, &arr[i].y);
	} 
	sort (arr, arr + n, cmp);
	int max_sum = 0;
	int s = 0;
	for (int i = 0; i < n; i++)
	{
		for (int j = i + 1; j < n; j++)
		{
			for (int k = j + 1; k < n; k++)
			{
				if (i == j || i == k || j == k)
				{
					continue;
				}
				s = 0;
				if (allowed(arr[i], arr[j], arr[k]))
				{
					s += gcd(abs(arr[j].y - arr[i].y), abs(arr[j].x - arr[i].x));
					s += gcd(abs(arr[k].y - arr[i].y), abs(arr[k].x - arr[i].x));
					s += gcd(abs(arr[j].y - arr[k].y), abs(arr[j].x - arr[k].x));
					max_sum = max(max_sum, s);
				}
			}
		}
	}
	cout << max_sum;
}
