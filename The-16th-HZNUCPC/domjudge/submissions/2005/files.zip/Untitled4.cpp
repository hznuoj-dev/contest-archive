#include<bits/stdc++.h>

#define ll long long
#define pdd pair<ll,ll>
const double eps=1e-9;
using namespace std;
vector<pdd>v;

double make1(double x1,double y1,double x,double y){
	return sqrt(pow((x1-x),2)+pow((y1-y),2));
}
bool abc(double a,double b,double c){
	return a+b-c>eps&&a+c-b>eps&&b+c-a>eps;
}
ll make(ll x1,ll y1,ll x,ll y){
	ll a=abs(x1-x);
	ll b=abs(y1-y);
	return __gcd(a,b);
}
ll check(pdd a,pdd b,pdd c){
	ll lena=make(a.first,a.second,b.first,b.second);
	ll lenb=make(b.first,b.second,c.first,c.second);
	ll lenc=make(a.first,a.second,c.first,c.second);
	
	double lenal=make1(a.first,a.second,b.first,b.second);
	double lenbl=make1(b.first,b.second,c.first,c.second);
	double lencl=make1(a.first,a.second,c.first,c.second);
	
	if(abc(lenal,lenbl,lencl)){
//		cout<<lenal+lenbl<<' '<<lencl<<endl;
		return lena+lenb+lenc;
	}
	return 0;
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int n;
	cin>>n;
	set<pdd>vis;
	pdd x;
	for(int i=0;i<n;i++){
		cin>>x.first>>x.second;
		if(vis.find(x)==vis.end()){
			vis.insert(x);
			v.push_back(x);
		}
	}
	n=v.size();
	ll ans=0;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			for(int z=0;z<n;z++){
				ans=max(ans,check(v[i],v[j],v[z]));		
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}