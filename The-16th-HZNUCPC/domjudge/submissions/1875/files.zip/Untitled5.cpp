#include<bits/stdc++.h>
int n;
int map[ 25 ][ 25 ];
int xx[]={-1,0,1,0};
int yy[]={0,1,0,-1};
int ans = 0;
void clean( int x , int y ){
	int cnt = 0;
	for( int i = 0 ; i < 4 ; i ++ ){
		int tx = x + xx[ i ] , ty = y + yy[ i ];
		if( map[ tx ][ ty ] != 0 && map[ tx ][ ty ] != map[ x ][ y ] ){

			cnt++;
		}
	}
	if( cnt == 4 ) map[ x ][ y ] = 0;
}
void check(int x , int y ){
	for( int i = 0 ; i < 4 ; i ++ ){
		int tx = x + xx[ i ],ty = y + yy[ i ];
		if( tx >= 1 && tx <= 19 && ty >= 1 && ty <= 19 && map[ tx ][ ty ] == 0 ){
//						std::cout<<tx<<' '<<ty<<'\n';
			ans++;
		}
	}
}
void solve(){
	std::cin>>n;
	ans = 0;
	std::memset( map , 0 , sizeof( map ) );
	for( int i = 1 ; i <= n ; i ++ ){
		int x , y , w ;std::cin>>x>>y>>w;
		map[ x ][ y ] = w;
//		clean( x , y );
	}
	for( int i = 1 ; i <= 19 ; i ++ ){
		for( int j = 1 ; j <= 19 ; j ++ ){
			if( map[ i ][ j ] == 1 ){
				check( i , j );
			}
		}
	}
	std::cout<<ans<<'\n';
}

int main(){
	int t;std::cin>>t;
	while( t-- )
		solve();
}