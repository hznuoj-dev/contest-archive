#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int main()
{
    ll n,m;
    cin>>n>>m;
    ll k=n;
    for(ll i=2;i<=n;i++)
    {
        if(n%i==0)
        {
            k=i;
            break;
        }
    }
    if(m==1||n==1)cout<<"YES";
    else if (m>=n||n%2==0||k<=m) cout <<"NO";
    else cout<<"YES";
    return 0;
}
