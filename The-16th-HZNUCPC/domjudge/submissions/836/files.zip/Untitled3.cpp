#include<bits/stdc++.h>
using namespace std;

int a[100][100];
int t,n;
int di[4][2]= {{-1,0},{1,0},{0,-1},{0,1}};

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cin>>t;
	while(t--)
	{
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				a[i][j]=0;
			}
		}
		cin>>n;
		for(int i=1; i<=n; i++)
		{
			int x,y,w;
			cin>>x>>y>>w;
			a[x][y]=w;
		}
		int res=0;
		for(int i=1; i<=19; i++)
		{
			for(int j=1; j<=19; j++)
			{
				if(a[i][j]==1)
				{
					for(int k=0; k<4; k++)
					{
						int x=i+di[k][0];
						int y=j+di[k][1];
						if(x>0&&x<=19&&y>0&&y<=19&&a[x][y]==0)
						{
							res++;
						}
					}
				}
			}
		}
		cout<<res<<"\n";
	}


	return 0;
}