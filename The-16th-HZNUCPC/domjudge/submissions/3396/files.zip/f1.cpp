#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	ll n,m;
	scanf("%lld%lld",&n,&m);
	if(n == 1 || m == 1 ){ 
		cout << "YES" << endl;
		return 0;
	}
	for(int i=2;i<=m;i++){
		if(n%i==0){
			puts("NO");
			return 0;
		}
	}
	puts("YES");
	return 0;
}

	