#include<bits/stdc++.h>
#define int long long
typedef long long ll;
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;

const int N=1e5+10,P=1e9+7,M=30;
string s1,s2;
int n;
int c1[M],c2[M],c[M][M];
int cnt1,cnt2;

int qmi(int a,int b)
{
	int ans=1;
	while(b)
	{
		if(b&1)ans=ans*a%P;
		a=a*a%P;
		b>>=1;
	}
	return ans;
}

bool check(int a,int b,int c,int d)
{
	if(!c1[a]||!c2[b]||!c1[c]||!c2[d])return false;
	c1[a]--;c1[b]++;c1[c]--;c1[d]++;
	c2[a]++;c2[b]--;c2[c]++;c2[d]--;
	int tc1=0,tc2=0;
	for(int i=0;i<26;i++)
	{
		tc1+=(c1[i]>0);
		tc2+=(c2[i]>0);
	}
	c1[a]++;c1[b]--;c1[c]++;c1[d]--;
	c2[a]--;c2[b]++;c2[c]--;c2[d]++;
	return tc1==tc2;
}

void solve()
{
	cin>>s1>>s2;
	n=s1.size();
	s1=" "+s1;s2=" "+s2;
	for(int i=1;i<=n;i++)
	{
		int x=s1[i]-'a';
		c1[x]++;
		if(c1[x]==1)cnt1++;
	}
	for(int i=1;i<=n;i++)
	{
		int x=s2[i]-'a';
		c2[x]++;
		if(c2[x]==1)cnt2++;
	}
	for(int i=1;i<=n;i++)
	{
		int x=s1[i]-'a',y=s2[i]-'a';
		c[x][y]++;
	}
	int ans=0;
	for(int i=0;i<26;i++)for(int j=0;j<26;j++)
	for(int ii=0;ii<26;ii++)for(int jj=0;jj<26;jj++)
	{
		if(!check(i,j,ii,jj))continue;
		int x=c[i][j],y=c[ii][jj];
		if(i==ii&&j==jj)
		{
			ans+=max(0ll,x*(x-1));
		}
		else
		{
			ans+=x*y;
		}
		ans%=P;
	}
	ans=ans*qmi(2,P-2)%P;
	cout<<ans<<endl;
}

signed main()
{
	solve();
}
