#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod = 1e9 + 7;
const int N = 110;

void solve(){
	string str, str1;
	cin >> str >> str1;
	int a = 0, n = str.length();
//	if(n < 20){
//			map<string, int> mp;
//	for(int i = 0; i < n; i++){
//		for(int j = i + 1; j < n; j++){
//			swap(str[i], str1[i]);
//			swap(str[j], str1[j]);
//			string s = str;
//			string t = str1;
//			if(s > t){
//				swap(s, t);
//			}
//			s += t;
//			mp[s] ++;
//			swap(str[i], str1[i]);
//			swap(str[j], str1[j]);
//		}
//	}
//	int ma = 0;
//	for(auto i : mp){
//		ma = max(ma, i.second);
//	}
////	for(auto i : mp){
////		if(i.second == ma){
//////			cout << "\n" << i.first << "\n";
////		}
////	}
//	cout << ma % mod << "\n";
//	return ;
//	}
	for(int i = 0; i < n; i++){
		if(str[i] == str1[i]){
			a ++;
		}
	}
//	cout << a * (a - 1) << " " << (n * (n - 1) / 2 - a * (a - 1) / 2 - 1) << "\n";
	int ans = 1;
	if(n >= 4 && n - a <= 4){
		if(n - a == 3){
			ans = a + 1;
		}else{
			ans = 2;
		}
	}
	if(n == 1){
		cout << "0\n";
	}else if(n == 2){
		cout << "1\n";
	}else if(n - a == 1){
		cout << max(ans, n * (n - 1) / 2) % mod << "\n";
	}else if(n - a == 2){
		ans = max(ans, a * (a - 1) / 2 + 1);
		if(a){
			ans = max(ans, (n * (n - 1) / 2 - a * (a - 1) / 2 - 1));
		}
		ans %= mod;
		cout << ans << "\n";
	}else{
		if(a != 2){
			cout << max(ans, a * (a - 1) / 2) % mod << "\n";
		}else{
			cout << max(2ll, ans) % mod << "\n";
		}
		
	}
	
		
	                                                 
}
signed main(){
	int t = 1;
//	freopen("1.txt", "in", stdin);
//	freopen("3.txt", "out", stdout);
//	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
