#include<bits/stdc++.h>
using namespace std;
#define int long long

void solve(){
	string str, str1;
	cin >> str >> str1;
	int n = str.length();
	map<string, int> mp;
	for(int i = 0; i < n; i++){
		for(int j = i + 1; j < n; j++){
			swap(str[i], str1[i]);
			swap(str[j], str1[j]);
			string s = str;
			string t = str1;
			if(s > t){
				swap(s, t);
			}
			s += t;
			mp[s] ++;
			swap(str[i], str1[i]);
			swap(str[j], str1[j]);
		}
	}
	int ma = 0;
	for(auto i : mp){
		ma = max(ma, i.second);
	}
//	for(auto i : mp){
//		if(i.second == ma){
////			cout << "\n" << i.first << "\n";
//		}
//	}
	cout << ma << "\n";
}
signed main(){
	int t = 1;
//	freopen("E:\\1.txt", "in", stdin);
//	freopen("2.txt", "out", stdout);
//	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
