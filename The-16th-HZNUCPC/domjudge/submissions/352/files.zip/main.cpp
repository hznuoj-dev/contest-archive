#include <iostream>
#include <vector>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;\

const int N=20;
bool st[N][N];
typedef pair<int,int>pii;
pii p[400];
vector<int>pst;
int dx[]={1,0,-1,0},dy[]={0,1,0,-1};

int main() {
	
	int t;
	cin>>t;
	while(t--)
	{
		pst.clear();
		memset(st,0,sizeof st);
		int n;
		cin>>n;
		int ans=0;
		for(int i=1;i<=n;i++)
		{
			int x,y,z;
			cin>>x>>y>>z;
			p[i]={x,y};
			if(z==1)
				pst.push_back(i);
			st[x][y]=1;
		}
		
		for(auto t:pst)
		{
			for(int i=0;i<4;i++)
			{
				int a=dx[i]+p[t].first,b=dy[i]+p[t].second;
				if(a<=0 || a> 19 || b<=0 ||b>19 )continue;
				if(st[a][b])continue;
				ans++;
			} 
		}
		
		cout<<ans<<endl;
		
	}
	
	
	
	return 0;
}