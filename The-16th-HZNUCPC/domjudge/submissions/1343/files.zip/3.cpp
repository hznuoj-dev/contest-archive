#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
bool check(ll x)
{
	if(x<2) return false;
	for(int i=2;i<=x/i;i++)
	{
		if(x%i==0) return false;
	}
	return true;
}
ll su(ll x)
{
	for(int i=2;i<=x/i;i++)
	{
		if(x%i==0) return i;
	}
	return x;
}
void solve()
{
	ll n,m;
	scanf("%lld%lld",&n,&m);
	if(n==1||m==1) printf("YES\n");
	else if(n<=m) printf("NO\n");
	else if(n%2==0)
	{
		if(m==1) printf("YES\n");
		else printf("NO\n");
	}
	else if(check(n)) printf("YES\n");
	else if(su(n)<m) printf("YES\n");
	else printf("NO\n");
}
int main()
{
	int t=1;
	//scanf("%d",&t);
	while(t--) solve();
	return 0;
}