#include<bits/stdc++.h>
#define PII pair<int,int>
#define F first
#define S second
#define LL long long
#define int LL
using namespace std;

const int N = 1e5 + 10,mod = 1e9 + 7;

int zia[27],zib[27],cnt1,cnt2;
int op[100],oop[100];
int a[N],b[N];
signed main()
{
	char ca[N],cb[N];
	cin >> ca + 1 >> cb + 1;
	int n = strlen(ca + 1);
	for(int i = 1;i <= n;i ++)
	{
		a[i] = ca[i] - 'a' + 1;
		b[i] = cb[i] - 'a' + 1;
		zia[a[i]] ++,zib[b[i]] ++;
	}
	
	for(int i = 1;i <= 26;i ++) 
	{
		if (zia[i]) cnt1 ++;
		if (zib[i]) cnt2 ++;
	}
	
	for(int i = 1;i <= n;i ++)
	{
		if (a[i] == b[i] || zia[a[i]] > 1 && zib[a[i]] >= 1 && zib[b[i]] > 1 && zia[b[i]] >= 1 || zia[a[i]] == 1 && zib[b[i]] == 1 && zia[b[i]] == 0 && zib[a[i]] == 0 || zia[a[i]] == 1 && zia[b[i]] == 0 && zib[b[i]] > 1 && zib[a[i]] > 0 || zib[b[i]] == 1 && zib[a[i]] == 0 && zia[a[i]] > 1 && zia[b[i]] > 0) op[1] ++;
		else if (zia[a[i]] > 1 && zib[a[i]] == 0 && zia[b[i]] > 0 && zib[b[i]] > 1|| zia[a[i]] == 1 && zib[a[i]] == 0 && zia[b[i]] == 0 && zib[b[i]] > 1) op[2] ++;
		else if (zib[b[i]] > 1 && zia[b[i]] == 0 && zib[a[i]] > 0 && zia[a[i]] > 1|| zib[b[i]] == 1 && zia[b[i]] == 0 && zib[a[i]] == 0 && zia[a[i]] > 1) op[3] ++;
		else if (zia[a[i]] > 1 && zib[a[i]] > 0 && zia[b[i]] >= 1 && zib[b[i]] == 1|| zia[a[i]] == 1 && zib[a[i]] > 0 && zia[b[i]] == 0 && zib[b[i]] == 1) op[4] ++;
		else if (zib[b[i]] > 1 && zia[b[i]] > 0 && zib[a[i]] >= 1 && zia[a[i]] == 1|| zib[b[i]] == 1 && zia[b[i]] > 0 && zib[a[i]] == 0 && zia[a[i]] == 1) op[5] ++;
		else if (zia[a[i]] == 1 && zib[b[i]] > 1 && zia[b[i]] > 1 && zib[a[i]] == 0) op[6] ++;
		else if (zib[b[i]] == 1 && zia[a[i]] > 1 && zib[a[i]] > 1 && zia[b[i]] == 0) op[7] ++;
		else if (zia[a[i]] > 1 && zib[b[i]] > 1 && zia[b[i]] == 0 && zib[a[i]] == 0) op[8] ++;
		else if (zia[a[i]] == 1 && zib[b[i]] == 1 && zia[b[i]] > 0 && zib[a[i]] > 0) op[9] ++;
	}
	
	oop[1] = op[1] + op[8] + op[9];
	oop[2] = op[3] + op[4];
	oop[3] = op[2] + op[5];
	oop[4] = op[6];
	oop[5] = op[7];
	
	if (abs(cnt1 - cnt2) >= 5) 
	{
		cout << 0;
	}
	else if (abs(cnt1 - cnt2) == 0) 
	{
		LL ans = 0;
		LL cnt = op[1] + op[8] + op[9];
		ans += cnt * (cnt - 1) / 2 + op[2] * op[3] + op[2] * op[4] + op[3] * op[5] + op[4] * op[5] + op[6] * op[7];
		
		cout << ans % mod;
	}
	else if (abs(cnt1 - cnt2) == 1)
	{
		if (cnt1 > cnt2)
		{
			LL ans = oop[1] * oop[2] + oop[3] * oop[4];
			cout << ans % mod;
		}
		else 
		{
			LL ans = oop[1] * oop[3] + oop[2] * oop[5];
			cout << ans % mod;
		}
		
	}
	else if (abs(cnt1 - cnt2) == 2)
	{
		if (cnt1 > cnt2)
		{
			LL ans = oop[1] * oop[4] + oop[2] * (oop[2] - 1) / 2;
			cout << ans % mod;
		}
		else 
		{
			LL ans = oop[1] * oop[5] + oop[3] * (oop[3] - 1) / 2;
			cout << ans % mod;
		}
	}
	else if (abs(cnt1 - cnt2) == 3)
	{
		if (cnt1 > cnt2)
		{
			LL ans = oop[2] * oop[4];
			cout << ans % mod;
		}
		else 
		{
			LL ans = oop[3] * oop[5];
			cout << ans % mod;
		}
	}
	else if (abs(cnt1 - cnt2) == 4)
	{
		if (cnt1 > cnt2)
		{
			LL ans = oop[4] *(oop[4] - 1) / 2;
			cout << ans % mod;
		}
		else 
		{
			LL ans = oop[5] * (oop[5] - 1) / 2;
			cout << ans % mod;
		}
	}
	return 0;
}