#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,k,t;
	while(cin>>n>>m){
		k =m;
		while(k>1){
			k = n%k;
		}
		if(k==0 && m!=1){
			cout <<"NO"<<endl;
		}else{
			cout <<"YES"<<endl;
		}
		
	}
	return 0;
}