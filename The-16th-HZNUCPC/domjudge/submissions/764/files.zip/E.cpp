#include<bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(),(a).end;
#define endl '\n'
using namespace std;

int n;

struct P {
	ll x, y;
}p[105];

bool check(P A, P B, P C)
{
	if (abs(1ll * (B.y - A.y) * (B.x - C.x)) == abs(1ll * (B.y - C.y) * (B.x - A.x)))
		return false;
	return true;
}

ll calc(P a, P b)
{
	ll yy = abs(b.y - a.y);
	ll xx = abs(b.x - a.x);
	return __gcd(xx, yy) + 1;
}

void solve()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> p[i].x >> p[i].y;
	ll mmax = 0;
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n; j++)
		{
			for (int k = 1; k <= n; k++)
			{
				if (i != j && i != k && j != k && check(p[i], p[j], p[k]))
				{
					mmax = max(mmax, calc(p[i], p[j]) + calc(p[i], p[k]) + calc(p[j], p[k]) - 3);
				}
			}
		}
	}
	cout << mmax << endl;
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t--) solve();
	return 0;
}