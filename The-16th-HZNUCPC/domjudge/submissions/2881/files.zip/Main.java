import java.util.Arrays;
import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			long piao = sc.nextLong();
			long ren = sc.nextLong();
			if (piao == 1 || ren == 1)
				System.out.println("YES");
			else {
				if (ren >= piao)
					System.out.println("NO");
				else {
					while (ren > 1) {
						ren = piao % ren;
						if (ren == 0) {
							System.out.println("NO");
							break;
						}
					}
					if (ren == 1)
						System.out.println("YES");
				}
			}
		}
	}
}
