#include<bits/stdc++.h>
using namespace std;

void solve(){
	long long n,m;
	cin>>n>>m;
	long long k=m;
	int flag=0;
	while(1){
		if(m!=1&&m!=0){
			m=n%m;
		}else{
			if(m==1){
				cout<<"YES"<<'\n';
			}else{
				cout<<"NO"<<'\n';
			}
			break;
		}
	}
//	while(1){
//		if(k==1){
//			flag=1;
//			break;
//		}
//		else if(k!=1&&n%k==0){
//			flag=0;
//			break;
//		}
//		else{
//			k=n%k;
//		}
//	}
//	if(flag) cout<<"YES"<<endl;
//	else cout<<"NO"<<endl;
}
int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
}
