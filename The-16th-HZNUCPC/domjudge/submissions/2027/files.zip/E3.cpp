#include<bits/stdc++.h>
using namespace std;
const int N = 110;

typedef long long ll;

int x[N],y[N];

int count(int x1,int y1,int x2,int y2){
	int a = abs(y2-y1) , b = abs(x2-x1);  // a fenzi b fenmu
	if(a>b) swap(a,b);
//	cout << a << " " << b << "\n";
	if(a==1) return 2;
	if(a==0) return b + 1;
	if(b%a==0) return a + 1;
	else return 2;
}

int main(){
	
//	cout << count(0,0,3,3) << endl;
	
	int n;cin>>n;
	for(int i=1;i<=n;i++) cin>>x[i]>>y[i];
	
	int res = 0;
	
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			for(int k=j+1;k<=n;k++){
				if((x[i]==x[j]&&x[j]==x[k])||(y[i]==y[j]&&y[j]==y[k])) continue;
				ll k1=1LL*(y[i]-y[j])*(x[j]-x[k]),k2=1LL*(y[j]-y[k])*(x[i]-x[j]);
				if(k1==k2) continue;
//				cout << count(x[i],y[i],x[j],y[j]) << " " << count(x[i],y[i],x[k],y[k]) << " " << count(x[j],y[j],x[k],y[k]) << endl;
				res = max(res,count(x[i],y[i],x[j],y[j]) + count(x[i],y[i],x[k],y[k]) +  count(x[j],y[j],x[k],y[k]) - 3) ;
			}
	
	cout << res << endl;
	return 0;
}
