#include <bits/stdc++.h>
using namespace std;
const int mod = 1e9+7;
typedef long long ll;
map<char,int> mp1, mp2;
ll cnt[10];
int vis1[30],vis2[30];
int main(){
	string sa, sb;
	cin >> sa >> sb;
	int cnta=0,cntb=0;
	int n = sa.size();
	for(int i=0;i<n;i++){
		if(!vis1[sa[i]-'a']){
			cnta++;	
		}
		vis1[sa[i]-'a']++;
	}
	for(int i=0;i<n;i++){
		if(!vis2[sb[i]-'a']){
			cntb++;	
		}
		vis2[sb[i]-'a']++;
	}
	if(cnta > cntb){
		swap(sa, sb);
		swap(cnta, cntb);
	}	
	for(int i=0; i<n; i++){
		mp1[sa[i]] ++;
		mp2[sb[i]] ++;
	}
	//int cnta = mp1.size(), cntb = mp2.size();
	for(int i=0; i<n; i++){
		int f1 = 0, f2 = 0;
		if(!mp2[sa[i]]) f1 = 1;
		if(!mp1[sb[i]]) f2 = 1;
		if(sa[i]==sb[i]) cnt[1] ++;  //���۲��� 
		else if(f1 && f2){
			cnt[2] ++;      //���۲��� 
		}else if(!f1 && f2){
			if(mp1[sa[i]]!=1) cnt[3]++;  //a+1, b-1
			else cnt[4]++;   //a����,b-1 
		}else if(f1 && !f2){
			if(mp2[sb[i]]!=1) cnt[5]++;  //a-1, b+1
			else cnt[6]++;  //b����,a-1 
		}else{
			if(mp2[sb[i]]==1 && mp1[sa[i]]==1) cnt[7]++; //b-1, a-1
			else if(mp1[sa[i]]==1) cnt[8]++; //a-1, b����
			else if(mp2[sb[i]]==1) cnt[9]++; //a����, b-1 
		}
	}
//	for(int i=1; i<=9; i++) printf("%d %lld\n",i,cnt[i]);
	ll ans = 0;
	if(cnta==cntb){
		if(sa==sb){
			ans = 1ll*n*(n-1)/2%mod;
		}else{
			ans = (cnt[1]*(cnt[1]-1)/2%mod + cnt[2]*(cnt[2]-1)/2%mod + cnt[3]*cnt[5]%mod + 
			cnt[8]*cnt[9]%mod + cnt[4]*cnt[6]%mod + cnt[4]*cnt[8]%mod + cnt[6]*cnt[9]%mod
			+cnt[1]*cnt[2]%mod)%mod; 
		}
	}else if(abs(cnta-cntb)>4){
		ans = 0;
	}else if(cnta+1==cntb){
		ans = (cnt[4]*cnt[2]%mod + cnt[4]*cnt[1]%mod + cnt[9]*cnt[1]%mod + cnt[9]*cnt[2]%mod)%mod;
	}else if(cnta+2==cntb){
		ans = (cnt[4]*(cnt[4]-1)/2%mod + cnt[9]*(cnt[9]-1)/2%mod + cnt[3]*cnt[1]%mod + cnt[3]*cnt[2]%mod)%mod;
	}else if(cnta+3==cntb){
		ans = (cnt[3]*cnt[4]%mod + cnt[3]*cnt[9]%mod)%mod;
	}else if(cnta+4==cntb){
		ans = cnt[3]*(cnt[3]-1)/2%mod;
	}
	printf("%lld\n",ans%mod);
	return 0;
}
