#include <iostream>
using namespace std;
using ll = long long;
int main(){
    ll a, b;
    cin >> a >> b;
    ll mn = a;
    for (long long i = 2; i * i <= a; i ++) {
        if (a % i == 0) {
            mn = i;
            break;
        }
    }
    if (a == 1) {
        cout << "YES\n";
        return 0;
    }
    if (b == 1) {
        cout <<"YES\n";
        return 0;
    }
    if (b < mn) {
        cout <<"YES\n";
    } else {
        cout <<"NO\n";
    }
    
}