#include<bits/stdc++.h>
using namespace std;

#define int long long
int vis[35][35];
int dir[4][2] = {{1,0},{0,1},{-1,0},{0,-1}};
signed main(){
	int T;
	cin >> T;
	while(T --){
		int n;
		cin >> n;
		memset(vis,0,sizeof(vis));
		for(int i = 0;i < n;i ++){
			int x, y, f;
			cin >>x>>y>>f;
			vis[x][y]=f;
		}
		int ans = 0;
		for(int i = 1;i <= 19;i ++){
			for(int j = 1;j <= 19;j++){
				if(vis[i][j] == 1){
					for(int k = 0;k < 4;k ++){
						int tx = i + dir[k][0];
						int ty = j + dir[k][1];
						if(tx < 1 || tx > 19 || ty < 1 || ty > 19) continue;
//						cout << tx << " " << ty << endl;
						if(vis[tx][ty] == 0) ans ++;
					}
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
