#include<bits/stdc++.h>
using namespace std;

const double MIN = 0.00001;
struct Point{
	int px;
	int py;
}point[105];

double k[5005];
int main()
{
	int n,cntk0=0,cntk=0,cnt=0;
	double kk;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>point[i].px>>point[i].py;
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if((point[j].px-point[i].px)==0){
				cntk0=1;
			}else if(point[j].py==point[i].py){
				cntk=1;
			}else{
				int flag=0;
				kk=1.0*(point[j].py-point[i].py)/(point[j].px-point[i].px);
				for(int q=0;q<cnt;q++){
					if(fabs(kk-k[q])<MIN){
						flag=1;
						break;
					}
				}
				if(flag==0){
					k[cnt]=kk;
				    cnt++;
				}
			}
		}
	}
	cout<<cnt+cntk0+cntk<<endl;
}