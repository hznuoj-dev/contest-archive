#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define IO ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
const ll mod=1e9+7;
const int maxn=1e5+10;
//---------------------------

char a[maxn],b[maxn];
int n,m;
int st[30],st2[30];
map<pair<char,char>,ll>mp;
set<char>s1,s2;
void huan(char f1,char f2)
{
    st[f1]--;st[f2]++;
    st2[f1]++;st2[f2]--;
    if(st[f1]==0)s1.erase(f1);
    if(st[f2]==1)s1.insert(f2);
    if(st2[f1]==1)s2.insert(f1);
    if(st2[f2]==0)s2.erase(f2);
}
void solve()
{
    cin>>a+1;
    cin>>b+1;
    n=strlen(a+1);
    ll cnt1=0,cnt2=0;
    for(int i=1;i<=n;i++)
    {
        a[i]-='a';
        b[i]-='a';
        st[a[i]]++;
        st2[b[i]]++;

    }
    for(int i=0;i<26;i++)
    {
        if(st[i])s1.insert(i);
        if(st2[i])s2.insert(i);
    }
    ll ans=0;
    for(int i=1;i<=n;i++)
    {
        huan(a[i],b[i]);
        //cout<<s1.size()<<" "<<s2.size()<<endl;
        for(auto e:mp)
        {
            huan(e.first.first,e.first.second);
            if(s1.size()==s2.size())
            {
                ans+=e.second;
                ans%=mod;
            }
            huan(e.first.second,e.first.first);
        }
        huan(b[i],a[i]);
        mp[{a[i],b[i]}]++;
    }
    cout<<ans;
}
int main()
{
    IO;
    int tn=1;
    //cin>>tn;
    while(tn--)
    {
        solve();
    }
    return 0;
}
