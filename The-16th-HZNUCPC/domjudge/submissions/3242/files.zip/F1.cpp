#include<iostream>
using namespace std;
int main()
{
	long long m,n;
	cin>>m>>n;
	if(n<=m)
	cout<<"NO"<<endl;
	else if(n%m==m-1)
	cout<<"YES"<<endl;
	else
	cout<<"NO"<<endl;
	return 0;
}