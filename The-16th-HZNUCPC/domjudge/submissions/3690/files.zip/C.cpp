#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 10;
const int mod = 1e9 + 7;
map<string,int> mp;
int vis[N];
signed main(){
	string a,b;
	while(cin >> a >> b){
		memset(vis,0,sizeof(vis));
		bool flag = false;
		for(int i = 0;i < a.size();i ++){
			if(a[i] == b[i]) vis[i + 1] = 1;
			if(vis[i + 1] == 1 && vis[i] == 1){
				flag = true;
				break;
			}
		}
		int ans = 1;
		if(flag) {
			for(int i = 1;i < a.size();i ++){
				ans = (ans * i) %mod;
			}
		}
	}	
	return 0;
}
