#include<bits/stdc++.h>


#define int long long
#define endl '\n'
using namespace std;

int n;

int f[30][30];

int dx[]= {-1,1,0,0};
int dy[]= {0,0,-1,1};

int  yx(int x,int y) {
	if(f[x][y]==1)return 1;
	if(f[x][y]==2)return 2;
	return 3;
//	f[x][y]+=3;
}

void slove() {
	cin>>n;


	memset(f,0,sizeof f);
	for(int i=1; i<=n; i++) {
		int a,b,c;
		cin>>a>>b>>c;
		f[a][b]=c;
	}
int ans=0;
	for(int i=1; i<=19; i++) {
		for(int j=1; j<=19; j++) {
			if(f[i][j]==1) {
				for(int k=0; k<4; k++) {
					int x=i+dx[k],y=j+dy[k];
					if(x>=1&&x<=19&&y>=1&&y<=19)
						f[x][y]=yx(x,y);
						if(f[x][y]==3)ans++;
				}
			}
		}
	}
	
//	for(int i=1; i<=19; i++) {
//		for(int j=1; j<=19; j++) {
//			cout<<f[i][j]<<' ';
//		}
//		cout<<endl;
//	}
//
//	int ans=0;
//
//	for(int i=1; i<=19; i++) {
//		for(int j=1; j<=19; j++) {
//			if(f[i][j]==3) {
//				ans++;
//			}
//		}
//	}

	cout<<ans<<endl;

}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	int t=1;
	cin>>t;

	while(t--) {
		slove();
	}
}
