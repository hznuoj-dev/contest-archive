#include<bits/stdc++.h>
//#define int long long
//#define mid (l+r>>1)
using namespace std;
typedef long long ll;
const int mod=1e9+7;
int cnt1[27],cnt2[27];
int ts1=0,ts2=0;
char s1[100005],s2[100005];
int sum[6];
int main(){
	scanf("%s%s",s1,s2);
	for(int i=0;i<strlen(s1);i++){
		cnt1[s1[i]-'a']++;
		cnt2[s2[i]-'a']++;
		if(cnt1[s1[i]-'a']==1)ts1++;
		if(cnt2[s2[i]-'a']==1)ts2++;
	}
	for(int i=0;i<strlen(s1);i++){
		int d=0;
		if(cnt1[s1[i]-'a']-1==0)d+=1;
		if(cnt2[s2[i]-'a']-1==0)d-=1;
		if(cnt1[s2[i]-'a']+1==1)d-=1;
		if(cnt2[s1[i]-'a']+1==1)d+=1;
		sum[d+2]++;
	}
//	for(int i=0;i<5;i++){
//		printf("#%d:%d\n",i-2,sum[i]);
//	}
	int ans=0;
	for(int i=-2;i<3;i++){
		for(int j=i;j<3;j++){
			if(i+j==ts1-ts2){
				if(i==j){
					ans=(ans+(ll)(sum[i+2]-1)*sum[i+2]/2)%mod;	
				}else{
					ans=(ans+(ll)sum[i+2]*sum[j+2])%mod;
				}
				
			}
		}
	}printf("%d\n",ans);
	return 0;	
}