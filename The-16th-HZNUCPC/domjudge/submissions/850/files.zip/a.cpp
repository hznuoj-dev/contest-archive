#include <bits/stdc++.h>

using i64 = long long;

int a[19][19];

void solve() {
	std::memset(a, 0, sizeof a);
	
	int n;
	std::cin >> n;
	
	for (int i = 0; i < n; i++) {
		int x, y, c;
		std::cin >> x >> y >> c;
		x--, y--;
		a[x][y] = c;
	}
	
	int ans = 0;
	for (int i = 0; i < 19; i++) {
		for (int j = 0; j < 19; j++) {
			if (a[i][j] == 1) {
				if (i > 0) ans += a[i - 1][j] == 0;
				if (i + 1 < 19) ans += a[i + 1][j] == 0;
				if (j > 0) ans += a[i][j - 1] == 0;
				if (j + 1 < 19) ans += a[i][j + 1] == 0;
			}
		}
	}
	
	std::cout << ans << "\n";
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int t;
	std::cin >> t;
	
	while (t--) {
		solve();
	}	
	
	return 0;
}
