#include<bits/stdc++.h>
using namespace std;

#define N 105
typedef pair<int, int> pii;
pii a[N];
int n;
int cal(pii x, pii y) {
	int xx = abs(x.first - y.first);
	int yy = abs(x.second - y.second);
	int gcdd = __gcd(xx, yy);
	if(xx == 0) return max(0, yy - 1);
	if(yy == 0) return max(0, xx - 1);
	return max(0, gcdd - 1);
}
bool check(pii x,pii y,pii z) {
	if(x.first == y.first && x.first == z.first) return false;
	if(x.first == y.first && x.first != z.first) return true;
	if(x.first != y.first && x.first == z.first) return true;
	if(((x.second - y.second) / (x.first - y.first)) == ((x.second - z.second) / (x.first - z.first))) return false;
	return true;
}
int main() {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i].first >> a[i].second;
	}
	//sort(a + 1, a + 1 + n);
	int res = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			for (int k = 1; k <= n; k++) {
				if (i != j && i != k && j != k) {
					if(check(a[i], a[j], a[k])) {
						res = max(res, 3 + cal(a[i], a[j]) + cal(a[i], a[k]) + cal(a[k], a[j]));	
					}
					
				}
			}
		}
	}
	cout << res << endl;
	return 0;
}