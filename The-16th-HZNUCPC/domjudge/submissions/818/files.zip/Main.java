package oj;

import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		long caipan = in.nextLong();
		long num = in.nextLong();
		long m = caipan % num;
		boolean f = true;
		if(num == 1){
			f = false;
			System.out.println("YES");
		}
		while(f){
			if(m == 0){
				System.out.println("NO");
				f = false;
				break;
			} else{
				m = caipan % m;
			}
		}
		if(m == 1){
			System.out.println("YES");
		}
	}
}
