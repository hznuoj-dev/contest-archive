#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e6+5;
const int M=1e3+5;
//int n,m,k,c,t;
int n,m,k;
int cs[N];
int az[4][2] = {{1,0},{0,1},{-1,0},{0,-1}};
long long ans;
//int s[N];
//string str,a;
//int vis[25][25],vss[25][25];
//int vis[105][105];
//struct node{
//	int x,y,z;
//}s[N];
//int pd(int x,int y,int xx,int yy){
//	return sqrt((x - xx) * (x - xx) + (y - yy) + (y - yy));
//}
signed main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	while (cin >> n >> m){
		if (n % m != 0 || m == 1) cout << "YES" << endl;
		else cout << "NO" << endl;
	}
}