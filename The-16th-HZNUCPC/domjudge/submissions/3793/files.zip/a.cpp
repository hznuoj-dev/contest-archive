// #include <bits/stdc++.h>
// using namespace std;
// int main(){
//     string a,b;
//     cin>>a>>b;
//     map<char,int>mp1,mp2;
//     for(int i=0;i<a.size();i++)
//     {
//         mp1[a[i]]++;
//     }
//     for(int i=0;i<b.size();i++)
//     {
//         mp2[b[i]]++;
//     }
//     vector<int>s(10);
//     for(int i=0;i<a.size();i++)
//     {
//         if(a[i]==b[i]||(mp1[b[i]]!=0&&mp2[a[i]]!=0))
//     }
// }