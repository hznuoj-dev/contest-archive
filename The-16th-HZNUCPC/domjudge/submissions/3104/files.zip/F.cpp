#include<iostream>
using namespace std;
int main(){
	long long n,m;
	cin >> n >> m;
	string res="NO";
	if(m==1||n==1) res="YES";
	else{
		long long k=m;
		while(k>0){
			if(n%k==1){
				res="YES";
				break;
			}
			k--;
		}
		
	}
	cout << res << endl;
			
}
	