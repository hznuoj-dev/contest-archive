#include<iostream>
using namespace std;
int main()
{
	long long n,m;
	cin>>n>>m;
	while(1)
	{
	if(m==1)
	{
		cout<<"YES";
		break;
	}
	if(m==0)
	{
		cout<<"NO";
		break;
	}
	m=n%m;
	}
	return 0;
}