#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define PII pair<int,int>
const int N = 10010;
int ma[20][20];
int st[20][20];
PII hei[N];
int dx[4] = {0,0,1,-1};
int dy[4] = {1,-1,0,0};

signed main(){
	int t;
	cin >> t;
	while(t--){
		int n;
		cin >> n;
		int cnt = 0;
		memset(st ,0,sizeof(st));
		for(int i=1;i<=n;i++){
			int a,b,w;
			cin >> a >> b >> w;
			if(w == 1){
				cnt ++;
				hei[cnt] = {a,b};
				st[a][b] = 1;
			}else{
				st[a][b] = 1;
			}
		}
		int ans = 0;
		for(int i=1;i<=cnt;i++){
			int a = hei[i].first ;
			int b = hei[i].second;
			for(int j=0;j<4;j++){
				int x = a + dx[j];
				int y = b + dy[j];
				if(x < 1 || y > 19 || x > 19 || y < 1) continue;
				if(st[x][y] == 1) continue;
				ans ++;
			}
		}
		cout << ans << '\n';
	}
	return 0;
}