#include<bits/stdc++.h>
using namespace std;
const int N = 1e5+5;
int k[1000006];
long long n,m;

int main(){
	while(cin >> n >> m){
		if(m==1 ||n==1){
			cout <<"YES\n";
			continue;
		}
		int alng=1;
		if(n<=m){
			cout << "NO\n";
			continue;
		}
		for(int i=2;i<=sqrt(n)+1;i++){
			if(i>m){
				alng=1;
				break;
			}
			if(n%i==0){
				alng=0;
				break;
			}
		}
		if(alng)cout <<"YES\n";
		else cout << "NO\n";
	}
	return 0;
}         
