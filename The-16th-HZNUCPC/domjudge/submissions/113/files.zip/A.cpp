#include<bits/stdc++.h>
typedef long long ll;
const ll N=5e3+7;
const ll mod =1e9+7;
const double eps =1e-6;
using namespace std;
void slove(){
ll n,m;cin>>n>>m;
ll k=sqrt(n);
	for(ll i=2;i<=min(k,m);i++){
		if(n%i==0&&i<=m){
			cout<<"NO\n";
			return ;
		}
	}
	cout<<"YES\n";
}
int main(){
	slove();
}
