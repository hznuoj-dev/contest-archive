#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define IO ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
const ll mode=1e9+7;
const int maxn=1e5+10;
//---------------------------
struct node
{
    int x,y,c;
    bool operator<(const node&o)const
    {
        return x<o.x;
    }
};

void solve()
{
   ll n,m;
   cin>>n>>m;

   while(1)
   {
       if (n==1 || m==1)
       {
           cout<<"YES"<<endl;
            return;
       }

         if (n%m==0)
        {
           cout<<"NO"<<endl;
            return;
       }

        ll xm = n%m;
        if (xm==m)
        {
           cout<<"NO"<<endl;
            return;
       }
       m = xm;
   }
}
int main()
{
    IO;
    int tn=1;
    //cin>>tn;
    while(tn--)
    {
        solve();
    }
    return 0;
}
