#include<bits/stdc++.h>
using namespace std;
long long n , m;

int main (){
	bool flag0=false;
//	cout<<"1";
	cin >> n >> m;
	if(n <= m){
		cout << "NO" << endl;
	}
	else {
		while(m>1){
			m = n % m;
			if(m == 0){
				cout << "NO" << endl;
				flag0=true;
				break;
			}
		}
			if(!flag0) cout << "YES" << endl;
	}
	return 0;
}