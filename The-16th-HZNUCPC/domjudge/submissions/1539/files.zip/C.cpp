#include<bits/stdc++.h>
#define LL long long
using namespace std;
const int maxn=100005,tt=1000000007;
char s1[maxn],s2[maxn];
int a[maxn],b[maxn];
int l1,l2,na,nb;
bool vis[5][5][5][5];
LL cnt[5][5],ans;
int main()
{
	scanf("%s%s",&s1,&s2);
	l1=strlen(s1);
	l2=strlen(s2);
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	na=nb=0;
	for (int i=0; i<l1; i++)
	{
		if (a[s1[i]-'a']==0) na++;
		a[s1[i]-'a']++;
	}
	for (int i=0; i<l2; i++)
	{
		if (b[s2[i]-'a']==0) nb++;
		b[s2[i]-'a']++;
	}
	memset(cnt,0,sizeof(cnt));
	for (int i=0; i<l1; i++)
	{
		int x1=s1[i]-'a',x2=s2[i]-'a';
		int t1=1,t2=1;
		if (a[x1]==1) t1--;
		if (a[x2]==0) t1++;
		if (b[x2]==1) t2--;
		if (b[x1]==0) t2++;
		cnt[t1][t2]++;
	}
	ans=0;
//	for (int i=0; i<=2; i++)
//	 for (int j=0; j<=2; j++)
//	  {
//	  	printf("%d %d %lld\n",i,j,cnt[i][j]);
//	  }
	memset(vis,0,sizeof(vis));
	for (int i=0; i<=2; i++)
	 for (int j=0; j<=2; j++)
	  for (int k=0; k<=2; k++)
	   for (int t=0; t<=2; t++)
	    if (!vis[i][j][k][t]&&!vis[k][t][i][j])
	  {
	  	vis[i][j][k][t]=1;
	  	int x=i-1,y=j-1,xx=k-1,yy=t-1;
	  	if (x+xx-y-yy!=nb-na) continue;
//	  	printf("%d %d %d %d %d %d %lld\n",x,y,xx,yy,cnt[i][j],cnt[k][t],ans);
	  	if (cnt[i][j]==0||cnt[k][t]==0) continue;
	  	if (x==xx&&y==yy) ans+=cnt[i][j]*(cnt[k][t]-1)/2,ans%=tt;
	  	 else ans+=cnt[i][j]*cnt[k][t],ans%=tt;
	  }
	printf("%lld",ans%tt);
	return 0;
}