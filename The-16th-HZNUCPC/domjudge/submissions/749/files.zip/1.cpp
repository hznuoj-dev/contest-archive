#include<iostream>
#include<cstring>
using namespace std;

int dx[4] = {1, -1, 0, 0};
int dy[4] = {0,0,1,-1}; 

int main(){
	int t;
	cin >> t;
	while (t --) {
		int n;
		cin >> n;
		int G[25][25];
		int f[25][25];
		memset(G, 0, sizeof G);
		memset(f, 0, sizeof f);
		for (int i = 0; i < n; i ++) {
			int x, y, c;
			cin >> x >> y >> c;
			G[x][y] = c;
		}
		for(int i = 1; i < 20; ++i){
			for(int j = 1; j < 20; ++j){
				if(G[i][j] == 1){
					for(int k = 0; k < 4; ++k){
						if(G[i + dx[k]][j +dy[k]] == 0){
							++f[i+dx[k]][j + dy[k]];
						}
					}
				}

			}
		}
		int res = 0;
		for(int i = 1; i < 20; ++i){
			for(int j = 1; j < 20; ++j){
				res += f[i][j];
			}
		}
		cout << res << endl;
	}
}