/*#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll mod = 1e9+7;


ll qpow(ll a,ll b){
    ll ans = 1;
    while(b){
        if(b&1) ans = ans*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return ans;
}

bitset<10> bs;

int pa[N];
int find(int a){
    return pa[a]==a?a:pa[a] = find(pa[a]);
}

void merge(int a,int b){
    a = find(a),b = find(b);
    if(a==b) return;
    pa[a] = b;
}
int op[N],x[N],y[N];
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    bs.set(1);
    bs.set(5);
    for(int i = bs._Find_first();i!=bs.size();i=bs._Find_next(i)){
        cout<<i<<endl;
    }

    int n,q,m;
    cin>>n>>q>>m;
    for(int i=1;i<=n;i++) pa[i] = i;
    for(int i=1;i<=m;i++){

    }
}
*/

#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll mod = 1e9+7;
const ll N = 1e6+10;
struct bus{
    int t,l,r;
};
struct peo{
    int id;
    int t,pos;
};
struct range{
    int l,r,dis;
};

struct cmp{
    bool operator()(range a,range b){
        return a.r<b.r;
    }
};
int ans[N];
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n,m,x;
    cin>>n>>m>>x;
    vector<bus> vb(n);
    vector<peo> vp(m);
    for(int i=0;i<n;i++){
        cin>>vb[i].t>>vb[i].l>>vb[i].r;
    }
    for(int i=0;i<m;i++){
        cin>>vp[i].t>>vp[i].pos;
        vp[i].id = i;
    }
    sort(vb.begin(),vb.end(),[](bus a,bus b){
            if(a.t!=b.t) return a.t>b.t;
            return a.r>b.r;
         });
    sort(vp.begin(),vp.end(),[](peo a,peo b){
            return a.t>b.t;
         });

    set<range,cmp> st;
    st.insert({1,x-1,0x3f3f3f3f});
    st.insert({x,x,0});
    int posp = 0;
    int posb = 0;
    for(int i=100000;i>=1;i--){
        while(posb<vb.size()&&vb[posb].t>=i){
            int l = vb[posb].l,r = vb[posb].r;
            auto it = *st.lower_bound({r,r,0});
            int d = it.dis+1;
            r = it.l-1;
            if(l>r){
                posb++;
                continue;
            }

            it = *st.lower_bound({l,l,0});
            if(it.l!=l){
                st.erase(it);
                st.insert({it.l,l-1,it.dis});
                st.insert({l,it.r,it.dis});
            }
            it = *st.lower_bound({r,r,0});
            if(it.r!=r){
                st.erase(it);
                st.insert({r+1,it.r,it.dis});
                st.insert({it.l,r,it.dis});
            }
            while(1){
                auto iter = st.lower_bound({l,l,0});
                if(iter==st.end()||iter->l>r) break;
                st.erase(iter);
            }
            while(1){
                if(l==1) break;
                auto iter = st.lower_bound({l-1,l-1,0});
                if(iter->dis==d){
                    l = iter->l;
                    st.erase(iter);
                }else {
                    break;
                }
            }
            st.insert({l,r,d});
            //cout<<posb<<' ';
            //for(auto x:st){
            //    cout<<x.l<<' '<<x.r<<' '<<x.dis<<'|';
            //}
            //cout<<endl;
            posb++;
        }
        while(posp<vp.size()&&vp[posp].t>=i){
            auto it = *st.lower_bound({vp[posp].pos,vp[posp].pos,0});
            ans[vp[posp].id] = it.dis;
            posp++;
        }
    }
    for(int i=0;i<m;i++){
            if(ans[i]==0x3f3f3f3f) cout<<-1<<endl;
            else cout<<ans[i]<<endl;
    }
}
