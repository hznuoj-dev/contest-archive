#include<iostream>
#include<set>

using namespace std;

int n, t, x, y, c, m;
set<int> aa;

int main () {
	cin >> n >> m;
	int flag = 1;
	if (n == 1) {
		cout << "YES\n";
		return 0;
	}
	for (int i = 2; ; i++) {
		while (n % i == 0) {
			n /= i;
			aa.insert(i);
		}
		if (n == 1) break;
	}
	if (m >= *(aa.begin())) cout << "NO\n";
	else cout << "YES\n";
	return 0;
}