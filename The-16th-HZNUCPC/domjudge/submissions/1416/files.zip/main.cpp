#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
bool check(pair<int,int> A, pair<int,int> B, pair<int,int> C) {
	int x1 = A.first, y1 = A.second;
	int x2 = B.first, y2 = B.second;
	int x3 = C.first, y3 = C.second;
	return !((y2 - y1) * (x3 - x1) == (y3 - y2) * (x2 - x1));
}
void solve() {
	int n;
	cin >> n;
	vector<pair<int,int>> a(n + 1);
	for (int i = 1;i <= n;i ++) {
		cin >> a[i].first >> a[i].second;
	}
	int ans = 0;
	for (int i = 1;i <= n;i ++) {
		for (int j = i + 1;j <= n;j ++) {
			for (int k = j + 1;k <= n;k ++) {
				if(check(a[i],a[j],a[k])) {
					int now = 0;
					int x1 = a[i].first, y1 = a[i].second;
					int x2 = a[j].first, y2 = a[j].second;
					int x3 = a[k].first, y3 = a[k].second;
					if(x2 - x1 != 0 && y2 - y1 != 0){
//						cout << "**" << endl;
						now += abs(x2 - x1) / (abs(x2 - x1) / (__gcd(abs(x2 - x1) , abs(y2 - y1))));
					}
					else if(x2 - x1 ==0){
						now += max(y2,y1) - min(y2,y1);
					}
					else now += max(x2,x1) - min(x2,x1);
					if(x3 - x2 != 0 && y3 - y2 != 0){
//						cout << "**" << endl;
						now += abs(x3 - x2) / (abs(x3 - x2) / (__gcd(abs(x3 - x2) , abs(y3 - y2))));
					}
					else if(x3 - x2 == 0){
						now += max(y3,y2) - min(y3,y2);
					}
					else now += max(x3,x2) - min(x3,x2);
					if(x3 - x1 != 0 && y3 - y1 != 0) {
//						cout << "**" << endl;
						now += abs(x3 - x1) / (abs(x3 - x1) / (__gcd(abs(x3 - x1) , abs(y3 - y1))));
					}
					else if(x3 - x1 == 0){
						now += max(y3,y1) - min(y3,y1);
					}
					else now += max(x3,x1) - min(x3,x1);
//					cout << now << endl;
					ans = max(now, ans);
				}
			}
		}
	}
	cout << ans << endl;
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    solve();
    return 0;
}
/*
4
0 0
1 1
2 4
4 2

4
1 1
2 2
3 3
2 4
*/
