#include <bits/stdc++.h>
using namespace std;
int read()	{
	int fw = 1, x = 0;
	char c = getchar();
	while (c < '0' || c > '9')	{
		if (c == '-')	fw = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9')	{
		x = (x << 1) + (x << 3) + c - '0';
		c = getchar();
	}
	return fw * x;
}
int a[20][20], dx[4] = {0, 0, 1, -1}, dy[4] = {1, -1, 0, 0};
int main()	{
	//freopen("data.in", "r", stdin);
	//freopen("data.out", "w", stdout);
	int T = read();
	while (T--)	{
		memset(a, 0, sizeof(a));
		int n = read(), x, y, c, cnt = 0;
		for (int i = 1; i <= n; i++)	{
			x = read(), y = read(), c = read();
			a[x][y] = c;
		}
		for (int i = 1; i <= 19; i++)
			for (int j = 1; j <= 19; j++)	{
				if (a[i][j] == 1)	{
					for (int k = 0; k < 4; k++)	{
						if (a[i + dx[k]][j + dy[k]] == 0 && i + dx[k] >= 1 && i + dx[k] <= 19 && j + dy[k] >= 1 && j + dy[k] <= 19)	
							cnt++;
					}
				}
			}
		printf("%d\n", cnt);
	}
	
}