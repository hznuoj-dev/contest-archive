#include<bits/stdc++.h>

using namespace std;

const int N = 20;

typedef pair<int,int> pii;
int dt[2][4] = {{1,-1,0,0},{0,0,1,-1}};
set<pii> st;
vector<pii> ve;
int cnt;
void run(int x, int y){
	for(int i = 0; i < 4; i++){
		int xx = x + dt[0][i];
		int yy = y + dt[1][i];
		if(xx>0 && xx<=19 && yy>0 && yy<=19 && !st.count({xx,yy})){
			ve.push_back({xx,yy});
		}
	}
	return;
}
void solve(){
	cnt = 0;
	st.clear();
	ve.clear();
	
	int n;
	scanf("%d",&n);
	
	while(n--){
		int x,y,c;
		scanf("%d%d%d", &x, &y, &c);
		if(c == 1){
			st.insert({x,y});
		}
	}
	
	for(auto s:st){
		run(s.first, s.second);
	}
	
	int ans = ve.size();
	printf("%d\n", ans);
	return;
}
signed main(){
	int T = 1;
	scanf("%d", &T);
	
	while(T--){
		solve();
	}
	
	return 0;
}