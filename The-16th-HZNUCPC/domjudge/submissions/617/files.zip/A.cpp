#include<bits/stdc++.h>
using namespace std;
const int N=50;
int qp[N][N];
void solve()
{
	int n;
	cin>>n;
	for(int i=0;i<=49;i++)
	{
		for(int j=0;i<=49;i++)
		{
			qp[i][j]=0;
		}
	}
	
	for(int i=1;i<=n;i++)
	{
		int x,y,c;
		cin>>x>>y>>c;
		qp[x][y]=c;
	}
	int ans=0;
	for(int i=1;i<=19;i++)
	{
		for(int j=1;j<=19;j++)
		{
			if (qp[i][j]==1)
			{
				if(j+1<=19)if(qp[i][j+1]==0)	ans++;
				if(i+1<=19)if(qp[i+1][j]==0)	ans++;
				if(i-1>=1)if(qp[i-1][j]==0)	ans++;
				if(j-1>=1)if(qp[i][j-1]==0)	ans++;
			}
		}
	}
	cout<<ans<<"\n";
}
int main()
{
	int T;
	cin>>T;
	while(T--)
	{
		solve();
	}
}