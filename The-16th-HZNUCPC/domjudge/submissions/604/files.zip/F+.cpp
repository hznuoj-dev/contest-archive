#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 105;
int n,m;
void solve() {
	cin>>n>>m;
	for(int i=2;n/i>=i&&i<=m;i++)
	{
		if(n%i==0)
		{
			printf("NO\n");
			return;
		}
	}
	if(n<=m)
	{
		printf("NO\n");
		return;
	}
	printf("YES\n");
	return;
}
signed main() {
	ios::sync_with_stdio(false);
	int T = 1;
	while(T--) {
		solve();
	}
	return 0;
}