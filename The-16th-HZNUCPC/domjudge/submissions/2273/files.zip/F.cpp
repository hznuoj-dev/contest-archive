#include<iostream>
using namespace std;
typedef long long ll;
ll n,m;
long long gcd(ll a,ll b){
	if(!b)return a;
	return gcd(b,a%b);
}
int main(){
	cin>>n>>m;
	if(m==1)puts("YES");	
    if(n%2==0)puts("NO");
    else
    {
    	int t=gcd(n,m);
    	if(t==1)puts("YES");
    	else puts("NO");
	}
	return 0;
}