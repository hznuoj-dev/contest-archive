#include <bits/stdc++.h>
#define int int64_t
#define endl '\n'
using namespace std;
const int MOD = 1e9+7;

int a[128][128] = {0};
int cnts = 0;
int ss[128] = {0};
int cntt = 0;
int tt[128] = {0};

void solve() {
	string s, t;
	cin >> s >> t;
	int n = s.size();
	for (int i = 0; i < n; i++) {
		ss[s[i]]++;
		if (ss[s[i]] == 1) cnts++;
		tt[t[i]]++;
		if (tt[t[i]] == 1) cntt++;
		a[s[i]][t[i]]++;
	}
	int res = 0;
	for (int i = 'a'; i <= 'z'; i++) {
		for (int j = 'a'; j <= 'z'; j++) {
			if (a[i][j] == 0) continue;
			int x = a[i][j];
			a[i][j]--;
			for (int ii = 'a'; ii <= 'z'; ii++) {
				for (int jj = 'a'; jj <= 'z'; jj++) {
					if (a[ii][jj] == 0) continue;
					int y = a[ii][jj];
					int xx = cnts, yy = cntt;
					if (ss[i] == 1) xx--;
					ss[i]--;
					if (ss[j] == 0) xx++;
					ss[j]++;
					if (tt[j] == 1) yy--;
					tt[j]--;
					if (tt[i] == 0) yy++;
					tt[i]++;
					if (ss[ii] == 1) xx--;
					ss[ii]--;
					if (ss[jj] == 0) xx++;
					ss[jj]++;
					if (tt[jj] == 1) yy--;
					tt[jj]--;
					if (tt[ii] == 0) yy++;
					tt[ii]++;
					if (xx == yy) {
//#ifdef DEBUG
//cout << (char)i << ' ' << (char)j << ' ' << (char)ii << ' ' << (char)jj << ' ' << x << ' ' << y << " **\n";
//#endif
						if (i == ii and j == jj) {
							res += x * y;
							res %= MOD;
						} else {
							res += x * y;
							res %= MOD;
						}
					}
					ss[i]++;
					ss[j]--;
					tt[j]++;
					tt[i]--;
					ss[ii]++;
					ss[jj]--;
					tt[jj]++;
					tt[ii]--;
				}
			}
			a[i][j]++;
		}
	}
	cout << res * (int)(5e8+4) % MOD << endl;
}

int32_t main() {
	cin.tie(0);
	cout.tie(0);
	ios::sync_with_stdio(false);
	
	solve();
	
	return 0;
}