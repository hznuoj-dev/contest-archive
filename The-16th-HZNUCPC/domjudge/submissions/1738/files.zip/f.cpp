#include<bits/stdc++.h>
using namespace std;

int main(){
	long long n,m;
	while(scanf("%lld %lld",&n,&m)!=EOF){
		int f=0;
		for(int i=2;i<=m;i++){
			if(n%i==0){
				f=1;
				break;
			}
		}
		if(f==0){
			printf("YES\n");
		}else{
			printf("NO\n");
		}
	}
	return 0;
}
