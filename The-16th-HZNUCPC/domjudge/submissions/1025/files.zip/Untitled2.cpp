#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
typedef long long ll;
ll m,n,k;
int main()
{
scanf("%lld%lld",&n,&m);
ll kk=0LL;
while (kk<=1000000)
{
kk++;
k=n%m;
if (k==0)
  {
  	cout<<"NO"<<endl;
  	return 0;
  }
else if (k==1)
{
  	cout<<"YES"<<endl;
  	return 0;
}
m=k;
}
cout<<"NO"<<endl;

}