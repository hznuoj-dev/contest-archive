#include<bits/stdc++.h>
#define ft first
#define sd second
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
#define rep(i,a,b) for(ll i=a;i<=b;++i)
using namespace std;
ll t,n,m,k,tt,tp,sum,ans,res,cnt;
const ll N=1e6+5;
ll a[N],b[N],c[N];
ll vis[366][366];
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    //IO
    cin>>t;
    while(t--)
    {
        cin>>n;
        vector<pll>v;
        rep(i,1,364)rep(j,1,364)vis[i][j]=0;
        rep(i,1,n)
        {
            ll x,y,z;
            cin>>x>>y>>z;
            vis[x][y]=1;
            if(z==1)v.pb({x,y});
        }
        ans=0;
        for(auto x:v)
        {
            ll dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
            rep(i,0,3)
            {
                ll xx=x.ft+dir[i][0];
                ll yy=x.sd+dir[i][1];
                if(min(xx,yy)<1||max(xx,yy)>19||vis[xx][yy])continue;
                ++ans;
            }
        }
        cout<<ans<<"\n";
    }
}
