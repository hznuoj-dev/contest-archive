#include<bits/stdc++.h>
using namespace std;

struct node{
	int x, y;
};
bool vis[25][25];
int dir[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
bool check(int x, int y){
	if(x >= 1 && y <= 19  && x <= 19 && y >= 1 && vis[x][y] == 0){
		return true;
	}
	return false;
}
int main(){
	int t;
	cin >> t;
	while(t--){
		vector<node> ve;
		int n;
		cin >> n;
		int x, y, c;
		for(int i = 1; i <= 19; i++){
			for(int j = 1; j <= 19; j++){
				vis[i][j] = 0;
			}
		}
		for(int i = 0; i < n; i++){
			cin >> x >> y >> c;
			if(c == 1){
				ve.push_back({x, y});
			}
			vis[x][y] = 1;
		}
		int sum = 0;
		for(int i = 0; i < ve.size(); i++){
			for(int j = 0; j < 4; j++){
				int dx = ve[i].x + dir[j][0];
				int dy = ve[i].y + dir[j][1];
				if(check(dx, dy)){
					sum++;
				}
			}
		}
		cout << sum << endl;
	}
	return 0;
}