#include <bits/stdc++.h>
#define ln '\n'

int main() {
	long long a, b;
	std::cin >> a >> b;
	if (a==1||b==1){
		puts("YES");
		return 0;
	}
	if (a<=b){
		puts("NO");
		return 0;
	}
	for (long long i=2; i*i<=a&&i<=b; ++i)
		if (a%i==0){
			puts("NO");
			return 0;
		}
	puts("YES");
	return 0;
}