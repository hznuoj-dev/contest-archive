#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> PII;
vector<array<int,2>>s;
int pos[30][30],ans;
int d[4][2]={
    {-1,0},
    {0,-1},
    {1,0},
    {0,1}
};
void solve(int a,int b){
    for(int i=0;i<4;i++){
        int xx=a+d[i][0],yy=b+d[i][1];
        if(xx>=1&&xx<=19&&yy>=1&&yy<=19&&pos[xx][yy]!=1)
        ans++;
    }
}
int main() {
   int n,m;
   scanf("%d",&n);
   for(int i=1;i<=n;i++){
       scanf("%d",&m);
       s.clear();
       ans=0;
       for(int j=1,x,y,a;j<=m;j++){
           scanf("%d%d%d",&x,&y,&a);
           if(a==1)
            s.push_back({x,y}),pos[x][y]=1;
            else pos[x][y]=1;
       }
       for(int j=0;j<s.size();j++){
           solve(s[j][0],s[j][1]);
       }
        printf("%d\n",ans);
       for(int j=1;j<=19;j++)
        for(int k=1;k<=19;k++)
         pos[j][k]=0;
   }
}
/*
100
3
10 10 1
10 12 1
10 11 2
*/
