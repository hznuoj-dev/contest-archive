#include<bits/stdc++.h>

using namespace std;

signed main(){
	long long a,b;
	cin >> a >> b ;
	if(a>b){
		if(a%b!=0){
			cout << "YES" << endl;
		}else cout << "NO" << endl;
	}else{
		cout << "NO" << endl;
	}
}