#include<bits/stdc++.h>
#define int long long
using namespace std;
struct edge{
	int u,v,w;
	edge(){}
	edge(int _u,int _v,int _w):u(_u),v(_v),w(_w){}
};
vector <edge> E,g[100005];
int n,m,q,visp[100005],vispt[100005];
bool ok=true;
void dfs(int u) {
	visp[u]=vispt[u];
	for (edge e:g[u]) {
		if (!visp[e.v]) {
			dfs(e.v);
		}
	}
}
void dfss(int u) {
	if (ok==false) return;
	for (edge e:g[u]) {
		int v=e.v;
		if (v==u) v=e.u;
		if (vispt[v]) {
			bool check=true;
			if (e.u==u) {
				if (visp[u]==1||vispt[u]==1) {
					check=(vispt[v]==e.w);
				}
				else{
					check=(vispt[v]==e.w%2+1);
				}
			}else {
				if (e.w==visp[u]||e.w==vispt[u]) {
					check=(vispt[v]==1);
				}
				else {
					check=(vispt[v]==2);
				}
			}
			if (!check) {
				//cout << "e.u=" << e.u << ",e.v=" << e.v << ",e.w=" << e.w << endl;
				//cout << "u=" << u << ",v=" << v << ",ans[" << u << "]=" << vispt[u] << ",ans[" << v << "]=" << vispt[v] << ",w=" << e.w << endl;
				ok=false;
				return;
			}
			continue;
		}
		if (e.u==u) {
			if (visp[u]==1||vispt[u]==1) {
				vispt[v]=e.w;
			}
			else{
				vispt[v]=e.w%2+1;
			}
		}else {
			if (e.w==visp[u]||e.w==vispt[u]) {
				vispt[v]=1;
			}
			else {
				vispt[v]=2;
			}
		}
		dfss(v);
	}
}
void dfsinit(int u){
	vispt[u]=0;
	for (edge e:g[u]) {
		if (vispt[e.v]) {
			dfsinit(e.v);
		}
	}
}
signed main(){
	cin >> n >> q >> m;
	while (m--) {
		int u,v,w;
		cin >> w >> u >> v;
		w++;
		g[u].push_back(edge(u,v,w));
		g[v].push_back(edge(u,v,w));
	}
	for (int i=1;i<=n;++i) {
		if (!visp[i]) {
			ok=true;
			vispt[i]=1;
			dfsinit(i);
			dfss(i);
			//cout << "ok1=" << ok << endl;
			if (ok) {
				dfs(i);
				continue;
			}
			//cout << "ok2" << endl;
			dfsinit(i);
			ok=true;
			vispt[i]=2;
			dfss(i);
			if (ok) {
				dfs(i);
				continue;
			}
			cout << "NO";
			exit(0);
		}
	}
	cout << "YES" << endl;
	for (int i=1;i<=n;++i) {
		if (visp[i]==1) cout << i << " ";
	}
}
/*




4 2 4
1 1 3
1 2 4
 0 3 4 
 0 1 2
 
 
 
 
 
 
 
 13 7 11
 0 1 2
 0 1 3
 0 1 4
 0 1 5 
 1 1 6
 1 1 7
 0 8 9
 0 8 10
 0 8 11
 1 13 12
  1 12 13
  
  
  2 1 2
  1 1 2
  0 2 1
  
  
 
 
 
 
 */