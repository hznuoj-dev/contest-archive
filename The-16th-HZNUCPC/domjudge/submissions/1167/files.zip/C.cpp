#include <bits/stdc++.h>
#define ll long long
#define Ma 1000005
#define mod 100000007
#define N 26
#define PLL pair<ll,ll>

using namespace std;

map <PLL,ll> mp;
ll f[N],g[N];
ll okf[N],okg[N];
ll op[4];

bool cmp()
{
	for (ll i=0;i<N;i++)
		if (!((!okf[i]&&!f[i])||(okf[i]&&f[i])))
			return 0;
	for (ll i=0;i<N;i++)
		if (!((!okg[i]&&!g[i])||(okg[i]&&g[i])))
			return 0;
	return 1;
}

bool cmp2()
{
	for (ll i=0;i<N;i++)
		if (!((!okf[i]&&!g[i])||(okf[i]&&g[i])))
			return 0;
	for (ll i=0;i<N;i++)
		if (!((!okg[i]&&!f[i])||(okg[i]&&f[i])))
			return 0;
	return 1;
}


void sol()
{
	string s,t;
	cin>>s>>t;
	for (ll i=0;i<s.size();i++)
		mp[{s[i]-'a',t[i]-'a'}]++,f[s[i]-'a']++,g[t[i]-'a']++;
	for (ll i=0;i<N;i++)
		okf[i]=f[i],okg[i]=g[i];
	ll ans=0;
	for (ll i=0;i<N*N;i++)
	{
		op[0]=i/N,op[1]=i%N;
		for (ll j=0;j<N*N;j++)
		{
			op[2]=j/N,op[3]=j%N;
			for (ll k=0;k<4;k++)
				if (k&1)
					f[op[k]]++,g[op[k]]--;
				else
					f[op[k]]--,g[op[k]]++;
			if (cmp()||cmp2())
			{
				if (i==j)
					ans+=mp[{op[0],op[1]}]*(mp[{op[0],op[1]}]-1);
				else
					ans+=mp[{op[0],op[1]}]*mp[{op[2],op[3]}];
				//printf("OK i=%lld j=%lld\n",i,j);
			}
			for (ll k=0;k<4;k++)
				if (k&1)
					f[op[k]]--,g[op[k]]++;
				else
					f[op[k]]++,g[op[k]]--;
		}
	}
	printf("%lld\n",ans);
	return;
}

int main ()
{
	sol();
	return 0;
}