#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
const int maxn=2e5+10;
const ll mod=1e9+7;
int s1[40],s2[40];
int mp[40][40];
int sum1,sum2;
set<int>s;
ll pow_mod(ll a,ll b){
	ll ans=1;
	while(b){
		if(b&1) ans=(ans*a)%mod;
		a=(a*a)%mod;
		b>>=1;
	}
	return ans;
}
ll inv(ll a){
	return pow_mod(a,mod-2);
}
signed main(){
	string a,b;
	cin>>a>>b;
	for(int i=0;i<a.length();i++){
		if(!s1[a[i]-'a'])sum1++;
		if(!s2[b[i]-'a'])sum2++;
		s1[a[i]-'a']++;
		s2[b[i]-'a']++;
		mp[a[i]-'a'][b[i]-'a']++;
		s.insert(a[i]-'a');
		s.insert(b[i]-'a');
	}
	ll sum=0;
	for(int i=0;i<a.length();i++){
		if(s1[a[i]-'a']==1)sum1--;
		if(s2[b[i]-'a']==1)sum2--;
		if(s2[a[i]-'a']==0)sum2++;
		if(s1[b[i]-'a']==0)sum1++;
		s1[a[i]-'a']--;
		s2[b[i]-'a']--;
		s1[b[i]-'a']++;
		s2[a[i]-'a']++;
		mp[a[i]-'a'][b[i]-'a']--;
		for(auto it:s){
			for(auto itt:s){
				if(!mp[it][itt]) continue;
				int cut=0;
				if(s1[it]==1)cut--;
				if(s1[itt]==0)cut++;
				if(s2[it]==0)cut--;
				if(s2[itt]==1)cut++;
				if(cut+sum1-sum2==0)sum=(sum+mp[it][itt])%mod;
			}
		}
		if(s1[a[i]-'a']==0)sum1++;
		if(s2[b[i]-'a']==0)sum2++;
		if(s2[a[i]-'a']==1)sum2--;
		if(s1[b[i]-'a']==1)sum1--;
		s1[a[i]-'a']++;
		s2[b[i]-'a']++;
		s1[b[i]-'a']--;
		s2[a[i]-'a']--;
	}
	cout<<sum;
}