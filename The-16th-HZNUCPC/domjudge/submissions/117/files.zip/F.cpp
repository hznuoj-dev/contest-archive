#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long n,m;
	scanf("%lld%lld",&n,&m);
	int flag = 0;
	for(int i = 2 ;i <=m || m==1;i++) {
		if(n%i){
			cout<<"YES"<<endl;
			flag = 1;
			break;
		}
	}
	if(!flag) {
		cout<<"NO"<<endl;
	}
	return 0;
}