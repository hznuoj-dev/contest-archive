#include<iostream>
#include<math.h>
using namespace std;
long long a,b; 
int main()
{
	long long n,m,minn;
	cin>>n>>m;
	for(int i=2;i<=sqrt(n);i++){
		if(n%i==0){
			minn=i;break;
		}
	}
	if(minn>=m || n==1)cout<<"YES";
	else cout<<"NO";
	return 0;
}