#include <bits/stdc++.h>
const int maxn=25;
int T,n,m,ans,a[maxn][maxn];
inline void solve() {
	scanf("%d",&n);
	memset(a,0,sizeof(a));
	for (int i=1;i<=n;++i){
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);a[x][y]=z;
	}
	ans=0;
	for (int x=1;x<=19;++x)
	for (int y=1;y<=19;++y)if (a[x][y]==1){
		if (x>1&&!a[x-1][y]) ++ans;
		if (y>1&&!a[x][y-1]) ++ans;
		if (x<19&&!a[x+1][y]) ++ans;
		if (y<19&&!a[x][y+1]) ++ans;
	}
	printf("%d\n",ans);
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);

	for (scanf("%d",&T);T--;) solve();
	return 0;
}