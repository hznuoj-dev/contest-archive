#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll gcd(ll x, ll y)
{
	if(y == 0) return x;
	else return gcd(y, x % y);
}
const int N = 105;
struct point{
	ll x, y;
}a[N];
ll calc(int i, int j)
{
	ll x = abs(a[i].x - a[j].x);
	ll y = abs(a[i].y - a[j].y);
	ll g = gcd(x, y);
	return g;
}
bool check(int i, int j, int k)
{
	ll ax = a[i].x - a[j].x;
	ll bx = a[j].x - a[k].x;
	ll ay = a[i].y - a[j].y;
	ll by = a[j].y - a[k].y;
	if(ax * by == bx * ay)return true;
	return false;
}
ll n;
int main()
{
	cin >> n;
	for(int i = 1; i <= n; i++){
		cin >> a[i].x >> a[i].y;
	}
	ll ans = 0;
	for(int i = 1; i <= n; i++)
		for(int j = i+1; j <= n; j++)
			for(int k = j+1; k <= n; k++){
				if(check(i, j, k))continue;
				ll tmp = calc(i,j) + calc(j,k) + calc(k,i);
				if(tmp > ans) ans = tmp;
			}
	cout << ans << endl;
}