#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,ans;
int x[101],y[101],d[101][101];
int zz(int a,int b){
	if(a<b)swap(a,b);
	while(b>0){
		int res=a%b;
		a=b,b=res;
	}
	return a;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if(i==j)continue;
			d[i][j]=zz(abs(x[i]-x[j]),abs(y[i]-y[j]));
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				double XY=sqrt((x[i]-x[j])*(x[i]-x[j])*1.0+(y[i]-y[j])*(y[i]-y[j])*1.0);
				double YZ=sqrt((x[k]-x[j])*(x[k]-x[j])*1.0+(y[k]-y[j])*(y[k]-y[j])*1.0);
				double XZ=sqrt((x[i]-x[k])*(x[i]-x[k])*1.0+(y[i]-y[k])*(y[i]-y[k])*1.0);
				if(XY+YZ-XZ<0.000001)continue;
				if(XY-YZ+XZ<0.000001)continue;
				if(YZ+XZ-XY<0.000001)continue;
				if(ans<d[i][j]+d[i][k]+d[j][k]){
					ans=d[i][j]+d[i][k]+d[j][k];
				}
			}
		}
	}
	cout<<ans;
	return 0;
}