#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m;
	cin>>n>>m;
	if(n==1){
		cout<<"YES";
		return 0;
	}
	if(n>m){
		long long t=sqrt(n);
		for(long long i=2;i<=min(t,m);i++){
			if(n%i==0){
				cout<<"NO";
				return 0;
			}
		}
		cout<<"YES";
		return 0;
	}
	else{
		cout<<"NO";
		return 0;  
	}
}
	
		
 