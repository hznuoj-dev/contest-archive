#include<bits/stdc++.h>

#define scanfint(a) scanf("%d",&a)
#define scanfstr(a) scanf("%s",a)
#define scanfll(a) scanf("%lld",&a)
#define scnafll(a) scanf("%lld",&a)
#define printfll(a) printf("%lld\n",a);
#define Get_rand(a) (rand()%(a+1))
#define swapnum(a,b) {a=a+b;b=a-b;a=a-b;}
#define FOR(i,l,r) for(int i=l;i<=r;i++)
#define FORLL(i,l,r) for(ll i=l;i<=r;i++)
#define Presentation(i,r) printf("%c"," \n"[i==r])
#define NO printf("NO\n")
#define YES printf("YES\n")
#define Max(a,b) (a>b?a:b)

typedef long long ll;

const double pi=3.141592653589793;
const ll MOD=1e9+7;
const int INF=0x7fffffff;
const double eps=1e-8;

using namespace std;
/*----------Cpp Head----------*/
char s[5005]={0};
ll len;

int edge(ll l,ll r)
{
return l==0||r==len-1;
}

ll M1(ll i)
{
    ll l,r,palin;
    ll templ,tempr;
    int flag=0;
    l=r=i;
    while(l>0&&r<len-1)
    {
        l--;r++;
        if(s[l]!=s[r])
        {
            if(flag==0)
            {
                templ=l;tempr=r;flag=1;
                if(edge(l,r)) {palin=r-l-1;break;}
            }
            else if(flag==1)
            {
                if(s[l]==s[templ]&&s[r]==s[tempr]||s[l]==s[tempr]&&s[r]==s[templ])
                {
                    templ=l;tempr=r;flag=2;
                    if(edge(l,r)) {palin=r-l+1;break;}
                }
                else {palin=tempr-templ-1;break;}
            }
            else if(flag==2) {palin=r-l-1;break;}
        }
        else if(edge(l,r))
        {
            if(flag==1) return tempr-templ-1;
            return r-l+1;
        }
    }
    return palin;
}

ll M0(ll l)
{
    ll r,palin;
    ll templ,tempr;
    int flag=0;
    r=l+1;
    while(l>=0&&r<=len-1)
    {
        if(s[l]!=s[r])
        {
            if(flag==0)
            {
                templ=l;tempr=r;flag=1;
                if(edge(l,r)) {palin=r-l-1;break;}
            }
            else if(flag==1)
            {
                if(s[l]==s[templ]&&s[r]==s[tempr]||s[l]==s[tempr]&&s[r]==s[templ])
                {
                    templ=l;tempr=r;flag=2;
                    if(edge(l,r)) {palin=r-l+1;break;}
                }
                else {palin=tempr-templ-1;break;}
            }
            else if(flag==2) {palin=r-l-1;break;}
        }
        else if(edge(l,r))
        {
            if(flag==1) return tempr-templ-1;
            return r-l+1;
        }
        l--;r++;
    }
    return palin;
}

int main()
{
    ll T;
    scnafll(T);
    ll m=0;
    while(T--)
    {
        m=0;
        scanfstr(s);
        len=strlen(s);
        FORLL(i,1,len-2) m=Max(m,M1(i));
        FORLL(i,0,len-2) m=Max(m,M0(i));
        if(m==1) m=0;
        //ll x;
        //scanfll(x);
        //m=M0(x);
        printfll(m);
    }
    return 0;
}