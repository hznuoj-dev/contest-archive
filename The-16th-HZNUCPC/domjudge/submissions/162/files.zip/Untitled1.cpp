#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		long long sum=0;
		int fan[30][30]= {0};
		int vis[30][30]= {0};
		int n,x,y,type;
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			cin>>x>>y>>type;
			if(type==1)
			{
				fan[x][y]=1;
			}
			else
			{
				fan[x][y]=2;
			}
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(fan[i][j]==1)
				{
					if(fan[i-1][j]==2&&fan[i][j-1]==2&&fan[i+1][j]==2&&fan[i][j+1]==2)fan[i][j]=0;
				}
			}
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(fan[i][j]==1)
				{
					if(fan[i-1][j]==0&&vis[i-1][j]==0)
					{
						sum++;
						vis[i-1][j]=1;
					}
					if(fan[i][j-1]==0&&vis[i][j-1]==0)
					{
						sum++;
						vis[i][j-1]=1;
					}
					if(fan[i+1][j]==0&&vis[i+1][j]==0)
					{
						sum++;
						vis[i+1][j]=1;
					}
					if(fan[i][j+1]==0&&vis[i][j+1]==0)
					{
						sum++;
						vis[i][j+1]=1;
					}
				}
			}
		}
		cout<<sum<<'\n';
	}
}