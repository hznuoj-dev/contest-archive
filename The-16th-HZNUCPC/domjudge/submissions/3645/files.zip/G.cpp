#include<bits/stdc++.h>
using namespace std;
int n,dy,m,x,y,z,ss[100001],ans[100001][2],ssum,mi[100001],mx[100001];
vector<int> bi[100001],ci[100001],ans2[100001][2],f[100001];
bool t[100001];
void dfs(int s,int qs,int lj)
{
//	cout<<s<<' '<<qs<<' '<<lj<<endl;
	for(int i=0;i<bi[s].size();i++)
	  if(bi[s][i]!=qs)
	  {
		if(ss[bi[s][i]]==-1)
		{
			ans[ssum][(lj+ci[s][i])%2]++;
			ans2[ssum][(lj+ci[s][i])%2].push_back(bi[s][i]);
			ss[bi[s][i]]=(lj+ci[s][i])%2;
			dfs(bi[s][i],s,(lj+ci[s][i])%2);
		}else
		{
			if((lj+ci[s][i])%2!=ss[bi[s][i]])
			{
				printf("NO");
				exit(0);
			}
		}  
	  }
}
void dfs2(int cs,int lj)
{
	if(cs==ssum+1)
	{
		if(lj==dy)
		{
			printf("YES\n");
			for(int i=1;i<=ssum;i++)
			  if(t[i])
			  {
			  	for(int j=0;j<ans2[i][0].size();j++)
			      printf("%d ",ans2[i][0][j]);
			  }else
              {
              	for(int j=0;j<ans2[i][1].size();j++)
              	  printf("%d ",ans2[i][1][j]);
			  }	
			exit(0);		    
		}
		return;
	}
	if(lj+mi[cs]>dy)
	  return;
	if(lj+mx[cs]<dy)
	  return;
	t[cs]=true;
	dfs2(cs+1,lj+ans[cs][0]);
	t[cs]=false;
	dfs2(cs+1,lj+ans[cs][1]);
}
int main()
{
	scanf("%d%d%d",&n,&dy,&m);
	for(int i=1;i<=m;i++)
	{
		scanf("%d%d%d",&z,&x,&y);
		bi[x].push_back(y);
	    ci[x].push_back(z);
	    bi[y].push_back(x);
	    ci[y].push_back(z);
	}
	for(int i=1;i<=n;i++)
	  ss[i]=-1;
	for(int i=1;i<=n;i++)
	{
		if(ss[i]==-1)
		{
			ans[++ssum][0]++;
			ans2[ssum][0].push_back(i);
			ss[1]=0;
			dfs(i,0,0);
			/*for(int j=0;j<ans2[ssum][0].size();j++)
			  cout<<ans2[ssum][0][j]<<' ';
			cout<<endl;
			for(int j=0;j<ans2[ssum][1].size();j++)
			  cout<<ans2[ssum][1][j]<<' ';
			cout<<endl<<endl;*/
		}
	}
	for(int i=ssum;i>=1;i--)
	{
		mi[i]=mi[i+1]+min(ans[i][0],ans[i][1]);
		mx[i]=mx[i+1]+max(ans[i][0],ans[i][1]);
	}
	dfs2(1,0);
	printf("NO");
	return 0;
}