#include <bits/stdc++.h>
using namespace std;
int t;
int a[30][30],sum;
int main()
{
	scanf("%d",&t);
	while(t--)
	{
		sum=0;
		memset(a,0,sizeof(a));
		int n;
		scanf("%d",&n);
		while(n--)
		{
			int x,y,z;
			scanf("%d %d %d",&x,&y,&z);
			if(z==1)
			{
				a[x][y]=1;
			}
			else
			{
				a[x][y]=2;
			}
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(a[i][j]==1||a[i][j]==2) ;
				else
				{
					if(a[i+1][j]==1) sum++;
					if(a[i-1][j]==1) sum++;
					if(a[i][j+1]==1) sum++;
					if(a[i][j-1]==1) sum++;
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}