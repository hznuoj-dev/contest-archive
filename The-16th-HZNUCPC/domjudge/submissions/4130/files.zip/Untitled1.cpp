#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10, mod = 1e9 + 7;
#define int long long 
#define endl '\n'
int a[N], b[N];

signed main(){
	
	string s, t;
	int cnt1 = 0, cnt2 = 0, ans = 0;
	cin >> s >> t;
	for (int i = 0; i < s.size(); i ++){
		a[s[i] - 'a'] ++;
		b[t[i] - 'a'] ++;
		if (a[s[i] - 'a'] == 1)cnt1 ++;
		if (b[t[i] - 'a'] == 1)cnt2 ++;
	}
	if (cnt1 < cnt2){
		swap (cnt1, cnt2);
		for (int i = 0; i < 26; i ++){
			swap (a[i], b[i]);
		}
	}
	int l = s.size(), temp1 = 0, temp2 = 0, temp3 = 0;
	if (cnt1 == cnt2){
		ans = l * (l - 1) / 2;
		ans %= mod;
		cout << ans << endl;
	}
	else{
		for (int i = 0; i < s.size(); i ++){
			if (s[i] == t[i])temp3 ++;
			else{
				if (a[s[i] - 'a'] >= 2 && b[s[i] - 'a'] == 0 && a[t[i] - 'a'] >= 1){
					temp1 ++;
					a[s[i] - 'a']--;
					b[s[i] - 'a'] --;
					a[t[i] - 'a']--;
				}
				if (a[s[i] - 'a'] == 1 && b[s[i] - 'a'] >= 1 && a[t[i] - 'a'] >= 1){
					temp1 ++;
					a[s[i] - 'a']--;
					b[s[i] - 'a']--;
					a[t[i] - 'a']--;
				}
				
				if (a[s[i] - 'a'] == 1 && b[s[i] - 'a'] == 0){
					temp2 ++;
					a[s[i] - 'a']--;
					b[t[i] - 'a']--;
				}
			}
		}
		//cout << cnt1 << " " << cnt2 << endl;
		if (cnt1 == cnt2 + 1){
			ans = temp3 * temp1;
			ans %= mod;
		}
		else if (cnt1 == cnt2 + 2){
			ans = temp3 * temp2 + (temp1 - 1) * temp1 * temp3 / 2;
		}
		else if (cnt1 == cnt2 + 3){
			ans = temp2 * temp1;
			ans %= mod;
		}
		else if (cnt1 == cnt2 + 4){
			ans = (temp2 - 1) * temp2 / 2;
			ans %= mod;
		}
		else ans = 0;
		cout << ans << endl;
		//cout << temp1 << temp2 << temp3 << endl;
		for (int i = 0; i < 26; i ++){
			a[i] = b[i] = 0;
		}
	}	
	
	
	return 0;
}