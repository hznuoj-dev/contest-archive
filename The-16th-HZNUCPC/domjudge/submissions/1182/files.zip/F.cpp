#include<bits/stdc++.h>
using namespace std;
int main(){
    //n:votes m:restContestant
    long long  n,m;
    scanf("%lld%lld",&n,&m);
    if(__gcd(n,m)!=1){
        printf("NO\n");
    }else{
        printf("YES\n");
    }
    return 0;
}