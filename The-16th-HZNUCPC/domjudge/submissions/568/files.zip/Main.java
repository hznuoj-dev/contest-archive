package oj;

import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		int caipan = in.nextInt();
		int num = in.nextInt();
		while(num > 1){
			if(caipan % num == 0){
				System.out.println("NO");
				break;
			} else{
				num --;
			}
		}
		if(num == 1){
			System.out.println("YES");
		}
	}

}
