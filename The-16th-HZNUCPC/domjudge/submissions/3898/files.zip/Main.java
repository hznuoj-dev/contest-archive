package oj;

import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		long n = sc.nextLong();
		long m = sc.nextLong();
		if(n%2==0){
			System.out.println("YES");
		}else{
			System.out.println("NO");
		}
//		long k = m;
//		if(n==1||m==1){
//			System.out.println("YES");
//			return;
//		}
//		while(true){
//			k = n % k;
//			System.out.println(k);
//			if(k==0){
//				System.out.println("NO");
//				break;
//			}
//			if(k==1){
//				System.out.println("YES");
//				break;
//			}
//		}
	}
}
