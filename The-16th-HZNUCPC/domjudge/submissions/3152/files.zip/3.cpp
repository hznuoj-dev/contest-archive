#include<bits/stdc++.h>
using namespace std;
#define int long long
#define aa first
#define bb second
const int N = 5002;
char s[N];
void solve(){
    cin >> (s + 1);
    int n = strlen(s + 1);
    int maxn = 0;
    for (int i = 1; i <= n; i ++ ) {
    	char p1 = '-', p2 = '-';
    	for (int j = 1; j <= n; j ++) {
    		if (i - j < 1 || i + j > n) break;
    		if (s[i - j] == s[i + j]) {
    			if (p1 == '-' || p1 == '#') {
    				maxn = max(maxn, j * 2 + 1);
    			}
    		} else {
    			if (p1 == '-') {
    				p1 = s[i - j];
    				p2 = s[i + j];
    			} else if (s[i - j] == p2 && s[i + j] == p1 || s[i - j] == p1 && s[i + j] == p2) {
    				maxn = max(maxn, j * 2 + 1);
    				p1 = '#';
    			} else {
    				break;
    			}
    		}
    	}
        p1 = '-', p2 = '-';
    	for (int j = 1; j <= n; j ++ ) {
    		if (i - j + 1 < 1 || i + j > n) break;
    		if (s[i - j + 1] == s[i + j]) {
    			if (p1 == '-' || p1 == '#') {
    				maxn = max(maxn, j * 2);
    			}
    		} else {
    			if (p1 == '-') {
    				p1 = s[i - j + 1];
    				p2 = s[i + j];
    			} else if (s[i - j + 1] == p2 && s[i + j] == p1 || s[i - j + 1] == p1 && s[i + j] == p2) {
    				maxn = max(maxn, j * 2);
    				p1 = '#';
    			} else {
    				break;
    			}
    		}
    	}
    	p1 = s[i];
    	for (int j = 1; j <= n; j ++) {
    		if (i - j < 1 || i + j > n) break;
    		if (s[i - j] == s[i + j]) {
                maxn = max(maxn, j * 2 + 1);
    		} else {
                if (p1 == s[i - j] || p1 == s[i + j]) {
                    p1 = '#';
                    maxn = max(maxn, j * 2 + 1);
                } else {
                    break;
                }
    		}
    	}
    }
    cout << maxn << '\n';
}
signed main(){
    int T=1;
    cin>>T;
    while(T--){
        solve();
    }
    return 0;
}



