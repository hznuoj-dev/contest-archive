#include <iostream>
#include <queue>
#include <vector>
#define maxn 20 
using namespace std;

int n = 19, m; 

int a[maxn][maxn];
bool vis[maxn][maxn];
bool use[maxn][maxn];

int dx[] = { 0, 0, 1, -1 };
int dy[] = { 1, -1, 0, 0 };

int bfs(int sx, int sy) { 
	queue<pair<int, int>> Q; Q.emplace(sx, sy);
	vector<pair<int, int>> vec;
	vis[sx][sy] = true;
	for (int i = 1; i <= n; ++i) 
		for (int j = 1; j <= n; ++j) use[i][j] = false;
	while (!Q.empty()) { 
		pair<int, int> t = Q.front(); Q.pop();
		int i = t.first, j = t.second;
		vec.emplace_back(i, j); 
		for (int k = 0; k < 4; ++k) { 
			int x = i + dx[k], y = j + dy[k];
			if (x < 1 || x > n || y < 1 || y > n) continue;
			if (vis[x][y] || a[x][y] != 1) continue;
			vis[x][y] = true; 
			Q.emplace(x, y);
		}
	} int sum = 0; 
	for (auto t : vec) 
		for (int k = 0; k < 4; ++k) {  
			int x = t.first + dx[k], y = t.second + dy[k];
			if (x < 1 || x > n || y < 1 || y > n) continue;
			if (a[x][y] != -1 || use[x][y]) continue;
			use[x][y] = true, ++sum;
		}
	return sum;
}

void work() { 
	cin >> m;
	for (int i = 1; i <= n; ++i) 
		for (int j = 1; j <= n; ++j) a[i][j] = -1, vis[i][j] = false;
	for (int i = 1; i <= m; ++i) { 
		int x, y, z; cin >> x >> y >> z; 
		a[x][y] = z; 
	} int ans = 0; 
	for (int i = 1; i <= n; ++i) 
		for (int j = 1; j <= n; ++j) {
			if (a[i][j] != 1) continue;
			for (int k = 0; k < 4; ++k) {
				int x = i + dx[k], y = j + dy[k];
				if (x < 1 || x > n || y < 1 || y > n) continue;
				if (a[x][y] == -1) ++ans;
			}
		}
	cout << ans << "\n";
}

int main() { 
	ios::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr); 
	
	int T; cin >> T;
	while (T--) work();
	return 0; 
} 