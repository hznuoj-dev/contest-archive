#include <bits/stdc++.h>

using namespace std;

using i64 = long long;

template <typename T> void read(T& x) {
	x = 0; 
	char ch = 0;
	int f = 1;
	for (; !isdigit(ch); ch = getchar()) {
		if (ch == '-') f = -1;
	}
	for (; isdigit(ch); ch = getchar()) {
		x = x * 10 + (ch & 15);
	}
	x *= f;
}
	
template <typename T>
void write(T x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

void solve();

int main() {
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
}

const int N = 2e5 + 5;

i64 n, m;

bool check(i64 x) {
	i64 t = n % x;
	i64 a = n / x, b = ceil(double(t) / double(m - x));
	return a > b;
}

void solve() {
	cin >> n >> m;
	if (n == 1 || m == 1) {
		cout << "YES\n";
		return;
	}
	if (n < m) {
		cout << "NO\n";
		return;
	}
	if (n % m == 0) {
		cout << "NO\n";
		return;
	}
	
	i64 l = 1, r = m - 1, ret = -1;
	while (l <= r) {
		i64 mid = (l + r) / 2;
		
		if (check(mid)) {
			l = mid + 1;
			ret = mid;
		} else {
			r = mid - 1;
		}
	}
	for (i64 i = 2; i * i <= n; i++) {
		if (n % i == 0) {
			if (i <= ret) {
				cout << "NO\n";
				return;
			}
		}
	}
	cout << "YES\n";
}