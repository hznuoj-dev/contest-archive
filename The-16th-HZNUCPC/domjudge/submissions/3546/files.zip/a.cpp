#include<bits/stdc++.h>
using namespace std;
const int N = 1e5+5;
int k[5005][30];
string s;
bool duil;
int main(){
	int T;
	cin >> T;
	while(T--){
		duil=false;
		memset(k,0,sizeof(k));
		cin >> s;
		int a,b;
		b=s.size();
		s=' '+s;
		for(int i=1;i<=b;i++){
			for(int j=1;j<=26;j++){
				char ccc=j-1+'a';
			
				if(ccc==s[i])k[i][j]=k[i-1][j]+1;
				else k[i][j]=k[i-1][j];
//				cout << k[i][j] << ' ';
			}
//			cout <<endl;
		}
		for(int i=b;i>=2;i--){
			if(duil)break;
			for(int j=1;j<=b-i+1;j++){
				a=j+i-1;
				int alng=2;
				for(int v=1;v<=26;v++){
					if((k[a][v]-k[j-1][v])%2==1) alng--;
				}
				if(alng<=0){
					
					continue;
				}
				alng=2;
				int A=a;
				for(int v=j;v<A/2;v++){
					if(s[a]!=s[v])alng--;
					a--;
				}
				if(alng<0){
//					cout << i << endl;
					continue;
				}else{
					cout << i << endl;
//					cout << j << ' ' <<A <<endl;
					duil=true;
					break;
				}
				
			}
		}
		if(!duil)cout << 0 << endl;
	}
	return 0;
}         


