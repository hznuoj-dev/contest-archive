#include<bits/stdc++.h>
using namespace std;
long long n,m;
int main()
{
	cin>>n>>m;
	if(n<=m)
	  cout<<"NO";else
	  while(1)
	  {
	  	if(n%m==1)
	  	{
	  		cout<<"YES";
	  	    break;
		}
		if(n%m==0)
		{
			cout<<"NO";
			break;
		}
		m=n%m;
	  }
	return 0;
}