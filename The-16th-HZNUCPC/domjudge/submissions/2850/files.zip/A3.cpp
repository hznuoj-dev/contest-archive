#include<bits/stdc++.h>
using namespace std;

struct stone{
	bool black,white;
};
stone s[20][20];

int main(){
	int n,m,x,y,z,sum;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&m);
		sum=0;
		for(int j=1;j<=m;j++){
			scanf("%d%d%d",&x,&y,&z);
			if(z==1){
				if(x==1&&y==1){
					sum=sum+2;
					if(s[x+1][y].black)sum=sum-2;
					if(s[x][y+1].black)sum=sum-2;
					if(s[x+1][y].white)sum=sum-1;
					if(s[x][y+1].white)sum=sum-1;
					s[x][y].black=true;
				} 
				else if(x==1&&y==19){
					sum=sum+2;
					if(s[x+1][y].black)sum=sum-2;
					if(s[x][y-1].black)sum=sum-2;
					if(s[x+1][y].white)sum=sum-1;
					if(s[x][y-1].white)sum=sum-1;
					s[x][y].black=true;
				}
				else if(x==19&&y==1){
					sum=sum+2;
					if(s[x-1][y].black)sum=sum-2;
					if(s[x][y+1].black)sum=sum-2;
					if(s[x-1][y].white)sum=sum-1;
					if(s[x][y+1].white)sum=sum-1;
					s[x][y].black=true;
				}
				else if(x==19&&y==19){
					sum=sum+2;
					if(s[x-1][y].black)sum=sum-2;
					if(s[x][y-1].black)sum=sum-2;
					if(s[x-1][y].white)sum=sum-1;
					if(s[x][y-1].white)sum=sum-1;
					s[x][y].black=true;
				}
				else if(x==1){
					sum=sum+3;
					if(s[x][y-1].black)sum=sum-2;
					if(s[x][y+1].black)sum=sum-2;
					if(s[x+1][y].black)sum=sum-2;
					if(s[x+1][y].white)sum=sum-1;
					if(s[x][y+1].white)sum=sum-1;
					if(s[x][y-1].white)sum=sum-1;
					s[x][y].black=true;
				}
				else if(x==19){
					sum=sum+3;
					if(s[x][y-1].black)sum=sum-2;
					if(s[x][y+1].black)sum=sum-2;
					if(s[x-1][y].black)sum=sum-2;
					if(s[x-1][y].white)sum=sum-1;
					if(s[x][y+1].white)sum=sum-1;
					if(s[x][y-1].white)sum=sum-1;
					s[x][y].black=true;
				}
				else if(y==1){
					sum=sum+3;
					if(s[x-1][y].black)sum=sum-2;
					if(s[x][y+1].black)sum=sum-2;
					if(s[x+1][y].black)sum=sum-2;
					if(s[x+1][y].white)sum=sum-1;
					if(s[x][y+1].white)sum=sum-1;
					if(s[x-1][y].white)sum=sum-1;
					s[x][y].black=true;
				}
				else if(y==19){
					sum=sum+3;
					if(s[x-1][y].black)sum=sum-2;
					if(s[x][y-1].black)sum=sum-2;
					if(s[x+1][y].black)sum=sum-2;
					if(s[x+1][y].white)sum=sum-1;
					if(s[x][y-1].white)sum=sum-1;
					if(s[x-1][y].white)sum=sum-1;
					s[x][y].black=true;
				}
				else {
					sum=sum+4;
					if(s[x-1][y].black)sum=sum-2;
					if(s[x][y+1].black)sum=sum-2;
					if(s[x+1][y].black)sum=sum-2;
					if(s[x][y-1].black)sum=sum-2;
					if(s[x+1][y].white)sum=sum-1;
					if(s[x][y+1].white)sum=sum-1;
					if(s[x-1][y].white)sum=sum-1;
					if(s[x][y-1].white)sum=sum-1;
					s[x][y].black=true;
				}
			}
			else{
				s[x][y].white=true;
				if(s[x-1][y].black)sum=sum-1;
				if(s[x+1][y].black)sum=sum-1;
				if(s[x][y-1].black)sum=sum-1;
				if(s[x][y+1].black)sum=sum-1;
			}
		} 
		printf("%d\n",sum);
		for(x=1;x<=19;x++){
			for(y=1;y<=19;y++){
				s[x][y].black=false;
				s[x][y].white=false;
			}
		}
	}
	
	return 0;
}
