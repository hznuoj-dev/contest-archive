#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	int n,m;
	cin>>n>>m;
	while(m!=1&&n%m!=0){
		m=n%m;
	}
	if(m==1)cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
}