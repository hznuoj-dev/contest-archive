import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		while (in.hasNext()) {
			long n = in.nextLong();
			long m = in.nextLong();
			System.out.print(n+"  "+m+"    " );
			if (n == m && n == 1) {
				System.out.println("YES");
			} else if (m >= n) {
				System.out.println("NO");
			} else if (m == 1) {
				System.out.println("YES");
			} else if (n - m == 1) {
				System.out.println("YES");
			} else if (n % 2 == 1) {
				System.out.println("YES");
			}else{
				System.out.println("NO");
			}
			
		}
	}
}
