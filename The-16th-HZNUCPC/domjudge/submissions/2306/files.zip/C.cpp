#include <bits/stdc++.h>

using namespace std;

using ll = long long;
const int mod = 1e9 + 7;
int cnt[2][30];
ll op_num[30][30];

ll kpow(ll a, ll k) {
	ll res = 1;
	while (k) {
		if (k & 1) res = res * a % mod;
		a = a * a % mod;
		k >>= 1;
	}
	return res;
}
void solve() {
	string s, t;
	cin >> s >> t;
	int n = s.size();
	for (int i = 0; i < n; i++) {
		cnt[0][s[i] - 'a']++;
		cnt[1][t[i] - 'a']++;
		op_num[s[i] - 'a'][t[i] - 'a']++;
	}
	int size_s = 0, size_t = 0;
	for (int i = 0; i < 26; i++) {
		if (cnt[0][i]) size_s++;
		if (cnt[1][i]) size_t++;
	}
	auto update = [&](int c1, int c2) {
		if (c1 == c2) return;
		cnt[0][c1]--;
		cnt[1][c1]++;
		if (cnt[0][c1] == 0) size_s--;
		if (cnt[1][c1] == 1) size_t++;
		cnt[0][c2]++;
		cnt[1][c2]--;
		if (cnt[0][c2] == 1) size_s++;
		if (cnt[1][c2] == 0) size_t--;
	};
	ll ans = 0, inv2 = kpow(2, mod - 2);
	for (int c1 = 0; c1 < 26; c1++) {
		for (int c2 = 0; c2 < 26; c2++) {
			for (int c3 = 0; c3 < 26; c3++) {
				for (int c4 = 0; c4 < 26; c4++) {
					update(c1, c2);
					update(c3, c4);
					if (size_s == size_t) {
						if (c1 == c3 && c2 == c4) {
							ans += op_num[c1][c2] * (op_num[c1][c2] - 1) / 2 % mod;
							ans %= mod;
						}else {
							ans += op_num[c1][c2] * op_num[c3][c4] % mod * inv2 % mod;
							ans %= mod;
						}
					}
					update(c2, c1);
					update(c4, c3);
				}	
			}
		}
	}
	printf("%lld\n", ans);
}
int main() {
	solve();
	return 0;
}