#include<bits/stdc++.h>
using namespace std;
#define ll long long

vector<ll> x,y;
ll find(ll a,ll b){
	ll n,m;
	n=abs(x[a]-x[b]);
	m=abs(y[a]-y[b]);
	ll a1,b1,r1;
	a1=n;
	b1=m;
	while(b1){
		r1=a1%b1;
		a1=b1;
		b1=r1;
	}
	return a1;
}
int main(){
	ll n,X,Y;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>X>>Y;
		x.push_back(X);
		y.push_back(Y);
	}
	ll ans=0,m;
	for(ll i=0;i<n;i++){
		for(ll j=i+1;j<n;j++){
			for(ll k=j+1;k<n;k++){
				if(abs(x[i]-x[j])*abs(y[i]-y[k])==abs(x[i]-x[k])*abs(y[i]-y[j])){
					m=0;
				}
				else m=find(i,j)+find(i,k)+find(j,k);
				ans=max(m,ans);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}