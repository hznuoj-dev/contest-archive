#include<bits/stdc++.h>
#define ft first
#define sd second
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
#define rep(i,a,b) for(ll i=a;i<=b;++i)
using namespace std;
ll t,n,m,k,tt,tp,sum,ans,res;
const ll N=1e6+5;
ll c1[27],c2[27],cnt[27][27];
const ll Z=1e9+7;
ll qpow(ll x,ll y)
{
    ll res=1;
    while(y)
    {
        if(y&1)res=res*x%Z;
        x=x*x%Z;
        y>>=1;
    }
    return res;
}
ll inv(ll x)
{
    return qpow(x,Z-2);
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    //IO
    string s,p;
    cin>>s>>p;
    n=s.size();
    s=" "+s;
    p=" "+p;
    rep(i,1,n)
    {
        c1[s[i]-'a']++;
        c2[p[i]-'a']++;
        cnt[s[i]-'a'][p[i]-'a']++;
    }
    ll cha=0;
    rep(i,0,25)cha-=(c1[i]>0)-(c2[i]>0);
    ans=0;
    rep(i,1,n)
    {
        ll x=s[i]-'a',y=p[i]-'a';
        ll pre=0;
        ll j=x,k=y;
        if(c2[j]==0&&c2[k]==1)pre-=0;
        if(c2[j]==0&&c2[k]>=2)pre-=1;
        if(c2[j]==1&&c2[k]==1)pre+=1;
        if(c2[j]==1&&c2[k]>=2)pre-=0;
        if(c2[j]>=2&&c2[k]==1)pre+=1;
        if(c2[j]>=2&&c2[k]>=2)pre-=0;

        if(c1[j]==1&&c1[k]==0)pre-=0;
        if(c1[j]==1&&c1[k]==1)pre-=1;
        if(c1[j]==1&&c1[k]>=2)pre-=1;
        if(c1[j]==2&&c1[k]==0)pre+=1;
        if(c1[j]==2&&c1[k]==1)pre-=0;
        if(c1[j]==2&&c1[k]>=2)pre-=0;

        c1[x]--;
        c1[y]++;
        c2[x]++;
        c2[y]--;
        cnt[x][y]--;
       // cout<<i<<"\n";
        //cout<<pre<<"\n";

        rep(j,0,25)rep(k,0,25)
        {
            ll res=0;
            if(c1[j]==0||c2[k]==0)continue;
            if(c2[j]==0&&c2[k]==1)res-=0;
            if(c2[j]==0&&c2[k]>=2)res-=1;
            if(c2[j]==1&&c2[k]==1)res+=1;
            if(c2[j]==1&&c2[k]>=2)res-=0;
            if(c2[j]>=2&&c2[k]==1)res+=1;
            if(c2[j]>=2&&c2[k]>=2)res-=0;

            if(c1[j]==1&&c1[k]==0)res-=0;
            if(c1[j]==1&&c1[k]==1)res-=1;
            if(c1[j]==1&&c1[k]>=2)res-=1;
            if(c1[j]==2&&c1[k]==0)res+=1;
            if(c1[j]==2&&c1[k]==1)res-=0;
            if(c1[j]==2&&c1[k]>=2)res-=0;

            if(res+pre==cha)
            {
               // cout<<j<<" "<<k<<" "<<cnt[j][k]<<"\n";
                ans=(ans+cnt[j][k])%Z;
            }
        }
        c1[x]++;
        c1[y]--;
        c2[x]--;
        c2[y]++;
        cnt[x][y]++;
    }
    cout<<ans*inv(2)%Z;
}
