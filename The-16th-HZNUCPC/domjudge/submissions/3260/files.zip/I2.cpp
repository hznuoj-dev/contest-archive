#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define mod 1000000007
const ll maxn = 2e5+10; 
ll findmax(string c,int i){
	ll ans=0;
	ll s=0;
	int l,r;
	int state=1;
	int a,b,w;
	if(i%2==0){
		l=i/2-1;
		r=i/2;
		while(l>=0&&r<=c.size()-1){
			if(state==1){
				if(c[l]==c[r]) s+=2,ans=s;
				else {
					a=c[l]-'a',b=c[r]-'a';
					s+=2;
					state=2;
				}
				l--;r++;
			}
			else if(state==2){
				if(c[l]==c[r]) s+=2;
				else {
					if(a==c[r]-'a'&&b==c[l]-'a'||a==c[l]-'a'&&b==c[r]-'a'){
						state=3;
						s+=2;
						ans=s;
					}
					else break;
				}
				l--;r++;
			}
			else{
				if(c[l]==c[r]) s+=2,ans=s;
				else {
					 break;
				}
				l--;r++;
			}
			
		}
		return ans;
	}
	else{
	//	cout<<l<<' '<<r<<'\n';
		s=1;
		l=i/2-1;
		r=i/2+1;
		while(l>=0&&r<=c.length()-1){
			//cout<<state<<'\n';
			if(state==1){
				if(c[l]==c[r]) s+=2,ans=s;
				else {
					a=c[l]-'a',b=c[r]-'a';
					s+=2;
					if(a==c[i/2]-'a'||b==c[i/2]-'a')
					state=4,ans=s;
					else
					state=2;
				}
				l--;r++;
			}
			else if(state==2){
				if(c[l]==c[r]) s+=2;
				else {
					if(a==c[r]-'a'&&b==c[l]-'a'||a==c[l]-'a'&&b==c[r]-'a'){
						state=3;
						s+=2;
						ans=s;
					}
					else break;
				}
				l--;r++;
			}
			else if(state==3){
				if(c[l]==c[r]) s+=2,ans=s;
				else {
					 break;
				}
				l--;r++;
			}
			else{
				if(c[l]==c[r]) s+=2,ans=s;
				else {
					if(a==c[r]-'a'&&b==c[l]-'a'||a==c[l]-'a'&&b==c[r]-'a'){
						state=3;
						s+=2;
						ans=s;
					}
					else break;
				}
				l--;r++;
			}
			
		}
		if(ans==1) return 0;
		return ans;
	}
}
void solve(){
	ll ans=0;
	string c;
	cin>>c;
	for(int i=0;i<=c.length()*2;i++){
		ans=max(findmax(c,i),ans);
	}
	cout<<ans<<'\n';
}

int main(){
    ios::sync_with_stdio(false);
    int T=1;
    cin>>T;
    while(T--){
        solve();
    }
    return 0;
}
