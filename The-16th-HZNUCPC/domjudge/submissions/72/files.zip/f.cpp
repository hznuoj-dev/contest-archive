	#include<bits/stdc++.h>

	using namespace std;
	int main()
	{
	    long long a,b;
	    cin>>a>>b;
	    if(b==1) 
		{
			cout<<"Yes"<<endl;
			return 0;
		}
	    if(a%b) cout<<"YES"<<endl;
	    else cout<<"No"<<endl;
	    return 0;
	}
