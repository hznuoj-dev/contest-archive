#include<bits/stdc++.h>
using namespace std;
const int L = 1e9+7;
const int N = 1e5+10;
int vis1[N];
int vis2[N];
int main(){
	string s1,s2;
	cin>>s1>>s2;
	int ans1 = 0,ans2 = 0;
	int cnt1 = 0,cnt2 = 0;
	int sum;
	int len = s1.size();
	for(int i=0;i<len;i++){
		if(!vis1[s1[i]-'a']) {
			vis1[s1[i]-'a'] = 1;
			cnt1++;
		}
		if(!vis2[s2[i]-'a']) {
			vis2[s2[i]-'a'] = 1;
			cnt2++;
		}
	}
	for(int i=0;i<len;i++){
		if(s1[i] == s2[i]){
			ans1++;
		}
		else if(s1[i]!=s2[i]&&vis2[s1[i]-'a']== 0&&vis1[s2[i]-'a']== 0||vis2[s1[i]-'a']== 1&&vis1[s2[i]-'a']== 1)
			ans1++;
	}
	ans2 = abs(cnt1-cnt2);
	if(ans2 == 0){
		sum = (ans1 * (ans1 - 1) / 2)%L;
	}
	else {
		if(ans2!=2&&ans2!=4) cout<<'0'<<endl;
		else {
			if(ans2 == 2){
				sum = (2 * ans1)%L;
			}
			else if(ans2 == 4){
				sum = 6;
			}
		}
	}
	cout<<sum<<endl;
	return 0;
}