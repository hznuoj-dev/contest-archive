#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=5010;
char s[N];
void solve() {
	scanf("%s",s+1);
	ll res=0,n=strlen(s+1);
	for(ll pos=2; pos<n; pos++) {
		ll cnt=0,p=0;
		for(ll l=pos-1,r=pos+1; l>=1&&r<=n; l--,r++) {
			if(s[l]!=s[r]) {
				cnt++;
				p^=1<<(s[l]-'a');
				p^=1<<(s[r]-'a');
			}
			if(cnt==0||(cnt==2&&p==0)) {
				res=max(res,r-l+1);
			}
		}
	}
	for(ll pos=1; pos<n; pos++) {
		ll cnt=0,p=0;
		for(ll l=pos,r=pos+1; l>=1&&r<=n; l--,r++) {
			if(s[l]!=s[r]) {
				cnt++;
				p^=1<<(s[l]-'a');
				p^=1<<(s[r]-'a');
			}
			if(cnt==0||(cnt==2&&p==0)) {
				res=max(res,r-l+1);
			}
		}
	}
	printf("%lld\n",res);
}
int main() {
	ll t;
	scanf("%lld",&t);
	while(t--) {
		solve();
	}
}