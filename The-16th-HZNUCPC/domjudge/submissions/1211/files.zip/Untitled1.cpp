#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;
typedef long long ll;


void solve(){
	ll pre,n,m;
	cin>>n>>m;
	if(n==1||m==1){
		cout<<"YES"<<endl;
		return;
	}
	if(n<=m){
		cout<<"NO"<<endl;
		return;
	}
	pre=m;
	m=n%m;
	while(m>0)
	{
		pre=m;
		m=n%m;
	}
	if(pre==1)cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	
	
	
	system("pause");
}

int main(){
	
	int t = 1;
	//cin >> t
	while(t--){
		solve();
	}
	
	return 0;
}