#include<bits/stdc++.h>
using namespace std;
void work(){
	map<int,map<int,int>> M;
	map<int,map<int,int>> N;
	int n,x,y,z;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d%d",&x,&y,&z);
		if(z==1){
			M[x-1][y]++;
			M[x+1][y]++;
			M[x][y-1]++;
			M[x][y+1]++;
		}
		N[x][y]=1;
	}
	int cnt=0;
	for(int i=1;i<=19;i++)
		for(int j=1;j<=19;j++)
			if(M[i][j]>0&&N[i][j]==0) cnt+=M[i][j];
	printf("%d\n",cnt);
}
int main(){
	int t;
	scanf("%d",&t);
	while(t--)
		work();
	return 0;
}