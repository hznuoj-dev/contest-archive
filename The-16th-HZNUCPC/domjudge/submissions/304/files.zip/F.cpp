#include <bits/stdc++.h>
#define ln '\n'

int main() {
	long long a, b;
	std::cin >> a >> b;
//	bool flag = false;
//	long long lst = b;
//	while(b > 1) 
//		b = a % b;
//	std::cout << (b == 1 ? "YES\n" : "NO\n");
	for(long long i = 2; i * i <= a; i++) 
		if(a % i == 0 && i <= b) return std::cout << "NO\n", 0;
	std::cout<<"YES\n";
}