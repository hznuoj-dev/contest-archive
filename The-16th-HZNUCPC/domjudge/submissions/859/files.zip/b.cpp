#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
int f(LL x){
    for(LL i = 2 ; i <= x / i; i++) {
        if(x % i == 0) return 0;
    }
    return 1;
}
int main() {
    LL a, b;
    cin >> a >> b;
    if(a == 1 || b == 1) {
        cout << "YES" << endl;
    } else if(a <= b){
        cout << "NO" << endl;
    } else {
        if(f(a) && a % b != 0) {
            cout << "YES" <<endl;
        } else {
            cout << "NO" << endl;
        }
    }
}
