#include<bits/stdc++.h>
#define int long long 
using namespace std;
const int N=1e5+5;
#define poly vector<int>
#define pb push_back
#define pii pair<int,int>
#define fi first
#define se second
#define mp make_pair
struct info{
	vector<pii> v;
	int cz;
};

vector<pii> v[N];
info kuai[N];
bool used[N];
int st[N];
poly ve;
void dfs(int u){
	used[u]=1; ve.pb(u);
	for(auto ssw:v[u]){
		int k=ssw.fi;
		if(used[k]) continue;
		st[k]=st[u]^ssw.se;
		dfs(k);
	}
}
bool check(poly &ve){
	for(auto u:ve){
		for(auto ssw:v[u]){
			int k=ssw.fi;
			if((st[k]^st[u])!=ssw.se) return 0;
		}
	}
	return 1;
}
const int lp=2e5;
int Tot;
int op[N*15],gs[N*15];
bool b[N*4];
int ob[N*4],gb[N*4];
void mk(int x,int Gs){
	for(int i=0;i<=30&&Gs>=(1ll<<i);i++){
		op[++Tot]=x;gs[Tot]=(1ll<<i);
		Gs-=(1ll<<i);
	}	
	if(Gs) op[++Tot]=x,gs[Tot]=Gs;
}

int kp[lp*4];
int ans[N*4];
signed main(){
	int n,m,q; scanf("%lld%lld%lld",&n,&q,&m);
	for(int i=1;i<=m;i++){
		int op,x,y; scanf("%lld%lld%lld",&op,&x,&y);
		v[x].pb(mp(y,op)); v[y].pb(mp(x,op));
	}
	int cnt=0,S=0;
	for(int i=1;i<=n;i++) if(!used[i]){
		ve.clear(); dfs(i);
		if(!check(ve)) return puts("NO"),0;
		cnt++;
		int tot=0,sum=0;
		for(auto x:ve){
			kuai[cnt].v.pb(mp(x,st[x]));
			sum+=st[x];
		}
		S+=sum;
		tot=(int)ve.size()-sum;
//		cout<<"Sum = "<<sum<<endl;
//		cout<<"tot = "<<tot<<endl;
		kp[tot-sum+lp]++;
		kuai[cnt].cz=tot-sum;
	}
	
//	cout<<"S = "<<S<<endl;
	
	for(int i=-n;i<=n;i++){
		if(kp[i+lp]){
//			cout<<" cz: "<<i<<endl;
			mk(i,kp[i+lp]);	
		}		
	}
	
	b[0+lp]=1;
	for(int i=1;i<=Tot;i++){
		if(op[i]>0){
			for(int j=n-op[i]*gs[i];j>=-n;j--)
				if(b[j+lp]&&!b[j+op[i]*gs[i]+lp]){
					b[j+op[i]*gs[i]+lp]=1;
					ob[j+op[i]*gs[i]+lp]=op[i];
					gb[j+op[i]*gs[i]+lp]=gs[i];
				}
		}else
		if(op[i]<0){
			for(int j=-n-op[i]*gs[i];j<=n;j++)
				if(b[j+lp]&&!b[j+op[i]*gs[i]+lp]){
					b[j+op[i]*gs[i]+lp]=1;
					ob[j+op[i]*gs[i]+lp]=op[i];
					gb[j+op[i]*gs[i]+lp]=gs[i];
				}			
		}		
	}
	
	if(!b[q-S+lp]){
		return puts("NO"),0;
	}else{
		int x=q-S+lp;
		while(x!=lp){
			ans[ob[x]+lp]+=gb[x];	
//			ansy[rt]=gb[x];
			x-=ob[x]*gb[x];
		}
		puts("YES");
		for(int i=1;i<=cnt;i++)
			if(ans[kuai[i].cz+lp]>0){
				for(auto ssw:kuai[i].v){
					if(ssw.se==0) printf("%lld ",ssw.fi);
				}
				ans[kuai[i].cz+lp]--;
			}else{
				for(auto ssw:kuai[i].v){
					if(ssw.se) printf("%lld ",ssw.fi);
				}
			}
		
	}
	return 0;
}
