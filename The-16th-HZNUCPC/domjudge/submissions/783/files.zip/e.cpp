#include <bits/stdc++.h>
const int maxn = 105;

int x[maxn], y[maxn];
long long ans = 0;
long long C(int i, int j) {
	int X = std::max(x[i], x[j]) - std::min(x[i], x[j]);
	int Y = std::max(y[i], y[j]) - std::min(y[i], y[j]);
	if (X == 0) {
		return std::max(0, Y - 1);
	}
	if (Y == 0) {
		return std::max(0, X - 1);
	}
	int gg = std::__gcd(X, Y);
	int xg = X / gg;
	int yg = Y / gg;
	long long ans = std::min(X / xg, Y / yg);
	ans = std::max(0ll, ans);
	return ans;
}

bool isline(int i, int j, int k) {
	if (y[i] == y[j] && y[i] == y[k]) return true;
	if (x[i] == x[j] && x[i] == x[k]) return true;
	if (y[i] == y[j] || y[i] == y[k]) return false;
	if (x[i] == x[j] || x[i] == x[k]) return true;
	return 1ll * (y[k] - y[j]) * (x[j] - x[i]) == 1ll * (y[j] - y[i]) * (x[k] - x[j]);
}

long long cal(int i, int j, int k) {
	long long ans = 0;
	if (isline(i, j, k)) return 0;
	ans += C(i, j);
	ans += C(j, k);
	ans += C(i, k);
	return ans;
}

int main () {
	std::ios::sync_with_stdio(false);
	int n;
	std::cin >> n;
	for (int i = 1; i <= n; i++) {
		std::cin >> x[i] >> y[i];
	}
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			for (int k = j + 1; k <= n; k++) {
				ans = std::max(ans, cal(i, j, k));
			}
		}
	}
	//std::cout << C(1, 3) << "\n";
	std::cout << ans << "\n";
} 
