#include<bits/stdc++.h>

using namespace std;

#define ios ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define ll long long

int gcd(int a, int b)
{
	while(b^=a^=b^=a%=b);
	return a;
}

struct Stu{
	int x, y;
}f[300];


double dis(Stu a, Stu b)
{
	return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}


bool isok(Stu a, Stu b, Stu c)
{
	set<double> se;
	int cnt = 0;
	if(a.x == b.x) cnt ++;
	else{
		double fz = a.y - b.y, fm = a.x - b.x;
		se.insert(fz/fm);
	}
	
	if(a.x == c.x) cnt++;
	else{
		double fz = a.y - c.y, fm = a.x - c.x;
		se.insert(fz/fm);
	}
	
	if(c.x == b.x) cnt++;
	else{
		double fz = c.y - b.y, fm = c.x - b.x;
		se.insert(fz/fm);
	}
	if(cnt > 1) return false;
	return se.size() + cnt == 3;
	
}


ll add(Stu a, Stu b)
{
	int cnt = 0;
	
	int fz = a.y - b.y, fm = a.x - b.x;
	if(fz == 0) cnt += abs(a.x - b.x) + 1;
	else if(fm == 0) cnt += abs(a.y - b.y) + 1;
	else{
		int _gcd = abs(gcd(fz, fm));
		fz /= _gcd, fm /= _gcd;
		fz = abs(fz), fm = abs(fm);
		if(fz < fm)
			cnt = cnt + (max(a.x, b.x) - min(a.x, b.x)) * fz / fm + 1;
		else
			cnt = cnt + (max(a.y, b.y) - min(a.y, b.y)) * fm / fz + 1;
	}

	return cnt;
}

int main()
{
	ios;
	int n; cin >> n;
	for(int i = 1; i <= n; i++) cin >> f[i].x >> f[i].y;
	ll ma = 0;
	
	for(int i = 1; i <= n; i++)
	{
		for(int j = i + 1; j <= n; j++)
		{
			for(int k = j + 1; k <= n; k++)
			{
				if(isok(f[i],f[j],f[k]))
				{
					ll cnt = add(f[i], f[j]) + add(f[i], f[k]) + add(f[j], f[k]) - 3;
					ma = max(0LL, max(ma, cnt));
				}
			}
		}
	}
	cout << ma << endl;
//	
//	cout << add(f[1], f[2]) << endl;
//	cout << add(f[1], f[3]) << endl;
//	cout << add(f[2], f[3]) << endl;
	return 0;
}

