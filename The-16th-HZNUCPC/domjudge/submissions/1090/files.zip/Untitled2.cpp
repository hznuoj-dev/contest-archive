#include<bits/stdc++.h>
using ll =long long ;
int n,m,k;
int A[26],B[26];
ll a[26][26];
const ll mod=1e9+7;
inline void add(int *a,int x,int &cnt)
{
	if(!a[x]++)cnt++;
}
inline void sub(int *a,int x,int &cnt)
{
	if(!--a[x])--cnt;
}
int main()
{
	std::ios::sync_with_stdio(false);
	std::string s,t;
	std::cin>>s>>t;
	int cnt1=0,cnt2=0;
	for(int i=0; i<s.length(); i++)
	{
		add(A,s[i]-'a',cnt1);
		add(B,t[i]-'a',cnt2);
		a[s[i]-'a'][t[i]-'a']++;
	}


	ll ans=0;
	for(int i=0; i<26; i++)
		for(int j=0; j<26; j++)
			for(int p=i; p<26; p++)
				for(int q=(i==p?j:0); q<26; q++)
				{
					if(!a[i][j]||!a[p][q])continue;
					sub(A,i,cnt1);
					add(A,j,cnt1);
					add(B,i,cnt2);
					sub(B,j,cnt2);

					sub(A,p,cnt1);
					add(A,q,cnt1);
					add(B,p,cnt2);
					sub(B,q,cnt2);

					if(cnt1==cnt2)
					{
//						std::cout<<i<<" "<<j<<" "<<p<<" "<<q<<" "<<ans<<std::endl;
						if(i==p&&j==q)
							ans=(ans+a[i][j]*(a[i][j]-1)/2)%mod;
						else
							ans=(ans+a[i][j]*a[p][q])%mod;
//						std::cout<<i<<" "<<j<<" "<<p<<" "<<q<<" "<<ans<<std::endl;
					}
					add(A,i,cnt1);
					sub(A,j,cnt1);
					sub(B,i,cnt2);
					add(B,j,cnt2);

					add(A,p,cnt1);
					sub(A,q,cnt1);
					sub(B,p,cnt2);
					add(B,q,cnt2);
				}
	std::cout<<ans;
	return 0;
}
