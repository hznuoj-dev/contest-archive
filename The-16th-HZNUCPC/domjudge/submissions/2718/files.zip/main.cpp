#include <iostream>
using namespace std;
long long  m,n,i;
bool flag=true;
int main(int argc, char** argv) {
	cin>>n>>m;
	i=m;
	if(m==1){
		flag=false;
		printf("YES");
	}
	while(flag){
		i=n%i;
		if(i==1){
			printf("YES");
			break;
		}
		if(i==0){
			printf("NO");
			break;
		}
	}
	return 0;
}