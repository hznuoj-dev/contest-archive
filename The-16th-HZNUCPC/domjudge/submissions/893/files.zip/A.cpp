#include<iostream>
#include<vector>
using namespace std;
struct point{int x, y;};
vector<vector<int>> table;
int method[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int main()
{
	int n;
	cin>>n;
	while(n--){
		vector<point> black;
		table = vector<vector<int>>(20,vector<int>(20,-1));
		int num;
		cin>>num;
		for(int i =0;i<num;i++){
			int a,b,c;
			cin>>a>>b>>c;
			table[a][b]=c;
			if(c==1){
				black.push_back({a,b});
			}
		}
		int count=0;
		for(point tmp:black){
			for(int i=0;i<4;i++){
				int newx = tmp.x+method[i][0];
				int newy = tmp.y+method[i][1];
				if(newx<=0||newx>19){
					continue;
				} 
				if(newy<=0||newy>19){
					continue;
				}
				if(table[newx][newy]==-1){
					count++;
				}
			}
		}
		cout<<count<<endl;
	}
	return 0;
}
