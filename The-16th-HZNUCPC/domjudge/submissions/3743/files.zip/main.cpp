#include <bits/stdc++.h>
using namespace std;



long long piao,ren;
bool tc=false;
void digui(long long piao,long long ren){
	if(ren==1){
		tc=true;
		return ;
	}
	if(ren==0){
		tc=false;
		return;
	}
	digui(piao,piao%ren);
}

int main() {
	while(cin>>piao>>ren){
		tc=false;
		digui(piao,ren);	
		if(tc==true)cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}