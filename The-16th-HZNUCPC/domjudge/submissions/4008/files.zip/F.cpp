#include<bits/stdc++.h>

using namespace std;

int main() {
	long long n,m;
	scanf("%lld %lld",&n,&m);
	long long t=n%m;
	if(t==0)
	printf("NO");
	else{
		if((n*m)%t==1)
	printf("YES");
	else printf("NO");
	}
	
	return 0;
}

