#include<bits/stdc++.h>
using namespace std;
int mp[25][25];
const int dx[]={1,-1,0,0};
const int dy[]={0,0,1,-1};
int Check(int x,int y)
{
	int res = 0;
	for(int i =0; i<=3; i++)
	{
		int xx = x+dx[i];
		int yy = y+dy[i];
		if(mp[xx][yy]==1)
			res++;
	}
	return res;
}
int main()
{
	ios::sync_with_stdio(false);
	int T;
	cin>>T;
	while(T--)
	{
		int n;
		cin>>n;
		memset(mp,0,sizeof(mp));
		for(int i =1; i<=n; i++)
		{
			int x,y;
			int c;
			cin>>x>>y>>c;
			mp[x][y]=c;
		}
		int cnt = 0;
		for(int i = 1; i<=19; i++)
			for(int j = 1; j<=19; j++)
				if(mp[i][j]==0)
					cnt+=Check(i,j);
		cout<<cnt<<"\n";
	}
	return 0;
}