#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define debug(x) cerr<<#x<<" "<<x<<"\n"

void _solve(){
    ll n,m;cin>>n>>m;
    if(m==1) cout<<"YES\n";
    else{
        if(n%2==0) cout<<"NO\n";
        else{
            vector<ll>vec;
            ll now=m;
            for(ll i=2;i*i<=m;i++){
                if(now%i==0){
                    vec.push_back(i);
                }
                while(now%i==0) now/=i;
            }
            if(now!=1) vec.push_back(now);
            for(auto p:vec){
                if(n%p==0){
                    cout<<"NO\n";
                    return;
                }
            }
            cout<<"YES\n";
        }
    }
}

int main(){
    ios::sync_with_stdio(false);

//    int T;cin>>T;while(T--)
    _solve();
}
