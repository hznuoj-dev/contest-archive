#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
typedef long long ll;
string a,b;
pair <char,char> c;
int numb[50],numa[50];
int numbb[50],numaa[50];
set <char>aa,bb,aaa,bbb;
map<pair<char,char>,int > m;
int len,ans=0;
int main(){
	cin>>a>>b;
	len=a.length();
	a=" "+a;
	b=" "+b;
	for(int i=1;i<=len;i++){
		m[{a[i],b[i]}]++;
		numa[a[i]-'a'+1]++;
		numb[b[i]-'a'+1]++;
		aa.insert(a[i]);
		bb.insert(b[i]);
	}
	int dd=aa.size()-bb.size();
	for(char i='a';i<='z';i++){
		for(char j='a';j<='z';j++){
			for(char k='a';k<='z';k++){
				for(char z='a';z<='z';z++){
					if(m[{i,j}]*m[{k,z}]){
						int nai,nbj,nak,nbz;
						nai=numa[i-'a'+1];
						nbj=numb[j-'a'+1];
						nak=numa[k-'a'+1];
						nbz=numb[z-'a'+1];
						
						int naj,nbi,naz,nbk;
						naj=numa[j-'a'+1];
						nbi=numb[i-'a'+1];
						naz=numa[z-'a'+1];
						nbk=numb[k-'a'+1];
						
						aaa=aa;
						bbb=bb;
						numa[j-'a'+1]++; 	if(numa[j-'a'+1]>0)	aaa.insert(j);
						numb[j-'a'+1]--;	if(numb[j-'a'+1]==0)	bbb.erase(j);
						numb[i-'a'+1]++;	if(numb[i-'a'+1]>0)	bbb.insert(i);
						numa[i-'a'+1]--;	if(numa[i-'a'+1]==0)	aaa.erase(i);
						numa[k-'a'+1]--;	if(numa[k-'a'+1]==0)	aaa.erase(k);
						numb[k-'a'+1]++;	if(numb[k-'a'+1]>0)	bbb.insert(k);
						numb[z-'a'+1]--;	if(numb[z-'a'+1]==0)	bbb.erase(z);
						numa[z-'a'+1]++;	if(numa[z-'a'+1]>0)	aaa.insert(z);
						
						numa[i-'a'+1]=nai;
						numb[j-'a'+1]=nbj;
						numa[k-'a'+1]=nak;
						numb[z-'a'+1]=nbz;
						
						numa[j-'a'+1]=naj;
						numb[i-'a'+1]=nbi;
						numa[z-'a'+1]=naz;
						numb[k-'a'+1]=nbk;
						
						
						if(aaa.size()==bbb.size()){
							//cout<<i<<j<<k<<z<<endl;
							if(i==j&&k==z) {
								
								ans+=(m[{i,j}]-1)*m[{i,j}]/2;
							}
							else ans+=m[{i,j}]*m[{k,z}]/2;
						}
						
					}
				}
			}
		}
	}
	/*switch(dd){
		case 2:{
			ans=(d[6])*(d[6]-1)/2;
			break;
		}
		case 1:{
			ans=(d[6])*(d[5]);
			break;
		}
		case 0:{
			ans=(d[5])*(d[5]-1)/2;
			break;
		}
		case -1:{
			ans=(d[4])*(d[5]);
			break;
		}
		case -2:{
			ans=(d[4])*(d[4]-1)/2;
			break;
		}
	}*/
	cout<<ans<<endl;
	return 0;
}








