#include<bits/stdc++.h>
#define ft first
#define sd second
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
#define rep(i,a,b) for(ll i=a;i<=b;++i)
using namespace std;
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    //IO
    int T=1;
    //cin>>T;
    while(T--)
    {
       ll n,m;
       cin>>n>>m;
       if(n==1||m==1)
       {
           cout<<"YES";
            return 0;
       }
       if(n<=m)
       {
           cout<<"NO";
            return 0;
       }
       ll t = sqrtl(n);
       for(int i=2;i<=t;i++)
       {
           if(n%i==0)
           {
               if(m>=i)
               {
                   cout<<"NO";
                   return 0;
               }

           }
       }
        cout<<"YES";
    }
}
