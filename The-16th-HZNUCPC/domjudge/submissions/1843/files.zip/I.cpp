#include<bits/stdc++.h>
#define ll long long
#define rep(i,j,k) for(int i=(j);i<=(k);i++)

char s[5003];

int f[5003][5003][3];
std::pair < char, char > p[5003][5003];

struct node{
	int x, y, k;
};

inline bool check ( int x, int y ) {
	std::pair < char, char > now = std::minmax ( s[x], s[y] ), cur = p[x + 1][y - 1];
	return now.first == cur.first && now.second == cur.second;
}

inline void solve() {
	std::queue < node > q;
	scanf ( "%s", s + 1 );
	int n = strlen ( s + 1 );
	rep ( i, 1, n ) rep ( j, 1, n ) f[i][j][0] = f[i][j][1] = f[i][j][2] = 0, p[i][j] = std::make_pair ( 0, 0 );
	int ans = 0;
	rep ( i, 1, n ) f[i][i][0] = 1, q.push ( { i, i, 0 } );
	rep ( i, 2, n ) if ( s[i] == s[i - 1] ) f[i - 1][i][0] = 2, q.push ( { i - 1, i, 0 } );
	while ( !q.empty() ) {
		node u = q.front(); q.pop();
		int x = u.x, y = u.y, k = u.k;
		if ( x > 1 && y < n ) {
			x--, y++;
			if ( s[x] == s[y] ) {
				f[x][y][k] = std::max ( f[x][y][k], f[x + 1][y - 1][k] + 2 );
				if ( k == 0 || k == 2 ) ans = std::max ( ans, f[x][y][k] );
				p[x][y] = p[x + 1][y - 1];
				q.push ( { x, y, k } );
			}
			else {
				if ( k == 0 ) f[x][y][1] = std::max ( f[x][y][1], f[x + 1][y - 1][0] + 2 ), p[x][y] = std::minmax ( s[x], s[y] ), q.push ( { x, y, 1 } );
				else if ( k == 1 && check ( x, y ) ) ans = std::max ( ans, f[x][y][2] = std::max ( f[x][y][2], f[x + 1][y - 1][1] + 2 ) ), q.push ( { x, y, 2 } ); 
			}
		}
	} printf ( "%d\n", ans );
}

signed main() {
	int t; scanf ( "%d", &t );
	while ( t-- ) solve();
}