#include<bits/stdc++.h>
using namespace std;
long long ssu(long long a)
{
	if(a<=1)
		return 0;
	for(long long i=2;i<=a/i;i++)
	{
		if(a%i==0)
			return 0;
	}
	return 1;
}
long long pd(long long a)
{
	long long i;
	if(ssu(a))return a;
	for(i=2;i<a;i++)
	{
		if(a%i==0)
		{	
			return i;
		}         
	}
}
int main()
{
	long long n=0,m=0;
	scanf("%lld %lld",&n,&m);
	if(n==1)cout<<"YES"<<endl;
 	else if(pd(n)>m){
			printf("YES\n");
	}
	else printf("NO\n");
}