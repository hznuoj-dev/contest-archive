#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define IO ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
const ll mode=1e9+7;
const int maxn=1e5+10;
//---------------------------
struct node
{
    int x,y,c;
    bool operator<(const node&o)const
    {
        return x<o.x;
    }
};
/*
1
2
1 1 1
2 2 1

1
2
10 9 11
10 10 11

2
4
1 2 1
2 1 1
3 2 1
2 3 1
2
2 2 1
2 3 2

1
2
19 19 1
19 18 1

*/
int n,m;
node a[400];

int mp[30][30];
int dix[]={0,0,-1,1};
int diy[]={1,-1,0,0};
//----------------------


int check(int x,int y)
{
    int ans=0;
    for(int i=0;i<4;i++)
    {
        int tx=dix[i]+x;
        int ty=diy[i]+y;
        if(tx<=0||tx>19||ty<=0||ty>19)continue;
        if(mp[tx][ty]==0)
        {
            ans++;
        }
    }
    return ans;
}
void solve()
{
    cin>>n;
    for(int i=0;i<29;i++)
    {
        for(int j=0;j<29;j++)mp[i][j]=0;
    }
    for(int i=1;i<=n;i++)
    {
        cin>>a[i].x>>a[i].y>>a[i].c;
        mp[a[i].x][a[i].y]=a[i].c;
    }
    int ans=0;
    for(int i=1;i<=n;i++)
    {
        if(a[i].c==1)
        {
            ans+=check(a[i].x,a[i].y);
        }
    }
    cout<<ans<<endl;
}
int main()
{
    IO;
    int tn=1;
    cin>>tn;
    while(tn--)
    {
        solve();
    }
    return 0;
}
