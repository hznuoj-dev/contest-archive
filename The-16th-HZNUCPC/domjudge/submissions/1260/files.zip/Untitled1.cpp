#include<bits/stdc++.h>
using namespace std;
int x[150],y[150];
int can(int a,int b,int c)
{
	if(x[a]==x[b])
	{
		if(x[c]==x[a]) return 1;
		else return 0;
	}
	if(x[c]==x[b])
	{
		if(x[c]==x[a]) return 1;
		else return 0;
	}
	if(1.0*(y[a]-y[b])/1.0*(x[a]-x[b])==1.0*(y[b]-y[c])/1.0*(x[b]-x[c])) return 0;
	else return 1;
}
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		scanf("%d%d",&x[i],&y[i]);
	int sum=0,ans=0;
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			for(int k=j+1;k<n;k++)
			{
				sum=0;
				if(!can(i,j,k)) continue;
				int a=abs(y[i]-y[j]);
				int b=abs(x[i]-x[j]);
				if(a==0||b==0)
				{
					sum+=b+1;
				}
				else
				{
					int g=__gcd(a,b);
					b/=g;
					int d=abs(x[i]-x[j])/b;
					sum+=d+1;	
				}
				
				a=abs(y[i]-y[k]);
				b=abs(x[i]-x[k]);
				if(a==0||b==0)
				{
					sum+=b+1;
				}
				else
				{
					int g=__gcd(a,b);
					b/=g;
					int d=abs(x[i]-x[k])/b;
					sum+=d+1;	
				}
				
				
				a=abs(y[j]-y[k]);
				b=abs(x[j]-x[k]);
				if(a==0||b==0)
				{
					sum+=b+1;
				}
				else
				{
					int g=__gcd(a,b);
					b/=g;
					int d=abs(x[k]-x[j])/b;
					sum+=d+1;	
				}
				
				sum-=3;
				ans=max(ans,sum);
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}