#include<bits/stdc++.h>
using namespace std;
long long n,m;
int main() {
	ios::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL);
	cin>>n>>m;
	if(n==1||m==1){
		cout<<"YES"<<endl;
		return 0;
	}
	if(n<=m){
		cout<<"NO"<<endl;
		return 0;
	}
	while(n%m){
		m=n%m;
		if(m==1){
			cout<<"YES"<<endl;
			return 0;
		}
	}
	cout<<"NO"<<endl;
	return 0;
}