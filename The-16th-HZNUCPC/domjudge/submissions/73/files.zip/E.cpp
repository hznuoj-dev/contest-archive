#include<bits/stdc++.h>
using namespace std;
int n;
int X[110],Y[110];
long long get(int x,int y){
	int dx=X[x]-X[y],dy=Y[x]-Y[y];
	if(dx<0) dx=-dx;if(dy<0) dy=-dy;
	int d=__gcd(dx,dy);
	return d;
}
bool chk(int x,int y,int z){
	return 1ll*(X[y]-X[x])*(Y[z]-Y[x])-1ll*(X[z]-X[x])*(Y[y]-Y[x])!=0;
}
int main(){
	ios::sync_with_stdio(false);
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>X[i]>>Y[i];
	}
	long long ans=0;
	for(int i=1;i<=n;++i){
		for(int j=i+1;j<=n;++j){
			for(int k=j+1;k<=n;++k) if(chk(i,j,k)){
				ans=max(ans,get(i,j)+get(j,k)+get(i,k));
			}
		}
	}
	printf("%lld\n",ans);
}