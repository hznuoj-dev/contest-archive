#include<bits/stdc++.h>
using namespace std;
int t,n,x[1001],y[1001],z[1001],a[21][21],ans,di[4][2]={-1,0,1,0,0,1,0,-1};
int main()
{
	printf("NO");
	return 0;
}