#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
	ll n, m;
	while(cin >> n >> m){
		if(n == 1){
			cout << "YES" << endl;
			continue;
		} 
		if(m == 1){
			cout << "YES" << endl;
			continue;;
		}
		if(n <= m){
			cout << "NO" << endl;
		}else{
			ll x = n % m;
			if(x == 0){
				cout << "NO" << endl;
			}else{
				m = x;
				while(1){
					if(m == 1){
						cout << "YES" << endl;
						break;
					}else if(m == 0){
						cout << "NO" << endl;
						break;
					}
					x = n % m;
					m = x;
				}
			}
		}
	}
	
	return 0;
}