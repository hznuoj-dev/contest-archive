#include <iostream>
#include <vector>
#include <cstring>

using namespace std;
const int mod = 1e9 + 7;
typedef pair<int,int>pii;
typedef long long ll;
const int N=1e5+10;
int cnt1[N];
int cnt2[N];
int ans[5][5];
pii zxw[N];

ll quick_mod(ll a,ll b )
{
	ll res=1;
	while(b)
	{
		if(b&1)res=res*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return res;
}

int main() {
	 string a,b;
	 cin>>a>>b;
	 int sz1,sz2;
	 ll res=0;
	 sz1=sz2=0;
	 for(int i=0;i<a.length();i++)
	 {
	 	cnt1[a[i]-'a'+ 1]++;
	 	if(cnt1[a[i]-'a'+ 1] == 1)
	 		sz1++;
	 	
	 }
	 for(int i=0;i<b.length();i++)
	 {
	 	cnt2[b[i]-'a'+ 1]++;
	 	if(cnt2[b[i]-'a'+ 1] == 1)
	 		sz2++;
	 }
	 
	 if(abs(sz1-sz2)>4)
	 {
	 	cout<<"0"<<endl;
	 	return 0;
	 }
	 
	 for(int i=0;i<a.length();i++)
	 {
		char x=a[i],y=b[i];
		if(x==y)
		{
			zxw[i]={2,2};
			ans[2][2]++;
			continue;
		}
		int c1,c2;
		c1=c2=2;
		if(cnt1[b[i]-'a'+1]+1 == 1)c1++;
		if(cnt1[a[i]-'a'+1]-1 == 0)c1--;
		if(cnt2[b[i]-'a'+1]-1 == 0)c2--;
		if(cnt2[a[i]-'a'+1]+1 == 1)c2++;
		zxw[i]={c1,c2};	
		ans[c1][c2]++;
	 }
	 
	 int dif=sz2-sz1;
	 for(int i=0;i<a.length();i++)
	 {
		auto t=zxw[i];
		int h1=t.first,h2=t.second;
		
		int tmp = dif + (h2-h1);
		if(tmp ==1)
		{
			res = (res + ans[2][1])%mod;
			res = (res + ans[3][2])%mod;
			if(h1 == 2 && h2 == 1 || h1 == 3 && h2 == 2)
				res--;
		}
		else if(tmp == 2)
		{
			res=(res + ans[3][1])%mod;
			if(h1 == 3 && h2 == 1)
				res--;
		}
		else if(tmp==0)
		{
			res=(res + ans[1][1])%mod;
			res=(res + ans[2][2])%mod;
			res=(res + ans[3][3])%mod;
			if(h1 == h2)
				res--;
		}
		else if(tmp==-1)
		{
			res = (res + ans[1][2])%mod;
			res = (res + ans[2][3])%mod;
			if(h1 == 1 && h2 == 2 || h1 == 2 && h2 == 3)
				res--;
		}
		else if(tmp==-2)
		{
			res=(res+ans[1][3])%mod;
			if(h1 == 1 && h2 == 3 )
				res--;
		}
		//cout<<h1<<" "<<h2<<" "<< tmp <<" "<<res<<endl;
		res=res%mod;
	 }
	 cout<< (res * quick_mod(2,mod -2) % mod + mod ) % mod <<endl;
	
}