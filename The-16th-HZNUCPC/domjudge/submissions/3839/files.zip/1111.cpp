#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=1e5+10;
const ll mod=1e9+7;
char sa[maxn],sb[maxn];
ll s[30][30],tmp;
int numa[30],numb[30];
int main(int argc, char** argv) {
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin>>sa;
	cin>>sb;
	int n=(int)strlen(sa);
	for(int i=0;i<n;i++){
		s[sa[i]-'a'][sb[i]-'a']++;
		numa[sa[i]-'a']++;
		numb[sb[i]-'a']++;
	}
	int seta=0,setb=0;
	for(int i=0;i<26;i++){
		if(numa[i]>0)seta++;
		if(numb[i]>0)setb++;
	}
	ll ans=0;
	for(int i=0;i<26;i++){
		for(int j=0;j<26;j++){
			//
			for(int i0=i;i0<=i;i0++){
				for(int j0=j;j0<26;j0++){
					if(i==i0&&j==j0&&s[i][j]<2) continue;
					if(s[i][j]==0||s[i0][j0]==0){
						continue;
					}
					int ka=seta,kb=setb;
					if(numa[i]==1)ka--;
					if(numa[j]==0)ka++;
					numa[i]--;
					numa[j]++;
					if(numb[j]==1) kb--;
					if(numb[i]==0) kb++;
					numb[i]++;
					numb[j]--;
					if(numa[i0]==1)ka--;
					if(numa[j0]==0)ka++;
					if(numb[j0]==1)kb--;
					if(numb[i0]==0)kb++;
					numa[i]++;
					numa[j]--;
					numb[j]++;
					numb[i]--;
					if(ka==kb){
						//cout<<i<<' '<<j<<i0<<j0<<endl;
						if(i==i0&&j==j0){
							tmp=s[i][j]*(s[i][j]-1)/2;
							ans+=tmp;
							ans%=mod;
						}else{
							tmp=s[i][j]*s[i0][j0];
							ans+=tmp;
							ans%=mod;
						}
					}
				}
			}
			//
			for(int i0=i+1;i0<26;i0++){
				for(int j0=0;j0<26;j0++){
					if(i==i0&&j==j0&&s[i][j]<2) continue;
					if(s[i][j]==0||s[i0][j0]==0){
						continue;
					}
					int ka=seta,kb=setb;
					if(numa[i]==1)ka--;
					if(numa[j]==0)ka++;
					numa[i]--;
					numa[j]++;
					if(numb[j]==1)kb--;
					if(numb[i]==0) kb++;
					numb[i]++;
					numb[j]--;
					if(numa[i0]==1)ka--;
					if(numa[j0]==0)ka++;
					if(numb[j0]==1)kb--;
					if(numb[i0]==0)kb++;
					numa[i]++;
					numa[j]--;
					numb[j]++;
					numb[i]--;
					if(ka==kb){
						//cout<<i<<' '<<j<<i0<<j0<<endl;
						if(i==i0&&j==j0){
							tmp=s[i][j]*(s[i][j]-1)/2;
							ans+=tmp;
							ans%=mod;
						}else{
							tmp=s[i][j]*s[i0][j0];
							ans+=tmp;
							ans%=mod;
						}
					}
				}
			}
		}
	}
	cout<<ans%mod<<endl;
	return 0;
}