#include <bits/stdc++.h>
using namespace std;
long long a,b,i;
int main()
{
	scanf("%lld %lld",&a,&b);
	if(b==1)
	printf("YES\n");
	else if(a==1) printf("YES\n");
	else if(a==2) printf("NO\n");
	else if(a==3)
	{
		if(a<=b)
		printf("NO\n");
		else
		printf("YES\n");
	}
	else
	{
		for(i=2;i<=sqrt(a);i++)
		{
			if(a%i==0)
			break;
		}
		if(i==(long long)sqrt(a)+1)
		i=a;
		if(i<=b)
		printf("NO\n");
		else
		printf("YES\n");
	}
	return 0;
}