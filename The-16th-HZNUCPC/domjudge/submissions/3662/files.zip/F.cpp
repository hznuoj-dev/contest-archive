#include "bits/stdc++.h"
using namespace std;

int main(){
	long long n,m;
	while(cin >> n >> m){
		if(n == 1 || m == 1){
			cout << "YES" << endl;
			continue;
		}
		m = n % m;
//		while(m > 1){
//			m = n % m;
//		}
		if(m == 1) cout << "YES" << endl;
		else puts("NO");
	}
	return 0;
}
