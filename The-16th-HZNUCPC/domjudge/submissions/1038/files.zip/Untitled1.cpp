#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,ans;
	cin>>n>>m;
	
	if(m==1){
		cout<<"YES"<<'\n';
		return 0;
	}
	ans=n%m;
	if(ans==0){
		cout<<"NO"<<'\n';
	}else{
		cout<<"YES"<<'\n';
	}
}