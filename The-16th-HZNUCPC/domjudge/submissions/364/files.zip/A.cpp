#include<bits/stdc++.h>
using namespace std;

#define int long long

const int N = 2e3 +10, inf = 1e17, mod = 1e9 +7;

int n, m, k, x, y, a[N][N], b[N];
char s[N], p[N];

int v[N];
struct S{
    int x,y,z;
    void input(){
        cin>>x>>y>>z;
    }
}c[N];
void run(){
    cin>>n;
    for(int i=1;i<=19;i++){
        for(int j=1;j<=19;j++){
            a[i][j]=0;
        }
    }
    for(int i=1;i<=n;i++){
        c[i].input();
        a[c[i].x][c[i].y]=1;
    }
    int ans=0;
    for(int i=1;i<=n;i++){
        if(c[i].z==2)continue;
        if(c[i].x+1<=19)ans+=(a[c[i].x+1][c[i].y]==0);
        if(c[i].y+1<=19)ans+=(a[c[i].x][c[i].y+1]==0);
        if(c[i].x-1>=1)ans+=(a[c[i].x-1][c[i].y]==0);
        if(c[i].y-1>=1)ans+=(a[c[i].x][c[i].y-1]==0);
    }
    cout<<ans<<'\n';
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int T;
    for(cin>>T;T>0;T--)
    run();return 0;
}
