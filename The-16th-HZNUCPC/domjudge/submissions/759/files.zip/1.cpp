#include<iostream>
#include<vector>
#define int long long
using namespace std;
struct node
{
	int x,y;
};
int gcd(int a,int b)
{
	return b ? gcd(b, a % b) : a;
}
bool check(node& a, node& b, node& c)
{
	return (c.y - a.y) * (b.x - a.x) == (b.y - a.y) * (c.x- a.x);
}
int solve(node& a, node& b)
{
	int kx = abs(a.x - b.x);
	int ky = abs(b.y - a.y);
	if(!kx) return ky;
	if(!ky) return kx;
	int d = gcd(kx,ky);
	kx /= d;
	return abs(a.x - b.x) / kx;
}
signed main()
{
	cin.tie(0);cout.tie(0);
	ios::sync_with_stdio(false);
	int n;
	cin>>n;
	vector<node> p(n);
	for(int i = 0;i<n;++i) cin>>p[i].x>>p[i].y;
	int res = 0;
	for(int i = 0;i<n;++i)
		for(int j = i + 1;j<n;++j)
			for(int k = j + 1;k<n;++k)
			{
				int r = 0;
				if(check(p[i],p[j],p[k])) continue;
				r += solve(p[i],p[j]);
				r += solve(p[j],p[k]);
				r += solve(p[k],p[i]);
				res = max(res, r);
			}
	cout << res;
}
