#include <bits/stdc++.h>

using namespace std;
using ll = long long;

bool check(ll n, ll m) {
	if (m == 1) return true;
//	cout << n << " " << m << endl;
	ll mod = n % m, div = n / m;
	ll mx_num = mod * (div + 1), mi_num = n - mx_num;
	assert(mx_num != mi_num);
	if (mod == 0) return false;
	else if (mx_num > mi_num) return check(n, mod);
	else return check(n, m - mod);
}
void solve() {
	ll n, m;
	scanf("%lld%lld", &n, &m);
	if (check(n, m)) puts("YES");
	else puts("NO");
}
int main() {
	solve();
	return 0;
}