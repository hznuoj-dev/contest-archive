#include<bits/stdc++.h>

#define all(a) a.begin(),a.end()
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define pb push_back
#define fi first
#define se second
#define quick ios.sync_with_stdio(false);cout.tie(0);cin.tie(0);
#define PLL pair<ll,ll>

typedef long long ll;
typedef unsigned long long ull;

using namespace std;

ll n,m;

int mp[111][111];

void solve(){
	rep(i,0,111)rep(j,0,111)mp[i][j]=0;
	cin>>n;
	vector<PLL>a;
	rep(i,0,n){
		ll x,y;cin>>x>>y;
		a.pb({x,y});
	}
	rep(i,0,n){
		rep(j,i+1,n){
			ll difx=abs(a[i].fi-a[j].fi);
			ll dify=abs(a[i].se-a[j].se);
			ll num=0;
			if(difx==0)num=dify-1;
			else if(dify==0)num=difx-1;
			else num=__gcd(difx,dify)-1;
			mp[i][j]=num;
		}
	}
	ll ans=-1;
	rep(i,0,n){
		rep(j,i+1,n){
			rep(k,j+1,n){
//				if((a[i].fi==a[j].fi&&a[i].fi==a[k].fi)||(a[i].se==a[j].se&&a[i].se==a[k].se))continue;
				ll difx=a[i].fi-a[j].fi;
				ll dify=a[i].se-a[j].se;
				ll difx2=a[i].fi-a[k].fi;
				ll dify2=a[i].se-a[k].se;
				if(difx*dify2==difx2*dify)continue;
				ans=max(ans, 3ll+mp[i][j]+mp[i][k]+mp[j][k]);
			}
		}
	}
	if(ans==-1)cout<<"0"<<endl;
	else cout<<ans<<endl;
}

int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
