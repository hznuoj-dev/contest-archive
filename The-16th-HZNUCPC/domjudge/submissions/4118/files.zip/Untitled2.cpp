#include<bits/stdc++.h>
using namespace std;
signed main(){
	cout<<"Hello World\n";
	return 0;
}