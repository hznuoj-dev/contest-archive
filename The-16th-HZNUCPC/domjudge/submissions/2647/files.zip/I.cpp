#include<bits/stdc++.h>
using namespace std;
int n;
string s;
int main() {
	int T;
	scanf("%d", &T);
	while(T--) {
		cin>>s;
		n = s.size();
		int ans = 0;
		for (int i = 0; i < n; i++) {
//		cout<<i<<" "<<ans<<endl;
			int l1 = i - 1, r1 = i + 1, len1 = 1;
			while(l1 >= 0 && r1 < n && s[l1] == s[r1])l1--, r1++, len1 += 2;//find first wrong
			if(l1 < 0 || r1 >= n) { //no wrong     aba
				ans = max(ans, len1);
//				cout<<len1<<endl;
				continue;
			}

			int l2 = l1 - 1, r2 = r1 + 1, len2 = 0;
			while(l2 >= 0 && r2 < n && s[l2] == s[r2])l2--, r2++, len2 += 2;//find second wrong

			if(l2 < 0 || r2 >= n) { //no second wrong     ad abbbc da
				ans = max(ans, len1);
				if(s[l1] == s[i] || s[r1] == s[i])
					ans = max(ans, len1 + 2 + len2);
				for (int j = r2 - 1; j > r1; j--) {
					int R = j, L = l2 + (r2 - j);
					if(s[R] == s[l1] || s[L] == s[l1] || s[R] == s[r1] || s[L] == s[r1]) {
						ans = max(ans, len1 + 2 + 2 * (j - r1 - 1));
						break;
					}
				}
				continue;
			}
			//l2  l1  r1  r2
			if((s[l1] == s[r2] && s[l2] == s[r1]) || (s[l1] == s[l2] && s[r2] == s[r1])) {
				int l3 = l2 - 1, r3 = r2 + 1, len3 = 0;
				while(l3 >= 0 && r3 < n && s[l3] == s[r3])l3--, r3++, len3 += 2;//find third wrong
				ans = max(ans, len1 + 2 + len2 + 2 + len3);
				continue;
			}
//puts("!!!");
//cout<<l2<<" "<<l1<<" "<<r1<<" "<<r2<<endl;
			ans = max(ans, len1);
			if(s[l1] == s[i] || s[r1] == s[i])
				ans = max(ans, len1 + 2 + len2);
			for (int j = r2 - 1; j > r1; j--) {
				int R = j, L = l2 + (r2 - j);
				if(s[R] == s[l1] || s[L] == s[l1] || s[R] == s[r1] || s[L] == s[r1]) {
					ans = max(ans, len1 + 2 + 2 * (j - r1 - 1));
					break;
				}
			}
		}
		
		
		for (int i = 0; i < n - 1; i++) {
			int l1 = i, r1 = i + 1, len1 = 0;
			while(l1 >= 0 && r1 < n && s[l1] == s[r1])l1--, r1++, len1 += 2;//find first wrong
			if(l1 < 0 || r1 >= n) { //no wrong     aba
				ans = max(ans, len1);
//				cout<<len1<<endl;
				continue;
			}

			int l2 = l1 - 1, r2 = r1 + 1, len2 = 0;
			while(l2 >= 0 && r2 < n && s[l2] == s[r2])l2--, r2++, len2 += 2;//find second wrong

			if(l2 < 0 || r2 >= n) { //no second wrong     ad abbbc da
				ans = max(ans, len1);
				for (int j = r2 - 1; j > r1; j--) {
					int R = j, L = l2 + (r2 - j);
					if(s[R] == s[l1] || s[L] == s[l1] || s[R] == s[r1] || s[L] == s[r1]) {
						ans = max(ans, len1 + 2 + 2 * (j - r1 - 1));
						break;
					}
				}
				continue;
			}

			//l2  l1  r1  r2
			if((s[l1] == s[r2] && s[l2] == s[r1]) || (s[l1] == s[l2] && s[r2] == s[r1])) {
				int l3 = l2 - 1, r3 = r2 + 1, len3 = 0;
				while(l3 >= 0 && r3 < n && s[l3] == s[r3])l3--, r3++, len3 += 2;//find third wrong
				ans = max(ans, len1 + 2 + len2 + 2 + len3);
				continue;
			}
			ans = max(ans, len1);
			for (int j = r2 - 1; j > r1; j--) {
				int R = j, L = l2 + (r2 - j);
				if(s[R] == s[l1] || s[L] == s[l1] || s[R] == s[r1] || s[L] == s[r1]) {
					ans = max(ans, len1 + 2 + 2 * (j - r1 - 1));
					break;
				}
			}
		}
		if(ans > 1)
		cout<<ans<<endl;
		else cout<<"0"<<endl;
	}
}