def tan(x,y):
    if pan[x][y]==0:
        return True
    a=3-pan[x][y]
    if x!=0 :
        if pan[x-1][y]!=a:
            return True
    if x!=18 :
        if pan[x+1][y]!=a:
            return True
    if y!=0 :
        if pan[x][y-1]!=a:
            return True
    if y!=18 :
        if pan[x][y+1]!=a:
            return True
    return False

def kong(x,y):
    k=0
    if x!=0 :
        if  pan[x-1][y]==0 and flag[x-1][y]:
            flag[x-1][y]=False
            k+=1
    if x!=18 :
        if pan[x+1][y]==0 and flag[x+1][y]:
            flag[x+1][y]=False
            k+=1
    if y!=0 :
        if pan[x][y-1]==0 and flag[x][y-1]:
            flag[x][y-1]=False
            k+=1
    if y!=18 :
        if  pan[x][y+1]==0 and flag[x][y+1]:
            flag[x][y+1]=False
            k+=1
    return k

n=int(input())
max=[]
pan=[[0]*19 for i in range(19)]
for _ in range(n):
    flag=[[True]*19 for i in range(19)]
    m=int(input())
    chess=[[]for _ in range(m)]
    for i in range(m):
        chess[i]=list(map(int,input().split()))
    for i in range(len(chess)):
        x=chess[i][0]
        y=chess[i][1]
        pan[x][y]=chess[i][2]
        if x!=0 :
            if not(tan(x-1,y)):
                pan[x-1][y]=0
        if y!=0 :
            if not(tan(x,y-1)):
                pan[x][y-1]=0
        if y!=18 :
            if not(tan(x,y+1)):
                pan[x][y+1]=0
        if x!=18 :
            if not(tan(x+1,y)):
                pan[x+1][y]=0
    max_m=0
    for x in range(19):
        for y in range(19):
            if pan[x][y]==1:
                max_m+=kong(x,y)
    max.append(max_m)
for i in range(len(max)):
    print(max[i])