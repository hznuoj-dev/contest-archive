#include<bits/stdc++.h>
using namespace std;

int main()
{
	long long n,m;
	cin>>n>>m;
	if(m==1)
	{
		cout<<"YES"<<"\n";
		return 0;
	}
	long long temp;
	while (true)
	{
		temp = n%m;
		if (temp == 1){
			cout<<"YES"<<"\n";
			return 0;
		}
		if(temp == 0){
			cout<<"NO"<<"\n";
			return 0;
		}
		m  = temp;
	}
	return 0;
}