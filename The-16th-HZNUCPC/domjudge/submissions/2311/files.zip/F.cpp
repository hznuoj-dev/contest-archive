#include<bits/stdc++.h>
using namespace std;

long long n,m;


int main()
{
	
	cin >> n >> m;
	
	if (m == 1||n==1) {
		cout << "YES";
		return 0;
	}
	while (n % m) {
		m = n % m;
		if (m == 1) {
			cout << "YES";
			return 0;
		}
	}
	
	cout << "NO" << endl;
	
	return 0;
}