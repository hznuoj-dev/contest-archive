
#include<bits/stdc++.h>
using namespace std;

#define int long long
signed main(){
	int n, m;
	while(cin >> n >> m){
		if(m == 1) cout <<"YES\n";
		else{
			if(n <= m) {
				if(n == 1) cout <<"YES\n";
				else cout << "NO\n";
			}
			else {
				if(n %m == 0) cout <<"NO\n";
				else cout <<"YES\n";
			}
		}
		
	}
	return 0;
}