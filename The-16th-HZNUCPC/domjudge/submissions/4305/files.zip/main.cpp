#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	
	verctor<char>b[n];
	verctor<char>a[n];
	cin>>a;
	cin>>b;
	int s[];
	int q[];
	int c[26];
	int f[26];
	int r;
	int l;
	int z;
	int k=a.len();
	for(i=1;i<=k;i++){
		s[i]=a[i]-'a'+1;
		q[i]=b[i]-'a'+1;
	}
			
	for(i=1;i<=k;i++){
		r=s[i];
		s[i]=q[i];
		q[i]=r;	
		for(j=1;j<=k;j++){	
			l=s[i];
			s[i]=q[i];
			q[i]=l;		
			for(d=1;d<=k;d++){
				c[a[d]]++;
				f[b[d]]++;
			}	
			for(d=1;d<+k;d++){
				if(c[d]==f[d]){t=1;
				}
				else {
				t=0;break;}
				if(t==1)z++;
			}
		
		
		
		
		
		
	 }
	}
	
	count<<z;
	
	
	
	
	
	
	return 0;
}