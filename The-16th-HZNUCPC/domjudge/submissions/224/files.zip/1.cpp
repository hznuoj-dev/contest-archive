#include<bits/stdc++.h>
using namespace std;
#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const int maxn=2e5+10;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;

int mp[21][21];
int vis[21][21];
void resolve(){
	int n;cin>>n;
	memset(mp,0,sizeof mp);
	memset(vis,0,sizeof vis);
	for(int i=1;i<=n;i++){
		int x,y,z;cin>>x>>y>>z;
		mp[x][y]=z;
	}
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(mp[i][j]==0||mp[i][j]==2)continue;
			else if(mp[i][j]==1){
				if(i-1>=1&&mp[i-1][j]==0)vis[i-1][j]++;
				if(i+1<=19&&mp[i+1][j]==0)vis[i+1][j]++;
				if(j-1>=1&&mp[i][j-1]==0)vis[i][j-1]++;
				if(j+1<=19&&mp[i][j+1]==0)vis[i][j+1]++;
			}
		}			
	}
	int ans=0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			ans+=vis[i][j];
		}
	}
	cout<<ans<<endl;
}
signed main(){
	fast;
	int _=1;
	cin>>_;
	while(_--){
		resolve();
	}
}