#include<bits/stdc++.h>

#define all(a) a.begin(),a.end()
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define pb push_back
#define fi first
#define se second
#define quick ios.sync_with_stdio(false);cout.tie(0);cin.tie(0);

typedef long long ll;
typedef unsigned long long ull;
//typedef pair<ll,ll> PLL;

using namespace std;

ll n,m;

void solve(){
	cin>>n>>m;
	if(m == 1){
		cout<<"YES\n";
		return ;
	}
	if(m>=n || n%m == 0){
		cout<<"NO\n";
		return ;
	}else{
		if(__gcd(n,m) == 1){
			cout<<"YES\n";
		}else{
			cout<<"NO\n";
		}
	}
	
}

int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
