#include <stdio.h>

int main(){
	long long  n,m;
	scanf("%lld%lld",&n,&m);
	if(m==1){
		printf("YES");
		return 0;
	}
	if(n<=m){
		printf("NO");
		return 0;
	}
	if(n%m==0){
		printf("NO");
		return 0;
	}

	int i=2;
	int a,b;
	for(;i<n/2;i++){
	a=n/i;
		b=n-i*a;
//		printf("%d %d\n",a,b);
		if(b < a){
			if (n%i==0){
				printf("NO");
				return 0;
		}
	}
}
printf("YES");
}