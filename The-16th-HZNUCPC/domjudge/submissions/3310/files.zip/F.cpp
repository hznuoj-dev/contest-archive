#include <bits/stdc++.h>
using namespace std;

int main()
{	
	long long n,m;
	cin>>n>>m;
	
	

	
	if (n==1||m==1)
	{
		printf("YES");
		return 0;
	}	
	
	if (n%2+m%2==0)
	{	printf("NO");
		return 0;
	}
	
	if (n<=m)
	{
		printf("NO");
		return 0;
	}
	
	if (n%2==0)
	{
		printf("NO");
		return 0;
	}
	
	while (m>1)//当被评分者仍大于1个
	{	m=n%m;
		
		if (n<=m)
		{
			printf("NO");
			return 0;
		}	
	
		if (n%2+m%2==0)
		{	
			printf("NO");
			return 0;
		}	
	}
	
	if (m==0)
		printf("NO");
	else
		printf("YES");
	
	return 0;
}