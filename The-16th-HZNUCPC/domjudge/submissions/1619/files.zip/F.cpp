#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>

using namespace std;

typedef long long LL;

int solve(int n,int m){
	int a,b;
	b = n%m;
	if(b==0||b==1){
		return b;
	}
	else{
		return solve(n,b);
	}

}

int main()
{
	LL n, m;
	cin >> n >> m;
	if(n==1||m==1){
		cout<<"YES"<<endl;
		return 0;
	}
	if(n<=m){
		cout<<"NO"<<endl;
		return 0;
	}
	int sign;
	sign = solve(n,m);
	if(sign==0){
		cout<<"NO"<<endl;
	}
	else{
		cout<<"YES"<<endl;
	}
	return 0;
}
