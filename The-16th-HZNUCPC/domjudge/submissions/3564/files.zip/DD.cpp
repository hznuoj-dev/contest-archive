#include <bits/stdc++.h>
#define ll int
#define Ma 1000005
#define mod 1000000007
#define N 26
#define PLL pair<ll,ll>
#define ls p<<1
#define rs p<<1|1
#define inf 1e9

using namespace std;

ll n,m,x;

struct node{
	ll ti,l,r,num;
	bool operator <(const node &A)const{
		if (ti==A.ti)
		{
			if (num==A.num)
				return l<A.l;
			return num<A.num;
		}
		return ti>A.ti;
	}
}a[Ma];
ll tot=0,cnt=0;
ll p[Ma];

struct segtree
{
	ll l,r,ma,add;
}t[Ma<<2];


void build(ll p,ll l,ll r)
{
	t[p].l=l,t[p].r=r;
	if (l==r)
		return;
	ll mid=(l+r)>>1;
	build(ls,l,mid),build(rs,mid+1,r);
	return;
}

void spread(ll p)
{
	if (t[p].add)
	{
		t[ls].ma=max(t[ls].ma,t[p].add);
		t[rs].ma=max(t[rs].ma,t[p].add);
		t[ls].add=max(t[ls].add,t[p].add);
		t[rs].add=max(t[rs].add,t[p].add);
		t[p].add=0;
	}
	return;
}

void up(ll p)
{
	t[p].ma=max(t[ls].ma,t[rs].ma);
	return;
}

void change(ll p,ll l,ll r,ll d)
{
	if (l>r)
		return;
	if (l<=t[p].l&&t[p].r<=r)
	{
		t[p].ma=max(t[p].ma,d);
		t[p].add=max(t[p].add,d);
		return;
	}
	spread(p);
	ll mid=(t[p].l+t[p].r)>>1;
	if (l<=mid) change(ls,l,r,d);
	if (r>mid) change(rs,l,r,d);
	up(p);
	return;
}

ll ask(ll p,ll l,ll r)
{
	if (l<=t[p].l&&t[p].r<=r) return t[p].ma;
	spread(p);
	ll mid=(t[p].l+t[p].r)>>1;
	ll val=0;
	if (l<=mid) val=max(val,ask(ls,l,r));
	if (r>mid) val=max(val,ask(rs,l,r));
	return val;
}

ll ans[Ma];

void sol()
{
	scanf("%d%d%d",&n,&m,&x);
	for (ll i=1;i<=n;i++)
	{
		tot++,scanf("%d%d%d",&a[tot].ti,&a[tot].l,&a[tot].r);
		a[tot].l=x-a[tot].l,a[tot].r=x-a[tot].r;
		swap(a[tot].l,a[tot].r);
	}
	for (ll i=1;i<=m;i++)
	{
		tot++,scanf("%d%d",&a[tot].ti,&a[tot].l),a[tot].r=a[tot].l,a[tot].num=i;
		a[tot].l=x-a[tot].l,a[tot].r=x-a[tot].r;
		swap(a[tot].l,a[tot].r);
	}
	sort(a+1,a+tot+1);
	build(1,0,n);
	for (ll i=1;i<=tot;i++)
	{
		if (!a[i].num)
		{
			ll l=0,r=n;
			while (l<=r)
			{
				ll mid=(l+r)>>1;
				if (ask(1,0,mid)<a[i].l)
					l=mid+1;
				else
					r=mid-1;
			}// ok-l
			change(1,l+1,n,a[i].r);
		}
		else
		{
			ll l=0,r=n;
			while (l<=r)
			{
				ll mid=(l+r)>>1;
				if (ask(1,0,mid)<a[i].l)
					l=mid+1;
				else
					r=mid-1;
			}// ok-l
			if (l==n+1)
				ans[a[i].num]=-1;
			else
				ans[a[i].num]=l;
		}
	}
	for (ll i=1;i<=m;i++)
		printf("%d\n",ans[i]);
	
	return;
}


int main()
{
	sol();
	return 0;
}