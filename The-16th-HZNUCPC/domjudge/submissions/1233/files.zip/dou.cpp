#include<bits/stdc++.h>
using namespace std;
int sum,n,m,flag=0,t,a,b,c;
int  mp[400][400];
int dir[][2]={0,1,0,-1,1,0,-1,0};
int main()
{
	cin>>t;
	while(t--)
	{
		cin>>n;
		sum=0;
		memset(mp,0,sizeof(mp));
		for(int i=1;i<=n;i++)
		{
			cin>>a>>b>>c;
			mp[a][b]=c;
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(mp[i][j]==0||mp[i][j]==2)
					continue;
				int flag=0;
				for(int z=0;z<4;z++)
				{
					int dx=i+dir[z][0];
					int dy=j+dir[z][1];
					if(dx<1||dy<1||dx>19||dy>19)
						continue;
					if(mp[dx][dy]==0)
					{
						sum++;
					}
				}
			}
		}
		cout<<sum<<endl;
	}
	return 0;
}