#include<bits/stdc++.h>
using namespace std;

#define int long long

const int N = 1e5 +10, inf = 1e17, mod = 1e9 +7;

int n, m, k, x, y, a[N], b[N];
char s[N], p[N];

int st[N];
vector<int>G1[N],G2[N];

int dfs(int u,int v,int w){
    st[u]=w;
    for(int i:G1[u]){
        if(st[i]!=0){
            if(st[i]!=1-w){
                return 0;
            }
            continue;
        }
        return dfs(i,u,w==1?0:1);
    }
    for(int i:G2[u]){
        if(st[i]!=0){
            if(st[i]!=w){
                return 0;
            }
            continue;
        }
        return dfs(i,u,w==1?1:0);
    }
}

int ok(int x,int y){
    memset(st,0,sizeof st);
    st[y]=x;
    return dfs(y,0,x);
}
void run(){
    cin>>n>>m;
    for(int i=1;i<=m;i++){
        cin>>k>>x>>y;
        if(k==1){
            G1[x].push_back(y);
        }
        else{
            G2[x].push_back(y);
        }
    }

    for(int i=1;i<=n;i++){
        if(st[i])continue;
        if(ok(1,i)){

            continue;
        }
        else if(ok(0,i)){

            continue;
        }
        cout<<"NO\n";
            return;
    }
    cout<<"YES\n";
    for(int i=1;i<=n;i++){
        if(st[i]==2){
            cout<<i<<" \n"[i==n];
        }
    }
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int T;
    //for(cin>>T;T>0;T--)
    run();return 0;
}
//uM8Z0uwWsZ2O
