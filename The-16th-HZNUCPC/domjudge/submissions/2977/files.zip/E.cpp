#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 1e5 + 10;
const double PI = acos(-1);
struct ty {
	ll x, y;
} a[105];
ll b[105][105];
ll gcd(ll a, ll b) {
	if (a % b == 0) return b;
	else return (b, a % b);
}
void solve() {
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++) cin >> a[i].x >> a[i].y;
	ll ans = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			ll dy = abs(a[j].y - a[i].y), dx = abs(a[j].x - a[i].x);
			if (dx == 0) {
				b[i][j] = max(0LL, dy - 1);
				b[j][i] = max(0LL, dy - 1);
			} else if (dy == 0) {
				b[i][j] = max(0LL, dx - 1);
				b[j][i] = max(0LL, dx - 1);
			}
			else {
				b[i][j] = gcd(max(dx, dy), min(dx, dy)) - 1;
				b[j][i] = gcd(max(dx, dy), min(dx, dy)) - 1;
			}
		}
	}
//	for (int i = 1; i <= n; i++) {
//		for (int j = 1; j <= n; j++) {
//			cout << b[i][j] << " ";
//		}
//		cout << "\n";
//	}
	for (int i = 1; i <= n; i++) {
		for (int j = 1; j <= n; j++) {
			for (int k = 1; k <= n; k++) {
				double l1 = sqrt(pow(a[i].x - a[j].x, 2) + pow(a[i].y - a[j].y, 2));
				double l2 = sqrt(pow(a[j].x - a[k].x, 2) + pow(a[j].y - a[k].y, 2));
				double l3 = sqrt(pow(a[i].x - a[k].x, 2) + pow(a[i].y - a[k].y, 2));
				if (l1 + l2 + l3 - max(l1, max(l2, l3)) <= max(l1, max(l2, l3))) {
					if (ans == 0) ans = -1;
				} else ans = max(ans, b[i][j] + b[j][k] + b[k][i]);
//				cout << i << " " << j << " " << k << " " << l1 << " " << l2 << " " << l3 << "\n";
			}
		}
	}
	if (ans != -1) cout << ans + 3;
	else cout << "0";
}
int main() {
	solve();
	return 0;
}