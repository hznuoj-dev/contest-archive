#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
typedef long long ll;
using namespace std;
int fa[100005],w[100005];
inline int find(int x){return fa[x]==x?x:fa[x]=find(fa[x]);}
int n,q,m,s[5];
int sk[100005],sa[100005],sb[100005];
vector<int> to[100005];
int vis[100005],vis2[100005];
int flag=0;
void dfs(int x){
//	printf("%d\n",x);
	s[vis[x]]+=w[x];
	for(int i=0;i<to[x].size();i++){
		int y=to[x][i];
		if(vis[y]){
			if(vis[y]==vis[x]) flag=1;
		}else{
			vis[y]=vis[x]^3;
			dfs(y);
		}
	}
}
int sum;
vector<int> ds,gs,as;
namespace bb {
	const int N=1e5+10;
	int n,m,f[N],l1[N],l2[N];
	vector<int>t[N];
	int lst[N];
	void trans(int w,int c) {
		For(i,0,w-1) lst[i]=-1e9;
		For(i,0,m) {
			if(!f[i]) {
				int l=lst[i%w];
				if(i-l<=w*c) {
					f[i]=1;
					l1[i]=w; l2[i]=(i-l)/w;
				}
			} else lst[i%w]=i;
		}
	}
	vector<int> work(int _n,int _m,int *a) {
		n=_n; m=_m;
		For(i,0,n-1) t[a[i]].push_back(i);
		f[0]=1;
		For(i,1,m) if(t[i].size()) {
			trans(i,t[i].size());
		}
		if(!f[m]) return {-1};
		int x=m; vector<int>ans;
		while(x) {
			For(j,0,l2[x]-1) ans.push_back(t[l1[x]][j]);
			x-=l1[x]*l2[x];
		}
		return ans;
	}
}
vector<int> t;
int ton[100005],tton[100005];
vector<int> tans,dans;
void dfs2(int x,int w){
	//printf("sq %d %d %d\n",x,vis[x],w);
	vis2[x]=1;
	if(vis[x]==w) tton[x]=1;//printf("aq %d\n",x);
	for(int i=0;i<to[x].size();i++){
		int y=to[x][i];
		if(!vis2[y]) vis2[y]=1,dfs2(y,w);
	}
}
signed main() {
    ios::sync_with_stdio(0); cin.tie(0);
    cin>>n>>q>>m;
    for(int i=1;i<=n;i++) fa[i]=i,w[i]=1;
    for(int i=1;i<=m;i++) cin>>sk[i]>>sa[i]>>sb[i];
    for(int i=1;i<=m;i++) if(!sk[i]) w[find(sb[i])]+=w[find(sa[i])],fa[find(sa[i])]=find(sb[i]);
    for(int i=1;i<=m;i++) if(sk[i]) to[find(sa[i])].push_back(find(sb[i])),to[find(sb[i])].push_back(find(sa[i]));
    for(int i=1;i<=n;i++) if(find(i)==i&&!vis[i]){
    	vis[i]=1;s[1]=0,s[2]=0;
//    	puts("QWQ");
    	dfs(i);
//    	printf("%d %d\n",s[1],s[2]);
    	if(flag) return puts("NO"),0;
    	sum+=min(s[1],s[2]);
    	t.push_back(max(s[2],s[1])-min(s[2],s[1]));
	}
	q-=sum;
//	printf("%d\n",q);
//	for(int i=0;i<t.size();i++) printf("%d ",t[i]);puts("");
	as=bb::work(t.size(),q,t.data());
	if(as.size()&&as[0]==-1) return puts("NO"),0;
	puts("YES");
	for(int i=0;i<as.size();i++){
		ton[t[as[i]]]++;
	}
	memset(vis,0,sizeof(vis));
	for(int i=1;i<=n;i++) if(find(i)==i&&!vis[i]){
    	vis[i]=1;s[1]=0,s[2]=0;
    	dfs(i);
    	int flag;
    	if(!ton[max(s[2],s[1])-min(s[2],s[1])]) flag=(s[1]<s[2]?1:2);
    	else{
    		ton[max(s[2],s[1])-min(s[2],s[1])]--;
    		flag=(s[1]>s[2]?1:2);
		}
    	dfs2(i,flag);
	}
	for(int i=1;i<=n;i++) if(tton[find(i)]) printf("%d ",i);
}
