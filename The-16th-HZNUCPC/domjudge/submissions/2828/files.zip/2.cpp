#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef unsigned long long int ull;
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
#define INF 0x7fffffff
#define mem 0x7f
#define int long long
int x[101],y[101];
int maxans=0;
bool check(int i,int j,int k)
{
	ll k1=(x[i]-x[j])*(y[i]-y[k]);
	ll k2=(x[i]-x[k])*(y[i]-y[j]);
	if(k1==k2){return true;
	}
	
	return false;
}
int gcd(int a,int b){
	return !b?a:gcd(b,a%b);
}
int nu(int a,int b){
	int xx=abs(x[a]-x[b]),yy=abs(y[a]-y[b]);
	
	if(xx==0)return yy-1;
	if(yy==0)return xx-1;
	return gcd(xx,yy)-1;
}
void solve(){
	int n;cin>>n;
	for(int i=1;i<=n;i++)cin>>x[i]>>y[i];
	for(int i=1;i<=n;i++)
	for(int j=i+1;j<=n;j++)
	for(int k=j+1;k<=n;k++)//three points
	{
		if(check(i,j,k)==true)
		continue;
		maxans=max(maxans,nu(i,j)+nu(j,k)+nu(k,i)+3);
		//cout<<nu(i,j)<<" "<<nu(j,k)<<" "<<nu(k,i)<<endl;
	}
	cout<<maxans<<endl;
}

signed main()
{
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	//int t;cin >> t;while(t--)
	solve();
	getchar();
	return 0;
}