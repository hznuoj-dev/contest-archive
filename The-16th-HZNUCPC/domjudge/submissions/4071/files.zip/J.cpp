#include <bits/stdc++.h>
using namespace std;
const double eps = 1e-6;
int n, m;
struct _ {
	int u, v, w;
} E[100010];
int F[100010];
int Cnt[100010];

int Find(int x) {
	return x == F[x] ? x : F[x] = Find(F[x]);
}

int main() {
	ios::sync_with_stdio(false);
	srand(time(0));
	double st = clock();
	cin >> n >> m;
	for (int i = 1; i <= m; i++) {
		cin >> E[i].u >> E[i].v >> E[i].w;
	}
	
	int Ans = 0;
	while (true) {
		random_shuffle(E + 1, E + 1 + m);
		memset(Cnt, 0, sizeof Cnt);
		for (int i = 1; i <= n; i++) F[i] = i;
		for (int i = 1; i <= m; i++) {
			int u, v;
			u = Find(E[i].u);
			v = Find(E[i].v);
			if (u != v) {
				F[u] = F[v];
				Cnt[E[i].w]++;
			}
		}
		for (int i = 0; i <= n; i++) {
			if (Cnt[i] == 0) {
				Ans = max(Ans, i);
				goto nxt;
			}
		}
		nxt:;
		if (clock() - st >= 960) break;
	}
	cout << Ans << endl;
	return 0;
}
