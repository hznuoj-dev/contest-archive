#include <bits/stdc++.h>
using namespace std;
  int a[22][22];
  int color,x,y;
  int cnt = 0 ;
  int movex[]={1,-1,0,0};
  int movey[]={0,0,1,-1};
int main(){
    for(int i = 0 ; i <= 20 ;i++){
             for(int j = 0  ; j <=20;j++){
                 a[i][j] = 3 ;
             }
         }
    int t ;
    cin >> t;
    while (t--){
        int n;
         cin >> n;
         cnt = 0 ;
         for(int i = 1 ; i <= 19 ;i++){
             for(int j = 1  ; j <=19;j++){
                 a[i][j] = 0 ;
             }
         }
        for(int i = 1 ; i <= n;i++){
            cin >> x >> y; 
            cin >> a[x] [y];  
        }
        for(int i = 1 ; i <= 19 ;i++){
            for(int j =  1  ; j <=19;j++){
                if(a[i][j] == 1){
                    for(int k = 0 ; k <4;k++){
                        if(a[i+movex[k]][j+movey[k]]==0){
                        //	cout << x+movex[k]<<" " << y + movey[k] << " ";
                            cnt++;
                        }
                    }
                }
            }
        }
        cout << cnt;
    }
}