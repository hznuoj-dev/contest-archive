#include <bits/stdc++.h>

using namespace std;
using ll=long long;
ll st[3];

int main(){
	ll x[101]{0},y[101]{0};
	ll n;
	cin>>n;
	ll sum=0,ans=0;
	for(int i=0;i<n;i++)cin>>x[i]>>y[i];
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			for(int k=j+1;k<n;k++){
				ll x1_=x[j]-x[i],y1_=y[j]-y[i],x2_=x[k]-x[i],y2_=y[k]-y[i];
				if(abs(x1_*y2_-x2_*y1_)==0)continue;
				ll a=__gcd(abs(x[j]-x[i]),abs(y[j]-y[i]));
				ll b=__gcd(abs(x[k]-x[i]),abs(y[k]-y[i]));
				ll c=__gcd(abs(x[j]-x[k]),abs(y[j]-y[k]));
				ans=max(ans,a+b+c);
			}
		} 
	}
	cout<<ans;
	return 0;
}