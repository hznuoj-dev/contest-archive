#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
const ll N=1005;
ll n,m;
bool car(ll x,ll y)
{
    if(y==1)return 1;
    if(y==0)return 0;
    if(x<=y)return 0;
    return car(x,x%y);
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>n>>m;
    if(m==1)cout<<"YES";
    else if(n==1)cout<<"YES";
    else if(n<=m)cout<<"NO";
    else
    {
        if(car(n,m))cout<<"YES";
        else cout<<"NO";
    }
    return 0;
}
