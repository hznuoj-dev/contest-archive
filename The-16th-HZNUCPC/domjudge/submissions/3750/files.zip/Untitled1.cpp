#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5,M=N<<1;
int tot,head[N],vet[M],Next[M],val[M];
void add(int x,int y,int z){
	tot++;
	vet[tot]=y;
	val[tot]=z;
	Next[tot]=head[x];
	head[x]=tot;
}
bool vis[N];
int sta[N],flag;
vector<int>idx[N];
int n,Q,m,cnt,num,a[M],f[N],g[N],ans[N],cur,pre[M],tag[M];
void dfs(int u,int cc){
	vis[u]=true;
	idx[num].push_back(u);
	for(int i=head[u];i;i=Next[i]){
		int v=vet[i],tmp;
//		printf("%d %d\n",cc,i); 
		if(i==(cc^1))continue;
		//
		if(sta[u])tmp=val[i];else tmp=!val[i];
//		printf("%d\n",sta[v]);
		if(sta[v]==-1){
			sta[v]=tmp;
			cnt+=tmp;
		}
	//	printf("tmp=%d sta[v]%d\n",tmp,sta[v]);
		if(sta[v]!=tmp){flag=false;return;}
		if(!vis[v])dfs(v,i);
		if(!flag)return;
	}
}
int peo[N][2],Big[N],Bigvalue[N];
int pre1[N],pre2[N];
vector<int>Clo[N];
int Part[405],Need[N];
int main(){
	scanf("%d%d%d",&n,&Q,&m);
	memset(sta,-1,sizeof(sta));
	memset(vis,false,sizeof(vis));
	tot=1;
	for(int i=1;i<=m;i++){
		int k,x,y;scanf("%d%d%d",&k,&x,&y);
		add(x,y,!k),add(y,x,!k);
//		printf("%d ",head[x]);
	}
	flag=true;
	for(int i=1;i<=n;i++)
		if(!vis[i]){
		//	printf("%d\n",i);
			sta[i]=cnt=1;
			++num;
			dfs(i,0);
			a[num]=cnt;
			if(!flag)break;
		}
//	puts("fjdsk");
//	for(int i=1;i<=n;i++)printf("%d ",sta[i]);puts("");
	if(!flag){puts("NO");return 0;}	
//	for(int i=1;i<=num;i++)printf("%d %d    ",a[i],idx[i].size()-a[i]);puts("");
	int Bas=0;
	for(int i=1;i<=num;i++){
		peo[i][0]=a[i],peo[i][1]=idx[i].size()-a[i];
		if(peo[i][0]>=peo[i][1])Big[i]=1;
		else Big[i]=0;
		Bigvalue[i]=abs(peo[i][0]-peo[i][1]);	
		Bas+=min(peo[i][0],peo[i][1]);
	}
	Q-=Bas;
	f[0]=1;
	for(int i=1;i<=num;i++){
		if(Bigvalue[i]==0)continue;
		if(Bigvalue[i]<=400)Part[Bigvalue[i]]++;
		else {
			for(int j=Q;j>=Bigvalue[i];j--)
				if(f[j-Bigvalue[i]])f[j]=1,pre1[j]=Bigvalue[i],pre2[j]=1;
		}
	}
	for(int i=1;i<=400;i++){
		int tmp=Part[i];
		int x=1;
		while(tmp){
			if(tmp&1){
				for(int j=Q;j>=x*i;j--){
					if(f[j-x*i])f[j]=1,pre1[j]=x*i,pre2[j]=x;
				}
			}
			tmp>>=1;
			x*=2;
		}
	}
	if(!f[Q])puts("NO");
	else{
		int res=Q;
		while(res){
			//printf("%d ",id);
			Need[pre1[res]/pre2[res]]+=pre2[res];
			res-=pre1[res];
		}
//		for(int i=1;i<=10;i++){
//			printf("%d ",Need[i]);
//		}
//		puts("!!");
		for(int i=1;i<=num;i++){
			if(Need[Bigvalue[i]]){
				Need[Bigvalue[i]]--;
				for(int j=0;j<idx[i].size();j++){
					int u=idx[i][j];
					if(sta[u]==Big[i])ans[++cur]=u;
				}
			}
			else {
				for(int j=0;j<idx[i].size();j++){
					int u=idx[i][j];
					if(sta[u]==1-Big[i])ans[++cur]=u;
				}
			} 
		}
		sort(ans+1,ans+cur+1);
		puts("YES");
		for(int i=1;i<=cur;i++)printf("%d ",ans[i]);
	}
	return 0;
}
/*
2 2 1
0 1 2

13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13
1 1 1 1 1 0 0 1 1 1 1 1 0 NO
*/