#include<bits/stdc++.h>
#define int long long
#define PII pair<int,int>
using namespace std;
void solve()
{
	long long n,m;
	cin>>n>>m;
	if(n==1||m==1)
	{
		cout<<"YES"<<endl;
		return;
	}
	if(m>=n)
	{
		cout<<"NO"<<endl;
		return;
	}
	while(1)
	{
//		cout<<n<<" "<<m<<endl;
		if(m==1)
		{
			cout<<"YES"<<endl;
			return;
		}
		int d=n/m;
		int k=n%m;
		if(k==0)
		{
			cout<<"NO"<<endl;
			return;
		}
		if(k*(d+1)==d*(m-k))
		{
			cout<<"NO"<<endl;
			return;
		}
		if(k*(d+1)>d*(m-k))
		{
			m=k;
		}
		else 
		{
			m=m-k;
		}
	}
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
//	int _;cin>>_;while(_--)
	solve();
}