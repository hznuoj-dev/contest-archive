#include<bits/stdc++.h>
using namespace std;
typedef pair<int, int> PII;
#define int long long
#define rep(i, a, n) for(int i = a; i <= n; i++)
#define x first
#define y second
const int N = 110;
PII a[N];

void solve() {
	string s; cin >> s;
	int n = s.length();
	s = ' ' + s;
	int ans = 0;
	rep(i, 1, n){
		int l = i, r = i, ll = 0, rr = 0;
		int flag = 0;
		while(l >= 0 && r <= n + 1){
			if(l == 0 || r == n + 1){
				if(flag != 1)
				ans = max(ans, r - l - 1);
				ans = max(ans, rr - ll - 1);
				break;
			}
			if(s[l] == s[r]){
				l--; r++;
			}else if(flag == 0){
				flag = 1;
				ll = l, rr = r;
				l--; r++;
			}else if(flag == 1){
				if(s[l] == s[rr] && s[ll] == s[r]){
					flag = 2;
					l--; r++;
				}else{
					ans = max(ans, rr - ll - 1);
					break;
				}
			}else{
				ans = max(ans, r - l - 1);
				break;
			}
		}
	}
	rep(i, 1, n - 1){
		int l = i, r = i + 1, ll = 0, rr = 0;
		int flag = 0;
		if(s[l] != s[r]){
			flag = 1;
			ll = l, rr = r;
			l--; r++;
		}
		while(l >= 0 && r <= n + 1){
			if(l == 0 || r == n + 1){
				if(flag != 1)
				ans = max(ans, r - l - 1);
				ans = max(ans, rr - ll - 1);
				break;
			}
			if(s[l] == s[r]){
				l--; r++;
			}else if(flag == 0){
				flag = 1;
				ll = l, rr = r;
				l--; r++;
			}else if(flag == 1){
				if(s[l] == s[rr] && s[ll] == s[r]){
					flag = 2;
					l--; r++;
				}else{
					ans = max(ans, rr - ll - 1);
					break;
				}
			}else{
				ans = max(ans, r - l - 1);
				break;
			}
		}
	}
	if(ans == 1) ans = 0;
	cout << ans << '\n';
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	int t; cin >> t;
	while(t--)
	solve();
}

/**
6
abccab
ihi
stfgfiut
palindrome
abcab
abcba
**/