#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	int f=0;
	ll a,b;
	cin>>a>>b;
	if(a==1||b==1){
		cout<<"YES"<<endl;
		return 0;
	}
	ll i;
	for( i=2;i<=a/i;i++){
		if(a%i==0) 
		{
			f=1;
			break;
		}
	}
	if(f==0){
		i=a;
	}
	if(i<=b){
		cout<<"NO"<<endl;
	}
	else{
		cout<<"YES"<<endl;
	}
}