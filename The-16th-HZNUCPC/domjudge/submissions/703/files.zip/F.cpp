#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

void solve(){
    ll n,m;
    cin>>n>>m;

    if(n==1||m==1)cout<<"YES\n";
    else {
        if(n<=m)cout<<"NO\n";
        else {
        	ll op=1;
        	if(n%m==0)op=0;
        	for(ll i=2;i<=sqrt(m)+1;i++){
        			if(i>m)continue;
        			if(n%i==0)op=0;
        			if(m/i==1||m/i==0){
        				continue;
					}
        			else if(n%(m/i)==0)op=0;
				
			}
			if(op)cout<<"YES\n";
			else cout<<"NO\n";
		}
    }
}



int main(){
    ios::sync_with_stdio(false);
    int T=1;
    //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}
