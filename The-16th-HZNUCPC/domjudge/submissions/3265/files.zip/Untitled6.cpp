#include<bits/stdc++.h>
#define pcc pair<char,char>
#define ll long long
using namespace std;
const int mod=1e9+7;
int main(){
	
	string a,b;
	cin>>a>>b;
	int n=a.length();
	map<pcc,ll>mp;
	ll x=0,y=0;
	for(int i=0;i<n;i++){
//		mp[{a[i],b[i]}]++;
		if(a[i]!=b[i])x++;
		else y++;
	}
//	for(auto k:mp){
//		cout<<k.first.first<<' '<<k.first.second<<' '<<k.second<<endl;
//	}
	cout<<max(x,1ll)*max(y,1ll)<<endl;
	return 0;
}