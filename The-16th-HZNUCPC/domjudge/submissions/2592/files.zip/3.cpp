#include<bits/stdc++.h>
using namespace std;
#define int long long
#define aa first
#define bb second

map<char, int>mp1, mp2;
map<pair<char,char>, int>mp;
int len1 = 0,len2 = 0;
//set<char>st1,st2;
const int mod = 1e9 + 7;
int power(int x, int k) {
    int res = 1;
    while (k) {
        if (k % 2) res = (res * x) % mod;
        x = (x * x) % mod;
        k >>= 1;
    }
    return res;
}
void solve(){
    int temp = power(2, mod - 2);
    string a, b;  cin>>a>>b;
    for(int i = 0; i < a.size(); i++){
        mp1[a[i]]++;  mp2[b[i]]++;
        //st1.insert(a[i]);
       // st2.insert(b[i]);
        mp[make_pair(a[i], b[i])]++;
    }
    int res = 0;
    //len1 = st1.size();
    //len2 = st2.size();
    for(auto it1 : mp){
        for(auto it2 : mp){
            //int n1 = len1,n2 = len2;
            char a1 = it1.aa.aa, b1 = it1.aa.bb;
            char a2 = it2.aa.aa, b2 = it2.aa.bb;
            mp1[a1]--;  mp1[a2]--; mp1[b1]++;  mp1[b2]++;
            mp2[a1]++;  mp2[a2]++; mp2[b1]--;  mp2[b2]--;

//            if(mp1[a1]==0)nn1--;
//            if(mp1[a2]==0)nn1--;
//            if(mp2[b1]==0)nn2--;
            //if(mp2[b2]==0)nn2--;
            if(mp1[a1]==0)mp1.erase(a1);
            if(mp1[a2]==0)mp1.erase(a2);
            if(mp1[b1]==0)mp1.erase(b1);
            if(mp1[b2]==0)mp1.erase(b2);
            if(mp2[a1]==0)mp2.erase(a1);
            if(mp2[a2]==0)mp2.erase(a2);
            if(mp2[b1]==0)mp2.erase(b1);
            if(mp2[b2]==0)mp2.erase(b2);
            int nn1 = mp1.size(), nn2 = mp2.size();
            if(nn1==nn2){
                if(it1.aa==it2.aa){
                    res += it1.bb*((it1.bb-1+mod)%mod)% mod * temp % mod;
                }else{
                    res += it1.bb*it2.bb% mod * temp % mod;
                }
                res %= mod;
            }
            mp1[a1]++;  mp1[a2]++; mp1[b1]--;  mp1[b2]--;
            mp2[a1]--;  mp2[a2]--; mp2[b1]++;  mp2[b2]++;
            if(mp1[a1]==0)mp1.erase(a1);
            if(mp1[a2]==0)mp1.erase(a2);
            if(mp1[b1]==0)mp1.erase(b1);
            if(mp1[b2]==0)mp1.erase(b2);
            if(mp2[a1]==0)mp2.erase(a1);
            if(mp2[a2]==0)mp2.erase(a2);
            if(mp2[b1]==0)mp2.erase(b1);
            if(mp2[b2]==0)mp2.erase(b2);
        }
    }
    cout<<res% mod<<"\n";
}
signed main(){
    int T=1;  //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}


