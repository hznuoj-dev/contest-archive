#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
		ll n,m,x;
		scanf("%lld %lld",&n,&m);
		while(1){
			
		}
		if(m==1||n==1) cout<<"YES\n";
		else if(n<=m) cout<<"NO\n";
		else{
			int flag=0;
			while(1){
				x=n%m;
				if(x==1){
					flag=1;break;
				}
				else if(x==0){
					break;
				}
				else{
					m=x;
				}
			}
			if(flag) cout<<"YES\n";
			else cout<<"NO\n";
		}
	return 0;
}