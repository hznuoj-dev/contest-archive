#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

typedef long long ll;

int main() {	
	ios;
	ll n, m;
	cin >> n >> m;
    if(m==1){
    	cout<<"YES"<<endl;
    	return 0;
	}
	if(n <= m) {
		cout << "NO";
		return 0;
	}
	while(true) {
		if(n % m == 0) {
			cout << "NO";
			return 0;
		}
		ll k = n % m;
		if(k == 1) break;
		m = k;
	}
	cout << "YES";
}