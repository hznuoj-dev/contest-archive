#include<bits/stdc++.h>
using namespace std;

int cnt[25][25];
int to[4][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
bool judge(int x, int y){
	if(x < 1 || y < 1 || x > 19 || y > 19)return false;
	return true;
}
int main(){
	int T;scanf("%d",&T);
	int n, x[405], y[405], ty[405];
	while(T--){
		memset(cnt, 0, sizeof(cnt));
		scanf("%d",&n);
		for(int i = 0;i < n; ++i){
			scanf("%d %d %d",&x[i],&y[i],&ty[i]);
			if(ty[i] == 2)continue;
			for(int j = 0;j < 4; ++j){
				int tox = x[i] + to[j][0];
				int toy = y[i] + to[j][1];
				if(judge(tox, toy))cnt[tox][toy] += 1;
			}
		}
		for(int i = 0;i < n ;++i){
			cnt[x[i]][y[i]] = 0;
		}
		int ans = 0;
		for(int i = 1;i <= 19; ++i){
			for(int j = 1;j <= 19; ++j){
				ans += cnt[i][j];
			}
		}
		printf("%d\n", ans);
	}
	
	
}