#include <bits/stdc++.h>
using namespace std;
long long ptnBtn[101][101];
long long ptns[101][2];
bool trg(int a,int b,int c){
    //Not the same point
    if(ptns[a][0]==ptns[b][0]&&ptns[a][1]==ptns[b][1])return false;
    if(ptns[b][0]==ptns[c][0]&&ptns[b][1]==ptns[c][1])return false;

    //share the same line
    if(a!=b&&b!=c&&
        //(x1-x2 )*(y2 - y3)
        (ptns[a][0]-ptns[b][0])*(ptns[c][1]-ptns[b][1])
        ==
        //(y1-y2)*(x2-x3)
        (ptns[a][1]-ptns[b][1])*(ptns[c][0]-ptns[b][0])
    )return false;
    return true;
}
int main()
{
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%lld%lld", &ptns[i][0], &ptns[i][1]);
    }
    for (int fstPtn = 0; fstPtn < n; fstPtn++)
    {
        for (int secPtn = 0; secPtn < fstPtn; secPtn++)
        {
            long long d1=abs(ptns[fstPtn][1] - ptns[secPtn][1]);//delta y
            long long d2=abs(ptns[fstPtn][0] - ptns[secPtn][0]);//delta x
            if(d1==0)d1=d2;
            if(d1==0)continue;
            if(d2==0)d2=d1;
            ptnBtn[fstPtn][secPtn] =ptnBtn[secPtn][fstPtn] = std::__gcd(d2, d1);
        }
    }
    long long ans = 0;
    for (int fstPtn = 0; fstPtn < n; fstPtn++)
    {
        for (int secPtn = 0; secPtn < fstPtn; secPtn++)
        {
            for (int ap = 0; ap < secPtn; ap++)
            {
                if(trg(fstPtn,secPtn,ap)){
                    ans = max(ans,ptnBtn[fstPtn][secPtn]+ptnBtn[ap][secPtn]+ptnBtn[fstPtn][ap]);
                }
            }
        }
    }
    printf("%lld\n",ans);
    return 0;
}