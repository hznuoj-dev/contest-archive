#include <bits/stdc++.h>

#define ll long long

using namespace std;

ll n,m;

int main(){
	cin>>n>>m;
	if(n==1 || m==1 || n%m==1) cout<<"YES"<<endl; 
	else if(n<=m || n%m==0) cout<<"NO"<<endl;
	else if(n&1) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	return 0;
}