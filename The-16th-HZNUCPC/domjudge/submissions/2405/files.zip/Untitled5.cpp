# include "bits/stdc++.h"
using namespace std;
# define int long long

int n, m;

signed main(){
	while(cin >> n >> m){
		if(m == 1 || n == 1){
			cout << "YES\n";
			continue;
		}
		bool flag = false;
		while(m != 0){
			m = n % m;
			if(m == 1){
				flag = true;
			}
		}
		if(flag) cout << "YES\n";
		else cout << "NO\n";
	}
	
	
	return 0;
}