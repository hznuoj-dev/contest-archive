#include<bits/stdc++.h>
using namespace std;
#define dzs ios::sync_with_stdio(false);cin.tie(nullptr),cout.tie(nullptr)
typedef long long ll;
struct node
{
	int x,y;
}a[200];
int gcd(int a,int b)
{
	if(a<b)
	{
		int t=a;
		a=b;
		b=t;
	}
	while(b)
	{
		int sup=b;
		b=a%b;
		a=sup;
	}
	return a;
}
int main()
{
	int n,maxx=0,cnt;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].x>>a[i].y;
	}
	for(int i=1;i<=n-2;i++)
	{
		for(int j=i+1;j<=n-1;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				if(abs(((double)a[i].y-(double)a[j].y)/((double)a[i].x-(double)a[j].x)-((double)a[i].y-(double)a[k].y)/((double)a[i].x-(double)a[k].x))<0.00001)continue;
				cnt=gcd(abs(a[i].x-a[j].x),abs(a[i].y-a[j].y))+gcd(abs(a[i].x-a[k].x),abs(a[i].y-a[k].y))+gcd(abs(a[k].x-a[j].x),abs(a[k].y-a[j].y));
				maxx=max(cnt,maxx);
			}
		}
	}
	cout<<maxx;
}