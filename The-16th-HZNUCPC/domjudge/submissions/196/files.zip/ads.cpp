#include<bits/stdc++.h>
using namespace std;
struct stone{
	int x,y,type;
};
void solve(){
	int n;
	cin>>n;
	set<pair<int,int> >s;
	vector<stone> a(n);
	for(int i=0;i<n;i++){
		cin>>a[i].x>>a[i].y>>a[i].type;
		if(a[i].type==1){   
//			if(a[i].x>1)
				s.insert({a[i].x-1,a[i].y});
//			if(a[i].x<19)
				s.insert({a[i].x+1,a[i].y});
//			if(a[i].y>1)
				s.insert({a[i].x,a[i].y-1});
//			if(a[i].y<19)
				s.insert({a[i].x,a[i].y+1});
		}
	}
//	for(auto i:s)
//		cout<<i.first<<" "<<i.second<<'\n';
	for(int i=0;i<n;i++)
		if(s.find({a[i].x,a[i].y})!=s.end())
			s.erase({a[i].x,a[i].y});
	cout<<s.size()<<'\n';
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int t;
	cin>>t;
	while(t--)
		solve();
}