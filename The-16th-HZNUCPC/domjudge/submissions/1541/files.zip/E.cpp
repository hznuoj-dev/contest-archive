#include<bits/stdc++.h>

using namespace std;

#define int long long
struct P{
	int x, y;
};
typedef long long LL;
const int N = 105;
vector<P> a(N);
LL dis[N][N];

signed main(){
	int n;
	cin >> n;
	for(int i = 1; i <= n; i++){
		cin >> a[i].x >> a[i].y;
	}	
	
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			LL dx = abs(a[i].x - a[j].x);
			LL dy = abs(a[i].y - a[j].y);
			dis[i][j] = __gcd(dx,dy);
		}
	}
	
	LL ans = 0;
	for(int i = 1; i <= n; i++){
		for(int j = i+1; j <= n; j++){
			for(int k = j+1; k <= n; k++){
				ans = max(ans, dis[i][j] + dis[j][k] + dis[k][i]);
			}
		}
	}
	
	cout << ans << endl;
	return 0;
}