#include <bits/stdc++.h>
using namespace std;
const int N = 110;

struct Node{
	int x,y;
};

int x[N] , y[N] , cnt = 0;

int count(int x1,int y1,int x2,int y2){
	int a = abs(y2-y1) , b = abs(x2-x1);
	if(a>b) swap(a,b);
	if(a==0) return b+1;
	if(b%a==0) return a+1;
	else return 2;
}

int main(){
	int n;cin>>n;
	map<Node,int> mp;
	for(int i=0;i<n;i++){
		int x,y;cin>>x>>y;
		mp[{x,y}] = 1;
	}
	
	for(auto &[a,b] : mp){
		cnt++;
		x[cnt] = a , y[cnt] = b;
	} 
	
	n = cnt;
	
	int res = 0;
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			for(int k=j+1;k<=n;k++){
				if(x[i]==x[j] && x[j]==x[k]) continue;
				if(y[i]==y[j] && y[j]==y[k]) continue;
				if(x[k]-x[j]!=0 && x[j]-x[i]!=0 && (double)(y[k]-y[j])/(double)(x[k]-x[j]) == (double)(y[j]-y[i])/(double)(x[j]-x[i])){
					continue;	
				}
				res = max(res , count(x[k],y[k],x[j],y[j]) + count(x[k],y[k],x[i],y[i]) + count(x[j],y[j],x[i],y[i]));
			}
	cout << res << endl;
	return 0;
}










