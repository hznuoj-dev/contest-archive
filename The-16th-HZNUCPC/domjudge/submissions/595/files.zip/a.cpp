#include  <bits/stdc++.h>

using namespace std;
typedef long long LL;

int dx[] = {-1, 0, 1, 0}, dy[] = {0, 1, 0, -1};

void kizk(){
	int n; cin >> n;
	set<pair<int, int>> s;
	vector<pair<int, int>> w;
	set<pair<int, int>> be;
	for(int k = 0; k < n; k ++)
	{
		int x, y, c; cin >> x >> y >> c;
		if(c == 2) w.push_back({x, y});
		else
		{
			be.insert({x, y});
			
		}

	}
	for(auto& ite : be)
	{
		int x = ite.first, y = ite.second;
		for(int i = 0; i < 4; i ++)
		{
			int a = x + dx[i], b = y + dy[i];
			if(be.count({a, b})) continue;
			s.insert({a, b});
		}
	}
	int m = s.size();
	// for(auto& ite : s)
	// cout << ite.first <<  " " << ite.second << " \n";
	for(auto& ite : w)
	{
		int a = ite.first, b = ite.second;
		if(s.count({a, b}))
			m -- ;
	}
	// for(auto& ite : be)
	// {
	// 	int a = ite.first, b = ite.second;
	// 	if(s.count({a, b})) m -- ;
	// }
	cout << m << "\n";

}


int main(){
	std::ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int T; T = 1;
	cin >> T;
	while(T --) kizk();
	return 0;
}