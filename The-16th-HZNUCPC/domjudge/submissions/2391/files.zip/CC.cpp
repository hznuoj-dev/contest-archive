#include<bits/stdc++.h>
using namespace std;
#define rep(i,a,b) for(int i=a;i<=b;i++)
typedef long long ll;
typedef pair<ll,ll>pii;
typedef pair<char, char> pcc;
const ll N=1e5+10,mod=1e9+7;
ll cs[N],ct[N],n;
char s[N],t[N];
map<ll,ll>mp;

ll power(ll a,ll b){
	ll rt=1;
	for(;b>0;b>>=1,a=a*a%mod)if(b&1)rt=rt*a%mod;
	return rt;
}
int main() {
	scanf("%s%s",s+1,t+1);
	//set<char>ss,st;
	int n = strlen(s + 1);
	map<pii,int> mp;
	for(int i=1;i<=n;i++){
		int _1=s[i]-'a',_2=t[i]-'a';
		mp[{_1,_2}]++;
	}
	map<int,int> S,T;
	for(int i=1;i<=n;i++){
		S[s[i]-'a']++;
	}
	for(int i=1;i<=n;i++){
		T[t[i]-'a']++;
	}

	ll s1=S.size(),s2=T.size();

	ll ans=0,res=0;
	auto C2=[&](ll x)->ll{
		return x*(x-1)/2;
	};
	rep(_1,0,25)rep(_2,0,25)if(mp.count({_1,_2})){
		rep(_3,0,25)rep(_4,0,25)if(mp.count({_3,_4})){
			ll p1=s1,p2=s2;
			S[_1]--;if(S[_1]==0)p1--;
			S[_2]++;if(S[_2]==1)p1++;
			S[_3]--;if(S[_3]==0)p1--;
			S[_4]++;if(S[_4]==1)p1++;
			S[_1]++;S[_2]--,S[_3]++,S[_4]--;
			
			T[_1]++;if(T[_1]==1)p2++;
			T[_2]--;if(T[_2]==0)p2--;
			T[_3]++;if(T[_3]==1)p2++;
			T[_4]--;if(T[_4]==0)p2--;
			T[_1]--,T[_2]++,T[_3]--,T[_4]++;
			
			if(p1!=p2)continue;
			if(_1==_3&&_2==_4){
				res=(res+C2(mp[{_1,_2}]))%mod;
			}
			else {
				ans=(ans+mp[{_1,_2}]*mp[{_3,_4}]%mod)%mod;
			}
		}
	}
	ans=ans*power(2ll,mod-2)%mod;
	ans=(ans+res)%mod;
	cout<<ans<<'\n';
	
}