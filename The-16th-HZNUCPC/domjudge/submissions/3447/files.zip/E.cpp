#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
using namespace std;

int main()
{
    long long sum = 0;
    long long res = 0;
    int n;
    cin >> n;
    long long a[110],b[110];
    for(int i = 1;i <= n; i++)
    {
        cin >> a[i] >> b[i];
    }
    for(int i = 1;i <= n-2; i++)
        for(int j = i+1;j <= n-1; j++)
            for(int z = j+1;z <= n; z++)
            {
                double k1 = (b[j]-b[i])/(double)(a[j] - a[i]);
                double k2 = (b[z]-b[j])/(double)(a[z] - a[j]);
                double k3 = (b[i]-b[z])/(double)(a[i] - a[z]);
                double b1 = b[i] - (double)k1 * a[i];
                double b2 = b[j] - (double)k2 * a[j];
                double b3 = b[z] - (double)k3 * a[z];
                if(k1 == k2 || k2 == k3 || k1 == k3)
                {
                    continue;
                }else
                {
                    //long long minx = min(a[i],min(a[j],a[z]));
                    //long long maxx = max(a[i],max(a[j],a[z]));
                    //long long miny = min(b[i],min(b[j],b[z]));
                    //long long maxy = max(b[i],max(b[j],b[z]));
                    //for(int x = minx;x <= maxx; x++)
                        //for(int y = miny; y <= maxy; y++)
                        //{
                            //if((y == k1 * x + b1) || (y == k2 * x + b2) || (y == k3 * x + b3))
                            //{
                                //res ++;
                            //}
                        //}
                    if(abs(k1) < 1)
                    {
                        long long minx = min(a[i],a[j]);
                        long long maxx = max(a[i],a[j]);
                        res += (maxx - minx+1) * abs(k1);
                    }else if(abs(k1) == 1)
                    {
                        long long minx = min(a[i],a[j]);
                        long long maxx = max(a[i],a[j]);
                        res += (maxx - minx+1) * abs(k1);
                    }else{
                        long long minx = min(a[i],a[j]);
                        long long maxx = max(a[i],a[j]);
                        res += (maxx - minx+1) / abs(k1);
                    }
                    if(abs(k2) < 1)
                    {
                        long long minx = min(a[j],a[z]);
                        long long maxx = max(a[j],a[z]);
                        res += (maxx - minx+1) * abs(k2);
                    }else if(abs(k2) == 1)
                    {
                        long long minx = min(a[j],a[z]);
                        long long maxx = max(a[j],a[z]);
                        res += (maxx - minx+1) * abs(k2);
                    }else{
                        long long minx = min(a[j],a[z]);
                        long long maxx = max(a[j],a[z]);
                        res += (maxx - minx+1) / abs(k2);
                    }
                    if(abs(k3) < 1)
                    {
                        long long minx = min(a[i],a[z]);
                        long long maxx = max(a[i],a[z]);
                        res += (int)(maxx - minx+1) * abs(k3);
                    }else if(abs(k3) == 1)
                    {
                        long long minx = min(a[i],a[z]);
                        long long maxx = max(a[i],a[z]);
                        res += (int)(maxx - minx+1) * abs(k3);
                    }else{
                        long long minx = min(a[i],a[z]);
                        long long maxx = max(a[i],a[z]);
                        res += (int)(maxx - minx+1) / abs(k3);
                    }
                    res += 3;
                    sum = max(sum,res);
                    res = 0;
                }
            }
    cout << sum << endl;
}
