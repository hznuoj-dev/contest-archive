def isprime(v):
    if v == 1:
        return True
    if v == 2:
        return True
    for i in range(2,int(v**(0.5)+1)):
        if v%i == 0:
            return False
    return True

n,m = map(int,input().split())
if isprime(n):
    print("YES")
else:
    print("NO")
