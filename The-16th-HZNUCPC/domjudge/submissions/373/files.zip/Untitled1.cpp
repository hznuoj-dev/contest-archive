#include<bits/stdc++.h>
#define int long long
using namespace std;

int n,m;

void solve(){
	int k;
	while(cin >> n >> m){
		int f=0;
		if(n<=m){
		 f=1;
		}
		while(m!=1){
			if(n%m!=0){
				m=(m+1)/2;
			}else{
				f=1;
				break;
			}
		}
		if(!f){
			cout<<"YES"<<endl;
		}else cout<<"NO"<<endl;
	}
	
}

signed main(){
//	int T;cin >> T;while(T--){
		solve();
//	}
	return 0;
}