#include<bits/stdc++.h>
using namespace std;
const int N=1e3+7;
typedef long long ll;
ll x[N],y[N];
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];
	}
	int ans=0,ans1=0,ok=0;
	double a=0,b=0,c=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				ans=0;
				a=0;
				b=0;
				c=0;
				a=sqrt(pow(x[i]-x[j],2)+pow(y[i]-y[j],2));
				b=sqrt(pow(x[i]-x[k],2)+pow(y[i]-y[j],2));
				c=sqrt(pow(x[j]-x[k],2)+pow(y[j]-y[k],2));
				if(fabs(a+b-c)<=0.0001||fabs(a+c-b)<=0.0001||fabs(b+c-a)<=0.0001||a==0||b==0||c==0){
					continue;
				}
				if(x[i]-x[j]==0){
					ans=ans+abs(y[i]-y[j])-1;
				}
				if(x[i]-x[k]==0){
					ans=ans+abs(y[i]-y[k])-1;
				}
				if(x[k]-x[j]==0){
					ans=ans+abs(y[k]-y[j])-1;
				}
				if(y[i]-y[j]==0){
					ans=ans+abs(x[i]-x[j])-1;
				}
				if(y[i]-y[k]==0){
					ans=ans+abs(x[i]-x[k])-1;
				}
				if(y[k]-y[j]==0){
					ans=ans+abs(x[k]-x[j])-1;
				}
				if(x[i]!=x[j]&&y[i]!=y[j]){
					ans+=__gcd(abs(x[i]-x[j]),abs(y[i]-y[j]))-1;
				}
				if(x[i]!=x[k]&&y[i]!=y[k]){
					ans+=__gcd(abs(x[i]-x[k]),abs(y[i]-y[k]))-1;
				}
				if(x[j]!=x[k]&&y[j]!=y[k]){
					ans+=__gcd(abs(x[j]-x[k]),abs(y[j]-y[k]))-1;
				}
				ans1=max(ans1,ans);
				if(ans1==0){
					ok=1;
				}
			}
		}
	}
	if(ok==1){
		cout<<0;
	}
	else{
		cout<<ans1+3;
	}
}