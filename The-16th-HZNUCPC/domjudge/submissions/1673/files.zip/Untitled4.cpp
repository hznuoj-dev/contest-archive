#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int N = 105;
//int a[N][N];

const double eps = 1e-8;
struct point{
	double x, y;
	point operator - (const point &p) const{
		return point{x - p.x, y - p.y};
	}
};
double cross(point p1, point p2){
	return p1.x * p2.y - p1.y * p2.x;
}
int sign(double k){
	if (k > eps){
		return 1;
	}else if (k < -eps){
		return -1;
	}else{
		return 0;
	}
}
int parallel(point p1,point p2,point p3,point p4){
	return sign(cross(p1 - p2,p3 - p4)) == 0;
}
point a[N];

void solve() {
	int n;
	cin >> n;
	for(int i = 1; i <= n; i++){
		cin >> a[i].x >> a[i].y;
	}
	int ans = 0;
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			for(int k = 1; k <= n; k++){
				if (i == j || i == k || j == k){
					continue;
				}
				//judge
				if (parallel(a[i],a[j],a[j],a[k])){
					continue;
				}
				
				int num = 0;
				num += (__gcd((int)abs(a[i].x - a[j].x),(int)abs(a[i].y - a[j].y)));
				num += (__gcd((int)abs(a[i].x - a[k].x),(int)abs(a[i].y - a[k].y)));
				num += (__gcd((int)abs(a[k].x - a[j].x),(int)abs(a[k].y - a[j].y)));
				ans = max(ans,num);
			}
		}
	}
	cout << ans << endl;
}
signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int Case = 1;
//	cin >> Case;
	while (Case -- ) {
		solve();
	}
	return 0;
}