#include<bits/stdc++.h>
using namespace std;
#define int long long

const int maxn = 1e5 + 7;
const int mod = 1e9 + 7;
map<int, int> mp1, mp2;
string str1, str2;

struct node{
	int ch1, ch2;
	bool operator < (const node &A) const{
		if(ch1 == A.ch1) return ch2 < A.ch2;
		else return ch1 < A.ch1;
	}
};
map<node, int> mp;
vector<node> vec;

int fac[maxn], inv[maxn], f[maxn];

int qpow(int base, int pow){
	int ans = 1;
	while(pow)
	{
		if(pow & 1) ans = ans * base % mod;
		base = base * base % mod;
		pow >>= 1;
	}
	return ans;
}

int C(int n, int m){
	if(m > n || m < 0) return 0;
	return fac[n] * ((inv[n - m] * inv[m]) % mod) % mod;
}

void ini(){
	fac[0] = 1;
	inv[0] = 1;
	for(int i = 1; i <= maxn- 2; i++)
	{
		fac[i] = (fac[i - 1] * i) % mod;
		inv[i] = qpow(fac[i], mod - 2);
	}
}


void init(){
	for(int i = 0; i < 26; i++){
		for(int j = 0; j < 26; j++){
			vec.push_back({i, j});
		}
	}
}

void run(){
//	cout << C(4, 2) << '\n';
	cin >> str1 >> str2;
	for(int i = 0; i < str1.length(); i++){
		mp1[str1[i] - 'a']++;
		mp2[str2[i] - 'a']++;
		mp[{str1[i] - 'a', str2[i] - 'a'}]++;
	}
	map<int, int> temp1, temp2, tmp1, tmp2;
	temp1 = mp1, temp2 = mp2;
	int len1 = mp1.size(), len2 = mp2.size();
	int ans = 0;
	for(int i = 0; i < vec.size(); i++){
		if(mp[vec[i]] == 0) continue;
		temp1[vec[i].ch1]--;
		temp1[vec[i].ch2]++;
		temp2[vec[i].ch1]++;
		temp2[vec[i].ch2]--;
		if(temp1[vec[i].ch1] == 0) len1--;
		if(temp2[vec[i].ch2] == 0) len2--;
		if(mp1[vec[i].ch2] == 0 && temp1[vec[i].ch2] > 0) len1++;
		if(mp2[vec[i].ch1] == 0 && temp2[vec[i].ch1] > 0) len2++;
		
		tmp1 = temp1, tmp2 = temp2;
		
		for(int j = i; j < vec.size(); j++){
			if(mp[vec[j]] == 0) continue;
			tmp1[vec[j].ch1]--;
			tmp1[vec[j].ch2]++;
			tmp2[vec[j].ch1]++;
			tmp2[vec[j].ch2]--;
			if(tmp1[vec[j].ch1] == 0) len1--;
			if(tmp2[vec[j].ch2] == 0) len2--;
			if(temp2[vec[j].ch2] == 0 && tmp1[vec[j].ch2] > 0) len1++;
			if(temp2[vec[j].ch1] == 0 && tmp2[vec[j].ch1] > 0) len2++;
			if(len1 == len2 && vec[i].ch1 == vec[j].ch1 && vec[i].ch2 == vec[j].ch2 &&  mp[vec[i]] > 1) {
				ans = ans + C(mp[vec[i]], 2);
			} 
			else if(len1 == len2 && (vec[i].ch1 != vec[j].ch1 || vec[i].ch2 != vec[j].ch2)) {
				ans = (ans + mp[vec[i]] * mp[vec[j]]) % mod;
			} 
			if(tmp1[vec[j].ch1] == 0) len1++;
			if(tmp2[vec[j].ch2] == 0) len2++;
			if(temp2[vec[j].ch2] == 0 && tmp1[vec[j].ch2] > 0) len1--;
			if(temp2[vec[j].ch1] == 0 && tmp2[vec[j].ch1] > 0) len2--;
			tmp1 = temp1;
			tmp2 = temp2;
		}
		if(temp1[vec[i].ch1] == 0) len1++;
		if(temp2[vec[i].ch2] == 0) len2++;
		if(mp1[vec[i].ch2] == 0 && temp1[vec[i].ch2] > 0) len1--;
		if(mp2[vec[i].ch1] == 0 && temp2[vec[i].ch1] > 0) len2--;
		temp1 = mp1;
		temp2 = mp2;
	}
	cout << ans << '\n';
}

signed main(){
	init();
	ini();
	run();
}