#include<iostream>
using namespace std;
int main(){
	long long n,m;
	cin >> n >> m;
	string res;
	if(m==1)res="YES";
	else if(n%2==0){
		res="NO";
	}else if(n%2==1){
		res="YES";
	}
	cout << res << endl;
}