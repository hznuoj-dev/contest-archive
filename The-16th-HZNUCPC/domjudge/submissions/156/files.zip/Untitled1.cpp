#include <iostream>
using namespace std;
int main()
{
    int n,m;
    cin>>n>>m;
    while(1)
    {
    	if(n%m==0)
    	{
    		cout<<"NO";
    		break;
		}
		if(m==2)
		{
			cout<<"YES";
			break;
		}
		m--;
	}
    return 0;
}