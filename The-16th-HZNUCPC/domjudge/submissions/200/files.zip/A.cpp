#include <bits/stdc++.h>
#define int int64_t
#define endl '\n'
using namespace std;

int a[25][25];

void solve() {
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		int x, y, c;
		cin >> x >> y >> c;
		a[x][y] = c;
	}
	int res = 0;
	for (int i = 1; i <= 19; i++) {
		for (int j = 1; j <= 19; j++) {
			if (a[i][j] == 1) {
				if (i > 1 and a[i-1][j] == 0) res++;
				if (i < 19 and a[i+1][j] == 0) res++;
				if (j > 1 and a[i][j-1] == 0) res++;
				if (j < 19 and a[i][j+1] == 0) res++;
			}
		}
	}
	cout << res << endl;
}

int32_t main() {
	cin.tie(0);
	cout.tie(0);
	ios::sync_with_stdio(false);
	
	int t;
	cin >> t;
	while (t--)
		solve();
}