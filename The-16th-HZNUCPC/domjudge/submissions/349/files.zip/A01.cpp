#include <bits/stdc++.h>

int n;

int board[21][21];

int col[20][20];

bool is[21][21];

void dfs(int x, int y, int c){
	col[x][y] = c;
	if(x > 1){
		if(0 == col[x - 1][y] && board[x - 1][y] == 1){
			dfs(x - 1, y, c);
		}
	}
	if(x < 19){
		if(0 == col[x + 1][y] && 1 == board[x + 1][y]){
			dfs(x + 1, y, c);
		}
	}
	if(y > 1){
		if(0 == col[x][y - 1] && 1 == board[x][y - 1]){
			dfs(x, y - 1, c);
		}
	}
	if(y < 19){
		if(0 == col[x][y + 1] && 1 == board[x][y + 1]){
			dfs(x, y + 1, c);
		}
	}
}

bool tot[20][20];

int main(){
	int T;
	scanf("%d", &T);
	for( ; T > 0; T--){
		scanf("%d", &n);
		int i, j;
		for(i = 1; i <= 19; i++){
			for(j = 1; j <= 19; j++){
				board[i][j] = 0;
				col[i][j] = 0;
			}
		}
		for(i = 0; i <= 20; i++){
			board[i][0] = 2;
			board[0][i] = 2;
			board[20][i] = 2;
			board[i][20] = 2;
		}
		
		for( ; n > 0; n--){
			int x, y;
			scanf("%d%d", &x, &y);
			scanf("%d", &board[x][y]);
		}
		
		int colcnt = 0;
		for(i = 1; i <= 19; i++){
			for(j = 1; j <= 19; j++){
				if(0 == board[i][j] || 2 == board[i][j]){
					col[i][j] = -1;
				}else if(0 == col[i][j]){
					colcnt++;
					dfs(i, j, colcnt);
				}
			}
		}
		
		int ans = 0;
		int k;
		for(i = 1; i <= colcnt; i++){
			for(j = 1; j <= 19; j++){
				for(k = 1; k <= 19; k++){
					is[j][k] = false;
				}
			}
			for(j = 1; j <= 19; j++){
				for(k = 1; k <= 19; k++){
					if(i == col[j][k]){
						if(0 == board[j - 1][k]){
							is[j - 1][k] = true;
						}
						if(0 == board[j + 1][k]){
							is[j + 1][k] = true;
						}
						if(0 == board[j][k - 1]){
							is[j][k - 1] = true;
						}
						if(0 == board[j][k + 1]){
							is[j][k + 1] = true;
						}
					}
				}
			}
			for(j = 1; j <= 19; j++){
				for(k = 1; k <= 19; k++){
					if(is[j][k]){
						ans++;
					}
				}
			}
		}
		printf("%d\n", ans);
		
	}
	return 0;
}
