#include<bits/stdc++.h>
using namespace std;
int fan[30][30]= {0};
int use[4][2]={{-1,0},{1,0},{0,-1},{0,1}};
bool vis[30][30]={0};
bool dfs(int x,int y)
{
	bool type=0;
	vis[x][y]=1;
	bool did=0;
	for(int i=0;i<4;i++)
	{
		if(fan[x+use[i][0]][y+use[i][1]]==2&&vis[x+use[i][0]][y+use[i][1]]==0)
		{
			did = 1;
			type=dfs(x+use[i][0],y+use[i][1]);
			if(type == 1)break;
			
		}
		if(fan[x+use[i][0]][y+use[i][1]]==0)
		{
			type =1;did =1;break;
		}
	}
	vis[x][y]=0;
	if(did == 0)type = false;
	return type;
}
void clean(int x,int y)
{
	
	fan[x][y]=0;
	for(int i=0;i<4;i++)
	{
		if(fan[x+use[i][0]][y+use[i][1]]==2)
		{
			clean(x+use[i][0],y+use[i][1]);
		}
	}
	return;
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		long long sum=0;
		int n,x,y,type;
		cin>>n;
		for(int i=0;i<=20;i++)//chu shi hua
		{
			for(int j=0;j<=20;j++)
			{
				if(i==0||i==20||j==0||j==20)fan[i][j]=3;
				else fan[i][j]=0;
			}
	    }
		for(int i=1;i<=n;i++)//shu ru
		{
			cin>>x>>y>>type;
			if(type==1)
			{
				fan[x][y]=1;
			}
			else
			{
				fan[x][y]=2;
			}
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(fan[i][j]==2)
				{
					if(!dfs(i,j))
					{
						clean(i,j);
					}
					
				}
			}
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(fan[i][j]==1)
				{
					if(fan[i-1][j]==0)
					{
						sum++;	
					}
					if(fan[i][j-1]==0)
					{
						sum++;   
					}
					if(fan[i+1][j]==0)
					{
						sum++; 
					}
					if(fan[i][j+1]==0)
					{
						sum++;
					}
				}
			}
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
		      cout<<fan[i][j]<<" ";cout<<'\n';
		      
		}
		cout<<sum<<'\n';
	}
}
