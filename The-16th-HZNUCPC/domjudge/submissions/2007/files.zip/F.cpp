#include<iostream>
#include<math.h>
using namespace std;
long long i,j,f; 
int main()
{
	long long n,m;
	cin>>n>>m;
	for(i=m;i>=2;i--)
	{
		if(n%i==0){
		cout<<"NO";
		f=1;
		break;
	}}
	if(f==0)cout<<"YES";
	return 0;
}