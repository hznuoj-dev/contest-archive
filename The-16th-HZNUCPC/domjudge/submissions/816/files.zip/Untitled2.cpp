#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
typedef pair<int,int> pii;
ll qpow (ll a,ll b ,ll p) 
{
ll res=1; 
while(b)
{
	if(b& 1)
	{
		res=res*a%p;
	}
		a=a*a%p;
		b>>=1;
	
}
return res;
}
signed main()
{
	Acode;
	int t;
	t=1;
	//cin>>t;
	while(t--)
	{
		ll a,b;
		cin>>a>>b;
		while(1)
		{
			if(a==1 || b==1 )
			{
				cout<<"YES\n";
				break;
			}
			if(a<=b) 
			{
				cout<<"NO\n";
				break;
			}
			if (a%2==0&& b >=2) 
			{
				cout<<"NO\n";
				break;
			 } 
			 if(b==1)
			 {
			 	cout<<"YES\n";
			 	break;
			 }
			if(a%b==0 && b!=1 ) 
			{
				cout<<"NO\n";
				break;
			}
			else if(a%b==1)
			{
				cout<<"YES\n";
				break;
			}
			b=a%b;
			
		}
	}
	return 0;
}
