#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
char s1[100010];
char s2[100010];
int main()
{
    //cin>>s1>>s2;
    ll n,m;
    cin>>n>>m;
    while(n%m!=0){
        m=n%m;
        if(m==1)break;
    }
    if(m==1)cout<<"YES"<<endl;
    else cout<<"NO"<<endl;
    return 0;
}
