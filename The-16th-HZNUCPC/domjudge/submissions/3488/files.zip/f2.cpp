#include <iostream>
using namespace std;
int main(){
	long long int n,m,y;
	cin>>n>>m;
	while(m>1){
		m = n%m;
		if(m==0){
			cout<<"NO";
			return 0;
		}
	}
	cout<<"YES";
	return 0;
}