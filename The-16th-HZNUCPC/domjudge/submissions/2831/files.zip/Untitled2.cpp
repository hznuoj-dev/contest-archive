#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(flase);cin.tie(0);cout.tie(0)
int n,m;
signed main(){
	cin>>n>>m;
	if(n==1||m==1){
		cout<<"YES"<<endl;
	}else{
		if(n<=m){
			cout<<"NO"<<endl;
		}else{
			if(n&1)cout<<"YES"<<endl;
			else cout<<"NO"<<endl;
		}
	}
	return 0;
}