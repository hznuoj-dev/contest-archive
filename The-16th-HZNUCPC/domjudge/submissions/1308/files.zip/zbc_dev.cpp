#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
#define per(i,x,y) for(int i=x;i>=y;i--)
using namespace std;
#define int long long
const int mod=1e9+7;
const int N=2e5+10;
int qmi(int a,int b){
	int res=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
int n,m;
bool check(int x){
	int y=n/x;
	int z=(n%x)/(m-x);
	z+=((n%x)%(m-x)!=0);
	return z<y;
}
void solve(){
	cin>>n>>m;
	if(m>=n or n%m==0){
		cout<<"NO\n";
	}else{
		int l=1,r=m-1;
		while(l<=r){
			int mid=l+r>>1;
			if(!check(mid))r=mid-1;
			else l=mid+1;
		}
		rep(i,2,n/i){
			if(n%i==0){
				int x=i,y=n/i;
				if(x<=r or y<=r){
					cout<<"NO\n";
					return;
				}
			}
		}
		cout<<"YES\n";
		//cout<<l<<" "<<r<<"\n";
	}
}
signed main(){
	cin.tie(0)->sync_with_stdio(false);
	int tc=1;
	for(int i=1;i<=tc;i++){
		solve();
	}
}