#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
const int X[4]={1,-1,0,0};
const int Y[4]={0,0,1,-1};

int a[100][100];
bool bo[100][100];

void solve()
{
	int n; cin>>n;
    for(int i=1;i<=n;i++)
    {
        int x,y,z; cin>>x>>y>>z;
        a[x][y]=z;
        bo[x][y]=true;
    }
    int ans=0;
    for(int i=1;i<=19;i++)
        for(int j=1;j<=19;j++)
        {
            if(a[i][j]==1)
            {
                for(int k=0;k<4;k++)
                	if(!bo[i+X[k]][j+Y[k]])
                    {
                        bo[i+X[k]][j+Y[k]]=true;
                        ans++;
                    }
            }
        }
    cout<<ans<<"\n";
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int t=1; cin>>t;
	while(t--)
    {
		solve();
    }
    return 0;
}