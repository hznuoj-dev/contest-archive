#include <bits/stdc++.h>
using namespace std;

int T, N;
string S;

int main() {
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin >> T;
	while (T--) {
		cin >> S;
		N = S.size();
		S = "$" + S;
		int Ans = 0;
		for (int i = 1; i <= N; i++) {
			// odd
			bool used = 0;
			pair<char, char> a = {'0', '0'};
			int temp = 1;
			for (int j = 1; i - j >= 1 && i + j <= N; j++) {
				if (S[i - j] == S[i + j]) temp += 2;
				else if (a == make_pair('0', '0')) {
					a = {S[i - j], S[i + j]};
					if (temp != 1) Ans = max(Ans, temp);
					temp += 2;
				}
				else if (used == 0) {
					if ((a.first == S[i + j]&& a.second == S[i - j])  || (a.first == S[i - j] && a.second == S[i + j])) {
						temp += 2;
						used = 1;
					} else {
						goto cyb1;
					}
				}
				else {
					break;
				}
			}
			if ((used == 1 || a == make_pair('0', '0')) && (temp != 1))Ans = max(Ans, temp);
			cyb1:;
			// even
			used = 0;
			a = {'0', '0'};
			temp = 0;
			for (int j = 0; i - j >= 1 && i + j + 1 <= N; j++) {
				if (S[i - j] == S[i + j + 1]) temp += 2;
				else if (a == make_pair('0', '0')) {
					a = {S[i - j], S[i + j + 1]};
					Ans = max(Ans, temp);
					temp += 2;
				}
				else if (used == 0) {
					if ((a.first == S[i + j+1]&& a.second == S[i - j])  || (a.first == S[i - j] && a.second == S[i + j+1])) {
						temp += 2;
						used = 1;
					} else {
						goto cyb2;
					}
				}
				else {
					break;
				}
			}
			if ((used == 1 || a == make_pair('0', '0')))Ans = max(Ans, temp);
			cyb2:;
		}
		cout << Ans << endl;
	}
	return 0;
}
