#include<bits/stdc++.h>
using namespace std;
const int N = 1e5+5;
double k[200][2];
long long n,m;
double x1,x2,x3,yy,y2,y3;
long long tt;
void suan(double a1,double b1,double a2,double b2){
	
	long long xl=a1-a2;
	long long yl=b1-b2;
	xl=abs(xl);
	yl=abs(yl);
	long long v=__gcd(xl,yl);
//	cout <<a1 << ' ' << b1 << ' ' << a2 << ' ' << b2 << ' ' << v << endl;
	tt+=v;

	
	
}


int main(){
	while(cin >> n ){
		for(int i=0;i<n;i++){
			cin >> k[i][0] >>k[i][1];
		}
		long long sum=0;
		for(int i=0;i<n-2;i++){
			x1=k[i][0];
			yy=k[i][1];
			for(int j=i+1;j<n-1;j++){
				x2=k[j][0];
				y2=k[j][1];
				for(int z=j+1;z<n;z++){
					x3=k[z][0];
					y3=k[z][1];
					if(yy==y2 &&yy==y3){
						continue;
					}else if(x1==x2 &&x1==x3){
						continue;
					}
					else if((x1-x2)/(yy-y2)==(x1-x3)/(yy-y3)){
						continue;
					}
					tt=0;
					suan(x1,yy,x2,y2);
					suan(x1,yy,x3,y3);
					suan(x2,y2,x3,y3);
					sum=max(tt,sum);
					
					
				}
				
			}
		}
		cout << sum << endl;
	}
	return 0;
}         
