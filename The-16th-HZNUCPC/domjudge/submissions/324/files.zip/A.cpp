#include<bits/stdc++.h>
using namespace std;
#define int long long
int ans,n;
int q[105][105];
int dir[4][2]={1,0,0,1,-1,0,0,-1};
bool ok(int x,int y){
	if(x<1||x>19||y<1||y>19){
		return false;
	}
	return true;
}
void dfs(int x,int y){
	for(int i=0;i<4;i++){
		int tx=x+dir[i][0];
		int ty=y+dir[i][1];
		if(ok(tx,ty)&&q[tx][ty]==0){
			ans++;
		}
	}
}
void solve(){
	ans=0;
	cin>>n;
	memset(q,0,sizeof q);
	for(int i=0;i<n;i++){
		int x,y,z;
		cin>>x>>y>>z;
		q[x][y]=z;
	}
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(q[i][j]==1){
				dfs(i,j);
			}
		}
	}
	cout<<ans<<endl;
}

signed main(){
	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}