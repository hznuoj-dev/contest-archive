#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;

typedef long long ll;

ll x[5], y[5];

ll gcd(ll a,ll b){return b==0?a:gcd(b,a%b);
}

struct node {
	ll u,v;
	ll cnt;
}point[105];


void solve(){
	int n;
	cin >> n;
	ll max = -1, flag = 0;
	for(int i = 1;i <= n; i++){
		ll a, b;
		cin >> a >> b;
		point[i].u = a;
		point[i].v = b;
	}
	
	for(int i = 1;i <= n - 2;i++){
		for(int j = i + 1; j <= n - 1;j++){
			for(int k = j + 1;k <= n;k++){
				x[1] = point[j].u - point[i].u;
				x[2] = point[k].u - point[j].u;
				x[3] = point[i].u - point[k].u;
				y[1] = point[j].v - point[i].v;
				y[2] = point[k].v - point[j].v;
				y[3] = point[i].v - point[k].v;
				ll cnt = 0, sum = 0;
				for(int g = 1; g <= 3;g++){
					ll temp1 = abs(x[g]), temp2 = abs(y[g]);
					if(x[g] == 0 || y[g] == 0) cnt = temp1 + temp2;
					
					else cnt = gcd(temp1, temp2);
					
					sum += cnt;
				}
				if((y[1] - y[2]) * (x[1] - x[3]) != (y[1] - y[3]) * (x[1] - x[2])){
					flag = 1;
					if(sum > max) max = sum;
				}
				
			}
		}
	}
	if(flag == 1) cout << max << endl;
	else cout << "0" << endl;
	//system("pause");
}

int main(){
	
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	
	return 0;
}