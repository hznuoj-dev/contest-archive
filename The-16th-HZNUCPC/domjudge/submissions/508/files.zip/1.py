t = int(input())
for _ in range(t):
    a = [[0]*21 for i in range(21)]
    r = 0
    n = int(input())
    for i in range(n):
        x, y, c = map(int, input().split())
        a[x][y] = c
    for x in range(20):
        for y in range(20):
            if a[x][y] == 0 and ((a[x][y+1]==1 or a[x+1][y]==1) or (x>0) and (a[x][y-1]==1 or a[x-1][y]==1)):
                r += 1
    print(r)
