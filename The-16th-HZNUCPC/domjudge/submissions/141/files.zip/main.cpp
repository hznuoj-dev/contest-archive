#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const ll N = 1e6 + 10;
ll x[N], y[N];

ll gcd(ll a, ll b)
{
    return b == 0 ? a : gcd(b, a % b);
}
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    ll n;
    cin >> n;
    for (ll i = 1; i <= n; i++)
    {
        cin >> x[i] >> y[i];
    }
    ll ans = 0;
    for (ll i = 1; i <= n; i++)
    {
        for (ll j = i + 1; j <= n; j++)
        {
            for (ll k = j + 1; k <= n; k++)
            {
                if(x[i]==x[j]&&y[i]==y[j]) continue;
                if(x[i]==x[k]&&y[i]==y[k]) continue;
                if(x[j]==x[k]&&y[j]==y[k]) continue;
                ll x1 = x[j]-x[i];
                ll x2 = x[k]-x[i];
                ll y1 = y[j]-y[i];
                ll y2 = y[k]-y[i];
                if(x1*y2-x2*y1==0) continue;
                ll tmp = 0;
                tmp += gcd(abs(x[i] - x[j]), abs(y[i]- y[j]));
                tmp += gcd(abs(x[i] - x[k]), abs(y[i]- y[k]));
                tmp += gcd(abs(x[j] - x[k]), abs(y[j]- y[k]));
                ans = max(ans, tmp);
            }
        }
    }
    cout << ans << endl;
}