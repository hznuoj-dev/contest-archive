#include <bits/stdc++.h>
using namespace std;
long long ptnBtn[101][101];
long long ptns[101][2];
double ptdst(int p1id,int p2id){
    return sqrt(
        (double)(ptns[p1id][0]-ptns[p2id][0])*(double)(ptns[p1id][0]-ptns[p2id][0])
        +
        (double)(ptns[p1id][1]-ptns[p2id][1])*(double)(ptns[p1id][1]-ptns[p2id][1])
        );
}
bool trg(double a,double b,double c){
    return max(a,max(b,c))*2.0<a+b+c;
}
int main()
{
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d%d", &ptns[i][0], &ptns[i][1]);
    }
    for (int fstPtn = 0; fstPtn < n; fstPtn++)
    {
        for (int secPtn = 0; secPtn < fstPtn; secPtn++)
        {
            ptnBtn[fstPtn][secPtn] =ptnBtn[secPtn][fstPtn] = std::__gcd(abs(ptns[fstPtn][0] - ptns[secPtn][0]), abs(ptns[fstPtn][1] - ptns[secPtn][1]));
        }
    }
    long long ans = 0;
    for (int fstPtn = 0; fstPtn < n; fstPtn++)
    {
        for (int secPtn = 0; secPtn < fstPtn; secPtn++)
        {
            for (int ap = 0; ap < n; ap++)
            {
                
                if(trg(ptdst(fstPtn,secPtn),ptdst(fstPtn,ap),ptdst(ap,secPtn))){
                    ans = max(ans,ptnBtn[fstPtn][secPtn]+ptnBtn[ap][secPtn]+ptnBtn[fstPtn][ap]);
                }
            }
        }
    }
    printf("%lld\n",ans);
    return 0;
}