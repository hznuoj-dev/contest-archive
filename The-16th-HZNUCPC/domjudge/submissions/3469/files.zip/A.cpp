#include<bits/stdc++.h>
using namespace std;

#define int long long

const int N = 2e5 +10, inf = 1e17, mod = 1e9 +7;

int n, m, k, x, y, a[N], b[N];
char s[N], p[N];

int v[N];
map<string,int>mp;
vector<int>G[N];
vector<string>H;
void run(){
    cin>>s+1>>p+1;
    n=strlen(s+1);

    for(int i=1;i<=n;i++){
        a[s[i]]++;
        b[p[i]]++;
        if(a[s[i]]==1)x++;
        if(b[p[i]]==1)y++;
    }

    if(abs(x-y) >= 5){
        cout<<0<<'\n';
        return;
    }
    for(int i=1;i<=n;i++){
        string h;
        h=s[i];
        h+=p[i];
        G[mp[h]].push_back(i);
    }
    int ans=0;
    for(int i=1;i<=n;i++){
        int u=x,v=y;
        string h;
        h=s[i];
        h+=p[i];
        a[s[i]]--;if(a[s[i]]==0)u--;
        b[p[i]]--;if(b[p[i]]==0)v--;
        a[p[i]]++;if(a[p[i]]==1)u++;
        b[s[i]]++;if(b[s[i]]==1)v++;
        for(string j:H){
            if(G[mp[j]].size()==0)continue;
            char t1 = j[0], t2 = j[1];
            a[t1]--;if(a[t1]==0)u--;
            b[t2]--;if(b[t2]==0)v--;
            a[t2]++;if(a[t2]==1)u++;
            b[t1]++;if(b[t1]==1)v++;

            if(u==v){
                ans+=G[mp[j]].size()-(j==h);
            }
            a[t1]++;if(a[t1]==1)u++;
            b[t2]++;if(b[t2]==1)v++;
            a[t2]--;if(a[t2]==0)u--;
            b[t1]--;if(b[t1]==0)v--;
        }
        a[s[i]]++;
        b[p[i]]++;
        a[p[i]]--;
        b[s[i]]--;
    }
    cout<<ans/2%mod<<'\n';
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int T;
    int cnt =1;
    for(int i=1;i<=26;i++){
        for(int j=1;j<=26;j++){
            string h;
            h= char(i+'a'-1);
            h+=char(j+'a'-1);
            mp[h]=cnt;
            cnt++;
            H.push_back(h);
        }
    }
    //for(cin>>T;T>0;T--)
    run();return 0;
}
//uM8Z0uwWsZ2O
