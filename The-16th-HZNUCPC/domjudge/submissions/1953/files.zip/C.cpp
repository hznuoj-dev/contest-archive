#include<bits/stdc++.h>

using namespace std;


typedef long long ll;

char x[100005];
char y[100005];

map<char,int> ft,sd;
map<pair<char,char>,long long> sz;
int cntx=0,cnty=0;

bool check(char a,char b,char c,char d){
    ft[b]++;
    if(ft[b]==1) cntx++;
    ft[a]--;
    if(ft[a]==0) cntx--;
    ft[d]++;
    if(ft[d]==1) cntx++;
    ft[c]--;
    if(ft[c]==0) cntx--;
    sd[a]++;
    if(sd[a]==1) cnty++;
    sd[b]--;
    if(sd[b]==0) cnty--;
    sd[c]++;
    if(sd[c]==1) cnty++;
    sd[d]--;
    if(sd[d]==0) cnty--;
    if(cntx == cnty) return true;
    else return false;
}

int main(){
    scanf("%s",&x);
    scanf("%s",&y);
    int n=strlen(x);
    for(int i=0;i<n;i++){
        pair<char,char> iter = make_pair(x[i],y[i]);
        sz[iter]++;
        ft[x[i]]++;
        if(ft[x[i]] == 1) cntx++;
        sd[y[i]]++;
        if(sd[y[i]] == 1) cnty++;
    }
    long long ans=0;
    long long ans2=0;
    for(char a='a';a<='z';a++){
        for(char b='a';b<='z';b++){
            for(char c='a';c<='z';c++){
                for(char d='a';d<='z';d++){
                    if(a==c&&b==d){
                        if(!sz.count(make_pair(a,b)))
                            continue;
                        long long ct = sz[make_pair(a,b)];
                        if(check(a,b,c,d))
                            ans += ct*(ct-1)/2;
                        check(b,a,d,c);
                    }
                    else{
                        if(!sz.count(make_pair(a,b)))
                            continue;
                        if(!sz.count(make_pair(c,d)))
                            continue;
                        long long ct1 = sz[make_pair(a,b)];
                        long long ct2 = sz[make_pair(c,d)];
                        if(check(a,b,c,d)){
                            ans2+=ct1*ct2;
                        }
                        check(b,a,d,c);
                    }
                }
            }
        }
    }
    cout<<(ans+ans2/2)%(1e9+7)<<endl;
    return 0;
}
