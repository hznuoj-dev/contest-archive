#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll x[150],y[150];
int can(int a,int b,int c)
{
	if(x[a]==x[b])
	{
		if(x[c]==x[a]) return 0;
		else return 1;
	}
	if(x[c]==x[b])
	{
		if(x[c]==x[a]) return 0;
		else return 1;
	}
	if((y[a]-y[b])*(x[b]-x[c])==(y[b]-y[c])*(x[a]-x[b])) return 0;
	else return 1;
}
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		scanf("%lld%lld",&x[i],&y[i]);
	ll sum=0,ans=0;
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			for(int k=j+1;k<n;k++)
			{
				sum=0;
				if(!can(i,j,k)) continue;
				
				ll a=abs(y[i]-y[j]);
				ll b=abs(x[i]-x[j]);
				if(a==0||b==0)
				{
					if(a==0) sum+=b+1;
					else sum+=a+1;
				}
				else
				{
					ll g=__gcd(a,b);
					b/=g;
					ll d=abs(x[i]-x[j])/b;
					sum+=d+1;	
				}
				
				a=abs(y[i]-y[k]);
				b=abs(x[i]-x[k]);
				if(a==0||b==0)
				{
					if(a==0) sum+=b+1;
					else sum+=a+1;
				}
				else
				{
					ll g=__gcd(a,b);
					b/=g;
					ll d=abs(x[i]-x[k])/b;
					sum+=d+1;	
				}
				
				
				a=abs(y[j]-y[k]);
				b=abs(x[j]-x[k]);
				if(a==0||b==0)
				{
					if(a==0) sum+=b+1;
					else sum+=a+1;
				}
				else
				{
					ll g=__gcd(a,b);
					b/=g;
					ll d=abs(x[k]-x[j])/b;
					sum+=d+1;	
				}
				
				sum-=3;
				ans=max(ans,sum);
				
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}