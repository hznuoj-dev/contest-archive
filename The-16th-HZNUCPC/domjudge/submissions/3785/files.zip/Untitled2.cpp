#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(flase);cin.tie(0);cout.tie(0)
int n,m;
signed main(){
	cin>>n>>m;
	if(m==1||n==1){
		cout<<"YES"<<endl;
	}else{
		if(n<=m){
			cout<<"NO"<<endl;
		}else{
			int p=n%m;
			if(p==0){
				cout<<"NO"<<endl;
			}else if(p==1)cout<<"YES"<<endl;
			while(p>1){
				if(n%p==0){
					cout<<"NO"<<endl;
					break;
				}
				if(n%p==1){
					cout<<"YES"<<endl;
					break;
				}
				p=n%p;
			}
		}
	}
	return 0;
}