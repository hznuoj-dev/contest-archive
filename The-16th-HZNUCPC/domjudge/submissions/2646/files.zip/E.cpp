#include "bits/stdc++.h"
using namespace std;
struct CC{
	long long x,y;
}fj[105];
int main(){
	long long n;
	while(cin >> n){
		long long a,b;
		for(long long i = 0; i < n; i ++){
			cin >> a >> b;
			fj[i].x=a;
			fj[i].y=b;
		}
		long long max=0;
		for(long long i=0;i<n-2;i++){
			for(long long j=i+1;j<n-1;j++){
				for(long long m=j+1;m<n;m++){
					long long sum=0;
					long long a=fj[i].x;
					long long b=fj[i].y;
					long long c=fj[j].x;
					long long d=fj[j].y;
					long long g=fj[m].x;
					long long h=fj[m].y;
					double aa=abs(a),bb=abs(b),cc=abs(c),dd=abs(d),gg=abs(g),hh=abs(h);
					if(bb/aa==dd/cc&&dd/cc==hh/gg)continue;
					long long f=__gcd(abs(d-b),abs(c-a));
					sum+=abs(f);
					c=fj[m].x;
					d=fj[m].y;
					f=__gcd(abs(d-b),abs(c-a));
					sum+=abs(f);
					a=fj[j].x;
					b=fj[j].y;
					f=__gcd(abs(d-b),abs(c-a));
					sum+=abs(f);
					if(sum>max)max=sum;
				}
			}
		}
		cout << max << endl;
	}
	return 0;
}
