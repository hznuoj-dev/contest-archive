#include<bits/stdc++.h>
using namespace std;
inline int read(){
    int x=0,f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c))x=x*10+c-48,c=getchar();
    return x*f;
}
long long n,m;
int main(){
    scanf("%lld%lld",&n,&m);
    while(1){
        if(m==1){puts("YES");break;}
        if(n%m==0){puts("NO");break;}
        m=n%m;
    }
    return 0;
}