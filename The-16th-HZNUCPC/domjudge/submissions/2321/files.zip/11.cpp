#include <bits/stdc++.h>

typedef long long ll;

using namespace std;

int T,n,x,y,c;

int main()
{
    cin>>T;
    while(T--)
    {
        cin>>n;
        int res=0;
        int dp[20][20]={0};
        while(n--)
        {
            cin>>x>>y>>c;
            if (c==2) dp[x][y]==2;
            else
            {
                dp[x][y]=1;
                if (dp[x][y-1]!=1 && dp[x][y-1]!=2)
                {
                    if (dp[x][y-1]==0) dp[x][y-1]=3;
                    else dp[x][y-1]++;
                }
                if (dp[x][y+1]!=1 && dp[x][y+1]!=2)
                {
                    if (dp[x][y+1]==0) dp[x][y+1]=3;
                    else dp[x][y+1]++;
                }
                if (dp[x-1][y]!=1 && dp[x-1][y]!=2)
                {
                    if (dp[x-1][y]==0) dp[x-1][y]=3;
                    else dp[x-1][y]++;
                }
                if (dp[x+1][y]!=1 && dp[x+1][y]!=2)
                {
                    if (dp[x+1][y]==0) dp[x+1][y]=3;
                    else dp[x+1][y]++;
                }
            }

        }
        for(int i=1;i<=19;i++)
        {

            for(int j=1;j<=19;j++)
            {

                if (dp[i][j]>=3)
                    res += (dp[i][j]-2);

            }
        }

        cout<<res<<endl;
    }

    return 0;
}
