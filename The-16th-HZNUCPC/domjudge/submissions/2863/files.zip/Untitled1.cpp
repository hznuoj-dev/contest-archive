#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=1e9+7;
vector<pair<int,int>> vp;
const int inf=0x3f3f3f3f;
#define debug(x) cerr<<#x<<" = "<<x<<endl
void solve() {
//	debug(__gcd(4,2));
//cerr<<s(2,2,3,3,2,4)<<endl;
	set<pair<int,int>> sp;
	set<double> st;
	int ad=0;
	int n;
	cin>>n;
	int res=3;
	vp.push_back({0,0});
	int xx,yy;
	cin>>xx>>yy;
	vp.push_back({xx,yy});
//	sp.insert({xx,yy});
	for(int i=2; i<=n; i++) {
		int x,y;
		cin>>x>>y;
		//if(sp.count({x,y})) {
		//		continue;
		//	}
		vp.push_back({x,y});
		//	sp.insert({x,y});
		if(x==xx) {
			//if(y==xx) continue;
			ad=1;
		} else st.insert((double)(y-yy)/(x-xx));
		//debug((float)y/x);
	}
//	cerr<<st.size()<<endl;
	/*
	for(int i=1; i<=n; i++) {

		for(int j=1; j<=n; j++) {
			if(j==i) continue;
			for(int k=1; k<=n; k++) {
				if(k==i||k==j) continue;
				res=max(res,s(vp[i].first,vp[i].second,vp[j].first,vp[j].second,vp[k].first,vp[k].second));
				if(res==3) cout<<i<<" "<<j<<" "<<k<<endl;
			}
		}
	}
	*/
	//if(res==0)cout<<0<<endl;
	//else {

	//res=3;
	//n=sp.size();
	int bl=0;
	int c1,c2,c3;
	if(st.size()+ad<=1) {
		cout<<0<<endl;
		return;
	}
	int mx=0;
	for(int i=1; i<=n; i++) {
		for(int j=i+1; j<=n; j++) {
			//if(j==i) continue;
			int x=abs(vp[i].first-vp[j].first);
			int y=abs(vp[i].second-vp[j].second);
			//if(x<y) swap(x,y);
			if(x==0) {
				if(y==0) continue;
				else c1=y-1;
			} else if(y==0) {
				if(x==0) continue;
				else c1=x-1;
			} else {
				c1=__gcd(x,y)-1;
			}
			//debug(c1);
			for(int k=j+1; k<=n; k++) {
				//	if(k==i||k==j) continue;

				x=abs(vp[i].first-vp[k].first);
				y=abs(vp[i].second-vp[k].second);
				//if()
				//debug(x),debug(y);
				if(x==0) {
					if(y==0) continue;
					else c2=y-1;
				} else if(y==0) {
					if(x==0) continue;
					else c2=x-1;
				} else c2=__gcd(x,y)-1;
				x=abs(vp[j].first-vp[k].first);
				y=abs(vp[j].second-vp[k].second);
				if(x==0) {
					if(y==0) continue;
					else c3=y-1;
				} else if(y==0) {
					if(x==0) continue;
					else c3=x-1;
				} else c3=__gcd(x,y)-1;
				mx=max(mx,c1+c2+c3);
				bl=1;
				//cout<<c1<<" "<<c2<<" "<<c3<<endl;
			}
		}
	}
	if(bl)
	cout<<mx+res<<endl;
	else cout<<0<<endl;
}


int main() {
	int t=1;
//	cin>>t;
	while(t--) {
		solve();
	}
}