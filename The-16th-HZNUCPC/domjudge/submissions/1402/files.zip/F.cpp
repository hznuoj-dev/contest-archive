#include<iostream>
#include<cstring>
using namespace std;
int main(){
	int n,m;
	cin>>n>>m;
	while(m>1){
		m=n%m;
	}
	if(m==0)cout<<"NO";
	else cout<<"YES";
}