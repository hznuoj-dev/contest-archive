#include<bits/stdc++.h>
//#define int long long
//#define mid (l+r>>1)
using namespace std;
typedef long long ll;
const int mod=1e9+7;
int cnt1[27],cnt2[27];
int ts1=0,ts2=0;
char s1[100005],s2[100005];
bool f1[27],f2[27];
int ex[6][6];
int sum[6];
int main(){
	scanf("%s%s",s1,s2);
	for(int i=0;i<strlen(s1);i++){
		cnt1[s1[i]-'a']++;
		cnt2[s2[i]-'a']++;
		if(cnt1[s1[i]-'a']==1)ts1++;
		if(cnt2[s2[i]-'a']==1)ts2++;
	}
	//abbd
	//acad
	for(int i=0;i<strlen(s1);i++){
		if(cnt1[s1[i]-'a']==2&&cnt2[s2[i]-'a']==1)f1[s1[i]-'a']++;
		if(cnt2[s2[i]-'a']==2&&cnt1[s1[i]-'a']==1)f2[s2[i]-'a']++;
	}
	for(int i=0;i<=26;i++){
		if(f1[i]==1){
			ex[2][3]++;
			ex[2][2]--;
		}
		if(f2[i]==1){
			ex[1][2]++;
			ex[2][2]--;
			cout<<ex[2][2]<<endl;
		}
	}
	for(int i=0;i<strlen(s1);i++){
		int d=0;
		if(s1[i]==s2[i]){
			sum[2]++;
			continue;
		}
		if(cnt1[s1[i]-'a']-1==0)d+=1;
		if(cnt2[s2[i]-'a']-1==0)d-=1;
		if(cnt1[s2[i]-'a']+1==1)d-=1;
		if(cnt2[s1[i]-'a']+1==1)d+=1;
		sum[d+2]++;
	}
//	for(int i=0;i<5;i++){
//		printf("#%d:%d\n",i-2,sum[i]);
//	}
	int ans=0;
	for(int i=-2;i<3;i++){
		for(int j=i;j<3;j++){
			
			
			if(i+j==ts1-ts2){
			//	cout<<i<<" "<<j<<endl;
				if(i==j){
					ans=(ans+(ll)(sum[i+2]-1)*sum[i+2]/2)%mod;	
					ans-=ex[i+2][j+2]/2;
				//		cout<<"ex:"<<ex[i+2][j+2]<<endl;
				}else{ 
					ans=(ans+(ll)sum[i+2]*sum[j+2])%mod;
					ans-=ex[i+2][j+2];
				//	cout<<"ex:"<<ex[i+2][j+2]<<endl;
				}
			//	cout<<"ans:"<<ans<<endl;
			}
		}
	}printf("%d\n",ans);
	return 0;	
}