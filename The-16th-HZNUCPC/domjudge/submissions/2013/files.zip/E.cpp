#include<bits/stdc++.h>
using namespace std;

#define int long long
const int N = 110;
typedef long long ll;
typedef pair<int, int> p;
pair<int, int> nodes[N];
#define x first
#define y second

int gcd(int a, int b) {
	if (!b) return a;
	return gcd(b, a % b);
}

long long get_point_nums(p p1, p p2, p p3, p p4) {
	if (p3.x <= p1.x || p3.y <= p4.y) return 0;
	return 1ll * (p3.x - p1.x + 1) * (p3.y - p4.y + 1);
}

long long get_inner_point_nums(p p1, p p2, p p3, p p4) {
	p1.x++, p1.y--;
	p2.x++, p2.y++;
	p3.x--, p3.y--;
	p4.x--, p4.y++;
	return get_point_nums(p1, p2, p3, p4);
}

long long get_line_point_nums(p p1, p p2, p p3, p p4) {
	if (p3.x <= p1.x || p3.y <= p4.y) return 0;
	int x = p3.x - p1.x, y = p3.y - p4.y;
	int gcd_num = gcd(x, y);
	return max(gcd_num - 1, 0ll);
}

long long get_tringle_point_nums(p p1, p p2, p p3, p p4) {
	long long cnt = get_line_point_nums(p1, p2, p3, p4);
	long long nums = max(get_inner_point_nums(p1, p2, p3, p4) - cnt, 0ll) / 2;
	nums += (p3.x - p1.x) + (p1.y - p2.y) + 1;
	return max(nums, 0ll);
}

int calc_tringle(p pa, p pb) {
	int minx = min(pa.x, pb.x);
	int maxx = max(pa.x, pb.x);
	int miny = min(pa.y, pb.y);
	int maxy = max(pa.y, pb.y);
	p p1 = {minx, maxy}, p2 = {minx, miny}, p3 = {maxx, maxy}, p4 = {maxx, miny};
	return get_tringle_point_nums(p1, p2, p3, p4);
}

long long calc(p pa, p pb) {
	long long x = max(pa.x, pb.x) - min(pa.x, pb.x);
	long long y = max(pb.y, pb.y) - min(pa.y, pb.y);
	int num = gcd(x, y);
	return num - 1;
}

long long calc(p pa, p pb, p pc) {
//	int minx = min(pa.x, min(pb.x, pc.x));
//	int maxx = max(pa.x, max(pb.x, pc.x));
//	int miny = min(pa.y, min(pb.y, pc.y));
//	int maxy = max(pa.y, max(pb.y, pc.y));
//	
//	p p1 = {minx, maxy}, p2 = {minx, miny}, p3 = {maxx, maxy}, p4 = {maxx, miny};
//	
//	ll total = get_point_nums(p1, p2, p3, p4);
//	
//	printf("total = %lld\n", total);
//	printf("pa %lld %lld\n", pa.x, pa.y);
//	printf("pb %lld %lld\n", pb.x, pb.y);
//	printf("pc %lld %lld\n", pc.x, pc.y);
//	
//	ll c1, c2;
//	ll c1 = max(calc_tringle(pa, pb) - 2, 0ll);
//	ll c2 = max(calc_tringle(pa, pc) - 2, 0ll);
//	ll c3 = max(calc_tringle(pb, pc) - 2, 0ll);
//	
//	printf("c1 = %lld, c2 = %lld c3 = %lld\n", c1, c2, c3);
	
	return calc(pa, pb) + calc(pa, pc) + calc(pb, pc) + 3;
}

void solve() {
	int n;
	scanf("%lld", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%lld%lld", &nodes[i].x, &nodes[i].y);
	}
	long long res = 0;
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			for (int k = j + 1; k <= n; k++) {
				res = max(res, calc(nodes[i], nodes[j], nodes[k]));
//				printf("i = %d, j = %d, k = %d calc = %lld\n", i, j, k)
			}
		}
	}
	printf("%lld\n", res);
}
 
signed main() {
	solve();
	return 0;
}