#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
ll n, k;
void solve()
{
	cin >> n >> k;
	while(k > 1) {
		if(n % k == 0) {
		cout << "NO\n";
		return;
		}
		k = n % k;
	}
	cout << "YES\n";
}

int main()
{
	IOS
	int T = 1;
//	cin >> T;
	while(T--) 
		solve();	
	return 0;
}