#include <bits/stdc++.h>
using namespace std;

const int inf = 0x3f3f3f3f;
const int Maxn = 300000 + 10;

struct segment_tree {
	int tree[Maxn << 2], lazy[Maxn << 2];
	void push_up(int p) {
		tree[p] = min(tree[p << 1], tree[p << 1 | 1]);
	}
	void build(int l, int r, int p) {
		lazy[p] = inf;
		if (l == r) {
			tree[p] = inf;
			return;
		}
		int mid = (l + r) >> 1;
		build(l, mid, p << 1);
		build(mid + 1, r, p << 1 | 1);
		push_up(p);
	}
	void f(int l, int r, int p, int k) {
		tree[p] = min(tree[p], k);
		lazy[p] = min(lazy[p], k);
	}
	void push_down(int l, int r, int p) {
		if (l == r) return;
		int mid = (l + r) >> 1;
		f(l, mid, p << 1, lazy[p]);
		f(mid + 1, r, p << 1 | 1, lazy[p]);
		lazy[p] = inf;
	}
	void modify(int nl, int nr, int l, int r, int p, int x) {
		if (nl <= l && r <= nr) {
			f(l, r, p, x);
			return;
		}
		push_down(l, r, p);
		int mid = (l + r) >> 1;
		if (nl <= mid) modify(nl, nr, l, mid, p << 1, x);
		if (mid < nr) modify(nl, nr, mid + 1, r, p << 1 | 1, x);
		push_up(p);
//		cout << p << " " << lazy[p] << " " << tree[p] << "nnn" << endl;
	}
	int query(int x, int l, int r, int p) {
//		cout << l << " " << r << " " << p << " " << tree[p] << endl;
		if (l == r) return tree[p];
		push_down(l, r, p);
		int mid = (l + r) >> 1, ans = inf;
		if (x <= mid) ans = query(x, l, mid, p << 1);
		else ans = query(x, mid + 1, r, p << 1 | 1);
//		cout << l << " " << r << " " << p << " " << ans << endl;
		return ans;
	}
	int query(int nl, int nr, int l, int r, int p) {
		if (nl <= l && r <= nr) return tree[p];
		push_down(l, r, p);
		int mid = (l + r) >> 1, ans = inf;
		if (nl <= mid) ans = min(ans, query(nl, nr, l, mid, p << 1));
		if (mid < nr) ans = min(ans, query(nl, nr, mid + 1, r, p << 1 | 1));
		return ans;
	}
}t;

struct bus {
	int t, l, r;
	bool operator < (const bus& rhs) const {
		if (t != rhs.t) return t < rhs.t;
		if (r != rhs.r) return r < rhs.r;
		return l < rhs.l;
	}
} b[Maxn];

struct human {
	int t, pos, ans, loc;
} h[Maxn];

int cmp_t(human a, human b) {
	return a.t < b.t;
}

int cmp_loc(human a, human b) {
	return a.loc < b.loc;
}

int cnt = 0;
int c[Maxn];

signed main() {
	ios::sync_with_stdio(false);
	
	int n, m, x; cin >> n >> m >> x;
	c[++cnt] = x;
	for(int i = 1; i <= n; ++i) {
		cin >> b[i].t >> b[i].l >> b[i].r;
		c[++cnt] = b[i].l;
		c[++cnt] = b[i].r;
	}
	for(int i = 1; i <= m; ++i) {
		cin >> h[i].t >> h[i].pos;
		h[i].ans = -1;
		h[i].loc = i;
		c[++cnt] = h[i].pos;
	}
	sort(b + 1, b + n + 1);
	sort(h + 1, h + m + 1, cmp_t);
	
	sort(c + 1, c + cnt + 1);
	cnt = unique(c + 1, c + cnt + 1) - c - 1;
	for(int i = 1; i <= n; ++i) {
		b[i].l = lower_bound(c + 1, c + cnt + 1, b[i].l) - c;
		b[i].r = lower_bound(c + 1, c + cnt + 1, b[i].r) - c;
	}
	for(int i = 1; i <= m; ++i) {
		h[i].pos = lower_bound(c + 1, c + cnt + 1, h[i].pos) - c;
	}
	x = lower_bound(c + 1, c + cnt + 1, x) - c;
	
	int human_point = m;

//	for(int i = 1; i <= n; ++i) cout << b[i].l << " " << b[i].r << endl;
//	for(int i = 1; i <= m; ++i) cout << h[i].pos << endl;
	
	t.build(1, cnt, 1);
	t.modify(x, x, 1, cnt, 1, 0);
	
//	for (int i = 1; i <= x * 4; ++i) {
//		cout << t.tree[i] << " ";
//	}cout << endl;
	
//	cout << h[m].pos << " " << t.query(h[m].pos, 1, cnt, 1);
	for (int i = n; i >= 1; --i) {
		while(human_point >= 1 && h[human_point].t > b[i].t) {
			int ans = t.query(h[human_point].pos, 1, cnt, 1);
			if (ans == inf) ans = -1;
			h[human_point].ans = ans;
			human_point --;
		}
		int minn = t.query(b[i].l, b[i].r, 1, cnt, 1);
		t.modify(b[i].l, b[i].r, 1, cnt, 1, minn + 1);
	}
	
	while(human_point >= 1) {
		int ans = t.query(h[human_point].pos, 1, cnt, 1);
		if (ans == inf) ans = -1;
		h[human_point].ans = ans;
		human_point --;
	}
	
	sort(h + 1, h + m + 1, cmp_loc);
	for(int i = 1; i <= m; ++i) {
		cout << h[i].ans << "\n";
	}
	return 0;
}