#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
typedef long long ll;
int a[1000][1000],sum,T,n;
int c[1000],x[1000],y[1000];
int d[5][2]={{0,0},{0,1},{1,0},{-1,0},{0,-1}};
int main(){
scanf("%d",&T);
while (T--)
 {
 	for (int i=0;i<=20;i++)
 	for (int j=0;j<=20;j++)
 	  a[i][j]=0;
 	scanf("%d",&n);sum=0;
 	for (int i=1;i<=n;i++)
 	   	{
 	   		
			scanf("%d%d%d",&x[i],&y[i],&c[i]);
		a[x[i]][y[i]]=c[i];
		}
  	for (int k=1;k<=n;k++)
 	   	{
		if (c[k]==1)
		  {
		  	for (int i=1;i<=4;i++)
		  	  {
			  int xx=x[k]+d[i][0];
			  int yy=y[k]+d[i][1];
			  if (xx>=1&&xx<=19&&yy>=1&&yy<=19)
			    if (a[xx][yy]==0)
			      {
			      	sum++;
			      	//a[xx][yy]=-1;
				  }
			  }
		  }
		}
	cout<<sum<<endl;
 }



}