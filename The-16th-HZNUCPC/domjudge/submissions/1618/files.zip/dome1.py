q = int(input())

def func(x:int, y:int):
    if 0 < x < 20 and 0 < y < 20:
        if (x, y) in place:
            pass
        elif (x, y) in space:
            space[(x, y)] += 1
        else:
            space[(x, y)] = 1

for _ in range(q):
    n = int(input())
    place = {}
    dicwhite = {}
    dicblack = {}
    space = {}
    for _ in range(n):
        x, y, c = map(int, input().split())
        if c == 1:
            dicblack[(x, y)] = 1
            place[(x, y)] = 1
        else:
            dicwhite[(x, y)] = 1
            place[(x, y)] = 1
    for i in dicblack:
        x = i[0]
        y = i[1]
        func(x + 1, y)
        func(x - 1, y)
        func(x, y + 1)
        func(x, y - 1)
    print(sum(space.values()))

        