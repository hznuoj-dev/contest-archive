#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#define maxn 100010
#define ll long long
using namespace std;

const int p = 1000000007;
int pow_mod(int x, int n) { 
	int s = 1;
	for (; n; n >>= 1, x = 1ll * x * x % p)
		if (n & 1) s = 1ll * s * x % p;
	return s;
}
const int mod2 = pow_mod(2, p - 2); 

char s[maxn], t[maxn];

int a[26][26], n, sz1[26], sz2[26], cnt1, cnt2;

ll ans;

inline void add(int *sz, int &cnt, int ch) { 
	if (++sz[ch] == 1) ++cnt;
}
inline void del(int *sz, int &cnt, int ch) { 
	if (--sz[ch] == 0) --cnt;
}

int main() { 
	ios::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr); 
	
	cin >> s + 1 >> t + 1; 
	n = strlen(s + 1); 
	for (int i = 1; i <= n; ++i) 
		++a[s[i] - 'a'][t[i] - 'a'];
	for (int i = 1; i <= n; ++i) ++sz1[s[i] - 'a'];
	for (int i = 1; i <= n; ++i) ++sz2[t[i] - 'a'];
	for (int i = 0; i < 26; ++i) 
		cnt1 += sz1[i] > 0, cnt2 += sz2[i] > 0;
	for (int i = 0; i < 26; ++i) 
		for (int j = 0; j < 26; ++j) {
			add(sz1, cnt1, j), del(sz1, cnt1, i);
			add(sz2, cnt2, i), del(sz2, cnt2, j);
			for (int x = 0; x < 26; ++x)
				for (int y = 0; y < 26; ++y) {
					add(sz1, cnt1, y), del(sz1, cnt1, x);
					add(sz2, cnt2, x), del(sz2, cnt2, y);
					if (cnt1 == cnt2) {
						if (i == x && j == y) ans += 1ll * a[i][j] * (a[i][j] - 1) % p * mod2 % p;
						else ans += 1ll * a[i][j] * a[x][y] % p * mod2 % p;
					}
					del(sz1, cnt1, y), add(sz1, cnt1, x);
					del(sz2, cnt2, x), add(sz2, cnt2, y);
				}
			del(sz1, cnt1, j), add(sz1, cnt1, i);
			del(sz2, cnt2, i), add(sz2, cnt2, j);
		}
	cout << ans << endl;
	return 0; 
} 