#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	int n,m;
	cin>>n>>m;
	if(n == 1){
		cout<<"Yes\n";
		return 0;
	}
	vector<int> p;
	for(int i = 2 ; i*i <= n ; i++){
		if(n % i == 0){
			while(n % i ==0) {
				n/=i;
			}
			p.push_back(i);
		}
	}
	if(n != 1) p.push_back(n);
	if(m >= p[0]) cout<<"No\n";
	else cout<<"Yes\n";
	return 0;
}