#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define debug(x) cerr<<#x<<" "<<x<<"\n"

void _solve(){
    string s;cin>>s;
    int ans=0;
    int n=s.length();
    for(int i=0;i<n;i++){
        vector<pair<char,char> >vec;
        for(int R=1;;R++){
            int l=i-R;
            int r=i+R;
            if(l<0||r>=n) break;
            if(s[l]==s[r]){
                if(vec.size()==0||vec.size()==2)
                    ans=max(ans,r-l+1);
                continue;
            }
            if(vec.size()==2) break;
            vec.push_back({s[l],s[r]});
            if(vec.size()==1) continue;
            else if(vec.size()==2){
                if(vec[0]==vec[1]){
                    ans=max(ans,r-l+1);
                    continue;
                }
                swap(vec[0].first,vec[0].second);
                if(vec[0]==vec[1]){
                    ans=max(ans,r-l+1);
                    continue;
                }
                break;
            }
        }
    }

    for(int i=0;i<n;i++){
        vector<pair<char,char> >vec;
        for(int R=1;;R++){
            int l=i-R+1;
            int r=i+R;
            if(l<0||r>=n) break;
            if(s[l]==s[r]){
                if(vec.size()==0||vec.size()==2)
                    ans=max(ans,r-l+1);
                continue;
            }
            if(vec.size()==2) break;
            vec.push_back({s[l],s[r]});
            if(vec.size()==1) continue;
            else if(vec.size()==2){
                if(vec[0]==vec[1]){
                    ans=max(ans,r-l+1);
                    continue;
                }
                swap(vec[0].first,vec[0].second);
                if(vec[0]==vec[1]){
                    ans=max(ans,r-l+1);
                    continue;
                }
                break;
            }
        }
    }

    for(int i=0;i<n;i++){
        int f=0;
        for(int R=1;;R++){
            int l=i-R;
            int r=i+R;
            if(l<0||r>=n) break;
//            debug(s[i]);
//            debug(s[l]);
//            debug(s[r]);
            if(s[l]==s[r]){
                ans=max(ans,r-l+1);
                continue;
            }
            if(s[l]==s[i]||s[r]==s[i]){
                if(f){
                    break;
                }
                ans=max(ans,r-l+1);
//                debug(r-l+1);
                f=1;
            }
            else break;
        }
    }
    cout<<ans<<"\n";
}

int main(){
    ios::sync_with_stdio(false);

    int T;cin>>T;while(T--)
    _solve();
}
