#include<bits/stdc++.h>

using namespace std;

#define int long long

const int N = 1e5 + 10, mod = 1e9 + 7;

int ca[26], cb[26], c[26][26];

signed main() {
	string a, b;
	cin >> a >> b;
	for (auto c : a) {
		ca[c - 'a'] ++;
	}
	for (auto c : b) {
		cb[c - 'a'] ++;
	}
	for (int i = 0; i < a.size(); i ++) {
		c[a[i]-'a'][b[i]-'a'] ++;
	}
	int ans = 0;
	for (int i = 0; i < 26; i ++)
		for (int j = 0; j < 26; j ++) {
			int res = c[i][j];
			int ta[26], tb[26];
			for (int k = 0; k < 26; k ++)
				ta[k] = ca[k], tb[k] = cb[k];
			if (ta[i] < 1 || tb[j] < 1) continue;
			ta[i] --, ta[j] ++;
			tb[i] ++, tb[j] --;
			c[i][j] --;
			for (int k = 0; k < 26; k ++) 
				for (int p = 0; p < 26; p ++) {
					if (ta[k] < 1 || tb[p] < 1) continue;
					ta[k] --, ta[p] ++;
					tb[k] ++, tb[p] --;
					int cnt1 = 0, cnt2 = 0;
					for (int ii = 0; ii < 26; ii ++) {
						if (ta[ii]) cnt1 ++;
						if (tb[ii]) cnt2 ++;
					}
					if (cnt1 == cnt2) {
						ans += res * c[k][p];
//						cout << i << ' ' << j << ' ' << k << ' ' << p << '\n';
//						cout << res << ' ' << c[k][p] << '\n';
					}	
					ta[k] ++, ta[p] --;
					tb[k] --, tb[p] ++;
				}
			c[i][j] ++;
		}
	cout << (ans % mod)/2 << '\n';
		
	
	
	
}