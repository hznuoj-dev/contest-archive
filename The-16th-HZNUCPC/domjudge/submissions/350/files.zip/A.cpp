#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+10;
int vis[30][30];
int dx[]={0,0,1,-1};
int dy[]={1,-1,0,0};
int x[N],y[N],c[N];
bool check(int x,int y)
{
	if(x>=1&&x<=19&&y>=1&&y<=19) return true;
	return false;
}
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		for(int i=1;i<=19;i++) 
		{
			for(int j=1;j<=19;j++) vis[i][j]=0;
		}
		int ans=0;
		for(int i=1;i<=n;i++) 
		{
			cin>>x[i]>>y[i]>>c[i];
			vis[x[i]][y[i]]=1;
		}
		for(int i=1;i<=n;i++)
		{
			int xx,yy;
			xx=x[i],yy=y[i];
			if(c[i]==2) continue;
			for(int j=0;j<4;j++)
			{
				int ax=xx+dx[j];
				int ay=yy+dy[j];
				if(check(ax,ay)) 
				{
					if(!vis[ax][ay]) ans++;
				}
			}
		}
		cout<<ans<<"\n";
	}	
	return 0;	
}
