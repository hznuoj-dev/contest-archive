#include<bits/stdc++.h>
using namespace std;
const int N=5e3+7;
int t,n,ans;
char s[N];
int cnt[30];
void check(int l,int r){
	int flag=0,lstx=0,lsty=0,flag2=0;
	while(l>=1&&r<=n){
		
		if(s[l]!=s[r]){
			if(!flag){
				int x=s[l]-'a'+1;
				int y=s[r]-'a'+1;
				if(lstx){
					
					if(lstx==x&&lsty==y||lstx==y&&lsty==x)flag=1;
					else break;
				}
				else{
					lstx=x;lsty=y;
				}
			}
			else break;
		}
		if(s[l]==s[r]&&r!=l)flag2=1;
		if(flag||flag2&&!lstx){
			ans=max(ans,r-l+1);
		}
		r++;l--;
	}
}
void check1(int l,int r){
	int lstx=s[l]-'a'+1;l--;r++;int flag=0;
	while(l>=1&&r<=n){
		if(s[l]!=s[r]){
			int x=s[l]-'a'+1,y=s[r]-'a'+1;
			if(x==lstx||y==lstx)flag=1;
			else break;
		}
		if(flag)ans=max(ans,r-l+1);
		l--;r++;
	}
}
signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>t;
	while(t--){
		cin>>(s+1);n=strlen(s+1);
		ans=0;
		for(int i=1;i<=n;i++){
			check(i,i);check1(i,i);
			if(i>1)check(i-1,i);
		}
		cout<<ans<<"\n";
	}
	return 0;
}