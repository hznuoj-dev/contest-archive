#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

const ll N = 1e6 + 10;
ll x[N], y[N];


ll gcd(ll a, ll b)
{
    return b == 0 ? a : gcd(b, a % b);
}
int dir[][2] = {1,0,0,1,-1,0,0,-1};
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int t;
    cin>>t;
    while(t--){
        int n;
        cin>>n;
        vector<pair<int,int> > v;
        set<pair<int,int> > st;
        for(int i=1;i<=n;i++){
            int x,y,op;
            cin>>x>>y>>op;
            v.push_back({x,y});
            if(op==2) continue;
            for(int k=0;k<4;k++){
                int xx = x+dir[k][0];
                int yy = y+dir[k][1];
                st.insert({xx,yy});
            }
        }
        for(auto x:v){
            st.erase(x);
        }
        cout<<st.size()<<endl;
    }
}