#include<bits/stdc++.h>
using namespace std;
const int N = 1e5+10;
const long long Mod = 1e9+7;
char mp1[N],mp2[N];
int p1,p2;
int main() {
	cin>>mp1>>mp2;
	for(int i=0 ; i<strlen(mp1);i++){
		if(mp1[i] != mp2[i]){
			p1=i;
			break;
		}
	}
	for(int i=strlen(mp1)-1 ; i>=0;i--){
		if(mp1[i] != mp2[i]){
			p2=i;
			break;
		}
	}
	cout<<p1<<" "<<p2<<endl;
	if(p1==p2 && p1==0) {
		int sum = 0;
		for(int i=1;i<strlen(mp1);i++){
			sum+=i;
			sum%=Mod;
		}
		cout<<sum%Mod<<endl;
	} else if(p1 == p2) {
		int sum = 0;
		for(int i=1;i<strlen(mp1)-(p2-p1);i++){
			sum+=i;
			sum%=Mod;
		}
		cout<<sum%Mod<<endl;
	} else {
		int sum = 0;
		for(int i=1;i<strlen(mp1)-(p2-p1+1);i++){
			sum+=i;
			sum%=Mod;
		}
		cout<<(sum+1)%Mod<<endl;
	}
	return 0;
}