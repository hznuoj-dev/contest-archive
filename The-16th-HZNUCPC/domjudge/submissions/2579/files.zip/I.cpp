#include<bits/stdc++.h>
using namespace std;
#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const int maxn=1e5+10;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
#define int long long


void resolve(){
	string s;cin>>s;
	int n=s.length();
	int ans=0;
	// ji not change center
	for(int i=0;i<n;i++){
		int flag=0;
		int sum=1;
		vector<char>vec;
		for(int len=1;;len++){
			if(i-len<0||i+len>=n){
				if(flag==0&&sum>1){
					ans=max(ans,sum);
				}
				break;
			}
			else{
				if(s[i-len]==s[i+len]){
					sum+=2;
					if(flag==0||flag==2){
						ans=max(sum,ans);
					}
				}
				else{
					if(flag==1){
						flag=2;
						vec.push_back(s[i-len]);
						vec.push_back(s[i+len]);
						
						sort(vec.begin(),vec.end());
						if(vec[0]==vec[1]&&vec[3]==vec[2]){
							sum+=4;
							ans=max(ans,sum);
						}
					}
					else if(flag==0){
						flag=1;
						vec.push_back(s[i-len]);
						vec.push_back(s[i+len]);
					}
					else{
						break;
					}
				
				}
			}
		}
	}
	// ji change center
	for(int i=0;i<n;i++){
		int flag=0;
		int sum=1;
		vector<char>vec;
		for(int len=1;;len++){
			if(i-len<0||i+len>=n){
				if(flag==0&&sum>1){
					ans=max(ans,sum);
				}
				break;
			}
			else{
				if(s[i-len]==s[i+len]){
					sum+=2;
					if(flag==0||flag==1){
						ans=max(sum,ans);
					}
				}
				else{
					if(flag==1){
						break;
					}
					else if(flag==0){
						flag=1;
						vec.push_back(s[i-len]);
						vec.push_back(s[i+len]);
						vec.push_back(s[i]);
						sort(vec.begin(),vec.end());
						if(vec[0]==vec[1]||vec[1]==vec[2]){
							sum+=2;
							ans=max(ans,sum);
						}
						else{
							break;
						}
					}
				}
			}
		}
	}
	//cout<<ans<<endl;
	for(int i=0;i<n-1;i++){
		int flag=0;
		int sum=0;
		vector<char>vec;
		if(s[i]==s[i+1]){
			sum=2;
		}
		else{
			flag=1;
			vec.push_back(s[i]);
			vec.push_back(s[i+1]);
		}
		
		for(int len=1;;len++){
			if(i-len<0||i+1+len>=n){
				if(flag==0&&sum>0){
					ans=max(ans,sum);
				}
				break;
			}
			else{
				if(s[i-len]==s[i+len+1]){
					sum+=2;
					if(flag==0||flag==2){
						ans=max(ans,sum);
					}
				}
				else{
					if(flag==1){
						flag=2;
						vec.push_back(s[i-len]);
						vec.push_back(s[i+len+1]);
						sort(vec.begin(),vec.end());
						if(vec[0]==vec[1]&&vec[3]==vec[2]){
							sum+=4;
							ans=max(ans,sum);
						}
					}
					else if(flag==0){
						flag=1;
						vec.push_back(s[i-len]);
						vec.push_back(s[i+len+1]);
					}
					else{
						break;
					}
				
				}
			}
		}
		//cout<<ans<<endl;
	}
	cout<<ans<<endl;
	
}
signed main(){
	fast;
	int _=1;
	cin>>_;
	while(_--){
		resolve();
	}
}