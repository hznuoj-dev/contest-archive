#include<bits/stdc++.h>
using namespace std;
void solve()
{
	long long n,m;
	cin>>n>>m;
	while(m>1)
	m=n%m;
	if(m==1){
		cout<<"YES";
	}else
		cout<<"NO";
}
signed main()
{
	solve();
	return 0;
}
