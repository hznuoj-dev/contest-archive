#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define MOD 1000000007LL;
ll getc(ll n)
{
	if(n<2) return 0;
	ll res=n*(n-1);
	return res%MOD;
}
string a,b;
unordered_set<char>set_a,set_b;
unordered_map<char,ll>map_a,map_b;
unordered_map<ll,ll>jishu;
//void same_func(){
//	ll all_same_a_app_1
//	for(int i=0;i<a.size();i++){
//		char tmp_a=a[i];
//		char tmp_b=b[i];
//		if(set_b.count(tmp_a)&&set_a.count(tmp_b)){
//			all_same++;
//		}
//		if(!set_b.count(tmp_a)&&!set_a.count(tmp_b)){
//			all_diff++;
//		}
//		if(set_b.count(tmp_a)&&!set_a.count(tmp_b)){
//			a_diff++;
//		}
//		if(!set_b.count(tmp_a)&&set_a.count(tmp_b)){
//			b_diff++;
//		}
//	}
////	cout<<all_same<<endl;
////	cout<<all_diff<<endl;
//	ll res=0;
//	res=(res+getc(all_same))%MOD;
//	res=(res+getc(all_diff))%MOD;
//	res=(res+a_diff*b_diff)%MOD;
//	cout<<res;
//}
//void diff_func_1(){
//
//}
//void diff_func_2(){
//
//}
//void diff_func_3(){
//
//}
//void diff_func_4(){
//
//}
//

//void solve(){
//	cin>>a>>b;
//	for(int i=0;i<a.size();i++){
//		map_a[a[i]]++;
//		map_b[b[i]]++;
//		set_a.insert(a[i]);
//		set_b.insert(b[i]);
//	}
//	if(set_a.size()==set_b.size()){
//		same_func();
//	}
//	int a_size=set_a.size();
//	int b_size=set_b.size();
//	if(abs(a_size-b_size)==1){
//		diff_func_1();
//	}
//	if(abs(a_size-b_size)==2){
//		diff_func_2();
//	}
//	if(abs(a_size-b_size)==3){
//
//	}
//	if(abs(a_size-b_size)==4){
//
//	}
//}
void init()
{
	for(int i=0; i<a.size(); i++)
	{
		char tmp_a=a[i];
		char tmp_b=b[i];
		if(set_a.count(tmp_b)&&map_b[tmp_b]>1&&set_b.count(tmp_a)&&map_a[tmp_a]>1)
		{
			jishu[0]++;
		}
		if(set_a.count(tmp_b)&&map_b[tmp_b]==1&&set_b.count(tmp_a)&&map_a[tmp_a]==1)
		{
			jishu[0]++;
		}
		if(!set_a.count(tmp_b)&&map_b[tmp_b]>1&&!set_b.count(tmp_a)&&map_a[tmp_a]>1)
		{
			jishu[0]++;
		}
		if(!set_a.count(tmp_b)&&map_b[tmp_b]==1&&!set_b.count(tmp_a)&&map_a[tmp_a]==1)
		{
			jishu[0]++;
		}
		//
		if(set_a.count(tmp_b)&&map_b[tmp_b]>1&&set_b.count(tmp_a)&&map_a[tmp_a]==1)
		{
			jishu[-1]++;
		}
		if(set_a.count(tmp_b)&&map_b[tmp_b]==1&&set_b.count(tmp_a)&&map_a[tmp_a]>1)
		{
			jishu[1]++;
		}
		if(!set_a.count(tmp_b)&&map_b[tmp_b]>1&&!set_b.count(tmp_a)&&map_a[tmp_a]==1)
		{
			jishu[-1]++;
		}
		if(!set_a.count(tmp_b)&&map_b[tmp_b]==1&&!set_b.count(tmp_a)&&map_a[tmp_a]>1)
		{
			jishu[1]++;
		}
		//
		if(!set_a.count(tmp_b)&&map_b[tmp_b]>1&&set_b.count(tmp_a)&&map_a[tmp_a]>1)
		{
			jishu[1]++;
		}
		if(!set_a.count(tmp_b)&&map_b[tmp_b]==1&&set_b.count(tmp_a)&&map_a[tmp_a]==1)
		{
			jishu[1]++;
		}
		if(set_a.count(tmp_b)&&map_b[tmp_b]>1&&!set_b.count(tmp_a)&&map_a[tmp_a]>1)
		{
			jishu[-1]++;
		}
		if(set_a.count(tmp_b)&&map_b[tmp_b]==1&&!set_b.count(tmp_a)&&map_a[tmp_a]==1)
		{
			jishu[-1]++;
		}
		//
		if(!set_a.count(tmp_b)&&map_b[tmp_b]>1&&set_b.count(tmp_a)&&map_a[tmp_a]==1)
		{
			jishu[0]++;
		}
		if(!set_a.count(tmp_b)&&map_b[tmp_b]==1&&set_b.count(tmp_a)&&map_a[tmp_a]>1)
		{
			jishu[2]++;
		}
		if(set_a.count(tmp_b)&&map_b[tmp_b]>1&&!set_b.count(tmp_a)&&map_a[tmp_a]==1)
		{
			jishu[-2]++;
		}
		if(set_a.count(tmp_b)&&map_b[tmp_b]==1&&!set_b.count(tmp_a)&&map_a[tmp_a]>1)
		{
			jishu[0]++;
		}
	}
}
void solve()
{
	cin>>a>>b;
	for(int i=0; i<a.size(); i++)
	{
		map_a[a[i]]++;
		map_b[b[i]]++;
		set_a.insert(a[i]);
		set_b.insert(b[i]);
	}
	ll res=set_a.size()-set_b.size();
//	if(abs(res)>4){
//		cout<<0;
//		return;
//	}
	init();
	//
//	for(int i=-2;i<=2;i++){
//		cout<<i<<' '<<jishu[i]<<endl;
//	}
	//
	res=-res;
	ll sum=0;
//	for(ll i=0;i<=2;i++){
//		if(i==res-i){
//			sum=(sum+jishu[i]*(jishu[i]-1)/2)%MOD;
//		}else{
//			sum=(sum+jishu[i]*jishu[res-i])%MOD;
//		}
//	}
	if(res==-4)
	{
		sum=(sum+jishu[-2]*(jishu[-2]-1)/2)%MOD;
	}
	if(res==-3)
	{
		sum=(sum+jishu[-1]*jishu[-2])%MOD;
	}
	if(res==-2)
	{
		sum=(sum+jishu[-1]*(jishu[-1]-1)/2)%MOD;
		sum=(sum+jishu[-2]*jishu[0])%MOD;
	}
	if(res==-1)
	{
		sum=(sum+jishu[-1]*jishu[0])%MOD;
		sum=(sum+jishu[-2]*jishu[1])%MOD;
	}
	if(res==0)
	{
		sum=(sum+jishu[0]*(jishu[0]-1)/2)%MOD;
		sum=(sum+jishu[-2]*jishu[2])%MOD;
		sum=(sum+jishu[-1]*jishu[1])%MOD;
	}
	if(res==4)
	{
		sum=(sum+jishu[2]*(jishu[2]-1)/2)%MOD;
	}
	if(res==3)
	{
		sum=(sum+jishu[1]*jishu[2])%MOD;
	}
	if(res==2)
	{
		sum=(sum+jishu[1]*(jishu[1]-1)/2)%MOD;
		sum=(sum+jishu[2]*jishu[0])%MOD;
	}
	if(res==1)
	{
		sum=(sum+jishu[1]*jishu[0])%MOD;
		sum=(sum+jishu[2]*jishu[-1])%MOD;
	}
	cout<<sum;
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	solve();
	return 0;
}