#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int T=1;
//	cin>>T;
	while(T--){
		ll m,n;
		int f=1;
		cin>>m>>n;
		if(n==1||m==1){
			f=1;
		}else if(m%n==0||m<=n){
			f=0;
		}else {
			for(int i=2;i<=n;i++){
				if(m%i==0){
					f=0;
					break;
				}
			}
		}
		if(f==1)cout<<"YES";
		else cout<<"NO";
	}
	return 0;
}