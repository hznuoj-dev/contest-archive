#include<bits/stdc++.h>
using namespace std;
int n;
long long x[105],y[105],max0;
int main () {
	cin>>n;
	max0=0;
	for(int i=1; i<=n; i++) {
		cin>>x[i]>>y[i];
	}
	for(int i=1; i<=n-2; i++) {
		for(int j=i+1; j<=n-1; j++) {
			for(int k=j+1; k<=n; k++) {
				long long s=abs(x[i]*y[j]-x[j]*y[i]+x[j]*y[k]-x[k]*y[j]+x[k]*y[i]-x[i]*y[k]);
				s/=2;
				if(s>max0) {
					max0=s;
				}
			}
		}
	}
	cout<<max0;
	return 0;
}