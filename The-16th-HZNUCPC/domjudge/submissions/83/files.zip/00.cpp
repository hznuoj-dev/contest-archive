#include <bits/stdc++.h>

using namespace std;

using i64 = long long;

const int N = 2e5 + 100;

int main()
{
	i64 n, m;
	cin >> n >> m;

	if(m == 1)
	{
		puts("YES");
		return 0;
	}
	else
	{	if(n % m == 0)
			puts("NO");
		else
			puts("YES");
	}

	return 0;
}