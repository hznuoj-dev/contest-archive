#include<bits/stdc++.h>
using namespace std;
#define int long long
const int inf=1e15;
const int N=1e6+5;
const int mod=1e9+7;
int n,m,sum;
int prime[N];
map<int,bool>st;
void run(){
	cin>>n>>m;
	if(n%m==0){
		cout<<"NO";
	}
	else{
		cout<<"YES";
	}
	
	
	
}
signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
//	int t=1;
//	cin>>t;
//	while(t--){
		run();
//	}
	return 0;
}