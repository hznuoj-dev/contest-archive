#include<bits/stdc++.h>

#define ll long long

using namespace std;



int main(){
	ll n,m;
	cin>>n>>m;
	if(m>=n)cout<<"NO"<<endl;
	else {
		for(int i=1;i<=m;i++){
			if(n%i==0&&i>1){
				cout<<"NO"<<endl;
				return 0;
			}
			if(m%i==0&&n%(m/i)==0&&m/i>1){
				cout<<"NO"<<endl;
				return 0;
			}
		}
		cout<<"YES"<<endl;
	}
	return 0;
}