#include<bits/stdc++.h>
using namespace std;

int f(long long int x,long long int y){
	int flag=1;
	for(int i=2;i<=sqrt(y);i++){
		if(x%i==0&&y%i==0){
			flag=0;
			break;
		}
	}
	return flag;
}

int main(){
	long long int n,m;
	bool flag=true;
	cin>>n>>m;
	if(n<m){
		flag=false;
	}
	else{
    	if(f(n,m)==0)flag=false;
    }
	if(flag){
		printf("YES");
	}
	else {
		printf("NO");
	}
	return 0;
}
