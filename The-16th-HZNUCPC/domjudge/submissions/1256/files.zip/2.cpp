#include<bits/stdc++.h>
using namespace std;
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
#define INF 0x7fffffff
#define mem 0x7f
int f[21][21];
void solve(){memset(f,0,sizeof(f));
	long long num=0;
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		int a,b,c;cin>>a>>b>>c;
		f[a][b]=c;
	}
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(f[i][j]==1){
				if(i+1<=19&&f[i+1][j]==0){num++;
				//f[i+1][j]=2;
				}
				if(i-1>=1&&f[i-1][j]==0){num++;
				//f[i-1][j]=2;
				}
				if(j+1<=19&&f[i][j+1]==0){num++;
				//f[i][j+1]=2;
				}
				if(j-1>=1&&f[i][j-1]==0){num++;
				//f[i][j-1]=2;
				}
			}
		}
	}
	cout<<num<<endl;
	return;
}

int main()
{
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int t;cin >> t;while(t--)
	solve();
	//-getchar();
	return 0;
}