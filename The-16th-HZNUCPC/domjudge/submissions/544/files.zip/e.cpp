#include <bits/stdc++.h>

using i64 = long long;

struct points{
	i64 x,y;
	
};

i64 cacal(i64 x1,i64 y1,i64 x2,i64 y2){
	int dx = std::abs(x2-x1);
	int dy = std::abs(y2-y1);
	int g = std::gcd (dx,dy);
	if(dx == 0){
		return dy;
	}else {
//		int kdx = dx / g;
		return g;
	}
}
i64 cross (i64 x1,i64 y1,i64 x2,i64 y2){
	return 1ll * x1 * y2 - 1ll * y1 * x2;
}



int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int n;
	std::cin >> n;
	std::vector<points>point(n);
	for(int i = 0; i < n; ++i){
		std::cin >> point[i].x >> point[i].y;
	}
	
	auto ok =[&](int i,int j,int k){
		return !(cross(point[i].x-point[j].x,point[i].y-point[j].y,point[j].x-point[k].x,point[j].y-point[k].y) == 0);
	};
	
	i64 ans = 0;
	for(int i = 0;i < n; ++i){
		for (int j = i + 1; j < n; ++j){
			for(int k = j + 1; k < n; ++k){
				if(!ok(i,j,k)){
					continue;
				}
//				std::cerr << i << ' ' << j << ' ' << k << "\n";
				i64 tmp = cacal(point[i].x,point[i].y,point[j].x,point[j].y);
//				std::cout <<tmp <<"!\n";
				tmp += cacal(point[k].x,point[k].y,point[j].x,point[j].y);
//				std::cout <<tmp <<"!\n";
				tmp += cacal(point[i].x,point[i].y,point[k].x,point[k].y);
//				std::cout <<tmp <<"!\n";
				
				ans = std::max(ans,tmp);
			}
		}
	}
	std::cout<<ans<<'\n';
	
	return 0;
}
