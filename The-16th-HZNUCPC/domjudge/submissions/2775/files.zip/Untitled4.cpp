#include<iostream>
#include<cmath>
using namespace std;
long long sumsave;
int num;
struct point
{
	int x;
	int y;
};
point p[102];
bool judge(point p1,point p2,point p3)
{
	if(
	fabs((double)(p1.x-p2.x)/(double)(p1.y-p2.y))
	-fabs((double)(p1.x-p3.x)/(double)(p1.y-p3.y))
	<0.00001&&
	fabs((double)(p1.x-p2.x)/(double)(p1.y-p2.y))
	-fabs((double)(p1.x-p3.x)/(double)(p1.y-p3.y))
	>-0.00001
	)
		return 1;
	else
		return 0;
}

int score(int p1x, int p1y,int p2x,int p2y)
{
//	xcha=fabs(p1.x-p2.x)
//	ycha=fabs(p1.y-p2.y)
	if((abs(p1x-p2x))%(abs(p1y-p2y))==0)
	{
		return abs(p1y-p2y)-1;
	}
	else if(abs(p1y-p2y)%abs(p1x-p2x)==0)
	{
		return abs(p1x-p2x)-1;
	}
	else
		return 0;
}

int main()
{
	cin>>num;
	for(int i=1;i<=num;i++)
	{
		cin>>p[i].x>>p[i].y;
	}
	for(int i=1;i<=num;i++)
	{
		for(int j=2;j<=num;j++)
		{
			for(int k=3;k<=num;k++)
			{
				long long sum=0;
				if(i==j||i==k||j==k)
					continue;
				if(judge(p[i],p[j],p[k])==1)
					continue;
				sum+=score(p[i].x, p[i].y, p[j].x, p[j].y);
				sum+=score(p[i].x, p[i].y, p[k].x, p[k].y);
				sum+=score(p[j].x, p[j].y, p[k].x, p[k].y);
				if(sum>sumsave)
				{
					sumsave=sum;
				}
			}
		}
	}
	
	cout<<sumsave+3;
	return 0;
}