#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 1e5 + 10;
const double PI = acos(-1);
void solve() {
	ll n, m;
	cin >> n >> m;
	while (m) {
		m = n % m;
		if (m == 1) {
			cout << "YES\n";
			return ;
		}
	}
	cout << "NO\n";
}
int main() {
	solve();
	return 0;
}