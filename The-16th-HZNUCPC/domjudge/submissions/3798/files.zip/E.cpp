#include<bits/stdc++.h>
using namespace std;

const int N=1e5+10,mod=1e9+7;
long long s[30][30],cnt1[30],cnt2[30];
char a[N],b[N];
long long ans;
bool pd()
{
	int res1=0,res2=0;
	for(int i=0;i<26;i++)
	{
		if(cnt1[i]>0)res1++;
		if(cnt2[i]>0)res2++;
	}
	return res1==res2;
}
long long mi(long long a,long long b)
{
	long long ans=1;
	while (b)
	{
		if(b&1)ans=ans*a%mod;
		b=b>>1;
		a=a*a%mod;
	}
	return ans%mod;
}
int main()
{
	ans=0;
	long long er=mi(2,mod-2);
	scanf("%s",a+1);
	scanf("%s",b+1);
	int n=strlen(a+1);
	for(int i=1;i<=n;i++)
	{
		s[a[i]-'a'][b[i]-'a']++;
		cnt1[a[i]-'a']++;
		cnt2[b[i]-'a']++;
	}
//	for(int i=0;i<26;i++)
//	{
//		for(int j=0;j<26;j++)
//		{
//			if(s[i][j])
//			{
//				cout<<i<<" "<<j<<" "<<s[i][j]<<"\n";
//			}
//		}
//	}
	for(int i=0;i<26;i++)//a
	{
		cnt1[i]--;
		cnt2[i]++;
		for(int j=0;j<26;j++)//b
		{
			cnt2[j]--;
			cnt1[j]++;
			for(int x=0;x<26;x++)//a
			{
				cnt1[x]--;
				cnt2[x]++;
				for(int y=0;y<26;y++)//b
				{
					cnt2[y]--;
					cnt1[y]++;
					if(i==x&&j==y)
					{
						if(s[i][j]>=2)
						{
							if(pd())
							{
								ans=ans+s[i][j]*(s[x][y]-1)%mod*er%mod;
							}
						}
					}
					else
					{
						if(s[i][j]>0&&s[x][y]>0)
						{
							if(pd())
							{
								ans=ans+s[i][j]*s[x][y]%mod*er%mod;
							}
						}
					}
					ans=ans%mod;
					cnt1[y]--;
					cnt2[y]++;
				}
				cnt1[x]++;
				cnt2[x]--;
			}
			cnt2[j]++;
			cnt1[j]--;
		}
		cnt1[i]++;
		cnt2[i]--;
	}
	cout<<ans<<"\n";
	return 0;
}

