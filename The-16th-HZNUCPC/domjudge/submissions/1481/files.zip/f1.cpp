#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
#define int long long
signed main(){
	int n,m;
	scanf("%lld %lld",&n,&m);
	int flag=0;
	if(m==1){
		printf("NO\n");
		return 0;	
	}	
	if(n==1){
		printf("YES\n");
		return 0;
	}

	if(n<=m){
		printf("NO\n");
		return 0;
	}
	while(m>1){
		if(n%m==0){
			break;
		}else{
			m=n%m;
		}
		if(m==1){
			flag=1;
			break;
		}
	}
	if(flag){
		printf("YES\n");
	}else{
		printf("NO\n");
	}
	return 0;
} 
