#include<bits/stdc++.h>
#define endl '\n'
using namespace std;

typedef long long ll;
const ll N = 1e5 + 7;
const ll mod = 1e9 + 7;
ll _,n, vis1[N], vis2[N];
string s1, s2;



void solve(){
	cin >> s1 >> s2;
	n = s1.size();
	s1 = " " + s1;
	s2 = " " + s2;
	ll sum = 0;
	for(int i = 1; i <= n; i++){
		if (s1[i] == s2[i]){
			sum++;
			vis1[i] = vis2[i] = 1;
		}
		else if (i - 1 == 0 || s1[i - 1] == s2[i - 1])vis1[i] = 1;
		else if (i + 1 == n + 1 || s1[i + 1] == s2[i + 1]){
			sum++;
			vis2[i] = 1;
		}
	}
	ll ans = 0;
	for (int i = 1; i < n; i++){
		if (vis2[i])sum--;
		if (vis1[i])ans = (ans + sum) % mod;
	}
	cout << ans << endl;
}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	//cin >> _;
	_ = 1;
	while(_--)solve();
}