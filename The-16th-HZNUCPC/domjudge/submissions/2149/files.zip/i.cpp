#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=5010;
char s[N];
void solve() {
	scanf("%s",s+1);
	ll res=0,n=strlen(s+1);
	for(ll pos=2; pos<n; pos++) {
		ll cnt=0,p=0;
		char a,b;
		ll lastl,lastr;
		for(ll l=pos-1,r=pos+1; l>=1&&r<=n; l--,r++) {
			if(s[l]!=s[r]) {
				cnt++;
				if(cnt==1) {
					a=s[l],b=s[r];
				} else {
					if(s[l]==a||s[l]==b||s[r]==a||s[r]==b) {
						res=max(res,lastr-lastl+1);
					}
				}
				p^=1ll<<(s[l]-'a');
				p^=1ll<<(s[r]-'a');
			}
			if(cnt==1) {
				lastl=l,lastr=r;
			}
			if(cnt==0||(cnt==2&&p==0)) {
				res=max(res,r-l+1);
			}
		}
	}
	for(ll pos=1; pos<n; pos++) {
		ll cnt=0,p=0;
		char a,b;
		ll lastl,lastr;
		for(ll l=pos,r=pos+1; l>=1&&r<=n; l--,r++) {
			if(s[l]!=s[r]) {
				cnt++;
				if(cnt==1) {
					a=s[l],b=s[r];
				} else {
					if(s[l]==a||s[l]==b||s[r]==a||s[r]==b) {
						res=max(res,lastr-lastl+1);
					}
				}
				p^=1ll<<(s[l]-'a');
				p^=1ll<<(s[r]-'a');
			}
			if(cnt==1) {
				lastl=l,lastr=r;
			}
			if(cnt==0||(cnt==2&&p==0)) {
				res=max(res,r-l+1);
			}
		}
	}
	printf("%lld\n",res);
}
int main() {
	ll t;
	scanf("%lld",&t);
	while(t--) {
		solve();
	}
}