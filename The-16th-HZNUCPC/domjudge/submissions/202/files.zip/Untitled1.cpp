#include<iostream>
using namespace std;
int main()
{
	long long n,m;
	cin>>n>>m;
	if (m==1)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	while(n%m!=0&&n%m!=1)
	{
		m=n%m;
	}
	if (n%m==1)
	cout<<"YES"<<endl;
	else
	cout<<"NO"<<endl;
	return 0;
}