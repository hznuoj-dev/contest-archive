#include <bits/stdc++.h>
using namespace std;
string x,y;
int n,cnt[200][200],hav[2][200],cnt1,cnt2;
bool change(char a,char b,char c,char d){
	if(!hav[0][a]||!hav[0][c]||!hav[1][b]||!hav[1][d])return false;
	if(!--hav[0][a])cnt1--;
	if(!--hav[0][c])cnt1--;
	if(!--hav[1][b])cnt2--;
	if(!--hav[1][d])cnt2--;
	if(!hav[1][a]++)cnt2++;
	if(!hav[1][c]++)cnt2++;			
	if(!hav[0][b]++)cnt1++;
	if(!hav[0][d]++)cnt1++;
	bool res=cnt1==cnt2;
	if(!--hav[1][a])cnt2--;
	if(!--hav[1][c])cnt2--;
	if(!--hav[0][b])cnt1--;
	if(!--hav[0][d])cnt1--;
	if(!hav[0][a]++)cnt1++;
	if(!hav[0][c]++)cnt1++;
	if(!hav[1][b]++)cnt2++;
	if(!hav[1][d]++)cnt2++;
	return res;
}
int main() {
	cin>>x>>y;
	n=x.size();
	for(int i=0;i<n;i++){
		cnt[x[i]][y[i]]++;
		if(!hav[0][x[i]]++)cnt1++;
		if(!hav[1][y[i]]++)cnt2++;
	}
	long long ans=0,mod=1e9+7;
	for(char i='a';i<='z';i++){
		for(char j='a';j<='z';j++){
			for(char p='a';p<='z';p++){
				for(char q='a';q<='z';q++){
					if(change(i,j,p,q)&&cnt[i][j]&&cnt[p][q]){
						if(i!=p||j!=q){
							ans=(ans+(long long)cnt[i][j]*cnt[p][q])%mod;
						}
						else{
							ans=(ans+(long long)cnt[i][j]*(cnt[i][j]-1))%mod;
						}
					}
				}
			}
		}
	}
	cout<<(ans%mod)*500000004ll%mod<<endl;
	return 0;
}
