#include<bits/stdc++.h>
using namespace std;
int ap[1000][1000],z[1000],x[1000],y[1000];
bool f[1000][1000];
int main(){	
	int t,ans,n;
	cin>>t;
	for(int i=1;i<=t;i++){
		ans=0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
		ap[i][j]=0;  //建图
		f[i][j]=false; //记录点的位置
		}
	}
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>x[i]>>y[i]>>z[i];
			ap[x[i]][y[i]]=1; //走过就标记1；
		}
		for(int i=1;i<=n;i++){
			if(z[i]==1){
				if(x[i]+1<=19){
				if(ap[x[i]+1][y[i]]==0){
					ans++;
				}
			}
			if(y[i]+1<=19){
				if(ap[x[i]][y[i]+1]==0){
					ans++;
				}
			}
			if(x[i]-1>0){
				if(ap[x[i]-1][y[i]]==0){
					ans++;
				}
			}
			if(y[i]-1>0){
				if(ap[x[i]][y[i]-1]==0){
						ans++;
				}
			}
				}
			}
			cout<<ans<<'\n';
		}
	
	}