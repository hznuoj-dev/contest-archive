#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9 +7;
const int N = 1e3 +7;
ll n,m,s;
ll x[N],y[N];
inline void run(){
      cin >> n ;
      for(int i=1;i<=n;i++) cin>>x[i]>>y[i];
      ll sum=0,Max=0;
      for(int i=1;i<=n-2;i++)
      {
          for(int j=i+1;j<=n-1;j++)
          {
              for(int k=j+1;k<=n;k++)
              {
              	sum=0;
              	double a=(x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]);
              	double b=(x[i]-x[k])*(x[i]-x[k])+(y[i]-y[k])*(y[i]-y[k]);
              	double c=(x[k]-x[j])*(x[k]-x[j])+(y[k]-y[j])*(y[k]-y[j]);
              	if(sqrt(a)+sqrt(b)<=sqrt(c)||sqrt(a)+sqrt(c)<=sqrt(b)||sqrt(b)+sqrt(c)<=sqrt(a)) continue;
              	double k1=(double)(y[j]-y[i])/(x[j]-x[i])*1.0;
              	if((double)k1==(int)k1) sum+=abs(x[i]-x[j])-1;
              	else
              	{
              		for(int l=min(x[i],x[j]);l<=max(x[i],x[j]);l++)
              		{
              			if((double)k1*l*0.1==(int)k1*l*1.0) sum++;
					}
				}
				double k2=(double)(y[k]-y[i])/(x[k]-x[i])*1.0;
              	if((double)k2==(int)k2) sum+=abs(x[i]-x[k])-1;
              	else
              	{
              		for(int l=min(x[i],x[k]);l<=max(x[i],x[k]);l++)
              		{
              			if((double)k2*l*0.1==(int)k2*l*1.0) sum++;
					}
				}
				double k3=(double)(y[j]-y[k])/(x[j]-x[k])*1.0;
              	if((double)k3==(int)k3) sum+=abs(x[k]-x[j])-1;
              	else
              	{
              		for(int l=min(x[k],x[j]);l<=max(x[k],x[j]);l++)
              		{
              			if((double)k3*l*0.1==(int)k3*l*1.0) sum++;
					}
				}
//				cout<<x[i]<<" "<<y[i]<<" "<<x[j]<<" "<<y[j]<<" "<<x[k]<<" "<<y[k]<<'\n';
//				cout<<k1<<" "<<k2<<" "<<k3<<'\n';
//				cout<<sum<<'\n';
				Max=max(Max,sum);
//				cout<<Max<<'\n';
              }
          }
      }
      if(Max==0) cout<<0<<'\n';
      else cout<<Max+3<<'\n';
}
int main()
{
        run();
}
