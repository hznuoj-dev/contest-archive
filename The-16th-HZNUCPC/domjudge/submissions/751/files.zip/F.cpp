#include <bits/stdc++.h>
#define ll long long
using namespace std;

bool check(ll m,ll n){
	if(n == 1) return true;
	ll ans = m % n;
	if(ans == 0) return false;
	return (m, ans); 
}



int main(){
	ll n,m;
	while(cin>>n>>m){
		if (check(n, m)) cout<<"YES"<<endl; else cout<<"NO"<<endl;
	}
	return 0;
}
