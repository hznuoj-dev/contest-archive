#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 7;
const int mod=1e9+7;
string s;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int T;
	cin >> T;
	while(T --){
		cin >> s;
		int len = s.size();
		int ans = 0;
		for(int i = 0; i < len; i ++){
			int u = i;
			int x,y, a , b, f = 0;
			x = u - 1, y = u + 1;
			while(x >= 0 && y < len && s[x] == s[y])x --, y ++;
			a = x - 1, b = y + 1;
			while(a >= 0 && b < len && s[a] == s[b]) a --, b ++;
			if(a >= 0 && b < len && (s[a] == s[y] && s[b] == s[x] || s[a] == s[x] && s[b] == s[y]))  {
				a --, b ++;
				while(a >= 0 && b < len && s[a] == s[b]) a --, b ++;
				f = 1;
			}else if(x >= 0 && y < len && (s[u] == s[x] || s[u] == s[y])){
				x --,y ++;
				while(x >= 0 && y < len && s[x] == s[y])x --, y ++;
			}
			if(f)ans = max(b - a - 1, ans);
			else ans = max(y - x - 1, ans);

			f = 0;
			x = u - 1, y = u;
			while(x >= 0 && y < len && s[x] == s[y])x --, y ++;
			a = x - 1, b = y + 1;
			while(a >= 0 && b < len && s[a] == s[b]) a --, b ++;
			if(a >= 0 && b < len && (s[a] == s[y] && s[b] == s[x] || s[a] == s[x] && s[b] == s[y]))  {
				a --, b ++;
				while(a >= 0 && b < len && s[a] == s[b]) a --, b ++;
				f = 1;
			}
			if(f)ans = max(b - a - 1, ans);
			else ans = max(y - x - 1, ans);
			
			f = 0;
			x = u, y = u + 1;
			while(x >= 0 && y < len && s[x] == s[y])x --, y ++;
			a = x - 1, b = y + 1;
			while(a >= 0 && b < len && s[a] == s[b]) a --, b ++;
			if(a >= 0 && b < len && (s[a] == s[y] && s[b] == s[x] || s[a] == s[x] && s[b] == s[y]))  {
				a --, b ++;
				while(a >= 0 && b < len && s[a] == s[b]) a --, b ++;
				f = 1;
			}
			if(f)ans = max(b - a - 1, ans);
			else ans = max(y - x - 1, ans);
		}
		if(ans == 1) ans = 0;
		cout << ans << endl;
	}
}