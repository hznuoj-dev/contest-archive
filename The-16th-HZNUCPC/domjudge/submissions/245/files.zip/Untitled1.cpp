#include<bits/stdc++.h>
using namespace std;
bool in(int x,int y)
{
	return x>=1&&x<=19&&y>=1&&y<=19;
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n;
		scanf("%d",&n);
		int x[500],y[500],c[500];
		int d[50][50]={0};
		for(int i=0;i<n;i++)
		{
			scanf("%d%d%d",&x[i],&y[i],&c[i]);
			d[x[i]][y[i]]=c[i];
		}
		int ans=0;
		for(int i=0;i<n;i++)
		{
			if(d[x[i]][y[i]]==1)
			{
				if(in(x[i]-1,y[i])&&!d[x[i]-1][y[i]]) ans++;
				if(in(x[i]+1,y[i])&&!d[x[i]+1][y[i]]) ans++;
				if(in(x[i],y[i]-1)&&!d[x[i]][y[i]-1]) ans++;
				if(in(x[i],y[i]+1)&&!d[x[i]][y[i]+1]) ans++;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}