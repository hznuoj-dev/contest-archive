#include <bits/stdc++.h>

using namespace std;
typedef long long LL;
const int N = 22;
LL x[N],y[N];

LL gcd(LL x,LL y)
{
	while (y)
	{
		LL t = x%y;
		x = y;
		y = t;
	}
	return x;
}
int main()
{
	int n;
	cin >> n;
	for (int i=1;i<=n;i++)
	{
		cin >> x[i] >> y[i];
	}
	LL res  = 0;
	for (int i=1;i<=n;i++)
	{
		for (int j=i+1;j<=n;j++)
		{
			for (int k=j+1;k<=n;k++)
			{
				LL y1=y[i],y2=y[j],y3=y[k];
				LL x1=x[i],x2=x[j],x3=x[k];
				
				if (x2-x1)
				{
					double k1 = 1.0*(y2-y1)/(x2-x1);
					double b1 = -1.0*(y2-y1)/(x2-x1) + y2;
					double yy = k1*x3+b1;
					if (yy==y3) continue;
				}
				else
				{
					if (x3==x1) continue;
				}
				
				LL sum = 0;
				if (x1-x2 && y1-y2) sum += gcd(abs(x1-x2),abs(y1-y2));
				else sum += max(abs(x1-x2),abs(y1-y2));
				
				if (x1-x3 && y1-y3) sum += gcd(abs(x1-x3),abs(y1-y3));
				else sum += max(abs(x1-x3),abs(y1-y3));
				
				if (x2-x3 && y2-y3) sum += gcd(abs(x2-x3),abs(y2-y3));
				else sum += max(abs(x2-x3),abs(y2-y3));
				
				res = max(res, sum);
				/*
			   for(int t=x[i]+1;t<x[j];t++){
			   	   if((y1-y2/x1-x2)*x1/1==0)res++;
			   }
			   for(int t=x1+1;t<x3;t++){
			   	   if((y1-y3/x1-x3)*x1/1==0)res++;
			   }
			   for(int t=1+x2;t<x3;t++){
			   	   if((y2-y3/x2-x3)*x1/1==0)res++;
			   }
			   */
			}
		}
	}
	cout << res;
	
	return 0;
}