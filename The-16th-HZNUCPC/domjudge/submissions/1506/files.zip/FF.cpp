#include<bits/stdc++.h>
#define int long long
using namespace std;
int isprime(int x){
	int flag=0;
	for(int i=2;i<=x/i;i++){
		if(x%i==0){
			flag=i;
			break;
		}
	}
	return flag;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
    int n,m;cin>>n>>m;
	if(m==1)
	{
		cout<<"YES";
		return 0;	
	}
	if(n==1){
		cout<<"YES";
		return 0;
	}
	if(n%2==0)
	{
		cout<<"NO";
		return 0;	
	}
	else
	{
		if(n<=m)
		{
			cout<<"NO";
			return 0;
		}
		else
		{
			int t=isprime(n);
			if(t==0)cout<<"YES";
			else{
				if(t>m)cout<<"YES";
			    else cout<<"NO";
			}
		}
	}
	return 0;
}
