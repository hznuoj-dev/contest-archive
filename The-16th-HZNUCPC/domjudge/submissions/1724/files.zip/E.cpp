#include<bits/stdc++.h>
using namespace std;

#define int long long
int temp[105][105];
pair<int ,int> mp[105];
inline bool check(pair<int,int> a,pair<int,int> b, pair<int,int> c){
	double x = sqrt((a.first - b.first) *(a.first - b.first) + (a.second - b.second) *(a.second - b.second) );
	double y = sqrt((a.first - c.first) *(a.first - c.first) + (a.second - c.second) *(a.second - c.second) );
	double z = sqrt((c.first - b.first) *(c.first - b.first) + (c.second - b.second) *(c.second - b.second) );
	if(x + y < z || x + z < y||z + y < x) return false;
	return true;
}

signed main(){
	int n;
	while(cin >>n){
		for(int i = 1;i <= n;i ++){
			cin >> mp[i].first >> mp[i].second;
		}
		for(int i = 1;i <= n;i ++){
			for(int j =1;j <= n;j ++){
				if(i == j) continue;
				int mi_x = min(mp[i].first,mp[j].first);
				int mi_y = min(mp[i].second,mp[j].second);
				int ma_x = max(mp[i].first,mp[j].first);
				int ma_y = max(mp[i].second,mp[j].second);
				double k = (ma_y - mi_y) * 1.0/ (ma_x - mi_x) * 1.0;
				double p;
				if (k < 1) p = (ma_x - mi_x) *k;
				else p = (ma_y - mi_y) / k;
				temp[i][j] = p +1;
			}
		}
		int ans = 0;
		for(int i = 1;i <= n;i ++){
			for(int j = i + 1;j <= n;j ++){
				for (int k = j + 1;k <= n;k ++){
					if(k == i || k == j) continue;
					if(check(mp[i],mp[j],mp[k])){
//						cout << i << " " << j << " " << k <<endl;
						ans = max(ans,temp[i][j] + temp[j][k]+temp[i][k]);
					}
				}
			}
		}
		cout <<max((long long)0,ans-3)<< endl;
	}
	return 0;
}

/*
4
0 0
1 1
2 4
4 2
*/
