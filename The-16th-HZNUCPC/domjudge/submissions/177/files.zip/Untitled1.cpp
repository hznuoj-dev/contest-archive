#include<bits/stdc++.h>
using namespace std;
//#define int long long 
typedef long long ll;
const int N = 2e5+7;
int n,a[27][27];

void solve(){
	cin>>n;
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;i++){
		int x,y,c;
		cin>>x>>y>>c;
		a[x][y]=c;
	}
	ll ans=0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(a[i][j]==1){
				if(i-1>=1&&a[i-1][j]==0) ans++;
				if(i+1<=19&&a[i+1][j]==0) ans++;
				if(j-1>=1&&a[i][j-1]==0) ans++;
				if(j+1<=19&&a[i][j+1]==0) ans++;
			}
		}
	}
	cout<<ans<<'\n';
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	int t = 1;
	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}
/*
1
2
2 2 1
1 1 1

*/