#include<bits/stdc++.h>
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const ll N=5e3+7;
const ll mod =1e9+7;
const double eps=1e-6;
const ll MAXN=1010;
using namespace std;
struct Edge
{
	int s,t,v;
}edge[MAXN];
int n,m;
int ans=0;
int cnts[MAXN]={};
void slove(){
	ios;
	cin>>n>>m;
	for(int i=1;i<=m;++i)
	{
	  cin>>edge[i].s>>edge[i].t>>edge[i].v;
	  cnts[edge[i].v]++;
    }
    for(int i=0;i<=n;++i)
    {
    	if(cnts[i]==0)
    	{
    		cout<<i;
    		return;
		}
	}
}
int main(){
	slove();
}
