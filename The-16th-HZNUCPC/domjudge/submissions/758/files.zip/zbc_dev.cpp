#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
#define per(i,x,y) for(int i=x;i>=y;i--)
using namespace std;
#define int long long
const int mod=1e9+7;
const int N=2e5+10;
int qmi(int a,int b){
	int res=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
void solve(){
	int n,m;cin>>n>>m;
	int mx=n%m;
	if(mx==0){
		cout<<"NO\n";
		return;
	}
	rep(i,1,n/i){
		if(n%i==0){
			int x=i,y=n/i;
			//cout<<x<<" "<<y<<"\n";
			if(x<=mx and x!=1){
				cout<<"NO\n";
				return;
			}
			if(y<=mx and y!=1){
				cout<<"NO\n";
				return;
			}
		}
	}
	cout<<"YES\n";
}
signed main(){
	cin.tie(0)->sync_with_stdio(false);
	int tc=1;
	for(int i=1;i<=tc;i++){
		solve();
	}
}