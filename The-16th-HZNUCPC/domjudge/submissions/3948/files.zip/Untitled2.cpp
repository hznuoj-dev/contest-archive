#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,ans,k;
	cin>>n>>m;
	if(m==1){
		cout<<"YES"<<'\n';
		return 0;
	}
//	if(n==1){
//		cout<<"NO"<<'\n';
//		return 0;
//	}
	while(m>1){
//	cout<<n<<" "<<m<<'\n';   
		ans=n%m;
		m=ans;
//		cout<<ans<<'\n';
	
		}
		if(ans==1){
			cout<<"YES"<<'\n';
			return 0;
	}else {
		cout<<"NO"<<'\n';	
	}
}