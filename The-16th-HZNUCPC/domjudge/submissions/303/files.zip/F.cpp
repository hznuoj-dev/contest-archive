#include <bits/stdc++.h>
#define int long long
using namespace std;
int n, m;
typedef pair<int,int> PII;
PII a[110];
signed main()
{
	ios::sync_with_stdio(0);
	
	cin.tie(0);
	cin >> n >> m;
	if(m == 1) cout << "YES" << endl;
	else if(n % m) cout << "YES" << endl;
	else cout << "NO" << endl;
	
}