#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod = 1e9 + 7;
const int N = 110;

void solve(){
	string str, str1;
	cin >> str >> str1;
	int a = 0, n = str.length();
	for(int i = 0; i < n; i++){
		if(str[i] == str1[i]){
			a ++;
		}
	}
	if(n == 2 || a == 0){
		cout << "1\n";
	}else if(n - a == 1){
		cout << n * (n - 1) / 2 % mod << "\n";
	}else if(n - a == 2){
		cout << max(a * (a - 1) / 2 + 1, (n * (n - 1) / 2 - a * (a - 1) / 2 - 1)) % mod << "\n";
	}else{
		if(a == 1){
			cout << "1\n";
		}else{
			cout << a * (a - 1) / 2 % mod << "\n";
		}
	}
	
}
signed main(){
	int t = 1;
//	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
