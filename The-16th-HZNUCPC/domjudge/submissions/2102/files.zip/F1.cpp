#include<bits/stdc++.h>
using namespace std;
#define debug(a) cout<<#a<<"="<<a<<"\n";
int main()
{
	long long n,m;
	cin>>n>>m;
	if(m==1)
	{
		cout<<"YES\n";
		return 0;
	}
	
	long long temp=n%m;
	while (temp!=0&&temp!=1)
	{
		temp = n%m;
		m  = temp;
	}
	if (temp == 1){
		cout<<"YES\n";
	}
	if(temp == 0){
		cout<<"NO\n";
	}
	return 0;
}