#include <bits/stdc++.h>
using namespace std;
void solve(){
	string ss;
	cin >> ss;
	string s;
	s += '$';
	for(int i = 0; i < ss.size(); i++){
		s += '#';
		s += ss[i];
	}
	s+="#^";
	int n = s.size(), ans = 0;
	for(int i = 0; i < n; i++){
		int lastL = -1, lastR = -1, cnt = 0, cur = 0;
		for(int j = 1; i - j >= 0 && i + j < n; j++){
			if(s[i - j] == s[i + j]){
				if(cnt != 1){
					cur = j;
				}
				continue;
			}
			if(cnt >= 2){
				break;
			}
			cnt++;
			int L = s[i - j] - 'a', R = s[i + j] - 'a';
			if(lastL == -1){
				lastL = L, lastR = R;
				continue;
			}
			if(lastL != R || lastR != L){
				break;
			}
			cur = j;
		}
		cnt = 0;
		int mid = 0;
		for(int j = 1; i - j >= 0 && i + j < n; j++){
			if(s[i - j] == s[i + j]){
				mid = j;
				continue;
			}
			if(cnt >= 1){
				break;
			}
			cnt++;
			int L = s[i - j] - 'a', R = s[i + j] - 'a';
			if(L == s[i] - 'a' || R == s[i] - 'a'){
				mid = j;
			}else{
				break;
			}
		}
		ans = max({ans, cur, mid});
	}
	if(ans == 1){
		ans = 0;
	}
	cout << ans << "\n";
	return void();
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int t = 1;
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
