#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5,mod=1e9+7;
int n,ca[30],cb[30],cnt[30][30],sza,szb,ans;
char a[N],b[N];
void adda(int x,int v){
	sza-=!!ca[x],ca[x]+=v,sza+=!!ca[x];
}
void addb(int x,int v){
	szb-=!!cb[x],cb[x]+=v,szb+=!!cb[x];
}
void swp(int x,int y){
	adda(x,-1),addb(x,1);
	addb(y,-1),adda(y,1);
}
signed main(){
	scanf("%s%s",a+1,b+1),n=strlen(a+1);
	for(int i=1;i<=n;i++)
		adda(a[i]-'a',1),addb(b[i]-'a',1),cnt[a[i]-'a'][b[i]-'a']++;
	for(int i=1;i<=n;i++){
		swp(a[i]-'a',b[i]-'a');
		cnt[a[i]-'a'][b[i]-'a']--;
		for(int x=0;x<26;x++) if(ca[x])
			for(int y=0;y<26;y++) if(cb[y]&&cnt[x][y]){
				swp(x,y);
				if(sza==szb) ans=(ans+cnt[x][y])%mod;
				swp(y,x);
			}
		swp(b[i]-'a',a[i]-'a');
	}
	printf("%d\n",ans);
	return 0;
}