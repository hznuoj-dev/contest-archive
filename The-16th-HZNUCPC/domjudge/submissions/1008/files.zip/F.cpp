#include<bits/stdc++.h>

using namespace std;

#define ll long long

void solve(){
	ll n,m;
	cin>>n>>m;
	ll i;
	ll now = n;
	for(i=2;i*i<=n;++i){
		if(n%i == 0){
			now = i;
			break;
		}
	}
	if(m == 1 || n == 1){
		cout<<"YES\n";
		return ;
	}else{
		if(m>=now){
			cout<<"NO\n";
			return ;
		}else{
			cout<<"YES\n";
			return ;
		}
	}
}

int main()
{
	cin.sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
	while(t--){
		solve();
	}
	
	return 0;
}
