#include <bits/stdc++.h>
#define ll long long

using namespace std;


int main(){
	ll n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"YES";
		return 0;
	}
	if(n%2==0)cout<<"YES";
	else cout<<"NO";
}