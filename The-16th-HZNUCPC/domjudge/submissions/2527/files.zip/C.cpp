#include<bits/stdc++.h>
#define N 100005
using namespace std;
const long long MOD=1e9+7;
char s1[N],s2[N];
int h[N];
int n,as,bs,a[N],b[N],c[N];
map<int,long long> mpa,mpb,mpc;
vector<int> v1[105],v2[105];
long long p[505][505],ans;
long long ksm(long long x,long long k){
	long long ans=1;
	while (k){
		if (k&1) ans=ans*x%MOD;
		x=x*x%MOD;
		k>>=1;
	}
	return ans;
}
int main(){
	scanf("%s",s1+1);
	scanf("%s",s2+1);
	n=strlen(s1+1);
	int anss=0;
//	for (int p1=1;p1<=n;p1++){
//		for (int p2=p1+1;p2<=n;p2++){
//			int ss1=0,ss2=0;
//			swap(s1[p1],s2[p1]);
//			swap(s1[p2],s2[p2]);
//			for (int i='a';i<='z';i++) h[i]=0;
//			for (int i=1;i<=n;i++){
//				if (h[s1[i]]==0) ss1++;
//				h[s1[i]]++;
//			}
//			for (int i='a';i<='z';i++) h[i]=0;
//			for (int i=1;i<=n;i++){
//				if (h[s2[i]]==0) ss2++;
//				h[s2[i]]++;
//			}
//			if (ss1==ss2){
//				anss++;
//				cout<<p1<<' '<<p2<<' '<<ss1<<' '<<ss2<<endl;	
//			}
//			swap(s1[p1],s2[p1]);
//			swap(s1[p2],s2[p2]);
//		}
//	}
//	cout<<anss<<endl;
	for (int i=1;i<=n;i++){
		if (mpa[s1[i]]==0) as++;
		mpa[s1[i]]++;
		if (mpb[s2[i]]==0) bs++;
		mpb[s2[i]]++;
	}
	for (int i=1;i<=n;i++){
		p[s1[i]][s2[i]]++;
	}
	for (int i='a';i<='z';i++)
		for (int j='a';j<='z';j++){
			for (int k='a';k<='z';k++)
				for (int l='a';l<='z';l++){
					if (p[i][j]&&p[k][l]){
							int sa=as,sb=bs;
							map<int,long long> mp=mpa;
							mp[i]--;
							if (mp[i]==0) sa--;
							mp[k]--;
							if (mp[k]==0) sa--;
							if (mp[j]==0) sa++;
							mp[j]++;
							if (mp[l]==0) sa++;
							mp[l]++;							
							mp=mpb;
							mp[j]--;
							if (mp[j]==0) sb--;
							mp[l]--;
							if (mp[l]==0) sb--;
							if (mp[i]==0) sb++;
							mp[i]++;
							if (mp[k]==0) sb++;
							mp[k]++;
							if (sa==sb){
								if (i!=k||j!=l) ans=(ans+p[i][j]*p[k][l]%MOD)%MOD;
								else ans=(ans+(p[i][j])*(p[i][j]-1)%MOD)%MOD;
//								printf("%c %c %c %c\n",i,j,k,l);
							}
						}
				}
		}
	ans=ans*ksm(2,MOD-2)%MOD;
	printf("%lld\n",ans);
}