#include<bits/stdc++.h>
using namespace std;
signed main (){
	ios::sync_with_stdio(0); cin.tie(0);cout.tie(0);
	int n,m; cin>>n>>m; bool flag=true;
	while(m!=1){
		if(n%m==0){
			flag=false;
			break;
		}else{
			m=n%m;
		}
	}
	if(flag) cout<<"YES\n";
	else cout<<"NO\n";
	
	return 0;
}