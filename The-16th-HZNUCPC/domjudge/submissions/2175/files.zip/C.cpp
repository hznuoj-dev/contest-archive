#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 25;
const ll mod = 1e9 + 7;
int n;
ll a[55], b[55], len_a, len_b;
ll cnt[10];//1: a+0 b+2 2:a+0 b+1 3: a+0 b+0 4: a+1 b+0 5: a+2 b+0
void solve() {
	len_a = len_b = 0;
	string s_a, s_b;
	cin >> s_a >> s_b;
	for(int i = 0; i < s_a.length(); i++) {
		a[s_a[i] - 'a' + 1]++;
		b[s_b[i] - 'a' + 1]++;
		if(a[s_a[i] - 'a' + 1] == 1) len_a++;
		if(b[s_b[i] - 'a' + 1] == 1) len_b++;
	}
	if(len_a > len_b) {
		swap(len_a, len_b);
		for(int i = 1; i <= 26; i++) {
			swap(a[i], b[i]);
		}
		swap(s_a, s_b);
	}
//	cout << len_a << "\n";
//	for(int i = 1; i <= 26; i++) cout << a[i] << " "; cout << endl;
//	cout << len_b << "\n";
//	for(int i = 1; i <= 26; i++) cout << b[i] << " "; cout << endl;
	map<pair<int, int>, ll> mp;
	for(int i = 0; i < s_a.length(); i++) {
		mp[{s_a[i] - 'a' + 1, s_b[i] - 'a' + 1}]++;
	}
	ll ans = 0;
	for(auto it_1 = mp.begin(); it_1 != mp.end(); it_1++) {
		auto it_2 = it_1;
		for(; it_2 != mp.end(); it_2++) {
			int a_1 = (*it_1).first.first, b_1 = (*it_1).first.second;
			int a_2 = (*it_2).first.first, b_2 = (*it_2).first.second;
//			cout << a_1 << " " << b_1 << " " << a_2 << " " << b_2 << " " << (*it_1).second << " " << (*it_2).second << "\n";
			a[a_1]--; b[a_1]++;
			a[b_1]++; b[b_1]--;
			a[a_2]--; b[a_2]++;
			a[b_2]++; b[b_2]--;
			int tmp = 0;
			if(a[a_1] == 0) tmp--;
			if(a[a_2] == 0 && a_1 != a_2) tmp--;
			if(a[b_1] == 1) tmp++;
			if(a[b_2] == 1) tmp++;
			if(a[b_2] == 2 && b_1 == b_2) tmp++;
			
			if(b[b_1] == 0) tmp++;
			if(b[b_2] == 0 && b_1 != b_2) tmp++;
			if(b[a_1] == 1) tmp--;
			if(b[a_2] == 1) tmp--;
			if(b[a_2] == 2 && a_1 == a_2) tmp--;
			if(len_a + tmp == len_b) {
//				cout << a[a_1] << " " << a[a_2] << " " << b[b_1] << " " << b[b_2] << endl;
//				cout << a_1 << " " << b_1 << " " << a_2 << " " << b_2 << " " << (*it_1).second << " " << (*it_2).second << "\n";
				if(it_1 == it_2) {
					ans += (*it_1).second * ((*it_2).second - 1) / 2 % mod;
					ans %= mod;
				}
				else {
					ans += (*it_1).second * (*it_2).second % mod;
					ans %= mod;
				}
			}
			a[a_1]++; b[a_1]--;
			a[b_1]--; b[b_1]++;
			a[a_2]++; b[a_2]--;
			a[b_2]--; b[b_2]++;
		}
	}
	cout << ans << "\n";
}
int main() {
	ios::sync_with_stdio(false);
	int T = 1;
	while(T--) {
		solve();
	}
	return 0;
}
//Fi30g7NOTTgu
/*
aaaa
aaaa

abca
aaaa
*/