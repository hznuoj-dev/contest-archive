#include<bits/stdc++.h>

using namespace std;
#define int long long


signed main(){
	ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
	int T;
	cin >> T;
	while (T--)
	{
		string s;
		cin >> s;
		int ans=0,n=s.length();
		
		//ji
		for(int m=1;m<n-1;m++){
			vector<pair<int,int> >ve;
			bool f=1;
			for(int len=1;m-len>=0&&m+len<n;len++){
				int l=m-len,r=m+len;
				if(s[l]!=s[r]){
					f=0;
					ve.push_back({l,r});
					if(ve.size()==2){
						int l1=ve[0].first;
						int r1=ve[0].second;
						int l2=ve[1].first;
						int r2=ve[1].second;
						
						if((s[l1]==s[r2]&&s[l2]==s[r1]) || (s[l1]==s[l2]&&s[r2]==s[r1])){
							f=1;
						}
					}
					if(ve.size()==1){
						int l1=ve[0].first;
						int r1=ve[0].second;
						if(s[l1]==s[m]||s[m]==s[r1]){
							f=1;
						}
					}
					if(ve.size()>=3)break;
				}
				if(f)ans=max(ans,len*2+1);
			}
		}
		
		
		//ou
		for(int m=0;m<n-1;m++){
			vector<pair<int,int> >ve;
			bool f=1;
			for(int len=1;m-len+1>=0&&m+len<n;len++){
				int l=m-len+1,r=m+len;
				//cout << l << " " << r << "  " << ans << "\n";
				if(s[l]!=s[r]){
					f=0;
					ve.push_back({l,r});
					if(ve.size()==2){
						int l1=ve[0].first;
						int r1=ve[0].second;
						int l2=ve[1].first;
						int r2=ve[1].second;
						
						if((s[l1]==s[r2]&&s[l2]==s[r1]) || (s[l1]==s[l2]&&s[r2]==s[r1])){
							f=1;
						}
					}
					if(ve.size()>=3)break;
				}
				if(f)ans=max(ans,len*2);
			}
		}
		
		
		cout<<ans<<"\n";
		
	}
}