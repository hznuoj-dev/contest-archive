package zime;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
			long n=sc.nextLong();
			long m=sc.nextLong();
			int p=2;
			while(n%p!=0){
				p++;
			}
			if(p>m)System.out.println("YES");
			else System.out.println("NO");
		}
	}

}
