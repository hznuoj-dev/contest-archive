#include<bits/stdc++.h>
using namespace std;
const int N=210;
long long x[N],y[N];
int main()
{
	long long n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>x[i]>>y[i];
	}
	double a=(y[2]-y[1])/(x[2]-x[1]);
	double b=y[1]-a*x[1];
	int flag=0;
	for(int i=3;i<=n;i++)
	{
		if(a*x[i]+b!=y[i])
		{
			flag=1;
			break;
		}
	}
	if(!flag)
	{
		cout<<0<<endl;
	}
	else
	{
		long long mx=0;
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				for(int k=1;k<=n;k++)
				{
					if(i!=j && i!=k && j!=k)
					{ 	
						mx=max(mx,__gcd(abs(x[i]-x[j]),abs(y[i]-y[j]))+__gcd(abs(x[i]-x[k]),abs(y[i]-y[k]))+__gcd(abs(x[j]-x[k]),abs(y[j]-y[k])));
	//					mx=max(mx,a+b+c);
					}
				}
			}
		}
		cout<<mx<<endl;
	}
	return 0;
}