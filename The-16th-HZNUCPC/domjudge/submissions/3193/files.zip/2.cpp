#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#include <stack>
#include <bitset>
#include <algorithm>
#define maxn 200010
#define maxm 200010
#define ll long long
using namespace std;

int n, m, k;

inline int trans(int x) { return x > n ? x - n : x + n; }

int fa[maxn];
void init_fa(int n) { for (int i = 1; i <= n; ++i) fa[i] = i; } 
int find(int x) { 
	vector<int> vec;
	while (fa[x] != x) { 
		vec.push_back(x);
		x = fa[x];
	}
	for (auto u : vec) fa[u] = x;
	return x;
}
void merge(int x, int y) { 
	x = find(x), y = find(y);
	if (x == y) return ;
	fa[x] = y;
}

bool vis[maxn];
vector<int> A[maxn]; int a[maxn];

const int N = 100001;
bitset<N> f[N];

void work() { 
	for (int i = 1; i <= 2 * n; ++i) 
		A[find(i)].push_back(i), a[find(i)] += i <= n;
	vector<int> vec;
	for (int i = 1; i <= 2 * n; ++i) { 
		if (vis[i] || !A[i].size()) continue;
		vec.push_back(i);
		vis[find(trans(i))] = 1;
	} 
	
	int top = vec.size(); f[0][0] = 1; 
	for (int o = 0, i = vec[o]; o < top; ++o) {
		i = vec[o];
		int v1 = a[i], v2 = A[i].size() - a[i];
		f[o + 1] = f[o] << v1;
		f[o + 1] |= f[o] << v2;
	}
	if (!f[top][k]) return cout << "NO" << "\n", void();
	vector<int> ans;
	for (int i = top; i; --i) { 
		int v1 = a[vec[i - 1]], v2 = A[vec[i - 1]].size() - v1;
		if (k >= v1 && f[i - 1][k - v1]) {
			k -= v1;
			for (auto u : A[vec[i - 1]])
				if (u <= n) ans.push_back(u);
		} else if (k >= v2 && f[i - 1][k - v2]) { 
			k -= v2;
			for (auto u : A[vec[i - 1]])
				if (u > n) ans.push_back(u - n);
		}
	}
	cout << "YES" << "\n";
	sort(ans.begin(), ans.end());
	for (auto u : ans) cout << u << " "; cout << "\n";
}

int main() { 
	ios::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr); 
	
	//freopen("1.in", "r", stdin);
	//freopen("1.out", "w", stdout);
	
	cin >> n >> k >> m; init_fa(2 * n);
	for (int i = 1; i <= m; ++i) { 
		int o, x, y; cin >> o >> x >> y;
		merge(x, y + o * n), merge(x + n, y + (o ^ 1) * n);
	}
	for (int i = 1; i <= n; ++i)
		if (find(i) == find(i + n)) return cout << "NO" << "\n", 0;
	work();
	return 0; 
} 