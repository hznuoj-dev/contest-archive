import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		long n = s.nextLong();
		long m = s.nextLong();
		if(n%m==0)System.out.println("NO");
		else System.out.println("YES");
	}
}
