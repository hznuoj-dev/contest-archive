#include <bits/stdc++.h>
using namespace std;
int a[200][200];
int yz(int x, int y)
{
	int temp;
	if(x<y)
	{
		temp=x;
		x=y;
		y=temp;
	}
	if(y==0)
	return x;
	while(x%y!=0)
	{
		int c = x%y;
		x = y;
		y = c;
	}
	return y;
}
int main()
{
	int t;
	long long k1, k2, sum=0, ans=0;
	int x,y,mark=0;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
		scanf("%d %d",&a[i][1],&a[i][2]);
	int m, z;
	for(m=2;m<=t;m++)
	{
		if(a[m][1]!=a[1][1])
		break;
	}
	if(m==t+1)
	{
		printf("0\n");
		return 0;
	}
	for(z=2;z<=t;z++)
	{
		if(a[z][2]!=a[1][2])
		break;
	}
	if(z==t+1)
	{
		printf("0\n");
		return 0;
	}
	double k;
	int flag=0;
	for(int i =2;i<=t;i++)
	{		
		y = abs(a[i][2]-a[1][2]);
		x = abs(a[i][1]-a[1][1]);
		if(x==0 || y==0)
		{
			flag=1;
			break;
		}
		if(i==2)
		k=1.0*y/x;
		else
		{
			double k2 = 1.0*y/x;
			if(fabs(k-k2)<=0.0000001)                           
				;
			else
			{
			 flag = 1;
				break;
			}
		}
	}
	if(flag == 0)
	{
		printf("0\n");
		return 0;	
	} 
	for(int i=1;i<=t-2;i++)
	{
		for(int j=i+1;j<=t-1;j++)
		{
			for(int k=j+1;k<=t;k++)
			{
					sum=0;
					k1=abs(a[i][1]-a[j][1]);
					k2=abs(a[i][2]-a[j][2]);
					if(yz(k1,k2)==1)
						sum=sum+2;
					else
						sum=sum+yz(k1,k2)+1;
					k1=abs(a[i][1]-a[k][1]);
					k2=abs(a[i][2]-a[k][2]);
					if(yz(k1,k2)==1)
						sum=sum+2;
					else
						sum=sum+yz(k1,k2)+1;
					k1=abs(a[j][1]-a[k][1]);
					k2=abs(a[j][2]-a[k][2]);
					if(yz(k1,k2)==1)
						sum=sum+2;
					else
						sum=sum+yz(k1,k2)+1;
					if(sum>ans)
					ans=sum;
			}
		}
	}
	printf("%lld\n",ans-3);
}