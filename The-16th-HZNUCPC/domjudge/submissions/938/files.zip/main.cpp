#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
const ll N=1005;
ll n,m;
/*bool car(ll x,ll y)
{
    if(y==1)return 1;
    if(y==0)return 0;
    return car(x,x%y);
}*/
ll na(ll x)
{
    for(ll i=2;i*i<=x;++i)
    {
        if(x%i==0)return i;
    }
    return 1e18;
}
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>n>>m;
    if(m==1)cout<<"YES";
    else if(n==1)cout<<"YES";
    else if(n<=m)cout<<"NO";
    else
    {
        bool p=1;
        while(m>1)
        {
            if(na(n)<=m)p=0;
            m=n%m;
        }
        if(p==0||m==0)cout<<"NO";
        else cout<<"YES";

    }
    return 0;
}
