#include<stdio.h>
#include<math.h>
int main()
{
	int i,j,n,m;
	for(i=0;i<1000;i++)
	{
		scanf("%d %d",&n,&m);
		if(n%m!=0)
		{
			printf("YES");
		}
		else
		{
			printf("NO");
		}
	}
}