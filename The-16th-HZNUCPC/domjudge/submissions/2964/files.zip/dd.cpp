#include <bits/stdc++.h>
using namespace std;
const int N=1e7+10,M=N*2;
int e[M], ne[M], h[N], w[M],idx,dis[N];
int n,m,x;
void add(int a,int b,int c)
{
	e[idx]=b;w[idx]=c;ne[idx]=h[a];h[a]=idx++;
}
struct node
{
	int time,l,r;
}edge[N];
bool st[N];
typedef pair <int,int> PII;
int dijkstra(int ti,int start)
{
	memset(dis,0x3f3f3f3f,sizeof dis);
	dis[start]=0;
	priority_queue<PII,vector<PII>,greater<PII>> q;
	q.push({0,start}); // first -> dis second -> id;
	while(!q.empty())
	{
		auto t=q.top();
		q.pop();
		int distance=t.first,num=t.second;
		for (int i=h[num];i!=-1;i=ne[i])
		{
			int j=e[i];
			int tiii=w[i];
			if(dis[j]>distance+1 && ti<=tiii)
			{
				dis[j]=distance+1;
				q.push({dis[j],j});
			}
		}
	}
	if(dis[x]==0x3f3f3f3f) return -1;
	return dis[x];
} 
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin >> n >> m >> x;
	memset(h,-1,sizeof h);
	for (int k=1;k<=n;k++)
	{
		cin >> edge[k].time >> edge[k].l >> edge[k].r;
		for (int i=edge[k].l;i<edge[k].r;i++)
		{
			for (int j=i+1;j<=edge[k].r;j++)
			{
				add(i,j,edge[k].time);
			}
		}
	}	
		while(m--)
		{
			int ti,start;
			cin >> ti >> start;
			cout << dijkstra(ti,start) << endl;
		}
	return 0;
}