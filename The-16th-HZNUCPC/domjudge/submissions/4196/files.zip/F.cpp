#include "bits/stdc++.h"
using namespace std;
#define LL long long
bool solve(LL n,LL m) {

	if(m == 1 || n == 1) {
		return true;
	}
	if (n <= m) {
		return false;
	}
	if(n%m==1) {
		return true;
	}
	if (n % m == 0) {
		return false;
	}

	return solve(n, n % m);
}
int main() {
	LL n,m;
	cin >> n >> m;
	if(solve(n,m)) {
		printf("YES");
	} else {
		printf("NO");
	}
}
