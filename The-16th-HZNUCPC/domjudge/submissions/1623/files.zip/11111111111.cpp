#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n,k;
	cin>>n>>k;
	if(n==1||k==1) {
		cout<<"YES\n";
		return 0;
	}
	if(n<=k){
		cout<<"NO\n";
	}else{
		for(int i=2;i*i<=n;i++){
			if(n%i==0){
				if(k>=i){
					cout<<"NO\n";
					return 0;
				}else{
					cout<<"YES\n";
					return 0;
				}
			}
		}
		cout<<"YES\n";

	}
return 0;
}