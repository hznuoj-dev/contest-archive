#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
typedef long long ll;
int main(){
int n,m,f=0;
cin>>n>>m;
for(int i=2;i*i<=n;i++){
	if(n%i==0&&i<=m){
		f=1;
		break;
	}
}
if(f) puts("NO");
else puts("YES");
}