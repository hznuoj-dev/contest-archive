#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
	ll n,m;
	cin>>n>>m;
	if(n==1||m==1)
	{
		cout<<"YES";
		return 0;
	}
	if(m>=n) 
	{	
		cout<<"NO";
		return 0;
	}
/*	for(ll i=2;i*i<=n;i++)
	{
		if(n%i==0)
		{
			if(m<i)
			{
				cout<<"YES";
				return 0;
			}
			else
			{
				cout<<"NO";
				return 0;
			}
		}
	}*/
	ll k;
	while(1)
	{
		k=n%m;
		if(k==1)
		{
			cout<<"YES";
			return 0;
		}
		if(k==0)
		{
			cout<<"NO";
			return 0;
		}
		m=k;
	}
	cout<<"YES";
}