#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,s;
	cin>>n>>m;
	if(m>=n){
		cout<<"NO";
	}
	for(int i=2;i<=sqrt(n);++i){
		if(n%i==0){
			if(i>m)cout<<"YES";
			else cout<<"NO";
			return 0;
		}
	}
	cout<<"YES";
	return 0;
}