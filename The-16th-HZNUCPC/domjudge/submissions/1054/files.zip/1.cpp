#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"YES"<<'\n';
		return 0;
	}
	int x=0;
	for(int i=2;i*i<=n;i++){
		if(n%i==0){
			x=i;
			break;
		}
	}
	if(x==0){
		x=n;
	}
	if(x<=m){
		cout<<"NO"<<'\n';
	}else {
		cout<<"YES"<<'\n';
	}
}