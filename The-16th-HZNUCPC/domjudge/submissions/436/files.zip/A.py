t=int(input())
for i in range(t):
    n=int(input())
    s=[]
    m=[]
    ans=0
    for j in range(n):
        x,y,c=map(int,input().split())
        if c==1:
            s.append((x,y))
        else:
            m.append((x,y))
    for x in s:
        if (x[0]-1,x[1]) and x[0]>1 and ((x[0]-1,x[1]) not in s+m):
            ans+=1
        if (x[0]+1,x[1]) and x[0]<19 and ((x[0]+1,x[1]) not in s+m):
            ans+=1
        if (x[0],x[1]-1) and x[1]>1 and ((x[0],x[1]-1) not in s+m):
            ans+=1
        if (x[0],x[1]+1) and x[1]<19 and ((x[0],x[1]+1) not in s+m):
            ans+=1
    print(ans)
