#include<bits/stdc++.h>
using namespace std;

long long n,m;
int main()
{
	cin>>n>>m;
	while(true)
	{
		if(n%m==0)
		{
			cout<<"NO\n";
			break;
		}
		else if(n%m==1)
		{
			cout<<"YES\n";
			break;
		}
		else
		{
			m=n%m;
		}
	}
	return 0;
}

