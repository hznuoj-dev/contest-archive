#include<iostream>

using namespace std;

int charm[50][50];

int n, t, x, y, c;

int main () {
	cin >> t;
	while (t--) {
		for (int i = 1; i <= 19; i++) {
			for (int j = 1; j <= 19; j++) {
				charm[i][j] = -1;
			}
		}
		cin >> n;
		for (int i = 0; i < n; i++) {
			cin >> x >> y >> c;
			charm[x][y] = c;
		}
		int ans = 0;
		for (int i = 1; i <= 19; i++) {
			for (int j = 1; j <= 19; j++) {
				if (charm[i][j] == 1) {
					if (charm[i + 1][j] == -1) {
						ans += 1;
					}
					if (charm[i - 1][j] == -1) {
						ans += 1;
					}
					if (charm[i][j + 1] == -1) {
						ans += 1;
					}
					if (charm[i][j - 1] == -1) {
						ans += 1;
					}
				}
			}
		}
		cout << ans << '\n';
	}
	return 0;
}