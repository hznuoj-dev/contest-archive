#include<iostream>
#include<cstring>
using namespace std;
int t,n,x[20][20];
long long ans;
int main()
{
	cin>>t;
	while(t--)
	{
		ans=0;
		cin>>n;
		memset(x,0,sizeof(x));
		int a,b,c;
		for (int i=1;i<=n;i++)
		{
			cin>>a>>b>>c;
			if (c==1)
			x[a][b]=1;
		}
		for (int i=1;i<=19;i++)
		{
			for (int j=1;j<=19;j++)
			{
				if (x[i][j]==1)
				{
					if (i-1>0&&x[i-1][j]==0)
					ans++;
					if (i+1<=19&&x[i+1][j]==0)
					ans++;
					if (j+1<=19&&x[i][j+1]==0)
					ans++;
					if (j-1>0&&x[i][j-1]==0)
					ans++;
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}