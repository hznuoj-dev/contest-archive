//#include<iostream>
//#include<algorithm>
//#include<vector>
//using namespace std;
//const int N = 400;
//int n;
//int num[N][N];
//int way[4][2] = {{-1 , 0} ,{1 , 0} , {0 , 1} , {0 , -1}};
//vector<pair<int,int>> a1;
//int main(){
//    int T;
//    cin >> T;
//    while(T--){
//		cin >> n;
//		int n1 , n2 , ans = 0;
//		a1.clear();
//		for(int i = 1 ; i <= 19 ; i++)
//			for(int j = 1 ; j <= 19 ; j++)
//				num[i][j] = 0;
//		for(int i = 1 , x ,y , c ; i <= n ; i++){
//			cin >> x >> y >> c;
//			num[x][y] = 1;
//			if(c == 1) a1.push_back({x , y});
//		}
//		for(int i = 0 ; i < a1.size();i++){
//			int x = a1[i].first;
//			int y = a1[i].first;
//			for(int j = 0 ; j < 4 ; j++){ 
//				int xx = x + way[j][0];
//				int yy = y + way[j][1];
//				if(num[xx][yy] || xx <= 0 || yy <= 0 || xx > 19 || yy > 19) continue;
//				ans++;
//			}
//		}
//		cout << ans << endl;
//    }
//}

#include<iostream>
#include<algorithm>
#include<vector>
#include<cmath>
using namespace std;
const int N = 1e5 + 10;
long long n , m;
int main(){
    cin >> n >> m;
    long long flag = 0;
    for(int i = 2 ; i <= sqrt(n);i++){
    	if(n % i == 0){
    		flag = i;
    		break;
		}
	}
	if(m == 1 || n == 1) cout << "YES" << endl;
	else if(flag == 0){
		if(n == 2 || n <= m) cout << "NO" << endl;
		else cout << "YES" << endl;
	}else{
		if(flag <= m) cout << "NO" << endl;
		else cout << "YES" << endl;
	}
}