#include<bits/stdc++.h>
using namespace std;
struct point{
	double x;
	double y;
};
double dis(point a,point b){
	return hypot(a.x-b.x,a.y-b.y);
}
signed main()
{
	int n,i,j,k,cnt=0,max=0;
	cin>>n;
	point a[n+1];
	for(i=1;i<=n;i++)
		cin>>a[i].x>>a[i].y;
	for(i=1;i<=n-2;i++)
		for(j=i+1;j<=n-1;j++)
			for(k=j+1;k<=n;k++){
				if(dis(a[i],a[j])+dis(a[i],a[k])>dis(a[k],a[j])&&dis(a[i],a[j])+dis(a[j],a[k])>dis(a[k],a[i])&&dis(a[i],a[k])+dis(a[j],a[k])>dis(a[j],a[i]))
				{
					cnt=0;
					/*cnt=cnt+std::__gcd((int)fabs(a[i].x-a[j].x),(int)fabs(a[i].y-a[j].y));
					cnt=cnt+std::__gcd((int)fabs(a[k].x-a[j].x),(int)fabs(a[k].y-a[j].y));
					cnt=cnt+std::__gcd((int)fabs(a[i].x-a[k].x),(int)fabs(a[i].y-a[k].y));*/
					if(a[i].x!=a[j].x || a[i].y!=a[j].y){
						cnt=cnt+std::__gcd((int)fabs(a[i].x-a[j].x),(int)fabs(a[i].y-a[j].y))+1;
					}else{
						cnt=cnt+(int)fabs(a[i].x-a[j].x)+(int)fabs(a[i].y-a[j].y)+1;
					}
					if(a[k].x!=a[j].x || a[k].y!=a[j].y)
						cnt=cnt+std::__gcd((int)fabs(a[k].x-a[j].x),(int)fabs(a[k].y-a[j].y))+1;
					else
						cnt=cnt+(int)fabs(a[k].x-a[j].x)+(int)fabs(a[k].y-a[j].y)+1;
					if(a[k].x!=a[i].x || a[k].y!=a[i].y)
						cnt=cnt+std::__gcd((int)fabs(a[i].x-a[k].x),(int)fabs(a[i].y-a[k].y))+1;
					else
						cnt=cnt+(int)fabs(a[k].x-a[i].x)+(int)fabs(a[k].y-a[i].y)+1;
						
						cnt=cnt-3;
					if(cnt>max)max=cnt;
				}
			}
	cout<<max;
	return 0;
}
