#include<bits/stdc++.h>
using namespace std;
typedef long long int ll;
typedef unsigned long long int ull;
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
#define INF 0x7fffffff
#define mem 0x7f
#define int long long
int x[101],y[101];
int maxans=0;
string s;char a[5005],b[5005];
void solve(){maxans=0;
	cin>>s;
	int len=s.size();
	for(int i=0;i<len/2;i++){
		int po=i,di1=-1,di2=-1,len=0,tag=-1;
		for(int j=0;j<=i;j++){
			a[po]=s[j];po--;
			b[j]=s[j+i+1];
		}
		for(int j=0;j<=i;j++){
			if(a[j]!=b[j]){
				if(di1==-1){
					di1=j;tag=len;
				}else if(di2==-1){
					di2=j;
				}else break;
			}len++;
		}maxans=max(maxans,tag*2+1);
		if(di1==-1&&di2==-1)maxans=max(maxans,len*2);
		if(di1!=-1&&di2!=-1){
			if(a[di1]==a[di2]&&b[di2]==b[di1]||a[di1]==b[di2]&&a[di2]==b[di1])
			maxans=max(maxans,len*2);
		}
	
		
	}
	for(int i=0;i<(len-1)/2;i++){
		int po=i,di1=-1,di2=-1,len=0,tag=-1;
		for(int j=0;j<=i;j++){
			a[po]=s[j];po--;
			b[j]=s[j+i+2];
		}
		for(int j=0;j<=i;j++){
			if(a[j]!=b[j]){
				if(di1==-1){
					di1=j;tag=len;
				}else if(di2==-1){
					di2=j;
				}else break;
			}len++;
		}
		maxans=max(maxans,tag*2+1);
		if(di1==-1&&di2==-1)maxans=max(maxans,len*2+1);
		if(di1!=-1&&di2!=-1){
			if(a[di1]==a[di2]&&b[di2]==b[di1]||a[di1]==b[di2]&&a[di2]==b[di1])
			maxans=max(maxans,len*2+1);
		}
	
		
	}
	if(maxans==1)cout<<0<<endl;
	else cout<<maxans<<endl;

}

signed main()
{
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int t;cin >> t;while(t--)
	solve();
	getchar();
	return 0;
}