#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int> PII;
const int MOD=1e9+7;

int cnt[30][30];

signed main(){
	string s1,s2;
	cin>>s1>>s2;
	int n=s1.size();
	for(int i=0;i<n;i++){
		cnt[s1[i]-'a'][0]++;
		cnt[s2[i]-'a'][1]++;
	}
	int cha=0;
	for(int i=0;i<26;i++){
		cha+=(cnt[i][0]>0);
		cha-=(cnt[i][1]>0);
	}
	map<int,int> m;
	for(int i=0;i<n;i++){
		int x=0;
		if(s1[i]==s2[i]){
		}else{
			if(cnt[s2[i]-'a'][0]==0){
				x++;
			}
			if(cnt[s1[i]-'a'][1]==0){
				x--;
			}
			if(cnt[s1[i]-'a'][0]==1){
				x--;
			}
			if(cnt[s2[i]-'a'][1]==1){
				x++;
			}
		}
		m[x]++;
	}
	map<int,int> st;
	int res=0;
	for(int i=-2;i<=2;i++){
		int j=-(cha+i);
		if(st[i]||st[j]) continue;
		st[i]=1;
		st[j]=1;

		if(i==j){
			int t1=m[i],t2=m[i]-1;
			if(t1%2==0){
				t1/=2;
			}else{
				t2/=2;
			}
			res=(res+(t1%MOD*t2)%MOD)%MOD;
		}else{
			res=(res+((m[i]%MOD)*m[j])%MOD)%MOD;
		}
	}
	cout<<res<<endl;
	return 0;
}