#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::synbc_with_stdio(flase);cin.tie(0);cout.tie(0)
void solve(){
	int n,m;cin>>n>>m;
	if(n==1){
		cout<<"YES"<<endl;
	}else {
		int p=n%m;
		
		if(n%m==0)cout<<"NO"<<endl;
		else {
			if(m%p==0)cout<<"NO"<<endl;
			else cout<<"YES"<<endl;
		}
	}
}
signed main(){
//	IOS;
	solve();
	return 0;
}