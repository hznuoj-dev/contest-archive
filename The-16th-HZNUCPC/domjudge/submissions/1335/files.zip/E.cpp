#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define x first
#define y second
using pii = pair<ll, ll>;
int main (){
    int n;
    cin >> n;
    vector <pii> p(n);
    for (int i = 0 ; i < n ; i ++){
        cin >>p[i].first >> p[i].second;
    }
    set<ll> s1, s2;
    for (int i = 0; i < n; i++) {
        s1.insert(p[i].x);
        s2.insert(p[i].y);
    }
    if (s1.size() == 1 || s2.size() == 1) {
        cout << 0 << endl;
        return 0;
    }
    set<pii> s3;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (i == j) {
                continue;
            }
            ll tx = abs(p[i].x - p[j].x), ty = abs(p[i].y - p[j].y);
            ll g = __gcd(tx, ty);
            s3.insert({tx / g, ty / g});
        }
    }
    if (s3.size() == 1) {
        cout << 0 << endl;
        return 0;
    }
    auto f = [&] (pii a, pii b){
        if (a.x == b.x){
            return abs(a.y - b.y) - 1;
        }
        if (a.y == b.y){
             return abs(a.x - b.x) -1;
        }
        ll dx = abs(a.x - b.x), dy = abs (a.y - b.y);
        ll g = __gcd(dx, dy);
        ll k = dx / g;
        return dx / k - 1;
    };
    ll ans = 0;
    for (int i = 0 ; i < n ; i ++){
        for (int j = 0 ; j < n ; j ++){
            for (int k = 0 ; k < n ; k ++){
                if (i == j || i == k || j == k) {
                    continue;
                }
                ll res = f(p[i], p[j]) + f(p[i],p[k]) + f(p[j],p[k]) + 3 ;
                ans = max (res, ans);
            }
        }
    }
    cout << ans <<endl;
}

