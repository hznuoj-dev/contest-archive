#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#include <stack>
#include <bitset>
#include <algorithm>
#include <cmath>
#define maxn 200010
#define maxm 200010
#define ll long long
using namespace std;

int n, m, k;

inline int trans(int x) { return x > n ? x - n : x + n; }

int fa[maxn];
void init_fa(int n) { for (int i = 1; i <= n; ++i) fa[i] = i; } 
int find(int x) { 
	vector<int> vec;
	while (fa[x] != x) { 
		vec.push_back(x);
		x = fa[x];
	}
	for (auto u : vec) fa[u] = x;
	return x;
}
void merge(int x, int y) { 
	x = find(x), y = find(y);
	if (x == y) return ;
	fa[x] = y;
}

bool vis[maxn];
vector<int> A[maxn]; int a[maxn], b[maxn];

const int N = 100001, sqtn = 400;
bitset<N> f[sqtn], g[sqtn], h;
int l[sqtn], r[sqtn];

void work() { 
	for (int i = 1; i <= 2 * n; ++i) 
		A[find(i)].push_back(i), a[find(i)] += i <= n;
	vector<int> vec; vec.push_back(0);
	for (int i = 1; i <= 2 * n; ++i) { 
		if (vis[i] || !A[i].size()) continue;
		vec.push_back(i);
		vis[find(trans(i))] = 1;
	} 
	
	
	int top = vec.size() - 1, B = sqrt(top), num = (top + B - 1) / B;
	for (int i = 1; i <= num; ++i) 
		l[i] = (i - 1) * B + 1, r[i] = i * B;
		
	f[0][0] = 1; r[num] = top;
	for (int i = 1; i <= num; ++i) { 
		f[i] = f[i - 1];
		for (int j = l[i]; j <= r[i]; ++j) 
			f[i] = f[i] << a[vec[j]] | f[i] << A[vec[j]].size() - a[vec[j]];
	}
	
	if (!f[num][k]) return cout << "NO" << "\n", void();
	
	vector<int> ans;
	for (int i = num; i; --i) { 
		g[0] = f[i - 1];
		for (int j = l[i], k = 0; j < r[i]; ++j, ++k) 
			g[k + 1] = g[k] << a[vec[j]] | g[k] << A[vec[j]].size() - a[vec[j]];
		for (int j = r[i], t = r[i] - l[i]; j >= l[i]; --j, --t) {
			int v1 = a[vec[j]], v2 = A[vec[j]].size() - v1;
			if (k >= v1 && g[t][k - v1]) {
				k -= v1;
				for (auto u : A[vec[j]])
					if (u <= n) ans.push_back(u);
			} else if (k >= v2 && g[t][k - v2]) { 
				k -= v2;
				for (auto u : A[vec[j]])
					if (u > n) ans.push_back(u - n);
			}
		}
	}
	
	cout << "YES" << "\n";
	sort(ans.begin(), ans.end());
	for (auto u : ans) cout << u << " "; cout << "\n";
}

int main() { 
	ios::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr); 
	
	//freopen("1.in", "r", stdin);
	//freopen("1.out", "w", stdout);
	
	cin >> n >> k >> m; init_fa(2 * n);
	for (int i = 1; i <= m; ++i) { 
		int o, x, y; cin >> o >> x >> y;
		merge(x, y + o * n), merge(x + n, y + (o ^ 1) * n);
	}
	for (int i = 1; i <= n; ++i)
		if (find(i) == find(i + n)) return cout << "NO" << "\n", 0;
	work();
	return 0; 
} 