#include<bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(),(a).end;
using namespace std;

void solve()
{
	ll n, m;
	cin >> n >> m;
	
	if(m == 1)
	{
		cout << "YES" << '\n';
		return;
	}
	if(n <= m)
	{
		cout << "NO" << '\n';
		return;
	}
	
	for(ll i = 2; i * i <= n; i++)
	{
		if(n % i == 0)
		{
			ll fac = i;
			if(fac <= m)
			{
				cout << "NO" << '\n';
				return;
			}
		}
	}
	
	cout << "YES" << '\n';
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t--) solve();
	return 0;
}