import java.util.ArrayList;
import java.util.Scanner;

import javax.print.attribute.standard.PDLOverrideSupported;

public class Main
{
	static long sum;

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		sum = 0;
		int n = s.nextInt();
		ArrayList<node> arr = new ArrayList<>();
		for (int i = 0; i < n; i++)
		{
			arr.add(new node(s.nextInt(), s.nextInt()));
		}
		int x1, x2, x3, y1, y2, y3, p;
		boolean f=false;
		for (int i = 0; i < arr.size(); i++)
		{
			x1 = arr.get(i).x;
			y1 = arr.get(i).y;
			for (int j = i + 1; j < arr.size(); j++)
			{
				x2 = arr.get(j).x;
				y2 = arr.get(j).y;
				for (int k = j + 1; k < arr.size(); k++)
				{
					x3 = arr.get(k).x;
					y3 = arr.get(k).y;
					double b=(y2-y3)*1.0/(x2-x3);
					double d=(y2-y1)*1.0/(x2-x1);
					if(b==d)continue;
					else 
					{
					p = pd(x1, x2, x3, y1, y2, y3);
					if (p  > sum)
						sum = p;
					f=true;
					}
				}
			}
		}
		System.out.println(f?sum+3:0);

	}

	private static int pd(int x1, int x2, int x3, int y1, int y2, int y3)
	{
		int p = 0;
		int x = x1 - x2;
		int y = y1 - y2;
		p = p + pd2(x, y);
		x = x1 - x3;
		y = y1 - y3;
		p = p + pd2(x, y);
		x = x2 - x3;
		y = y2 - y3;
		p = p + pd2(x, y);
		return p;
	}

	private static int pd2(int x, int y)
	{
		int p = 0;
		if (x < 0) x = -x;
		if (y < 0) y = -y;
		if (x == 1 || y == 1){} 
		else if (x == 0)
			p = p + y-1;
		else if (y == 0)
			p = p + x-1;
		else if (x <= y)
			if (y % x == 0)
				p = p + (y / x);
		else if (y < x)
			if (x % y == 0)
				p = p + (x / y);
		return p;
	}
}

class node
{
	int x;
	int y;

	public node()
	{

	}

	public node(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
}