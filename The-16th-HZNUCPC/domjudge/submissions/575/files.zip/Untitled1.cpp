#include<bits/stdc++.h>
using namespace std;
#define ll long long;
int T,n,x,y,c,a[21][21];
int main() {
	cin>>T;
	while(T--) {
		cin>>n;
		for(int i=1; i<=n; i++) {
			cin>>x>>y>>c;
			if(c==1) {
				a[x][y]=1;
			} else {
				a[x][y]=2;
			}
		}
		int sum=0;
		for(int i=0; i<=20; i++) {
			for(int j=0; j<=20; j++) {
				if(i==0||j==0||i==20||j==20) {
					a[i][j]=3;
				}
			}
		}
		for(int i=1; i<=19; i++) {
			for(int j=1; j<=19; j++) {
				if(a[i][j]==1) {
					if(a[i-1][j]==0) {
						sum++;
					}
					if(a[i+1][j]==0) {
						sum++;
					}
					if(a[i][j-1]==0) {
						sum++;
					}
					if(a[i][j+1]==0) {
						sum++;
					}
				}
			}
		}
		cout<<sum<<endl;
	}
	return 0;
}