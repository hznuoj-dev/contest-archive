#include<bits/stdc++.h>
#define ll long long
#define sf scanf
#define pf printf
#define x first
#define y second
#define ld long double
using namespace std;
const ld eps=1e-4;
const int N=110;
typedef pair<ll,ll>pll;
pll p[N];
ll gcd(ll n,ll m){return m?gcd(m,n%m):n;}
bool check(int i,int j,int k){
	ll x1=p[i].x,x2=p[j].x,x3=p[k].x;
	ll y1=p[i].y,y2=p[j].y,y3=p[k].y;
	return ((y2-y1)*(x3-x1)!=(x2-x1)*(y3-y1));
}
void solve(){
	int n;sf("%d",&n);
	for(int i=1;i<=n;i++)sf("%d %d",&p[i].x,&p[i].y);
	ll ans=0;
	bool flag=0; 
	//check(1,2,3);
	for(int i=1;i<=n-2;i++){
		for(int j=i+1;j<=n-1;j++){
			for(int k=j+1;k<=n;k++){
				//printf("check(%d,%d,%d)=%d\n",i,j,k,check(i,j,k));
				if(!check(i,j,k))continue;
				flag=1;
				ll x,y,g,tmp=0;
				x=abs(p[i].x-p[j].x),y=abs(p[i].y-p[j].y);
				g=gcd(x,y);
				tmp+=g;
				x=abs(p[i].x-p[k].x),y=abs(p[i].y-p[k].y);
				g=gcd(x,y);
				tmp+=g;
				x=abs(p[j].x-p[k].x),y=abs(p[j].y-p[k].y);
				g=gcd(x,y);
				tmp+=g;
				ans=max(ans,tmp);
			}
		}
	}
	if(flag)pf("%lld\n",ans);
	else puts("0");
}
signed main(){
	int T=1;//sf("%d",&T);
	while(T--)solve();
	return 0;
}

