
#include <bits/stdc++.h>
using namespace std;
long long n, m;
long long k = 0;
int main() {
	cin >> n >> m;
	if (n == 1 || m == 1) {
		puts("YES");
		return 0;
	} else if (n <= m) {
		puts("NO");
		return 0;
	}
	for (long long i = 2; i * i <= n; i++) {
		if (n % i == 0) {
			k = i;
			break;
		}
	}
	if (k == 0) {
		puts("YES");
		return 0;
	}
	if (k <= m) {
		puts("NO");
	} else {
		puts("YES");
	}
	return 0;
}
