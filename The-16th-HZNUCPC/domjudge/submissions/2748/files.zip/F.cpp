#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll min(ll x, ll y){
	if(x < y) return x;
	return y;
}
bool is_prime(ll x,ll m){
	ll len = min(sqrt(x), m);
	for (int i=2;i <= len;i++){
		if (x%i==0){
			return false;
		}
	}
	return true;
}
int main(){
	ll  n,m;
	while(cin>>n>>m){
		while(n % 2 == 0){
			n /= 2;
		}
		while(m % 2 == 0){
			m /= 2;
		}
//		if(is_prime(n, m) && n > m){
//			cout << "YES" << endl;
//		}else{
//			cout << "NO" << endl;
//		}
		if(n % m != 0 && n > m){
			cout << "YES" << endl;
		}else{
			cout << "NO" << endl;
		}
	}
	return 0;
}
