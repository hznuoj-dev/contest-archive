#include <bits/stdc++.h>
#define all(x) (x).begin(),(x).end()

using namespace std;

const int N = 1e5 + 10;

typedef long long LL;
typedef pair<int, int> PII;

int d[25][25];
int dx[] = {0, 0, 1, -1};
int dy[] = {1, -1, 0, 0};

void solve()
{
	int n;
	cin >> n;
	for (int i = 0; i <= 19; i ++ )
		for (int j = 0; j <= 19; j ++ )
			d[i][j] = 0;
			
	for (int i = 1; i <= n; i ++ )
	{
		int x, y, c;
		cin >> x >> y >> c;
		d[x][y] = c;
	}
	
	for (int i = 1; i <= 19; i ++ )
		for (int j = 1; j <= 19; j ++ )
			{
				if(d[i][j] == 0) continue;
				int cnt = 0;
				for (int k = 0; k < 4; k ++ ) 
				{
					int xx = i + dx[k], yy = j + dy[k];
					if(xx <= 0 || xx >= 20 || yy <= 0 || yy >= 20) continue;
					cnt ++ ;
					if(d[xx][yy] != 0) cnt -- ;
				}
				
				if(cnt == 0) d[i][j] = 0;
			}
	
	int res = 0;
	for (int i = 1; i <= 19; i ++ )
		for (int j = 1; j <= 19; j ++ )
			{
				if(d[i][j] == 0) continue;
				int cnt = 0;
				for (int k = 0; k < 4; k ++ ) 
				{
					int xx = i + dx[k], yy = j + dy[k];
					if(xx <= 0 || xx >= 20 || yy <= 0 || yy >= 20) continue;
					if(d[xx][yy] == 0) res ++ ;
				}
			}
	
	cout << res << '\n';
}

int main()
{
	//ios::sync_with_stdio(0), cin.tie(0);
    int t = 1;
    cin >> t;
    while (t -- ) solve();
    return 0;
}
