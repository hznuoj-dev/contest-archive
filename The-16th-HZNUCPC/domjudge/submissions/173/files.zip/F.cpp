#include<bits/stdc++.h>
using namespace std;
const int N=1e6;
typedef long long ll;
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	ll n,m;
	cin>>n>>m;
	int ok=0;
	if(n<=m){
		cout<<"NO";
	}
	else{
		while(m!=1){
			m=n%m;
			if(m==0){
				ok=1;
				break;
			}
		}
		if(ok==1){
			cout<<"NO";
		}
		else{
			cout<<"YES";
		}
	}
	
}