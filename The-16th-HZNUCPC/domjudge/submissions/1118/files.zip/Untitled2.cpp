#include<bits/stdc++.h>
using namespace std;
#define dzs ios::sync_with_stdio(false);cin.tie(nullptr),cout.tie(nullptr)
typedef long long ll;
int main()
{
	ll n,m;
	int flag=1;
	cin>>n>>m;
	if(n<=m)flag=0;
	if(n%2==0)flag=0;
	for(int i=2;i<=m&&flag;i++)
	{
		if(n%i==0)flag=0;
	}
	flag ? cout<<"YES" : cout<<"NO";
} 