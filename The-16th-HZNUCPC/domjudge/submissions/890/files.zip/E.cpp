#include <bits/stdc++.h>

using namespace std;
using LL = long long;

const double eps = 1e-8;

int main()
{
	int n;
	cin >> n;
	vector<pair<int, int>> v(n);
	for (auto &[x, y] : v) cin >> x >> y;
	
	LL ans = 0;
	for (int i = 0; i < n; ++ i)
	{
		auto [x1, y1] = v[i];
		for (int j = 0; j < n; ++ j)
		{
			auto [x2, y2] = v[j];
			for (int k = 0; k < n; ++ k)
			{
				auto [x3, y3] = v[k];
				LL a = __gcd(abs(x1 - x2), abs(y1 - y2)) - 1;	
				LL b = __gcd(abs(x1 - x3), abs(y1 - y3)) - 1;	
				LL c = __gcd(abs(x3 - x2), abs(y3 - y2)) - 1;
//				double k1 = 1.0 * abs(y1 - y2) / abs(x1 - x2);
//				double k2 = 1.0 * abs(y1 - y3) / abs(x1 - x3);
				if ((LL)abs(y1 - y2) * abs(x1 - x3) != (LL)(abs)(x1 - x2) * (y1 - y3)) ans = max(ans, a + b + c + 3);		
			}
		}
	}
	cout << ans << "\n";
}