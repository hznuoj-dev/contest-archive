#include <bits/stdc++.h>
#define ll long long

using namespace std;

ll gcd(ll a,ll b){
	return b?gcd(b,a%b):a;
}

int main(){
	ll n,m;	
	cin>>n>>m;
	if(n<=m){
		cout<<"NO";
		return 0;
	}
	if(gcd(n,m)==1)cout<<"YES";
	else cout<<"NO";
}