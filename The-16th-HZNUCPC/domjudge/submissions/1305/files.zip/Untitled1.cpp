#include <bits/stdc++.h>
using namespace std;
  
int main(){
    long long  n , m ;
    cin >> n >> m;
    long long  pre = -1 ;
    if(m >= n){
    	cout << "NO";
    	return 0 ;
	}else{
		int t = 100;
		while(t--){
			 if(n  % m ==0 ){
		 	cout << "NO";
		 	return 0 ;
		 }else if(n % m == 1 ){
		 	cout << "YES";
		 	return 0 ;
		 }else{
		 	m = n % m;
		 	if(pre == m ){
		 		cout << "NO";
		 	return 0 ;
			 }
		 	pre = m ;
		 }
		}
		return 0 ;
		
	}
    
    
}