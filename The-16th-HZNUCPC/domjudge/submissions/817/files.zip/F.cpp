#include<iostream>

using namespace std;


int main(){

int n, m;
cin>>n>>m;
if (m == 1 && n ==1)
{
    cout<<"YES"<<endl;
}
if ((n % 2) == 0)
{
    cout<<"NO"<<endl;
}
else
{
    if (n <= m)
    {
        cout<<"NO"<<endl;
    }
    else
    {
        if (n % m == 0)
        {
            cout<<"NO"<<endl;
        }
        else
        {
            cout<<"YES"<<endl;
        }
    }
}

}
