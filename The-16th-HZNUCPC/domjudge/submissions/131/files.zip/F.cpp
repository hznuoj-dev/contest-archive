#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int>PII;
#define pb push_back
void solve(){
    int n,m;
    cin>>n>>m;
    if(m>=n){
        cout<<"NO"<<endl;
    }else{
        int now=m;
        while(now!=1){
            int x=n%now;
            if(x==now||x==0){
                cout<<"NO"<<endl;
                return ;
            }else{
                now=x;
            }
        }
        cout<<"YES"<<endl;
    }
    return ;
} 
signed main(){
    int t=1;
    cin>>t;
    while(t--){
        solve();
    }
    return 0;
}