#include<bits/stdc++.h>
#define int long long
using namespace std;
void solve() {
	int n,m;
	cin>>n>>m;
	if (gcd(n,m)==1&&n>m)
		cout<<"YES\n";
	else
		cout<<"NO\n";
}
signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}
