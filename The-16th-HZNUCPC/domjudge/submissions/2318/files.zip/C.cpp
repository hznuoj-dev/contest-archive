#include <bits/stdc++.h>
using namespace std;
const int N = 1e5 + 9;
const int MOD = 1e9 + 7;
int a[2][N], n, g[2][26], ans[2], f[26][26];
char s[N];
long long sum;
long long pw(long long a, int b) {
	long long res = 1;
	while (b) {
		if (b & 1) res = res * a % MOD;
		a = a * a % MOD;
		b >>= 1;
	}
	return res;
}
void cal(int k0, int k1) {
	for (int i = 1; i <= n; ++ i) ++ f[a[k0][i]][a[k1][i]];
	for (int i = 1; i <= n; ++ i) {
		-- f[a[k0][i]][a[k1][i]];
		if (g[k0][a[k0][i]] == 1) -- ans[k0];
		if (g[k0][a[k1][i]] == 0) ++ ans[k0];
		if (g[k1][a[k1][i]] == 1) -- ans[k1];
		if (g[k1][a[k0][i]] == 0) ++ ans[k1];
		-- g[k0][a[k0][i]]; ++ g[k0][a[k1][i]];
		-- g[k1][a[k1][i]]; ++ g[k1][a[k0][i]];
		for (int j0 = 0; j0 < 26; ++ j0)
			for (int j1 = 0; j1 < 26; ++ j1)
				if (f[j0][j1]) {
					if (g[k0][j0] == 1) -- ans[k0];
					if (g[k0][j1] == 0) ++ ans[k0];
					if (g[k1][j1] == 1) -- ans[k1];
					if (g[k1][j0] == 0) ++ ans[k1];
					if (ans[k0] == ans[k1]) sum = (sum + f[j0][j1]) % MOD;
					if (g[k0][j0] == 1) ++ ans[k0];
					if (g[k0][j1] == 0) -- ans[k0];
					if (g[k1][j1] == 1) ++ ans[k1];
					if (g[k1][j0] == 0) -- ans[k1];
				}
		++ f[a[k0][i]][a[k1][i]];
		if (g[k0][a[k0][i]] == 0) ++ ans[k0];
		if (g[k0][a[k1][i]] == 1) -- ans[k0];
		if (g[k1][a[k1][i]] == 0) ++ ans[k1];
		if (g[k1][a[k0][i]] == 1) -- ans[k1];
		++ g[k0][a[k0][i]]; -- g[k0][a[k1][i]];
		++ g[k1][a[k1][i]]; -- g[k1][a[k0][i]];
	}
	printf("%lld", sum * pw(2, MOD - 2) % MOD);
}
int main() {
	scanf("%s", s + 1);
	n = strlen(s + 1);
	for (int i = 1; i <= n; ++ i) {
		a[0][i] = s[i] - 'a';
		if (g[0][a[0][i]] == 0) ++ ans[0];
		++ g[0][a[0][i]];
	}
	scanf("%s", s + 1);
	for (int i = 1; i <= n; ++ i) {
		a[1][i] = s[i] - 'a';
		if (g[1][a[1][i]] == 0) ++ ans[1];
		++ g[1][a[1][i]];
	}
	if (abs(ans[0] - ans[1]) > 4) printf("0");
	else if (ans[0] >= ans[1]) cal(0, 1);
	else cal(1, 0);
	return 0;
}