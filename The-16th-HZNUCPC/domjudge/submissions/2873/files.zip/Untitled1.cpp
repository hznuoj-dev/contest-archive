#include<iostream>
using namespace std;
typedef long long LL;
LL n,m;//n caipan  m xuanshou
int main(){
	cin >> n >> m;
	while(1){
		if(n == 1 || m == 1){
			cout << "YES";
			break;
		}else if(m == 0){
			cout << "NO";
			break;
		}
		if(m >= n){
			cout << "NO";
			break;
		}else{
			m = n % m;
		}
	}
	return 0;
}