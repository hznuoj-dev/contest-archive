import sys
input = lambda: sys.stdin.readline().strip()
def func(n,m):
    if m == 1:
        print('YES')
        return
    if n % m == 0:
        print('NO')
        return
    return func(n,n%m)
n,m = map(int,input().split())
func(n,m)
