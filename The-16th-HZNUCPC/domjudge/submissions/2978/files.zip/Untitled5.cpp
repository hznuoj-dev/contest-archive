#include<bits/stdc++.h>

using namespace std;

#define int long long

const int N = 1e5 + 10, mod = 1e9 + 7;

int ca[26], cb[26], c[26][26];

int qpow(int x, int k) {
	int res = 1;
	while (k) {
		if (k & 1)
			res = res * x % mod;
		k >>= 1;
		x = x * x % mod;
	}
	return res;
}

signed main() {
	string a, b;
	cin >> a >> b;
	for (auto c : a) {
		ca[c - 'a'] ++;
	}
	for (auto c : b) {
		cb[c - 'a'] ++;
	}
	for (int i = 0; i < a.size(); i ++) {
		c[a[i]-'a'][b[i]-'a'] ++;
	}
	int ans = 0;
	for (int i = 0; i < 26; i ++)
		for (int j = 0; j < 26; j ++) {
			int res = c[i][j];
			if (ca[i] < 1 || cb[j] < 1) continue;
			ca[i] --, ca[j] ++;
			cb[i] ++, cb[j] --;
			c[i][j] --;
			for (int k = 0; k < 26; k ++) 
				for (int p = 0; p < 26; p ++) {
					if (ca[k] < 1 || cb[p] < 1) continue;
					ca[k] --, ca[p] ++;
					cb[k] ++, cb[p] --;
					int cnt1 = 0, cnt2 = 0;
					for (int ii = 0; ii < 26; ii ++) {
						if (ca[ii]) cnt1 ++;
						if (cb[ii]) cnt2 ++;
					}
					if (cnt1 == cnt2) {
						ans += res * c[k][p];
//						cout << i << ' ' << j << ' ' << k << ' ' << p << '\n';
//						cout << res << ' ' << c[k][p] << '\n';
					}	
					ca[k] ++, ca[p] --;
					cb[k] --, cb[p] ++;
				}
			ca[i] ++, ca[j] --;
			cb[i] --, cb[j] ++;
			c[i][j] ++;
		}
	cout << (ans % mod)*qpow(2, mod - 2) % mod << '\n';
		
	
	
	
}