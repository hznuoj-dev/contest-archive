#include<bits/stdc++.h>
#define int long long
using namespace std;
int wq[22][22];
int dir[5][5] = {{-1,0},{1,0},{0,-1},{0,1}};

bool check(int x,int y){
	if(x < 1 || y < 1 || x > 19 || y > 19 || wq[x][y] != 0){
		return false;
	}else{
		return true;
	}
}

signed main()
{
	int T,n;
	cin >> T;
	while(T--)
	{
		cin >> n;
		memset(wq,0,sizeof wq);
		int ans = 0;
		for(int i = 1; i <= n; i++){
			int x,y,c;
			cin >> x >> y >> c;
			if(c == 1){//black
				wq[x][y] = 1;
			}else if(c == 2){//white
				wq[x][y] = 2;				
			}
		}
		
		for(int i = 1; i <= 20; i++){
			for(int j = 1; j <= 20; j++){
				if(wq[i][j] == 1){
					for(int k = 0; k < 4; k++){
						int tx = i + dir[k][0];
						int ty = j + dir[k][1];
						if(check(tx,ty)){
							ans ++;
						}
					}
				}
			}
		}
		
		cout << ans << endl;
	}
	return 0;
}
