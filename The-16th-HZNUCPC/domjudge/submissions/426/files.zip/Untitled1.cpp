#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main (){
    ll a, b;
    cin >> a >> b;
    ll x = 1E6 + 10;
    ll y = -1;
    for (int t = 2; t <= x; t++) {
        if (a % t == 0) {
            y = t;
            break;
        }
    }
    if (y == -1)
        y = a;
    if (a == 1 || b == 1) {
        cout << "YES" << endl;
    } else if (y <= b) {
        cout << "NO" << endl;
    } else {
        cout << "YES" << endl;
    }

}

