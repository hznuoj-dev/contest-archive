#include <bits/stdc++.h>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int n,m;
int main(int argc, char** argv) {
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin>>n>>m;
	while(n%m>0){
		m=n%m;
	}
	if(m==1) cout<<"YES\n";
	else cout<<"NO\n";
	return 0;
}