#include<iostream>
using namespace std;
int n,m;
int main()
{
	cin>>n>>m;
	while(1)
	{
		m=n%m;
		if(m==1)
		{
		cout<<"YES";
		return 0;
	}
		if(m==0){
		cout<<"NO";
		return 0;
	}
	}
	return 0;
}