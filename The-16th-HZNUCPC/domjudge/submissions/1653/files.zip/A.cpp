#include<iostream>
#include<cstring>
using namespace std;
int n,m,ys[19919][10010];
long long ans=0;
int main()
{
	cin>>n;
	for(int h=1;h<=n;h++)
	{ ans=0;
		cin>>m;
	
		for(int i=1;i<=m;i++)
		{
			int x,y;
			cin>>x>>y;
				//	cout<<ys[x][y]<<endl;
			cin>>ys[x][y];
	
		if	(ys[x][y]==1)ans+=4;
		//cout<<ans<<endl;
		}
		for(int i=1;i<=190;i++)
	{
		for(int j=1;j<=190;j++)
		{
	
				if(ys[i][j]==1)
			{
				if(i==1)ans--;
				if(j==1)ans--;
					if(i==19)ans--;
				if(j==19)ans--;
				if(ys[i+1][j]>0)ans--;
				if(ys[i-1][j]>0)ans--;
				if(ys[i][j+1]>0)ans--;
				if(ys[i][j-1]>0)ans--;
			}
		}
	}
		for(int i=1;i<=190;i++)
		for(int j=1;j<=190;j++)
		ys[i][j]=0;
	
		cout<<ans<<endl;
	}
	

	return 0;
}