#include<bits/stdc++.h>
#define int long long
using namespace std;
struct point{
	int x,y;
}p[120];
int check(int x,int y) {
	return __gcd(abs(x),abs(y))-1;
}
pair<int,int> calc(int x,int y) {
	if (x==0) return {0,1};
	if (y==0) return {1,0};
	int d=__gcd(x,y);
	if (x<0&&y>0) {
		x=-x,y=-y;
	}
	int sgn=1;
	if (x>0&&y<0) {
		sgn=-1;
		x=abs(x),y=abs(y);
	}
	return {sgn*x/d,y/d};
}
signed main() {
	int n;
	cin>>n;
	bool flag=false;
	set<pair<int,int>> se;
	for (int i=1;i<=n;i++) {
		cin>>p[i].x>>p[i].y;	
		if (i>1) {
			if (p[i].x==p[1].x&&p[i].y==p[2].y) continue;
			se.insert(calc(p[i].x-p[1].x,p[i].y-p[1].y));
		}
	}
	if (se.size()==1) {
		cout<<0<<endl;
		return 0;
	}
	int ans=0;
	for (int i=1;i<=n;i++) {
		for (int j=i+1;j<=n;j++){
			for (int k=j+1;k<=n;k++) {
				point p1=p[i],p2=p[j],p3=p[k];
				int cur=check(p1.x-p2.x,p1.y-p2.y)+check(p1.x-p3.x,p1.y-p3.y)+check(p2.x-p3.x,p2.y-p3.y)+3;
				ans=max(ans,cur);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}