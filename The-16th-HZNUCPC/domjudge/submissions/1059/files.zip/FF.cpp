#include <bits/stdc++.h>
#define int int64_t
#define endl '\n'
using namespace std;

const int MAX = 105;
int x[MAX], y[MAX];
int edge[MAX][MAX];

void solve() {
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> x[i] >> y[i];
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			int dx = abs(x[i]-x[j]), dy = abs(y[i]-y[j]);
			edge[i][j] = __gcd(dx, dy);
		}
	}
	int res = 0;
	for (int i = 0; i < n; i++) {
		for (int j = i + 1; j < n; j++) {
			for (int k = j + 1; k < n; k++) {
				if ((x[i] - x[j]) * (y[i] - y[k]) == (x[i] - x[k]) * (y[i] - y[j])) continue;
				res = max(res, edge[i][j] + edge[i][k] + edge[j][k]);
			}
		}
	}
	cout << res << endl;
}

int32_t main() {
	cin.tie(0);
	cout.tie(0);
	ios::sync_with_stdio(false);
	
	solve();
	
	return 0;
}