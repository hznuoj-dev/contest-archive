#include <bits/stdc++.h>
using namespace std;
#define rep(a,b,c) for(int a=b;a<=c;a++)
#define per(a,b,c) for(int a=b;a>=c;a--)

typedef long long ll;
typedef unsigned long long ull;

typedef pair<int,int> PII;
typedef pair<ll,ll> PLL;

const int N=1e5+5,M=5*N;

int dct[4][2]={0,1,0,-1,1,0,-1,0};

int a[25][25];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);

    int t;cin>>t;
    while(t--){
        int n;cin>>n;
        memset(a,0,sizeof a);
        rep(i,0,20){a[0][i]=a[20][i]=a[i][0]=a[i][20]=-1;}
        rep(i,1,n){
            int x,y,c;cin>>x>>y>>c;
            a[x][y]=c;
        }int ans=0;
        rep(i,1,19){
            rep(j,1,19){
                if(a[i][j]==1){
                    rep(k,0,3){
                        int dx=dct[k][0],dy=dct[k][1];
                        if(a[i+dx][j+dy]==0){
                            ans++;

                        }
                    }
                }
            }
        }cout<<ans<<"\n";
    }



    return 0;
}