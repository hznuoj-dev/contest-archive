#include <bits/stdc++.h>
#define N (int)1e5+10
#define dwan ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define int long long
typedef long long ll;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

signed main(int argc, char** argv) {
	dwan;
	int n,m;
	cin>>n>>m;
	if(gcd(n,m)==1) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
}