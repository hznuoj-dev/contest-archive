#include "bits/stdc++.h"
using namespace std;
#define LL long long
bool solve(LL n,LL m){
	if(m == 1){
		return true;
	}
	else if (n % m == 0){
		return false;
	}
	
	if (n <= m){
		return false;
	}
	else {
		return solve(n,n % m); 
	}
}
int main(){
	LL n,m;
	cin >> n >> m;
	if(solve(n,m)){
		printf("YES");
	}else{
		printf("NO");
	}
}
