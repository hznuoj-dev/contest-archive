#include<bits/stdc++.h>
using namespace std;
int x[105],y[105];
int count(int x1,int y1,int x2,int y2){
	int ax=max(abs(x1-x2),abs(y1-y2));
	int in=min(abs(x1-x2),abs(y1-y2));
	if(in==0) return 2;
	if(ax%in==0&&in!=1) return ax/in+1;
	return 2;
}
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>x[i]>>y[i];
	}
	int ans=0;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(i==j||i==k||j==k) continue;
				if((x[i]==x[j]&&x[j]==x[k])||(y[i]==y[j]&&y[j]==y[k])) continue;
				int sum=count(x[i],y[i],x[j],y[j])+count(x[i],y[i],x[k],y[k])+count(x[k],y[k],x[j],y[j])-2;
				ans=max(ans,sum);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
