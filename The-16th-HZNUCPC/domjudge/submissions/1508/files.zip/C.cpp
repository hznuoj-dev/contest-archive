#include<bits/stdc++.h>
using namespace std;
#define int long long
const int P = 1e9 + 7;
int a[27][27];
int cnt1[27];
int cnt2[27];
int num1 = 0,num2 = 0;
void change(int i , int j){
	cnt1[i]--;
	cnt2[i]++;
	cnt1[j]++;
	cnt2[j]--;
}
int qsm(int a, int b){
	int res = 1;
	while(b){
		if(b & 1) res = res * a %P;
		a = a*a %P;
		b>>=1;
	}
	return res;
}
signed main(){
	string s1,s2;
	cin>>s1>>s2;
	for(int i = 0 ; i < s1.length() ; i++){
		cnt1[s1[i]-'a']++;
		cnt2[s2[i]-'a']++;
		a[s1[i]-'a'][s2[i]-'a']++;
	}
	int num1 , num2 ;
	int ans = 0;
	for(int i = 0 ; i < 26 ; i++){
		for(int j = 0 ; j < 26 ; j++){
			if(!a[i][j]) continue;
			a[i][j]--;
			for(int x = 0 ; x < 26 ; x++){
				for(int y = 0 ; y < 26 ; y++){
					if(!a[x][y]) continue;
					change(i,j);
					change(x,y);
					num1 = 0 , num2 = 0;				
					for(int i = 0 ; i < 26 ; i++){
						num1 += (cnt1[i] > 0);
						num2 += (cnt2[i] > 0);
					}
					if(num1 == num2){
						ans += (a[i][j]+1)*(a[x][y]);
						ans %= P;
					}
					change(j,i);
					change(y,x);
				}
			}
			a[i][j]++;
		}
	}
	int ny = qsm(2,P-2);
	ans = ans*ny %P;
	cout<<ans<<"\n";
	return 0;
}