#include<bits/stdc++.h>
using namespace std;
string s;
int n;
int check(int k){
	if(k==1||k==0) return 0;
	int a,b;
	char c,l[20],r[20];
	int cnt;
	for(int i=1;i<=n-k+1;i++){
		a=i,b=i+k-1;
		c=s[(a+b)/2];
		cnt=0;
		while(a<b){
			if(s[a]!=s[b]){
				cnt++;
				if(cnt>2) break;
				l[cnt]=s[a];
				r[cnt]=s[b];
			}
			a++;
			b--;
		}
		if(cnt>2) continue;
		if(cnt==2){
			if(l[1]==l[2]&&r[1]==r[2]) return 1;
			if(l[1]==r[2]&&r[1]==l[2]) return 1;
		}
		else if(cnt==1&&k%2==1){
			if(l[1]==c||r[1]==c) return 1;
		}
		else if(cnt==0){
			return 1;
		}
	}
	return 0;	
}
void work(){
	int res=0;
	cin>>s;
	n=s.length();
	s=" "+s;
	for(int i=n;i>=2;i--)
		if(check(i)){
			res=i;
			break;
		}
	cout<<res<<endl;
}

int main(){
	int t;
	cin>>t;
	while(t--)
		work();
	return 0;
}