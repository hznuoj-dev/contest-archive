#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
ll n, k;

int main()
{
	scanf("%lld %lld", &n, &k);
	if(k == 1) puts("YES");
	else if(n % k == 1) puts("YES");
	else if(n % 2 == 1) puts("YES");
	else puts("NO");
	return 0;
}