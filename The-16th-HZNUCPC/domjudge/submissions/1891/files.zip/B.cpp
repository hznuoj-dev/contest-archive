#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9 +7;
const int N = 1e3 +7;
ll t,n,m,s;

inline void run(){
   cin >> n >>m;
    while(m!=0&&m!=1) {
    	m = n %m;
	}
    if(m==1) cout <<"YES\n";
    else cout <<"NO\n";
}
int main()
{
//      int T;
//      for(cin >>T;T--;)
	    run();
}
