#include<iostream>
using namespace std;
using ll=long long;
int main()
{
	ll n,m;
	cin>>n>>m;
	if(m>n){
		cout<<"NO";
		return 0;
	}
	if(m==1){
		cout<<"YES";
		return 0;
	}
	while(true)
	{
		if(n%m==0){
			cout<<"NO";
			return 0;
		}
		if((m==2||m==1)&&n%m==1){
			cout<<"YES";
			return 0;
		}
		m=n%m;
		if(m==0){
			cout<<"NO";
			return 0;
		}
	}
	return 0;
}