#include <iostream>
#include <vector>
#include <cstring>
#define x first
#define y second
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int n;
pair<int,int>p[105];
pair<int,int>cnt[5];//记录三个点的位置
int gcd(int a,int b)
{
      return b == 0 ? a: gcd(b,a%b);
}
int find()
{
	int num=3;
	
    long long  x1=cnt[0].x-cnt[1].x;
	long long y1=cnt[0].y-cnt[1].y;
	long long x2=cnt[1].x-cnt[2].x;
	long long y2=cnt[1].y-cnt[2].y;
	long long t1=x2*y1;
	long long t2=x1*y2;
	if(t1==t2)return 0;
	
	
	
    for(int i=0;i<3;i++)
	{
	 for(int j=i+1;j<3;j++)
	 {
	 	int a=abs(cnt[i].x-cnt[j].x);
	 	int b=abs(cnt[i].y-cnt[j].y);
	 	num+=gcd(a,b)-1;
	 	//cout<<a<<b<<gcd(a,b)<<endl;
	 }
	}	
    return num;	
}
int maxsum=0;
void dfs(int num,int temp)
{
	if(num==3)
	{
		maxsum=max(maxsum,find());
		return;
	}
	for(int i=temp+1;i<=n;i++)
	{
		cnt[num]=p[i];
		dfs(num+1,i);
	}
	
	
}


int main() {
	
    
    
	scanf("%d",&n);
    
    
    
    for(int i=1;i<=n;i++)
    {
    	scanf("%d%d",&p[i].x,&p[i].y);
    	
	}
	dfs(0,0);
	//cout<<gcd(0,2)<<endl;
	printf("%d",maxsum);
	
	return 0;
}