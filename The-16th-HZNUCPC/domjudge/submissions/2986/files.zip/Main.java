

import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int t=sc.nextInt();
			while(t-->0)
			{
				int n=sc.nextInt();
				int map[][]=new int[21][21];
				for(int i=0;i<n;i++)
				{
					int xi=sc.nextInt();
					int yi=sc.nextInt();
					int ci=sc.nextInt();
					map[xi][yi]=ci;
				}
				int count=0;
				for(int i=1;i<=19;i++)
				{
					for(int j=1;j<=19;j++)
					{
						if(map[j][i]==1)
						{
							if(j-1>=1&&map[j-1][i]==0)count++;
							if(i-1>=1&&map[j][i-1]==0)count++;
							if(j+1<=19&&map[j+1][i]==0)count++;
							if(i+1<=19&&map[j][i+1]==0)count++;
						}
					}
				}
				System.out.println(count);
			}
		}

	}

}
