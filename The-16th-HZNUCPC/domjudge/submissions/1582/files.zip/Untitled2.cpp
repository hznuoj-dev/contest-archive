#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
	ll n, m;
	cin >> n >> m;
	if(n == 1){
		cout << "YES" << endl;
		return 0;
	} 
	if(m == 1){
		cout << "YES" << endl;
		return 0;
	}
	while(1){
		if(m == 1){
			cout << "YES" << endl;
			break;
		}else if(m == 0){
			cout << "NO" << endl;
			break;
		}
		ll x = n % m;
		m = x;
	}
	return 0;
}