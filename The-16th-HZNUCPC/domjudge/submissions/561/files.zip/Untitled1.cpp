#include<bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i,l,r) for(int i=l;i<=r;++i)
#define N 110
#define M 50
int n,ans=0;
struct Vector{
	int x,y;
}a[N];
Vector del(Vector a,Vector b){
	return (Vector){b.x-a.x,b.y-a.y};
}
int cross(Vector a,Vector b){
	return a.x*b.y-a.y*b.x;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n;
	rep(i,1,n)cin>>a[i].x>>a[i].y;
	rep(i,1,n){
		rep(j,i+1,n){
			rep(k,j+1,n){
				Vector la=del(a[i],a[j]),lb=del(a[i],a[k]);
				if(cross(la,lb)==0)continue;
				int tmp=0;
				int x1=abs(a[i].x-a[j].x);
				int y1=abs(a[i].y-a[j].y);
				tmp+=__gcd(x1,y1);
				x1=abs(a[i].x-a[k].x);
				y1=abs(a[i].y-a[k].y);
				tmp+=__gcd(x1,y1);
				x1=abs(a[j].x-a[k].x);
				y1=abs(a[j].y-a[k].y);
				tmp+=__gcd(x1,y1);
				ans=max(ans,tmp);
			}
		}
	}
	cout<<ans;
}