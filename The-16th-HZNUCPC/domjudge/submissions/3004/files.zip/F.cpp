#include <bits/stdc++.h>
#define ll long long

using namespace std;


int main(){
	ll n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"YES";
		return 0;
	}
	if(n<=m){
		cout<<"NO";
		return 0;
	}
	for(;m>0;){
		ll f=n%m;
		
		if(f==0){
			cout << "NO";
			break;
		}else m=f;

		if(m==1) {
			cout << "YES";
			break;
		}
	}
}