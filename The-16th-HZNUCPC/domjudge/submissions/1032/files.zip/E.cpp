#include<bits/stdc++.h>
using namespace std;
#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const int maxn=2e5+10;
const int mod=1e9+7;
const int inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
#define int long long

int gcd(int a,int b){
	if(a<0)a=-a;
	if(b<0)b=-b;
	return b?gcd(b,a%b):a;
}

struct node{
	int x,y;
	node(int x=0,int y=0):x(x),y(y){}
	
}no[110];
node operator - (node a,node b){return node(a.x-b.x,a.y-b.y);}
int count(node a,node b){
	int dx=b.x-a.x;
	int dy=b.y-a.y;
	int g=gcd(dx,dy);
	return g+1;
}
typedef node line;
bool check(node a,node b,node c){
	line ab=a-b;
	line ac=a-c;
	int g=gcd(ab.x,ab.y);
	if(g!=0){
		ab.x/=g;
		ab.y/=g;
	}
	g=gcd(ac.x,ac.y);
	if(g!=0){
		ac.x/=g;
		ac.y/=g;	
	}
	//cout<<ab.x<<" "<<ab.y<<" "<<ac.x<<" "<<ac.y<<endl;
	if((ab.x==ac.x&&ab.y==ac.y)||(ab.x==-ac.x&&ab.y==-ac.y)){
		return false;
	}
	return true;
}
void resolve(){
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		cin>>no[i].x>>no[i].y;
	}
	int ans=0;
	for(int i=1;i<=n-2;i++){
		for(int j=i+1;j<=n-1;j++){
			for(int k=j+1;k<=n;k++){
				//cout<<check(no[i],no[j],no[k])<<endl;
				if(!check(no[i],no[j],no[k]))continue;
				int now=0;
				now+=count(no[i],no[j]);
				//cout<<now<<endl;
				now+=count(no[k],no[j]);
				//cout<<now<<endl;
				now+=count(no[i],no[k]);
				//cout<<now<<endl;
				ans=max(ans,now-3);
			}
		}
	}
	cout<<ans<<endl;
}
signed main(){
	fast;
	int _=1;
	//cin>>_;
	while(_--){
		resolve();
	}
}