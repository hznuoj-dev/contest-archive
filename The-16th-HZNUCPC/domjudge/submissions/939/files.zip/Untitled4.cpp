#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,s;
struct node {
	int x,y;
	node(){
	}
	node(int _x,int _y):x(_x),y(_y){
		
	}
	node const operator -  (const node &b) const {
		return node(x-b.x,y-b.y);
	}
	int operator ^(const node &b) const{
		return x*b.y-y*b.x;
	}
	bool const operator == (const node &b) const{
		return x==b.x&&y==b.y;
	}
	int ans(){
		int xx=abs(x),yy=abs(y);
		//cout << "xx=" << xx << ",yy=" << yy << endl;
		if (!xx) return yy;
		if (!yy) return xx; 
		return __gcd(xx,yy);
	}
}p[365];
signed main(){
	cin >> n;
	for (int i=1;i<=n;++i) cin >> p[i].x >> p[i].y;
	for (int i=1;i<=n;++i) {
		for (int j=i+1;j<=n;++j) {
			for (int k=j+1;k<=n;++k) {
				if (p[i]==p[j]||p[i]==p[k]||p[j]==p[k]) continue;
				if ((p[i]-p[j])^(p[i]-p[k])) {
				//cout << "i=" << i << ",j=" << j << ",k=" << k << endl;
					int tmp=0;
					node q;
					q=p[i]-p[j];
					tmp+=q.ans();
					//cout << "tmp=" << tmp << endl;
					q=p[i]-p[k];
					tmp+=q.ans();
					//cout << "tmp=" << tmp << endl;
					q=p[k]-p[j];
					tmp+=q.ans();
					//cout << "tmp=" << tmp << endl;
					s=max(s,tmp);
				}
			}
		}
	}
	cout << s;
}
/*

4
0 0 1 1 2 4  4 2

*/