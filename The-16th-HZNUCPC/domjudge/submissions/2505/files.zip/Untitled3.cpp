#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
typedef pair<int,int> pii;
const int N = 1e2+10;
const int INF = 0x3f3f3f3f3f;
ll qpow (ll a,ll b ,ll p) 
{
ll res=1; 
while(b)
{
	if(b& 1)
	{
		res=res*a%p;
	}
		a=a*a%p;
		b>>=1;
	
}
return res;
}
int n;
pii p[N];

signed main()
{
	Acode;

		cin >> n;
		for (int i=1;i<=n;++i)
		{
			cin >> p[i].first >> p[i].second;
		}
		int ans = 0;
		int f = 0;
		for (int i=1;i<=n;++i)
		{
			for (int j=1;j<=n;++j)
			{
				for (int k=1;k<=n;++k)
				{
					if (i==j || j==k || i==k)
						continue;
					int x1 = p[i].first,y1 = p[i].second;
					int x2 = p[j].first,y2 = p[j].second;
					int x3 = p[k].first,y3 = p[k].second;
//					double a = sqrt((x2-x1)*(x2-x1)+(y2-y1)*(y2-y1));
//					double b = sqrt((x3-x1)*(x3-x1)+(y3-y1)*(y3-y1));
//					double c = sqrt((x3-x2)*(x3-x2)+(y3-y2)*(y3-y2));
					if ((x2-x1)*(y3-y1)-(x3-x1)*(y2-y1) > 0)
					{
						f = 1;
						int ans1 = __gcd(abs(x2-x1),abs(y2-y1));
						int ans2 = __gcd(abs(x3-x1),abs(y3-y1));
						int ans3 = __gcd(abs(x3-x2),abs(y3-y2));
						ans = max(ans,ans1+ans2+ans3);
					}
				}
			}
		}
		if (f)
		cout << ans;
		else
		cout << 0;
	return 0;
}
