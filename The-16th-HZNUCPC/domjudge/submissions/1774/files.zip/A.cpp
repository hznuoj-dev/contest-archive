#include <bits/stdc++.h>

using namespace std;

int vis[25][25],v[25][25],ans,T,n;

struct S{
	int x,y,c;
}a[400];

int main(){
	cin>>T;
	while(T--){
		ans=0;
		memset(a,0,sizeof a);
		memset(vis,0,sizeof vis);
		memset(v,0,sizeof v);
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			cin>>a[i].x>>a[i].y>>a[i].c;
			if(a[i].c==2) vis[a[i].x][a[i].y]=1;
			if(a[i].c==1) v[a[i].x][a[i].y]=1;
		}
		for(int i=1;i<=n;i++)
		if(a[i].c==1){
			if(!vis[a[i].x-1][a[i].y] && !v[a[i].x-1][a[i].y] && a[i].x-1>0) ans++;
			if(!vis[a[i].x+1][a[i].y] && !v[a[i].x+1][a[i].y] && a[i].x+1<20) ans++;
			if(!vis[a[i].x][a[i].y-1] && !v[a[i].x][a[i].y-1] && a[i].y-1>0) ans++;
			if(!vis[a[i].x][a[i].y+1] && !v[a[i].x][a[i].y+1] && a[i].y+1<20) ans++;
		}
		cout<<ans<<endl;
	}
	return 0;
}