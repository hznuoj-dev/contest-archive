#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=1e5+10,mod=1e9+7;
char s[N],t[N];
int n;
int a[50][50];

void solve(){
	scanf("%d", &n);
	for (int i = 1; i <= 19; i ++ )
		for (int j = 1; j <= 19; j ++ ) a[i][j] = 0;
		
	for (int i = 1; i <= n; i ++ )
	{
		int x, y, c;
		scanf("%d%d%d", &x, &y, &c);
		a[x][y] = c;
	}
	
	ll ans = 0;
	for (int i = 1; i <= 19; i ++ )
		for (int j = 1; j <= 19; j ++ )
			if(a[i][j] == 1)
			{
				if(a[i - 1][j] == 0 && i - 1 >= 1) ans ++;
				if(a[i + 1][j] == 0 && i + 1 <= 19) ans ++;
				if(a[i][j - 1] == 0 && j - 1 >= 1) ans ++;
				if(a[i][j + 1] == 0 && j + 1 <= 19) ans ++;
			}
	printf("%lld\n", ans);
 }
int main() {
	int T; scanf("%d", &T);
	while(T --) solve();
}