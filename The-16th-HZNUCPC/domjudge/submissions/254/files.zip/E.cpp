#include <bits/stdc++.h>
#define int long long
using namespace std;
int n;
typedef pair<int,int> PII;
PII a[110];
signed main()
{
	ios::sync_with_stdio(0);
	
	cin.tie(0);
	
	cin >> n;
	for(int i = 0 ; i < n ; i ++) {
		int x, y; cin >> x >> y;
		a[i] = {x, y};
	}
	
	int res = (-1 + n) * n / 2;
	
	for(int i = 0 ; i < n ; i ++)
	{
		for(int j = i + 1 ; j < n ; j ++)
		{
			for(int k = j + 1 ; k < n ; k ++)
			{
				if(k == i || k == j) continue;
				if( ( a[k].second - a[i].second) * (a[j].first - a[i].first) == (a[k].first - a[i].first) * (a[j].second - a[i].second)) {
					res -= 2;
				}
			}
		}
	}
	
	/*for(int i = 0 ; i < n ; i ++)
	{
		for(int j = i + 1 ; j < n ; j ++)
		{
			for(int k = j + 1 ; k < n ; k ++)
			{
				if( ( a[k].second - a[i].second) * (a[j].first - a[i].first) != (a[k].first - a[i].first) * (a[j].second - a[i].second)) res ++;
			}
		}
	}*/
	
	cout << res << endl;
}