#include <bits/stdc++.h>
using namespace std;
long long n, m;
int main() {
	scanf("%lld%lld", &n, &m);
	for (long long i = 2; i * i <= n && i <= m; ++ i)
		if (n % i == 0){
			if (m < i) {printf("YES"); return 0;}
			else {printf("NO"); return 0;}
		}
	printf("YES");
	return 0;
}