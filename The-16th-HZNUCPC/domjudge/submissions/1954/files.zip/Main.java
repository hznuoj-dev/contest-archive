import java.util.*;
public class Main
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		//while (sc.hasNext())
		{
			long n=sc.nextLong();
			long m=sc.nextLong();
			int f=0;
			long x=n,y=m;
			int pd=1;
			for(int i=0;;i++){
				if(y==1&&i==0){pd=0;break;}
				y=x%y;
				if(y==1){
					pd=0;
					break;
				}else if(y==0)break;
			}
			System.out.println(pd==0?"YES":"NO");
		
		}
	}	
}