#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 1e5 + 10;
const double PI = acos(-1);
bool check(ll n) {
	if (n == 1 || n == 2) return true;
	for (int i = 2; i <= sqrt(n); i++) {
		if (n % i == 0) return false;
	}
	return true;
}
void solve() {
	ll n, m;
	cin >> n >> m;
	if (check(n) && n != m) cout << "YES";
	else cout << "NO";
}
int main() {
	solve();
	return 0;
}