#include<bits/stdc++.h>
using namespace std;
long long p,n,m,flagx=1,flagy=1,flagk=1;
long long pdx,pdy,non=1;
double pdk;
long long x[120],y[120],z[120],ans=0;
long long pd(long long tmp1,long long tmp2)
{
//	cout<<tmp1<<" "<<x[tmp1]<<" "<<y[tmp1]<<endl;
	//cout<<tmp2<<" "<<x[tmp2]<<" "<<y[tmp2]<<endl;
	long long fx=abs(x[tmp1]-x[tmp2]);
	long long fy=abs(y[tmp1]-y[tmp2]);
	if(y[tmp1]==y[tmp2])
		return abs(x[tmp1]-x[tmp2])-1;
	if(x[tmp1]==x[tmp2])
		return abs(y[tmp1]-y[tmp2])-1;
	return max(0ll,min(fx,fy)-1);
}
int main() 
{
	cin>>n;
	for(long long i=1;i<=n;i++)
	{
		cin>>x[i]>>y[i];
		if(i==2||non)
		{
			if(y[i]-y[i-1]==0)
				continue;
			pdk=(double)(((x[i]-x[i-1])/(y[i]-y[i-1]))*1.0);
			non=0;
		}
		else if(i>2)
		{
			if(y[i]-y[i-1]==0)
				continue;
			//cout<<pdk<<" "<<(double)(((x[i]-x[i-1])/(y[i]-y[i-1]))*1.0)<<endl;
			if(pdk!=(double)(((x[i]-x[i-1])/(y[i]-y[i-1]))*1.0))
				flagk=0;
		}
		if(i==1)
		{
		//	cout<<pdk<<endl;
			pdx=x[1];
			pdy=y[i];
		}
		else
		{
			//cout<<(double)((x[i]/y[i])*1.0)<<endl;
			if(pdx!=x[i])
				flagx=0;
			if(pdy!=y[i])
				flagy=0;
		}
	}
	if(flagx||flagy||flagk)
	{
		cout<<0<<endl;
		return 0;
	}
	for(long long i=1;i<=n;i++)
	{
		for(long long j=i+1;j<=n;j++)
		{
			for(long long z=j+1;z<=n;z++)
			{
				long long sum=pd(i,j);
			//	cout<<sum<<"***********"<<endl;
				sum+=pd(j,z);//cout<<sum<<"***********"<<endl;
				sum+=pd(i,z);//cout<<sum<<"***********"<<endl;
				sum+=3;
				ans=max(ans,sum);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}