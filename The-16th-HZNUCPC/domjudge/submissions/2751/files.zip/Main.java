import java.util.*;
import java.io.*;

public class Main {
	static StreamTokenizer sr=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in))); 
	static Scanner in = new Scanner(System.in);
	static int[] Prime;
	static boolean[] isPrime;
	
	static void EP() {
		int maxn = (int) 1e6 + 5;
		Prime = new int[maxn];
		isPrime = new boolean[maxn];
		
		isPrime[1] = true;
		for (int i = 2; i < maxn; i ++) {
			if (!isPrime[i]) {
				Prime[++ Prime[0]] = i;
			}
			for (int j = 1; j <= Prime[0] && i * Prime[j] < maxn; j ++) {
				isPrime[i * Prime[j]] = true;
				if (i % Prime[j] == 0) break;
			}
		}
	}

	public static void main(String[] args)  {
		EP();
		long n = in.nextLong();
		long m = in.nextLong();
		if(n<=m){
			System.out.println("NO");
			return;
		}
		long x=0;
		for(int i=1;i<=Prime[0];i++){
			if(n%Prime[i]==0){
				x=Prime[i];
				break;
			}
		}
		if(x==0)x=n;
		if(x<=m)System.out.println("NO");
		else System.out.println("YES");
	}
}