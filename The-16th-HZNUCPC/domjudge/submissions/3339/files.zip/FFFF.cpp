#include<bits/stdc++.h>
using namespace std;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	long long n, m;
	cin >> n >> m;
	
	if(n == 1)
	{
		cout << "YES";
		return 0;
	}
	else if(n <= m)
	{
		cout << "NO";
		return 0;
	}
	
	while(m != 1 && m != 0)
	{
		m = n % m;
	}
	
	if(m == 1)
		cout << "YES";
	else
		cout << "NO";
}