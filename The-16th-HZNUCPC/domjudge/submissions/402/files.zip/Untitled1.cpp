
#include<bits/stdc++.h>
using namespace std;

#define int long long
signed main(){
	int n, m;
	while(cin >> n >> m){
		bool flag = true;
		if(m == 1) cout <<"YES\n";
		else{
			if(n <= m) {
				if(n == 1) cout <<"YES\n";
				else cout << "NO\n";
			}
			else {
				for(int i = 2;i <= sqrt(n);i ++){
					int p = n / i;
					if(p * i == n){
						if(m >= n / p){
							flag = false;
							break;
						}
					}
					if(m >= n* 1.0 / i*1.0){
						flag = false;
						break;
					}
				}
				if(flag) cout <<"YES\n";
				else cout << "NO\n";
			}
		}
		
	}
	return 0;
}