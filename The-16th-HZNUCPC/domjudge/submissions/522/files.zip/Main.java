import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
         Scanner s=new Scanner(System.in);
         int n=s.nextInt();
         for(int i=0;i<n;i++)
         {
        	 boolean arr[][]=new boolean[19][19];
        	 int m=s.nextInt();
        	 ArrayList<node>ac=new ArrayList<>();
        	 for(int t=0;t<19;t++)Arrays.fill(arr[t],true);
        	 for(int t=0;t<m;t++)
        	 {
        		 int a=s.nextInt();
        		 int b=s.nextInt();
        		 int c=s.nextInt();
        		 if(c==1)ac.add(new node(a-1,b-1));
        		 arr[a-1][b-1]=false;
        	 }
        	 long sum=0;
        	 for(int t=0;t<ac.size();t++)
        	 {
        		 int a=ac.get(t).a;
        		 int b=ac.get(t).b;
        		 if(a>0&&arr[a-1][b])sum++;
        		 if(b>0&&arr[a][b-1])sum++;
        		 if(a<18&&arr[a+1][b])sum++;
        		 if(b<18&&arr[a][b+1])sum++;
        	 }
        	 System.out.println(sum);
        	 
         }
	}

}
class node
{
	int a;
	int b;
	public node()
	{
		
	}
	public node(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
}