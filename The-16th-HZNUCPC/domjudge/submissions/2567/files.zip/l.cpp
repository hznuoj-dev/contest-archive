#include "bits/stdc++.h"
using namespace std;
long long a,b,c,d,e,f;
int main(){
	while(cin>>a>>b){
		long long k=b;
		while(k!=1){
			
			
			k=k+1;
		}
		
}
	return 0;
}