#include<bits/stdc++.h>
#define ft first
#define sd second
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
#define rep(i,a,b) for(ll i=a;i<=b;++i)
using namespace std;
int n;
string s;
int cnt[27];
bool check(int len){
    if(len>n) return 0;
    if(len<=1) return 1;
    int can=0;
    rep(i,1,n-len+1){
        int l=i,r=l+len-1;
        rep(j,l,r){
            cnt[s[j]-'a']++;
     //       cout<<"add"<<s[i]<<endl;
        }
        if(len&1){
            cnt[s[(l+r)/2]-'a']--;
        }
        int shipei=0;
        int f=1;
        rep(j,l,r){
        if(len&1&&j==(l+r)/2) continue;
            if(cnt[s[j]-'a']&1)  f=0;
        }
        rep(j,l,(l+r)/2){
            if(len&1&&j==(l+r)/2) continue;
            if(s[j]!=s[r-(j-l)]) shipei++;
        }
        rep(j,l,r){
             if(len&1&&j==(l+r)/2) continue;
            cnt[s[j]-'a']=0;
        }
     //   cout<<shipei<<" "<<f<<endl;
        if(shipei<=2&&f) can=1;
    }
    if(can) return 1;
    else return 0;
}

bool checkk(int len){
    if(len>n) return 0;
    if(len<=1) return 0;
    int can=0;
    rep(i,1,n-len+1){
        int l=i,r=l+len-1;
        rep(j,l,r){
            cnt[s[j]-'a']++;
        }
        if(len&1){
            cnt[s[(l+r)/2]-'a']--;
        }
     //   cout<< cnt[s[(l+r)/2]-'a']<<endl;
        int shipei=0;
        int f=1;
        int cntji=0;
        vector<int>cao(27);
        rep(j,l,r){
        if(len&1&&j==(l+r)/2) continue;
            if(cnt[s[j]-'a']&1){
                f=0;
                cao[s[j]-'a']=1;
            }
        }
        for(auto it:cao) cntji+=it;
        if(!f){
          //  cout<<cnt[s[(l+r)/2]-'a']+1<<" "<<cntji<<endl;
             if((cnt[s[(l+r)/2]-'a']+1)%2==0&&cntji<=2) f=1;
        }

        rep(j,l,(l+r)/2){
            if(len&1&&j==(l+r)/2) continue;
            if(s[j]!=s[r-(j-l)]) shipei++;
        }
        rep(j,l,r){
             if(len&1&&j==(l+r)/2) continue;
            cnt[s[j]-'a']=0;
        }
        if(shipei<=2&&f) can=1;
    }
    if(can) return 1;
    else return 0;
}

int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    int t;
    cin>>t;
    while(t--){
  //      string s;
        cin>>s;
        n=s.length();
        s=' '+s;
        int l=1,r=n;
        int ans=0;

        while(l<=r){
            int mid;
            mid=(l+r)/2;
            if(check(2*mid)) ans=2*mid,l=mid+1;
            else r=mid-1;
        }

         l=1,r=n;
        int anss=1;
        while(l<=r){
            int mid;
            mid=(l+r)/2;
          //  cout<<"run:"<<2*mid-1<<endl;
            if(checkk(2*mid-1)) anss=2*mid-1,l=mid+1;
            else r=mid-1;
        }
      //  cout<<ans<<" "<<anss<<endl;
        int caoa=max(ans,anss);
        if(caoa==1) caoa=0;
        cout<<caoa<<"\n";
    }
}
