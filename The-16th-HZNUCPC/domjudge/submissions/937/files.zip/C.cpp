#include<bits/stdc++.h>
#define int long long
#define ll long long
#define vi vector<int>
#define pb push_back

using namespace std;
const int mod = 1e9 + 7;
int mp[30][30];
int ca[30],cb[30];
int na = 0, nb = 0;

void swp(int i1, int i2) {
	ca[i2] ++;
	if (ca[i2] == 1) na ++;
	cb[i1] ++;
	if (cb[i1] == 1) nb ++;
	ca[i1] --;
	if (ca[i1] == 0) na --;
	cb[i2] --;
	if (cb[i2] == 0) nb --;
}
signed main() {
	string a, b;
	cin >> a >> b;
	int n = a.size();
	for (int i = 0; i < n; i ++) {
		mp[a[i]-'a'][b[i]-'a'] ++;
		ca[a[i]-'a']++;
		cb[b[i]-'a']++;
	}
	
	
	for (int i = 0; i < 26; i ++) {
		na += ca[i] != 0;
		nb += cb[i] != 0;
	}
	
	ll ans = 0;
	for (int i1 = 0; i1 < 26; i1 ++) {
		for (int i2 = 0; i2 < 26; i2 ++) {
			if (!mp[i1][i2]) continue;
			mp[i1][i2] --;
			swp(i1, i2);
			for (int j1 = 0; j1 < 26; j1 ++) {
				for (int j2 = 0; j2 < 26; j2 ++) {
					swp(j1,j2);
					if (na == nb) ans += 1ll * (mp[i1][i2]+1)*mp[j1][j2] % mod;
					if (ans >= mod) ans -= mod;
					swp(j2,j1);
				}
			}
			mp[i1][i2] ++;
			swp(i2,i1);
		}
	}
	cout << ans*(mod+1)/2%mod << '\n';
	return 0;
}
/*
4
0 0
1 1
2 4
4 2




4
1 1
2 2
3 3
2 4


*/