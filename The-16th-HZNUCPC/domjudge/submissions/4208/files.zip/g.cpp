#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define x first
#define y second
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;

const int maxn = 200100;

int n, q, m, tot, dp[maxn], id[maxn];
int p[maxn], vis[maxn];
pair<int, int> a[maxn];
array<int, 3> pre[maxn];
vector<int> good[maxn];

int get(int id, int t) {
	return id + t * n;
}
int find(int x) {
	if(p[x] == x) return p[x];
	return p[x] = find(p[x]);
}
void merge1(int u, int v) {
	int pu = find(get(u, 0)), pv = find(get(v, 0));
	if(pu != pv) p[pu] = pv;
	pu = find(get(u, 1)), pv = find(get(v, 1));
	if(pu != pv) p[pu] = pv;
}
void merge2(int u, int v) {
	int pu = find(get(u, 0)), pv = find(get(v, 1));
	if(pu != pv) p[pu] = pv;
	pu = find(get(u, 1)), pv = find(get(v, 0));
	if(pu != pv) p[pu] = pv;
}


int main() {
	ios;
	cin >> n >> q >> m;
	for(int i = 1; i <= 2 * n; i++) p[i] = i;
	for(int i = 1; i <= m; i++) {
		int ty, u, v;
		cin >> ty >> u >> v;
		if(ty == 0) merge1(u, v);
		else merge2(u, v);
	}
	for(int i = 1; i <= n; i++) {
		int P = find(i);
		good[P].push_back(i);
	}
	for(int i = 1; i <= n; i++) {
		int P1 = find(i), P2 = find(i + n);
		if(!vis[P1]) {
			a[++tot] = {good[P1].size(), good[P2].size()};
			id[tot] = i;
			vis[P1] = vis[P2] = 1;
		}
	}
	for(int i = 1; i <= tot; i++) cout << a[i].x << " " << a[i].y << endl;
	dp[0] = 1;
	for(int i = 1; i <= tot; i++) {
		for(int j = q; j >= 1; j--) {
			if(j >= a[i].x) {
//				cout << i << " " << j << " " << j - a[i].x << endl;
				if(dp[j - a[i].x] && !dp[j]) {
//					cout << i << " " << j << endl;
					pre[j] = {id[i], 0, a[i].x};	
					dp[j] = 1;
				}
			}
			if(j >= a[i].y) {
				if(dp[j - a[i].y] && !dp[j]) {
					pre[j] = {id[i], 1, a[i].y};	
					dp[j] = 1;
				}
			}
		}
	}
//	cout << pre[5][0] << endl;
	if(dp[q] == 0) {
		cout << "NO" << endl;
		return 0;
	}
	cout << "YES" << endl;
	while(q) {
		auto now = pre[q];
		int p = now[0], t = now[1]; 
		if(t == 0) {
			for(int i: good[find(p)]) if(i <= n) cout << i << " ";
		} else {
			for(int i: good[find(p + n)]) if(i <= n) cout << i << " ";
		}
		q -= now[2];
	}
}