#include <bits/stdc++.h>
using namespace std;
int num[100][100];

int gcd(int a,int b){

    if(b == 0){
        return a;
    }
    else{
        return gcd(b,a%b);
    }

}

int main()
{
    memset(num,-1,sizeof(num));
    int n;
    cin >> n;
    int x[110], y[110];
    int ans = 3, ma = 0;
    int dx,dy;
    int de;
    for (int i = 0; i < n; i ++) cin >> x[i] >> y[i];
    for (int i = 0; i < n; i ++)
    {
        for (int j = i + 1; j < n; j ++)
        {
            for (int k = j + 1; k < n; k ++)
            {
                int x1 = x[i], x2= x[j], x3 = x[k], y1 = y[i], y2 = y[j], y3 = y[k];
                //cout<<"id"<< i<<" "<< j<<" "<< k<<" ";
                if(x1 == x2 && x2 == x3 && x1 == x3 ){
                    continue;
                }
                if(y1 == y2 && y2 == y3 && y1 == y3){
                    continue;
                }
                if(x1 - x2 != 0 && x3 - x2 != 0&& x3 - x1 != 0){

                double k1 = (y1 - y2) / (x1 - x2);
                double k2 =(y3 - y2) / (x3 - x2);
                double k3 = (y1 - y3) / (x1 - x3);
                if (k1 == k2 || k1 == k3 || k2 == k3) continue;
                }

                if(num[i][j] == -1){
                    dy = abs(y1 - y2), dx = abs(x1 - x2);
                        num[i][j] = gcd(dx,dy) - 1;
                }
                if(num[j][k] == -1){
                    dy = abs(y3 - y2), dx = abs(x3 - x2);
                        num[j][k] = gcd(dx,dy) - 1;
                }
                if(num[i][k] == -1){
                    dy = abs(y1 - y3), dx = abs(x1 - x3);
                    num[i][k] = gcd(dx,dy) - 1;
                }
                //cout<<num[i][j]<<" "<<num[j][k]<<" "<<num[i][k]<<endl;
                ans = 3 + num[i][j]+num[i][k]+num[j][k];
                if (ma < ans)
                {
                    ma = ans;
                }
            }
        }

    }
    cout << ma << endl;
    return 0;

}
