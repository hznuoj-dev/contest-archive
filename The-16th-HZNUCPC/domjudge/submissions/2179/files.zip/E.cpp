#include <bits/stdc++.h>
using namespace std;
const int N=105;

struct d{
	int x;
	int y;
}a[N];

int s[N][N];
int ans=-2e9;

void suan(int i,int j)
{
	int x1=a[i].x,y1=a[i].y,x2=a[j].x,y2=a[j].y;
	int xx=x2-x1,yy=y2-y1;
	if (xx==0||yy==0)
	{
		if (xx)
			s[i][j]=xx-1,s[j][i]=xx-1;
		else
			s[i][j]==yy-1,s[j][i]=yy-1;
			
		return;
	}
	//除最大公约数
	if (abs(xx)>=abs(yy))
	{
		for (int k=abs(yy);k>1;k--)
			if (abs(xx)%k==0&&abs(yy)%k==0)
			{
				xx=xx/k,yy=yy/k;
				break;
			}
	}
	else
	{
		for (int k=abs(xx);k>1;k--)
			if (abs(xx)%k==0&&abs(yy)%k==0)
			{
				xx=xx/k,yy=yy/k;
				break;
			}	
	}
	int h=(x2-x1)/xx-1;
	s[i][j]=h;
	s[j][i]=h;
}

int main()
{	memset(s,-1,sizeof s);
	int n;
	cin>>n;
	for (int i=1;i<=n;i++)
	{
		cin>>a[i].x>>a[i].y;
	}
	
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			if (s[i][j]==-1)
				suan(i,j);	
		
	
	for (int i=1;i<=n;i++)
		for (int j=i+1;j<=n;j++)
			for (int k=j+1;k<=n;k++)
				ans=max(ans,s[i][j]+s[i][k]+s[j][k]);
				
				
	printf("%d",ans+3);
	
	return 0;
}