import sys
input = lambda: sys.stdin.readline().strip()
for _ in range(int(input())):
    s = input()
    a = []
    def func():
        if (a[0][1]-a[0][0]) % 2 == 0:bo = s[(a[0][1]+a[0][0])//2]
        else:bo = ''
        if len(a) == 1:
            return a[0][1]-a[0][0]-1
        elif len(a) == 2:
            if bo == s[a[0][0]] or bo == s[a[0][1]]:
                return a[1][1] - a[1][0] - 1
            else:
                return a[0][1]-a[0][0]-1
        else:
            z,x,c,v = s[a[0][0]],s[a[0][1]],s[a[1][0]],s[a[1][1]]
            if (z == v and x == c) or (z == x and c == v):
                return a[2][1] - a[2][0] - 1
            elif bo == z or bo == x:
                return a[1][1] - a[1][0] - 1
            else:
                return a[0][1]-a[0][0]-1
    def back(l,r):
        if l < 0 or r >= n:
            a.append([l,r])
            return func()
        if s[l] == s[r]:
            return back(l-1,r+1)
        else:
            a.append([l,r])
            if len(a) == 3:
                return func()
        return back(l-1,r+1)
    n = len(s)
    ans = back(n-1,n-1)
    for i in range(n-1):
        a = []
        x = back(i,i)
        a = []
        y = back(i,i+1)
        ans = max(ans,x,y)
    if ans == 1:print(0)
    else:print(ans)
