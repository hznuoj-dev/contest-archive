#include "bits/stdc++.h"
using namespace std;
long long a,b,c,d,e,f;
int main(){
	while(cin>>a>>b){
		long long k=b;
		if(a>b){
			while(k!=1){
			c=a%k;
			if(c==0){
				break;
			}
			k=c;
		}
		if(k==1){
			cout<<"YES"<<endl;
		}else if(k!=1){
			cout<<"NO"<<endl;
		}
		}else if(a==1&&b==1){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
		
}
	return 0;
}