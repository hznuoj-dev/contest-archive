#include <bits/stdc++.h>

#include <random>

#define dbg(x...) \
    do { \
        std::cout << #x << " -> "; \
        err(x); \
    } while (0)

void err() {
    std::cout << std::endl;
}

template<class T, class... Ts>
void err(T arg, Ts &... args) {
    std::cout << arg << ' ';
    err(args...);
}

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using i128 = __int128;

struct DSU {
    std::vector<int> f;

    DSU(int n) : f(n + 1, -1) {};

    int find(int x) {
        return f[x] < 0 ? x : f[x] = find(f[x]);
    }

    bool merge(int x, int y) {
        x = find(x);
        y = find(y);
        if (x == y) return false;
        if (f[x] > f[y]) std::swap(x, y);
        f[x] += f[y];
        f[y] = x;
        return true;
    }

    int siz(int x) {
        return -f[find(x)];
    }
};

void run(int tCase) {
    int n, q, m;
    std::cin >> n >> q >> m;
    DSU dsu(n);
    std::vector<std::pair<int, int>> es;
    for (int i = 0; i < m; ++i) {
        int t, u, v;
        std::cin >> t >> u >> v;
        u--, v--;
        if (t == 0) {
            dsu.merge(u, v);
        } else {
            es.emplace_back(u, v);
        }
    }
    std::vector<std::vector<int>> adj(n);
    for (auto [u, v]: es) {
        u = dsu.find(u);
        v = dsu.find(v);
        if (u == v) {
            std::cout << "NO\n";
            return;
        }
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    std::vector<int> col(n, -1);
    std::vector<std::pair<int, int>> a;
    std::vector<int> mark(n);
    std::vector<std::vector<int>> mk;
    for (int i = 0; i < n; ++i) {
        int rt = dsu.find(i);
        std::vector<int> marked;
        if (col[rt] == -1) {
            int cnt[2] = {};
            auto dfs = [&](auto &dfs, int u) -> void {
                for (int v: adj[u]) {
                    if (col[v] == -1) {
                        col[v] = !col[u];
                        marked.push_back(v);
                        cnt[col[v]] += dsu.siz(v);
                        dfs(dfs, v);
                    }
                }
            };
            col[rt] = 0;
            cnt[0] += dsu.siz(rt);
            marked.push_back(rt);
            dfs(dfs, rt);
            if (cnt[0] > cnt[1]) {
                std::swap(cnt[0], cnt[1]);
                for (int u: marked) {
                    col[u] = !col[u];
                }
            }
            mk.push_back(marked);
            q -= cnt[0];
            int id = a.size();
            a.emplace_back(cnt[1] - cnt[0], id);
        }
    }
    for (auto [u, v]: es) {
        u = dsu.find(u);
        v = dsu.find(v);
        if (col[u] == col[v]) {
            std::cout << "NO\n";
            return;
        }
    }
    if (q < 0) {
        std::cout << "NO\n";
    }
    std::bitset<100001> bs;
    bs[0] = 1;
    std::sort(a.begin(), a.end());
    for (auto [i, id]: a) {
        bs |= bs << i;
    }
    if (!bs[q]) {
        std::cout << "NO\n";
    } else {
        std::cout << "YES\n";
        std::vector<int> rev(a.size());
        for (int _ = 0; _ < 10; ++_) {
            std::shuffle(a.begin(), a.end(), std::mt19937(std::random_device()()));
            int now = q;
            for (auto [i, id]: a) {
                if (i <= now) {
                    now -= i;
                    rev[id] = 1;
                }
            }
            if (now) continue;
            for (int i = 0; i < a.size(); ++i) {
                if (rev[i]) {
                    for (int u: mk[i]) {
                        col[u] = !col[u];
                    }
                }
            }
            for (int i = 0; i < n; ++i) {
                if (col[dsu.find(i)] == 0) {
                    std::cout << i + 1 << ' ';
                }
            }
            std::cout << '\n';
            break;
        }

    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int T = 1;
//    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        run(t);
    }
    return 0;
}