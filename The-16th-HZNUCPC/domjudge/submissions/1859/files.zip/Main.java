import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;


public class Main {   //a

	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		while(in.hasNext()){
			int t=in.nextInt();
			for(int i=0;i<t;i++){
				int n=in.nextInt();
				int sz[][]=new int[20][20];
				Queue <bl> qq=new LinkedList<bl>();
				for(int j=0;j<n;j++){
					int a=in.nextInt();
					int b=in.nextInt();
					int c=in.nextInt();
					if(c==2){
						sz[a][b]=2;
					}else{
						bl ww=new bl(a,b);
						qq.add(ww);
						sz[a][b]=1;
					}
				}
				System.out.println(bfs(qq,sz));
			}
		}
	}
public static class bl{
	int a;
	int b;
	public bl(int a,int b){
		this.a=a;
		this.b=b;
	}
}
public static int bfs(Queue<bl> qq,int sz[][]){
	int sum=0;
	int s[]={1,-1,0,0};
	int z[]={0,0,1,-1};
	while(!qq.isEmpty()){
		bl qwe=qq.poll();
		for(int i=0;i<4;i++){
			int nx=qwe.a;
			int ny=qwe.b;
			if(nx+s[i]>=0&&nx+s[i]<=18&&ny+z[i]>=0&&ny+z[i]<=18){
				if(sz[nx+s[i]][ny+z[i]]==0){
					sum+=1;
					sz[nx+s[i]][ny+z[i]]=2;
				}
			}
		}
	}
	return sum;
}
}

//for(int i=0;i<=19;i++){
//	for(int j=0;j<=19;j++){
//		System.out.print(sz[i][j]+" ");
//	}
//	System.out.println();
//}
