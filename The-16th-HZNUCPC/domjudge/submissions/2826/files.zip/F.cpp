
#include<iostream>
#include<cmath>

using namespace std;
int check(long long k){
	if(k==1)return 0;
	if(k==2)return 1;
	for(long long i=2;i<=sqrt(k);i++){
		if(k%i==0)return 0;
	}
	return 1;
}
int minyueshu(long long t){
	for(long long i=2;i<=sqrt(t);i++){
		if(t%i==0)return  i;
	}
	return 1;
}
int main(){
	long long n,m;
	cin>>n>>m;
	if(n<=m){
		cout<<"NO";
		return 0;
	}
	if(check(n)!=0||m==1)cout<<"YES";
	else if(check(n)==0){
		if(minyueshu(n)>n/((n-1)/m+1))cout<<"YES";
		else cout<<"NO";
	}
	return 0;
}