#include<bits/stdc++.h>
using namespace std;
int check(long long k){
	if(k==2)return 1;
	if(k==1)return 0;
	for(long long i=2;i<=sqrt(k);i++){
		if(k%i==0)return 0;
	}
	return 1;
}
int main(){
	long long n,m;
	cin>>n>>m;
	if(n<=m){
		cout<<"NO";
		return 0;
	}
	if(check(n)||m==1)cout<<"YES";
	else cout<<"NO";
	return 0;
}