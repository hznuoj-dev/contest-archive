#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
const int MOD=1e9+7;
#define ll long long 
int main()
{
	int t;
	cin >> t;
	while (t -- )
	{
		string a;
		cin >> a;
		ll ans = 0;
		int n = a.size();
		for (int i = 1;i < n; i ++ )
		{
			ll cnt = 1, cnt1 = 1, k = 0;
			for (int j = 1; j <= min(i, n - i); j ++ )
			if (a[i - j] == a[i + j] && k == 0) {cnt += 2; cnt1 += 2; continue;}
			else if (a[i - j] == a[i + j]) {cnt += 2; continue;}
			else if (k == 0)
			{
				k = j;
				cnt1 = cnt;
				cnt += 2;
			}
			else if (k > 0)
			{
				if ((a[i - j] == a[i + k] && a[i + j] == a[i - k]) || (a[i - j] == a[i - k] && a[i + j] == a[i + k])) 
				{
				cnt += 2, k = -1; continue;	
				}
				else break;
			}
			else break;
			if (k == -1) ans = max(ans, cnt); else ans = max(ans, cnt1);
			cnt = 0, cnt1 = 0, k = -2;
			for (int j = 0; j <= min(i, n - i - 1); j ++ )
			if (a[i - j] == a[i + 1 + j] && k == -2) {cnt += 2; cnt1 += 2;  continue;}
			else if (a[i - j] == a[i + 1 + j]) {cnt += 2; continue;}
			else if (k == -2)
			{
				k = j;
				cnt1 = cnt;
				cnt += 2;//cout << i << " " << j << endl;
			}
			else if (k >= 0)
			{
				if ((a[i - j] == a[i + 1 + k] && a[i + 1 + j] == a[i - k]) || (a[i - j] == a[i - k] && a[i + j + 1] == a[i + 1 + k])) 
				{
					//cout << k << endl;
					//cout << i << " " << j << endl;
				cnt += 2, k = -1; 
				continue;	
				}
				else break;
			}
			else break;
			if (k == -1) ans = max(ans, cnt); else ans = max(ans, cnt1);
			//cout << cnt << endl;
		}
		if (ans == 1) cout << 0 << endl;
		else
		cout << ans << endl;
	}
	return 0;
}