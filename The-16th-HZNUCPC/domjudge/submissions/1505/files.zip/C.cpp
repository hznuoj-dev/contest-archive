#include<bits/stdc++.h>
#define PII pair<int,int>
#define F first
#define S second
#define LL long long
using namespace std;

const int N = 1e5,mod = 1;



int main()
{
	string a,b;
	cin >> a >> b;
	int n = a.size();
	int st = -1,ed = n;
	while(a[st + 1] == b[st + 1] && st < n) st ++;
	while(a[ed - 1] == b[ed - 1] && ed > 0) ed --;
	if (st >= ed) 
	{
		LL ans = n * (n - 1) / 2;
		cout << ans ;
	}
	else 
	{
		LL ans = (st + 2) * (n - ed + 1);
		cout << ans;
	}
	return 0;
}