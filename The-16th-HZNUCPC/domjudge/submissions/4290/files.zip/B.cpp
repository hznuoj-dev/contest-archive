#define _GLIBCXX_DEBUG_ASSERT

#include <bits/stdc++.h>
using namespace std;
using ll = long long;

using pll = pair<ll, ll>;

#define x first
#define y second

inline pll operator+(const pll &l, const pll &r) {
    return {l.x + r.x, l.y + r.y};
}
inline pll operator-(const pll &l, const pll &r) {
    return {l.x - r.x, l.y - r.y};
}
inline ll dot(const pll &l, const pll &r) {
    return l.x * r.x + l.y * r.y;
}

ll dis2(const pll &p) {
    return p.x * p.x + p.y * p.y;
}


template <int B, int P>
struct Ha {
    int n;
    std::vector<int> pw;
    std::vector<int> h;
    Ha(const vector<ll> &v) : n(v.size()), pw(n + 1), h(n + 1) {
        ll x = 0;
        for (int i = 0; i <= n; i++) {
            pw[i] = i == 0 ? 1 : 1ll * pw[i - 1] * B % P;
        }
        for (int i = n - 1; i >= 0; i--) {
            h[i] = (1ll * h[i + 1] * B + v[i]) % P;
        }
    }
    ll calc(int l, int r) const { // [l, r)
        return (ll(P) * P + h[l] - h[r] * ll(pw[r - l])) % P;
    }
    auto get() const {
        std::vector<int> v(n / 2);
        for (int i = 0; i < n / 2; i++) {
            v[i] = calc(i, i + n / 2);
            ////// std::cout << v[i] << " \n"[i == n / 2 - 1];
        }
        return v;
    }
};

constexpr int P1 = 998244353;
constexpr int P2 = 19260817;

int main (){
    cin.tie(0)->sync_with_stdio(0); // 111111
    int T;
    cin >>T;
    std::map<ll, ll> mp;
    while (T--) {
        int n;
        cin >> n;
        std::vector<pll> C(n);
        for (auto &[x, y] : C) {
            cin >> x >> y;
        }
        std::vector<ll> len(n * 2), arg(n * 2);
        ll g1 = 0, g2 = 0;
        for (int i = 0; i < n; ++i) {
            pll ci = C[i];
            pll ci0 = i == 0 ? C.back() : C[i - 1];
            pll ci1 = i == n - 1 ? C.front() : C[i + 1];
            len[i] = dis2(ci1 - ci);
            arg[i] = dot(ci1 - ci, ci0 - ci);
            len[i + n] = len[i];
            arg[i + n] = arg[i];
            g1 = __gcd(len[i], g1);
            g2 = __gcd(arg[i], g2);
        }
        if (g1 != 0) {
            for (int i = 0; i < n; i++) {
                len[i] = len[i + n] = len[i] / g1;
            }
        }
        if (g2 != 0) {
            for (int i = 0; i < n; i++) {
                arg[i] = arg[i + n] = arg[i] / g2;
            }
        }
        ////// for (int i = 0; i < n; i++)
         //////     std::cout << len[i] << " \n"[i == n - 1];
         ////// for (int i = 0; i < n; i++)
         //////     std::cout << arg[i] << " \n"[i == n - 1];
        auto h = [&]() {
            std::vector<ll> h1(n * 2);
            for (int i = 0; i < n * 2; i++) {
                h1[i] = len[i] * 3ll + arg[i];
            }
            auto h2 = h1;
            std::reverse(h2.begin(), h2.end());
            auto v = Ha<131, P1>(h1).get();
            int x11 = *std::min_element(v.begin(), v.end());
            v = Ha<131, P2>(h2).get();
            int x12 = *std::min_element(v.begin(), v.end());

            v = Ha<131, P1>(h1).get();
            int x21 = *std::min_element(v.begin(), v.end());

            v = Ha<131, P2>(h2).get();
            int x22 = *std::min_element(v.begin(), v.end());

            return ll(std::min(x11, x21)) << 32 | std::min(x12, x22);
        };
        ll ch = h();
        //std::cout << ch << '\n';
        std::cout << mp[ch] << '\n';
        mp[ch]++;

    }
}

