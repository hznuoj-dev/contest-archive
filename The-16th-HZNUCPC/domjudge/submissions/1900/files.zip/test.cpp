#include <bits/stdc++.h>

using namespace std;
#define int long long

signed main(){
	int n,k;
	while(cin >> n >> k){
		bool f = true;
		while(1)
		{
			if(k == 1) break;
			if((n % k) == 0){
				f = false;
				break;
			}
			k = n % k;
			cout << "N: " << n << "K: " << k << endl;
		}
		if(f) cout << "YES\n";
		else cout << "NO\n";
	}
	return 0;
}