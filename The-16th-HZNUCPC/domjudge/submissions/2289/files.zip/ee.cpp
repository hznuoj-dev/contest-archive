#include<bits/stdc++.h>
using namespace std;

void solve(){
    long long n,max=0;
    long long x[110],y[110],a[110][110];
    double k;
    cin>>n;
    for(int i=1;i<=n;i++)cin>>x[i]>>y[i];
    for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++){
			long long xx=abs(x[i]-x[j]),yy=abs(y[i]-y[j]);
			a[i][j]=__gcd(xx,yy)-1;
			a[j][i]=__gcd(xx,yy)-1;
		}
	int flag=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int z=j+1;z<=n;z++){
				if((x[j]-x[i])*(y[z]-y[j])!=(y[j]-y[i])*(x[z]-x[j])){
					long long ans=a[i][j]+a[i][z]+a[j][z];
					if(ans>max)max=ans;
					flag=1;
				}
//				if((x[j]-x[i])*(y[z]-y[j])!=(y[j]-y[i])*(x[z]-x[j])){
//					int ans;
//					ans=a[i][j]+a[i][z]+a[j][z];
//					if(ans>max)max=ans;
//					flag=1;
//		 		}
			}
		}
	}
	if(flag)cout<<max+3<<endl;
	else cout<<0<<endl;
}

int main(){
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
}
