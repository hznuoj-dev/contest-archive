#include<bits/stdc++.h>
using namespace std;

void solve(){
	long long n, m;
	cin >> n >> m;
	while(n % m){
		if(n % m == 1){
			cout << "YES\n";
			return ;
		}
		m = n % m;
	}
	cout << "NO\n";
}
int main(){
	int t = 1;
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}