#include<stdio.h>

int main()
{
	long long n=0,m=0;
	scanf("%lld %lld",&n,&m);
	while(m>1)
	{
		if(n%m==0)
			break;
		m=n%m;
	}
	if(m==1)
		printf("YES\n");
	else
		printf("NO\n");
}