#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod =1e9+7; 
const char c[26]={'a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'};
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    unordered_map<char,int> jkl1,jkl2;
    string a,b;
    int ans=0;
    cin>>a>>b;
    int n=a.size();
    for(int i=0;i<n;i++)
    {
        jkl1[a[i]]++;
        jkl2[b[i]]++;
    }
    for(int i=0;i<n;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            jkl1[a[i]]--,jkl2[a[i]]++;
            jkl2[b[i]]--,jkl1[b[i]]++;
            jkl1[a[j]]--,jkl2[a[j]]++;
            jkl2[b[j]]--,jkl1[b[j]]++;

            for(int k=0;k<26;k++)
            {
                if(jkl1[c[k]]!=0 && jkl1[c[k]]==jkl2[c[k]])
                {
                    ans=(ans+1)%mod;
                    break;
                }
            }
            jkl1[a[i]]++,jkl2[a[i]]--;
            jkl2[b[i]]++,jkl1[b[i]]--;
            jkl1[a[j]]++,jkl2[a[j]]--;
            jkl2[b[j]]++,jkl1[b[j]]--;

        }
    }
    cout<<ans<<endl;
    return 0;
}