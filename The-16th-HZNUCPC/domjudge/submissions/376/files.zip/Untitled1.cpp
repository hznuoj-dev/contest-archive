#include<bits/stdc++.h>
using namespace std;
//#define int long long 
typedef long long ll;
const int N = 2e5+7;
ll n,m;

void solve(){
	cin>>n>>m;
	if(m==1){
		cout<<"YES\n";
		return;
	}
	ll maxn=sqrtl(n);
	for(int i=1;i<=maxn;i++){
		if(n%i==0&&i>=2&&i<=m){
			cout<<"NO\n";
			return;
		}else if(n%i==0&&n/i>=2&&n/i<=m){
			cout<<"NO\n";
			return;
		}
	}
	cout<<"YES\n";
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	int t = 1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}