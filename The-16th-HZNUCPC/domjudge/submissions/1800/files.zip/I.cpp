#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int>pii;

void kaibai(){
	string s;
	cin >> s;
	int n = s.size(), ans = 0;
	for(int i = 0; i < n; i++){
		int l = i - 1, r = i + 1;// odd
		int c1 = -1, c2 = -1;
		while(l >= 0 && r < n){
			if(s[l] == s[r]){
				l--;r++;
			}else{
				if(c1 == -1){
					c1 = i - l;
					l--;r++;
				}else if(c2 == -1){
					if(s[l] == s[i + c1] && s[i - c1] == s[r]){
						l--;r++;
						c2 = 114514;
					}else if(s[l] == s[i - c1] && s[i + c1] == s[r]){
						l--;r++;
						c2 = 114514;
					}else{
						break;
					}
				}else{
					ans = max(ans, r - l - 1);
					break;
				}
			}
		}
		if(c2 != -1){
			ans = max(ans, r - l - 1);
		}
		if(c1 != -1){
			if(s[i - c1] == s[i] || s[i + c1] == s[i]){
				ans = max(ans, r - l - 1);
			}else{
				ans = max(ans, c1 * 2 - 1);
			}
		}else{
			ans = max(ans, r - l - 1);
		}
		
		
		
		l = i - 1, r = i;// even
		c1 = -1, c2 = -1;
		while(l >= 0 && r < n){
			if(s[l] == s[r]){
				l--;r++;
			}else{
				if(c1 == -1){
					c1 = i - l;
					l--;r++;
				}else if(c2 == -1){
					if(s[l] == s[i + c1 - 1] && s[i - c1] == s[r]){
						l--;r++;
						c2 = 114514;
					}else if(s[l] == s[i - c1] && s[i + c1 - 1] == s[r]){
						l--;r++;
						c2 = 114514;
					}else{
						break;
					}
				}else{
					ans = max(ans, r - l - 1);
					break;
				}
			}
		}
		if(c2 != -1){
			ans = max(ans, r - l - 1);
		}
		if(c1 != -1){
			ans = max(ans, c1 * 2 - 1);
		}else{
			ans = max(ans, r - l - 1);
		}
	}	
	if(ans == 1) ans = 0;
	cout << ans << '\n';
}

/*
4
abccab
ihi
stfgfiut
palindrome
*/

int main(void){
	int T=1;
	ios::sync_with_stdio(false);
	cin >> T;
	while(T--){
		kaibai();
	}
}