#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int N = 105;
//int a[N][N];
int x[N],y[N];

void solve() {
	int n;
	cin >> n;
	for(int i = 1; i <= n; i++){
		cin >> x[i] >> y[i];
	}
	int ans = 3;
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			for(int k = 1; k <= n; k++){
				if (i == j || i == k || j == k){
					continue;
				}
				int num = 0;
				num += (__gcd(abs(x[i] - x[j]),abs(y[i] - y[j])));
				num += (__gcd(abs(x[i] - x[k]),abs(y[i] - y[k])));
				num += (__gcd(abs(x[k] - x[j]),abs(y[k] - y[j])));
				ans = max(ans,num);
			}
		}
	}
	cout << ans << endl;
}
signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int Case = 1;
//	cin >> Case;
	while (Case -- ) {
		solve();
	}
	return 0;
}