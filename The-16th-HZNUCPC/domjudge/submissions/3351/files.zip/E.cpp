#include<bits/stdc++.h>
using namespace std;
struct dian{
	int x,y;
}a[110];
struct pass{
	int x1,y1,x2,y2,num;
}b[11000];
bool cmp(pass p1,pass p2){
	return p1.num<p2.num;
}
signed main()
{
	int n,k=0;
	cin>>n;
	for(int t=1;t<=n;t++){
		cin>>a[t].x>>a[t].y;
	}
	for(int t1=1;t1<=n;t1++){
		for(int t2=t1+1;t2<=n;t2++){
			k++;
			b[k].num=0;
			b[k].x1=a[t1].x;
			b[k].y1=a[t1].y;
			b[k].x2=a[t2].x;
			b[k].y2=a[t2].y;
			if(b[k].x1!=b[k].x2 && b[k].y1!=b[k].y2){
				if((a[t2].y-a[t1].y)%(a[t2].x-a[t1].x)==0){
					b[k].num=(a[t2].y-a[t1].y)/(a[t2].x-a[t1].x)+1;
				}else{
					b[k].num=2;
				}
			}else{
				if(b[k].x1==b[k].x2){
					b[k].num=abs(b[k].y2-b[k].y1)+1;
				}else if(b[k].y1==b[k].y2){
					b[k].num=abs(b[k].x2-b[k].x1)+1;
				}
			}
			
			
		}
	}
	sort(b+1,b+k+1,cmp);
	
	return 0;
}
