#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>

using namespace std;

typedef long long LL;

vector<int> s;

int main()
{
	LL n, m;
	cin >> n >> m;
	
	
	LL a = n , b = m;
	for(LL i = 2; i * i <= n; i++)
	{
		if(n % i == 0)
		{
			a = i;
			break;
		} 
	}
	

	
	if(m == 1) cout << "YES" << endl;
	else if(n <= m) cout << "NO" << endl; 
	else if(a <= b) cout << "NO" << endl;
	else cout << "YES" << endl;
	
	return 0;
}
