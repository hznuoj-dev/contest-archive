#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
inline void run(){
   cin >> n >>m;
   if(n==1||m==1) cout<<"YES"<<'\n';
   else if(n<=m) cout<<"NO"<<'\n';
   else
   {
   		ll k=n%m;
		while(k>1)	k=n%k;
		if(k==1) cout<<"YES"<<'\n';
		else cout<<"NO"<<'\n';
   }
}
int main()
{
	run();
}
