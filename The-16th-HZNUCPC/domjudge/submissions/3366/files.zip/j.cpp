#include<bits/stdc++.h>
using namespace std;
int x[100000];
int main(){
	int n,m;
	cin>>n>>m;
	int k=1;
	for(int i=1;i<=m;i++){
		int a,b,c;
		cin>>a>>b>>c;
		x[k]=c;
		k++;
	}
	sort(x+1,x+k);
	for(int i=1;i<=k-1;i++){
		
		if(x[i+1]-x[i]>1){
			cout<<x[i]+1<<endl;
			break;
		}
	}
}