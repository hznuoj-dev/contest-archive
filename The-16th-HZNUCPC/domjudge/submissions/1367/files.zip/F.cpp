#include<bits/stdc++.h>
using namespace std;
#define int long long 
int n,m,k;
pair<int,int>s[2005];
int dir[4][2]={1,0,0,1,-1,0,0,-1};

void solve(){
	while(cin>>n>>m){
		int f=0;
		if(m-n==1){
			cout<<"YES"<<endl;
			continue;
		}
		if(n<=m){
			cout<<"NO"<<endl;
		}else{
			for(int i=2;i<=sqrt(n);i++){
				if(n%i==0){
					if(i<=m||n/i<=m){
						f=1;
						break;
					}
				}
			}
			if(f==1){
				cout<<"NO"<<endl;
			}else{
				cout<<"YES"<<endl;
			}
		}
		
	}
}
signed main(){
	solve();
	return 0;
}