#include <iostream>
#include <algorithm>
#include <stack>
#include <map>
#include <cstring> 
#define qcin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define endl '\n'
#define int long long
using namespace std;


signed main(){
	int n,m;
	cin>>n>>m;
	if(n%m == 0)	cout<<"NO";
	else	cout<<"YES";


	return 0;
}