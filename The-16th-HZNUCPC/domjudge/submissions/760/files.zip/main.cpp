#include<bits/stdc++.h>
#define ft first
#define sd second
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
#define rep(i,a,b) for(ll i=a;i<=b;++i)
using namespace std;
ll t,n,m,k,tt,tp,sum,ans,res,cnt;
const ll N=1e6+5;
ll a[N],b[N],c[N];
ll ck(ll i,ll j,ll k)
{
    if((b[j]-b[i])*(a[k]-a[j])==(a[j]-a[i])*(b[k]-b[j]))return 0;
   // cout<<i<<" "<<j<<" "<<k<<"\n";
    ll res=0;
    ll x1=a[i],x2=a[j],y1=b[i],y2=b[j];
    ll kk=__gcd(abs(x1-x2),abs(y1-y2));
   // cout<<kk<<" ";
    res+=kk;

    x1=a[i],x2=a[k],y1=b[i],y2=b[k];
    kk=__gcd(abs(x1-x2),abs(y1-y2));
    res+=kk;
    //cout<<kk<<" ";

    x1=a[j],x2=a[k],y1=b[j],y2=b[k];
    kk=__gcd(abs(x1-x2),abs(y1-y2));
    res+=kk;
    //cout<<kk<<"\n";

    return res;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    //IO
    cin>>n;
    rep(i,1,n)cin>>a[i]>>b[i];
    ans=0;
    rep(i,1,n)rep(j,i+1,n)rep(k,j+1,n)ans=max(ans,ck(i,j,k));
    cout<<ans<<"\n";
}
