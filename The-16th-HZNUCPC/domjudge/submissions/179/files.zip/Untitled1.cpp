#include<bits/stdc++.h>
using namespace std;
int T,ans,fx[4]={0,0,1,-1},fy[4]={1,-1,0,0},col[21][21],vis[21][21],n;
struct node {
	int x,y,c;
}p[365];
void init(){
	ans=0;
	for (int i=1;i<=19;++i) for (int j=1;j<=19;++j) vis[i][j]=col[i][j]=0;
}
int check(int x,int y) {
	//cout << "col[" << x << "][" << y << "]=" << col[x][y] << endl;
	return col[x][y];
}
void dfs(int x,int y) {
	//cout << "x=" << x << ",y=" << y << endl;
	//cnt++;
	vis[x][y]=1;
	for (int i=0;i<4;++i) {
		int xx=x+fx[i],yy=y+fy[i];
		if (check(xx,yy)==0&&vis[xx][yy]==0) {
			ans++;
		}
		if (check(xx,yy)==1&&vis[xx][yy]==0) {
			dfs(xx,yy);
		}
	}
}
signed main(){
	cin >> T;
	for (int i=0;i<=20;++i) col[i][0]=col[i][20]=col[0][i]=col[20][i]=2;
	while (T--) {
		cin >> n;
		init();
		for (int i=1;i<=n;++i) {
			cin >> p[i].x >> p[i].y >> p[i].c;
			col[p[i].x][p[i].y]=p[i].c;
		}
		for (int i=1;i<=n;++i) {
			if (p[i].c==1&&!vis[p[i].x][p[i].y]) {
				dfs(p[i].x,p[i].y);
			}
		}
		cout << ans << endl;
	}
}