#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int n;
int G[23][23];

int dx[]={0,0,1,-1};
int dy[]={1,-1,0,0};

bool check(int x,int y) {
	if(x>=1&&y>=1&&x<=19&&y<=19) return true;
	else return false;
}

void solve() {
	cin>>n;
	for(int i = 1; i <= 19; i++){
		for(int j = 1; j <= 19; j++){
			G[i][j] = 0;
		}
	}
	for(int i=1;i<=n;i++) {
		int x,y,c;
		cin>>x>>y>>c;
		G[x][y]=c;
	}
	int ans=0;
	for(int i=1;i<=19;i++) {
		for(int j=1;j<=19;j++) {
			if(G[i][j]==1) {
				for(int k=0;k<4;k++) {
					int nx=i+dx[k];
					int ny=j+dy[k];
					if(check(nx,ny)) {
						//if(G[nx][ny]==1) {
						if(G[nx][ny]==1||G[nx][ny]==2) {
							continue;
						}
						ans++;
					}
				}
			}
		}
	}
	cout<<ans<<endl;
}

int main() {
	ios::sync_with_stdio(false);
	
	int t;
	cin>>t;
	while(t--) {
		solve();
	}
}