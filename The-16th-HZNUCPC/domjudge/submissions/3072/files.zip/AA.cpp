#include<bits/stdc++.h>
using namespace std;
int main(){
int c[20][20]={{5},0};
int t,x,y,z,n;
scanf("%d",&t);
while(t--){
	int count=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
	scanf("%d %d %d",&x,&y,&z);
	if(z==1)
	c[x+1][y+1]=1;
	else
	c[x+1][y+1]=2;
	}
	for(int i=1;i<20;i++){
		for(int j=1;j<20;j++){
			if(c[i][j]==1){
				if(c[i+1][j]==0)c[i+1][j]=5,count++;
				if(c[i-1][j]==0)c[i-1][j]=5,count++;
				if(c[i][j+1]==0)c[i][j+1]=5,count++;
				if(c[i][j-1]==0)c[i][j-1]=5,count++;
			}
		}
	}
	printf("%d\n",count);
}
}
