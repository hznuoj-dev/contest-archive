#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod=1e9+7;
int q[100005];
void solve(){
//	cout<<256*1024*1024/2<<endl;
	string s,ss;
	cin>>s>>ss;
	int len=s.length();
//	if(len==1){
//		cout<<1<<endl;
//		return ;
//	}
	int cnt=0;
	int sum=0;
	int ans1=0;
	int sum1=INT_MAX,sum2=INT_MAX;
	int l=-1;
	for(int i=0;i<len;i++){
		if(s[i]!=ss[i]){
			sum1=min(sum1,i);
			sum2=min(sum2,len-i-1);
			if(l==-1){
				l=i+1;
			}else{
				ans1+=(i-l)*(i-l-1)/2;
				ans1%=mod;
			}
		}
	}
	if(sum1==INT_MAX){
		int ans1=len*(len-1)/2%mod;
		cout<<ans1<<endl;
	}else{
		ans1+=sum1+sum2+sum1*sum2;
		ans1%=mod;
		if(len-sum1-sum2>1){
			ans1++;
		}
		ans1%=mod;
		if(sum1>0){
			ans1+=sum1*(sum1-1)/2%mod;
			ans1%=mod;
		}
		if(sum2>0){
			ans1+=sum2*(sum2-1)/2%mod;
			ans1%=mod;
		}
		cout<<ans1<<endl;
	}
	
}
signed main(){
	
	solve();
	
	
	return 0;
}