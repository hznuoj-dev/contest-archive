#include<bits/stdc++.h>
using namespace std;
const int N = 2e5 + 100;
int n,m,q;
int fa[N],sz[N];
int found(int x)
{
	if(x == fa[x])return x;
	else return fa[x] = found(fa[x]);
}
void unity(int x,int y)
{
//	cout <<' '<< x << ' ' << y << '\n';
	x = found(x);
	y = found(y);
	if(x == y)return;
	if(sz[x] > sz[y])swap(x,y);//y da
	fa[x] = y;
	sz[y] += sz[x];
}
int hao(int x)
{
	return x * 2 - 1;
}
int huai(int x)
{
	return x * 2;
}
int getyuan(int x)
{
	if(x & 1)return x / 2 + 1;
	else return x / 2;
}
int vis[N];
struct A{
	int a,b;
	int id;
}t[N];
//int a[N],b[N];
vector<int> belong[N];
int dp[N],tmp[2][N];
pair<int,int> qian[N],tmpqian[2][N];
int pre[N],suf[N];
signed main()
{
	scanf("%d%d%d",&n,&q,&m);
	for(int i = 1; i <= 2 * n; ++i){
		fa[i] = i;
		sz[i] = 1;
	}
	for(int i = 1; i <= m; ++i){
		int k,a,b;
		scanf("%d%d%d",&k,&a,&b);
		if(k == 0){
			unity(hao(a),hao(b));
			unity(huai(a),huai(b));
		}else{
			unity(huai(a),hao(b));
			unity(hao(a),huai(b));
		}
	}
	
	int cnt = 0;
	for(int i = 1; i <= n; ++i){
		if(found(hao(i)) == found(huai(i))){
//			cout <<"!\n";
			printf("NO\n");
			return 0;
		}
	}
	for(int i = 1; i <= 2 * n; ++i){
//		cout << found(i) << ' ' << i << '\n';
		belong[found(i)].push_back(i);
	}
	for(int i = 1; i <= 2 * n; ++i){
		if(belong[i].empty())continue;
		int haocnt = 0,huaicnt = 0;
		if(vis[getyuan(belong[i].back())])continue;
		for(auto & x : belong[i]){
//			cout << x << ' ';
			if(x & 1)haocnt++;
			else huaicnt++;
			vis[getyuan(x)] = 1;
		}
//		cout<<'\n';
		t[++cnt].a = haocnt;
		t[cnt].b = huaicnt;
		if(t[cnt].a < t[cnt].b)swap(t[cnt].a,t[cnt].b);
		t[cnt].id = i;
	}
	sort(t + 1,t + cnt + 1,[](A &x,A &y){
		return x.a + x.b < y.a + y.b;
	});
	for(int i = 1; i <= cnt; ++i){
		pre[i] = pre[i - 1] + max(t[i].a,t[i].b);
	}
	for(int i = cnt; i >= 1; --i){
		suf[i] = suf[i + 1] + max(t[i].a,t[i].b);
	}
//	cout << cnt << "cnt\n";
//	cout << t[1].a << ' ' <<t[1].b << '\n';
//	for(int i = 1; i <= cnt; ++i){
//		cout << t[i].a << ' ' << t[i].b << '\n';
//	}
	dp[0] = 1;
	for(int i = 1; i <= cnt; ++i){
		for(int j = q; j >= 0; --j){
			if(j >= t[i].a)if(dp[j - t[i].a] &&!dp[j])dp[j]=1,qian[j]={j-t[i].a,i};
			if(j >= t[i].b)if(dp[j-t[i].b]&&!dp[j])dp[j]=1,qian[j]={j-t[i].b,i};
		}
//		int l = max(q - suf[i + 1],0),r = min(pre[i],q);
//		for(int j = q; j >= 0; --j){
//			if(j - t[i].a >= 0 && dp[j - t[i].a])tmp[0][j] = 1,tmpqian[0][j] = {j - t[i].a,i};
//			else tmp[0][j] = 0;
//			if(j - t[i].b >= 0 && dp[j - t[i].b])tmp[1][j] = 1,tmpqian[1][j] = {j - t[i].b,i};
//			else tmp[1][j] = 0;
//		}
//		for(int j = q; j >= 0; --j){
//			if(tmp[0][j]){
//				dp[j] = 1;
//				qian[j] = tmpqian[0][j];
//			}else if(tmp[1][j]){
//				dp[j] = 1;
//				qian[j] = tmpqian[1][j];
//			}
//		}
	}
	if(dp[q]){
		cout <<"YES\n";
		int k = q;
		vector<int> ans;
		while(k){
			int haocnt = 0,huaicnt = 0;
			int id = t[qian[k].second].id;
			for(auto & x : belong[id]){
//				cout << x << ' ';
				if(x & 1)haocnt++;
				else huaicnt++;
			}
//			cout <<"!\n";
			if(haocnt == k - qian[k].first){
				for(auto & x : belong[id]){
					if(x & 1)ans.push_back(getyuan(x));
				}
			}else{
				for(auto & x : belong[id]){
					if(x & 1);
					else ans.push_back(getyuan(x));
				}
			}
			k = qian[k].first;
		}
		sort(ans.begin(),ans.end());
		for(auto & x : ans){
			printf("%d ",x);
		}
		printf("\n");
	}else{
		cout << "NO\n";
	}
	return 0;
}
/*
4 2 4
1 1 3
1 2 4
0 3 4
0 1 2

13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13
*/