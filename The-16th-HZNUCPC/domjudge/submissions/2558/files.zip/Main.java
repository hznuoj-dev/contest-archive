import java.util.Scanner;


public class Main {    
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			long n=in.nextLong();
			long m=in.nextLong();
			boolean t=false;
				while(n>m){
					if(m==1){
						break;
					}
					
					if(n%m==0){
						t=true;
						break;
					}
					m=n%m;
					
				}
				if(t==true){
					System.out.println("NO");
				}
				if(t==false){
					System.out.println("YES");
				}
		}
	}
}
