#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mode = 1e9 + 7;
const ll N = 1e6 + 7;
ll t, n, a[N],m;
void solve(){
	
return;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
//    cin>>t;
//    while(t != 0){
//    	t--;
//    	solve();
//	}
	cin>>n>>m;
//	for(int i = 1; i <= n; i++){
//		cin>>a[i];
//	}
	if(m==1||n&1==1){
		cout<<"YES";
	}else{
		cout<<"NO";
	}
return 0;
}