#include<bits/stdc++.h>

using namespace std;
#define int long long


signed main(){
	ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
	int T;
	cin >> T;
	while (T--)
	{
		string s;
		cin >> s;
		s="?"+s;
		int len=s.size();
		s=s+"!";
		int ans=0;
		for (int i=1; i<=len; i++)
		{
			vector <pair<int,int>> v;
			int cnt=0;
			int j,l,flag=0;
			for (j=i-1,l=1; j>=1&&i+l<len; j--,l++)
			{
				//if (i==5)
				// cout << j << " " << l << " " << ans << " \n";
				if (s[j]!=s[i+l]) 
				{
					cnt++;
					v.push_back({j,i+l});
					if (cnt==1)
					{
						
						int l1=v[0].first;
						int r1=v[0].second;
						if (s[l1]==s[i] || s[r1]==s[i]) flag=1;
					}
					if (cnt==2)
					{
						int l1=v[0].first;
						int r1=v[0].second;
						int l2=v[1].first;
						int r2=v[1].second;
						if (s[l2]==s[r1] && s[l1]==s[r2]) 
						{
							ans=max(ans,l*2+1);
						}
						else break;
					}
					if (cnt==3) ans=max(ans,(l-1)*2+1);
				}
				if (cnt==0) ans=max(ans,l*2+1);
				if (cnt==1 && flag) ans=max(ans,l*2+1);
			}
		}
				
		for (int i=1; i<=len; i++)
		{
			vector <pair<int,int>> v;
			int cnt=0;
			int j,l;
			for (j=i,l=1; j>=1&&i+l<len; j--,l++)
			{
				if (s[j]!=s[i+l]) 
				{
					cnt++;
					v.push_back({j,i+l});
					if (cnt==2)
					{
						int l1=v[0].first;
						int r1=v[0].second;
						int l2=v[1].first;
						int r2=v[1].second;
						if (s[l2]==s[r1] && s[l1]==s[r2]) 
						{
							ans=max(ans,l*2);
						}
						else break;
					}
					if (cnt==3) ans=max(ans,(l-1)*2);
				}
				if (cnt==0) ans=max(ans,l*2);
			}
		}
		if (ans==1) ans=0;		
		cout << ans << "\n";
	}
}