#include <bits/stdc++.h>
using namespace std;

// #define DEBUG

long long n;
long long x[110], y[110];
long long ans;

long long gcd(long long x, long long y) {
	while (x ^= y ^= x ^= y %= x);
	return y;
}

long long calc(long long i, long long j) {
	long long tx = abs(x[i] - x[j]), ty = abs(y[i] - y[j]);
	long long d = __gcd(tx, ty);
	return d;
}

bool check(long long i, long long j, long long k) {
	long long x1=x[i]-x[j],x2=x[i]-x[k];
	long long y1=y[i]-y[j],y2=y[i]-y[k];
	if(x1*y2-x2*y1==0) return 1;
	else return 0;
}

int main() {
	scanf("%lld", &n);
	for (long long i = 1; i <= n; i++) {
		scanf("%lld %lld", x + i, y + i);
	}
	for (long long i = 1; i <= n; i++) {
		for (long long j = 1; j < i; j++) {
			for (long long k = 1; k < j; k++) {
				if (check(i, j, k)) continue;
				ans = max(ans, calc(i, j) + calc(j, k) + calc(i, k));	
			}
		}
	}
	printf("%lld\n", ans);
    return 0;
}