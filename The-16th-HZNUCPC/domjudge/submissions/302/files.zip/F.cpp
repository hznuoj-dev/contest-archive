#include<iostream>
using namespace std;
int main()
{
	int n,m;
	cin>>n>>m;
	if(((n%m==0) || (m!=1 && n%2==0)) && (n!=1))
	{
		cout<<"NO"<<endl;
	}
	else
	{
		cout<<"YES"<<endl;
	}
	return 0;
}