#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll x[105], y[105];
bool vis[105][105];
bool check(int a, int b, int c){
	if(x[a] == x[b] && x[a] == x[c]){
		return false;
	}
	if(y[a] == y[b] && y[a] == y[c]){
		return false;
	}
	if((y[a] - y[b]) * (x[a] - x[c]) == (y[a] - y[c]) * (x[a] - x[b])){
		return false;
	}
	return true;
}
bool isl(int a, int b, int c, int d){
	if((y[a] - y[b]) * (x[c] - x[d]) == (y[c] - y[d]) * (x[a] - x[b])){
		if(x[a] > x[c] && x[a] < x[d]){
			return true;
		}
		if(x[b] > x[c] && x[b] < x[d]){
			return true;
		}
		return false;
	}else{
		return false;
	}
}
int n;
bool bo(int a, int b){
	if(vis[a][b]){
		return false;	
	}else{
		bool f = 0;
		for(int i = 0; i < n; i++){
			for(int j = i + 1; j < n; j++){
				if(isl(a, b, i, j)){
					f = 1;
					break;
				}
			}
			if(f){
				break;
			}
		}
		if(!f){
			return true;
		}
		return false;
	}
}
int main(){
	cin >> n;
	for(int i = 0; i < n; i++){
		cin >> x[i] >> y[i];
	}
	int sum = 0;
	for(int i = 0; i < n; i++){
		for(int j = i + 1; j < n; j ++){
			for(int l = j + 1; l < n; l++){
				if(check(i, j, l)){
					if(bo(i, j)){
						sum++;
						vis[i][j] = vis[j][i] = 1;
					}else{
						vis[i][j] = vis[j][i] = 1;
					}
					if(bo(l, j)){
						sum++;
						vis[l][j] = vis[j][l] = 1;
					}else{
						vis[l][j] = vis[j][l] = 1;
					}
					if(bo(l, i)){
						sum++;
						vis[l][i] = vis[i][l] = 1;
					}else{
						vis[l][i] = vis[i][l] = 1;
					}
				}
			}
		}
	}
	cout << sum << endl;
	return 0;
}