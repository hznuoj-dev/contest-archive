#include <bits/stdc++.h>

using namespace std;

using i64 = int64_t;

template <typename T> void read(T& x) {
	x = 0; 
	char ch = 0;
	int f = 1;
	for (; !isdigit(ch); ch = getchar()) {
		if (ch == '-') f = -1;
	}
	for (; isdigit(ch); ch = getchar()) {
		x = x * 10 + (ch & 15);
	}
	x *= f;
}
	
template <typename T>
void write(T x) {
	if (x < 0) {
		x = -x;
		putchar('-');
	}
	if (x > 9) {
		write(x / 10);
	}
	putchar(x % 10 + '0');
}

void solve();

int main() {
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
}

const int N = 2e5 + 5;

i64 n, m;

void solve() {
	cin >> n >> m;
	while (n % m != 0) {
		m = n % m;
	}
	if (m != 1) {
		cout << "NO\n";
	} else {
		cout << "YES\n";
	}
}