#include <bits/stdc++.h>
using namespace std;

bool judge(long long x){
	for(long long i = 2; i * i <= x; ++i){
		if(x % i == 0)return false;
	}
	return true;
}

int main(){
	long long n, m;
	cin >> n >> m;
	if(n <= m){
		printf("NO\n");
	} else {
		if(judge(n))printf("YES\n");
		else printf("NO\n");
	}
	
}