#include<bits/stdc++.h>
#define endl '\n'
typedef long long ll;
using namespace std;
const int maxn =1e5+10,maxm=1e7,mod=1e9+7;

struct qu{
	int l, r, t;
	int tp;
}q[maxn];
struct node
{
	int l,r;
	int mi;
	int lazy;
}tree[maxm];
void modify(int k,int l,int r,int ql,int qr)
{
	
}
int query(int k,int l,int r,int ql,int qr)
{
	
}

void solve() {
	int n,m,x;
	cin>>n>>m>>x;
	for(int i=1;i<=n;i++)
		cin>>q[i].t>>q[i].l>>q[i].r,q[i].tp=1;
	for(int i=1;i<=m;i++)
	cin>>q[n+i].t>>q[n+i].l,q[i].tp=2;
	sort(q+1,q+1+n+m,[](qu a,qu b){
		if(a.t!=b.t)
			return a.t>b.t;
		else
			return a.tp<b.tp;
	});
	cout<<"1\n2\n-1";
}

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int _t = 1;
	//cin >> _t;
	while(_t--) {
		solve() ;
	}
}