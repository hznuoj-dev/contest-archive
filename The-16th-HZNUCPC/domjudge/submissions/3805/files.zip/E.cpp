#include<bits/stdc++.h>


#define int long long
#define endl '\n'
using namespace std;


struct num {
	int x,y;
};

const int mod=1e9+7;
int n,x,y;

int dx[]= {-1,1,0,0};
int dy[]= {0,0,-1,1};
int inf=1e18;
int a1[30];
int a2[30];
int a3=0;
int b[10000];

void slove() {
	
	
	string s1,s2;
	cin>>s1>>s2;
	int m=s1.size();
	
	for(auto i:s1)
		a1[i-'a'+1]++;
	for(auto i:s2)
		a2[i-'a'+1]++;
	
	int ans=0;
	for(int i=0;i<s1.size();i++)
	{
		int x=s1[i]-'a'+1;
		int y=s2[i]-'a'+1;
		b[x*100+y]++;
	}
//	cout<<a1[1]<<' '<<a2[1]<<endl;
	
	for(int i=101;i<=2626;i++)
	{
		if(i%100>=27)i-=26,i+=100;
		int x=b[i];
		if(x==0)continue;
		if(i%100==i/100)
		{
			int res=0,res2=0;
			for(int u=1;u<=26;u++)
			{
				if(a1[u])res++;
				if(a2[u])res2++;
			}
			if(res==res2)
				ans=(ans+x*(x-1)/2%mod)%mod;
//			cout<<"--"<<ans<<endl;
		}
			
		for(int j=i+1;j<=2626;j++)
		{
			
			if(j%100>=27)j-=26,j+=100;
			if(b[j]==0)continue;
			int x1=i/100,x2=i%100;
			int x3=j/100,x4=j%100;
			a1[x1]--;a2[x2]--;
			a1[x2]++;a2[x1]++;
			a1[x3]--;a2[x4]--;
			a1[x4]++;a2[x3]++;

			int res=0,res2=0;
			for(int u=1;u<=26;u++)
			{
				if(a1[u])res++;
				if(a2[u])res2++;
			}
			if(res==res2)
				ans=(ans+b[i]*b[j]%mod)%mod;
				
			a1[x2]--;a2[x1]--;
			a1[x1]++;a2[x2]++;
			a1[x4]--;a2[x3]--;
			a1[x3]++;a2[x4]++;
		}
	}		
	
	cout<<ans%mod<<endl;

}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	int t=1;
//	cin>>t;

	while(t--) {
		slove();
	}
}