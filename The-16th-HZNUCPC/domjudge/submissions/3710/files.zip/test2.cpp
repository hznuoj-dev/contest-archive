#include <bits/stdc++.h>
#define int long long
using namespace std;
struct node{
	int c, d;
}s[105];
bool check(node x, node y, node z){
	int x1 = x.c;
	int y1 = x.d;
	int x2 = y.c;
	int y2 = y.d;
	int x3 = z.c;
	int y3 = z.d;
	//double si1 = sqrt((double)(x2 - x1) * (x2 - x1) - (double)(y2 - y1) * (y2 - y1));
	//double si2 = sqrt((double)(x3 - x1) * (x3 - x1) - (double)(y3 - y1) * (y3 - y1));
	//double si3 = sqrt((double)(x3 - x2) * (x3 - x2) - (double)(y2 - y3) * (y2 - y3));
	//if(si1 + si2 <= si3) return false;
	//if(si1 + si3 <= si2) return false;
	//if(si2 + si3 <= si1) return false;
	if((y2 - y1) * (x3 - x1) == (y3 - y1) * (x2 - x1)) return false;
	return true;
}
int ca(node x, node y, node z){
	int x1 = x.c;
	int y1 = x.d;
	int x2 = y.c;
	int y2 = y.d;
	int x3 = z.c;
	int y3 = z.d;
	int ans1 = __gcd(abs(x1 - x2), abs(y1 - y2));
	int ans2 = __gcd(abs(x2 - x3), abs(y2 - y3));
	int ans3 = __gcd(abs(x3 - x1), abs(y3 - y1));
	if(x1 - x2 == 0) ans1 = abs(y1 - y2);
	if(y1 - y2 == 0) ans1 = abs(x1 - x2);
	if(x2 - x3 == 0) ans2 = abs(y2 - y3);
	if(y2 - y3 == 0) ans2 = abs(x2 - x3);
	if(x3 - x1 == 0) ans3 = abs(y3 - y1);
	if(y3 - y1 == 0) ans3 = abs(x3 - x1);
	//cout << ans1 << " " << ans2 << ans3 << endl;
	return ans1 + ans2 + ans3;
}
signed main(){
	int n;
	cin >> n;
	int ma = 0;
	for(int i = 0 ;i < n;i ++) cin >> s[i].c >> s[i].d;
	for(int i = 0; i < n - 2; i++){
		for(int j = i + 1; j < n - 1; j++){
			for(int k = i + 2; k < n; k++){
				if(!check(s[i], s[j], s[k])) continue;
				//cout << check(s[i], s[j], s[k]) << endl;
				int tmp = ca(s[i], s[j], s[k]);
				if(tmp > ma) ma = tmp;
			}
		}
	}
	cout << ma;
}
