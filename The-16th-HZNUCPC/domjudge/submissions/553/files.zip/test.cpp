#include <bits/stdc++.h>

using namespace std;
#define int long long
const int N = 25;
int vis[N][N];
int dir[4][2] = {-1,0,0,-1,1,0,0,1};
struct Node
{
	int x,y,color;
}s[500];

void solve()
{
	int n;
	cin >> n;
	memset(s,0,sizeof s);
	memset(vis,0,sizeof vis);
	for(int i = 0;i < n ; i++){
		cin >> s[i].x >> s[i].y >> s[i].color;
		vis[s[i].x][s[i].y] = s[i].color;
	}
	int ans = 0;
	for(int i = 0;i < n ; i ++)
	{
		if(s[i].color != 1) continue;
		int tx = s[i].x,ty = s[i].y;
		for(int k = 0;k < 4;k ++)
		{
			int dx = tx + dir[k][0],dy = ty + dir[k][1];
			if(dx >= 1 && dx <= 19 && dy >= 1 && dy <= 19 && vis[dx][dy] != 2) ans ++;
		}
	}
	cout << ans << "\n";
}

signed main(){
	int T;
	cin >> T;
	while(T--){
		solve();
	}	
	return 0;
}