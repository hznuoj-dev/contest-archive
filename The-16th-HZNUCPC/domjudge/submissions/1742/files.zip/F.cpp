#include <bits/stdc++.h>
using namespace std;
int main()
{
    //n:votes m:restContestant
    long long n, m;
    cin >> n >> m;
    if (m == 1 || n == 1)
        cout << ("YES");
    else if (n <= m)
        cout << ("NO");
    else
    {
        bool flg = true;
        for (int i = 2; i <= m && i * i <= n; i++)
        {
            if (n % i == 0)
            {
                flg = false;
                break;
            }
        }
        if (!flg)
        {
            cout << ("NO");
        }
        else
        {
            cout << ("YES");
        }
    }
    return 0;
}