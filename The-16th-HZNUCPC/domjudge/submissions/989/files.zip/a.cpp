#include<bits/stdc++.h>
using namespace std;

using ll=long long;

struct P
{
	ll x,y;
	void read()
	{
		cin>>x>>y;
	}
	ll operator^(const P &b)const
	{
		return x*b.y-y*b.x;
	}
	P operator-(const P &b)const
	{
		return {x-b.x,y-b.y};
	}
};

int n;
P p[105];
ll S(P a,P b,P c)
{
	return abs((b-a)^(c-a));
}
ll JS(P a,P b)
{
	ll fz=b.y-a.y;
	ll fm=b.x-a.x;
	
	ll g=__gcd(fz,fm);
	return abs(g)-1;
}

//void yzyzyz(P a,P b,P c)
//{
//	
//}
void SV()
{
	//cout<<JS({0,0},{100,50})<<"\n";
	
	cin>>n;
	for(int i=1;i<=n;++i)p[i].read();
	
	ll ans=0;
	for(int i=1;i<=n;++i)
		for(int j=i+1;j<=n;++j)
			for(int k=j+1;k<=n;++k)
			{
				//yzyzyz(p[i],p[j],p[k]);
				//continue;
				
				
				ll s2_2=S(p[i],p[j],p[k])+2;//bian+2*nei
				ll bian=JS(p[i],p[j])+JS(p[j],p[k])+JS(p[i],p[k])+3;
				ll nei2=s2_2-bian;
				
				//ans=max(ans,nei2);
				ans=max(ans,bian);
			}
	//assert(ans%2==0);
	cout<<ans<<"\n";
}
int main()
{
	ios::sync_with_stdio(0);
	SV();
	return 0;
}