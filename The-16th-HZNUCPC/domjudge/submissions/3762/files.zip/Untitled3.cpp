#include <stdio.h>
int main()
{
	while(1)
	{
		printf("Hello HZNU!!!!!!\n");
	}
	return 0;
}