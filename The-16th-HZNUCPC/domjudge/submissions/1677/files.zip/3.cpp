#include <iostream>
using namespace std;


bool back(int n,int m)
{
	if(m == 1) return true;
	if(m == 0) return false;
	back(n,n%m);
}

int main(){
	int n,m;
	cin >>n>>m;
	if(back(n,m))
	{
		printf("YES");
	}else
	{
		printf("NO");
	}
	return 0;
}