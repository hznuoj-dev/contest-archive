/*#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll mod = 1e9+7;


ll qpow(ll a,ll b){
    ll ans = 1;
    while(b){
        if(b&1) ans = ans*a%mod;
        a=a*a%mod;
        b>>=1;
    }
    return ans;
}

bitset<10> bs;

int pa[N];
int find(int a){
    return pa[a]==a?a:pa[a] = find(pa[a]);
}

void merge(int a,int b){
    a = find(a),b = find(b);
    if(a==b) return;
    pa[a] = b;
}
int op[N],x[N],y[N];
signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    bs.set(1);
    bs.set(5);
    for(int i = bs._Find_first();i!=bs.size();i=bs._Find_next(i)){
        cout<<i<<endl;
    }

    int n,q,m;
    cin>>n>>q>>m;
    for(int i=1;i<=n;i++) pa[i] = i;
    for(int i=1;i<=m;i++){

    }
}
*/

#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll mod = 1e9+7;

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int t;
    cin>>t;
    while(t--){
        string s,tmp;
        cin>>tmp;
        s.push_back('!');
        s.push_back('@');
        for(auto x:tmp){
            s.push_back('#');
            s.push_back(x);
        }
        s.push_back('#');
        s.push_back('$');
        s.push_back('%');


        int ans = 1;
        for(int i=2;i<=s.length()-3;i++){
            pair<int,int> flag = {-1,-1};
            int l = i-1,r = i+1;
            while(1){
                if(flag.first==-1&&flag.second==-1){
                    if(s[l]==s[r]){
                        l--,r++;
                        ans = max(ans,r-l-1);
                    }else {
                        flag.first = s[l]-'a';
                        flag.second = s[r]-'a';
                        l--,r++;
                    }
                }else if(flag.first==30&&flag.second==30){
                    if(s[l]==s[r]){
                        l--,r++;
                        ans = max(ans,r-l-1);
                    }else{
                        break;
                    }
                }else {
                    if(s[l]==s[r]){
                        l--,r++;
                    }else {
                        if(flag.first==s[r]-'a'&&flag.second==s[l]-'a'){
                            l--,r++;
                            ans = max(ans,r-l-1);
                            flag = {30,30};
                        }else {
                            break;
                        }
                    }
                }
            }
        }
        ans = ans / 2;
        if(ans==1){
            ans = 0;
        }
        cout<<ans<<endl;
    }
}
