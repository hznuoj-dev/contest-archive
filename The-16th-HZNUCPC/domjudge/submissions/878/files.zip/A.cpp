#include <bits/stdc++.h>

using namespace std;
vector<pair<int, int>>bk;
int st[19][19];
int dx[4]={1,-1,0,0};
int dy[4]={0,0,-1,1};
int main(){
	int t; cin >> t;
	while(t--){
		int n;
		cin >> n;
		int x,y,c;
		
		for(int i = 0;i<n;i++){
			cin >> x >> y >> c;
			st[x][y]=1;
			if(c==1)
				bk.push_back({x,y});
		}	
		int ans = 0;
		for(auto i:bk){

			for(int g = 0 ; g <=3 ;g++){
			int x =i.first + dx[g], y=i.second + dy[g];

			if(0<=x && x<=18 && y>=0 && y <=18 && st[x][y]==0){
				ans++;
				st[x][y]=1;
				}
			}
		}

		cout << ans<<endl;
	}
}
	          