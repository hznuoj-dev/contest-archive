#include  <bits/stdc++.h>

using namespace std;
typedef long long LL;

int dx[] = {-1, 0, 1, 0}, dy[] = {0, 1, 0, -1};
int g[30][30];
int cnt[30][30];
bool flg[30][30];
void kizk(){
	int n; cin >> n;
	set<pair<int, int>> s;
	vector<pair<int, int>> w;
	set<pair<int, int>> be;
	memset(g, 0, sizeof g);
	memset(cnt, 0 , sizeof cnt);
	memset(flg, false, sizeof flg);
	for(int k = 0; k < n; k ++)
	{
		int x, y, c; cin >> x >> y >> c;
		g[x][y] = c;
		if(c == 2)
			cnt[x][y] -- ;

	}
	for(int i = 1; i <= 19; i ++)
		for(int j = 1; j <= 19; j ++)
		{
			if(g[i][j] == 1)
			{
				for(int k = 0; k < 4; k ++)
				{
					int a = i + dx[k], b = dy[k] + j;
					if(a < 1 || b < 1 || a > 19 || b > 19) continue;
					if(g[a][b] == 1) continue;
					cnt[a][b] ++ ;
					flg[a][b] = true;
				}
			}
		}
	int res = 0;
	for(int i = 1; i <= 19; i ++)
		for(int j = 1; j <= 19; j ++)
			res += flg[i][j] ? cnt[i][j] : 0;
	cout << res << "\n";


}


int main(){
	std::ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int T; T = 1;
	cin >> T;
	while(T --) kizk();
	return 0;
}