#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

ll x,y,n,m,a;
int main()
{
	cin>>n>>m;
	x=n;y=m;
	while(1)
	{
		a=x-y;
		if(a>y)	
		{
			x=a;	
		}
		else break;
	}

	if(m==3 && n%m==0 && n>= 8)printf("NO");
	else if(m == 1 || n-m == 1 || x-y == 1)printf("YES");
	else if (n % m == 0 || m >= n || n % 2==0) printf("NO");
	else if(m == 2) printf("YES");
	else if(x%(x-y) == 0)printf("NO");
	else printf("YES");
	return 0;
}

