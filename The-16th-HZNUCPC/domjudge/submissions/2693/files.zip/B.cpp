#include <bits/stdc++.h>

#define dbg(x...) \
    do { \
        std::cout << #x << " -> "; \
        err(x); \
    } while (0)

void err() {
    std::cout << std::endl;
}

template<class T, class... Ts>
void err(T arg, Ts &... args) {
    std::cout << arg << ' ';
    err(args...);
}

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using i128 = __int128;
using p = std::pair<ll, ll>;
using p128 = std::pair<i128, i128>;

p operator-(p &p1, p &p2) {
    return {p1.first - p2.first, p1.second - p2.second};
}

i128 operator*(p &p1, p &p2) {
    return p1.first * p2.first + p1.second * p2.second;
};

i128 gcd(i128 a, i128 b) {
    if (b == 0) return a;
    return a % b == 0 ? b : gcd(b, a % b);
}

void run(int tCase) {
    int n;
    std::cin >> n;
    auto abs = [&](p &p) {
        return p.first * p.first + p.second * p.second;
    };
    auto multi = [&](p p1, p p2) {
        return p1.first * p2.second - p1.second * p2.first;
    };
    std::map<std::vector<p128>, int> mp;
    for (int _ = 0; _ < n; ++_) {
        int m;
        std::cin >> m;
        std::vector<p> v(m);
        for (auto &[x, y]: v) {
            std::cin >> x >> y;
        }
        std::sort(v.begin(), v.end());
        p o = v[0];
        std::sort(v.begin(), v.end(), [&](p &p1, p &p2) {
            if (multi(p1 - o, p2 - o)) return multi(p1 - o, p2 - o) > 0;
            return p1.first < p2.first;
        });
        std::vector<p128> angles;
        for (int i = 0; i < m; ++i) {
            int j = (i + 1) % m;
            int k = (i + 2) % m;
            p p1 = v[j] - v[i]; //i -> j, j -> k
            p p2 = v[k] - v[j];
            i128 up = p1 * p2;
            up *= up;
            i128 down = 1;
            down *= abs(p1);
            down *= abs(p2);
            i128 g = gcd(up, down);
            up /= g, down /= g;
            angles.emplace_back(up, down);
        }
        std::sort(angles.begin(), angles.end());
        std::cout << mp[angles] << '\n';
        mp[angles]++;
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int T = 1;
//    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        run(t);
    }
    return 0;
}