#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
const ll N=1005,mod=1000000007;
string s,t;
ll n,sum[30][2],a[30][30];
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>s>>t;
    n=s.length();
    for(ll i=0;i<n;++i)
    {
        a[s[i]-'a'][t[i]-'a']++;
        sum[s[i]-'a'][0]++;
        sum[t[i]-'a'][1]++;
    }
    ll ans=0;
    for(ll i1=0;i1<26;++i1)
    {
        for(ll j1=0;j1<26;++j1)
        {
            for(ll i2=0;i2<26;++i2)
            {
                for(ll j2=0;j2<26;++j2)
                {
                    if(sum[i1][0]==0||sum[i2][0]==0||sum[j1][1]==0||sum[j2][1]==0)continue;
                    if(i1==i2&&sum[i1][0]<2)continue;
                    if(j1==j2&&sum[j1][1]<2)continue;
                    sum[i1][0]--;
                    sum[i2][0]--;
                    sum[j1][1]--;
                    sum[j2][1]--;
                    sum[j1][0]++;
                    sum[j2][0]++;
                    sum[i1][1]++;
                    sum[i2][1]++;
                    ll w=0,ww=0;
                    for(ll k=0;k<26;++k)
                    {
                        if(sum[k][0]>0)++w;
                        if(sum[k][1]>0)++ww;
                    }
                    if(w==ww)
                    {
                        if(i1==i2&&j1==j2)ans+=a[i1][j1]*(a[i1][j1]-1);
                        else ans+=a[i1][j1]*a[i2][j2];
                    }


                    sum[i1][0]++;
                    sum[i2][0]++;
                    sum[j1][1]++;
                    sum[j2][1]++;
                    sum[j1][0]--;
                    sum[j2][0]--;
                    sum[i1][1]--;
                    sum[i2][1]--;
                }
            }
        }
    }
    cout<<ans/2%mod;
    return 0;
}
