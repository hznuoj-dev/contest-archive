#include<iostream>
#include<vector>
#include<string>
#include<cmath>
#include<unordered_map>
#include<algorithm>
using namespace std;
typedef long long LL;
typedef pair<int,int>PII;
int tong[10010][5010];
vector<int>q[50010];
string s,t;
int n;
bool check(int l,int r)
{
//	cout<<"l="<<l<<" "<<r<<endl;
	int rr=n-r;
	int py=l-rr+5010;
	vector<PII>idx;
	int lll=l,rrr=r;
	if(r-l+1==2&&s[l]!=s[r])return false;
//	if(!(l==0&&r==5))return false;
	while(1){
		auto p=lower_bound(q[py].begin(),q[py].end(),l);
		if(p!=q[py].end()&&*p<=r){
			int id=*p,id2=n-*p;
//			cout<<id<<endl;
			idx.push_back({s[id]-'a',t[id]-'a'});
			l=*p+1;
		}
		else break;
	}
//	cout<<ll<<" "<<rrr<<" "<<idx.size()<<" "<<py-5010<<endl;
	if((int)idx.size()!=4&&(int)idx.size()!=2)return false;
	sort(idx.begin(),idx.end());
	if((int)idx.size()==4){
			if(idx[0].first==idx[1].first&&idx[0].second==idx[1].second){
		if(idx[2].first==idx[3].first&&idx[2].second==idx[3].second){
			if(!(idx[1].first==idx[2].first&&idx[1].second==idx[2].second)){
				if(idx[0].first==idx[2].second&&idx[0].second==idx[2].first){
					return true;
				}
			}
		}
	}
//	cout<<idx[0].first<<" "<<idx[0].second<<" "<<idx[1].first<<" "<<idx[1].second<<endl;
//	cout<<ll<<" "<<rrr<<" "<<idx.size()<<" "<<py-5010<<endl;
	return false;
	}
	else{
		if((r-l+1)%2==0)return false;
//		cout<<"hh="<<endl;
//		cout<<"idx="<<idx[0].first<<" "<<idx[0].second<<" "<<idx[1].first<<" "<<idx[1].second<<endl;
		if(idx[0].first==idx[1].second&&idx[0].second==idx[1].first){
//			cout<<"op="<<s[(lll+rrr)/2]<<endl;
			if(idx[0].first==s[(lll+rrr)/2]-'a'||idx[0].second==s[(lll+rrr)/2]-'a')return true;
			else return false;
		}
		else return false;
	}
}
signed main()
{
	cin.tie(0);cout.tie(0);
	ios::sync_with_stdio(false);
	int T;
	cin>>T;
	while(T--)
	{
		cin>>s;
		n=s.size();
		
		vector<char>a;
		a.push_back(0);
		for(int i=0;i<n;i++){
			a.push_back(s[i]);
			a.push_back(0);
		}		
		vector<int>p;
		p.resize(a.size());
		p[0]=0;
		int id,mx=0;
		for(int i=1;i<a.size();i++){
			if(i<mx)p[i]=min(mx-i,p[2*id-i]);
			else p[i]=1;
			while(i-p[i]>=0&&i+p[i]<a.size()&&a[i-p[i]]==a[i+p[i]])++p[i];
			if(mx<i+p[i]){
				mx=i+p[i];
				id=i;
			}
		}
		int res=0;
		for(int i=0;i<a.size();i++)res=max(res,p[i]-1);
		if(res==1)res=0;
		for(int i=0;i<=n+5010;i++){
			for(int j=0;j<=n;j++){
				tong[i][j]=0;
			}
		}
		for(int i=0;i<=30000;i++)q[i].clear();
		t=s;
		n--;
		reverse(t.begin(),t.end());
		for(int py=-(n);py<=n;py++){
			for(int j=0;j<=n;j++){
				if(j-py<0||j-py>n)continue;
				if(s[j]!=t[j-py])tong[py+5010][j]=1;
			}
		}
		for(int py=-(n);py<=n;py++){
			int p=py+5010;
			for(int j=0;j<=n;j++){
				if(j-py<0||j-py>n)continue;
				if(tong[p][j])q[p].push_back(j);
			}
		}
		for(int l=0;l<=n;l++){
			for(int r=l;r<=n;r++){
				if(check(l,r))res=max(res,r-l+1);
			}
		}
		cout<<res<<endl;
	}
}
