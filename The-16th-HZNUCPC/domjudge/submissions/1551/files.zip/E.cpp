#include<bits/stdc++.h>
using namespace std;

#define int long long

const int N = 2e3 +10, inf = 1e17, mod = 1e9 +7;

int n, m, k, x, y, ans;
char s[N], p[N];

int v[N];

struct point{
    int x;
    int y;
}a[N];

void run(){
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i].x>>a[i].y;
    }
    ans = 0;
    for(int i=1;i<=n;i++){
        for(int j=i+1;j<=n;j++){
            for(int k=j+1;k<=n;k++){
                double S = abs(a[i].x*a[j].y-a[i].y*a[j].x+a[j].x*a[k].y-a[j].y*a[k].x+a[k].x*a[i].y-a[k].y*a[i].x);
                if(S==0)continue;
                int res = 0;
                x = abs(a[i].x-a[j].x);
                y = abs(a[i].y-a[j].y);
                res += __gcd(x,y);

                x = abs(a[i].x-a[k].x);
                y = abs(a[i].y-a[k].y);
                res += __gcd(x,y);

                x = abs(a[j].x-a[k].x);
                y = abs(a[j].y-a[k].y);
                res += __gcd(x,y);
                ans=max(ans,res);
            }
        }
    }
    cout<<ans<<'\n';
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int T;
    //for(cin>>T;T>0;T--)
    run();return 0;
}
