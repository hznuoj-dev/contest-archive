#include<bits/stdc++.h>
#define int long long
#define rep(i,a,n) for(int i=a;i<n;i++)
#define per(i,a,n) for(int i=n-1;i>=a;i--)
#define fi first 
#define se second
#define pb push_back
#define endl '\n'
#define pii pair<int,int> 
#define vii vector<pair<int,int> >

using namespace std;
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
int g[22][22];
int dx[]={1,-1,0,0},dy[]={0,0,-1,1};
pii p[110];
pii get(pii a,pii b){
	if(a.fi==b.fi) return {0,1};
	if(a.se==b.se) return {1,0};
	int dx=a.fi-b.fi;
	int dy=a.se-b.se;
	if(dx*dy>0){
		int d=gcd(dx,dy);
		return {dx/d,dy/d};
	}else{
		int d=gcd(dx,dy);
		return {-dx/d,dy/d};
	}
}
int getn(pii a,pii b){
	if(a.fi==b.fi) return abs(a.se-b.se)-1;
	if(a.se==b.se) return abs(a.fi-b.fi)-1;
	int dx=abs(a.fi-b.fi),dy=abs(a.se-b.se);
	return gcd(dx,dy)-1;
}
void solve(){
	int n;cin>>n;int m;cin>>m;
	rep(i,1,n+1){
		//cin>>p[i].fi>>p[i].se;
	}
	for(int i=2;i*i<=n&&i<m;i++){
		if(n%i==0){
			cout<<"NO\n";return;
		}
	}cout<<"YES\n";
	
}
signed main(){
	int t=1;//cin>>t;
	while(t--){
		solve();
	}
	return 0;
}