#include<iostream>
#include<math.h>
using namespace std;
long long ss(long long a)
{
	long long i=2;
	for(i=2;i<=sqrt(a)+1;i++)
	{
		if(a%i==0)
		 return 0;
	}
	return 1;
}
int main()
{
	long long n,m;
	cin>>n>>m;
	if(n==1||m==1)
	cout<<"YES"<<endl;
	else if(n<=m)
	cout<<"NO"<<endl;
	else if(n%2==0)
	cout<<"NO"<<endl;
	else if(ss(n))
	cout<<"YES"<<endl;
	else
	{
		if(n%m==0||n%(m-1)==0)
		cout<<"NO"<<endl;
		else
		cout<<"YES"<<endl;
	}
	return 0;
}