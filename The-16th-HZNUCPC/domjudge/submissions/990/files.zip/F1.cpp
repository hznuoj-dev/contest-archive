#include<bits/stdc++.h>
using namespace std;
#define int long long
#define ll long long
const int N=2e3;
int vis[N][N];
struct node{
	int a,b,sta;
}s[N];
int dir[4][2]={{0,1},{0,-1},{-1,0},{1,0}};
signed main(){
	ll n,m;
	while(cin>>n>>m){
		if(m==1){
			cout<<"YES"<<endl;
			continue;
		}
		if(n==m){
			cout<<"NO"<<endl;
		}else{
			if(n%2){
				cout<<"YES"<<endl;
			}else{
//				if(((n%m)%2)){
//					cout<<"YES"<<endl;
//				}else{
//					cout<<"NO"<<endl;
//				}
				cout<<"NO"<<endl;
			}
		}
	}
	return 0;
}