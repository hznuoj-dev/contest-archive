#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	ll a, b;
	cin >> a >> b;
	if(b == 1) {
		cout << "YES";
		return 0;
	}
	if(a == 1) {
		cout << "YES";
		return 0;
	}
	int flag = 0;
	while(b != 0) {
		b = a % b;
		if(b == 1) {
			flag = 1;
		}
	}
	if(flag == 1) cout << "YES";
	else cout << "NO";
	return 0;
}