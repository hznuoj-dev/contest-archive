#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define me(a,b) memeset(a,b,sizeof a);
int n,m;
signed main() {
	IOS
	cin>>n>>m;
	if(m==1||n==1) {
		cout<<"YES"<<endl;
		return 0;
	}else if(n<=m){
		cout<<"NO"<<endl;
		return 0;
	}
	while(m>1){
		m=n%m;
//		cout<<m<<endl;
	}
	if(m==1) cout<<"YES"<<endl;
	if(m==0) cout<<"NO"<<endl;
	return 0;

}