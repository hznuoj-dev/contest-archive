package dd;

import java.util.HashMap;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		while (in.hasNext()) {
			long n = in.nextLong();
			long m = in.nextLong();
			if (n < m) {
				if (n == 1) {
					System.out.println("YES");

				} else {
					System.out.println("NO");
				}
			}else{
				if(n%2==1){
			long a = gcd(n, m);
			  if (a == 1) {
				System.out.println("YES");
			   } else {
				 System.out.println("NO");
			   }
			  }else{
				if(m==1||n==1||n-m==1){
					System.out.println("YES");
				}else{
					System.out.println("NO");
				}
			}
		}
		}
	}

	private static long gcd(long n, long m) {
		while (n%m!=0 ) {
			long x=n%m;
			n=m;
			m=x;
		}
		return m;
	}

}
