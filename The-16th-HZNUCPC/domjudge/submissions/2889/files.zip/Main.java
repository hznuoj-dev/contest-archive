package demo;
import java.util.Scanner;

public class Main {
	public static void main(String args[]){
	Scanner sc =new Scanner(System.in);
	while(sc.hasNext()){
	Boolean b=false;
	int max=0,len=0;
	int t=sc.nextInt();
	while(t--!=0){
		String s=sc.nextLine();
		for(int i=0;i<s.length();i++){
			for(int j =i+1;j<s.length();j++){
				if(s.charAt(i)==s.charAt(j)){
					int n=i;
					int m=j;
					for(;n<=m;n++,m--){
						if(s.charAt(n)==s.charAt(m)){
							b=true;
						}else{
							b=false;
							break;
						}
					}
					if(b){
						len=j-i+1;
						if(len>max){
							max=len;
						}
					}
				}
			}
		}
		System.out.print(max);
	}
	}
	sc.close();
}
}

