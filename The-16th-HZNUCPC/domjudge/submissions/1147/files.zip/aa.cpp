#include<bits/stdc++.h>
typedef long long ll;
const ll N=5e3+7;
const ll mod =1e9+7;
const double eps=1e-6;
using namespace std;
int f[21][21];
void slove(){
	int n;cin>>n;
	memset(f,0,sizeof(f));
	while(n--){
		int x,y,c;cin>>x>>y>>c;
		if(c==1){
			f[x][y]=-0x3f3f3f;
			f[x-1][y]++;
			f[x+1][y]++;
			f[x][y-1]++;
			f[x][y+1]++;
		}
		else f[x][y]=-0x3f3f3f;
	}	
	int ans=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(f[i][j]>=1) ans+=f[i][j];
			}
		}
		cout<<ans<<"\n";
}
int main(){
	int t;cin>>t;
	while(t--)
	slove();
}
