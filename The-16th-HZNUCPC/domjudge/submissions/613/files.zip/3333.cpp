#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	int n,m,i,j,k,judge=1;
	cin>>n>>m;
	int end=sqrt(m+1);
	for(i=2;i<=end;i++){
		if(n%i==0){
			judge=0;
			break;
		}
	}
	if(judge==1){
		cout<<"YES";
	}
	else{
		cout<<"NO";
	}
	
	return 0;
}