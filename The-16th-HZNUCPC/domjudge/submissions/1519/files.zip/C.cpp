#include <bits/stdc++.h>

#define dbg(x...) \
    do { \
        std::cout << #x << " -> "; \
        err(x); \
    } while (0)

void err() {
    std::cout << std::endl;
}

template<class T, class... Ts>
void err(T arg, Ts &... args) {
    std::cout << arg << ' ';
    err(args...);
}

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using i128 = __int128;

constexpr int mod = 1e9 + 7;

ll qpow(ll a, ll b = mod - 2) {
    a %= mod;
    ll ret = 1;
    while (b) {
        if (b & 1) ret = ret * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return ret;
}

void run(int tCase) {
    std::string s, t;
    std::cin >> s >> t;
    int n = (int) s.length();
    std::vector<int> cnt_s(26), cnt_t(26);
    for (int i = 0; i < n; ++i) {
        cnt_s[s[i] - 'a']++;
        cnt_t[t[i] - 'a']++;
    }
    auto check = [&](std::vector<int> &v) {
        //a1 b1 a2 b2
        auto mps = cnt_s;
        auto mpt = cnt_t;
        mps[v[0]]--;
        mpt[v[0]]++;
        mps[v[1]]++;
        mpt[v[1]]--;
        mps[v[2]]--;
        mpt[v[2]]++;
        mps[v[3]]++;
        mpt[v[3]]--;
        int ss = 0, tt = 0;
        for (int i = 0; i < 26; ++i) {
            if (mps[i]) ss++;
            if (mpt[i]) tt++;
        }
        return ss == tt;
    };
    int tot = 26 * 26 * 26 * 26;
    //a1 b1 a2 b2
    std::vector<int> mp(26 * 26);
    for (int i = 0; i < n; ++i) {
        mp[(s[i] - 'a') * 26 + t[i] - 'a']++;
    }
    ll ans = 0;
    for (int f = 0; f < tot; ++f) {
        int g = f;
        std::vector<int> v(4);
        for (int i = 0; i < 4; ++i) {
            v[i] = g % 26;
            g /= 26;
        }
        if (not check(v)) continue;
        ll sum = 1ll * mp[v[0] * 26 + v[1]] * mp[v[2] * 26 + v[3]];
        if (v[0] == v[2] and v[1] == v[3]) sum -= mp[v[0] * 26 + v[1]];
        sum %= mod;
        ans = (ans + sum) % mod;
    }
    std::cout << ans * qpow(2) % mod << '\n';
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int T = 1;
//    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        run(t);
    }
    return 0;
}