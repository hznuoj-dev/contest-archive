#include <bits/stdc++.h>
#define int long long int
#define all(x) (x).begin(),(x).end()

using namespace std;

const int N = 120;

struct Point
{
	int x, y;
	Point operator - (const Point &a) { return {x - a.x, y - a.y}; }
	int operator ^ (const Point &a) { return x * a.y - y * a.x; }
}v[N];

int n;

int get(Point a, Point b)
{
	int xx = abs(a.x - b.x), yy = abs(a.y - b.y);
	int d = __gcd(xx, yy);
	return d;
}

void solve()
{
	cin >> n;
	for(int i = 1; i <= n; i ++)
		cin >> v[i].x >> v[i].y;
	
	int res = 0;
	for(int i = 1; i <= n; i ++)
	{
		for(int j = i + 1; j <= n; j ++)
		{
			for(int k = j + 1; k <= n; k ++)
			{
				Point a = v[j] - v[i], b = v[k] - v[i], c = v[k] - v[j];
				int s = abs(a ^ b) / 2;
				int d1 = get(v[i], v[j]), d2 = get(v[i], v[k]), d3 = get(v[k], v[j]);
				int dd = d1 + d2 + d3; // S = aa + dd / 2 - 1
				int aa = s + 1 - dd / 2;
				
//				cout << i << " --- " << j << " ---- " << k << " ---- \n";
				cout << aa << " " << dd << " " << s << " +++ \n";
				res = max(res, dd);
			}
		}
	}
	
	cout << res << '\n';
}

signed main()
{
    int t = 1;
//    cin >> t;
    while (t -- ) solve();
}
