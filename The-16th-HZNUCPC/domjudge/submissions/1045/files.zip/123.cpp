#include<bits/stdc++.h>
using namespace std;
const int N=111;
pair<int,int>p[N];
int n,m;
int main()
{
    cin>>n>>m;
    if(n%m==0)
    {

        cout<<"NO"<<endl;
        return 0;
    }
    for(int i=2;i*i<=m;i++)
    {
        if(n%i==0 || n%m==0)
        {

            cout<<"NO"<<endl;
            return 0;
        }

    }
    cout<<"YES"<<endl;

}
