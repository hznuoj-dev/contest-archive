#include<bits/stdc++.h>
#define int long long 
using namespace std;
const int mo=1e9+7;
char s1[100005],s2[100005];
int n;
int a1[55],a2[55];
int kp[55][55];
int ans;
int t1,t2;
signed main(){
	scanf("%s",s1+1);
	scanf("%s",s2+1);
	n=strlen(s1+1);
	for(int i=1;i<=n;i++){
		kp[s1[i]-'a'][s2[i]-'a']++;
		a1[s1[i]-'a']++;
		if(a1[s1[i]-'a']==1) t1++;
		a2[s2[i]-'a']++;
		if(a2[s2[i]-'a']==1) t2++;
	}
	int inv=(mo+1)/2;
	for(int i=0;i<26;i++)
		for(int j=0;j<26;j++)
			for(int k=i;k<26;k++)
				for(int l=(k==i?i:0);l<26;l++){
					if(i^k||j^l){
						int u1=t1,u2=t2;
						a1[i]--;
						if(a1[i]==0) u1--;
						a1[j]++;
						if(a1[j]==1) u1++; 
						a1[k]--;
						if(a1[k]==0) u1--;
						a1[l]++;
						if(a1[l]==1) u1++;
						
						a2[i]++;
						if(a2[i]==1) u2++;
						a2[j]--;
						if(a2[j]==0) u2--;
						a2[k]++;
						if(a2[k]==1) u2++;
						a2[l]--;
						if(a2[l]==0) u2--;
						
						if(u1==u2){
							ans=(ans+kp[i][j]*kp[k][l]%mo)%mo;
						}
						a1[i]++;a1[j]--;a1[k]++;a1[l]--;
						a2[i]--;a2[j]++;a2[k]--;a2[l]++;
					}else{
							int u1=t1,u2=t2;
						a1[i]--;
						if(a1[i]==0) u1--;
						a1[j]++;
						if(a1[j]==1) u1++; 
						a1[k]--;
						if(a1[k]==0) u1--;
						a1[l]++;
						if(a1[l]==1) u1++;
						
						a2[i]++;
						if(a2[i]==1) u2++;
						a2[j]--;
						if(a2[j]==0) u2--;
						a2[k]++;
						if(a2[k]==1) u2++;
						a2[l]--;
						if(a2[l]==0) u2--;
						
						if(u1==u2){
							ans=(ans+(kp[i][j]*(kp[k][l]-1)%mo)*inv%mo)%mo;
						}
						a1[i]++;a1[j]--;a1[k]++;a1[l]--;
						a2[i]--;a2[j]++;a2[k]--;a2[l]++;
					}				
				}
	printf("%lld",(ans%mo+mo)%mo);
	return 0;
}
