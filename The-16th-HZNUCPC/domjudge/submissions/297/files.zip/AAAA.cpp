#include<bits/stdc++.h>

using namespace std;
#define int long long 
#define eb emplace_back
#define pii pair<int, int> 
#define endl '\n'
int dr[4] = {1, 0, -1, 0};
int dc[4] = {0, 1, 0, -1};
void run() {
	int n;
	cin >> n;
	vector<vector<int> > arr(20, vector<int>(20, 0));
	vector<pii> all;
	for (int i = 0; i < n; i++) {
		int x, y, c;
		cin >> x >> y >> c;
		arr[x][y] = 2;
		if (c == 1) all.eb(pii(x, y));
	}
	int sum = 0;
	for (auto p : all) {
		int x = p.first, y = p.second;
		for (int k = 0; k < 4; k++) {
			pii nx= pii(x + dr[k], y + dc[k]);
			if (nx.first < 1 || nx.first > 19 || nx.second < 1 || nx.second > 19 || arr[nx.first][nx.second] == 2) continue;
			sum++;
		}
	}

	cout << sum << endl;






	return;
}
/*
1
2
1 1 1
2 2 1

1
2
10 9 1
10 10 1

*/
signed main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int T = 1;
	cin >> T;
	while (T--) {
		run();
	}



	return 0;
}