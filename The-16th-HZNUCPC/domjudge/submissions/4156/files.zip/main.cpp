#include <iostream>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;
typedef unsigned long long ll;

ll n, m, x = 0;

int main()
{
    cin >> n >> m;
    if (n == 1 || m == 1)
    {
        cout << "YES";
        return 0;
    }
    if (n <= m)
    {
        cout << "NO";
        return 0;
    }
    for (int i = 2; i <= n/2; i++)
    {
        if (n % i == 0)
        {
            x = i;
            break;
        }
    }
    if (x == 0)
        x = n;
    if (x <= m)
        cout << "NO";
    else
        cout << "YES";
    return 0;
}