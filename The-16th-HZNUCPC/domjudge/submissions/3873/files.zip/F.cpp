#include<bits/stdc++.h>
using namespace std;
int isSu(long long x){
	if(x==1 ||x==0)return 0;
	for(int i=2;i<=sqrt(x);i++){
		if(x%i==0)return 0;
	}	
	return 1;
}
int main(){
	long long n,m,k,t;
	while(cin>>n>>m){
		if(n==1 || m==1){
			cout <<"YES"<<endl;
		}else{
			if(n<=m){
				cout <<"NO"<<endl;
			}else{
				int a,b;
				a = n%2;
				b= m%2;
				
				if(a==1 &&b==1){
					cout <<"YES"<<endl;
				}else if(a==0 &&b==0){
					cout <<"YES"<<endl;
				}else if(a==1 && b==0){
					cout <<"YES"<<endl;
				}else if(a==0&&b==1){
					cout <<"NO"<<endl;
				}
				
				
				
			}
			
		
		}
		
	}
	
	return 0;
}