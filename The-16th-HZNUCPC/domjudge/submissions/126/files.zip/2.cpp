#include<bits/stdc++.h>
using namespace std;
long long n, m;
int main() {
	scanf("%lld%lld", &n, &m);
	if (n == 1) printf("YES\n");
	else if (n <= m) printf("NO\n");
    else {
    	bool tf = 0;
    	for (long long i = 2; i * i <= n && i <= m; i++)
    		if (n % i == 0) {
    			tf = 1;
    			break;
			}
		if (tf == 1) printf("NO\n");
		else printf("YES\n");
	}
}