#include<bits/stdc++.h>
#define PII pair<int,int>
#define F first
#define S second
#define LL long long
using namespace std;

const int N = 1e5,mod = 1;

LL minl(LL a, LL b)
{
	if( a < b) return a;
	return b;
}

int main()
{
	int flag = 1;
	LL n,m;
	cin >> n >> m;
	for(int i = 2;i <= minl(m,(LL)sqrt(n));i ++)
	{
		if (n % i == 0) 
		{
			flag = 0;
			break;
		}
	}
	if (flag) cout << "YES";
	else cout << "NO";
		
	return 0;
}