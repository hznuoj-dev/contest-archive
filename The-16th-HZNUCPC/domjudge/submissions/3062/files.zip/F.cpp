#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,k,t;
	while(cin>>n>>m){
		if(n==1||m==1){
			cout <<"YES"<<endl;
		}else if(n<m){
			cout <<"NO"<<endl;
		}else{
			if((n-m)%2 ==0){
				cout <<"YES"<<endl;
			}else{
				cout <<"NO"<<endl;
			}
		}
		
		
		
	}
	
	return 0;
}