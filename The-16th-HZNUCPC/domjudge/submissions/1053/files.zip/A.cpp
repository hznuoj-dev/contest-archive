#include<bits/stdc++.h>
using namespace std;
int t,n,x,y,z,a[21][21],ans;
int main()
{
	scanf("%d",&t);
	for(int ii=1;ii<=t;ii++)
	{
	    scanf("%d",&n);
	    ans=0;
	    memset(a,0,sizeof(a));
	    for(int i=1;i<=n;i++)
	    {
	    	scanf("%d%d%d",&x,&y,&z);
	    	if(z==1)
	    	{
	    		a[x][y]=2;
	    		if(!a[x-1][y])
	    		  a[x-1][y]=1;
	    		if(!a[x+1][y])
	    		  a[x+1][y]=1;
	    		if(!a[x][y-1])
	    		  a[x][y-1]=1;
	    		if(!a[x][y+1])
	    		  a[x][y+1]=1;
			}
			if(z==2)
			  a[x][y]=2;
		}
		for(int i=0;i<=20;i++)
		  for(int j=0;j<=20;j++)
		    if(a[i][j]==1)
		      ans++;
		printf("%d\n",ans);
	}
	return 0;
}