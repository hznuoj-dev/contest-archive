# include "bits/stdc++.h"
using namespace std;
# define int long long

int n, m;

signed main(){
	cin >> n >> m;
	if(m == 1 || n == 1){
		cout << "YES\n";
	}else{
		bool flag = false;
		while(m != 0){
			if(m == 1){
				flag = true;
				break;
			}
			m = n % m;
		}
		if(flag) cout << "YES\n";
		else cout << "NO\n";
	}
	
	
	return 0;
}