import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		while (in.hasNext()) {
			long n = in.nextLong();
			long m = in.nextLong();
			if(n==1||m==1){
					System.out.println("YES");
				}
			else{
				while(true){
				
				if(n%m==0){
					System.out.println("NO");
					break;
				}
				if(n%m==1){
					System.out.println("YES");
					break;
				}
				m=n%m;
				
			}
		}
		}
	}
	
}
