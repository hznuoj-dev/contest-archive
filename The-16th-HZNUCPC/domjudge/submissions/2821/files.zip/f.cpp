#include<iostream>
using namespace std;
int main()
{
	int n,x,y;
	cin>>x>>y;
	n=x%y;	
	if(x==1||y==1)
	{
	cout<<"YES";
	}
	else if(n==0)
	{
		cout<<"NO";
	}
	else
	{
		while(n%y==1)
		{
			n+=x;	
		}
		cout<<"YES";
	}
	return 0;
}
