#include<bits/stdc++.h>
#define int long long
using namespace std;
int a[105],b[105];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
    int n;cin>>n;
    for(int i=0;i<n;++i)cin>>a[i]>>b[i];
    if(n<=2){
    	cout<<0<<'\n';
		return 0;	
	}
    int ans=0;
    for(int i=0;i<n;++i){
    	for(int j=0;j<n;++j){
    		if(i==j)continue;
    		for(int k=0;k<n;++k){
    			int sum=0;
    			double xa,xb,xc;
    			if(i==k || j==k)continue;
    			int t1=abs(a[i]-a[j]),t2=(b[i]-b[j]);
    			if(t1==0 || t2==0)sum+=max(t1,t2);
    			else sum+=__gcd(t1,t2);
    			xa=t1*1.0/t2;
    			t1=abs(a[i]-a[k]),t2=(b[i]-b[k]);
    			if(t1==0 || t2==0)sum+=max(t1,t2);
    			else sum+=__gcd(t1,t2);
    			xb=t1*1.0/t2;
    			t1=abs(a[j]-a[k]),t2=(b[j]-b[k]);
    			if(t1==0 || t2==0)sum+=max(t1,t2);
    			else sum+=__gcd(t1,t2);
    			xc=t1*1.0/t2;
    			if(xa!=xb && xb!=xc && xa!=xc)ans=max(ans,sum);
			}
		}
	}
	cout<<ans;
	return 0;
}
