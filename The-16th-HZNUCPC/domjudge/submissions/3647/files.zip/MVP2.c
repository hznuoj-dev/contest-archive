#include <stdio.h>

int main(){
	long long  n,m;
	scanf("%lld%lld",&n,&m);
	long i=2;
	if(m==1||n==1){
		printf("YES");
	}
	else if(n<=m){
		printf("NO");
	}
	else{
	 long long i=2;
	 long long a,b;
	 for(;i<m;i++){
	 	a=n/i;
	 	b=n-i*a;
	 	if (b<a){
	 		if(n%i==0) {
	 			printf("NO");
	 			return 0;
			 }
		 }
	 }
	}
	printf("Yes");
	return 0;}
	
