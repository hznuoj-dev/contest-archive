#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
signed main(){
	while(cin>>n>>m){
		if(m==1){
			cout<<"YES"<<endl;
			continue;
		}
		int f=0;
		while(m>0){
			m=n%m;
			if(m==0){
				;
			}
			if(m==1){
				f=1;
			}
		}
		if(f==1){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}