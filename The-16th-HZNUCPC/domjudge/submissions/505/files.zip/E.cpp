#include<bits/stdc++.h>
using namespace std;
// #define int long long
using ll = long long;
typedef pair<int,int>PII;
#define pb push_back
struct Point{
    ll x, y;
};
void solve(){
    int n;
    cin >> n;
    vector<Point> a(n + 1);
    for(int i = 1;i <= n;i ++){
        cin >> a[i].x >> a[i].y;
    }
    ll res = 0;
    ll mx, my;
    auto calc = [&](Point aa, Point b){
        ll x = aa.x - b.x;
        ll y = aa.y - b.y;
        x = abs(x), y = abs(y);
        return (__gcd(x, y));
    };
    for(int i = 1;i <= n;i ++){
        for(int j = i + 1;j <= n;j ++){
            for(int k = j + 1;k <= n;k ++){
                ll now = (a[j].y - a[i].y) * (a[k].x - a[i].x);
                ll last = (a[k].y - a[i].y) * (a[j].x - a[i].x);
                if(now == last) continue;
                ll ikun = calc(a[i], a[j]) + calc(a[i], a[k]) + calc(a[j], a[k]);
                res = max(res, ikun);
            }
        }
    }
    cout << res << endl;
    return ;
} 
signed main(){
    int t=1;
    while(t--){
        solve();
    }
    return 0;
}