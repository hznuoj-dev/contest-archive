#include<bits/stdc++.h>
using namespace std;

int a[20][20]={0};

int main()
{
	int i,j;
	int time=0;
	scanf("%d",&time);
	while(time--)
	{
		memset(a,0,sizeof(a));
		int n=0;
		scanf("%d",&n);
		for(i=1;i<=n;i++)
		{
			int x=0,y=0,f=0;
			scanf("%d %d %d",&x,&y,&f);
			a[x][y]=f;
		}
		int sum=0;
		for(i=1;i<=19;i++)
		{
			for(j=1;j<=19;j++)
			{
				int k=4;
				if(a[i][j]==1)
				{
					if(i==1) k--;
					if(j==1) k--;
					if(i==19) k--;
					if(j==19) k--;
					if(a[i-1][j]==2||a[i-1][j]==1) k--;
					if(a[i+1][j]==2||a[i+1][j]==1) k--;
					if(a[i][j+1]==2||a[i][j+1]==1) k--;
					if(a[i][j-1]==2||a[i][j-1]==1) k--;
					sum+=k;
				}
				
			}
		}
		cout<<sum<<endl;
	}
	
	return 0;
}