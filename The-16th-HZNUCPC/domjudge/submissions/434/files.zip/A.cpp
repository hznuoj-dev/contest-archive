#include<bits/stdc++.h>
#define int long long
#define ll long long
#define vi vector<int>
#define pb push_back

using namespace std;

int mp[20][20];
int dx[] = {0,0,-1,1};
int dy[] = {1,-1,0,0};
void solve() {
	int n;
	cin >> n;
	for (int i = 1; i <= 19; i ++) {
		for (int j = 1; j <= 19; j ++) {
			mp[i][j] = 0;
		}
	}
	for (int i = 1; i <= n; i ++) {
		int x, y, c;
		cin >> x >> y >> c;
		mp[x][y] = c;
	}
	
	int ans = 0;
	for (int i = 1; i <= 19; i ++) {
		for (int j = 1; j <= 19; j ++) {
			if (mp[i][j] == 0) {
				for (int k = 0; k < 4; k ++) {
					int tx = i + dx[k], ty = j + dy[k];
					if (tx < 1 || tx > 19 || ty < 1 || ty > 19) continue;
					ans += mp[tx][ty] == 1;
				}
			}
		}
	}
	cout << ans << '\n';
}
signed main() {
	int t;
	cin >> t;
	while (t --) {
		solve();
	}
	
	
	return 0;
}
/*
4
0 0
1 1
2 4
4 2




4
1 1
2 2
3 3
2 4


*/