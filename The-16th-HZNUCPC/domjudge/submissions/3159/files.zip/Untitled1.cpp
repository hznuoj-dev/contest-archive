#include<bits/stdc++.h>
using namespace std;
int m[21][21];
int dis[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int vis[20][20];
long long temp=0;
int c;
long long ans=0;
void dfs(int x,int y){
	vis[x][y]=1;
	for(int i=0;i<4;i++){
		if(m[x+dis[i][0]][y+dis[i][1]]==0){
			temp++;
		}else if(m[x+dis[i][0]][y+dis[i][1]]==c&&vis[x+dis[i][0]][y+dis[i][1]]==0){
			dfs(x+dis[i][0],y+dis[i][1]);
		}
	}
}
void check(int x,int y){
	if(!m[x+1][y])ans++;
	if(!m[x-1][y])ans++;
	if(!m[x][y+1])ans++;
	if(!m[x][y-1])ans++;
}
int main(){
	int t;
	cin>>t;
	while(t--){
		for(int i=0;i<=20;i++){
			for(int j=0;j<=20;j++){
				if(i==0||j==0||i==20||j==20){
					m[i][j]=-1;
				}else{
					m[i][j]=0;
				}
			}
		}
		int n;
		cin>>n;
		while(n--){
			int x,y;
			cin>>x>>y>>c;
			m[x][y]=c;
			if(c==1)
				c=2;
			else if(c==2)
				c=1;
			for(int i=0;i<4;i++){
				if(m[x+dis[i][0]][y+dis[i][1]]==c){
					for(int i=1;i<=19;i++){
						for(int j=1;j<=19;j++){
							vis[i][j]=0;
						}
					}
					temp=0;
					dfs(x+dis[i][0],y+dis[i][1]);
					if(!temp){
						for(int i=1;i<=19;i++){
							for(int j=1;j<=19;j++){
								if(vis[i][j]==1){
									m[i][j]=0;
								}
							}
						}
					}
				}
			}
			ans=0;
			for(int i=1;i<20;i++){
				for(int j=1;j<20;j++){
					if(m[i][j]==1){
						check(i,j);
					}
				}
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}