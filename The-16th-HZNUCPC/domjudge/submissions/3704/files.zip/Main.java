import java.util.ArrayList;
import java.util.Scanner;


public class Main {
	public static String createString (String s) {
		String res = "^#";
		for (int i = 0; i < s.length(); i++)
			res += s.charAt(i) + "#";
		
		res += "$";
		return res;
			
	}
	
	public static int mlc (String s) {
		s = createString(s);
		
		int len = s.length();
		
		int r = 0, mid = 0;
		int[] p = new int[len];
		
		for (int i = 1; i < len - 1; i++) {
			int mirror = 2 * mid - i;
			if (r > i) {
				p[i] = Math.min(p[mirror], r - i);
			}
			else{
				p[i] = 0;
			}
			
			while (s.charAt(i - 1 - p[i]) == s.charAt(i + 1 + p[i])) p[i]++;
			
			if (i + p[i] > r) {
				mid = i;
				r = i + p[i];
			}
		}
		
		int mx = 0;
		for (int i = 1; i < len - 1; i++) {
			if (p[i] > mx) mx = p[i];
		}
		
		return mx;
	}
	
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		int n=sc.nextInt();
		
		while(n-->0){
		String sb = sc.next();  
		int max=mlc(sb);
		for(int x=0;x<sb.length()-1;x++){
			StringBuffer st = new StringBuffer(sb);
			String a = st.substring(x,x+2);
		    StringBuffer sb2 = new StringBuffer(a).reverse();
			sb2 = st.replace(x, x+2,sb2.toString());
			max=Math.max(mlc(sb2.toString()), max);
		}
		if(max==1)
			max=0;
		System.out.println(max);
		}
	}
}