#include<bits/stdc++.h>
using namespace std;
int vis1[30];
int vis2[30];
const int N = 1e9+10;
int main(){
	string s1,s2;
	cin>>s1>>s2;
	int len = s1.size();
	int cnt1 = 0,cnt2 = 0;
	int ans = 0;
	for(int i=0;i<len;i++){
		if(!vis1[s1[i]-'a']) cnt1++;
		if(!vis2[s2[i]-'a']) cnt2++;
		vis1[s1[i]-'a']++;
		vis2[s2[i]-'a']++;
	}
	for(int i=0;i<len;i++){
		vis1[s2[i]-'a'] ++;
		if(vis1[s2[i]-'a'] == 1) cnt1++;
		vis1[s1[i]-'a'] --;
		if(!vis1[s1[i]-'a']) cnt1--;
		vis2[s1[i]-'a'] ++;
		if(vis2[s1[i]-'a']==1) cnt2++;
		vis2[s2[i]-'a'] --;
		if(!vis1[s2[i]-'a'])  cnt2--;
		for(int j=i+1;j<len;j++){
			vis1[s2[j]-'a'] ++;
			if(vis1[s2[j]-'a'] == 1) cnt1++;
			vis1[s1[j]-'a'] --;
			if(!vis1[s1[j]-'a']) cnt1--;
			vis2[s1[j]-'a'] ++;
			if(vis2[s1[j]-'a']==1) cnt2++;
				vis2[s2[j]-'a'] --;
			if(!vis1[s2[j]-'a'])  cnt2--;
			if(cnt1 == cnt2) ans++;
			
				vis1[s2[j]-'a'] --;
			if(!vis1[s2[j]-'a']) cnt1--;
			vis1[s1[j]-'a'] ++;
			if(vis1[s1[j]-'a']==1) cnt1++;
			vis2[s1[j]-'a'] --;
			if(!vis2[s1[j]-'a']) cnt2--;
				vis2[s2[j]-'a'] ++;
			if(vis1[s2[j]-'a']==1)  cnt2++;
		}
		vis1[s2[i]-'a'] --;
		if(!vis1[s2[i]-'a']) cnt1--;
		vis1[s1[i]-'a'] ++;
		if(vis1[s1[i]-'a']==1) cnt1++;
		vis2[s1[i]-'a'] --;
		if(!vis2[s1[i]-'a']) cnt2--;
		vis2[s2[i]-'a'] ++;
		if(vis1[s2[i]-'a']==1)  cnt2++;
	}
	cout<<ans%N<<endl;
	return 0;
}