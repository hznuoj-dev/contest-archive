#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
int a[21][21];
#define ll long long 
ll gcd(ll a, ll b)
{
	return b == 0 ? a : gcd(b, a % b);
}
int main()
{
	std::ios::sync_with_stdio(false); 
	cin.tie(0), cout.tie(0);
	int n, m;
	cin >> n >> m;
	if (gcd(n, m) == 1) cout << "YES" << endl;
	else cout << "NO" << endl;	 
	/*int t;
	cin>>t;
	while(t--)
	{
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			cin>>x>>y>>c;
			a[x][y]=c;
		}
		for(int i=1;i<=19;i++)
		for(int j=1;j<=19;j++)
		{
			if()
		}
	}*/
	return 0;
}