#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
ll n, k;

int main()
{
	scanf("%lld %lld", &n, &k);
	if(n <= k) {
		puts("NO");
		return 0;
	}
	for(int i = 2; i <= sqrt(n); i++) {
		if(n % i == 0) {
			if(k >= i) {
				puts("NO");
				return 0;
			}
			break;
		}
	}
	puts("YES");	
	return 0;
}