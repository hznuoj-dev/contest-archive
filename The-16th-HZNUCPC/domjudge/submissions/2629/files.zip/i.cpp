#include "bits/stdc++.h"
typedef long long int ll;
using namespace std;
 
const int N = 25;
int arr[N+1][N+1];

string process(string &s){
    string s2;
    int n = s.size();
    int m = n * 2 + 3;
    s2.reserve(m);
    s2.push_back('!');
    for(int i = 0; i < n;i++) {
        s2.push_back('#');
        s2.push_back(s[i]);
    }
    s2.push_back('#');
    s2.push_back('$');
    return s2;
}

void solve(){
    string s;
    cin >> s;


    int n = s.size();
    int m = n * 2 + 3; 
    string s2 = process(s);
    vector<int> mp(m);
    int mx= 0, id = 0;
    int ans = 0;
    for(int i = 0; i < m ;i++) {
        mp[i] = mx > i ? min(mp[id*2-i], mx-i): 1;
        while (s2[i+mp[i]] == s2[i-mp[i]]) {
            mp[i]++;
        }
        if(i+mp[i] > mx) {
            mx = i + mp[i];
            id = i;
        }
    }
    // for(int i = 0; i < m; i++) {
    //     cout << s2[i] <<" \n"[i==m-1];
    // } 
    // for(int i = 0; i < m; i++) {
    //     cout << mp[i] <<" \n"[i==m-1];
    // } 

    for(int i = 1; i < m;i++) {
        char c1, c2;
        int k = 0;
        int edge = mp[i] ;
        int ok = 0;
        int a = 0;
        // ans = max(ans,mp[i]);
        while (i - edge >= 0 && i + edge < m) {
            if(s2[i-edge] != s2[i+edge]) {
                k++;
                if(k ==1) {
                    c1 = s2[i-edge];
                    c2 = s2[i+edge];
                    // cout <<"c1 and c2: "<<c1 <<" : "<< c2 << endl;
                    


                }
                if( k == 2) {
                    // cout << i <<": "<< "OK3 " << s2[i+edge] << "  "<< s2[i-edge] <<"  "<<   c1 <<" : "<< c2  << endl;
                    if( (c1 == s2[i+edge] && c2 == s2[i-edge]) || (c1 == s2[i-edge] && c2 == s2[i+edge])) {
                        // cout <<"OK 2" <<endl;
                    }else {
                        if(s2[i] == '#'){
                            a = max(a, mp[i] -1  );
                        }else {
                            // odd 
                            a = max(a, mp[i] -1 );
                        }
                        ok = 1;
                        break;
                    }
                }
                if( k == 3) {
                    // even 
                    if(s2[i] == '#'){
                        a = max(a, edge -1  );
                    }else {
                        // odd 
                        a = max(a, edge -1 );
                    }
                    // ans = max(ans, edge - 1);
                    break;
                }
            }
           
            
            edge++;
        }
        if(!ok && k == 2) {
            // cout <<"OK" << endl;
            if(s2[i] == '#'){
                    a = max(a, edge -1   );
                }else {
                    // odd 
                    a = max(a, edge -1  );
                }
            // ans = max(ans, edge-1);
        }else if (k == 1) {
            a = max(a, mp[i] - 1);
        }
        ans = max(ans, a);
    }
   
  for(int i = 1; i < m;i++) {
        char c1, c2;
        int k = 0;
        int edge = mp[i] ;
        int ok = 0;
        int a = 0;
        // ans = max(ans,mp[i]);
        while (i - edge >= 0 && i + edge < m) {
            if(s2[i-edge] != s2[i+edge]) {
                k++;
                if(k ==1) {
                    c1 = s2[i-edge];
                    c2 = s2[i+edge];
                    // cout <<"c1 and c2: "<<c1 <<" : "<< c2 << endl;
                    if( s2[i] == c1 || s2[i] == c2) {
                        k = 2;
                    } 


                }
                if( k == 2) {
                    // cout << i <<": "<< "OK3 " << s2[i+edge] << "  "<< s2[i-edge] <<"  "<<   c1 <<" : "<< c2  << endl;
                    if( (c1 == s2[i+edge] && c2 == s2[i-edge]) || (c1 == s2[i-edge] && c2 == s2[i+edge])) {
                        // cout <<"OK 2" <<endl;
                    }else {
                        if(s2[i] == '#'){
                            a = max(a, mp[i] -1  );
                        }else {
                            // odd 
                            a = max(a, mp[i] -1 );
                        }
                        ok = 1;
                        break;
                    }
                }
                if( k == 3) {
                    // even 
                    if(s2[i] == '#'){
                        a = max(a, edge -1  );
                    }else {
                        // odd 
                        a = max(a, edge -1 );
                    }
                    // ans = max(ans, edge - 1);
                    break;
                }
            }
           
            
            edge++;
        }
        if(!ok && k == 2) {
            // cout <<"OK" << endl;
            if(s2[i] == '#'){
                    a = max(a, edge -1   );
                }else {
                    // odd 
                    a = max(a, edge -1  );
                }
            // ans = max(ans, edge-1);
        }else if (k == 1) {
            a = max(a, mp[i] - 1);
        }
        ans = max(ans, a);
    }

   if(ans == 1) {
       ans = 0;
   }
    cout <<  ans   <<endl;





    return ;


}



int main (){
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    int t = 1;
    cin >> t;
    while (t--){
        solve();
    }

    return 0;
}
/*

5
abaaba
abccab
ihi
stfgfiut
palindrome
 

4
abccab
7
ihi
5
stfgfiut
6
palindrome
4


4
abccab
1 1 2 1 2 1 2 3 2 1 2 1 2 1 1
7
ihi
1 1 2 1 4 1 2 1 1
5
stfgfiut
1 1 2 1 2 1 2 1 4 1 2 1 2 1 2 1 2 1 1
6
palindrome
1 1 2 1 2 1 2 1 2 1 2 1 2 1 2 1 2 1 2 1 2 1 1
4
xxxyxababay
1
xxxyxababayx


1
aaaass


bxxbccaxxa
*/