#include <bits/stdc++.h>
using namespace std;
const int N = 100010;
typedef long long ll;
#define int ll
const int B = 233;
const int M1 = 1e9+7;
const int M2 = 1e9+81;

ll hs[N],hs2[N],powb[N];
int t;
int mp[35][35];
int n;
signed main(){
	cin >> t;
	while(t--){
		memset(mp,0,sizeof mp);
		int ans = 0;
		cin >> n;
		for(int i = 1;i<=n;i++){
			int x,y,color;
			cin >> x >> y >> color;
			mp[x][y] = 1;
		} 
		for(int i = 1;i<=30;i++){
			for(int j = 1;j<=30;j++){
				if(mp[i][j] == 1){
					if(mp[i+1][j] == 0){
						mp[i+1][j] = 2;
						ans++;
					}
					if(mp[i-1][j] == 0){
						mp[i-1][j] = 2;
						ans++;
					}
					if(mp[i][j-1] == 0){
						mp[i][j-1] = 2;
						ans++;
					}
					if(mp[i][j+1] == 0){
						mp[i][j+1] = 2;
						ans++;
					}
				}
			}
		}
		cout << ans << endl;
	}
}