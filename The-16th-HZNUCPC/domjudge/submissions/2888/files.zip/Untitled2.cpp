#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int maxn=1e4+10;
string s1,s2;
int ma1[50],ma2[50];
struct NODE{
	int x,y;
}no[110];

void solve(){
	int n,ans=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>no[i].x>>no[i].y;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int z=1;z<=n;z++)
			if(i!=j&&j!=z&&((no[j].y-no[z].y)*(no[j].x-no[i].x)!=(no[j].y-no[i].y)*(no[j].x-no[z].x)))
			{
				int tmp1=__gcd(abs(no[i].x-no[j].x),abs(no[i].y-no[j].y));
				int tmp2=__gcd(abs(no[i].x-no[z].x),abs(no[i].y-no[z].y));
				int tmp3=__gcd(abs(no[j].x-no[z].x),abs(no[j].y-no[z].y));
				if(tmp1+tmp2+tmp3>ans)
					ans=tmp1+tmp2+tmp3;
				
			}
		}
	}
	cout<<ans<<endl;
	

	
}
signed main(){
	int T;
	solve();
	return 0;
} 