#include <bits/stdc++.h>
#define ln '\n'

typedef std::array<int,2> Point;

Point operator -(Point a, Point b) { 
	return {a[0] - b[0], a[1] - b[1]};
}

inline long long calc(Point a) {
	return abs(std::__gcd(a[0], a[1]));
}

inline bool check(Point a, Point b, Point c) {
	Point x=a-b,y=a-c;
	return (x[1]*y[0]-x[0]*y[1])!=0;
}

inline void solve() {
	
	int n;
	std::cin>>n;
	std::vector<Point> a(n);
	for(int i = 0; i < n; i++) 
		std::cin >> a[i][0] >> a[i][1];
		
	long long ans = 0;
	
	for(int i = 0; i < n; i++) 
		for(int j = i + 1; j < n; j++) 
			for(int k = j + 1; k < n; k++) 
				if(check(a[i], a[j], a[k]))
					ans = std::max(ans, calc(a[i] - a[j]) + calc(a[j] - a[k]) + calc(a[k] - a[i]));
	
	std::cout << ans << ln;
	
}

int main() {
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	solve();
}