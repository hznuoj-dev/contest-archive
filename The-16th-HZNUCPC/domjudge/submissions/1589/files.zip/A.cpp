#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define IO ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
const ll mode=1e9+7;
const int maxn=1e5+10;
//---------------------------
struct node
{
    ll x,y;
    bool operator<(const node&o)const
    {
        return x<o.x;
    }
};
struct Point
{
    ll x,y;
    Point(ll x=0,ll y=0):x(x),y(y){}

};
Point operator -(Point A,Point B)
{
        return Point(abs(A.x-B.x),abs(A.y-B.y));
}
double Dot (Point A,Point B)
{
    return A.x*B.x+A.y*B.y;
}
double Length(Point A)
{
    return sqrt(1.0*Dot(A,A));
}
double Angle(Point A,Point B)
{
    return acos(1.0*Dot(A,B)/Length(A)/Length(B));
}
Point a[200];
int n;
ll gcd(ll a,ll b)
{
    return b==0?a:gcd(b,a%b);
}
//----------------------
void solve()
{
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i].x>>a[i].y;
    }
    ll ans=0;
    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            for(int k=j+1;k<=n;k++)
            {
                Point A,B,C;
                A=a[i]-a[j],B=a[j]-a[k],C=a[i]-a[k];
                double e=Angle(a[i]-a[j],a[j]-a[k]);
                //printf("%.15lf\n",e);
                if(e>=1e-7)
                {
                    //cout<<A.x<<" "<<A.y<<" "<<B.x<<" "<<B.y<<" "<<C.x<<" "<<C.y<<endl;
                    ll ans2=gcd(abs(A.x),abs(A.y))+gcd(abs(B.x),abs(B.y))+gcd(abs(C.x),abs(C.y));
                    if(ans2>ans)ans=ans2;
                }
            }
        }
    }
    if(ans<3)ans=0;
    cout<<ans<<endl;
}
int main()
{
    IO;
    int tn=1;
    //cin>>tn;
    while(tn--)
    {
        solve();
    }
    return 0;
}
