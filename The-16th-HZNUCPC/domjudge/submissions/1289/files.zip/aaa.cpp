#include<bits/stdc++.h>
using namespace std;
int a[21][21]{{0}};
typedef long long ll;
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		cin>>n;
		while(n--){
			int x,y,c;
			scanf("%d%d%d",&x,&y,&c);
			a[x][y]=c;
			
		}
		ll ans=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(a[i][j]==1){
					if(a[i][j-1]!=1&&j-1>=1){//zuo找
						ans++;
					
					}
					if(a[i][j+1]!=1&&j+1<=19){//you
						ans++;
						
					}
					if(a[i+1][j]!=1&&i+1<=19){//xia
						ans++;
						
						
					}
					if(a[i-1][j]!=1&&i-1>=1){
						ans++;
					}
				}
				
			}
			
		}
		cout<<ans<<endl;
	}
}