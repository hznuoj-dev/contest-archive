#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;
typedef long long ll;

int gcd(ll a,ll b){return b==0?a:gcd(b,a%b);
}

int vis[21][21];
int heix[400];
int heiy[400];

void solve(){
	
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			vis[i][j]=0;
		}
	}
	
	for(int i=0;i<=20;i++){
		vis[0][i]=-1;
		vis[20][i]=-1;
		vis[i][0]=-1;
		vis[i][20]=-1;
	}
	
	int c=0;//chess
	cin>>c;
	
	int h=0;//heiqi
	
	for(int i=0;i<c;i++){
		
		int x=0, y=0;
		cin>>x>>y;
		
		int op=0;//option
		cin>>op;
		
		if(op==1){
			vis[x][y]=1;
			heix[h]=x;
			heiy[h]=y;
			h++;
		}else{
			vis[x][y]=-1;
		}
		
	}
	
	int cnt=0;
	
	for(int i=0;i<h;i++){
		if(vis[heix[i]-1][heiy[i]]==0){
			cnt++;
		}
		if(vis[heix[i]+1][heiy[i]]==0){
			cnt++;
		}
		if(vis[heix[i]][heiy[i]-1]==0){
			cnt++;
		}
		if(vis[heix[i]][heiy[i]+1]==0){
			cnt++;
		}
		
	}
	
	/*
	for(int i=0;i<h;i++){
		if(vis[heix[i]-1][heiy[i]]==1||vis[heix[i]+1][heiy[i]]==1||vis[heix[i]][heiy[i]-1]==1||vis[heix[i]][heiy[i]+1]==1){
			if(vis[heix[i]][heiy[i]]==0){
				cnt++;
				}
		}
	}
	
	
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(vis[i-1][j]==1||vis[i+1][j]==1||vis[i][j-1]==1||vis[i][j+1]==1){
				
				if(vis[i][j]==0){
				cnt++;
				}
				
			}
		}
	}*/
	
	cout<<cnt<<"\n";
	
	//system("pause");
}

int main(){
	
	int t = 1;
	cin >> t;
	while(t--){
		solve();
	}
	
	return 0;
}