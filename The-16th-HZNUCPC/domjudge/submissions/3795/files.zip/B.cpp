#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
inline void run()
{
    while(cin>>n>>m)
    {
    	if(m==1)
	    {
	    	cout<<"YES"<<'\n';
	    	return;
		}
	   	ll k=n%m;
		while(k>1) k=n%k;
		if(k==1) cout<<"YES"<<'\n';
		else cout<<"NO"<<'\n';
	}
}
int main()
{
//	ll T;
//	cin>>T;
//	while(T--)
	run();
}
