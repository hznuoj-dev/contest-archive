#include<iostream>
using namespace std;
int main()
{
	long long m,n;
	cin>>m>>n;
	if(n%m==0)
	cout<<"NO"<<endl;
	else
	cout<<"YES"<<endl;
	return 0;
}