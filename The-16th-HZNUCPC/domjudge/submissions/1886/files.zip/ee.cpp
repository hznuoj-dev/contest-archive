#include<bits/stdc++.h>
using namespace std;

void solve(){
    int n,max=0;
    long long x[110],y[110],a[110][110];
    double k;
    cin>>n;
    for(int i=1;i<=n;i++)cin>>x[i]>>y[i];
    for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++){
			long long xl,yl;
			xl=x[i]-x[j];
			if(xl<0)xl=-xl;
			yl=y[i]-y[j];
			if(yl<0)yl=-yl;
			a[i][j]=__gcd(xl,yl)-1;
			a[j][i]=a[i][j];
		}
	int flag=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int z=j+1;z<=n;z++){
				if((x[j]-x[i])*(y[z]-y[j])!=(y[j]-y[i])*(x[z]-x[j])){
					int ans;
					ans=a[i][j]+a[i][z]+a[j][z];
					if(ans>max)max=ans;
					flag=1;
		 		}
			}
		}
	}
	if(flag)cout<<max+3<<endl;
	else cout<<0;
}

int main(){
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
}
