#include<bits/stdc++.h>
#define endl '\n'
using namespace std;

typedef long long ll;
const ll N = 1e7 + 7;
ll _, prime[N],tot, isprime[N];
ll n,m;

void getprime(){
	for (int i = 2; i < N; i++)isprime[i] = 1;
	for (int i = 2; i < N; i++){
		if (isprime[i])prime[++tot] = i;
		for (int j = 1; j <= tot; j++){
			if (i * prime[j] >= N)break;
			isprime[i * prime[j]] = 0;
			if (i % prime[j] == 0)break;
		}
	}
}

void solve(){
	cin >> n >> m;
	ll flag = 0;
	getprime();
	for (int i = 1; i <= tot && n > 1; i++){
		if (n % prime[i] == 0){
			while (n % prime[i] == 0)n /= prime[i];
			if (prime[i] <= m){
				flag = 1;
				break;
			}
		}
	}
	if (n > 1 && n <= m)flag = 1;
	if (flag)cout << "NO";
	else cout << "YES";
	cout <<endl;
}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	//cin >> _;
	_ = 1;
	while(_--)solve();
}