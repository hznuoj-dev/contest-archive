a,b= map(int,input().split(" "))
if(a > b):
    t = a
    a = b
    b = t
    
while(a % b != 0):
    t = a
    a = b
    b = t%b
if b == 1:
    print("YES")
else:
    print("NO")
