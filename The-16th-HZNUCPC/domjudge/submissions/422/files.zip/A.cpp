#include<bits/stdc++.h>
using namespace std;
const int N = 400;
int a[N][N];
bool st1[N][N],st2[N][N];
int dx[]={1,0,-1,0},dy[]={0,1,0,-1};
int main()
{
	int T;
	cin>>T;
	while(T--)
	{
		int n;
		cin>>n;
		memset(st1,0,sizeof st1);
		memset(st2,0,sizeof st2);
		for(int i=1;i<=n;i++)
		{
			int a,b,c;
			cin>>a>>b>>c;
			if(c==1) st1[a][b]=1;
			else st2[a][b]=1;
		}
		int ans=0;
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(st1[i][j])
				{
					for(int k=0;k<4;k++)
					{
						int x=i+dx[k],y=j+dy[k];
						if(x>=1 && x<=19 && y>=1 && y<=19 && !st1[x][y] && !st2[x][y])
						{
							ans++;
						}
					}
				}
			}
		}
		cout<<ans<<endl;
	}
	
}
