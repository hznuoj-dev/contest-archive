#include <bits/stdc++.h>
using namespace std;
const int N=1e6+10;

int a[300][300];
int f[300][300];

long long sum=0;

int dx[4]={0,1,-1,0};
int dy[4]={1,0,0,-1};


void bfs(int i,int j)
{	//枚举上下左右的四个位置
	for (int h=0;h<=3;h++)
	{
		int xx=i+dx[h],yy=j+dy[h];
		
		if (a[xx][yy]==0&&f[xx][yy]==0&&xx<=19&&xx>=0&&yy<=19&&yy>=0)//如果搜索到空
		{	
			sum=sum+1;
			f[xx][yy]=1;
		}
	}
}

int main()
{	
	int T,n;
	cin>>T;

	while (T--)
	{
		scanf("%d",&n);
		
		memset(f,0,sizeof f);
		memset(a,0,sizeof a);
		sum=0;
		
		
		int x,y,ys;
		//读入   0-无 1-白 2-黑
		for (int i=1;i<=n;i++)
			scanf("%d%d%d",&x,&y,&ys),a[x][y]=ys;
		
		
		for (int i=1;i<=30;i++)
			for (int j=1;j<=30;j++)
				if (a[i][j]==1&&f[i][j]==0)
					bfs(i,j),f[i][j]=1;
			
		printf("%lld\n",sum);
	}
	
	return 0;
}