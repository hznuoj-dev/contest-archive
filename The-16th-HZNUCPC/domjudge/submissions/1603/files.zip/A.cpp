#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
const ll mod = 1e9 + 7;
ll a[30],b[30];
int main ()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    //cin >> tt;
    while (tt--)
    {
        string s,t;
        cin >> s >> t;
        int n = s.size();
        ll now = 0;
        for (int i = 0; i < n; ++i)
        {
            int x = s[i] - 'a';
            int y = t[i] - 'a';
            a[x]++;
            b[y]++;
        }
        ll ans = 0;
        for (int i = 0; i < 26; ++i)
        {
            if (a[i]) ++now;
            if (b[i]) --now;
        }
        //cout << now << "\n";
        map<ll,ll>mp;
        for (int i = 0; i < n; ++i)
        {
            int x = s[i] - 'a';
            int y = t[i] - 'a';
            ll xz=0;
            if (a[x] == 1) --xz;
            if (b[x] == 0) --xz;
            if (b[y] == 1) ++xz;
            if (a[y] == 0) ++xz;
            //cout << xz << '\n';
            mp[xz]++;
        }
        for (auto [u,v]:mp)
        {
            for (auto [z,y]:mp)
            {
                if (z < u) continue;
                if (u+z+now==0)
                {
                    if (u != z)
                        ans = (ans + 1ll*v*y) % mod;
                    else
                        ans = (ans + 1ll*v*(v-1)/2) % mod;
                }
            }
        }
        cout << ans << "\n";
    }

}
