#include<bits/stdc++.h>
using namespace std;
using ll=long long;

ll x[1000],y[1000];

ll f(int a,int b){
	if(x[a]==x[b]) return abs(y[a]-y[b])-1;
	if(y[a]==y[b]) return abs(x[a]-x[b])-1;
	ll xx=abs(x[a]-x[b]);
	ll yy=abs(y[a]-y[b]);
	return __gcd(xx,yy)-1;
}
bool check(int i, int j, int k) {
	if (x[i] == x[j] && x[i] == x[k]) return 0;
	if (y[i] == y[j] && y[i] == y[k]) return 0;
	if ((1ll * (x[i] - x[j]) * (y[j] - y[k])) == (1ll * (x[j] - x[k]) * (y[i] - y[j]))) return 0;
	return 1;
}
int main() {
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int n;
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>x[i]>>y[i];
	}
	ll ans=0;
	for(int i=0;i<n;++i){
		for(int j=i+1;j<n;++j){
			for(int k=j+1;k<n;++k){
				if (!check(i,j,k)) continue;
				ans=max(ans,f(i,j)+f(j,k)+f(k,i)+3);
			}
		}
	}
	cout<<ans<<'\n';
}