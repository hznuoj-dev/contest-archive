#include <stdio.h>

int main()
{
	int X[]={0,0,-1,1};
	int Y[]={1,-1,0,0};
	int n,m;
	scanf("%d%d",&n,&m);
	int point[m][3];
	int k = 0;
	for(k=0;k<n;k++){
		int bool[19][19];
		int x,y;
		for(x=0;x<19;x++)
			for(y=0;y<19;y++)
				bool[x][y] = 0;
		int i;
		for(i = 0;i<m;i++){
			scanf("%d%d%d",&point[i][0],&point[i][1],&point[i][2]);
			if(point[i][2]==1){
				bool[point[i][0]-1][point[i][1]-1]=1;
			}else{
			    bool[point[i][0]-1][point[i][1]-1]=2;
			}
		}
		int ans=0;
		for( i = 0;i<m;i++){
			if(point[i][2]==1){//黑点
			int j;
			for(j=0;j<4;j++){
			int newX=point[i][0]-1+X[j];
			int newY=point[i][1]-1+Y[j];
			if(newX>=0&&newX<=18&&newY>=0&&newY<=18){
				if(bool[newX][newY]==0){
//					printf("%d  %d\n",newX,newY);
					ans++;
				}
//				else if(bool[newX][newY]==2){
////					bool[newX][newY]=0;
//				}  
			}
			}
			}
			}
				printf("%d\n",ans);

		}
		}
		