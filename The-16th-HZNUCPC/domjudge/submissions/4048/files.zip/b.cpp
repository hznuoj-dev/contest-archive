#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int read(){
    int x=0,f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c))x=x*10+c-48,c=getchar();
    return x*f;
}
const int N=1e5+5;
int n,q,m,fa[N<<1],sz[N<<1],f[N<<1],vis[N<<1];
int find(int x){
    return x==fa[x]?x:fa[x]=find(fa[x]);
}
void merge(int x,int y){
    x=find(x);y=find(y);
    if(x==y)return;
    if(x<y)swap(x,y);
    fa[x]=y;sz[y]+=sz[x];f[y]+=f[x];
}
bitset<N>g[N];
vector<int>ans[N<<1];
vector<pair<int,int> >c;
vector<pair<int,int> >v;
void print(int x){
    // printf("%lld:\n",x);
    for(int i:ans[x])printf("%lld ",i);
    // puts("");
}
void dfs(int x,int sum)
{
    //printf("%lld %lld\n",x,sum);
    if(x==0)return;
    if(sum-v[x-1].first>=0&&g[x-1][sum-v[x-1].first]) dfs(x-1,sum-v[x-1].first),print(c[x-1].first);
    else dfs(x-1,sum-v[x-1].second),print(c[x-1].second);
}
signed main(){
    //freopen("in.txt","r",stdin);
   // freopen("b.out","w",stdout);
    n=read();q=read();m=read();
    for(int i=1;i<=(n<<1);i++)fa[i]=i,sz[i]=1,f[i]=(i<=n);
    for(int i=1;i<=m;i++){
        int op=read(),a=read(),b=read();
        //if(op==1&&a==b){puts("NO");return 0;}
        if(op==0){
            merge(a,b);
            merge(a+n,b+n);
        }else{
            merge(a,b+n);
            merge(b,a+n);
        }
    }
    for(int i=1;i<=n;i++)if(find(i)==find(i+n)){puts("NO");return 0;}
   // puts("qwq");
    for(int i=1;i<=n;i++)if(find(i)==i){
        if(vis[i]||vis[find(i+n)])continue;
        v.push_back({f[i],f[find(i+n)]}),c.push_back({i,find(i+n)});
        vis[i]=vis[find(i+n)]=1;
    }
    for(int i=1;i<=n;i++)ans[find(i)].push_back(i);
    int cnt=v.size();
    g[0][0]=1;
    //for(int i=1;i<=cnt;i++)printf("%lld %lld\n",v[i-1].first,v[i-1].second);puts("");
    //for(int i=1;i<=cnt;i++)printf("%lld %lld\n",c[i-1].first,c[i-1].second);puts("");
    for(int i=1;i<=cnt;i++)g[i]=(g[i-1]<<v[i-1].first)|(g[i-1]<<v[i-1].second);
    //for(int i=1;i<=n;i++)printf("%lld ",g[cnt][i]==1);puts("");
    if(!g[cnt][q]){puts("NO");return 0;}
    puts("YES");
    dfs(cnt,q);
    return 0;
}