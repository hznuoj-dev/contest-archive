#include<bits/stdc++.h>
using namespace std;
#define int long long
struct ll{
	double x,y;
}q[105];

void solve(){
	int x,y;
	cin>>x>>y;
	if(x>y){
		x%=y;
	}
	if(x==0){
		cout<<"NO"<<endl;
		return ;	
	}
	if(x<y){
		if(y%x==0){
			cout<<"NO"<<endl;
		}else{
			cout<<"YES"<<endl;
		}
		return ;
	}
}

signed main(){
//	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}