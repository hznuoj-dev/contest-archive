#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int>p;
typedef long long ll;
int gcd(int x,int y){
	if(x<y)swap(x,y);
	if(y==0)return x;
	return gcd(y,x%y);
}

int getNodSize(p a,p b){
	int pa=abs(a.first-b.first);
	int pb=abs(a.second-b.second);
	int g= gcd(pa,pb);
	if(g==1)return 0;
	return min(pa/g,pb/g);
}
bool gx(p a,p b,p c){
	p ab={b.first-a.first,b.second-a.second};
	p ac={c.first-a.first,c.second-a.second};
	return ab.first*ac.second==ab.second*ac.first;
	
//	if(c.first<b.first)swap(c,b);
//	if(b.first <a.first)swap(a,b);
//	if(c.first<b.first)swap(c,b);
//	int aa=c.first-a.first;
//	int bb=c.second-a.second;
//	int ga= gcd(abs(aa),abs(bb));
//	p pa={aa/ga,bb/ga};
//	aa=c.first-b.first;
//	bb=c.second-b.second;
//	int gb=gcd(abs(aa),abs(bb));
//	p pb={aa/ga,bb/ga};
//	return pa==pb;	
}
map<p,int>m;
vector<p>v;
void solve(){
	int n;cin>>n;
	for(int i=0;i<n;i++){
		int a,b;cin>>a>>b;
		v.push_back({a,b});
	}
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(i==j)continue;
			int s=getNodSize(v[i],v[j]);
			m[{i,j}]=s;
			m[{j,i}]=s;
		}
	}
	ll ans=0,temp;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(i==j)continue;
			for(int k=0;k<n;k++){
				if(k==j)continue;
				if(gx(v[i],v[j],v[k]))continue;
//				cout<<i<<' '<<j<<' '<<k<<endl;
				temp=m[{i,j}]+m[{j,k}]+m[{k,i}];
//				cout<<m[{i,j}]<<' '<<m[{j,k}]<<' '<<m[{k,i}]<<endl;
//				cout<<temp+3<<endl<<endl;
				ans=max(temp+3,ans);
			}
		}
	}
	cout<<ans;
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int t;
//	cin>>t;
//	while(t--)
		solve();
}