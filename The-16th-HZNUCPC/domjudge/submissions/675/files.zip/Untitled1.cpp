#include<iostream>
#include<cstring>
using namespace std;
int d[4]={-1,1,0,0};
int f[4]={0,0,-1,1};
int main(){
	int t;
	cin >> t;
	while(t--){
		int s[20][20]={0};
		int sum=0;
		int n;
		cin >> n;
		for(int i=0;i<n;i++){
			int x,y,c;
			cin >> x>>y>>c;
			if(c==1){
				s[x][y]=1;
				for(int j=0;j<4;j++){
					int bx=x-d[j];
					int by=y-f[j];
					if(bx>0&&bx<20&&by>0&&by<20){
						if(s[bx][by]!=1){
							s[bx][by]=-1;
							sum++;
						}
						else{
							sum--;
						}
					}
				}		
			}else{
				if(s[x][y]==-1) sum--;
			}
		}
		cout << sum << endl;
	}
}