#include <bits/stdc++.h>
using namespace std;

int main(){
	long long n,m,k;
	scanf("%lld%lld",&n,&m);
	k=m;
	if(m>=n)printf("NO");
	else while(k!=1){
		if(n%k==0){
			printf("NO");
			break;
		}
		else k=n%k;
		if(k==1)printf("YES");
	}
	return 0;
}