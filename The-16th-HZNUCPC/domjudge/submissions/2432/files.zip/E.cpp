#include <bits/stdc++.h>
using namespace std;
const int N=105;

struct d{
	int x;
	int y;
}a[N];

int s[N][N];
int ans=-2e9;

void suan(int i,int j)
{
	int x1=a[i].x,y1=a[i].y,x2=a[j].x,y2=a[j].y;
	int xx=x2-x1,yy=y2-y1;
	if (xx==0||yy==0)
	{
		if (xx)
			s[i][j]=xx-1,s[j][i]=xx-1;
		else
			s[i][j]==yy-1,s[j][i]=yy-1;
			
		return;
	}
	//除最大公约数
	
	int c=1;
	int n=abs(xx);
	int m=abs(yy);	
	
	
		while (n%m!=0)
		{	c=n%m;
			n=m;
			m=c;
		}	
		
	xx=xx/m;
	yy=yy/m;
	
	
	//
	
	
	
	
	int h=(x2-x1)/xx-1;
	s[i][j]=h;
	s[j][i]=h;
}

int main()
{	memset(s,-1,sizeof s);
	int n;
	cin>>n;
	for (int i=1;i<=n;i++)
	{
		cin>>a[i].x>>a[i].y;
	}
	
	for (int i=1;i<=n;i++)
		for (int j=1;j<=n;j++)
			if (s[i][j]==-1)
				suan(i,j);	
		
	
	for (int i=1;i<=n;i++)
		for (int j=i+1;j<=n;j++)
			for (int k=j+1;k<=n;k++)
			{	double k1,k2;
			
				if (a[i].x==a[j].x&&a[i].x==a[k].x&&a[k].x==a[j].x)
					continue;
				if (a[i].y==a[j].y&&a[i].y==a[k].y&&a[k].y==a[j].x)
					continue;
			
				k1=(a[i].y-a[j].y)*1.0/(a[i].x-a[j].x);
				k2=(a[k].y-a[j].y)*1.0/(a[k].x-a[j].x);
				
				if (k1==k2)
					continue;
				
				ans=max(ans,s[i][j]+s[i][k]+s[j][k]);
			}
				
				
	if (ans==-2e9)
		printf("0");
	else			
		printf("%d",ans+3);
	
	return 0;
}