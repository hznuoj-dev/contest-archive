#include <bits/stdc++.h>

using namespace std;
const int N = 22;
int way[][2] = {{0,1},{0,-1},{1,0},{-1,0}};
int d[N][N];
// bool st[N][N];
int n;

int main()
{
	int T;
	cin >> T;
	while (T--)
	{
		memset(d,0,sizeof d);
		// memset(st,0,sizeof st);
		cin >> n;
		vector<pair<int,int>> q;
		for (int i=1;i<=n;i++)
		{
			int x,y,c;
			cin >> x >> y >> c;
			d[x][y] = c;
			if (c==1)
			{
				q.push_back({x,y});
			}
		}
		int cnt = 0;
		for (auto i:q)
		{
			int r = i.first;
			int c = i.second;
			for (int j=0;j<4;j++)
			{
				int rr = r+way[j][0];
				int cc = c+way[j][1];
				if (rr>19 || rr==0 || cc>19 || cc==0) continue;
				// cout << rr << ' ' << cc << endl;
				// if (!st[rr][cc] && d[rr][cc]==0)
				if ( d[rr][cc]==0)
				{
					// st[rr][cc] = true;
					cnt ++;
				}
			}
		}
		cout << cnt << '\n';
	}
	
}