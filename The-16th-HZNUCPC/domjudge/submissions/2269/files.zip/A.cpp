#include<bits/stdc++.h>
using namespace std;

#define int long long

const int N = 2e3 +10, inf = 1e17, mod = 1e9 +7;

long long n, m, k, x, y, ans;
char s[N], p[N];

int v[N];
map<int,int>mp;

void run(){
    cin>>n>>m;
    assert(n>0);
    assert(m>0);
    ans = 0;
    if(m==1||n==1){
        cout<<"YES";
        return;
    }
    if(n<=m){
        cout<<"NO";
        return;
    }
    while(1){
        int k=n%m;
        if(k==0){
            cout<<"NO";
            return;
        }
        if(k==1){
            cout<<"YES";
            return;
        }
        m=k;
    }
    cout<<"NO";
    return;
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int T;
  //  for(cin>>T;T>0;T--)
    run();return 0;
}
