#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	ll n,m;
	cin>>n>>m;
	if(n>m){
	ll t=sqrt(n);
	for(ll i=2;i<=min(t,m);i++){
		if(n%i==0){
			cout<<"NO";
			return 0;
		}
	}
	cout<<"YES";
	return 0;
	}
	else{
		cout<<"NO";
		return 0;
	}
}