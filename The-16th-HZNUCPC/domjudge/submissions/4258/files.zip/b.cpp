#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const int N=1e3+10;
int n,m,n1,m1;
class DS2 {
#define ls (k<<1)
#define rs (ls|1)
   public:
	ll t1[300],t2[300];
	void upd(int L,int R,ll x,int k=1,int l=0,int r=m1) {
		t2[k]+=x*(R-L+1);
		if(L<=l && r<=R) return t1[k]+=x,void();
		int m=l+r>>1; 
		if(L>m) return upd(L,R,x,rs,m+1,r);
		if(R<=m) return upd(L,R,x,ls,l,m);
		upd(L,m,x,ls,l,m); upd(m+1,R,x,rs,m+1,r);
	}
	ll que(int L,int R,int k=1,int l=0,int r=m1) {
		if(L<=l && r<=R) return t2[k];
		int m=l+r>>1; ll ans=(R-L+1)*t1[k];
		if(L>m) return ans+que(L,R,rs,m+1,r);
		if(R<=m) return ans+que(L,R,ls,l,m);
		return ans+que(L,m,ls,l,m)+que(m+1,R,rs,m+1,r);
	}
};
class DS1 {
   public:
	DS2 t1[300],t2[300];
	void upd(int L,int R,int L2,int R2,ll x,int k=1,int l=0,int r=n1) {
		t2[k].upd(L2,R2,x*(R-L+1));
		if(L<=l && r<=R) return t1[k].upd(L2,R2,x),void();
		int m=l+r>>1; 
		if(L>m) return upd(L,R,L2,R2,x,rs,m+1,r);
		if(R<=m) return upd(L,R,L2,R2,x,ls,l,m);
		upd(L,m,L2,R2,x,ls,l,m); upd(m+1,R,L2,R2,x,rs,m+1,r);
	}
	ll que(int L,int R,int L2,int R2,int k=1,int l=0,int r=n1) {
		if(L<=l && r<=R) return t2[k].que(L2,R2);
		int m=l+r>>1; ll ans=(R-L+1)*t1[k].que(L2,R2);
		if(L>m) return ans+que(L,R,L2,R2,rs,m+1,r);
		if(R<=m) return ans+que(L,R,L2,R2,ls,l,m);
		return ans+que(L,m,L2,R2,ls,l,m)+que(m+1,R,L2,R2,rs,m+1,r);
	}
#undef ls
#undef rs
}ds[10][10];
int main() {
#ifdef LOCAL
    freopen(".in","r",stdin);
#endif
    ios::sync_with_stdio(0); cin.tie(0);
    int q;
    cin>>n>>m>>q;
    n1=(n-1)/10; m1=(m-1)/10;
    ll sum=0;
    For(i,0,n-1) For(j,0,m-1) {
    	ll x;cin>>x; sum+=x;
    	ds[i%10][j%10].upd(i/10,i/10,j/10,j/10,x);
	}
//	cerr<<ds[0][0].que(0,1,0,1)<<endl;
    while(q--) {
    	int o,L1,R1,L2,R2;ll x;
    	cin>>o>>L1>>L2>>R1>>R2>>x;
    	--L1; --R1; --L2; --R2;
    	if(o==1) {
    		sum+=x*(R1-L1+1)*(R2-L2+1);
    		For(i,0,9) For(j,0,9) {
    			int l1=(L1-i+19)/10-1,r1=(R1-i+10)/10-1,l2=(L2-j+19)/10-1,r2=(R2-j+10)/10-1;
    			if(l1>r1 || l2>r2) continue;
    			ds[i][j].upd(l1,r1,l2,r2,x);
			}
		} else {
			vector<ll>ch;
    		For(i,0,9) For(j,0,9) {
    			int l1=(L1-i+19)/10-1,r1=(R1-i+10)/10-1,l2=(L2-j+19)/10-1,r2=(R2-j+10)/10-1;
    			if(l1>r1 || l2>r2) continue;
//    			cerr<<l1<<" "<<r1<<" "<<l2<<" "<<r2<<endl;
    			ch.push_back(ds[i][j].que(l1,r1,l2,r2));
			}
			sort(ch.begin(),ch.end(),greater<ll>());
//			for(auto x:ch) cerr<<x<<" "; cerr<<endl;
			ll rs=sum;
			For(i,0,min(ll(ch.size()),x)-1) rs+=ch[i];
			cout<<rs<<"\n";
		}
	}
}