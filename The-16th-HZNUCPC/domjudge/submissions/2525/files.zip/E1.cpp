#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll  num[102][102],x[102],y[102];
ll n;
ll gcd(ll a,ll b)
{
    return b?gcd(b,a%b):a;

}
ll query(ll i,ll j)
{
    ll ggcd=1;
    ll x1=x[i],x2=x[j],y1=y[i],y2=y[j];
ll    dx=x1-x2;
  ll  dy=y1-y2;
    ggcd=gcd(abs(dx),abs(dy));
    dx/=ggcd;
    dy/=ggcd;
    ll num=0;
    if(dx==0)
    {
        num=abs((y1-y2)/dy)+1;
    }
    else
    {
        num=abs((x1-x2)/dx)+1;
    }
    return num;
}
bool check(ll  i,ll  j,ll k)
{

    ll  dx1,dx2,dy1,dy2;
    dx1=x[i]-x[j];
    dx2=x[j]-x[k];
    dy1=y[i]-y[j];
    dy2=y[j]-y[k];
    return (dx1*dy2==dy1*dx2);

}
int main()
{
    scanf("%lld",&n);
    for(ll i=0;i<n;i++)
    {
        scanf("%lld%lld",&x[i],&y[i]);
    }
    for(ll i=0;i<n;i++)
    {
        for(ll j=i+1;j<n;j++)
        {
            num[i][j]=query(i,j);
        }
    }
  //  for(ll i=0;i<n;i++)
 //   {
  //      for(ll j=i+1;j<n;j++)
  //      {
  //          printf("%lld",num[i][j]);
  //      }
 //       printf("\n");
   // }
    ll ans=0;
    for(ll i=0;i<n;i++)
    {
        for(ll j=i+1;j<n;j++)
        {
            for(ll k=j+1;k<n;k++)
            {
                if(!check(i,j,k))
                ans=max(ans,(num[i][j]*num[j][k]-num[i][k])/2+num[i][k]);
            }
        }
    }
    printf("%lld\n",ans);
}
