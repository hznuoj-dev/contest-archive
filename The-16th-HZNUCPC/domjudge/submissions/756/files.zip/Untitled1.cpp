#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
#define ll long long 
ll gcd(ll a, ll b)
{
	return b == 0 ? a : gcd(b, a % b);
}
ll x[N], y[N];
int main()
{
	std::ios::sync_with_stdio(false); 
	cin.tie(0), cout.tie(0);
	long long n, m;
	cin >> n >> m;
	if (m == 1) 
	cout<<"YES"<<endl;
	else if(n<=m)
	cout<<"NO"<<endl;
	else{
		int fl=0;
		for(int i=2;i<= n / i;i++)
		{
			if(n%i==0)
			{
				fl=1;
				if(i<=m)
				cout<<"NO"<<endl;
				else cout<<"YES"<<endl;
			}
		}
		if(fl==0)
		cout<<"YES"<<endl;
	}
	/*int n, m;
	cin >> n >> m;
	if (gcd(n, m) == 1) cout << "YES" << endl;
	else cout << "NO" << endl;	*/ 
/*	int n;
	cin >> n;
	ll ans = 0;
	for (int i = 1; i <= n; i ++ ) cin >> x[i] >> y[i];
	for (int i = 1; i <= n; i ++ )
	  for (int j = i + 1; j <= n; j ++ )
	    for (int k = j + 1; j <= n; j ++ )
	    {
	    	ans = max(ans, (x[j] - x[i]) * (y[k] - y[i]) - (y[j] - y[i]) * (x[k] - x[i]));
		}
	cout << ans / 2 << endl;*/
	return 0;
}