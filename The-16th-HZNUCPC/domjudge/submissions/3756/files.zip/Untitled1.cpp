#include<stdio.h>
int main(){
	int t,n,ii,jj,l,sum;
	int s[20][20];
	int a1[400];
	int b1[400];

	scanf("%d",&t);
	for (int i=1;i<=t;i++){
		scanf("%d",&n);
		sum=0;
		int count1=0,count2=0;
		
		for (int j=0;j<20;j++){
			for (int k=0;k<20;k++){
				s[j][k]=0;
			}
		}
		for (int j=1;j<=n;j++){
			scanf("%d %d %d",&ii,&jj,&l);
			if (l==1){
				s[ii][jj]=2;
				count1++;
				a1[count1]=ii;
				b1[count1]=jj;
			}else{
				s[ii][jj]=1;
				count2++;

			}
		}
	for (int i=1;i<=count1;i++){
		 			
			if (s[a1[i]][b1[i]]==2){
   			if (s[a1[i]-1][b1[i]]==0&&a1[i]-1>=1){
				sum++;
			}
            
        	if (s[a1[i]+1][b1[i]]==0&&a1[i]+1<=19){
        	sum++;
		}
            
        	if (s[a1[i]][b1[i]-1]==0&&b1[i]-1>=1){
        	sum++;
		}
            
        	if (s[a1[i]][b1[i]+1]==0&&b1[i]+1<=19){
        	sum++;
		}         
	}

	
}

	
           

		
	
		printf("%d",sum);
	}
	return 0;
}