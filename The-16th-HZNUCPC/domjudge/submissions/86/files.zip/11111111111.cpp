#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int n,k;cin>>n>>k;
	while(k>1){
		if(n%k==0){
			cout<<"NO\n";
			return 0;
		}
		k=n%k;
	}
	cout<<"YES\n";
	return 0;
}