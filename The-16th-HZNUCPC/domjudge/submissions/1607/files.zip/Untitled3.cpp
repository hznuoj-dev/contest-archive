#include<bits/stdc++.h>
#define int long long
#define PII pair<int,int>
using namespace std;
int fun(PII a,PII b,PII c)
{
//		cout<<a.first<<" "<<a.second<<" "<<b.first<<" "<<b.second<<" "<<c.first<<" "<<c.second<<endl;
	if((a.first==b.first&&a.second==b.second)||(a.first==c.first&&a.second==c.second)||(c.first==b.first&&c.second==b.second)) return 0;
	if((a.first-b.first)*(a.second-c.second)==(a.first-c.first)*(a.second-b.second)) return 0;
	int xa=abs(a.first-b.first);
	int ya=abs(a.second-b.second);
	int xb=abs(a.first-c.first);
	int yb=abs(a.second-c.second);
	int xc=abs(c.first-b.first);
	int yc=abs(c.second-b.second);
//	if(__gcd(xa,ya)+1ll+__gcd(xb,yb)+1ll+__gcd(xc,yc)+1ll==7)
//	{
//		cout<<xa<<" "<<ya<<" "<<xb<<" "<<yb<<" "<<xc<<" "<<yc<<endl;
//		cout<<__gcd(xa,ya)<<" "<<__gcd(xb,yb)<<" "<<__gcd(xc,yc)<<endl;
//	}
	return __gcd(xa,ya)+__gcd(xb,yb)+__gcd(xc,yc);
	
}
void solve()
{
	vector<PII>v;
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		int x,y;
		cin>>x>>y;
		v.push_back({x,y});
	}
	int ans=0;
	for(int i=0;i<n;i++)
	{
		for(int j=i+1;j<n;j++)
		{
			for(int k=j+1;k<n;k++)
			{
//				cout<<a.first<<" "<<a.second<<" "<<b.first<<" "<<b.second<<" "<<c.first<<" "<<c.second<<endl;	
				ans=max(ans,fun(v[i],v[j],v[k]));	
			}	
		}
	}
	cout<<ans<<endl;
	
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
//	int _;cin>>_;while(_--)
	solve();
}