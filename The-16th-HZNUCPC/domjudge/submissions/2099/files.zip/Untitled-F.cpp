#include <bits/stdc++.h>
using namespace std;
#define rep(a,b,c) for(int a=b;a<=c;a++)
#define per(a,b,c) for(int a=b;a>=c;a--)
#define output(a,b,c) cout<<a<<" "<<b<<" "<<c<<"\n"
#define ft first
#define sd second

typedef long long LL;
typedef unsigned long long ULL;

typedef pair<int,int> PII;
typedef pair<LL,LL> PLL;

const int N=1e6+5000,M=5*N;






int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    

	LL n,m;cin>>n>>m;
	int jud=0;
	rep(i,1,N){
		if(i>n){break;}
		if(n%i==0){
			LL t=i,k=n/t;
			//cout<<t<<" "<<k<<"\n";
			if((t<=m&&t!=1)||(k<=m&&k!=1)){
				jud=1;break;
			}
		}	
	}
	cout<<(jud?"NO":"YES");
	
	


    return 0;
}