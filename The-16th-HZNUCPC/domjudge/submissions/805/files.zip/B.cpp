#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
bool co_line(pair<ll,ll> a,pair<ll,ll> b,pair<ll,ll> c){
	ll k1=__gcd(abs(a.first-b.first),abs(a.second-b.second));
	ll k2=__gcd(abs(a.first-c.first),abs(a.second-c.second));
	pair<ll,ll> p1={abs(a.first-b.first)/k1,abs(a.second-b.second)/k1};
	pair<ll,ll> p2={abs(a.first-c.first)/k2,abs(a.second-c.second)/k2};
	return p1==p2;
}
ll calc(pair<ll,ll> a,pair<ll,ll> b,pair<ll,ll> c){
	ll res=0;
	return __gcd(abs(a.first-b.first),abs(a.second-b.second))
			+__gcd(abs(a.first-c.first),abs(a.second-c.second))
			+__gcd(abs(c.first-b.first),abs(c.second-b.second));
}
void solve(){
	int n;
	cin>>n;
	vector<pair<int,int>> ve;
	for(int i=1,a,b;i<=n;i++){
		cin>>a>>b;
		ve.push_back({a,b});
	}
	ll ans=0;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(ve[i]!=ve[j]&&ve[k]!=ve[j]&&ve[i]!=ve[k]&&!co_line(ve[i],ve[j],ve[k])){
					ans=max(ans,calc(ve[i],ve[j],ve[k]));
				}
			}
		}
	}
	cout<<ans<<'\n';
}
int main(){
	ios::sync_with_stdio(0);
	int T=1;
//	cin>>T;
	while(T--){
		solve();
	}
}