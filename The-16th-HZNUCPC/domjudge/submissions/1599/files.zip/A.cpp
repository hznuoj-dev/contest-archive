#include<bits/stdc++.h>

using namespace std;
int x[365],y[365],c[365];
int main() {
	int t;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		int val[25][25]={0};
		int n;
		scanf("%d",&n);
		for(int z=1;z<=n;z++)
		{
			scanf("%d %d %d",&x[z],&y[z],&c[z]);
			val[x[z]][y[z]]=c[z];
		}
		int ans=0;
		for(int j=1;j<=n;j++)
		{
			if(c[j]==1)
			{
				if(val[x[j]+1][y[j]]==0&&x[j]+1>0&&x[j]+1<=19&&y[j]>0&&y[j]<=19)
				{
					ans++;
				}
				
				if(val[x[j]][y[j]+1]==0&&x[j]>0&&x[j]<=19&&y[j]+1>0&&y[j]+1<=19)
				{
					ans++;
				}
				
				if(val[x[j]-1][y[j]]==0&&x[j]-1>0&&x[j]-1<=19&&y[j]>0&&y[j]<=19){
					ans++;
				}
				
				if(val[x[j]][y[j]-1]==0&&x[j]>0&&x[j]<=19&&y[j]-1>0&&y[j]-1<=19)
				{
					ans++;	
				}	
			}
		}
		printf("%d\n",ans);
	}
}

