#include<bits/stdc++.h>
#define int long long
#define ll long long
#define vi vector<int>
#define pb push_back

using namespace std;
const int mod = 1e9 + 7;

void solve() {
	string s;
	cin >> s;
	int n = s.size();
	int ans = 0;
	for (int i = 0; i < n; i ++) {
		vector<pair<int,int>> point;
		bool f = 0;
		for (int j = i-1, k = i + 1; j >= 0 && k < n; j --, k ++) {
			if (s[j] != s[k]) {
				if (point.size() == 0) {
					point.pb({j,k});
					if (s[j] == s[i] || s[k] == s[i]) f = 1;
				} else if (point.size() == 1) {
					int jj = point[0].first, kk = point[0].second;
					if ((s[j] == s[kk] && s[k] == s[jj]) || (s[j] == s[jj] && s[k] == s[kk])) {
						point.pb({j,k});
					} else {
						//ans = max(ans, k - j - 1);
						break;
					}
				} else {
					//ans = max(ans, k - j - 1);
					break;
				}
			}
			if (point.size() != 1 || f == 1)ans = max(ans, k - j + 1);
		}
		point.clear();
		for (int j = i, k = i + 1; j >= 0 && k < n; j --, k ++) {
			if (s[j] != s[k]) {
				if (point.size() == 0) {
					point.pb({j,k});
				} else if (point.size() == 1) {
					int jj = point[0].first, kk = point[0].second;
					if ((s[j] == s[kk] && s[k] == s[jj]) || (s[j] == s[jj] && s[k] == s[kk])) {
						point.pb({j,k});
					} else {
						//ans = max(ans, k - j - 1);
						break;
					}
				} else {
					//ans = max(ans, k - j - 1);
					break;
				}
			}
			if (point.size() != 1)ans = max(ans, k - j + 1);
		}
	}
	cout << ans << '\n';
}
signed main() {
	int t;
	cin >> t;
	while (t --) solve();
	return 0;
}
/*
4
0 0
1 1
2 4
4 2




4
1 1
2 2
3 3
2 4


*/