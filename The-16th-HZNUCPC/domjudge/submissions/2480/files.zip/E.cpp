#include<bits/stdc++.h>
#define endl '\n'
#define pll pair<ll, ll>
using namespace std;

typedef long long ll;
const ll N = 1e9 + 7;
ll n;
pll p[105];

ll gcd(ll x, ll y){
	return y == 0 ? x : gcd(y, x % y);
}

int main() {
	cin >> n;
	for (int i = 1, u, v; i <= n; i++){
		cin >> u >> v;
		p[i] = {u, v};
	}
	ll ans = 0;
	for (int i = 1; i <= n - 2; ++i) {
		for (int j = i + 1; j <= n - 1; ++j) {
			for (int k = j + 1; k <= n; ++k) {
				double a1 = sqrt(((p[i].first - p[j].first) * (p[i].first - p[j].first)) + ((p[i].second - p[j].second) * (p[i].second - p[j].second)));
				double a2 = sqrt(((p[i].first - p[k].first) * (p[i].first - p[k].first)) + ((p[i].second - p[k].second) * (p[i].second - p[k].second)));
				double a3 = sqrt(((p[k].first - p[j].first) * (p[k].first - p[j].first)) + ((p[k].second - p[j].second) * (p[k].second - p[j].second)));
				if (a1 + a2 > a3 && fabs(a1 - a2) < a3){
					//cout << i << " " << j << " " << k << endl;
					ll num = 0;
					ll ijf = abs(p[i].first - p[j].first), ijs = abs(p[i].second - p[j].second);
					ll ikf = abs(p[i].first - p[k].first), iks = abs(p[i].second - p[k].second);
					ll kjf = abs(p[k].first - p[j].first), kjs = abs(p[k].second - p[j].second);
					//cout << ijf << " " << ijs << endl;
					//cout << ikf << " " << iks << endl;
					//cout << kjf << " " << kjs << endl;
					num += max(ijf, ijs) / (max(ijf, ijs) / gcd(ijf, ijs));
					num += max(ikf, iks) / (max(ikf, iks) / gcd(ikf, iks));
					num += max(kjf, kjs) / (max(kjf, kjs) / gcd(kjf, kjs));
					//cout << num << endl;
					ans = max(ans, num);
				}
			}
		}
	}
	cout << ans << endl;
	return 0;
}