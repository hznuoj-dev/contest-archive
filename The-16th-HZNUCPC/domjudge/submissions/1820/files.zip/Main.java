import java.util.Scanner;


public class main {
		public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		long a=s.nextLong();
		long b=s.nextLong();
		if(a==1||b==1)
		{
			System.out.println("YES");
		}
		else if(a%2==1)
		{
			System.out.println("YES");
		}
		else{System.out.println("NO");}
	}
}
