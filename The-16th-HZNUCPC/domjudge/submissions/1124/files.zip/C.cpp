#include<bits/stdc++.h>
using namespace std;

long long n,m;


int main()
{
	
	cin >> n >> m;
	
	if (n < m) {
		cout << "NO\n";
		return 0;
	}
	
	if(n%m)
	cout<<"YES"<<'\n';
	else
	cout<<"NO"<<'\n';
}