#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int N=110;
long long a[N],b[N];
int main()
{
    cout <<"nb" <<endl;

    return 0;
}
