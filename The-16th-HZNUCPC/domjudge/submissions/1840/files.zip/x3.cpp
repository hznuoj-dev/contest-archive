#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=300005;
LL mod=1e9+7;
char s[5000+10];
int n;
int main(){
#ifndef ONLINE_JUDGE
	freopen("in.txt","r",stdin);
#endif
	int _;
	scanf("%d",&_);
	while(_--){
		scanf("%s",s + 1);
		n = strlen(s + 1);
	
		int ans = 0;
		
		vector<pair<int,int> > g;
		for (int i = 1; i <= n; i ++) {
			int l = i, r = i;	
			auto solve = [&](int l, int r) {
				g.clear();
				while (r <= n and l>= 1) {
					if (s[l] != s[r]) {
						g.push_back({l, r});
					}
					if (g.size() == 3) {
						// [l, r]
						break;
					}
					r ++; l --;
				}	
				l ++, r --;
				// printf("l=%d,r=%d, %d\n",l,r,g.size());
				
				if (g.size() >= 2) {
					bool can = 0;
					if (s[g[0].first] == s[g[1].first] and s[g[0].second] == s[g[1].second])
						can = 1;
					if (s[g[0].first] == s[g[1].second] and s[g[0].second] == s[g[1].first])
						can = 1;						
					if (can) {
						ans = max(ans, r - l + 1);
						//printf("%d\n", ans);
					}
				}
				
				int lb = l, rb = r;
				if (g.size() >= 1) {
					lb = g[0].first + 1, rb = g[0].second - 1;
				} 
				int c[26] = {0};
				for (int x = lb; x <= rb; x ++) {
					c[s[x] - 'a'] ++;
				}
				for (int x = 0; x < 26; x ++) if (c[x] >= 2) ans = max(ans, rb - lb + 1);
				
			};
			solve(i, i);
			if (i + 1 <= n) solve(i, i + 1);
		}
		
		printf("%d\n", ans);
	}
    return 0;
}