#include <bits/stdc++.h>
using namespace std;
struct point{
	int l,r,t;
	int step,id;
	point(){step=0;}
	point(int _id,int _r,int _t):l(-1),r(_r),t(_t),step(0),id(_id){}
}a[200010];
int n, m,x,ans[200010];
bool cmp1(point x,point y){return x.r<y.r;}
bool cmp2(point x,point y){return x.l<y.l;}
int t[1000010];
void upd(int p,int l,int r,int rr,int sum){
	if(l>rr)return;
	if(r<=rr){
		t[p]=!t[p]?sum:min(t[p],sum);
		return;
	}
	int mid=(l+r)>>1;
	upd(p<<1,l,mid,rr,sum),upd(p<<1|1,mid+1,r,rr,sum);
}
void clr(int p,int l,int r,int rr){
	if(l>rr)return;
	if(r<=rr){
		t[p]=0;
		return;
	}
	int mid=(l+r)>>1;
	clr(p<<1,l,mid,rr),clr(p<<1|1,mid+1,r,rr);
}
int query(int p,int l,int r,int k){
	if(l==r)return t[p];
	int mid=(l+r)>>1;
	int res=k<=mid?query(p<<1,l,mid,k):query(p<<1|1,mid+1,r,k);
	if(t[p]){
		res=res?min(res,t[p]):t[p];
	}
	return res;
}
void cdq(int l,int r){
	if(l==r){
		if(a[l].id){
			ans[a[l].id]=a[l].step;
		}
		return;
	}
	int mid=(l+r)>>1;
	cdq(mid+1,r);
//	puts("");
//	printf("%d %d:\n",l,r);
	sort(a+mid+1,a+r,cmp2);
	int pos1=mid+1;
	for(int i=l;i<=mid;i++){
		while(pos1<=r&&a[pos1].l<=a[i].r){
			if(!a[pos1].id)upd(1,1,100000,a[pos1].t,a[pos1].step);
			pos1++;
		}
//		printf("%d\n",pos1);
		int t=query(1,1,100000,a[i].t);
//		printf("%d\n",t);
		if(!a[i].id&&t)t++;
		if(t){
			a[i].step=a[i].step?min(a[i].step,t):t;
		}
	}pos1--;
	while(pos1>mid)clr(1,1,100000,a[pos1].t),pos1--;
	cdq(l,mid);
}
int main() {
	scanf("%d%d%d" ,&n,&m,&x);
	for(int i=1;i<=n;i++)scanf("%d%d%d",&a[i].t,&a[i].l,&a[i].r);
	for(int i=1;i<=m;i++){
		int c,p;
		scanf("%d%d",&c,&p);
		a[++n]=point(i,p,c);
	}
	sort(a+1,a+1+n,cmp1);
	for(int i=1;i<=n;i++)if(a[i].r==x)a[i].step=1;
	cdq(1,n);
	for(int i=1;i<=m;i++)printf("%d\n",ans[i]?ans[i]:-1);
	return 0;
}
/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5
*/