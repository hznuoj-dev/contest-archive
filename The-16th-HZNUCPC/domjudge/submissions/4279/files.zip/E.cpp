#include<bits/stdc++.h>
using namespace std;
typedef struct B{
	long long int x;
	long long int y;
} pos,B;
int main()
{
    long long int sum,sum1,i,j,n,z,e;
    float k,l1,l2,l3,m;
    scanf("%lld",&n);
    pos p[n+1];
    sum=0;
    for(i=1;i<=n;i++)
    {
    	scanf("%lld%lld",&p[i].x,&p[i].y);
	}
	for(i=1;i<=n-2;i++)
	{
		for(j=i+1;j<=n-1;j++)
		{
			for(z=j+1;z<=n;z++)
			{   sum1=0;
				
				if((p[i].x-p[j].x)==0)
				sum1=sum1+abs(p[i].y-p[j].y);
				if((p[i].y-p[j].y)==0)
				sum1=sum1+abs(p[i].x-p[j].x);
				if((p[i].x-p[z].x)==0)
				sum1=sum1+abs(p[i].y-p[z].y);
				if((p[i].y-p[z].y)==0)
				sum1=sum1+abs(p[i].x-p[z].x);
				if((p[z].x-p[j].x)==0)
				sum1=sum1+abs(p[z].y-p[j].y);
				if((p[z].y-p[j].y)==0)
				sum1=sum1+abs(p[z].x-p[j].x);
				//	
				if((p[i].x-p[j].x)!=0&&(p[i].y-p[j].y)!=0)
				{
				k=(p[i].y-p[j].y)*1.0/(p[i].x-p[j].x);
				
				if((p[i].x-p[j].x)<(p[i].y-p[j].y))
				{
					e=(p[i].x-p[j].x);
				}
				else
				{
					e=(p[i].y-p[j].y);
				}
					for(m=1;m<=e;m=m+1)
					{
						if(int(m*k)==m*k){
							sum1=sum1+e/m;
							break;
						}
									
						}
						
				}
				//
					if((p[j].x-p[z].x)!=0&&(p[j].y-p[z].y)!=0)
					{
					k=(p[z].y-p[j].y)*1.0/(p[z].x-p[j].x);
					if((p[i].x-p[j].x)<(p[i].y-p[j].y))
				{
					e=(p[i].x-p[j].x);
				}
				else
				{
					e=(p[i].y-p[j].y);
				}
					for(m=1;m<=abs(p[z].x-p[j].x);m++){
						if(int(m*k)==m*k){
							sum1=sum1+e/m;
							break;
									}
						}
					}
					//
					if((p[z].x-p[i].x)!=0&&(p[z].y-p[i].y)!=0)
					{
					k=(p[i].y-p[z].y)*1.0/(p[i].x-p[z].x);
						if(int(m*k)==m*k){
							sum1=sum1+e/m;
							break;
									}
						}
						
					}
					
					l1=sqrt((p[i].x-p[j].x)*(p[i].x-p[j].x)+(p[i].y-p[j].y)*(p[i].y-p[j].y));
					l2=sqrt((p[z].x-p[j].x)*(p[z].x-p[j].x)+(p[z].y-p[j].y)*(p[z].y-p[j].y));
					l3=sqrt((p[i].x-p[z].x)*(p[i].x-p[z].x)+(p[i].y-p[z].y)*(p[i].y-p[z].y));
					
					if(l1+l2>l3&&l3+l2>l1&&l1+l3>l2){
						if(sum1>sum)
						sum=sum1;
						
				}
				}

			}printf("%lld",sum);
		}
	
	
