#include<bits/stdc++.h>
using namespace std;
// #define int long long
inline int read(){
    int x=0,f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c))x=x*10+c-48,c=getchar();
    return x*f;
}
int T,n,x,y,ans,flag;
char ch[1000010];
signed main(){
    scanf("%d",&T);
    while(T--)
    {
        scanf("%s",ch+1),n=strlen(ch+1),ans=0;
        for(int i=1;i<=n;i++)
        {
            x=0,y=0,flag=0;
            for(int len=1;1<=i-len&&i+len<=n;len++)
            {
                if(ch[i-len]==ch[i+len]) {if(!x&&!y) ans=max(ans,len+len+1);}
                else
                {
                    if(flag) break;
                    if(!x&&!y) x=i-len,y=i+len;
                    else if((ch[x]==ch[i+len]&&ch[y]==ch[i-len])||(ch[x]==ch[i-len]&&ch[y]==ch[i+len])) flag=1,x=y=0,ans=max(ans,len+len+1);
                    else break;
                }
            }
            // printf("%d %d %d\n",ans,x,y);
        }
        for(int i=1;i<=n;i++)
        {
            flag=0;
            for(int len=1;1<=i-len&&i+len<=n;len++)
            {
                if(ch[i-len]==ch[i+len]) ans=max(ans,len+len+1);
                else
                {
                    if(flag) break;
                    if(ch[i-len]==ch[i]||ch[i+len]==ch[i]) flag=1,ans=max(ans,len+len+1);
                    else break;
                }
            }
            // printf("%d %d %d\n",ans,x,y);
        }
        for(int i=1;i<=n;i++)
        {
            x=0,y=0,flag=0;
            for(int len=1;1<=i-len+1&&i+len<=n;len++)
            {
                if(ch[i-len+1]==ch[i+len]) {if(!x&&!y) ans=max(ans,len+len);}
                else
                {
                    if(flag) break;
                    if(!x&&!y) x=i-len+1,y=i+len;
                    else if((ch[x]==ch[i+len]&&ch[y]==ch[i-len+1])||(ch[x]==ch[i-len+1]&&ch[y]==ch[i+len])) flag=1,x=y=0,ans=max(ans,len+len);
                    else break;
                }
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}