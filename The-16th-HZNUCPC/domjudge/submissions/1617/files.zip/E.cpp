#include<bits/stdc++.h>
#define rep(i,a,b) for(int i=(a),__##i##__=(b);i<=__##i##__;i++)

#define int long long
#define debug(a)
using namespace std;
const int N=111;
int x[N],y[N];


bool check(int i,int j,int k)
{
	if((x[i]-x[k])*(y[i]-y[j])==(x[i]-x[j])*(y[i]-y[k])) return false;
	return true;
}
signed main()
{
	int n;
	cin>>n;
	rep(i,1,n)
	{
		cin>>x[i]>>y[i];
	}
	long long mx=0;
	rep(i,1,n-2)
	{
		rep(j,i+1,n-1)
		{
			rep(k,j+1,n)
			{	
				if(check(i,j,k)) //是否共线
				{
					long long ans=0;
					int dy=abs(y[i]-y[j]);
					int dx=abs(x[i]-x[j]);
					int ddy=dy/__gcd(dx,dy);
					ans+=dy/ddy;
					
					dy=abs(y[i]-y[k]);
					dx=abs(x[i]-x[k]);
					ddy=dy/__gcd(dx,dy);
					ans+=dy/ddy;	
					
					dy=abs(y[j]-y[k]);
					dx=abs(x[j]-x[k]);
					ddy=dy/__gcd(dx,dy);
					ans+=dy/ddy;
					mx=max(ans,mx);
				}
			}
		}
	}
	cout<<mx<<"\n";
	return 0;
}