//#include<iostream>
//#include<algorithm>
//#include<vector>
//using namespace std;
//const int N = 400;
//int n;
//int way[4][2] = {{-1 , 0} ,{1 , 0} , {0 , 1} , {0 , -1}};
//pair<int,int> a1[N] , a2[N];
//int main(){
//    int T;
//    cin >> T;
//    while(T--){
//		cin >> n;
//		int n1 , n2 . ans = 0;
//		for(int i = 1 , x ,y , c ; i <= n ; i++){
//			cin >> x >> y >> c;
//			if(c == 1) a1[n1++] = {x  ,y};
//			else if(c == 2) a2[n2++] = {x ,y};
//		}
//		for(int i = 0 ;  i < n1 ; i++){
//			int x = a1[i].first;
//			int y = a1[i].first;
//			for(int )
//		}
//    }
//}

#include<iostream>
#include<algorithm>
#include<vector>
using namespace std;
const int N = 1e5 + 10;
long long n , m;
int main(){
    cin >> n >> m;
    if(m != 1 && (n % m == 0 || (n % 2 == 0))) cout << "NO" << endl;
    else cout << "YES" << endl;
}