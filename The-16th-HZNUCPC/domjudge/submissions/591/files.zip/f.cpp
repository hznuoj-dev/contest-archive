#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int N=1e6+10;
int primes[N],cnt;
bool st[N];
void get_primes(int n)
{
	for(int i=2;i<=n;i++)
	{
		if(!st[i])primes[cnt++]=i;
		for(int j=0;primes[j]<=n/i;j++)
		{
			st[primes[j]*i]=1;
			if(i%primes[j]==0)break;
		}
	}
}
signed main()
{
	get_primes(N-1);
	
	int n,m;
	cin>>n>>m;
	if(n==1||m==1)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	else if(n<m)
	{
		cout<<"NO"<<endl;
		return 0;
	}
	int num=-1;
	for(int i=0;i<cnt;i++)
	{
		if(n%primes[i]==0)
		{
			num=primes[i];
			break;
		}
	}
	if(num==-1)num=n;
	if(m>=num)cout<<"NO"<<endl;
	else cout<<"YES"<<endl;
	return 0;
}