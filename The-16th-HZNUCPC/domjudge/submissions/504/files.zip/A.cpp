#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
int main ()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    //cin >> tt;
    while (tt--)
    {
        ll n,m;
        cin >> n >> m ;
        ll mai = 1e9;
        for (ll i = 1; i * i <= n; ++i)
        {
            if (n % i == 0)
            {
                if (i != 1)
                    mai = min(mai,i);
                mai = min(mai,n/i);
            }
        }
        if (mai > m ||n == 1) cout<<"YES\n";
        else cout << "NO\n";
    }

}
