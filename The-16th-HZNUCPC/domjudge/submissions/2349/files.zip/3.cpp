#include <bits/stdc++.h>
using namespace std;
int main(){
	long n,m;
	cin>>n>>m;
	if(m == 1)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	if(n % 2 == 0 && m %2 == 0 || n <=0 || m <=0)
	{
		cout<<"NO"<<endl;
		return 0;
	}
	while(1)
	{
		m = n % m;
		
		if(m == 1) 
		{
			cout<<"YES"<<endl;
			return 0;
		}
		if(m == 0) 
		{
			cout<<"NO"<<endl;
			return 0;
		}
	}
	return 0;
}