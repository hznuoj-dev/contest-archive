#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define debug(x) cerr<<#x<<" "<<x<<"\n"

const int maxn=105;

ll x[maxn],y[maxn];

ll re(ll a,ll b){
    if(a==0) return b+1;
    if(b==0) return a+1;
    a=abs(a);
    b=abs(b);
    if(a<b) swap(a,b);
    if(a%b==0){
        return b+1;
    }
    else return 2;
}

void _solve(){
    int n;cin>>n;
    for(int i=0;i<n;i++){
        cin>>x[i]>>y[i];
    }
    ll ans=0;
    for(int i=0;i<n;i++){
        for(int j=i+1;j<n;j++){
            for(int k=j+1;k<n;k++){
                ll now1=re(x[i]-x[j],y[i]-y[j]);
                ll now2=re(x[i]-x[k],y[i]-y[k]);
                ll now3=re(x[k]-x[j],y[k]-y[j]);
                ll now=now1+now2+now3-3;
                ans=max(ans,now);
            }
        }
    }
    cout<<ans<<"\n";
}

int main(){
    ios::sync_with_stdio(false);

//    int T;cin>>T;while(T--)
    _solve();
}
