#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
bool func(ll a,ll b){
    for(int i=2;i<=a/i;i++){
        if(a%i==0){
            if(b>=i || b>=a/i)return true;
        }
    }
    return false;
}
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n>>m;
    if(m==1) 
    {
        cout<<"YES"<<endl;
        return 0;
    }
    if(m>=n){
        cout<<"NO"<<endl;
        return 0;
    }
    if(func(n,m))cout<<"NO"<<endl;
    else cout<<"YES"<<endl;
    return 0;
}