import java.util.Arrays;
import java.util.Scanner;

public class Main {
	static int T;
	static int N;
	static int sum;
	static int wx[] = { 0, 1, 0, -1 };
	static int wy[] = { 1, 0, -1, 0 };

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext()) {
			T = sc.nextInt();
			for (int m = 1; m <= T; ++m) {
			 int ans[][] = new int[19][19];
				N = sc.nextInt();
				for (int j = 1; j <= N; ++j) {
					int x = sc.nextInt() - 1;
					int y = sc.nextInt() - 1;
					int c = sc.nextInt();
					ans[x][y] = c;
				}
				sum = 0;
				for (int i = 0; i < 19; ++i) {
					for (int j = 0; j < 19; ++j) {
						if (ans[i][j] == 1) {
							for (int k = 0; k < 4; ++k) {
								int newx = i + wx[k];
								int newy = j + wy[k];
								if (newx >= 0 && newy >= 0 && newx < 19
										&& newy < 19) {
									if (ans[newx][newy] != 1
											&& ans[newx][newy] != 2)
										++sum;
								}
							}
						}
					}
				}
				System.out.println(sum);
				sum = 0;
			}
		}
	}
}
