#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
#define fi first
#define se second
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
const ll mod = 1e9 + 7;
int main ()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    cin >> tt;
    while (tt--)
    {
       string a;
       cin>>a;
       int n;
       n=a.size();
       a=" "+a;int ans;
       int l,r;
       l=2;
       r=n;
       ans=0;
       for(int m=r;m>=l;m--){
            //cout<<"m:"<<m<<endl;
            int pan;
            pan=0;
            for(int i=1;i+m-1<=n;i++){
                vector<pair<int,int> >ve;
                 int ls,rs;
                ls=i;
                rs=i+m-1;

                for(int len=1;len<=m/2;len++){

                    if(a[ls+len-1]!=a[rs-len+1]){
                        ve.push_back({ls+len-1,rs-len+1});
                    }
                }

                if(ve.empty()){
                    pan=1;
                   // break;
                }
                else if(ve.size()==1&&m%2==1){
                    int mid;
                    mid=(ls+rs)/2;
                    if(a[ve[0].fi]==a[mid]||a[ve[0].se]==a[mid]){
                        pan=1;
                    }
                }
                else if(ve.size()==2){
                       // cout<<'@'<<m<<' '<<a[ve[0].fi]<<' '<<a[ve[0].se]<<' '<<a[ve[1].fi]<<' '<<a[ve[1].se]<<endl;
                    if((a[ve[0].fi]==a[ve[1].se]&&a[ve[0].se]==a[ve[1].fi])||(a[ve[0].fi]==a[ve[1].fi]&&a[ve[0].se]==a[ve[1].se])){
                        pan=1;
                       // break;
                    }
                }

                if(pan)break;
            }
           // cout<<'@'<<m<<' '<<pan<<endl;

                if(pan){
                    ans=max(ans,m);
                    break;
                }

       }
      cout<<ans<<'\n';

    }

}
/*
1
aabcadcbda
*/
