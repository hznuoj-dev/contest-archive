#include <bits/stdc++.h>
using namespace std;

int main()
{	
    long long n=1e12,m=1e11+231; 
//	scanf("%lld%lld",&n,&m);
	int flag=1;
	
	if (n==1||m==1)
	{
		printf("YES\n");
		return 0;
	}
	else if(n<=m)
	{
		printf("NO\n");
			return 0;
	}
	else if (n%2==0&&m%2==0)
	{	printf("NO\n");
			return 0;
	}

	while(m>1){
		m=n%m;
		if(m==0){
			flag=0;
			break;
    	}
	}
	
	
	if(flag)printf("YES\n");
	else printf("NO\n");
	
	return 0;
}
// 1e12 1e12-1