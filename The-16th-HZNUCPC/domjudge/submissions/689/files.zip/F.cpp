#include <bits/stdc++.h>
using namespace std;
const int N=1e6+10;


int main()
{	
    long long n,m;cin>>n>>m;

	int flag=1;

	while(1)cout<<1;
	
	return 0;
}