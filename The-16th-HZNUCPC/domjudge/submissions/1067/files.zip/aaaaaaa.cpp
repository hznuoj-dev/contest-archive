#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define me(a,b) memeset(a,b,sizeof a);
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int mp[30][30];
int vis[30][30];
int n,m,a,b,c,T,ans;
void dfs(int x,int y){
	for(int i=0;i<4;i++){
		int tx=x+dir[i][0];
		int ty=y+dir[i][1];
		if(tx>=0&&ty>=0&&tx<=25&&ty<=25&&vis[tx][ty]==0){
			if(mp[tx][ty]==0){
				mp[tx][ty]=2;	
				ans++;
				vis[tx][ty]=1;
			}else if(mp[tx][ty]==1){
				vis[tx][ty]=1;
			//	cout<<tx<<" "<<ty<<" "<<ans<<endl;
				dfs(tx,ty);
			}
		}
	}
	return ;
}
signed main() {
	IOS
	while(cin>>T){
		while(T--){
			cin>>n;
			memset(vis,0,sizeof(vis));
			memset(mp,0,sizeof(mp));
			for(int i=0;i<n;i++){
				cin>>a>>b>>c;
				if(c==1){
					mp[a][b]=1;
				}else{
					mp[a][b]=2;
				}
			}
			ans=0;
			for(int i=0;i<=20;i++){
				for(int j=0;j<=20;j++){
					if(mp[i][j]==1&&vis[i][j]==0){
						vis[i][j]=1;
						dfs(i,j);
					}
				}
			}
//			for(int i=0;i<=20;i++){
//				for(int j=0;j<=20;j++){
//					cout<<mp[i][j]<<" ";
//				}
//				cout<<endl;
//			}
			cout<<ans<<endl;
		}
	}
	return 0;
}