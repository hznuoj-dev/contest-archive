#include<iostream>
using namespace std;
int main()
{
	long long n,m;
	cin>>n>>m;
	while(1)
	{
	if(m==1||n==1)
	{
		cout<<"YES";
		break;
	}
	if(m==0||n<=m)
	{
		cout<<"NO";
		break;
	}
	m=n%m;
	}
	return 0;
}