#include<bits/stdc++.h>
#define ft first
#define sd second
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
#define rep(i,a,b) for(ll i=a;i<=b;++i)
using namespace std;
ll n,m,k,tt,tp,sum,ans,res;
const ll N=1e6+5;
ll x;
struct car
{
    ll t,l,r;
    bool operator < (const car&a)const{
        return t>a.t;
    }
};
struct ask
{
    ll c,p,id;
    bool operator < (const ask&a)const{
        return c>a.c;
    }
};
struct Seg
{
    #define ls(x) (x<<1)
    #define rs(x) (x<<1|1)
    #define mid ((l+r)>>1)
    ll tr[N<<2],lz[N<<2],lzz[N<<2];
    void pushup(ll p)
    {
        tr[p]=tr[ls(p)]+tr[rs(p)];
        return ;
    }
    void build(ll p,ll l,ll r)
    {
        if(l==r)
        {
            tr[p]=lz[p]=0;
            return ;
        }
        build(ls(p),l,mid);
        build(rs(p),mid+1,r);
        pushup(p);
    }
    void pushdown(ll p,ll l,ll r)
    {
        if(lzz[p])
        {
            lz
        }
        lz[ls(p)]+=lz[p];
        lz[rs(p)]+=lz[p];
        tr[ls(p)]+=lz[p]*(mid-l+1);
        tr[rs(p)]+=lz[p]*(r-mid);
        lz[p]=0;
        return ;
    }
    void update(ll p,ll l,ll r,ll ql,ll qr,ll x)
    {
        if(l>qr||r<ql)return ;
        if(ql>=l&&qr<=r)
        {
            tr[p]+=(r-l+1)*x;
            lz[p]+=x;
            return ;
        }
        pushdown(p,l,r);
        update(ls(p),l,mid,ql,qr,x);
        udpate(rs(p),mid+1,r,ql,qr,x);
        pushup(p);
    }
    void updateval(ll p,ll l,ll r,ll ql,ll qr,ll x)
    {
        if(l>qr||r<ql)return ;
        if(ql>=l&&qr<=r)
        {
            tr[p]=x*(r-l+1);
            lzz[p]=1;
            return ;
        }
        pushdown(p,l,r);
        update(ls(p),l,mid,ql,qr,x);
        udpate(rs(p),mid+1,r,ql,qr,x);
        pushup(p);
    }
    ll query(ll p,ll l,ll r,ll f)
    {
        if(l>f||r<f)return 0;
        if(l==r&&l==f)
        {
            if(tr[p]==0)return -1;
            return tr[p];
        }
        pushdown(p,l,r);
        return query(ls(p),l,mid,f)+query(rs(p),mid+1,r,f);
    }
    #undef ls
    #undef rs
    #undef mid
}T;
set<pll>s;
ll SZ;
void Add(car &a)
{
    ll L=a.l,R=a.r;
    auto kr=s.lower_bound((pll){a.r,0LL});
    auto kln=s.lower_bound((pll){a.l,0LL});
    if(R>=x)
    {
        T.updateval(1,1,SZ,L,x,1);
        if(kln!=s.begin())
        {
            auto kl=prev(kln);
            if(T.query(1,1,SZ,L-1)<=0)
            {
                ll pre=L,res=2;
                while((kl->r>=pre))
                {
                    if((kl->r)>=L&&(k1->l)<L)T.updateval(1,1,SZ,res);
                    if(kl==s.begin())break;
                    ++res;
                    pre=k1->L;
                    kl=prev(kl);
                }
            }
            else T.update(1,1,SZ,(kl->l),L-1,1);
        }
    }
    else if(kr!=s.end())
    {
        if(T.query(1,1,SZ,kr->r)>0)
        {
            T.updateval(1,1,SZ,L,(kr->l)-1,T.query(1,1,SZ,kr->r)+1);
            kr=next(kr);
            kln=next(kln);
            if(kln!=s.begin())
            {
                T.updateval()
                auto kl=prev(kln);
                if(T.query(1,1,SZ,L-1)<=0)
                {
                    ll pre=L,res=2;
                    while((kl->r>=pre))
                    {
                        if((kl->r)>=L&&(k1->l)<L)T.updateval(1,1,SZ,res);
                        if(kl==s.begin())break;
                        ++res;
                        pre=k1->L;
                        kl=prev(kl);
                    }
                }
                else T.update(1,1,SZ,(kl->l),L-1,1);
            }
        }
    }
    else s.insert({l,r});
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    //IO
    cin>>n>>m>>x;
    vector<car>v(n);
    vector<ask>vv(m);
    vector<ll>op;
    rep(i,0,n-1)
    {
        cin>>v[i].t>>v[i].l>>v[i].r;
        op.pb(v[i].l);
        op.pb(v[i].r);
    }
    rep(i,0,m-1)
    {
        cin>>vv[i].c>>vv[i].p;
        vv[i].id=i;
        op.pb(vv[i].p);
    }
    op.pb(x);
    sort(all(op));
    op.erase(unique(all(op)),op.end());
    SZ=op.size();
    T.build(1,1,SZ);
    rep(i,0,n-1)
    {
        v[i].l=lower_bound(all(op,v[i].l))-op.begin()+1;
        v[i].r=lower_bound(all(op,v[i].r))-op.begin()+1;
    }
    rep(i,0,m-1)vv[i].p=lower_bound(all(op,vv[i].p))-op.begin()+1;
    x=lower_bound(all(op,x))-op.begin()+1;
    sort(all(v));
    sort(all(vv));
    ll now=0;
    vector<ll>ans(m);
    rep(i,0,m-1)
    {
        ll tm=vv[i].c;
        while(now!=n&&v[now].t>=tm)
        {
            Add(v[now]);
            ++now;
        }
        ans[vv[i].id]=T.query(1,1,SZ,vv[i].p);
    }
    for(auto x:ans)cout<<x<<"\n";
}
