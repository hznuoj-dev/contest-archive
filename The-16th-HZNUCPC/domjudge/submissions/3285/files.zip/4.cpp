#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+10;
const int maxn=10;
struct node
{
    int v,t;
};
vector<struct node>vec[N];

int co[N];
int cnt[3],Q,n;
bool flag=0;

struct P{
    int a,b,t;
    P(int a=0,int b=0,int t=0):a(a),b(b),t(t) {}
    bool operator <(const P& rhs)const{
        return a>rhs.a;
    }
};

vector<P>sz;
vector<int>people[N][3];
int now=0;
vector<pair<int,int> >id;

void dfs(int i,int c)
{
    if(flag)return;
    co[i]=c;
    cnt[c]++;
    people[now][c].push_back(i);
    for(auto j:vec[i])
    {
        if(flag)return;
        if(!co[j.v])
        {
            if(j.t==0)dfs(j.v,c);
            else dfs(j.v,3-c);
        }
        else
        {
            if(j.t==0&&co[j.v]!=c){flag=1;return;}
            else if(j.t==1&&co[j.v]==c){flag=1;return;}
        }
    }
}
vector<int>ans;

bool solve(int dep,int sum){
    if(sum>Q) return false;
    if(dep==sz.size()){
        if(sum==Q){
            printf("YES\n");
            for(auto p:id){
                if(p.first==1){
                    for(auto q:people[p.second][2]){
                        ans.push_back(q);
                    }
                }
                else{
                    for(auto q:people[p.second][1]){
                        ans.push_back(q);
                    }
                }
            }
            sort(ans.begin(),ans.end());
            for(auto p:ans) printf("%d ",p);
            printf("\n");
            return true;
        }
        else return false;
    }
    id.push_back({0,sz[dep].t});
    if(solve(dep+1,sum+sz[dep].a)){
        return true;
    }
    id.pop_back();
    id.push_back({1,sz[dep].t});
    if(solve(dep+1,sum+sz[dep].b)){
        return true;
    }
    id.pop_back();
    return false;
}

void _solve(){
    int m,i,j;
    scanf("%d%d%d",&n,&Q,&m);
    for(i=1;i<=m;i++){
       int t,x,y;
       scanf("%d%d%d",&t,&x,&y);
       vec[x].push_back({y,t});
       vec[y].push_back({x,t});
    }

    for(i=1;i<=n;i++){
       if(!co[i]){
           cnt[1]=cnt[2]=0;
           dfs(i,1);
           sz.push_back(P(cnt[1],cnt[2],sz.size()));
           now++;
       }
    }
    if(flag){
        printf("NO\n");
        return ;
    }
    sort(sz.begin(),sz.end());
    if(!solve(0,0)) printf("NO\n");


}

int main(){
    //ios::sync_with_stdio(false);

    //int T;scanf("%d",&T);while(T--)
    _solve();
}
