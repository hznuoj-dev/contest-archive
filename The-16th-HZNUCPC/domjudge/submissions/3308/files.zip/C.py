a=input()
b=input()
y = 0
for i in range(len(a)-1):
    for k in range(i+1,len(a)):
        if k != len(a)-1:
            c=a[:i]+b[i]+a[i+1:k]+b[k]+a[k+1:]
            d=b[:i]+a[i]+b[i+1:k]+a[k]+b[k+1:]
        else:
            c=a[:i]+b[i]+a[i+1:k]+b[k]
            d=b[:i]+a[i]+b[i+1:k]+a[k]
        for j in range(len(a)-1):
            if c[j:j+2] in d:
                y=(y+1)%(10**9+7)
                break
print(y%(10**9+7))
