import java.io.*;
import java.util.StringTokenizer;


public class Main {
	int n,m,acnt,bcnt,i,j;
	int[]x,ac,bc;
	long p=1000000007;
	void cal(int i){
		int aa=i/26;
		int bb=i%26;
		if(bc[bb]--==1)bcnt--;
		if(ac[bb]++==0)acnt++;
		if(ac[aa]--==1)acnt--;
		if(bc[aa]++==0)bcnt++;
	}
	void recal(int i){
		int bb=i/26;
		int aa=i%26;
		if(bc[bb]--==1)bcnt--;
		if(ac[bb]++==0)acnt++;
		if(ac[aa]--==1)acnt--;
		if(bc[aa]++==0)bcnt++;
	}
	void solve()throws IOException{
		char[]a=in.ins().toCharArray();
		char[]b=in.ins().toCharArray();
		n=a.length;
		x=new int[26*26];
		ac=new int[26];
		bc=new int[26];
		acnt=0;
		bcnt=0;
		for(int i=0;i<n;i++){
			a[i]-='a';
			b[i]-='a';
			if(ac[a[i]]++==0)acnt++;
			if(bc[b[i]]++==0)bcnt++;
			x[a[i]*26+b[i]]++;
		}
		long ans=0;
		for(i=0;i<x.length;i++){
			if(x[i]==0)continue;
			cal(i);
			if(x[i]>=2){
				cal(i);
				if(acnt==bcnt){
					ans=(ans+1l*x[i]*(x[i]-1)/2%p)%p;
				}
				recal(i);
			}
			for(j=i+1;j<x.length;j++){
				if(x[j]==0)continue;
				cal(j);
				if(acnt==bcnt){
					ans=(ans+1l*x[i]*x[j]%p)%p;
				}
				recal(j);
			}
			recal(i);
		}
		out.println(ans);
	}
	int te;
	void run()throws IOException{
		int t=1;
//		t=in.in();
		for(te=1;te<=t;te++){
			solve();
//			out.flush();
		}
		out.close();
	}
	public static void main(String[]args)throws IOException{
		new Main().run();
	}
	In in=new In();
	PrintWriter out=new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	class In{
		StringTokenizer st=new StringTokenizer("");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String ins() throws IOException{
			while(!st.hasMoreTokens())st=new StringTokenizer(br.readLine());
			return st.nextToken();
		}
		int in()throws IOException{
			return Integer.parseInt(ins());
		}
	}
}
