#include<iostream>
#include<cstring>
#include<algorithm>

using namespace std;
typedef long long int ll;
ll n,m;

int main()
{
	cin>>n>>m;
	if(m>=n) cout<<"NO";
	else if(m == 1||n == 1) cout<<"YES";
	else
	{
		ll x=n%m;
			if(x==0) 
			{
				cout<<"NO";
				return 0;
			}
			else if(x==1) 
			{
				cout<<"YES";
				return 0;
			}
			else
			{
				while(1)
		{
			x=n%x;
			if(x==0) 
			{
				cout<<"NO";
				break;
			}
			if(x==1) 
			{
				cout<<"YES";
				break;
			}
		}
			}
		
	
	} 
}