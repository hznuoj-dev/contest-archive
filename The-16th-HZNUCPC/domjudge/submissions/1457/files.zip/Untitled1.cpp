#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int MAX = 1e6 + 10;
const double PI = acos(-1);
int a[MAX], cnt = 0;
void check(ll n) {
	for (int i = 2; i <= sqrt(n); i++) {
		if (n % i == 0) {
			a[++cnt] = i;
			a[++cnt] = n / i;
		}
	}
}
void solve() {
	ll n, m;
	cin >> n >> m;
	if (m == 1 || n == 1 || (n == 3 && m == 2)) {
		cout << "YES";
		return ;
	}
	if (n <= m) {
		cout << "NO";
		return ;
	}
	check(n);
	if (a[1] <= m) cout << "NO";
	else cout << "YES";
}
int main() {
	solve();
	return 0;
}