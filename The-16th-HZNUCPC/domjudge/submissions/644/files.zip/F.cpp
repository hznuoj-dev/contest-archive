#include <bits/stdc++.h>
#define ln '\n'

int main() {
	long long a, b;
	std::cin >> a >> b;
	if(a == 1) return std::cout << "YES\n", 0;
//	bool flag = false;
//	long long lst = b;
//	while(b > 1) 
//		b = a % b;
//	std::cout << (b == 1 ? "YES\n" : "NO\n");
	for(long long i = 1; i * i <= a; i++) {
		int d = i;
		if(a % d == 0) {
			if(d == 1);
			else if(d <= b) 
				return std::cout << "NO\n", 0;
			d = a / d;
			if(d <= b) 
				return std::cout << "NO\n", 0;
		}
		
	}
	std::cout << (a % b != 0 ? "YES\n" : "NO\n");

}