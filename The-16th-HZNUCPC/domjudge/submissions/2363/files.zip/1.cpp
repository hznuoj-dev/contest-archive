#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int main()
{
    int t;
    cin >> t;
    while(t--)
    {
        int n;
        cin>>n;
        int a[20][20]={0};
        ll flag=0;
        while (n -- )
        {
            int x,y,c;
            cin >> x >> y >> c;
            if (c==1)
            {
                a[x][y]=5;
                a[x-1][y]++;
                a[x+1][y]++;
                a[x][y+1]++;
                a[x][y-1]++;
            }
        }
        for (int i=1;i<=19;i++)
        {
            for (int j=1;j<=19;j++)
            {
                if (a[i][j]!=0 && a[i][j]<=4) flag+=a[i][j];
                if (a[i][j]>=7) flag++;
            }
        }

        cout << flag <<endl;



    }

    return 0;
}
