#include<bits/stdc++.h>
//#define int long long
//#define mid (l+r>>1)
using namespace std;
typedef long long ll;


int main(){
	ll n,m;
	bool f=1;
	scanf("%lld%lld",&n,&m);
	for(int i=2;(long long)i*i<=n;i++){
		if(n%i==0){
			//printf("%d\n",i);
			if(i<=m)f=0;
			break;
		}
	}
	if(n<=m&&n!=1)f=0;
	if(f){
		printf("YES\n");
	}else{
		printf("NO\n");
	}

	return 0;	
}