#include<bits/stdc++.h>
using namespace std;
const int N=110;
struct node{
	int x,y;
}a[N];
int ans,sum;
int cal(int a,int b,int c,int d,double k){
	if(k==0) return fabs(c-a);
	if(fabs(k)<1) return fabs(a-c)*fabs(k);
	else return fabs(b-d)/fabs(k);
}
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++) scanf("%d%d",&a[i].x,&a[i].y);
	for(int i=1;i<=n;i++){
		int x1=a[i].x,y1=a[i].y;
		for(int j=i+1;j<=n;j++){
			int x2=a[j].x,y2=a[j].y;
			int t=0;
			double k1;
			if(x1==x2) t=fabs(y1-y2);
			else{
				double k1=fabs(1.0*(y2-y1)/(x2-x1));
				t=cal(x1,y1,x2,y2,k1);
			}
			sum=0;
			for(int k=j+1;k<=n;k++){
				int x3=a[k].x,y3=a[k].y;
				if(x1==x2&&x2==x3){
					sum=0;
					continue;
				}
				int p=0,q=0;
				double k2;
				if(x3!=x1) k2=(1.0*(y3-y1)/(x3-x1));
				else p=fabs(y3-y1);
				double k3;
				if(x2!=x3) k3=(1.0*(y2-y3)/(x2-x3));
				else q=fabs(y2-y3);
				if(k2==k3){
					sum=0;
					continue;
				}
				else{
					if(!p) p=cal(x1,y1,x3,y3,k2);
					if(!q) q=cal(x2,y2,x3,y3,k3);
					sum+=t+p+q;
				}
				ans=max(ans,sum);
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}