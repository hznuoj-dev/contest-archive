#include <iostream>
using namespace std;
long long a,b;
int main() {
	cin >> a >> b;
	if ((a == 1 || b == 1) || (a % 2 == 1 && a > b)) cout << "YES" << endl;
	else cout << "NO" << endl;
}
