#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll P=1e9+7;
ll cnt[26][26];
ll c1[26],c2[26],ans;
ll qmi(ll x,ll k){
	ll res=1;
	x=(x%P+P)%P;
	for(;k;k>>=1ll){
		if(k&1ll)
		ans=(x*ans)%P;
		x=x*x%P;
	}
	return res;
}
int main(){
	string st1,st2;
	cin>>st1>>st2;
	for(int i=0;i<st1.size();i++){
		c1[st1[i]-'a']++;
		c2[st2[i]-'a']++;
		cnt[st1[i]-'a'][st2[i]-'a']++;
	}
	for(int p11=0;p11<26;p11++)
		for(int p12=0;p12<26;p12++){
			if(!cnt[p11][p12])continue;
			for(int p21=0;p21<26;p21++)
				for(int p22=0;p22<26;p22++){
					if(!cnt[p21][p22])continue;
					
					c1[p11]--;c1[p12]++;c1[p21]--;c1[p22]++;
					c2[p11]++;c2[p12]--;c2[p21]++;c2[p22]--;
					
					int cnt1=0,cnt2=0;
					for(int i=0;i<26;i++){
						if(c1[i])
							cnt1++;
						if(c2[i])
							cnt2++;
					}
					if(cnt1==cnt2){
						if(p11==p21&&p12==p22)
							ans=(ans+cnt[p11][p12]*(cnt[p21][p22]-1)%P)%P;else
							ans=(ans+cnt[p11][p12]*cnt[p21][p22]%P)%P;
					}
					
					
					c1[p11]++;c1[p12]--;c1[p21]++;c1[p22]--;
					c2[p11]--;c2[p12]++;c2[p21]--;c2[p22]++;
				}
		}
	cout<<ans*qmi(2,P-2)%P;
}