#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdio>
#include<queue>
#include<map>
#include<vector>
#define int long long
#define FOR(i,m,n) for(int i = m;i <= n;i++)
#define CLR(arr,value) memset(arr,value,sizeof arr)
using namespace std;
const int N = 0x3f3f3f;
int tt,n,k;
int cnt = 0;
bool f;
signed main()
{
	while(cin >> n >> k)
	{
		if(n == 1 || k == 1)
		{
			puts("YES");
			continue;
		}
		if(k >= n){puts("NO");continue;}
		bool f = 1;
		for(;;){
			if(k == 1)break;
			if(n%k == 0){f = 0;break;}
			int x = n%k;
			int y = n/k * (k-x);
			int z = (n/k+1)*x;
			if(y > z)k = (k-x);
			else k = x;
		}
        if(f) puts("YES"); 
		else puts("NO");
	}
}