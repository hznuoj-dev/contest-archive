#include<bits/stdc++.h>
#define M 100005
using namespace std;
template<class T,class... A> void odn(T&& x, A&&... a) {cout<<x; (int[]){(cout<<' '<<a,0)...}; cout<<'\n';}
int flag,cnt,n,q,m,col[M],belong[M];
struct hzl{
    int a,b;
};
vector<hzl>E[M];
struct hzl2{
    vector<int>a,b;
}block[M];
void dfs(int x,int c){
    col[x]=c;
    if(flag)return ;
    for(int i=0;i<E[x].size();i++){
        int v=E[x][i].a;
        if(col[v]==-1)dfs(v,c^E[x][i].b);
        else if(col[v]!=c^E[x][i].b)flag=1;
    }
    return ;
}
void find(int x){
    if(col[x]==1)block[cnt].a.push_back(x);
    else block[cnt].b.push_back(x);
    col[x]=3;
    for(int i=0;i<E[x].size();i++){
        int v=E[x][i].a;
        if(col[v]==3)continue;
        find(v);
    }
    return ;
}
vector<int> goodn[M];
int usenum[M];
int lst[500][M*2];
int main(){
    memset(col,-1,sizeof(col));
    scanf("%d%d%d",&n,&q,&m);
    for(int i=1;i<=m;i++){
        int f,a,b;
        scanf("%d%d%d",&f,&a,&b);
        E[a].push_back((hzl){b,f});
        E[b].push_back((hzl){a,f});
    }
    for(int i=1;i<=n;i++){
        if(col[i]==-1){
            dfs(i,1);
            cnt++;
            find(i);
        }
    }
    if(flag){
        puts("NO");
        return 0;
    }
    // odn(cnt);
    for (int i = 1; i <= cnt; i++) {
        if (block[i].a.size() < block[i].b.size()) swap(block[i].b, block[i].a);
        // odn(i, block[i].a.size(), block[i].b.size());
        goodn[block[i].a.size() - block[i].b.size()].push_back(i);
    }
    int mov = M;
    int ccnt = 0; 
    // lst[0][0+mov] = -1;
    lst[0][mov] = 1;
    vector<pair<int,int>> n0p{{0,0}}; 
    for (int i = 0; i < M; i++) if (goodn[i].size()) {
        // odn(i, goodn[i].size());
        // for (int k = 0; k <= 2*M; k++) lst[ccnt][k] = lst[ccnt-1][k];
        vector<int> sp;
        int rem = goodn[i].size();
        for (int j = 1; j <= rem; j = j * 2) {
            rem -= j;
            sp.push_back(j);
        }
        if (rem) sp.push_back(rem);
        for (int j : sp) {
            ccnt++;
            n0p.push_back({i, j});
            int a = j * i;
            for (int k = 0; k < 2*M; k++) if (lst[ccnt-1][k] != 0) {
                if (k+a < 2*M) lst[ccnt][k+a] = j;
                if (k-a >= 0) lst[ccnt][k-a] = -j;
            }
        }
    }
    int needq = q - (n - q);
    if (!lst[ccnt][needq + M]){
        puts("NO");
        return 0;
    }
    puts("YES");
    int p = needq + M;
    // odn(p);
    for (int i = ccnt; i >= 1; i--) {
        int eleid = i;
        usenum[n0p[eleid].first] += lst[i][p];
        p -= n0p[eleid].first * lst[i][p];
    }
    // odn(p);
    assert(p == M);

    // for (auto i : block[1].a) odn(i); 
    // for (auto i : block[1].b) odn(i); 
    vector<int> ans;
    for (int i = 0; i < M; i++) {
        // if(usenum[i]) odn(usenum[i]);
        // odn(usenum[i]);
        int st = 0;
        for (int j = 0; j < usenum[i]; j++) {
            for (int k : block[goodn[i][st++]].a)
                ans.push_back(k);
                // printf("%d ", k);
        }
        for (int j = 0; j < -usenum[i]; j++) {
            for (int k : block[goodn[i][st++]].b)
                ans.push_back(k);
                // printf("%d ", k);
        }
    }
    sort(begin(ans), end(ans));
    for(auto i: ans) printf("%d ", i);
    puts("");
    return 0;
}