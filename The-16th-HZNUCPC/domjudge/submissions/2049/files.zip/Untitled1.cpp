#include<bits/stdc++.h>
using namespace std;
string fun(string s)	{
	int len = s.size();
	string out = "0";
	for (int i = len - 1; i >= 0; i--)
		out = s[i] + out, out = '0' + out;
		//cout << out;
	return out;
}
void func(string s)	{
	int len = s.size(), ans = 0;
	for (int i = 1; i < len - 1; i++)	{
		int w = 0, p[2][2];
		//printf("\n%d\n", i);
		for (int j = 1; i + j < len && i - j >= 0; j++)	{
			if (s[i + j] != s[i - j])	{
				//printf("%d ", w);
				w++;
				if (w == 3)	break;
				p[w - 1][0] = i - j, p[w - 1][1] = i + j;
			}
			if (w == 0)	ans = max(ans, j == 1 ? 0 : j);
			if (w == 2)	{
				//printf("%d %d %d %d\n", p[0][0], p[0][1], p[1][0], p[1][1]);
				if (s[p[0][0]] == s[p[1][0]] && s[p[0][1]] == s[p[1][1]])
					ans = max(ans, j == 1 ? 0 : j);
				if (s[p[0][0]] == s[p[1][1]] && s[p[0][1]] == s[p[1][0]])
					ans = max(ans, j == 1 ? 0 : j);
			}
		}
	}
	printf("%d\n", ans);
}
int main(){
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++)	{
		string s;
		cin >> s;
		func(fun(s));
	}
	return 0;
}