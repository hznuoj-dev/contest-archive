import math
n,m=map(int,input().split())
if m==1:
    print("YES")
elif(n%m==0 and n%2==0):
    print("NO")
else:
    min=n
    for i in range(2,int(pow(n,0.5))+1):
        if n%i==0:
            min=i
            break
    if min<=m:
        print("NO")
    else:
        print("YES")
