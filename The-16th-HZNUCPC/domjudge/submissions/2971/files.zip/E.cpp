#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
typedef long long ll;
struct node{
	ll x,y;	
}a[110];
int main(void){
	ll n;
	cin>>n;
	for(ll i=1;i<=n;i++){
		cin>>a[i].x>>a[i].y;
	}
	ll ans=0;
	for(ll i=1;i<=n-2;i++){
		for(ll j=i+1;j<=n-1;j++){
			for(ll k=j+1;k<=n;k++){
				if((a[i].x==a[j].x&&a[j].x==a[k].x)||(a[i].y==a[j].y&&a[j].y==a[k].y)){
					continue;
				} else {
					if(((a[j].y-a[i].y)*(a[k].x-a[i].x))==((a[k].y-a[i].y)*(a[j].x-a[i].x))){
						continue;
					}
				}
				ll tans=0;
				if(a[i].x==a[j].x){
					tans+=abs(a[j].y-a[i].y);
				} else if(a[i].y==a[j].y){
					tans+=abs(a[j].x-a[i].x);
				} else {
					tans+=__gcd(abs(a[j].y-a[i].y),abs(a[j].x-a[i].x));
				}
				if(a[i].x==a[k].x){
					tans+=abs(a[k].y-a[i].y);
				} else if(a[i].y==a[k].y){
					tans+=abs(a[k].x-a[i].x);
				} else {
					tans+=__gcd(abs(a[k].y-a[i].y),abs(a[k].x-a[i].x));
				}
				if(a[k].x==a[j].x){
					tans+=abs(a[j].y-a[k].y);
				} else if(a[k].y==a[j].y){
					tans+=abs(a[j].x-a[k].x);
				} else {
					tans+=__gcd(abs(a[j].y-a[k].y),abs(a[j].x-a[k].x));
				}
				ans=max(ans,tans);
			}
		}
	}
	cout<<ans;
	return 0;
}