#include <iostream>
#include <algorithm>
#include <cmath>
#include <stack>
#include <map>
#include <cstring> 
#define qcin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define endl '\n'
#define int long long
using namespace std;
int sort1(int x){
	for(int i=3;i<=sqrt(x);i++){
		if(x%i==0)return i;
	}
	return 0;
}

signed main(){
	int n,m;
	cin>>n>>m;
	if(m == 1)
	{
		cout<<"YES";
		return 0;
	}
	
	
	if(n%m == 0)	cout<<"NO";
	else
	{
		if(n%2 == 0)	
		{
			cout<<"NO";
			return 0;
		}
		else 
		{
			int cnt=sort1(n);
			if(cnt!=0){
				if(m>=cnt)cout<<"NO";
				else cout<<"YES";
			}
			else cout<<"YES";
		}
		
	}


	return 0;
}