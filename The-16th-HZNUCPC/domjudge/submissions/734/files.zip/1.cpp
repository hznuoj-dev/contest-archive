#include<bits/stdc++.h>
using namespace std;
const int P = 1e9+7;
string a,b;
int cnta[26],cntb[26];
map<pair<int,int>,int>mp;
long long Calc(long long a, long long b)
{
	long long res = 1;
	while(b)
	{
		if(b&1)res = res * a % P;
		a = a * a % P,b>>=1;
	}
	return res;
}
int main()
{
	ios::sync_with_stdio(false);
	cin>>a>>b;
	int n = a.length();
	for(int i = 0; i<n; i++)
	{
		cnta[a[i]-'a']++;
		cntb[b[i]-'a']++;
	}
	int tota = 0, totb = 0;
	for(int i = 0; i<26; i++)
	{
		if(cnta[i]!=0)
			tota++;
		if(cntb[i]!=0)
			totb++;
	}
	for(int i =0; i<26; i++)
		for(int j = 0; j<26; j++)
			mp[make_pair(i,j)] = 0;
	long long ans = 0;
	for(int i = 0; i<n; i++)
		mp[make_pair(a[i]-'a',b[i]-'a')]++;
	for(int i = 0; i<26; i++)
		for(int j = 0; j<26; j++)
			for(int k = 0; k<26; k++)
				for(int l = 0; l<26; l++)
				{
					int nowa = 0, nowb = 0;
//					
//					int ctai = cnta[i], ctak = cnta[k], ctaj = cnta[j], ctal = cnta[l];
//					int ctbi = cntb[i], ctbk = cntb[k], ctbj = cntb[j], ctal = cnta[l];
					
					cnta[i]--,cnta[k]--;
					cnta[j]++,cnta[l]++;
					
					cntb[j]--,cntb[l]--;
					cntb[i]++,cntb[k]++;
					
					for(int c = 0; c<26; c++)
					{
						if(cnta[c]>0)nowa++;
						if(cntb[c]>0)nowb++;
					}
					
					cnta[i]++,cnta[k]++;
					cnta[j]--,cnta[l]--;
					
					cntb[j]++,cntb[l]++;
					cntb[i]--,cntb[k]--;
					
					if(nowa==nowb)
					{
						if(i==k&&j==l)
						{
							long long c = mp[make_pair(i,j)];
							ans = (ans + 1ll * c * (c-1) % P) % P;
						}
						else 
						{
							long long c1 = mp[make_pair(i,j)];
							long long c2 = mp[make_pair(k,l)];
							if(c1!=0||c2!=0)
							ans = (ans + 1ll * c1 * c2 % P) % P;
						}
					}
				}
	cout<<ans * Calc(2,P-2) % P<<"\n";
	return 0;
}