#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long int i,j,x,n,m;
    scanf("%lld%lld",&n,&m);
    
    if(n%2==0||m>=n)
    {
    	printf("NO");
	}
	else
	{
		for(j=2;j<=m;j++)
		{
			if(n%j==0)
			{
//				printf("NO");
//				j=-1;
				break;
			}
		}
		
		if(j>m)
			printf("YES");
		else
			printf("NO");
	}
}