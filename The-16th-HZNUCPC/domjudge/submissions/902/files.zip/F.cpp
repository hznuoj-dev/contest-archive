#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
    ll n,m,a,b;
    cin>>n>>m;
    if(m==1)cout<<"YES"<<endl;
    else if(m>=n||n%m==0)cout<<"NO"<<endl;
    else{
    	a=(n-1)/m+1;
    	b=n/a;
    	if(b==1)cout<<"YES"<<endl;
    	else if(n%b==0)cout<<"NO"<<endl;
    	else cout<<"YES"<<endl;
	}
    
    return 0;
}
