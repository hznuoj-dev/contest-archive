#include <bits/stdc++.h>
using namespace std;
#define ll long long

ll n,m;
int main()
{
    scanf("%lld%lld",&n,&m);
    for (ll i=2;i<=sqrt(n);i++)
    {
        if (n%i==0)
        {
            n=i;
            break;
        }
    }
    if (n==1 || m==1)printf("YES\n");
    else if (n<=m)printf("NO\n");
    else printf("YES\n");
    return 0;
}
