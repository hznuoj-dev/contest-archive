#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n, m;

int main() {
	ios::sync_with_stdio(false);
	cin >> n >> m;
	vector<ll> ans;
	for (ll i = 2; i * i <= n; ++i) {
		if (n % i == 0) {
			if (i * i != n) {
				ans.push_back(i);
				ans.push_back(n / i);
			} else ans.push_back(i);
		}
	}
	if (n > 1) ans.push_back(n);
	sort(ans.begin(), ans.end());
	bool flag = true;
	for (ll i : ans) {
		if (i <= m)
			flag = false;
	}
	cout << (flag ? "YES" : "NO") << "\n";
	return 0;
}