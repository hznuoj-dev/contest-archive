#include <bits/stdc++.h>
using namespace std;
int main(void)
{
	long n,m;
	cin >> n >> m;
	
	if(m == 1) cout << "YES";
	else 
	{
		if(n % m == 0)
		 	cout << "NO";
		else 
			cout << "YES";
	}
	return 0;
}