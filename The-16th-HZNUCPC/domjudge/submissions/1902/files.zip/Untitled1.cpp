#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 7;
int n,m;
struct node {
	int x,y;
}a[110];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int T;
	T = 1;
	while(T --){
		cin >> n;
		for(int i = 0; i < n ; i ++){
			cin >> a[i].x >> a[i].y;
		}
		int ans = 0;
		for(int i = 0; i < n - 2; i ++)
			for(int j = i + 1; j < n - 1; j ++)
				for(int k = j + 1; k < n; k ++){
					int res  = 0;
					int ok=1;
					int u[3] = {i, j, k};
					node k1,k2;
					k1.x = abs(a[i].x - a[j].x);
					k1.y = abs(a[i].y - a[j].y);
					k2.x = abs(a[i].x - a[k].x);
					k2.y = abs(a[i].y - a[k].y);
					k1.x/=__gcd(k1.x,k1.y);
					k1.y/=__gcd(k1.x,k1.y);
					k2.x/=__gcd(k2.x,k2.y);
					k2.y/=__gcd(k2.x,k2.y);
					if(k1.x==k2.x&&k2.x==k1.x) ok=0;
					for(int p = 0; p < 2; p ++)
						for(int q = p + 1; q < 3; q ++){
							node k;
							k.x = abs(a[u[p]].x - a[u[q]].x);
							k.y = abs(a[u[p]].y - a[u[q]].y);
							int w = __gcd(k.x,k.y);
							if(k.x && k.y)res += w + 1;
							else if(k.x) res += k.x + 1;
							else res += k.y + 1;
						}
					res -= 3;
					if(ok)ans = max(res,ans);
				}
		cout << ans << endl;
	}
}