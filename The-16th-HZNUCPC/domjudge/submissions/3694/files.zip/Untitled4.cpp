#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main() {
	int n,m;

	while(cin >> n >> m) {
		if(n % m == 0){
			cout << "NO" << endl;
		}else{
			cout<< "YES" << endl;	
		}

	return 0;

}
}