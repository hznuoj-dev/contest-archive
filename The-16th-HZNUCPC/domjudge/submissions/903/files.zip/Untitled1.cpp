#include<bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i,l,r) for(int i=l;i<=r;++i)
#define N 110
#define M 50
int n,m;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n>>m;
	while(m!=1&&m!=0){
		m=n%m;
	}
	if(m==1)cout<<"YES";
	else cout<<"NO";
}