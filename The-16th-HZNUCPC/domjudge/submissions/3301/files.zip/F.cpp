#include<bits/stdc++.h>

using namespace std;

int main() {
	long long n,m,k;
	while(scanf("%lld %lld",&n,&m)!=EOF)
	{
		k=0;
		if(m==1)
	{
		k=1;
		printf("YES\n");
	}
	while(m!=0)
	{
		m=n%m;
		if(m==1)
		{
			k=1;
			printf("YES\n");
			break;
		}
	}
	if(k==0)
	printf("NO\n");
	}
	return 0;
}

