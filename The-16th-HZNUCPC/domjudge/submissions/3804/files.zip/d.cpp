#include <bits/stdc++.h>

using i64 = long long;

const int inf = 100000000;


struct Node{
	int l,r;
	int min;
	Node(int x = inf){
		min = x;
	}
	friend Node merge(const Node &lh,const Node &rh){
		Node ans;
		ans.l = lh.l;
		ans.r = rh.r;
		ans.min = std::min(lh.min,rh.min);
		return ans;
	}
	void apply(int y){
		if (y == inf) {
			return;
		}
		min  = y;
	}
};

void apply(int &x, int y) {
	if (y == inf) {
		return;
	}
	x = y;
}

struct seg {
	const int n;
	std::vector<Node> info;
	std::vector<int> tag;
	seg(int n):n(n),info(n*4),tag(4 * n,inf){}
	seg(std::vector<int> a) : seg(int(a.size()) - 1) {
		auto dfs = [&](auto self, int p, int l, int r) -> void {
			if(l == r){
				info[p].l = l;
				info[p].r = r;
				info[p].min = a[l];
//				std::cerr << p << ' ' << l << ' ' << r << ' ' << info[p].min<<'\n';
//				std::cerr  << p << ' '<< l <<' ' << info[p].min<<'\n';
				return;
			}
			int m = (l + r) >> 1;
			self(self, 2*p,l,m);
			self(self, 2*p+1,m+1,r);
			
			pull(p);
//			std::cerr << p  << ' ' << l << ' ' << r << ' ' << info[p].min<<'\n';
		};
		dfs(dfs, 1, 1, n);
	}
	void pull(int p) {
		info[p] = merge(info[2 * p], info[2 * p + 1]);
	}
	void push(int p) {
		apply(2 * p, tag[p]);
		apply(2 * p + 1, tag[p]);
		tag[p] = inf;
	}
	void apply(int p, int t) {
		info[p].apply(t);
		::apply(tag[p], t);
	}
	void rangeModify(int p,int l,int r,int x,int y,int v){
		if( x <= l && r <= y){
			apply(p, v);
			return;
		}
		push(p);
		int m = (l+r)>>1;
		if(m >= x)rangeModify(p*2,l,m,x,y,v);
		if(m < y)rangeModify(2*p+1,m+1,r,x,y,v);
		pull(p);
	}
	Node rangeQry(int p,int l,int r,int x,int y){
		if(x > r|| y < l){
			return Node();
		}
		if(x <= l && r <= y){
			return info[p];
		}
		push(p);
		int m = (l + r) >> 1;
		return merge(rangeQry(2*p,l,m,x,y),rangeQry(2*p+1,m+1,r,x,y));
	}
	
	int find(int p,int l,int r,int x){
		if (l == r) {
			return l;
		}
		if (info[p].min > x) {
			return r;
		}
		int m = (l + r) >> 1;
		if(info[p*2].min <= x)return find(p*2,l,m,x);
		else return find(p*2,m+1,r,x);
	}
};

struct bus{
	int t,l,r;
	bus(int t,int l,int r):t(t),l(l),r(r){}
	bus(){	}
	bool operator < (const bus&rhs)const{
		return t == rhs.t ?  r > rhs.r : t > rhs.t;
	}
};
struct person{
	int t,p,id;
	person(int t,int p,int id):p(p),t(t),id(id){}
	person(){	}
	bool operator < (const person&rhs)const{
		return t > rhs.t;
	}
};

void solve() {
	int n, m ,x;
	std::cin >> n >> m >> x;
	std::vector<bus>buses(n);
	std::vector<person>persons(m);
	std::vector<int>cnt;
	cnt.push_back(x);
	cnt.push_back(0);
	for(auto &[t,l,r]: buses){
		std::cin >> t >> l >> r;
		cnt.push_back(l);
		cnt.push_back(r);
	}
	
	
	for(int tot = 0;auto &[t,p,id]:persons){
		std::cin >> t >> p;
		id = tot++;
		cnt.push_back(p);
	}


	std::sort(cnt.begin(),cnt.end());
	cnt.erase(std::unique(cnt.begin(),cnt.end()),cnt.end());


	for(auto &[t,l,r]:buses){
		l = std::lower_bound(cnt.begin(),cnt.end(),l) - cnt.begin();
		r = std::lower_bound(cnt.begin(),cnt.end(),r) - cnt.begin();
	}
	for(auto &[t,p,id]:persons){
		p = std::lower_bound(cnt.begin(),cnt.end(),p) - cnt.begin();
	}
	x = std::lower_bound(cnt.begin(),cnt.end(),x) - cnt.begin();
	
	std::sort(buses.begin(),buses.end());
	std::sort(persons.begin(),persons.end());
	
	std::vector<int>a(cnt.size(),inf);
	a[x] = 0;
	int len = cnt.size() - 1;
//	std::cout<<cnt.size() << ' ';
//	std::cout << x << '\n';
	
	int ptr = 0;
	seg Tree(a);
//	std::cerr << len << "!\n";
//	for (int i = 1; i <= len; i++) {
//		std::cout << Tree.rangeQry(1, 1, len, i, i).min << " \n"[i == len];
//	}
//	std::cerr << Node().min<<'\n';
	auto add=[&](int x){
		auto [t,l,r] = buses[x];
		auto now = Tree.rangeQry(1,1,len,l,r);
 		int mint = now.min + 1;
		int pos = Tree.find(1,1,len,mint);
		pos -- ;
		if(pos >= l)Tree.rangeModify(1,1,len,l,pos,mint);
	};
	std::vector<int>res(m);
	for(int i = 0; i < m; ++i){
		auto [tim,pos,id] = persons[i];
//		std::cout<<tim <<' ' << pos <<"RRR\n";
		while(ptr < n && buses[ptr].t >= tim){
			add(ptr);
			ptr++;
		}
//		std::cerr << len << "!\n";
//		for (int i = 1; i <= len; i++) {
//			std::cout << Tree.rangeQry(1, 1, len, i, i).min << " \n"[i == len];
//		}
//		std::cout << pos << "AAA";
		auto ans = Tree.rangeQry(1,1,len,pos,pos);
		if(ans.min == inf)res[id]=-1 ;
		else res[id]=ans.min;
	}
	for(auto x :res)std::cout<<x <<'\n';
//	std::cout<<Tree.info[1].min;
//	std::vector<int>a(n+1)
}

int main() {
	freopen("in.txt", "r", stdin);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int t;
//	std::cin >> t;
	t = 1;
	while (t--) {
		solve();
	}

	return 0;
}

/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5
*/
