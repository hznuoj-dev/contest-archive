#include<bits/stdc++.h>

#define all(a) a.begin(),a.end()
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define pb push_back
#define fi first
#define se second
#define quick ios.sync_with_stdio(false);cout.tie(0);cin.tie(0);
#define PLL pair<ll,ll>
#define debug(a) cout<<#a<<" "<<a<<endl 

typedef long long ll;
typedef unsigned long long ull;

using namespace std;

const ll mod=1e9+7;

ll n,m;
ll mp[27][27];

ll qpow(ll num,ll q){
	ll res=1;
	while(q){
		if(q&1)res*=num;
		res%=mod;
		num*=num;
		num%=mod;
		q>>=1;
	}
	return res%mod;
}

void solve(){
	string a,b;
	cin>>a>>b;
	set<char>sta,stb;
	vector<ll>mpa(26,0),mpb(26,0);
	rep(i,0,a.size()){
		sta.insert(a[i]);
		stb.insert(b[i]);
		mpa[a[i]-'a']++;
		mpb[b[i]-'a']++;
		mp[a[i]-'a'][b[i]-'a']++;
	}
	ll dis=sta.size()-stb.size();
	if(abs(dis)>4){
		cout<<0<<endl;
		return ;	
	}
	ll ans=0;
	rep(i,0,26){
		rep(j,0,26){
			if(mp[i][j]==0)continue;
			rep(k,0,26){
				rep(h,0,26){
					if(mp[k][h]==0)continue;		
					vector<ll>mpat=mpa,mpbt=mpb;
					mpat[i]--;
					mpbt[i]++;
					mpat[k]--;
					mpbt[k]++;
					mpbt[j]--;
					mpat[j]++;
					mpbt[h]--;
					mpat[h]++;
					ll siza=0,sizb=0;
					rep(i,0,26){
						if(mpat[i]!=0)siza++;
						if(mpbt[i]!=0)sizb++;
					}
					if(siza==sizb&&i==k&&j==h)ans+=(mp[i][j]-1)*(mp[k][h])%mod;
					else if(siza==sizb)ans+=mp[i][j]*mp[k][h]%mod;ans%=mod;
				}
			}
		}
	}
	cout<<ans*qpow(2,mod-2)%mod<<endl;
}

int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
