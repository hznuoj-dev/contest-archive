#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 10;
int p[N];
//char a[N], b[N << 1];
string a, b;
int len;
void build() {
	int k = 0;
	len = a.length();
	b += '$';
	b += '#';
//	b[k++] = '$', b[k++] = '#';
	
	for (int i = 0; i < len; ++i) {
//		b[k++] = a[i];
//		b[k++] = '#';
		b += a[i];
		b += '#';
	}
//	b[k++] = '^';
	b += '^';
	len = 2 * len + 2; 
}
void manacher() {
	int mr = 0, mid;
	for (int i = 1; i < len; ++i) {
		if (i < mr) p[i] = min(p[mid * 2 - 1], mr - i);
		else p[i] = 1;
		while(b[i - p[i]] == b[i + p[i]]) p[i]++;
		if (i + p[i] > mr) {
			mr = i + p[i];
			mid = i;
		}
	}
}
void solve() {
	a = "", b = "";
	cin >> a;
	build();
	for (int i = 0; i <= len; ++i) p[i] = 0;
	manacher();
//	for (int i = 1; i <= len; ++i) {
//		cout << p[i] << " ";
//	}
//	cout << endl;
	map<char, int> mp;
	int res = 0;
	for (int i = 1; i < len; ++i) {
		int cnt = 0;
		res = max(res, p[i] - 1);
		mp.clear();
		int j = 0;
		bool f = 0;
		for (j = 0; i + j + p[i] < len && i - j - p[i] > 0; ++j)
		{  
			if (b[i + p[i] + j] != b[i - p[i] - j]) {
				if (cnt == 2) break;
				if (cnt == 0 && b[i] != '#') {
					if (b[i] == b[i + p[i] + j] || b[i] == b[i - p[i] - j]) {
						f = 1;
					}
				}
				if (cnt == 1 && f) {
					res = max(res, p[i] + j - 1);
				} 
				cnt++;
				mp[b[i + p[i] + j]]++;
				mp[b[i - p[i] - j]]++;
			}
		}
		if (cnt == 1 && f) {
			res = max(res, p[i] + j - 1);
		}
		if (mp.size() == 2) {
			auto it = mp.begin();
			if (it->second != 2) continue;
			it++;
			if (it->second != 2) continue;
			res = max(res, p[i] + j - 1);
		} 
//		cout << res << " ";
		//ecceddabcdedcbeddacca
	}  
	if (res == 1) res = 0;
	cout << res << endl;
}
signed main() {
	int t = 1;
	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
}