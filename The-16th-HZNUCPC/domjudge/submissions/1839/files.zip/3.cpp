#include <stdio.h>

int main(){
	int n,m,f = 1;
	scanf("%d %d",&n,&m);
	if(m == 1)
	{
		printf("YES");
		return 0;
	}
	while(f)
	{
		m = n % m;
		if(m == 1) 
		{
			printf("YES");
			f = 0;
		}
		if(m == 0) 
		{
			printf("NO");
			f = 0;
		}
	}
	return 0;
}