#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
const int N = 1e5 + 10, mod = 1e9 + 7;
int a[30], b[30];
ll n, cnt1, cnt2, ans;
map<ll, ll> mp;
vector<ll> change;
void solve()
{
	string sa, sb;
	cin >> sa >> sb;
	for(int i = 0; i < sa.length(); i++){
		if(a[sa[i] - 'a'] == 0) cnt1++;
		a[sa[i] - 'a'] ++;
	}
	for(int i = 0; i < sb.length(); i++){
		if(b[sb[i] - 'a'] == 0) cnt2++;
		b[sb[i] - 'a'] ++;
	}
	int x = cnt1 - cnt2;
	for(int i = 0; i < sa.length(); i++) {
		int mv = 0;
		if(a[sa[i] - 'a'] == 1) {
			mv --;
		}
		if(a[sb[i] - 'a'] == 0) {
			mv ++;
		}
		if(b[sb[i] - 'a'] == 1) {
			mv ++;
		}
		if(b[sa[i] - 'a'] == 0) {
			mv --;
		}
		change.push_back(mv);
		mp[mv] ++;
	}
	sort(change.begin(), change.end());
	change.erase(unique(change.begin(), change.end()), change.end());
	for(int i = 0; i < change.size(); i++) {
		if(change[i] != x + change[i]){
		ans += mp[change[i]] * mp[x + change[i]];
		mp[change[i]] = mp[x + change[i]] = 0;
		}
		else ans += (mp[change[i]]) * (mp[change[i]] - 1) / 2;
		ans %= mod;
	}
	cout << ans << "\n";
}

int main()
{
	IOS
	int T = 1;
//	cin >> T;
	while(T--) 
		solve();	
	return 0;
}