package zime;

import java.util.Scanner;

public class jisuan {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		long sum=0;
		int a=1000000006;
		int b=1000000006;
		sum=lj(b);
		System.out.print(sum);
		while(sc.hasNext()){
			
		}
	}
private static long lj(long zag) {
		
		return (zag)*((zag-1))/2;
	}
}
