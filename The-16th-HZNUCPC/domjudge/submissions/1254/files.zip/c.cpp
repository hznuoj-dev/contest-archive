#include <iostream>
#include <algorithm>
#include <vector>
#include <cstring>
using namespace std;
typedef pair<int,int> pii;
int vis[30][30];
bool vis2[30][30];
pii dir[4] = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}};
void solve() {
    memset(vis, 0, sizeof vis);
    memset(vis2, 0, sizeof vis2);
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        int r, c, w;
        cin >> r >> c >> w;
        vis2[r][c] = 1;
        for (int j = 0; j < 4; j++) {
            int tr = r +dir[j].first;
            int tc = c +dir[j].second;
            if(tr <1 || tr > 19 ||tc < 1 || tc > 19) continue;
            if(w == 1) {
                vis[tr][tc]++;
            }
        }
    }
    int ans = 0;
    for (int i = 1; i <= 19; i++) {
        for (int j = 1; j <= 19; j++) {
            if(vis2[i][j]) continue;
            ans += vis[i][j];
        }
    }
    cout << ans <<"\n";
    
}
int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int t;
    std::cin >> t;
    while (t--) {
        solve();
    }
}