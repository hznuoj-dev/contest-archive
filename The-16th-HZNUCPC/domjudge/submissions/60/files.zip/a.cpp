#include<bits/stdc++.h>
using namespace std;
int T,n,b[22][22];


int main(){
	cin>>T;
	while(T--){
		cin>>n;
		for(int i=0;i<=20;i++)
			for(int j=0;j<=20;j++) b[i][j]=1;
		for(int i=1;i<=19;i++)
			for(int j=1;j<=19;j++) b[i][j]=0;	
		for(int i=1;i<=n;i++){
			int x,y,op;
			cin>>x>>y>>op;
			if(op==1){
				b[x][y]=2;
			}else{
				b[x][y]=3;	
			}			
		}
		int ans=0;
		for(int i=1;i<=19;i++)
			for(int j=1;j<=19;j++)
				if(b[i][j]==2){
					ans+=(b[i-1][j]==0)+(b[i][j-1]==0)+(b[i+1][j]==0)+(b[i][j+1]==0);
				}
		cout<<ans<<endl;		
	}
	return 0;
}
