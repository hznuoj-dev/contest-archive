#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9 +7;
const int N = 1e3 +7;
ll t,n,m,s;
bool st[30][30];
bool a[30][30];
int dx[] ={0,0,-1,1};
int dy[] ={-1,1,0,0};
inline void run(){
    for(int i = 0;i <= 29;i ++){
    	for(int j = 0;j <= 29;j ++)
    	 st[i][j] = 0,a[i][j] = 0;
	}
     cin >> t;
     while(t--){
     	 cin >>n >>m>>s;
     	 if(s == 2) st[n][m] = 1;
         else a[n][m] =1,st[n][m] = 1;
	 }
	 ll ans = 0;
	 ll x ,y;
     for(int i = 1; i<= 19;i ++) {
     	for(int j= 1;j <= 19;j ++){
     		if(a[i][j] == 1) {
     			for(int k = 0;k <= 3;k ++) {
     				x = i +dx[k];
     				y = j +dy[k];
//     			     cout << x << ' ' <<y <<"\n";
				 	if(x >0 && x <= 19 && y >0 &&y <=19) {
     					if(st[x][y] == 0) {
						 ans ++;
						 }
					 }
				 }
			 }
		 }
	 }
     cout << ans <<endl;
}
int main()
{
      int T;
      for(cin >>T;T--;)
	    run();
}
