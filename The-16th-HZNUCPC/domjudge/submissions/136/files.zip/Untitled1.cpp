#include <bits/stdc++.h>
using namespace std;
bool blk[21][21];
int x[400],y[400],pt,xa,ya,j,ans;
int delt[4][2]={{0,1},{0,-1},{1,0},{-1,0}};
int n;
int main(){
	
	int t;cin>>t;
	while(t--)
	{
		for(int i=0;i<=20;i++)for(int j=0;j<=20;j++)blk[i][j]=0;
		pt=ans=0;cin>>n;
		while(n--)
		{		
		    cin>>xa>>ya>>j;
		    blk[xa][ya]=1;
		    if(j==1)
		    {
		    	pt++;x[pt]=xa;y[pt]=ya;
			}
	    }
		for(int i=1;i<=pt;i++)
		{
			for(int j=0;j<4;j++)
			{
				xa=x[i]+delt[j][0];
				ya=y[i]+delt[j][1];
				if(!blk[xa][ya])
				{
					ans++;
					blk[xa][ya]=1;
				}
			}
		}
		cout<<ans<<'\n';
	}
    return 0;
}