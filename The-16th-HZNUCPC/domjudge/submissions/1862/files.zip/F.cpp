#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
	ll n,m;
	scanf("%lld%lld",&n,&m);
	if(n == 1 || m == 1){
		cout << "YES" << endl;
	}else{
		if((n>m&&n%m==0)||(n<m))cout<<"NO";
		else {
		while(1){
			int c = n % m;
			m = c;
			if(m == 1){
				cout << "YES" << endl;
				return 0;
			}
			if(m == 0){
				cout << "NO" << endl;
				return 0;
			}
		}
	}
	
	}
	return 0;
}
	