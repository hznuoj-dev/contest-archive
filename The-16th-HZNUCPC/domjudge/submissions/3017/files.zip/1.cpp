#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
ll n, k;

int main()
{
	scanf("%lld %lld", &n, &k);
	for(int i = 2; i <= sqrt(n) + 1; i++) {
		if(n % i == 0 && i <= k) {
			puts("NO");
			return 0;
		}
	}
	while(k > 1) {
		if(n % k == 0) {
			puts("NO");
			return 0;
		}
		k = n % k;
	}
	puts("YES");
	return 0;
}