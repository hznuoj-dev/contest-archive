#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
queue<pair<int,int> >  q;

int dir[4][2]={1,0,0,1,-1,0,0,-1};
int mp[25][25],v[25][25];
int ck(int num){
	int ans=0;
	while(!q.empty()){
		auto t=q.front();
		int x=t.first;
		int y=t.second;
		q.pop();
		for(int i=0;i<4;i++){
			int tx=x+dir[i][0];
			int ty=y+dir[i][1];
			if(tx>=1&&ty>=1&&tx<=19&&ty<=19&&v[tx][ty]!=1){
				ans++;
				v[tx][ty]=2;
			}
		}
	}
	return ans;
}
signed main(){
	int t;
	cin>>t;
	while(t--){
		while(!q.empty()){
			q.pop();
		}
		int sum=0;
		memset(v,0,sizeof(v));
		memset(mp,0,sizeof(mp));
		cin>>n;
		int a,b,c;
		for(int i=0;i<n;i++){
			cin>>a>>b>>c;
			v[a][b]=c;
			if(c==1){
				q.push({a,b});
				sum++;
			}
		}
		if(sum==0){
			cout<<0<<endl;
			continue;
		}
		cout<<ck(0);
	}
	
	
	return 0;
}

