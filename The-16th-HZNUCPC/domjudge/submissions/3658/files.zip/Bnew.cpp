#include<bits/stdc++.h>
#define int __int128
#define li long long
using namespace std;
inline int read(){
	int x=0,f=1;char c=getchar();
	while(!isdigit(c)) {
		if(c=='-') f=-1;c=getchar();
	}
	while(isdigit(c)){
		x=x*10+c-'0';c=getchar();
	}
	return x*f;
}
const int N=2e5+5,mod=(int)(1e9+7)*998244353;
int t,n,top,b[N];
int c=131,p[N],hx[N],hy[N],hx2[N],hy2[N],h3[N],inf=1e18;
double pi=acos(-1);
map<array<int,5>,int>mp;
struct P{
	int x,y;
	P operator-(P a){return {x-a.x,y-a.y};}
	int operator^(P a){return x*a.x+y*a.y;}
	int operator*(P a){return x*a.y-y*a.x;}
	int len2(){return x*x+y*y;}
	friend double rad(P a,P b){return atan2(a*b,a^b);}
}a[N],s[N];
int qry(int *h,int l,int r){
	return (h[r]-h[l-1]*p[r-l+1]%mod+mod)%mod;
}
void Convex(P *a,int n,P *s,int &top){
	sort(a+1,a+1+n,[](P x,P y){return x.x^y.x?x.x<y.x:x.y<y.y;});
	top=0;
	for(int i=1;i<=n;i++){
		while(top>1&&(a[i]-s[top-1])*(s[top]-s[top-1])>=0) top--;
		s[++top]=a[i];
	}
	for(int tmp=top,i=n-1;i>=1;i--){
		while(top>tmp&&(a[i]-s[top-1])*(s[top]-s[top-1])>=0) top--;
		s[++top]=a[i];
	}
	if(n>1) top--;
}
signed main(){
	//freopen("test.in","r",stdin);
	t=read(),p[0]=1;
	for(int i=1;i<N;i++) p[i]=p[i-1]*c%mod;
	while(t--){
		n=read();
		for(int i=1;i<=n;i++) a[i].x=read(),a[i].y=read();
		Convex(a,n,s,top);
		//for(int i=1;i<=top;i++) cout<<"conv: "<<(li)s[i].x<<" "<<(li)s[i].y<<endl;
		array<int,5>mn={inf,inf,inf,inf,inf};
		for(int o=0;o<2;o++){
			//hash angle
			int g=0;
			for(int i=1;i<=top;i++){
				P x=s[i>1?i-1:top]-s[i],y=s[i<top?i+1:1]-s[i];
				a[i]={(x*y)*(x*y),x.len2()*y.len2()};
				//cout<<"ovo1: "<<(li)a[i].x<<" "<<(li)a[i].y<<endl;
				g=__gcd(a[i].x,a[i].y);
				a[i].x/=g,a[i].y/=g;
				//g=__gcd(g,a[i].x),g=__gcd(g,a[i].y);
				//cout<<"qwq: "<<x.x<<" "<<x.y<<" "<<y.x<<" "<<y.y<<endl;
				//cout<<"len2: "<<(li)x.len2()<<" "<<(li)y.len2()<<endl;
				//cout<<"ovo2: "<<(li)a[i].x<<" "<<(li)a[i].y<<endl;
			}
			for(int i=1;i<=top;i++) a[i+top]=a[i];
			for(int i=1;i<=top+top;i++)
				hx[i]=(hx[i-1]*c%mod+a[i].x)%mod,hy[i]=(hy[i-1]*c%mod+a[i].y)%mod;
			//hash len
			g=0;
			int mnlen=1e18;
			for(int i=1;i<=top;i++) mnlen=min(mnlen,(s[i<top?i+1:1]-s[i]).len2());
			for(int i=1;i<=top;i++){
				a[i]={(s[i<top?i+1:1]-s[i]).len2(),mnlen};
				g=__gcd(g,a[i].x),g=__gcd(g,a[i].y);
			}
			for(int i=1;i<=top;i++)
				a[i].x/=g,a[i].y/=g,a[i+top]=a[i];
			for(int i=1;i<=top+top;i++)
				hx2[i]=(hx2[i-1]*c%mod+a[i].x)%mod,hy2[i]=(hy2[i-1]*c%mod+a[i].y)%mod;
			//hash xiang xian
			for(int i=1;i<=top;i++){
				P x=s[i>1?i-1:top]-s[i],y=s[i<top?i+1:1]-s[i];
				b[i]=rad(x,y)<=pi/2?1:2,b[i+top]=b[i];
			}
			for(int i=1;i<=top+top;i++)
				h3[i]=(h3[i-1]*c%mod+b[i])%mod;
			for(int i=1;i<top;i++){
				int j=i+top-1;
				mn=min(mn,array<int,5>{qry(hx,i,j),qry(hy,i,j),qry(hx2,i,j),qry(hy2,i,j),qry(h3,i,j)});
			}
			reverse(s+1,s+1+top);
		}
		//for(int i=0;i<5;i++) cout<<(long long)mn[i]<<" "; puts("");
		printf("%lld\n",(long long)mp[mn]);
		mp[mn]++;
	}
	return 0;
}