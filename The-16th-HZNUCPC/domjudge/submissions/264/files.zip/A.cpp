#include<bits/stdc++.h>
#define endl '\n'
typedef long long ll;
using namespace std;
const int N =1e6+10;

ll n, m;

void solve() {
	cin >> n >> m;
	vector<int> g;
	for(ll i=2; i*i<=n; i++) {
		if(n%i==0)
		{
			g.push_back(i);
			while(n%i==0)
			n/=i;
		}
	}
	if(n!=1)
	g.push_back(n);
	for(int i=0;i<g.size();i++)
	{
		if(g[i]<=m)
		{
			cout<<"NO"<<'\n';
			return;
		}
	}
	cout<<"YES"<<'\n';
}

int main() {
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int _t = 1;
	// cin >> _t;
	while(_t--) {
		solve() ;
	}
}