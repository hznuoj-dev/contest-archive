#include<bits/stdc++.h>
#define int long long
typedef long long ll;
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;

const int N=1e4+10;
string s;
int n;

void expand()
{
	string ss="$";
	for(int i=0;i<s.size();i++)
	{
		ss+='#';
		ss+=s[i];
	}
	ss+="#^";
	s=ss;
}

void solve()
{
	cin>>s;
	expand();
	int ans=0;
	n=s.size();
	//cout<<s<<endl;
	for(int i=1;i<n;i++)
	{
		int j=1,a=-1,b=-1,cnt=0;
		int res=0;
		while(i-j>=0&&i+j<n)
		{
			if(s[i-j]==s[i+j])
			{
				if(cnt!=1)res=j;
				j++;
				continue;
			}
			if(cnt==2)break;
			cnt++;
			int aa=s[i-j]-'a',bb=s[i+j]-'a';
			if(a==-1)
			{
				a=aa;b=bb;j++;continue;
			}
			if(aa!=b||bb!=a)break;
			res=j;j++;
		}
		int x=0;
		cnt=0;
		for(int j=1;i-j>=0&&i+j<n;j++)
		{
			if(s[i-j]==s[i+j])
			{
				x=j;continue;
			}
			if(cnt==1)break;
			cnt++;
			if(s[i-j]==s[i]||s[i+j]==s[i])
			{
				x=j;
			}
			else
			break;
		}
		res=max(res,x);
		//cout<<"i="<<i<<' '<<res<<endl;
		ans=max(ans,res);
	}
	if(ans==1)ans=0;
	cout<<ans<<'\n';
}

signed main()
{
	int t;
	cin>>t;
	while(t--)solve();
}
