#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int,int>
const int N = 110 , inf = 1e10;
PII a[N];
int ma[N][N];
double xie[N];

signed main(){
	int n;
	cin >> n;
	for(int i=1;i<=n;i++){
		int x,y;
		cin >> x >> y;
		a[i] = {x,y};
		double k;
		if(x == 0){
			k = inf;
		}else{
			k = (double)y / (double)x;
		}
		xie[i] = k;
	}
	for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			int x1 = a[i].first , y1 = a[i].second;
			int x2 = a[j].first , y2 = a[j].second;
			int cha1 = abs(x1-x2) , cha2 = abs(y1-y2);
			ma[i][j] = __gcd(cha1,cha2) + 1;
			ma[j][i] = ma[i][j];
		}
	}
	int ans = 0;
	for(int i=1;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			for(int k=j+1;k<=n;k++){
				if(xie[i] == xie[j] && xie[i] == xie[k]) continue;
				int x1 = a[i].first , y1 = a[i].second;
				int x2 = a[j].first , y2 = a[j].second;
				int x3 = a[k].first , y3 = a[k].second;
				if(x1==0 && y1 == 0 && xie[j] == xie[k]) continue;
				if(x2==0 && y2 == 0 && xie[i] == xie[k]) continue;
				if(x3==0 && y3 == 0 && xie[i] == xie[j]) continue;
				int res = 0;
				//cout << "---" << i << ' ' << j << ' ' << k << ' ' << ma[i][j] << ' ' <<  ma[i][k] << ' ' << ma[j][k] << '\n';
				res = ma[i][j] + ma[i][k] + ma[j][k] - 3;
				ans = max(ans , res);
			}
		}
	}
	cout << ans;
	return 0;
}