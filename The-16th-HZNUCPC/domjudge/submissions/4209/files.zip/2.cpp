#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 1e5 + 10;
char s[N],s1[N];
int v[30],v1[30];
vector<int>pos[7];
const int mod=1e9+7;
int main() {
    int n=0,m=0;
    scanf("%s%s",s + 1,s1 + 1);
    int len = strlen(s+1);
    for(int i=1;i<=len;i++){
        if(!v[s[i]-'a'])
            n++;
        v[s[i]-'a']++;
    }
    for(int i=1;i<=len;i++){
        if(!v1[s1[i]-'a'])
            m++;
        v1[s1[i]-'a']++;
    }
    if(abs(n-m)>2) {
        puts("0");
        return 0;
    }
    ll ans=0;
    for(int i=1;i<=len;i++){
        if(v[s[i]]==1&&v[s1[i]]&&v1[s1[i]]==1&&v1[s[i]]){//-1 -1
            if(n==m+1)
              ans = (ans+pos[5].size())%mod;
            if(n==m)
              ans=(ans+pos[3].size())%mod;
            if(n+1==m)
              ans=(ans+pos[4].size())%mod;
        }
        if(v[s[i]]==1&&v[s1[i]]&&v1[s1[i]]>1&&v1[s[i]]){//-1 0 1
            if(n==m+2)
              ans=(ans+pos[5].size())%mod;
              if(n==m+1)
              ans=(ans+pos[3].size())%mod;
              if(n==m)
              ans=(ans+pos[2].size())%mod;
        }
        if(v[s[i]]==1&&v[s1[i]]&&v1[s1[i]]==1&&(s[i]==s1[i]||!v1[s[i]])){//-1 0 2
            if(n==m+2)
              ans=(ans+pos[5].size())%mod;
              if(n==m+1)
              ans=(ans+pos[3].size())%mod;
              if(n==m)
              ans=(ans+pos[2].size())%mod;
        }
        if(v[s[i]]>1&&v[s1[i]]&&v1[s1[i]]==1&&v1[s[i]]){//0 -1 1
            if(n==m)
            ans=(ans+pos[5].size())%mod;
            if(n+1==m)
            ans=(ans+pos[3].size())%mod;
            if(n+2==m)
            ans=(ans+pos[4].size())%mod;
        }
        if(v[s[i]]>1&&v[s1[i]]&&v1[s1[i]]==1&&v1[s[i]]){//0 -1 2
            if(n==m)
            ans=(ans+pos[5].size())%mod;
            if(n+1==m)
            ans=(ans+pos[3].size())%mod;
            if(n+2==m)
            ans=(ans+pos[4].size())%mod;
        }
        if(v[s[i]]>1&&v[s1[i]]&&v1[s1[i]]>1&&v1[s[i]]){//0 0
            if(n==m+1)
               ans=(ans+pos[5].size())%mod;
            if(n==m)
            ans=(ans+pos[3].size())%mod;
            if(n+1==m)
            ans=(ans+pos[2].size())%mod;
        }
    }
    printf("%lld\n", ans);
}
