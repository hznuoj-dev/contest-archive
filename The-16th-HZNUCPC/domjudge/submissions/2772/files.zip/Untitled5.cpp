#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
ll n, k;

int main()
{
	while(1){
		
	}
	return 0;
}