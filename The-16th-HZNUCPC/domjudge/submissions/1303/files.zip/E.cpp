#include<bits/stdc++.h>
#define PII pair<int,int>
#define x first
#define y second
#define LL long long
using namespace std;

const int N = 1e5,mod = 1;

PII q[120];

int main()
{
	int n;
	cin >> n;
	for(int i = 1;i <= n;i ++) cin >> q[i].x >> q[i].y;
	//sort(q + 1,q + 1 + n);
	LL ma = 0;
	for(int i =1;i <= n ;i ++)
		for(int j = i + 1;j <= n ;j ++)
			for(int k = j + 1;k <= n ;k ++)
			{
				LL ans = 0;
				if (q[i].x == q[j].x && q[j].x == q[k].x) continue;
				long long r1 = (q[k].y - q[j].y) * (q[k].x - q[i].x) ,r2 = (q[k].y - q[i].y) * (q[k].x - q[j].x); 
				if (r1 == r2) continue;
				else 
				{
					LL xij = abs(q[i].x - q[j].x),yij = abs(q[i].y - q[j].y);
					LL xjk = abs(q[j].x - q[k].x),yjk = abs(q[j].y - q[k].y);
					LL xik = abs(q[i].x - q[k].x),yik = abs(q[i].y - q[k].y);
					if(xij&&yij) ans += __gcd(xij,yij) + 1;
					else ans += xij + yij + 1; 
					if(xik&&yik) ans += __gcd(xik,yik) + 1;
					else ans += xik + yik + 1;
					if(xjk&&yjk) ans += __gcd(xjk,yjk) + 1;
					else ans += xjk + yjk + 1;
				}
				ma = max(ma,ans);
			}
	ma -= 3;
	ma = max(ma,(LL)0);
	cout << ma;
	return 0;
}
//4
//0 0
//1 1
//2 4
//4 2
