
#include <bits/stdc++.h>
using namespace std;
long long n, m;
int main() {
	cin >> n >> m;
	if(__gcd(n, m) == 1) puts("YES");
	else puts("NO");
	return 0;
}
