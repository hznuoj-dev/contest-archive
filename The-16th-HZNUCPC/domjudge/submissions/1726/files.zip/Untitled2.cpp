#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
	ll n, m;
	cin >> n >> m;
	if(n == 1){
		cout << "YES" << endl;
		return 0;
	}
	if(m == 1){
		cout << "YES" << endl;
		return 0;
	}
	if(n <= m){
		cout << "NO" << endl;
		return 0;
	}
	bool f = 0;
	for(int i = 2; i <= m && i <= n; i++){
		if(n % m == 0){
			f = 1;
			cout << "NO" << endl;
			break;
		}
	}
	if(!f){
		cout << "YES" << endl;
	}
//	cout << "YES" << endl;
	return 0;
}