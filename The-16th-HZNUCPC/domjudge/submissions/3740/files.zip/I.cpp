#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
void solve() {
	string ss;
	cin >> ss;
	
	string s = "+$";
	for (auto c : ss){
		s = s + c + "$";
	}
	s = s + "-";
	int n = s.size();
//	cout << s << "\n";
	
	int ans = 0;
	for (int mid = 2; mid <= n - 1; mid ++ ){
		vector<int> ch(26, 0);
		int len = 1, diff = 0, cnt = 0, tot = 0;
		if ('a' <= s[mid] && s[mid] <= 'z'){
			cnt = 1;
			if ( ++ ch[s[mid] - 'a'] == 1){
				
			}
		}
		while (mid - len >= 1 && mid + len <= n){
			if ('a' <= s[mid - len] && s[mid - len] <= 'z' && 'a' <= s[mid + len] && s[mid + len] <= 'z'){
				cnt += 2;
			}
			if (s[mid - len] != s[mid + len] && 'a' <= s[mid - len] && s[mid - len] <= 'z' && 'a' <= s[mid + len] && s[mid + len] <= 'z'){
				if (++ ch[s[mid - len] - 'a'] == 1){
					tot ++ ;
				}
				if (++ ch[s[mid + len] - 'a'] == 1){
					tot ++ ;
				}
				diff ++ ;
			}
//			if (mid == 10){
//				cout << len << " " << diff << " " << tot << "\n";
//			}
			if (diff == 0 || (diff == 2 && tot == 2)){
				ans = max(ans, cnt);
			}
			if (cnt % 2 && diff == 1 && 'a' <= s[mid - len] && s[mid - len] <= 'z' && 'a' <= s[mid + len] && s[mid + len] <= 'z'){
				if ((ch[s[mid - len] - 'a'] + ch[s[mid + len] - 'a']) % 2){
					ans = max(ans, cnt);
				}
			}
			len ++ ;
		}
	}
	cout << (ans <= 1 ? 0 : ans) << "\n";
}
signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
//	freopen("1.in", "r", stdin);
	int Case = 1;
	cin >> Case;
	while (Case -- ) {
		solve();
	}
	return 0;
}