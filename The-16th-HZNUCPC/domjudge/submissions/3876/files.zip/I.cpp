#include<bits/stdc++.h>
#define int long long
#define rep(i,a,n) for(int i=a;i<n;i++)
#define per(i,a,n) for(int i=n-1;i>=a;i--)
#define fi first 
#define se second
#define pb push_back
#define endl '\n'
#define pii pair<int,int> 
#define vii vector<pair<int,int> >
using namespace std;
const int mod = 1e9+7;
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
pii get(pii a,pii b){
	if(a.fi==b.fi) return {0,1};
	if(a.se==b.se) return {1,0};
	int dx=a.fi-b.fi;
	int dy=a.se-b.se;
	if(dx*dy>0){
		int d=gcd(dx,dy);
		return {dx/d,dy/d};
	}else{
		int d=gcd(dx,dy);
		return {-dx/d,dy/d};
	}
}
int getn(pii a,pii b){
	if(a.fi==b.fi) return abs(a.se-b.se)-1;
	if(a.se==b.se) return abs(a.fi-b.fi)-1;
	int dx=abs(a.fi-b.fi),dy=abs(a.se-b.se);
	return gcd(dx,dy)-1;
}
struct car{
	int t,l,r;
};
struct peo{
	int id,t,x;
};
int ans[100010];
bool ok[5010][5010];
char s[5010];
int c[26];
void solve(){
	int ans=0;
	rep(i,0,26) c[i]=0;
	cin>>s+1;int n=strlen(s+1);
	rep(i,1,n+1){
		int cnt=0;
		rep(j,i,n+1){
			c[s[j]-'a']++;
			if(c[s[j]-'a']&1) cnt++;
			else cnt--;
			int len=i-j+1;
			if(i==1&&j==n){
				rep(k,0,26){
					//cout<<c[k]<<" \n"[i==25];
				}
				//cout<<"???"<<cnt<<endl;
			}
			if(len&1){
				if(cnt==1) ok[i][j]=1;
			}else if(!cnt) ok[i][j]=1;
		}
		rep(i,0,26) c[i]=0;
	}
	rep(i,1,n+1){
		rep(j,i,n+1){
			//cout<<i<<' '<<j<<" "<<ok[i][j]<<endl;
		}
	}
	rep(i,1,n){
		int now=0;
		int l=i,r=i+1;
		while(l>=1&&r<=n){
			if(s[l]!=s[r]) {
				now++;
				if(now==3){
					l++,r--;
					break;
				}
			}
			if(ok[l][r]) ans=max(ans,r-l+1);
			l--;r++;
		}
		//if(i==3) cout<<l<<" "<<r<<endl;
		if(l==0||r==n+1) l++,r--;
		if(ok[l][r]) ans=max(ans,r-l+1);
	}
	rep(i,2,n){
		int l=i-1,r=i+1;
		int now=0;
		while(l>=1&&r<=n){
			if(s[l]!=s[r]){
				now++;
				if(now==3){
					l++,r--;
					break;
				}
			}
			if(ok[l][r]) ans=max(ans,r-l+1);
			l--,r++;
		}
		if(l==0||r==n+1) l++,r--;
		if(ok[l][r]) ans=max(ans,r-l+1);
	}cout<<((ans==1)?0:ans)<<endl;
	rep(i,1,n+1){
		rep(j,i,n+1) ok[i][j]=0;
	}
	
}
signed main(){
	int t=1;cin>>t;
	while(t--){
		solve();
	}
	return 0;
}

/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5
*/