#include <bits/stdc++.h>
using namespace std;

#define int long long
const int kMaxN = 105;
int n;
int x[kMaxN], y[kMaxN];

int calc(int x, int y) {
	int g = __gcd(x, y);
	x /= g, y /= g;
	return g - 1;
}

signed main() {
	ios::sync_with_stdio(false);
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		cin >> x[i] >> y[i];
	}
	
	int res = 0;
	for (int i = 1; i <= n; ++i) {
		for (int j = i + 1; j <= n; ++j) {
			for (int k = j + 1; k <= n; ++k) {
				int x1 = abs(x[j] - x[i]), y1 = abs(y[j] - y[i]);
				int x2 = abs(x[k] - x[i]), y2 = abs(y[k] - y[i]);
				int x3 = abs(x[k] - x[j]), y3 = abs(y[k] - y[j]);
				if (1LL * x1 * y2 == 1LL * x2 * y1) continue;
				int ans = calc(x1, y1) + calc(x2, y2) + calc(x3, y3) + 3;	
				res = max(res, ans);
			}
		}
	}
	cout << res << "\n";
	return 0;
}