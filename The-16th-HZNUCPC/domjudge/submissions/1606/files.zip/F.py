n,m=map(int,input().split())
flag=False
if m==1:
    print('Yes')
elif n%2==0:
    print('NO')
else:
    for i in range(3,m//2):
        if n%i==0:
            flag=True
            break
if flag:
    print('NO')
else:
    print('YES')