#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
void solve()
{
	cin>>n>>m;
	if(n&1==1||m==1){
    	cout<<"YES";
	}else{
		cout<<"NO";
	}
	return;	
}
int mian(){
	ios_base::sync_with_stdio(0);
	cin.tie(0), cout.tie(0);
    solve();
	return 0;
}