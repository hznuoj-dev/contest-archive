#include <bits/stdc++.h>
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int t;
int n;
int a[50][50];
int ans[50][50];
int main(int argc, char** argv) {
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin>>t;
	while(t--){
		cin>>n;
		for(int i=0;i<50;i++){
			for(int j=0;j<50;j++){
				a[i][j]=0;ans[i][j]=0;
		    }
		}
		int u,v,z;
		for(int i=0;i<n;i++){
			cin>>u>>v>>z;
			a[u][v]=z;
		}
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(a[i][j]==1){
					if(j-1>0&&a[i][j-1]==0) ans[i][j]++;
					if(j+1<20&&a[i][j+1]==0) ans[i][j]++;
					if(i-1>0&&a[i-1][j]==0)ans[i][j]++;
					if(i+1<20&&a[i+1][j]==0)ans[i][j]++;
				}
			}
		}
		int num=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				num+=ans[i][j];
			}
		}
		cout<<num<<endl;
	}
	return 0;
}