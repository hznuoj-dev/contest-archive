#include<bits/stdc++.h>

using namespace std;

#define int long long
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

using ll = long long;

const int N = 1e5+10;
const int M = 1e9+7;

void solve(){
	int n,m;
	cin>>n>>m;
	
	if(n<m && n!=1){
		cout<<"NO\n";
		return ;
	}
	
	if(m==1){
		cout<<"YES\n";
		return ;
	}
	
	if(n%m==0){
		cout<<"NO\n";
		return ;
	}
	
	int k=m;
	while(n%k!=0){
		k=n%k;
	}
	
	if(k==1){
		cout<<"YES\n";
	}
	else{
		cout<<"NO\n";
	}
}

signed main(){
	IOS;
	
	int t;
	//cin>>t;
	t=1;
	
	while(t--){
		solve();
	}
	
	return 0;
}