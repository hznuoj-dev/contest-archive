#include<bits/stdc++.h>
using namespace std;
typedef struct B{
	int x;
	int y;
} pos,B;
int main()
{
    int a[21][21];
    int x,y,z,sum,i,j,t,n,m1,m2,q;
    scanf("%d",&t);
    
    for(i=0;i<=20;i++)
    	for(j=0;j<=20;j++)
    		a[i][j]=0;
    for(q=1;q<=t;q++)
    {	
		scanf("%d",&n);
		m1=1;
		m2=1;
		pos p1[400],p2[400];
		sum=0;
    	for(j=1;j<=n;j++)
    	{
    		scanf("%d%d%d",&x,&y,&z);
			a[x][y]=z;
			if(z==1)
			{
				p1[m1].x=x;
				p1[m1].y=y;
				m1=m1+1;
			}
			if(z==2)
			{
				p2[m2].x=x;
				p2[m2].y=y;
				m2=m2+1;
			}
		}
		for(j=1;j<m1;j++)
		{
			x=p1[j].x;
			y=p1[j].y;
			sum=sum+4;
			if(a[x-1][y]!=0||x==1)
			{
			 sum=sum-1;
		    }
		    if(a[x+1][y]!=0||x==19)
			{
			 sum=sum-1;
		    }
		    if(a[x][y-1]!=0||y==1)
			{
			 sum=sum-1;
		    }
		    if(a[x][y+1]!=0||y==19)
			{
			 sum=sum-1;
		    }
		}
		for(j=1;j<m1;j++)
		{
			x=p1[j].x;
			y=p1[j].y;
			a[x][y]=0;
		}
		for(j=1;j<m2;j++)
		{
			x=p2[j].x;
			y=p2[j].y;
			a[x][y]=0;
		}
		printf("%d\n",sum);
	}
}