#include<bits/stdc++.h>
using namespace std;
#define int long long
const int inf=1e15;
const int N=1e6+5;
const int mod=1e9+7;
int n,m,sum;

void run(){
	cin>>n>>m;
	sum=m;
	while(sum>1){
		if(n%sum!=0){
		sum=n%sum;
	}
	else{
		cout<<"NO";
		return;
	}
	}
	cout<<"YES";
	return;
	
}
signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
//	int t=1;
//	cin>>t;
//	while(t--){
		run();
//	}
	return 0;
}