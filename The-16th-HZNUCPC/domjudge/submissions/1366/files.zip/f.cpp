#include <bits/stdc++.h>

using namespace std;
const int N = 1e9+7;

int isPrime(long long x)
{
	if (x<2) return 0;
	for (long long i=2;i<=x/i;i++)
	{
		if (x%i==0) return i;
	}
	return 0;
}
int main(){
	long long int n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"YES";
		return 0;
	}
	else if(m==2&&n%2==1){
		cout<<"YES";
		return 0;
	}
	else{
		if(isPrime(n)<=m){
			cout<<"NO";
			return 0;
		}
		else{
			cout<<"YES";
		}
	}
	return 0;
}