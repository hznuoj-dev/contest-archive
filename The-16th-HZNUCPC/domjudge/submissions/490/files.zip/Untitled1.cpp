#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int maxn=1e6+10;
int ma[30][30];
void solve(){
	int n,ans=0;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		int x,y;
		cin>>x>>y;
		cin>>ma[x][y];
	}
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(ma[i][j]==1){
				if(ma[i+1][j]==0) {
					ans++;
					
				}
			if(ma[i-1][j]==0) {
				ans++;
			
			}
			if(ma[i][j+1]==0) 
			{
				ans++;
			}
			if(ma[i][j-1]==0) {
				ans++;
			} 
			}
			
		}
	}
	cout<<ans<<endl;
	
}
signed main(){
	int T;
	cin>>T;
	while(T--)
	{
		for(int i=0;i<=20;i++){
			ma[i][0]=1;
			ma[0][i]=1;
			ma[i][20]=1;
			ma[20][i]=1;
		}
		for(int i=1;i<=19;i++)
			for(int j=1;j<=19;j++) 
				ma[i][j]=0;
		solve();
		
	}
	
	
	return 0;
} 