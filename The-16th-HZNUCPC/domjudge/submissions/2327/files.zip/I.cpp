#include<bits/stdc++.h>

using namespace std;


typedef long long ll;
int t;
char s[10000];
int main(){
    scanf("%d",&t);
    while(t--){
       scanf("%s",s);
       int n = strlen(s);
       int maxlen=0;
       for(int i=0;i<n;i++){
           int l=i-1,r=i+1;
           int judge=0;
           int len = 0;
           char prea,preb;
           while(l>=0&&r<n){
                if(s[l]==s[r]&&(judge==0||judge==2)){
                    len=r-l+1;
                }
                if(s[l]!=s[r]){
                    if(judge==0){
                        judge=1;
                        prea = s[l];
                        preb = s[r];
                    }
                    else if(judge==1){
                        if((prea==s[l]&&preb==s[r])||(prea==s[r]&&preb==s[l])){
                            len=r-l+1;
                            judge=2;
                        }
                        else{
                            break;
                        }
                    }
                    else{
                        break;
                    }
                }
                l--;
                r++;
           }
           maxlen=max(maxlen,len);
       }
       for(int i=0;i<n-1;i++){
           if(s[i]!=s[i+1])
            continue;
           int len=2;
           int l=i-1,r=i+2;
           int judge=0;
           char prea,preb;
           while(l>=0&&r<n){
                if(s[l]==s[r]&&(judge==0||judge==2)){
                    len=r-l+1;
                }
                if(s[l]!=s[r]){
                    if(judge==0){
                        //cout<<l<<endl;
                        judge=1;
                        prea = s[l];
                        preb = s[r];
                    }
                    else if(judge==1){
                       // cout<<s[l]<<" "<<s[r]<<endl;
                        if((prea==s[l]&&preb==s[r])||(prea==s[r]&&preb==s[l])){
                            len=r-l+1;
                            judge=2;
                        }
                        else{
                            break;
                        }
                    }
                    else{
                        break;
                    }
                }
                l--;
                r++;
           }
           //cout<<l<<" "<<r<<endl;
           maxlen=max(maxlen,len);
       }
       printf("%d\n",maxlen);

    }
    return 0;
}
