#include<bits/stdc++.h>
using namespace std;

int n,c;
int qx[1000],qy[1000];
int mp[32][32];
int check(int x,int y)
{
    if(mp[x][y]==2)return 0;
    int sum=0;
    if(x-1>=1)
    {
        if(mp[x-1][y]==0)++sum;
    }
    if(x+1<=19)
    {
        if(mp[x+1][y]==0)++sum;
    }
    if(y+1<=19)
    {
        if(mp[x][y+1]==0)++sum;
    }
    if(y-1>=1)
    {
        if(mp[x][y-1]==0)++sum;
    }
    return sum;
}
void sol()
{
    memset(mp,0,sizeof mp);
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
    {
        scanf("%d%d%d",&qx[i],&qy[i],&c);
        mp[qx[i]][qy[i]]=c;
    }
    int ans=0;
    for(int i=1;i<=n;++i)
    {
        ans+=check(qx[i],qy[i]);
    }
    printf("%d\n",ans);
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    sol();
    return 0;
}
