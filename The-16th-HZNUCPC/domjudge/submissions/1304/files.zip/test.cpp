#include <bits/stdc++.h>

using namespace std;
#define int long long

signed main(){
	int n,k;
	while(cin >> n >> k){
		bool f = true;
		while(1)
		{
			if(n % k == 0){
				f = false;
				break;
			}
			k = n % k;
			if(k == 1) break;
		}
		if(f) cout << "YES\n";
		else cout << "NO\n";
	}	
	return 0;
}