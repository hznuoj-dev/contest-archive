#include <bits/stdc++.h>

using namespace std;


const int N = 3e5 + 10;
const int INF = 0x3f3f3f3f;
int b[N];
int cnt;

int n, m, x;
int mn[N << 2];
int mx[N << 2];
int lazy[N << 2];

struct node{
    int t;
    int l, r;
}a[N], q[N];

int ans[N];

bool cmp(node &a, node &b){

    return a.t < b.t;
}

void build(int rt, int l, int r){
    mn[rt] = INF;
    mx[rt] = INF;
    lazy[rt] = INF;
    if(l == r) return ;
    int mid = l + r >> 1;
    build(rt << 1, l, mid);
    build(rt << 1 | 1, mid + 1, r);
}

void pushup(int rt){
    mx[rt] = max(mx[rt << 1], mx[rt << 1 | 1]);
    mn[rt] = min(mn[rt << 1], mn[rt << 1 | 1]);
}

void pushdown(int rt)
{
    if(lazy[rt] != INF)
    {

        lazy[rt << 1] = lazy[rt];
        lazy[rt << 1 | 1] = lazy[rt];
        mn[rt << 1] = lazy[rt];
        mn[rt << 1 | 1] = lazy[rt];
        mx[rt << 1] = lazy[rt];
        mx[rt << 1] = lazy[rt];

        lazy[rt] = INF;
    }
}


void update(int rt, int L, int R, int l, int r, int C)
{
//    cout << l <<" " << r <<" " << C << '\n';
    if(L <= l && R>= r && mn[rt] >= C)
    {
 //       cout <<"???"<< l <<" " << r << " " << C<<'\n';
        mn[rt] = C;
        mx[rt] = C;
        lazy[rt] = C;
        return ;
    }
    int mid = l + r >> 1;
    pushdown(rt);
    if(L <= mid) update(rt << 1, L, R, l, mid, C);
    if(R > mid) update(rt << 1 | 1, L, R, mid + 1, r, C);
    pushup(rt);
}


int query(int rt, int L, int R, int l, int r)
{
    if(L <= l && R >= r){
        return mn[rt];
    }
    int ans = INF;
    int mid = l + r >> 1;
    pushdown(rt);
    if(L <= mid) ans = min(ans, query(rt << 1, L, R, l, mid));
    if(R > mid) ans = min(ans, query(rt << 1 | 1, L, R, mid + 1, r));
    return ans;
}

int main(){
    scanf("%d%d%d", &n, &m, &x);
    b[++ cnt] = x;
    for (int i = 1; i <= n; i ++)
    {
        scanf("%d%d%d", &a[i].t, &a[i].l, &a[i].r);
        b[++ cnt] = a[i].l;
        b[++ cnt] = a[i].r;
    }
    for (int i = 1; i <= m; i ++)
    {
        q[i].t = i;
        scanf("%d%d", &q[i].l, &q[i].r);
        b[++ cnt] = q[i].r;
    }
    sort(b + 1, b + cnt + 1);
    cnt = unique(b + 1, b + cnt + 1) - (b + 1);
    x = lower_bound(b + 1, b + cnt + 1, x) - b;
    for (int i = 1; i <= n; i ++)
    {
        a[i].l = lower_bound(b + 1, b + cnt + 1, a[i].l) - b;
        a[i].r = lower_bound(b + 1, b + cnt + 1, a[i].r) - b;
    }
    for (int i = 1; i <= m; i ++)
    {
        q[i].r = lower_bound(b + 1, b + cnt + 1, q[i].r) - b;
    }

    sort(a + 1, a + n + 1, cmp);
    sort(q + 1, q + m + 1, cmp);
    build(1, 1, cnt);
    update(1, x, x, 1, cnt, 0);
    int j = n;
    priority_queue<pair<int,int>> que;
    for (int i  = m; i >= 1; i --)
    {
        while(j >= 1 && a[j].t >= q[i].l)
        {
            que.push({a[j].r, a[j].l});
            j --;
        }
        bool f = true;
        while(1){
            if(que.size() == 0) break;
            if(f == false) break;
            auto tmp = que.top();
            int need = query(1, tmp.second, tmp.second, 1, cnt);
            if(need ==INF){
                f = false;
                break;
            }
            else{
                que.pop();
                update(1, tmp.second, tmp.first, 1, cnt, need + 1);
            }
        }
        ans[q[i].t] = query(1, q[i].r, q[i].r, 1, cnt);
    }
    for (int i = 1; i <= m; i ++)
    {
        if(ans[i] == INF) ans[i] = -1;
        cout << ans[i] << '\n';
    }
}

