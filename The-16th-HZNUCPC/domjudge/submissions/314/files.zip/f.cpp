#include<iostream>
#include<cmath>

using namespace std;


typedef long long ll; 
ll n, m;
int main(){
	cin >> n >> m;
	int flag = 0;
	if(n <= m){
		flag = 1;
	}
	for(ll i = 2; i <= min(m, (ll)sqrt(0.1+n)); i++){
		if(n % i == 0){
			flag = 1;
			break;
		}
	}
	if(flag){
		cout << "NO"<<endl;
	}else{
		cout << "YES"<<endl;
	}
}