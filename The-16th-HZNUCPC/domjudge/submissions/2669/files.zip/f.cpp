    #include  <bits/stdc++.h>

    using namespace std;
    typedef long long LL;
    const int mod = 1e9 + 7;

    LL n, m;

    void kizk(){
        cin >> n >> m;
        if(m >= n)
        {
            cout << "NO\n";
            return;
        }
        if(n % m == 0)
        {
            cout << "NO" << "\n";
            return;
        }
        while(true)
        {
            m = n % m;
            if(m == 1)
                break;
            if(n % m == 0)
            {
                cout << "NO" << "\n";
                return;
            }
        }
        cout << "YES\n";
    }


    int main(){
        std::ios::sync_with_stdio(false);
        cin.tie(nullptr);
        int T; T = 1;
        // cin >> T;
        while(T --) kizk();
        return 0;
    }