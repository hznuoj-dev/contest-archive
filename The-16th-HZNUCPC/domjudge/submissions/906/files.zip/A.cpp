#include<iostream>
using namespace std;
int n,m,ys[19919][10010],wz[10010][10010];
long long ans=0;
int main()
{
	cin>>n;
	for(int h=1;h<=n;h++)
	{ ans=0;
		cin>>m;
		memset(ys,0,sizeof(ys));
		for(int i=1;i<=m;i++)
		{
			int x,y;
			cin>>x>>y>>ys[x][y];
		if	(ys[x][y]==1)ans+=4;
		
		}
		for(int i=1;i<=19;i++)
	{
		for(int j=1;j<=19;j++)
		{
			if(ys[i][j]==1)
			{
				if(i==1)ans--;
				if(j==1)ans--;
				if(ys[i+1][j]>0)ans--;
				if(ys[i-1][j]>0)ans--;
				if(ys[i][j+1]>0)ans--;
				if(ys[i][j-1]>0)ans--;
			}
		}
	}	cout<<ans<<endl;
	}
	

	return 0;
}