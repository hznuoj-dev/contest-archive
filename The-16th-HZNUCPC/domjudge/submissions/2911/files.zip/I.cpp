#include <bits/stdc++.h>
using namespace std;

// #define DEBUG

string s;
int ans;

int main() {
	int _;
	scanf("%d", &_);
	while (_--) {
		cin >> s;
		//奇数
		ans = 0;
		for (int i = 1; i < s.size() - 1; i++) {
			int l = i - 1, r = i + 1;
			int dl = -1, dr = -1;
			bool two = false;
			while (l >= 0 && r < s.size()) {
				if (s[l] != s[r]) {
					if (dl == -1) {
						dl = l, dr = r;
					}
					else {
						if (two == true) {
							r--, l++;
							break;
						}
						if ((s[l] == s[dr] && s[r] == s[dl]) ||
							(s[l] == s[dl] && s[r] == s[dr])) {
							two = true;
						}
						else {
							r = dr - 1, l = dl + 1;
							break;
						}
					}
				}
				r++, l--;
			}
			if (l < 0 || r == s.size()) r--, l++;
			if (dl != -1 && two == false) {
				if (s[i] != s[dl] && s[i] != s[dr]) {
					r = dr - 1;
					l = dl + 1;
				}
			}
			if (r > l) {
				ans = max(ans, r - l + 1);
				// printf("%d %d\n", l, r);
			}
		}
		for (int i = 0; i < s.size() - 1; i++) {
			int l = i, r = i + 1;
			int dl = -1, dr = -1;
			bool two = false;
			while (l >= 0 && r < s.size()) {
				if (s[l] != s[r]) {
					if (dl == -1) {
						dl = l, dr = r;
					}
					else {
						if (two == true) {
							r--, l++;
							break;
						}
						if ((s[l] == s[dr] && s[r] == s[dl]) ||
							(s[l] == s[dl] && s[r] == s[dr])) {
							two = true;
						}
						else {
							r = dr - 1, l = dl + 1;
							break;
						}
					}
				}
				r++, l--;
			}
			if (l < 0 || r == s.size()) r--, l++;
			if (dl != -1 && two == false) {
				r = dr - 1;
				l = dl + 1;
			}
			if (r > l) {
				ans = max(ans, r - l + 1);
			}
		}
		printf("%d\n", ans);
	}
    return 0;
}