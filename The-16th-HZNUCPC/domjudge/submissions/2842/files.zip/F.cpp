#include <bits/stdc++.h>
using namespace std;

int main()
{	
    long long n=1e12,m=1e12-1; 
	scanf("%lld%lld",&n,&m);
	int flag=1;
	
	while(m>1){
		m=n%m;
		
		if(m==0){
			flag=0;
			break;
    	}
	}
	
	
	if(flag)printf("YES");
	else printf("NO");
	
	return 0;
}
// 1e12 1e12-1