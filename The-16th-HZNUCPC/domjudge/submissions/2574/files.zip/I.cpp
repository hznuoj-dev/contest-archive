#include<bits/stdc++.h>

using namespace std;

int n, len;
string s;
int ans;

void Solve() {
	for(int i = 1; i <= len; i ++) {
		int l = i, r = i;
		while(true) {
			if(l < 1 || r > len) {
				ans = max(ans, r - l - 1);
				break;
			}
			if(s[l] == s[r]) {
				l --;
				r ++;
			} else {
				l --; r ++;
				if(l < 1 || r > len) {
					ans = max(ans, r - l - 3);
					break;
				}
				if((s[l]==s[l+1]&&s[r]==s[r-1]) || (s[l]==s[r-1]&&s[l+1]==s[r])) {
					l --; r ++;
					while(true) {
						if(l < 1 || r > len) {
							ans = max(ans, r - l - 1);
							break;
						}
						if(s[l] != s[r]) {
							ans = max(ans, r - l - 1);
							break;
						}
						l --, r ++;
					}
					break;
				} else {
					ans = max(ans, r - l - 3);
					break;
				}
			}
		}
	}
	for(int i = 1; i < len; i ++) {
//		if(s[i] != s[i + 1]) {
//			continue;w
//		}
		int l = i, r = i + 1;
		while(true) {
			if(l < 1 || r > len) {
				ans = max(ans, r - l - 1);
				break;
			}
			if(s[l] == s[r]) {
				l --;
				r ++;
			} else {
				l --; r ++;
				if(l < 1 || r > len) {
					ans = max(ans, r - l - 3);
					break;
				}
				if((s[l]==s[l+1]&&s[r]==s[r-1]) || (s[l]==s[r-1]&&s[l+1]==s[r])) {
					l --; r ++;
					while(true) {
						if(l < 1 || r > len) {
							ans = max(ans, r - l - 1);
							break;
						}
						if(s[l] != s[r]) {
							ans = max(ans, r - l - 1);
							break;
						}
						l --, r ++;
					}
					break;
				} else {
					ans = max(ans, r - l - 3);
					break;
				}
			}
		}
	}
}

signed main(){
	scanf("%d", &n);
	for(int kk = 1; kk <= n; kk ++) {
		cin >> s;
		len = s.length();
		ans = 0;
		s = " " + s;
		Solve();
		if(ans<2)ans=0;
		printf("%d\n", ans);
	}
	return 0;
}