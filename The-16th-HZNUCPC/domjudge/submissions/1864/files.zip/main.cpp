#include <iostream>
using namespace std;
long long  m,n,i;

int main(int argc, char** argv) {
	cin>>n>>m;
	i=m;
	while(1){
		i=n%i;
		if(i==1){
			printf("YES");
			break;
		}
		if(i==0){
			printf("NO");
			break;
		}
	}
	return 0;
}