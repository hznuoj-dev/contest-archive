#include<bits/stdc++.h>
using namespace std;
#define int long long
void solve(){
	int x,y;
	cin>>x>>y;
	if(x==1||y==1){
		cout<<"YES"<<endl;
		return ;
	}
	if(y>=x){
		cout<<"NO"<<endl;
		return ;
	}
	int xxx=sqrt(x);
	for(int i=2;i<=min(y,xxx);i++){
		if(x%i==0){
			cout<<"NO"<<endl;
			return ;
		}
	}
	cout<<"YES"<<endl;
	
	
	
}
signed main(){
//	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}