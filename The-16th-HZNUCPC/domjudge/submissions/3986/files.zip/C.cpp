#include<bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(0);cin.tie(nullptr);cout.tie(nullptr)
#define fi first
#define se second
#define pb push_back
#define eb emplace_back
#define int long long
#define endl '\n'
#define yes "YES\n"
#define ll long long
#define no "NO\n"
const int inf = 0x3f3f3f3f;
const int mod = 1e9 +7;

int fp(int x,int y){
	int ans = 1;
	while(y){
		if(y&1) ans = ans*x%mod;
		x = x*x%mod;
		y >>= 1;
	}
	return ans%mod;
}

ll cz(ll a,ll b){
	if(b==0)	return 1;
	int i;
	if(b>a-b)	b=a-b;
	ll up=1,down=1;
	for(int i=1;i<=b;i++){
		up=(up*(a-i+1))%mod;
		down=(down*i)%mod;
	}
	return up*fp(down,mod-2)%mod;
}

ll lucas(ll a,ll b){
	if(b==0)	return 1;
	return cz(a%mod,b%mod)*lucas(a/mod,b/mod)%mod;
}

map<int,int>ms,mt;
int a[26][26];

void solve(){
	string s,t;
	cin>>s>>t;
	int n=s.size();
	for(int i=0;i<n;i++){
		a[s[i]-'a'][t[i]-'a']++;
		ms[s[i]-'a']++;
		mt[t[i]-'a']++;
	}
	int Ms = ms.size(),Mt = mt.size();
	int ans=0;
	if(abs((int)ms.size()-(int)mt.size())==0){	
		int cnt1 = 0,cnt2 = 0;
		for(int i=0;i<26;i++){
			for(int j=0;j<26;j++){
				if(a[i][j] == 0) continue;
				if(ms[i]>=2&&mt[i]>=1||mt[j]>=2&&ms[j]>=1) cnt1+=a[i][j];
				else if(i == j) cnt1+=a[i][j];
			}
		}
		ans = lucas(cnt1,2);
		for(int i=0;i<26;i++){
			for(int j=0;j<26;j++){
				for(int k=0;k<26;k++){
					if(a[i][j] >=1 && a[k][i] >= 1){
						if(ms[k]==1&&mt[j]==1){
							ans++;
							ans%=mod;
						}
					}
					else if(a[j][i] >=1 && a[i][k] >= 1){
						if(ms[j]==1&&mt[k]==1){
							ans++;
							ans%=mod;
						}
					}
				}
			}
		}
	}else if(abs((int)ms.size()-(int)mt.size())==1){
		int cnt1 = 0,cnt2 = 0;
		for(int i=0;i<26;i++){
			for(int j=0;j<26;j++){
				if(a[i][j] == 0) continue;
				if(ms[i]>=2&&mt[i]>=1&&mt[j]>=2&&ms[j]>=1) cnt1+=a[i][j];
				else if(i == j) cnt1+=a[i][j];
			}
		}
		ans = lucas(cnt1,1);
		for(int i=0;i<26;i++){
			for(int j=0;j<26;j++){
				if(a[i][j] == 0) continue;
				if(ms[i]>=2&&mt[i]==0&&mt[j]>=2&&ms[j]!=0&&Ms>Mt) cnt2+=a[i][j];
				else if(mt[j]>=2&&ms[j]==0&&ms[i]>=2&&mt[i]!=0&&Ms<Mt) cnt2+=a[i][j];
			}
		}
		ans = ans*lucas(cnt2,1)%mod;
		if(cnt2 ==0||cnt1 == 0) ans = 0;
	}else if(abs((int)ms.size()-(int)mt.size())==2){
		int cnt1 = 0,cnt2 = 0;
		for(int i=0;i<26;i++){
			for(int j=0;j<26;j++){
				if(a[i][j] == 0) continue;
				if(ms[i]>=2&&mt[i]>=1&&mt[j]>=2&&ms[j]>=1) cnt1+=a[i][j];
				else if(i == j) cnt1+=a[i][j];
			}
		}
		ans = lucas(cnt1,1);
		for(int i=0;i<26;i++){
			for(int j=0;j<26;j++){
				if(a[i][j] == 0) continue;
				if(ms[i]==1&&mt[i]==0&&mt[j]>=2&&ms[j]!=0&&Ms>Mt) cnt2+=a[i][j];
				else if(mt[j]==1&&ms[j]==0&&ms[i]>=2&&mt[i]!=0&&Ms<Mt) cnt2+=a[i][j];
			}
		}
		ans = ans*lucas(cnt2,1)%mod;
		if(cnt2 ==0||cnt1 == 0) ans = 0;	
	}else if(abs((int)ms.size()-(int)mt.size())==4){
		int cnt2 = 0;
		for(int i=0;i<26;i++){
			for(int j=0;j<26;j++){
				if(a[i][j] == 0) continue;
				if(ms[i]==1 &&mt[i]==0&&mt[j]>=2&&ms[j]!=0&&Ms>Mt) cnt2+=a[i][j];
				else if(mt[j]==1&&ms[j]==0&&ms[i]>=2&&mt[i]!=0&&Ms<Mt) cnt2+=a[i][j];
			}
		}
		if(cnt2<2) ans = 0;
		else
		ans = lucas(cnt2,2)%mod;
	}else{
		cout<<0<<endl;
		return ;
	}
	cout << ans << endl;
}

/*
10000000000 153
*/
signed main(){
	IOS;
	int  T = 1;
	//cin >> T;
	while(T--) solve();
	return 0;
}