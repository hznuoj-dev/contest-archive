#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
typedef pair<ll,ll> P;
P a[110];
map<P,ll> mp;
ll f(ll x1,ll y1,ll x2,ll y2)
{
    if(x1==0&&x2==0){
        return 0;
    }
    else if(y1==0&&y2==0){
        return 0;
    }
    else if(x1*y2==x2*y1)return 0;
    return 1;
}
int main()
{
    ll n;
    P temp;
    cin>>n;
    for(ll i=1;i<=n;i++){
        cin>>a[i].first>>a[i].second;
    }
    for(ll i=1;i<=n;i++){
        for(ll j=i+1;j<=n;j++){
            temp.first=i;
            temp.second=j;
            mp[temp]=__gcd(abs(a[i].first-a[j].first),abs(a[i].second-a[j].second))+1;
        }
    }
    ll ans=0;
    for(ll i=1;i<=n;i++){
        for(ll j=i+1;j<=n;j++){
            for(ll k=j+1;k<=n;k++){
                if(f(a[i].first-a[j].first,a[i].second-a[j].second,a[j].first-a[k].first,a[j].second-a[k].second)){
                    P t1,t2,t3;
                    t1.first=i;
                    t1.second=j;
                    t2.first=i;
                    t2.second=k;
                    t3.first=j;
                    t3.second=k;
                    ans=max(ans,mp[t1]+mp[t2]+mp[t3]-3);
                }
            }
        }
    }
    cout<<ans<<endl;



    return 0;
}
