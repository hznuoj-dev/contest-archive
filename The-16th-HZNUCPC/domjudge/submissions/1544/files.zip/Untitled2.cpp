#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=1e9+7;
vector<pair<int,int>> vp;
void solve() {
	ll n;
	cin>>n;
	ll m;
	cin>>m;
	if(sqrt(m)>=n) {
		for(int i=2; i*i<=n; i++) {
			if(n%i==0) {
				cout<<"NO"<<endl;
				return;
			}
		}
		cout<<"YES"<<endl;
	} else {


		for(int i=m; i>=2; i--) {
			int md=n%i;
			int per=n/i;
			if(md>=per) {
				continue;
			}
			if(n%i==0) {
				cout<<"NO"<<endl;
				return;
			}
		}
		cout<<"YES"<<endl;
	}
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cout<<fixed<<setprecision(10);
	int t=1;
//	cin>>t;
	while(t--) {
		solve();
	}
}