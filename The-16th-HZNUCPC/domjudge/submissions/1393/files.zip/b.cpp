#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

typedef long long ll;

int main() {	
	ios;
	ll n, m;
	cin >> n >> m;
	
	if (n == 1) {
		cout << "YES\n";
		return 0;
	}
	
    if(m==1){
    	cout<<"YES"<<endl;
    	return 0;
	}
	
	for (ll i = 2; i * i <= n; ++i) {
		if (n % i != 0) continue;
		if (i <= m) {
			cout << "NO\n";
			return 0;
		}
	}
	cout << "YES\n";
}