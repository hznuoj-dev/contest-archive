#include <bits/stdc++.h>
#define int long long
using namespace std;
int n, T;
typedef pair<int, int> PII;

string s;
signed main()
{
	ios::sync_with_stdio(0);
	
	cin.tie(0);
	
	cin >> T;
	while(T --)
	{
		cin >> s;
		n = s.size();
		int res = 0;
		for(int k = 1 ; k <= n; k ++)
		{
			int mn = 1e18;
		
			for(int i = 0 ; i + k - 1 < n ; i ++) {
				int x = i + k - 1, no = 0;
				for(int j = 0 ; j < k / 2 ; j ++) {
					if(s[i + j] != s[x - j]) no ++;
				}
				mn = min(mn, no);
			}
			if(mn <= 2) res = max(res, k);
			cout << k << " " << mn << "\n";
		}
		
		cout << res << endl;
	}
}   
