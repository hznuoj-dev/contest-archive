#include<iostream>
using namespace std;
typedef long long ll;
ll n=0,m=0;
bool flag=0;
bool delet[10000020];
//F
int main()
{
	cin>>n>>m;
	for(ll i=2;i<=m;i++)
	{
		if(i>10000000||delet[i]==0)
		{
			if(n%i==0)
			{
				flag=1;
				break;
			}
			delet[2*i]=1;
			delet[3*i]=1;
		}
	}
	
	if(flag==1)
		cout<<"NO";
	else
		cout<<"YES";
	
	
	return 0;
}