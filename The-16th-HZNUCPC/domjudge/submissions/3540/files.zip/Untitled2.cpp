#include <bits/stdc++.h>
using namespace std;
char a[100005], b[100005];
int aa[30]={0}, bb[30]={0};
int main()
{
	int len, s1=0, s2=0, t1=0;
	gets(a);
	gets(b);
	len=strlen(a);
	for(int i=0;i<len;i++)
	{
		aa[a[i]-'a']++;
		bb[b[i]-'a']++;
	}
	for(int i=0;i<=25;i++)
	{
		if(aa[i]!=0)
		s1++;
		if(bb[i]!=0)
		s2++;
	}
	int x= 0;
	for(int i = 0;i<len;i++)
	{
		if(a[i] != b[i] && aa[a[i]-'a']==1 && bb[b[i]-'a'] == 1)
			x++;
		else if(a[i] == b[i])
			x++;	
	}
	if(s1 == s2)
	{
		if(x == 1)
		printf("0\n");
		else
		printf("%lld\n",x*(x-1));
	}
	else if(s1 - 2 == s2)
	{
		int x = 0,y = 0;
		for(int i = 0;i<len;i++)
		{
			if(a[i]!= b[i] && aa[a[i]-'a'] == 1 && bb[a[i]-'a'] == 0 && aa[b[i]-'a'] > 0 && bb[b[i]-'a'])
			;
		}
		
	}
	return 0;
}