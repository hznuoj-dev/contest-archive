#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define endl '\n'
ll t;
ll l[5];
ll r[5];
ll ttemp[5];
string s;
int main(){
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    cin>>t;
    while(t--){
        cin>>s;
        ll ans =s.size()-1;
        ll minn=0;
        for(int i=0;i<=ans;i++){
            ll len=min((ll)i,(ll)ans-i);
            ll temp=1;
            ll flag=0;
            for(int j=1;j<=len;j++){
                if(s[i-j]==s[i+j]){
                    temp+=2;
                }
                else{
                    flag++;
                    l[flag]=i-j;
                    r[flag]=i+j;
                    ttemp[flag-1]=temp;
                    temp+=2;
                    if(flag==3)
                    break;
                }
            }
            ttemp[flag]=temp;
            if(flag==0){
                if(len>0){
                    minn=max(minn,ttemp[flag]);
                }
            }
            else if(flag==1){
                if(s[l[flag]]==s[i]||s[r[flag]]==s[i]){
                    minn=max(minn,ttemp[flag]);
                }
                if(ttemp[0]>1){
                    minn=max(minn,ttemp[0]);
                }
            }
            else if(flag==2||flag==3){
                if(flag==3)
                flag--;
                if((s[l[flag]]==s[l[flag-1]]&&s[r[flag]]==s[r[flag-1]])||(s[l[flag]]==s[r[flag-1]]&&s[r[flag]]==s[l[flag-1]]))
                {
                    minn=max(minn,ttemp[flag]);
                }
                flag--;
                if(s[l[flag]]==s[i]||s[r[flag]]==s[i]){
                    minn=max(minn,ttemp[flag]);
                }
                if(ttemp[0]>1){
                    minn=max(minn,ttemp[0]);
                }
            }
        }
        for(int i=0;i<ans;i++){
            ll j=i+1;
            ll len=min((ll)i+1,(ll)ans-j+1);
            ll temp=0;
            ll flag=0;
            for(int k=1;k<=len;k++){
                if(s[i-k+1]==s[j+k-1]){
                    temp+=2;
                }
                else{
                    flag++;
                    l[flag]=i-k+1;
                    r[flag]=j+k-1;
                    ttemp[flag-1]=temp;
                    temp+=2;
                    if(flag==3)
                    break;
                }
            }
            ttemp[flag]=temp;
            if(flag==0){
                if(len>=1){
                    minn=max(minn,ttemp[flag]);
                }
            }
            if(flag==1){
                if(ttemp[0]>1)
                minn=max(minn,ttemp[0]);
            }
            else if(flag==2||flag==3){
                if(flag==3)
                flag--;
                if((s[l[flag]]==s[l[flag-1]]&&s[r[flag]]==s[r[flag-1]])||(s[l[flag]]==s[r[flag-1]]&&s[r[flag]]==s[l[flag-1]]))
                {
                    minn=max(minn,ttemp[flag]);
                }
                if(ttemp[0]>1){
                    minn=max(minn,ttemp[0]);
                }
            }
        }
        cout<<minn<<endl;
    }
}