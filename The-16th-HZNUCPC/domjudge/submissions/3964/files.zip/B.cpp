#include <bits/stdc++.h>
using namespace std;

// #define DEBUG

typedef long long ll;
typedef complex<double> Complex;
const int N=33336,M=100005;
const ll p=1e9+7;
const double eps=1e-5;

double cross(Complex a,Complex b){
	return a.real()*b.imag()-a.imag()*b.real();
}

int n;
struct Cvx{
	int m;
	vector<Complex> A;
}C[N];

double sq(Complex a){
	return a.real()*a.real()+a.imag()*a.imag();
}

struct idx{
	Complex x;
	idx(double a=0,double b=0){ x=Complex(a,b); }
	idx(Complex t){ x=t; }
	bool operator<(const idx& o)const{
		if(abs(x.real()-o.x.real())>eps) return x.real()<o.x.real();
		else return x.imag()<(o.x.imag()-eps);
	}
};
struct Node{
	int cnt;
	map<idx,int> ch;
}tr[M];int tp;

int query(int u){
	int cur=1;
	for(int j=0;j<C[u].m;j++){
		if(tr[cur].ch.count(C[u].A[j])){
			cur=tr[cur].ch[C[u].A[j]];
		}else{
			return 0;
		}
	}
	return tr[cur].cnt;
}
void add(int u){
	int cur=1;
	for(int j=0;j<C[u].m;j++){
		if(!tr[cur].ch.count(C[u].A[j])){
			tr[cur].ch[C[u].A[j]]=++tp;
		}
		cur=tr[cur].ch[C[u].A[j]];
	}
	tr[cur].cnt++;
}

bool eq(Complex a,Complex b){
	if(abs(a.real()-b.real())<eps && abs(a.imag()-b.imag())<eps){
		return 1;
	}else{
		return 0;
	}
}

vector<Complex> lst;
bool inv(int u){
	lst.clear();
	for(int j=0;j<C[u].m;j++){
		lst.push_back(C[u].A[j]);
	}
	for(int j=0;j<C[u].m;j++){
		C[u].A[j].imag(-C[u].A[j].imag());
	}
	reverse(C[u].A.begin()+1,C[u].A.end());
	bool r=0;
	for(int j=0;j<C[u].m;j++){
		if(!eq(lst[j],C[u].A[j])){
			r=1;
			break;
		}
	}
	return r;
}

vector<Complex> t;

int main() {
	
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>C[i].m;
		t.clear();
		Complex av=0,cur;int x,y;
		for(int j=1;j<=C[i].m;j++){
			cin>>x>>y;
			cur=Complex(x,y);
			av+=cur;
			t.push_back(cur);
		}
		av/=C[i].m;
		for(int j=0;j<C[i].m;j++){
			t[j]-=av;
		}
		if(cross(t[0],t[1])>0){
			reverse(t.begin(),t.end());
		}
		int mx_dis=-1;
		for(int j=0;j<C[i].m;j++){
			if(mx_dis==-1 || sq(t[j])>sq(t[mx_dis])){
				mx_dis=j;
			}
		}
		Complex rt=t[mx_dis];
		for(int j=0;j<C[i].m;j++){
			t[j]/=rt;
		}
		for(int j=0;j<C[i].m;j++){
			C[i].A.push_back(t[(j+mx_dis)%C[i].m]);
			// cout<<C[i].A[j]<<"\n";
		}
		// cout<<"\n\n";
	}

	tr[++tp].cnt=0;
	for(int i=1;i<=n;i++){
		cout<<query(i)<<"\n";
		add(i);
		if(inv(i)) add(i);
	}

	// map<idx,int> m;
	// m[idx(1,2)]=12;
	// m[idx(1,2+eps/2)]=15;
	// m[idx(1,4)]=14;
	// m[idx(5,4)]=54;

	// for(auto i:m){
	// 	cout<<i.first.x<<" "<<i.second<<"\n";
	// }
	// cout<<m[idx(2,4)]<<"\n";

    return 0;
}