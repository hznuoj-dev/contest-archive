import java.io.*;
import java.util.*;
import java.math.*;
public class Main {
  public static void main(String[] args){
	  InputStream inputStream = System.in;
	  OutputStream outputStream = System.out;
	  InputReader in = new InputReader(inputStream);
	  PrintWriter out = new PrintWriter(outputStream);
	  TaskA solver = new TaskA();
	  solver.solve(1,in,out);
	  out.close();
  }
  
  static class TaskA{
	  public void solve(int testNumber,InputReader in,PrintWriter out){
		  String a = in.next();
		  String b = in.next();
		  int n = a.length();
		  int count = 0;
		  for(int i = 0;i < n;i++){
			  if(a.charAt(i) == b.charAt(i)){
				  count++;
			  }
		  }
		  if(n - count == 0){
			  long res = n * (n-1L) / 2;
			  res %= 1000000007;
			  out.println(res);
		  }else{
			  long res = count * (n - count);
			  res %= 1000000007;
			  out.println(res);
		  }
	  }
  }
  
  static class InputReader{
	  public BufferedReader reader;
	  public StringTokenizer tokenizer;
	  public InputReader(InputStream stream){
		  reader = new BufferedReader(new InputStreamReader(stream),32768);
		  tokenizer = null;
	  }
	  boolean hasNext()
	  {
		 while(tokenizer == null || !tokenizer.hasMoreTokens())
		 {
			 try
			 {
				 tokenizer = new StringTokenizer(reader.readLine());
			 }catch(Exception e)
			 {
				 return false;
			 }
		 }
		 return true;
	  }
	  public String next(){
		  while(tokenizer == null || !tokenizer.hasMoreTokens()){
			  try{
				  tokenizer = new StringTokenizer(reader.readLine());
			  }catch(IOException e){
				  throw new RuntimeException(e);
			  }
		  }
		  return tokenizer.nextToken();
	  }
	  public String nextLine()
	  {
		  String str = null;
		  try
		  {
			  str = reader.readLine();
		  }catch(IOException e){
			  e.printStackTrace();
		  }
		  return str;
	  }
	  public int nextInt(){
		  return Integer.parseInt(next());
	  }
	  public double nextDouble(){
		  return Double.parseDouble(next());
	  }
	  public long nextLong(){
		  return Long.parseLong(next());
	  }
	  public BigInteger nextBigInteger(){
		  return new BigInteger(next());
	  }
	  public BigDecimal nextBigDecimal(){
		  return new BigDecimal(next());
	  }
  }
}
