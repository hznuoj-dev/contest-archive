#include<bits/stdc++.h>
using namespace std;
int T,ans;

signed main(){
	cin >> T;
	while (T--) {
		ans=0;
		string s;
		cin>>s;
		s=' '+s;
		int len=s.size()-1;
		for(int i=2;i<=len;i++){
			int l,r;
			l=r=i;
			bool flag=false;
			bool first=false;
			while(l-1>=1&&r+1<=len){
				l--;r++;
				if(s[l]!=s[r]&&!first){
					first=true;
					if(s[r]==s[i]||s[l]==s[i]){
						ans=max(ans,r-l+1);
						flag=true;
					}
					for(int j=1;j<=len;j++){
						if(r+j<=len&&l-j>=1&&s[r+j]!=s[l-j]){
							if(s[r+j]==s[l]&&s[l-j]==s[r]){
								flag=true;
								l=l-j;
								r=r+j;
								ans=max(ans,r-l+1);
								break;
							}
							else flag=false;
							break;
						}
						else if(r+j>len||l-j<1){
							flag=false;
							ans=max(ans,r-l-1);
							break;
						}
					}
				}
				else if(s[l]!=s[r]){
					ans=max(ans,r-l-1);
					break;
				}
				else{
					ans=max(ans,r-l+1);
				}
				if(!flag){	
					break;
				}
			}
		}
		vector<int>v;
		for(int i=1;i<=len;i++){
			if(i+1<=len&&s[i]==s[i+1]){
				v.push_back(i);
			}
		}
		if(v.size()>=1)ans=max(ans,2);
		for(int pos:v){
			int l,r;
			l=pos,r=pos+1;
			bool flag=false;
			bool first=false;
			while(l-1>=1&&r+1<=len){
				l--;r++;
				if(s[l]!=s[r]&&!first){
					first=true;
					for(int j=1;j<=len;j++){
						if(r+j<=len&&l-j>=1&&s[r+j]!=s[l-j]){
							if(s[r+j]==s[l]&&s[l-j]==s[r]){
								flag=true;
								l=l-j;
								r=r+j;
								ans=max(ans,r-l+1);
								break;
							}
							else flag=false;
							break;
						}
						else if(r+j>len||l-j<1){
							flag=false;
							ans=max(ans,r-l-1);
							break;
						}
					}
				}
				else if(s[l]!=s[r]){
					ans=max(ans,r-l-1);
					break;
				}
				else{
					ans=max(ans,r-l+1);
				}
				if(!flag){	
					break;
				}
			}
		}
		if(ans==1)ans=0;
		cout<<ans<<'\n';
	}
}
/*
6
abccab
ihi
stfgfiut
palindrome
i
aaa
*/