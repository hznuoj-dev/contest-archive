#include<iostream>
#include<cstring>
#include<algorithm>
#include<stack>
#include<queue>
#define endl '\n'
using namespace std;
const int N=1e6+10,INF=2e9;
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int,int> PII;
int dx[4]={0,0,1,-1},dy[4]={1,-1,0,0};
struct node{
	int x,y,c;
}a[400];
int b[20][20];
int dfs(int x,int y){
	int res=0;
	queue<PII> q;
	q.push({x,y});
	while(q.size()){
		auto t=q.front();
		b[t.first][t.second]=1;
		q.pop();
		for(int i=0;i<4;i++){
		    int xx=t.first+dx[i],yy=t.second+dy[i];
		    if(xx<1||xx>19||yy<1||yy>19||b[xx][yy])continue;
		    if(!b[xx][yy])res++;
		    else if(b[xx][yy]==1)q.push({xx,yy});
     	}
	}
	return res;
} 
void solve(void){
	memset(b,0,sizeof b);
	int n,res=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i].x>>a[i].y>>a[i].c;
		b[a[i].x][a[i].y]=a[i].c;
	}
	for(int i=1;i<=n;i++){
		if(a[i].c==1)res+=dfs(a[i].x,a[i].y);
	}
	cout<<res<<endl;
}
int main(void){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int TT;
	TT=1;
	cin>>TT;
	while(TT--){
		solve();
	}
	return 0;
}