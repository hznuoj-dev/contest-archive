#include <bits/stdc++.h>
using namespace std;
int main(){
	char s[5005];
	int T;scanf("%d",&T);
	int cnt = 0, ans;
	int pos1, pos2;
	while(T--){
		scanf("%s", s);
		int len = strlen(s);
		ans = 0;
		for(int i = 0;i < len; ++i){
			cnt = 0;
			
			for(int j = 1; i - j >= 0 && i + j < len; ++j){
				//cout<< '#' << i - j << ' '<< s[i - j] << ' ' << s[i + j] << endl;
				//cout << i << " " << j << ' ' << cnt << endl;
				if(s[i - j] == s[i + j] && cnt == 0){
					ans = max(ans, j * 2 + 1);
					//cout << i << " " << j << "  "<< 1 << endl;
				}
				else if(s[i - j] == s[i + j] && cnt == 1){
					//cout << i << " " << j << "  "<< 2 << endl;
					continue;
				} 
				else if(s[i - j] == s[i + j] && cnt == 2){
					if(s[i - pos1] == s[i + pos2] && s[i + pos1] == s[i - pos2]){
						ans = max(ans, j * 2 + 1);
						//cout << i << " " << j << "  "<< 3 << endl;
					}
				} else {
					cnt += 1;
					if(cnt >= 3)break;
					if(cnt == 1){
						pos1 = j;
					} else if (cnt == 2){
						pos2 = j;
						if(s[i - pos1] == s[i + pos2] && s[i + pos1] == s[i - pos2]){
							ans = max(ans, j * 2 + 1);
							//cout << i << " " << j << "  "<< 4 << endl;
						}
					}
				}
			}
			cnt = 1; 
			pos1 = i;
			for(int j = 1; i - j >= 0 && i + j < len; ++j){
				//cout<< '#' << i - j << ' '<< s[i - j] << ' ' << s[i + j] << endl;
				//cout << i << " " << j << ' ' << cnt << endl;
				if(s[i - j] == s[i + j] && cnt == 0){
					ans = max(ans, j * 2 + 1);
					//cout << i << " " << j << "  "<< 1 << endl;
				}
				else if(s[i - j] == s[i + j] && cnt == 1){
					//cout << i << " " << j << "  "<< 2 << endl;
					continue;
				} 
				else if(s[i - j] == s[i + j] && cnt == 2){
					if(s[i] == s[i + pos2] || s[i] == s[i - pos2]){
						ans = max(ans, j * 2 + 1);
						//cout << i << " " << j << "  "<< 3 << endl;
					}
				} else {
					cnt += 1;
					if(cnt >= 3)break;
					if(cnt == 1){
						pos1 = j;
					} else if (cnt == 2){
						pos2 = j;
						if(s[i] == s[i + pos2] || s[i] == s[i - pos2]){
							ans = max(ans, j * 2 + 1);
							//cout << i << " " << j << "  "<< 4 << endl;
						}
					}
				}
			}
			cnt = 0;
			for(int j = 1; i - j + 1 >= 0 && i + j < len; ++j){
				//cout << i - j + 1 << ' '<< s[i - j + 1] << ' ' << s[i + j] << endl;
				if(s[i - j + 1] == s[i + j] && cnt == 0){
					ans = max(ans, j * 2);
					//cout << i << " " << j << "  "<< 1 << endl;
				}
				else if(s[i - j + 1] == s[i + j] && cnt == 1){
					//cout << i << " " << j << "  "<< 2 << endl;
					continue;
				} 
				else if(s[i - j + 1] == s[i + j] && cnt == 2){
					if(s[i - pos1 + 1] == s[i + pos2] && s[i + pos1] == s[i - pos2 + 1]){
						ans = max(ans, j * 2);
						//cout << i << " " << j << "  "<< 3 << endl;
					}
				} else {
					cnt += 1;
					if(cnt >= 3)break;
					if(cnt == 1){
						pos1 = j;
						//cout << i << " " << j << "  "<< 4 << endl;
					} else if (cnt == 2){
						pos2 = j;
						if(s[i - pos1 + 1] == s[i + pos2] && s[i + pos1] == s[i - pos2 + 1]){
							ans = max(ans, j * 2);
							//cout << i << " " << j << "  "<< 5 << endl;
						}
					}
				}
			}
		}
		printf("%d\n", ans);
	}
	
	
}