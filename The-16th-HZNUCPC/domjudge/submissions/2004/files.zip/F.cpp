#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;
#define quick_cin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define rep1(i,a,n) for(int i=(a);i<(n);++i)
#define rep2(i,a,n) for(int i=(a);i<=(n);++i)
#define per1(i,n,a) for(int i=(n);i>(a);--i)
#define per2(i,n,a) for(int i=(n);i>=(a);--i)
#define endl "\n"

#define dbug(a) cout<<(a)<<"\n"
#define dbug2(a,b) cout<<(a)<<" "<<(b)<<"\n"
#define dbug3(a,b,c) cout<<(a)<<" "<<(b)<<" "<<(c)<<"\n"
typedef long long LL;
typedef unsigned long long ULL;
#define int LL
typedef double dob;
typedef pair<int,int> PII;
int n,m;
struct node {
	int x,y;
}a[110];
int ok(dob a,dob b, dob c)
{
	if(a<b+c&&b<a+c&&c<a+b)
	{
		if(a>fabs(b-c)&&b>fabs(a-c)&&c>fabs(b-a))return 1;
	}
	return 0;
}

bool ok2(int i,int j,int k){
	dob k1,k2;
	int x1=a[i].x,x2=a[j].x,x3=a[k].x;
	int y1=a[i].y,y2=a[j].y,y3=a[k].y;
	if(x1-x2==0)
	{
		if(x1-x3==0)return 0;
		else return 1;
	}
	if(x1-x3==0)
	{
		if(x1-x2==0)return 0;
		else return 1;
	}
	k1=1.0*(y1-y2)/(x1-x2);
	k2=1.0*(y1-y3)/(x1-x3);
	if(k1==k2)return 0;
	return 1;
}

dob len(int i,int j)
{
	ULL x1=a[i].x,x2=a[j].x;
	ULL y1=a[i].y,y2=a[j].y;
	return sqrt((ULL)(x1-x2)*(ULL)(x1-x2)+(ULL)(y1-y2)*(ULL)(y1-y2));
}
int add(int i,int j)
{
	int x1=a[i].x,x2=a[j].x;
	int y1=a[i].y,y2=a[j].y;
	int fz=y1-y2;
	int fm=x1-x2;
	int ans=0;
	if(fm==0)
	{
		ans= abs(y1-y2)-1;
	}
	else if(fz==0)ans= abs(x1-x2)-1;
	else if(fz%fm==0||fm%fz==0)
	{
		ans= min(abs(y1-y2)-1,abs(x1-x2)-1);
	}
	return max(ans,0ll);
}
signed main ()
{
	quick_cin();
	
	cin>>n;
	
	rep2(i,1,n)cin>>a[i].x>>a[i].y;
	int ans=0;
	rep2(i,1,n)
	rep2(j,1,n)
	rep2(k,1,n)
	{
		if(i==j||i==k||j==k)continue;
		dob a=len(i,j),b=len(j,k),c=len(i,k);
	//	dbug3(a,b,c);
	if(!ok2(i,j,k)){
		continue;
	}
		if(ok(a,b,c))
		{
			int ans1=0;
			ans1+=add(i,j);
			ans1+=add(i,k);
			ans1+=add(j,k);
			ans1+=3;
		//	dbug3(i,j,k);
		//	dbug2("--",ans1);
			ans=max(ans,ans1);
		}
	}
	dbug(ans);
	return 0;
}