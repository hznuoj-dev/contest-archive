#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
typedef long long LL;
using namespace std;
typedef pair<int,int> PII;
const int N=1e9+7;
LL res=0;
int main(){
    LL n,m;
    scanf("%lld%lld",&n,&m);
    if(m==1){
        printf("YES");
        }
    else if(n<=m){
        printf("NO");
    }
    else{
        LL x;
        //ƽ��
        if(m==3){
            if(n-2<=3)m-1;
            else if (n-3<3){cout<<"YES";return 0;}
            else if (n-3==3){cout<<"NO";return 0;}
            else if(n-3>3)m-1;
        }
		if (m==2){
            if(n==3){cout<<"NO";return 0;}
            else {cout<<"YES";return 0;}
}
        if (n-m+1<=m)m-1;
        while(m>3){
            if(n-m+1>m)m-1;
            else m-2;
        }
        if(m==3){
            if(n-2<=3)m-1;
            else if (n-3<3){cout<<"YES";return 0;}
            else if (n-3==3){cout<<"NO";return 0;}
            else if(n-3>3)m-1;
        }
		if (m==2){

            if(n==3){cout<<"NO";return 0;}
            else {cout<<"YES";return 0;}
}
        }



}
