#include<bits/stdc++.h>
#define LL long long
using namespace std;
LL n,m;
int main()
{
	scanf("%lld%lld",&n,&m);
	if (n<=m) {printf("NO"); return 0;}
	LL t=t=min((LL)sqrt(n),m);
	for (int i=2; i<=t; i++)
	 if (n%i==0)
	  {
	  	printf("NO");
	  	return 0;
	  }
	printf("YES");
	return 0;
}