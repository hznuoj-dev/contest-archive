import math
flag=0
flag=False
n,m=map(int,input().split())
def fact(n,m):
    if(m==1):
        return True
    elif(m%n==0 or n%m==0):
        return False
    elif (n>m):
        return fact(n,n%m)
for i in range(2,m):
    if(n%i==0):
        flag=1
        print("NO")
        break
if(flag==0):
    if(fact(n,m)):
        print("YES")
    else:
        print("NO")
