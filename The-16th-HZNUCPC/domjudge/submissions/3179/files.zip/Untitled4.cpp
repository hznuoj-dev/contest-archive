#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
typedef pair<int,int> pii;
const int mod =1e9+7;
ll jiecheng (int a)
{
	ll res =1;
	res =res*a%mod;
	res=res*(a-1)%mod;
	res/=2;
	return res;
}
string s1,s2;
unordered_map<char,int> st1,st2;
int a[10];
signed main()
{
	Acode;
	cin >> s1 >> s2;
	s1 = ' ' + s1;
	s2 = ' ' + s2;
	int len = s1.size();
	for(int i = 1;i < len;i++)
	{
		st1[s1[i]]++;
		st2[s2[i]]++;
	}
	int si1 = st1.size();
	int si2 = st2.size();
	int x=abs(si1-si2);
	if(abs(si1 - si2) > 4){
		cout << 0;
		return 0;
	}
	for(int i = 1, c1,c2;i < len;i++)
	{
		if(s1[i]==s2[i])
		{
			a[0]++;
		}
		else if(st1[s1[i]] == 1 && st2[s1[i]] == 0)
		{
			a[2]++;
		}
		else if(st1[s1[i]] == 1 && st2[s1[i]] == 1)
		{
			a[0]++;
		}
		else  if(st1[s1[i]] == 0 && st2[s1[i]] == 1)
		{
			a[2]++;
		}
		else if(st1[s1[i]] >= 2 && st2[s1[i]] == 0)
		{
			a[1]++;
		}
		else if(st1[s1[i]] == 0 && st2[s1[i]] >= 2)
		{
			a[1]++;
		}
	}
//	for(int i=0;i<=2;i++) 
//	{
//		cout<<"-----------"<<a[i]<<endl;
//	}
	if(x==0) 
	{
		cout<<jiecheng(a[0])<<endl;
	}
	else if(x==1)
	{
		cout<<(a[0]*a[1])%mod <<endl;;
	}
	else if(x==2)
	{
		cout<<((a[2]*a[0])%mod+jiecheng(a[1]))%mod;
	}
	else if(x==3)
	{
		cout<<(a[1]*a[2])%mod;
	}
	else if(x==4)
	{
		cout<<jiecheng(a[2])%mod<<endl;
	}
	else 
	{
		cout<<0<<endl;
	}
	return 0;
}
