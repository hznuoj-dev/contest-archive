#include <iostream>
using namespace std;
int a[25][25];
void p(int x,int y){
	if(a[x-1][y]!=0&&a[x-1][y]!=3){
		if(a[x-2][y]!=0&&a[x-1][y-1]!=0&&a[x-1][y+1]!=0){
			a[x-1][y]=0;
		}
	}
	if(a[x+1][y]!=0&&a[x+1][y]!=3){
		if(a[x+2][y]!=0&&a[x+1][y-1]!=0&&a[x+1][y+1]!=0){
			a[x+1][y]=0;
		}
	}
	if(a[x][y+1]!=0&&a[x][y+1]!=3){
		if(a[x-1][y+1]!=0&&a[x+1][y+1]!=0&&a[x][y+2]!=0){
			a[x][y+1]=0;
		}
	}
	if(a[x][y-1]!=0&&a[x][y-1]!=3){
		if(a[x][y-2]!=0&&a[x-1][y-1]!=0&&a[x+1][y-1]!=0){
			a[x][y-1]=0;
		}
	}
}
int main(void){
	int t;
	cin>>t;
	for(int i=0;i<=20;i++){
		a[0][i]=3;
		a[i][0]=3;
		a[i][20]=3;
		a[20][i]=3;
	}
	while(t--){
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				a[i][j]=0;
			}
		}
		int n;
		cin>>n;
		for(int i=1;i<=n;i++){
			int x,y,c;
			cin>>x>>y>>c;
			if(a[x-1][y]!=0&&a[x+1][y]!=0&&a[x][y-1]!=0&&a[x][y+1]!=0){
				continue;
			} else {
				p(x,y);
				a[x][y]=c;
			}
		}
		int ans=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(a[i][j]==1){
					if(a[i-1][j]==0){
						ans++;
					}
					if(a[i+1][j]==0){
						ans++;
					}
					if(a[i][j-1]==0){
						ans++;
					}
					if(a[i][j+1]==0){
						ans++;
					}
				}
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}
