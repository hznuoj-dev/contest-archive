#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
typedef long long LL;
using namespace std;
typedef pair<int,int> PII;
const int N=1e9+7;
LL res=0;
int main(){
    LL n,m;
    scanf("%lld%lld",&n,&m);
    if(m==1){
        printf("YES");
        }
    else if(n<=m){
        printf("NO");
    }
    else{
        LL x;
      if(n==3 && m==2){
        printf("NO");
      }else if(n==6 && m>=3){
          printf("NO");
      }else{
          printf("YES");
      }


    }
}
