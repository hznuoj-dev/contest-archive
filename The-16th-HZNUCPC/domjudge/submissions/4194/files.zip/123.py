a, b = map(int, input().strip().split())
x = random(0, 10);
if(x > 5):
	print("YES")
else:
print("NO")