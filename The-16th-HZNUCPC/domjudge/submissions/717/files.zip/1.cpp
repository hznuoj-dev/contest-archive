#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll t,x,y;
ll s[101][101];
ll check(ll a,ll b,ll c,ll d){
	ll w1=abs(d-b);
	ll w2=abs(c-a);
	ll w3=max(w1,w2);
	ll w4=w1+w2-w3;
	return __gcd(w3,w4);
}
int main()
{
	scanf("%lld",&t);
	for(int i=0;i<t;i++){
		cin>>x>>y;
		s[i][0]=x;
		s[i][1]=y;
	}
	ll mx=0;
	for(int i=0;i<t;i++){
		for(int j=i+1;j<t;j++){
			for(int k=j+1;k<t;k++){
				ll sum=0;
				ll a=s[i][0],b=s[i][1],c=s[j][0],d=s[j][1],e=s[k][0],f=s[k][1];
				if((e-c)*(d-b)!=(f-d)*(c-a)){
					sum+=check(a,b,c,d);
					sum+=check(c,d,e,f);
					sum+=check(a,b,e,f);
					mx=max(mx,sum);
				}
				else break;
			}
		}
	}
	cout<<mx<<endl;
	return 0;
}
