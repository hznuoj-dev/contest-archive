#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int long long
int x[30][30]={0};
	ll ans=0,ans1=0;
	void g1(int u,int v,int xa,int xb,int temp,int fa){
					if(x[u][v]==0)return;
					int temp1=x[u][v];
					if(x[u][26]==1)xa--;
					if(x[26][v]==1)xb--;
					if(x[v][26]==0){
						xa++;
					}						
					if(x[26][u]==0){
						xb++;	
					}
			//		cout<<temp1<<' '<<temp<<' '<<u<<' '<<v<<']'<<xa<<' '<<xb<<endl;
					if(xa==xb){
						if(fa){
							ans+=(temp*temp1/2)%1000000007;
						}else{
							ans+=(temp*temp1)%1000000007;
						}
						
						ans%=1000000007;
					}					
}
void g(int i,int j,int xa,int xb){
	int temp=x[i][j];
			x[i][j]--;
		//	cout<<x[i][j]<<endl;
	
			x[i][26]--;
			x[26][j]--;
			if(x[i][26]==0)xa--;
			if(x[26][j]==0)xb--;
			if(x[j][26]==0){
				xa++;	
			}
			x[j][26]++;
			if(x[26][i]==0){
				xb++;
			}
	        x[26][i]++;
	        for(int u=i;u<26;u++){
			int v=0;
			if(u==i)v=j;
				for(;v<26;v++){
					int fa=0;
					if(i==u&&j==v){
						fa=1;
					}
        			g1(u,v,xa,xb,temp,fa);
				}
			}
		x[i][j]++;
		x[i][26]++;
		x[26][j]++;	
		x[26][i]--;	
		x[j][26]--;
		
}

void solve()
{
	string a,b;
	cin>>a;
	cin>>b;
	int len=a.length();
	for(int i=0;i<len;i++){
		x[a[i]-'a'][b[i]-'a']++;
	}
	for(int i=0;i<26;i++){
		for(int j=0;j<26;j++){
			x[i][26]+=x[i][j];
			x[26][j]+=x[i][j];
			if(i==j){
				x[26][26]+=x[i][j];
			}
		}
	}
	int xa=0,xb=0;
	
	for(int i=0;i<26;i++){
		if(x[26][i]>0)xb++;
		if(x[i][26]>0)xa++;	
	}
//	cout<<xa<<endl<<xb<<endl;
/*	for(int i=0;i<=26;i++){
		for(int j=0;j<=26;j++){
			cout<<x[i][j]<<' ';
		}
		cout<<endl;
	}*/
	for(int i=0;i<26;i++){
		for(int j=0;j<26;j++){
			//if(i==j)continue;
			if(x[i][j]==0)continue;
			g(i,j,xa,xb);
		}
	}
	cout<<ans;
}
signed main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	ll t=1;
	//cin>>t;
	while(t--)
	{
		solve();
		cout<<'\n';
	}
}