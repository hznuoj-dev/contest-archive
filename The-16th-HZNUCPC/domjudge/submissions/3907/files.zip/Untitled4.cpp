#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
#include<unordered_map>
#include<cstring>
#include<cmath>
#include<set>

using namespace std;
const int N=110;
typedef long long ll;
const double eps=1e-9;

ll x[N],y[N];
int n;



int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld%lld",&x[i],&y[i]);
	}
	ll ans=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int k=1;k<=n;k++)
			{
				if(i==j || j==k || i==k)
				{
					continue;
				}
			
				if(y[i] == y[j] && y[j] == y[k] && y[k] == y[i] || x[i] == x[j] && x[j] == x[k] && x[k] == x[i])
					continue;
				
				double x1,y1,z1;
				
				if(y[i]==y[j]||x[i]==x[j])
				{
					x1=-1;
				
				}else{
					x1 = 1.0*abs(1.0*(x[i] - x[j])/(y[i] - y[j]));
				}
				
				if(y[j]==y[k]||x[j]==x[k])
				{
					y1=-1;
				}
				else{
					y1 = 1.0*abs(1.0*(x[j] - x[k])/(y[j] - y[k]));
				}
				
				if(y[i]==y[k]||x[i]==x[k])
				{
					z1=-1;
				}
				else{
				z1 = 1.0*abs(1.0*(x[k] - x[i])/(y[k] - y[i]));
				}
				
				if(x1==y1 && z1==y1 && x1==z1)
				{
					
					continue;
				}
				if(x1<1) x1=1.0/x1;
				if(y1<1) y1=1.0/y1;
				if(z1<1) z1=1.0/z1;
				//cout<<x1<<" "<<y1<<" "<<z1<<" "<<endl;
				ll ans1=1LL*max(abs(x[i]-x[j]),abs(y[i]-y[j]))/x1;
				ll ans2=1LL*max(abs(x[i]-x[k]),abs(y[i]-y[k]))/z1;
				ll ans3=1LL*max(abs(x[k]-x[j]),abs(y[k]-y[j]))/y1;
				ans=max(ans,abs(ans1) + abs(ans2) + abs(ans3)+3);
			//	cout<<ans1<<" "<<ans2<<" "<<ans3<<" "<<endl;
			}
		}
	}
	printf("%lld\n",ans-3);
	
	return 0;
}