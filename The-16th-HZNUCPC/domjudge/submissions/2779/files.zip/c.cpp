#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ct(x) cout<<x<<'\n'
#define dg(x)  cout<<#x<<'='<<x<<'\n';
#define pii  pair<int,int> 
#define N 350000

#define double long double
#define ios ios::sync_with_stdio(0),cin.tie(0),cout.tie(0)

/*
aaaa
aaaa

6

abca
aaaa

4

*/
const int mod=1e9+7;



void solve(){
	int inv=(mod-mod/2)%mod;
	
  string s1,s2;
  cin>>s1>>s2;
  int n=s1.size();
 
  map<pair<char,char>,int> mp;
  map<char,int> mp1,mp2;
  int ans1=0,ans2=0;
  
  for(int i=0;i<n;i++){
  	mp1[s1[i]]++;
  	mp2[s2[i]]++;
  	if(mp1[s1[i]]==1)
  	ans1++;
  	 if(mp2[s2[i]]==1)
  	 ans2++;
  	mp[{s1[i],s2[i]}]++;
  }

  int be1=ans1,be2=ans2;

  int ans=0;

  for(char c1='a';c1<='z';c1++)
    for(char c2='a';c2<='z';c2++)
      for(char c3='a';c3<='z';c3++)
       for(char c4='a';c4<='z';c4++){
         mp1[c1]--;
         if(mp1[c1]==0)
         ans1--;
         
         mp1[c3]--;
         if(mp1[c3]==0)
         ans1--;
         
         mp2[c1]++;
         if(mp2[c1]==1)
         ans2++;
         
         mp2[c3]++;
         if(mp2[c3]==1)
         ans2++;
         
         
         mp2[c2]--;
         if(mp2[c2]==0)
         ans2--;
         mp2[c4]--;
          if(mp2[c4]==0)
         ans2--;
         
         mp1[c2]++;
         if(mp1[c2]==1)
		  ans1++;
		  
         mp1[c4]++;
          if(mp1[c4]==1)
		  ans1++;         
          
         if(mp1[c1]>=0&&mp1[c3]>=0&&mp2[c2]>=0&&mp2[c4]>=0)
         if(ans1==ans2){
         
         	 int d1=mp[{c1,c2}];
         	 int d2=mp[{c3,c4}];
         	  if(c1==c3&&c2==c4)
         	  d2--;
         	  if(d2>=0&&d1>=0){
//         	    if(c1=='a'&&c2=='a'&&c3=='a'&&c4=='a')
//         	    {
//         	    	dg(ans1)
//				}
         	  	ans+=d1*d2%mod;
         	  	ans%=mod;
			   }
		 }
		 
		 ans1=be1;
		 ans2=be2;
         
          mp2[c2]++;
          mp2[c4]++;
         
          mp1[c2]--;
          mp1[c4]--;
          
          
           mp1[c1]++;
           mp1[c3]++;
         
           mp2[c1]--;
           mp2[c3]--;
           
	   }
	  
	   ans=ans*inv;
	   ans%=mod;
	   ct(ans);
}

signed main(){
	ios;
	int t=1;
	// cin>>t;
	while(t--)
	solve();
	return 0;
}