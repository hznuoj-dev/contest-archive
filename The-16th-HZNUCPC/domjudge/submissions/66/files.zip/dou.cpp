#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long n,m;
	scanf("%lld%lld",&n,&m);
	if(n%m||m==1)
		cout<<"YES"<<endl;
	else
		cout<<"NO"<<endl;
	return 0;
}