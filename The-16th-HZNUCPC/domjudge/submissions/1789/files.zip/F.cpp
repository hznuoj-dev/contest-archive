#include<iostream>
#include<cstring>
using namespace std;
int main(){
	long long n,m;
	cin>>n>>m;
	if(n%2==0)cout<<"NO";
	else cout<<"YES";
	return 0;
}