#include <bits/stdc++.h>
#define ll long long
#define Ma 1000005
#define mod 1000000007
#define N 26
#define PLL pair<ll,ll>

using namespace std;

map <PLL,ll> mp;
ll f[N],g[N];
ll okf[N],okg[N];
ll op[4];
ll all=0;

bool cmp()
{
	ll cnt=0;
	for (ll i=0;i<N;i++)
		cnt+=(f[i]!=0)+(g[i]!=0);
	return (cnt==all);
}



void sol()
{
	string s,t;
	cin>>s>>t;
	for (ll i=0;i<s.size();i++)
		mp[{s[i]-'a',t[i]-'a'}]++,f[s[i]-'a']++,g[t[i]-'a']++;
	for (ll i=0;i<N;i++)
		okf[i]=f[i],okg[i]=g[i],all+=(f[i]!=0)+(g[i]!=0);
	ll ans=0;
	for (ll i=0;i<N*N;i++)
	{
		op[0]=i/N,op[1]=i%N;
		for (ll j=i;j<N*N;j++)
		{
			op[2]=j/N,op[3]=j%N;
			for (ll k=0;k<4;k++)
				if (k&1)
					f[op[k]]++,g[op[k]]--;
				else
					f[op[k]]--,g[op[k]]++;
			if (cmp())
			{
				if (i==j)
					ans+=mp[{op[0],op[1]}]*(mp[{op[0],op[1]}]-1)/2;
				else
					ans+=mp[{op[0],op[1]}]*mp[{op[2],op[3]}];
				//printf("OK i=%lld j=%lld\n",i,j);
			}
			for (ll k=0;k<4;k++)
				if (k&1)
					f[op[k]]--,g[op[k]]++;
				else
					f[op[k]]++,g[op[k]]--;
		}
	}
	printf("%lld\n",ans%mod);
	return;
}

int main ()
{
	sol();
	return 0;
}