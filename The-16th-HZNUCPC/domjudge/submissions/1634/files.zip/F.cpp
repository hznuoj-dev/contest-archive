#include <bits/stdc++.h>
#define ll long long
#define Ma 1000005
#define mod 100000007
#define N 1000005
#define PLL pair<ll,ll>

using namespace std;

ll n,m;


void sol()
{
	cin>>n>>m;
	if (m==1)
	{
		printf("YES\n");
		return;
	}
	if (m>=n)
	{
		printf("NO\n");
		return;
	}
	for (ll i=2;i<=min(m,(ll)N);i++)
	{
		if (n%i==0)
		{
			printf("NO\n");
			return;
		}
	}
	printf("YES\n");
}

int main ()
{
		sol();
	return 0;
}