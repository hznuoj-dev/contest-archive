#include<bits/stdc++.h>

#define scanfint(a) scanf("%d",&a)
#define scanfstr(a) scanf("%s",a)
#define scanfll(a) scanf("%lld",&a)
#define scnafll(a) scanf("%lld",&a)
#define printfll(a) printf("%lld\n",a);
#define Get_rand(a) (rand()%(a+1))
#define swapnum(a,b) {a=a+b;b=a-b;a=a-b;}
#define FOR(i,l,r) for(int i=l;i<=r;i++)
#define FORLL(i,l,r) for(ll i=l;i<=r;i++)
#define Presentation(i,r) printf("%c"," \n"[i==r])
#define NO printf("NO\n")
#define YES printf("YES\n")
#define Max(a,b) (a>b?a:b)

typedef long long ll;

const double pi=3.141592653589793;
const ll MOD=1e9+7;
const int INF=0x7fffffff;
const double eps=1e-8;

using namespace std;
/*----------Cpp Head----------*/
ll GCD(ll a,ll b)
{
    return b==0?a:GCD(b,a%b);
}
ll cntp(ll x1,ll y1,ll x2,ll y2)
{
    ll difx=fabs(x1-x2),dify=fabs(y1-y2);
    ll gcd=GCD(difx,dify);
    return gcd+1;
}
int main()
{
    /*ll a,b,c,d;
    while(cin >> a >> b >> c >> d) printfll(cntp(a,b,c,d));*/
    ll p[105][2],x,n;
    scnafll(n);
    FORLL(i,0,n-1) scanf("%lld%lld",&p[i][0],&p[i][1]);
    ll m=3;
    ll cntx=0;
    FOR(i,0,n-3)
        FOR(j,i+1,n-2)
            FOR(k,j+1,n-1)
            {
                if((p[j][1]-p[i][1])*(p[k][0]-p[i][0])==(p[k][1]-p[i][1])*(p[j][0]-p[i][0])) continue;
                x=  cntp(p[i][0],p[i][1],p[j][0],p[j][1])+
                    cntp(p[k][0],p[k][1],p[j][0],p[j][1])+
                    cntp(p[i][0],p[i][1],p[k][0],p[k][1]);
                m=Max(m,x);
                //cntx++;
            }
    printfll(m-3);
    //printfll(cntx);
    return 0;
}