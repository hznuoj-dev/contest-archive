#include<iostream>
#include<math.h>
#include<algorithm>

#define min(x,y) x<y ? x:y

using namespace std;


int main(){

    long long int n, m;
    cin>>n>>m;
    if (m == 1 || n ==1)
    {
        cout<<"YES"<<endl;
        return 0 ;
    }
    else
    {
        if ((n % 2) == 0)
        {
            cout<<"NO"<<endl;
            return 0 ;
        }
        else
        {
            if (n <= m)
            {
                cout<<"NO"<<endl;
                return 0 ;            }
            long long int end = min(m, (int)sqrt(n)+1);
            for (long long int k = 3; k <=end; ++k)
            {
                if (n % k == 0)
                {
                    cout<<"NO"<<endl;
                    return 0 ;
                }
            }
            cout<<"YES"<<endl;
            return 0 ;
        }
    }
}

