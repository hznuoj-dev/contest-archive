#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
void solve() {
	string ss;
	cin >> ss;
	
	string s = "+$";
	for (auto c : ss){
		s = s + c + "$";
	}
	s = s + "-";
	int n = s.size();
	
	int ans = 0;
	for (int mid = 2; mid <= n - 1; mid ++ ){
		set<char> S;
		
		int len = 1, diff = 0, cnt = ('a' <= s[mid] && s[mid] <= 'z');
		while (mid - len >= 1 && mid + len <= n){
			if ('a' <= s[mid - len] && s[mid - len] <= 'z'){
				cnt ++ ;
			}
			if ('a' <= s[mid + len] && s[mid + len] <= 'z'){
				cnt ++ ;
			}
			if (s[mid - len] != s[mid + len]){
				S.insert(s[mid - len]);
				S.insert(s[mid + len]);
				diff ++ ;
			}
			if (diff == 0 || (diff == 2 && S.size() == 2)){
				ans = max(ans, cnt);
			}
			len ++ ;
		}
	}
	cout << (ans <= 1 ? 0 : ans) << "\n";
}
signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
//	freopen("1.in", "r", stdin);
	int Case = 1;
	cin >> Case;
	while (Case -- ) {
		solve();
	}
	return 0;
}