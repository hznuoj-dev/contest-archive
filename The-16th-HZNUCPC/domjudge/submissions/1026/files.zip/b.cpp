#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

#define int long long
typedef long long ll;

int f(array<int, 2> x, array<int, 2> y) {
	int a = x[0], b = x[1], c = y[0], d = y[1];
	if (c == a) {
		return abs(b - d + 1);
	}
	if (b == d) {
		return abs(a - c + 1);
	}
	ll g = __gcd(abs(d - b), abs(c - a));
	ll w = abs((c - a)) / g;
	if (a > c) swap(a, c);
//	printf("g = %d w = %d\n", g, w);
	return (c - a) / w + 1; 
}

void solve() {
	int n;
	cin >> n;
	
	vector<array<int, 2>> v(n + 1);
	for (int i = 1; i <= n; ++i) {
		cin >> v[i][0] >> v[i][1];
	}
	
	int ans = 0;
	for (int i = 1; i <= n; ++i) {
		for (int j = i + 1; j <= n; ++j) {
			for (int k = j + 1; k <= n; ++k) {
				if ((v[i][0] - v[j][0]) * (v[i][1] - v[k][1]) == (v[i][1] - v[j][1]) * (v[i][0] - v[k][0])) continue;
				ll t = 0;
				t = f(v[i], v[j]) + f(v[j], v[k]) + f(v[i], v[k]);
//				printf("i = %d j = %d k = %d ans = %d\n", i, j, k, t);
//				printf("x = %d y = %d z = %d\n", f(v[i], v[j]), f(v[j], v[k]), f(v[i], v[k]));
				ans = max(ans, t - 3);
			}
		}
	}
	cout << ans << '\n';
}

signed main() {	
	ios;
	int _ = 1;
	while(_--) solve();
}