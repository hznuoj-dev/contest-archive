#include<stdio.h>
int main(){
	long long n,m;
	scanf("%lld%lld",&n,&m);
	if(n%2==1){
		printf("YES\n");
	}
if(n%2==0){
		printf("NO\n");
	}
	return 0; 
}
/*#include<iostream>
using namespace
struct point{
	int x;
	int y;
};
int cishu(struct point p1,struct point p2,struct point p3){
	    if(p1.x>=p2.x&&p2.x>=p3.x) {
		int maxx=p1.x;
		int minx=p3.x;
		}
		if(p1.x>=p3.x&&p3.x>=p2.x) {
		int maxx=p1.x;
		int minx=p2.x;
		}
		if(p2.x>=p1.x&&p1.x>=p3.x) {
		int maxx=p2.x;
			int minx=p3.x;}
		if(p2.x>=p3.x&&p3.x>=p1.x) {
		int maxx=p2.x;
			int minx=p1.x;}
		if(p3.x>=p2.x&&p2.x>=p1.x) {
		int maxx=p3.x;
			int minx=p1.x;}
		if(p3.x>=p1.x&&p1.x>=p2.x) {
		int maxx=p3.x;
			int minx=p2.x;}
			
			 if(p1.y>=p2.y&&p2.y>=p3.y) {
		int maxy=p1.y;
		int miny=p3.y;
		}
		if(p1.y>=p3.y&&p3.y>=p2.y) {
		int maxy=p1.y;
		int miny=p2.y;
		}
		if(p2.y>=p1.y&&p1.y>=p3.y) {
		int maxy=p2.y;
			int miny=p3.y;}
		if(p2.y>=p3.y&&p3.y>=p1.y) {
		int maxy=p2.y;
			int minx=p1.y;}
		if(p3.y>=p2.y&&p2.y>=p1.y) {
		int maxy=p3.y;
			int miny=p1.y;}
		if(p3.y>=p1.y&&p1.y>=p2.y) {
		int maxy=p3.y;
			int minxy=p2.y;}
	int k1=(p1.y-p2.y)/(p1.x-p2.x);
	int b1=(p1.y-k1*p1.x);
	int k2=(p3.y-p2.y)/(p3.x-p2.x);
	int b2=(p3.y-k2*p3.x);
	int k3=(p3.y-p1.y)/(p3.x-p1.x);
	int b3=(p3.y-k3*p3.x);
	int sum=0;
	for(int i=minx;i<=maxx;i++){
		for(int j=miny;j=maxy;j++){
			if(j==k1*i+b1) sum++;
				if(j==k2*i+b2) sum++;
					if(j==k2*i+b2) sum++;
		}
	}
	return sum;
}
int main(){
	struct point p[101];
	int n;
	
	int sum;
	sum=(n*(n-1)*(n-2))/6;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>p[i].x>>p[i].y;
	}
	for(int i=0;i<sum;i++){
		for(int j=0;j<)
	}
}*/