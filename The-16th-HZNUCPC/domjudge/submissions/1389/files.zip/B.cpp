#include<bits/stdc++.h>

using namespace std;
int i;
bool Prime(long long a){
	long long x=sqrt(a);
	if(a<=1)return false;
	if(a==2)return true;
	for(i=2;i<=x;i++){
		if(a%i==0)return false;
	}
	return true;
}
bool f(long long a,long long b){
	bool F = Prime(a);
	if(a==1)return true;
	if(a>b)	if(b==1||Prime(a)||b<i)return true;
	return false;
}
signed main(){
	long long a,b;
	cin >> a >> b ;
	if(f(a,b))cout << "YES" << endl;
	else cout << "NO" << endl;
	return 0;
}