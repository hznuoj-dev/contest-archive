#include<iostream>
#include<math.h>
using namespace std;
#define int long long
int gcd(int x,int y)
{
	int z=x%y;
	while(z)
	{
		x=y;
		y=z;
		z=x%y;
	}
	return y;
}
signed main()
{
	int n,x[105],y[105],ans=0;
	cin>>n;
	for (int i=1;i<=n;i++)
		cin>>x[i]>>y[i];
	for (int i=1;i<=n;i++)
	{
		for (int j=i+1;j<=n;j++)
		{
			for (int k=j+1;k<=n;k++)
			{
				if (y[j]==y[i]&&y[k]==y[i])
				continue;
				else if (x[j]==x[i]&&x[k]==x[i])
				continue;
				else if (y[j]!=y[i]&&x[j]!=x[i]&&y[k]!=y[i]&&x[k]!=x[i])
				{
					int a=gcd(abs(y[j]-y[i]),abs(x[j]-x[i]));
				    int b=gcd(abs(y[k]-y[i]),abs(x[k]-x[i]));
		            if (abs(x[j]-x[i])/a==abs(x[k]-x[i])/b)
				    continue;
				}
				int c=0;
				if (y[j]==y[i])
				c+=abs(x[j]-x[i]);
				else if (x[j]==x[i])
				c+=abs(y[j]-y[i]);
				else
				c+=gcd(abs(y[j]-y[i]),abs(x[j]-x[i]));
				if (y[k]==y[j])
				c+=abs(x[k]-x[j]);
				else if (x[k]==x[j])
				c+=abs(y[k]-y[j]);
				else
				c+=gcd(abs(y[k]-y[j]),abs(x[k]-x[j]));
				if (y[i]==y[k])
				c+=abs(x[i]-x[k]);
				else if (x[i]==x[k])
				c+=abs(y[i]-y[k]);
				else
				c+=gcd(abs(y[i]-y[k]),abs(x[i]-x[k]));
				ans=max(ans,c);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}