#include<bits/stdc++.h>
using namespace std;

int len;
string s;
int ct[30],t[30],xt[30];

int ed(int l,int r,char a,char b)
{
    //printf("{%d %d}{%c %c}\n",l,r,a,b);
    int cd=r-l+1,ok=1;
    while(l-1>=0&&r+1<len)
    {
        if(s[l-1]==s[r+1]&&(xt[s[l-1]-'a']>=2))
        {
            --xt[s[l-1]-'a'];
            --xt[s[r+1]-'a'];
            cd+=2;
        }
        else if((s[l-1]==a&&s[r+1]==b)||(s[l-1]==a&&s[r+1]==b))
        {
            if(ok==0)break;
            ok=0;
            xt[b-'a']-=2;
            cd+=2;
        }
        else break;
        --l;
        ++r;
    }
    if(ok==1)return 0;
    return cd;
}
int ck(int l,int r)
{
    int cd=r-l+1;
    for(int i=0;i<26;++i)t[i]=ct[i];
    if(l==r)--t[s[l]-'a'];
    while(l-1>=0&&r+1<len)
    {
        if(s[l-1]==s[r+1])
        {
            --t[s[l-1]-'a'];
            --t[s[r+1]-'a'];
            cd+=2;
        }
        else
        {
            int mx=cd;
            if((t[s[l-1]-'a'])>=2)
            {
                for(int i=0;i<26;++i)
                {
                    xt[i]=t[i];
                }
                xt[s[l-1]-'a']-=2;
                mx=max(mx,ed(l-1,r+1,s[l-1],s[r+1]));
            }
            if((t[s[r+1]-'a'])>=2)
            {
                for(int i=0;i<26;++i)
                {
                    xt[i]=t[i];
                }
                xt[s[r+1]-'a']-=2;
                mx=max(mx,ed(l-1,r+1,s[r+1],s[l-1]));
            }
            return mx;
        }
        --l;
        ++r;
    }
    if(cd==1)return 0;
    return cd;
}

void sol()
{
    memset(ct,0,sizeof ct);
    cin>>s;
    len=s.size();
    for(int i=0;i<len;++i)
    {
        ++ct[s[i]-'a'];
    }
    int mx=0;
    for(int i=0;i<len;++i)
    {
        mx=max(mx,ck(i,i));
        if(i!=0)mx=max(mx,ck(i,i-1));
        //printf("%d:[%d]\n",i,mx);
    }
    if(mx==1)mx=0;
    printf("%d\n",mx);
}

int main()
{
    int t=1;
    scanf("%d",&t);
    while(t--) sol();
    return 0;
}
