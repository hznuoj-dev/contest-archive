#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const ll mod = 1e9+7;
const ll N = 1e6+10;

bitset<100001> bs,add,tmp;
int pa[N],siz[N];
int find(int a){
    return pa[a]==a?a:pa[a] = find(pa[a]);
}

void merge(int a,int b){
    a = find(a),b = find(b);
    if(a==b) return;
    siz[b] += siz[a];
    pa[a] = b;
}
int op[N],x[N],y[N];
vector<int> g[N];
struct xuan{
    int num;
    int batch;
};
vector<xuan> vx;
int color[N];
int c1,c2;
int ok;
vector<int> buffer;
int rtbatch[N];
void dfs(int u,int col,int batch){
    if(col==1) c1+=siz[u];
    else c2+=siz[u];
    rtbatch[u] = batch;
    buffer.push_back(u);
    color[u] = col;
    for(auto x:g[u]){
        if(!color[x]){
            dfs(x,3-col,batch);
        }else if(color[x]==color[u]){
            ok = 0;
        }
    }
}

vector<int> b1[N],b2[N];
int xl[N];
int last[N];

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);

    int n,q,m;
    cin>>n>>q>>m;
    for(int i=1;i<=n;i++) pa[i] = i,siz[i] = 1;
    for(int i=1;i<=m;i++){
        cin>>op[i]>>x[i]>>y[i];
    }
    for(int i=1;i<=m;i++){
        if(op[i]==0) merge(x[i],y[i]);
    }
    for(int i=1;i<=m;i++){
        if(op[i]==1) {
            int xx = find(x[i]);
            int yy = find(y[i]);
            g[xx].push_back(yy);
            g[yy].push_back(xx);
        }
    }
    int bcnt = 0;
    //cout<<"rt ";
    for(int i=1;i<=n;i++){
        if(find(i)!=i) continue;
        if(color[i]) continue;
        bcnt++;
        //cout<<i<<' ';
        c1 = c2 = 0;
        buffer.clear();
        ok = 1;
        dfs(i,1,bcnt);
        if(!ok){
            cout<<"NO"<<endl;
            return 0;
        }
        if(c1>c2){
            swap(c1,c2);
            for(auto x:buffer){
                color[x] = 3-color[x];
            }
        }
        q -= c1;
        vx.push_back({c2-c1,bcnt});
    }
    //cout<<endl;
    for(int i=1;i<=n;i++){
        int bt = rtbatch[find(i)];
        if(color[find(i)]==1) b1[bt].push_back(i);
        else b2[bt].push_back(i);
    }
    if(q<0){
        cout<<"NO"<<endl;
        return 0;
    }
    //cout<<"aaaa"<<endl;
    bs.set(0);
    last[0] = -1;
    for(int i=0;i<vx.size();i++){
        if(vx[i].num==0) continue;
        tmp =(bs|(bs<<vx[i].num));
        add = (tmp^bs);
        for(int j = add._Find_first();j!=add.size();j=add._Find_next(j)){
            last[j] = vx[i].batch;
        }
        bs = tmp;
    }
    if(!bs[q]){
        cout<<"NO"<<endl;
        return 0;
    }
    //cout<<"q "<<q<<endl;
    //cout<<"vx "<<endl;
    //for(auto x:vx){
    //    cout<<x.num<<' '<<x.batch<<endl;
    //}
    //cout<<"last ";
    //for(int i=0;i<=q;i++) cout<<last[i]<<' ';
   // cout<<endl;
    while(last[q]!=-1){
        //cout<<"q lastq "<<q<<' '<<last[q]<<endl;
        //cout<<"vx[last[q]].num "<<vx[last[q]].num<<endl;
        xl[last[q]] = 1;
        q -= vx[last[q]-1].num;
    }
    //cout<<"bbbb"<<endl;
    vector<int> ans;
    for(int i=1;i<=bcnt;i++){
        if(xl[i]){
            for(auto x:b2[i]) ans.push_back(x);
        }else {
            for(auto x:b1[i]) ans.push_back(x);
        }
    }
    sort(ans.begin(),ans.end());
    cout<<"YES"<<endl;
    for(auto x:ans){
        cout<<x<<' ';
    }

}
/*
13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13
*/
