#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define debug(x) cerr<<#x<<" "<<x<<"\n"

void _solve(){
    ll n,m;cin>>n>>m;
    if(m==1||n==1) cout<<"YES\n";
    else{
        if(n%2==0) cout<<"NO\n";
        else{
            vector<ll>vec;
            for(ll i=2;i*i<=n;i++){
                if(n%i==0){
                    vec.push_back(i);
                }
            }
            vec.push_back(n);
            for(auto p:vec){
                if(p<=m){
                    cout<<"NO\n";
                    return;
                }
            }
            cout<<"YES\n";
        }
    }
}

int main(){
    ios::sync_with_stdio(false);

//    int T;cin>>T;while(T--)
    _solve();
}
