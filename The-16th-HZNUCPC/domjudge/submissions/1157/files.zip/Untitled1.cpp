#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int haxi[19][19];
int main()
{
	ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n;
    cin>>n;
    while(n--)
    {
    	int nn;
    	cin>>nn;
    	for (int i=0;i<=18;i++)
		{
			for (int j=0;j<=18;j++)
			{
				haxi[i][j]=0;
			}
		}
    	while(nn--)
    	{
    		int x,y,shu;
    		cin >>x>>y>>shu;
    		haxi[x][y]=shu;
    		if (shu==1)
    		{
    			if (x>0&& haxi[x-1][y]==0)
    			{
    				haxi[x-1][y]=3;
				}
				if (x<=18&& haxi[x+1][y]==0)
    			{
    			haxi[x+1][y]=3;
				}
				if (y>0&& haxi[x][y-1]==0)
    			{
    				haxi[x][y-1]=3;
				}
				if (y<=18 && haxi[x][y+1]==0)
    			{
    				haxi[x][y+1]=3;
				}
			}
		}
		int ans=0;
		for (int i=0;i<=18;i++)
		{
			for (int j=0;j<=18;j++)
			{
				if (haxi[i][j]==3)
				{	
					ans++;
				}
			}
		}
		cout <<ans<<endl;
	}
    return 0;
}