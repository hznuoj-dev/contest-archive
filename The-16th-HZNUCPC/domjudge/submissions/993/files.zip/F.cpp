#include <bits/stdc++.h>
#define int long long
using namespace std;

int n, m;
typedef pair<int,int> PII;
PII a[110];

signed main()
{
	ios::sync_with_stdio(0);
	
	cin.tie(0);
	cin >> n >> m;
	
	if(m == 1) {
		cout << "YES" << endl;
		return 0;
	}
	if(n <= m) {
		cout << "NO" << endl;
		return 0;
	}
	
	bool ok = 0;
	for(int i = 2 ; i <= sqrt(n) ; i ++) {
		if(n % i == 0) {
			ok = 1;
			if(i > m) cout << "YES" << endl;
			else cout << "NO" << endl;
			break;
		}
	}
	if(!ok) {
		if(n == m) cout << "NO" << endl;
		else cout << "YES" << endl;
	}
}