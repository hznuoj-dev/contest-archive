#include<bits/stdc++.h>
#define int long long
using namespace std;

int n,m;
bool check(int x){
	for(int i=2;i<=sqrt(x);i++){
		if(x%i==0){
			return false;
		}
	}
	return true;
}
void solve(){
	int k;
	while(cin >> n >> m){
		int f = 1;
		if(n==1||m==1){
			cout << "YES" << endl;
			continue;
		}
		if(m >= n)f = 0;
		int d = sqrt(n);
		m = min(d,m);
		for(int i = 2 ; i <= m ; i ++){
			if(n % i == 0 || f == 0){
				f = 0;
				break;
			}
		}
		if(f)cout << "YES" <<endl;
		else cout << "NO" << endl;
	}
	
}

signed main(){
//	int T;cin >> T;while(T--){
		solve();
//	}
	return 0;
}