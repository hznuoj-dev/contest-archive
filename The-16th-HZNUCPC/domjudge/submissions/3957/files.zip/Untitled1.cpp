#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdio>
#include<queue>
#include<map>
#include<vector>
#define int long long
#define FOR(i,m,n) for(int i = m;i <= n;i++)
#define CLR(arr,value) memset(arr,value,sizeof arr)
using namespace std;
const int N = 0x3f3f3f;
int tt,n,k;
int cnt = 0;
bool f;

void dfs(int k){
	if(n%k == 1 || n % k == 0){
		if(n % k == 1)puts("YES");
		else puts("NO");
		return;
	}
	dfs(n%k);
}

signed main()
{
	while(cin >> n >> k)
	{
		if(n == 1 || k == 1)
		{
			puts("YES");
			continue;
		}
		if(k >= n){puts("NO");continue;}
		dfs(k);
	}
}