#include<bits/stdc++.h>

using namespace std;
#define int long long 
#define eb emplace_back
#define pii pair<int, int> 
#define pcc pair<char, char> 
#define endl '\n'
int dr[4] = {1, 0, -1, 0};
int dc[4] = {0, 1, 0, -1};

void run() {
	string s;
	cin >> s;
	string str;
	for (auto x : s) {
		str.push_back('#');
		str.push_back(x);
	}
	str.push_back('#');
	int n = str.size();
	str = "_" + str;
//	cout << str << endl;
	int ans = 0;
	for (int mid = 2; mid < n; mid++) {
		pii rem = pii(-1, -1);
		int ok = 0;
		int flag = 1;
		for (int i = 1; mid + i <= n && mid - i > 0; i++) {
			if (str[mid - i] == str[mid + i]) {
				if (rem == pii(-1, -1) || flag == 0 || ok) {
					ans = max(ans, mid + i - (mid - i) + 1);
//					if (mid == 7) cout << mid - i << ' ' << mid + i << endl;
				}
			} else {
				if (rem == pii(-1, -1)) {
					rem = pii(str[mid - i], str[mid + i]);
					if (str[mid - i] == str[mid] || str[mid + i] == str[mid]) {
						ok = 1;
						ans = max(ans, mid + i - (mid - i) + 1);
//						if (mid == 7) cout << mid - i << ' ' << mid + i << endl;
					}
				} else if (flag == 1) {
					if (rem == pii(str[mid - i], str[mid + i]) || rem == pii(str[mid + i], str[mid - i])) {
						flag = 0;
						ans = max(ans, mid + i - (mid - i) + 1);
//						if (mid == 7) cout << mid - i << ' ' << mid + i << endl;
					} else break;
				} else break;
			}
		}
	}
	
	ans = (ans) / 2;
	if (ans == 1) ans = 0;
	cout << ans << endl;

	


	return;
}
/*
4
abccab
ihi
stfgfiut
palindrome


*/
signed main() {
	ios::sync_with_stdio(false); cin.tie(nullptr); cout.tie(nullptr);
	int T = 1;
	cin >> T;
	while (T--) {
		run();
	}



	return 0;
}