#include <bits/stdc++.h>
#define N (int)1e5+10
#define dwan ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define int long long
typedef long long ll;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int mp[22][22];
void solve(){
	for(int i=0;i<21;i++){
		for(int j=0;j<21;j++){
			mp[i][j]=0;
		}
	}
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		int x,y,color;
		cin>>x>>y>>color;
		mp[x][y]=color;
	}
	int cnt=0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(mp[i][j]==1){
				//left
				if(i-1>0){
					if(mp[i-1][j]==0){
						cnt++;
					}
				}
				//up
				if(j+1<=19){
					if(mp[i][j+1]==0){
						cnt++;	
					}
				}
				//down
				if(j-1>0){
					if(mp[i][j-1]==0){
						cnt++;	
					}
				}
				//right
				if(i+1<=19){
					if(mp[i+1][j]==0){
						cnt++;
					}
				}
			}
		}
	}
	cout<<cnt<<endl;
}
signed main(int argc, char** argv) {
	dwan;
	int t;
	cin>>t;
	while(t--){
		solve();
	}
}