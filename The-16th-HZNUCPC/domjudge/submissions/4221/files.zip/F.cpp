#include<bits/stdc++.h>
using namespace std;
const int N=110;
struct dian {
	int x;
	int y;
}a[105];
int gcd(int a,int b){
	if(a==0||b==0)return 1;
	while(a%b!=0){
		int t;
		t=a%b;
		a=b;
		b=t;
	}
	return b;
}
int zhaodian(int x1,int y1,int x2,int y2,int x3,int y3){
	int k1=x1/(gcd(abs(y1-y2),abs(x1-x2))),k2=x2/(gcd(abs(y2-y3),abs(x2-x3))),k3=x3/(gcd(abs(y3-y1),abs(x3-x1)));
	int sum=0;
	k1=(abs(x1-x2)-1)/k1;
	k2=(abs(x2-x3)-1)/k2;
	k3=(abs(x3-x1)-1)/k3;
	if(x1==x2)k1=abs(y1-y2)-1;
	if(x2==x3)k2=abs(y2-y3)-1;
	if(x3==x1)k3=abs(y3-y1)-1;
	if(y1==y2)k1=abs(x1-x2)-1;
	if(y2==y3)k2=abs(x2-x3)-1;
	if(y3==y1)k3=abs(x3-x1)-1;
	sum=k1+k2+k3+3;
	return sum;
}
int main(){
	int n,ans=0;
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i].x>>a[i].y;
	for(int i=1;i<=n;i++){
		for(int j=1+i;j<=n;j++){
			for(int k=1+j;k<=n;k++){
				ans=max(ans,zhaodian(a[i].x,a[i].y,a[j].x,a[j].y,a[k].x,a[k].y));
			}
		}
	}
	cout<<ans;	
}