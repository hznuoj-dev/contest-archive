#include <bits/stdc++.h>
using namespace std;
using ll = long long;

int main (){
    ll a, b;
    cin >> a >> b;
    if (a == 1 || b == 1){
        cout << "YES" <<endl;
        return 0;
    }
    if (a <= b || a % b == 0){
        cout << "NO" << endl;
    }
    else {
        ll t = b;
        while (1){
            b = a % b;
            if (a % b == 0) break;
        }
        if (b == 1){
            cout << "YES" << endl;
        }
        else cout << "NO" <<endl;
    }

}

