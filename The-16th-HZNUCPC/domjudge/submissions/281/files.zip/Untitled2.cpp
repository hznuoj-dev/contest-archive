#include<bits/stdc++.h>
using namespace std;
int a[30][30];
int b[30][30];
int fx[4][2] = {{0, -1}, {0, 1}, {-1, 0}, {1, 0}};
void solve(){
	int n;
	cin >> n;
	memset(a, 0, sizeof(a));
	memset(b, 0, sizeof(b));
	for(int i = 0; i < n; i++){
		int x, y, c;
		cin >> x >> y >> a[x][y];
		for(int j = 0; j < 4; j++){
			int xx = x + fx[j][0];
			int yy = y + fx[j][1];
			if(b[x][y]){
				b[x][y] = 0;		
			}
			if(a[x][y] == 1){
				
				if(a[xx][yy] != 1 && a[xx][yy] != 2)
					b[xx][yy]++;
			}else{
				if(a[xx][yy] != 1 && a[xx][yy] != 2)
					b[xx][yy]=0;
			}
		}
	}
	int ans = 0;
	for(int i = 1; i <= 19; i++){
		for(int j = 1; j <= 19; j++){
			if(b[i][j]){
				ans += b[i][j];
			}
		}
	}
	cout << ans << "\n";
}
int main(){
	int t = 1;
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}