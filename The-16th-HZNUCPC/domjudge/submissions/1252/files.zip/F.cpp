#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>

using namespace std;

typedef long long LL;


int main()
{
	LL n, m;
	cin >> n >> m;
	
	
	
	if(m == 1 || n < m) cout << "YES" << endl;
	if(n % m == 0) cout << "NO" << endl; 
	else cout << "YES" << endl;
	
	return 0;
}
