#include<iostream>
#include<string>
#include<vector>
#include<map>

using namespace std;

int n, t, x, y;
string str;

void run() {
	cin >> str;
	int len = str.length();
	str = " " + str;
	int maxans = 0;
	// --------- odd -------------
	for (int i = 1; i <= len; i++) {
		int ans = 0;
		vector<pair<char,char> > pr;
		int l = i, r = i, cnt = 0;
		char a, b, c = str[i];
		while (l >= 1 && r <= len) {
			if (str[l] != str[r]) {
				pr.push_back(make_pair(str[l], str[r]));
			}
			if (pr.size() >= 3) break; 
			l--; r++; cnt++;
		}
		if (pr.size() == 1) {
			if (pr[0].first == c || pr[0].second == c) {
				while (l >= 1 && r <= len) {
					if (str[l] == str[r]) {
						l--; r++; cnt++;
					} else {
						break;
					}
				}
				ans = max(ans, cnt * 2 + 1);
			}
			else {
				l = i - 1, r = i, cnt = 1;
				if (str[l] != str[r]) ans = max(ans, 0);
				while (l >= 1 && r <= len) {
					if (str[l] == str[r]) {
						l--; r++; cnt++;
					} else {
						break;
					}
				}
			}
			ans = max(ans, cnt * 2 + 1);
		}
		else if (pr.size() == 2) {
			int a1 = pr[0].first, a2 = pr[0].second, b1 = pr[1].first, b2 = pr[1].second;
			if ((a1 == b1 && a2 == b2) || (a1 == b2 && a2 == b1)) {
				while (l >= 1 && r <= len) {
					if (str[l] == str[r]) {
						l--; r++; cnt++;
					} else {
						break;
					}
				}
				ans = max(ans, cnt * 2 + 1);
			} else {
				if (pr[0].first == c || pr[1].second == c) {
					while (l >= 1 && r <= len) {
						if (str[l] == str[r]) {
							l--; r++; cnt++;
						} else {
							break;
						}
					}
					ans = max(ans, cnt * 2 + 1);
				} else {
					l = i - 1, r = i, cnt = 1;
					if (str[l] != str[r]) ans = max(ans, 0);
					while (l >= 1 && r <= len) {
						if (str[l] == str[r]) {
							l--; r++; cnt++;
						} else {
							break;
						}
					}
				}
				ans = max(ans, cnt * 2 + 1);
			}
		} else if (pr.size() == 3) {
			l = i - 1, r = i, cnt = 1;
			if (str[l] != str[r]) ans = max(ans, 0);
			while (l >= 1 && r <= len) {
				if (str[l] == str[r]) {
					l--; r++; cnt++;
				} else {
					break;
				}
			}
			ans = max(ans, cnt * 2 + 1);
		} else {
			while (l >= 1 && r <= len) {
				if (str[l] == str[r]) {
					l--; r++; cnt++;
				} else {
					break;
				}
			}
			ans = max(ans, cnt * 2 + 1);
		}
		maxans = max(ans, maxans);
	}
	
	cout << maxans << '\n';
	maxans = 0;
	
	
	// --------- even ------------
	for (int i = 2; i <= len; i++) {
		int ans = 0;
		vector<pair<char,char> > pr;
		int l = i - 1, r = i, cnt = 1;
		if (str[l] != str[r]) {
			pr.push_back(make_pair(l,r));
		}
		char a, b;
		while (l >= 1 && r <= len) {
			if (str[l] != str[r]) {
				pr.push_back(make_pair(str[l], str[r]));
			}
			if (pr.size() >= 2) break; 
			l--; r++; cnt++;
		}
		if (pr.size() == 1) {
			l = i - 1, r = i, cnt = 1;
			if (str[l] != str[r]) ans = max(ans, 0);
			while (l >= 1 && r <= len) {
				if (str[l] == str[r]) {
					l--; r++; cnt++;
				} else {
					break;
				}
			}
			ans = max(ans, cnt * 2);
		}
		else if (pr.size() == 2) {
			int a1 = pr[0].first, a2 = pr[0].second, b1 = pr[1].first, b2 = pr[1].second;
			if ((a1 == b1 && a2 == b2) || (a1 == b2 && a2 == b1)) {
				while (l >= 1 && r <= len) {
					if (str[l] == str[r]) {
						l--; r++; cnt++;
					} else {
						break;
					}
				}
				ans = max(ans, cnt * 2);
			} else {
				l = i - 1, r = i, cnt = 1;
				if (str[l] != str[r]) ans = max(ans, 0);
				while (l >= 1 && r <= len) {
					if (str[l] == str[r]) {
						l--; r++; cnt++;
					} else {
						break;
					}
				}
				ans = max(ans, cnt * 2);
			}
		} else {
			while (l >= 1 && r <= len) {
				if (str[l] == str[r]) {
					l--; r++; cnt++;
				} else {
					break;
				}
			}
			ans = max(ans, cnt * 2);
		}
		maxans = max(ans, maxans);
	}
	
	
	cout << maxans << '\n';
}

int main () {
	cin >> t;
	while (t--) {
		run();
	}
	return 0;
}