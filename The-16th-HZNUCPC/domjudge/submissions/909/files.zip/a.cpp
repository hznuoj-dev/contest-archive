// #define DEBUG
#include <bits/stdc++.h>


using namespace std;
#define int long long
#define endl '\n'
void solve() {
    int n, m;
    cin >> n >> m;
    if (m == 1 || n == 1) {
        cout << "YES\n";
        return ;
    }
    for (int i = 2; i * i <= n && i <= m; i ++ ) {
        if (n % i == 0) {
            cout << "NO\n";
            return ;
        }
    }
    cout << "YES\n";
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    // cin >> T;
    // while (T--)
    {solve(); }
#ifdef DEBUG
    cerr << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}