#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::synbc_with_stdio(flase);cin.tie(0);cout.tie(0)
int dir[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
int s[25][25];
int vis[25][25];
void solve(){

	int t;cin>>t;
	while(t--){
		int n;
		cin>>n;
		int sum=0;
		memset(vis,0,sizeof vis);
		while(n--){
			int x,y,l;
			cin>>x>>y>>l;
			if(l==2){
				if(vis[x][y]==0){
					vis[x][y]=2;
				}
				else if(vis[x][y]==1){
					vis[x][y]=2;
					sum--;
				}
			}
			else{
				if(vis[x][y]==0){
					vis[x][y]=2;
				}
				else if(vis[x][y]==1){
					vis[x][y]=2;
					sum--;
				}
				for(int i=0;i<4;i++){
					int tx=x+dir[i][0];
					int ty=y+dir[i][1];
					if(tx>=1&&tx<=19&&ty>=1&&ty<=19){
						if(vis[tx][ty]!=2){
//							cout<<tx<<" "<<ty<<endl;
							sum++;
							vis[tx][ty]=1;
						}
					}
				}
			}
		}
		cout<<sum<<endl;
	}
}
signed main(){
//	IOS;
	solve();
	return 0;
}