#include<bits/stdc++.h>

#define scanfint(a) scanf("%d",&a)
#define scanfstr(a) scanf("%s",a)
#define scanfll(a) scanf("%lld",&a)
#define scnafll(a) scanf("%lld",&a)
#define Get_rand(a) (rand()%(a+1))
#define swapnum(a,b) {a=a+b;b=a-b;a=a-b;}
#define FOR(i,l,r) for(int i=l;i<=r;i++)
#define FORLL(i,l,r) for(ll i=l;i<=r;i++)
#define Presentation(i,r) printf("%c"," \n"[i==r])
#define NO printf("NO\n")
#define YES printf("YES\n")

typedef long long ll;

const double pi=3.141592653589793;
const ll MOD=1e9+7;
const int INF=0x7fffffff;
const double eps=1e-8;

using namespace std;
/*----------Cpp Head----------*/
int Min_Pri(ll a)
{
    for(ll i=2;i*i<a;i++) if(a%i==0) return i;
    return 1;
}
int main()
{
    ll n,m;
    scanfll(n);scanfll(m);
    if(m>=n) {NO;}
    else if(n==1||m==1||Min_Pri(n)>m||Min_Pri(n)==1) YES;
    else NO;
    return 0;
}