#include <bits/stdc++.h>

std::string a, b;
std::map<int, int> ma, mb;
const int mod = 1e9 + 7;

int n;

int cnt[26][26];

void modify(int f ,int k, int v) {
	if (f == 0) {
		ma[k] += v;
		//std::cout << k << " " << v << " " << ma[k] << "\n";
		//if (ma[k] < 0) std::cout << k << "???????\n";
		if (ma[k] == 0) ma.erase(k);
	}
	else {
		mb[k] += v;
		//if (mb[k] < 0) std::cout << k << "???????\n";
		if (mb[k] == 0) mb.erase(k);
	}
}

int main () {
	std::cin >> a >> b;
	n = a.size();
	for (int i = 0; i < n; i++) {
		ma[a[i] - 'a']++;
		mb[b[i] - 'a']++;
		cnt[a[i] - 'a'][b[i] - 'a']++;
	}
	long long ans = 0;
	for (int i = 0; i < 26; i++) {
		for (int j = 0; j < 26; j++) {
			for (int k = 0; k < 26; k++) {
				for (int l = 0; l < 26; l++) {
					if (i != k || j != l) {
						if (!cnt[i][j] || !cnt[k][l]) continue;
					}
					else{
						if (cnt[i][j] < 2) continue;
					}
					
					modify(0, i, -1);
					modify(1, i, 1);
					modify(0, j, 1);
					modify(1, j, -1);
					
					modify(0, k, -1);
					modify(1, k, 1);
					modify(0, l, 1);
					modify(1, l, -1);
					
					//std::cout << i << " " << j << " " << k << " " << l << "\n";
					//std::cout << ma.size() << " " << mb.size() << "\n";
//					for (auto it : ma) {
//						std::cout << it.first << "\n";
//					}
//					for (auto it : mb) {
//						std::cout << it.first << "\n";
//					}
					if (ma.size() == mb.size()) {
						if (i != k || j != l) {
							ans += 1ll * cnt[i][j] * cnt[k][l];
						}
						else {
							ans += 1ll * cnt[i][j] * (cnt[i][j] - 1);
						}
					}
					
					modify(0, i, 1);
					modify(1, i, -1);
					modify(0, j, -1);
					modify(1, j, 1);
					
					modify(0, k, 1);
					modify(1, k, -1);
					modify(0, l, -1);
					modify(1, l, 1);
				}
			}
		}
	}
	ans /= 2;
	ans %= mod;
	std::cout << ans << "\n";
}
