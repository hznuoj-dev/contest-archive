for _ in range(int(input())):
	s = input()

	temp = len(s)
	res = 0
	for i in range(temp-1):
		num = 0
		list1 = []
		dict1 = {}
		dict1[s[i]] = 1
		if s[i+1] == s[i]:
			dict1[s[i]] += 1
		else:
			dict1[s[i+1]] = 1
			num += 1
			list1.append(sorted([s[i],s[i+1]]))
		if dict1[s[i]] == 2:
			res = max(res,2)
		for k in range(1,min(i,temp-i-1)+1):
			f = 0
			tt1 = s[i-k]
			if i + 1 + k <= temp-1:
				tt2 = s[i+1+k]
			else:
				break
			if tt1 != tt2:
				num +=1
				list1.append(sorted([tt1,tt2]))
			if num > 2:
				break
			elif num==2:
				if list1[0] == list1[1]:
					f = 1
				else:
					break
			elif num == 0:
				f  =1
			if tt1 not in dict1:
				dict1[tt1] = 1
			else:
				dict1[tt1] +=1
			if tt2 not in dict1:
				dict1[tt2] = 1
			else:
				dict1[tt2] +=1
			for j in dict1:
				if dict1[j] % 2 == 1:
					f = 0
					break
				
			if f:
				res = max(res,2 + k * 2)
	for i in range(temp):
		num = 0
		list1 = []
		dict1 = {}
		dict1[s[i]] = 1
		for k in range(1,min(i,temp-i-1)+1):
			f = 0
			tt1 = s[i-k]
			if i + k <= temp-1:
				tt2 = s[i+k]
			else:
				break
			if tt1 != tt2:
				num +=1
				list1.append(sorted([tt1,tt2]))
			if num > 2:
				break
			elif num==2:

				if list1[0] == list1[1]:
					f = 1
				else:
					break
			elif num == 0:
				f  =1
			if tt1 not in dict1:
				dict1[tt1] = 1
			else:
				dict1[tt1] +=1
			if tt2 not in dict1:
				dict1[tt2] = 1
			else:
				dict1[tt2] +=1

			for j in dict1:
				if dict1[j] % 2 == 1 and j != s[i] or j == s[i] and dict1[j] % 2 == 0:
					f = 0
					break
	
				
			if f:
				res = max(res,1 + k * 2)
	print(res)
			




