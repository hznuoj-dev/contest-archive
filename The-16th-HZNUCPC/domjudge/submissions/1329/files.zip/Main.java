
import java.io.*;
import java.util.*;
import java.math.*;
public class Main {
  public static void main(String[] args){
	  InputStream inputStream = System.in;
	  OutputStream outputStream = System.out;
	  InputReader in = new InputReader(inputStream);
	  PrintWriter out = new PrintWriter(outputStream);
	  TaskA solver = new TaskA();
	  solver.solve(1,in,out);
	  out.close();
  }
  
  static class TaskA{
	  boolean check(int x,int y){
		  if(x > 0 && x < 20 && y > 0 && y < 20)
			  return true;
		  return false;
	  }
	  public void solve(int testNumber,InputReader in,PrintWriter out){
		  int t = in.nextInt();
		  while(t-- > 0){
			  int n = in.nextInt();
			  Set<A> set = new HashSet();
			  int[][] a = new int [20][20];
			  for(int i = 0;i < n;i++){
				  int x = in.nextInt();
				  int y = in.nextInt();
				  a[x][y] = in.nextInt();
				  if(a[x][y]==1)
					  set.add(new A(x,y));
			  }
			  int count = 0;
			  for(A b:set){
				  int x = b.x;
				  int y = b.y;
				  if(check(x-1,y) && a[x-1][y] != 1){
					  count++;
					  a[x-1][y] = 2;
				  }
				  if(check(x+1,y) && a[x+1][y] != 1){
					  count++;
					  a[x+1][y] = 2;
				  }
				  if(check(x,y-1) && a[x][y-1] != 1){
					  count++;
					  a[x][y-1] = 2;
				  }
				  if(check(x,y+1) && a[x][y+1] != 1){
					  count++;
					  a[x][y+1] = 2;
				  }
			  }
			  out.println(count);
		  }
	  }
	  class A{
		  int x,y;
		  A(int x,int y){
			  this.x = x;
			  this.y = y;
		  }
	  }
  }
  
  static class InputReader{
	  public BufferedReader reader;
	  public StringTokenizer tokenizer;
	  public InputReader(InputStream stream){
		  reader = new BufferedReader(new InputStreamReader(stream),32768);
		  tokenizer = null;
	  }
	  boolean hasNext()
	  {
		 while(tokenizer == null || !tokenizer.hasMoreTokens())
		 {
			 try
			 {
				 tokenizer = new StringTokenizer(reader.readLine());
			 }catch(Exception e)
			 {
				 return false;
			 }
		 }
		 return true;
	  }
	  public String next(){
		  while(tokenizer == null || !tokenizer.hasMoreTokens()){
			  try{
				  tokenizer = new StringTokenizer(reader.readLine());
			  }catch(IOException e){
				  throw new RuntimeException(e);
			  }
		  }
		  return tokenizer.nextToken();
	  }
	  public String nextLine()
	  {
		  String str = null;
		  try
		  {
			  str = reader.readLine();
		  }catch(IOException e){
			  e.printStackTrace();
		  }
		  return str;
	  }
	  public int nextInt(){
		  return Integer.parseInt(next());
	  }
	  public double nextDouble(){
		  return Double.parseDouble(next());
	  }
	  public long nextLong(){
		  return Long.parseLong(next());
	  }
	  public BigInteger nextBigInteger(){
		  return new BigInteger(next());
	  }
	  public BigDecimal nextBigDecimal(){
		  return new BigDecimal(next());
	  }
  }
}
