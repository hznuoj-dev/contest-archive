#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
#include<unordered_map>
#include<cstring>
#include<cmath>
#include<set>

using namespace std;
const int N=110;
typedef long long ll;
const double eps=1e-9;

int x[N],y[N];
int n;

void solve()
{
	
}

int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&x[i],&y[i]);
	}
	ll ans=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			for(int k=1;k<=n;k++)
			{
				if(i==j || j==k || i==k)
				{
					continue;
				}
				if(y[i] == y[j] && y[j] == y[k] && y[k] == y[i])
					continue;
				double x1,y1,z1;
				x1 = abs((x[i] - x[j])/(y[i] - y[j]));
				y1 = abs((x[j] - x[k])/(y[j] - y[k]));
				z1 = abs((x[k] - x[i])/(y[k] - y[i]));
				if(x1==y1 && x1==y1 && x1==z1)
				{
					continue;
				}
				ll ans1=1LL*min(abs(x[i]-x[j]),abs(y[i]-y[j]))+1;
				ll ans2=1LL*min(abs(x[i]-x[k]),abs(y[i]-y[k]))+1;
				ll ans3=1LL*min(abs(x[k]-x[j]),abs(y[k]-y[j]))+1;
				ans=max(ans,ans1 + ans2 + ans3);
//				cout <<"ans = " << ans << endl;
			}
		}
	}
	printf("%lld\n",ans-3);
	
	return 0;
}