#include <iostream>
using namespace std;
int f[21][21],i,j,x,y,c,t,n,ans;
int main() {
	cin >> t;
	while (t-- > 0) {
		for (i = 1;i < 21;i++)
		for (j = 1;j < 21;j++)
		f[i][j]= 0;
		ans = 0;
		for(i=0;i<21;i++){
		f[i][0]=3;
			f[0][i]=3;
			f[i][20]=3;
			f[20][i]=3;
	}
		
		cin >> n;
		while(n-- > 0) {
			cin >> x >> y>> c;
			f[x][y] = c;
		}
		for (i = 1;i < 20;i++ ) {
			for (j = 1;j < 20;j++ ) {
				if (f[i][j] == 1) {
					if(f[i - 1][j] == 0) ans++;
					if(f[i + 1][j] == 0) ans++;
					if(f[i][j - 1] == 0) ans++;
					if(f[i][j + 1] == 0) ans++;
				}
			}
		}
		cout << ans << endl;
		
	}
}
