#include "iostream"
using namespace std;
long long a,b,c,d,e,f;
int main(){
	while(cin>>a>>b){
		long long k=b;
		e=0;
		
		while(k!=1){
			c=a%k;\
			if(c==0){
				break;
			}
			k=c;
		}
		if(k==1){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
	
}
	return 0;
}