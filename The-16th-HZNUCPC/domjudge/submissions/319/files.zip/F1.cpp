#include<bits/stdc++.h>
using namespace std;

int main()
{
	long long n,m;
	cin>>n>>m;
	if(n<=m){
		cout<<"NO\n";
		return 0;
	}
	for(int i = 2;i < (int)sqrt(n)+1;i++){
		if(n%i==0){
			int j=n/i;
			if(i>=2 && i<= m){
				cout<<"NO\n";
				return 0;
			}		
			if(j>=2 && j<= m){
				cout<<"NO\n";
				return 0;
			}
		}
	}
	cout<<"YES\n";
	return 0;
}