#include <bits/stdc++.h>

using namespace std;
using ll=long long;

struct EDGES{
	int from,to,w;
}es[ 1005 ];
int estot;
int fa[ 1005 ];
int find_fa( int x ){
	while( x != fa[ x ] ) x = fa[ x ] = fa[ fa[ x ] ];
	return x;
}
bool cmp( EDGES x , EDGES y ){
	return x.w < y.w;
}
int main(){
	int n , m;std::cin>>n>>m;
	for( int i = 1 ; i <= n ; i ++ ) fa[ i ] = i;
	for( int i = 1 ; i <= m ; i ++ ){
		std::cin>>es[ ++estot ].from>>es[ estot ].to>>es[ estot ].w;
	}
	
	std::sort( es + 1 , es + 1 + m , cmp );
	
	int cnt = 0;
	std::map< int , int > mp;
	int round = 0;
	while( cnt != n - 1 ){
		++round;
			for( int i = 1 ; i <= estot ; i ++ ){
			int x = es[ i ].from , y = es[ i ].to;
			int fx = find_fa( x ) , fy = find_fa( y );
			if( fx == fy ) continue;
			if( mp[ es[ i ].w ] == round ) continue;
			fa[ fx ] = fy;
			cnt++;
			mp[ es[ i ].w ] = round;
			if( cnt == n - 1 ) break;
		}	
	}
	
	int p = 0;
	while( mp[ p ] ) p ++;
	std::cout<<p;
	return 0;
}