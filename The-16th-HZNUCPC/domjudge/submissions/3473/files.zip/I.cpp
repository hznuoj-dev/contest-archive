#include<bits/stdc++.h>

using namespace std;

int n, len;
string s;
int ans;

void Solve() {

	for(int i = 1; i <= len; i ++) {
		int l = i, r = i;
		while(true) {
			if(l < 1 || r > len) {
//cout<<"1:"<<l<<" "<<r<<"\n";
				ans = max(ans, r - l - 1);
//cout<<"===>"<<r-l-1<<"\n";
				break;
			}
			if(s[l] == s[r]) {
				l --;
				r ++;
			} else {
				l --; r ++;
				if(l < 1 || r > len) {
					if(s[l+1]==s[i]||s[r-1]==s[i]){
//cout<<"2:"<<l<<" "<<r<<"\n";
						ans = max(ans,r-l-1);
//cout<<"===>"<<r-l-1<<"\n";
						break;
					}
//cout<<"3:"<<l<<" "<<r<<"\n";
					ans = max(ans, r - l - 3);
//cout<<"===>"<<r-l-3<<"\n";
					break;
				}
				if((s[l]==s[l+1]&&s[r]==s[r-1]) || (s[l]==s[r-1]&&s[l+1]==s[r])) {
					l --; r ++;
					while(true) {
						if(l < 1 || r > len) {
//cout<<"4:"<<l<<" "<<r<<"\n";
							ans = max(ans, r - l - 1);
//cout<<"===>"<<r-l-1<<"\n";
							break;
						}
						if(s[l] != s[r]) {
//cout<<"5:"<<l<<" "<<r<<"\n";
							ans = max(ans, r - l - 1);
//cout<<"===>"<<r-l-1<<"\n";
							break;
						}
						l --, r ++;
					}
					break;
				} else {
					if(s[l+1]==s[i]||s[r-1]==s[i]) {
						l --; r ++;
						while(true) {
							if(l < 1 || r > len) {
//cout<<"6:"<<l<<" "<<r<<"\n";
								ans = max(ans, r - l - 1);
//cout<<"===>"<<r-l-1<<"\n";
								break;
							}
							if(s[l] != s[r]) {
//cout<<"7:"<<l<<" "<<r<<"\n";
								ans = max(ans, r - l - 3);
//cout<<"===>"<<r-l-1<<"\n";
								break;
							}
							l --, r ++;
						}
						break;
					}
					else{
//cout<<"8:"<<l<<" "<<r<<"\n";
						ans = max(ans, r - l - 3);
//cout<<"===>"<<r-l-3<<"\n";
					}
					break;
				}
			}
		}
	}
	for(int i = 1; i < len; i ++) {
//		if(s[i] != s[i + 1]) {
//			continue;
//		}
		int l = i, r = i + 1;
		while(true) {
			if(l < 1 || r > len) {
//cout<<"9:"<<l<<" "<<r<<"\n";
				ans = max(ans, r - l - 1);
//cout<<"===>"<<r-l-1<<"\n";
				break;
			}
			if(s[l] == s[r]) {
				l --;
				r ++;
			} else {
				l --; r ++;
				if(l < 1 || r > len) {
//cout<<"10:"<<l<<" "<<r<<"\n";
					ans = max(ans, r - l - 3);
//cout<<"===>"<<r-l-3<<"\n";
					break;
				}
				if((s[l]==s[l+1]&&s[r]==s[r-1]) || (s[l]==s[r-1]&&s[l+1]==s[r])) {
					l --; r ++;
					while(true) {
						if(l < 1 || r > len) {
//cout<<"11:"<<l<<" "<<r<<"\n";
							ans = max(ans, r - l - 1);
//cout<<"===>"<<r-l-1<<"\n";
							break;
						}
						if(s[l] != s[r]) {
//cout<<"12:"<<l<<" "<<r<<"\n";
							ans = max(ans, r - l - 1);
//cout<<"===>"<<r-l-1<<"\n";
							break;
						}
						l --, r ++;
					}
					break;
				} else {
//cout<<"13:"<<l<<" "<<r<<"\n";
					ans = max(ans, r - l - 3);
//cout<<"===>"<<r-l-3<<"\n";
					break;
				}
			}
		}
	}
}

signed main(){
	scanf("%d", &n);
	for(int kk = 1; kk <= n; kk ++) {
		cin >> s;
		len = s.length();
		ans = 0;
		s = " " + s;
		Solve();
		if(ans<2)ans=0;
		printf("%d\n", ans);
	}
	return 0;
}