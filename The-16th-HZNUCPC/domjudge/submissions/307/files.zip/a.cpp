#include <bits/stdc++.h>
using namespace std;
int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};
void solve(){
    int n;
    scanf("%d",&n);
    map<pair<int,int>,int> mp;
    for (int i = 0; i < n; i++)
    {
        int x,y,c;
        scanf("%d%d%d",&x,&y,&c);
        mp[make_pair(x,y)]=c;
    }
    int ans=0;
    for (int i = 1; i <= 19; i++)
    {
        for (int j = 1; j <=19; j++)
        {
            if(mp[make_pair(i,j)]==1){
                for (int d = 0; d < 4; d++)
                {
                    int nx=i+dx[d];
                    int ny=j+dy[d];
                    if(nx<1||nx>19||ny<1||ny>19){
                        continue;
                    }
                    if(mp[make_pair(nx,ny)]==0){
                        ans++;
                    }
                }
                
                
            }
        }
        
    }
    printf("%d\n",ans);
    
    
}
int main(){
    int t=1;
    // ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    scanf("%d",&t);
    while (t--)
    {
        solve();
    }
    return 0;
}