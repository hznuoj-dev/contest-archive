#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll T;

void run(){
	ll n,m;
	cin>>n>>m;
	if(n==1|| m ==1){
		cout<<"YES"<<'\n';
		return ;
	}
	ll c = m,d=0;
	while(c!=0&&d<2){
		c = n % c;
		if(c == 1){
			cout << "YES" << '\n';
			return ;
		}
		d++;
	}
	cout << "NO" << '\n';
	return ;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	T=1;
	while(T--){
		run();
	}
}