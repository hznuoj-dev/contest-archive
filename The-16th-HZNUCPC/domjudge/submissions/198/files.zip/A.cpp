#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
ll cross(ll a,ll b,ll c,ll d)
{
    return a*d-c*b;
}
ll js(ll a,ll b,ll c,ll d)
{
    return __gcd(abs(a-c),abs(b-d));
}
ll x[105],y[105];
int main ()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    //cin >> tt;
    while (tt--)
    {
        int n;
        cin>>n;
        for(int i=1;i<=n;i++)
        {
            cin>>x[i]>>y[i];
        }
        ll da=0;
        for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
            {
                for(int k=1;k<=n;k++)
                {
                    if(i==j||j==k||i==k) continue;
                    if(cross(x[i]-x[j],y[i]-y[j],x[k]-x[j],y[k]-y[j])==0)
                    {
                        continue;
                    }
                    da=max(da,js(x[i],y[i],x[j],y[j])+js(x[i],y[i],x[k],y[k])+js(x[k],y[k],x[j],y[j]));
                }
            }
        }
        cout<<da<<'\n';
    }

}
