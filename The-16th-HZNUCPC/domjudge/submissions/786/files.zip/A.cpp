#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define IO ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
const ll mode=1e9+7;
const int maxn=1e5+10;
//---------------------------
struct node
{
    int x,y,c;
    bool operator<(const node&o)const
    {
        return x<o.x;
    }
};
/*
5 3
5 4
1 7

6 3
5 5
5 6
18 5
*/
ll x,y;
//----------------------
set<ll>st;
void solve()
{
    cin>>x>>y;
    while(x%y)
    {
        if(x%y==1)
        {
            cout<<"YES";
            return;
        }
        y=x%y;

        if(!st.count(y))
        {
            st.insert(y);
            continue;
        }else
        {
            break;
        }
    }
    cout<<"NO";
}
int main()
{
    IO;
    int tn=1;
    //cin>>tn;
    while(tn--)
    {
        solve();
    }
    return 0;
}
