#include <bits/stdc++.h>
using namespace std;
#define ln '\n'

const int N = 2e4 + 5;
char a[N], s[N];

inline void solve() {
	cin >> (a+1);
	int n = strlen(a+1);
	s[1]='#';
	for (int i=1; i<=n; i++) s[2*i]=a[i];
	for (int i=1; i<=n; i++) s[2*i+1]='#';
	n=2*n+1;
	int ans=0;
	for (int mid=1; mid<=n; ++mid){
		int tmp=s[mid]!='#';
		vector<int> p={};
		for (int l=mid-1,r=mid+1; l>=1&&r<=n; --l,++r){
			if (s[l]!='#') tmp+=2;
			if (s[l]!=s[r]) p.push_back(s[l]),p.push_back(s[r]);
			if (p.size()==0){
				if (tmp!=1) ans=max(ans,tmp);
			} else if (p.size()==2){
				if (s[mid]==p[0]||s[mid]==p[1]) ans=max(ans,tmp);
			} else if (p.size()==4){
				if (p[0]==p[2]&&p[1]==p[3]) ans=max(ans,tmp);
				if (p[0]==p[3]&&p[1]==p[2]) ans=max(ans,tmp);
			} else break;
		}
	}
	cout << ans << ln;
}

int main() {
	int test;
	cin >> test;
	while(test--) solve();
	return 0;
}
/*
4
abccab
ihi
stfgfiut
palindrome
*/