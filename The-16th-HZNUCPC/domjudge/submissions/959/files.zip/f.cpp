#include  <bits/stdc++.h>

using namespace std;
typedef long long LL;
const int mod = 1e9 + 7;
void kizk(){
	LL n, m; cin >> n >> m;
    if(n <= m)
    {
        cout << "NO\n";
        return;
    }
    for(int k = m; k >= 1; k --)
    {
        if(n % m == 0)
        {
            cout << "NO\n";
            return;
        }
        if(n / k > n % k)
        {
            m = k;
        }
    }
    cout << "YES\n";
}


int main(){
	std::ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int T; T = 1;
	// cin >> T;
	while(T --) kizk();
	return 0;
}