#include<bits/stdc++.h>
using namespace std;
int mp[40][40];
int X[5]={0,1,-1,0};
int Y[5]={1,0,0,-1};
int bfs(int x,int y){
	queue<int> qux,quy,tqux,tquy;
	qux.push(x);
	quy.push(y);
	tqux.push(x);
	tquy.push(y);
	while(!qux.empty()){
		int jx=qux.front(),jy=quy.front();
		qux.pop();
		quy.pop();
		for(int i=0;i<4;i++){
			if(mp[jx+X[i]][jy+Y[i]]==mp[x][y]){
				qux.push(jx+X[i]);
				quy.push(jy+Y[i]);
				tqux.push(jx+X[i]);
				tquy.push(jy+Y[i]);
			}else if(mp[jx+X[i]][jy+Y[i]]==0){
				return 1;
			}	
		}
	}
	while(!tqux.empty()){
		int jx=tqux.front(),jy=tquy.front();
		tqux.pop();
		tquy.pop();
		mp[jx][jy]=0;
	}
	return 0;
}
int main()
{
	int T;
	cin>>T;
	while(T--){
		for(int i=0;i<=20;i++){
			for(int j=0;j<=20;j++){
				mp[i][j]=0;
			}
		}
		int n;
		cin>>n;
		for(int i=0;i<n;i++){
			int x,y,c;
			cin>>x>>y>>c;
			mp[x][y]=c;		
			for(int i=0;i<4;i++){
				if(mp[x+X[i]][y+Y[i]]!=0&&mp[x+X[i]][y+Y[i]]!=mp[x][y]){
					bfs(x+X[i],y+Y[i]);
				}
			}
		}
		int ans=0;
		for(int i=0;i<=20;i++){
			for(int j=0;j<=20;j++){
				if(mp[i][j]==1){
					for(int q=0;q<4;q++){
						if(mp[i+X[q]][j+Y[q]]==0){
							ans++;
							mp[i+X[q]][j+Y[q]]=-1;
						}
					}
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
//1