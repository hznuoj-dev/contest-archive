#include <bits/stdc++.h>
using namespace std;
double x[100010], y[100010], w[100010];
map <double, int> mp;
double dis(double a, double b, double c, double d)	{
	return sqrt((c - a) * (c - a) + (d - b) * (d - b));
}
int main()	{
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)	{
		int m;
		scanf("%d", &m);
		double zx = 0, zy = 0, t = 1;
		for (int j = 1; j <= m; j++)	{
			scanf("%lf%lf", &x[j], &y[j]);
			zx += x[j], zy += y[j];
		}
		zx /= m, zy /= m;
		for (int j = 1; j <= m; j++)	{
			w[j] = dis(zx, zy, x[j], y[j]);
		}
		sort(w + 1, w + m + 1);
		for (int j = 1; j <= m / 2; j++)	{
			t *= w[j] / w[m - j + 1];
		}
		//printf("%lf %lf\n", zx, zy);
		printf("%d\n", mp[t]);
		mp[t]++;
	}
}