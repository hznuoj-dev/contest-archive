#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 7;
const int mod=1e9+7;
string a,b;
int cnt[30][30],a1[30],b1[30];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>a>>b;
	int n=a.size();
	for(int i=0;i<n;i++)
	{
		a1[a[i]-'a'+1]++;
		b1[b[i]-'a'+1]++;
		cnt[a[i]-'a'+1][b[i]-'a'+1]++;
	}
	int ans=0;
	for(int i=0;i<n;i++)
	{
		int x=a[i]-'a'+1,y=b[i]-'a'+1;
		a1[x]--;b1[x]++;
		b1[y]--;a1[y]++;
		cnt[x][y]--;
		for(int j=1;j<=26;j++)
		{
			for(int k=1;k<=26;k++)
			{
				if(cnt[j][k])
				{
					a1[j]--;b1[j]++;
					a1[k]++;b1[k]--;
					int sizea2=0,sizeb2=0;
					for(int i=1;i<=26;i++)
					{
					if(a1[i]) sizea2++;
					if(b1[i]) sizeb2++;
					}
					if(sizea2==sizeb2)
					{
						//cout<<x<<' '<<y<<' '<<j<<' '<<k<<endl;
						ans+=cnt[j][k];
					}
					a1[j]++;b1[j]--;
					a1[k]--;b1[k]++;
				}
			}
		}
		a1[x]++;b1[x]--;
		b1[y]++;a1[y]--;
		cnt[x][y]++;
	}
	ans/=2;
	ans%=mod;
	cout<<ans<<endl;
}