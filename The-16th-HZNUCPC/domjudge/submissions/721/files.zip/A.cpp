#include<bits/stdc++.h>
using namespace std;
void solve() {
	int n,i,j,cnt=0;
	cin>>n;
	int board[21][21]={0};
	for(j=0;j<=20;j++)
		board[0][j]=-1;
	for(j=0;j<=20;j++)
		board[j][0]=-1;
	for(j=0;j<=20;j++)
		board[j][20]=-1;
	for(j=0;j<=20;j++)
		board[20][j]=-1;
	for(i=1;i<=n;i++)
	{
		int x,y,c;
		cin>>x>>y>>c;
		board[x][y]=c;
	}
	for(i=1;i<=19;i++){
		for(j=1;j<=19;j++){
			if(board[i][j]==0)
				continue;
			if(board[i][j]==1){
				if(board[i-1][j]==0)cnt++;
				if(board[i+1][j]==0)cnt++;
				if(board[i][j+1]==0)cnt++;
				if(board[i][j-1]==0)cnt++;
			}
		}
	}
	cout<<cnt<<endl;
}	
signed main() {
	int T;
	cin>>T;
	while(T--)
		solve();
	return 0;
}
