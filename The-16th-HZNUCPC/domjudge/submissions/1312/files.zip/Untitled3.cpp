#include "iostream"
using namespace std;
long long a,b,c,d,e,f;
int pan[20][20];
struct hei{
	int x;
	int y;
};
hei hei[370];
int dir[4][2]={(0,1),(0,-1),(1,0),(-1,0)};
int main(){
	int T;
	while(cin>>T){
		while(T--){
			int t;
			cin>>t;
			memset(pan,0,sizeof(pan));
			int n=1;
			int sum=0;
			while(t--){
				
				int x,y,c;
				cin>>x>>y>>c;
				if(c==1){
					hei[n].x=x;
					hei[n].y=y;
					n++;
				}
				pan[x][y]=c;
			}
			for(int r=1;r<=n-1;r++){
				if(hei[r].x==1)sum--;
				if(hei[r].y==1)sum--;
				if(hei[r].x==19)sum--;
				if(hei[r].y==19)sum--;
				if(pan[hei[r].x-1][hei[r].y]==0){
					sum++;
				}
				if(pan[hei[r].x+1][hei[r].y]==0){
					sum++;
				}
				if(pan[hei[r].x][hei[r].y+1]==0){
					sum++;
				}
				if(pan[hei[r].x][hei[r].y-1]==0){
					sum++;
				}
			}
			cout<<sum<<endl;
	
		}
	}
	return 0;
}