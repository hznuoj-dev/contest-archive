#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct stu{
	int x,y;
}q[110];
ll maxn,a,b;
int main(){
	int n,flag=0;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>q[i].x>>q[i].y;
	}
	for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			if(q[i].y!=0||q[j].y!=0){
				if(q[i].x*1.0/q[i].y!=q[j].x*1.0/q[j].y){
					flag=1;
				}
			
			}
			} 
			if(flag==1){
				break;
			}
	}	
	if(flag==0){
			cout<<"0";
		}else{
			for(int i=1;i<=n-1;i++)
			{
				for(int j=i+1;j<=n-1;j++)
				{
					for(int h=j+1;h<=n;h++)
					{
						ll num=3;
						a=abs(q[i].x-q[j].x);
						b=abs(q[i].y-q[j].y);		
						num=num+__gcd(a,b)-1;
						a=abs(q[i].x-q[h].x);
						b=abs(q[i].y-q[h].y);		
						num=num+__gcd(a,b)-1;
						a=abs(q[h].x-q[j].x);
						b=abs(q[h].y-q[j].y);		
						num=num+__gcd(a,b)-1;	
						maxn=max(maxn,num);	
					}
				}
			}
			cout<<maxn;
		}
	return 0;
}