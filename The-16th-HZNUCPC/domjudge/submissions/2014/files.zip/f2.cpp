#include <bits/stdc++.h>
using namespace std;
const int N=1000,M=N*2;
int e[M], ne[M], h[N], w[M], idx;
#define ll long long 
//#define int long long

ll qpow(ll a,ll b,ll p)
{
	ll sum=1;
	while(b)
	{
		if(b&1)
		sum*=a%p;
		b>>=1;
		a*=a%p;
	}
	return sum;
}

void add(int a,int b,int c){
	e[idx]=b;w[idx]=c;ne[idx]=h[a];h[a]=idx++;
}

int g[N][N];
bool st[N][N];

signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int n;
	cin >> n;
	vector<pair<int, int> > vec;
	
	for(int i = 0; i < n; i++){
		int a, b;
		cin >> a >> b;
		vec.push_back({a, b});
	}
	
	int max = -1e8;
	for(int i = 0; i < n-1; i++){
		for(int j = i+1; j < n-1; j++){
			for(int k = j+1; k < n; k++){
				int point = 0;
				for(int l = 0; l < 3; l++){
					int detx, dety;
					
					
					if(l == 0){
						detx = vec[i].first - vec[j].first;
						dety = vec[i].second - vec[j].second;
					}
					if(l == 1){
						detx = vec[i].first - vec[k].first;
						dety = vec[i].second - vec[k].second;
					}
					if(l == 2){
						detx = vec[j].first - vec[k].first;
						dety = vec[j].second - vec[k].second;
					}
					
					int point_line;
					if(detx == 0){
						point += abs(dety) - 1;
					}
					else if(dety == 0){
						point += abs(detx) - 1;
					}
					else{
						point += abs(__gcd(detx, dety)) - 1;
				    }
				    
				    
				    
				}
				
				if(max < point) max = point;
				
				
			}
		}
	}
	
	
	max += 3;
	cout << max;
}