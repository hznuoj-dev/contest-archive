import java.util.*;
public class Main 
{
	public static void main(String[]args)
	{
		Scanner sc=new Scanner(System.in);
		while (sc.hasNext())
		{
			long n=sc.nextLong();
			long m=sc.nextLong();
			int f=0;
			while(m>1)
			{
				if(m>n)
				{
					f=1;
					break;
				}
				if(n%m==0)
				{
					f=1;
					break;
				}
				else
				{
					m--;
				}
			}
			System.out.println(f==0?"YES":"NO");			
		}
	}	
}