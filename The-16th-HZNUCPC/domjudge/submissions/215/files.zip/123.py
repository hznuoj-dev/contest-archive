Python 2.7.18 (v2.7.18:8d21aa21f2, Apr 20 2020, 13:25:05) [MSC v.1500 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.
>>> T = int(input()) #������������

def check(i,j):
	global sum
	x1 = [0,0,-1,1]
	y1 = [1,-1,0,0]
	for i in range(4):
		x = i+x1
		y = j+y1
		if 1<=x<=19 and 1<=y<=19 and stone[x,y] == 0:
			sum += 1
			stone[x,y]=3
			check(x,y)

def work(stone):
	for i in range(20):
		for j in range(20):
			if stone[i][j] == 1:
				check(i,j)

for i in range(T):
	n = int(input())
	stone = [[[0] for j in range(20)] for i in range(20)]
	sum = 0
	for j in range(n):
		x,y,c = map(int,input().split())
		stone[x][y] = c
	work(stone)
	print(sum)



Traceback (most recent call last):
  File "<pyshell#0>", line 1, in <module>
    T = int(input()) #������������
  File "<string>", line 0
    
    ^
SyntaxError: unexpected EOF while parsing
>>> 
>>> T = int(input()) #������������

def check(i,j):
	global sum
	x1 = [0,0,-1,1]
	y1 = [1,-1,0,0]
	for i in range(4):
		x = i+x1
		y = j+y1
		if 1<=x<=19 and 1<=y<=19 and stone[x,y] == 0:
			sum += 1
			stone[x,y]=3
			check(x,y)

def work(stone):
	for i in range(20):
		for j in range(20):
			if stone[i][j] == 1:
				check(i,j)

for i in range(T):
	n = int(input())
	stone = [[[0] for j in range(20)] for i in range(20)]
	sum = 0
	for j in range(n):
		x,y,c = map(int,input().split())
		stone[x][y] = c
	work(stone)
	print(sum)

1
>>> 2
2
>>> 111
111
>>> 
>>> def check(i,j):
	global sum
	x1 = [0,0,-1,1]
	y1 = [1,-1,0,0]
	for i in range(4):
		x = i+x1
		y = j+y1
		if 1<=x<=19 and 1<=y<=19 and stone[x,y] == 0:
			sum += 1
			stone[x,y]=3
			check(x,y)

def work(stone):
	for i in range(20):
		for j in range(20):
			if stone[i][j] == 1:
				check(i,j)
T = int(input()) #������������
for i in range(T):
	n = int(input())
	stone = [[[0] for j in range(20)] for i in range(20)]
	sum = 0
	for j in range(n):
		x,y,c = map(int,input().split())
		stone[x][y] = c
	work(stone)
	print(sum)
	
SyntaxError: invalid syntax
>>> 1
1
>>> 
>>> 
>>> def check(i,j):
	global sum
	x1 = [0,0,-1,1]
	y1 = [1,-1,0,0]
	for i in range(4):
		x = i+x1
		y = j+y1
		if 1<=x<=19 and 1<=y<=19 and stone[x,y] == 0:
			sum += 1
			stone[x,y]=3
			check(x,y)

def work(stone):
	for i in range(20):
		for j in range(20):
			if stone[i][j] == 1:
				check(i,j)
T = int(input()) #������������
for i in range(T):
	n = int(input())
	stone = [[[0] for j in range(20)] for i in range(20)]
	sum = 0
	for j in range(n):
		x,y,c = map(int,input().split())
		stone[x][y] = c
	work(stone)
	print(sum)
