#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int read(){
    int x=0,f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c))x=x*10+c-48,c=getchar();
    return x*f;
}
long long n,m;
signed main(){
    scanf("%lld%lld",&n,&m);
    if(n==1){puts("YES");return 0;}
    if(n<=m){puts("NO");return 0;}
    for(int i=2;i*i<=n;i++){
        if(n%i==0){
            int x=i,y=n/i;
            if(x<=m||y<=m){
                puts("NO");return 0;
            }
        }
    }
    puts("YES");
    return 0;
}