#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,m,x;
struct node1{
	int t,l,r;
}car[N];
struct node2{
	int c,p;
	int id,ans;
}peo[N];
bool cmp1(node1 x,node1 y){
	if(x.t==y.t)return x.r>y.r;
	return x.t>y.t;
}
bool cmp2(node2 x,node2 y){
	return x.c>y.c;
}
bool cmp3(node2 x,node2 y){
	return x.id<y.id;
}
int dp[N],dpmx,mq;
int main() {
	ios::sync_with_stdio(false);
	cin>>n>>m>>x;
	for(int i=1;i<=n;i++){
		cin>>car[i].t>>car[i].l>>car[i].r;
		dp[i]=x+1;
	}
	for(int i=n+1;i<=n+3;i++)dp[i]=x+1;
	for(int i=1;i<=m;i++){
		cin>>peo[i].c>>peo[i].p;
		peo[i].id=i;
	}
	sort(car+1,car+n+1,cmp1);
	sort(peo+1,peo+m+1,cmp2);
	dp[0]=x;dpmx=0;mq=1;
	for(int i=1,l,r,mid;i<=n;i++){
		while(mq<=m && peo[mq].c>car[i].t){
			l=0;r=dpmx;
			while(l<r){
				mid=(l+r)/2;
				if(dp[mid]<=peo[mq].p){
					r=mid;
				}else{
					l=mid+1;
				}
			}
			if(dp[l]<=peo[mq].p){
				peo[mq].ans=l;
			}else{
				peo[mq].ans=-1;
			}
			mq++;
		}
		
		l=0,r=dpmx;
		while(l<r){
			mid=(l+r)/2;
			if(dp[mid]<=car[i].r){
				r=mid;
			}else{
				l=mid+1;
			}
		}
		if(dp[l]<=car[i].r){
			dp[l+1]=min(dp[l+1],car[i].l);
			if(l+1>dpmx)dpmx=l+1;
			else if(dp[l+1]<=dp[l+2])dpmx=l+1;
		}
	}
	for(int i=mq,l,r,mid;i<=m;i++){
		l=0;r=dpmx;
			while(l<r){
				mid=(l+r)/2;
				if(dp[mid]<=peo[i].p){
					r=mid;
				}else{
					l=mid+1;
				}
			}
			if(dp[l]<=peo[i].p){
				peo[i].ans=l;
			}else{
				peo[i].ans=-1;
			}
	}
	sort(peo+1,peo+m+1,cmp3);
	for(int i=1;i<=m;i++){
		cout<<peo[i].ans<<'\n';
	}
	return 0;	
}