#include<bits/stdc++.h>
using namespace std;
string x;
bool p(int a,int b) {
	int c=0,n=b-a+1;
	map<char,int> v;
	for(int i=a,j=0; i<(a+b+1)/2; i++,j++) {
		if(x[i]!=x[b-j]) {
			c++;v[x[i]]++;v[x[b-j]]++;
		}
	}
	if(c==0||(c==2&&v.size()==2)) return true;
	if(n%2){
		if(c==1&&v[x[(a+b)/2]]==1) return true;
	}
	return false;
}
int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	int t;
	cin>>t;
	while(t--) {
		int f=0,ans=-1;
		cin>>x;
		int n=x.size();
		for(int i=0; i<n; i++) {
			for(int j=i+1; j<n; j++) {
				if(j-i+1<=ans) continue;
				if(p(i,j)){
					ans=max(ans,j-i+1);
				}
			}
		}
		if(ans==-1) cout<<0<<endl;
		else cout<<ans<<endl;
	}
	return 0;
}