#include <bits/stdc++.h>
using namespace std;

// #define DEBUG

const int d[4][2] = {
	{1, 0}, 
	{-1, 0}, 
	{0, 1}, 
	{0, -1}
};

int mp[25][25];
bool vis[25][25];
int n, ans;

void dfs(int x, int y) {
	if (mp[x][y] == 0) {
		ans++;
		return;
	}
	if (mp[x][y] == 2) return;
	vis[x][y] = true;
	for (int i = 0; i < 4; i++) {
		int tx = x + d[i][0], ty = y + d[i][1];
		if (tx < 1 || tx > 19 || ty < 1 || ty > 19 || vis[tx][ty]) continue;
		dfs(tx, ty);
	}
}

int main() {
	int _;
	scanf("%d", &_);
	while (_--) {
		scanf("%d", &n);
		memset(mp, 0, sizeof mp);
		memset(vis, 0, sizeof vis);
		ans = 0;
		for (int i = 1; i <= n; i++) {
			static int x, y, c;
			scanf("%d %d %d", &x, &y, &c);
			mp[x][y] = c;
		}
		for (int i = 1; i <= 19; i++) {
			for (int j = 1; j <= 19; j++) {
				if (mp[i][j] == 1 && !vis[i][j]) {
					dfs(i, j);
				}
			}
		}
		printf("%d\n", ans);
	}
    return 0;
}