#include<bits/stdc++.h>
using namespace std;

long long n,m;
int check(long long x)
{
    //printf("[%d]\n",x);
    if(x!=m)
    {
        if((n-(n/x)*x)>=n/x)return 1;
    }
    else
    {
        if(n%x!=0)return 1;
    }
    if(n%x==0)return 0;
    return 1;

}
int main()
{
    scanf("%lld%lld",&n,&m);
    if(m==1)
    {
        puts("YES");
    }
    else if(n<=m)
    {
        puts("NO");
    }
    else
    {
        int ans=1;
        for(long long i=2;i<=m&&i*i<=n;++i)
        {
            if(n%i!=0)continue;
            if(check(i)==0||check(n/i)==0)
            {
                ans=0;
                break;
            }
        }
        if(ans==1)
        {
            puts("YES");
        }
        else
        {
            puts("NO");
        }
    }

    return 0;
}
