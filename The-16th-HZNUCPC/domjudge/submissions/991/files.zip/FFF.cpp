#include<stdio.h>
int main(){
	long long n,m;
	scanf("%lld%lld",&n,&m);
	if(n%2==1&&m%2==1||n%2==1&&m%2==0&&m!=0){
		printf("YES\n");
	}
if(n%2==0&&n!=0&&m%2==1||n%2==0&&n!=0&&m%2==0&&m!=0){
		printf("NO\n");
	}
	return 0; 
}