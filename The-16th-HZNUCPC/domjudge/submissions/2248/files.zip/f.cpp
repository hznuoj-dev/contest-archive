#include <bits/stdc++.h>
using namespace std;
long long isPrime(long long x)
{
	if (x<2) return 0;
	for (long long i=2;i<=x/i;i++)
	{
		if (x%i==0) return i;
	}
	return 0;
}
int main(){
	long long int n,m;
	cin>>n>>m;
	if(m==1||n==1){
		cout<<"YES";
	}
	else if(m>=n){
		cout<<"NO";
	}
	else{
		if(isPrime(n)<=m&&isPrime(n)!=0){
			cout<<"NO";
		}
		else{
			cout<<"YES";
		}
	}
	return 0;
}