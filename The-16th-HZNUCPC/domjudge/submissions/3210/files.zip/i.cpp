#include<bits/stdc++.h>
using namespace std;

const int N = 5e3 + 10;

char ma[N << 2];
int mp[N << 2];
int n;

char s[N];

void manachar(char s[], int len) {
	int l = 0;
	ma[l++] = '$';
	ma[l++] = '#';
	for (int i = 0; i < len; i++) {
		ma[l++] = s[i];
		ma[l++] = '#';
	}
	ma[l] = 0;
	int mx = 0, id = 0;
	for (int i = 0; i < l; i++) {
		mp[i] = mx > i ? min(mp[2 * id - i], mx - i) : 1;
		while(ma[i + mp[i]] == ma[i - mp[i]]) mp[i]++;
		if (i + mp[i] > mx) {
			mx = i + mp[i];
			id = i;
		} 
	}
}

void init() {
	for (int i = 0; i <= N * 2 + 1; i++) {
		mp[i] = 0;
	}
}
void solve() {
	init();
	scanf("%s", s);
	int len = strlen(s);
	manachar(s, len);
	vector<int> l_idx, r_idx;
	for (int i = 2; i < 2 * len + 2; i++) {
		int len = mp[i] - 1, l, r;
		if (len == 0) continue;
		if (i & 1) {
			r = i / 2 - 1 + len / 2;
			l = r - (len - 1);
		} else {
			int mid = i / 2 - 1;
			r = mid + len / 2;
			l = r - (len - 1);
		}
		l_idx.push_back(l);
		r_idx.push_back(r);
//		cout << l << " " << r << endl;
	}
	for (int i = 0; i < len - 1; i++) {
		r_idx.push_back(i);
		l_idx.push_back(i + 1);
	}
	int ans = 0;
	for (int i = 0; i < l_idx.size(); i++) {
		if (r_idx[i] - l_idx[i] + 1 >= 2) {
			ans = max(ans, r_idx[i] - l_idx[i] + 1);
		}
		int l = l_idx[i] - 1, r = r_idx[i] + 1;	
		int res = r - l + 1;
		if (l < 0 || r >= len) continue;
		for (int p = 1; l - p >= 0 && r + p < len; p++) {
			if (s[l - p] == s[r] && s[l] == s[r + p]) {
//				cout << p << endl;
				res += p * 2;
				p++;
				while (l - p >= 0 && r + p < len && s[l - p] == s[r + p]) {
					res += 2;
					p++;
				}
//				cout << p << " " << res << endl;
				ans = max(ans, res);
				break;
			}
			if (s[l - p] != s[r + p]) break;
		}
	}
	printf("%d\n", ans);
}

int main() {
	int T; scanf("%d", &T);
	while (T--)
	solve();
	return 0;
}