#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const ll mod=1e9+7;
char s1[100010];
char s2[100010];
ll a[30];
ll b[30];
ll s[30][30];

ll ksm(ll x,ll y,ll m)
{
    ll res=1;
    while(y){
        if(y&1)res*=x,res%=m;
        x=(x*x)%m;
        y>>=1;
    }
    return res;
}
int main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);
    cout.tie(0);
    ll ans=0;
    cin>>s1>>s2;
    ll z=0;
    ll len=strlen(s1);
    for(ll i=0;i<len;i++){
        a[s1[i]-'a']++;
        b[s2[i]-'a']++;
        s[s1[i]-'a'][s2[i]-'a']++;
        if(s1[i]==s2[i])z++;
    }
    for(ll i=0;i<26;i++){
        for(ll j=0;j<26;j++){
            for(ll k=i;k<26;k++){
                for(ll l=j;l<26;l++){
                    if(s[i][j]>0&&s[k][l]>0){
                        a[i]--;
                        b[i]++;
                        a[j]++;
                        b[j]--;
                        a[k]--;
                        b[k]++;
                        a[l]++;
                        b[l]--;
                        ll z1,z2;
                        z1=z2=0;
                        for(ll i=0;i<26;i++){
                            if(a[i])z1++;
                            if(b[i])z2++;
                        }
                        if(z1==z2){
                            if(i==k&&j==l){
                                ans=(ans+(s[i][j]*(s[i][j]-1)/2)%mod)%mod;
                            }
                            else ans=(ans+(s[i][j]*s[k][l])%mod)%mod;
                        }
                        //printf("%c %c %c %c %lld\n",i+'a',j+'a',k+'a',l+'a',ans);
                        a[i]++;
                        b[i]--;
                        a[j]--;
                        b[j]++;
                        a[k]++;
                        b[k]--;
                        a[l]--;
                        b[l]++;
                    }
                }
            }
        }
    }
    cout<<ans%mod<<endl;
    /*ll zz1,zz2;
    zz1=zz2=0;
    for(ll i=0;i<26;i++){
        if(a[i]>0)zz1++;
        if(b[i]>0)zz2++;
        a[i]=0;
        b[i]=0;
    }
    if(zz1<zz2)swap(s1,s2);
    for(ll i=0;i<len;i++){
        a[s1[i]-'a']++;
        b[s2[i]-'a']++;
        s[s1[i]-'a'][s2[i]-'a']++;
        if(s1[i]==s2[i])z++;
    }*/
    /*ll ans1=0;
    ll ans2=0;
    for(ll i=0;i<26;i++){
        if(a[i]>0)ans1++;
        if(b[i]>0)ans2++;
    }
    ll z1,z2,z3,z4;
    z1=z2=z3=z4=0;
    for(ll i=0;i<26;i++){
        for(ll j=0;j<26;j++){
            if(i==j)continue;
            if(a[i]>0&&b[i]>0&&a[j]==0&&b[j]>0){
                z1++;
            }
            if(a[i]>0&&b[i]>0&&a[j]>0&&b[j]==0){
                z1++;
            }

        }
    }
    ll ans=0;
    cout<<ans1<<"  "<<ans2<<endl;*/
    /*if(ans1==ans2){
        for(ll i=0;i<26;i++){
            for(ll j=0;j<26;j++){
                if(i==j){
                    ans=(ans+(s[i][j]*(s[j][i]-1)/2)%mod)%mod;
                }
                else{
                    ans=(ans+(s[i][j]*s[j][i]%mod))%mod;
                }
            }
        }
    }
    else if(ans1-ans2>4){
        ans=0;
    }
    else if(ans1==ans2+4){
        for(ll i=0;i<26;i++){
            for(ll j=0;j<26;j++){
                for(ll k=0;k<26;k++){
                    for(ll l=0;l<26;l++){
                        if(i!=j&&i!=k&&i!=l&&j!=k&&j!=l&&k!=l){
                            if(a[i]==1&&b[i]==0&&a[j]>0&&b[j]>1&&a[k]==1&&b[k]==0&&a[l]>0&&b[l]>1){
                                ans++;
                            }
                        }
                    }
                }
            }
        }
    }
    else if(ans1==ans2+3){
        for(ll i=0;i<26;i++){
            for(ll j=0;j<26;j++){
                for(ll k=0;k<26;k++){
                    for(ll l=0;l<26;l++){
                        if(i!=j&&i!=k&&i!=l&&j!=k&&j!=l&&k!=l){
                            if(a[i]==1&&b[i]==0&&a[j]>1&&b[j]==0&&a[k]>0&&b[k]>1&&a[l]>0&&b[l]>1){
                                ans=(ans+((s[i][k]+s[i][l])*(s[j][k]+s[j][l])%mod))%mod;
                            }
                            if(a[i]==1&&a[j]==1&&b[i]==0&&b[j]>0&&a[k]>0&&b[k]>1&&a[l]>0&&b[l]>1){
                                ans=(ans+((s[i][k]+s[i][l])*(s[j][k]+s[j][l])%mod))%mod;
                            }
                            if(a[i]==1&&a[j]==1&&b[i]>0&&b[j]==0&&a[k]>0&&b[k]>1&&a[l]>0&&b[l]>1){
                                ans=(ans+((s[i][k]+s[i][l])*(s[j][k]+s[j][l])%mod))%mod;
                            }
                        }
                    }
                }
            }
        }
    }
    else if(ans1==ans2+2){
        for(ll i=0;i<26;i++){
            for(ll j=0;j<26;j++){
                for(ll k=0;k<26;k++){
                    for(ll l=0;l<26;l++){
                        if(i!=j&&i!=k&&i!=l&&j!=k&&j!=l&&k!=l){
                            if(a[i]>1&&b[i]==0&&a[j]>1&&b[j]==0&&a[k]>0&&b[k]>1&&a[l]>0&&b[l]>1){
                                ans=(ans+((s[i][k]+s[i][l])*(s[j][k]+s[j][l])%mod))%mod;
                            }
                            if(a[i]==1&&b[i]>0&&a[j]==1&&b[j]>0&&a[k]>0&&b[k]>1&&a[l]>0&&b[l]>1){
                                ans=(ans+((s[i][k]+s[i][l])*(s[j][k]+s[j][l])%mod))%mod;
                            }
                            if(a[i]==1&&b[i]==0&&a[j]>1&&b[j]>0&&a[k]>0&&b[k]>1&&a[l]>0&&b[l]>1){  //5 3 -> 4 4 ��ȷ��
                                ans=(ans+((s[i][k]+s[i][l])*(s[j][k]+s[j][l])%mod))%mod;
                            }
                            if(a[i]==1&&b[i]==0&&a[j]>1&&b[j]>0&&a[k]>0&&b[k]>1&&a[l]>0&&b[l]>1){
                                ans=(ans+((s[i][k]+s[i][l])*(s[j][k]+s[j][l])%mod))%mod;
                            }
                        }
                    }
                }
            }
        }
    }
    else if(ans1==ans2+1){
        for(ll i=0;i<26;i++){
            for(ll j=0;j<26;j++){
                for(ll k=0;k<26;k++){
                    for(ll l=0;l<26;l++){
                        if(i!=j&&i!=k&&i!=l&&j!=k&&j!=l&&k!=l){
                            if(a[i]>1&&b[i]==0&&a[j]>1&&b[j]==0&&a[k]>0&&b[k]>1&&a[l]>0&&b[l]>1){
                                ans=(ans+((s[i][k]+s[i][l])*(s[j][k]+s[j][l])%mod))%mod;
                            }
                        }
                    }
                }
            }
        }
    }*/

    //cout<<ans<<endl;
    return 0;
}
