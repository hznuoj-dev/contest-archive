#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int md=1e9+7;
//map<char,int> mpa,mpb;
string a,b;
ll num=0;
ll dp[100005];
int main(){
	cin>>a>>b;
	int lens = a.length();
	/*for(int i=0;i<a.length();i++){
		num=num+min(mpa[a[i]],mpb[b[i]]);
		mpa[a[i]]++;
		mpb[b[i]]++;
		num%=md;
	}
	cout<<num;*/
	a = " " + a;
	b = " " + b;
	dp[0] = 1;
	for(int i = 1; i <= lens; i++) {
		if(a[i] == b[i]) {
			dp[i] = dp[i - 1] + 1;
		} else {
			dp[i] = max(dp[i], dp[i - 1]);
		}
	}
	cout << dp[lens];
	return 0;
}