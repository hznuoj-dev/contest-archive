#include<bits/stdc++.h>
#define int long long
using namespace std;

double x[105];
double y[105];
int n,m;

double dist(double a,double b,double c,double d){
	double p1 = a - c;
	double p2 = b - d;
	return sqrt(p1*p1 + p2*p2);
}
void solve(){
	while(cin >> n){
		for(int i=1;i<=n;i++){
			cin>>x[i]>>y[i];
		}
		double yy =(y[1] - y[2]);
		double k = (x[1] - x[2]);
		if(yy!=0){
			k = k / yy;
		}else{
			k = 0;
		}
		bool f = 0;
		int maxn = 0;
		for(int i = 1;  i <= n ; i ++){
			for(int j = i + 1 ; j <= n ; j ++){
				yy =(y[i] - y[j]);
				double p = (x[i] - x[j]);
				if(yy!=0){
					p = p / yy;
				}else{
					p = 0;
				}
				double tt = abs(x[i] - x[j]) + abs(y[i] - y[j]);
				if(p!=k){
					f = 1;
				}
				if(tt > maxn){
					maxn = tt;
				}
			}
		}
		if(f){
			cout<< maxn <<endl;
		}else{
			cout << 0 << endl;
		}
	}
}

signed main(){
//	int T;cin >> T;while(T--){
		solve();
//	}
	return 0;
}