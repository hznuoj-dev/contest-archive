#include<bits/stdc++.h>
using namespace std;
const int MAXN = 2e5+10;
int f[MAXN],sz[MAXN];
int find(int x){
	return f[x]==x? x:f[x]=find(f[x]);
}
#define pii pair<int,int>
int BLK;
int vis[MAXN];
bool a[400][100001];
int pre[400][100001];
int ans[MAXN];
int main(){
	std::ios::sync_with_stdio(false);
	int n,q,m;
	//cout<<sqrt(100000)<<'\n';
	cin>>n>>q>>m;
	BLK=sqrt(n);
	for(int i=1;i<=2*n;i++) f[i]=i,sz[i]=(i<=n)? 1:0;
	for(int i=1;i<=m;i++){
		int k,u,v;cin>>k>>u>>v;
		if(k==0){
			int fu=find(u),fv=find(v);
			if(fu!=fv) f[fu]=fv,sz[fv]+=sz[fu];
			fu=find(u+n),fv=find(v+n);
			if(fu!=fv) f[fu]=fv,sz[fv]+=sz[fu];
		}
		else{
			int fu=find(u),fv=find(v+n);
			if(fu!=fv) f[fu]=fv,sz[fv]+=sz[fu];
			fu=find(u+n),fv=find(v);
			if(fu==fv) continue;
			f[fu]=fv;sz[fv]+=sz[fu];
		}
	}
	for(int i=1;i<=n;i++){
		if(find(i)==find(i+n)){
			cout<<"NO\n";return 0;
		}
	}
	vector<pair<int,int>> V;
	for(int i=1;i<=n;i++){
		if(!vis[find(i)]){
			vis[find(i)]=1;V.push_back(make_pair(sz[find(i)],find(i)));
		}
	}for(int i=0;i<V.size();i++) cout<<V[i].first<<' '<<V[i].second<<'\n';
	sort(V.begin(),V.end());
	vector<pair<int,int>> obj;
	for(int i=0;i<V.size();i++){
		int p=i;
		while(p<V.size()&&V[p].first==V[i].first) p++;
		int len=p-i;
		int kk=1;
		while(kk<=len){
			obj.push_back(make_pair(kk*V[i].first,V[i].first));
			len-=kk;
			kk<<=1;
		}
		if(len){
			obj.push_back(make_pair(len*V[i].first,V[i].first));
		}
		i=p-1;
	}
	a[0][0]=1;
	int sz=obj.size();
	for(int i=0;i<obj.size();i++){
		for(int j=q;j>=0;j--){
			a[i+1][j]=a[i][j];
		}
		for(int j=q;j>=obj[i].first;j--){
			if(a[i][j-obj[i].first]){
				a[i+1][j]=1;
				pre[i+1][j]=i;
			}
		}
	}
	if(!a[sz][q]){
		cout<<"NO\n";
	}
	else{
		cout<<"YES\n";
		int now=q;
		
		while(now){
			int pp=pre[sz][now];
			if(!pp){
				sz--;continue;
			}
			else{
				now-=obj[pp].first;
				ans[obj[pp].second]+=obj[pp].first/obj[pp].second;
			}
		}
		map<int,int> Map;
		for(int i=0;i<V.size();i++){
			if(ans[V[i].first]){
				ans[V[i].first]--;
				Map[V[i].second]=1;
			}
		}
		for(int i=1;i<=n;i++){
			if(Map.count(find(i))){
				cout<<i<<' ';
			}
		}
		cout<<'\n';
	}
}
/*
13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13
*/