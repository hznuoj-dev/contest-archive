#include<bits/stdc++.h>
#define PII pair<int,int>
#define F first
#define S second
#define LL long long
using namespace std;

const int N = 1e5 + 10,mod = 1e9 + 7;

int zia[27],zib[27],cnt1,cnt2;
int op[100],oop[100];
int a[N],b[N];
int main(){
	LL ans=0;
	char a1[N],b1[N];
	scanf("%s %s",&a1,&b1);
	int n=strlen(a1);
	for(int i=0;i<n;i++){
		a[i]=a1[i]-'a'+1;
		b[i]=b1[i]-'a'+1;
	}
	for(int i=0;i<n;i++){
		zia[a[i]]++;
		zib[b[i]]++;
	}
	for(int i=1;i<=26;i++){
		if(zia[i]>0)cnt1++;
		if(zib[i]>0)cnt2++;
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			int aa=0,bb=0;
			if(zia[b[i]]==0){
				cnt1++;
				aa++;
			}
			if(zib[a[i]]==0){
				cnt2++;
				bb++;
			}
			zia[a[i]]--,zia[b[i]]++;
			zib[a[i]]++,zib[b[i]]--;
			if(zia[a[i]]==0){
				cnt1--;
				aa--;
			}
			if(zib[b[i]]==0){
				cnt2--;
				bb--;
			}
			if(zia[b[j]]==0){
				aa++;
				cnt1++;
			}
			if(zib[a[j]]==0){
				bb++;
				cnt2++;
			}
			zia[a[j]]--,zia[b[j]]++;
			zib[a[j]]++,zib[b[j]]--;
			if(zia[a[j]]==0){
				aa--;
				cnt1--;
			}
			if(zib[b[j]]==0){
				bb--;
				cnt2--;
			}
			if(cnt1==cnt2)ans++;
			cnt1=cnt1-aa;
			cnt2=cnt2-bb;
			zia[a[i]]++,zia[b[i]]--;
			zib[a[i]]--,zib[b[i]]++;
			zia[a[j]]++,zia[b[j]]--;
			zib[a[j]]--,zib[b[j]]++;			
		}
	}
	cout<<ans%mod;
	return 0;
}