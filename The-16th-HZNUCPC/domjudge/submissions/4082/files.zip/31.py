import math
flag=False
n,m=map(int,input().split())
def fact(n,m):
    if(m==1):
        return True
    elif(m%n==0 or n%m==0):
        return False
    for i in range(2,m):
        if n%i==0:
            return False

if m==1:
    print("YES")
else:
    for i in range(1,m):
        if fact(n,i)==False:
            print("NO")
            flag=True
            break
    if(flag==False):
        print("YES")
