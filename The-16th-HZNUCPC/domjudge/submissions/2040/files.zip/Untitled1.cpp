#include<bits/stdc++.h>
using namespace std;
int haxi[25][25];
int main()
{
	ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n;
    cin>>n;
    while(n--)
    {
    	int nn;
    	int ans;
    	cin>>nn;
    	for (int i=0;i<=20;i++)
		{
			for (int j=0;j<=20;j++)
			{
				if (i==0 || j==0 || i==20||j==20)haxi[i][j]=1;
				else haxi[i][j]=0;
			}
		}
    	while(nn--)
    	{
    		int x,y,shu;
    		cin >>x>>y>>shu;
    		haxi[x][y]=shu;
		}
		ans=0;
		for (int i=1;i<=19;i++)
		{
			for (int j=1;j<=19;j++)
			{
				if (haxi[i][j]==1)
    			{	
    				if (haxi[i][j-1]==0)ans++;
    				if (haxi[i][j+1]==0)ans++;
    				if (haxi[i-1][j]==0)ans++;
    				if (haxi[i+1][j]==0)ans++;
				}
			}
		}
		cout <<ans<<endl;
	}
    return 0;
}