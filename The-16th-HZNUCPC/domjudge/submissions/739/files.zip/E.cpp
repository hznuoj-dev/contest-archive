#include <bits/stdc++.h>
#define ln '\n'

typedef std::array<int,2> Point;

//struct Point{
//	
//};

Point operator -(Point a, Point b) { 
	return {a[0] - b[0], a[1] - b[1]};
}

inline long long calc(Point a) {
	return std::__gcd(abs(a[0]), abs(a[1]));
}

inline bool check(Point a, Point b, Point c) {
	std::vector<Point> f{a, b, c};
	sort(f.begin(), f.end());
	Point a1 = f[1] - f[0];
	int d1 = std::__gcd(a1[0], a1[1]);
	
	Point a2 = f[2] - f[1];
	int d2 = std::__gcd(a2[0], a2[1]);
	
	return d1 != d2;
}

inline void solve() {
//	std::cout << std::__gcd(-2, 4) << ln;
	int n;
	std::cin>>n;
	std::vector<Point> a(n);
	for(int i = 0; i < n; i++) 
		std::cin >> a[i][0] >> a[i][1];
	long long ans = 0;
	
	
	for(int i = 0; i < n; i++) 
		for(int j = i + 1; j < n; j++) 
			for(int k = j + 1; k < n; k++) 
				if(check(a[i], a[j], a[k]))
					ans = std::max(ans, calc(a[i] - a[j]) + calc(a[j] - a[k]) + calc(a[k] - a[i]));
	std::cout << ans << ln;
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	solve();
}