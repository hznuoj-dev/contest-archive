n,m=map(int,input().split())
flag=0
if m==1:
    print('Yes')
elif n%2==0:
    print('NO')
else:
    for i in range(m//2):
        if n%i==0:
            flag=1
            break
if flag:
    print('NO')
else:
    print('YES')