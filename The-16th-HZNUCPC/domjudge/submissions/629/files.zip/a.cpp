//#define DEBUG
#include <bits/stdc++.h>


using namespace std;
#define endl '\n'
const int maxn = 25;   
int T,n,a[maxn][maxn];
int dx[4] = {0,0,1,-1};
int dy[4] = {1,-1,0,0};
void solve() {
    memset(a,0,sizeof a);
    cin >> n;
    for(int i = 1;i <= n;i ++){
        int x,y,z;
        cin >> x >> y >> z;
        a[x][y] = z;
    }
    int ans = 0;
    for(int i = 1;i <= 19;i ++){
        for(int j = 1;j <= 19;j ++){
            if(a[i][j] == 1){
        
                for(int k = 0;k < 4;k ++){
                    int xx = i + dx[k],yy = j + dy[k];
                    if(xx > 19 || xx < 1 || yy > 19 || yy < 1) continue;
                    if(a[xx][yy] == 0) ans++; 
                }
        
            }
        }
    }
    cout << ans << endl;
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    cin >> T;
    while (T--)
    {solve(); }
#ifdef DEBUG
    cerr << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}