n,m=map(int,input().split())
flag=True
if m==1:
    print('Yes')
elif n==1:
    print('YES')
elif m>=n:
    print('NO')
else:
    k=n//2+2
    for i in range(2,k):
        if n%i==0:
            if i >m:
                print('YES')
                break
            else:
                print('NO')
                break
        if i==k-1:
            flag=False
    if not flag :
        print('YES')
    
        