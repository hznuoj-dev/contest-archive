#include <iostream>
using namespace std;
int main(){
	int t,h;
	cin>>t;
	int a,b;
	for(int i1=0;i1<t;i1++)
	{
		int k=1;
		cin>>h;
		for(int i=0;i<h;i++)
		{
			cin>>a>>b;
			if(a==0 && b==0)
			{
				k=0;
			}
		}
		cout<<k<<endl;
	}
}