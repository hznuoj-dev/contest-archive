#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
const int MOD=1e9+7;
#define ll long long 
ll gcd(ll a, ll b)
{
	return b == 0 ? a : gcd(b, a % b);
}
ll a[30], b[30], k[N];
int main()
{
	std::ios::sync_with_stdio(false); 
	cin.tie(0), cout.tie(0);
	string s1, s2;
	int cnt1 = 0, cnt2 = 0, n;
	ll ans=0;
	cin >> s1 >> s2;
	int k[26][26]={0};
	n = s1.size();
	for (int i = 0; i < n; i ++ ) a[s1[i]- 'a'] ++ ;
	for (int i = 0; i < n; i ++ ) b[s2[i]- 'a'] ++ ;
	for (int i = 0; i < n; i ++ )
		k[s1[i]-'a'][s2[i]-'a']++;
	for (int i = 0; i < 26; i ++ ) 
	{
		if (a[i]) cnt1 ++ ;
		if (b[i]) cnt2 ++ ;
	}
	for (int a1 = 0; a1 < 26; a1 ++ ) 
	  	for(int b1 = 0; b1< 26 ; b1++)
      		for (int a2 = 0; a2 < 26; a2 ++ )
	  			for(int b2 = 0 ;b2<26; b2++){
	  				if(a1>a2)continue;
	  				else if(a1==a2){
	  					if(b1>b2)continue;
					  }
	  			a[a1]--;a[a2]--;
	  			b[b1]--;b[b2]--;
	  			b[a1]++;b[a2]++;
	  			a[b1]++;a[b2]++;
	  			if(a[a1]<0||a[a2]<0||b[b1]<0||b[b2]<0){
	  				a[a1]++;a[a2]++;
	  				b[b1]++;b[b2]++;
	  				b[a1]--;b[a2]--;
	  				a[b1]--;a[b2]--;
	  				continue;
				  }
	  			int cnt3=0,cnt4=0;
	  			for(int i=0;i<26;i++){
	  				if(a[i]!=0)cnt3++;
	  				if(b[i]!=0)cnt4++;
				  }
				if(cnt3==cnt4){
					//cout<< a1<<" "<<b1<<" "<<a2<<" "<<b2<<endl;
					if(a1!=a2||b1!=b2){
						ans=(ans+(k[a1][b1]*k[a2][b2])%MOD)%MOD;
					}
					else {
						ans=(ans+(k[a1][b1]*(k[a2][b2]-1)/2)%MOD)%MOD;
					}
				}
				a[a1]++;a[a2]++;
	  			b[b1]++;b[b2]++;
	  			b[a1]--;b[a2]--;
	  			a[b1]--;a[b2]--;
			  }
	cout<<ans<<endl;
	return 0;
}