#include<iostream>
using namespace std;
int main()
{
	long long m,n;
	cin>>n>>m;
	if(n%2==0)
	cout<<"NO"<<endl;
	else
	cout<<"YES"<<endl;
	
}