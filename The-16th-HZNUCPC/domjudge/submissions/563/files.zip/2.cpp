#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=200;
int a[maxn][maxn];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--)
	{
		for(int i=1;i<=19;i++)
		for(int j=1;j<=19;j++)
		{
			a[i][j]=0;	
		}	
		int n;
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			int x,y,v;
			cin>>x>>y>>v;
			a[x][y]=v;
		}
		int cnt=0;
		for(int i=1;i<=19;i++)
		for(int j=1;j<=19;j++)
		{
			if(a[i][j]==1)
			{
				if(i>1)
				{
				if(a[i-1][j]==0)
				{
					cnt++;
				//	a[i-1][j]=3;
				}
				}
				if(i<19)
				{
				if(a[i+1][j]==0)
				{
					cnt++;
					//a[i+1][j]=3;
				}
				}
				if(j>1)
				{
				if(a[i][j-1]==0)
				{
					cnt++;
				//	a[i][j-1]=3;
				}
				}
				if(j<19)
				{
				if(a[i][j+1]==0)
				{
					cnt++;
					//a[i][j+1]=3;
				}
				}
			}
		}
		cout<<cnt<<'\n';
	}	
}