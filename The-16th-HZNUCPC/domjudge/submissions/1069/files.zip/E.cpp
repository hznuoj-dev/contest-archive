#include<iostream>
#include<cmath>

using namespace std;

#define ll long long
const ll MAXN=105;

struct S{
	ll	x,y;
}a[MAXN];

int n;
ll res,ans;

ll 	MAX(ll b, ll c,ll d){
	ll t=-0x7fffffff;
	if(b>t) t=b;
	if(c>t) t=c;
	if(d>t) t=d;
	return t;
}
ll 	MIN(ll b, ll c,ll d){
	ll t=0x7fffffff;
	if(b<t) t=b;
	if(c<t) t=c;
	if(d<t) t=d;
	return t;
}

int main()
{
	cin>>n;
	int p=0;
	for(int i=1;i<=n;i++)
	cin>>a[i].x>>a[i].y;
	ll dx=a[1].x-a[2].x;
	ll dy=a[1].y-a[2].y;
	for(int i=2;i<n;i++)
		{
			ll dx1=a[i].x-a[i+1].x;
			ll dy1=a[i].y-a[i+1].y;
			if(dx*dy1!=dx1*dy) {
				p=1;
				break;
			}
		}
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++)
			{
				ans=0;
				if(abs(a[i].y-a[j].y)>=abs(a[i].x-a[j].x)){
					ans+=abs(a[i].x-a[j].x);
				}
				else if(!(a[i].x-a[j].x)) ans+=abs(a[i].y-a[j].y);
				else{
					ans+=abs(a[i].x-a[j].x)*abs(a[i].y-a[j].y)/abs(a[i].x-a[j].x);
				}
				if(abs(a[k].y-a[j].y)>=abs(a[k].x-a[j].x)){
					ans+=abs(a[k].x-a[j].x);
				}
				else if(!(a[k].x-a[j].x)) ans+=abs(a[k].y-a[j].y);
				else{
					ans+=abs(a[k].x-a[j].x)*abs(a[k].y-a[j].y)/abs(a[k].x-a[j].x);
				}
				if(abs(a[i].y-a[k].y)>=abs(a[i].x-a[k].x)){
					ans+=abs(a[i].x-a[k].x);
				}
				else if(!(a[i].x-a[k].x)) ans+=abs(a[i].y-a[k].y);
				else{
					ans+=abs(a[i].x-a[k].x)*abs(a[i].y-a[k].y)/abs(a[i].x-a[k].x);
				}
			}
			res=max(ans,res);
			}
			if(p)
	cout<<res;
	else {
		cout<<0;
	}
	return 0;
}