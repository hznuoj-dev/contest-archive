#include<bits/stdc++.h>
using namespace std;
#define int long long
#define ll long long
const int N=2e3;
int vis[N][N];
struct node{
	int a,b,sta;
}s[N];
int dir[4][2]={{0,1},{0,-1},{-1,0},{1,0}};
signed main(){
	ll t;
	while(cin>>t){
		while(t--){
			int n;
			memset(vis,0,sizeof vis);
			cin>>n;
			for(int i=0;i<n;i++){
				cin>>s[i].a>>s[i].b>>s[i].sta;
				vis[s[i].a][s[i].b]=1;
			}
			ll sum=0;
			for(int i=0;i<n;i++){
				if(s[i].sta==2)continue;
				for(int j=0;j<4;j++){
					int tx=s[i].a+dir[j][0];
					int ty=s[i].b+dir[j][1];
					if(vis[tx][ty]==0&&tx>=1&&ty>=1&&tx<=19&&ty<=19){
						sum++;
					}
				}
			}
			cout<<sum<<endl;
		}
	}
	return 0;
}