#include <bits/stdc++.h>
using namespace std;
#define ll long long
#define endl '\n'
ll x[110],y[110],n;
// ll gcd(ll a,ll b){
//     if(b==0)return a;
//     return gcd(b,a%b);
// }
ll triangle(ll x1,ll y1,ll x2,ll y2,ll x3,ll y3){
    ll x12=x1-x2;
    ll x23=x2-x3;
    ll y12=y1-y2;
    ll y23=y2-y3;
    if(y12*x23-x12*y23==0){
        return 0;
    }
    else return 1;
}
void solve(){
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>x[i]>>y[i];
    }
    ll ans=0;
    ll flag=0;
    ll maxx=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<i;j++){
            for(int k=1;k<j;k++){
                if(triangle(x[i],y[i],x[j],y[j],x[k],y[k])==0)
                continue;
                else{
                    flag=1;
                    ll ans1=0;
                    ll ans2=0;
                    ll ans3=0;
                    ll x12=abs(x[i]-x[j]);
                    ll y12=abs(y[i]-y[j]);
                    ll x23=abs(x[j]-x[k]);
                    ll y23=abs(y[j]-y[k]);
                    ll x13=abs(x[i]-x[k]);
                    ll y13=abs(y[i]-y[k]);
                    ans1=__gcd(x12,y12);
                    ans2=__gcd(x23,y23);
                    ans3=__gcd(x13,y13);
                    ans=ans1+ans2+ans3;
                    maxx=max(maxx,ans);
                }
            }
        }
    }
    if(flag==0){
        cout<<0<<endl;
    }
    else{
        cout<<maxx<<endl;
    }
}
int main(){
    int t=1;
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    // scanf("%d",&t);
    t=1;
    while (t--)
    {
        solve();
    }
    return 0;
}