#include <iostream>
#include <algorithm>
#include <stack>
#include <cmath>
#include <map>
#include <cstring> 
#define qcin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define endl '\n'
#define int long long
using namespace std;
const int N=100;
int x[N],y[N];
int p[N][N];//point on line point 1 to point 2
signed main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)cin>>x[i]>>y[i];
	int dx ,dy;
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			dy=y[j]-y[i];
			dx=x[j]-x[i];
			int dx1=dx;
			for(int k=2;k<=sqrt(abs(min(dx,dy)))+1;k++){
				while(dx%k==0&&dy%k==0)dx/=k,dy/=k;
			}
			p[i][j]=dx1/dx-1;
			//cout<<i<<" "<<j<<" "<<p[i][j]<<" "<<dy<<" "<<dx<<endl;
		}
	}
	//int ansi,ansj,ansk,
	int mp,ansp=-1;
	double k1,k2;
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{	
				k1=(y[i]-y[j])/(x[i]-x[j]);
				k2=(y[j]-y[k])/(x[j]-x[k]);
				if(k1!=k2)
				{
					mp=p[i][j]+p[i][k]+p[j][k];
					if(mp>ansp) 
					{
						//ansi=i,ansj=j,ansk=k;
						ansp=mp;
					}
				}
				
			}
		}
	}
	cout<<ansp+3;
	return 0;
}