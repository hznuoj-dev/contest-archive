#include<bits/stdc++.h>
using namespace std;
struct point{
	double x;
	double y;
};
double dis(point a,point b){
	return hypot(a.x-b.x,a.y-b.y);
}
signed main()
{
	int n,i,j,k,cnt=0,max1=0,flag=0;
	double b;
	cin>>n;
	point a[n+1];
	for(i=1;i<=n;i++)
		cin>>a[i].x>>a[i].y;
	for(i=1;i<=n-2;i++)
		for(j=i+1;j<=n-1;j++)
			for(k=j+1;k<=n;k++){
				if(dis(a[i],a[j])+dis(a[i],a[k])>dis(a[k],a[j])&&dis(a[i],a[j])+dis(a[j],a[k])>dis(a[k],a[i])&&dis(a[i],a[k])+dis(a[j],a[k])>dis(a[j],a[i]))
				{
					flag=1;
					cnt=0;
				/*	b=1.0*a[i].y-1.0*(a[i].y-a[j].y)/(a[i].x-a[j].x)*a[i].x;
					for(int t1=min(a[i].x,a[j].x);t1<=max(a[i].x,a[j].x);t1++){
						if(t1*1.0*(a[i].y-a[j].y)/(a[i].x-a[j].x)==(int)t1*1.0*(a[i].y-a[j].y)/(a[i].x-a[j].x) && t1*1.0*(a[i].y-a[j].y)/(a[i].x-a[j].x)<=max(a[i].y,a[j].y) &&  t1*1.0*(a[i].y-a[j].y)/(a[i].x-a[j].x)>=min(a[i].y,a[j].y)){
							cnt++;
						}
					}
					b=1.0*a[i].y-1.0*(a[i].y-a[k].y)/(a[i].x-a[k].x)*a[i].x;
					for(int t1=min(a[i].x,a[k].x);t1<=max(a[i].x,a[k].x);t1++){
						if(t1*1.0*(a[i].y-a[k].y)/(a[i].x-a[k].x)==(int)t1*1.0*(a[i].y-a[k].y)/(a[i].x-a[k].x) && t1*1.0*(a[i].y-a[k].y)/(a[i].x-a[k].x)<=max(a[i].y,a[k].y) &&  t1*1.0*(a[i].y-a[k].y)/(a[i].x-a[k].x)>=min(a[i].y,a[k].y)){
							cnt++;
						}
					}
					b=1.0*a[j].y-1.0*(a[j].y-a[k].y)/(a[j].x-a[k].x)*a[j].x;
					for(int t1=min(a[j].x,a[k].x);t1<=max(a[j].x,a[k].x);t1++){
						if(t1*1.0*(a[j].y-a[k].y)/(a[j].x-a[k].x)==(int)t1*1.0*(a[j].y-a[k].y)/(a[j].x-a[k].x) && t1*1.0*(a[j].y-a[k].y)/(a[j].x-a[k].x)<=max(a[j].y,a[k].y) &&  t1*1.0*(a[j].y-a[k].y)/(a[j].x-a[k].x)>=min(a[j].y,a[k].y)){
							cnt++;
						}
					}
					if(cnt>max1)max1=cnt;*/
					cnt=0;
					cnt=cnt+std::__gcd((int)fabs(a[i].x-a[j].x),(int)fabs(a[i].y-a[j].y));
					cnt=cnt+std::__gcd((int)fabs(a[k].x-a[j].x),(int)fabs(a[k].y-a[j].y));
					cnt=cnt+std::__gcd((int)fabs(a[i].x-a[k].x),(int)fabs(a[i].y-a[k].y));
					if(cnt>max1)max1=cnt;
					cnt=0;
					if(a[i].x!=a[j].x && a[i].y!=a[j].y){
						cnt=cnt+std::__gcd((int)fabs(a[i].x-a[j].x),(int)fabs(a[i].y-a[j].y))+1;
					}else{
						cnt=cnt+(int)fabs(a[i].x-a[j].x)+(int)fabs(a[i].y-a[j].y)+1;
					}
					if(a[k].x!=a[j].x && a[k].y!=a[j].y)
						cnt=cnt+std::__gcd((int)fabs(a[k].x-a[j].x),(int)fabs(a[k].y-a[j].y))+1;
					else
						cnt=cnt+(int)fabs(a[k].x-a[j].x)+(int)fabs(a[k].y-a[j].y)+1;
					if(a[k].x!=a[i].x && a[k].y!=a[i].y)
						cnt=cnt+std::__gcd((int)fabs(a[i].x-a[k].x),(int)fabs(a[i].y-a[k].y))+1;
					else
						cnt=cnt+(int)fabs(a[k].x-a[i].x)+(int)fabs(a[k].y-a[i].y)+1;
					cnt=cnt-3;
					if(cnt>max1)max1=cnt;
				}
			}
	if(flag==1)
		cout<<max1;
	else 
		cout<<"0";
	return 0;
}
