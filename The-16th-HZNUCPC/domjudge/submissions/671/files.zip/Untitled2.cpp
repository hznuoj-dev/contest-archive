#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin >> t;
	while(t--) {
		int vis[25][25] = {}, n, cnt = 0;
		cin >> n;
		while(n--) {
			int x, y, c;
			cin >> x >> y >> c;
			if(c == 1) {
				if(vis[x][y]) {
					cnt--;
				}
				vis[x][y] = 1;
				if(x - 1 >= 0) {
					if(vis[x - 1][y] == 0) {
						cnt++;
						vis[x - 1][y] = 1;
					}
				}
				if(y - 1 >= 0) {
					if(vis[x][y - 1] == 0) {
						cnt++;
						vis[x][y - 1] = 1;
					}
				}
				if(x + 1 <= 19) {
					if(vis[x + 1][y] == 0) {
						cnt++;
						vis[x + 1][y] = 1;
					}
				}
				if(y + 1 <= 19) {
					if(vis[x][y + 1] == 0) {
						cnt++;
						vis[x][y + 1] = 1;
					}
				}
			} else if(c == 2) {
				if(vis[x][y]) {
					cnt--;
				}
				vis[x][y] = 1;
			}
		}
		cout << cnt << "\n";
	}
	return 0;
}