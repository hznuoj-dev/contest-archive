#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=1e9+7;
vector<pair<int,int>> vp;
void solve() {
	ll n;
	cin>>n;
	ll m;
	cin>>m;
	if(n==1){
		cout<<"YES"<<endl;
		return;
	}
	if(n<=m) {
		cout<<"NO"<<endl;
		return;
	}
	for(int i=2; i<=sqrt(n)&&i<=m; i++) {
		if(n%i==0) {
			cout<<"NO"<<endl;
			return;
		}
	}
	cout<<"YES"<<endl;
}

int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cout<<fixed<<setprecision(10);
	int t=1;
	cin>>t;
	while(t--) {
		solve();
	}
}