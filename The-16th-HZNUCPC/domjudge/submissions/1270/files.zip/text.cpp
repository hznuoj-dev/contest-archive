#include <bits/stdc++.h>
const int maxn=1e5+5,tt=1e9+7;
int n,an[2],f[30][2],g[30][30];
char a[maxn],b[maxn];
long long ans;
void work(int x,int y){
	--f[x][0];if (!f[x][0]) --an[0];
	++f[y][0];if (f[y][0]==1) ++an[0];
	--f[y][1];if (!f[y][1]) --an[1];
	++f[x][1];if (f[x][1]==1) ++an[1];
}
inline void solve() {
	scanf("%s%s",a+1,b+1);n=strlen(a+1);
	for (int i=1;i<=n;++i){
		f[a[i]-'a'][0]++;
		f[b[i]-'a'][1]++;
	}
	for (int i=0;i<26;++i) an[0]+=(f[i][0]>0),an[1]+=(f[i][1]>0);
	for (int i=1;i<=n;++i){
		if (i>1){
			work(a[i]-'a',b[i]-'a');
			for (int j=0;j<26;++j)
			for (int k=0;k<26;++k){
				work(j,k);
				if (an[0]==an[1]) ans=(ans+g[j][k])%tt;
				work(k,j);
			}
			work(b[i]-'a',a[i]-'a');
		}
		g[a[i]-'a'][b[i]-'a']++;
	}
	printf("%lld\n",ans);
}
int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	solve();
	return 0;
}