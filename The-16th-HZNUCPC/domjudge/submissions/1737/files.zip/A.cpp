#include "bits/stdc++.h"
using namespace std;
int board[25][25];
int n;

int DFS(int x,int y) {
	if (x >= 1 && x <= 19 && y>=1 && y<= 19) {
		if(board[x][y] != 1) {
			return 0;
		}
		board[x][y] = 3;
		int s = 0;
		if (x > 1) {
			if(board[x - 1][y] == 0) {
				s += 1;
				board[x - 1][y] = 4;
			}
		}
		if (x < 19) {
			if(board[x + 1][y] == 0) {
				s += 1;
				board[x + 1][y] = 4;
			}
		}
		if (y > 1) {
			if(board[x][y - 1] == 0) {
				s += 1;
				board[x][y - 1] = 4;
			}
		}
		if (y < 19) {
			if(board[x][y + 1] == 0) {
				s += 1;
				board[x][y + 1] = 4;
			}
		}

		int sum = DFS(x - 1,y) + DFS(x + 1, y) + DFS(x,y-1) + DFS(x,y+1) +s;
		return sum;
	} else {
		return 0;
	}
}

void solve() {
	int sum = 0;
	for(int i = 1; i <= 19; i++) {
		for(int j = 1; j <= 19; j++) {
			sum += DFS(i,j);
//			for(int x = 1; x <= 19; x++) {
//				for(int y = 1; y <= 19; y++) {
//					if(board[x][y] == 4) {
//						board[x][y] = 0;
//					}
//				}
//			}
		}
	}
	printf("%d\n",sum);
}
int main() {
	int T;
	cin >> T;
	for(int i =1; i <= T; i ++) {
		for(int x = 1; x <= 19; x++) {
			for(int y = 1; y <= 19; y++) {
				board[x][y] = 0;
			}
		}
		cin >> n;
		int x,y,c;
		for(int j = 1; j<=n; j++) {
			cin >> x >> y >> c;
			board[x][y] = c;
		}
		solve();
	}
}
