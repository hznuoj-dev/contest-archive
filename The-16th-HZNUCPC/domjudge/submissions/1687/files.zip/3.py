n,m=map(int,input().split())
x=n
if m==1:
    print("YES")
elif n%2==0:
    print("NO")
else:
    while(x>0):
        x=n%m
        m=x
        if m==1:
            break
    if m==1:
        print("YES")
    else:
        print("NO")
