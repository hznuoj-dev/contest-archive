#include<bits/stdc++.h>
using namespace std;

#define ll long long
ll temp[105][105];
pair<int ,int> mp[105];
inline bool check(pair<int,int> a,pair<int,int> b, pair<int,int> c){
	if(a.first == b.first && b.first == c.first) return false;
	if(a.second == b.second && b.second == c.second) return false;
	double k = (c.second - b.second)*1.0/(c.first-b.first)*1.0;
	double q = (a.second - b.second)*1.0/(a.first-b.first)*1.0;
	if(k == q) return false;
	double x = sqrt((a.first - b.first) *(a.first - b.first) + (a.second - b.second) *(a.second - b.second) );
	double y = sqrt((a.first - c.first) *(a.first - c.first) + (a.second - c.second) *(a.second - c.second) );
	double z = sqrt((c.first - b.first) *(c.first - b.first) + (c.second - b.second) *(c.second - b.second) );
	if(x + y < z || x + z < y||z + y < x) return false;
	return true;
}

int main(){
	int n;
	while(cin >>n){
		for(int i = 1;i <= n;i ++){
			cin >> mp[i].first >> mp[i].second;
		}
		for(int i = 1;i <= n;i ++){
			for(int j =1;j <= n;j ++){
				if(i == j) continue;
				int mi_x = min(mp[i].first,mp[j].first);
				int mi_y = min(mp[i].second,mp[j].second);
				int ma_x = max(mp[i].first,mp[j].first);
				int ma_y = max(mp[i].second,mp[j].second);
				if(ma_x - mi_x == 0) {
					temp[i][j] = ma_y - mi_y +1;
				}
				else if(ma_y - mi_y == 0) temp[i][j] = ma_x - mi_x +1;
				else {
					int p = __gcd(int(fabs(ma_y - mi_y)),int(fabs(ma_x - mi_x))) + 1;
					temp[i][j] = p;
				}
				
			}
		}
		ll ans = 0;
		for(int i = 1;i <= n;i ++){
			for(int j = i + 1;j <= n;j ++){
				for (int k = j + 1;k <= n;k ++){
					if(k == i || k == j) continue;
					if(check(mp[i],mp[j],mp[k])){
//						cout << i << " " << j << " " << k <<endl;
						ans = max(ans,temp[i][j] + temp[j][k]+temp[i][k]);
					}
				}
			}
		}
		cout <<max((long long)0,ans-3)<< endl;
	}
	return 0;
}

/*
4
0 0
1 1
2 4
4 2
*/
