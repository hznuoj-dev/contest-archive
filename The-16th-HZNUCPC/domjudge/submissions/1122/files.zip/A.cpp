#include<bits/stdc++.h>
using namespace std;
// #define int long long
typedef pair<int,int>PII;
#define pb push_back
using ll = long long;
int dx[4] = {1, 0, -1, 0};
int dy[4] = {0, 1, 0, -1};
void solve(){
    vector<vector<int>> f(20, vector<int> (20));
    int n;
    vector<vector<bool>> st(20, vector<bool>(20));
    queue<pair<int,int>> q;
    cin >> n;
    for(int i = 1;i <= n;i ++){
        int x, y, op;
        cin >> x >> y >> op;
        f[x][y] = op;
        if(op == 1){
            q.push({x, y});
        }
    }
    ll res = 0;
    while(q.size()){
        auto t = q.front(); q.pop();
        for(int i = 0;i < 4;i ++){
            int sx = t.first + dx[i], sy = t.second + dy[i];
            if(sx < 1 || sy < 1 || sx > 19 || sy > 19) continue;
            if(!f[sx][sy]) res ++;
        }
    }
    cout << res << endl;
    return ;
} 
signed main(){
    int t=1;
    cin >> t;
    while(t--){
        solve();
    }
    return 0;
}