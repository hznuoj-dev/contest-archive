//#include <iostream>
#include<bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'


int n,m;
struct node{
	int x,y;
}p[110];

bool check(node a,node b,node c)
{
	if((a.x*b.y + b.x*c.y + c.x*a.y - a.x*c.y - b.x*a.y - c.x*b.y) > 0)return true;
	return false;
}

int pd(node a,node b)
{
	int x = abs(a.x - b.x);
	int y = abs(a.y - b.y);
	if(__gcd(x,y) != 1 )
	{
		int q1 = x / __gcd(x,y);
		int q2 = y / __gcd(x,y);
//		cout<<x<<" "<<y<<" "<<q<<" "<<__gcd(x,y)<<endl;
//if(q != 0)cout<<x/q - 1 <<" "<<y/q- 1<<endl;

		int p1 = 0 , p2 = 0;
		if(q1 != 0)p1 = x / q1 - 1;
		if(q2 != 0)p2 = y / q2 - 1;
		return max(p1,p2);
	}
	return 0;
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	int t = 1;
//	cin >> t;
	while(t -- ) 
	{
		cin >> n;
		for(int i = 0 ; i < n ; i ++ )
		{
			cin >> p[i].x >> p[i].y;
		}
		int mx = 0;
		for(int i = 0 ; i < n ; i ++ )
		{
			for(int j = 0 ; j < n ; j ++ )
			{
				for(int k = 0 ; k < n ; k ++ )
				{
					if(i != j && j != k && i != k && check(p[i],p[j],p[k]))
					{
						int sum = pd(p[i],p[j]) + pd(p[i],p[k]) + pd(p[j],p[k]);
//						cout<<pd(p[i],p[j])<<" "<<pd(p[i],p[k])<<" "<<pd(p[k],p[j])<<" "<<k<<" "<<i<<endl;
						mx = max(mx,sum + 3);
					}
//					cout<<endl;
				}
			}
		}
		cout<<mx<<endl;
	}
	return 0;
}