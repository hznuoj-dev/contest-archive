#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
inline void run()
{
    cin>>n>>m;
    if(m==1) cout<<"YES"<<'\n';
    else if(n%m==0) cout<<"NO"<<'\n';
    else if(n%(m-1)==0) cout<<"NO"<<'\n';
    else cout<<"YES";
}
int main()
{
//	ll T;
//	cin>>T;
//	while(T--)
	run();
}
