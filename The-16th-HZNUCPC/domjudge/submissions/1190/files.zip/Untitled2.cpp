#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::synbc_with_stdio(flase);cin.tie(0);cout.tie(0)
int dir[4][2]={{0,1},{1,0},{0,-1},{-1,0}};
int s[25][25];
void solve(){

	int t;cin>>t;
	while(t--){
		int n;
		cin>>n;
		memset(s,0,sizeof s);
		while(n--){
			int x,y,l;
			cin>>x>>y>>l;
			s[x][y]=l;
		}
		int ans=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(s[i][j]==1){
					for(int k=0;k<4;k++){
						int tx=i+dir[k][0];
						int ty=j+dir[k][1];
						if(tx>=1&&ty>=1&&tx<=19&&ty<=19&&!s[tx][ty]){
							ans++;
						} 
					}
				}
			}
		}
		cout<<ans<<endl;
	}
}
signed main(){
//	IOS;
	solve();
	return 0;
}