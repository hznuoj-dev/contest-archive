#include<bits/stdc++.h>
using namespace std;
#define M 300005
int n,m,cnt,cnt2,x,ans[M],where[M],where2[M];
struct hzl{
    int t,l,r;
}A[100005],ask[100005];
bool cmp(hzl a,hzl b){
    return a.t<b.t;
}
struct Tree
{
    int mina;
    int lazy;
}SegTree[1200005];
void pushdown(int rt){
    SegTree[rt*2].lazy=min(SegTree[rt].lazy,SegTree[rt*2].lazy);
    SegTree[rt*2].mina=min(SegTree[rt*2].mina,SegTree[rt].lazy);
    SegTree[rt*2+1].lazy=min(SegTree[rt].lazy,SegTree[rt*2+1].lazy);
    SegTree[rt*2+1].mina=min(SegTree[rt*2+1].mina,SegTree[rt].lazy);
    SegTree[rt].lazy=1e6;
    return ;
}
void pushup(int rt)
{
    SegTree[rt].mina=min(SegTree[rt*2].mina,SegTree[rt*2+1].mina);
    SegTree[rt].mina=min(SegTree[rt].mina,SegTree[rt].lazy);
    return;
}
void build(int l,int r,int rt)
{
    SegTree[rt].lazy=1e6;
    if(l==r)
    {
        SegTree[rt].mina=SegTree[rt].lazy=1e6;
        return;
    }
    int mid=(l+r)/2;
    build(l,mid,rt*2);
    build(mid+1,r,rt*2+1);
    pushup(rt);
}
void Update(int l,int r,int L,int R,int C,int rt)
{
    if(l!=r) pushdown(rt);
    if(L>r) return;
    if(R<l) return;
    if(L<=l&&R>=r)
    {
        SegTree[rt].lazy=min(SegTree[rt].lazy,C);
        SegTree[rt].mina=min(SegTree[rt].mina,SegTree[rt].lazy);
        return;
    }
    int mid=(l+r)/2;
    if(L<=mid) Update(l,mid,L,R,C,rt*2);
    if(mid<R) Update(mid+1,r,L,R,C,rt*2+1);
    pushup(rt);
}
int query(int l,int r,int L,int rt)
{
    if(l!=r)pushdown(rt);
    if(l==r)
    {
        return min(SegTree[rt].mina,SegTree[rt].lazy);
    }
    int mid=(l+r)/2;
    if(mid>=L) return query(l,mid,L,rt*2);
    else return query(mid+1,r,L,rt*2+1);
}
void Print(){
    for(int i=1;i<=cnt2;i++)printf("%d ",query(1,cnt2,i,1));
    puts("");
}
int main(){
    scanf("%d%d%d",&n,&m,&x);
    where[++cnt]=x;
    for(int i=1;i<=n;i++){
        scanf("%d%d%d",&A[i].t,&A[i].l,&A[i].r);
        where[++cnt]=A[i].l;
        where[++cnt]=A[i].r;
    }
    sort(A+1,A+n+1,cmp);
    for(int i=1;i<=m;i++){
        scanf("%d%d",&ask[i].t,&ask[i].l);
        where[++cnt]=ask[i].l;
        ask[i].r=i;
    }
    sort(where+1,where+cnt+1);
    for(int i=1;i<=cnt;i++)
        if(where[i]!=where[i-1])where2[++cnt2]=where[i];
    x=lower_bound(where2+1,where2+cnt2+1,x)-where2;
    for(int i=1;i<=m;i++)ask[i].l=lower_bound(where2+1,where2+cnt2+1,ask[i].l)-where2;
    build(1,cnt2,1);
    Update(1,cnt2,x,x,0,1);
    //puts("!!!");
    //Print();
    sort(ask+1,ask+m+1,cmp);
    int now=n;
    for(int i=m;i>=1;i--){ 
        while(A[now].t>=ask[i].t&&now>=1){
            int s=query(1,cnt2,A[now].r,1);
            Update(1,cnt2,A[now].l,A[now].r,s+1,1);
            //printf("%d %d %d\n",A[now].l,A[now].r,s);
            //Print();
            now--;
        }
        ans[ask[i].r]=query(1,cnt2,ask[i].l,1);
        if(ans[ask[i].r]==1e6)ans[ask[i].r]=-1;
    }
    for(int i=1;i<=m;i++)printf("%d\n",ans[i]);
    return 0;
}