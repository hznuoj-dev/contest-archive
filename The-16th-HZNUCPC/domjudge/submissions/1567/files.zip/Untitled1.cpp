#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define eps 1e-8
const int maxn=105;
const int inf=0x3f3f3f3f;
int n,ans=0;
struct point{
	double x,y;
	point(){}
	point(double x,double y):x(x),y(y){}
	point operator - (point B){
		return point(x-B.x,y-B.y);
	}
}p[maxn],pt[maxn];
int sgn(double x){
	if(fabs(x)<eps) return 0;
	else return x<0?-1:1;
}
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
double Cross(point p1,point p2){
	return p1.x*p2.y-p1.y*p2.x;
}
bool dots_inline(point p1,point p2,point p0){
	return sgn(Cross(p1-p0,p2-p0));
}
int grid_onedge(int n,point* p){
	
	int ret=0;
	for(int i=0;i<n;i++){
		ret+=gcd((int)abs(p[i].x-p[(i+1)%n].x),(int)abs(p[i].y-p[(i+1)%n].y));
	}
	return ret;
}
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>pt[i].x>>pt[i].y;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				p[0]=pt[i];
				p[1]=pt[j];
				p[2]=pt[k];
				if(!dots_inline(p[0],p[1],p[2]))  continue;
				ans=max(ans,grid_onedge(3,p));
			}
		}
	}
	cout<<ans;
}