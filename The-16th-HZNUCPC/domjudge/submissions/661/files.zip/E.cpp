#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[111],b[111];
typedef pair<int,int>pii;
ll count(int i,int j){
	ll x,y;
	x=abs(a[i]-a[j]);
	y=abs(b[i]-b[j]);
	if(x==0) return abs(b[i]-b[j]);
	if(y==0) return abs(a[i]-a[j]);
	return __gcd(x,y);
}
void kaibai(){
	int n,i,j,k,ans=0;
	ll x1,x2,y1,y2;
	ll x,mx=0;
	cin>>n;
	for(i=1;i<=n;i++){
		scanf("%d%d",a+i,b+i);
	}
	for(i=1;i<=n;i++){
		for(j=i+1;j<=n;j++){
			for(k=j+1;k<=n;k++){
				x1=a[i]-a[j];
				x2=a[j]-a[k];
				y1=b[i]-b[j];
				y2=b[j]-b[k];
				if(x1*y2==x2*y1) continue;
				x=0;
				x+=count(i,j);
				x+=count(i,k);
				x+=count(j,k);
				mx=max(mx,x);
			}
		}
	}
	printf("%lld",mx);
}
int main(void){
	int T=1;
//	cin>>T;
	while(T--){
		kaibai();
	}
}