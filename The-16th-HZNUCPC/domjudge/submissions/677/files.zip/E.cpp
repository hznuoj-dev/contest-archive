#include<bits/stdc++.h>
#define ll long long
#define y1 y_1

int gcd ( int n, int m ) {
	return !m ? n : gcd ( m, n % m );
}

int x[105], y[105];

inline ll cal ( int i, int j ) {
	int x1 = x[i], x2 = x[j], y1 = y[i], y2 = y[j];
	return gcd ( abs ( x1 - x2 ), abs ( y1 - y2 ) );
}

signed main() {
	int n; scanf ( "%d", &n ); ll ans = 0;
	for ( int i = 1 ; i <= n ; i++ ) scanf ( "%d%d", &x[i], &y[i] );
	for ( int i = 1 ; i <= n ; i++ ) for ( int j = i + 1 ; j <= n ; j++ ) for ( int k = j + 1 ; k <= n ; k++ ) {
		ll res;
		ll x1 = x[j] - x[i], x2 = x[k] - x[j], y1 = y[j] - y[i], y2 = y[k] - y[j];
		if ( x1 * y2 == x2 * y1 ) continue;
		else res = cal ( i, j ) + cal ( j, k ) + cal ( i, k );
		ans = std::max ( ans, res );
	} printf ( "%lld\n", ans );
}