#include <iostream>
#include <vector>
#include <cstring>
#define x first
#define y second
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
typedef long long ll;
ll n,m;

int main() {
	
	cin>>n>>m;
	bool f=true;
	
	if(n==1||m==1){
		cout<<"YES";
		return 0;
	}
	bool ok=1;
	long long find = -1;
	long long i;
	for(i=2;i*i<=n;i++)
	{
		if(n%i==0)
		{
		   find=i;
		   break;
			
		}
	}
	if(find==-1)
      find=n;
	if(find<=m)
	{
		ok=0;
	}
	if(ok==1)
	{
		cout<<"YES";
		return 0;
	}
    else
	{
		cout<<"NO";
		return 0;
	}
	/*
	while(m!=1)
	{
		if(n<=m)
		{
			f=false;
			break;
		}
		if(n%m==0)
		{
			f=false;
			break;
		}
		m= n%m;
		cout << m << endl;
	}	
    */


	
}