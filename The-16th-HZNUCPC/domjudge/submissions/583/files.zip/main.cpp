#include <iostream>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;


int main()
{
    int long long n,m;
    cin>>n>>m;
    while (m>=sqrt(n))
    {
        if(n%m==0){
            cout<<"NO";
            return 0;
        }
        m--;
    }
     cout<<"YES";
    return 0;
}