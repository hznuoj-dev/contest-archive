#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll,ll> pii;
const int N=100005;
int fa[N],n,q,m;
vector<pii> v;
vector<int> ans;
map<int,int> mp;
vector<int> children[N];
int find(int now){
	if(fa[now]==now)
		return now;
	fa[now]=find(fa[now]);
	return fa[now];
}
void merge(int x,int y){
	fa[find(x)]=find(y);
}
bool dfs(int p,ll sum){
	if(sum>q||p>v.size()){
		return false;
	}
	if(sum==q){
		return true;
	}
	if(p>=v.size())return false;
	ans.push_back(v[p].second);
	if(dfs(p+1,sum+v[p].first))return true;
	ans.pop_back();
	if(dfs(p+1,sum))return true;
	return false;
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>n>>q>>m;
	for(int i=1;i<=n;i++)
		fa[i]=i;
	vector<int> opt(m+1),x(m+1),y(m+1);
	for(int i=1;i<=m;i++){
		cin>>opt[i]>>x[i]>>y[i];
		if(opt[i]==0)
			merge(x[i],y[i]);
	}
	for(int i=1;i<=m;i++){
		if(opt[i]==1&&find(x[i])==find(y[i])){
			cout<<"NO";
			return 0;
		}
	}
	
	for(int i=1;i<=n;i++){
		mp[find(i)]++;
		children[find(i)].push_back(i);
	}
		

	for(auto x:mp){
		v.push_back({x.second,x.first});
	}
	sort(v.begin(),v.end());
	if(!dfs(0,0))cout<<"NO";
	else{
		cout<<"YES\n";
		for(auto x:ans){
			for(auto y:children[x]){
				cout<<y<<' ';
			}
		}
	}
}