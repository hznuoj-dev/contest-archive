#include<iostream>
using namespace std;
int main(){
	long long n,m;
	cin >> n >> m;
	if(n == 1 || m == 1){
		cout << "NO";
	}else if(n <= m){
		cout << "NO";
	}else {
		long long yz = 1e9;
		if(n % 2 == 0){
			cout << "NO";
		}else {
			for(int i = 3 ; i * i < n ; i ++){
				if(n % i == 0){
					yz = i;
					break;
				}
			}
			if(yz == 1e9){
				yz = n;
			}
//			cout << yz << endl;
//			long long x = min(n / 2 , m);
			if(yz <= x){
				cout << "NO";
			}else {
				cout << "YES";
			}
		}
	}
	return 0;
}