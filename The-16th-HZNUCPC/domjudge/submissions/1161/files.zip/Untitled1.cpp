#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdio>
#include<queue>
#include<map>
#include<vector>
#define int long long
#define FOR(i,m,n) for(int i = m;i <= n;i++)
#define CLR(arr,value) memset(arr,value,sizeof arr)
using namespace std;
const int N = 0x3f3f3f;
int tt,n,k;
const int pp = 25;
int a[pp][pp],x[365],y[365],c[365];
bool vis[pp][pp];
int dx[] = {-1,1,0,0};
int dy[] = {0,0,-1,1};
int cnt = 0;
bool f;
signed main()
{
	cin >> n >> k;
	bool f = 0;
	while(true)
	{
		k = n % k;
		if(k == 1)
		{
			f = 1;
			break;
		}
		if(k == 0)
		{
			f = 0;
			break;
		}
	}
	if(f) puts("YES");
	else puts("NO");
}