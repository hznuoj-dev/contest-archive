import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner in=new Scanner(System.in);
		while(in.hasNext()){
			int xxx=in.nextInt();
			for(int iiii=1;iiii<=xxx;iiii++){
				int[][] map=new int[20][20];
				int geshu=in.nextInt();
				for(int i=1;i<=geshu;i++){
					map[in.nextInt()][in.nextInt()]=in.nextInt();
				}
				int sum=0;
				for(int x=1;x<=19;x++){
					for(int y=1;y<=19;y++){
						if(map[x][y]==1){
							if(x-1>=1&&map[x-1][y]==0)sum++;
							if(x+1<=19&&map[x+1][y]==0)sum++;
							if(y-1>=1&&map[x][y-1]==0)sum++;
							if(y+1<=19&&map[x][y+1]==0)sum++;
						}
					}
				}
				System.out.println(sum);
			}
		}
	}

}
