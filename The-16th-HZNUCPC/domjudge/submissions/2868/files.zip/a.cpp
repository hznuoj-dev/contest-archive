#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
const int maxn=1e5+5;
char c1[maxn],c2[maxn];
int ct[30][30];
int cnt[5][30];
int ans[5];

void add(int type,int num)
{
    cnt[type][num]++;
    if(cnt[type][num]==1) ans[type]++;
}

void dec(int type,int num)
{
    cnt[type][num]--;
    if(cnt[type][num]==0) ans[type]--;
}

void sol()
{
    cin>>c1+1>>c2+1;
    int n=strlen(c1+1);
    for(int i=1;i<=n;i++)
    {
        int num1=c1[i]-'a'+1,num2=c2[i]-'a'+1;
        add(1,num1);
        add(2,num2);
    }
    int anss=0;
    for(int i=1;i<=n;i++)
    {
        int num1=c1[i]-'a'+1,num2=c2[i]-'a'+1;
        dec(1,num1),add(1,num2);
        dec(2,num2),add(2,num1);
        for(int j=1;j<=26;j++)
        {
            for(int k=1;k<=26;k++)
            {
                dec(1,j),add(1,k);
                dec(2,k),add(2,j);
                if(ans[1]==ans[2]) (anss+=ct[j][k])%=mod;
                add(1,j),dec(1,k);
                add(2,k),dec(2,j);
            }
        }
        add(1,num1),dec(1,num2);
        add(2,num2),dec(2,num1);
        ct[num1][num2]++;
    }
    cout<<anss<<endl;
}

int main()
{
    int t=1;
    while(t--) sol();
    return 0;
}
