#include<bits/stdc++.h>
#define int long long
#define fs first
#define sc second
using namespace std;
const int N=1e5+5,M=1e6+5;
int n,m,T;
pair<double,double> a[105];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin >> n;
	for (int i=0;i<n;i++){
		cin >> a[i].fs >> a[i].sc;
	}
	set<pair<double,double>> se;
	for (int i=0;i<n;i++){
		for (int j=0;j<i;j++){
			if (a[i].fs==a[j].fs){
				se.insert({90,-a[i].fs});
			//	cout << 90<<' '<< -a[i].fs << '\n';
				continue;
			}
			double k=(a[i].sc-a[j].sc)/(a[i].fs-a[j].fs);
			double c=k*a[i].fs-a[i].sc;
		//	cout << k <<' '<<c << '\n';
			se.insert({k,c});
		}
	}
	int ans=se.size();
	if (ans<3) ans=0;
	cout << ans<<'\n';
	return 0;
}
/*
4
0 0
1 1
2 4
4 2

4
1 1
2 2
3 3
2 4

4
0 0
0 3
1 1
1 2

6
0 0 
0 1
0 2 
0 3
0 4
0 5
*/
