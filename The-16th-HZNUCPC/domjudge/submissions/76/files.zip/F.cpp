#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;
#define quick_cin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define rep1(i,a,n) for(int i=(a);i<(n);++i)
#define rep2(i,a,n) for(int i=(a);i<=(n);++i)
#define per1(i,n,a) for(int i=(n);i>(a);--i)
#define per2(i,n,a) for(int i=(n);i>=(a);--i)
#define endl "\n"
typedef long long LL;
#define int LL
int n,m;
signed main ()
{
	quick_cin();
	
	cin>>n>>m;
	while(1)
	{
		//cout<<n<<" "<<m<<endl;
		if(m==1)
		{
			cout<<"YES";
			return 0;
		}
		if(n%m==0)
		{
			cout<<"NO";
			return 0;
		}
		int yu=n%m;
		m=yu;
	}
	return 0;
}