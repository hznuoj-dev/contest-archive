#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int main()
{
    ll n,m;
    cin>>n>>m;
    if (n<=m) cout << "NO" << endl;
    else if (__gcd(n,m)==1) cout << "YES" <<endl;
    else cout <<"NO"<<endl;
    return 0;
}
