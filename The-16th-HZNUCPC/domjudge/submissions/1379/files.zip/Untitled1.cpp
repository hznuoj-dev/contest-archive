#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,ans;
	cin>>n>>m;
	if(m==1){
		cout<<"YES"<<'\n';
		return 0;
	}
for(int i=1;i<=m;i++){
		ans=n%m;
		m=ans;
		if(ans==1){
			cout<<"YES"<<'\n';
			return 0;
		}
		if(ans==0){
			cout<<"NO"<<'\n';
			return 0;
}
		}
	
}