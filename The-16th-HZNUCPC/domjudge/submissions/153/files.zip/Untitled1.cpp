#include "iostream"
using namespace std;
long long a,b,c,d,e,f;
int main(){
	while(cin>>a>>b){
		c=0;
		for(int i=b;i>1;i--){
			if(a%i==0){
				cout<<"NO"<<endl;
				c=1;
				break;
			}
		}
		if(c==0){
			cout<<"YES"<<endl;
		}
	}
	return 0;
}