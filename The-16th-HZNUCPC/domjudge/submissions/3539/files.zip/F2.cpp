#include<bits/stdc++.h>
using namespace std;
int main(){
	int  flag=0;
	long long int n,m;
	cin>>n>>m;
	for(int i=1;i<=9;i++){
		if(i*n%m==1){
			flag=1;
			break;
		}
	}
	if(flag){
		cout<<"YES";
	}
	else cout<<"NO";
}
