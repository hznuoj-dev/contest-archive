#include<bits/stdc++.h>
using namespace std;
int flg[30][30];
int sto[1000][2];
int jdg(int x,int y){
    if(x<=0 || x>=20 ||y<=0||y>=20)return 0;
    if(flg[x][y])return 0;
    return 1;
}
int main(){
    int _T;
    scanf("%d",&_T);
    while(_T--){
        memset(flg,0,sizeof(flg));
        int n,stlen=0,ans=0;
        int x,y,t;
        scanf("%d",&n);
        while(n--){
            scanf("%d%d%d",&x,&y,&t);
            flg[x][y]=1;
            if(t==1){
                sto[stlen][0]=x;
                sto[stlen++][1]=y;
            }
        }
        while(stlen--){
            x=sto[stlen][0];
            y=sto[stlen][1];
            ans+=jdg(x-1,y);
            ans+=jdg(x,y-1);
            ans+=jdg(x+1,y);
            ans+=jdg(x,y+1);
        }
        printf("%d\n",ans);
    }
    return 0;
}