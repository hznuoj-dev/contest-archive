
#include <iostream>
using namespace std;
int main()
	{
	int a[21][21],i,j,n,t,x[10000],y[10000],c[10000],h;
	cin>>n;
	while(n>0)
	{
		n--;
		cin>>t;
		h=0;
		for(i=0;i<21;i++)
		{
			for(j=0;j<21;j++)
				{
					a[i][j]=0;
				}
		}
		for(i=0;i<t;i++)
		{
			cin>>x[i]>>y[i]>>c[i];
			a[x[i]][y[i]]=c[i];
		}
		for(i=0;i<t;i++)
		{
			if(c[i]==1)
			{
				if(a[x[i]+1][y[i]]==0&&x[i]<19)
				{
					h++;
				}
				if(a[x[i]-1][y[i]]==0&&x[i]>1)
				{
					h++;
				}
				if(a[x[i]][y[i]+1]==0&&y[i]<19)
				{
					h++;
				}
				if(a[x[i]][y[i]-1]==0&&y[i]>1)
				{
					h++;
				}
			}
		}
		cout<<h<<"\n";
	}
}