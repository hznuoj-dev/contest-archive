//#include <iostream>
#include<bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'

int n,m;

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	int t = 1;
//	cin >> t;
	while(t -- ) {
		cin >> n >> m;
		if(n % 2 != 0 && __gcd(n,m) == 1 && n > m)cout<<"YES"<<endl;
		else cout<<"NO"<<endl;

	}


}