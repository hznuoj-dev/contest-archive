#include<bits/stdc++.h>

using namespace std;

const int MAXN = 5e3 + 10;

char Ma[MAXN * 2];
int Mp[MAXN * 2];

int manachar(char s[], int len) {
	for (int i = 0; i <= len*2 + 2; i ++)
		Mp[i] = 0;
	memset(Ma, ' ', sizeof Ma);
	int l = 0;
	Ma[l ++] = '$';
	Ma[l ++] = '#';
	for (int i = 0; i < len; i ++) {
		Ma[l ++] = s[i];
		Ma[l ++] = '#';
	}	
	Ma[l] = 0;
	int mx = 0, id = 0;
	for (int i = 0; i < l; i ++){
		Mp[i] = mx>i?min(Mp[2*id-i], mx-i) : 1;
		int f = 0, ff = 0, tmp;
		char t1, t2;
		while (1) {
			if (Ma[i + Mp[i]] == '#' && Ma[i - Mp[i]] == '$') break; 
			if (Ma[i + Mp[i]] == Ma[i - Mp[i]]) {
				Mp[i] ++; continue;
			} else {
				if (ff) {
					//cout << 66 << '\n';
					break;
				}
				if (f == 0) {
					f = 1;
					t1 = Ma[i + Mp[i]], t2 = Ma[i - Mp[i]];
					tmp = Mp[i];
					Mp[i] ++; 
				} else if (f == 1) {
					if (t1 == Ma[i - Mp[i]] && t2 == Ma[i + Mp[i]] || t1 == Ma[i + Mp[i]] && t2 == Ma[i - Mp[i]])  {
						ff = 1;
						Mp[i] ++; 
					} else {
						Mp[i] = tmp; 
						//cout << i - Mp[i] << ' ' << i + Mp[i]<< "\n";
						break;
					}
				}
			}
		} 
		if (i + Mp[i] > mx) {
			mx = i + Mp[i];
			id = i;
		}
		
	}
	int ans = 0;
	for (int i = 0; i < 2 * len + 2; i ++)
		ans = max(ans, Mp[i] - 1);
	return ans;
}


signed main() {
	int t; cin >> t;
	while (t --) {
		char s[5010];
		cin >> s;
		int t = manachar(s, strlen(s));
		if (t == 1) {
			cout << 0 << '\n';
		} else cout << t << '\n';
		//cout << manachar(s, strlen(s)) << '\n';
	}
}