#include <bits/stdc++.h>
using namespace std;

bool judge(long long x){
	for(long long i = 2; i * i <= x; ++i){
		if(x % i == 0)return false;
	}
	return true;
}
long long get(long long x){
	for(long long i = 2; i * i <= x; ++i){
		if(x % i == 0)return i;
	}
	return x;
}

int main(){
	long long n, m;
	cin >> n >> m;
	if(m == 1 || n == 1){
		printf("YES\n");
	}
	else if(n <= m){
		printf("NO\n");
	} else {
		if(judge(n))printf("YES\n");
		else {
			if(get(n) > m) printf("YES\n");
			else printf("NO\n");
		}
	}
	
}