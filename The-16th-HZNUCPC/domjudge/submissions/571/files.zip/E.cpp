#include <bits/stdc++.h>
using namespace std;


const int N = 110;

int n;
int x[N];
int y[N];

int gcd(int a, int b)
{
    if(!b) return a;
    return gcd(b, a % b);
}

int check(int i, int j)
{

    int xx = abs(x[i] - x[j]);
    int yy = abs(y[i] - y[j]);
    return gcd(xx, yy);
}

int get(int i, int j, int k)
{
    return check(i, j) + check(i, k) + check(j, k);
}

bool vis(int i, int j, int k)
{
    if(1ll * (1ll * x[i] - x[j]) * (y[j] - y[k]) == 1ll * (1ll *y[i] - y[j]) * (x[j] - x[k])) return false;
}

int main()
{
    int ans = 0;
    scanf("%d", &n);
    for (int i = 1; i <= n; i ++)
        scanf("%d%d", &x[i], &y[i]);
    for (int i = 1; i <= n; i ++)
    {
        for (int j = i + 1; j <= n; j ++)
        {
            for (int k = j + 1; k <= n; k ++)
            {
                if(vis(i, j, k))
                ans = max(ans, get(i, j, k));
            }
        }}

    cout << ans << '\n';

}
