#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[26][26];
int c[26];
int d[26];
void kaibai(){
	ll n,i,j,m,ans=0,x,y,c1,c2,cnt,mod=1e9+7,I=5e8+4;
	string s,t;
	cin>>s>>t;
	n=s.length();
	for(i=0;i<n;i++){
		x=s[i]-'a';
		y=t[i]-'a';
		a[x][y]++;
		c[x]++;
		d[y]++;
	}
	c1=c2=0;
	for(i=0;i<26;i++){
		if(c[i]) c1++;
	}
	for(i=0;i<26;i++){
		if(d[i]) c2++;
	}
	for(i=0;i<26;i++){
		for(j=0;j<26;j++){
			for(int p=0;p<26;p++){
				for(int q=0;q<26;q++){
					cnt=c1-c2;
					c[i]--;
					if(c[i]==0) cnt--;
					c[j]++;
					if(c[j]==1) cnt++;
					d[j]--;
					if(d[j]==0) cnt++;
					d[i]++;
					if(d[i]==1) cnt--;
					c[p]--;
					if(c[p]==0) cnt--;
					c[q]++;
					if(c[q]==1) cnt++;
					d[q]--;
					if(d[q]==0) cnt++;
					d[p]++;
					if(d[p]==1) cnt--;
					
					
					c[i]++;
					c[j]--;

					d[j]++;
					d[i]--;
					c[p]++;
					c[q]--;
					d[q]++;
					d[p]--;
					if(cnt==0){
						x=a[i][j];
						y=a[p][q];
						if(i==p&&j==q) ans=(ans+x*(x-1)%mod*I%mod)%mod;
						else ans=(ans+x*y%mod*I%mod)%mod;
					}
				}
			}
		}
	}
	printf("%lld",ans);
}
int main(void){
	int T=1;
	//scanf("%d", &T);
	while(T--){
		kaibai();
	}
}