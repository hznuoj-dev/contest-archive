#include <bits/stdc++.h>

using i64 = long long;
using pii = std::pair<int, int>;

void solve() {
	int n;
	std::cin >> n;
	
	std::vector<pii> p;
	std::set<pii> S;
	for (int i = 0; i < n; i++) {
		int x, y, t;
		std::cin >> x >> y >> t;
		
		S.insert({x, y});
		
		if (t == 1) {
			p.push_back({x, y});
		}
	}

    int mx[] = {0, 1, 0, -1}, my[] = {1, 0, -1, 0};

    int ans = 0;

    for (auto[x, y] : p) {
        for (int i = 0; i < 4; i++) {
            int tx = x + mx[i], ty = y + my[i];
            if (tx <= 0 || tx > 19 || ty <= 0 || ty > 19 || S.count({tx, ty})) {
                continue;
            }
            ans++;
        }
    }

    std::cout << ans << "\n";
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int t;
	std::cin >> t;
	
	while(t--) solve();	
	
	return 0;
}