import sys
input = lambda: sys.stdin.readline().strip()
def func():
    n,q,m = map(int,input().split())
    has = [[[],[]] for _ in range(n+1)]
    for _ in range(m):
        a = list(map(int,input().split()))
        if a[0] == 0:
            has[a[1]][0].append(a[2])
            has[a[2]][0].append(a[1])
        else:
            has[a[1]][1].append(a[2])
            has[a[2]][1].append(a[1])
    rep = [0]*(n+1)
    ans = []
    for i in range(1,n+1):
        if rep[i]:continue
        lin = [0,[i],[]]
        rep[i] = 1
        res = [i]
        while res:
            p = res.pop()
            if has[p][0]:
                for i in has[p][0]:
                    if rep[i] == 0:
                        rep[i] = rep[p]
                        lin[rep[p]].append(i)
                        res.append(i)
                    if rep[i] != rep[p]:return False
            if has[p][1]:
                for i in has[p][1]:
                    if rep[i] == 0:
                        lin[3-rep[p]].append(i)
                        rep[i] = 3-rep[p]
                        res.append(i)
                    if rep[i] == rep[p]:return False
        ans.append(lin[1:])
    dp = {0:[]}
    rep = [0]*(p+1)
    res = [0]
    for i,j in ans:
        lin = []
        for x in res:
            v = dp[x]
            if i and x+len(i) <= q:
                dp[x+len(i)] = v+i
                lin.append(x+len(i))
            if j and x+len(j) <= q:
                dp[x+len(j)] = v+j
                lin.append(x+len(j))
        res = lin
    if q not in dp:return False
    return dp[q]
        

res = func()
if res == False:
    print('NO')
else:
    print('YES')
    print(*res)

