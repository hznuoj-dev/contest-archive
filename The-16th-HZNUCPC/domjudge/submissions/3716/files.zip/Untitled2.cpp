#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
		ll n,m,x;
		scanf("%lld %lld",&n,&m);
		if(n==1||m==1) cout<<"YES";
		else if(n<=m) cout<<"NO";
		else{
			int flag=0;
			while(1){
				x=n%m;
				if(x==1){
					flag=1;break;
				}
				else if(x==0){
					break;
				}
				else{
					m=x;
				}
			}
			if(flag) cout<<"YES";
			else cout<<"NO";
		}
	return 0;
}