#include<bits/stdc++.h>
using namespace std;
void solve()
{
	long long int n,m;
	cin >> n >> m;
	if (m==1 || n==1)
	{
		cout << "YES" << endl;
		return;	
	}
	int zc;
	int c=sqrt(m);
	for (int i=2;i<=c;i++)	
	{
		int flag=0;
		for (int j=2;j<i;j++)
		{
			if (i%j==0)
			{
				flag=1;
				break;
			}
		}
		if (flag==0)
		{
			zc=i;
			break;
		}
	}
	if (zc<=m)
	{
		cout << "NO" << endl;
		return ;
	}
}
int main()
{
	solve();
	return 0;
}