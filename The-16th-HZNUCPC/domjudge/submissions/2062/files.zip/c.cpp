#include <iostream>
#include <algorithm>
#include <vector>
#include <map>
using namespace std;
using ll = long long;
using pll = pair<ll, ll>;
bool judge(char a, char b, char c, char d)
{
    map<char, int> m;
    m[a] += 1;
    m[b] += 1;
    m[c] += 1;
    m[d] += 1;
    if (m.size() != 2)
        return false;
    for (auto it : m)
    {
        if (it.second != 2)
            return false;
    }
    return true;
}
void solve()
{
    string s;
    cin >> s;
    int n = s.length();
    int mx = 0;
    for (int i = 0; i < n; i++)
    {
        int l = i, r = i;
        mx = max(r - l + 1, mx);
        int cnt = 0;
        int x, y;
        bool use = false;
        while (1)
        {
            l -= 1, r += 1;
            if (l < 0 || r >= n)
                break;
            if (s[l] != s[r])
            {
                if (use)
                {
                    break;
                }
                if (!cnt)
                {
                    x = l, y = r;
                    cnt = 1;
                }
                else if (cnt == 1)
                {
                    if (judge(s[x], s[y], s[l], s[r]))
                    {
                        use = true;
                        cnt = 2;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (cnt != 1)
            {
                mx = max(mx, r - l + 1);
            }
        }
        l = i + 1, r = i;
        cnt = 0;
        x, y;
        use = false;
        while (1)
        {
            l -= 1, r += 1;
            if (l < 0 || r >= n)
                break;
            if (s[l] != s[r])
            {
                if (use)
                {
                    break;
                }
                if (!cnt)
                {
                    x = l, y = r;
                    cnt = 1;
                }
                else if (cnt == 1)
                {
                    if (judge(s[x], s[y], s[l], s[r]))
                    {
                        use = true;
                        cnt = 2;
                    }
                    else
                    {
                        break;
                    }
                }
            }
            if (cnt != 1)
            {
                mx = max(mx, r - l + 1);
            }
        }
    }
    if (mx == 1) mx = 0;
    cout << mx << '\n';
}
int main()
{
    int t;
    cin >> t;
    while (t--)
    {
        solve();
    }
}
