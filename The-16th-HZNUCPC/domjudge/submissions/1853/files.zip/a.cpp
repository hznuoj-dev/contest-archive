#include<bits/stdc++.h>

#define ll long long

using namespace std;

int dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int s[25][25];
bool vis[25][25];

int dfs1(int x,int y){
	int ans=0;
	vis[x][y]=1;
	for(int i=0;i<4;i++)
	{
		int tx=dir[i][0]+x;
		int ty=dir[i][1]+y;
		if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
		{
			if(s[tx][ty]==0)
			{
				ans++;
			}
			else if(s[tx][ty]==1&&vis[tx][ty]==0)
			{
				ans+=dfs1(tx,ty);
			}
		}
	}
	return ans;
}

int dfs2(int x,int y){
	int ans=0;
	vis[x][y]=1;
	for(int i=0;i<4;i++)
	{
		int tx=dir[i][0]+x;
		int ty=dir[i][1]+y;
		if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
		{
			if(s[tx][ty]==0)
			{
				ans++;
				vis[tx][ty]=1;
			}
			else if(s[tx][ty]==2&&vis[tx][ty]==0)
			{
				ans+=dfs2(tx,ty);
			}
		}
	}
	return ans;
}

void gone1(int x,int y){
	s[x][y]=0;
	for(int i=0;i<4;i++)
	{
		int tx=dir[i][0]+x;
		int ty=dir[i][1]+y;
		if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
		{
			if(s[tx][ty]==1)
			{
				gone1(tx,ty);
			}
		}
	}
	return ;
}

void gone2(int x,int y){
	s[x][y]=0;
	for(int i=0;i<4;i++)
	{
		int tx=dir[i][0]+x;
		int ty=dir[i][1]+y;
		if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
		{
			if(s[tx][ty]==2)
			{
				gone2(tx,ty);
			}
		}
	}
	return ;
}

int main()
{
	int T;
	while(~scanf("%d",&T))
	{
		while(T--)
		{
			memset(vis,0,sizeof(vis));
			memset(s,0,sizeof(s));
			int n;
			int res=0;
			scanf("%d",&n);
			for(int i=0;i<n;i++)
			{
				int x,y,z;
				scanf("%d %d %d",&x,&y,&z);
				if(s[x][y]!=0)
				{
					continue;
				}
				s[x][y]=z;
				if(z==1)
				{
					bool key=true;
					int sum=0;
					memset(vis,0,sizeof(vis));
					for(int j=0;j<4;j++)
					{
						int tx=x+dir[j][0];
						int ty=y+dir[j][1];
						if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
						{
							if(s[tx][ty]==2&&vis[tx][ty]==0)
							{
								if(dfs2(tx,ty)==0)
								{
									gone2(tx,ty);
								}
							}
						}
					}
					memset(vis,0,sizeof(vis));
					for(int j=0;j<4;j++)
					{
						int tx=x+dir[j][0];
						int ty=y+dir[j][1];
						if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
						{
							if(s[tx][ty]==0)
							{
								sum++;
							}
							else if(s[tx][ty]==1&&vis[tx][ty]==0)
							{
								int k=dfs1(tx,ty);
								if(k==0)
								{
									key=false;
									break;
								}
								else
								{
									sum+=k;
								}
							}
						}
					}
					if(key==false||sum==0)
					{
						s[x][y]=0;
					}
				}
				else if(z==2)
				{
					bool key=true;
					int sum=0;
					memset(vis,0,sizeof(vis));
					for(int j=0;j<4;j++)
					{
						int tx=x+dir[j][0];
						int ty=y+dir[j][1];
						if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
						{
							if(s[tx][ty]==1&&vis[tx][ty]==0)
							{
								if(dfs1(tx,ty)==0)
								{
									gone1(tx,ty);
								}
							}
						}
					}
					memset(vis,0,sizeof(vis));
					for(int j=0;j<4;j++)
					{
						int tx=x+dir[j][0];
						int ty=y+dir[j][1];
						if(tx>=1&&tx<=19&&ty>=1&&ty<=19)
						{
							if(s[tx][ty]==0)
							{
								sum++;
							}
							else if(s[tx][ty]==2&&vis[tx][ty]==0)
							{
								int k=dfs2(tx,ty);
								if(k==0)
								{
									key=false;
									break;
								}
								else
								{
									sum+=k;
								}
							}
						}
					}
					if(key==false||sum==0)
					{
						s[x][y]=0;
					}
				}
//				
				for(int i=1;i<=19;i++)
				{
					for(int j=1;j<=19;j++)
					{
						cout<<s[i][j]<<" ";
					}
					cout<<endl;
				}
			}
			memset(vis,0,sizeof(vis));
			for(int i=1;i<=19;i++)
			{
				for(int j=1;j<=19;j++)
				{
					if(s[i][j]==1&&vis[i][j]==0)
					{
						res+=dfs1(i,j);
					}
				}
			}
			printf("%d\n",res);
		}
	}
	return 0;
}
