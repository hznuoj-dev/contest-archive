#include <bits/stdc++.h>

using namespace std;
using ll=long long;

int n,q,m,parent[100005],e[100005],p=0,num[100005],len,back[100005],sum,target;
pair<int,int>q_1[100005];
vector<int> v;
bool in[100005],choose[100005],chose[100005];
int find(int a){
	return parent[a]==a?a:(parent[a]=find(parent[a]));
}

void union_(int a,int b){
	parent[find(a)]=find(b);
}

bool dfs(int now,int s){
	if(s==target)return true;
	if(now==len)return s==target;
	if(s+back[now]<target)return false;
	choose[now]=true;
	int tmp;
	if(e[v[now]]==0)tmp=num[v[now]];
	else tmp=abs(num[v[now]]-num[e[v[now]]]);
	if(dfs(now+1,s+tmp)) return true;
	choose[now]=false;
	return dfs(now+1,s);
}

int main(){
	//freopen("222.txt","r",stdin);
	cin>>n>>q>>m;
	for(int i=1;i<=n;i++)parent[i]=i;
	for(int i=1;i<=m;i++){
		int k,a,b;
		cin>>k>>a>>b;
		if(k==0)union_(a,b);
		else{
			q_1[p++]={a,b};
		}
	}
	for(int i=0;i<p;i++){
		int a_=find(q_1[i].first),b_=find(q_1[i].second);
		if(a_==b_){
			cout<<"NO";
			return 0;
		}else{
			if(e[a_]==0)e[a_]=b_;
			else union_(b_,e[a_]);
			if(e[b_]==0)e[b_]=a_;
			else union_(a_,e[b_]);
		}
	}
	
	for(int i=1;i<=n;i++){
		num[find(i)]++;
		if(e[i]>0)e[i]=find(e[i]);
		if(i==find(i)){
			if(e[i]>0&&in[e[i]])continue;
			else{
				v.emplace_back(i);
				in[i]=true;
			}
		}
	}
	/*for(int i=1;i<=n;i++){
		cout<<i<<" "<<find(i)<<" "<<e[find(i)]<<'\n';
	}*/
	//for(auto &a:v)cout<<a<<" ";
	len=v.size();
	for(int i=len-1;i>=0;i--){
		if(e[v[i]]>0)sum+=min(num[v[i]],num[e[v[i]]]);
		if(e[v[i]]>0)back[i]=abs(num[v[i]]-num[e[v[i]]]);
		else back[i]=num[v[i]];
		if(i<len-1)back[i]+=back[i+1];
	}
	target=q-sum;
	if(target<0){
		cout<<"NO";
		return 0;
	}
	/*for(auto &a:v)cout<<a<<" ";
	cout<<'\n';
	for(int i=1;i<=n;i++)cout<<i<<" "<<num[i]<<" ";
	cout<<'\n';
	cout<<target<<'\n';*/
	
	bool ok=dfs(0,0);
	
	//for(int i=0;i<len;i++)cout<<v[i]<<" "<<choose[i]<<"   ";
	if(!ok)cout<<"NO";
	else{
		cout<<"YES\n";
		for(int i=0;i<len;i++){
			if(e[v[i]]){
				if(choose[i]){
					if(num[e[v[i]]]<num[v[i]])chose[v[i]]=true;
					else chose[e[v[i]]]=true;
				}else{
					if(num[e[v[i]]]<num[v[i]])chose[e[v[i]]]=true;
					else chose[v[i]]=true;
				}
			}else{
				if(choose[i])chose[v[i]]=true;
			}
		}
		for(int i=1;i<=n;i++)if(chose[find(i)])cout<<i<<" ";
	}
	return 0;
}
/*
13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13
*/