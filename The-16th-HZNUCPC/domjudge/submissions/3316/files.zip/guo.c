#include<stdio.h>
#include<math.h>
int main()
{
	int n,m;
	int i,j;
	
	for(i=0;i<1000;i++)
	{
		scanf("%d %d",&n,&m);
		if(n==1 && m==2)
		{
			printf("YES");
		}	
		if(n%m==0)
		{
			printf("NO");
		}	
		else
		{
			if(n>m)
			{
					for(j=0;j<=n/m;j++)
					{
						if(n%m!=0)
						{
							if(m==2)
							{
								printf("YES");
								break;
							}	
							else
							{
								m--;
							}
						}
					}
			}	
			if(m>n)
			{
				printf("NO");
			}
	}
}
}