#include<bits/stdc++.h>
using namespace std;
#define int long long
struct ll{
	int x,y;
}q[105];
int ck(int x,int y){
	int re=0;
	int g=__gcd(x,y);
	re+=g;
	return re;
}
bool ck1(int x,int y,int xx,int yy,int xxx,int yyy){
	if((y-yy)*1.0/(x-xx)*xxx==yyy){
		return true;
	}
	return false;
}
bool cmd(ll x,ll y){
	return x.x<y.x;
}
void solve(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		int x,y;
		cin>>x>>y;
		q[i]={x,y};
	}
	sort(q,q+n,cmd);	
	int ans=0;
	for(int i=0;i+2<n;i++){
		int x=q[i].x,y=q[i].y;
		for(int j=i+1;j+1<n;j++){
			int xx=q[j].x,yy=q[j].y;
			for(int k=j+1;k<n;k++){
				int sum=0;
				int xxx=q[k].x,yyy=q[k].y;
				if((x==xx&&y==yy)||(x==xxx&&y==yyy)||(xx==xxx&&yy==yyy)||ck1(x,y,xx,yy,xxx,yyy)){
					continue;
				}
				sum+=ck(abs(x-xx),abs(y-yy));	
				sum+=ck(abs(x-xxx),abs(y-yyy));	
				sum+=ck(abs(xxx-xx),abs(yyy-yy));	
				ans=max(sum,ans);
			}
		}
	}
	printf("%lld\n",ans);
}

signed main(){
//	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}