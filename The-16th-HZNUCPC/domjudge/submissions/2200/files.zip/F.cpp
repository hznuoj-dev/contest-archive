#include<iostream>
#include<math.h>
using namespace std;
long long i,j,f; 
int main()
{
	long long n,m,minn=1;
	cin>>n>>m;
	for(int i=2;i<=sqrt(n);i++){
		if(n%i==0){
			minn=i;
			break;
		}
	}
	if(minn==1)minn=n;
	if(minn>m || n==1)cout<<"YES";
	else cout<<"NO";
	return 0;
}