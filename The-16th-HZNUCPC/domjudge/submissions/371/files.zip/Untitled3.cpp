#include<bits/stdc++.h>

#define ll long long


using namespace std;
string s,a,b;
const int N=25;
int vis[N][N];
int x[366],y[366];
int dx[4]={1,0,-1,0};
int dy[4]={0,1,0,-1};
int ans;
void check(int a,int b){
	for(int i=0;i<4;i++){
		int tx=a+dx[i];
		int ty=b+dy[i];
		if(tx>=1&&tx<=19&&ty>=1&&ty<=19&&!vis[tx][ty]){
			ans++;
		}
	}
}
void solve(){
	int n;cin>>n;
	memset(vis,0,sizeof vis);
	int w;
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];cin>>w;
		vis[x[i]][y[i]]=w;
	}
	ans=0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(vis[i][j]==1){
				check(i,j);
			}
		}
	}
	cout<<ans<<endl;
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t;cin>>t;
	while(t--){
		solve();
	}
	
	
	return 0;
}