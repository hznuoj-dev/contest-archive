#include <bits/stdc++.h>
using namespace std;

const int P = 1e9 + 7;
int cnt[2][26], c[2];
string A, B;
int d[26][26];

#define ADD(a, j) do { \
		if (cnt[a][j] == 0) ++c[a]; \
		++cnt[a][j];  \
	} while (0)
#define SUB(a, j) do { \
		if (--cnt[a][j] == 0) --c[a]; \
	} while (0)

int main() {
	ios::sync_with_stdio(false);
	cin >> A >> B;
	int n = (int)A.size();
	for (int i = 0; i < (int)A.size(); ++i) ++cnt[0][A[i] - 'a'];
	for (int i = 0; i < (int)B.size(); ++i) ++cnt[1][B[i] - 'a'];
	for (int i = 0; i < 2; ++i)
		for (int j = 0; j < 26; ++j)
			if (cnt[i][j] > 0) ++c[i];
	
	int a = 0, b = 1;
	if (c[a] > c[b]) swap(a, b), swap(A, B);
	
	long long ans = 0;
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < 26; ++j)
			for (int k = 0; k < 26; ++k) {
				if (d[j][k] > 0) {
					SUB(a, j); SUB(b, k);
					SUB(a, A[i] - 'a'); SUB(b, B[i] - 'a');
					ADD(b, j); ADD(a, k);
					ADD(b, A[i] - 'a'); ADD(a, B[i] - 'a');
//					cout << i << " " << j << " " << k << " " << c[a] << " " << c[b] << "\n";
					if (c[a] == c[b]) {
						ans += d[j][k];
						ans %= P;
					}
					SUB(b, j); SUB(a, k);
					SUB(b, A[i] - 'a'); SUB(a, B[i] - 'a');
					ADD(a, j); ADD(b, k);
					ADD(a, A[i] - 'a'); ADD(b, B[i] - 'a');
				}
			}
		
		++d[A[i] - 'a'][B[i] - 'a'];
	}
	
	cout << ans << "\n";

	return 0;
}