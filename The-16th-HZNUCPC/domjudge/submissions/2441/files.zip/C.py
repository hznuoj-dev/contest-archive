x=input()
y=input()
L=len(x)
list1=[]
for i in range(L):
    if x[i]!=y[i]:
        list1.append(i)
if list1==[]:
    l=1
else:
    l=list1[-1]-list1[0]+1
r=L-l
if l>1:
    result=r*(L-l+1)/2+1
else:
    result=r*(L-l+1)/2
print(int(result))
