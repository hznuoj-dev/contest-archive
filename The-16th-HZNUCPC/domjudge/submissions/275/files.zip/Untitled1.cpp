#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
int a[21][21];
#define ll long long 
ll gcd(ll a, ll b)
{
	return b == 0 ? a : gcd(b, a % b);
}
int main()
{
	std::ios::sync_with_stdio(false); 
	cin.tie(0), cout.tie(0);
	/*int n, m;
	cin >> n >> m;
	if (gcd(n, m) == 1) cout << "YES" << endl;
	else cout << "NO" << endl;	*/ 
	int t,n,x,y,c;
	cin>>t;
	while(t--)
	{
		int summ=0;
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			cin>>x>>y>>c;
			a[x][y]=c;
		}
		for(int i=1;i<=19;i++)
		for(int j=1;j<=19;j++)
		{
			if(a[i][j]==1)
			{
				if(i-1>=1)
			{
				if(a[i-1][j]==0)
				summ++;
			}
			if(i+1<=19)
			{
				if(a[i+1][j]==0)
				summ++;
			}
			if(j-1>=1)
			{
				if(a[i][j-1]==0)
				summ++;
			}
			if(j+1<=19)
			{
				if(a[i][j+1]==0)
				summ++;
			}
			}
			
		}
		cout<<summ<<endl;
	}
	return 0;
}