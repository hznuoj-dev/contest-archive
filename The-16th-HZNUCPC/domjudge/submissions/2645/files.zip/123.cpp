#include<bits/stdc++.h>
using namespace std;
#define int long long
//#define first fi
//#define second se
const int N=2e5+5;
const int mod=1e9+7;
int in[55][55];
int mp[55],mp1[55];
int vis[26][26][26][26];
char s[N];
char ss[N];
int fac[N],inv[N];
int n,m;
int s1,s2;
int ans;
void init()
{
    fac[0]=1;
    for(int i=1;i<N;i++)
    {

        fac[i]=fac[i-1]*i%mod;
    }
    inv[1]=1;
    for(int i=2;i<N;i++)inv[i]=mod-(mod/i)*inv[mod%i]%mod;
    inv[0]=1;
    for(int i=1;i<N;i++)
    {

        inv[i]=inv[i]*inv[i-1]%mod;
    }

}
int C(int n,int m)
{
  //  cout<<n<<" "<<m<<endl;

    if(n<m)return 0;
    return fac[n]%mod*inv[m]%mod*inv[(n-m)]%mod;
}
signed main()
{
    init();
    cin>>(s+1)>>(ss+1);n=strlen(s+1);
    for(int i=1;i<=n;i++)
    {
        int x=s[i]-'a';
        int y=ss[i]-'a';
        in[x][y]++;
        mp[x]++;
        mp1[y]++;
        if(mp[x]==1)s1++;
        if(mp1[y]==1)s2++;

    }
    for(int i=0;i<=25;i++)
    {

        for(int j=0;j<=25;j++)
        {
            for(int k=0;k<=25;k++)
            {
                for(int l=0;l<=25;l++)
                {
                    if(vis[i][j][k][l])continue ;
                    vis[i][j][k][l]++;
                    vis[k][l][i][j]++;

                    if(in[i][j]>0)in[i][j]--;
                    else continue ;
                    if(in[k][l]>0)in[k][l]--;
                    else
                    {

                        in[i][j]++;
                        continue ;
                    }
                    mp[i]--;mp1[j]--;
                    if(mp[i]==0)s1--;
                    if(mp1[j]==0)s2--;
                    mp[j]++;mp1[i]++;
                    if(mp[j]==1)s1++;
                    if(mp1[i]==1)s2++;


                     mp[k]--;mp1[l]--;
                    if(mp[k]==0)s1--;
                    if(mp1[l]==0)s2--;
                    mp[l]++;mp1[k]++;
                    if(mp[l]==1)s1++;
                    if(mp1[k]==1)s2++;

 //cout<<"Sd"<<endl;
                   // cout<<i<<" "<<j<<endl;
                    if(s1==s2)
                    {
                       // cout<<i<<" "<<j<<endl;
                      //  cout<<k<<" "<<l<<endl;
                        if(i==k && j==l)
                        {
                            ans+=C(in[i][j]+2,2);
                           // cout<<ans<<endl;

                        }

                        else
                        {

                            ans+=(in[i][j]+1)*(in[k][l]+1);
                        }
                    }
                    ans%=mod;
                    mp[j]--;mp1[i]--;
                    if(mp[j]==0)s1--;
                    if(mp1[i]==0)s2--;
                    mp[i]++;mp1[j]++;
                    if(mp[i]==1)s1++;
                    if(mp1[j]==1)s2++;



                    mp[l]--;mp1[k]--;
                    if(mp[l]==0)s1--;
                    if(mp1[k]==0)s2--;
                    mp[k]++;mp1[l]++;
                    if(mp[k]==1)s1++;
                    if(mp1[l]==1)s2++;



                    in[i][j]++;
                    in[k][l]++;










                }
            }
        }
    }
    cout<<ans<<endl;

}
