#include<bits/stdc++.h>
using ll =long long ;
int n,m,k;



int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	int T;
	freopen("in.txt","r",stdin);
	std::cin>>T;
	while(T--)
	{
		std::string s;
		std::cin>>s;
		int ans=0;
		for(int m=0; m<s.length(); m++)
		{
			int cnt=0;
			std::vector<int>mp(26);
			for(int i=0; m-i>=0&&m+i+1<s.length(); i++)
			{
				if(s[m-i]!=s[m+i+1])
				{
					cnt+=2;
					mp[s[m-i]-'a']++;
					mp[s[m+i+1]-'a']++;
					if(cnt==4)
					{
						if(mp[s[m-i]-'a']!=2||mp[s[m+i+1]-'a']!=2)
							break;
					}
					if(cnt>4)break;
				}
				if(cnt==0||cnt==4)
					ans=std::max(ans,i*2+2);
//					std::cout<<i<<" "<<m<<" "<<cnt<<std::endl;
			}
		}
		for(int m=0; m<s.length(); m++)
		{
			int cnt=0;
			std::vector<int>mp(26);
			for(int i=1; m-i>=0&&m+i<s.length(); i++)
			{
				if(s[m-i]!=s[m+i])
				{
					cnt+=2;
					mp[s[m-i]-'a']++;
					mp[s[m+i]-'a']++;
					if(cnt==4)
					{
						if(mp[s[m-i]-'a']!=2||mp[s[m+i]-'a']!=2)
							break;
					}
					if(cnt>4)break;
				}
				if(cnt==0||cnt==4)
					ans=std::max(ans,i*2+1);
			}
		}
		std::cout<<ans<<'\n';
	}

	return 0;
}
