#include<stdio.h>

int main()
{
	long long m,a,b;
	scanf("%ld %ld",&a,&b);
     if (a%2!=0&&a%b!=0&&a>b)
      m=1;
     
	if (m==1)
	 printf("YES");
	else
	 printf("NO");
}