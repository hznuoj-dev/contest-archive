#include<iostream>
#include<vector>
using namespace std;
int main()
{
	cin.tie(0);cout.tie(0);
	ios::sync_with_stdio(false);
	int T;
	cin>>T;
	while(T--)
	{
		int n;
		cin>>n;
		vector<vector<bool>> st(20,vector<bool>(20,false));
		vector<int> x(n),y(n),c(n);
		for(int i = 0;i<n;++i) 
		{
			cin>>x[i] >> y[i] >> c[i];
			st[x[i]][y[i]]  = true;
		}
		int cnt = 0;
		for(int i = 0;i<n;++i)
		{
			if(c[i] == 2) continue;
			if(x[i] > 1 && !st[x[i] - 1][y[i]]) ++cnt;
			if(x[i] < 19 && !st[x[i] + 1][y[i]]) ++cnt;
			if(y[i] > 1 && !st[x[i]][y[i] - 1]) ++cnt;
			if(y[i] < 19 && !st[x[i]][y[i] + 1]) ++cnt;
		}
		cout << cnt << '\n';
	}
}
