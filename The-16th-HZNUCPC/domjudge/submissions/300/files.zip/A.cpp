#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve(){
	ll n,m;
	cin>>n>>m;
	set<long long> cnt;
	if(m==1){
		cout<<"YES\n";
		return;
	}
	do{
		//cout<<m<<'\n';
		cnt.insert(m);
		m=n%m;
		if(m==0||m==1)break;
	}while(!cnt.count(m));
	if(m==1){
		cout<<"YES"<<'\n';
	}else{
		cout<<"NO"<<'\n';
	}
}
int main(){
	ios::sync_with_stdio(0);
	int T=1;
//	cin>>T;
	while(T--){
		solve();
	}
}