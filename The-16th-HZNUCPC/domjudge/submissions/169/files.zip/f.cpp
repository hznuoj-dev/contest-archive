#include "bits/stdc++.h"
typedef long long int ll;
using namespace std;


ll  parse(ll x ){
    ll e = sqrt(x);
    for(int i = 2; i <= e;i++) {
        if (x % i == 0){
            return i;
        }
    }

    return x;


}

void solve(){
    ll x, y;
    cin >> x >> y;

    ll base = parse(x);

    // cout << base << endl;
    if(y < base) {
        cout <<"YES"<<endl;
    }else {
        cout <<"NO" <<endl;
    }

    return ;


}



int main (){
    int t = 1;
    // cin >> t;
    while (t--){
        solve();
    }

    return 0;
}
