#include<stdio.h>
int main(){
	int a[19][19];
	int i,j,k,t;
	int b,c,d;
	for(i=0;i<19;i++){
		for(j=0;j<19;j++){
			a[i][j]=0;
		}
	}
	scanf("%d",&t);
	for(i=0;i<t;i++){
		int a1;
		scanf("%d",&a1);
		for(j=0;j<a1;j++){
			
			scanf("%d %d %d",&b,&c,&d);
			a[b][c]=d;
			if(d==1){
				if(a[b-1][c]!=1&&a[b][c-1]!=1&&a[b+1][c]!=1&&a[b][c+1]!=1&&a[b-1][c]!=2&&a[b][c-1]!=2&&a[b+1][c]!=2&&a[b][c+1]!=2)
				a[b-1][c]=3;
				a[b][c-1]=3;
				a[b+1][c]=3;
				a[b][c+1]=3;
			}
		}
	}
	int sec=0;
	for(i=0;i<19;i++){
		for(j=0;j<19;j++){
			if(a[i][j]==3){
				sec++;
			}
		}
	}
	printf("%d",sec);
	return 0;
}