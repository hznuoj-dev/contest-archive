#include<bits/stdc++.h>
using namespace std;
#define dzs ios::sync_with_stdio(false);cin.tie(nullptr),cout.tie(nullptr)
typedef long long ll;
const int N=1e5+10;
signed main()
{
	dzs;
	int l,sum=0,aa[30]={0},bb[30]={0},na=0,nb=0;
	string a,b;
	cin>>a>>b;
	l=a.length();
	for(int i=0;i<l;i++)
	{
		aa[a[i]-'a']++;
		if(aa[a[i]-'a']==1) na++;
		bb[b[i]-'a']++;
		if(bb[b[i]-'a']==1) nb++;
	}
	for(int i=0;i<l-1;i++)
	{
		aa[a[i]-'a']--;
		if(aa[a[i]-'a']==0) na--;
		bb[b[i]-'a']--;
		if(bb[b[i]-'a']==0) nb--;
		aa[b[i]-'a']++;
		if(aa[b[i]-'a']==1) na++;
		bb[a[i]-'a']++;
		if(bb[a[i]-'a']==1) nb++;	
		for(int j=i+1;j<l;j++)
		{
			aa[a[j]-'a']--;
			if(aa[a[j]-'a']==0) na--;
			bb[b[j]-'a']--;
			if(bb[b[j]-'a']==0) nb--;
			aa[b[j]-'a']++;
			if(aa[b[j]-'a']==1) na++;
			bb[a[j]-'a']++;
			if(bb[a[j]-'a']==1) nb++;
			if(na==nb)
			{
				sum++;
				sum=sum%(1000000007);
			}
			aa[b[j]-'a']--;
			if(aa[b[j]-'a']==0) na--;
			bb[a[j]-'a']--;
			if(bb[a[j]-'a']==0) nb--;
			aa[a[j]-'a']++;
			if(aa[a[j]-'a']==1) na++;
			bb[b[j]-'a']++;
			if(bb[b[j]-'a']==1) nb++;
		}
		aa[b[i]-'a']--;
		if(aa[b[i]-'a']==0) na--;
		bb[a[i]-'a']--;
		if(bb[a[i]-'a']==0) nb--;
		aa[a[i]-'a']++;
		if(aa[a[i]-'a']==1) na++;
		bb[b[i]-'a']++;
		if(bb[b[i]-'a']==1) nb++;
	}
	cout<<sum;
}