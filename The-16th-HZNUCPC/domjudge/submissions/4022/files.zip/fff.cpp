#include<stdio.h>

int main()
{
	long long m,a,b,t;
	scanf("%ld %ld",&a,&b);
	m=2;
	t=0;
	for (int i=2;i<=a/i;i++)
	 if (a%i==0)
	 {
	  t=i;
	  break;
     }
	
	while ((b<t)&&(m!=1)&&(m!=0)&&(a%2!=0))
	{
		m=a%b;
		b=m;
		
	}
	if (m==1)
	 printf("YES");
	else
	 printf("NO");
}