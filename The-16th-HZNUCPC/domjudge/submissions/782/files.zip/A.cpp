#include<bits/stdc++.h>
#define int long long
typedef long long ll;
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;
const int N = 25;
int dx[]={-1,0,1,0};
int dy[]={0,1,0,-1};
int st[N][N];
int ans;
int n;
vector<pii> B;
bool check(int xx,int yy){
	if(xx >= 1 && xx <= 19 && yy >= 1 && yy <= 19){
		return true;
	}else{
		return false;
	}
}
void solve(){
	cin >> n;
	ans = 0;
	B.clear();
	for (int i = 0; i <= 20; i++){
		for (int j = 0; j <= 20; j++){
			st[i][j] = 0;
		}	
	}
	for (int i = 0; i < n; i++){
		int x, y, w;
		cin >> x >> y >> w;
		st[x][y] = w;
		if(w == 1){
			B.push_back({x,y});
		}
	}
	for (auto i:B){
		for (int j = 0; j < 4; j++){
			int cx = i.fi + dx[j];
			int cy = i.se + dy[j];
//			cout << cx << " " << cy << endl;
			if(st[cx][cy] == 0 && check(cx,cy)){
//				st[cx][cy] = 1;
				ans++;
			}
		}
	}
//	for (int i = 1; i <= 20; i++){
//		for (int j = 1; j <= 20; j++){
//			cout << st[i][j] << " \n"[j==10];
//		}	
//	}
	cout << ans << endl;
}
signed main(){
	int _;
	cin >> _;
	while(_--){
		solve();
	}
	return 0;
}
