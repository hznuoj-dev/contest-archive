#include<bits/stdc++.h>
int n;
int map[ 25 ][ 25 ];
int vis[ 25 ][ 25 ];
int xx[]={-1,0,1,0};
int yy[]={0,1,0,-1};
int ans = 0;
void check(int x , int y ){
	for( int i = 0 ; i < 4 ; i ++ ){
		int tx = x + xx[ i ],ty = y + yy[ i ];
		if( map[ tx ][ ty ] == 0 && vis[ tx ][ ty ] == 0 ){
			ans++;
			vis[ tx ][ ty ] = 1;
		}
	}
}
void solve(){
	std::cin>>n;
	ans = 0;
	std::memset( map , 0 , sizeof( map ) );
	std::memset( vis , 0 , sizeof( vis ) );
	for( int i = 1 ; i <= n ; i ++ ){
		int x , y , w ;std::cin>>x>>y>>w;
		map[ x ][ y ] = w;
	}
	
	for( int i = 1 ; i <= 19 ; i ++ ){
		for( int j = 1 ; j <= 19 ; j ++ ){
			if( map[ i ][ j ] == 1 ){
				check( i , j );
			}
		}
	}
	std::cout<<ans<<'\n';
}

int main(){
	int t;std::cin>>t;
	while( t-- )
		solve();
}