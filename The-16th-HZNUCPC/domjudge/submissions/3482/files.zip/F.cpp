#include<iostream>
using namespace std;
int main(){
	long long n,m;
	cin >> n >> m;
	string res="NO";
	if(m==1||n==1) res="YES";
	else{
		while(n%m>1){
			m=n%m;
		}
		if(n%m==1)res="YES";
	}
	cout << res << endl;
			
}
	