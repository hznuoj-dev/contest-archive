#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int> PII;

signed main(){
    int n,m;
    cin>>n>>m;
    while(1){
    	if(m==1){
    		cout<<"YES"<<endl;
    		return 0;
		}
		if(n%m==0){
			cout<<"NO"<<endl;
			return 0;
		}
		if(n>m){
			m=n%m;
		}else{
			m=m%n;
		}
	}
}