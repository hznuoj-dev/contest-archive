#include<bits/stdc++.h>
using namespace std;


long long n,m;
int bol(long long x)
{
	long long cnt=sqrt(x);
	for(int i=2; i<=cnt; i++)
	{
		if(x%i==0&&i<=m)
		{
			return 1;
		}
	}
	return 0;
}
int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);

	cin>>n>>m;
	if(m==1||n==1)
	{
		cout<<"YES\n";
		return 0;
	}
	if(n==2)
	{
		cout<<"NO\n";
		return 0;
	}
	else
	{
		int f=bol(n);
		if(f==0&&n>m)
		{
			cout<<"YES\n";
		}
		else
		{
			cout<<"NO\n";
		}
	}


	return 0;
}