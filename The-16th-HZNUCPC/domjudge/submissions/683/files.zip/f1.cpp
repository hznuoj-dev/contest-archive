#include<bits/stdc++.h>
#define int long long
typedef long long ll;
#define pii pair<int,int>
#define fi first
#define se second
using namespace std;

void solve()
{
	int n,m;
	cin>>n>>m;
	if(m==1||n==1)
	{
		cout<<"YES"<<endl;
		return;
	}
	for(int i=2;i<=m&&i*i<=n;i++)
	{
		if(n%i==0)
		{
			cout<<"NO"<<endl;
			return;
		}
	}
	if(n<=m)
	{
		cout<<"NO"<<endl;
		return;
	}
	cout<<"YES"<<endl;
}

signed main()
{
	solve();
}
