#include<bits/stdc++.h>
using namespace std;
int t,n;
const int N=25;
int a[N][N];
int f[N][N];
int x,y,c;
int main(){
	cin>>t;
	while(t--){
		int sum=0;
		cin>>n;
		for(int i=0;i<n;i++){
			cin>>x>>y>>c;
			a[x][y]=c;
		}
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(a[i][j]==1){
					if(i-1>0&&!a[i-1][j]&&!f[i-1][j]){
						sum++;
						f[i-1][j]=1;
					}
					if(i+1<20&&!a[i+1][j]&&!f[i+1][j]){
						sum++;
						f[i+1][j]=1;
					}
					if(j-1>0&&!a[i][j-1]&&!f[i][j-1]){
						sum++;
						f[i][j-1]=1;
					}
					if(j+1<20&&!a[i][j+1]&&!f[i][j+1]){
						sum++;
						f[i][j+1]=1;
					}	
				}
			}
		}
		cout<<sum<<"\n";
	}
	return 0;
}