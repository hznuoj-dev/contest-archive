#include<iostream>
using namespace std;
int main(){
	long long n,m;
	cin >> n >> m;
	string res="YES";
	if(m==1||n==1) res="YES";
	else if(n%m==0){
		res="NO";
	}
	cout << res << endl;
			
}
	