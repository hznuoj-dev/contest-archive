#include<stdio.h>

long long ssu(long long a)
{
	if(a<=1)
		return 0;
	for(int i=2;i<=a/i;i++)
	{
		if(a%i==0)
			return 0;
	}
	return 1;
}

int main()
{
	long long n=0,m=0;
	scanf("%lld %lld",&n,&m);
	if((ssu(n) && n%m!=0 &&n>m )|| n==1)
		printf("YES\n");
	else
		printf("NO\n");
}