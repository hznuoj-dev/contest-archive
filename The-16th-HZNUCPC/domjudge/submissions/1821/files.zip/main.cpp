#include <iostream>
#include <cstdio>
#include <bits/stdc++.h>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;
typedef long long ll;

ll n, m;
ll k=0;
bool e=0;
int main()
{
    cin >> n >> m;
    
    for(int i=2;i*i<=n;i++){
        if(n%i==0)
        {
            k=i;
            e=1;
            break;
        }
    }
    if(e&&k<=m)
    cout<<"NO";
    else if(e||k==0)
    cout<<"YES";
    return 0;
}