#include<bits/stdc++.h>
using namespace std;
long long ys(long long x){
	for(long long i=2;i*i<=x;i++){
		if(x%i==0)return i;
	}
	return x;
}
void solve(){
	long long n,m;
	cin>>n>>m;
	int flag=0;	
	if(m==1||n==1){
		flag=1;
	}
	if(n%2==1){
	    if(m>=ys(n)){
//	    	flag=0;
		}else{
			flag=1;
		}
	}
//	if(n>=ys(m))cout<<"NO"<<endl;
//	else cout<<"YES"<<endl;
///
//	if(m==1||n==1){
//		flag=1;
//	}
	
	if(flag){
		cout<<"YES"<<endl;
	}else{
		cout<<"NO"<<endl;
	}
	return;
}
int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
