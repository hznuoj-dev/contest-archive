#include <stdio.h>

int main(){
	int n,m;
	scanf("%d%d",&n,&m);
	if(m==1){
		printf("YES");
		return 0;
	}
	if(n<=m){
		printf("NO");
		return 0;
	}
	if(n%m==0){
		printf("NO");
		return 0;
	}
	if(n%2==1){
		printf("YES");
		return 0;
	}else{
		printf("NO");
		return 0;
	}
}