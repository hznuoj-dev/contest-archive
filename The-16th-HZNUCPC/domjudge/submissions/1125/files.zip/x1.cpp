#include<bits/stdc++.h>
#define int long long
#define maxn 110
using namespace std;
int x[maxn],y[maxn];
signed main(){
    int n;  cin >> n;
    long long maxx=0;
    for(int i=1;i<=n;++i)  cin >> x[i] >> y[i];
    for(int i=1;i<=n-2;++i){
    	for(int j=i+1;j<=n-1;++j){
    		for(int k=j+1;k<=n;++k){
    			int tx1,tx2,tx3,ty1,ty2,ty3;
    			if(y[i]>y[j])  ty1=y[i]-y[j],tx1=x[i]-x[j];
    			else  ty1=y[j]-y[i],tx1=x[j]-x[i];
    			if(y[j]>y[k])  ty2=y[j]-y[k],tx2=x[j]-x[k];
    			else  ty2=y[k]-y[j],tx2=x[k]-x[j];
    			tx3=x[i]-x[k];
    			ty3=y[i]-y[k];
    			if(tx1*ty2==tx2*ty1)  continue;
    			int d1=__gcd(abs(tx1),abs(ty1)),d2=__gcd(abs(tx2),abs(ty2)),d3=__gcd(abs(tx3),abs(ty3));
    			d1=max(1ll*0,d1-1),d2=max(1ll*0,d2-1),d3=max(1ll*0,d3-1);
    			maxx=max(maxx,d1+d2+d3+3);
			}
		}
	}
	cout << maxx << '\n';
    return 0;
}