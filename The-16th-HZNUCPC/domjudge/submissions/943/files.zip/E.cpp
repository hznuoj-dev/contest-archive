#include <bits/stdc++.h>
#define int long long
#define endl '\n'
using namespace std;
typedef unsigned long long ull;
const int N=104;
const int mod=1e9+7;

int x[N],y[N];

void run()
{
	int n,ans=0,tmp=0,k1,k2;
	
	cin >> n;
	for(int i=1;i<=n;i++)
		cin >> x[i] >> y[i];
	
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		{
			if(i==j)
				continue;
			for(int k=1;k<=n;k++)
			{
				if(i==k || j==k)
					continue;
//				cout << i << ' ' << j << ' ' << k << ' ' << (int)((y[j]-y[i])*(x[k]-x[j])==(y[k]-y[j])*(x[j]-x[i])) << endl; 
				k1=(y[j]-y[i])*(x[k]-x[j]);
				k2=(y[k]-y[j])*(x[j]-x[i]);
				if(k1==k2)
					continue;
				tmp=0;
				
				tmp+=__gcd(abs(x[i]-x[j]),abs(y[i]-y[j]))-1;
				tmp+=__gcd(abs(x[j]-x[k]),abs(y[j]-y[k]))-1;
				tmp+=__gcd(abs(x[i]-x[k]),abs(y[i]-y[k]))-1;
//				cout << tmp << endl;
				ans=max(ans,tmp);
			}
		}
//	cout << 'A' << ans << endl;
	if(ans>0)
		ans+=3;
	cout << ans;
}

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

