#include<bits/stdc++.h>

#define ll long long

using namespace std;

int main()
{
	string s1,s2;
	while(cin>>s1>>s2)
	{
		int r=-1,l=INT_MAX;
		bool key=false;
		ll res=0;
		int t=0;
		for(int i=0;i<s1.length();i++)
		{
			if(s1[i]!=s2[i])
			{
				key=true;
				r=max(i,r);
				l=min(i,l);
				t=0;
			}
			else
			{
				t++;
				if(t>=2)
				{
					res+=t-1;
					res%=1000000007;
				}
			}
		}
		if(key)
		{
			for(int i=1;i<l;i++)
			{
				res-=i;
			}
			for(int i=1;i<s1.length()-1-r;i++)
			{
				res-=i;
			}
			if(r!=l)
			{
				res++;
				res%=1000000007;
			}
			t=s1.length()-(r-l+1)+1;
		}
		for(int i=1;i<t;i++)
		{
			res+=i;
			res%=1000000007;
		}
		cout<<res<<endl;
	}
	return 0;
}
