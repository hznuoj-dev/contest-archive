#include<bits/stdc++.h>
using namespace std;
void solve(){
	long long n,m;
	cin>>n>>m;
	int flag=1;
	for(int i=2;i<=m;i++){
		if(n%i==0){
			flag=0;
		}
	}
	if(flag) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
//	while(m!=1&&m!=0&&n>m){
//		long long kk=n/m;
//		m=n-kk*m;
//
//	}
//	if(m==1||n==1){
//		cout<<"YES"<<endl;
//	}else{
//		cout<<"NO"<<endl;
//	}
//	return;
}
int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
