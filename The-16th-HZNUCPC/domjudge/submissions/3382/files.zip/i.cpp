#include <bits/stdc++.h>

using namespace std;
typedef long long LL;
const int N = 220;
string s,tmp;
int nn;
int n;

bool check(int bg,int siz)
{
	tmp = s.substr(bg,siz);
	// cout << "try " << tmp << endl;
	nn = tmp.size();
	vector<pair<int,int>> q;
	for (int i=0,j=nn-1;i<=j;i++,j--)
	{
		if (tmp[i]!=tmp[j])
		{
			q.push_back({i,j});
		}
		if (q.size()>2) return false;
	}
	if (q.size()==0) return true;
	if (q.size()==1) return false;
	
	
	swap(tmp[q[0].first],tmp[q[1].first]);
	
	// cout << " case " << tmp << endl;
	if (tmp[q[0].first]==tmp[q[0].second] && tmp[q[1].first]==tmp[q[1].second])
	{
		return true;
	}
	swap(tmp[q[0].first],tmp[q[1].first]);
	
	swap(tmp[q[0].first],tmp[q[1].second]);
	// cout << " case " << tmp << endl;
	if (tmp[q[0].first]==tmp[q[0].second] && tmp[q[1].first]==tmp[q[1].second])
	{
		return true;
	}
	swap(tmp[q[0].first],tmp[q[1].second]);
	
	
	
	
	
	
	swap(tmp[q[1].first],tmp[q[0].first]);
	// cout << " case " << tmp << endl;
	if (tmp[q[0].first]==tmp[q[0].second] && tmp[q[1].first]==tmp[q[1].second])
	{
		return true;
	}
	swap(tmp[q[1].first],tmp[q[0].first]);
	
	swap(tmp[q[1].first],tmp[q[0].second]);
	// cout << " case " << tmp << endl;
	if (tmp[q[0].first]==tmp[q[0].second] && tmp[q[1].first]==tmp[q[1].second])
	{
		return true;
	}
	swap(tmp[q[1].first],tmp[q[0].second]);
	
	
	
	
	
	
	// 3
	swap(tmp[q[0].second],tmp[q[1].first]);
	// cout << " case " << tmp << endl;
	if (tmp[q[0].first]==tmp[q[0].second] && tmp[q[1].first]==tmp[q[1].second])
	{
		return true;
	}
	swap(tmp[q[0].second],tmp[q[1].first]);
	
	swap(tmp[q[0].second],tmp[q[1].second]);
	// cout << " case " << tmp << endl;
	if (tmp[q[0].first]==tmp[q[0].second] && tmp[q[1].first]==tmp[q[1].second])
	{
		return true;
	}
	swap(tmp[q[0].second],tmp[q[1].second]);
	
	
	
	
	
	
	swap(tmp[q[1].second],tmp[q[0].first]);
	// cout << " case " << tmp << endl;
	if (tmp[q[0].first]==tmp[q[0].second] && tmp[q[1].first]==tmp[q[1].second])
	{
		return true;
	}
	swap(tmp[q[1].second],tmp[q[0].first]);
	
	swap(tmp[q[1].second],tmp[q[0].second]);
	// cout << " case " << tmp << endl;
	if (tmp[q[0].first]==tmp[q[0].second] && tmp[q[1].first]==tmp[q[1].second])
	{
		return true;
	}
	swap(tmp[q[1].second],tmp[q[0].second]);
	
	return false;
}
int main()
{
	int T;
	cin >> T;
	while (T--)
	{
		cin >> s;
		n = s.size();
		int res = 0;
		for (int i=0;i<n;i++)
		{
			/*
			int l = 1,r = n-i,mid;
			while (l<r)
			{
				mid = l+r+1 >> 1;
				if (check(i,mid))
				{
					l = mid;
				}
				else r = mid-1;
			}
			*/
			/*
			for (int len=1;len<=min(i,n-i;len++))
			{
				if (check(i-len,len*2+1))
				{
					
				}
			}
			*/
			for (int len=2;len+i<=n;len++)
			{
				if (check(i,len))
				{
					res = max(res,len);
				}
			}
		}
		cout << res << '\n';
	}
}