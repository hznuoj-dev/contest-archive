package aasass;
import java.util.Scanner;

public class asjajajka {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		int n = in.nextInt();
		int m = in.nextInt();
		int k=m;
		for(int i=0;i<m;i++)
		{
			if(n%k==0)
			{
				k=k-1;
				if(k==1)
				{
					break;
				}
			}
		}
		if(k==1)
		{
			System.out.println("YES");
		}
		else
			System.out.println("NO");
}
}
