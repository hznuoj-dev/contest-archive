#include<bits/stdc++.h>
using namespace std;
#define int long long
//#define first fi
//#define second se
const int N=111;
pair<int,int>p[N];
int n,m;
int get(int pos1,int pos2,int pos3)
{

    int ans=0;
    int x,y;
    x=abs(p[pos1].first-p[pos2].first);
    y=abs(p[pos1].second-p[pos2].second);
   // cout<<x<<" "<<y<<endl;
    if(x<y)swap(x,y);
    if( x==0 || y==0 || x%y);
    else
    {
        ans+=x/y;

    }

     x=abs(p[pos1].first-p[pos3].first);
    y=abs(p[pos1].second-p[pos3].second);
    if(x<y)swap(x,y);
    if( x==0 || y==0 || x%y);
    else
    {
        ans+=x/y;

    }


     x=abs(p[pos2].first-p[pos3].first);
    y=abs(p[pos2].second-p[pos3].second);
    if(x<y)swap(x,y);
    if( x==0 || y==0 || x%y);
    else
    {
        ans+=x/y;

    }
    /*if(x%y==0);
    else
    {
        ans+=max(0ll,abs(p[pos1].first-p[pos2].first)-2ll);
    }
    if(abs(p[pos1].first-p[pos3].first)!=abs(p[pos1].second-p[pos3].second));
    else
    {
        ans+=max(0ll,abs(p[pos1].first-p[pos2].first)-2ll);
    }
    if(abs(p[pos2].first-p[pos3].first)!=abs(p[pos2].second-p[pos3].second));
    else
    {
        ans+=max(0ll,abs(p[pos1].first-p[pos2].first)-2ll);
    }*/
    return ans;
}
signed main()
{
    int ans=0;
    cin>>n;
    for(int i=1;i<=n;i++)
    {

        cin>>p[i].first>>p[i].second;
    }
    for(int i=1;i<=n;i++)
    {

        for(int j=i+1;j<=n;j++)
        {

            for(int k=j+1;k<=n;k++)
            {

                ans=max(ans,get(i,j,k)-1);
            }
        }
    }
    cout<<ans<<endl;
}
