#include<iostream>
using namespace std;
typedef long long ll;
ll n=0,m=0;
bool flag=0;
bool delet[10000020];
//F
int main()
{
	cin>>n>>m;
	if(n>m)
	{
		for(int i=2;i<=m;i++)
		{
			if(i>10000000||delet[i]==0)
			{
				if(n%i==0)
				{
					flag=1;
					break;
				}
				if(i*3<=10000000)
				{
					delet[i*2]=1;
					delet[i*3]=1;
				}
			}
		}
	}
	else
	{
		for(int i=2;i<=n-1;i++)
		{
			if(i>10000000||delet[i]==0)
			{
				if(n%i==0)
				{
					flag=1;
					break;
				}
				if(i*3<=10000000)
				{
					delet[i*2]=1;
					delet[i*3]=1;
				}
			}
		}
	}
	if(flag==1)
		cout<<"NO";
		else
		cout<<"YES";
	return 0;
}  
                 
    	
     	
      	         
         	
     
 
     
      
        