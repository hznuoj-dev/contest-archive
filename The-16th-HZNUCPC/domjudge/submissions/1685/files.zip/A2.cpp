#include<bits/stdc++.h>
using namespace std;
long long n,m;
int main() {
	cin>>n>>m;
	if(n<=m) {
		cout<<"NO"<<endl;
		return 0;
	}
	while(m>1) {
		m=n%m;
	}
	if(m==1) {
		cout<<"YES"<<endl;
	} else {
		cout<<"NO"<<endl;
	}
	return 0;
}