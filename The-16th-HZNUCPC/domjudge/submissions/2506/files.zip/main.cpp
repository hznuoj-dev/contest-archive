#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
const ll N=5005,mod=1000000007;
ll t,n;
char s[N];
signed main()
{
    //ios::sync_with_stdio(false);
    //cin.tie(0);
    cin>>t;
    while(t--)
    {
        scanf("%s",s+1);
        n=strlen(s+1);
        ll ans=0;
        for(ll i=1;i<=n;++i)
        {
            ll x=i-1,y=i+1,w=0,h=0;
            char a,b,c;
            c=s[i];
            while(x>=1&&y<=n)
            {
                if(s[x]==s[y])
                {
                    if(w==0||h==1)ans=max(ans,y-x+1);
                }
                else
                {
                    if(w==0)
                    {
                        ++w;
                        if(h==0&&(s[x]==c||s[y]==c))ans=max(ans,y-x+1),++h;
                        a=s[x],b=s[y];
                    }
                    else if(w==1)
                    {
                        if(s[x]==a&&s[y]==b||s[x]==b&&s[y]==a)ans=max(ans,y-x+1),++w;
                        else break;
                    }
                    else break;
                }
                --x,++y;
            }
            ++x,--y;
            if(w==0)ans=max(ans,y-x+1);
        }
        for(ll i=1;i<=n-1;++i)
        {
            ll x=i-1,y=i+2,w=0;
            char a,b;
            if(s[i]!=s[i+1])a=s[i],b=s[i+1],w=1;
            if(s[i]==s[i+1])ans=max(ans,2ll);
            while(x>=1&&y<=n)
            {
                if(s[x]==s[y])
                {
                    if(w==0)ans=max(ans,y-x+1);
                }
                else
                {
                    if(w==0)
                    {
                        ++w;
                        a=s[x],b=s[y];
                    }
                    else if(w==1)
                    {
                        if(s[x]==a&&s[y]==b||s[x]==b&&s[y]==a)ans=max(ans,y-x+1),++w;
                        else break;
                    }
                    else break;
                }
                --x,++y;
            }
            ++x,--y;
            if(w==0)ans=max(ans,y-x+1);
        }
        if(ans>1)cout<<ans<<endl;
        else cout<<0<<endl;
    }
    return 0;
}
/*
4
abccab
ihi
stfgfiut
palindrome
*/
