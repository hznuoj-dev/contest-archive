#include<bits/stdc++.h>
using namespace std;
inline int read(){
    int x=0,f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c))x=x*10+c-48,c=getchar();
    return x*f;
}
int dx[4]={0,0,-1,1};
int dy[4]={-1,1,0,0};
int T,ans,x[100010],y[1000010],c[1000010];
int vis[20][20];
int main(){
    scanf("%d",&T);
    while(T--)
    {
        int n;
        memset(vis,0,sizeof(vis));
        scanf("%d",&n),ans=0;
        for(int i=1;i<=n;i++)
        {
            scanf("%d%d%d",&x[i],&y[i],&c[i]),vis[x[i]][y[i]]=1;
        }
        for(int i=1;i<=n;i++)
        {
            if(c[i]==1)
            {
                for(int k=0;k<4;k++)
                {
                    int nx=x[i]+dx[k],ny=y[i]+dy[k];
                    if(nx<1||nx>19||ny<1||ny>19) continue;
                    if(!vis[nx][ny]) ans++;
                }
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}