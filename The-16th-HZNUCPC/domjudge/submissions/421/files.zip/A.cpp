#include<bits/stdc++.h>
using namespace std;
#define ll long long
int  mp[21][21];
int step[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		memset(mp,0,sizeof(mp));
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			int x,y,c;
			cin>>x>>y>>c;
			mp[x][y]=c;
		}
		for(int i=0;i<=20;i++)
		{
			mp[i][0]=2;
			mp[0][i]=2;
			mp[20][i]=2;
			mp[i][20]=2;
		}
		int ans=0;
		for(int i=1;i<=19;i++)
			for(int j=1;j<=19;j++)
				if(mp[i][j]==0)
					for(int k=0;k<=3;k++)
					{
						if(mp[i+step[k][0]][j+step[k][1]]==1)
							ans++;
					}
		cout<<ans<<endl;
	}
	
}