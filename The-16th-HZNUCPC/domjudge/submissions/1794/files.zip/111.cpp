#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdio>
#include<queue>
#include<map>
#include<vector>
#define int long long
#define FOR(i,m,n) for(int i = m;i <= n;i++)
#define CLR(arr,value) memset(arr,value,sizeof arr)
using namespace std;
const int N = 0x3f3f3f;
int tt,n;
const int pp = 25;
int a[pp][pp],x[365],y[365],c[365];
bool vis[pp][pp];
int dx[] = {-1,1,0,0};
int dy[] = {0,0,-1,1};
int cnt = 0;
bool f;
void dfs(int xx,int yy)
{
	if(a[xx][yy] == 0)
	{
		if(!f){
		cnt++,f = 1;
		//cout << xx << " "<<yy<<"\n";
	}
		return;
	}
	if(f)return;
	for(int i = 0;i < 4;i++)
	{
		int nx = 0,ny = 0;
		nx = dx[i] + xx;
		ny = dy[i] + yy;
		if(nx >= 1 && nx <= 19 && ny >= 1 && ny <= 19 && !vis[nx][ny] && a[nx][ny] != 2)
		{
			vis[nx][ny] = true;
			dfs(nx,ny);
			//vis[nx][ny] = false;
		}
	}
}

signed main()
{
	while(cin>>tt)
	{
		while(tt--)
		{
			cnt = 0;
			cin >> n;
			for(int i = 1;i <= n;i++)
			{
				cin >> x[i] >> y[i] >> c[i];
				if(c[i]==1) a[x[i]][y[i]] = 1;
				else a[x[i]][y[i]] = 2;
			}
			for(int i = 1;i <= n;i++)
			{
				if(a[x[i]][y[i]] != 1) continue;
				for(int j = 0;j < 4;j++)
				{
					int xx = x[i] + dx[j],yy = y[i] + dy[j];
					if(xx < 1 || xx > 19 ||yy < 1 || yy > 19 || a[xx][yy]!=0) continue;
					f = 0;
					CLR(vis,0);
					//vis[xx][yy] = 1;
					//a[xx][yy] = 2;
					//cout << xx<<" "<<yy<<"\n";
					if(a[xx][yy]==0){
						a[xx][yy] = 2;
					dfs(xx,yy);
				}
					a[xx][yy] = 0;
				}
			}
			cout << cnt << "\n";
		}
	}
}
/* 2 1 2
 3 2 2
 1 2 2
 1 3 2
 2 2 1
 3 3 2
 2 4 2*/