#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;
typedef long long ll;


void solve(){
	
	ll i=0;
	
	while(1){
		i++;
	}
	
//	system("pause");
}

int main(){
	
	int t = 1;
	//cin >> t
	while(t--){
		solve();
	}
	
	return 0;
}