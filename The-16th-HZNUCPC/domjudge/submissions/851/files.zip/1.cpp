#include<bits/stdc++.h>
using namespace std;
#define max(a,b) ((a)>(b)?(a):(b))
#define min(a,b) ((a)<(b)?(a):(b))
#define INF 0x7fffffff
#define mem 0x7f
void solve(){
	long long n,m;cin>>n>>m;long long t;
	if(m==1){
		cout<<"YES";return;
	}else if(n%2==0){
			cout<<"NO";return;
	}
	while(m!=1){t=n%m;
	if(t==0){
		cout<<"NO";return;
	}else{
		m=t;
	}
		
	}
	cout<<"YES";
	return;
}

int main()
{
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	//int t;cin >> t;while(t--)
	solve();getchar();
	return 0;
}