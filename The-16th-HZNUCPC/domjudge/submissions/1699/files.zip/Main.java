import java.util.ArrayList;
import java.util.Scanner;
public class Main {
	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		long a = sc.nextLong();
		long b =sc.nextLong();
		if(a<b)b=a;
		long jl=0;
		while(b-a%b!=1&&a-a%b==jl){
			b=a-a%b;
			jl=a-a%b;
		}
		if(b-a%b==1){
			System.out.println("YES");
		}else{
			System.out.println("NO");
		}
	}
}
