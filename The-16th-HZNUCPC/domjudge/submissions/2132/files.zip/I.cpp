#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int p[100005];
int l,r;
int mana(string s)
{
	int i;
	int l=s.length();
	if(l<2) return l;
	string t="$";
	for(i=0;i<l;i++)
	{
		t+='#';
		t+=s[i];
	}
	t+="#@";
	int n=t.length();
	int id=0,maxlength=-1,mx=0;
	int index=0;
	for(int j=1;j<n-1;j++)
	{
		p[j]=mx>j?min(mx-j,p[2*id-j]):1;
		while(t[p[j]+j]==t[j-p[j]])
		{p[j]++;
		}
		if(mx<p[j]+j)
		{
			mx=p[j]+j;
			id=j;
		}
		if(maxlength<p[j]-1)
		{
			maxlength=p[j]-1;
			
			index=j;
		
		}
	}
	l=(index-maxlength)/2;
	r=(index-maxlength)/2+maxlength-1;
//	for(i=0;i<n;i++)
//	cout<<p[i];
//	cout<<'\n';
//	int start=(index-maxlength)/2;
//	for(i=start;i<start+maxlength;i++)
//	cout<<s[i];
//	cout<<'\n';
	return maxlength;
}
int main()
{
	int  t,d,maxd;
	string s;
	cin>>t;
	while(t--)
	{
		maxd=-1;
		cin>>s;
		d=mana(s);
		maxd=max(d,maxd);
		for(int i=0;i<s.length()-1;i++)
		{
				char c=s[i];
				s[i]=s[i+1];
				s[i+1]=c;
				d=mana(s);
				if(l<=i&&r>=i&&l<=i+1&&r>=i+1)
				maxd=max(d,maxd);
				c=s[i];
				s[i]=s[i+1];
				s[i+1]=c;
			
		}
		
		if(maxd==1)
		maxd=0;
		cout<<maxd<<'\n';
	}
}