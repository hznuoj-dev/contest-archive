#include<bits/stdc++.h>


#define int long long
#define endl '\n'
using namespace std;


struct num {
	int x,y;
};


int n,x,y;

int dx[]= {-1,1,0,0};
int dy[]= {0,0,-1,1};
int inf=1e18;
num a[110];

//void pd(num a1,int &sz,int &sy,int &xz,int &xy,int &zs,int &zx,int &ys,int &yx,int ss,int xx,int zz,int yy)
//{
//	int mx=ss;//shang
//	
//	if(a1.y==ss)
//	{
//		sz=min(sz,a1.x);
//		sy=max(sy,a1.x);
//	}
//	
////	if(a1.y>mx)
////	{
////		sz=a1.x;
////		sy=a1.x;
////		mx=a1.y;
////	}
//	
//	
//	mx=inf;//xia
//	
//	if(a1.y==xx)
//	{
//		xz=min(xz,a1.x);
//		xy=max(xy,a1.x);
//	}
////	if(a1.y<mx)
////	{
////		xz=a1.x;
////		xy=a1.x;
////		mx=a1.y;
////	}
//	
//	
//	
//	mx=inf;//zuo
//	if(a1.x==zz)
//	{
//		zs=max(zs,a1.y);
//		zx=min(zx,a1.y);
//	}
////	if(a1.x<mx)
////	{
////		zs=a1.y;
////		zx=a1.y;
////		mx=a1.x;
////	}
//	
//	
//	
//	mx=-inf;//you
//	if(a1.x==yy)
//	{
//		ys=max(ys,a1.y);
//		yx=min(yx,a1.y);
//	}
////	if(a1.x>mx)
////	{
////		ys=a1.y;
////		yx=a1.y;
////		mx=a1.x;
////	}
//	
//	
//}
//
//int yx(num a1,num a2,num a3)
//{
//	int sz,sy,xz,xy,zs,zx,ys,yx;
//	num zss,zxx,yss,yxx;
//	sz=xz=zx=yx=inf;
//	sy=xy=zs=ys=-inf;
//	
//	zss={min({a1.x,a2.x,a3.x}),max({a1.y,a2.y,a3.y})};
//	zxx={min({a1.x,a2.x,a3.x}),min({a1.y,a2.y,a3.y})};
//	yss={max({a1.x,a2.x,a3.x}),max({a1.y,a2.y,a3.y})};
//	yxx={max({a1.x,a2.x,a3.x}),min({a1.y,a2.y,a3.y})};
//	
//	pd(a1,sz,sy,xz,xy,zs,zx,ys,yx,zss.y,zxx.y,zss.x,yss.x);
//	pd(a2,sz,sy,xz,xy,zs,zx,ys,yx,zss.y,zxx.y,zss.x,yss.x);
//	pd(a3,sz,sy,xz,xy,zs,zx,ys,yx,zss.y,zxx.y,zss.x,yss.x);
//	
//	
//	
//	int m=(yss.y-yxx.y)*(yss.x-zss.x);
////	cout<<"m:"<<m<<endl;
//	int ans=0;
//	ans+=(sz-zss.x)*(zss.y-zs);
////	cout<<m<<endl;
//	ans+=(zx-zxx.y)*(xz-zxx.x);
////	cout<<m<<endl;
//	ans+=(yss.x-sy)*(yss.y-ys);
////	cout<<m<<endl;
//	ans+=(yx-yxx.y)*(yxx.x-xy);
////	cout<<m<<endl;
////	cout<<"ans:"<<ans/2<<endl;
////	cout<<sz<<' '<<sy<<' '<<xz<<' '<<xy<<' '<<zs<<' '<<zx<<' '<<ys<<' '<<yx<<' '<<endl;
//	return m-ans/2;
//	
//}


int ds(num a1,num a2)
{
	a1.x-=a2.x;
	a1.y-=a2.y;
	a2={0,0};
	if(a1.x<0)a1.x=-a1.x;
	if(a1.y<0)a1.y=-a1.y;
	if(a1.x==0)return a1.y-1;
	if(a1.y==0)return a1.x-1;
	int k=__gcd(a1.x,a1.y);
	
	return a1.x/(a1.x/k)-1;
}


int yx(num a1,num a2,num a3)
{
	
	if(a1.x==a2.x==a3.x)return 0;
	if(a1.y==a2.y==a3.y)return 0;
//	cout<<ds(a1,a2)<<endl;ds(a1,a3)+ds(a2,a3)
	return 3+ds(a1,a2)+ds(a1,a3)+ds(a2,a3);
	
}



void slove() {
	cin>>n;

	for(int i=1; i<=n; i++) {
		cin>>a[i].x>>a[i].y;
	}

	int mx=0;
	for(int i=1; i<=n; i++)
		for(int j=i+1; j<=n; j++)
			for(int k=j+1; k<=n; k++) {
				mx=max(mx,yx(a[i],a[j],a[k]));
			}

	cout<<mx<<endl;

}

signed main() {
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);

	int t=1;
//	cin>>t;

	while(t--) {
		slove();
	}
}