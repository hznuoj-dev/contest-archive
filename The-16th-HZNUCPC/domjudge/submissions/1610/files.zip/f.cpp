#include<bits/stdc++.h>
#include<vector>
using namespace std;
vector<long long>v;
long long n,m;
bool solve()
{
	for(int i=2;i<=n/i;i++)
	{
		if(n%i==0)
		{
			v.push_back(i);
			if(i!=n/i) v.push_back(n/i);
		} 
	}
	int flag=0;
	sort(v.begin(),v.end());
	for(int i=0;i<v.size();i++)
	{
		if(v[i]<=m)
		{
			flag=1;
			break;
		}
	}
	return flag;
}
int main()
{
	
	cin>>n>>m;
	
	if((n%2==0 &&m==1) || (n%2!=0 && m==1) || n==1) 
	{
		cout<<"YES"<<endl;
		return 0;
	}
	if(n<=m)
	{
		cout<<"NO"<<endl;
		return 0;
	}
	if(n%2==0)
	{
		cout<<"NO"<<endl;
		return 0;
	}
	if(solve()) cout<<"NO"<<endl;
	else cout<<"YES"<<endl;
	return 0;
}
