#include <stdio.h>
bool judge(int n,int m){
	if (m % 2 == 0) return false;
	else{
		if (m>n &&m%n==0) return false;
		if (m<n &&n%m==0) return false;
		return true;
	}
}
int main(void){
	int n,m;
	scanf("%d%d",&n,&m);
	if (judge(n,m)) printf("YES");
	else printf("NO");
}
