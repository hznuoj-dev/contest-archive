#include <bits/stdc++.h>

using i64 = long long;

i64 gcd(i64 x, i64 y) {
    return y == 0 ? x : gcd(y, x % y);
}

void solve() {
    i64 n, m;
    std::cin >> n >> m;

    i64 i = 0;
    for (i = 2; i * i <= n; i++) {
        if (n % i == 0) break;
    }

    if (i * i > n) {
        std::cout << "YES\n";
    } else if (m < i) {
        std::cout << "YES\n";
    } else {
        std::cout << "NO\n";
    }
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int t;
	// std::cin >> t;
    t = 1;
	
	while(t--) solve();	
	
	return 0;
}