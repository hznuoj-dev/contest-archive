#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int mod = 1e9 + 7;
template <class... Args> void _(Args... args) {
	auto _ = [&](auto x) {cout << x << " ";};
	cout << "-->";
	int arr[] = {(_(args), 0)...};
	cout << endl;
}
int qp(int a, int b){
	int ans = 1;
	while (b){
		if (b & 1){
			ans = ans * a % mod;
		}
		b >>= 1;
		a = a * a % mod;
	}
	return ans;
}
void solve() {
	string s1, s2; cin >> s1 >> s2;
	set<int> uni1, uni2;
	map<pair<int, int>, int> pp;
	int dic1[30] = {}, dic2[30] = {};
	for (auto it : s1) ++ dic1[it - 'a'], uni1.insert(it - 'a');
	for (auto it : s2) ++ dic2[it - 'a'], uni2.insert(it - 'a');
	for (int i = 0; i < s1.size(); ++ i) {
		++ pp[{s1[i] - 'a', s2[i] - 'a'}];
	}
	
	int size1 = uni1.size(), size2 = uni2.size();
//	if (abs(size1 - size2) > 2) {
//		cout << 0;
//		return;
//	}
	
	int DIC1[30] = {}, DIC2[30] = {};
	for (int i = 0; i < 26; ++ i) {
		DIC1[i] = dic1[i];
		DIC2[i] = dic2[i];
	}
	int ans = 0, ans1 = 0;
	for (int i = 0; i < 26; ++ i) {
		for (int j = 0; j < 26; ++ j) {
			for (int p = 0; p < 26; ++ p) {
				for (int q = 0; q < 26; ++ q) {
					if (pp.count({i, j}) == 0 || pp.count({p, q}) == 0) continue;
					size1 = uni1.size(), size2 = uni2.size();
					
					if (dic1[i] == 1) -- size1;
					if (dic2[i] == 0) ++ size2;
					-- dic1[i], ++ dic2[i];
					
					if (dic1[j] == 0) ++ size1;
					if (dic2[j] == 1) -- size2;
					++ dic1[j], -- dic2[j];
					
					if (dic1[p] == 1) -- size1;
					if (dic2[p] == 0) ++ size2;
					-- dic1[p], ++ dic2[p];
					
					if (dic1[q] == 0) ++ size1;
					if (dic2[q] == 1) -- size2;
					++ dic1[q], -- dic2[q];
					
					if (size1 == size2) {
						if (i == p && j == q) {
							ans = (ans + pp[{i, j}] * (pp[{i, j}] - 1) * qp(2,mod - 2) % mod) % mod;
						}
						else {
							ans1 = (ans1 + (pp[{i, j}] * pp[{p, q}]) % mod) % mod;
//							_("  ", (pp[{i, j}] * pp[{p, q}]));
//							ans = (ans + pp[{i, j}] * pp[{p, q}] % mod) % mod;
						}
						
//						_(char(i + 'a'), char(j + 'a'), char(p + 'a'), char(q + 'a'),ans,ans1);
					}
					dic1[p] = DIC1[p], dic2[p] = DIC2[p];
					dic1[q] = DIC1[q], dic2[q] = DIC2[q];
					dic1[i] = DIC1[i], dic2[i] = DIC2[i];
					dic1[j] = DIC1[j], dic2[j] = DIC2[j];
				}
			}
		}
	}
	cout << (ans + ans1 * qp(2, mod - 2) % mod) % mod;
}
signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int Case = 1;
//	cin >> Case;
	while (Case -- ) {
		solve();
	}
	return 0;
}