#include<bits/stdc++.h>
using namespace std;
//#define int long long 
typedef long long ll;

const int N = 2e5+7,MOD=1e9+7;
string s1,s2;
ll c1[2][31];
ll c2[31][31];

ll qpow(ll x,ll y){
	ll res=1;
	x%=MOD;
	while(y){
		if(y&1) res=res*x%MOD;
		x=x*x%MOD;
		y>>=1;
	}
	return res;
}

bool check(int i,int j,int k,int l){
	c1[0][i]--;
	c1[0][j]--;
	c1[1][k]--;
	c1[1][l]--;
	c1[0][k]++;
	c1[0][l]++;
	c1[1][i]++;
	c1[1][j]++;
	int sz1=0,sz2=0;
	bool flag=true;
	for(int i0=0;i0<26;i0++){
		if(c1[0][i0]>0) sz1++;
		else if(c1[0][i0]<0) flag=false;
		
		if(c1[1][i0]>0) sz2++;
		else if(c1[1][i0]<0) flag=false;
	}
	c1[0][i]++;
	c1[0][j]++;
	c1[1][k]++;
	c1[1][l]++;
	c1[0][k]--;
	c1[0][l]--;
	c1[1][i]--;
	c1[1][j]--;
	return sz1==sz2&&flag;
}

void solve(){
	cin>>s1>>s2;
	for(int i=0;i<s1.size();i++){
		c1[0][s1[i]-'a']++;
		c1[1][s2[i]-'a']++;
		c2[s1[i]-'a'][s2[i]-'a']++;
	}
	ll ans=0;
	for(int i=0;i<26;i++){
		for(int j=0;j<26;j++){
			for(int k=0;k<26;k++){
				for(int l=0;l<26;l++){
					if(check(i,j,k,l)){
						if(i==j&&k==l){
							ans=(ans+c2[i][k]*(c2[i][k]-1))%MOD;
						}else{
							ans=(ans+c2[i][k]*c2[j][l])%MOD;
						}
					}
				}
			}
		}
	}
	ans=ans*qpow(2,MOD-2)%MOD;
	cout<<ans<<'\n';
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	int t = 1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}