#include<iostream>
using namespace std;
int main()
{
	int t,n,i,j,x,y,c,l;
	cin>>t;
	for(i=0;i<t;i++)
	{
		int sum=0;
		int a[21][21]={0};//1 20
		cin>>n;
		for(j=0;j<n;j++)
		{
			cin>>x>>y>>c;
			a[x][y]=c;
		}
		for(j=1;j<20;j++)
		{
			for(l=1;l<20;l++)
			{
				if(a[j][l]==1)
				{
					if(a[j-1][l]==0 && j-1!=0)
					{
						sum++;
					}
					if(a[j+1][l]==0 && j+1!=20)
					{
						sum++;
					}
					if(a[j][l-1]==0 && l-1!=0)
					{
						sum++;
					}
					if(a[j][l+1]==0 && l+1!=20)
					{
						sum++;
					}
				}
			}
		}
		cout<<sum<<endl;
	}
	return 0;
}