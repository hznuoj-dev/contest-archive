#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod=1e9+7;
int q[100005];
unordered_map<char,int>s1,s2;
void solve(){
//	cout<<256*1024*1024/2<<endl;
	string s,ss;
	cin>>s>>ss;
	int len=s.length();
	if(len==1){
		cout<<1<<endl;
		return ;
	}
	for(int i=0;i<len;i++){
		s1[s[i]]++;
		s2[ss[i]]++;
	}
	int len1=s1.size();
	int len2=s2.size();
	if(abs(len1-len2)>4){
		cout<<0<<endl;
		return ;
	}
	int sum1=0,sum2=0,sum3=0,sum4=0,sum=0;;
	for(int i=0;i<len;i++){
		int a=0;
		int b=0;
		s1[s[i]]--;
		s2[ss[i]]--;
		if(s1[s[i]]==0){
			a--;
		}
		if(s2[s[i]]==0){
			a--;
		}
		if(s1[ss[i]]==0){
			a++;
		}
		if(s2[ss[i]]==0){
			a++;
		}
		s1[s[i]]++;
		s2[ss[i]]++;
		
//		cout<<a<<endl;
		if(a==1){
			sum1++;
		}else if(a==2){
			sum2++;
		}else if(a==-1){
			sum3++;
		}else if(a==-2){
			sum4++;
		}else{
			sum++;
		}
	}
	int ans=0;
	if(len1-len2==0){
		ans+=(sum-1)*sum/2;
		ans%=mod;
		ans+=sum1*sum3;ans%=mod;
		ans+=sum2*sum4;ans%=mod;
	}else if(len1-len2==1){
		ans+=sum*sum3;ans%=mod;
		ans+=sum4*sum1;ans%=mod;
	}else if(len2-len1==1){
		ans+=sum1*sum;ans%=mod;
		ans+=sum2*sum3;ans%=mod;
	}else if(len1-len2==2){
		ans+=sum4*sum;ans%=mod;
		ans+=sum1*(sum1-1)/2;ans%=mod;
	}else if(len2-len1==2){
		ans+=sum2*sum;ans%=mod;
		ans+=sum3*(sum3-1)/2;ans%=mod;
	}else if(len1-len2==3){
		ans+=sum3*sum4;ans%=mod;
	}else if(len2-len1==3){
		ans+=sum1*sum2;ans%=mod;
	}else if(len1-len2==4){
		ans+=sum4*sum4;ans%=mod;
	}else if(len2-len1==4){
		ans+=sum2*sum2;ans%=mod;
	}
	cout<<ans<<endl;
}
signed main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	solve();
	
	
	return 0;
}