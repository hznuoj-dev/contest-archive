#include<iostream>
#include<math.h>
using namespace std;
#define maxn 101
int a[maxn],b[maxn];
int main(){
	
	int pd(int x,int y);
	int n,Max=0,w1=0,w2=0,w3=0,flag=0;
	double k1,k2;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){

		scanf("%d %d",&a[i],&b[i]);
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int t=j+1;t<=n;t++){
				flag=1;//cout<<"1";
				if((a[i]==a[j]&&a[t]!=a[i])||(a[i]==a[t]&&a[j]!=a[i])||(a[j]==a[t]&&a[i]!=a[j])){
					flag=2;
				}
				if(a[i]==a[j]&&a[i]==a[t])flag=3;
			if(flag==1){
			k1=(b[i]-b[j])/(a[i]-a[j]);
			k2=(b[i]-b[t])/(a[i]-a[t]);
			if(k1!=k2){
			w1=pd(abs(a[i]-a[j]),abs(b[i]-b[j]));
			w2=pd(abs(a[i]-a[t]),abs(b[i]-b[t]));
			w3=pd(abs(a[j]-a[t]),abs(b[j]-b[t]));
			Max=max(Max,w1+w2+w3);}
		}
			if(flag==2){
			if(a[i]==a[j]){
				w1=abs(b[i]-b[j]);
				w2=pd(abs(a[i]-a[t]),abs(b[i]-b[t]));
			    w3=pd(abs(a[j]-a[t]),abs(b[j]-b[t]));
			    Max=max(Max,w1+w2+w3);
			}
			if(a[i]==a[t]){
				w1=pd(abs(a[i]-a[j]),abs(b[i]-b[j]));
				w2=abs(b[i]-b[t]);
			    w3=pd(abs(a[j]-a[t]),abs(b[j]-b[t]));
			    Max=max(Max,w1+w2+w3);
			}
			if(a[j]==a[t]){
				w1=pd(abs(a[i]-a[j]),abs(b[i]-b[j]));
			    w2=pd(abs(a[i]-a[t]),abs(b[i]-b[t]));
			    w3=abs(b[j]-b[t]);
			    Max=max(Max,w1+w2+w3);
			}
			}
}
}
}
printf("%d",Max);
return 0;
}
int pd(int x,int y){
	int small,big,d,flag1=1;
	small=min(x,y);
	big=max(x,y);
	d=big-small;
	if(d==0){
		d=small;
		flag1=0;
	}
	while(small%d!=0 && flag1==1){
		d=abs(small-d);
		small=max(small,d);
		d=min(small,d);
	}
	return d;
}