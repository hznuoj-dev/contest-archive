#include<stdio.h>
#include<math.h>
int main()
{
	long long n,m,ys;
	int k,i,j;
	while(scanf("%lld %lld",&n,&m)!=EOF)
	{		
		if(n==1 && m==2)
		{
			printf("YES");
		}
		if(n%m==0 &&(n!=1 && m!=2) || m%n==0 && (n!=1 && m!=2))
		{
			printf("NO");
		}
		
		else
		{
			if(n>m  && (n!=1 && m!=2))
			{
				for(i=0;i<100000;i++)
				{
						if(m==2 && n%2==0)
						{
							printf("NO");
							break;
						}
						if(m==2 && n%2!=0)
						{
							printf("YES");
							break;
						}
						if(m>2 && n%m!=0)
						{
							m--;
						}
					if(n%m==0)
					{
						printf("NO");
						break;
					}
				}
			}
			if(m>n && (n!=1 && m!=2))
			{
				n=m-1;
				if(n==1)
				{
					printf("YES");
				}
				for(i=0;i<100000;i++)
				{
					if(m==2 && n%2==0)
					{
						printf("NO");
						break;
					}
					if(m==2 && n%2!=0)
					{
						printf("YES");
						break;
					}
						if(m>2 && n%m!=0)
					{
						m--;
					}
					if(n%m==0)
					{
						printf("NO");
						break;
					}
				}	
			}
		}
	}	
}