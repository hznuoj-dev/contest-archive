#include<iostream>

using namespace std;

int main(){
	long long int n,m;
	scanf("%lld%lld",&n,&m);
	
	long long int x = m;
	
	int f = 0;
	if(m == 1){
		printf("YES");
	}else{
		if(n % 2 == 0){
			printf("NO");
		}else{
				while(1){
			x = n % x;
			if(x == 1){
				f = 1;
				break;
			}

			if(x == 0){
				f = 0;
				break;
			}
		}
		
		if(f == 1) printf("YES");
		else printf("NO");
		}
}
		
	
	
	return 0;
}