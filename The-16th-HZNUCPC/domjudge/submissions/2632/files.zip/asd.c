#include<stdio.h>
int main(){
	int a,b;
	scanf("%d %d",&a,&b);
	while(b!=1){
		if(a%b==0){
			printf("NO");
			return 0;
		}
		b=a%b;
	}
	printf("YES");
	return 0;
}