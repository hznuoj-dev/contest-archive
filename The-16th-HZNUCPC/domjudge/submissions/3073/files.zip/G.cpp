#include <bits/stdc++.h>

using namespace std;
#define ln '\n'

const int N = 1e5 + 5;

int f[N], siz[N], col[N], w[N], id[N];

//bitset<50000>
int find(int x) {
	if(f[x] == x) return x;
	int par = find(f[x]);
	col[x] = col[f[x]] ^ w[x];
	return par;
}

bool ans = true;

void merge(int x, int y, int W) {
//	cout << x << " " << y << ln;
	int fx = find(x), fy = find(y);
//	cout << x << " " << y << " " << col[x] << " " << col[y] << " " << W << ln;
	if(fx == fy) {
		if(col[x] ^ col[y] != W) ans = false;
		return;
	}
	if(siz[fx] < siz[fy]) 
		swap(x, y), swap(fx, fy);
	
	siz[fx] += siz[fy];
	f[fy] = fx;
	w[fy] = col[x] ^ col[y] ^ W;
	
}

inline void solve() {
	int n, q, m;
	cin >> n >> q >> m;
	for(int i = 1; i <= n; i++) 
		f[i] = i, col[i] = 0, siz[i] = 1, w[i] = 0;
	for(int i = 1; i <= m; i++) {
		int x, y, w;
		cin >> w >> x >> y;
		merge(x, y, w);
		find(x); find(y);
	}
	if(ans == false) 
		return cout << "NO\n", void();
	else 
		cout << "YES\n";
	
	int tot = 0;
	for(int i = 1; i <= n; i++) 
		if(find(i) == i) id[i] = ++tot;	
	for(int i = 1; i <= n; i++) 
		id[i] = id[find(i)];
		
	vector<vector<int>> good(tot + 1), bad(tot + 1);
	for(int i = 1; i <= n; i++) {
		if(col[i] == 0) good[id[i]].push_back(i);
		else bad[id[i]].push_back(i);
	}
	
	int mn = min(q, n - q);
	vector<bitset<50005>> p(tot + 1);
	p[0][0] = 1;
	for(int i = 1; i <= tot; i++) 
		p[i] = (p[i - 1] << good[i].size()) | (p[i - 1] << bad[i].size());
//		cout << p[i] << ln;

	vector<int> ans_good, ans_bad;
	for(int i = tot; i; i--)
		if(mn >= good[i].size() && p[i - 1][mn - good[i].size()])  {
			mn -= good[i].size();
			for(auto x: good[i]) ans_good.push_back(x);
			for(auto x: bad[i]) ans_bad.push_back(x);
		} else {
			mn -= bad[i].size();
			for(auto x: bad[i]) ans_good.push_back(x);
			for(auto x: good[i]) ans_bad.push_back(x);	
		}
	
	sort(ans_good.begin(), ans_good.end());
	sort(ans_bad.begin(), ans_bad.end());
	if(ans_good.size() == q) {
		for(auto x: ans_good) cout << x << " ";
		cout << ln;
	} else {
		for(auto x: ans_bad) cout << x << " ";
		cout << ln;
	}
}

int main() {
	
//	freopen("1.txt", "r", stdin);
	
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	
	solve();
}

/*
2 1 2
1 1 2
0 2 1

0 0 1
1 0 0
*/
