#include<bits/stdc++.h>
using ll =long long ;
ll n,m,k;
int main() {
	std::cin>>n>>m;
	ll ans=n;
	for(ll i=2; i*i<=n; i++)
		if(n%i==0)
		{
			ans=i;
			break;			
		}
	if(n==1||m==1)puts("YES");
	else if(ans<=m)puts("NO");
	else puts("YES");
	return 0;
}