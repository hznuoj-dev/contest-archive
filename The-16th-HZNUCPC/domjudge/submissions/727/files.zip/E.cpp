#include<bits/stdc++.h>
#define int long long
using namespace std;
struct node{
	int x,y;
}p[200];
int check(int p1,int p2,int p3){
	int ans=0;
	int a2=(p[p3].x-p[p2].x)*(p[p3].x-p[p2].x)+(p[p3].y-p[p2].y)*(p[p3].y-p[p2].y);
	int b2=(p[p3].x-p[p1].x)*(p[p3].x-p[p1].x)+(p[p3].y-p[p1].y)*(p[p3].y-p[p1].y);
	int c2=(p[p2].x-p[p1].x)*(p[p2].x-p[p1].x)+(p[p2].y-p[p1].y)*(p[p2].y-p[p1].y);
	double ch1=sqrt(a2)+sqrt(b2);
	double ch2=sqrt(a2)+sqrt(c2);
	double ch3=sqrt(c2)+sqrt(b2);
	if((ch1-sqrt(c2)>=1e-7)&&(ch2-sqrt(b2)>=1e-7)&&(ch3-sqrt(a2)>=1e-7))
	{
		ans=ans+abs(__gcd(p[p3].x-p[p2].x,p[p3].y-p[p2].y))-1;
		ans=ans+abs(__gcd(p[p3].x-p[p1].x,p[p3].y-p[p1].y))-1;
		ans=ans+abs(__gcd(p[p1].x-p[p2].x,p[p1].y-p[p2].y))-1;
		ans+=3;
		return ans;
	}
	return 0; 
}
void solve(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>p[i].x>>p[i].y;
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				ans=max(ans,check(i,j,k));
			}
		}
	}
	cout<<ans<<'\n';
}
signed main(){
	int t;
	t=1;
	while(t--){
		solve();
	}
}