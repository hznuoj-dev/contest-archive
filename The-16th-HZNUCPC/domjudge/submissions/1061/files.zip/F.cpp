#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ct(x) cout<<x<<'\n'
#define dg(x)  cout<<#x<<'='<<x<<'\n';
#define pii  pair<int,int> 
#define N 350000
#define double long double
#define ios ios::sync_with_stdio(0),cin.tie(0),cout.tie(0)
#define endl '\n'


void solve(){
	int n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"YES"<<'\n';
		return; 
	}
	
	if(n<=m){
		cout<<"NO"<<endl;
		return;
	}
	while(true){
		int p = n%m;
		if(p==0){
			cout<<"NO"<<endl;
			return;
		}else if(p==1){
			cout<<"YES"<<endl;
			return;
		}else{
			m=p;
		}
	}
}

signed main(){
	ios;
	int t=1;
	// cin>>t;
	while(t--)
	solve();
	return 0;
}