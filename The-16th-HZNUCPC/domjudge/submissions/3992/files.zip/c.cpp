#include<iostream>
#include<cstring>
#include<algorithm>
#include<stack>
#include<queue>
#define endl '\n'
using namespace std;
const int N=1e6+10,INF=2e9,mod=1e9+7;
typedef long long LL;
typedef unsigned long long ULL;
typedef pair<int,int> PII;
LL x[27],y[27],tx[27],ty[27];
LL q[5][5];
void solve(void){
	LL d1=0,d2=0,same=0,ans=0;
	string s1,s2;
	cin>>s1>>s2;
	for(auto i:s1){
		if(!x[i-'a']) d1++;
		x[i-'a']++;
	}
	for(auto i:s2){
		if(!y[i-'a']) d2++;
		y[i-'a']++;
	}
		for(int i=0;i<s1.size();i++){
			int j=s1[i]-'a',k=s2[i]-'a';
			if(s1[i]==s2[i])q[1][1]++;
			else if(!x[k]&&x[j]>1){
				if(!y[j]&&y[k]>1)q[2][2]++;
				else if(y[j]&&y[k]==1)q[2][0]++;
				else q[2][1]++;
			}
			else if(x[k]&&x[j]==1){
				if(!y[j]&&y[k]>1)q[0][2]++;
				else if(y[j]&&y[k]==1)q[0][0]++;
				else q[0][1]++;
			}
			else {
				if(!y[j]&&y[k]>1)q[1][2]++;
				else if(y[j]&&y[k]==1)q[1][0]++;
				else q[1][1]++;
			}
		}
	//	cout<<q[0][2];
		for(int i=0;i<=2;i++){
			for(int j=0;j<=2;j++){
				for(int i1=0;i1<=2;i1++){
					for(int j1=0;j1<=2;j1++){
						if(d1+i-1+i1-1==d2+j-1+j1-1){
							if(i==i1&&j==j1)ans=(ans+(q[i][j]*q[i1][j1]-q[i][j]))%mod;
							else ans=(ans+q[i][j]*q[i1][j1])%mod;
						}
					}
				}
			}
		}
		cout<<(ans/2)%mod;

	
		
}
int main(void){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int TT;
	TT=1;
	//cin>>TT;
	while(TT--){
		solve();
	}
	return 0;
}