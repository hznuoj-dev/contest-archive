#include<bits/stdc++.h>
using namespace std;
bool Mbe;
const int N=1e5+5,M=N<<6;
int n,m,x,f,ans[N];
struct P{
	int t,p,l,r,id;
}a[N<<1];
struct Seg{
	int tot,rt,lc[M],rc[M],mn[M];
	void modify(int &p,int l,int r,int pos,int v){
		if(!p) p=++tot,mn[p]=1e9;
		mn[p]=min(mn[p],v);
		if(l==r) return ;
		int mid=(l+r)>>1;
		if(pos<=mid) modify(lc[p],l,mid,pos,v);
		else modify(rc[p],mid+1,r,pos,v);
	}
	int query(int p,int l,int r,int lx,int rx){
		if(!p) return 1e9;
		if(l>=lx&&r<=rx) return mn[p];
		int mid=(l+r)>>1,ans=1e9;
		if(lx<=mid) ans=query(lc[p],l,mid,lx,rx);
		if(rx>mid) ans=min(ans,query(rc[p],mid+1,r,lx,rx));
		return ans;
	}
}T1;
struct Seg2{
	int tot,rt,lc[M],rc[M],mn[M];
	void modify(int &p,int l,int r,int lx,int rx,int v){
		if(!p) p=++tot,mn[p]=1e9;
		if(l>=lx&&r<=rx){mn[p]=min(mn[p],v);return ;}
		int mid=(l+r)>>1;
		if(lx<=mid) modify(lc[p],l,mid,lx,rx,v);
		if(rx>mid) modify(rc[p],mid+1,r,lx,rx,v);
	}
	int query(int p,int l,int r,int pos){
		if(!p) return 1e9;
		if(l==r) return mn[p];
		int mid=(l+r)>>1,ans=mn[p];
		if(pos<=mid) ans=min(ans,query(lc[p],l,mid,pos));
		else ans=min(ans,query(rc[p],mid+1,r,pos));
		return ans;
	}
}T2;
bool Med;
signed main(){
	//fprintf(stderr,"%.3lf MB\n",(&Med-&Mbe)/1024.0/1024);
	scanf("%d%d%d",&n,&m,&x);
	for(int i=1;i<=n;i++)
		scanf("%d%d%d",&a[i].t,&a[i].l,&a[i].r);
	for(int i=1;i<=m;i++)
		scanf("%d%d",&a[n+i].t,&a[n+i].p),a[n+i].id=i;
	sort(a+1,a+1+n+m,[](P x,P y){return x.t^y.t?x.t>y.t:x.id<y.id;});
	for(int i=1;i<=n+m;i++){
		if(a[i].id) ans[a[i].id]=T2.query(T2.rt,1,x,a[i].p);
		else{
			if(a[i].l<=x&&x<=a[i].r) f=1;
			else f=T1.query(T1.rt,1,x,a[i].l,a[i].r)+1;
			T1.modify(T1.rt,1,x,a[i].l,f);
			T2.modify(T2.rt,1,x,a[i].l,a[i].r,f);
		}
	}
	for(int i=1;i<=m;i++) printf("%d\n",ans[i]<1e9?ans[i]:-1);
	return 0;
}