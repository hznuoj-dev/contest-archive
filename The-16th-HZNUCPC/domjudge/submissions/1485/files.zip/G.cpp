#include<bits/stdc++.h>
#define fi first
#define se second
using namespace std;
int n,q,m;
bool vis[100010];
int col[100010];
vector<pair<int,int> >vec[100010];
int cnt0=0,cnt1=0;
int ans[100010];
void dfs(int x){
	vis[x]=1;
	if(col[x]==0) ++cnt0;else ++cnt1;
	for(auto i:vec[x]){
		int v=i.fi;
		int tar=col[x]^i.se;
		if(col[v]==-1){
			col[v]=tar;
			dfs(v);
		}
		else if(col[v]!=tar){
			puts("NO");exit(0);
		}
	}
}
void getans(int x,int f){
	ans[x]=col[x]^f;
	for(auto i:vec[x]){
		int v=i.fi;
		if(ans[v]==-1) getans(v,f);
	}
}
int dp[100010];
pair<int,int> F[100010];
vector<int>st[100010];
int cnt[100010];
int c0[100010],c1[100010];
int main(){
	ios::sync_with_stdio(false);
	cin>>n>>q>>m;
	for(int i=1;i<=m;++i){
		int k,a,b;
		cin>>k>>a>>b;
		vec[a].push_back({b,k});
		vec[b].push_back({a,k});
	}
	memset(col,-1,sizeof(col));
	memset(ans,-1,sizeof(ans));
	int mn=0;
	for(int i=1;i<=n;++i) if(!vis[i]){
		col[i]=0;cnt0=cnt1=0;
		dfs(i);
		c0[i]=cnt0;c1[i]=cnt1;
		mn+=min(cnt0,cnt1);
		st[max(cnt0,cnt1)-min(cnt0,cnt1)].push_back(i);
	}
	if(mn>q){
		puts("NO");return 0;
	}
	dp[0]=1;
	for(int i=1;i<=n;++i) if(st[i].size()){
		for(int j=0;j<i;++j){
			int lst=-100000000;
			for(int k=0;i*k+j<=n;++k){
				if(dp[i*k+j]) lst=k;
				else if(k-lst<=st[i].size()){
					dp[i*k+j]=1;F[i*k+j]={i,k-lst};
				}
			}
		}
	}
	if(dp[q-mn]==0){
		puts("NO");return 0;
	}
	int nw=q-mn;
	while(nw!=0){
		cnt[F[nw].first]=F[nw].second;
		nw-=F[nw].first*F[nw].second;
	}
	for(int i=0;i<=n;++i){
		for(int j=0;j<cnt[i];++j){
			int p=st[i][j];
			getans(p,c0[p]<c1[p]?0:1);
		}
		for(int j=cnt[i];j<st[i].size();++j){
			int p=st[i][j];
			getans(p,c0[p]<c1[p]?1:0);
		}
	}
	puts("YES");
	for(int i=1;i<=n;++i) if(ans[i]==1) printf("%d ",i);
}