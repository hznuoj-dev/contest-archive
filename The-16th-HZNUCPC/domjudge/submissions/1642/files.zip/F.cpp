#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
int main()
{
	cin>>n>>m;
	if(m == 1)printf("YES");
	else if (n % m == 0 || m >= n) printf("NO");
	else printf("YES");
	return 0;
}

