#include<stdio.h>
#include<math.h>
int main()
{
	int n,m,sum;
	int i;
	while(scanf("%d %d",&n,&m)!=EOF)
	{		
		if(n%m!=0 && n>m)
		{
			for(i=0;i<100000;i++)
			{
				if(n%m!=0 && n>2)
				{
					n--;
				}
				if(n%m!=0 && n<=2)
				{
					printf("YES");
					break;
				}
				else 
				{
					printf("NO");
					break;
				}
			}
		}
		
		if(m%n!=0 && n<m)
		{
			for(i=0;i<100000;i++)
			{
				if(m%n!=0 && n>2)
				{
					m--;
				}
				if(n%m!=0 && n<=2)
				{
					printf("YES");
					break;
				}
					else 
				{
					printf("NO");
					break;
				}
			}
		}
		else
		{
			printf("NO");
		}
	}}
	