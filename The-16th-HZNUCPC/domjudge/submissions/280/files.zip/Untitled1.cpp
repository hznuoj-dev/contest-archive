#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 110;
int t[N][N];
int n;
int x[N],y[N];
pair<int,int> getk(int i,int j)
{
	int dx = abs(x[i]-x[j]),dy=abs(y[i]-y[j]);
	if(dx == 0)return {0,1};
	if(dy == 0)return {1,0};
	int g = __gcd(dx,dy);
	pair<int,int> ans = {dx / g,dy / g};
	if(x[i]-x[j] < 0 && y[i]-y[j] < 0)return ans;
	if(x[i]-x[j] > 0 && y[i]-y[j] > 0)return ans;
	ans.first = -ans.first;
	return ans;
}
int check(int i,int j,int k)
{
	if(getk(i,j) == getk(j,k))return 0;
	return 1;
}
signed main()
{
//	printf("%d",__gcd(0,3));
	scanf("%lld",&n);
	for(int i = 1; i <= n; ++i)
		scanf("%lld%lld",&x[i],&y[i]);
	for(int i = 1; i <= n; ++i){
		for(int j = i + 1; j <=n;++j){
			int dx = abs(x[i]-x[j]),dy=abs(y[i]-y[j]);
			int g = __gcd(dx,dy);
			t[i][j] = g - 1;
			t[j][i] = g - 1;
		}
	}
	long long ans = 0;
	for(int i = 1; i <= n; ++i){
		for(int j = i + 1; j <= n; ++j){
			for(int k = j + 1; k <= n; ++k){
				if(x[i] == x[j] && y[i] == y[j])continue;
				if(x[i] == x[k] && y[i] == y[k])continue;
				if(x[k] == x[j] && y[k] == y[j])continue;
				if(!check(i,j,k))continue;
				ans = max(ans,3 + t[i][j] + t[j][k] + t[i][k]);
			}
		}
	}
	printf("%lld",ans);
	return 0;
}