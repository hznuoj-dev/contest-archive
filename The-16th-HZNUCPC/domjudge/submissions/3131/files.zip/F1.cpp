#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll zhishu(ll x)
{
	int flag=1;
	ll y=sqrt(x);
	for(int i=2;i<=y;i++)
	{
		if(x%i==0)
		flag=0;
	}
	if(flag)
	return 1;
	return 0;
}
int main()
{
	ll n,m;
	scanf("%lld %lld",&n,&m);
	
		if(m==1||n==1)
			printf("YES\n");
		else if(m==2&&n%2==1)//9 2
			printf("YES\n");
	else 
	{
		if(n<=m)
		printf("NO\n");
		else 
		{
			if(n%2==0)
			  printf("NO\n");
			else
			{
				 if(zhishu(n))//3,5,7,11,13,17,
				{
					printf("YES\n");
				}
				else	
				printf("NO\n");

			}
		
	}
	}
	

	
	
	
  return 0;
}
