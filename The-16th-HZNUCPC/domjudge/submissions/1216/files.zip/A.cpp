#include<bits/stdc++.h>
using namespace std;
int t,n,x[1001],y[1001],z[1001],a[21][21],ans,di[4][2]={-1,0,1,0,0,1,0,-1};
int main()
{
	scanf("%d",&t);
	for(int ii=1;ii<=t;ii++)
	{
	    scanf("%d",&n);
	    ans=0;
	    memset(a,0,sizeof(a));
	    for(int i=1;i<=n;i++)
	    {
	    	scanf("%d%d%d",&x[i],&y[i],&z[i]);
            a[x[i]][y[i]]=1;
		}
		for(int i=1;i<=n;i++)
		  if(z[i]==1)
	      {
	      	for(int j=0;j<=3;j++)
	      	{
			  int nx=x[i]+di[j][0];
			  int ny=y[i]+di[j][1];
			  if(a[nx][ny]!=1&&nx>=1&&nx<=19&&ny>=1&&ny<=19)
			    ans++;
			}
		  }
		printf("%d\n",ans);
	}
	return 0;
}