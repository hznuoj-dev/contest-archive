#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int n;
long long a[110][2];
ll gcd(ll a,ll b){
	if(b==0)return a;
	return gcd(b,a%b);
}
int main(int argc, char** argv) {
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i][0]>>a[i][1];
	}
	long long mx=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				ll p=0;
				ll x1=abs(a[i][0]-a[j][0]),y1=abs(a[i][1]-a[j][1]);
				ll x2=abs(a[i][0]-a[k][0]),y2=abs(a[i][1]-a[k][1]);
				ll x3=abs(a[j][0]-a[k][0]),y3=abs(a[j][1]-a[k][1]);
				double k1,k2;
				k1=1.0*(a[i][1]-a[j][1])/(1.0*(a[i][0]-a[j][0]));
				k2=1.0*(a[i][1]-a[k][1])/(1.0*(a[i][0]-a[k][0]));
				p+=gcd(x1,y1)+1;
				p+=gcd(x2,y2)+1;
				p+=gcd(x3,y3)+1;
				if(k1!=k2){
				    mx=max({mx,p});
			    }
			}
		}
		
	}
	cout<<mx-3<<endl;
	return 0;
}