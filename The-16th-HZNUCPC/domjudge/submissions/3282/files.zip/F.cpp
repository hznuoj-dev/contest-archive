#include "bits/stdc++.h"
using namespace std;
#define LL long long
bool solve(LL n,LL m){
	if(m == 1 || n == 1){
		return true;
	}
	else if (n % m == 0){
		return false;
	}
	if (n <= m){
		return false;
	}
	else {
		if ((n%m)*(n/m)+(n%m)>(m-n%m)*(n/m)){
			return solve(n,n % m); 
		}
		else{
			return solve(n,m-n%m);
		}
	}
}
int main(){
	LL n,m;
	cin >> n >> m;
	if(solve(n,m)){
		printf("YES\n");
	}else{
		printf("NO\n");
	}
}
