#include<bits/stdc++.h>
using namespace std;
signed main()
{
	long long n,m,b;
	int flag=0;
	cin>>n>>m;
	for(int t=2;t<=m;t++){
		if(n%t==0){
			flag=1;
			break;
		}
	}
	if(flag==1){
		cout<<"NO";
	}else if(flag==0){
		cout<<"YES";
	}
	/*if(n<1 || m<1){
		cout<<"NO";
		return 0;
	}
	while(m>1){
		m=n%m;
	}	
	if(m==1){
		cout<<"YES";
	}else if(m==0){
		cout<<"NO";
	}*/
		
	return 0;
}
