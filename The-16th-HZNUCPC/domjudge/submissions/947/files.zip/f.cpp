#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
typedef long long ll;
#define int long long
using namespace std;
int n,m;
signed main() {
    ios::sync_with_stdio(0); cin.tie(0);
    cin>>n>>m;
    if(n==1) return puts("YES"),0;
    if(n<=m) return puts("NO"),0;
    for(int i=2;i<=m&&i*i<=n;i++) if(n%i==0) return puts("NO"),0;
    puts("YES");
}
