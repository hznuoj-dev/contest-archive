#include <bits/stdc++.h>

using i64 = long long;

void solve() {
	std::string s;
	std::cin >> s;
	
	std::string t = "*";
	for (auto x : s) {
		t.push_back(x);
		t.push_back('*');
	}
	
	std::swap(s, t);
	
	int n = s.length();
	s = "&" + s;
			
	int ans = 1;
	for (int i = 1; i <= n; i++) {
		int cntDiff = 0;
		int offset;
		int off = -1;
		for (offset = 1; i - offset > 0 && i + offset <= n; offset++) {
			if (s[i - offset] != s[i + offset]) {
				if (cntDiff == 0) {
					cntDiff++;
					off = offset;
				} else if (cntDiff == 1) {
					cntDiff++;
					break;
				}
			}
		}
		if (cntDiff == 2) {
			assert(off != -1);
			if (s[i - offset] == s[i + off] && s[i - off] == s[i + offset]) {
				for (offset++; i - offset > 0 && i + offset <= n; offset++) {
					if (s[i - offset] != s[i + offset]) {
						break;
					}
				}
				offset--;				
//				if (i == 12) std::cerr << f << "!!!\n";
			} else if (s[i] != '*' && (s[i] == s[i - off] || s[i] == s[i + off])) {
//				offset = off - 1;
				offset--;
			} else {
				offset = off - 1;
			}
		} else if (cntDiff == 1) {
			if (s[i] != '*' && (s[i] == s[i - off] || s[i] == s[i + off])) {
				offset--;
			} else {
				offset = off - 1;
			}
		} else {
			offset--;
		}
//		std::cerr << i << " " << offset << "!\n";
		ans = std::max(ans, offset);
	}
	
	if (ans == 1) {
		ans = 0;
	}
	std::cout << ans << "\n";
}

int main() {
//	freopen("in.txt", "r", stdin);
	
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int t;
	std::cin >> t;
	
	while (t--) {
		solve();
	}

	return 0;
}

/*
4
abccab
ihi
stfgfiut
palindrome
*/
