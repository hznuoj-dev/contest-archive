#include <bits/stdc++.h>
using namespace std;
using ll =long long ;
ll n,m,k,cnt,sum;
int raw[25][25];
const int maxn=1e5+7;
ll mod = 1e9+7;
struct pos{
	ll l,r,sum;
	
};
ll fact[maxn];
void solve(){
	set<double> b;
	map<double,ll> mm;
	ll ly=-1e9-1,lx=-1e9-1;
	cin >> n;
	ll x,y;
	vector<pair<ll,ll>> a;
	vector<ll> num;
	for(int i = 0;i<n;i++){
		cin >> x >> y;
		a.push_back(pair<ll,ll>(x,y));
	}
	for(int i=0;i<n-2;i++){
		for(int j = i+1;j<n-1;j++){
			for(int k = j+1;k<n;k++){
				ll x1=a[i].first,x2=a[j].first,y1=a[i].second,y2=a[j].second,x3=a[k].first,y3=a[k].second;
				if ((x2-x1)*(y3-x2)!=(x3-x2)*(y2-y1)) {
					ll lx1,lx2,lx3,ly1,ly2,ly3;
					lx1 = abs(x2-x1);
					lx2 = abs(x3-x2);
					lx3 = abs(x3-x1);
					ly1= abs(y1-y2);
					ly2 = abs(y2-y3);
					ly3 = abs(y3-y1);
					sum = 0;
					if (lx1==0||ly1==0) sum+=max(lx1,ly1);
					else {
						sum+=__gcd(lx1,ly1);
					}
					
					if (lx2==0||ly2==0) sum+=max(lx2,ly2);
					else {
						sum+=__gcd(lx2,ly2);
					}
					
					if (lx3==0||ly3==0) sum+=max(lx3,ly3);
					else {
						sum+=__gcd(lx3,ly3);
					}
					num.push_back(sum);
					//num.push_back(__gcd(abs(y2-y1),abs(x2-x1))+__gcd(abs(y3-y1),abs(x3-x1))+__gcd(abs(y2-y3),abs(x2-x3)));
				}
			}
		}
	}
	sort(num.begin(),num.end(),greater<ll>());
	cout <<num[0]<<endl;
//	cout << ans << endl;
}
int main(){
	ll t;
	//cin >> t;
	//while(t--)
		solve();
}