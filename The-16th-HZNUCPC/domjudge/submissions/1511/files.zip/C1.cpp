#include<bits/stdc++.h>
using namespace std;
#define pb push_back
using ll=long long;
const int N=2e5+5,mod=1e9+7;
char s1[N],s2[N];
int n;
long long cnt[40][40];
long long cnt1[40], cnt2[40];
int main() {
	scanf("%s%s",s1+1,s2+1);
	n=strlen(s1+1);
	for(int i=1;i<=n;++i){
		int c1=s1[i]-'a',c2=s2[i]-'a';
		++cnt1[c1];
		++cnt2[c2];
		++cnt[c1][c2];
	}
	long long ans = 0;
	long long ans2 = 0;
	for (int i = 0; i < 26; i++) {
		for (int j = 0; j < 26; j++) {
			for (int i1 = 0; i1 < 26; i1++) {
				for (int j1 = 0; j1 < 26; j1++) {
					if (i == j && i1 == j1) {
						if (cnt[i][i1] < 2) continue;
						vector<int>tmp1(27), tmp2(27);
						for (int k = 0; k < 26; k++) tmp1[k] = cnt1[k], tmp2[k] = cnt2[k];
						tmp1[i]--, tmp1[j]--;tmp2[i1]--, tmp2[j1]--;
						tmp1[i1]++, tmp1[j1]++;tmp2[i]++, tmp2[j]++;
						int sum1 = 0, sum2 = 0;
						for (int k = 0; k < 26; k++) {
							if (tmp1[k]) sum1++;
							if (tmp2[k]) sum2++;
						}
						if (sum1 == sum2) ans += 1ll * cnt[i][i1] * (cnt[i][i1] - 1) / 2;
						ans %= mod;
						continue;
					}
					if (!cnt[i][i1] || !cnt[j][j1]) continue;
					vector<int>tmp1(27), tmp2(27);
					for (int k = 0; k < 26; k++) tmp1[k] = cnt1[k], tmp2[k] = cnt2[k];
					tmp1[i]--, tmp1[j]--;tmp2[i1]--, tmp2[j1]--;
					tmp1[i1]++, tmp1[j1]++;tmp2[i]++, tmp2[j]++;
					int sum1 = 0, sum2 = 0;
					for (int k = 0; k < 26; k++) {
						if (tmp1[k]) sum1++;
						if (tmp2[k]) sum2++;
					}
					if (sum1 == sum2) ans2 += 1ll * cnt[i][i1] * cnt[j][j1];
				}
			}
		}
	}
	ans2 /= 2;
	ans += ans2;
	ans %= mod;
	cout << ans << "\n";
}