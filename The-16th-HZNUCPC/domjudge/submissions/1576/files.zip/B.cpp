#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9 +7;
const int N = 1e3 +7;
ll t,n,m,s;

inline void run(){
   cin >> n >>m;
    while(n%m!=0&&n%m!=1) {
    	m = n %m;
	}
	if(m == 1) cout <<"YES\n";
	else if(n%m == 0) cout <<"NO\n";
	else cout <<"YES\n";
}
int main()
{
//      int T;
//      for(cin >>T;T--;)
	    run();
}
