#include<bits/stdc++.h>

using namespace std;
#define int long long
int x[150],y[150];
int solve(int l, int r)
{
	int xx=abs(x[l]-x[r]);
	int yy=abs(y[l]-y[r]);
	return __gcd(xx,yy);
}
signed main(){
	ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
	int n;
	cin >> n;
	for (int i=1; i<=n; i++)
	{
		cin >> x[i] >> y[i];
	}
	int ans=0;
	for (int i=1; i<=n; i++)
		for (int j=i+1; j<=n; j++)
			for (int k=j+1; k<=n; k++)
			{
				int res=solve(i,j)+solve(i,k)+solve(j,k);
				ans=max(ans,res);	
			}
	cout << ans << "\n";
}