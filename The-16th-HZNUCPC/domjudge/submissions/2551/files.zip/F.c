#include<stdio.h>
#include<math.h>
int main()
{
	long long n,m;
	long long i;
	while(scanf("%lld %lld",&n,&m)!=EOF)
	{		
		if(n==1 && m==2)
		{
			printf("YES\n");
		}
		if(n%m==0 && n!=1 && m!=2 || m%n==0 && n!=1 && m!=2)
		{
			printf("NO\n");
		}
		
		else
		{
			if(n>m && n!=1 && m!=2)
			{
				for(i=0;i<100000000005;i++)
				{
						if(m==2 && n%2==0)
						{
							printf("NO\n");
							break;
						}
						if(m==2 && n%2!=0)
						{
							printf("YES\n");
							break;
						}
						if(m>2 && n%m!=0)
						{
							m--;
						}
					if(n%m==0)
					{
						printf("NO\n");
						break;
					}
				}
			}
			if(m>n && m!=1 && m!=2)
			{
				n=m-1;
				if(n==1)
				{
					printf("YES\n");
				}
				for(i=0;i<1000000000005;i++)
				{
					if(m==2 && n%2==0)
					{
						printf("NO\n");
						break;
					}
					if(m==2 && n%2!=0)
					{
						printf("YES\n");
						break;
					}
						if(m>2 && n%m!=0)
					{
						m--;
					}
					if(n%m==0)
					{
						printf("NO\n");
						break;
					}
				}	
			}
		}
	}	
}