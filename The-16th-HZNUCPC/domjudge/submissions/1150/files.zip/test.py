res=0
a=list(input())
b=list(input())
l=len(a)
for i in range(l):
    for j in range(i+1,l):
        m1=a
        m2=b
        m1[i],m2[i]=m2[i],m1[i]
        m1[j],m2[j]=m2[j],m1[j]
        if len(set(m1))==len(set(m2)):
            res+=1
pritn(res)
