    #include  <bits/stdc++.h>

    using namespace std;
    typedef long long LL;
    const int mod = 1e9 + 7;

    LL n, m;

    void kizk(){
        cin >> n >> m;
        if(n == 1 || m == 1)
        {
            cout << "YES\n";
            return;
        }
        if(n <= m)
        {
            cout << "NO\n";
            return;
        }
        bool flg = true;
        for(int i = 2; i <= n / i; i ++)
            if(n % i == 0)
                flg = false;
        if(flg)
        {
            cout << "YES\n";
            return;
        }
        for(int i = 2; i <= min(1ll * int(sqrt(n)), m); i ++)
        {
            if(n % i == 0)
            {
                cout << "NO\n";
                return;
            }
        }
        cout << "YES\n";

    }


    int main(){
        std::ios::sync_with_stdio(false);
        cin.tie(nullptr);
        int T; T = 1;
        // cin >> T;
        while(T --) kizk();
        return 0;
    }