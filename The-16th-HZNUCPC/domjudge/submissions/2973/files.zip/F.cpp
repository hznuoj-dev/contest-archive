#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,k,t;
	cin>>n>>m;
		k=m;
		while(k>1){
			t = n%m;
			k = t%k;
		}
		if(k==1){
			cout <<"YES"<<endl;
		}else{
			cout <<"NO"<<endl;
		}
	
	return 0;
}