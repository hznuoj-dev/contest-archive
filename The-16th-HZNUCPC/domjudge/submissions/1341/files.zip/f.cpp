#include <bits/stdc++.h>

long long n, m;
std::vector<long long> v;
bool dfs (int m) {
	if (m == 1) return true;
	if (m >= v[0]) return false;
	bool ans = false;
	for (int i = 1; i < v[0]; i++) {
		//ö�����ֵ
		int cnt = n / i;
		int lev = n % i;
		if (cnt <= lev / (m - i) + (lev % (m - i) != 0)) {
			continue;
		}  
		ans = true;
	}
	return ans;
}

int main () {
	std::ios::sync_with_stdio(false);
	std::cin >> n >> m;
	int sz = sqrt(n);
	for (int i = 2; i <= sz; i++) {
		if (n % i) continue;
		v.emplace_back(i);
		if (i != n / i) v.emplace_back(n / i);
	}
	sort(v.begin(), v.end());
	if (!v.size()) {
		if (m >= n) std::cout << "NO\n";
		else std::cout << "YES\n";
		return 0;
	}
	bool ans = dfs(m);
	if (ans) std::cout << "YES\n";
	else std::cout << "NO\n";
}
