#include<iostream>
#include<cmath>

using namespace std;



//long long ma(long long x, long long y, long long z){
//	return max(x, max(y, z));
//}
//
//long long mi(long long x, long long y, long long z){
//	return min(x, min(y,z));
//}

long long gcd(long long x, long long y){
	return (y == 0)? x:gcd(y, x % y); 
}


typedef long long ll; 
long long x[105], y[105];
int main(){
	int n;
	cin >> n;
	for(int i = 0; i < n; ++i){
		cin >> x[i] >> y[i];
	}
	long long res = 0;
	for(int i = 0; i < n; ++i){
		for(int j = i + 1; j < n; ++j){
			for(int k = j + 1; k < n; ++k){
				if((x[k] - x[i]) * (y[j] - y[i]) == (y[k]-y[i]) * (x[j] - x[i])){
					continue;
				}
				
				long long kr = 0;
				long long k1x = abs(x[i] - x[j]);
				long long k1y = abs(y[i] - y[j]);
				long long g1 = gcd(k1x, k1y);
				kr += g1;

				long long k2x = abs(x[i] - x[k]);
				long long k2y = abs(y[i] - y[k]);
				long long g2 = gcd(k2x, k2y);
				kr += g2;

				long long k3x = abs(x[j] - x[k]);
				long long k3y = abs(y[j] - y[k]);
				long long g3 = gcd(k3x, k3y);
				kr += g3;
				if(g1 == 0){
					kr += k1x + k1y - 1;
				}
				
				if(g2 == 0){
					kr += k2x + k2y -1;
				}
				
				if(g3 == 0){
					kr += k3x + k3y - 1;
				}

				res = max(res, kr);
				
			}
		}
	}
	cout << res << endl;

}