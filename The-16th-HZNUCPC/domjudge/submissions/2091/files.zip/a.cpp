// #define DEBUG
#include <bits/stdc++.h>

using namespace std;
const int MOD = 1000000007;
const int INV2 = 500000004;
const int MAXN = 1e5 + 5;
#define int long long
#define endl '\n'

int q_pow(int a, int b) {
    int res = 1;
    for (; b; b >>= 1) {
        if (b & 1) res = res * a % MOD;
        a = a * a % MOD;
    }
    return res;
}

int dis[26][26][MAXN];
int fuck[26][26][5];

void solve() {
    string a, b; cin >> a >> b;
    int n = (int)a.size();
    vector<int> cntA(26);
    vector<int> cntB(26);
    int szA = 0, szB = 0;
    for (int i = 0; i < n; i ++ ) {
        cntA[a[i] - 'a'] ++;
        cntB[b[i] - 'a'] ++;
    }
    for (int i = 0; i < 26; i ++ ) {
        if (cntA[i] > 0) szA ++;
        if (cntB[i] > 0) szB ++;
    }
    auto calc = [&](int i ) {
        int res = 0;
        if (cntA[a[i] - 'a'] == 1) res ++;
        if (cntA[b[i] - 'a'] == 0) res --;
        if (cntB[a[i] - 'a'] == 0) res ++;
        if (cntB[b[i] - 'a'] == 1) res --;
        // if (cntA[a[i] - 'a'] == 1) dis[l][k][i] ++;
        // if (cntA[b[i] - 'a'] == 0) dis[l][k][i] --;
        // if (cntB[a[i] - 'a'] == 0) dis[l][k][i] ++;
        // if (cntB[b[i] - 'a'] == 1) dis[l][k][i] --;
        return res;
    };
    for (int l = 0; l < 26; ++l) {
        for (int k = 0; k < 26; ++k) {
            if (cntA[l] == 0 || cntB[k] == 0) continue;
            cntA[l]--, cntB[k]--,cntA[k]++, cntB[l]++;
            int pos = 0;
            for (int i = 0; i < n; ++i) {
                if (a[i] - 'a' == l && b[i] - 'a' == k) {pos = i; break;}
            }
            swap(a[pos], b[pos]);
            for (int i = 0; i < n; i ++ ) {
                if (pos == i) continue;
                dis[l][k][i] = calc(i);
                fuck[l][k][dis[l][k][i] + 2] ++;
            }
            swap(a[pos], b[pos]);
            cntA[l]++, cntB[k]++,cntA[k]--, cntB[l]--;
        }
    }
    // for (int i = 0; i < n; i ++ ) cout << dis[i] << ' ';
    // cout << endl;
    // for (int i = 0; i < 5; i ++ ) cout << fuck[i] << ' ';
    // cout << endl;
    int res = 0;
    for (int i = 0; i < n; i ++ ) {
        int d = szB - szA + calc(i);
        if (abs(d) > 2) continue;
        int x = a[i] - 'a', y = b[i] - 'a';
        d = -d;
        res = (res + fuck[x][y][d + 2]) % MOD;
        // cout << i << ":" << res << endl;
    }
    // cout << q_pow(2, MOD - 2) << endl;
    cout << (res + MOD) % MOD * INV2 % MOD << endl;
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    // cin >> T;
    // while (T--)
    {solve(); }
#ifdef DEBUG
    cerr << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}