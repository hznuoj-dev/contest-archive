package zime;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
			int n=sc.nextInt();
			int a[][]=new int[n][2];
			for(int i=0;i<n;i++)
			{
				 a[i][0]=sc.nextInt();
				 a[i][1]=sc.nextInt();
			}
			long ans=0;
			long count=0;
			for(int i=0;i<n-2;i++){
				for(int t=i+1;t<n-1;t++){
					for(int k=t+1;k<n;k++){
						if((Math.max(a[i][0], a[t][0])-Math.min(a[i][0], a[t][0]))*1.0/(Math.max(a[i][1], a[t][1])-Math.min(a[i][1], a[t][1])*1.0)==(Math.max(a[i][0], a[k][0])-Math.min(a[i][0], a[k][0]))*1.0/(Math.max(a[i][1], a[k][1])-Math.min(a[i][1], a[k][1])*1.0))
						{
							continue;
						}
						int ab=Math.max(a[i][0], a[t][0])-Math.min(a[i][0], a[t][0]);
						int ab2=Math.max(a[i][1], a[t][1])-Math.min(a[i][1], a[t][1]);
						ans=gcd(ab,ab2)-1;
						ans=ans+gcd(Math.max(a[i][0], a[k][0])-Math.min(a[i][0], a[k][0]),Math.max(a[i][1], a[k][1])-Math.min(a[i][1], a[k][1]))-1;
						ans=ans+gcd(Math.max(a[t][0], a[k][0])-Math.min(a[t][0], a[k][0]),Math.max(a[t][1], a[k][1])-Math.min(a[t][1], a[k][1]))-1;
						ans+=3;
						count=Math.max(count, ans);
					}
				}
			}
			System.out.println(count);
	 }
  }

	private static int gcd(int ab, int ab2) {
		return ab2==0?ab:gcd(ab2,ab%ab2);
	}

	
}

	
	

