#include<bits/stdc++.h>
#define int long long
#define fs first
#define sc second
using namespace std;
const int N=1e5+5,M=1e6+5;
int n,m,T;
struct node{
	double k,c;
	bool operator<(const node&x)const{
		return k>x.k;
	}
};
pair<double,double> a[105];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin >> n;
	for (int i=0;i<n;i++){
		cin >> a[i].fs >> a[i].sc;
	}
	set<node> se;
	for (int i=0;i<n;i++){
		for (int j=0;j<i;j++){
			double k=(a[i].fs-a[j].fs)/(a[i].sc-a[j].sc);
			double c=a[i].sc-a[i].fs*k;
			se.insert({k,c});
		}
	}
	cout << se.size()<<'\n';
	return 0;
}
/*
4
0 0
1 1
2 4
4 2

4
1 1
2 2
3 3
2 4

*/
