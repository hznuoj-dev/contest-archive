#include<bits/stdc++.h>

#define ll long long

using namespace std;


int main(){
	ll n,m;
	cin>>n>>m;
	map<ll,ll> mp;
	int f=0;
	if(m==1){
		cout<<"YES"<<endl;
		return 0;
	}
	while(1){
		m=n%m;
		if(m==1){
			f=1;
			break;
		}
		if(m==0){
			break;
		}
//		cout<<m<<endl;
		if(!mp[m]){
			mp[m]++;
		}else{
			break;
		}
	}
	if(f) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	
	return 0;
}