#include <iostream>
using namespace std;
int main()
{
	int n,m,i,h;
	cin>>n>>m;
	h=0;
	for(i=2;i<n;i++)
	{
		if(n%i==0)
		{
			h=1;
			break;
		}
	}
	if((m<n&&h==0&&n!=1&&n!=2)||m==1)cout<<"YES\n";
	else cout<<"NO\n";
}