#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
#define per(i,x,y) for(int i=x;i>=y;i--)
using namespace std;
#define int long long
const int mod=1e9+7;
const int N=2e5+10;
int qmi(int a,int b){
	int res=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
int n,m;
void solve(){
	cin>>n>>m;
	if(m>=n or n%m==0){
		cout<<"NO\n";
	}else{
		rep(i,2,n/i){
			if(n%i==0){
				int x=i,y=n/i;
				if(x<=m or y<=m){
					cout<<"NO\n";
					return;
				}
			}
		}
		cout<<"YES\n";
	}
}
signed main(){
	cin.tie(0)->sync_with_stdio(false);
	int tc=1;
	for(int i=1;i<=tc;i++){
		solve();
	}
}