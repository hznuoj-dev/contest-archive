#include<bits/stdc++.h>
using namespace std;

const int N = 1e5 + 5;
int n, m, q;
struct Data {
	int x, id;
};
int vis[N], sum[2], col[N];
vector <Data> e[N];
vector <int> v[2][N];
int cnt;
int dfs(int x, int c) {
	vis[x] = 1; col[x] = c;
	sum[c]++;
	v[c][cnt].push_back(x);
	for(auto y : e[x]) {
		if(!vis[y.x]) {
			if(!dfs(y.x, c ^ y.id)) return 0;
		}else if((col[x] ^ col[y.x]) != y.id) return 0;
	}
	return 1;
}
struct que {
	int x, id;
	bool operator < (const que &a)const {
		return x < a.x;
	}
}a[N];
struct DP {
	int val, y, last;
}dp[N];
int val[N];
int main() {
	ios :: sync_with_stdio(false);
	cin >> n >> q >> m;
	for(int i = 1; i <= m; i++) {
		int k, x, y; cin >> k >> x >> y;
		e[x].push_back((Data){y, k});
		e[y].push_back((Data){x, k});
	}
	for(int i = 1; i <= n; i++)
		if(!vis[i]) {
			++cnt;
			sum[0] = sum[1] = 0;
			if(!dfs(i, 0)) {
				cout << "NO\n";
				return 0;
			}
			if(sum[0] > sum[1]) {
				swap(v[0][cnt], v[1][cnt]);
			}
		}
//	cout << "N";
//	cout << cnt << "\n";
//	cout << v[0][1][0] << " " << v[0][1][1] << "\n";
/*	cout << cnt << "\n";
	for(int i = 1; i <= cnt; i++) {
		for(auto y : v[0][i]) {
			cout << y << " ";
		}cout << "\n";
		for(auto y : v[1][i]) {
			cout << y << " ";
		}cout << "\n";		
	}*/
	for(int i = 1; i <= cnt; i++)
		a[i].x = v[1][i].size() - v[0][i].size(), a[i].id = i;
	sort(a + 1, a + 1 + cnt);
	for(int i = 1; i <= n; i++)
		vis[i] = 0;
	for(int i = 1; i <= cnt; i++) {
		q -= v[0][i].size();
	}
//	cout << q << "\n";
	if(q < 0) {
		cout << "NO\n";
		return 0;	
	}
	dp[0].val = 1;
	for(int i = 1, j = 1; i <= cnt; i = j) {
		if(a[i].x == 0) {
			j++;
			continue;
		}
		for(; a[j].x == a[i].x; j++);
		int tot = j - i, flag = 1;
		for(int p = 1; flag; p *= 2) {
			if(p >= tot) {
				flag = 0;
				p = tot;
			}
			tot -= p;
//			cout << q - p * a[i].x << "\n";
			for(int k = q; k - p * a[i].x >= 0; k--)
				if(dp[k - p * a[i].x].val) {
					dp[k].val = 1;
//					cout << a[i].x << "dfs\n";
					dp[k].last = k - p * a[i].x;
					dp[k].y = a[i].x;
				}
		}
	}
//	cout << q << "dd\n";
	if(dp[q].val == 0) {
		cout << "NO\n";
		return 0;
	}
	cout << "YES\n";
	for(int i = q; i; i = dp[i].last) {
		int qz = i - dp[i].last;
		val[dp[i].y] += qz / dp[i].y;
	}
	for(int i = 1; i <= cnt; i++) {
		if(a[i].x == 0 || val[a[i].x]) {
			for(auto y : v[1][a[i].id]) 
				vis[y] = 1;
			val[a[i].x]--;
		}else {
			for(auto y : v[0][a[i].id]) 
				vis[y] = 1;
		}
	}
//	cout << _ << "\n";
	for(int i = 1; i <= n; i++)
		if(vis[i]) cout << i << " ";
	cout << "\n";
	return 0;
}
/*
4 2 4
1 1 3
1 2 4
0 3 4
0 1 2

2 1 2
1 1 2
0 2 1
uTeMSwAEpNdp

13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13

*/