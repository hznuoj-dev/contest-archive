import java.util.*;
import java.io.*;
import java.math.*;

public class Main {
	public static void main(String[] args) {
		InputStream inputStream = System.in;
		OutputStream outputStream = System.out;
		InputReader in = new InputReader(inputStream);
		PrintWriter out = new PrintWriter(outputStream);
		TaskA solver = new TaskA();
		solver.solve(1, in, out);
		out.close();
	}
	static class TaskA{
		class Node{
			int x,y;
			Node(int x,int y){
				this.x=x;
				this.y=y;
			}
		}
		int[] ax = {-1,0,1,0};
		int[] ay = {0,1,0,-1};
		void dfs(Node node){
			for(int i=0;i<4;i++){
				int nx = node.x+ax[i];
				int ny = node.y+ay[i];
				if(map[nx][ny]==1)
					f=0;
				else if(map[nx][ny]==1){
					vt[nx][ny]=1;
					dfs(new Node(nx,ny));
				}
			}
			if(f==1)map[node.x][node.y]=1;
		}
		int[][] map = new int[21][21];
		int[][]vt=new int[21][21];
		int f=1;
		public void solve(int testNumber,InputReader in,PrintWriter out){
			int t = in.nextInt();
			while(t-->0){
				int n = in.nextInt();
				List<Node> list = new ArrayList<>();
				List<Node> list2 = new ArrayList<>();
				map = new int[21][21];
				for(int i=1;i<=19;i++){
					for(int j=1;j<=19;j++){
						map[i][j] = 1;
					}
				}
				for(int i=0;i<n;i++){
					int x = in.nextInt();
					int y = in.nextInt();
					int c = in.nextInt();
					if(c==1){
						list.add(new Node(x,y));
						map[x][y]=0;
					}
					else{
						list2.add(new Node(x,y));
						map[x][y]=2;
					}
				}
				for(Node node:list2){
					f=1;
					if(vt[node.x][node.y]==0){
						vt[node.x][node.y]=1;
						dfs(node);
					}
					
				}
				int sum = 0;
				for(Node node:list){
					for(int i=0;i<4;i++){
						int nx = node.x+ax[i];
						int ny = node.y+ay[i];
						if(map[nx][ny]==1)
							sum++;
					}
				}
				
				out.println(sum);
			}
		}
	}
	static class InputReader{
		public BufferedReader reader;
		public StringTokenizer tokenizer;
		public InputReader(InputStream stream){
			reader = new BufferedReader(new InputStreamReader(stream),32768);
			tokenizer = null;
		
		}
		public boolean hasNext(){
			while(tokenizer==null||!tokenizer.hasMoreTokens()){
				try{
					tokenizer = new StringTokenizer(reader.readLine());
				}catch(Exception e){
					return false;
				}
			}
			return true;
		}
		public String next(){
			while(tokenizer==null||!tokenizer.hasMoreTokens()){
				try{
					tokenizer = new StringTokenizer(reader.readLine());
				}catch(IOException e){
					throw new RuntimeException(e);
				}
			}
			return tokenizer.nextToken();
		}
		public String nextLine(){
			String str = null;
			try{
				str = reader.readLine();
			}catch(IOException e){
				e.printStackTrace();
			}
			return str;
		}
		public int nextInt(){
			return Integer.parseInt(next());
		}
		public double nextDouble(){
			return Double.parseDouble(next());
		}
		public long nextLong(){
			return Long.parseLong(next());
		}
		public BigInteger nextBigInteger(){
			return new BigInteger(next());
		}
		public BigDecimal nextBigDecimal(){
			return new BigDecimal(next());
		}
	}
}
