#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ct(x) cout<<x<<'\n'
#define dg(x)  cout<<#x<<'='<<x<<'\n';
#define pii  pair<int,int> 
#define N 350000
#define double long double
#define ios ios::sync_with_stdio(0),cin.tie(0),cout.tie(0)

/*
4
0 0
1 1 
2 4 
4 2

6

4
1 1 
2 2 
3 3
2 4

4
*/


int check(int x1,int y1,int x2,int y2,int x3,int y3){
	int dx1=x2-x1;
	int dy1=y2-y1;
	int dx2=x3-x1;
	int dy2=y3-y1;
//	dg(x1)
//	dg(x2)
//	dg(x3)
//	dg(dy1)
//	dg(dy2)
	if(dx1*dy2+dx2*dy1==0){
		
		return 1;
	}
	return 0;
}

int sum(int x,int y){
	x=abs(x);
	y=abs(y);
	if(x==0)
	return y;
	else if(y==0)
	return x;
	int d=__gcd(x,y);
	return abs(d);
}

int f(int x1,int y1,int x2,int y2,int x3,int y3){
	int ans=0;
	ans+=sum(x2-x1,y2-y1);
	ans+=sum(x3-x1,y3-y1);
	ans+=sum(x3-x2,y3-y2); 

	return ans;
}


void solve(){
   int n;cin>>n;
   vector<pii> v(n);
   for(int i=0;i<n;i++)
   cin>>v[i].first>>v[i].second;
   int ans=-4e18;
   for(int i=0;i<n;i++)
     for(int j=i+1;j<n;j++)
       for(int k=j+1;k<n;k++){
       	if(check(v[i].first,v[i].second,v[j].first,v[j].second,v[k].first,v[k].second))
       	continue;
       
       	ans=max(ans,f(v[i].first,v[i].second,v[j].first,v[j].second,v[k].first,v[k].second));
	   }
	   ct(ans);
}

signed main(){
	ios;
	int t=1;
	// cin>>t;
	while(t--)
	solve();
	return 0;
}