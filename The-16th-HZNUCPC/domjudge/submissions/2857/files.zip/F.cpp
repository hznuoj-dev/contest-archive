#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>

using namespace std;

typedef long long LL;


int main()
{
	LL n, m;
	cin >> n >> m;
	
	if(n > m && n % m != 0) cout << "YES" << endl;
	else if(n > m && n % m == 0) cout << "NO" << endl;
	else if(n == m) cout << "NO" << endl;
	else cout << "NO" << endl;

	return 0;
}
