#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> PII;
ll n,m;
bool solve(){
    for(ll i = 2;i * i <= n; i++){
        if(n % i == 0){
            ll a = i,b = n / i;
            if(m > a || m > b)
                return 1;
        }
    }
    return 0;
}
int main() {
    scanf("%lld%lld",&n,&m);
    puts(solve()?"YES":"NO");
}