#include<bits/stdc++.h>
using namespace std;
int main()	{
	long long m, n;
	cin >> n >>m;
	if(m==1||n==1){
		cout<<"YES";
		return 0;
	}
	if(m>=n){
		cout<<"NO";
		return 0;
	}
	for(int i=2;i<=sqrt(n);++i){
		if(n%i==0){
			if(i>m)cout<<"YES";
			else cout<<"NO";
			return 0;
		}
	}
	cout<<"YES";
	return 0;
}