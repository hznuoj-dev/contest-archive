#include<bits/stdc++.h>
using namespace std;
int ap[1000][1000],z[1000],x[1000],y[1000];
bool f[1000][1000];
int main(){	
	int t,ans,n;
	cin>>t;
	for(int i=1;i<=t;i++){
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
		ap[i][j]=0;
		f[i][j]=false;
		}
	}
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>x[i]>>y[i]>>z[i];
			ap[x[i]][y[i]]=z[i];
		}
		for(int i=1;i<=n;i++){
			if(z[i]==1){
				if(ap[x[i]+1][y[i]]==0&&f[x[i]+1][y[i]]==false){
					f[x[i]+1][y[i]]=true;
					ans++;
				}
				if(ap[x[i]][y[i]+1]==0&&f[x[i]][y[i]+1]==false){
					ans++;
					f[x[i]][y[i]+1]=true;
				}
				if(ap[x[i]-1][y[i]]==0&&f[x[i]-1][y[i]]==false){
					f[x[i]-1][y[i]]=true;
					ans++;
				}
				if(ap[x[i]][y[i]-1]==0&&f[x[i]][y[i]-1]==false){
						f[x[i]][y[i]-1]=true;
						ans++;
				}
				}
			}
			cout<<ans<<'\n';
		}
	
	}