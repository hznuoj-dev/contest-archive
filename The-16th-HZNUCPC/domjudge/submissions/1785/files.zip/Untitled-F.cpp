#include <bits/stdc++.h>
using namespace std;
#define rep(a,b,c) for(int a=b;a<=c;a++)
#define per(a,b,c) for(int a=b;a>=c;a--)
#define output(a,b,c) cout<<a<<" "<<b<<" "<<c<<"\n"
#define ft first
#define sd second

typedef long long LL;
typedef unsigned long long ULL;

typedef pair<int,int> PII;
typedef pair<LL,LL> PLL;

const int N=1e6+5,M=5*N;

LL vis[N],pri[N];int pos=0;
void init(){
	rep(i,2,N-1){
		if(vis[i]){continue;}
		
		pri[++pos]=i;
		for(int j=2;i*j<=N-1;j++){
			vis[i*j]=1;
		}
	}
}



int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    
	init();
	LL n,m;cin>>n>>m;
	int jud=0;
	rep(i,1,pos){
		if(pri[i]>=n){break;}
		if(n%pri[i]==0&&n!=pri[i]){
			LL t=pri[i],k=n/t;
			//output(t,k,"");
			if(t<=m||k<=m){
				jud=1;break;
			}
		}	
	}
	cout<<(jud?"NO":"YES");
	
	


    return 0;
}