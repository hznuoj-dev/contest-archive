#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
    int n;
    int p[n][3];
	int a,b,c;
	standard input(a,b,c);
int main(int argc, char *argv[]) {
	int T;
	int a[361];
	scanf("%d",&T)
	int sum,t;
    for(t=1;t<=T,t++){
	for(i=0;i<n;i++){
		for(j=0;j<=2;j++)
		scanf("%d",&p[i][j]);
	}while(p[i][2]==1){
		a[19*(p[i][1]-1)+p[i][0]]=1;
	}
	for(i=1;i<=n;i++){
	while(p[i][2]==1){
				{score(p[i][j]);}
		sum+=score(p[i][j]);}
	}
	}
	printf("%d",&sum);
	return 0;
}
int score(int p[a][b]){
	int i;
	int sum;
	while(i<=4&&c==1){
		if((p[a][0]==1||p[a][1]==19||p[a][0]==1||p[a][1]==19)&&(a[19*(p[a][0]-1)]!=a[19*(p[a][0-1])]+1||a[19*(p[a][0]-1)]!=a[19*(p[a][0]-1)]-1
		                                 ||a[19*(p[a][0]-1)]!=a[19*(p[a][0]-1)-19]||a[19*(p[a][0]-1)]!=a[19*(p[a][0]-1)]+19){
		sum+=2;
	}
   if(a[19*(p[a][0]-1)]!=a[19*(p[a][0-1])]+1||a[19*(p[a][0]-1)]!=a[19*(p[a][0]-1)]-1
		                                 ||a[19*(p[a][0]-1)]!=a[19*(p[a][0]-1)-19]||a[19*(p[a][0]-1)]!=a[19*(p[a][0]-1)]+19){
   sum+=4;}
   if(a[19*(p[a][0]-1)]==a[19*(p[a][0-1])]+1||a[19*(p[a][0]-1)]==a[19*(p[a][0]-1)]-1
		                                 ||a[19*(p[a][0]-1)]==a[19*(p[a][0]-1)-19]||a[19*(p[a][0]-1)]==a[19*(p[a][0]-1)]+19){
   sum-=2;}
      if((p[a][0]==1||p[a][1]==19||p[a][0]==1||p[a][1]==19){
   sum-=1;}}
   i++}
   return sum;
}