#include <bits/stdc++.h>
using namespace std;

// #define DEBUG

const int maxn = 1e5 + 5;
const long long mod = 1e9 + 7;

string s1, s2;
int set1, set2, cnt1[30], cnt2[30];
map<int, int> t;
long long ans;

int main() {
	cin >> s1 >> s2;
	for (char c : s1) if (cnt1[c - 'a']++ == 0) set1++;
	for (char c : s2) if (cnt2[c - 'a']++ == 0) set2++;
	for (int i = 0; i < s1.size(); i++) {
		int tmp = 0;
		if (cnt2[s1[i] - 'a'] == 0) tmp--; //2++
		if (cnt1[s2[i] - 'a'] == 0) tmp++; //1++
		if (cnt1[s1[i] - 'a'] == 1) tmp--; //1--
		if (cnt2[s2[i] - 'a'] == 1) tmp++; //2--
		t[tmp]++;
		// printf("%d%c", tmp, " \n"[i == s1.size() - 1]);
	}
	for (int i = -2; i <= 2; i++) {
		for (int j = -2; j <= i; j++) {
			if (i + j == set2 - set1) {
				if (i == j) {
					ans += t[i] * (t[i] - 1) / 2;
					ans %= mod;
				}
				else {
					ans += t[i] * t[j];
					ans %= mod;
				}
			}
		}
	}
	printf("%lld\n", ans);
    return 0;
}