#include "bits/stdc++.h"
typedef long long int ll;
using namespace std;
 
const int N = 25;
int arr[N+1][N+1];
    
void solve(){
    // for(int i = 0; i <= N;i++) {
    //     for(int j = 0; j  <= N;j++) {
    //         arr[i][j] = 0;
    //     }
    // }
    memset(arr, 0, sizeof arr);
    int n;
    cin >> n;
    int ans = 0;
    for(int i =0 ; i < n;i++) {
        int x,y, op;
        cin >> x >> y >> op;
        arr[x][y] = op;
    }

    for(int i = 1; i <= 19;i++) {
        for(int j = 1; j <= 19 ;j++ ) {
            if(arr[i][j] == 0) {
                if( i + 1 <= 19) {
                    ans+=arr[i+1][j] == 1;
                }
                if( i - 1 > 0) {
                    ans+=arr[i-1][j] == 1;
                }
                 if( j + 1 <= 19) {
                     ans+=arr[i][j+1] == 1;
                }
               if( j-1 > 0) {
                    ans+=arr[i][j-1] == 1;
                }
            }
        }
    }

    cout << ans << endl;
    
     


    return ;


}



int main (){
    int t = 1;
    cin >> t;
    while (t--){
        solve();
    }

    return 0;
}
/*

1 2
10 9 1
10 10 1
 
*/