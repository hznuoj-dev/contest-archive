n, m = map(int, input().split())
l = []
for i in range(m):
    u, v, w = map(int, input().split())
    l.append([u,v,w])
l.sort(key=lambda x:x[0])
maxn = 0
p = l[0]
s= {p[2]}
for i in l[1:]:
    if p[1] >= i[0]:
        p[1] = max(p[1], i[1])
        s.add(i[2])
    else:
        t =0
        while t in s:
            t += 1
        maxn = max(maxn, t)
        p = i
        s={p[2]}
t = 0
while t in s:
    t += 1
maxn = max(maxn, t)
print(maxn)
        