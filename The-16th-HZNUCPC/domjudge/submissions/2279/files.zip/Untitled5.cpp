#include<bits/stdc++.h>
#define ll long long
int n;
using namespace std;
ll sum[12][12],st,output;
ll xl,yu,xr,yd,j;
struct aa
{
	int y;int x;
	bool operator<(const aa &a)const
	{
		return sum[y][x]>sum[a.y][a.x];
	}
	
};
set<aa>arr;
int cal(int bas,int x)
{
	return (bas+10-x)/10;
}
void solve(){
   int n,m,q;
   cin>>n>>m>>q;
   for(int i=1;i<=n;i++)for(int j=1;j<=m;j++)cin>>st,sum[i%10][j%10]+=st;
   while(q--)
   {
   	  //cin>>j>>xl>>yu>>xr>>yd>>st;
   	  cin>>j>>yu>>xl>>yd>>xr>>st;
   	  if(j==1)
   	  {
   	  	  for(int i=0;i<10;i++)for(int j=0;j<10;j++)
   	  	  {
   	  	  	sum[i][j]+=1ll*(cal(xr,j)-cal(xl-1,j))*(cal(yd,i)-cal(yu-1,i))*st;
		}
	  }
	  else
	  {
	  	//for(int i=0;i<10;i++)
		 // {
		 // for(int j=0;j<10;j++)cout<<sum[i][j]<<" ";cout<<'\n';
	//}
	  	output=0;arr.clear();
	  	  for(int i=0;i<10;i++)for(int j=0;j<10;j++)
	  	  {
	  	  	output+=sum[i][j];
	  	  	if(1ll*(cal(xr,j)-cal(xl-1,j))*(cal(yd,i)-cal(yu-1,i)))arr.insert({i,j});
		 }
		 for(auto k:arr)
		 {
		 	if(!st)break;
		 	output+=sum[k.y][k.x];
		 	//cout<<k.y<<"*"<<k.x<<"*"<<sum[k.y][k.x]<<'\n';
		 	st--;
		 }
		 cout<<output<<'\n';
	  }
   }
}

int main(){
	//freopen("2.in","r",stdin);
	int t=1;//std::cin>>t;
	while( t-- )
		solve();
}