#include <bits/stdc++.h>
using namespace std;
long long n, m;
int ans,tag;
int main() {
	scanf("%lld%lld", &n, &m);
	for (long long i = 2; i * i <= n ; ++ i){
		if(n%i==0){
			if(m<i){
				ans=1;
			}
			tag=1;
			break;
		}
	}
	if(!tag&&m<n)ans=1;
	if(m==1)ans=1;
	if(ans)printf("YES\n");
	else printf("NO\n");
	return 0;
}
//