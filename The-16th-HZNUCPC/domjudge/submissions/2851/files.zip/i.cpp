#include <bits/stdc++.h>

const int maxn = 5005;

unsigned long long f[maxn][2], p[maxn][2];

const int base = 13331;

bool check(int A, int B, int C, int D) {
	return f[B][0] - f[A - 1][0] * p[B - A + 1][0]
				== f[C][1] - f[D + 1][1] * p[B - A + 1][0];
}

int main () {
	std::ios::sync_with_stdio(false);
	int _;
	std::string s;
	std::cin >> _;
	while (_--) {
		int ans = 0;
		std::cin >> s;
		f[0][0] = 0, p[0][0] = 1;
		int n = s.size();
		f[n + 1][1] = 0, p[n + 1][1] = 1;
		for (int i = 1; i <= n; i++) {
			f[i][0] = f[i - 1][0] * base + s[i - 1] - 'a' + 1;
			p[i][0] = p[i - 1][0] * base;
		}
		for (int i = n; i >= 1; i--) {
			f[i][1] = f[i + 1][1] * base + s[i - 1] - 'a' + 1;
			p[i][1] = p[i + 1][1] * base;
		}
		for (int i = 1; i <= n; i++) {
			int L = 1, R = n, p1 = 0;
			while (L <= R) {
				int mid = (L + R) >> 1;
				if (i - mid < 1 || i + mid > n) {
					R = mid - 1;
					continue;
				}
				if (check(i - mid, i - 1, i + 1, i + mid)) {
					p1 = mid;
					L = mid + 1;
				}
				else {
					R = mid - 1;
				}
			}
			if (p1 > 0) {
				ans = std::max(ans, p1 * 2 + 1);
			}
			if (i - p1 - 1 < 1 || i + p1 + 1 > n) {
				continue;
			}
			std::set<int> s1;
			s1.insert(s[i - p1 - 2] - 'a');
			s1.insert(s[i + p1] - 'a');
			L = 1, R = n;
			int p2 = 0;
			while (L <= R) {
				int mid = (L + R) >> 1;
				if (i - p1 - 1 - mid < 1 || i + p1 + 1 + mid > n) {
					R = mid - 1;
					continue;
				}
				if (check(i - p1 - 1 - mid, i - p1 - 2, i + p1 + 2, i + p1 + 1 + mid)) {
					p2 = mid;
					L = mid + 1;
				}
				else {
					R = mid - 1;
				}
			}
			int f = 0;
			for (auto it : s1) if (s[i - 1] - 'a' == it) f = 1;
			if (f) {
				ans = std::max(ans, (p1 + p2 + 1) * 2 + 1);
			}
			if (i - p1 - p2 - 2 < 1 || i + p1 + p2 + 2 > n) {
				continue;
			}
			std::set<int> s2;
			s2.insert(s[i - p1 - p2 - 3] - 'a');
			s2.insert(s[i + p1 + p2 + 1] - 'a');
			if (s1 != s2) continue;
			L = 1, R = n;
			int p3 = 0;
			while (L <= R) {
				int mid = (L + R) >> 1;
				if (i - p1 - p2 - 2 - mid < 1 || i + p1 + p2 + 2 + mid > n) {
					R = mid - 1;
					continue;
				}
				if (check(i - p1 - p2 - 2 - mid, i - p1 - p2 - 3, i + p1 + p2 + 3, i + p1 + p2 + 2 + mid)) {
					p3 = mid;
					L = mid + 1;
				}
				else {
					R = mid - 1;
				}
			}
			ans = std::max(ans, (p1 + p2 + p3 + 2) * 2 + 1);
		}
	
		for (int i = 1; i <= n; i++) {
			int L = 1, R = n, p1 = 0;
			while (L <= R) {
				int mid = (L + R) >> 1;
				if (i - mid + 1 < 1 || i + mid > n) {
					R = mid - 1;
					continue;
				}
				if (check(i - mid + 1, i, i + 1, i + mid)) {
					p1 = mid;
					L = mid + 1;
				}
				else {
					R = mid - 1;
				}
			}
			if (p1 > 0) {
				ans = std::max(ans, p1 * 2);
			}
			if (i - p1 < 1 || i + p1 + 1 > n) {
				continue;
			}
			std::set<int> s1;
			s1.insert(s[i - p1 - 1] - 'a');
			s1.insert(s[i + p1] - 'a');
			L = 1, R = n;
			int p2 = 0;
			while (L <= R) {
				int mid = (L + R) >> 1;
				if (i - p1 - mid < 1 || i + p1 + 1 + mid > n) {
					R = mid - 1;
					continue;
				}
				if (check(i - p1 - mid, i - p1 - 1, i + p1 + 2, i + p1 + 1 + mid)) {
					p2 = mid;
					L = mid + 1;
				}
				else {
					R = mid - 1;
				}
			}
			if (i - p1 - p2 - 1 < 1 || i + p1 + p2 + 2 > n) {
				continue;
			}
			std::set<int> s2;
			s2.insert(s[i - p1 - p2 - 2] - 'a');
			s2.insert(s[i + p1 + p2 + 1] - 'a');
			if (s1 != s2) continue;
			L = 1, R = n;
			int p3 = 0;
			while (L <= R) {
				int mid = (L + R) >> 1;
				if (i - p1 - p2 - 1 - mid < 1 || i + p1 + p2 + 2 + mid > n) {
					R = mid - 1;
					continue;
				}
				if (check(i - p1 - p2 - 1 - mid, i - p1 - p2 - 2, i + p1 + p2 + 3, i + p1 + p2 + 2 + mid)) {
					p3 = mid;
					L = mid + 1;
				}
				else {
					R = mid - 1;
				}
			}
			ans = std::max(ans, (p1 + p2 + p3 + 2) * 2);
		}
		std::cout << ans << "\n";
	}
}
