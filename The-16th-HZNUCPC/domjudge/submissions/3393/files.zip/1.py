n,m=map(int,input().split())
if n==1 or m==1:
    print("YES")
elif n<=m:
    print("NO")
else:
    flag=0
    while True:
        x=n%m
        if x==1:
            flag=1
            break
        elif x==0:
            break
        else:
            m=x
    if flag==1:
        print("YES")
    else:
        print("NO")
    
