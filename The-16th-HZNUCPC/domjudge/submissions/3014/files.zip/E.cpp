#include <bits/stdc++.h>
using namespace std;
const int N=105;

struct d{
	long long x;
	long long  y;
}a[N];

long long s[N][N];
long long ans=-2e9;

void suan(int i,int j)
{
	long long  x1=a[i].x,y1=a[i].y,x2=a[j].x,y2=a[j].y;
	
	long long xx=abs(x2-x1),yy=abs(y2-y1);
	
	if (xx==0||yy==0)
	{
		if (xx)
			s[i][j]=xx-1,s[j][i]=xx-1;
		else
			s[i][j]=yy-1,s[j][i]=yy-1;
			
		return;
	}
	//除最大公约数
	
	long long c=1;
	long long n=abs(xx);
	long long m=abs(yy);	
	
	
		while (n%m!=0)
		{	c=n%m;
			n=m;
			m=c;
		}	
		
	xx=xx/abs(m);
	yy=yy/abs(m);
	
	
	//100000
	
	long long h=abs(x2-x1)/xx-1;
	s[i][j]=h;
	s[j][i]=h;
}

int main()
{	memset(s,-1,sizeof s);
	int n;
	cin>>n;
	for (int i=1;i<=n;i++)
	{
		cin>>a[i].x>>a[i].y;
	}
	
	for (int i=1;i<=n;i++)
		for (int j=i+1;j<=n;j++)
			if (s[i][j]==-1)
				suan(i,j);	
		
	
	
	
	
	for (int i=1;i<=n;i++)
		for (int j=i+1;j<=n;j++)
			for (int k=j+1;k<=n;k++)
			{	double k1,k2;
			
				if (a[i].x==a[j].x&&a[i].x==a[k].x&&a[k].x==a[j].x)
					continue;
				if (a[i].y==a[j].y&&a[i].y==a[k].y&&a[k].y==a[j].x)
					continue;
			
				k1=(a[i].y-a[j].y)*1.0/(a[i].x-a[j].x);
				k2=(a[k].y-a[j].y)*1.0/(a[k].x-a[j].x);
				
				if (k1==k2)
					continue;
				
				
				long long p=s[i][j]+s[i][k]+s[j][k];
				ans=max(ans,p);
			}
				
				
	if (ans==-2e9)
		printf("0");
	else			
		printf("%lld",ans+3);
	
	return 0;
}