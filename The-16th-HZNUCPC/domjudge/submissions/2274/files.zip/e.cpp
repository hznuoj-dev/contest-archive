#include <bits/stdc++.h>
using namespace std;
#define int long long
#define ll long long
const ll mod=1e9+7;
ll qpow(ll a,ll b)
{
    ll ans=1;
    while(b)
    {
        if(b&1)
        {
            // a=a*a%mod;
            ans=ans*a%mod;
        }
        a=a*a%mod;
        b>>=1;
    }
    return ans;

}
void solve(){
    string a,b;
    cin>>a>>b;
    map<pair<int,int>,int> mp;
    ll ans=0;
    map<int,int> mpa,mpb;
    for (int i = 0; i < a.size(); i++)
    {
        mpa[a[i]]++;
        mpb[b[i]]++;
        mp[make_pair(a[i],b[i])]++;
    }
    for (int i = 'a'; i <= 'z'; i++)
    {
        for (int j = 'a'; j <='z'; j++)
        {
            for (int ki = 'a'; ki <='z';ki++)
            {
                for (int kj = 'a'; kj <='z'; kj++)
                {
                    pair<int,int> p1=make_pair(i,ki);
                    pair<int,int> p2=make_pair(j,kj);
                    mpa[i]--;
                    mpa[j]--;
                    mpa[ki]++;
                    mpa[kj]++;
                    mpb[ki]--;
                    mpb[kj]--;
                    mpb[i]++;
                    mpb[j]++;
                    int se1=0,se2=0;
                    for (int tmp = 'a'; tmp <= 'z'; tmp++)
                    {
                        if(mpa[tmp]!=0)se1++;
                        if(mpb[tmp]!=0)se2++;
                    }
                    mpa[i]++;
                    mpa[j]++;
                    mpa[ki]--;
                    mpa[kj]--;
                    mpb[ki]++;
                    mpb[kj]++;
                    mpb[i]--;
                    mpb[j]--;
                    if(se1!=se2||mp[p1]==0||mp[p2]==0)
                        continue;
                    // cout<<"p1:"<<p1.first<<" "<<p1.second<<"\n";
                    // cout<<"p2:"<<p2.first<<" "<<p2.second<<"\n";
                    if(p1!=p2){
                        ans=(ans+(mp[p1]*mp[p2])%mod)%mod;
                    }else{
                        ans=(ans+(mp[p1]*(mp[p2]-1))%mod)%mod;
                    }
                }
            }
            
        }
    }
    cout<<ans*qpow(2,mod-2)%mod<<"\n";
    
}
signed main(){
    int t=1;
    ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
    // scanf("%d",&t);
    while (t--)
    {
        solve();
    }
}