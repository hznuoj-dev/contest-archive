#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int f[21][21]={0};
void solve()
{
	int n,ans=0;
	cin>>n;
	for(int i=0;i<n;i++){
		int x,y,c;
		cin>>x>>y>>c;
		f[x][y]=c;
	}
	for(int x=1;x<=19;x++){
		for(int y=1;y<=19;y++){
			if(f[x][y]==1){
				if(f[x-1][y]==0){
					ans++;
					
				}
				if(f[x+1][y]==0){
					ans++;
				
				}
				if(f[x][y+1]==0){
					ans++;
				
				}
				if(f[x][y-1]==0){
					ans++;
					
				}
			}
		}
	}
	cout<<ans<<endl;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
				f[i][j]=0;
			
		}
	}
}
int main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	ll t=1;
	cin>>t;
	for(int i=0;i<=20;i++){
		for(int j=0;j<=20;j++){
			if(i==0||i==20||j==0||j==20){
				f[i][j]=2;
			}
		}
	}
	while(t--)
	{
		solve();
	//	cout<<'\n';
	}
}