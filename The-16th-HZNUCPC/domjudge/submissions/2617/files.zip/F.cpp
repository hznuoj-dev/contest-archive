#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll min(ll x, ll y){
	if(x < y) return x;
	return y;
}
bool is_prime(ll x,ll m){
	ll len = min(sqrt(x) + 1, m);
	for (int i=2;i <= len;i++){
		if (x%i==0){
			return false;
		}
	}
	return true;
}
int main(){
	ll  n,m;
	while(cin>>n>>m){
		if(is_prime(n, m) && n > m){
			cout << "YES" << endl;
		}else{
			cout << "NO" << endl;
		}
		
	}
	return 0;
}
