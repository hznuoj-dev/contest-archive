#include<cstdio>

long long gcd(long long a,long long b){
	return (a%b)?gcd(b,a%b):b;
}

int main(){
//	freopen("data.in","r",stdin);
	long long n,m;
	scanf("%lld%lld",&n,&m);
	if(n<=m && n>1){
		puts("NO");
		return 0;
	}
	for(long long i=2;i*i<=n && i<=m;++i){
		if(n%i==0){
			puts("NO");
			return 0;
		}
	}
	puts("YES");
	return 0;
}