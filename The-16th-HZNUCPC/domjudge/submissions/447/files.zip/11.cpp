#include<bits/stdc++.h>
using namespace std;
#define int long long

signed main(){
	int m,n;
	scanf("%lld%lld",&n,&m);	
	
	if(m==1||n==1){
		printf("YES\n");
		return 0;	
	}
	if(n<=m) printf("NO\n");
	else{
		if(n%2==0) printf("NO\n");
		else{
			int f=1,ans=0;
			for(int i=2;i*i<=n;i++){
				if(n%i==0){
					ans=i;
					break;
				}
			}
			//printf("%lld ***\n",ans);
			if(ans<=m&&ans!=0) printf("NO");
			else printf("YES\n");
			
		}
		
	}
	
	return 0;
}