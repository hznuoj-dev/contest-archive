#include<bits/stdc++.h>
#define int long long
#define ll long long
#define vi vector<int>
#define pb push_back

using namespace std;
int n;
int a[107],b[107];
int len[107][107];
int cl(int l,int r){
	int dx=abs(a[l]-a[r]);
	int dy=abs(b[l]-b[r]);
	int res=__gcd(dx,dy)+1;
	return res;
}
int cj(int x1, int y1, int x2, int y2) {
	return x1 * y2 - x2 * y1;
}
bool check(int x1, int y1, int x2, int y2, int x3, int y3) {
	if (cj(x2 - x1, y2 - y1, x3 - x1, y3 - y1) == 0) return 0;
	return 1;
}
signed main() {
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i]>>b[i];
	}
	int res=0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			len[i][j]=cl(i,j);
//			cout<<len[i][j]<<" ";
		}
//		cout<<"\n";
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				if(check(a[i],b[i],a[j],b[j],a[k],b[k]))
					res=max(res,len[i][j]+len[i][k]+len[j][k]-3);
			}
		}
	}
	cout<<res;
	
	
	return 0;
}
/*
4
0 0
1 1
2 4
4 2




4
1 1
2 2
3 3
2 4


*/