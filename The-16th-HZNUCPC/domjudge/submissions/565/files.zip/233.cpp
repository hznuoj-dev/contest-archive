#include<bits/stdc++.h>
using namespace std;
#define rep(i,l,r) for(int i=(l);i<=(r);i++)
using ll =long long ;

map<pair<int,int>,int> m;
int dx[]={0,0,1,-1};
int dy[]={1,-1,0,0};
void solve(){
    int n;cin>>n;
    int ans=0;
    m.clear();
    rep(i,1,n){
        int x,y,c;cin>>x>>y>>c;
        m[{x,y}]=c;
    }
    for(auto [p,c]:m){
        if(c==2)continue;
        rep(o,0,3){
            int nx=p.first+dx[o],ny=p.second+dy[o];
            if(nx<=0||ny<=0||nx>19||ny>19)continue;
            if(!m.count({nx,ny}))++ans;
        }
    }
    cout<<ans<<endl;
}

int main() {
    //freopen("in.txt","r",stdin);
    int t;cin>>t;
    while(t--)solve();
	return 0;
}
