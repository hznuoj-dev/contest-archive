#include<bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(),(a).end;
using namespace std;

void solve()
{
	ll n, m;
	cin >> n >> m;
	
	if(m == 1)
	{
		cout << "YES" << '\n';
		return;
	}
	if(n <= m)
	{
		cout << "NO" << '\n';
		return;
	}
	
	int mifac = -1;
	for(ll i = 2; i * i <= n; i++)
	{
		if(n % i == 0)
		{
			mifac = i;
			
			ll x = n / mifac;
			ll y = -1;
			if(m - mifac)
			{
				y = (n - x * mifac) / (m - mifac);
				if((n - x * mifac) % (m - mifac)) y++;
			}
	
			if(x > y)
			{
				cout << "NO" << '\n';
				return;
			}
		}
	}
	
	cout << "YES" << '\n';
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t--) solve();
	return 0;
}