#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};
bool check(int x,int y){
	return x>0&&x<20&&y>0&&y<20;
}
void solve(){
	int n;
	cin>>n;
	int res=0;
	map<pair<int,int>,int> mp;
	for(int i=1,a,b,c;i<=n;i++){
		cin>>a>>b>>c;
		mp[{a,b}]=c;
	}
	for(auto [p,c]:mp){
		auto [x,y]=p;
		if(c==1)
		for(int i=0;i<4;i++){
			if(check(x+dx[i],y+dy[i])&&!mp.count({x+dx[i],y+dy[i]})){
				res++;
			}
		}
	}
	cout<<res<<'\n';
}
int main(){
	ios::sync_with_stdio(0);
	int T=1;
	cin>>T;
	while(T--){
		solve();
	}
}