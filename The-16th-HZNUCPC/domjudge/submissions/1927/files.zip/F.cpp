#include <bits/stdc++.h>
using namespace std;

long long mod1(int n,int m){
	int k=n;
	while(k>=m)k-=m;
	return k;
}

int main()
{	
    long long n,m;
	//while(cin>>n>>m){
	cin>>n>>m;

	int flag=1;
	
	while(m>1){
		m=mod1(n,m);
		if(m==0){
			flag=0;
			break;
    	}
    	//cout<<' '<<m;
	}
	
	
	if(flag)printf("YES");
	else printf("NO");
	//cout<<'\n';
	//}
	return 0;
}
//1000000000000
//99999999999