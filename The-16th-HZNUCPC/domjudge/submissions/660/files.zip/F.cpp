#include<iostream>
using namespace std;


bool fact(int n, int m);

int main()
{
	int n = 0;
	int m = 0;
	cin >> n >> m;
	if (fact(n, m))
	{
		cout << "YES";
	}
	else
	{
		cout << "NO";
	}
	return 0;
}

bool fact(int n, int m)
{
	if (m == 1)
	{
		return 1;
	}
	if (n % m == 0)
	{
		return 0;
	}
	fact(n, n % m);
}
