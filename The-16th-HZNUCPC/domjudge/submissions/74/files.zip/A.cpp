#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	ll a, b;
	int flag = 0;
	cin >> a >> b;
	if(b == 1) {
		cout << "YES\n";
		return 0;
	}
	while(1) {
		b = a % b;
		if(b == 1) {
			flag = 1;
			break;
		} else if(b == 0) {
			flag = 0;
			break;
		}
	}
	if(flag) {
		cout << "YES\n";
	} else {
		cout << "NO\n";
	}
	return 0;
}