#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m;
signed main(){
	while(cin>>n>>m){
		if(n==1||m==1||n-m==1){
			cout<<"YES"<<endl;
			continue;
		}
		if(n<=m){
			cout<<"NO"<<endl;
			continue;
		}
		int f=0;
		while(m!=1){
			if(n%m==0||m<=0){
				f=1;
				break;
			}
			m-=n/m;
		}
		if(f==0){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
 
  