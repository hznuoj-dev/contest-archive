#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

float x,y,n,m,a;
int main()
{
	cin>>n>>m;
	if(m == 1)printf("YES");
	else if (n % m == 0 || m >= n || n % 2==0) printf("NO");
	else if(m == 2) printf("YES");
	
	return 0;
}

