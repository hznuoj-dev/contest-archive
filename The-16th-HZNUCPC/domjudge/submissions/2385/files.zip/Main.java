import java.util.Scanner;


public class Main {    
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			long n=in.nextLong();
			long m=in.nextLong();
				while(m!=1&&n%m!=0){
					m=n%m;
				}
				if(m==1){
					System.out.println("YES");
				}else{
					System.out.println("NO");
				}
			}
		
	}
}
