#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
#include<string>
#include<cstdio>
#include<queue>
#include<map>
#include<vector>
#define int long long
#define FOR(i,m,n) for(int i = m;i <= n;i++)
#define CLR(arr,value) memset(arr,value,sizeof arr)
using namespace std;
const int N = 0x3f3f3f;
int n,m;
int a[N];
signed main()
{
	cin >> n >> m;
	if(m > n) puts("NO");
	else
	{
		if(n % m == 0) puts("NO");
		else puts("YES");
	}
}