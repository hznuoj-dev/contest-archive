#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m;
	while(cin>>n>>m){
		bool flag =true;
		if(n<m &&m!=1)flag =false;
		while(m!=1){
			if(n%m==0){
				flag = false;
				break;
			}
			m= n%m;
	
		}
		if(flag|| n==1){
			cout <<"YES"<<endl;
		}else{
			cout <<"NO"<<endl;
		}
	}
	return 0;
}