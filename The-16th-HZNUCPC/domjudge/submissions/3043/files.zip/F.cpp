#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
signed main(){
	while(cin>>n>>m){
		if(n%m!=0||m==1){
			cout<<"YES"<<endl;
		}else cout<<"NO"<<endl;
	}
	return 0;
}