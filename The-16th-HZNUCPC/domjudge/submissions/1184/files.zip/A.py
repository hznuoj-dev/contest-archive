def check(i,j):
	global sum
	x1 = [0,0,-1,1]
	y1 = [1,-1,0,0]
	for i in range(4):
		x = i+x1[i]
		y = j+y1[i]
		if 1<=x<=19 and 1<=y<=19 and stone[x][y] == 0:
			sum += 1
		elif 1<=x<=19 and 1<=y<=19 and stone[x][y] == 0:
			stone[x][y] = 3
			check(x,y)

def work():
	for i in range(20):
		for j in range(20):
			if stone[i][j] == 1:
				check(i,j)

T = int(input())
for i in range(T):

	n = int(input())
	stone = [[[0] for j in range(20)] for i in range(20)]
	sum = 0

	for j in range(n):
		x,y,c = map(int,input().split())
		stone[x][y] = c
	work()
	print(sum)
