#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+10;
int vis[30][30];
int n;
ll x[N],y[N];
bool check(int x1,int y1,int x2,int y2,int x3,int y3)
{
	ll k1=(y1-y2)*(x3-x2);
	ll k2=(x1-x2)*(y3-y2);
	if(k1==k2) return false;
	return true;
}
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld%lld",&x[i],&y[i]);
	}
	ll ans=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				if(check(x[i],y[i],x[j],y[j],x[k],y[k]))
				{
					ll cha12=x[i]-x[j],cha23=x[j]-x[k],cha13=x[i]-x[k];
					ll y12=y[i]-y[j],y23=y[j]-y[k],y13=y[i]-y[k];
					
					ll gcd12=__gcd(abs(cha12),abs(y12)),gcd23=__gcd(abs(cha23),abs(y23)),gcd13=__gcd(abs(cha13),abs(y13));
					//cout<<gcd12<<" "<<gcd23<<" "<<gcd13<<"\n";
					ans=max(ans,gcd12+gcd23+gcd13);
				}
			}
		}
	}
	printf("%lld\n",ans);
}
