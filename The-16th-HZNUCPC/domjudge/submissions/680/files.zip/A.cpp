    #include<iostream>

    using namespace std;

    int board[21][21];
    int black[400][2];
    int kmove[4][2] = {{0,-1},{0,1},{-1,0},{1,0}};

    int main(){

        int T;
        int n;
        int bn;
        int x,y;
        int color;
        int num;
        cin>>T;
        while(T-->0){
            cin>>n;
            num = 0;
            bn = 0;
            for(int i = 0;i<21;++i){
                for(int j = 0;j<21;++j){
                    board[i][j] = 0;
                }
            }
            for(int i = 0;i<n;++i){
                cin>>x>>y>>color;
                board[x][y] = color;
                if(color == 1){
                    black[bn][0] = x;
                    black[bn][1] = y;
                    bn+=1;
                }
            }
            for(int i = 0;i<bn;++i){
                for(int k = 0;k<4;++k){
                    if(black[i][0]+kmove[k][0]>0&&black[i][0]+kmove[k][0]<20){
                        if(black[i][1]+kmove[k][1]>0&&black[i][1]+kmove[k][1]>0){
                            if(board[black[i][0]+kmove[k][0]][black[i][1]+kmove[k][1]] == 0){
                                num+=1;
                            }
                        }
                    }
                }
            }
            cout<<num<<endl;
        }

    }
