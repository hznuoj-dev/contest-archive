# include "bits/stdc++.h"
using namespace std;
# define int long long

int n, m;

signed main(){
	while(cin >> n >> m){
		int k = m;
		bool flag = false;
		while(k){
			int l = n % k;
			k = l;
			if(k == 1){
				flag = true;
			}
		}
		if(flag) cout << "YES\n";
		else cout << "NO\n";
	}
	
	
	return 0;
}