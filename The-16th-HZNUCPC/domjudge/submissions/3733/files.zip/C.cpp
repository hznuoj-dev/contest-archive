#include<bits/stdc++.h>
using namespace std;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
    char x;
    string c1;
	long long int n,i,j,sum,sa,sb;
	sa=0;
	sb=0;
	sum=0;
	cin >> c1;
	for(i=0;i<c1.size();i++)
	{
		cin >> x;
		if(x==c1[i])
		{
			sa=sa+1;
		}
		else
		{
			sb=sb+1;
		}
	}
	if(sa<=1)
	{
		cout << "0";
	}
	else
	{
		if(sa==2)
		{
			sum=sb*sa%1000000007;
		}
		else
		{
			sum=((sa-1)*sa/2+sb*sa)%1000000007;
		}
		cout << sum;
	}
}