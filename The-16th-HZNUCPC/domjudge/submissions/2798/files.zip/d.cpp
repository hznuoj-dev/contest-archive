#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
typedef long long ll;
using namespace std;
const int N=3e5+10,INF=1e9;
struct nd {
	int t,id,l,r;
	bool operator<(const nd b)const{
		if(t!=b.t) return t>b.t;
		if(id!=b.id) return id<b.id;
		return r>b.r;
	}
}a[N];
int n,m,k,b[N],ans[N];
namespace DS {
#define ls (k<<1)
#define rs (ls|1)
	const int S=N<<2;
	int tr[S];
	void build(int k=1,int l=1,int r=m) {
		tr[k]=INF;
		if(l==r) return;
		int m=l+r>>1;
		build(ls,l,m); build(rs,m+1,r);
	}
	void upd(int L,int R,int x,int k=1,int l=1,int r=m) {
//		cerr<<L<<" "<<R<<endl;
		if(L<=l && r<=R) return tr[k]=min(tr[k],x),void();
		int m=l+r>>1;
		if(L<=m) upd(L,R,x,ls,l,m);
		if(m<R) upd(L,R,x,rs,m+1,r);
	}
	int que(int p,int k=1,int l=1,int r=m) {
		if(l==r) return tr[k];
		int m=l+r>>1,ans=tr[k];
		if(p<=m) ans=min(ans,que(p,ls,l,m));
		else ans=min(ans,que(p,rs,m+1,r));
		return ans;
	}
#undef ls
#undef rs
}
int main() {
#ifdef LOCAL
	freopen(".in","r",stdin);
#endif
	ios::sync_with_stdio(0); cin.tie(0);
	cin>>n>>k>>b[m=1];
	For(i,1,n) {
		cin>>a[i].t>>a[i].l>>a[i].r;
		if(a[i].l>1) b[++m]=a[i].l-1; b[++m]=a[i].r;
	}
	For(i,n+1,n+k) {
		cin>>a[i].t>>a[i].l; a[i].r=a[i].l;
		a[i].id=i-n; b[++m]=a[i].l;
	}
	n+=k;
	sort(b+1,b+m+1); m=unique(b+1,b+m+1)-b-1;
	For(i,1,n) {
		a[i].l=lower_bound(b+1,b+m+1,a[i].l)-b;
		a[i].r=lower_bound(b+1,b+m+1,a[i].r)-b;
	}
	DS::build();
	DS::upd(m,m,0);
	sort(a+1,a+n+1);
	For(i,1,n) {
		int x=DS::que(a[i].r);
		if(!a[i].id) {
			DS::upd(a[i].l,a[i].r,x+1);
		} else ans[a[i].id]=x;
	}
	For(i,1,k) {
		if(ans[i]==INF) cout<<-1<<"\n";
		else cout<<ans[i]<<"\n";
	}
}