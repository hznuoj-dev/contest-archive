//#include <iostream>
#include<bits/stdc++.h>

using namespace std;

//#define int long long
#define endl '\n'

long long n,m;

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);

	int t = 1;
//	cin >> t;
	while(t -- ) 
	{
		cin >> n >> m;
		
		bool f = true;
		int cnt=0;long long mn=min(m,n);
		if(n==1 || m==1) cout << "YES" << endl;
		else if(n<=m) cout << "NO" << endl;
		else
		{
			while(1==1)
			{
				cnt++;
				int x=n%m;
				if(x==0)
				{
					f=false;
					break;
				}
				if(x==1)
				{
					break;
				}
				m=x;
			}
			if(f && cnt<=mn)cout<<"YES"<<endl;
			else cout<<"NO"<<endl;
		}
			
	}
	return 0;
}