#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[100][100];
void kaibai(){
	ll n, m;
	scanf("%lld%lld", &n, &m);
	int ok = 1;
	while(m > 1){
		if(n % m == 0){
			ok = 0;
			break;
		}
		m = n % m;
	}
	if(ok) puts("YES");
	else puts("NO");
}
int main(void){
	int T=1;
//	cin>>T;
	while(T--){
		kaibai();
	}
}