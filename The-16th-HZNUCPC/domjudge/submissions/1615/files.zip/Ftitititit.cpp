#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define me(a,b) memeset(a,b,sizeof a);
int n,m;
int sus(int x) {
	if(x<2) return 0;
	for(int i=2; i<=sqrt(x); i++) {
		if(x%i==0) return 0;
	}
	return 1;
}
signed main() {
	IOS
	while(cin>>n>>m) {
		if(m==1||n==1) {
			cout<<"YES"<<endl;
			continue;
		}
		if(n==2||n==3) cout<<"NO"<<endl;
		else if(sus(n)==1) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;

}