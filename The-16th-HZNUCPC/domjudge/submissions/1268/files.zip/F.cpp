#include <bits/stdc++.h>
using namespace std;
int main()
{
    //n:votes m:restContestant
    long long n, m;
    scanf("%lld%lld", &n, &m);

    if ((n <= m && m != 1) || __gcd(n, m) != 1)
    {
        printf("NO");
    }
    else
    {
        printf("YES");
    }

    return 0;
}