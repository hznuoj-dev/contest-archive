#include<bits/stdc++.h>
using namespace std;
#define int long long

int dp1[30][30];
int dp[30][30];
const int mod=1e9+7;
int qpow(int a,int b){
	int ans=1;
	int base=a;
	while(b){
		if(b%2) ans=ans*base%mod;
		base=base*base%mod;
		b=b/2;
	}
	return ans;
}
bool vis[27][27][27][27];
int sum1[27];
int sum2[27];
signed main(){
	string a,b;
	int res1=0,res2=0;
	cin>>a>>b;
	for(int i=0;i<a.length();i++){
		dp[a[i]-'a'][b[i]-'a']++;
		dp[a[i]-'a'][b[i]-'a']=dp[a[i]-'a'][b[i]-'a']%mod;
		//dp1[a[i]-'a'][b[i]-'a']++;
		//dp1[a[i]-'a'][b[i]-'a']=dp1[a[i]-'a'][b[i]-'a']%mod;
		sum1[a[i]-'a']++;
		if(sum1[a[i]-'a']==1)
		{
			res1++;
		}
		sum2[b[i]-'a']++;
		if(sum2[b[i]-'a']==1)
		{
			res2++;
		}
	}
	
//	if(a.length()==2&&res1!=res2)
//	{
//		printf("0\n");
//		return 0;
//	}
//	else if(a.length()==1)
//	{
//		printf("0\n");
//		return 0;
//	}
//	
	
	int sum=0,new1=res1,new2=res2;
	for(int i=0;i<26;i++){

		for(int j=0;j<26;j++){

			for(int i1=0;i1<26;i1++){
				
				for(int j1=0;j1<26;j1++){
				   new1=res1;
				   new2=res2;	
				    if(vis[i][j][i1][j1]==true) continue;
					if(dp[i][j]&&dp[i1][j1]){
					
						sum1[i]--;
						if(sum1[i]==0) new1--;
						sum1[j]++;
						if(sum1[j]==1) new1++;
						
						sum2[i]++;
						if(sum2[i]==1) new2++;
						sum2[j]--;
						if(sum2[j]==0) new2--;
						
							
						sum1[i1]--;
						if(sum1[i1]==0) new1--;
						sum1[j1]++;
						if(sum1[j1]==1) new1++;
						
						sum2[i1]++;
						if(sum2[i1]==1) new2++;
						sum2[j1]--;
						if(sum2[j1]==0) new2--;
							
						if(new1==new2){
							if(i==i1&&j==j1){
								//printf("1111 %lld %lld \n",dp[i][j],dp[i1][j1]);
								sum=(sum+dp[i1][j1]*(dp[i1][j1]-1)/2%mod)%mod;	
							}
							else{
									//printf("2222 %lld %lld \n",dp[i][j],dp[i1][j1]);
								sum=(sum+dp[i][j]*dp[i1][j1]%mod)%mod;	
							}		
						}
						
					
						sum1[i]++;
						sum1[j]--;
						sum2[i]--;
						sum2[j]++;
						
						sum1[i1]++;
						sum1[j1]--;
						sum2[i1]--;
						sum2[j1]++;
								
						vis[i][j][i1][j1]=true;
						vis[i1][j1][i][j]=true;
					}
						
				}
				
			}			//dp[i][j]=0;	
		}
		
	}
	printf("%lld\n",sum);
	
}