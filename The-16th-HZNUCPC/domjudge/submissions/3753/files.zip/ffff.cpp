#include <stdio.h>




int main()
{
	int n=0;
	int m=0;
	scanf("%d %d",&n,&m);
	if (n%2==0)
	{
		printf("NO\n");
		return 0;
	}
	else
	{
		for (int i=3;i<=n && i<m;i++)
		{
			if (n%i==0)
			{
				int num1=n/i;
		
				int num2=n%i;					
				int l1=num2/(m-i);				
				if (num2%(m-i)!=0)
				{
					l1++;
				}
				if (l1<num1)
				{
					printf("NO\n");
					return 0;
				}

			}
		}

	}
	printf("YES\n");
	return 0;
}
	



