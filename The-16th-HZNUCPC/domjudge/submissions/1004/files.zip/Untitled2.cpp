#include<bits/stdc++.h>
using namespace std;
#define int long long
struct ll{
	double x,y;
}q[105];

void solve(){
	int x,y;
	cin>>y>>x;
	if(x==1||y==1){
		cout<<"YES"<<endl;
		return ;
	}
	if(x%y==0||y%x==0){
		cout<<"NO"<<endl;
		return ;
	}
	if(x>y){
		cout<<"NO"<<endl;
		return ;
	}
	while(x>1){
		x-=y%x;
	}	
	if(x==0){
		cout<<"NO"<<endl;
		return ;
	}
	cout<<"Yes"<<endl;
	return ;
}
signed main(){
//	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}