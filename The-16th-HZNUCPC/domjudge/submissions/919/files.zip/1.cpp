#include<bits/stdc++.h>
using namespace std;
#define ll long long
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	ll n,m;
	cin>>n>>m;
	bool f=1;
	for(ll i=2;i*i<=n&&i<=m;i++ )
	{
		if(n%i==0&&i<=m)
		{
			f=0;
			break;
		}
	}
	if(f==0||(n<=m&&m!=1)||(n%m==0&&m!=1))
	cout<<"NO\n";
	else
	cout<<"YES\n";
//	while(n%m!=1&&n%m!=0)
//	{
//		m=n%m;
//	}
//	if(n%m==1)
//	cout<<"YES\n";
//	else if(m==1)
//	cout<<"YES\n";
//	else if(n%m==0)
//	cout<<"NO\n";	
}