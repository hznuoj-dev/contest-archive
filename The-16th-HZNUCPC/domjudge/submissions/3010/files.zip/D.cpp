#include <bits/stdc++.h>
using namespace std;

const int kMaxN = 3e5 + 5, kInf = 0x3f3f3f3f;
int n, m, x, ans[kMaxN], inft = 0x3f3f3f3f;
struct Node {
	int qid, t, l, r, dp;
} a[kMaxN];
vector<int> b, c;
vector<int> add[kMaxN], qry[kMaxN];
int ca[kMaxN], cb[kMaxN];

inline int lowbit(int x) {
	return x & -x;
}

void cdq(int l, int r) {
	if (l == r) return;
	
	int mid = (l + r) >> 1;
	cdq(mid + 1, r);
	
	for (int i = mid + 1; i <= r; ++i) {
		if (a[i].qid > 0) continue;
		cb[++cb[0]] = i;
	}
	for (int i = l; i <= mid; ++i) {
		ca[++ca[0]] = i;
	}
	sort(ca + 1, ca + ca[0] + 1, [&](int x, int y) {
		return a[x].t > a[y].t || (a[x].t == a[y].t && a[x].r < a[y].r);
	});
	sort(cb + 1, cb + cb[0] + 1, [&](int x, int y) {
		return a[x].t > a[y].t || (a[x].t == a[y].t && a[x].l < a[y].l);
	});
	vector<int> tmp;
	for (int i = 1; i <= cb[0]; ++i) {
		tmp.push_back(a[cb[i]].l);
	}
	for (int i = 1; i <= ca[0]; ++i) {
		tmp.push_back(a[ca[i]].r);
	}
	sort(tmp.begin(), tmp.end());
	tmp.resize(unique(tmp.begin(), tmp.end()) - tmp.begin());
	
	auto idx = [&](int val) {
		return lower_bound(tmp.begin(), tmp.end(), val) - tmp.begin() + 1;
	};
	
	int lim = (int)tmp.size() + 1;
	vector<int> bit(lim, kInf);
	auto query = [&](int x) {
		x = idx(x);
		int ans = kInf;
		while (x > 0) {
			ans = min(ans, bit[x]);
			x -= lowbit(x);
		}
		return ans;
	};
	
	auto add = [&](int x, int val) {
		x = idx(x);
		while (x <= lim) {
			bit[x] = min(bit[x], val);
			x += lowbit(x);
		}
	};
	
	// decreasingly enumerate t
	for (int i = 1, j = 0; i <= ca[0]; ++i) {
		while (j + 1 <= cb[0] && a[ca[i]].t <= a[cb[j + 1]].t && a[ca[i]].r >= a[cb[j + 1]].l) {
			add(a[cb[j + 1]].l, a[cb[j + 1]].dp);
			++j;
		}
		
		a[ca[i]].dp = min(a[ca[i]].dp, query(a[ca[i]].r) + 1);
	}
	
	cdq(l, mid);
}

int main() {
	ios::sync_with_stdio(false);
	cin >> n >> m >> x;
	for (int i = 1; i <= n; ++i) {
		a[i].qid = 0;
		cin >> a[i].t >> a[i].l >> a[i].r;
		b.push_back(a[i].t);
		c.push_back(a[i].l);
		c.push_back(a[i].r);
	}
	
	for (int i = 1; i <= m; ++i) {
		int ta, tb;
		cin >> ta >> tb;
		a[i + n].qid = i;
		a[i + n].t = ta;
		a[i + n].l = a[i + n].r = tb;
		b.push_back(ta);
		c.push_back(tb);
	}
	
	b.push_back(inft);
	c.push_back(x);
	sort(b.begin(), b.end());
	b.resize(unique(b.begin(), b.end()) - b.begin());
	sort(c.begin(), c.end());
	c.resize(unique(c.begin(), c.end()) - c.begin());
	
	inft = lower_bound(b.begin(), b.end(), inft) - b.begin();
	x = lower_bound(c.begin(), c.end(), x) - c.begin();
	for (int i = 1; i <= n + m; ++i) {
		a[i].t = lower_bound(b.begin(), b.end(), a[i].t) - b.begin() + 1;
		a[i].l = lower_bound(c.begin(), c.end(), a[i].l) - c.begin() + 1;
		a[i].r = lower_bound(c.begin(), c.end(), a[i].r) - c.begin() + 1;
		a[i].dp = kInf;
	}
	a[n + m + 1].t = inft;
	a[n + m + 1].l = x;
	a[n + m + 1].r = x;
	a[n + m + 1].qid = -1;
	a[n + m + 1].dp = 0;
	
	sort(a + 1, a + (n + m + 1) + 1, [&](const Node &lhs, const Node &rhs) {
		return lhs.r < rhs.r;	
	});
	int B = (int)b.size(), C = (int)c.size();
	cdq(1, n + m + 1);
	
	for (int i = 1; i <= n + m + 1; ++i) {
		if (a[i].qid > 0) ans[a[i].qid] = a[i].dp;
	}
	
	for (int i = 1; i <= m; ++i) {
		if (ans[i] < kInf) {
			cout << ans[i] - 1 << "\n";
		} else {
			cout << -1 << "\n";
		}
	}
	
	return 0;
}