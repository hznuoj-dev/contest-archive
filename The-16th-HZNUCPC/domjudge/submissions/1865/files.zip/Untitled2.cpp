#include <bits/stdc++.h>
using namespace std;
typedef long long ll;

struct point{
	int x, y;
	int c;
}nums[25];
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin >> t;
	while(t--) {
		int vis[25][25] = {0}, cnt = 0;
		//vis为记录点的数组，cnt为总和
		int n;
		cin >> n;
		//读入次数
		for(int i = 1; i <= n; i++) {
			cin >> nums[i].x >> nums[i].y >> nums[i].c;
			//坐标x，y，c
			vis[nums[i].x][nums[i].y] = 1;
			//此点已放置
		}
		for(int i = 1; i <= n; i++) {
			if(nums[i].c == 1) {
				if(nums[i].x - 1 >= 1) {
					if(vis[nums[i].x - 1][nums[i].y] != 1) {
						cnt++;
					}
				}
				if(nums[i].y - 1 >= 1) {
					if(vis[nums[i].x][nums[i].y - 1] != 1) {
						cnt++;
					}
				}
				if(nums[i].x + 1 <= 19) {
					if(vis[nums[i].x + 1][nums[i].y] != 1) {
						cnt++;
					}
				}
				if(nums[i].y + 1 <= 19) {
					if(vis[nums[i].x][nums[i].y + 1] != 1) {
						cnt++;
					}
				}
			}
		}
		cout << cnt << '\n';
	}
	return 0;
}