#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define IO ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define ll long long
const ll mode=1e9+7;
const int maxn=1e7;
//---------------------------

char a[maxn];
char s[maxn];
int hw[maxn];
int jhw[maxn];
void solve()
{
    cin>>a;
    int n = strlen(a);
    s[0] = '>';
    s[1] = '#';
    for (int i =0;i<n;i++)
    {
        s[i*2+2] = a[i];
        s[i*2+3] = '#';
    }
    s[n*2+2] = '<';
    s[n*2+3] = '\0';



    int le = strlen(s);

    for (int i =0;i<=le;i++)
        hw[i]=jhw[i] = 0;


    int m  = -1, r = -1;
    for (int i = 0;i<=le;i++)
    {
        bool flag = true;
        bool erci = true;
        // jie
        char st1 = '.';
        // huan
        char st2 =  '.';


        int p = 0;
        if (r>i) p = min(r-i,hw[m+m-i]);

        hw[i] = p;

        while(1)
        {
      //      if (i==7)
      //      {
      //          cout<< m<<"=="<<r<<"    "<< flag <<" "<<erci<<" "<<p<<":"<< st1<<st2<<endl;
      //      }

            if (i-p<=0 || i+p>=le)
                break;

           else if  (flag && erci && s[i+p]==s[i-p])
           {
               hw[i] = ++p;

               if ( i+p>r)
            {
                r = i+p;
                m = i;
            }
           }
           else if  (!flag && !erci && s[i+p]==s[i-p])
           {
               jhw[i] = ++p;
           }
           else if  (!flag&& erci&& s[i+p]==s[i-p])
           {
               ++p;
           }
           else if (flag &&erci)
           {
               st1 = s[i-p];
               st2 = s[i+p];
               flag = false;
                ++p;



           }else if (!flag && erci && (st1==s[i-p] && st2 == s[i+p])||(st1==s[i+p] && st2 == s[i-p]))
           {
               erci = false;
               jhw[i] = ++p;
           }else
                break;
        }


    if (!flag && erci &&  s[i]!='#'&& (s[i]==st1||s[i]==st2))
        jhw[i] = p;
    }



 //   for (int i = 0;i<le;i++)
 //     cout<<s[i]<<" ";
 //   cout<<endl;
 // for (int i = 0;i<le;i++)
 //       cout<<hw[i]<<" ";
 //   cout<<endl;
  //  for (int i = 0;i<le;i++)
 //       cout<<jhw[i]<<" ";
 //   cout<<endl;

    int ans = 0 ;

    for (int i = 0;i<le;i++)
        ans = max(ans,hw[i] -1);
    for (int i = 0;i<le;i++)
        ans = max(ans,jhw[i] -1);


    cout<<((ans<=1)?0:ans)<<endl;

}
int main()
{
    IO;
    int tn=1;
    cin>>tn;
    while(tn--)
    {
        solve();
    }
    return 0;
}
