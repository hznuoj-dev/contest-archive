#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
typedef long double LD;
const int N=300005;

struct compress {
	vector<LD> res;
	void insert(vector<LD> x) {
		for (auto e: x) res.push_back(e);
	}
	void build() {
		sort(res.begin(), res.end());
		res.erase(unique(res.begin(), res.end()), res.end());
		// for (auto x: res) cout << x << endl;
		const LD kEps = 1e-12;
		vector<LD> ans;
		for (int i = 0; i < res.size(); i ++) {
			if (ans.size() == 0 || res[i] - ans.back() > kEps) {
				ans.push_back(res[i]);
			}
		}
		res = move(ans);
	}
	int query(LD x) {
		return upper_bound(res.begin(), res.end(), x) - res.begin() + 1;
	}
};

struct Point {
	LD x, y;
	void read() {
		cin >> x >> y;
	}
	Point() {
	}
	Point(LD x_, LD y_) {
		x = x_, y = y_;
		// cout << x << " " << y << endl;
	}
	LD length() {
		return sqrt(x*x + y*y);
	}
	Point operator -(const Point&o) const {
		return Point(x - o.x, y - o.y);
	}
	Point operator /(const LD&k) const {
		//cout << x << " " << y << " " << k << endl;
		return Point(x / k, y / k);
	}
	LD heading() {
	    // cout << x << " " << y << " " << atan2(x, y) << endl;
		return atan2(x, y);
	}
};

const LD PI = acos(-1);
LD angle(Point v1, Point v2) {
	v1 = v1 / v1.length();
	v2 = v2 / v2.length();
	LD diff = v2.heading() - v1.heading();
	diff -= 6 * PI;
	while (diff <= 0) diff += 2 * PI;
	return diff;
}

void shift(vector<int>& a) {
	int i = 1, j = 0, k = 0;
	int n = a.size();
	while (i < n && j < n && k < n) {
		if (a[(i+k) % n] == a[(j+k)%n])
			k ++;
		else {
			if (a[(i + k) % n] > a[(j + k) % n]) {
				i = i + k + 1;
			} else {
				j = j + k + 1;
			}
			if (i == j) i ++;
			k = 0;
		}
	}
	int start = min(i, j);
	vector<int> ans;
	for (int i = start; i < start + n; i ++) {
		ans.push_back(a[i % n]);
	}
	a = ans;
}

LL hashValue(vector<int> arr) {
	const LL B = 131;
	const LL MOD = 1e9 + 9;
	LL ans = 0;
	for (auto x: arr) {
		ans = (ans * B + x) % MOD;
	}	
	return ans;
}
struct Polygon {
	int m;
	vector<Point> p;
	vector<LD> l, a;
	 
	void init() {
		cin >> m;
		a.resize(m);
		l.resize(m);
		p.resize(m);
		for (int i = 0; i < m; i ++) {
			p[i].read();
		}
		for (int i = 0; i < m; i ++) {
			Point A = p[(i-1+m)%m];
			Point B = p[(i+m)%m];
			Point C = p[(i+1+m)%m];
			
			l[i] = (p[(i+1)%m] - p[i]).length();
			a[i] = angle(A - B, C - B);
		}
		LD mx = 0;
		for (int i = 0; i < m; i ++) mx = max(mx, l[i]);
		for (int i = 0; i < m; i ++) l[i] /= mx;
		/*
		printf("polygon: ");
		for (int i = 0; i < m; i ++) printf("%.18f %.18f ", l[i], a[i]);
		printf("\n");
		*/
	}
	pair<int, LL> calHash(compress& handler_ang, compress& handler_len) {
		LL hash = 0;
		vector<int> a_(m), l_(m);
		for (int i = 0; i < m; i ++) {
			a_[i] = handler_ang.query(a[i]);
			l_[i] = handler_len.query(l[i]);
		}
		vector<int> arr;
		for (int i = 0; i < m; i ++) {
			arr.push_back(a_[i]);
			arr.push_back(l_[i]);
			arr.push_back(0);
		}
		/*
		printf("polygon compressed: ");
		for (int i = 0; i < m; i ++) printf("%d %d ", l_[i], a_[i]);
		printf("\n");
		*/
		shift(arr);
		return {m, hashValue(arr)};
	}
};



int main(){
/*
#ifndef ONLINE_JUDGE
	freopen("in.txt","r",stdin);
#endif
*/
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	int n;
	cin >> n;
	
	vector<Polygon> polygons(n);
	for (int i = 0; i < n; i ++) {
		polygons[i].init();
	}
	compress ang, len;
	for (int i = 0; i < n; i ++) {
		ang.insert(polygons[i].a);
		len.insert(polygons[i].l);
	}
	ang.build();
	len.build();
	
	map< pair<int,LL> , int> vis;
	for (int i = 0; i < n; i ++) {
		auto cur = polygons[i].calHash(ang, len);
		cout << vis[cur] << "\n";
		vis[cur] ++;
	}
	
	
    return 0;
}