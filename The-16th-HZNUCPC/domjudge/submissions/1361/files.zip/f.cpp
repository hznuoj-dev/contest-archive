#include <bits/stdc++.h>
using namespace std;

int main(){
	long long n,m,k;
	scanf("%lld%lld",&n,&m);
    if(n<m)printf("NO");
    else{
        if(n==1||m==1)printf("YES");
		else{
			if(n%2==1&&n%m!=0)printf("YES");
			else printf("NO");
		}
	}
	return 0;
}