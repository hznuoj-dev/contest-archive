#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int> PII;

int minfac;

bool is_prime(int x){
	for(int i=2;i<=sqrt(x);i++){
		if(x%i==0){
			minfac=i;
			return false;
		}
	}
	return true;
}

signed main(){
    int n,m;
    cin>>n>>m;
    if(n==1){
    	cout<<"YES"<<endl;
    	return 0;
	}	
	if(n<=m){
		cout<<"NO"<<endl;
		return 0;
	}
	if(is_prime(n)){
		cout<<"YES"<<endl;
		return 0;
	}else{
		if(minfac>m){
			cout<<"YES"<<endl;
			return 0;
		}else{
			cout<<"NO"<<endl;
			return 0;
		}
	}

    while(1){
    	if(m==1){
			cout<<"YES"<<endl;
			return 0;
		}
    	if(n<=m){
    		cout<<"NO"<<endl;
    		return 0;
		}
		if(n%m==0){
			cout<<"NO"<<endl;
			return 0;
		}
		if(n>m){
			m=n%m;
		}

		
	}
}