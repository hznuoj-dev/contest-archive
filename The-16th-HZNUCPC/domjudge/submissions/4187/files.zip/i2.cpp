#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
const int mod=1e9+7;
#define int long long
signed main(){
	int t;
	scanf("%lld",&t);
	while(t--){
		vector<int>g[30];
		int ans=1;int len;
		string s,s1; 
		cin>>s;
		s1=s;
		len=s.size();
		for(int r=len;r>=2;r--){
			int flag=0;
			for(int k=0;k<=len-r;k++){
				s=s1;
				int i=k;
				int j=i+len-1;
				int ok=0;
				char x,y;
				if(r%2){
					for(int d=0;d<=len/2;d++){
						if(s[i+d]!=s1[j-d]){
							if(ok==1){
								if((x==s[i+d]&&y==s[j-d])||(y==s[i+d]&&x==s[j-d])){
									ok=2;
								}else{
									break;
								}
							}else if(ok==0){
								ok=1;
								x=s[i+d];
								y=s[j-d];
							}else if(ok==2){
								break;
							}
						}
						if(d==len/2) flag=1;
					}
					if(flag==1){
						ans=r;
						break;
					}
				}else{
					for(int d=0;d<=len/2;d++){
						if(s[i+d]!=s1[j-d]){
							if(ok==1){
								if((x==s[i+d]&&y==s[j-d])||(y==s[i+d]&&x==s[j-d])){
									ok=2;
								}else{
									break;
								}
							}else if(ok==0){
								ok=1;
								x=s[i+d];
								y=s[j-d];
							}else if(ok==2){
								break;
							}
						}
						if(d==len/2) flag=1;
					}
					if(flag==1){
						ans=r;
						break;
					}
				}
			}
			if(flag==1){
				break;
			}
		} 
		printf("%lld\n",ans);
		
	}
	return 0;
}
