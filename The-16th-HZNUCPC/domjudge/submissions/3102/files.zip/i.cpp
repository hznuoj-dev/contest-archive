#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define x first
#define y second
#define mp make_pair
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
typedef pair<int, int> hashv;
const ll mod1 = 1e9 + 7, mod2 = 1e9 + 9;

hashv operator+ (const hashv &a, const hashv &b) {
	return {(a.x + b.x) % mod1, (a.y + b.y) % mod2};
}
hashv operator- (const hashv &a, const hashv &b) {
	return {(a.x - b.x + mod1) % mod1, (a.y - b.y + mod2) % mod2};
}
hashv operator* (const hashv &a, const hashv &b) {
	return {(1ll * a.x * b.x % mod1), (1ll * a.y * b.y % mod2)};
}

const int maxn = 6000;

int n, ans;
char str[maxn];
hashv s[maxn], t[maxn], pw[maxn];

hashv get1(int l, int r) {
	return s[r] - s[l - 1] * pw[r - l + 1];
}
hashv get2(int l, int r) {
	return t[l] - t[r + 1] * pw[r - l + 1];
}

void check1(int mid) {
	int l = mid, r = mid, posl_i = -1, posl_j = -1, posr_i = -1, posr_j = -1;
	while(true) {
		if(l < 1 || r > n) break;
		if(str[l] == str[r]) {
			if(posr_i == -1) ans = max(ans, r - l + 1);
			else if(posr_j != -1) ans = max(ans, r - l + 1);
			l--;
			r++;
			continue;
		}
		if(posr_i == -1) {
			posl_i = l;
			posr_i = r;
			l--;
			r++;
			continue;
		} else if(posr_j == -1)  {
			if((str[r] != str[posl_i] || str[l] != str[posr_i]) && (str[r] != str[posr_i] || str[l] != str[posl_i])) break;
			posr_j = r;
			posl_j = l;
			ans = max(ans, r - l + 1);
			l--;
			r++;
		} else {
			break;
		}
	}
}
void check2(int mid) {
	int l = mid, r = mid + 1, posl_i = -1, posl_j = -1, posr_i = -1, posr_j = -1;
	while(true) {
		if(l < 1 || r > n) break;
		if(str[l] == str[r]) {
			if(posr_i == -1) ans = max(ans, r - l + 1);
			else if(posr_j != -1) ans = max(ans, r - l + 1);
			l--;
			r++;
			continue;
		}
		if(posr_i == -1) {
			posr_i = r;
			posl_i = l;
			l--;
			r++;
			continue;
		} else if(posr_j == -1)  {
//			cout << r << ' ' << pos_i << endl;
			if((str[r] != str[posl_i] || str[l] != str[posr_i]) && (str[r] != str[posr_i] || str[l] != str[posl_i])) break;
			posr_j = r;
			ans = max(ans, r - l + 1);
			l--;
			r++;
		} else {
//			ans = max(ans, r - l + 1);
			break;
		}
	}
//	cout << posl_i << " " << posr_i << " " << posl_j << " " <<  posr_j << endl;
}

void solve() {
	ans = 0;
	scanf("%s", str + 1);
	n = strlen(str + 1);
	hashv base = {31, 131};
	s[0] = {1, 1};
	for(int i = 1; i <= n; i++) {
		s[i] = s[i - 1] * base + mp(str[i], str[i]);
		pw[i] = pw[i - 1] * base;
	}
	t[n + 1] = {1, 1};
	for(int i = n; i >= 1; i--) {
		t[i] = t[i + 1] * base + mp(str[i], str[i]);
	}
	for(int i = 1; i <= n; i++) {
		check1(i);
		check2(i);
//		cout << i << " " << ans << endl;	
	}
//check2(3);
	if(ans == 1) ans = 0;
	printf("%d\n", ans);
}

int main() {
	int _;
	scanf("%d", &_);
	while(_--) solve();
}