#include<iostream>
using namespace std;
typedef long long ll;
ll n=0,m=0;
bool flag=0;
//F
int main()
{
	cin>>n>>m;
	for(int i=2;i<=m;i++)
	{
		if(n%i==0)
		{
			flag=1;
			break;
		}
	}
	if(flag==1)
		cout<<"NO";
	else
		cout<<"YES";
	
	
	return 0;
}