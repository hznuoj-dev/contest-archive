

import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			long n=sc.nextLong();
			long m=sc.nextLong();
			int f=0;
			if(n%2==0)f=1;//false
			else
			{
				long a=n>>1;
				long b=(n+1)>>1;
				while(a>0||b>0)
				{
					if(a==m||b==m)
					{
						f=0;break;
					}
					else
					{
						a>>=1;b>>=1;
						f=1;
					}
				}
			}
			if(n<=m)f=1;
			if(n==1||m==1)f=0;
			System.out.println(f==1?"NO":"YES");
		}

	}

}
