#include<bits/stdc++.h>
using namespace std;
int T,a[21][21],n,i,j,x,y,z,k,dx[4]={1,-1,0,0},dy[4]={0,0,1,-1},cnt;
int main(){
	scanf("%d",&T);
	for (;T--;){
		scanf("%d",&n);
		memset(a,-1,sizeof(a));
		for (i=1;i<=n;i++){
			scanf("%d%d%d",&x,&y,&z);
			a[x][y]=z;
		}
		cnt=0;
		for (i=1;i<=19;i++)
			for (j=1;j<=19;j++) if (a[i][j]==-1)
				for (k=0;k<4;k++){
					x=i+dx[k],y=j+dy[k];
					if (a[x][y]==1) cnt++;
				}
		printf("%d\n",cnt);
	}
}
/*
2
2
1 1 1
2 2 1
2
10 9 1
10 10 1

*/