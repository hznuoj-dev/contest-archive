#include<bits/stdc++.h>
using namespace std;
const int N=410;
int t,n,a1[N][N],a0[N][N],vis[N][N],x,y,c,dx[4]={1,-1,0,0},dy[4]={0,0,1,-1},ans;
signed main(){
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n),ans=0;
		for(int i=1;i<=19;i++)
			for(int j=1;j<=19;j++) a1[i][j]=a0[i][j]=vis[i][j]=0;
		for(int i=1;i<=n;i++)
			scanf("%d%d%d",&x,&y,&c),(c==1?a1[x][y]:a0[x][y])=1;
		for(int i=1;i<=19;i++)
			for(int j=1;j<=19;j++) if(a1[i][j]){
				for(int k=0;k<4;k++){
					int x=i+dx[k],y=j+dy[k];
					ans+=x>=1&&x<=19&&y>=1&&y<=19&&!a1[x][y]&&!a0[x][y];
				}
			}
		printf("%d\n",ans);
	}
	return 0;
}