#include<iostream>
#include<cmath>
using namespace std;
int zui(long long b,long long c)
{
	long long k,i=2;
	for(i=2;i<=sqrt(b)+1;i++)
	{
		if(b%i==0)
		k=i;
		break;
	}
	if(c<=k)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}
int main()
{
	long long n,m;
	cin>>n>>m;
	if(n==1||m==1)
	cout<<"YES"<<endl;
	else if(n%2==1&&m==2)
	cout<<"YES"<<endl;
	else if(n<=m)
	cout<<"NO"<<endl;
	else
	{
		if(zui(n,m))
		cout<<"NO"<<endl;
		else
		cout<<"YES"<<endl;
	}
	return 0;
}