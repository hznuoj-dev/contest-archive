#include<bits/stdc++.h>
using namespace std;

void solve(){
	long long n,m;
	cin>>n>>m;
	while(m>1){
		if(n%m==0){
			cout<<"NO";
			return;
		}else{
			m-=n%m;
		}
	}
	cout<<"YES";
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int t;
//	cin>>t;
//	while(t--)
		solve();
}