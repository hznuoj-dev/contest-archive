#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod=1e9+7;
const int N=1e6+5;
const int M=1e3+5;
int n,m,k,c,t;
//int n,m,k;
int cs[N];
int az[4][2] = {{1,0},{0,1},{-1,0},{0,-1}};
long long ans;
//int s[N];
string str,a;
signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	while (cin >> str >> a) {
		ans = 0;
		int len = str.length();
		c = len; t = len;
		for (int i=0; i<str.length(); i++) {
			if (str[i] != a[i]) {
				if (c == len) c = i;
				t = i;
			}
		}
		if (c == len){
			ans = (len) * (len - 1) / 2;
			ans %= mod;
		}
		else{
			ans = (c + (len - t - 1)) + (c * (len - t - 1)) + (c != t);
			ans %= mod;
		}
		cout << ans << endl;
	}
}