#include <stdio.h>
#include <stdlib.h>
int sushu(int x);
int main(void)
{
	int n,m;
	scanf("%d %d",&n,&m);
	if(n>m)
	{
		if(n<=0||n>1000000000000)
		{
			printf("NO");
		}
		else
		{
			if(m<=0||m>1000000000000)
			{
				printf("NO");
			}
			else
			{
				sushu(n);
				if((sushu(n))==1)
				{
					printf("YES");
				}
				else
				{
					printf("NO");
				}
			}
		}
	}
	else if(n<m)
	{
		printf("NO");
	}
	else
	{
		if(n==1&&m==1)
		{
			printf("YES");
		}
		else
		{
			printf("NO");
		}
	}
	return 0;	
}
int sushu(int x){
	int flag;
	if(x==1)
	{
		flag=1;
	}
	if(x==2)
	{
		flag=0;
	}
	if(x>2)
	{
		for(int i=2;i<x;i++)
		{
			if(x%i==0)
			{
				flag=0;
				break;
			}
			else flag=1;
		}
	}
	return flag;
} 