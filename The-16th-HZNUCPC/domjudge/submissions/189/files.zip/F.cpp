#include<bits/stdc++.h>
#define int long long
#define ll long long
#define vi vector<int>
#define pb push_back

using namespace std;

signed main() {
	
	ll n, m;
	cin >> n >> m;
	ll x = 2;
	for (x; x * x <= n; ++ x) {
		if (n % x == 0) break;
	}
	if (n % x) x = n;
	if (x <= m) cout << "NO\n";
	else cout << "YES\n";
	return 0;
}