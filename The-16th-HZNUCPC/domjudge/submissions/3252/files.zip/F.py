n,m=map(int,input().split())
if (m%2==0 and n%2==0) or n%m==0:
	print("NO")
else:
	print("YES")
