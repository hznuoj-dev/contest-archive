#include <bits/stdc++.h>
#define int int64_t
#define endl '\n'
using namespace std;

void solve() {
	string s;
	cin >> s;
	int n = s.size();
	int ans = 0;
 	//odd
	for(int mid = 0; mid < n; ++ mid) {
		char mid_c = s[mid];
		int l = mid, r = mid, dif = 0;
		int lon = 1;
		bool chance = 1;
		char c1, c2;
		while(1) {
			-- l, ++ r;
			lon += 2;
			if(l < 0 || r >= n) break;
			if(s[l] == s[r]) {continue;}
			if(dif == 0) {
				ans = max(ans, lon - 2);
				if(mid_c == s[l] || mid_c == s[r]) chance = 1;
				else chance = 0;
				c1 = s[l], c2 = s[r];
				dif = 1;
			}
			else if(dif == 1) {
				if(chance == 1) ans = max(ans, lon - 2);
				if(c1 == s[l] && c2 == s[r] || c2 == s[l] && c1 == s[r]) chance = 1;
				else {chance = 0; break;}
				dif = 2;
			}
			else {
				break;
			}
		}
		if(chance == 1) ans = max(ans, lon - 2);
	}
	// even
	for(int mid = 0; mid < n - 1; ++ mid) {
		int l = mid + 1, r = mid, dif = 0;
		int lon = 0;
		bool chance = 1;
		char c1, c2;
		while(l >= 0 && r < n) {
			-- l, ++ r;
			lon += 2;
			if(s[l] == s[r]) {continue;}
			if(dif == 0) {
				if(lon - 2 > 1) ans = max(ans, lon - 2);
				c1 = s[l], c2 = s[r];
				dif = 1;
			}
			else if(dif == 1) {
				if(c1 == s[l] && c2 == s[r] || c2 == s[l] && c1 == s[r]) chance = 1;
				else {chance = 0; break;}
				dif = 2;
			}
			else {
				break;
			}
		}
		if(chance == 1) ans = max(ans, lon - 2);
	}
	if(ans <= 1) cout << "0\n";
	else cout << ans << endl;
}
int32_t main() {
	#ifdef DEBUG
	freopen("in.txt","r", stdin);
	#else
	cin.tie(0);
	cout.tie(0);
	ios::sync_with_stdio(false);
	#endif
	int T;
	cin >> T;
	while(T --) {
		solve();
	}
}