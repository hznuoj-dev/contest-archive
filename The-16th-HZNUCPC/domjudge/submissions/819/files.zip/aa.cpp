#include<bits/stdc++.h>
typedef long long ll;
const ll N=5e3+7;
const ll mod =1e9+7;
const double eps=1e-6;
using namespace std;
int f[21][21];
void slove(){
	int n;cin>>n;
	memset(f,0,sizeof(f));
	while(n--){
		int x,y,c;cin>>x>>y>>c;
		if(c==1){
			f[x][y]=max(2,f[x][y]);
			f[x-1][y]=max(1,f[x-1][y]);
			f[x+1][y]=max(1,f[x+1][y]);
			f[x][y-1]=max(1,f[x][y-1]);
			f[x][y+1]=max(1,f[x][y+1]);
		}
		else f[x][y]=max(3,f[x][y]);
	}	
	int ans=0;
		for(int i=0;i<=20;i++){
			for(int j=0;j<=20;j++){
				if(f[i][j]==1) ans++;
			}
		}
		cout<<ans<<"\n";
}
int main(){
	int t;cin>>t;
	while(t--)
	slove();
}
