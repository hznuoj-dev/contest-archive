#include<bits/stdc++.h>

#define ll long long
#define pdd pair<ll,ll>

using namespace std;
vector<pdd>v;

double make1(ll x1,ll y1,ll x,ll y){
	return sqrt((x1-x)*(x1-x)+(y1-y)*(y1-y));
}
bool abc(ll a,ll b,ll c){
	return a+b>c&&a+c>b&&b+c>a;
}
ll make(ll x1,ll y1,ll x,ll y){
	ll a=abs(x1-x);
	ll b=abs(y1-y);
	return __gcd(a,b);
}
ll check(pdd a,pdd b,pdd c){
	ll lena=make(a.first,a.second,b.first,b.second);
	ll lenb=make(b.first,b.second,c.first,c.second);
	ll lenc=make(a.first,a.second,c.first,c.second);
	
	ll lenal=make1(a.first,a.second,b.first,b.second);
	ll lenbl=make1(b.first,b.second,c.first,c.second);
	ll lencl=make1(a.first,a.second,c.first,c.second);
	if(abc(lenal,lenbl,lencl)){
		
		return lena+lenb+lenc;
	}
	return 0;
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int n;
	cin>>n;
	set<pdd>vis;
	pdd x;
	for(int i=0;i<n;i++){
		cin>>x.first>>x.second;
		if(vis.find(x)==vis.end()){
			vis.insert(x);
			v.push_back(x);
		}
	}
	n=v.size();
	ll ans=0;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			for(int z=0;z<n;z++){
				ans=max(ans,check(v[i],v[j],v[z]));		
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}