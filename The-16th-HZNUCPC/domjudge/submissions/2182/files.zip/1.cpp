#include <bits/stdc++.h>
using namespace std;
using ll =long long ;
uint64_t n,m,k,cnt,sum;
struct pos{
	ll l,r,sum;
	
};
int f(int n,int m){
	m=n%m;
	
	if(m==0)
		return 0;
	for(int i=m;i<=n-2;i--)
		if(f(n,i)==0)return 0;
	return 1;
}
void solve(){
	cin >> n;
	cin>> m;
	k = 0;
	for(int i = 2;i<=(ll)sqrt(n);i++){
		if (n%i==0) {
			k=i;
			break;
		}
	}
	if (m<k||k==0) cout<<"YES";
	else cout<<"NO";
	cout<<endl;
}
int main(){
	uint64_t t;
	//cin >> t;
	//while(t--)
	solve();
}