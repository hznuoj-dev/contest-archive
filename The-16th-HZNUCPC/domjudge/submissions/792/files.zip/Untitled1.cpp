#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		long long sum=0;
		int fan[30][30]= {0};
		int vis[30][30]= {0};
		int n,x,y,type;
		cin>>n;
		for(int i=1;i<=n;i++)
		{
			cin>>x>>y>>type;
			if(type==1)
			{
				fan[x][y]=1;
			}
			else
			{
				fan[x][y]=2;
			}
		}
		for(int i=0;i<=20;i++)
		{
			fan[0][i]=3;
			fan[i][0]=3;
			fan[20][i]=3;
			fan[i][20]=3;
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(fan[i][j]==1||fan[i][j]==2)
				{
					if(!(fan[i-1][j]==0||fan[i+1][j]==0||fan[i][j-1]==0||fan[i][j+1]==0||fan[i-1][j]==fan[i][j]||fan[i+1][j]==fan[i][j]||fan[i][j-1]==fan[i][j]||fan[i][j+1]==fan[i][j]))
				    fan[i][j]=0;
				}
			}
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(fan[i][j]==1)
				{
					if(fan[i-1][j]==0&&vis[i-1][j]==0)
					{
						sum++;
					
						
					}
					if(fan[i][j-1]==0&&vis[i][j-1]==0)
					{
						sum++;
					    
					}
					if(fan[i+1][j]==0&&vis[i+1][j]==0)
					{
						sum++;
						
					}
					if(fan[i][j+1]==0&&vis[i][j+1]==0)
					{
						sum++;
					
					}
				}
			}
		}
		
		cout<<sum<<'\n';
	}
}