#include<bits/stdc++.h>
using namespace std;
typedef pair<int, int> PII;
#define rep(i, a, n) for(int i = a; i <= n; i++)
#define x first
#define y second
const int N = 110;
PII a[N];

void solve() {
	int n;
	cin >> n;
	rep(i, 1, n){
		cin >> a[i].x >> a[i].y;
	}
	int ans = 0;
	rep(i, 1, n){
		rep(j, 1, n){
			rep(k, 1, n){
				int x1 = abs(a[i].x - a[j].x), y1 = abs(a[i].y - a[j].y);
				int x2 = abs(a[i].x - a[k].x), y2 = abs(a[i].y - a[k].y);
				int x3 = abs(a[j].x - a[k].x), y3 = abs(a[j].y - a[k].y);
				int res = __gcd(x1, y1) + __gcd(x2, y2) + __gcd(x3, y3);
				if(x1 * y2 == x2 * y1 && x1 * y3 == x3 * y1 && x2 * y3 == x3 * y2){
					continue;
				}
				ans = max(res, ans);
			}
		}
	}
	cout << ans << '\n';
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	solve();
}