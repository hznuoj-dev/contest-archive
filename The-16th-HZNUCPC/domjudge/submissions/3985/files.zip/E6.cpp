#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
const int N = 110;

ll x[N],y[N];

int count(int x1,int y1,int x2,int y2){
	int a = abs(y2-y1) , b = abs(x2-x1);
	if(a>b) swap(a,b);
	if(a==0) return b+1;
	if(b%a==0) return a+1;
	return 2;
}

int main(){
	int n;cin>>n;

	for(int i=1;i<=n;i++) cin>>x[i]>>y[i];
	
	int res = 0;
	
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			for(int k=j+1;k<=n;k++){
				if(x[i]==x[j] && x[j]==x[k]) continue;
				if(y[i]==y[j] && y[j]==y[k]) continue;
				if(x[k]-x[j]!=0 && x[j]-x[i]!=0 && 1LL*(y[k]-y[j])*(x[j]-x[i]) == 1LL*(y[j]-y[i])*(x[k]-x[j])){
					continue;	
				}
				res = max(res , count(x[k],y[k],x[j],y[j]) + count(x[k],y[k],x[i],y[i]) + count(x[j],y[j],x[i],y[i]) - 3);
			}
	cout << res << endl;
	return 0;
}










