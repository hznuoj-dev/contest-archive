n,m=map(int,input().split())
flag=n%m
while flag!=1 and flag!=0:
	m=n-n%m
	flag=n%m
if flag==1:
	print("YES")
if flag==0:
	print("NO")
