#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n>>m;
	for(int i=2;i*i<=n;i++){
		if(n%i==0&&i<=m){
			cout<<"NO";
			return 0;
		}
	}
	if(m>=n){
		cout<<"NO";
		return 0;
	}
	cout<<"YES";
	return 0;
}