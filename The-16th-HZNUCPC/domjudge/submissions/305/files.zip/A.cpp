#include<bits/stdc++.h>
using namespace std;

const int maxn = 20;

int mp[maxn + 10][maxn + 10];

int dir[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};

void solve(){
	int n;
	cin >> n;
	for(int i = 1;i<=19;i++){
		for(int j = 1;j<=19;j++)
			mp[i][j] = 0;
	}
	for(int i = 1;i<=n;i++){
		int x,y,c;
		cin >> x >> y >> c;
		mp[x][y] = c;
	}
	int ans = 0;
	for(int i = 1;i <= 19;i++){
		for(int j = 1;j<=19;j++){
			if(mp[i][j] != 1)
				continue;
			for(int d = 0;d < 4;d++){
				int nx = i + dir[d][0];
				int ny = j + dir[d][1];
			//	cout << nx << " " << ny << "\n";
				if(nx <= 0 || nx > 19 || ny <= 0 || ny > 19)
					continue;
				if(mp[nx][ny] == 0)
					ans++;
			}
		}
			
	}
	cout<< ans<<"\n";
}
/*
1
2
10 9 1
10 10 1
*/

int main(){
	ios::sync_with_stdio(false);
	int t;
	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}