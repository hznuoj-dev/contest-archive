#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int inf = 0x3f3f3f3f, N = 5e5 + 10;

int sum[N << 2], lz[N << 2], lz1[N << 2];

void apply(int k, int lazy, int lazy1){
	sum[k] += lazy;
	lz[k] += lazy;
	sum[k] = min(sum[k], lazy1);
	lz1[k] = min(lz1[k], lazy1);
}

void pd(int k){
	apply(k << 1, lz[k], lz1[k]);
	apply(k << 1 | 1, lz[k], lz1[k]);
	lz[k] = 0;
	lz1[k] = inf;
}

void build(int k, int l, int r, int x){
	lz[k] = 0;
	lz1[k] = inf;
	if(l == r){
		if(l == x){
			sum[k] = 0;
		}else{
			sum[k] = inf;
		}
		return;
	}
	int mid = (l + r) >> 1;
	build(k << 1, l, mid, x);
	build(k << 1 | 1, mid + 1, r, x);
	sum[k] = min(sum[k << 1], sum[k << 1 | 1]);
}

void upd(int k, int l, int r, int ql, int qr, int x){
	if(l > qr || r < ql) return;
	if(l >= ql && r <= qr){
		sum[k] += x;
		lz[k] += x;
		lz1[k] += x;
		return;
	}
	pd(k);
	int mid = (l + r) >> 1;
	upd(k << 1, l, mid, ql, qr, x);
	upd(k << 1 | 1, mid + 1, r, ql, qr, x);
	sum[k] = min(sum[k << 1], sum[k << 1 | 1]);
}

void upd1(int k, int l, int r, int ql, int qr, int x){
	if(l > qr || r < ql) return;
	if(l >= ql && r <= qr){
		sum[k] = min(sum[k], x);
		lz1[k] = min(lz1[k], x);
		return;
	}
	pd(k);
	int mid = (l + r) >> 1;
	upd1(k << 1, l, mid, ql, qr, x);
	upd1(k << 1 | 1, mid + 1, r, ql, qr, x);
	sum[k] = min(sum[k << 1], sum[k << 1 | 1]);
}

int qry(int k, int l, int r, int px){
	if(l == r){
		return sum[k];
	}
	pd(k);
	int mid = (l + r) >> 1;
	if(px <= mid){
		return qry(k << 1, l, mid, px);
	}else{
		return qry(k << 1 | 1, mid + 1, r, px);
	}
}

vector<int> num;

int get(int x){
	return lower_bound(num.begin(), num.end(), x) - num.begin() + 1;
}

struct Qry{
	int c, p, id;
	
	bool operator < (const Qry &pi) const{
		return c > pi.c;
	}
}a[N];

struct node{
	int t, l, r;
	
	bool operator < (const node &pi) const{
		return t > pi.t;
	}
}b[N];

int ans[N];

void kaibai(){
	int n, m, x;
	cin >> n >> m >> x;
	num.push_back(x);
	for(int i = 1, t, l, r; i <= n; i++){
		cin >> t >> l >> r;
		b[i] = {t, l, r};
		num.push_back(l);
		num.push_back(r);
	}
	for(int i = 1, c, p; i <= m; i++){
		cin >> c >> p;
		a[i] = {c, p, i};
		num.push_back(p);
	}
	sort(num.begin(), num.end());
	num.erase(unique(num.begin(), num.end()), num.end());
	sort(a + 1, a + 1 + m);
	sort(b + 1, b + 1 + n);
	int len = num.size(), lt = 1;
	for(int i = 1; i <= n; i++){
		b[i].l = get(b[i].l);
		b[i].r = get(b[i].r);
	}
	for(int i = 1; i <= m; i++){
		a[i].p = get(a[i].p);
	}
	build(1, 1, len, get(x));
	priority_queue<pii> q;
	int left = get(x);
	for(int i = 1; i <= m; i++){
		while(lt <= n && b[lt].t >= a[i].c){
			q.push({b[lt].r, b[lt].l});
			lt++;
		}
		while(!q.empty()){
			int r = q.top().first, l = q.top().second;
			if(r < left){
				break;
			}
			q.pop();
			int pi = qry(1, 1, len, r);
			int qi = qry(1, 1, len, l);
			upd1(1, 1, len, l, r, pi + 1);
			if(left <= l - 1 && pi + 2 - qi < 0){
				upd(1, 1, len, left, l - 1, pi + 2 - qi);
			}
			left = min(left, l);
		}
		ans[a[i].id] = qry(1, 1, len, a[i].p);
	}
	for(int i = 1; i <= m; i++){
		if(ans[i] == inf) ans[i] = -1;
		cout << ans[i] << '\n';
	}
}
/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5

3 3 10
1 3 8
2 1 2
3 7 10
1 7
1 1 
1 9

5 3 9
1 2 8
2 1 3
3 3 5
4 5 7
5 7 9
1 1
2 1
1 2

*/

int main(void){
	int T=1;
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
//	cin >> T;
	while(T--){
		kaibai();
	}
}