#include<bits/stdc++.h>
using namespace std;
#define dzs ios::sync_with_stdio(false);cin.tie(nullptr),cout.tie(nullptr)
int main()
{
    //dzs;
    int t;
    cin>>t;
    while(t--)
    {
    	int a[30][30]={0};
    	int n,x,y,cnt=0;
    	cin>>n;
    	for(int i=1;i<=n;i++)
    	{
    		cin>>x>>y;
    		cin>>a[x][y];
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(a[i][j]==1)
				{
					if(a[i+1][j]==0&&i+1<=20)
					{
						a[i+1][j]=3;
						cnt++;
					}
					if(a[i-1][j]==0&&i-1>=0)
					{
						a[i-1][j]=3;
						cnt++;
					}
					if(a[i][j+1]==0&&j+1<=20)
					{
						a[i][j+1]=3;
						cnt++;
					}
					if(a[i][j-1]==0&&j-1>=0)
					{
						a[i][j-1]=3;
						cnt++;
					}
				}
			}
		}
		cout<<cnt;
	}
}