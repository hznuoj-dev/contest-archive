#include <bits/stdc++.h>

using namespace std;

using i64 = long long;

const int N = 2e5 + 100;

int main()
{
	i64 n, m;
	cin >> n >> m;
	
//	if(n == m && n == 1)
//	{
//		puts("YES");
//		return 0;
//	}
//		
//	if(n <= m )
//	{
//		puts("NO");
//		return 0;
//	}
//	
//	if(m == 1)
//	{
//		puts("YES");
//		return 0;
//	}
//	else
//	{	if(n % m == 0)
//			puts("NO");
//		else
//			puts("YES");
//	}
//	
	if(n == 1)
	{	
		puts("YES");
		return 0;
	}
	
	if(n<m){ 
		cout<<"NO";
		return 0 ;
	}
	
	while(1){
		if(m==1) {
			cout<<"YES";
			return 0;
		}
		else if(m==0){
			cout<<"NO";
			return 0;
		}
		m=n % m;
	}
	return 0;
}