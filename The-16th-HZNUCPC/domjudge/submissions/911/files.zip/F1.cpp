#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int n;
int G[23][23];

int dx[]={0,0,1,-1};
int dy[]={1,-1,0,0};

bool check(int x,int y) {
	if(x>=0&&y>=0&&x<=20&&y<=20) return true;
	else return false;
}

void solve() {
	cin>>n;
	for(int i=1;i<=n;i++) {
		int x,y,c;
		cin>>x>>y>>c;
		G[x][y]=c;
	}
	for(int i=1;i<=19;i++) {
		for(int j=1;j<=19;j++) {
			if(G[i][j]==1) {
				for(int k=0;k<4;k++) {
					int nx=i+dx[k];
					int ny=j+dy[k];
					if(check(nx,ny)) {
						if(G[nx][ny]==2||G[nx][ny]==1) {
							continue;
						}
						G[nx][ny]=3;
					}
				}
			}
		}
	}
	int ans=0;
//	for(int i=1;i<=19;i++) {
//		for(int j=1;j<=19;j++) {
//			cout<<G[i][j]<<' ';
//		}
//		cout<<endl;
//	}
	for(int i=0;i<=20;i++) {
		for(int j=0;j<=20;j++) {
			if(G[i][j]==3) {
				ans++;
			}
		}
	}
	cout<<ans<<endl;
}


int main() {
	ios::sync_with_stdio(false);
	ll n,m;
	cin>>n>>m;
	if(m==1||n==1) {
		cout<<"YES\n";
		return 0;
	}
	if(n%2==1) {
		ll k=-1;
		for(ll i=2;i*i<=n;i++) {
			if(n%i==0) {
				k=i;
				break;	
			}
		}
		if(k==-1) {
			k=n;
		}
		if(k<m&&m<n) {
			cout<<"YES\n";
		} else {
			cout<<"NO\n";
		}
	} else {
		cout<<"NO\n";
	}
}