#include<bits/stdc++.h>
using namespace std;

void solve(){
	long long n,m;
	cin>>n>>m;
//	while(m>1){
//		if(n<m||n%m==0){
//			cout<<"NO";
//			return;
//		}else{
//			m=n%m;
//		}
//	}
	if(m==1||n==1){
		cout<<"YES";
		return;
	}
	long long p=n;
	for(long long i=2;i<=n/i;i++)
		if(n%i==0){
			p=i;
			break;
		}
	if(p<=m){
		cout<<"NO";
	}else
		cout<<"YES";
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int t;
//	cin>>t;
//	while(t--)
		solve();
}