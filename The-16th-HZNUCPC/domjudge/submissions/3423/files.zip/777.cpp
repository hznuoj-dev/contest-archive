#include<bits/stdc++.h>
using namespace std;
long long n,m;
int main() {
	cin>>n>>m;
	int k;
if(n==1||m==1){
	cout<<"YES"<<endl;
	return 0;
}
k=m;
while(1){
	
	if(k==1){
		cout<<"YES"<<endl;
		break;
	}else if(k==0){
		cout<<"NO"<<endl;
		break;
	}
	k=n%k;
	
}


	return 0;
}