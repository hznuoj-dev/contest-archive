#include<iostream>
#include<cstring>
#include<string>
using namespace std;

long long p = 1e9+7;
int ka[200];
int f[200][200];
int kb[200];
int main(){
	string a, b;
	long long res = 0;
	cin >> a >> b;
	

	for(int i = 0; i < a.size(); ++i){
		++f[a[i]][b[i]];
		++ka[a[i]];
		++kb[b[i]];
	}
	
	for(int i = 'a'; i <= 'z'; ++i){
		for(int j = 'a'; j <= 'z'; ++j){
			if(f[i][j] == 0){
				continue;
			}
			--f[i][j];
			for(int ki = 'a'; ki <= 'z'; ++ki){
				for(int kj = 'a'; kj <= 'z'; ++kj){
					if(f[ki][kj] == 0){
						continue;
					}
					--ka[i];
					--ka[ki];
					++ka[j];
					++ka[kj];
					--kb[j];
					--kb[kj];
					++kb[i];
					++kb[ki];
					int ca = 0, cb = 0;
					for(int k = 'a'; k <= 'z'; ++k){
						if(ka[k] > 0){
							++ca;
						}
						if(kb[k] > 0){
							++cb;
						}
					}
					if(ca == cb){
						res += (f[i][j] + 1) * f[ki][kj];
//						cout << res <<' ';
//						cout << (char)i << (char)j << (char)ki << (char)kj << endl;
					}

					
					++ka[i];
					++ka[ki];
					--ka[j];
					--ka[kj];
					++kb[j];
					++kb[kj];
					--kb[i];
					--kb[ki];
				}
			}
			++f[i][j];
		}
	}
	res /=2;
	res %= p;
	cout << res <<endl;
}