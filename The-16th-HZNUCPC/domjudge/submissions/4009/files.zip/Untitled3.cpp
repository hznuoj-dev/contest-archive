#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m;
const int mod=1e9+7,N = 1e5 + 10;

int p[N];
int sum[N];

int find(int x){
	return p[x] == x?p[x] : p[x] = find(p[x]);
}

void solve(){
	int n,m,q;
	while(cin >> n >> q >> m){
		vector<int> v[n+1];
		for(int i = 1 ; i <= n ; i ++)p[i] = i,sum[i] = 1;
		while(m--){
			int a,b,c;
			cin >> a >> b >> c;
			if(a == 0){
				b = find(b);
				c = find(c);
				if(c!=b){
					p[c] = b;
					sum[b] += sum[c];
				}
			}else{
				v[b].push_back(c);
				v[c].push_back(b);
			}
		}
		bool ff = 0;
		for(int i = 1 ; i <= n ; i ++){
			int t = v[i][0];
			for(int j = 0 ; j < v[i].size() ; j ++){
				int a = find(i);
				int b = find(v[i][j]);
				if(a!=b){
					t = find(t);
					p[t] = b;
					sum[b] += sum[t];
				}else{
					ff = 1;
					break;
				}
			}
			if(ff)break;
		}
		if(ff){
			cout << "NO" << endl;
			continue;
		}
		int cnt = 0;
		int idx = -1;
		for(int i = 1 ; i <= n ; i ++){
			if(p[i] == i){
				cnt ++;
				if(sum[i] == q){
					idx = i;
				}
			}
		}
		if(cnt!=2 || idx == -1){
			cout << "NO" << endl;
		}else{
			cout << "YES" << endl;
			for(int i = 1 ; i <= n ; i ++){
				if(p[i] == idx){
					cout << i << " ";
				}
			}	
			cout << endl;
		}
	}
}

signed main(){
//	int T;cin >> T;while(T--){
		solve();
//	}
	return 0;
}
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1