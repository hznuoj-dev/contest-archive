#include <bits/stdc++.h>
using namespace std;

const int inf = 0x3f3f3f3f;
const int Maxn = 300000 + 10;
int n;
string s;
int go(int _s, int _e) {
	int i = _s, j = _e;
	bool is_odd = _s + 2 == _e;
	char mid = s[(_s + _e) / 2];
	int mis_cnt = 0;
	int res = 0;
	int left_mask = 0, right_mask = 0;
	auto check = [&]() {
		if (mis_cnt == 0 || (mis_cnt == 2 && (left_mask == right_mask))) {
//			cout << "update " << i << " " << j << "\n";
			res = max(res, j - i + 1);
		}
	};
	while (i >= 0 && j < n) {
		if (s[i] == s[j]) {
			check();	
			i--, j++;
			continue;
		}
		mis_cnt++;
		if (mis_cnt == 1 || mis_cnt == 2) {
			left_mask |= 1 << (s[i] - 'a');
			right_mask |= 1 << (s[j] - 'a');
		}
		
		if (mis_cnt == 1 && is_odd) {
			if (mid == s[i] || mid == s[j]) {
				res = max(res, j - i + 1);
			}
		}
		
		
		if (mis_cnt == 3) {
			break;
		}
		
		check();
		//cout << i << " " << j << "\n";
		i--, j++;
		
	}
	return res;
}
void solve() {
	cin >> s;
	n = s.size();
	int res = 0;
	for (int i = 0; i < n; ++i) {
		if (i + 1 < n) {
			res = max(res, go(i, i + 1));
		} 
		 if (i > 0 && i + 1 < n) {
			res = max(res, go(i - 1, i + 1));
		}
		//cout << i << " " << res << "\n";
	}
//	cout << go(5, 6) << "\n";
//	cout << go(2, 4) << "\n";
	cout << res << "\n";
}

signed main() {
	ios::sync_with_stdio(false);
	
	int t;
	cin >> t;
	while (t--) {
		solve();
	}	
	return 0;
}

/*
1
stfhfiut
4
abccab
ihi
stfhfiut
palindrome
*/