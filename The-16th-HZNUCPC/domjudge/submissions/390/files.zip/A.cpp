#include<bits/stdc++.h>
using namespace std;
queue<pair<int,int> > q;
int room[25][25];
int vis[25][25];
int dir[4][2]={1,0,0,1,-1,0,0,-1};
int ans;
void bfs(){
	
	while(!q.empty()){
		int x,y,tx,ty;
		pair<int,int> tmp;
		tmp = q.front();
		x = tmp.first;
		y = tmp.second;
		q.pop();
		for(int i=0;i<4;i++){
			tx = x+dir[i][0];
			ty = y+dir[i][1];
			if(tx>=0&&ty>=0&&tx<19&&ty<19 && room[tx][ty]==0 &&vis[tx][ty]==0){
				ans +=1;
				vis[tx][ty] =1;
				
			}
		}
		
	}
	
	return ;
}
int main(){
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		while(!q.empty()){
			q.pop();
		}
		memset(vis,0,sizeof vis);
		memset(room,0,sizeof room);
		for(int i=0;i<n;i++){
			int a,b,c;
			cin>>a>>b>>c;
			if(c==1){
				q.push({a,b});
				room[a][b] = 1;
			}else{
				room[a][b] = 2;
			}
	
		}
		ans =0;
		bfs();
		cout <<ans <<endl;
		
	}
	
	
	return 0;
}