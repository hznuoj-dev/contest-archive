#include <bits/stdc++.h>
using namespace std;
#define rep(a,b,c) for(int a=b;a<=c;a++)
#define per(a,b,c) for(int a=b;a>=c;a--)
#define output(a,b,c,d) cout<<a<<" "<<b<<" "<<c<<" "<<d<<"\n"
#define ft first
#define sd second

typedef long long LL;
typedef unsigned long long ULL;

typedef pair<int,int> PII;
typedef pair<LL,LL> PLL;

const int N=1e6+5000,M=5*N;
const LL mod=1e9+7;

int cnt[26][26],pos=0;
int chr[2][26];



int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    
	string a,b;
	cin>>a>>b;
	int n=a.length();
	rep(i,0,n-1){
		chr[0][a[i]-'a']+=1;
		chr[1][b[i]-'a']+=1;
		cnt[a[i]-'a'][b[i]-'a']+=1;
	}
	LL ans=0;
	rep(a1,0,25){
		rep(a2,a1,25){
			rep(b1,0,25){
				rep(b2,b1,25){
					if(chr[0][a1]==0){break;}
					if(chr[0][a2]==0){break;}
					if(chr[1][b1]==0){break;}
					if(chr[1][b2]==0){break;}
					
					chr[0][a1]--;chr[0][a2]--;
					chr[1][b1]--;chr[1][b2]--;
					chr[1][a1]++;chr[1][a2]++;
					chr[0][b1]++;chr[0][b2]++;
					
					int t1=0,t2=0;
					rep(i,0,25){
						if(chr[0][i]){t1++;}
						if(chr[1][i]){t2++;}
					}
					if(t1==t2){
						//output(a1,b1,a2,b2);
						if(a1==a2&&b1==b2){
							ans+=1LL*cnt[a1][b1]*(cnt[a1][b1]-1)/2;
						}else{
							
							ans+=1LL*cnt[a1][b1]*cnt[a2][b2];
						}ans%=mod;
					}
					
					
					
					chr[0][a1]++;chr[0][a2]++;
					chr[1][b1]++;chr[1][b2]++;
					chr[1][a1]--;chr[1][a2]--;
					chr[0][b1]--;chr[0][b2]--;
					
				}
			}
		}
	}
	cout<<ans;
	
	


    return 0;
}