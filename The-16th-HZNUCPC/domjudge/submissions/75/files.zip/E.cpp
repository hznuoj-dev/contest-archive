#include<bits/stdc++.h>
using namespace std;
using ll=long long;

ll x[1000],y[1000];

ll f(int a,int b){
	if(x[a]==x[b]) return abs(y[a]-y[b])-1;
	if(y[a]==y[b]) return abs(x[a]-x[b])-1;
	ll xx=abs(x[a]-x[b]);
	ll yy=abs(y[a]-y[b]);
	return __gcd(xx,yy)-1;
}

int main() {
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int n;
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>x[i]>>y[i];
	}
	ll ans=0;
	for(int i=0;i<n;++i){
		for(int j=i+1;j<n;++j){
			for(int k=j+1;k<n;++k){
				ans=max(ans,f(i,j)+f(j,k)+f(k,i)+3);
			}
		}
	}
	cout<<ans<<'\n';
}