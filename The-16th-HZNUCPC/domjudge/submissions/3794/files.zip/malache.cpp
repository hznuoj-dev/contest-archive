#include<bits/stdc++.h>

#define ll long long


using namespace std;
const int N=5e3+5;
int n,P[N<<1];
char a[N],S[N<<1],b[N];
void change(){
	n=strlen(a);
	int k=0;S[k++]='$';S[k++]='#';
	for(int i=0;i<n;i++){
		S[k++]=a[i];S[k++]='#';
	}
	S[k++]='&';
	n=k;
}
void manacher(){
	int R=0,C=0;
	for(int i=1;i<n;i++){
		if(i<R)P[i]=min(P[(C<<1)-i],P[C]+C-i);
		else P[i]=1;
		while(S[i+P[i]]==S[i-P[i]])P[i]++;
		if(P[i]+i>R){
			R=P[i]+i;
			C=i;
		}
	}
}
void solve(){
	memset(P,0,sizeof P);
	scanf("%s",a);
	int len=strlen(a);
	n=strlen(a);
	change();
	manacher();
	int maxa=1;
	int l=0;
	for(int i=0;i<n;i++){
		if(maxa<P[i]){
			maxa=max(maxa,P[i]);
			l=i;	
		}
	}
//	cout<<maxa<<" "<<len<<endl;
	if(maxa-1==1){
		cout<<0<<endl;
	}
	else if(maxa-1==len){
		cout<<maxa-1<<endl;
	}else{
		for(int i=2;i<strlen(S);i+=2){
//			cout<<S[i]<<endl;
			if(S[l+P[l]+2]!=S[i]){
				swap(S[l+P[l]+2],S[i]);
				manacher();
				swap(S[l+P[l]+2],S[i]);
				maxa=max(maxa,P[l]);
			}
			if(S[l-P[l]-2]!=S[i]){
				swap(S[l-P[l]-2],S[i]);
				manacher();
				swap(S[l-P[l]-2],S[i]);
				maxa=max(maxa,P[l]);
			}
		}
		cout<<maxa-1<<endl;
		
	}
}
int main(){
	int _;
	scanf("%d",&_);
	while(_--){
		solve();
	}
	
	
	return 0;
}