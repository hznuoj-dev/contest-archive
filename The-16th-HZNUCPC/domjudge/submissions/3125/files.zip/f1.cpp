//#pragma GCC optimize(2)
#include<iostream>
#include <algorithm>
#include<cstring>
using namespace std;
typedef long long LL;

int main ()
{
	LL n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"YES";
		return 0;
	}
	while(1){
		int ys=n%m;
		if(ys==0){
			cout<<"NO";
			return 0;
		}
		if(ys==1){
			cout<<"YES";
			return 0;
		}
		m=ys;
	}
	return 0;
}