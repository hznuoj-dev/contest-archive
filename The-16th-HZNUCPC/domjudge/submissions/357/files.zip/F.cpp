#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	int n,m;
	cin>>n>>m;
	if(m==1) cout<<"YES";
	else if(n<m){
		if(n==1) cout<<"YES";
		else cout<<"NO";
	}
	else if(n==m) cout<<"NO";
	else{
	for(int i=2;i*i<=n;i++){
		if(n%i==0){
			if(i>=2&&i<=m) {
				cout<<"NO";return 0;
			}
			if(n/i>=2&&n/i<=m) {
				cout<<"NO";return 0;
			}
		}
	}
	cout<<"YES";
	}
	return 0;
}
