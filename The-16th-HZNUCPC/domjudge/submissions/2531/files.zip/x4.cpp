#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=300005;
LL mod=1e9+7;
const int INF=0x3f3f3f3f;
struct Node {
	int l,r;
};
struct Qode {
	int x,id;
};
int b[N],tot;
int ans[N];
vector<Qode> e[N];
vector<Node> a[N];

int zh(int x) {
	return lower_bound(b,b+tot,x)-b+1;
}


int val[N<<2],lazy[N<<2];

void push_up(int u) {
	val[u]=min(val[u<<1],val[u<<1|1]);
}
void push_down(int u) {
	if(lazy[u]!=INF) {
		val[u<<1]=min(val[u<<1],lazy[u]);
		val[u<<1|1]=min(val[u<<1|1],lazy[u]);
		lazy[u<<1]=min(lazy[u<<1],lazy[u]);
		lazy[u<<1|1]=min(lazy[u<<1|1],lazy[u]);
		lazy[u]=INF;
	}
}
void update(int u,int l,int r,int x, int y,int v) {
	if(x<=l&&r<=y) {
		val[u]=min(val[u],v);
		lazy[u]=min(lazy[u],v);
		return;
	}
	int mid=l+r>>1;
	push_down(u);
	if(x<=mid)update(u<<1,l,mid,x,y,v);
	if(y>mid)update(u<<1|1,mid+1,r,x,y,v);
	push_up(u);
}

int query(int u,int l,int r,int x,int y){
	if(x<=l&&r<=y)return val[u];
	int mid=l+r>>1;
	push_down(u);
	int res=INF;
	if(x<=mid)res=min(res,query(u<<1,l,mid,x,y));
	if(y>mid)res=min(res,query(u<<1|1,mid+1,r,x,y));
	return res;
}
int main() {
#ifndef ONLINE_JUDGE
	//freopen("in.txt","r",stdin);
#endif
	int n,m,st;
	scanf("%d%d%d",&n,&m,&st);
	b[tot++]=st;
	for(int i=1; i<=n; i++) {
		int t,l,r;
		scanf("%d%d%d",&t,&l,&r);
		a[t].push_back({l,r});
		b[tot++]=l;
		b[tot++]=r;
	}
	for(int i=1; i<=m; i++) {
		int t,x;
		scanf("%d%d",&t,&x);
		b[tot++]=x;
		e[t].push_back({x,i});
	}
	sort(b,b+tot);
	st=zh(st);
	memset(val,0x3f,sizeof val);
	memset(lazy,0x3f,sizeof lazy);
	update(1,1,tot,st,st,0);
	for(int i=100000; i>=1; i--) {
		sort(a[i].begin(),a[i].end(),[](Node p1,Node p2){
			return p1.r>p2.r;
		});
		for(auto [l,r]:a[i]){
			l=zh(l),r=zh(r);
			int now=query(1,1,tot,l,r)+1;
			update(1,1,tot,l,r,now);
		}
		
		for(auto [x,id]:e[i]){
			x=zh(x);
			ans[id]=query(1,1,tot,x,x);
			if(ans[id]==INF)ans[id]=-1;
		}
	}
	for(int i=1; i<=m; i++)printf("%d\n",ans[i]);
	return 0;
}