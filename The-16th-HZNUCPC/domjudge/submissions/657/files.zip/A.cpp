#include<bits/stdc++.h>
using namespace std;

int t,n;
int a[21][21];
int b[21][21];
int x,y,f;
int cnt;

void dfs()
{
	for(int i=0;i<=20;i++)
	{
		for(int j=0;j<=20;j++)
		{
			if(a[i][j]==1)
			{
				if(a[i+1][j]!=2) b[i+1][j]++;
				if(a[i-1][j]!=2) b[i-1][j]++;
				if(a[i][j+1]!=2) b[i][j+1]++;
				if(a[i][j-1]!=2) b[i][j-1]++;
			}
		}
	}
	
	for(int i=0;i<=20;i++)
	{
		for(int j=0;j<=20;j++)
		{
			if(b[i][j] && a[i][j]==1)
			{
				b[i][j]=0;
			}
		}
	}
	
	for(int i=1;i<=19;i++)
	{
		for(int j=1;j<=19;j++)
		{
			if(b[i][j])
			{
				cnt+=b[i][j];
			}
		}
	}
	cout<<cnt<<'\n';
}

int main()
{
	ios::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL);
	
	cin >>t;
	
	while(t--)
	{
		cin >> n;
		cnt=0;
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		for(int i=0;i<=20;i++)
		{
			a[i][20] = 2;
			a[20][i] = 2;
			a[0][i] = 2;
			a[i][0] = 2;
		}

		for(int i=1;i<=n;i++)
		{
			cin >> x >> y >> f;
			if(f==1)
			a[x][y]=1;
			else if(f==2)
			a[x][y]=2;
		}
		
		dfs();
	
	}
	
	return 0;
}