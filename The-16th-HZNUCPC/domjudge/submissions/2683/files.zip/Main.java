import java.util.*;
import java.io.*;
import java.math.*;

public class Main {
	public static void main(String[] args) {
		InputStream inputStream = System.in;
		OutputStream outputStream = System.out;
		InputReader in = new InputReader(inputStream);
		PrintWriter out = new PrintWriter(outputStream);
		TaskA solver = new TaskA();
		solver.solve(1, in, out);
		out.close();
	}
	static class TaskA{
//		PriorityQueue<Integer> q = new PriorityQueue<>();
//		class Node{
//			
//		}
		int gcd(int a,int b){
			return b==0?a:gcd(b,a%b);
		}
		public void solve(int testNumber,InputReader in,PrintWriter out){
			int n = in.nextInt();
			int[] x = new int[n+1];
			int[] y = new int[n+1];
			for(int i=1;i<=n;i++){
				x[i] = in.nextInt();
				y[i] = in.nextInt();
			}
			long max=0;
			for(int i=1;i<=n;i++){
				for(int j=i+1;j<=n;j++){
					for(int k=j+1;k<=n;k++){
						long sum=0;
						long x1=x[j]-x[i];
						long y1=y[j]-y[i];
						long x2 = y[i]-y[k];
						long y2 = x[k]-x[i];
						if((x1*x2)+(y1*y2)==0)
							continue;
						sum+=gcd(Math.abs(x[i]-x[j]),Math.abs(y[i]-y[j]));
						sum+=gcd(Math.abs(x[k]-x[j]),Math.abs(y[k]-y[j]));
						sum+=gcd(Math.abs(x[i]-x[k]),Math.abs(y[i]-y[k]));
						max=Math.max(max, sum);
					}
				}
			}
			System.out.println(max);
			
			
		}
	}
	static class InputReader{
		public BufferedReader reader;
		public StringTokenizer tokenizer;
		public InputReader(InputStream stream){
			reader = new BufferedReader(new InputStreamReader(stream),32768);
			tokenizer = null;
		
		}
		public boolean hasNext(){
			while(tokenizer==null||!tokenizer.hasMoreTokens()){
				try{
					tokenizer = new StringTokenizer(reader.readLine());
				}catch(Exception e){
					return false;
				}
			}
			return true;
		}
		public String next(){
			while(tokenizer==null||!tokenizer.hasMoreTokens()){
				try{
					tokenizer = new StringTokenizer(reader.readLine());
				}catch(IOException e){
					throw new RuntimeException(e);
				}
			}
			return tokenizer.nextToken();
		}
		public String nextLine(){
			String str = null;
			try{
				str = reader.readLine();
			}catch(IOException e){
				e.printStackTrace();
			}
			return str;
		}
		public int nextInt(){
			return Integer.parseInt(next());
		}
		public double nextDouble(){
			return Double.parseDouble(next());
		}
		public long nextLong(){
			return Long.parseLong(next());
		}
		public BigInteger nextBigInteger(){
			return new BigInteger(next());
		}
		public BigDecimal nextBigDecimal(){
			return new BigDecimal(next());
		}
	}
}
