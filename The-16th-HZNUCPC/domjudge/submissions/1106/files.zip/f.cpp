#include <bits/stdc++.h>
using namespace std;
using i64 = long long;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int N = 1e7;
	vector<int>prime, isprime(N+1);
	for(int i = 2; i < N; i ++){
		if(!isprime[i]){
			prime.push_back(i);
			isprime[i] = i;
		}
		for(auto p : prime){
			if(i * p > N) break;
			isprime[i * p] = p;
			if(p == isprime[i])	break;
		}
	}
	i64 x,y;
	cin >> x >> y;
	if(x <= y){
		cout << "NO\n";
	}
	else{
		for(auto p : prime){
			if(p <= y && x % p == 0){
				cout << "NO\n";
				return 0;
			}
		}
		cout << "YES\n";
	}

	return 0;
}
