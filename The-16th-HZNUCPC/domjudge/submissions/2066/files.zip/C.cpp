#include <bits/stdc++.h>
//#define int long long
#define endl '\n'
using namespace std;
typedef unsigned long long ull;
typedef long long ll;
const int N=2e5+10;
const int mod=1e9+7;

string a,b;
int ca[34],cb[34];
int xx[27][27][27][27],cx[27][27];

void run()
{
	int n,tmpa,tmpb,sa=0,sb=0;
	ll ans=0,cca,ccb;
	
	cin >> a;
	cin >> b;
	n=a.size();	
	
	for(auto it:a)
	{
		if(!ca[it-'a'])
			sa++;
		ca[it-'a']++;
	}
	for(auto it:b)
	{
		if(!cb[it-'a'])
			sb++;
		cb[it-'a']++;
	}
	for(int s1=0;s1<=25;s1++)
		for(int s2=s1;s2<=25;s2++)
			for(int s3=0;s3<=25;s3++)
				for(int s4=s3;s4<=25;s4++)
				{
					if(!ca[s1] || !ca[s2] || !cb[s3] || !cb[s4])
					{
						xx[s1][s2][s3][s4]=-100;
						continue;
					}
					tmpa=0,tmpb=0;
					ca[s1]--;ca[s2]--;ca[s3]++;ca[s4]++;
					cb[s1]++;cb[s2]++;cb[s3]--;cb[s4]--;
					
					for(int i=0;i<=25;i++)
					{
						if(ca[i]>0)
							tmpa++;
						if(cb[i]>0)
							tmpb++;
					}
					xx[s1][s2][s3][s4]=tmpa-tmpb;
					ca[s1]++;ca[s2]++;ca[s3]--;ca[s4]--;
					cb[s1]--;cb[s2]--;cb[s3]++;cb[s4]++;
				}
				
//	cout << xx[0][0][0][0] << endl;				
				
	for(int i=0;i<n;i++)
		cx[a[i]-'a'][b[i]-'a']++;
	for(int s1=0;s1<=25;s1++)
		for(int s2=s1;s2<=25;s2++)
			for(int s3=0;s3<=25;s3++)
				for(int s4=s3;s4<=25;s4++)
				{
					if(xx[s1][s2][s3][s4]==0)
					{
//						cout << '#' << s1 << ' ' << s2 << ' ' << s3 << ' ' << s4 << endl;
						cca=cx[s1][s3];ccb=cx[s2][s4];
						if(s1==s2 && s3==s4)
							ans=(ans+(cca)*(cca-1)/2)%mod;
						else
							ans=(ans+cca*ccb)%mod;
					}
				}
		
	cout << ans;
}

/*
aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa
*/

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

