#include<iostream>
#include<cstring>
#include<algorithm>
#include<stack>
#include<queue>
#include<cmath>
#define endl '\n'
using namespace std;
const int N=1e6+10,INF=2e9;
typedef long long ll;
typedef unsigned long long ULL;
typedef pair<int,int> PII; 
bool solve(){
	ll n,m,t;
	cin>>n>>m;
	t=m;
	if(n==1||m==1)return true;
	if(n<=m)return false;
	for(int i=2;i<=sqrt(m)+1;i++){
		if(n%i==0) return false;
	} 
	return true;
}
int main(void){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int TT;
	TT=1;
	//cin>>TT;
	while(TT--){
		if(solve())cout<<"YES";
		else cout<<"NO";
	}
	return 0;
}