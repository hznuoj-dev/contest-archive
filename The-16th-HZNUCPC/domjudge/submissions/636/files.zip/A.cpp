#include<bits/stdc++.h>

using namespace std;

#define ios ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define ll long long

struct Stu{
	int x, y, p;
}F[400];

int flag[30][30];
int dir[][2] = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
int main()
{
	ios;
	int t; cin >> t;
	while(t--)
	{
		int n; cin >> n;
		memset(flag, 0, sizeof flag);
		for(int i = 1; i <= n; i++)
		{
			cin >> F[i].x >> F[i].y >> F[i].p;
			flag[F[i].x][F[i].y] = 1;
		}
		int ans = 0;
		for(int i = 1; i <= n; i++)
		{
			int x = F[i].x, y = F[i].y, p = F[i].p;
			if(p == 1)
			{
				for(int j = 0; j < 4; j++)
				{
					int dx = x + dir[j][0], dy = y + dir[j][1];
					if(dx >= 1 && dx <= 19 && dy >= 1 && dy <= 19)
					{
						if(flag[dx][dy] == 0) ans += 1;
					}
				}
			}
		}
		cout << ans << endl;
	}
	return 0;
}

