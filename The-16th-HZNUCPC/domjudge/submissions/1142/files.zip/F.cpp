#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main()
{
	ll n,m;
	scanf("%lld%lld",&n,&m);
	for (ll i=1;i*i<=n;i++)
		if (n%i==0)
		{
			if (i!=1&&i<=m) 
			{
				
				puts("NO");return 0;
			}
			if (n/i!=1&&n/i<=m) 
			{
				
				puts("NO");return 0;
			}
		}
	puts("YES");
}