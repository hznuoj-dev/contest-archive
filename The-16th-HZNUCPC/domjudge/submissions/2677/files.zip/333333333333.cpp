#include<bits/stdc++.h>
using namespace std;
const int N=1e2+5;
struct sjx{
	int x,y;
}x[N],t[5];
bool cmp(sjx a,sjx b){
	return a.x<b.x;
}
int n,ans;
int pd(sjx a,sjx b){
	int s=0;
	int a1=abs(a.x-b.x),a2=abs(a.y-b.y);
	if(a1<a2)swap(a1,a2);
	int i=__gcd(a1,a2);
	s+=i;
	return s;
}
int js(sjx a,sjx b,sjx c){
	if((b.y-a.y)*1.0/(b.x-a.x)==(c.y-b.y)*1.0/(c.x-b.x))return 0;
	if(a.x==b.x&&a.y==b.y||a.x==c.x&&a.y==c.y||c.x==b.x&&c.y==b.y)return 0;
	int s=0;
	s+=pd(a,b);
	s+=pd(a,c);
	s+=pd(b,c);
	return s;
}
void dfs(int k,int wz){
	t[k]=x[wz];
	if(k==3){
		ans=max(ans,js(t[1],t[2],t[3]));
		return;
	}
	for(int i=wz+1;i<=n;i++)dfs(k+1,i);
	return;
}
signed main(){
	ios::sync_with_stdio(false);cin.tie(0);
	cin>>n;ans=0;
	for(int i=1;i<=n;i++){
		cin>>x[i].x>>x[i].y;
	}
	sort(x+1,x+n+1,cmp);
	for(int i=1;i<=n;i++)dfs(1,i);
	cout<<ans<<'\n';
	return 0;
}