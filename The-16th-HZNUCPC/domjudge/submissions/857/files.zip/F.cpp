#include <bits/stdc++.h>
using namespace std;
const int N = 100010;
typedef long long ll;
int main(){
	int n,m;
	cin >> n >> m;
	if(n == 1 || m == 1){
		cout << "YES" << endl;
		return 0;
	}
	while(1){
		int c = n % m;
		m = c;
		if(m == 1){
			cout << "YES" << endl;
			return 0;
		}
		if(m == 0){
			break;
		}		
	}
	cout << "NO" << endl;
	return 0;
}
