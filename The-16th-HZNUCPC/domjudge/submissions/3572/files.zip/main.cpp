#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define int LL
int MOD=1e9+7;
signed main(){
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	int cnt=0;
	string s1,s2;
	cin>>s1>>s2;
	int len=s1.size();
	for(int i=0;i<len;i++){
		if(s1[i]==s2[i]) cnt++;
	}
	if(cnt==len){
		cout<<(len*(len-1)/2)%MOD;
	}else{
		int x=len-cnt;
		cout<<x*cnt<<'\n';
	}
	cout<<'\n';
}