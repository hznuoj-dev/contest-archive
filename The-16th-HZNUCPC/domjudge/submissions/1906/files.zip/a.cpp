#include <iostream>
using namespace std;
int main()
{
	int x,y,n,t,sum=0;
	cin>>n;
	while(n--)
	{	
		int a[25][25]={0};
		int a1[25][25]={0};
		cin>>t;
		for(int i=0;i<t;i++)
		{
			cin>>x>>y;
			if(a[x][y]!=0)
			sum-=a1[x][y];
			cin>>a[x][y];
			if(a[x][y]==2)sum--;
				if(a[x][y]==1)
				{
					if(y-1>0)
					if(a[x][y-1]!=1)
					{
						sum++;
						a[x][y-1]=2;
						a1[x][y-1]++;
					}
					if(y+1<21)
					if(a[x][y+1]!=1)
					{
						sum++;
						a[x][y+1]=2;
						a1[x][y+1]++;
					}
					if(x+1<21)
					if(a[x+1][y]!=1)
					{
						sum++;
						a[x+1][y]=2;
						a1[x+1][y]++;
					}
					if(x-1>0)
					if(a[x-1][y]!=1)
					{
						sum++;
						a[x-1][y]=2;
						a1[x-1][y]++;
					}
				}
		}
		cout<<sum<<endl;
		sum=0;
		
	}
}