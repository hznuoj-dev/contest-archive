#include<bits/stdc++.h>
using namespace std;
string a,b;
typedef long long ll;
const ll mod=1e9+7;
set<char> sa,sb;
map<char,int> ca,cb;
int cnt[10];
ll binpow(ll a,ll b,ll p){ll res=1%p;for(;b;b>>=1){if(b&1)res=res*a%p;a=a*a%p;}return res;}
#define mmi(a,b) binpow(a,b-2,b)
ll C(ll a,ll b,ll p){
	if(b>a)return 0;
	ll res=1;
	for(ll i=1,j=a;i<=b;i++,j--){
		res=res*j%p,res=res*mmi(i,p)%p;
	}return res;
}
ll Lucas(ll n){
	return((n*(n-1))%mod*mmi(2,mod))%mod;
}
signed main(){
	cin>>a>>b;
	a="#"+a,b="#"+b;
	int n=a.size()-1;
	for(int i=1;i<=n;i++){
		sa.insert(a[i]);
		sb.insert(b[i]);
		ca[a[i]]++,cb[b[i]]++;
	}
	int sza=sa.size(),szb=sb.size();
	if(sza<szb){
		swap(a,b);
		swap(ca,cb);
		swap(sa,sb);
		swap(sza,szb);
	}
	for(int i=1;i<=n;i++){
		ll tmpa=0,tmpb=0;
		if(ca[b[i]]==0) tmpa++;
		if(ca[a[i]]==1) tmpa--;
		if(cb[a[i]]==0) tmpb++;
		if(cb[b[i]]==1) tmpb--;
		ll res=tmpa-tmpb;
		if(res>=0) cnt[res]++;
		else if(res==-1) cnt[3]++;
		else if(res==-2) cnt[4]++;
	}
	if(sza==szb){
		ll ans=((Lucas(cnt[0])+(cnt[1]*cnt[3])%mod)%mod+(cnt[2]*cnt[4])%mod)%mod;
		printf("%lld\n",ans%mod);
	}
	if(sza-szb==1){
		ll ans=((cnt[0]*cnt[3])%mod+(cnt[1]*cnt[4])%mod)%mod;
		printf("%lld\n",ans%mod);
	}
	if(sza-szb==2){
		ll ans=((cnt[0]*cnt[4])%mod+Lucas(cnt[3]))%mod;
		printf("%lld\n",ans%mod);
	}
	if(sza-szb==3){
		ll ans=(cnt[3]*cnt[4])%mod;
		printf("%lld\n",ans%mod);
	}
	if(sza-szb==4){
		ll ans=Lucas(cnt[4]);
		printf("%lld\n",ans%mod);
	}
	if(sza-szb>4){
		puts("0");
	}
	return 0;
}
