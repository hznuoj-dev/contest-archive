#include <iostream>
#include <vector>
#include <cstring>
#define x first
#define y second
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
typedef long long ll;
ll n,m;

int main() {
	
	cin>>n>>m;
	bool f=true;
	while(m!=1)
	{
		if(n<=m)
		{
			f=false;
			break;
		}
		if(n%m==0)
		{
			f=false;
			break;
		}
		m= n%m;
	}	
	
	if(f)cout<<"YES"<<endl;
	else cout<<"NO"<<endl;

	
}