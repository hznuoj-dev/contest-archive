#include <bits/stdc++.h>
#define int long long
#define endl '\n'
using namespace std;
typedef unsigned long long ull;
const int N=5e3+10;
const int mod=1e9+7;

char ma[N<<1];
int mp[N<<1];
char s[N];

void manacher(char s[],int len)
{
	int l=0;
	ma[l++]='$';
	ma[l++]='#';
	for(int i=0;i<len;i++)
	{
		ma[l++]=s[i];
		ma[l++]='#';
	}
	ma[l]=0;
	int mx=0,id=0,flag=0,pos0,pos1;
	for(int i=0;i<l;i++)
	{
		flag=0;
		mp[i]=1;
		while(ma[i+mp[i]]==ma[i-mp[i]] || ma[i+mp[i]]!=ma[i-mp[i]] && flag<2)
		{
//			cout << i << ' ' << mp[i] << endl;
//			if(i==7)
//			{
//				cout << ma[i+mp[i]] << ' ' << ma[i-mp[i]] << ' ' << flag << endl;
//			}
			if(ma[i+mp[i]]!=ma[i-mp[i]] && flag<=0)
			{
				flag++;
				pos0=mp[i];
			}
			else if(ma[i+mp[i]]!=ma[i-mp[i]] && flag==1)
			{
				bool ff=0;
				flag++;
				pos1=mp[i];
				
//				if(ma[i-pos0]==ma[i+pos0] && ma[i-pos1]==ma[i+pos1])
				if(ma[i-pos1]==ma[i+pos0] && ma[i-pos0]==ma[i+pos1])
					ff=1;
				if(ma[i-pos0]==ma[i-pos1] && ma[i+pos0]==ma[i+pos1])
					ff=1;
				if(ma[i+pos1]==ma[i+pos0] && ma[i-pos1]==ma[i-pos0])
					ff=1;
				if(ma[i-pos0]==ma[i+pos1] && ma[i-pos1]==ma[i+pos0])
					ff=1;
					
				if(!ff)
				{
					mp[i]=pos0;
					flag=0;
					break;
				}
			}
			
			mp[i]++;
		}
		if(i+mp[i]>mx)
		{
			mx=i+mp[i];
			id=i;
		}
	}
}

void run()
{
	int n,ans=0;
	
	cin >> s;
	n=strlen(s);
	memset(mp,0,sizeof(mp));
	manacher(s,n);
	for(int i=0;i<2*n+2;i++)
		ans=max(ans,mp[i]-1);
	if(ans==1)
		ans=0;
	
//	cout << ma << endl;	
		
	cout << ans << endl;
}

/*
abccab
*/

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    cin >> T;
    while(T--)
        run();

    return 0;
}

