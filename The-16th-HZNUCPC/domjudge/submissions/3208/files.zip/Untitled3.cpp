#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m;
const int mod=1e9+7;
void solve(){
	string a,b;
	while(cin>>a){
		cin>>b;
		if(a==b){
			int ans=a.length()-1;
			int res=((1+ans)*ans)%mod/2;
			cout<<res%mod<<endl;
		}else{
			int len=a.length();
			int ans1=0,ans2=0;
			for(int i=0;i<len;i++){
				if(a[i]==b[i]){
					ans1++;
				}else ans2++;
			}
			if(ans1>0){
				ans1--;
			}
			int sum=((1+ans1)*ans1)%mod/2;
			sum%=mod;
			sum+=((1+ans2)*ans2)%mod/2;
			sum%=mod;
			cout<<sum<<endl;
		}
	}
}

signed main(){
//	int T;cin >> T;while(T--){
		solve();
//	}
	return 0;
}
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1
//1 1 1 1 1