#include <bits/stdc++.h>
using namespace std;
using ll = long long;
template<class T,class... A> void odn(T&& x, A&&... a) {cout<<x; (int[]){(cout<<' '<<a,0)...}; cout<<'\n';}
signed main() {
    // freopen("i", "r", stdin);
    cin.tie(0)->sync_with_stdio(0);
    int n; cin>> n;
    vector<int> x(n), y(n);
    for (int i = 0; i < n; i++) cin>> x[i]>> y[i];
    ll mx = 0;
    for (int i = 0; i < n; i++)
        for (int j = i+1; j < n; j++)
            for (int k = j+1; k < n; k++) {
                ll cross = 1ll*(y[i]-y[j])*(x[i]-x[k]) - 
                            1ll * (x[i]-x[j])*(y[i]-y[k]);
                if (cross == 0) continue;
                // odn(i,j,k);
                ll ans = 0;
                ll x1 = x[i]-x[j], y1 = y[i]-y[j];
                ll d = __gcd(x1, y1);
                ans += std::abs(d);
                x1 = x[i]-x[k], y1 = y[i]-y[k];
                d = __gcd(x1, y1);
                ans += std::abs(d);
                x1 = x[k]-x[j], y1 = y[k]-y[j];
                d = __gcd(x1, y1);
                ans += std::abs(d);
                mx = max(mx, ans);
            }
    odn(mx);
}