#include<bits/stdc++.h>
//please  ac!!!
using namespace std;
#define int long long
int judge(int begin,int end,string s){
				int i,j,k,cnt=0;
				char local1[3]={0};	
				char local2[3]={0};				
				while(begin<end){
					if(s[begin]!=s[end]){
						cnt++;
						if(cnt>2){
							return 0;
						}
						local1[cnt]=s[begin];
						local2[cnt]=s[end];
					}
					end--;
					begin++;
				}
				if(cnt==1){
					return 0;
				}
				if(cnt==0){
					return 1;
				}
					if(cnt==2){
						if(local1[1]==local2[2]&&local1[2]==local2[1]){
							return 1;
						}
						else{
							return 0;
						}
					}			
}
void solve(){
	int i,j,k;
	string s;
	cin>>s;
	int len=s.size();
	int add_len=len;
	while(add_len--){
		for(i=0;i+add_len<len;i++){
			for(j=i+add_len;j<len;j++){
				if(judge(i,j,s)){
					if(j-i+1==1){
						cout<<0<<endl;
						return ;
					}
					cout<<j-i+1<<endl;
					return;				
				}
			
			}
		}
	}
	cout<<0<<endl;
}
signed main (){
	ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
	int t;
	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}

