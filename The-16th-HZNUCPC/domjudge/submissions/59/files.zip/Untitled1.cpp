#include<bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i,l,r) for(int i=l;i<=r;++i)
#define N 362
#define M 50
int x[N],y[N],mp[M][M],T;
signed main(){
	cin>>T;
	while(T--){
		int ans=0;
		memset(mp,0,sizeof(mp));
		int cnt=0;
		int n;
		cin>>n;
		rep(i,1,n){
			int xx,yy,z;
			cin>>xx>>yy>>z;
			mp[xx][yy]=z;
			if(z==1)x[++cnt]=xx,y[cnt]=yy;
		}
		rep(i,1,cnt){
			if(mp[x[i]+1][y[i]]==0)mp[x[i]+1][y[i]]=1,ans++;
			if(mp[x[i]-1][y[i]]==0)mp[x[i]-1][y[i]]=1,ans++;
			if(mp[x[i]][y[i]-1]==0)mp[x[i]][y[i]-1]=1,ans++;
			if(mp[x[i]][y[i]+1]==0)mp[x[i]][y[i]+1]=1,ans++;
		}
		cout<<ans<<endl;
	}
}