import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main 
{
	static zb a[]=new zb[100];
	static double max=-1;
	static int nn;
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		nn=sc.nextInt();
		for (int i = 0; i < nn; i++) {
			long xx=sc.nextLong();
			long yy=sc.nextLong();
			a[i]=new zb(xx,yy);
		}
		zb[] b=new zb[3];
		dfs(0,b,0);
		System.out.println(max==-1?0:(int)max);
	}
	private static void dfs(int n,zb[] b,int ans) {
		if(n==3){
			if((b[0].x-b[1].x)*1.0/(b[0].y-b[1].y)==(b[2].x-b[1].x)*1.0/(b[2].y-b[1].y))return;
			long xmin=Integer.MAX_VALUE;
			long xmax=Integer.MIN_VALUE;
			long ymin=Integer.MAX_VALUE;
			long ymax=Integer.MIN_VALUE;
			for (int i = 0; i < 3; i++) {
				xmax=Math.max(b[i].x, xmax);
				xmin=Math.min(b[i].x, xmin);	
				ymax=Math.max(b[i].y, ymax);
				ymin=Math.min(b[i].y, ymin);	
			}
			double sum=(xmax-xmin)*(ymax-ymin)*1.0;
			sum=sum-Math.abs(b[0].x-b[1].x)*Math.abs(b[0].y-b[1].y)*1.0/2;
			sum=sum-Math.abs(b[1].x-b[2].x)*Math.abs(b[1].y-b[2].y)*1.0/2;
			sum=sum-Math.abs(b[2].x-b[0].x)*Math.abs(b[2].y-b[0].y)*1.0/2;
			max=Math.max(max, sum);
			return;
		}
		for (int i = ans; i < nn; i++) {
			b[n]=a[i];
			dfs(n+1,b,i+1);
		}
		
	}
}
class zb{
	long x,y;
	zb(long a,long b){
		this.x=a;
		this.y=b;
	}
}
