#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mode = 1e9 + 7;
const ll N = 1e6 + 7;
ll t, n, a[365][365];
string s1,s2;
void solve(){
	ll x, y, f, ans;
	ans = 0;
	for(int i = 1; i <= 19; i++){
		for(int j = 1; j <= 19; j++){
			a[i][j] = 0;
		}
	}
	cin>>n;
	for(int i = 1; i <= n; i++){
		cin>>x>>y>>f;
		a[x][y] = 2 - f;
	}
	for(int i = 1; i <= 19; i++){
		for(int j = 1; j <= 19; j++){
			if((i - 1 == 0 || a[i - 1][j] == 2) && (i + 1 == 20 || a[i + 1][j] == 2) && (j - 1 == 0 || a[i][j - 1] == 2) && (j + 1 == 0 || a[i][j + 1] == 2)){
				a[i][j] = -1;
			}
		}
	}
	for(int i = 1; i <= 19; i++){
		for(int j = 1; j <= 19; j++){
			if(a[i][j] != 1) continue;
			if(a[i - 1][j] == 0 && i - 1 != 0) ans++;
			if(a[i + 1][j] == 0 && i + 1 != 20) ans++;
			if(a[i][j - 1] == 0 && j - 1 != 0) ans++;
			if(a[i][j + 1] == 0 && j + 1 != 20) ans++;
		}
	}
//	for(int i = 1; i <= 19; i++){
//		for(int j = 1; j <= 19; j++){
//			cout<<a[i][j]<<" ";
//		}
//		cout<<'\n';
//	}
	cout<<ans<<'\n';
return;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
    cin>>t;
    while(t != 0){
    	t--;
    	solve();
	}
return 0;
}