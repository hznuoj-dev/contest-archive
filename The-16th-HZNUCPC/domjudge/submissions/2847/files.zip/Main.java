import java.util.Arrays;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Scanner;

public class Main 
{
	static int a[][]=new int[21][21];
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		int T=sc.nextInt();
		while(T-->0){
			int n=sc.nextInt();
			for (int i = 1; i <=19; i++) {
				Arrays.fill(a[i], 0);
			}
			for (int i = 0; i < n; i++) {
				int x=sc.nextInt();
				int y=sc.nextInt();
				int c=sc.nextInt();
				if(c==1)a[x][y]=1;
				else a[x][y]=2;
			}
			int ans=0;
			for (int i = 1; i <=19; i++) {
				for (int j = 1; j <=19; j++) {
					if(a[i][j]==1){
						if(i+1<=19){
							if(a[i+1][j]==0)ans++;
						}
						if(j+1<=19){
							if(a[i][j+1]==0)ans++;
						}
						if(i-1>=1){
							if(a[i-1][j]==0)ans++;
						}
						if(j-1>=1){
							if(a[i][j-1]==0)ans++;
						}
					}
				}
			}
			System.out.println(ans);
		}
	}
}
