#include <iostream>
using namespace std;
int main()
{
	int T;
	cin>>T;
	while(T--)
	{
		int n,sum=0,x[365]={0},y[365]={0};
		int a[25][25]={0};
		cin>>n;
		for(int i=1;i<=n;i++)
			cin>>x[i]>>y[i]>>a[x[i]][y[i]];
		for(int i=1;i<=n;i++)
		{
			if(a[x[i]][y[i]]==1)
			{
				sum+=4;
				if(a[x[i]][y[i]-1]!=0)sum--;
				if(a[x[i]][y[i]+1]!=0)sum--;
				if(a[x[i]-1][y[i]]!=0)sum--;
				if(a[x[i]+1][y[i]]!=0)sum--;
				if(x[i]+1>19)sum--;
				if(x[i]-1<1)sum--;
				if(y[i]+1>19)sum--;
				if(y[i]-1<1)sum--;
			}
		}
		cout<<sum<<endl;
	}
}