#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
#include <cmath>
#include <set>
#include <map>
#include <queue>
#include <stack>

using namespace std;
typedef long long ll;

string s;

ll J(int l){

	ll MAx=0;
	string rem=s;
	
	//jishu
	for(ll i=1;i<l-1;i++){
		
		ll cnt=1;
		ll flag=0;
		
		for(ll j=1;i-j>=0&&i+j<=l;j++){
			if(s[i-j]==s[i+j]){
				cnt+=2;
			}
			else{
				if(i-j-1>=0&&i+j+1<=l&&flag==0){
					if(s[i-j-1]==s[i+j]&&s[i+j+1]==s[i-j]){
						cnt+=4;
						flag=1;
						j++;
					}
				}
				else if(i-j-1>=0&&flag==0){
					if(s[i-j-1]==s[i+j]){
						cnt+=2;
						flag=1;
						j++;
					}
				}
				else if(i+j+1<=l&&flag==0){
					if(s[i+j+1]==s[i-j]){
						cnt+=2;
						flag=1;
						j++;
					}
				}
				
			}
			
			
			
		}
		
		if(cnt==1){
			cnt = 0;
		}
		
		MAx=max(MAx,cnt);
		
	}
	
	//oushu
	for(ll i=1;i<l-1;i++){
		
		ll cnt=2;
		ll flag=0;
		
		for(ll j=1;i-j>=0&&i+1+j<=l-1;j++){
			if(s[i-j]==s[i+1+j]&&s[i]==s[i+1]){
				cnt+=2;
			}
			else if(s[i]==s[i+1]){
				if(i-j-1 >= 0 && i+1+j+1<=l && flag == 0){
					if(s[i-j-1]==s[i+1+j]&&s[i+1+j+1]==s[i-j]){
						cnt+=4;
						flag=1;
						j++;
					}
				}else if(i-j-1 >= 0&& flag == 0){
					if(s[i-j-1]==s[i+1+j]){
						cnt+=2;
						flag=1;
						j++;
					}
				}else if(i+1+j+1<=l && flag == 0){
					if(s[i+1+j+1]==s[i-j]){
						cnt+=2;
						flag=1;
						j++;
					}
					
				}
			}
		}
		
		if(cnt==2){
			cnt = 0;
		}
		
		
		MAx=max(MAx,cnt);
		
	}
	
	ll fuck=2;
	
	for(ll i=1;i<l;i++){
		if(s[i-1]==s[i]){
			MAx=max(fuck,MAx);
			break;
		}
	}
	
	
	return MAx;
	
}

void solve(){
	
	cin>>s;
	
	ll l=s.length();
	
	if(l==1){
		cout<<"1"<<"\n";
	}else{
		
		cout<<J(l)<<"\n";
		
	}
	

	
	//system("pause");
}

int main(){
	
	int t = 1;
	cin >> t;
	while(t--){
		solve();
	}
	
	return 0;
}