#include<bits/stdc++.h>
#define endl '\n'
#define pll pair<ll, ll>
using namespace std;

typedef long long ll;
const ll N = 1e5 + 7;
const ll mod = 1e9 + 7;
ll _,n, num1[30], num2[30];
map<pll, ll>mp;
string s1, s2;

ll qpow(ll x, ll y){
	ll res = 1;
	while (y){
		if (y % 2)res = res * x % mod;
		y /= 2;
		x = x * x % mod;
	}
	return res;
}

void solve(){
	cin >> s1 >> s2;
	n = s1.size();
	s1 = " " + s1;
	s2 = " " + s2;
	ll mul = qpow(2, mod - 2);
	for (int i = 0; i < 27; i++){
		for (int j = 0; j < 27; j++)mp[{i, j}] = 0;
	}
	for (int i = 1; i <= n; i++){
		num1[s1[i] - 'a']++;
		num2[s2[i] - 'a']++;
		if (s1[i] == s2[i])mp[{26, 26}]++;
		else mp[{s1[i] - 'a', s2[i] - 'a'}]++;
	}
	ll ans = 0;
	for (int i1 = 0; i1 < 27; i1++){
		for (int j1 = 0; j1 < 27; j1++){
			for (int i2 = i1; i2 < 27; i2++){
				for (int j2 = 0; j2 < 27 ; j2++){
					if (i2 == i1 && j1 > j2)continue;
					if (mp[{i1, j1}] == 0 || mp[{i2, j2}] == 0)continue;
					if (i1 < 26){
						num1[i1]--;
						num2[i1]++;
					}
					if (i2 < 26){
						num1[i2]--;
						num2[i2]++;
					}
					if (j1 < 26){
						num1[j1]++;
						num2[j1]--;
					}
					if (j2 < 26){
						num1[j2]++;
						num2[j2]--;
					}
					ll flag = 0;
					for (int i = 0; i < 26; i++){
						if (num1[i] == num2[i] && num1[i] > 0){
							flag = 1;
							break;
						}
					}
					if (flag){
						if (i1 == i2 && j1 == j2)ans = (ans + mp[{i1, j1}] * (mp[{i1, j1}] - 1) % mod * mul % mod) % mod;
						else ans =  (ans + mp[{i1, j1}] * mp[{i2, j2}] % mod) % mod;
						//cout << ans << endl;
						//cout << i1 << " " << j1 << " " << i2 << " " << j2 << endl;
					}
					if (i1 < 26){
						num1[i1]++;
						num2[i1]--;
					}
					if (i2 < 26){
						num1[i2]++;
						num2[i2]--;
					}
					if (j1 < 26){
						num1[j1]--;
						num2[j1]++;
					}
					if (j2 < 26){
						num1[j2]--;
						num2[j2]++;
					}
				}
			}
		}
	}
	cout << ans << endl;
}

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	//cin >> _;
	_ = 1;
	while(_--)solve();
}