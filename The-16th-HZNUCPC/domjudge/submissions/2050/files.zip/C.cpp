#include<bits/stdc++.h>
using namespace std;
typedef pair<int, int> PII;
#define int long long
#define rep(i, a, n) for(int i = a; i <= n; i++)
#define x first
#define y second
#define endl '\n'

const int p=1e9+7;

int C(int x) {
	int ans=x*(x-1)/2;
	return ans%p;
}

string A,B;
int sa[27];
int sb[27];
int lena,lenb;
int numa=0,numb=0;

int cal() {
	int na=0;
	int nb=0;
	for(int i=1;i<=26;i++) {
		if(sa[i]) na++;
		if(sb[i]) nb++;
	}
	return na-nb;
}

void solve() {
	cin>>A>>B;
	lena=A.length();
	lenb=B.length();
	for(int i=0;i<lena;i++) {
		
		sa[A[i]-'a'+1]++;
		
	}
	for(int i=0;i<lenb;i++) {
		
		sb[B[i]-'a'+1]++;
		
	}
	for(int i=1;i<=26;i++) {
		
		if(sa[i]) numa++;
		if(sb[i]) numb++;
		
	}
	if(numa<numb) {
		swap(numa,numb);
		for(int i=1;i<=26;i++) {
			swap(sa[i],sb[i]);
		}
		swap(A,B);
	}
	
	int num_1=0,num_2=0;
	int num0=0,num1=0,num2=0;
	int pre=cal();
	for(int i=0;i<lena;i++) {
		sa[B[i]-'a'+1]++;
		sa[A[i]-'a'+1]--;
		
		sb[A[i]-'a'+1]++;
		sb[B[i]-'a'+1]--;
		int y=cal();
		int x=pre-y;
		
		sa[B[i]-'a'+1]--;
		sa[A[i]-'a'+1]++;
		
		sb[A[i]-'a'+1]--;
		sb[B[i]-'a'+1]++;
		if(x==0) {
			num0++;
		} else if(x==1) {
			num1++;
		} else if(x==2) {
			num2++;
		} else if(x==-1) {
			num_1++;
		} else if(x==-2) {
			num_2++;
		}
	}
	int ans;
	if(pre==0) {
		ans=(num_1*num1%p+num_2*num2%p)%p+C(num0);
		ans%=p;
	} else if(pre==1) {
		ans=(num1*num0%p+num_1*num2%p)%p;
	} else if(pre==2) {
		ans=(num2*num0%p)+C(num1)%p;
		ans%=p;
	} else if(pre==3) {
		ans=(num1*num2%p);
	} else if(pre==4) {
		ans=C(num2)%p;
	}

	cout<<ans<<'\n';
	
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	solve();
}