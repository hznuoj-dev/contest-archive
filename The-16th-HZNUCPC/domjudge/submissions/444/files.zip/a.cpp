#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int> PII;

int st[21][21];
int dx[4]={1,0,-1,0},dy[4]={0,-1,0,1};

void solve(){
	memset(st,0,sizeof st);
	int n;
	cin>>n;
	vector<PII> v;
	for(int i=1;i<=n;i++){
		int x,y,c;
		cin>>x>>y>>c;
		st[x][y]=1;
		if(c==1){
			v.push_back({x,y});
		}
	}
	int res=0;
	for(auto it:v){
		int x=it.first,y=it.second;
		for(int i=0;i<4;i++){
			int xx=x+dx[i],yy=y+dy[i];
			if(xx>=1&&xx<=19&&yy>=1&&yy<=19&&!st[xx][yy]){
				res++;
			}
		}
	}
	cout<<res<<endl;
}

signed main(){
	if(fopen("in.txt","r")){
        freopen("in.txt","r",stdin);
        freopen("out.txt","w",stdout);
    }
	int t;
	cin>>t;
	while(t--){
		solve();
	}
}