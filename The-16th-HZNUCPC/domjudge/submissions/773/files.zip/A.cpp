#include<bits/stdc++.h>

using namespace std;
#define int long long
int g[40][40];

signed main(){
	ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
	int T;
	cin >> T;
	while (T--)
	{
		int n; cin >> n;
		for (int i=0; i<=30; i++)
			for (int j=0; j<=30; j++)
				g[i][j]=0;
		for (int i=0; i<=20; i++) g[0][i]=2;
		for (int i=0; i<=20; i++) g[20][i]=2;
		for (int i=0; i<=20; i++) g[i][20]=2;
		for (int i=0; i<=20; i++) g[i][0]=2;
		
		for (int i=1; i<=n; i++)
		{
			int x,y,z;
			cin >> x >> y >> z;
			g[x][y]=z;
		}
		int ans=0;
		for (int i=1; i<=19; i++)
			for (int j=1; j<=19; j++)
			{
				if (g[i][j]==1)
				{
					if (g[i+1][j]==0) { g[i+1][j]=0; ans++;	}
					if (g[i-1][j]==0) { g[i-1][j]=0; ans++;	}
					if (g[i][j+1]==0) { g[i][j+1]=0; ans++;	}
					if (g[i][j-1]==0) { g[i][j-1]=0; ans++;	}
				}
		//	cout << ans << "\n";
			}
		cout << ans << "\n";
	}
}