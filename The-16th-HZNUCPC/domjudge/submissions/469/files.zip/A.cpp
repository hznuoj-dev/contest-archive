#include <bits/stdc++.h>
using namespace std;
using ll = long long;
int g[22][22];
int dx[] = {0, 1, 0, -1}, dy[] = {1, 0, -1, 0};

int main (){
    cin.tie(0)->sync_with_stdio(0);
    int T;
    cin >>T;
    while (T--) {
        int n;
        cin >> n;
        memset(g, 0, sizeof g);
        for (int i = 1; i <= n; i++) {
            int x, y, z;
            cin >> x >> y >> z;
            g[x][y] = z;
        }
        int ans = 0;
        for (int i = 1; i <= 19; i++) {
            for (int j = 1; j <= 19; j++) {
                if (g[i][j] == 1) {
                    for (int k = 0; k < 4; k++) {
                        int x = dx[k] + i, y = dy[k] + j;
                        if (x >= 1 && x <= 19 && y >= 1 && y <= 19) {
                            if (g[x][y] == 0) {
                                ans++;
                            }
                        }
                    }
                }
            }
        }
        cout << ans << '\n';
    }
}

