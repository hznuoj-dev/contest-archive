import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		long n = s.nextLong();
		long m = s.nextLong();
		int k=0;
		while (m != 0 && m != 1)
		{
			long h = n % m;
			if(h==0)
			{
				k=1;break;
			}
			long j=m-h;
		    if(h*(n/m+1)>j*(n/m))m=h;
		    else if(h*(n/m+1)==j*(n/m)){k=1;break;}
		    else m=m-n%m;
//		    	System.out.println(n+"��"+m);
		}
		if (m == 1&&k==0)
			System.out.println("YES");
		else
			System.out.println("NO");
	}
}
