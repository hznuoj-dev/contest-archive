#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

typedef long long ll;

void solve() {
	int n;
	cin >> n;
	vector<array<int, 3>> a(n + 1); 
	for(int i = 1; i <= n; i++) {
		cin >> a[i][0] >> a[i][1] >> a[i][2];
	}
	int ans = 0;
	vector<vector<int>> vis(100, vector<int>(100));
	for(int i = 1; i <= n; i++) {
		int x = a[i][0], y = a[i][1], c = a[i][2];
		if(c == 2 || c == 1) vis[x][y] = 1;
	}
	for(int i = 1; i <= n; i++) {
		int x = a[i][0], y = a[i][1], c = a[i][2];
		if(c == 1) {
			if(!vis[x - 1][y]) {
				vis[x - 1][y] = 1;
				ans++;
			}
			if(!vis[x + 1][y]) {
				vis[x + 1][y] = 1;
				ans++;
			}
			if(!vis[x][y - 1]) {
				vis[x][y - 1] = 1;
				ans++;
			}
			if(!vis[x][y + 1]) {
				vis[x][y + 1] = 1;
				ans++;
			}
		}
	}
	cout << ans << endl;
}

int main() {	
	ios;
	int _; cin >> _;
	while(_--) solve();
}