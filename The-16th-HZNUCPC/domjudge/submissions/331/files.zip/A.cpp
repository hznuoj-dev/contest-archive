#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=25;
int a[maxn][maxn];
int dx[]={0,0,1,-1};
int dy[]={1,-1,0,0};
void solve(){
	memset(a,0,sizeof a);
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		int x,y,c;cin>>x>>y>>c;
		a[x][y]=c;
	}
	int cnt=0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(a[i][j]==1){
				for(int k=0;k<4;k++){
					int tx=i+dx[k];
					int ty=j+dy[k];
					if(tx>=1&&tx<=19&&ty>=1&&ty<=19&&a[tx][ty]==0){
						cnt++;
					}
				}
			}
		}
	}
	cout<<cnt<<'\n';
	return ;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	int t;cin>>t;
	while(t--)solve();
	return 0;
}
