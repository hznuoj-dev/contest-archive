#include<bits/stdc++.h>
#define endl '\n'
using namespace std;

typedef long long ll;

int n;

double dis(ll x1, ll y11, ll x2, ll y2) {
	return sqrt((x1 - x2) * (x1 - x2) + (y11 - y2) * (y11 - y2));
}

bool check(int i, int j, int k, vector<pair<ll, ll> > &p) {
	double a = dis(p[i].first, p[i].second, p[j].first, p[j].second);
	double b = dis(p[i].first, p[i].second, p[k].first, p[k].second);
	double c = dis(p[j].first, p[j].second, p[k].first, p[k].second);
	if ((a + b) > c && (a + c) > b && (b + c) > a)
		return true;
	return false;
}

ll gcd(ll a, ll b) {
	return b == 0 ? a : gcd(b, a % b);
}
 
ll count(int i, int j, vector<pair<ll, ll> > &p) {
	ll x1 = p[i].first, y11 = p[i].second;
	ll x2 = p[j].first, y2 = p[j].second;
	if (x1 == x2) {
		return abs(y11 - y2);
	} 
	else if (y11 == y2) {
		return abs(x1 - x2);
	}
	else {
		ll num1 = abs(y2 - y11);
		ll num2 = abs(x2 - x1);
		ll g = gcd(num1, num2);
		num1 /= g, num2 /= g;
		return abs(x2 - x1) / num2 + 1;
	}
}

int main() {
	cin >> n;
	vector<pair<ll, ll> > p(n + 1);
	for (int i = 1, x, y; i <= n; ++i) {
		cin >> x >> y;
		p[i] = make_pair(x, y);
	}
	ll ans = 0;
	for (int i = 1; i <= n; ++i) {
		for (int j = i + 1; j <= n; ++j) {
			for (int k = j + 1; k <= n; ++k) {
				ll temp = 0;
				if (check(i, j, k, p)) {
					temp += count(i, j, p);
					temp += count(i, k, p);
					temp += count(j, k, p);
				}
				ans = max(ans, temp);
			}
		}
	}
	cout << ans - 3 << endl;
	return 0;
}