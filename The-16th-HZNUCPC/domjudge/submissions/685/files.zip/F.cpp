#include<bits/stdc++.h>
#define int long long
using namespace std;
signed main()
{
	int n,m;
	cin >> n >> m;
	int minn = n;
	for(int i = 2; i <= 1000010; i++)
	{
		if(n%i == 0)
		{
			minn = min(i,minn);
			break;
		}
	}
	if(minn==1)
		cout<< "YES";
	else if(m < minn)
	{
		cout << "YES";
	}
	else 
	{
		cout << "NO";
	}
}