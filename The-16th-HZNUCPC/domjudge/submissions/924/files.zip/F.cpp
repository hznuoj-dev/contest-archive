#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void kaibai(){
	ll n, m;
	scanf("%lld%lld", &n, &m);
	if(n <= m){
		puts("NO");
		return;
	}
	for(ll i = 2; i * i <= n; i++){
		if(n % i == 0){
			if(i <= m){
				puts("NO");
				return;
			}
		}
	}
	puts("YES");
}
int main(void){
	int T=1;
//	cin>>T;
	while(T--){
		kaibai();
	}
}