#include<bits/stdc++.h>

using namespace std;


typedef long long ll;


const int N = 1e6 + 10;
int st[N];
int prime[N];
int cnt;

void init()
{
    for (int i = 2; i < N; i ++)
    {
        if(!st[i]) prime[++ cnt] = i;
        for (int j =  i + i; j < N; j += i)
        {
            st[j] = 1;
        }
    }
}
int main(){
    int f = 1;
    ll n, m;
    init();
    cin >> n >> m;
    for (int i = 1; 1ll * prime[i] * prime[i] <= n && i <= cnt; i ++)
    {
        if(n % prime[i] == 0)
        {
            while(n % prime[i] == 0)
            {
                n /= prime[i];
            }
            if(m >= prime[i])
            {
                f = 0;
            }
        }
    }
    if(n > 1 && m >= n)
    {
        f = 0;
    }
    if(f ==0)
    {

        puts("NO");
    }
    else
    {

        puts("YES");
    }


}
