#include<bits/stdc++.h>
#define int long long 
using namespace std;
const int N=40005;
int T,n;
#define Vector Point
#define LD double
struct Point{
	LD x,y;
}G[100005],g;
inline LD Dot(Vector a,Vector b){return a.x*b.x+a.y*b.y;}
inline LD Cro(Vector a,Vector b){return a.x*b.y-a.y*b.x;}
inline LD Len(Vector a){return sqrt(Dot(a,a));}
inline LD Cos(Vector a,Vector b){return Dot(a,b)/Len(a)/Len(b);}


inline Vector operator -(Vector a,Vector b){return Vector{a.x-b.x,a.y-b.y};}

inline int op(Vector g,Vector p){
	if(p.x>=g.x&&p.y>=g.y) return 1;
	if(p.x>=g.x&&p.y<=g.y) return 2;
	if(p.x<=g.x&&p.y<=g.y) return 3;
	return 4;
}
inline bool cmp(Vector a,Vector b){
	if(op(g,a)!=op(g,b)) return op(g,a)<op(g,b);
	return Cro(a-g,b-g)<0;
}
LD ty[100005];
LD mx;
map<int ,map<int, map<int ,int> > > mp; 
int id;
signed main(){
	scanf("%lld",&T);
	while(T--){
		scanf("%lld",&n);g.x=0;g.y=0;
		for(int i=1;i<=n;i++) scanf("%lf%lf",&G[i].x,&G[i].y),g.x+=G[i].x,g.y+=G[i].y;
		g.x/=(double)n;g.y/=(double)n;
		sort(G+1,G+n+1,cmp);
		int tot=0;
		id=0;mx=-1e9;
		for(int i=1;i<=n;i++){
			int l=i-1,r=i+1;
			if(l==0) l=n;
			if(r>n) r=1;
			if(Cos(G[l]-G[i],G[i]-G[r])>mx){
				mx=Cos(G[l]-G[i],G[i]-G[r]);
				id=i;
			}
		}
		int i=id;
		while(tot<n){
			int l=i-1,r=i+1;
			if(l==0) l=n;
			if(r>n) r=1;
			ty[++tot]=Cos(G[l]-G[i],G[i]-G[r]);
			i++;
			if(i>n) i=1;
		}				
		LD x=0,y=0;
		for(int i=1;i<=tot;i++)
			x+=ty[i]*i;
		y=mx;
		
		int X=(int)(x*10000);
		int Y=(int)(y*10000);
		printf("%lld\n",mp[n][X][Y]);
		mp[n][X][Y]++;
//		for(int i=1;i<=n;i++) printf("%.0lf %.0lf\n",G[i].x,G[i].y);
	}
	
}
