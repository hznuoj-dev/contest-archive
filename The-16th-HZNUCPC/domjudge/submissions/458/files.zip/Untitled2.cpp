#include<bits/stdc++.h>
#define int long long
#define PII pair<int,int>
using namespace std;
int s[50][50];
int dir[4][2]={{1,0},{-1,0},{0,1},{0,-1}};
bool check(int x,int y)
{
	if(x>=1&&x<=19&&y>=1&&y<=19) return true;
	return false;
}
void solve()
{
	int n;
	cin>>n;
	vector<PII>v;
	memset(s,0,sizeof s);
	for(int i=1;i<=n;i++)
	{
		int x,y,z;
		cin>>x>>y>>z;
		s[x][y]=z;
		if(z==1)
		{
			v.push_back({x,y});
		}
	}
	int ans=0;	
	for(auto e:v)
	{
		int x=e.first;
		int y=e.second;
		for(int i=0;i<4;i++)
		{
			int tx=dir[i][0]+x;
			int ty=dir[i][1]+y;
			if(check(tx,ty)&&s[tx][ty]==0)
			{
				ans++;
			}
		}
	}
	cout<<ans<<endl;
	
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int _;cin>>_;while(_--)
	solve();
}