#include<stdio.h>
int main(){
	int n,m;
	scanf("%d%d",&n,&m);
	if(n%2==1&&m%2==1||n%2==1&&m%2==0){
		printf("YES\n");
	}
	if(n%2==0&&m%2==1||n%2==0&&m%2==0){
		printf("NO\n");
	}
	return 0;
}