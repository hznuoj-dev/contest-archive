#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mode = 1e9 + 7;
const ll N = 1e6 + 7;
ll t, n, x[N], y[N],a[400][400],num[N];
ll fx[]={0,1,0,-1};
ll fy[]={1,0,-1,0};
void solve(){
	cin>>n;
	memset(a,0,sizeof a);
	ll ans=0;
	bool s[400][400];
	for(ll i=1;i<=n;i++){
		cin>>x[i]>>y[i]>>num[i];
		if(num[i]==1){
			a[x[i]][y[i]]=1;
		}else{
			a[x[i]][y[i]]=2;
		}
	}
	for(ll i=1;i<=n;i++){
		if(num[i]==2)continue;
		for(ll j=0;j<4;j++){
			ll tx=fx[j]+x[i];
			ll ty=fy[j]+y[i];
			if(tx>19||tx<1||ty>19||ty<1||a[tx][ty]==1||a[tx][ty]==2)continue;
			ans++;
		}
	}
	cout<<ans<<"\n";
return;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
    cin>>t;
    while(t--){
    	solve();
	}
	
return 0;
}