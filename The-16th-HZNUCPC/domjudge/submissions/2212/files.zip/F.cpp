#include<bits/stdc++.h>

using namespace std;

int main() {
	long long n,m,k=0;
	scanf("%lld %lld",&n,&m);
	long long t=n;
	if(m==1)
	{
		k=1;
		printf("YES");
		return 0;
	}
	while(m!=0&&t--)
	{
		m=n%m;
		if(m==1)
		{
			k=1;
			printf("YES");
			break;
		}
	}
	if(k==0)
	printf("NO");
	return 0;
}

