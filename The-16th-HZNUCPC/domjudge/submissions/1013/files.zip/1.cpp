#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[25][25],xx[400],yy[400];
void solve()
{
	memset(a,1,sizeof a);
	for(int i=1;i<=19;i++)
	{
		for(int j=1;j<=19;j++) a[i][j]=0;
	}
	int n,m=0,cnt=0;
	scanf("%d",&n);
	while(n--)
	{
		int x,y,c;
		scanf("%d%d%d",&x,&y,&c);
		if(c==1)
		{
			xx[++m]=x,yy[m]=y;
		}
		a[x][y]=1;
	}
	for(int i=1;i<=m;i++)
	{
		int x=xx[i],y=yy[i];
		if(a[x-1][y]==0) cnt++;
		if(a[x+1][y]==0) cnt++;
		if(a[x][y-1]==0) cnt++;
		if(a[x][y+1]==0) cnt++;
	}
	printf("%d\n",cnt);
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--) solve();
	return 0;
}
