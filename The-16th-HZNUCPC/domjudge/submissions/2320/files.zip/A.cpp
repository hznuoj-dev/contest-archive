#include<bits/stdc++.h>
using namespace std;

#define int long long

const int N = 2e3 +10, inf = 1e17, mod = 1e9 +7;

long long n, m, k, x, y, ans;
char s[N], p[N];

int v[N];
map<int,int>mp;
int ok(int x){
    for(int i=2;i*i<=x;i++){
        if(x%i==0)return 0;
    }
    return 1;
}
void run(){
    cin>>n>>m;
    if(n==1||m==1){
        cout<<"YES\n";
        return;
    }
    if(n<=m||ok(n)==0){
        cout<<"NO";
        return;
    }
    cout<<"YES";
    return;
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int T;
  //  for(cin>>T;T>0;T--)
    run();return 0;
}
