#include <bits/stdc++.h>
#define int long long
using namespace std;
int n;
typedef pair<int,int> PII;
PII a[110];
signed main()
{
	ios::sync_with_stdio(0);
	
	cin.tie(0);
	
	cin >> n;
	set<PII> all;
	int uu = 0;
	for(int i = 0 ; i < n ; i ++) {
		int x, y; cin >> x >> y;
		if(all.find({x, y}) == all.end()) a[uu ++] = {x, y};
		all.insert({x, y});
	}
	
	n = uu;
	
	int res = (-1 + n) * n / 2;
	set<PII> s;
	for(int i = 0 ; i < n ; i ++)	
	{
		for(int j = i + 1 ; j < n ; j ++)
		{
			int x1 = a[i].first, y1 = a[i].second;
			int x2 = a[j].first, y2 = a[j].second;
			for(int k = j + 1 ; k < n ; k ++)
			{
				int x3 = a[k].first, y3 = a[k].second;
				if((y3 - y1) * (x2 - x1) == (x3 - x1) * (y2 - y1)) {
					if(s.find({i, k}) == s.end()) {
						res --;
					}
					if(s.find({j, k}) == s.end()) {
						res --;
					}
					s.insert({i, k});
					s.insert({j, k});
				}
			}
		}
	}
	
	
	if(res <= 2) cout << 0 << endl;
	else cout << res << endl;
}   
