#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=5e3+10;
char s[maxn<<1],t[maxn];

bool isp(char s[6]){
	int i=0,j=4;
	while(i<=j){
		if(s[i]!=s[j])return false;
		i++;
		j--;
	}
	return true;
}

bool check(char s[6]){
//	puts(s);
	for(int i=0;i<5;++i){
		for(int j=i+1;j<5;++j){
			swap(s[i],s[j]);
			if(isp(s))return true;
			swap(s[i],s[j]);
		}
	}
	return false;
}

void solve(){
	scanf("%s",t);
	int len=0;
	s[len++]='$';
	s[len++]='#';
	for(int i=0;t[i];++i){
		s[len++]=t[i];
		s[len++]='#';
	}
	s[len] = 0;
	//puts(s);
	int ans = 0;
	for(int i=1;i<len;++i){
		char ss[6] = {0};
		int ll = 0;
		ss[2+ll]=s[i];
		int l = 1;
		for(;ll < 3 && s[i+l-1] && (i-l+1 > 0);l++){
			if(ll==0 && s[i+l-1]==s[i-l+1]){
				ans=max(ans,l-1);
			}
			if(s[i+l-1]!=s[i-l+1]){
				ll++;
				ss[2+ll]=s[i+l-1];
				ss[2-ll]=s[i-l+1];
			}
			if(ll==2 && check(ss)){
				ans = max(ans,l-1);
				//printf("debug %d %d %d\n",i,l,ans);
			}
		}
		//printf("debug %d %d\n",i,ll);
		
	}
	printf("%d\n",ans>1?ans:0);
}
int main(){
	//ios::sync_with_stdio(0);
	int T=1;
	scanf("%d",&T);
	while(T--){
		solve();
	}
}


/*
4
stfgfiut
$s#t#f#g#f#i#u#t#
debug 1 0
debug 2 1
debug 3 1
st#fg
debug 4 2
stfgf
debug 5 2
tf#gf
tf#gf
debug 6 3
stgiu
debug 7 2
fg#fi
fg#fi
debug 8 3
fgfiu
fgfiu
fgfiu
fgfiu
debug 9 2
gf#iu
gf#iu
debug 10 3
gfiut
gfiut
debug 11 2
fi#ut
fi#ut
debug 12 2
debug 13 1
debug 14 1
debug 15 0
debug 16 0
4



*/