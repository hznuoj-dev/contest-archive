#include<bits/stdc++.h>
#define ll long long
using namespace std;
signed main()
{
	ll n,m;
	scanf("%lld %lld",&n,&m);
	int flag=1;
	while(m!=1)
	{
		if(n==1)
		{
			break;
		}
		if(n%m==0)
		{
			flag=0;
			break;
		}
		m=n%m;
	}
	if(flag)
	{
		puts("YES");
	}
	else
	{
		puts("NO");
	}
}
