#include<stdio.h>

int main()
{
	long long m,a,b;
	scanf("%ld %ld",&a,&b);
	m=2;
	while (m!=1&&m!=0&&a%2!=0)
	{
		m=a%b;
		b=m;
		
	}
	if (m==1)
	 printf("YES");
	else
	 printf("NO");
}