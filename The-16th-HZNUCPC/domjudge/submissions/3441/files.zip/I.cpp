#include<bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(),(a).end;
using namespace std;
const int N = 5e3 + 10;

ll p = 2333, mod = 1e9 + 7, h1[N], h2[N];
ll pp[N];

inline ll get1(int l, int r)
{
	return (h1[r] - h1[l - 1] * pp[r - l + 1] % mod + mod) % mod;
}

inline ll get2(int l, int r)
{
	return (h2[l] - h2[r + 1] * pp[r - l + 1] % mod + mod) % mod;
}

inline int cal(int i, int j)
{
	if(j <= i) return -1;
	
	int l = 1, r = (j - i + 1) / 2, res = -1;
	while(l <= r)
	{
		int mid = (l + r) / 2;
		
		ll s1 = get1(i, i + mid - 1);
		ll s2 = get2(j - mid + 1, j);
		
		if(s1 != s2) 
		{
			res = mid;
			r = mid - 1;
		}
		else
			l = mid + 1;
	}
	return res;
}

void solve()
{
	string s;
	cin >> s;
	int n = s.size();
	s = '?' + s;
	
	for(int i = 1; i <= n; i++) h1[i] = (h1[i - 1] * p % mod + s[i]) % mod;
	h2[n + 1] = 0;
	for(int i = n; i >= 1; i--) h2[i] = (h2[i + 1] * p % mod + s[i]) % mod;
	
	int ans = 0;
	for(int i = 1; i <= n; i++)
	{
		for(int j = i + 1; j <= n; j++)
		{
			int res = cal(i, j);
			
			if(res == -1)
			{
				ans = max(j - i + 1, ans);
				continue;
			}
			
			int L1 = i + res - 1;
			int R1 = j - res + 1;
			
			res = cal(L1 + 1, R1 - 1);
			
			if(res == -1)
			{
				int len = j - i + 1;
				if(len & 1)
				{
					if(s[L1] == s[i + (j - i) / 2] || s[R1] == s[i + (j - i) / 2])
						ans = max(ans, j - i + 1);
				}
				continue;
			}
			
			int L2 = L1 + res;
			int R2 = R1 - res;
			
			if(L2 + 1 >= R2 - 1 || get1(L2 + 1, R2 - 1) == get2(L2 + 1, R2 - 1)) res = -1;
			else res = 1;
			
			if(res != -1) continue;
			
			if(s[L1] == s[L2] && s[R1] == s[R2] || s[L1] == s[R2] && s[R1] == s[L2])
				ans = max(ans, j - i + 1);
		}
	}
	
	cout << ans << '\n';
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
	pp[0] = 1;
	for(int i = 1; i < N; i++) pp[i] = pp[i - 1] * p % mod;
	cin >> t;
	while(t--) solve();
	return 0;
}
/*
4
abccab
ihi
stfgfiut
palindrome
*/