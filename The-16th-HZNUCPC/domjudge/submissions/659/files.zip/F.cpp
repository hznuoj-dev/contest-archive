#include<bits/stdc++.h>
#define ll long long
#define PII pair<int,int>
using namespace std;
void solve() {
	int n,m;
	cin>>n>>m;
	if (n<=m)
		cout<<"NO\n";
	else if (gcd(n,m)!=1)
		cout<<"NO\n";
	else
		cout<<"YES\n";
}
signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}
