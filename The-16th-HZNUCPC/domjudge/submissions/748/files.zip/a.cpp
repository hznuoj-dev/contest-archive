// #define DEBUG
#include <bits/stdc++.h>


using namespace std;
#define int long long
#define endl '\n'
void solve() {
    int n, m;
    cin >> n >> m;
    if (m == 1) {
        cout << "YES\n";
        return ;
    } else {
        while (true) {
            int d = n % m;
            if (d == 1) {
                cout << "YES\n";
                return ;
            } else if (d == 0) {
                cout << "NO\n";
                return ;
            }
            m = d;
        }
    }
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    // cin >> T;
    // while (T--)
    {solve(); }
#ifdef DEBUG
    cerr << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}