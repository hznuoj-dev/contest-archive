#include <iostream>
#include <algorithm>
#include <cmath>
#include <stack>
#include <map>
#include <cstring>
#define qcin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define endl '\n'
#define int long long
using namespace std;
signed main() {
	int n,m;
	cin>>n>>m;
	if(m == 1) {
		cout<<"YES";
		return 0;
	}


	if(n%m == 0)	cout<<"NO";
	else {
		if(n%2 == 0) {
			cout<<"NO";
			return 0;
		} else {
			while(m>1) {
				if(n%m!=0) m-=(n%m);
				else {
					cout<<"NO";
					return 0;
				}
			}
			cout<<"YES";

		}

	}


	return 0;
}