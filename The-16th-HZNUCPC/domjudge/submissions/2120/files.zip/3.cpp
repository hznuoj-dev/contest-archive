#include<bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(0);cin.tie(nullptr);cout.tie(nullptr)
#define fi first
#define se second
#define pb push_back
#define eb emplace_back
#define int long long
#define endl '\n'
#define yes "YES\n"
#define no "NO\n"
#define pii pair<int,int>
const int inf = 0x3f3f3f3f;
const int mod = 1e9 +7;
const int N = 1e2+7;
int fpow(int x,int y){
	int ans = 1;
	while(y){
		if(y&1) ans = ans*x%mod;
		x = x*x%mod;
		y >>= 1;
	}
	return ans%mod;
}
pii a[N];

void exgcd(int a,int b,int &x,int &y){
	if(b == 0){
		x = 1,y = 0;
		return ;
	}
	exgcd(b,a%b,y,x);
	int tmp = x;
	x = y;
	y = tmp - (a/b)*y;
}

void solve(){
	int n;
	cin >> n;
	for(int i=1;i<=n;i++) cin >> a[i].fi >> a[i].se;
	int ans = 0;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			for(int k=1;k<=n;k++){
				int x1 = a[i].fi,y1 = a[i].se,x2 = a[j].fi,y2 = a[j].se,x3 = a[k].fi,y3 = a[k].se;
				if(i == j|| i== k|| j == k) continue;
				int cnt = 0;
				if((y2 - y1)*(x3-x1) == (y3-y1)*(x2-x1)){
					continue;
				}
				cnt += __gcd(abs(y2-y1),abs(x2-x1));
				cnt += __gcd(abs(y2-y3),abs(x2-x3));
				cnt += __gcd(abs(y3-y1),abs(x3-x1));
				ans = max(ans,cnt);
			}
		}
	}
	cout << ans << endl;
}

signed main(){
	IOS;
	int  T = 1;
	//cin >> T;
	while(T--) solve();
	return 0;
}