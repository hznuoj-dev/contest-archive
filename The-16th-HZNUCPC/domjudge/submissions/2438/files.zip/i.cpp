#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
typedef long long ll;
using namespace std;
int t,n;
char ch[100005];
main() {
	scanf("%d",&t);
	while(t--){
		scanf("%s",ch+1);
		n=strlen(ch+1);
		int ans=0;
		for(int i=1;i<=n;i++){
			int f1=0,f2=0;
			int flag=2;
			for(int l=i,r=i;l&&r<=n&&flag;l--,r++){
				if(ch[l]==ch[r]){if(flag==2&&!f1&&r!=l||flag==2&&f1==ch[i]-'a'+1||f2==ch[i]-'a'+1) ans=max(ans,r-l+1);}
				else{
					if(flag==2){
						if(!f1){
							f1=ch[l]-'a'+1,f2=ch[r]-'a'+1;
							if(ch[l]==ch[i]||ch[r]==ch[i])  ans=max(ans,r-l+1);
						}
						else{
							if(f1==ch[l]-'a'+1&&f2==ch[r]-'a'+1||f1==ch[r]-'a'+1&&f2==ch[l]-'a'+1) flag--,f1=0,f2=0;
							else flag=0;
						}
					}else flag=0;
					if(flag==1) ans=max(ans,r-l+1);
				}
			}
		}
//		printf("%d\n",ans);
		for(int i=1;i<n;i++){
			int f1=0,f2=0;
			int flag=2;
			for(int l=i,r=i+1;l&&r<=n&&flag;l--,r++){
				if(ch[l]==ch[r]){if(flag==2&&!f1) ans=max(ans,r-l+1);}
				else{
					if(flag==2){
						if(!f1) f1=ch[l]-'a'+1,f2=ch[r]-'a'+1;
						else{
							if(f1==ch[l]-'a'+1&&f2==ch[r]-'a'+1||f1==ch[r]-'a'+1&&f2==ch[l]-'a'+1) flag--,f1=0,f2=0;
							else flag=0;
						}
					}else flag=0;
					if(flag==1) ans=max(ans,r-l+1);
				}
			}
		}
		printf("%d\n",ans);
	}
}
