#include <bits/stdc++.h>

using i64 = long long;

i64 gcd(i64 x, i64 y) {
    return y == 0 ? x : gcd(y, x % y);
}

void solve() {
    int n;
    std::cin >> n;

    std::vector<i64> x(n), y(n);
    for (int i = 0; i < n; i++) {
        std::cin >> x[i] >> y[i];
    }

    auto check = [&](int a, int b, int c) {
        return (x[a] - x[b]) * (y[a] - y[c]) == (x[a] - x[c]) * (y[a] - y[b]);
    };

    auto count = [&](int a, int b) {
        if (x[a] == x[b]) {
            return std::abs(y[a] - y[b]);
        }
        if (y[a] == y[b]) {
            return std::abs(x[a] - x[b]);
        }

        i64 dy = std::abs(y[a] - y[b]), dx = std::abs(x[a] - x[b]);
        i64 g = gcd(dy, dx);
        return g;
    };

    i64 ans = 0;

    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            for (int k = j + 1; k < n; k++) {
                if (check(i, j, k)) continue;
                
                ans = std::max(ans, (count(i, j) + count(j, k) + count(k, i)));
            }
        }
    }

    std::cout << ans << "\n";
}

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int t;
	// std::cin >> t;
    t = 1;
	
	while(t--) solve();	
	
	return 0;
}
