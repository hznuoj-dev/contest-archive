#include <bits/stdc++.h>

using namespace std;
#define int long long
#define endl '\n'
#define lson node << 1
#define rson node << 1 | 1
const int maxn = 1e6 + 5;
const int INF = 1e9;
struct node {
    int l, r;
    int minn,tag;
}t[maxn << 2];
void pushup(int node){
    t[node].minn = min(t[lson].minn,t[rson].minn);
}
void spread(int node){
    if(t[node].tag == -1) return;
    int &k = t[node].tag;
    t[lson].tag = t[rson].tag = k;
    t[lson].minn = min(t[lson].minn,k);
    t[rson].minn = min(t[rson].minn,k);
    k = -1;
}
void build(int l,int r,int node){
    t[node].minn = inf;
    t[node].tag = -1;
    if(l == r) return;
    int mid = l + r >> 1;
    build(l,mid,lson);
    build(mid + 1,r,rson);
    pushup(node);
}
void change(int l,int r,int node,int x,int y,int k){
    if(x <= l && r <= y){
        t[node].minn = min(t[node].tag,k);
        t[node].tag = k;
        return;
    }
    spread(node);
    int mid = l + r >> 1;
    if(x <= mid) change(l,mid,lson,x,y,k);
    if(y > mid) change(mid + 1,r,rson,x,y,k);
    pushup(node);
}
int get(int l,int r,int node,int x){
    if(l == r) return t[node].minn;
    spread(node);
    int mid = l + r >> 1;
    if(x <= mid) return get(l,mid,lson,x);
    return get(mid + 1,r,rson,x);
}


void solve() {
    int n, m, x;
    cin >> n >> m >> x;
    vector<vector<int>> a(n, vector<int>(3));
    vector<pair<int, int>>b(m);
    for (int i = 0; i < n; ++i) {
        for(int j = 0; j < 3; ++j) cin >> a[i][j];
    }
    for (int i = 0; i < m; ++i) {
        cin >> b[i].first >> b[i].second;
    }
    sort(a.rbegin(), a.rend());
    sort(b.rbegin(), b.rend());
    int k = 0;
    build(1, n, 1);
    for (int i = 0; i < n; ++i) {
        while(b[k].first > a[i][0]) 
    }
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    int T;
    cin >> T;
    while (T--)
    {solve(); }
#ifdef DEBUG
    cerr << setprecision(2) << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}