#include<bits/stdc++.h>
using namespace std;
long long mmod=1e9+7;
void solve(){
	string a,b;
	cin>>a>>b;
	map<char,int>mp1;
	map<char,int>mp2;
	int numa=0,numb=0;
	for(int i=0;i<a.size();i++){
		mp1[a[i]]++; 
		mp2[b[i]]++;
		if(mp1[a[i]]==1) numa++;
		if(mp2[b[i]]==1) numb++;
	}
	int ans=0;
	for(int i=0;i<a.size();i++){
		int num1=numa,num2=numb;
		if(mp1[a[i]]==1) num1--;
		if(mp2[a[i]]==0) num2++;
		if(mp2[b[i]]==1) num2--;
		if(mp1[b[i]]==0) num1++;
		for(int j=0;j<a.size();j++){
			if(i!=j){
				int numa1=num1,numb1=num2;
		if(mp1[a[j]]==1) numa1--;
		if(mp2[a[j]]==0) numb1++;
		if(mp2[b[j]]==1) numb1--;
		if(mp1[b[j]]==0) numa1++;
		if(numa1==numb1){
			ans++;
		}
			}
		}
	}
	cout<<ans/2<<endl;
	
}
/*
string s1,s2;
int char1,char2,sum;//
int s1char[200],s2char[200];
void ff(string s1,string s2){
	int ans=0;
	for(int i=0;i<s1.length();i++){
		
	}
}
void solve(){
	cin>>s1>>s2;
	for(int i=0;i<s1.length();i++){
		if(s1[i]==s2[i]){
			sum++;
		}
		if(s1char[s1[i]]==0){
			
			char1++;
		}
		s1char[s1[i]]++;
	}
	for(int i=0;i<s2.length();i++){
		if(s2char[s2[i]]==0){
		
			char2++;
		}
		s2char[s2[i]]++;
	}
	int ans=0;
	if(char1==char2){
		cout<<sum*(sum-1)/2<<'\n';
	}else if(char1>char2){
		ff(s1,s2);
	}else{
		ff(s2,s1);
	}
}
*/
//long long sum1,sum2;
//long long s1_char[40],s2_char[40];
//long long ff(int x){
//	if(x==0||x==1){
//		return x;
//	}else{
//		return ((long long)x*(x-1)/2)%mmod;
//	}
//}
//void solve(){
//	cin>>s1>>s2;
//	for(long long i=0;i<s1.length();i++){
//		if(s1_char[s1[i]-97]==0){
//			sum1++;
//		}
//		s1_char[s1[i]-97]++;
//	}
//	for(long long i=0;i<s2.length();i++){
//		if(s2_char[s2[i]-97]==0){
//			sum2++;
//		}
//		s2_char[s2[i]-97]++;
//	}
////	cout<<"*****"<<sum1<<"****"<<sum2<<endl;
//	long long ans=0;
//	if(sum1==sum2){
//		for(int i=0;i<28;i++){
//			ans=(ans+ff(s1_char[i]))%mmod;
//		}
//	}else if(sum1>sum2){
////	cout<<"1"<<endl;
////		for(int i=0;i<28;i++){
//////			cout<<"s1_char[i]:::*"<<s1_char[i]<<"*s2_char[i]:::*"<<s2_char[i]<<endl;
////			if(s2_char[i]==0&&s1_char[i]!=0){
////				ans=ans+abs(s2_char[i]-s1_char[i])%mmod;
//////				cout<<ans<<endl;
////			}
////		}
//        for(long long i=0;i<s2.length();i++){
//        	if(s2_char[s2[i]-97]!=0&&s2[i]!=s1[i]){
//        			ans+=abs(s2_char[s2[i]-97]-s1_char[s2[i]-97])%mmod;
////        			cout<<s2_char[s2[i]-97]<<"****"<<s1_char[s2[i]-97]<<endl;
//			}
//		}
//	}else{
//		for(long long i=0;i<s1.length();i++){
//        	if(s1_char[s1[i]-97]!=0&&s1[i]!=s2[i]){
//        			ans+=abs(s1_char[s1[i]-97]-s2_char[s1[i]-97])%mmod;
////        			cout<<s2_char[s2[i]-97]<<"****"<<s1_char[s2[i]-97]<<endl;
//			}
//		}
//	}
//	cout<<ans<<'\n';
//}
int main(){
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
}
