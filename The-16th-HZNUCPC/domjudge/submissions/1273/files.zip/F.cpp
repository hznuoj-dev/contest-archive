#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
	ll n,m;
	cin>>n>>m;
	if(m>=n) 
	{
		if(m==1)
			cout<<"YES";
		else	
			cout<<"NO";
		return 0;
	}
	for(ll i=2;i*i<=n;i++)
	{
		if(n%i==0)
		{
			if(m<i)
			{
				cout<<"YES";
				return 0;
			}
			else
			{
				cout<<"NO";
				return 0;
			}
		}
	}
	cout<<"YES";
}