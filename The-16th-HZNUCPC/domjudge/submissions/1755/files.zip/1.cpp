#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define debug(x) cerr<<#x<<" "<<x<<"\n"

ll kk[27*27];
map<ll,ll>A,B;

const ll mod=1e9+7;

ll sza=0,szb=0;

void myswap(int u,int v){
    A[u]--;
    if(A[u]==0) sza--;

    if(B[u]==0) szb++;
    B[u]++;

    if(A[v]==0) sza++;
    A[v]++;

    B[v]--;
    if(B[v]==0) szb--;
}

void _solve(){
    string a,b;cin>>a>>b;
    int n=a.length();
    ll ans=0;
    for(int i=0;i<n;i++){
        int u=a[i]-'a';
        int v=b[i]-'a';
        A[u]++;
        B[v]++;
        kk[u*26+v]++;
    }
    sza=A.size();
    szb=B.size();
    for(int i=0;i<27*27;i++){
        if(kk[i]<1) continue;
        if(kk[i]>=2){
            int u=i/26;
            int v=i%26;
            myswap(u,v);
            myswap(u,v);
            if(sza==szb){
                ans+=kk[i]*(kk[i]-1)/2;
                ans%=mod;
            }
            myswap(v,u);
            myswap(v,u);
        }
        for(int j=i+1;j<27*27;j++){
            if(kk[j]<1) continue;
            int u1=i/26;
            int v1=i%26;
            int u2=j/26;
            int v2=j%26;
            myswap(u1,v1);
            myswap(u2,v2);
            if(sza==szb){
                ans+=kk[i]*kk[j];
                ans%=mod;
            }
            myswap(v1,u1);
            myswap(v2,u2);
        }
    }
    cout<<ans<<"\n";
}

int main(){
    ios::sync_with_stdio(false);

//    int T;cin>>T;while(T--)
    _solve();
}
