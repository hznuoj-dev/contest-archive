#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,m;
	cin>>n>>m;
	if(n<m){
		cout<<"NO";
		return 0;
	}else{
		while(true){
		int t=n%m;
		if(t==1){
			cout<<"YES";
			return 0;
		}
		if(t==0){
			cout<<"NO";
			return 0;
		}
		m=t;
		}
	}
}