#include<bits/stdc++.h>
#define int long long
#define fs first
#define sc second
using namespace std;
const int N=1e5+5,M=1e6+5;
int n,m,T;
pair<double,double> a[105];
double p(int i,int j){
	if (a[i].fs==a[j].fs) return 90;
	return (a[i].sc-a[j].sc)/(a[i].fs-a[j].fs);
}
int cal(int i,int j){
	double f=p(i,j);
	if (f==90){
		return abs(a[i].sc-a[j].sc)-1;
	}
	if (f==0){
		return abs(a[i].fs-a[j].fs)-1;
	}
	int  x=abs(a[i].fs-a[j].fs),y=abs(a[i].sc-a[j].sc);
	return __gcd(x,y)-1;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin >> n;
	for (int i=0;i<n;i++){
		cin >> a[i].fs >> a[i].sc;
	}
	int ans=0;
	for (int i=0;i<n;i++){
		for (int j=i+1;j<n;j++){
			if (a[i].fs==a[j].fs && a[i].sc==a[j].sc) continue;
			for (int k=j+1;k<n;k++){
				if (a[i].fs==a[k].fs && a[i].sc==a[k].sc) continue;
				if (a[j].fs==a[k].fs && a[j].sc==a[k].sc) continue;
				if ((a[i].fs-a[j].fs)*(a[k].sc-a[j].sc)==(a[k].fs-a[j].fs)*(a[i].sc-a[j].sc)) continue;
				
				int c1=cal(i,j),c2=cal(i,k),c3=cal(j,k);
				//cout << c1 <<' '<< c2 <<' '<<c3<<'\n';
				ans=max(ans,c1+c2+c3+3);
			}
		}
	}
	cout << ans << '\n';
	return 0;
}
/*
3
0 0
0 3
1 3
4
0 0
1 1
2 4
4 2

4
1 1
2 2
3 3
2 4

4
0 0
0 3
1 1
1 2

6
0 0 
0 1
0 2 
0 3
0 4
0 5

3
0 0
1 0
2 0

4
0 0
0 1
1 0
1 1
*/
