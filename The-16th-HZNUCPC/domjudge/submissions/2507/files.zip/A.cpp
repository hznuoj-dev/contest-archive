#include<bits/stdc++.h>
using namespace std;
const int N = 20;
int gp[N][N];
int dx[4] = {1 , 0 , -1 , 0};
int dy[4] = {0 , 1 , 0 , -1};
int cnt;
int st[N][N];

void dfs(int xx , int yy){
				if(gp[xx][yy] != 2){
				bool flag = false;
					for(int k = 0 ; k < 4 ; k ++){		
						int x = xx + dx[k] , y = yy + dy[k];
						if(gp[x][y] != 1 && x <= 19 && x >= 0 && y <= 19 && y >= 0 && !st[x][y]){
							st[x][y] = true;
							dfs(x , y);
						}
						if(gp[x][y] == 1 && x <= 19 && x >= 0 && y <= 19 && y >= 0 && !st[x][y]){
							flag = true;
						}
					}
					if(flag){
//						cout << xx << ' ' << yy << endl;
						cnt ++;
					}
				}
}

int main (){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin >> t;
	while(t --){
		int n;
		cin >> n;
		cnt = 0;
		memset(gp , 0 , sizeof gp);
		memset(st , false , sizeof st);
		for(int i = 1 ;i <= n ; i ++){
			int x , y , c;
			cin >> x >> y >> c;
			gp[x][y] = c;
		}
		dfs(0 , 0);
		cout << cnt << "\n";
	}
	return 0;
}