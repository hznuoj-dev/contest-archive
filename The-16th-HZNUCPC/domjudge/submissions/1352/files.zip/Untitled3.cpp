#include<iostream>
using namespace std;
int main(){
	long long n, m;
	while(cin >> n >> m){
		if(m == 1) cout << "YES\n";
		else if(n == 1) cout << "YES\n";
		else if(n <= m) cout << "NO\n";
		else{
			long long a = m;
			long long b = n % m;
			bool flag = false;
			while(b != 0){
				a = b;
				b = n % a;
				if(a == 1){
					flag = true;
					break;
				}
			}
			if(flag) cout << "YES\n";
			else cout << "NO\n";
		}
	}
	return 0;
}