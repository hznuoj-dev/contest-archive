#include<bits/stdc++.h>
using namespace std;
#define rep(i,l,r) for(int i=(l);i<=(r);i++)
#define mkp make_pair
#define mod (int)(1e9+7)
#define int long long
const int N=50100;
int T;
char ch[N];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>T;
	while(T--){
		cin>>(ch+1);
		int len=strlen(ch+1);
		int ans=0;
		string s="@#";
		rep(i,1,len)s+=ch[i],s+="#";
		len=s.size()-1;
//		rep(i,1,len)cout<<s[i];cout<<endl;
		rep(i,1,len){
			int ll=1;int cc=0;
			char ca,cb;
			while(i-ll>0&&i+ll<=len){
				if(s[i-ll]!=s[i+ll]){
					if(cc==2)break;
					if(cc==1){
						char mn=min(s[i-ll],s[i+ll]),mx=max(s[i-ll],s[i+ll]);
						if(mn!=ca||mx!=cb)break;
						cc++;
					}
					if(cc==0){
						ca=min(s[i-ll],s[i+ll]),cb=max(s[i-ll],s[i+ll]);
						cc++;ans=max(ans,ll-1);
					}
				}
				ll++;
			}
			if(cc==1)continue;
			ans=max(ans,ll-1);
//			cout<<i<<' '<<ll<<endl;
		}
		if(ans<2)cout<<0<<endl;
		else cout<<ans<<endl;
	}
	return 0;
}