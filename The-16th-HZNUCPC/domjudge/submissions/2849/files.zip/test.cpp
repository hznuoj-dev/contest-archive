#include <bits/stdc++.h>

using namespace std;

int main(){
	long long n,k;
	while(cin >> n >> k){
		bool f = true;
		while(1)
		{
			if(k == 1) break;
			if((n % k) == 0 || n < k){
				f = false;
				break;
			}
			k = n % k;
		}          
		if(f) cout << "YES\n";
		else cout << "NO\n";      
	}
	return 0;     
}