#include<iostream>
using namespace std;
int ground[21][21];
int t;
int num;
int x,y;
bool color;
int dir[4][2]={-1,0, 0,1, 1,0, 0,-1};
int cnt;
int main()
{
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		cin>>num;
		for(int j=1;j<=num;j++)
		{
			cin>>x>>y>>color;
			ground[x][y]=color;
		}
	}
	for(int i=1;i<=19;i++)
	{
		for(int j=1;j<=19;j++)
		{
			if(ground[i][j]==1)
			{
				for(int k=0;k<=3;k++)
				{
					if(i+dir[k][0]>=1 && i+dir[k][0]<=19 &&
					i+dir[k][1]>=1 && i+dir[k][1]<=19 &&
					ground[i+dir[k][0]][i+dir[k][1]]==0)
						cnt++;
				}
			}
		}
	}
	cout<<cnt;
	
	return 0;
}