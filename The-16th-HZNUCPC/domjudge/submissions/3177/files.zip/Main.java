package oj;

import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner sc = new Scanner(System.in);
		long n = sc.nextLong();
		long m = sc.nextLong();
		long k = m;
		if(n==1||m==1){
			System.out.println("YES");
			return;
		}
		while(true){
			k = n % k;
			if(k==0){
				System.out.println("NO");
				break;
			}
			if(k==1){
				System.out.println("YES");
				break;
			}
		}
	}
}
