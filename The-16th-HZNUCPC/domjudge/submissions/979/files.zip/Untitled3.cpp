#include<bits/stdc++.h>

using namespace std;

const int N = 1e5 + 10;

#define int long long

signed main() {
	int n, m;
	cin >> n >> m;
	if (n <= m)  {
		puts("NO");
		return 0;
	}
	for (int i = 2; i * i <= n; i ++)
	{
		if (n % i == 0) {
			if (i <= m) {
				puts("NO");
				return 0;
			}
			int t = n / i;
			if (t <= m) {
				puts("NO");
				return 03;
			}
		}
	}
	puts("YES");
	
}