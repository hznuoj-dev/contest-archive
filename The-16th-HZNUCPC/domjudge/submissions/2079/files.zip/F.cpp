#include<bits/stdc++.h>

using namespace std;

int main() {
	long long n,m,k=0;
	scanf("%lld %lld",&n,&m);
	while(m!=0)
	{
		m=n%m;
		if(m==1)
		{
			k=1;
			printf("YES");
			break;
		}
	}
	if(k==0)
	printf("NO");
	return 0;
}

