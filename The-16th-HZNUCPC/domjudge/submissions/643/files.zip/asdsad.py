dirs = [[0,1],[0,-1],[1,0],[-1,0]]
for _ in range(int(input())):
    n = int(input())
    has = [[0]*20 for _ in range(20)]
    hei = []
    for _ in range(n):
        x,y,c = map(int,input().split())
        if c == 1:
            has[x][y] = 1
        elif c == 2:
            has[x][y] = 2
        hei.append([x,y])
    res = 0
    for i,j in hei:
        for x,y in dirs:
            x += i;y += j;
            if 1 <= x <= 19 and 1 <= y <= 19 and has[x][y] == 0:
                res += 1
    print(res)
                    
    
