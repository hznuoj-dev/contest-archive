import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			int n=in.nextInt();
			int m=in.nextInt();
			int x=in.nextInt();
			t sz[]=new t[n+1];
			for(int i=0;i<n;i++){
				int q=in.nextInt();
				int w=in.nextInt();
				int e=in.nextInt();
				t qq=new t(w,e);
				sz[q]=qq;
			}
			for(int i=0;i<m;i++){
				int time=in.nextInt();
				int z=in.nextInt();
				if(sz[time].a<=z&&sz[time].b>=z){
					System.out.println(time);
				}else{
					System.out.println(-1);
				}
			}
		}
		
		}
	public static class t {
		int a;
		int b;
		public  t(int a,int b){
			this.a=a;
			this.b=b;
		}
	}
}
