#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int P=1e9+7;
ll c[26][26];
struct node{
	int c,cc[26];
	node(){
		c=0;
		memset(cc,0,sizeof(cc));
	}
	void add(int x){
		if(!cc[x])c++;
		cc[x]++;
	}
	void del(int x){
		cc[x]--;
		if(!cc[x])c--;
	}
};
ll C[222][222];
node A,B;
ll ans;
ll qpow(ll a,ll b=P-2) {
	ll res=1;
	while(b){
		if(b&1)res=res*a%P;
		a=a*a%P;b>>=1;
	}
	return res;
}
void solve(){
	for(int i=0;i<222;i++){
		C[i][0]=C[i][i]=1;
		for(int j=1;j<i;j++){
			C[i][j]=(C[i-1][j]+C[i-1][j-1])%P;
		}
	}
	string a,b;
	cin>>a>>b;
	int n=a.size();
	for(int i=0;i<n;i++){
		c[a[i]-'a'][b[i]-'a']++;
		A.add(a[i]-'a');
		B.add(b[i]-'a');
	}
	for(int p1=0;p1<26;p1++){
		for(int p2=0;p2<26;p2++){
			for(int q1=0;q1<26;q1++){
				for(int q2=0;q2<26;q2++){
					if(c[p1][p2]&&c[q1][q2]){
						if(p1==q1&&p2==q2){
							if(c[p1][p2]==1)continue;
							A.del(p1),A.del(q1);
							A.add(q2),A.add(q2);
							B.add(p1),B.add(q1);
							B.del(q2),B.del(q2);
							if(A.c==B.c){
								ans=(ans+c[p1][p2]*(c[p1][p2]-1))%P;
							}
							B.del(p1),B.del(q1);
							B.add(q2),B.add(q2);
							A.add(p1),A.add(q1);
							A.del(q2),A.del(q2);
						}else{
							A.del(p1),A.del(q1);
							A.add(q2),A.add(q2);
							B.add(p1),B.add(q1);
							B.del(q2),B.del(q2);
							if(A.c==B.c){
								ans=(ans+c[p1][p2]*c[q1][q2])%P;
							}
							B.del(p1),B.del(q1);
							B.add(q2),B.add(q2);
							A.add(p1),A.add(q1);
							A.del(q2),A.del(q2);
						}
					}
				}
			}
		}
	}
	cout<<ans*qpow(2)%P<<'\n';
}
int main(){
	ios::sync_with_stdio(0);
	int T=1;
//	cin>>T;
	while(T--){
		solve();
	}
}