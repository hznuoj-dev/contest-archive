#include<bits/stdc++.h>
using namespace std;
int T;
char a[10050],b[10050];
int main(){
	cin>>T;
	while(T--)
	{
		cin>>b+1;
		int n=strlen(b+1);
		for(int i=1;i<=n;i++)
		{
			a[2*i]=b[i];
			a[2*i-1]='#';
		}
		int ans=0;
		n=2*n+1;
		a[n]='#';
		a[n+1]=0;
//		cout<<(a+1)<<endl;
		for(int i=1;i<=n;i++)
		{
			int difCnt=0;
			int sto[10]={};
			for(int len=1;1;len++)
			{
				int ls=i-len+1;
				int rs=i+len-1;
				if(ls<=0||rs>n)
				{
					break;
				}
				if(a[ls]!=a[rs])
				{
					if(difCnt<2)
					{
						sto[++sto[0]]=a[ls];
						sto[++sto[0]]=a[rs];
						difCnt++;
					}
					else
					{
						break;
					}
				}
				if(difCnt==2)
				{
					sort(sto+1,sto+4+1);
					if(sto[1]!=sto[2]||sto[3]!=sto[4])break;
				}
				if(difCnt==1)
				{
					if(a[i]!='#')
					{
						if(a[i]==sto[1]||a[i]==sto[2])
						{
							ans=max(ans,len-1);
						}
					}
				}
				if(difCnt!=1)
				{
					ans=max(ans,len-1);
				}
			}
		}
		if(ans==1)ans=0;
		printf("%d\n",ans);
	}
	return 0;
}
