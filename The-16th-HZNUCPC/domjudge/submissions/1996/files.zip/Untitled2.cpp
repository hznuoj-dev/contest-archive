#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
#include<unordered_map>
#include<cstring>
#include<cmath>
#include<set>
using namespace std;
const int N=1e5+7;
typedef long long ll;
int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};
ll n,m;
inline ll gcd(ll x,ll y)
{
	return y?gcd(y,y%y):x;
}
void solve()
{
	scanf("%lld%lld",&n,&m);
	if(n==1 || m==1)
	{
		printf("YES\n");
		return;
	}
	if(n<=m){
		printf("NO\n");
		return;
	}
	if(n&1 ==0 )
	{
		printf("NO\n");
	}
	ll x=0;
	for(ll i=2;i<=n/i;i++)
	{
		if(n%i==0)
		{
			x=i;
			break;
		}
	}
	if(x<=m)
	{
		printf("NO\n");
	}
	else{
		printf("YES\n");
	}
	return ;
}

int main()
{
	int T;
	T=1;
	//scanf("%d",&T);
	while(T--)
	{
		solve();
	}
	return 0;
}