#include<iostream>
using namespace std;
long long n,m,flag=0;
int main()
{
	scanf("%lld%lld",&n,&m);
	if(n==1||m==1)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	if(n<=m)
	{
		cout<<"NO"<<endl;
		return 0;
	}
	while(m)
	{
		cout << n<< " "<<m <<endl;
		if(m==1)
			break;
		if(n%m==0)
		{
			cout<<"NO"<<endl;
			return 0;
		}
		m=n%m;
		
	}
	cout<<"YES"<<endl;
	return 0;
}