#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
// #define DEBUG

int main() {
	
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);

	ll n,m;
	cin>>n>>m;

	if(n==1 || m==1) cout<<"YES\n";
	else{

		ll r=-1;
		for(ll i=2;i*i<=n;i++){
			if(n%i==0){ r=i;break; }
		}
		if(r==-1) r=n;
		if(m<r) cout<<"YES\n";
		else cout<<"NO\n";

	}
	
    return 0;
}