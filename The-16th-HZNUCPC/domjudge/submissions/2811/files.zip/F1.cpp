#include<bits/stdc++.h>

using namespace std;

#define int long long
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

using ll = long long;

const int N = 1e5+10;
const int M = 1e9+7;

ll prime(ll n){
	for(int i=2;i<=sqrt(n);i++){
		if(n%i==0){
			return 0;
		}
	}
	return 1;
}

void solve(){
	int n,m,i;
	cin>>n>>m;
	
	if(n==1){
		cout<<"YES";
		return ;
	}
	if(n>m){
		if(m==1) cout<<"YES";
		else if(n%2==0) cout<<"NO";
		else if(prime(n)) cout<<"YES";
		else if(n%3==0) cout<<"NO";
		else cout<<"YES"; 
	}
	else cout<<"NO";
	
	
	

}

signed main(){
	IOS;
	
	int t;
	//cin>>t;
	t=1;
	
	while(t--){
		solve();
	}
	
	return 0;
}