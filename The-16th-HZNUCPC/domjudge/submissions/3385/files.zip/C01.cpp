#include <bits/stdc++.h>

typedef long long int ll;

const ll mo = 1000000007;

char s1[100100]; ll cnt1[30];
char s2[100100]; ll cnt2[30];
int len;

ll cnt[30][30];

inline bool judge(){
	int i;
	int set1 = 0, set2 = 0;
	for(i = 0; i < 26; i++){
		if(cnt1[i]){
			set1++;
		}
		if(cnt2[i]){
			set2++;
		}
	}
	return set1 == set2;
}

bool vis[30][30][30][30];

int main(){
	scanf("%s", s1 + 1);
	scanf("%s", s2 + 1);
	
	len = strlen(s1 + 1);
	
	int i, j, k, t;
	
	for(i = 1; i <= len; i++){
		cnt1[s1[i] - 'a']++;
		cnt2[s2[i] - 'a']++;
		cnt[s1[i] - 'a'][s2[i] - 'a']++;
	}
	
	ll ans = 0;
	for(i = 0; i < 26; i++){
		for(j = 0; j < 26; j++){
			for(k = 0; k < 26; k++){
				for(t = 0; t < 26; t++){
					if(vis[k][t][i][j]){
						continue;
					}
					vis[i][j][k][t] = true;
					if(i == k && j == t){
						if(cnt[i][j] <= 1){
							continue;
						}
						cnt1[i] -= 2;
						cnt1[j] += 2;
						cnt2[i] += 2;
						cnt2[j] -= 2;
						if(judge()){
							ans += cnt[i][j] * (cnt[i][j] - 1) / 2;
							ans %= mo;
						}
						cnt1[i] += 2;
						cnt1[j] -= 2;
						cnt2[i] -= 2;
						cnt2[j] += 2;
					}else{
						if(0 == cnt[i][j] || 0 == cnt[k][t]){
							continue;
						}
						cnt1[i]--; cnt2[i]++;
						cnt1[j]++; cnt2[j]--;
						cnt1[k]--; cnt2[k]++;
						cnt1[t]++; cnt2[t]--;
						if(judge()){
							ans += cnt[i][j] * cnt[k][t];
							ans %= mo;
						}
						cnt1[i]++; cnt2[i]--;
						cnt1[j]--; cnt2[j]++;
						cnt1[k]++; cnt2[k]--;
						cnt1[t]--; cnt2[t]++;
					}
				}
			}
		}
	}
	
	printf("%lld", ans);
	
	return 0;
}
