#include<bits/stdc++.h>
using namespace std;
int n,x[105],y[105];
#define LD double
const LD eps=1e-8;
struct Point
{
	LD x,y;Point(LD X=0,LD Y=0){x=X,y=Y;};
	inline void in(){scanf("%lf%lf",&x,&y);};
}a[105];
inline int dcmp(LD a){return a<-eps?-1:(a>eps?1:0);}
inline bool operator==(Point a,Point b){return !dcmp(a.x-b.x)&&!dcmp(a.y-b.y);}
inline Point operator-(Point a,Point b){return Point(a.x-b.x,a.y-b.y);
}
inline LD Cro(Point a,Point b){
	return a.x*b.y-a.y*b.x;
}
int gcd(int x,int y){
	return y==0?x:gcd(y,x%y);
}
int check(Point p,Point a,Point b){
	return !dcmp(Cro(p-a,b-a));
}
int main(){
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		a[i].in();
	}
	long long ans=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				if(a[i]==a[j]||a[j]==a[k]||a[i]==a[k])continue;
				if(check(a[i],a[j],a[k]))continue;
				ans=max(ans,(long long)
				gcd(abs(a[i].x-a[j].x),abs(a[i].y-a[j].y))+
				gcd(abs(a[i].x-a[k].x),abs(a[i].y-a[k].y))+
				gcd(abs(a[j].x-a[k].x),abs(a[j].y-a[k].y)));
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}
