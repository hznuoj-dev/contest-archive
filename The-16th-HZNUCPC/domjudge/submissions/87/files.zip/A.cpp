#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int vis[22][22];
int n;
int dx[]={1,-1,0,0};
int dy[]={0,0,1,-1};

void work(){
	memset(vis,0,sizeof vis);
	
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		vis[x][y]=z;
	}	
	int cnt=0;
	for(int i=1;i<=19;++i){
		for(int j=1;j<=19;++j){
			if(vis[i][j]==1){
				for(int k=0;k<4;++k){
					int tx=i+dx[k],ty=j+dy[k];
					if(tx>=1&&tx<=19&&ty>=1&&ty<=19&&!vis[tx][ty]){
						++cnt;
					}
				}				
			}
		}
	}
	printf("%d\n",cnt);
}

int main() {
	int T;
	scanf("%d",&T);
	while(T--){
		work();
	}
}
/*
2
2
1 1 1
2 2 1
2
10 9 1
10 10 1

*/