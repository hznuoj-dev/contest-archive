#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod = 1e9 +7;
const int N = 1e3 +7;
ll n,m,s;
ll x[N],y[N];
inline void run(){
      cin >> n ;
      for(int i=1;i<=n;i++) cin>>x[i]>>y[i];
      ll sum=0,Max=0;
      double a,b,c;
      for(int i=1;i<=n-2;i++)
      {
          for(int j=i+1;j<=n-1;j++)
          {
              for(int k=j+1;k<=n;k++)
              {
              	  ll x1 = abs(x[i]-x[j]);
              	  ll y1 = abs(y[i]-y[j]);
              	  ll x2 = abs(x[i]-x[k]);
				  ll y2 = abs(y[i]-y[k]);
				  ll x3 = abs(x[k]-x[j]);
				  ll y3 = abs(y[k]-y[j]);
                  double a = sqrt(x1*x1+y1*y1)*1.0;
              	  double b=sqrt(x2*x2+y2*y2)*1.0;
              	  double c=sqrt(x3*x3+y3*y3)*1.0;
              	 if(a+b<=c||a+c<=b||b+c<=a) continue;
				 ll d1 = __gcd(x1,y1);
				 ll d2 = __gcd(x2,y2);
				 ll d3 = __gcd(x3,y3); 
//				 sum = max(sum,d1+d2+d3-2);
//                 cout<<d1 <<" " <<d2 <<' ' <<d3<<endl;
                 sum = max(sum,d1+d2+d3);
              }
          }
      }
    cout <<sum <<endl;
}
int main()
{
        run();
        /*
	        4
	        0 0
	        1 1
	        2 4
	        4 2
		*/
        
}

