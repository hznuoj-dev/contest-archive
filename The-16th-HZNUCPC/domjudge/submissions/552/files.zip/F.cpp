#include<bits/stdc++.h>
#define int long long
using namespace std;
const int A=1e5+5;
int n,m;
int dir[4][2]={1,0,0,1,-1,0,0,-1};
int arr[25][25];
int ck(int y,int x){
	int num=0;
	for(int i=0;i<4;i++){
		int ty=y+dir[i][0];
		int tx=x+dir[i][1];
		if(ty<0||ty>20||tx<0||tx>20)continue;
		if(arr[ty][tx]!=-1)continue;
		arr[ty][tx]=2;
		num++;
	}
	return num;
}
signed main(){
	while(cin>>n>>m){
		int f=0;
		while(m){
			if(n%m==0)break;
			m=n%m;
			if(m==1){
				f=1;
				break;
			}
		}
		if(f)cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
	return 0;
}