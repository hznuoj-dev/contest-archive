#include<bits/stdc++.h>
using namespace std;
int flag=0;
int p,n,m,flagx=1,flagy=1;
int pdx,pdy;
int x[120],y[120],z[120],ans=0;
int pd(int tmp1,int tmp2)
{
	int fx=abs(x[tmp1]-x[tmp2]);
	int fy=abs(y[tmp1]-y[tmp2]);
	return min(fx,fy)-1;
}
int main() 
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d",&x[i],&y[i]);
		if(i==1)
		{
			pdx=x[1];
			pdy=y[i];
		}
		else
		{
			if(pdx!=x[i])
				flagx=0;
			if(pdy!=y[i])
				flagy=0;
		}
	}
	if(flagx||flagy)
	{
		cout<<0<<endl;
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int z=j+1;z<=n;z++)
			{
				int sum=pd(i,j);
				sum+=pd(j,z);
				sum+=pd(i,z);
				sum+=3;
				ans=max(ans,sum);
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}