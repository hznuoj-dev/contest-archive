#include <bits/stdc++.h>
#define all(x) (x).begin(),(x).end()

using namespace std;

const int N = 1e5 + 10, mod = 1e9 + 7;

typedef long long LL;
typedef pair<int, int> PII;

int s[2];
int Cnt[26][26];
int cnt[2][26];
int d[26][26];

void add(int op, int x) {
	if(cnt[op][x] == 0) s[op] ++ ;
	cnt[op][x] ++ ;
}

void del(int op, int x) {
	cnt[op][x] -- ;
	if(cnt[op][x] == 0) s[op] -- ;
}

void solve()
{
	string a, b;
	cin >> a >> b;
	int n = a.size();
	a = " " + a;
	b = " " + b;

	LL res = 0;
	for (int i = 1; i <= n; i ++ )
	{
		if(cnt[0][a[i] - 'a'] == 0) s[0] ++ ;
		if(cnt[1][b[i] - 'a'] == 0) s[1] ++ ;
		
		Cnt[a[i] - 'a'][b[i] - 'a'] ++ ;

		cnt[0][a[i] - 'a'] ++ ;
		cnt[1][b[i] - 'a'] ++ ;
	}
	
	for (int i = 1; i <= n; i ++ )
	{
		Cnt[a[i] - 'a'][b[i] - 'a'] -- ;
		
		del(0, a[i] - 'a');
		add(1, a[i] - 'a');
		del(1, b[i] - 'a');
		add(0, b[i] - 'a');
		
		for (int j = 0; j < 26; j ++ ) {
			for (int k = 0; k < 26; k ++ ) {
				if(Cnt[j][k]) {
					del(0, j);
					add(1, j);
					del(1, k);
					add(0, k);
					if(s[0] == s[1]) 
					{
						//cout << i << ' ' << j << ' ' << k << ' ' << Cnt[j][k] << '\n';	
						res += Cnt[j][k];
					}
					
					del(1, j);
					add(0, j);
					del(0, k);
					add(1, k);	
				}		
			}
		}
		
		del(1, a[i] - 'a');
		add(0, a[i] - 'a');
		del(0, b[i] - 'a');
		add(1, b[i] - 'a');
	}
	
	cout << res % mod << '\n';
}

int main()
{
	ios::sync_with_stdio(0), cin.tie(0);
    int t = 1;
//    cin >> t;
    while (t -- ) solve();
    return 0;
}
