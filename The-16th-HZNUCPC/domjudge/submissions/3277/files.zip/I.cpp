#include<bits/stdc++.h>
using namespace std;
using ll=long long;
using ull=unsigned long long;
const int N=5e4+5,mod=1e9+7;
const ll k=131;
const int mo1 = 998244353;
ull hs1[N],hs2[N];
ll hsm1[N],hsm2[N];
ull kpow[N];
ll kpowm[N];
pair<ll,ll>gethash1(int l,int r){
	ll u=hs1[r]-hs1[l-1]*kpow[r-l+1];
	ll v=hsm1[r]-hsm1[l-1]*kpowm[r-l+1];
	u = (u%mo1+mo1)%mo1;
	v=(v%mod+mod)%mod;
	return {u,v};
}
pair<ll,ll> gethash2(int l,int r){
	ll u=hs2[l]-hs2[r+1]*kpow[r-l+1];
	ll v=hsm2[l]-hsm2[r+1]*kpowm[r-l+1];
	u = (u%mo1+mo1)%mo1;
	v=(v%mod+mod)%mod;
	return {u,v};
}
int ch[N][26],pam_cnt,last,fail[N],len[N],pos[N];
char s[N];
int n;
int maxlen[N];
void pam_init(){
	for(int i=0;i<=pam_cnt;++i){
		memset(ch[i],0,sizeof ch[i]);
		len[i]=fail[i]=0;
	}
	pam_cnt=1;last=0;fail[0]=1;fail[1]=1;len[1]=-1;
}
int getfail(int x,int i){
	while(i-len[x]-1<0||s[i-len[x]-1]!=s[i])x=fail[x];
	return x;
}
void extend(int c,int i){
	int f=getfail(last,i);
	if(!ch[f][c]){
		int p=++pam_cnt;
		pos[p]=i;
		len[p]=len[f]+2;
		int q=getfail(fail[f],i);
		fail[p]=ch[q][c];
		ch[f][c]=p;
	}
	last=ch[f][c];
}
void work(){
	scanf("%s",s+1);
	n=strlen(s+1);
	for(int i=1;i<=n;++i){
		hs1[i]=(hs1[i-1]*k%mo1+s[i])%mo1;
		hsm1[i]=(hsm1[i-1]*13331%mod+s[i])%mod;
	}
	hs2[n+1]=0;
	hsm2[n+1]=0;
	for(int i=n;i;--i){
		hs2[i]=(hs2[i+1]*k%mo1+s[i])%mo1;
		hsm2[i]=(hsm2[i+1]*13331%mod+s[i])%mod;
	}
	pam_init();
	for(int i=1;i<=n;++i){
		extend(s[i]-'a',i);
		maxlen[i]=len[last];
	}
	int ans=0;
	for(int i=1;i<=n;++i){
		int L=i-maxlen[i]+1,R=i;
		if(R-L+1>=2)ans=max(ans,R-L+1);
		if(L==1||R==n)continue;
		int p=R+1,l=R+2,r=n;
		while(l<=r){
			int mid=l+r>>1;
			int slen=mid-R-1;
			if(L-2<slen||gethash1(R+2,mid)!=gethash2(L-1-slen,L-1-1))r=mid-1;
			else p=mid,l=mid+1;
		}
		int q=p+1;
		int q1=L-(q-R);
		if(1<=q&&q<=n&&q1>=1&&q1<=n&&s[q]==s[L-1]&&s[q1]==s[R+1]){
			int xx=q,l=q+1,r=n;
			while(l<=r){
				int mid=l+r>>1;
				int slen=mid-q;
				if(q1-1<slen||gethash1(q+1,mid)!=gethash2(q1-slen,q1-1))r=mid-1;
				else xx=mid,l=mid+1;
			}
			ans=max(ans,R-L+1+2*(xx-R));
		}
	}
	printf("%d\n",ans);
}

int main() {
	kpow[0]=kpowm[0]=1;
	for(int i=1;i<N;++i){
		kpow[i]=kpow[i-1]*k%mo1;
		kpowm[i]=kpowm[i-1]*13331%mod;
	}
	int T;scanf("%d",&T);
	while(T--)work();
}
/*

1
ccxyxazyxbghgaxyzbxydc

1000
abccab
ihi
stfgfiut
palindrome
ccxyxazyxbghgaxyzbxydc
cbacb


*/