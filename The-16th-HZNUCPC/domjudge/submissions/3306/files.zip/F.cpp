#include<bits/stdc++.h>
using namespace std;
long long n,m;
int main() {
	ios::sync_with_stdio(false), cin.tie(NULL), cout.tie(NULL);
	cin>>n>>m;
	if(n==1||m==1){
		cout<<"YES"<<endl;
		return 0;
	}
	
	for (long long i = 2; i <= m; i ++) {
		if (n % i == 0) {
			cout << "NO" << endl;
			return 0;
		}
	}
	
	cout<<"YES"<<endl;
}