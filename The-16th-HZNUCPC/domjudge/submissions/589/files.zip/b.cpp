#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;
int main(){
	scanf("%lld%lld",&n,&m);
	if (n<=m) return puts("NO"),0;
	for (ll i=2;i*i<=n;++i){
		if (n%i) continue;
		if (i<=m||n/i<=m) return puts("NO"),0;
	}
	puts("YES");
	return 0;
}