#include <bits/stdc++.h>

using std::min;
using std::sqrt;
using std::floor;

typedef long long int ll;

ll n, m;

int main(){
	scanf("%lld%lld", &n, &m);
	if(1 == m){
		printf("YES");
		return 0;
	}
	if(m >= n){
		printf("NO");
		return 0;
	}
	ll i;
	ll end = min(min(n, (ll)floor(sqrt(n)) + 1), m);
	for(i = 2; i <= end; i++){
		if(n % i == 0){
			printf("NO");
			return 0;
		}
	}
	printf("YES");
	return 0;
}
