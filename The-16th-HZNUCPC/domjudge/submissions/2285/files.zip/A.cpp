#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
#define fi first
#define se second
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
const ll mod = 1e9 + 7;
int cnt[28];
int main ()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    cin >> tt;
    while (tt--)
    {
       string a;
       cin>>a;
       int n;
       n=a.size();
       a=" "+a;int ans;
       int l,r;
       l=2;
       r=n-n%2;
        memset(cnt,0,sizeof(cnt));
        for(int i=1;i<=n;i++){
            cnt[a[i]-'a']++;
        }
       ans=0;
       while(l<=r){
            int m;
            m=(l+r)/2;
            m-=m%2;
            //cout<<"m:"<<m<<endl;
            int pan;
            pan=0;
            for(int i=1;i+m-1<=n;i++){
                vector<pair<int,int> >ve;
                 int ls,rs;
                ls=i;
                rs=i+m-1;
                for(int j=ls;j<=rs;j++){
                    cnt[a[j]-'a']--;
                }
                for(int len=1;len<=m/2;len++){

                    if(a[ls+len-1]!=a[rs-len+1]){
                        ve.push_back({ls+len-1,rs-len+1});
                    }
                }

                if(ve.empty()){
                    pan=1;
                   // break;
                }
                else if(ve.size()==1){
 //
                    if(cnt[a[ve[0].fi]-'a']>0||cnt[a[ve[0].se]-'a']>0){
                        pan=1;
                       // break;
                    }
                }
                else if(ve.size()==2){
                       // cout<<'@'<<m<<' '<<a[ve[0].fi]<<' '<<a[ve[0].se]<<' '<<a[ve[1].fi]<<' '<<a[ve[1].se]<<endl;
                    if((a[ve[0].fi]==a[ve[1].se]&&a[ve[0].se]==a[ve[1].fi])||(a[ve[0].fi]==a[ve[1].fi]&&a[ve[0].se]==a[ve[1].se])){
                        pan=1;
                       // break;
                    }
                }
                for(int j=ls;j<=rs;j++){
                    cnt[a[j]-'a']++;
                }
                if(pan)break;

            }
           // cout<<'@'<<m<<' '<<pan<<endl;
            if(pan){
                    l=m+2;
                    ans=max(ans,m);
                }
                else {
                    r=m-2;
                }

       }
        l=3;
       r=n-(1^(n%2));
       while(l<=r){
            int m;
            m=(l+r)/2;
            m-=(1^(m%2));
            int pan;
            pan=0;
             for(int i=1;i+m-1<=n;i++){
                vector<pair<int,int> >ve;
                 int ls,rs;
                ls=i;
                rs=i+m-1;
                for(int j=ls;j<=rs;j++){
                    cnt[a[j]-'a']--;
                }
                for(int len=1;len<=m/2;len++){

                    if(a[ls+len-1]!=a[rs-len+1]){
                        ve.push_back({ls+len-1,rs-len+1});
                    }
                }

                if(ve.empty()){
                    pan=1;
                    //break;
                }
                else if(ve.size()==1){
                    //   cout<<'@'<<m<<' '<<a[ve[0].fi]<<' '<<a[ve[0].se]<<' '<<cnt[a[ve[0].fi]-'a']<<' '<<cnt[a[ve[0].se]-'a']<<endl;
                    if(cnt[a[ve[0].fi]-'a']>0||cnt[a[ve[0].se]-'a']>0){
                        pan=1;
                       // break;
                    }
                }
                else if(ve.size()==2){
                  if((a[ve[0].fi]==a[ve[1].se]&&a[ve[0].se]==a[ve[1].fi])||(a[ve[0].fi]==a[ve[1].fi]&&a[ve[0].se]==a[ve[1].se])){
                           pan=1;
                        //break;
                    }
                }
                for(int j=ls;j<=rs;j++){
                    cnt[a[j]-'a']++;
                }
                if(pan)break;

            }if(pan){
                    l=m+2;
                    ans=max(ans,m);
                }
                else {
                    r=m-2;
                }
       }
       cout<<ans<<'\n';

    }

}
/*
1
aabcadcbda
*/
