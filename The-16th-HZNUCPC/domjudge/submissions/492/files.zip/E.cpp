#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 105;
int n;
struct data {
	int x, y;
}a[N];
ll ans;
ll gcd(ll x, ll y) {
	return (!y) ? x : gcd(y, x % y);
}
ll check(int p, int q) {
	ll x = abs(a[p].x - a[q].x), y = abs(a[p].y - a[q].y);
	return gcd(x, y);
}
int main() {
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> a[i].x >> a[i].y;
	}
	for(int i = 1; i <= n; i++)
		for(int j = i + 1; j <= n; j++)
			for(int k = j + 1; k <= n; k++)
				ans = max(ans, check(i, j) + check(i, k) + check(j, k));
	cout << ans << "\n";
	return 0;
}
/*
4
0 0
1 1
2 4
4 2

4
1 1
2 2
3 3
2 4
*/