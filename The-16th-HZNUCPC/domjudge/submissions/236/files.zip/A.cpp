#include<bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(0);cin.tie(nullptr);cout.tie(nullptr)
#define fi first
#define se second
#define pb push_back
#define eb emplace_back
#define int long long
#define endl '\n'
#define yes "YES\n"
#define no "NO\n"
const int inf = 0x3f3f3f3f;
const int mod = 1e9 +7;
const int N = 25;

int dx[4] = {0,0,-1,1};
int dy[4] = {1,-1,0,0};
int fpow(int x,int y){
	int ans = 1;
	while(y){
		if(y&1) ans = ans*x%mod;
		x = x*x%mod;
		y >>= 1;
	}
	return ans%mod;
}
int a[N][N];

void solve(){
	int n;
	cin >> n;
	memset(a,0,sizeof a);
	for(int i=1;i<=n;i++){
		int  x,y,c;
		cin >> x >> y >> c;
		a[x][y] = c;		
	}
	int cnt = 0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(a[i][j] == 0){
				for(int k=0;k<4;k++){
					int x = i+dx[k];
					int y = j+dy[k];
					if(x<1 || x>19 || y<1 || y> 19) continue;
					if(a[x][y] == 1) cnt++;
				}
			}
		}
	}
	cout << cnt << endl;
}

signed main(){
	IOS;
	int  T = 1;
	cin >> T;
	while(T--) solve();
	return 0;
}