import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		while (s.hasNext())
		{
			long n = s.nextLong();
			long m = s.nextLong();
			while (m != 0 && m != 1)
			{
				m = n % m;
			}
			if (m == 1)
				System.out.println("YES");
			else
				System.out.println("N0");
		}
	}
}
