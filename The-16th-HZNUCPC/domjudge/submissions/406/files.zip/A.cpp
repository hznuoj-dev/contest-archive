#include <bits/stdc++.h>
#define int long long
#define endl '\n'
using namespace std;
typedef unsigned long long ull;
const int N=2e5+10;
const int mod=1e9+7;

int a[24][24];

void run()
{
	int n,x,y,c,ans=0;
	
	cin >> n;
	memset(a,0,sizeof(a)); 
	for(int i=1;i<=n;i++)
	{
		cin >> x >> y >> c;
		a[x][y]=c;
	}
	
	for(int i=1;i<=19;i++)
		for(int j=1;j<=19;j++)
			if(a[i][j]==1)
			{
				if(i>1 && !a[i-1][j])
					ans++; 
				if(i<19 && !a[i+1][j])
					ans++;
				if(j>1 && !a[i][j-1])
					ans++;
				if(j<19 && !a[i][j+1])
					ans++;
			 } 
	cout << ans << endl;
}

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    cin >> T;
    while(T--)
        run();

    return 0;
}

