#include <bits/stdc++.h>

int _, n;

const int maxn = 500;

int x[maxn], y[maxn], z[maxn];
std::set<std::pair<int, int> > s2, s3;
std::vector<std::pair<int, int> > s1;

int X[4] = {1, 0, -1, 0};
int Y[4] = {0, 1, 0, -1};
bool check (int x, int y) {
	if (x < 1 || x > 19 || y < 1 || y > 19) return false;
	return true;
}
void solve () {
	std::cin >> n;
	s1.clear();
	s2.clear();
	for (int i = 1; i <= n; i++) {
		std::cin >> x[i] >> y[i] >> z[i];
		if (z[i] == 2)s2.insert(std::make_pair(x[i], y[i]));
		else s3.insert(std::make_pair(x[i], y[i]));
		for (int j = 0; j < 4; j++) {
			int tx = x[i] + X[j];
			int ty = y[i] + Y[j];
			if (!check(tx, ty)) continue;
			if (z[i] == 1) {
				s1.emplace_back(std::make_pair(tx, ty));
			}
		}
	}
	int ans = 0;
	for (auto it : s1) {
		if (!s2.count(it) && !s3.count(it)) {
			ans++;
		}
	}
	std::cout << ans << "\n";
}

int main () {
	std::ios::sync_with_stdio(false);
	std::cin >> _;
	while (_--) {
		solve();
	}
}
