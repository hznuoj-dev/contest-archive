#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
struct DSU
{
    vector<int>f,siz;
    DSU (int n):f(n),siz(n,1) {iota(f.begin(),f.end(),0); }
    int leader (int x)
    {
        while (x != f[x])
        {
            x = f[x] = f[f[x]];
        }
        return x;
    }
    bool same (int x,int y)
    {
        return leader(x) == leader(y);
    }
    bool merge (int x,int y)
    {
        x = leader(x);
        y = leader(y);
        if (x == y) return false;
        if (x < y)
            f[y] = x;
        else
            f[x] = y;
        return true;
    }
    int size(int x) { return siz[leader(x)];}
};
vector<int>ha[maxn];
int dp[maxn],w[maxn],wh[maxn];
pii pre[maxn];
int main ()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    //cin >> tt;
    while (tt--)
    {
        int n,m,q;
        cin >> n >> q >> m;
        DSU g(n*2+1);
        int pd = 1;
        for (int i = 1; i <= m; ++i)
        {
            int op,a,b;
            cin >> op >> a >> b;
            if (op == 0)
            {
                g.merge(a,b);
                g.merge(a+n,b+n);
            }
            else
            {
                g.merge(a+n,b);
                g.merge(a,b+n);
            }
        }
        for (int i = 1; i <= n; ++i)
        {
            if (g.same(i,i+n)) pd = 0;
        }
        if (pd)
        {
            for (int i = 1; i <= n; ++i)
            {
                ha[g.leader(i)].push_back(i);
            }
            int tot = 0,sum = 0;
            for (int i = 1; i <= n; ++i)
            {
                if (ha[i].size() > 0)
                {
                    w[++tot] = ha[i].size();
                    wh[tot] = i;
                }
            }
            dp[0] = 1;
            for (int i = 1; i <= tot; ++i)
            {
                //cout << ha[i].size() << "\n";
                for (int j = 0; j <= sum; ++j)
                {
                    if (dp[j] && !dp[j+w[i]])
                    {
                        dp[j+w[i]] = 1;
                        pre[j+w[i]] = {wh[i],j};
                    }
                }
                sum += w[i];
            }
            if (dp[q])
            {
                cout << "YES\n";
                int pos = q;
                while (pos > 0)
                {
                    int np = pre[pos].first;
                    pos = pre[pos].second;
                    for (auto it:ha[np])
                    {
                        cout << it << ' ';
                    }
                }
                cout << "\n";
            }
            else
            {
                cout << "NO\n";
            }
        }
        else{
            cout << "NO\n";
        }
    }

}
/*
4 2 4
1 1 3
1 2 4
0 3 4
0 1 2
*/
