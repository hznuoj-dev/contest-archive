#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
const ll N=100005,mod=1000000007;
ll n,k,m,tot,head[N],f[N],sum[N],c[N][2],now,d[N];
bool vis[N],is[N],b[N];
ll find(ll x)
{
    if(x==f[x])return x;
    return f[x]=find(f[x]);
}
struct node
{
    ll v,next,w;
}e[N<<1];
void add(ll u,ll v,ll w)
{
    e[++tot].v=v;
    e[tot].w=w;
    e[tot].next=head[u];
    head[u]=tot;
}
ll bfs(ll u)
{
    queue<ll>q;
    q.push(u);
    b[u]=0;
    vis[u]=1;
    ll cnt=1;
    while(!q.empty())
    {
        ll now=q.front();q.pop();
        for(ll i=head[u];i;i=e[i].next)
        {
            ll v=e[i].v,w=e[i].w;
            if(vis[v])
            {
                ll x=b[now]^w;
                if(x!=b[v])return -1;
            }
            else
            {
                vis[v]=1;
                ll x=b[now]^w;
                b[v]=x;
                if(x==0)++cnt;
                q.push(v);
            }
        }
    }
    return cnt;
}
signed main()
{
    //ios::sync_with_stdio(false);
    //cin.tie(0);
    cin>>n>>k>>m;
    for(ll i=1;i<=n;++i)f[i]=i;
    for(ll i=1;i<=m;++i)
    {
        ll w,u,v;
        cin>>w>>u>>v;
        add(u,v,w);
        add(v,u,w);
        u=find(u),v=find(v);
        f[u]=v;
    }
    for(ll i=1;i<=n;++i)
    {
        ll u=find(i);
        sum[u]++;
    }
    for(ll i=1;i<=n;++i)
    {
        ll u=find(i);
        if(is[u])continue;
        is[u]=1;
        ll h=bfs(u);
        if(h==-1){cout<<"NO";return 0;}
        c[++now][0]=h;
        c[now][1]=sum[u]-h;
    }
    //cout<<now<<endl;
    for(ll i=1;i<=now;++i)
    {
        ll mi=min(c[i][0],c[i][1]);
        d[i]=max(c[i][0],c[i][1])-mi;
        k-=mi;
    }
    if(k<0)cout<<"NO";
    else
    {
        cout<<k<<endl;
        for(ll i=1;i<=now;++i)cout<<d[i]<<" ";
    }
    return 0;
}
/*
4 2 4
1 1 3
1 2 4
0 3 4
0 1 2
*/
