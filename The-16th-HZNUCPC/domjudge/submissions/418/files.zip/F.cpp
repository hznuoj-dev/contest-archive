#include<bits/stdc++.h>
using namespace std;
using ll=long long;

vector<long long> v;

int main() {
	ll n,m;
	scanf("%lld%lld",&n,&m);
	if(n==1){
		puts("YES");
		return 0;
	}
	for (int i = 1; 1ll * i * i <= n; i++) {
		if (n % i == 0) {
			v.push_back(i);
			v.push_back(n/i);
		}
	}
	sort(v.begin(),v.end());
	if(v[1]<=m)puts("NO");
	else puts("YES");
//	if (!v.size()) puts("NO");
//	else if (v[0] <= m) puts("YES");
//	else puts("NO");
}