#include<bits/stdc++.h>
using namespace std;
int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};
void solve(){
	int i,j,n,m,k,sum=0;
	int ar[21][21]={0};
	cin>>n;
	int x,y,c;
	while(n--){
		cin>>x>>y>>c;
		ar[y][x]=-1;
		if(c==1){
			for(i=0;i<4;i++){
				int jx=x+dx[i];
				int jy=y+dy[i];
				if(ar[jy][jx]>=0){
					ar[jy][jx]++;
				}
			}
		}
	}
	for(i=1;i<=19;i++){
		for(j=1;j<=19;j++){
			sum+=max(0,ar[i][j]);
		}
	}
	cout<<sum<<endl;
}
int main(){
	
	int t;
	cin>>t;
	while(t--){
		solve();
	}

	return 0;
}