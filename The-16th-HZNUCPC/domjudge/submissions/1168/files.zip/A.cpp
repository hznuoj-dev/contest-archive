#include<bits/stdc++.h>
using namespace std;
#define int long long
struct ll{
	int x,y;
}q[105];
int ck(int x,int y){
	int re=0;
	int g=__gcd(x,y);
	re+=g;
	return re;
}
void solve(){
//	double a=sqrt((1-2)*(1-2)+(1-4)*(1-4));
//	double b=sqrt((1-3)*(1-3)+(1-3)*(1-3));
//	double c=sqrt((3-2)*(3-2)+(3-4)*(3-4));
//	double p=(a+b+c)/2;
//	double mx=sqrt(p*(p-a)*(p-b)*(p-c));
//	cout<<mx<<endl;
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		int x,y;
		cin>>x>>y;
		q[i]={x,y};
	}	
	int ans=0;
	for(int i=0;i+2<n;i++){
		int x=q[i].x,y=q[i].y;
		for(int j=i+1;j+1<n;j++){
			int xx=q[j].x,yy=q[j].y;
			for(int k=j+1;k<n;k++){
				int sum=0;
				int xxx=q[k].x,yyy=q[k].y;
				sum+=ck(abs(x-xx),abs(y-yy));	
				sum+=ck(abs(x-xxx),abs(y-yyy));	
				sum+=ck(abs(xxx-xx),abs(yyy-yy));	
				ans=max(sum,ans);	
			}
		}
	}
	printf("%lld\n",ans);
}

signed main(){
//	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}