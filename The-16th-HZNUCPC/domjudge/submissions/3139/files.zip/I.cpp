#include<iostream>
#include<cstdio>
#include<cmath>
using namespace std;
int T,n;
int main(){
	cin>>T;
	while (T--){
		string s;
		int ans=0;
		cin>>s;
		n=s.size();
		s=" "+s;
		for (int i=2;i<=n;++i){
			int t1=0,t2=0,fl=0;
			if (s[i-1]==s[i+1]) {
				fl=1;
				ans=max(ans,3);
			}
			else {
				t1=i+1;
				fl=0;
			}
			for (int j=i-2,k=i+2;j>=1&&k<=n;--j,++k){
				if (s[j]==s[k]){
					if (fl==1){
						ans=max(ans,k-j+1);
					}
				}
				else{	//不相等
					if (t1!=0){
						if (t2!=0){
//							if (i==3) cout<<t1<<" "<<t2<<endl;
							break;
						}
						else{
							t2=k;
							if (s[t1]==s[j] && s[t2]==s[2*i-t1]){
								ans=max(ans,k-j+1);
								fl=1;
							}
							else if (s[t1]==s[t2] && s[j]==s[2*i-t1]){
								ans=max(ans,k-j+1);
								fl=1;
							}
							else{
								break;
							}
						}
					}
					else{
						t1=k;
						fl=0;
					}
				}
			}
		} //step1
		
		for (int i=1;i<n;++i){
			int t1=0,t2=0,fl=0;
			if (s[i]==s[i+1]) {
				fl=1;
				ans=max(ans,2);
			}
			else {
				t1=i+1;
				fl=0;
			}
			for (int k=i+2,j=i-1;k<=n&&j>=1;--j,++k){
				if (s[j]==s[k]){
					if (fl==1){
						ans=max(ans,k-j+1);
					}
				}
				else{	//不相等
					if (t1!=0){
						if (t2!=0){
							break;
						}
						else{
							t2=k;
							if (s[t1]==s[j] && s[t2]==s[2*i+1-t1]){
//								cout<<i<<" "<<t1<<" "<<t2<<" ";
//								cout<<k<<" "<<j<<" "<<k-j+1<<endl;
								ans=max(ans,k-j+1);
								fl=1;
							}
							else if (s[t1]==s[t2] && s[j]==s[2*i+1-t1]){
								ans=max(ans,k-j+1);
								fl=1;
							}
							else{
								break;
							}
						}
					}
					else{
						t1=k;
						fl=0;
					}
				}
			}
		}	//step2
		
		for (int i=2;i<=n;++i){
			int t1=0,fl=1;
			for (int j=i-1,k=i+1;j>=1&&k<=n;--j,++k){
				if (s[j]==s[k]){
					if (fl==1){
						ans=max(ans,k-j+1);
					}
				}
				else{	//不相等
					if (t1!=0){
						break;
					}
					else{
						t1=k;
						if (s[i]==s[j]){
							fl=1;
							ans=max(ans,k-j+1);
						}
						else if (s[i]==s[k]){
							fl=1;
							ans=max(ans,k-j+1);
						}
						else{
							fl=0;
							break;
						}
					}
				}
			}
		} //step3
		cout<<ans<<endl;
	}
	return 0;
}