#include<bits/stdc++.h>
using namespace std;
#define dzs ios::sync_with_stdio(false);cin.tie(nullptr),cout.tie(nullptr)
typedef long long ll;
int main()
{
	int t=1;
	while(t--)
	{
	
	ll n,m;
	cin>>n>>m;
	while(n%m!=0&&n%m!=1)
	{
		m=n%m;
	}
	if(n%m==0&&m!=1) cout<<"NO"<<endl;
	else if(n%m==1||m==1) cout<<"YES"<<endl;
	}
} 