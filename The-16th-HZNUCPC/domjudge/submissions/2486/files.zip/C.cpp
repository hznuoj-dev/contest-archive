#include<bits/stdc++.h>
#define ll long long
#define all(a) (a).begin(),(a).end;
using namespace std;

int cnt[150][150];
int cnt2[2][150];
int w[50];
ll mod = 1e9 + 7;

int cal(int a, int b)
{
	int res = 10;
	if(cnt2[0][a] > 1 && (cnt2[1][a] == 1 && a == b || cnt2[1][a] == 0)) res += 1;
	else if(cnt2[0][a] > 1 && (cnt2[1][a] > 1 || cnt2[1][a] == 1 && a != b)) res += 0;
	else if(cnt2[0][a] == 1 && (cnt2[1][a] == 0 || cnt2[1][a] == 1 && a == b)) res += 2;
	else res++;
	
	if(cnt2[1][b] > 1 && (cnt2[0][b] == 1 && a == b || cnt2[0][b] == 0)) res -= 1;
	else if(cnt2[1][b] > 1 && (cnt2[0][b] > 1 || cnt2[0][b] == 1 && a != b)) res -= 0;
	else if(cnt2[1][b] == 1 && (cnt2[0][b] == 0 || cnt2[0][b] == 1 && a == b)) res -= 2;
	else res--;
	
	return res;
}

void solve()
{
	string s1, s2;
	cin >> s1 >> s2;
	int n = s1.size();
	
	for(int i = 0; i < n; i++) cnt[s1[i]][s2[i]]++;
	for(int i = 0; i < n; i++) cnt2[0][s1[i]]++, cnt2[1][s2[i]]++;
	
	for(int i = 'a'; i <= 'z'; i++)
		for(int j = 'a'; j <= 'z'; j++)
			w[cal(i, j)] += cnt[i][j];
	
	
//	cout << "w " << w[cal('a', 'a')] << '\n';
//	cout << "??? " << cal('a', 'a') << '\n';
	ll ans = 0;
	for(int i = 0; i < n; i++)
	{		
		cnt[s1[i]][s2[i]]--;

		cnt2[0][s1[i]]--;
		cnt2[0][s2[i]]++;
		cnt2[1][s2[i]]--;
		cnt2[1][s1[i]]++;		
		
		int diff = 10;
		for(int j = 'a'; j <= 'z'; j++) if(cnt2[0][j]) diff++;
		for(int j = 'a'; j <= 'z'; j++) if(cnt2[1][j]) diff--;
		
		for(int j = 0; j <= 30; j++) w[j] = 0;
		for(char ch1 = 'a'; ch1 <= 'z'; ch1++)
			for(char ch2 = 'a'; ch2 <= 'z'; ch2++)
				w[cal(ch1, ch2)] += cnt[ch1][ch2];
		
//		for(char j = 'a'; j <= 'c'; j++)
//			for(char k = 'a'; k <= 'c'; k++)
//				cout <<"i j k cnt cal w " <<  i << ' ' << j << ' ' << k << ' ' << cnt[j][k] << ' ' << cal(j, k) << ' ' << w[cal(j, k)] << '\n';
				
//		cout << "diff " << diff << '\n';
		
		if(diff < 50 && diff >= 0) ans += w[diff];
		
//		cout << "ans " << ans << '\n';
		/////////////////////////////
		cnt[s1[i]][s2[i]]++;
		
		cnt2[0][s1[i]]++;
		cnt2[0][s2[i]]--;
		cnt2[1][s2[i]]++;
		cnt2[1][s1[i]]--;
	}
	
	cout << ans / 2 % mod << '\n';
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin >> t;
	while(t--) solve();
	return 0;
}