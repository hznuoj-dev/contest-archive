#include <bits/stdc++.h>

using namespace std;
#define int long long

signed main(){
	int n,k;
	while(cin >> n >> k){
		if((n & 1) || k == 1) cout << "YES\n";
		else cout << "NO\n";
	}	
	return 0;
}