import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		long n = s.nextLong();
		long m = s.nextLong();
		while (true)
		{
			long h = n % m;
			if (h == 0)
			{
				m = 0;
				break;
			}
			if (h == 1)
			{
				m=1;
				break;
			}
			long j = m - h;
			long piao=n/m;
			if (n-j*piao > j *piao)
			{	
				m = h;
			}
			else if (n-j*piao < j *piao)
			{	
				m = j;
			}
		}
		if (m == 1 )
			System.out.print("YES\r\n");
		else
			System.out.print("NO\r\n");
	}
}
