#include <iostream>
using namespace std;
long long  m,n;
bool flag=true;
int main(int argc, char** argv) {
	cin>>n>>m;
	for(long long i=2;i<=m;i++){
		if(n%i==0){
			flag=false;
			break;
		}
	}
	if(flag) cout<<"YES";
    else cout<<"NO";
	return 0;
}