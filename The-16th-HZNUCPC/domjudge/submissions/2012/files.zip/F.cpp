#include<iostream>

using namespace std;


int main(){

long long int n, m;
cin>>n>>m;
if (m == 1 || n ==1)
{
    cout<<"YES"<<endl;
}
else
{
    if ((n % 2) == 0)
    {
        cout<<"NO"<<endl;
    }
    else
    {
        if (n <= m)
        {
            cout<<"NO"<<endl;
        }
        else
        {
            int f = 0;
            for (long long int k = m; k >= 3; k--)
            {
                if (n % k == 0)
                {
                    cout<<"NO"<<endl;
                    f = 1;
                }
            }
            if (f == 0)
                cout<<"YES"<<endl;
        }
    }
}


}
