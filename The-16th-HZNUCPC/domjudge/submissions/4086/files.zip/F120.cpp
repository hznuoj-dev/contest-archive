#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m;
signed main(){
	while(cin>>n>>m){
		if(n==1||m==1||n-m==1){
			cout<<"YES"<<endl;
			continue;
		}
		if(n<=m){
			cout<<"NO"<<endl;
			continue;
		}
		if(n%2==1&&m%2==1){
			cout<<"YES"<<endl;
		}else if(n%2==1&&m%2==0){
			cout<<"YES"<<endl;
		}else if(n%2==0&&m%2==1){
			cout<<"YES"<<endl;
		}else if(n%2==0&&m%2==0){
			cout<<"YES"<<endl;
		}
	}
	return 0;
}