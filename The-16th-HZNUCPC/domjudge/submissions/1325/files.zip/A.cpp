#include<bits/stdc++.h>
using namespace std;
const int N=500;
const int M=500;
int dx[10]={0,1,-1,0,0};
int dy[10]={0,0,0,1,-1};
int T,n,q,m;
int a[N][N],b[N],c[N];
int main()
{
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		for(int i=1;i<=n;i++)
		{
			scanf("%d%d",&b[i],&c[i]);
			scanf("%d",&a[b[i]][c[i]]);
		}
		int ans=0;
		for(int i=1;i<=n;i++)
		{
			if(a[b[i]][c[i]]==1)
			{
				for(int j=1;j<=4;j++)
				{	
//					printf("%d %d\n",b[i]+dx[j],c[i]+dy[j]);
					if(b[i]+dx[j]>=20||b[i]+dx[j]<=0||c[i]+dy[j]>=20||c[i]+dy[j]<=0) continue;
					if(!a[b[i]+dx[j]][c[i]+dy[j]]) ans++;
				}
			}
		}
		printf("%d\n",ans);
		for(int i=1;i<=n;i++)
		{
			a[b[i]][c[i]]=0;
		}
	}
	return 0;
}