#include <bits/stdc++.h>
using namespace std;


const int N = 110;

int n;
int x[N];
int y[N];

int gcd(int a, int b)
{
    if(!b) return a;
    return gcd(b, a % b);
}

int check(int i, int j)
{

    int xx = abs(x[i] - x[j]);
    int yy = abs(y[i] - y[j]);
    return gcd(xx, yy) + 1;
}

int get(int i, int j, int k)
{
    return check(i, j) + check(i, k) + check(j, k);
}

int main()
{
    int ans = 0;
    scanf("%d", &n);
    for (int i = 1; i <= n; i ++)
        scanf("%d%d", &x[i], &y[i]);
    for (int i = 1; i <= n; i ++)
    {
        for (int j = i + 1; j <= n; j ++)
        {
            for (int k = j + 1; k <= n; k ++)
            {
                ans = max(ans, get(i, j, k));
            }
        }}

    cout << ans -3 << '\n';

}
