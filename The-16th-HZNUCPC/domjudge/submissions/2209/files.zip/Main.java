import java.util.Arrays;
import java.util.Scanner;

public class Main 
{
	public static void main(String[] args) 
	{
		Scanner sc = new Scanner(System.in);
		long n=sc.nextLong();
		long k=sc.nextLong();
		boolean y;
		while(true){
			if(k==1){
				y=true;
				break;
			}
			if(k==0){
				y=false;
				break;
			}
			k=n%k;
			
		}
		if(y)System.out.println("YES");
		else System.out.println("NO");
	}
}
