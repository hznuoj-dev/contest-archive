#include<bits/stdc++.h>
#define pcc pair<char,char>
#define pss pair<string,string>
#define ll long long
using namespace std;
const int mod=1e9+7;
int main(){
	string a,b;
	cin>>a>>b;
	int n=a.length();
	map<pss,ll>mp;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(i==j)continue;
			string x=a;
			string y=b;
			swap(x[i],y[i]);
			swap(x[j],y[j]);
			
			mp[{x,y}]++;
		}
	}
	ll ans=0;
	for(auto kk:mp){
//	cout<<kk.first.first<<' '<<kk.first.second<<' '<<kk.second<<endl;	
		ans=max(ans,kk.second);
	}
	cout<<ans%mod<<endl;
//	map<pcc,ll>mp;
//	ll x=0,y=0;
//	for(int i=0;i<n;i++){
////		mp[{a[i],b[i]}]++;
//		if(a[i]!=b[i])x++;
//		else y++;
//	}
////	for(auto k:mp){
////		cout<<k.first.first<<' '<<k.first.second<<' '<<k.second<<endl;
////	}
//	cout<<max(x,1ll)*max(y,1ll)%mod<<endl;
	return 0;
}