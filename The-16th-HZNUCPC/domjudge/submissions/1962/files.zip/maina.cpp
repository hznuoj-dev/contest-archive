#include <bits/stdc++.h>
#define N (int)110
#define dwan ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define int long long
typedef long long ll;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

void solve(){
	vector<int> p_fac;
	int n,m;
	cin>>n>>m;
	if(n==1){
		cout<<"YES"<<endl;
		return;
	}
	if(m>=n){
		cout<<"NO"<<endl;
		return;
	}else{
		for(int i=2;i<=n/i;i++){
			if(n%i==0){
				p_fac.push_back(i);
				while(n%i==0) n/=i;
			}
		}
	}
	if(n>1)p_fac.push_back(n);
	for(int i=0;i<p_fac.size();i++){
		if(p_fac[i]<=m){
			cout<<"NO"<<endl;
			return;
		}
	}
	cout<<"YES"<<endl;
}
signed main(int argc, char** argv) {
	dwan;
	int t = 1;
	//cin>>t;
	while(t--){
		solve();
	}
}