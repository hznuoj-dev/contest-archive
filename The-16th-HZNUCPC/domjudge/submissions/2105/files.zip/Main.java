import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;
import java.util.Scanner;

public class Main {
	static StreamTokenizer sr=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in))); 
	
	static Scanner in = new Scanner(System.in);
	public static void main(String[] args) {
		long n=in.nextLong();
		long m=in.nextLong();
		while(m!=1){
			if(n%m==0){
				System.out.println("NO");
				return;
			}else{
				m=n%m;
			}
		}
		System.out.println("YES");
	}
}
