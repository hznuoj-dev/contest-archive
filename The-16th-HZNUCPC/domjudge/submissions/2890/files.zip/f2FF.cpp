#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ct(x) cout<<x<<'\n'
#define dg(x)  cout<<#x<<'='<<x<<'\n';
#define pii  pair<int,int> 
#define N 350000
#define double long double
#define ios ios::sync_with_stdio(0),cin.tie(0),cout.tie(0)
#define endl '\n'
#define yes cout<<"YES"<<'\n';
#define no cout<<"NO"<<'\n';


void solve(){
		int n,m;
	cin>>n>>m;
   while(1){
     int p=n%m;
	 if(p==0){
	 	if(m==1){
	 		yes;
	 		return;
		 }
		else{
			no;
			return;
		}
	 }	
	 	m=p; 
  }
	
}

signed main(){
	ios;
	int t=1;
	// cin>>t;
	while(t--)
	solve();
	return 0;
}