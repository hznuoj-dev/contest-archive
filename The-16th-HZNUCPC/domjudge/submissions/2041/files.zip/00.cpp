#include <bits/stdc++.h>

using namespace std;

using i64 = long long;

const int N = 2e5 + 100;

int main()
{
	i64 n, m;
	cin >> n >> m;
	
	if(m > n)
	{
		puts("NO");
		return 0;
	}
	
	if(m == 1)
	{
		puts("YES");
		return 0;
	}
	
	while(1)
	{
//		if(m == 1)
//		{
//			puts("YES");
//			return 0;
//		}
		
		if(n % m == 0)
		{
			puts("NO");
			return 0;
		
		}
		
		if(n % m == 1)
		{
			puts("YES");
			return 0;
		}	
		
		m = n % m;
		
//		if(m == 1)
//		{
//			puts("YES");
//			return 0;
//		}
	}
	return 0;
}