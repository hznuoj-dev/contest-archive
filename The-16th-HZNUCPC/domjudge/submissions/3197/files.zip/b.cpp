#include<bits/stdc++.h>
#define For(i,l,r) for(int i=l,i##end=r;i<=i##end;++i)
#define rFor(i,r,l) for(int i=r,i##end=l;i>=i##end;--i)
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
ull func(ull x) {
	x^=x<<13;
	x^=x>>7;
	x^=x<<17;
	return x;
}
ull gh(int n,ull *a) {
	static const ull D=2541195834385911452;
	ull ans=D;
	For(i,0,n-1) {
		ans=func(ans)^(a[i]+D);
	}
	return func(ans);
}
const int N=1e5+10;
struct nd {
	ll x,y;
	nd operator-(const nd b)const{
		return {x-b.x,y-b.y};
	}
};
ll dis(nd a) {
	return a.x*a.x+a.y*a.y;
}
int n; nd a[N];
ull get(nd a,nd b,nd c) {
	static ull f[10];
	ll x=dis(b-a),y=dis(c-b),z=dis(c-a);
	ll g=__gcd(x,__gcd(y,z));
	f[0]=x/g; f[1]=y/g; f[2]=z/g;
	return gh(3,f);
}
ull b[N];
map<ull,int>cnt;
const ull B=1e9+9;
ull p[N];
struct nd2 {
	ull x;int l;
	nd2 operator+(const nd2 b)const{
		return {x*p[b.l]+b.x,l+b.l};
	}
};
nd2 f[N],g[N];
int main() {
#ifdef LOCAL
    freopen(".in","r",stdin);
#endif
    ios::sync_with_stdio(0); cin.tie(0);
    int T;cin>>T;
    p[0]=1; For(i,1,1e5) p[i]=p[i-1]*B;
    while(T--) {
    	cin>>n;
    	For(i,1,n) cin>>a[i].x>>a[i].y;
    	For(j,1,2) a[n+j]=a[j];
    	For(i,1,n) b[i]=get(a[i],a[i+1],a[i+2]);
    	g[n+1]={0,0}; set<ull>st;
    	For(i,1,n) f[i]=f[i-1]+nd2{b[i],1};
    	rFor(i,n,1) g[i]=nd2{b[i],1}+g[i+1];
    	cout<<cnt[f[n].x]<<"\n";
    	For(i,0,n) {
    		st.insert((g[i+1]+f[i]).x);
		}
		reverse(b+1,b+n+1);
    	For(i,1,n) f[i]=f[i-1]+nd2{b[i],1};
    	rFor(i,n,1) g[i]=nd2{b[i],1}+g[i+1];
    	For(i,0,n) {
    		st.insert((g[i+1]+f[i]).x);
		}
		for(auto x:st) ++cnt[x];
	}
}