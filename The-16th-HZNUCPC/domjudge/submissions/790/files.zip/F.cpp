#include<iostream>
#include<cstring>
#include<algorithm>
#include<vector>

using namespace std;

typedef long long LL;

vector<int> s;

bool is_prime(LL n)
{
	if(n < 2) return false;
	else 
	{	
		for(LL i = 2; i <= n / i; i++)
			if(n % i == 0) return false;	
	}	
	return true;
} 


int main()
{
	LL n, m;
	cin >> n >> m;
	
	
	LL a = n , b = m;
	
	if(is_prime(n)) a = n;
	else
	{
		for(LL i = 2; i <= n / i; i++)
		{
			if(n % i == 0)
			{
				a = i;
				break;
			} 
		}
	}

	
	if(m == 1) cout << "YES" << endl;
	else if(n <= m) cout << "NO" << endl; 
	else if(a <= b) cout << "NO" << endl;
	else cout << "YES" << endl;
	
	return 0;
}
