#include<bits/stdc++.h>
using namespace std;
const int N=30;
int n;
int vis[N][N];
struct node{
	int x,y,c;
}a[N*N];
void clear(){
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++)vis[i][j]=0;
	}
}
int dx[]={1,-1,0,0};
int dy[]={0,0,1,-1};
signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int t;cin>>t;
	while(t--){
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>a[i].x>>a[i].y>>a[i].c;
			vis[a[i].x][a[i].y]=-1;
		}
		for(int i=1;i<=n;i++){
			if(a[i].c==2)continue;
			for(int j=0;j<4;j++){
				int rx=a[i].x+dx[j],ry=a[i].y+dy[j];
				if(vis[rx][ry]!=-1)vis[rx][ry]+=1;
			}
		}
		int ans=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(vis[i][j]!=-1){
					ans+=vis[i][j];
				}
			}
		}
		cout<<ans<<"\n";
		clear();
	}
}