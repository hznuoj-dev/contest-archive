#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

bool isp(ll n,ll m){
	if(m==1)return true;
	if(n==2)return false;
	if(m>=n)return false;
	for(ll i=2;i*i<=n && i<=m;i++){
		if(n%i==0)return false;
	}
	return true;
}

void solve(){
	ll n,m;
	cin>>n>>m;
	if(isp(n,m)){
		cout<<"YES\n";
	}else{
		cout<<"NO\n";
	}
}
int main(){
	ios::sync_with_stdio(0);
	int T=1;
//	cin>>T;
	while(T--){
		solve();
	}
}