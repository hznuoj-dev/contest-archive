#include "iostream"
using namespace std;
long long a,b,c,d,e,f;
int main(){
	while(cin>>a>>b){
		long long k=b;
		e=0;
		
		while(k!=1){
			c=a%k;\
			if(c==0){
				break;
			}
			d=a/k;
			k=a-d*k;
			
			
		}
		if(k==1){
			cout<<"YES"<<endl;
		}else{
			cout<<"No"<<endl;
		}
	
}
	return 0;
}