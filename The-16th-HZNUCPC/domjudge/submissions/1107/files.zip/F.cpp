#include "bits/stdc++.h"
using namespace std;
const int N = 1e5 + 10;
int a[N];
int main(){
	long long n,m;
	while(cin >> n >> m){
		if(n == 1){
			cout << "YES" << endl;
			continue;
		}
		if(n < m)cout << "NO" << endl;
		else {
			long long a = m % n;
			while(a > 1){
				a = n % a;
			}
			if(a == 1)cout << "YES" << endl;
			else cout << "NO" << endl;
		}
	}
	return 0;
}
