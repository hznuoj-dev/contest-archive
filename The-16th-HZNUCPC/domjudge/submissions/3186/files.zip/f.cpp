#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,x,y;
    scanf("%d%d",&x,&y);
	n=x%y;	
	if(x==1||y==1)
	{
     printf("YES");
	}
	else if(n==0||n<y)
	{
	   printf("NO");
	}
	else
	{
		while(n%y==1)
		{
			n+=x;	
		}
		printf("YES");
	}
	return 0;
}
