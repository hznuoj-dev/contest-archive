#include<bits/stdc++.h>
using namespace std;
typedef pair<int,int>p;
bool check(string s,int len){
// 	cout<<len<<endl;
	for(int l=0;l<=s.size()-len;l++){
		vector<p>v;
		int r=l+len-1,mid=(l+r)/2;
		for(int step=0;step<=len/2;step++){
			if(s[mid+step]!=s[mid-step]){
				v.push_back({mid+step,mid-step});
			}
		}
		if(v.size()==2){
			if(s[v[0].first]==s[v[1].second ]&& s[v[0].second]==s[v[1].first])
				return 1;
		}
		else if(v.size()==1){
			if(s[v[0].first]==s[mid] || s[v[0].second]==s[mid])
				return 1;
			}
		else if(v.size()==0)return 1;
	}
	return 0;
}
	
void solved(){
	string t;cin>>t;
	string s="#";
	for(auto i:t){
		s+=i;
		s+='#';
	}
	int l=2,r=t.size()+1,mid,ans=0;
	while(l<r){
		mid=(l+r)/2;
//		cout<<mid<<endl;
		if(check(s,mid*2+1)){
			l=mid+1;
			ans=max(ans,mid);
		}else r=mid;
	}
	cout<<ans<<endl;
}
int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int T;cin>>T;
	while(T--){
		solved();
	}
	return 0;
}