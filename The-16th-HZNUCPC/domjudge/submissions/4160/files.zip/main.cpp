#include <iostream>
using namespace std;
long long  m,n;
bool flag=true;
bool isPrime(int n){
	if(n%2==0){
		return false;
	}
	if(n==1||n==2){
		return true;
	}
	for(int i=3;i<n;i=i+2){
		if(n%i==0){
			return false;
		}
	}
	return true;
}
int main(int argc, char** argv) {
	cin>>n>>m;
	if(m==1||n==1){
		printf("YES");
	}
	else if(m>=n){
		printf("NO");
	}
	else if(isPrime(n)){
		printf("YES");
	}
	else{
		printf("NO");
	}
	return 0;
}