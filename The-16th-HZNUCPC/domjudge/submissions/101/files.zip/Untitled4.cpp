#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int,int>
const int N = 10010;

signed main(){
	int a,b;
	cin >> a >> b;
	if(__gcd(a,b) == 1){
		cout << "YES" ;
	}else{
		cout << "NO";
	}
	return 0;
}