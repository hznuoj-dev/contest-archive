#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n;
		scanf("%d",&n);
		int x[500],y[500],c[500];
		int d[50][50]={0};
		for(int i=0;i<n;i++)
		{
			scanf("%d%d%d",&x[i],&y[i],&c[i]);
			d[x[i]][y[i]]=c[i];
		}
		int ans=0;
		for(int i=0;i<n;i++)
		{
			if(d[x[i]][y[i]]==1)
			{
				if(!d[x[i]-1][y[i]]) ans++,d[x[i]-1][y[i]]=3;
				if(!d[x[i]+1][y[i]]) ans++,d[x[i]+1][y[i]]=3;
				if(!d[x[i]][y[i]-1]) ans++,d[x[i]][y[i]-1]=3;
				if(!d[x[i]][y[i]+1]) ans++,d[x[i]][y[i]+1]=3;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}