#include <bits/stdc++.h>

using namespace std;

const int N = 4e5 + 5;
const double eps = 1e-8;

int sgn(double x) {
	if (fabs(x) < eps) {
		return 0;
	} else if (x > 0) {
		return 1;
	} else {
		return -1;
	}
}

struct Point {
	double x, y;
	
	Point() { x = y = 0; }
	Point(double _x, double _y): x(_x), y(_y) { }
	Point operator+(const Point& b) {
		return Point(x + b.x, y + b.y);
	}
	Point operator-(const Point& b) {
		return Point(x - b.x, y - b.y);
	}
	double operator*(const Point& b) {
		return x * b.x + y * b.y;
	}
	double operator^(const Point& b) {
		return x * b.y - y * b.x;
	}
	
	const double dist() {
		return sqrt(x * x + y * y);
	}
};

using Vector = Point;

bool cmp(Point a, Point b) {
	if (sgn(a.x - b.x)) {
		return a.x < b.x;
	}
	return a.y < b.y;
}


Point stk[N];
int top;

vector<Point> get(vector<Point> v) {
	sort(v.begin(), v.end(), cmp);
	top = 0;
	int n = v.size(); 
	for (int i = 0; i < n; i++) {
		while (top > 1 && ((stk[top - 1] - stk[top - 2]) ^ (v[i] - stk[top - 2])) <= 0) {
			--top;
		}
		stk[top++] = v[i];
	}
	int k = top;
	for (int i = n - 2; i >= 0; i--) {
		while (top > k && ((stk[top - 1] - stk[top - 2]) ^ (v[i] - stk[top - 2])) <= 0) {
			top--;
		}
		stk[top++] = v[i];
	}
	
	vector<Point> ret;
	for (int i = 0; i < top - 1; i++) {
		ret.push_back(stk[i]);
	}
	return ret;
}

bool cmp2(pair<Vector, int> a, pair<Vector, int> b) {
	return a.first.dist() < b.first.dist();
}

const double P = 98244353;

double calc(vector<Point> a) {
	int n = a.size();
	vector<pair<Vector, int>> b(n);
	for (int i = 0; i < n; i++) {
		b[i] = {a[(i + 1) % n] - a[i], i};
	} 
	int id = b[0].second;
	vector<Point> g;
	for (int i = id; i < n; i++) {
		g.push_back(a[i]);
	}
	for (int i = 0; i < id; i++) {
		g.push_back(a[i]);
	}
	double k = b[0].first.dist();
	double s1 = 0, s2 = 0;
	for (int i = 0; i < n; i++) {
		s1 += b[i].first.dist();
		s2 += a[(i + 1) % n] ^ a[i];
	}
	return fabs(s2) / s1 / s1;
}


int n, m;
int ans[N];
int tmp[N];

int main() {
	cin >> n;
	vector<pair<double, int>> rec;
	for (int i = 1; i <= n; i++) {
		cin >> m;
		vector<Point> a(m);
		for (int j = 0; j < m; j++) {
			cin >> a[j].x >> a[j].y;
		}
		vector<Point> t = get(a);
		double x = calc(t);
//		cerr << i << " " << x << "\n";
		rec.push_back({x, i});        
	}
	sort(rec.begin(), rec.end());
	double st = rec[0].first;
	int m = 1;
	for (int i = 1; i < n; i++) {
		if (sgn(st - rec[i].first) == 0) {
			tmp[++m] = rec[i].second;
		} else {
			sort(tmp + 1, tmp + 1 + m);
			for (int j = 1; j <= m; j++) {
				ans[tmp[j]] = j - 1;
			}
			m = 1;
			st = rec[i].first;
		}
	}
	if (m > 1) {
		sort(tmp + 1, tmp + 1 + m);
		for (int j = 1; j <= m; j++) {
			ans[tmp[j]] = j - 1;
		}
	}
	for (int i = 1; i <= n; i++) {
		printf("%d\n", ans[i]);
	}
	return 0;
}