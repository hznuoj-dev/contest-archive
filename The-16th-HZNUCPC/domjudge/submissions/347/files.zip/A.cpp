#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[100][100];
int dx[] = {0, 1, -1, 0};
int dy[] = {1, 0, 0, -1};
void kaibai(){
	int n, ans=0, m = 19;
	scanf("%d", &n);
	for(int i = 0, x, y, w; i < n; i++){
		scanf("%d%d%d", &x, &y, &w);
		a[x][y] = w;
	}
	for(int i = 1; i <= 19; i++){
		for(int j = 1; j <= 19; j++){
			if(a[i][j] != 1) continue;
			for(int k = 0; k < 4; k++){
				int u = i + dx[k], v = j + dy[k];
				if(u >= 1 && u <= m && v >= 1 && v <= m && !a[u][v]){
					ans++;
				}
			}
		}
	}
	for(int i = 0; i <= 20; i++){
		for(int j = 0; j <= 20; j++){
			a[i][j] = 0;
		}
	}
	printf("%d\n", ans);
}
int main(void){
	int T=1;
	scanf("%d", &T);
	while(T--){
		kaibai();
	}
}