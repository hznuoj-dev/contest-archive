#include <bits/stdc++.h>
using namespace std;

const int kMaxN = 1e5 + 5;
int n, q, m, col[kMaxN], cnt[2], belong[kMaxN], tag[kMaxN];
bool vis[kMaxN];
vector<pair<int, int>> G[kMaxN];
bool valid;

void dfs(int cur, int scc) {
	++cnt[col[cur]];
	belong[cur] = scc;
	for (auto &j : G[cur]) {
		int to = j.first, typ = j.second;
		if (!vis[to]) {
			vis[to] = true;
			col[to] = col[cur] ^ typ;
			dfs(to, scc);
		} else {
			if (col[to] != col[cur] ^ typ) {
				cout << "NO" << "\n";
				exit(0);
			}
		}
	}
}

struct Node {
	int id, mn, mx, mxtag;
};
vector<Node> bag;
int smx[kMaxN], smn[kMaxN];
int scc = 0;

void dfs1(int pos, int sum) {
	if (clock() > 1.45 * CLOCKS_PER_SEC) {
		cout << "NO\n";
		exit(0);
	}
	if (pos == scc) {
		if (sum == q) {
			cout << "YES\n";
			vector<int> ans;
			for (int i = 1; i <= n; ++i) {
				if ((tag[belong[i]] ^ col[i]) == 0) {
					ans.push_back(i);
				}
			}
			for (int i = 1; i <= (int)ans.size(); ++i) {
				cout << ans[i - 1] << " \n"[i == (int)ans.size()];
			}
			exit(0);
		} else {
			return;	
		}
	}
	if (sum + smx[pos] < q) return;
	if (sum + smn[pos] > q) return;
	
	tag[pos] = bag[pos].mxtag;
	dfs1(pos + 1, sum + bag[pos].mx);
	
	tag[pos] = bag[pos].mxtag ^ 1;
	dfs1(pos + 1, sum + bag[pos].mn);
}

int main() {
	ios::sync_with_stdio(false);
	
	valid = true;
	cin >> n >> q >> m;
	for (int i = 1; i <= m; ++i) {
		int opt, a, b;
		cin >> opt >> a >> b;
		G[a].push_back(make_pair(b, opt));
		G[b].push_back(make_pair(a, opt));
	}
	
	memset(col, 0xff, sizeof col);
	for (int i = 1; i <= n; ++i) {
		if (!vis[i]) {
			++scc;
			tag[scc] = 0;
			cnt[0] = cnt[1] = col[i] = 0;
			vis[i] = true;
			dfs(i, scc);
			bag.push_back((Node) {scc, min(cnt[0], cnt[1]), max(cnt[0], cnt[1]), cnt[0] < cnt[1]});
		}
	}
	
	for (int i = scc - 1; i >= 0; --i) {
		smx[i] = smx[i + 1] + bag[i].mx;
		smn[i] = smn[i + 1] + bag[i].mn;
	}
	
	dfs1(0, 0);
	
	cout << "NO\n";
	
	return 0;
}