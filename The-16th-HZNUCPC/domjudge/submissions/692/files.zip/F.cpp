#include<bits/stdc++.h>
#define ll long long
#define sf scanf
#define pf printf
#define pb push_back
using namespace std;
vector<ll>num;
void divide(ll n){
	for(ll i=2;i<=n/i;i++)if(n%i==0){
		while(n%i==0)n/=i;
		num.pb(i);
	}if(n>1)num.pb(n);
} 
bool solve(){
	ll n,m;sf("%lld %lld",&n,&m);
	if(n==1)return 1;
	divide(n);
	for(auto x:num)if(x>=2&&x<=m)return 0;
	return 1;
	
}
signed main(){
	int t=1;//scanf("%d",&t);
	while(t--)puts(solve()?"YES":"NO");
}
