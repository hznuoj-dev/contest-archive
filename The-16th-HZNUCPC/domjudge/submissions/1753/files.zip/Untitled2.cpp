#include<bits/stdc++.h>
using namespace std;
#define dzs ios::sync_with_stdio(false);cin.tie(nullptr),cout.tie(nullptr)
typedef long long ll;
int main()
{
	dzs;
	int t=1;
	while(t--)
	{
		ll n,m,fl=1;
		cin>>n>>m;
		for(ll i=2;i<=sqrt(n)+2&&i<=m;i++)
		{
			if(n%i==0){
				fl=0;
				break;
			}
		}
		if(m>=n) fl=0;
		if(fl) cout<<"YES"<<endl;
		else cout<<"NO"<<endl;
	}
} 