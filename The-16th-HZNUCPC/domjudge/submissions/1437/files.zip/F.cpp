#include<iostream>
using namespace std;
long long n,m,k,score;
int main()
{
	cin>>n>>m;
	k = m;
	while(1){
		if(n % k == 0){
			printf("NO");
			break;
		}
		score = n / k + 1;
		k = n / score;
		if(k == 1){
			printf("YES");
			break;
		}
	}
	return 0;
}