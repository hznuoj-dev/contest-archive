#include<bits/stdc++.h>
#define int long long
#define mod (1000000007)
using namespace std;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
    string str1,str2;
    cin>>str1>>str2;
    int num1[26]={},num2[26]={},dp[30][30]={};
    int len=str1.size();
    for(int i=0;i<len;i++)
	{
		num1[str1[i]-'a']++;num2[str2[i]-'a']++;
		dp[str1[i]-'a'][str2[i]-'a']++;
	}
	int ans=0;
	int vis[30][30]={};
	for(int a=0;a<26;a++)
	{
		for(int b=0;b<26;b++)
		{
			for(int c=0;c<26;c++)
			{
				for(int d=0;d<26;d++)
			 	{
			 		if(dp[a][b]&&dp[c][d])
			 		{
			 			if(vis[a][b]&&vis[c][d])continue;
			 			vis[a][b]=1,vis[c][d]=1;
			 			if(a!=c||b!=d)
			 			{
			 			num1[a]--,num2[a]++;
					    num1[b]++,num2[b]--;
					    num1[c]--,num2[c]++;
						num1[d]++,num2[d]--;
						int a1=0;
						for(int i=0;i<26;i++)
						{
							if(num1[i])a1++;
							if(num2[i])a1--;
						}
						if(a1==0)ans=(ans%mod+(dp[a][b]*dp[c][d])%mod)%mod;
						num1[a]++,num2[a]--;
					    num1[b]--,num2[b]++;
					    num1[c]++,num2[c]--;
						num1[d]--,num2[d]++;	
						//cout<<a<<' '<<b<<'\n'<<c<<' '<<d<<'\n'<<ans1<<'\n';	
						}
						else if(a==c&&b==d)
						{
							num1[a]--,num2[a]++;
					    num1[b]++,num2[b]--;
					    num1[c]--,num2[c]++;
						num1[d]++,num2[d]--;
						int a1=0;
						for(int i=0;i<26;i++)
						{
							if(num1[i])a1++;
							if(num2[i])a1--;
						}
						//cout<<a1;
						if(a1==0)ans=(ans+((dp[a][b]-1)*dp[c][d]/2)%mod)%mod;
						//cout<<a<<' '<<b<<'\n'<<c<<' '<<d<<'\n'<<ans2<<'\n';
						num1[a]++,num2[a]--;
					    num1[b]--,num2[b]++;
					    num1[c]++,num2[c]--;
						num1[d]--,num2[d]++;
						}
					}
				}
			}
		}
	}
	cout<<ans%mod;
	return 0;
}
