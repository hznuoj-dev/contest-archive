#include <iostream>
#include <vector>
#include <cstring>
#define x first
#define y second
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
using namespace std;
int n;
pair<long long,long long>p[105];
pair<long long,long long>cnt[5];//记录三个点的位置
long long gcd(long long a,long long b)
{
      return b == 0 ? a: gcd(b,a%b);
}
long long find()
{
	long long num=3;
	
    long long x1=cnt[0].x-cnt[1].x;
	long long y1=cnt[0].y-cnt[1].y;
	long long x2=cnt[1].x-cnt[2].x;
	long long y2=cnt[1].y-cnt[2].y;
	long long t1=x2*y1;
	long long t2=x1*y2;
	if(t1==t2)return 0;
	
	
	
    for(int i=0;i<3;i++)
	{
	 for(int j=i+1;j<3;j++)
	 {
	 	long long a=abs(cnt[i].x-cnt[j].x);
	 	long long b=abs(cnt[i].y-cnt[j].y);
	 	num+=gcd(a,b)-1;
	 	//cout<<a<<b<<gcd(a,b)<<endl;
	 }
	}	
    return num;	
}
long long maxsum=0;
void dfs(long long num,long long temp)
{
	if(num==3)
	{
		maxsum=max(maxsum,find());
		return;
	}
	for(int i=temp+1;i<=n;i++)
	{
		cnt[num]=p[i];
		dfs(num+1,i);
	}
	
	
}


int main() {
	
    
    
	scanf("%lld",&n);
    
    
    
    for(int i=1;i<=n;i++)
    {
    	scanf("%lld%lld",&p[i].x,&p[i].y);
    	
	}
	dfs(0,0);
	//cout<<gcd(0,2)<<endl;
	printf("%lld",maxsum);
	
	return 0;
}