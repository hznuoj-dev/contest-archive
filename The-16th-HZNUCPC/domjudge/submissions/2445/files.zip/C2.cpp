#include<iostream>
#include<cstdio>
using namespace std;
string s1,s2;
long long n,len1,len2,a1[300],a2[300];
long long ans,p=1000000007,f[300][300];
int main(){
	cin>>s1>>s2;
	n=s1.size();
	for (int i=0;i<n;++i){
		if (!a1[s1[i]]) ++len1;
		++a1[s1[i]];
	}
	for (int i=0;i<n;++i){
		if (!a2[s2[i]]) ++len2;
		++a2[s2[i]];
	}
	for (int i=0;i<n;++i){
		++f[s1[i]][s2[i]];
	}
	
//	for (int i='a';i<='z';++i){
//		cout<<a1[i]<<" ";
//	}cout<<endl;
//	for (int i='a';i<='z';++i){
//		cout<<a2[i]<<" ";
//	}
	
//	cout<<len1<<" "<<len2<<endl;
//	cout<<f['b']['a']<<endl;
	
	for (int i1='a';i1<='z';++i1){
		for (int j1='a';j1<='z';++j1){
			if (!f[i1][j1]){
				continue;
			}
			for (int i2='a';i2<='z';++i2){
				for (int j2='a';j2<='z';++j2){
					if (!f[i2][j2]){
						continue;
					}
					if (i1==i2 && j1==j2 && f[i1][j1]<=1){
						continue;
					}
					int t1=len1,t2=len2;
					if (a1[i1]==1) --t1;
					if (a2[i1]==0) ++t2;
					--a1[i1];++a2[i1];
					if (a2[j1]==1) --t2;
					if (a1[j1]==0) ++t1;
					++a1[j1];--a2[j1];
					
					if (a1[i2]==1) --t1;
					if (a2[i2]==0) ++t2;
					--a1[i2];++a2[i2];
					
					if (a2[j2]==1) --t2;
					if (a1[j2]==0) ++t1;
					++a1[j2];--a2[j2];
					
					++a1[i1];--a2[i1];
					--a1[j1];++a2[j1];
					++a1[i2];--a2[i2];
					--a1[j2];++a2[j2];
						
					if (t1==t2){
//						cout<<(char)i1<<" "<<(char)j1<<" "<<(char)i2<<" "<<(char)j2<<endl;
//						cout<<f[i1][j1]*f[i2][j2]<<endl<<endl;
						if (i1==i2 && j1==j2) ans=(ans+(f[i1][j1]*(f[i2][j2]-1)));
						else ans=(ans+f[i1][j1]*f[i2][j2]);
					}
				}
			}
		}
	}
	cout<<(ans/2)%p;
	return 0;
}
