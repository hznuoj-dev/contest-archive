#include<bits/stdc++.h>
#define int long long
using namespace std;
map<int,int> mp;
int n;
int x[110],y[110];
signed main(){
	while(cin>>n){
		for(int i=0;i<n;i++){
			cin>>x[i]>>y[i];
		}
		int ans=0;
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				for(int z=j+1;z<n;z++){
					int sum=3;
					int dyx=abs(x[i]-x[j]),dyy=abs(y[i]-y[j]);
					int dex=abs(x[j]-x[z]),dey=abs(y[j]-y[z]);
					int dsx=abs(x[i]-x[z]),dsy=abs(y[z]-y[i]);
					int dygc=__gcd(dyx,dyy);
					int degc=__gcd(dex,dey);
					int dsgc=__gcd(dsx,dsy);
//					cout<<dygc<<" "<<degc<<" "<<dsgc<<endl;
					sum=sum+dygc+degc+dsgc-3;
					//pilipalayidunchaozho
					ans=max(ans,sum);
				}
			}
		}
		cout<<ans<<endl;
	}
	
	return 0;
}