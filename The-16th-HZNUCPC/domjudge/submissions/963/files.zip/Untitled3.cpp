#include<bits/stdc++.h>
using namespace std;

void solve(){
	long long n, m;
	cin >> n >> m;
	if(m == 1 || n == 1){
		cout << "YES\n";
		return ;
	}
	if(n % 2 == 0 || n % m == 0 || n <= m){
		cout << "NO\n";
		return ;
	}
	for(int i = 3; i * i <= n; i++){
		if(n % i == 0){
			if(i <= m){
				cout << "NO\n";
				return ;
			}
		}
	}
	cout << "YES\n";
}
int main(){
	int t = 1;
//	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}