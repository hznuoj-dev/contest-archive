n,m=map(int,input().split())
flag=False
if m==1:
    print('Yes')
elif n==1:
    print('YES')
elif m>=n:
    print('NO')
else:
    for i in range(2,n):
        if n%i==0:
            if i >m:
                print('YES')
                break
            else:
                print('NO')
                break
        