#include<stdio.h>
int main(){
	int t,n,ii,jj,l,sum;
	int s[21][21];
	scanf("%d",&t);
	for (int i=1;i<=t;i++){
		scanf("%d",&n);
		sum=0;
		int count1=0,count2=0;
		
		for (int j=0;j<20;j++){
			for (int k=0;k<20;k++){
				s[j][k]=0;
			}
		}
		for (int j=1;j<=n;j++){
			scanf("%d %d %d",&ii,&jj,&l);
			if (l==1){
				s[ii][jj]=2;
				count1++;
			}else{
				s[ii][jj]=1;
				count2++;
			}
		}
		for (int ii=0;ii<=19;ii++)
		 for(int jj=0;jj<=19;jj++){
		 			
			if (s[ii][jj]==2){
   			if (s[ii-1][jj]==0&&ii-1>=0){
				s[ii-1][jj]=1;
			}
            
        	if (s[ii+1][jj]==0&&ii+1<=19){
        	s[ii+1][jj]=1;
		}
            
        	if (s[ii][jj-1]==0&&jj-1>=0){
        	s[ii][jj-1]=1;
		}
            
        	if (s[ii][jj+1]==0&&jj+1<=19){
        	s[ii][jj+1]=1;
		}         
	}

	
}
	for (int ii=0;ii<=19;ii++){
		 for(int jj=0;jj<=19;jj++){
           sum+=s[ii][jj];
		   }
		   
	}
           

		
	
		printf("%d",sum-count1*2-count2);
	}
	return 0;
}