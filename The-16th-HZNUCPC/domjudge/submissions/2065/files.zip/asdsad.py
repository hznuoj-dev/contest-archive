import sys
input = lambda: sys.stdin.readline().strip()
n = int(input())
nums = []
for _ in range(n):
    nums.append(list(map(int,input().split())))
def gcd(a,b):
    while b:a,b = b,a%b
    return a
def aaa(x,y):
    return gcd(abs(x[0]-y[0]),abs(x[1]-y[1]))
def func(a,b,c):
    if (b[0]-a[0])*(c[1]-b[1]) == (c[0]-b[0])*(b[1]-a[1]):return 0
    return aaa(a,b)+aaa(b,c)+aaa(a,c)
ans = 0
for i in range(n):
    for j in range(i+1,n):
        for k in range(j+1,n):
            ans = max(ans,func(nums[i],nums[j],nums[k]))
print(ans)
    
                    
    
