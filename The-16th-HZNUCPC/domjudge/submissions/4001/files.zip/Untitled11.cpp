#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int n,m,q,cnt[2],flag,a[N],b[N],num,vis[N],col[N];
int ver[N<<1],head[N],tot,Next[N<<1],edge[N<<1];
int v[2][N],f[N];
void add(int x,int y,int z){
	ver[++tot]=y;
	Next[tot]=head[x];
	head[x]=tot;
	edge[tot]=z;
}
void dfs(int x){
	vis[x]=1;
	cnt[col[x]]++;
	for(int i=head[x];i;i=Next[i]){
		int y=ver[i];
		if(!vis[y]){
			if(!edge[i])col[y]=col[x];
			else col[y]=col[x]^1;
			dfs(y);
			if(flag)return;
		}
		else{
			if((edge[i]&&col[x]==col[y])||(!edge[i]&&col[x]!=col[y])){
				flag=1;
				return;
			}
		}
	}
}
int main()
{
	scanf("%d%d%d",&n,&q,&m);
	for(int i=1,k,a,b;i<=m;i++){
		scanf("%d%d%d",&k,&a,&b);
		add(a,b,k),add(b,a,k);
	}
	for(int i=1;i<=n;i++){
		if(!vis[i]){
			cnt[0]=cnt[1]=0;
			dfs(i);
			a[++num]=cnt[0],b[num]=cnt[1];
		}
	}
	if(flag)printf("NO\n");
	else{
		int op=1;
		for(int i=1;i<=num;i++){
			for(int j=q;j>=a[i];j--){
				if(!v[op^1][j]&&v[op^1][j-a[i]]){
					v[op][j]=i;
				}
				else v[op][j]=v[op^1][j];
			}
			for(int j=q;j>=b[i];j--){
				if(!v[op^1][j]&&v[op^1][j-b[i]]){
					v[op][j]=-i;
				}
				else v[op][j]=v[op^1][j];
			}
			op^=1;
		}
		if(!v[op][q])printf("NO\n");
		else{
			printf("YES\n");
			int tag=v[op][q];
			while(q){
				if(tag>0){
					printf("%d ",tag);
					q-=a[tag];
					tag=v[op][q];
				}
				else{
					printf("%d ",-tag);
					q-=b[-tag];
					tag=v[op][q];
				}
			}
		}
	}
	return 0;
}