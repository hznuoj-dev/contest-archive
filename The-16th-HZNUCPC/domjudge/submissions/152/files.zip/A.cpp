#include <stdio.h>

int main() {
	int t, n, x, y, i, j;
	scanf("%d", &t);
	while (t--){
		int a[19][19] = {0}, cnt = 0;
		scanf("%d", &n);
		while (n--) {
			scanf("%d %d", &x, &y);
			scanf("%d", &a[x][y]);
		}
		for (i = 0; i < 19; i++) {
			for (j = 0; j < 19; j++) {
				if (a[i][j] == 1) {
					if (!a[i + 1][j] && i + 1 < 19) {
						a[i + 1][j] = 3;
						cnt++;
					}
					if (!a[i - 1][j] && i - 1 > -1) {
						a[i - 1][j] = 3;
						cnt++;
					}
					if (!a[i][j + 1] && j + 1 < 19) {
						a[i][j + 1] = 3;
						cnt++;
					}
					if (!a[i][j - 1] && j - 1 > -1) {
						a[i][j - 1] = 3;
						cnt++;
					}
				}
			}
		}
		printf("%d\n", cnt);
	}
	return 0;
}