    #include  <bits/stdc++.h>

    using namespace std;
    typedef long long LL;
    const int mod = 1e9 + 7;

    LL n, m;

    void kizk(){
        cin >> n >> m;
        if(n <= m)
        {
            cout << "NO\n";
            return;
        }
        LL k = n / int(sqrt(n));
        if(n % m == 0)
        {
            cout << "NO\n";
            return;
        }
        if(n / k > n % k)
        {
            for(LL i = 2; i <= k; i ++)
            {
                if(n % i == 0)
                {
                    cout << "NO\n";
                    return;
                }
            }
        }
        
        cout << "YES\n";
    }


    int main(){
        std::ios::sync_with_stdio(false);
        cin.tie(nullptr);
        int T; T = 1;
        // cin >> T;
        while(T --) kizk();
        return 0;
    }