#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
char s1[100010];
char s2[100010];
ll s[21][21];
int main()
{
    //cin>>s1>>s2;
    ll n,m;
    cin>>n>>m;
    if(n<m){
        if(n==1)cout<<"YES"<<endl;
        else cout<<"NO"<<endl;
        return 0;
    }
    if(m==1){
        cout<<"YES"<<endl;
    }
    else{
        if(n%2==0){
            cout<<"NO"<<endl;
        }
        else{
            for(ll i=2;i*i<=m;i++){
                if(n%i==0){
                    cout<<"NO"<<endl;
                    return 0;
                }
            }
            cout<<"YES"<<endl;
        }
    }



    return 0;
}
