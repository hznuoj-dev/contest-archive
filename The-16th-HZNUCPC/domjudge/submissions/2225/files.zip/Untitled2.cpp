#include<bits/stdc++.h>
#define int long long
using namespace std;
int n, k;
signed main(){
	cin >> n >> k;
	int f = 0;
	while(1){
		if(k == 1){
			f = 1;
			break;
		}
		if(k == 0){
			f = 0;
			break;
		}
		k = n % k;
	}
	if(f)cout << "YES";
	else cout << "NO";
	return 0;
}