#include  <bits/stdc++.h>

using namespace std;
typedef long long LL;
const int mod = 1e9 + 7;
const int inf = 2e9;
vector<pair<LL, LL>> v(4);
map<int,int> mp;

void kizk(){
	int n; cin >> n;
    LL minl = inf, maxr = -inf, maxt = -inf, minb = inf;
    
    for(int i = 0; i < n; i ++)
    {
        LL x, y; cin >> x >> y;
        mp[x]=y;
        if(x < minl)
            v[0] = {x, y}, minl = x;
        if(x > maxr)
            v[1] = {x, y}, maxr = x;
        if(y < minb)
            v[2] = {x, y}, minb = y;
        if(y > maxt)
            v[3] = {x, y}, maxt = y;
    }
    set<pair<LL, LL>> s;
    for(auto& ite : v)
        s.insert(ite);
    if(s.size() > 3)
    {
        cout << 0 << "\n";
        return;
    }
    vector<pair<LL, LL>> res;
    for(auto& ite : s)
    {
        res.push_back({ite.first, ite.second});
    }
    LL r = 0;
    n = s.size();
    for(int i = 0; i < n; i ++)
        for(int j = i + 1; j < n; j ++)
            r = max(r, 1ll * abs(res[i].first  - res[j].first) + abs(res[i].second - res[j].second));
    cout << r << "\n";
    
}


int main(){
	std::ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int T; T = 1;
	// cin >> T;
	while(T --) kizk();
	return 0;
}