#include<cstdio>
#include<cstring>
#include<cmath>
#include<algorithm>
using namespace std;

int main()
{
    long long n,m;
    scanf("%lld%lld",&n,&m);
    if(n==1) printf("YES\n");
    else if(m>=n) printf("NO\n");
    else
    {
        long long z=1;
        for(z=1;(z+1)*(z+1)<=n;z++);
        z=min(m,z);
        int flag=1;
        for(int i=2;i<=z;i++)
        {
            if(n%i==0)
            {
                flag=0;
                break;
            }
        }
        if(flag) printf("YES\n");
        else printf("NO\n");
    }
    return 0;
}