#include<bits/stdc++.h>
#define int long long
#define hor(i,l,r) for(int i=l;i<=r;i++)
using namespace std;
template<typename T> void rd(T &x){
    int f=1;x=0;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c))x=x*10+c-48,c=getchar();x*=f;
}int x[114],y[114],n,ans;
bool check(int i,int j,int k){
	int a=x[j]-x[i],b=x[k]-x[j];
	int c=y[j]-y[i],d=y[k]-y[j];
	return (a*d==c*b);
}
int get(int i,int j){
	int nx=abs(x[i]-x[j]),ny=abs(y[i]-y[j]);
	return __gcd(abs(nx),abs(ny));
}signed main(){
	rd(n);
	hor(i,1,n) rd(x[i]),rd(y[i]);
	hor(i,1,n){
		hor(j,i+1,n){
			int now=get(i,j);
			hor(k,j+1,n){
				if(check(i,j,k)) continue;
			//	printf("%d %d %d %d %d %d\n",i,j,k,now,get(i,k),get(k,j));
				ans=max(ans,now+get(k,i)+get(k,j));
			}
		}
	}printf("%lld",ans);
    return 0;
}