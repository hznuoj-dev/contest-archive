#include <bits/stdc++.h>
using namespace std;
const int N=1000,M=N*2;
int e[M], ne[M], h[N], w[M], idx;
#define ll long long 
//#define int long long

ll qpow(ll a,ll b,ll p)
{
	ll sum=1;
	while(b)
	{
		if(b&1)
		sum*=a%p;
		b>>=1;
		a*=a%p;
	}
	return sum;
}

void add(int a,int b,int c){
	e[idx]=b;w[idx]=c;ne[idx]=h[a];h[a]=idx++;
}

int g[N][N];
bool st[N][N];
int dfs()
{
	int ans=0;
	int dx[4]={1,0,-1,0};
	int dy[4]={0,1,0,-1};
	for (int i=19;i>=1;i--)
	{
		for (int j=1;j<=19;j++)
		{
			if(g[i][j]==1 && !st[i][j])
			{
//				st[i][j]=true;
				for (int k=0;k<4;k++)
				{
					int x=i+dx[k],y=j+dy[k];
					if(x<1 || y<1 || x>19 || y>19) continue;
					if(g[x][y]==0 && !st[x][y])
					{
						ans++;
					}
				}
			}
		}
	}
	return ans;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	
	int t;
	cin >> t;
	while(t--)
	{
		
		int n;
		cin >> n;
		memset(st,0,sizeof st);
		memset(g,0,sizeof g);
		while(n--)
		{
		int a,b,c;
		cin >> a >> b >> c;
		g[20-a][b]=c;	
		}	
//		for (int i=1;i<=19;i++)
//		{
//			for (int j=1;j<=19;j++)
//			{
//				cout << g[i][j] << ' ';
//			}cout << endl;
//		}
		cout << dfs() << endl;
	}
	
	return 0;
}