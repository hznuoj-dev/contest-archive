n=int(input())
m=int(input())
chess=[[]for _ in range(m)]
for i in range(m):
    chess[i]=list(map(int,input().split()))
pan=[[0]*19 for i in range(19)]
def tan(x,y):
    if pan[x][y]==0:
        return True
    a=3-pan[x][y]
    if x!=0 :
        if pan[x-1][y]!=a:
            return True
    if x!=18 :
        if pan[x+1][y]!=a:
            return True
    if y!=0 :
        if pan[x][y-1]!=a:
            return True
    if y!=18 :
        if pan[x][y+1]!=a:
            return True
    return False

def kong(x,y):
    k=0
    if x!=0 :
        if  pan[x-1][y]==0:
            pan[x-1][y]=3
            k+=1
    if x!=18 :
        if pan[x+1][y]==0:
            pan[x+1][y]=3
            k+=1
    if y!=0 :
        if pan[x][y-1]==0:
            pan[x][y-1]=3
            k+=1
    if y!=18 :
        if  pan[x][y+1]==0:
            pan[x][y+1]=3
            k+=1
    return k

for i in range(len(chess)):
    x=chess[i][0]
    y=chess[i][1]
    pan[x][y]=chess[i][2]
    if x!=0 :
        if not(tan(x-1,y)):
            pan[x-1][y]=0
    if y!=0 :
        if not(tan(x,y-1)):
            pan[x][y-1]=0
    if y!=18 :
        if not(tan(x,y+1)):
            pan[x][y+1]=0
    if x!=18 :
        if not(tan(x+1,y)):
            pan[x+1][y]=0
max=0
for x in range(19):
    for y in range(19):
        if pan[x][y]==1:
            max+=kong(x,y)
print(pan)
print(max)
