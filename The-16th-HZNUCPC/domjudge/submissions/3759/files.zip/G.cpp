#include<bits/stdc++.h>
using namespace std;
vector<pair<int,bool>> e[100005];//0 good 1 bad
bool good[100005],vis[100005];
int scc[100005],cnt,num[100005],ff[100005],pp[100005],tot[100005];
bool wocaonima;
vector<int> a[100005],b[100005];
struct Node{
	int x,p;
}c[2000005];
void dfs(int x,int fa)
{
	if(vis[x]) return;
	vis[x]=1;
	scc[x]=cnt;
	for(auto& i:e[x]){
		if(i.first==fa) continue;
		bool p=!i.second;
		if(!good[x]) p=!p;
		if(vis[i.first]&&good[i.first]!=p){
			wocaonima=true;
		}
		good[i.first]=p;
		dfs(i.first,x);
	}
}
void solve()
{
	int n,q,m;
	cin>>n>>q>>m;
	for(int i=1;i<=m;i++){
		int op,u,v;
		cin>>op>>u>>v;
		e[u].push_back({v,op});
		e[v].push_back({u,op});
	}
	for(int i=1;i<=n;i++){
		if(vis[i]) continue;
		good[i]=true;
		cnt++;
		dfs(i,0);
	}
	vector<pair<int,int>> siz(cnt+1);
	for(int i=1;i<=n;i++){
		if(good[i]) siz[scc[i]].first++;//0
		else siz[scc[i]].second++;//1
	}
//	cout<<"-------------------------\n";
//	for (int i=1; i<=n; i++) cout<<i<<" "<<good[i]<<" "<<scc[i]<<"\n";
	if(wocaonima){
		cout<<"NO\n";
		return;
	}
	vector<int> dis(cnt+1,0);
	memset(num,0,sizeof(num));
	memset(tot,0,sizeof(tot));
	int sum=0;
	for(int i=1;i<=cnt;i++) dis[i]=abs(siz[i].first-siz[i].second),num[dis[i]]++,sum+=min(siz[i].first,siz[i].second);
	for(int i=1;i<=cnt;i++) if (dis[i]==0) tot[0]++;
	vector<int> dp(n+1,0);
	dp[sum]=1; int ll=0;
	for (int i=1; i<=100000; i++)
	 if (num[i]>0)
	  {
	  	int j=num[i],k=20;
	  	while (j>0&&k>=0)
	  	{
	  		if ((1<<k)<=j) c[++ll]=(Node){(1<<k)*i,i},j-=(1<<k);
	  		--k;
		}
	  }
	memset(ff,0,sizeof(ff));
	memset(pp,0,sizeof(pp));
	for (int i=1; i<=ll; i++)
	 for (int j=q; j>=sum; j--)
	  if (j+c[i].x<=q)
	   if (dp[j])
	    {
	    	dp[j+c[i].x]=1;
	    	ff[j+c[i].x]=j;
	    	pp[j+c[i].x]=i;
		}
	if(dp[q]==0){
		cout<<"NO\n";
		return;
	}
	int t=q;
	while (t>sum)
	{
		int x=pp[t];
		int p=c[x].x/c[x].p;
		tot[c[x].p]+=p;
		t=ff[t];
	}
	vector<int> ans;
	bool isuse[100005];
	for (int i=1; i<=cnt; i++)
	 if (tot[dis[i]]>0)
	  {
	  	tot[dis[i]]--;
	  	isuse[i]=true;
	  }
	for(int i=1;i<=n;i++){
		if(good[i]){
			if(siz[scc[i]].first>=siz[scc[i]].second&&isuse[scc[i]]) ans.push_back(i);
			if(siz[scc[i]].first<=siz[scc[i]].second&&!isuse[scc[i]]) ans.push_back(i);
		}
		else
		{
			if(siz[scc[i]].first>siz[scc[i]].second&&!isuse[scc[i]]) ans.push_back(i);
			if(siz[scc[i]].first<siz[scc[i]].second&&isuse[scc[i]]) ans.push_back(i);
		}
	}
	sort(ans.begin(),ans.end());
	cout<<"YES\n";
	for(auto& i:ans){
		cout<<i<<" ";
	}
	cout<<"\n";
}
int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	solve();
	return 0;	
}