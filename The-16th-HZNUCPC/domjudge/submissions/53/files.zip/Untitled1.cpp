#include<bits/stdc++.h>

#define ll long long


using namespace std;


int main(){
	ll n,m;
	cin>>n>>m;
	if(n%m!=0)cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	
	
	return 0;
}