#include<bits/stdc++.h>
using namespace std;
bool p(string x) {
	int c=0,n=x.size();
	map<char,int> v;
	for(int i=0; i<n/2; i++) {
		if(x[i]!=x[n-i-1]) {
			c++;v[x[i]]++;v[x[n-i-1]]++;
		}
	}
	if(c==0||(c==2&&v.size()==2)) return true;
	if(n%2){
		if(c==1&&v[x[n/2]]==1) return true;
	}
	return false;
}
int main() {
	int t;
	cin>>t;
	while(t--) {
		string x;
		int f=0;
		cin>>x;
		int n=x.size();
		for(int len=n; len>1; len--) {
			for(int j=0; j<n-len+1; j++) {
				string y=x.substr(j,len);
				if(p(y)){
					cout<<len<<endl;f=1;break;
				}
			}
			if(f==1) break;
		}
		if(f==0) cout<<0<<endl;
	}
	return 0;
}
