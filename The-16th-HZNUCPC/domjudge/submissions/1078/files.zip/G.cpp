#include<iostream>

using namespace std;

int n, t, x, y, c, q, m;

int ide[100010];

int main () {
	cin >> n >> q >> m;
	int flag = 1;
	for (int i = 1; i <= m; i++) {
		cin >> c >> x >> y;
		if (ide[x] == 0 && ide[y] == 0) {
			ide[x] = 1;
			if (c == 0) ide[y] = 1;
			else ide[y] = 2;
		} else if (ide[x] != 0 && ide[y] == 0) {
			if (c == 0) {
				ide[y] = ide[x];
			} else {
				if (ide[x] == 1) ide[y] = 2;
				else ide[y] = 1;
			}
		} else if (ide[x] == 0 && ide[y] != 0) {
			if (c == 0) {
				ide[x] = ide[y];
			} else {
				if (ide[y] == 1) ide[x] = 2;
				else ide[x] = 1;
			}
		} else {
			if (c == 0) {
				if (ide[x] != ide[y]) flag = 0;
			} else {
				if (ide[x] == ide[y]) flag = 0;
			}
		}
	}
	if (flag == 0) cout << "NO\n";
	else {
		cout << "YES\n";
		for (int i = 1; i <= n; i++) {
			if (ide[i] == 1) {
				cout << i << ' ';
			}
		}
		cout << '\n';
	}
	return 0;
}