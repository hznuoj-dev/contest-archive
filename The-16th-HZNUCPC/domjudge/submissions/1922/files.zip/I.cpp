#include<bits/stdc++.h>
using namespace std;
int l,r,cnt,len,ans,dif,flag;
pair<char,char>difp;
char str[5005];
void solve() {
	scanf("%s",str+1);
	len=strlen(str+1);
	ans=0;
	for(int i=1;i<=len;i++)
	{
		cnt=1;
		dif=flag=0;
		l=r=i;
		while(l>=1&&r<=len)
		{
			if(str[l]!=str[r])
			{
				if(!dif)
				{
					dif++;
					difp=make_pair(str[l],str[r]);
					ans=max(ans,cnt-2);
					if(str[l]==str[i]||str[r]==str[i])
					{
						flag=1;
						ans=max(ans,cnt);
					}
				}
				else if(dif==1&&(make_pair(str[r],str[l])==difp||make_pair(str[l],str[r])==difp))
				dif++;
				else break;
			}
			l--;
			r++;
			if(dif==2||dif==0||dif==1&&flag)
			ans=max(ans,cnt);
			cnt+=2;
		}
	}
	for(int i=1;i<=len;i++)
	{
		cnt=2;
		dif=0;
		l=i;
		r=i+1;
		while(l>=1&&r<=len)
		{
			if(str[l]!=str[r])
			{
				if(!dif)
				{
					dif++;
					difp=make_pair(str[l],str[r]);
					ans=max(ans,cnt-2);
				}
				else if(dif==1&&(make_pair(str[r],str[l])==difp||make_pair(str[l],str[r])==difp))
				dif++;
				else break;
			}
			l--;
			r++;
			if(dif==2||dif==0)
			ans=max(ans,cnt);
			cnt+=2;
		}
	}
	if(ans==1)
	{
		printf("0\n");
		return;
	}
	printf("%d\n",ans);
	return;
}
signed main() {
	//ios::sync_with_stdio(false);
	int T;
	scanf("%d",&T);
	while(T--) {
		solve();
	}
	return 0;
}
/*
4
abccab
ihi
stfgfiut
palindrome
*/