#include <bits/stdc++.h>
#define ll long long

using namespace std;


int main(){
	ll n,m;
	cin>>n>>m;
	if(m==1){
		cout<<"Yes";
		return 0;
	}
	while(n>m){
		m=n%m;
		if (!m) {
		cout << "NO";
		return 0;
		}
		else if (m==1){
			cout << "YES";
			return 0;
		}
	}
	cout << "NO";
	return 0;
	
	
}