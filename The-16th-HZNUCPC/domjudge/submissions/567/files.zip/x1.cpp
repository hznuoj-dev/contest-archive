#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=300005;
LL mod=1e9+7;
int a[105],b[105];
LL cx(LL x1,LL y1,LL x2,LL y2){
	return x1*y2-x2*y1;
}
LL cal(LL x,LL y){
	x=abs(x),y=abs(y);
	return __gcd(x,y);
}
LL T, n, m;
int main(){
#ifndef ONLINE_JUDGE
	//freopen("in.txt","r",stdin);
#endif
	scanf("%lld %lld", &n, &m);
	if(n == 1 || m == 1) printf("YES\n");
	else {
		bool f = false;
		for (LL i = 1; i*i <= n; ++i) {
			if(n%i == 0) {
				if(2 <= i && i <= m) f = true;
				if(2 <= n/i && n/i <= m) f = true;
			}
		}
		if(f) printf("NO\n");
		else printf("YES\n");
	}
    return 0;
}