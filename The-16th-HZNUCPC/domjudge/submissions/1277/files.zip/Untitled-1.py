T = int(input())
for i in range(T):
    Bord=[[0 for i in range(21)] for i in range(21)]
    for i in range(21):
        Bord[0][i] = 1
        Bord[20][i] = 1
        Bord[i][0] = 1
        Bord[i][20] = 1
    black = []
    cnt = 0
    n = int(input())
    for i in range(n):
        temp=input().split()
        tempX=int(temp[0])
        tempY=int(temp[1])
        Bord[tempX][tempY] = int(temp[2])
        if int(temp[2]) == 1:
            black.append([tempX, tempY])
    for i in range(len(black)):
        if Bord[black[i][0]][black[i][1]-1]==0:
            cnt+=1
        if Bord[black[i][0]][black[i][1]+1]==0:
            cnt+=1
        if Bord[black[i][0]-1][black[i][1]]==0:
            cnt+=1
        if Bord[black[i][0]+1][black[i][1]]==0:
            cnt+=1
    print(cnt)
