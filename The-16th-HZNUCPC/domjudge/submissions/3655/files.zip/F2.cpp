#include <bits/stdc++.h>

#define ll long long

using namespace std;
ll n,m;//ncai,mxuan
int main(){
	cin>>n>>m;
	if(m==1 || n==1){
	cout<<"YES"<<endl;
	return 0;
	}
	if(n<=m|| __gcd(n,m)!=1) {
	cout<<"NO"<<endl;
	return 0;
	}
	int p=0;
	while(m!=0 || m!=1){
		if(__gcd(n,m)!=1) {
			p=1;
			break;
		}
		m=n%m;
	}
	if(p) cout<<"NO"<<endl;
	else if(m) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
	return 0;
}