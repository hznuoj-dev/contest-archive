#include<bits/stdc++.h>
using namespace std;
int main(){
	long long int n,m;
	bool flag=true;
	cin>>n>>m;
	while(m>1){
		if(n%m==1){
			break;
		}
		if(n%m==0){
			flag=false;
			break;
		}
		m=n%m;
	}
	if(flag){
		printf("YES");
	}
	else {
		printf("NO");
	}
	return 0;
}
