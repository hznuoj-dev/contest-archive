#include<bits/stdc++.h>
using namespace std;

#define int long long

const int N = 2e3 +10, inf = 1e17, mod = 1e9 +7;

long long n, m, k, x, y, ans;

int manacher(string s){
    string t = "&#";
    int mx = 0, id = 0;
    for(int i=0;i<s.size();i++){
        t += s[i];
        t += '#';
    }
    int ans = 0;
    vector<int> v(t.size(),0);
    //cout<<t<<'\n';
    for(int i=1;i<t.size();i++){

        v[i] = mx > i?min(v[id*2-i],mx-i):1;
        while(t[i+v[i]]==t[i-v[i]])v[i]++;

        ans=max(v[i]-1,ans);
        set<int>q;q.insert(t[i+v[i]]),q.insert(t[i-v[i]]);
        int cnt = v[i]+1;
        while(t[i+cnt]==t[i-cnt])cnt++;
        q.insert(t[i+cnt]),q.insert(t[i-cnt]);

        if(q.size()==2){
            cnt++;
            while(t[i+cnt]==t[i-cnt])cnt++;
            ans=max(cnt-1,ans);
            //cout<<i<<" "<<cnt<<'\n';
        }

        if(mx < i+v[i]){
            mx = i+v[i];
            id = i;
        }
    }
    return ans;

}
/*
4
abccab
ihi
stfgfiut
palindrome

*/
void run(){
    string s;
    cin>>s;
    ans=manacher(s);
    cout<<(ans==1?0:ans)<<'\n';
}

signed main(){
    ios_base::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);
    int T;
    for(cin>>T;T>0;T--)
    run();return 0;
}
