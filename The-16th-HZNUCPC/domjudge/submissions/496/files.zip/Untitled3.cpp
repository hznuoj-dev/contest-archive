#include <bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
typedef pair<int,int> pii;
const int N = 22;
ll qpow (ll a,ll b ,ll p) 
{
ll res=1; 
while(b)
{
	if(b& 1)
	{
		res=res*a%p;
	}
		a=a*a%p;
		b>>=1;
	
}
return res;
}
int mp[N][N], n;
void init(){
	memset(mp,0,sizeof mp);
}
int fx[4][2] = {{1,0},{0,1},{-1,0},{0,-1}};
signed main()
{
	Acode;
	int t;
	cin>>t;
	while(t--)
	{
		init();
		cin >> n;
		for(int i = 1,x,y,c;i <= n;i++){
			cin >> x >> y >> c;
			mp[x][y] = c;
		}
		int ans = 0;
		for(int i = 1;i <= 19;i++){
			for(int j = 1;j <= 19;j++)if(mp[i][j] == 1){
				for(int f = 0,x,y;f < 4;f++){
					x = i + fx[f][0];
					y = j + fx[f][1];
					if(x >= 1 && x <= 19 && y >= 1 && y <= 19 && mp[x][y] == 0)
						ans++;
				}
			}
		}
		cout << ans << '\n';
		
	}
	return 0;
}
