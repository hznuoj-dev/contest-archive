#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define me(a,b) memeset(a,b,sizeof a);
signed main() {
	string s,ss;
	cin>>s>>ss;
	int ans=0;
	int flag=0;
	if(s.find(ss)!=-1) {
		flag=1;
	}
	for(int i=0; i<s.size(); i++) {
		for(int j=i+1; j<ss.size(); j++) {
			string sss=s,ssss=ss;
			swap(sss[i],ssss[i]);
			swap(sss[j],ssss[j]);
//			cout<<sss<<" "<<ssss<<endl;
			if(sss.find(s)!=-1||sss.find(ss)!=-1) {
				ans++;
				ans%=1000000007;
			}if(ssss.find(s)!=-1||ssss.find(ss)!=-1) {
				ans++;
				ans%=1000000007;
			}
		}
	}
	if(ans==1){
		cout<<ans<<endl;
		return 0;
	}
	if(flag==0) {
		ans%=1000000007;
		cout<<ans<<endl;
	} else {
		ans%=1000000007;
		if(ans%2==1) ans++;
		cout<<ans/2<<endl;
	}
	return 0;
}