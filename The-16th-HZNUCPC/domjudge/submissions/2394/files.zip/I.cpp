#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
const int N=1e6+10;
ll ksm(ll a,ll b,ll mod)
{
	ll res=1;
	while(b)
	{
		if(b&1) res=res*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return res%mod;
}
string s;
ll ans=0;
int check(int x,int flag){
	ll l,r;
	if(flag)
		l=x-1,r=x+1;
	else
		l=x-1,r=x+2;
		
	while(l>=0&&r<s.size()&&s[l]==s[r]){
		l--,r++;
	}
	ll l1=l,r1=r;
	l--,r++;
	while(l>=0&&r<s.size()&&s[l]==s[r]){
		l--,r++;
	}
		
		if(s[l]==s[r1]&&s[r]==s[l1]){
			l--,r++;
			while(l>=0&&r<s.size()&&s[l]==s[r]){
				l--,r++;
			}
			ans=max(ans,r-l-1);
			//printf("%lld %lld %d %d\n",r,l,x,flag);
		}else{
			if(flag&&((s[x]==s[l1]||s[x]==s[r1])&&(l1>2&&r1<s.size()-3))){
				ans=max(ans,r-l-1);
				//printf("%lld %lld %d %d\n",r,l,x,flag);
			}else{
				ans=max(ans,r1-l1-1);
				//printf("%lld %lld %d %d\n",r1,l1,x,flag);
			}
		}

}
int main()
{
	IOS
	int t;
	cin>>t;
	while(t--){
		ans=0;
		cin>>s;
	//	for(int i=1;i<=5e3;i++) s=s+"a";
		s="}+-"+s;
		s=s+"*{$";
		int len=s.length();
		for(int i=3;i<len-3;i++){
			check(i,1);
		}
		for(int i=3;i<len-4;i++){
			if(s[i]==s[i+1]){
				check(i,0);
			}
		}
		if(ans==1)
		ans=0;
		cout<<ans<<"\n";
	}
}
