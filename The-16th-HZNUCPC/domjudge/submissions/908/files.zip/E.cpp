#include<bits/stdc++.h>
using namespace std;
#define int long long
int n;
int x[110], y[110];
int arr[100010];

int gcd(int a, int b) {
	if(b == 0) return a;
	else return gcd(b, a % b);
}

signed main() {
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> x[i] >> y[i];
	}
	int cnt = 0;
	int ans = 0;
	for(int i = 1; i <= n; i++) {
		for(int j = i + 1; j <= n; j++) {
			for(int k = j + 1; k <= n; k++){
				int temp1 = gcd(abs(y[j] - y[i]), abs(x[j]-x[i]));
				int temp2 = gcd(abs(y[j] - y[k]), abs(x[j]-x[k]));
				int temp3 = gcd(abs(y[i] - y[k]), abs(x[i]-x[k]));
				if((y[j] - y[i]) * (x[k] - x[i]) == (y[k] - y[i]) * (x[j] - x[i])) break;
				ans = max(ans, temp1 + temp2 + temp3);
			}
		}
	}
	cout << ans << '\n';
	return 0;
}

/*
4
0 0
1 1
2 4
4 2

*/