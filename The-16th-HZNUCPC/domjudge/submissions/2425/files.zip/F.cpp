#include<bits/stdc++.h>

using namespace std;

#define ios ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define ll long long

inline ll gcd(ll a, ll b)
{
	while(b^=a^=b^=a%=b);
	return a;
}
ll n, m;
int flag1, flag2;

void wa()
{
	if(n == 1 || m == 1) cout << "YES\n";
	else if(n <= m) cout << "NO\n";
	else
	{
		while(n % m >= 1)
		{
			m = n % m;
		}
		if(m == 1) cout << "YES\n";	
		else cout << "NO\n";
	}
	return ;
}

void vio()
{
	ll nn = n, mm = m;
	ll ans = gcd(nn, mm);
	if(ans == 1) cout << "YES\n";	
	else cout << "NO\n";
	return ;
}

int main()
{
	ios;
	cin >> n >> m;
//	vio();

	
	
	wa();
	
	return 0;
}

