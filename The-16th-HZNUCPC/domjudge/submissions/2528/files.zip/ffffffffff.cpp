#include<bits/stdc++.h>
using namespace std;

void solve(){
	unsigned long long n,m;
	cin>>n>>m;
////	long long k=m;
//	int flag=0;
	if(n<=m){
		cout<<"NO"<<'\n';
		return;
	}
	if(__gcd(n,m)!=1){
		cout<<"NO"<<'\n';
	}else{
		cout<<"YES"<<'\n';
	}
	return;
//	while(1){
//		if(m!=1&&m!=0){
//			unsigned long long kk=n/m;
//			m=n-kk*m;
////			m=n%m;
////			cout<<"NOW ren:"<<m<<endl;
//		}else{
//			if(m==1){
//				cout<<"YES"<<'\n';
//			}else{
//				cout<<"NO"<<'\n';
//			}
//			return;
//		}
//	}
////	return;
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
