#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const int N = 5e5 + 5;
int n, m, X;
struct que {
	int t, l, r, x, op, id, ans;
	bool operator < (const que &a)const {
		if(t == a.t) {
			if(op != a.op) return op < a.op;
			else return min(abs(X - l), abs(X - r)) < min(abs(X - l), abs(X - r));
		}
		else return (t > a.t);
	}
}a[N];
int hah[N], tot;
struct tree {
	int mn, tag;
}t[N << 2];
void pushup(int k) {
	t[k].mn = min(t[k << 1].mn, t[k << 1 | 1].mn);
}
void build(int k, int l, int r) {
	if(l == r) {
		t[k].mn = 114514;
		return;
	}
	int mid = l + r >> 1;
	build(k << 1, l, mid);
	build(k << 1 | 1, mid + 1, r);
	pushup(k);
}
void pushdown(int k, int l, int r) {
	int tag = t[k].tag; t[k].tag = 0;
	if(!tag || l == r) return;
	t[k << 1].mn = min(t[k << 1].mn, tag);
	t[k << 1 | 1].mn = min(t[k << 1 | 1].mn, tag);
	if(t[k << 1].tag != 0) t[k << 1].tag = min(t[k << 1].tag, tag);
	else t[k << 1].tag = tag;
	if(t[k << 1 | 1].tag != 0) t[k << 1 | 1].tag = min(t[k << 1 | 1].tag, tag);
	else t[k << 1 | 1].tag = tag;
}
void update(int k, int l, int r, int x, int y, int val) {
	pushdown(k, l, r);
	if(l == x && r == y) {
		t[k].mn = min(t[k].mn, val);
		t[k].tag = val;
		return;
	}
	int mid = l + r >> 1;
	if(y <= mid) update(k << 1, l, mid, x, y, val);
	else if(x > mid) update(k << 1 | 1, mid + 1, r, x, y, val);
	else {
		update(k << 1, l, mid, x, mid, val);
		update(k << 1 | 1, mid + 1, r, mid + 1, y, val);
	}
	pushup(k);
}
int query(int k, int l, int r, int x, int y) {
	if(l == x && r == y) return t[k].mn;
	pushdown(k, l, r);
	int mid = l + r >> 1;
	if(y <= mid) return query(k << 1, l, mid, x, y);
	else if(x > mid) return query(k << 1 | 1, mid + 1, r , x, y);
	else return min(query(k << 1, l, mid, x, mid), query(k << 1 | 1, mid + 1, r, mid + 1, y));
}
int cmp(que x, que y) {
	return x.id < y.id;
}
int main() {
	ios :: sync_with_stdio(false);
	cin >> n >> m >> X;
	hah[tot = 1] = X;
	for(int i = 1; i <= n; i++) {
		cin >> a[i].t >> a[i].l >> a[i].r;
		a[i].id = m + 1;
		a[i].op = 0;
		hah[++tot] = a[i].l;
		hah[++tot] = a[i].r;
	}
	int cnt = n;
	for(int i = 1; i <= m; i++) {
		++cnt;
		cin >> a[cnt].t >> a[cnt].x;
		a[cnt].op = 1;
		a[cnt].id = i;
		hah[++tot] = a[cnt].x;
	}
	sort(a + 1, a + 1 + cnt);
	sort(hah + 1, hah + 1 + tot);
	tot = unique(hah + 1, hah + 1 + tot) - hah - 1;

/*	cout << tot << "\n";
	for(int i = 1; i <= tot; i++)
		cout << hah[i] << " ";
	cout << "\n";*/
	
	X = lower_bound(hah + 1, hah + 1 + tot, X) - hah;
	for(int i = 1; i <= cnt; i++) {
	//	cout << a[i].op << " " << a[i].t << " " << a[i].l << " " << a[i].r << " " << a[i].x;
	//	cout << "\n";
		if(a[i].op) {
			a[i].x = lower_bound(hah + 1, hah + 1 + tot, a[i].x) - hah;
		}else {
			a[i].l = lower_bound(hah + 1, hah + 1 + tot, a[i].l) - hah;
			a[i].r = lower_bound(hah + 1, hah + 1 + tot, a[i].r) - hah;
		}
	}
	build(1, 1, tot);
	update(1, 1, tot, X, X, 0);
//	cout << query(1, 1, tot, 1, tot) << "\n";
	for(int i = 1; i <= cnt; i++) {
		if(a[i].op == 0) {
			int mn = query(1, 1, tot, a[i].l, a[i].r) + 1;
			update(1, 1, tot, a[i].l, a[i].r, mn);
		}else {
			a[i].ans = query(1, 1, tot, a[i].x, a[i].x);
		}
	}
	sort(a + 1, a + 1 + cnt, cmp);
	for(int i = 1; i <= m; i++) {
		if(a[i].ans > n) cout << "-1\n";
		else cout << a[i].ans << "\n";
	}
	return 0;
}
/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5
*/