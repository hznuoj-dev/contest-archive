#include<bits/stdc++.h>
typedef long long ll;
const ll N=5e3+7;
const ll mod =1e9+7;
const double eps=1e-6;
using namespace std;
vector<pair<int,int>> a;
void slove(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		int x,y;
		cin>>x>>y;
		a.push_back({x,y});
	}
	int maxn=0;
	for(int i=0;i<n-2;i++)
	{
		for(int j=i+1;j<n-1;j++)
		{
			for(int p=j+1;p<n;p++)
			{
			double a1=sqrt(1.0*abs(a[i].first-a[j].first)*abs(a[i].first-a[j].first)+abs(a[i].second-a[j].second)*abs(a[i].second-a[j].second));
				double b1=sqrt(1.0*abs(a[i].first-a[p].first)*abs(a[i].first-a[p].first)+abs(a[i].second-a[p].second)*abs(a[i].second-a[p].second));
				double c1=sqrt(1.0*abs(a[p].first-a[j].first)*abs(a[p].first-a[j].first)+abs(a[p].second-a[j].second)*abs(a[p].second-a[j].second));
				if(a1+b1>c1&&a1+c1>b1&&c1+b1>a1)
				{
					int p1=__gcd(abs(a[i].first-a[j].first),abs(a[i].second-a[j].second));
					int p2=__gcd(abs(a[i].first-a[p].first),abs(a[i].second-a[p].second));
					int p3=__gcd(abs(a[j].first-a[p].first),abs(a[j].second-a[p].second));
					maxn=max(maxn,p1+p2+p3);
				}
					
			}
		}
	}
	cout<<maxn<<"\n";
}
int main(){
	slove();
}
