#include<bits/stdc++.h>
#define LL long long
using namespace std;
const int maxn=100005,maxm=35,tt=1000000007;
char s1[maxn],s2[maxn];
int a[maxm],b[maxm];
int l1,l2,na,nb;
LL cnt[maxm][maxm],ans;
bool vis[maxm][maxm][maxm][maxm];
int main()
{
	scanf("%s%s",&s1,&s2);
	l1=strlen(s1);
	l2=strlen(s2);
	memset(a,0,sizeof(a));
	memset(b,0,sizeof(b));
	na=nb=0;
	for (int i=0; i<l1; i++)
	{
		if (a[s1[i]-'a']==0) na++;
		a[s1[i]-'a']++;
	}
	for (int i=0; i<l2; i++)
	{
		if (b[s2[i]-'a']==0) nb++;
		b[s2[i]-'a']++;
	}
	memset(cnt,0,sizeof(cnt));
	for (int i=0; i<l1; i++) cnt[s1[i]-'a'][s2[i]-'a']++;
	ans=0;
//	for (int i=0; i<=2; i++)
//	 for (int j=0; j<=2; j++)
//	  {
//	  	printf("%d %d %lld\n",i,j,cnt[i][j]);
//	  }
	memset(vis,0,sizeof(vis));
	for (int i=0; i<=25; i++)
	 for (int j=0; j<=25; j++)
	  for (int k=0; k<=25; k++)
	   for (int t=0; t<=25; t++)
	    if (!vis[i][j][k][t]&&!vis[k][t][i][j])
	    {
	    	vis[i][j][k][t]=1;
	    	if (cnt[i][j]==0||cnt[k][t]==0) continue;
	    	int x=0,y=0;
	    	a[i]--; a[j]++;
			a[k]--; a[t]++;
	    	b[j]--; b[i]++;
			b[t]--; b[k]++;
			for (int p=0; p<=25; p++)
			 if (a[p]>0) x++;
			for (int p=0; p<=25; p++)
			 if (b[p]>0) y++;
	    	if (x==y)
	    	{
	    		if (i==k&&j==t) ans=(ans+cnt[i][j]*(cnt[k][t]-1)/2)%tt;
	    		 else ans=(ans+cnt[i][j]*cnt[k][t])%tt;
			}
	    	a[i]++; a[k]++;
	    	b[j]++; b[t]++;
	    	b[i]--; b[k]--;
	    	a[j]--; a[t]--;
		}
	printf("%lld",ans%tt);
	return 0;
}