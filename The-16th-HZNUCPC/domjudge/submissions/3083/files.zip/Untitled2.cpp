#include<bits/stdc++.h>
using namespace std;

char a[100005];
char b[100005];
int ca[30];
int cb[30];
int cc[30];
int cd[30];
pair<int,int> bh[30][30][30][30];
const int mod=1e9+7;
map<pair<int,int>,int> mp;
/*
0 0 0
1 -1 0
2 0 1
5 0 -1
*/

long long qpow(long long a,long long b)
{
	long long ans=1;
	while(b>0)
	{
		if(b&1)
		{
			ans=ans*a%mod;
		}
		a=a*a%mod;
		b/=2;
	}
	return ans;
}


int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cin>>a+1;
	cin>>b+1;
	int len=strlen(a+1);

	for(int i=1; i<=len; i++)
	{
		ca[a[i]-'a']++;
		cb[b[i]-'a']++;
		mp[ {a[i]-'a',b[i]-'a'}]++;
	}
	int suma=0;
	int sumb=0;
	long long inv=qpow(2,mod-2);
//	cout<<inv<<"\n";
	for(int i=0; i<26; i++)
	{
		if(ca[i])
		{
			suma++;
		}
		if(cb[i])
		{
			sumb++;
		}
	}
	long long ans=0;
	for(int i=0; i<26; i++)
	{
		for(int j=0; j<26; j++)
		{
			for(int k=0; k<26; k++)
			{
				for(int p=0; p<26; p++)
				{
					cc[i]=ca[i];
					cc[j]=ca[j];
					cc[k]=ca[k];
					cc[p]=ca[p];
					cd[i]=cb[i];
					cd[j]=cb[j];
					cd[k]=cb[k];
					cd[p]=cb[p];
					cc[i]--;
					cc[k]--;
					cc[j]++;
					cc[p]++;
					cd[i]++;
					cd[k]++;
					cd[j]--;
					cd[p]--;
					bh[i][j][k][p]= {0,0};
					if(cc[i]==0&&ca[i]>0)
					{
						bh[i][j][k][p].first--;
					}
					if(cc[j]>0&&ca[j]==0)
					{
						bh[i][j][k][p].first++;
					}
					if(cc[k]==0&&ca[k]>0&&k!=i)
					{
						bh[i][j][k][p].first--;
					}
					if(cc[p]>0&&ca[p]==0&&p!=j)
					{
						bh[i][j][k][p].first++;
					}
					if(cd[i]>0&&cb[i]==0)
					{
						bh[i][j][k][p].second++;
					}
					if(cd[j]==0&&cb[j]>0)
					{
						bh[i][j][k][p].second--;
					}
					if(cd[k]>0&&cb[k]==0&&k!=i)
					{
						bh[i][j][k][p].second++;
					}
					if(cd[p]==0&&cb[p]>0&&p!=j)
					{
						bh[i][j][k][p].second--;
					}
					if(suma+bh[i][j][k][p].first==sumb+bh[i][j][k][p].second)
					{


						long long aa=mp[ {i,j}];
						long long bb=mp[ {k,p}];	
						if(aa==0||bb==0)
						{
							continue;
						}
						long long res=aa*bb%mod;
						res=inv*res%mod;
//						cout<<(char)(i+'a')<<" "<<(char)(j+'a')<<" "<<(char)(k+'a')<<" "<<(char)(p+'a')<<"\n";
						if(i==k&&j==p)
						{
							res=aa*(aa-1)/2;
							res%=mod;
						}
//						cout<<res<<"\n";
						ans=(ans+res)%mod;
					}
				}
			}
		}
	}
	cout<<ans<<"\n";






	return 0;
}