#include<bits/stdc++.h>
using namespace std;
const int mod=1000000007;
typedef long long ll;
ll qpow(ll a,ll b)
{
	ll ans=1;
	while(b)
	{
		if(b&1) ans=ans*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return ans;
}
ll f[100005],inv[100005];
ll c(ll x,ll y)
{
	if(x<y) return 0;
	else return  f[x]*qpow(f[y],mod-2)%mod*qpow(f[x-y],mod-2)%mod;
}
int main()
{
	string a,b;
	cin>>a>>b;
	int c1[30]={0},c2[30]={0};
	for(int i=0;i<a.size();i++)
	{
		c1[a[i]-'a']++;
		c2[b[i]-'a']++;
	}
    f[0]=1;
    for(int i=1;i<=100000;i++) f[i]=f[i-1]*i%mod;
    
	int k;
	long long ans=0;
	for(int j=0;j<26;j++)
	{
		k=c1[j]-c2[j];
		
		if(!(k==0||k==2||k==-2||k==-4||k==4) )continue;
		if(c1[j]==0&&c2[j]==0) continue;
		ll dd=0,bb=0,ss=0;
		
		
		for(int i=0;i<a.size();i++)
		{
			if(a[i]-'a'==j&&b[i]-'a'!=j) ss++;
			else if(a[i]-'a'!=j&&b[i]-'a'==j) dd++;
			else bb++;
		}
		if(k==0) ans=(ans+c(bb,2))%mod;
		else if(k==-4) ans=(ans+c(dd,2))%mod;
		else if(k==4) ans=(ans+c(ss,2))%mod;
		else if(k==-2) ans=(ans+c(dd,1)*c(bb,1)%mod)%mod;
		else ans=(ans+c(bb,1)*c(ss,1)%mod)%mod;
	}
	printf("%lld\n",ans);
	return 0;
}