#include <bits/stdc++.h>
#define int long long
#define endl '\n'
using namespace std;
typedef unsigned long long ull;
const int N=2e5+10;
const int mod=1e9+7;

string a,b;
int ca[34],cb[34];
int xx[27][27][27][27],cx[27][27];

void run()
{
	int ans=0,tmpa,tmpb,cca,ccb;
	
	cin >> a;
	cin >> b;
	for(auto it:a)
		ca[it-'a']++;
	for(auto it:b)
		cb[it-'a']++;
		
	for(int s1=0;s1<=25;s1++)
		for(int s2=0;s2<=25;s2++)
			for(int s3=s1;s3<=25;s3++)
				for(int s4=0;s4<=25;s4++)
				{
					ca[s1]--;ca[s3]--;ca[s2]++;ca[s4]++;
					cb[s1]++;cb[s3]++;cb[s2]--;cb[s4]--;
					if(ca[s1]<0 || ca[s3]<0 || cb[s2]<0 || cb[s4]<0)
						xx[s1][s2][s3][s4]=-100;
					else
					{
						tmpa=tmpb=0;
						for(int i=0;i<=25;i++)
						{
							if(ca[i]>0)
								tmpa++;
							if(cb[i]>0)
								tmpb++;
						}
						xx[s1][s2][s3][s4]=tmpa-tmpb;
					}
					
					ca[s1]++;ca[s3]++;ca[s2]--;ca[s4]--;
					cb[s1]--;cb[s3]--;cb[s2]++;cb[s4]++;
				}
				
	for(int i=0;i<a.size();i++)
		cx[a[i]-'a'][b[i]-'a']++;
		
	for(int s1=0;s1<=25;s1++)
		for(int s2=0;s2<=25;s2++)
			for(int s3=s1;s3<=25;s3++)
				for(int s4=0;s4<=25;s4++)
				{
					if(xx[s1][s2][s3][s4]!=0)
						continue;
					cca=cx[s1][s2];ccb=cx[s3][s4];
					if(s1==s3 && s2==s4)
						ans=(ans+(cca)*(cca-1)/2)%mod;
					else
						ans=(ans+cca*ccb)%mod;
				}
	cout << ans;
}

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

