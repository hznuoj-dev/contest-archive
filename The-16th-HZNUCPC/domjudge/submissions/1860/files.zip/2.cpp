#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll, ll> PII;
vector<array<ll,2>>s;
int main() {
    int n;
    scanf("%d",&n);
    ll a,b;
    for(int i=1;i<=n;i++){
        scanf("%lld%lld",&a,&b);
        s.push_back({a,b});
    }
    ll mx=-1;
    for(int i=0;i<s.size();i++)
        for(int j=i+1;j<s.size();j++)
            for(int k=j+1;k<s.size();k++){
                if((s[k][0]-s[i][0])*(s[j][1]-s[i][1])==(s[j][0]-s[i][0])*(s[k][1]-s[i][1])) continue;
                //cout<<i<<" "<<j<<" "<<k<<endl;
                ll x=abs(s[i][0]-s[j][0]);
                ll y=abs(s[i][1]-s[j][1]);
                ll gc=__gcd(x,y);
                ll num = gc;
                num++;
                //cout<<num<<endl;
                x=abs(s[i][0]-s[k][0]);
                y=abs(s[i][1]-s[k][1]);
                gc=__gcd(x,y);
                //cout<<gc<<" "<<x<<".."<<endl;
                num+=gc;
                num++;
                //cout<<num<<endl;
                x=abs(s[j][0]-s[k][0]);
                y=abs(s[j][1]-s[k][1]);
                gc=__gcd(x,y);
                num+=gc;
                num++;
                num-=3;
                //cout<<num<<endl;
                //cout<<"|||"<<endl;
                mx=max(mx,num);

            }
    printf("%lld\n",mx==-1?0:mx);
}
