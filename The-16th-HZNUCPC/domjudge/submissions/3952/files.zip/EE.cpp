#include<bits/stdc++.h>
using namespace std;
#define int long long

struct node{
	int x,y;
}s[105];

signed main(){
	int n;
	while(cin>>n){
		for(int i=0;i<n;i++){
			cin>>s[i].x>>s[i].y;
		}
		int ans=0;
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				for(int k=j+1;k<n;k++){
					
					int a=s[i].x-s[j].x;
					int b=s[i].y-s[j].y;
					int c=s[j].x-s[k].x;
					int d=s[j].y-s[k].y;	
					int e=s[k].x-s[i].x;
					int f=s[k].y-s[i].y;
					a=fabs(a);
					b=fabs(b);
					c=fabs(c);
					d=fabs(d);
					e=fabs(e);
					f=fabs(f);
					int num1=__gcd(a,b);
					int num2=__gcd(c,d);
					int num3=__gcd(e,f);
					int aa=a,bb=b;
					int cc=c,dd=d;
					int ee=e,ff=f;
					if(num1){
						aa/=num1;
						bb/=num1;
					}
					if(num2){
						cc/=num2;
						dd/=num2;
					}
					if(num3){
						ee/=num3;
						ff/=num3;
					}
					if(aa==cc&&cc==ee&&bb==dd&&dd==ff)continue;
//					if(num1==0&&num2==0&&num3==0)continue;
//					int ck=min(num1,min(num2,num3));
//					if(ck!=0&&((num1%ck==0)&&(num2%ck==0)&&(num3%ck==0)))continue;
					int sum1=0,sum2=0,sum3=0;
					if(a==0){
						sum1=b+1;
					}else if(b==0){
						sum1=a+1;
					}else{
						sum1=num1+1;
//						cout<<sum1<<endl;
					}
					if(c==0){
						sum2=d+1;
					}else if(d==0){
						sum2=c+1;
					}else{
						sum2=num2+1;
					}
					if(e==0){
						sum3=f+1;
					}else if(f==0){
						sum3=e+1;
					}else{
						sum3=num3+1;
					}
					int num=sum1+sum2+sum3-3;
					ans=max(ans,num);
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}