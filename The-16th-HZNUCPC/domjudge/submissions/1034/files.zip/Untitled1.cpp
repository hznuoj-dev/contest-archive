#include<bits/stdc++.h>
#define int long long
using namespace std;
const int A=1e5+5;
int n,m;
int dir[4][2]={1,0,0,1,-1,0,0,-1};
int arr[25][25];
int ck(int y,int x){
	int num=0;
	for(int i=0;i<4;i++){
		int ty=y+dir[i][0];
		int tx=x+dir[i][1];
//		cout<<ty<<" "<<tx<<endl;
		if(ty<=0||ty>20||tx<=0||tx>20)continue;
		if(arr[ty][tx]==1)continue;
		
		arr[ty][tx]=2;
		num++;
	}
	return num;
}
signed main(){
	int _;cin>>_;
	while(_--){
		memset(arr,-1,sizeof(arr));
		cin>>n;
		vector<pair<int,int>>v;
		while(n--){
			int a,b,c;
			cin>>a>>b>>c;
			arr[a][b]=c;
			if(c==1){
				v.push_back({a,b});
			}
		}
		int sum=0;
		for(auto k:v){
			int y=k.first;
			int x=k.second;
			sum+=ck(y,x);
		}
		cout<<sum<<endl;
	}
	return 0;
}