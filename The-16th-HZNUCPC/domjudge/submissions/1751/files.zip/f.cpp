#include <bits/stdc++.h>
typedef long long ll;
using namespace std;
int main()
{
    int n,m;
    cin>>n>>m;
    if(m==1 || n==1)cout<<"YES";
    else if(m>=n)cout<<"NO";
    else if (n%2==0) cout <<"NO";
    else cout<<"YES";
    return 0;
}
