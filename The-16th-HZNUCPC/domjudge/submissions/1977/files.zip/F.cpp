#include<bits/stdc++.h>
using namespace std;
long long n,m;
int  main()
{
	cin>>n>>m;
	if(m>=n)
	{
		cout<<"NO\n";return 0;
	}
	if(n==1||m==1||n==3)
	{
		cout<<"YES\n";return 0;
	}
	for(int i=2;i<=sqrt(n);i++)
	{
		if(n%i==0)
		{
			if(m>=i)
			{
				cout<<"NO\n";return 0;
			}
		}
	}
	cout<<"YES\n";
}