#include <bits/stdc++.h>
using namespace std;
int a[200][200];
int yz(int x, int y)
{
	int temp;
	if(x<y)
	{
		temp=x;
		x=y;
		y=temp;
	}
	if(y==0)
	return x;
	while(x%y!=0)
	{
		int c = x%y;
		x = y;
		y = c;
	}
	return y;
}
int main()
{
	int t;
	long long k1, k2, sum=0, ans=0;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{
		scanf("%d %d",&a[i][1],&a[i][2]);
	}
	int flag=0;
	for(int i=1;i<=t-2;i++)
	{
		for(int j=i+1;j<=t-1;j++)
		{
			for(int k=j+1;k<=t;k++)
			{
				double l1,l2,l3;
				l1=sqrt(pow(a[i][1]-a[j][1],2)+pow(a[i][2]-a[j][2],2));
				l2=sqrt(pow(a[i][1]-a[k][1],2)+pow(a[i][2]-a[k][2],2));
				l3=sqrt(pow(a[j][1]-a[k][1],2)+pow(a[j][2]-a[k][2],2));
				if(l1+l2>l3&&l1+l3>l2&&l2+l3>l1)
				{
					flag=1;
					sum=0;
					k1=abs(a[i][1]-a[j][1]);
					k2=abs(a[i][2]-a[j][2]);
					if(yz(k1,k2)==1)
						sum=sum+2;
					else
						sum=sum+yz(k1,k2)+1;
					k1=abs(a[i][1]-a[k][1]);
					k2=abs(a[i][2]-a[k][2]);
					if(yz(k1,k2)==1)
						sum=sum+2;
					else
						sum=sum+yz(k1,k2)+1;
					k1=abs(a[j][1]-a[k][1]);
					k2=abs(a[j][2]-a[k][2]);
					if(yz(k1,k2)==1)
						sum=sum+2;
					else
						sum=sum+yz(k1,k2)+1;
				}
				if(sum>ans)
				ans=sum;
			}
		}
	}
	if(flag==1)
	printf("%lld\n",ans-3);
	else
	printf("0\n");
	return 0;
}