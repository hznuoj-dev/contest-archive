#include <bits/stdc++.h>
using namespace std;
int main()
{
    long long T;
    cin >>T;
    while (T -- )
    {

        int a[20][20]={{0}};
        long long n;
        cin >> n;
        long long sum=0;
        while (n -- )
        {
            int x,y,c;
            cin >> x >> y >> c;
            if (c == 1)
            {

                a[x][y]=5;
                a[x-1][y]++;
                a[x+1][y]++;
                a[x][y-1]++;
                a[x][y+1]++;
            }
            else
            {
                a[x][y]=7;
            }
        }

        for (int i=1;i<=19;i++)
        {
            for (int j=1;j<=19;j++)
            {
                if (a[i][j] == 5 && a[i][j-1]<5 && a[i][j+1]<5 && a[i+1][j]<5 && a[i-1][j]<5) a[i][j]=0;
            }
        }
        for (int i=1;i<=19;i++)
        {
            for (int j=1;j<=19;j++)
            {
                if(a[i][j]>0 && a[i][j]<5) sum+=a[i][j];
            }
        }

        cout << sum <<endl;

    }
}
