m,n = map(int,input().split())
flag = 0
if n == 1:
    print('YES')
    
else:
    while(n):
        n=m%n
        if n==1:
            flag = 1
            print("YES")
            break
        if flag == 0:
            print("NO")