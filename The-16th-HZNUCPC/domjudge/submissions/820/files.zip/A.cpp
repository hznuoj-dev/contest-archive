#include<bits/stdc++.h>
#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
typedef long long LL;
using namespace std;
typedef pair<int,int> PII;
const int N=25;
int a[N][N];
void bfs(int x,int y){
    queue<PII> p;
    p.push({x,y});
    int dx[4]={0,0,1,-1};
    int dy[4]={1,-1,0,0};
    while(p.size()){
        PII t=p.front();
        p.pop();
        for(int i=0;i<4;i++){
            int ax=t.first+dx[i];
            int ay=t.second+dy[i];
            if(ax>=1 && ax<=20 && ay>=1 && ay<=20 && a[ax][ay]==0){
                        a[ax][ay]=11;
                }
            }
        }
    }
void Init(){
    LL res=0;
    memset(a,0,sizeof a);
    LL n;
    scanf("%lld",&n);
    while(n--){
         int x,y,c;
        scanf("%d%d%d",&x,&y,&c);
        a[x+1][y+1]=c;
    }
    for(int i=1;i<=20;i++)
    for(int j=1;j<=20;j++){
        if(a[i][j]==1){
            bfs(i,j);
        }
    }


    for(int i=1;i<=20;i++)
        for(int j=1;j<=20;j++){
            if(a[i][j]==11)res++;
        }

    printf("%lld\n",res);

}
int main(){
    LL t;
    scanf("%lld",&t);
    while(t--)Init();
}
