#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#include<map>
#include<unordered_map>
#include<cstring>
#include<cmath>
#include<set>
using namespace std;
const int N=1e5+7;
int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};
int n,x,y,c;
int a[20][20];
map<pair<int,int>,int> mp;
void solve()
{
	int ans=0;
	scanf("%d",&n);
	memset(a,0,sizeof(a));
	for(int i=1;i<=n;i++)
	{
		scanf("%d%d%d",&x,&y,&c);
		if(c==2)
		{
			ans-=a[x][y];
			a[x][y]=-1;
		}else{
			ans-=a[x][y];
			a[x][y]=-1;
			for(int i=0;i<4;i++)
			{
				if(a[x+dx[i]][y+dy[i]]!=-1 && x+dx[i]>=1 && x+dx[i]<=19 && y+dy[i]>=1 && y+dy[i]<=19)
				{
					a[x+dx[i]][y+dy[i]]++;
					ans++;
				}
			}
		}
		//cout<<ans<<endl;
	}
	mp.clear();
	printf("%d\n",ans);
	return ;
}

int main()
{
	int T;
	T=1;
	scanf("%d",&T);
	while(T--)
	{
		solve();
	}
	return 0;
}