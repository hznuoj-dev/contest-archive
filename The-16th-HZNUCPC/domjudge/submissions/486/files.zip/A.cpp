#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 25;
int n, a[N][N];
void solve() {
	cin >> n;
	vector<pair<int, int> > vec;
	for(int i = 1; i <= n; i++) {
		int x, y, col;
		cin >> x >> y >> col;
		a[x][y] = 1;
		if(col == 2) {
			
		}
		else {
			vec.push_back({x, y});
		}
	}
	ll ans = 0;
	for(auto it : vec) {
		int x = it.first, y = it.second;
		ans += 4 - a[x - 1][y] - a[x + 1][y] - a[x][y - 1] - a[x][y + 1];
	}
	cout << ans << "\n";
	for(int i = 1; i <= 19; i++) {
		for(int j = 1; j <= 19; j++) {
			a[i][j] = 0;
		}
	}
}
int main() {
	ios::sync_with_stdio(false);
	for(int i = 1; i <= 19; i++) a[0][i] = a[20][i] = a[i][0] = a[i][20] = 1;
	int T = 1;
	cin >> T;
	while(T--) {
		solve();
	}
	return 0;
}
//Fi30g7NOTTgu
/*
2
2
1 1 1
2 2 1
2
10 9 1
10 10 1
*/