#include <iostream>
#include <algorithm>
#include <stack>
#include <cmath>
#include <map>
#include <cstring> 
#define qcin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define endl '\n'
#define int long long
using namespace std;
const int N=1000;
int x[N],y[N];
int p[N][N];//point on line point 1 to point 2
int n;
int dx ,dy;
signed main(){
	
	cin>>n;
	for(int i=1;i<=n;i++)cin>>x[i]>>y[i];

	for(int i=1;i<=n-1;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			dy=abs(y[j]-y[i]);
			dx=abs(x[j]-x[i]);
			if(x[i]!=x[j]&&y[i]!=y[j])
			{
				
				int dx1=dx;
				for(int k=2;k<=sqrt(min(dx,dy))+1;k++){
					while(dx%k==0&&dy%k==0&&dx&&dy)dx/=k,dy/=k;
				}
				p[i][j]=dx1/dx-1;
				//cout<<i<<" "<<j<<" "<<p[i][j]<<" "<<dy<<" "<<dx<<endl;
			}
			else
			{
				p[i][j]=dy+dx-1;
			}
		}
	}
	//int ansi,ansj,ansk,
	
	int mp,ansp=-1;
	double k1,k2;
	for(int i=1;i<=n-2;i++)
	{
		for(int j=i+1;j<=n-1;j++)
		{
			for(int k=j+1;k<=n;k++)
			{	
				k1=1.0*(y[i]-y[j])/(x[i]-x[j]);
				k2=1.0*(y[j]-y[k])/(x[j]-x[k]);
				if(k1!=k2)
				{
					mp=p[i][j]+p[i][k]+p[j][k];
					if(mp>ansp) 
					{
						//ansi=i,ansj=j,ansk=k;
						ansp=mp;
					}
				}
				
			}
		}
	}
	cout<<ansp+3;

	return 0;
}