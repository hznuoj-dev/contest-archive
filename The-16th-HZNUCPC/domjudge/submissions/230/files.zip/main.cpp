#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define endl '\n'
#define int long long
const ll N=1005;
ll t,n,x,y,c;
bool is[21][21],vis[21][21];
signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>t;
    while(t--)
    {
        memset(is,0,sizeof is);
        memset(vis,0,sizeof vis);
        cin>>n;
        for(ll i=1;i<=n;++i)
        {
            cin>>x>>y>>c;
            is[x][y]=1;
            if(c==1)
            {
                vis[x+1][y]=vis[x-1][y]=vis[x][y+1]=vis[x][y-1]=1;
            }
        }
        ll ans=0;
        for(ll i=1;i<=19;++i)
        {
            for(ll j=1;j<=19;++j)
            {
                if(is[i][j]==0&&vis[i][j]==1)++ans;
            }
        }
        cout<<ans<<endl;
    }
    return 0;
}
