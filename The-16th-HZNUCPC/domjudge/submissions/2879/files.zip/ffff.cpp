#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m;
signed main(){
	while(cin>>n>>m){
		int f=0;
		int sum=n;
		while(m){
			if(m==1){
				f=1;
			}
			sum--;
			m=n%m;
			if(sum==0){
				break;
			}
		}
		if(f==1){
			cout<<"YES"<<endl;
		}
		else{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}