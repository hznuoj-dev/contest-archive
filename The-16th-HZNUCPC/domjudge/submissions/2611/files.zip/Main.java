import java.util.Scanner;


public class Main {    
	public static void main(String[] args) {
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			long n=in.nextLong();
			long m=in.nextLong();
			boolean t=false;
				while(true){
					if(m==1){
						t=true;
						break;
					}
					
					if(n%m==0){
						
						break;
					}
					m=n%m;
					
				}
				if(t==true){
					System.out.println("YES");
				}
				if(t==false){
					System.out.println("NO");
				}
		}
	}
}
