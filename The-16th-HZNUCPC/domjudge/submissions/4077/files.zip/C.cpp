#include<bits/stdc++.h>

using namespace std;
#define int long long

map<char,int> mpa, mpb;
set<char> sta, stb;
int cnt[26][26];
string a, b;
typedef pair<int,int> pii;
vector<pii> ve;

signed main(){
	ios::sync_with_stdio(0);
	
	
	cin >> a >> b;
	int len = a.size();
	
	for(int i = 0; i < len; i++){
		cnt[a[i] - 'a'][b[i] - 'a']++;
		mpa[a[i]] ++;
		mpb[b[i]] ++;
		sta.insert(a[i]);
		stb.insert(b[i]);
	}
	
	int dt = abs((int)sta.size() - (int)stb.size());
	if(dt > 4){
		cout << 0 << endl;
		return 0;
	}
	if(dt == 0){
		cout << (len)*(len-1)/2 << endl;
		return 0;
	}
	
	for(int i = 0; i < 26; i++){
		for(int j = 0; j < 26; j++){
			if(cnt[i][j]) ve.push_back({i,j});
		}
	}
	
	int tot = ve.size();
	int ans = 0;
	
	for(int i = 0; i < tot; i++){
		for(int j = i+1; j < tot; j++){
			int x, y, u, v;
			x = ve[i].first;
			y = ve[j].first;
			u = ve[i].second;
			v = ve[i].second;
			
			mpa[x + 'a']--;
			mpa[y + 'a']--;
			mpb[u + 'a']--;
			mpb[v + 'a']--;
			
			
			if(mpa[x + 'a'] == 0) sta.erase(x + 'a');
			if(mpa[y + 'a'] == 0) sta.erase(y + 'a');
			if(mpb[u + 'a'] == 0) stb.erase(u + 'a');
			if(mpb[v + 'a'] == 0) stb.erase(v + 'a');
			
			sta.insert(u + 'a');
			sta.insert(v + 'a');
			stb.insert(x + 'a');
			stb.insert(y + 'a');
			
//			mpa[u + 'a'] ++;
//			mpa[v + 'a'] ++;
//			mpb[x + 'a'] ++;
//			mpb[y + 'a'] ++;
			
			
			if((int)sta.size() == (int)stb.size()) ans += cnt[x][u]*cnt[y][v];
			
			cout << ans << endl;
					
//			mpa[u + 'a'] --;
//			mpa[v + 'a'] --;
//			mpb[x + 'a'] --;
//			mpb[y + 'a'] --;
			
			
			if(mpa[u + 'a'] == 0) sta.erase(u + 'a');
			if(mpa[v + 'a'] == 0) sta.erase(v + 'a');
			if(mpb[x + 'a'] == 0) stb.erase(x + 'a');
			if(mpb[y + 'a'] == 0) stb.erase(y + 'a');
			
			mpa[x + 'a'] ++;
			mpa[y + 'a'] ++;
			mpb[u + 'a'] ++;
			mpb[v + 'a'] ++;
			
			sta.insert(x + 'a');
			sta.insert(y + 'a');
			stb.insert(u + 'a');
			stb.insert(v + 'a');
		}
	}
	
	cout << ans << endl;
	
	return 0;
}





