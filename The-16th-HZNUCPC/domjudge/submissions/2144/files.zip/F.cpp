#include <bits/stdc++.h>

#define ll long long

using namespace std;

ll n,m;

int main(){
	cin>>n>>m;
	if(n==1 || m==1||abs(n-m)==1) cout<<"YES\n"; 
	else if(n<=m || n%m==0) cout<<"NO\n";
	else if(n&1) cout<<"YES\n";
	else cout<<"NO\n";
	return 0;
}