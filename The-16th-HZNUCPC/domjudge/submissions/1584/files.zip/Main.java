import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);

		long n = s.nextLong();
		long m = s.nextLong();
		long k = m;
		while (true)
		{
			k = n % k;
			if (k == 0 || k == 1)
				break;
		}
		if (k == 1)
			System.out.println("YES\r");
		else
			System.out.println("NO\r");

	}
}
