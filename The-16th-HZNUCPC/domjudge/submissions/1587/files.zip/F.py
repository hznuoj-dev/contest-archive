n,m=map(int,input().split())
while True:
	m=n%m
	if m==1:
		print("YES")
		break
	elif m==0:
		print("NO")
		break