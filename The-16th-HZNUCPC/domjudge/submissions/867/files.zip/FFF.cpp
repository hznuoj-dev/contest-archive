#include<stdio.h>
int main(){
	long long n,m;
	scanf("%lld%lld",&n,&m);
	if(n%2==1&&m%2==1||n%2==1&&m%2==0){
		printf("YES\n");
	}
		else
		{
				printf("NO\n");
		}
	
	return 0; 
}