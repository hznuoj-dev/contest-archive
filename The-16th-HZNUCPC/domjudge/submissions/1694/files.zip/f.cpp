    #include  <bits/stdc++.h>

    using namespace std;
    typedef long long LL;
    const int mod = 1e9 + 7;

    LL n, m;

    void kizk(){
        cin >> n >> m;
        if(n <= m)
        {
            cout << "NO\n";
            return;
        }
        if(n % m == 0)
        {
            cout << "NO\n";
            return;
        }
        LL k;
        for(k=m;k>1;k--)
        {
            if(n/k>n%k)
            {
                break;
            }
        }

        for(int i=2;i<=(int)sqrt(n);i++)
        {
            if(n%i==0) 
            {
                cout<<"NO\n";
                return;
            }

        }
        for(LL i = (int)sqrt(n)+1; i <= k; i ++)
        {
            if(n/i>(n-i)/(m-i)+((n-i)%(m-i) != 0 ? 1 : 0))
            {
                if(n%i==0)
                {
                    cout<<"NO\n";
                    return;
                }
            }
        }
        
        cout<<"YES\n";
    }


    int main(){
        std::ios::sync_with_stdio(false);
        cin.tie(nullptr);
        int T; T = 1;
        // cin >> T;
        while(T --) kizk();
        return 0;
    }