#include<bits/stdc++.h>
#define ft first
#define sd second
#define ll long long
#define pb push_back
#define pll pair<ll,ll>
#define rep(i,a,b) for(ll i=a;i<=b;++i)
using namespace std;
ll cnt1[30],cnt2[30];
ll sum[30][30];
const int p = 1e9+7;
ll qpow(ll x,ll y)
{
    ll res=1;
    while(y)
    {
        if(y&1)res=res*x%p;
        x=x*x%p;
        y>>=1;
    }
    return res;
}
ll inv(ll x)
{
    return qpow(x,p-2);
}
int main()
{
    ios::sync_with_stdio(0),cin.tie(0);
    int T=1;
    //cin>>T;
    while(T--)
    {
        string a,b;
        cin>>a>>b;
        ll n = a.size();
        for(int i=0;i<26;i++)
            for(int j=0;j<26;j++)
                cnt1[i]=cnt2[i]=0,sum[i][j]=0;;


        for(int i=0;i<a.size();i++)
            cnt1[a[i]-'a']++,cnt2[b[i]-'a']++,sum[a[i]-'a'][b[i]-'a']++;


        ll sz1=0,sz2=0;
        for(int i=0;i<26;i++)
        {
            if(cnt1[i])
                sz1++;
            if(cnt2[i])
                sz2++;
        }
        auto change=[&](ll x,ll y)
        {
            cnt1[x]--;
            if(cnt1[x]==0)
                sz1--;
            if(cnt1[y]==0)
                sz1++;
            cnt1[y]++;

            cnt2[y]--;
            if(cnt2[y]==0)
                sz2--;
            if(cnt2[x]==0)
                sz2++;
            cnt2[x]++;
        };
        ll ans=0;
        //for(int i=0;i<3;i++) {for(int j=0;j<3;j++){cout<<sum[i][j]<<" ";}cout<<endl;}
        //cout<<sz1<<" "<<sz2<<endl;
        for(int i=0;i<n;i++)
        {
            int t1=a[i]-'a',t2=b[i]-'a';
            change(t1,t2);

            sum[t1][t2]--;
            for(int j=0;j<26;j++)
            {
                for(int k=0;k<26;k++)
                {
                    if(sum[j][k])
                    {
                        change(j,k);
                        if(sz1==sz2)
                        {
                            ans = (ans + sum[j][k]) % p;
                        }
                        change(k,j);
                    }
                }
            }
            change(t2,t1);
            sum[t1][t2]++;
            //cout<<ans<<endl;
        }

        cout<<ans*inv(2)%p<<"\n";
    }
}
