#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int P=1e9+7;
void solve(){
	string s="#",tmp;
	cin>>tmp;
	for(int i=0;i<tmp.size();i++){
		s.push_back(tmp[i]);
		s.push_back('#');
	}
//	cout<<s<<'\n';
	int ans=0;
	for(int i=0;i<s.size();i++){
		vector<char> dif;
		if(s[i]!='#')dif.push_back(s[i]);
		int ok=1,res=0;
		for(int j=1;i-j>=0&&i+j<s.size();j++){
			if(s[i-j]!=s[i+j]){
				if(s[i]!='#'){
					dif.push_back(s[i-j]);
					dif.push_back(s[i+j]);
					if(dif.size()==3){
						if(dif[0]==dif[1]||dif[0]==dif[2])ok=1;
						else ok=0;
					}else if(dif.size()==5){
						if(dif[1]==dif[3]&&dif[2]==dif[4]||dif[2]==dif[3]&&dif[1]==dif[4])ok=1;
						else ok=0;
					}else{
						ok=0;
					}
				}else{
					dif.push_back(s[i-j]);
					dif.push_back(s[i+j]);
					if(dif.size()==2){
						ok=0;
					}else if(dif.size()==4){
//						for(auto x:dif)cout<<"["<<x<<"]";cout<<'\n';
						if(dif[0]==dif[2]&&dif[1]==dif[3]||dif[1]==dif[2]&&dif[0]==dif[3])ok=1;
						else ok=0;
					}else{
						ok=0;
					}
				}
			}
			if(ok){
				res=max(res,j);
//				cout<<"dbg: "<<i<<" "<<j<<'\n';
			}
		}
		ans=max(ans,res);
	}
	if(ans==1)ans=0;
	cout<<ans<<'\n';
}
int main(){
	ios::sync_with_stdio(0);
	int T=1;
	cin>>T;
	while(T--){
		solve();
	}
}
/*
4 2 4
1 1 3
1 2 4 
0 3 4
0 1 2

13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13

2 1 2
1 1 2
0 2 1
*/