#include <stdio.h>

int main(){
	long long  n,m;
	scanf("%lld%lld",&n,&m);
	int i=2;
	if(m==1){
		printf("YES");
		return 0;
	}
	if(n<=m){
		printf("NO");
		return 0;
	}
	for(;i*i<=n;i++){
		if(n%i==0){
		printf("No");
		return 0;
		}
	}
	printf("Yes");
	return 0;
}