#include<iostream>
using namespace std;
int main(){
	long long n,m;
	cin >> n >> m;
	string res;
	if(m==1) res="YES";
	else if(n>m){
		long long k=m,v=n;
		while(k!=1){
			long long dy=n%k;
			k=dy;
			if(k==0)break;
		}
		if(k==0) res="NO";
		else res="YES";
	}else res="NO";
	cout << res << endl;
			
}
	