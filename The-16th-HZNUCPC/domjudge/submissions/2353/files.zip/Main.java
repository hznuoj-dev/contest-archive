package zime;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext()){
			String str1=sc.next();
			String str2=sc.next();
			int len=str1.length();
			char ch1[]=str1.toCharArray();
			char ch2[]=str2.toCharArray();
			int ag=0;
			int zag=0;
			int start=0;
			int end=0;
			int sum=0;
			boolean de=true;
			for(int i=0;i<len;i++)
			{
				if(de==true)
				{
					if(ch1[i]==ch2[i])
					{
						ag++;
					}
					else
					{
						start=i;de=false;
					}
					
				}
				else
				{
					if(ch1[i]==ch2[i]&&zag==0)
					{
						end=i-1;zag++;
					}
					else if(ch1[i]==ch2[i]&&zag!=0)
					{
						zag++;
					}
					if(ch1[i]!=ch2[i])
					{
						//System.out.println(zag+"++++");
						sum=(sum+lj(zag))%1000000007;
						zag=0;
					}
				}
			}
			//System.out.print(sum+"----");
			if(ch1[len-1]!=ch2[len-1])
			{
				end=len-1;
			}
			if(start!=end)
			{
				sum=(sum+1)%1000000007;
			}
			if(de==true)
			{
				sum=(sum+lj(len))%1000000007;
			}
			else sum=(sum+lj(len-end+start))%1000000007;
			
			System.out.println(sum%1000000007);
	 }
  }

	private static int lj(int zag) {
		
		return (zag%1000000007)*((zag-1)%1000000007)/2;
	}

	
	
}
