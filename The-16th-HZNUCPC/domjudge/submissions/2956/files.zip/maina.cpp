#include <bits/stdc++.h>
#define N (int)1e5+10
#define dwan ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define int long long
typedef long long ll;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
ll mod = 1000000007;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
string str1,str2;
map<char,int>mp1,mp2;
int s1[N],s2[N];
int num[5];//-2,-1,0,1,2
void solve(){
	cin>>str1>>str2;
	for(int i=0;i<str1.length();i++){
		mp1[str1[i]]++;
		mp2[str2[i]]++;
	}
	int cha = mp2.size()-mp1.size();
//	cout<<mp1.size()<<" "<<mp2.size()<<endl;
//	cout<<cha<<endl;
	for(int i=0;i<str1.length();i++){
		char c_1=str1[i];
		char c_2=str2[i];
		if(c_1==c_2){
			s1[i]=0;
			s2[i]=0;
		}else{
			if(mp1[c_1]==1&&mp1[c_2]==0){
				s1[i]=0;
			}else if(mp1[c_1]>1&&mp1[c_2]==0){
				s1[i]=1;
			}else if(mp1[c_1]>1&&mp1[c_2]>0){
				s1[i]=0;
			}else if(mp1[c_1]==1&&mp1[c_2]>0){
				s1[i]=-1;
			}
			
			if(mp2[c_2]==1&&mp2[c_1]==0){
				s2[i]=0;
			}else if(mp2[c_2]>1&&mp2[c_1]==0){
				s2[i]++;
			}else if(mp2[c_2]>1&&mp2[c_1]>0){
				s2[i]=0;
			}else if(mp2[c_2]==1&&mp2[c_1]>0){
				s2[i]=-1;
			}
		}
		int gg = s1[i]-s2[i]+2;
		num[gg]++;
	}
	
	ll k = str1.length();
//	for(int i=0;i<k;i++){
//		cout<<s1[i]<<" ";
//	}
//	cout<<endl;
//	for(int i=0;i<k;i++){
//		cout<<s2[i]<<" ";
//	}
	ll ans=0;
	if(cha==0){
		ans = (num[0]*num[4]%mod + num[1]*num[3]%mod+num[2]*(num[2]-1)/2%mod)%mod ;
	}else if(cha==1){
		ans = (num[4]*num[1]%mod+num[3]*num[2]%mod)%mod;
	}else if(cha==2){
		ans = (num[3]*(num[3]-1)/2%mod+num[2]*num[4]%mod)%mod;
	}else if(cha==-1){
		ans = num[0]*num[3]%mod+num[1]*num[2]%mod;
	}else if(cha==-2){
		ans = num[1]*(num[1]-1)/2%mod+num[0]*num[2]%mod;
	}else if(cha==3){
		ans = num[3]*num[4]%mod;
	}else if(cha==-3){
		ans = num[0]*num[1]%mod;
	}else if(cha==4){
		ans = num[4]*(num[4]-1)/2%mod;
	}else if(cha==-4){
		ans = num[0]*(num[0]-1)/2%mod;
	}
	cout<<ans%mod<<endl;
}
signed main(int argc, char** argv) {
	dwan;
	int t = 1;
	//cin>>t;
	while(t--){
		solve();
	}
}