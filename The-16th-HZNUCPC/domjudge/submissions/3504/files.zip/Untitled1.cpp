#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll x[105], y[105];
bool vis[105][105];
struct node{
	int x, y;
};
vector<node> ve;
bool check(int a, int b, int c){
	if(x[a] == x[b] && x[a] == x[c]){
		return false;
	}
	if(y[a] == y[b] && y[a] == y[c]){
		return false;
	}
	if((y[a] - y[b]) * (x[a] - x[c]) == (y[a] - y[c]) * (x[a] - x[b])){
		return false;
	}
	return true;
}
int n;
bool bo(int a, int b){
	for(int i = 0; i < ve.size(); i++){
		int c = ve[i].x;
		int d = ve[i].y;
		if((y[a] - y[b]) * (x[c] - x[d]) == (y[c] - y[d]) * (x[a] - x[b])){
			return true;;
		}
	}
	return false;;
}
int main(){
	cin >> n;
	for(int i = 0; i < n; i++){
		cin >> x[i] >> y[i];
	}
	int sum = 0;
	for(int i = 0; i < n; i++){
		for(int j = i + 1; j < n; j ++){
			for(int l = j + 1; l < n; l++){
				if(check(i, j, l)){
					if(!bo(i, j)){
						sum++;
						ve.push_back({i, j});
					}
					if(!bo(l, j)){
						sum++;
						ve.push_back({l, j});
					}
					if(!bo(i, l)){
						sum++;
						ve.push_back({i, l});
					}
				}
			}
		}
	}
	cout << sum << endl;
	return 0;
}