#include<bits/stdc++.h>
#define int long long
using namespace std;
int a[105],b[105];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
    int n;cin>>n;
    for(int i=0;i<n;++i)cin>>a[i]>>b[i];
    int ans=0;
    for(int i=0;i<n;++i){
    	for(int j=0;j<n;++j){
    		if(i==j)continue;
    		for(int k=0;k<n;++k){
    			int sum=0;
    			if(i==k || j==k)continue;
    			sum+=__gcd(abs(a[i]-a[j]),abs(b[i]-b[j]));
    			sum+=__gcd(abs(a[i]-a[k]),abs(b[i]-b[k]));
    			sum+=__gcd(abs(a[j]-a[k]),abs(b[j]-b[k]));
    			ans=max(ans,sum);
			}
		}
	}
	cout<<ans;
	return 0;
}
