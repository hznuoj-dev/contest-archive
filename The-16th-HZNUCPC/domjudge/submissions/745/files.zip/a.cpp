#include<bits/stdc++.h>
using namespace std;
const int N = 1e5+5;
int k[500][500];
int n;

int main(){
	int T;
	cin>>T;
	while(T--){
		int sum=0;
		memset(k,0,sizeof(k));
		cin >> n;
		int a,b,c;
		for(int i=1;i<=n;i++){
			cin >> a >> b >> c;
			k[a][b]=c;
		}
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(k[i][j]==1){

				 	if(k[i-1][j]<=0)k[i-1][j]--;
					if(k[i+1][j]<=0)k[i+1][j]--;
					if(k[i][j-1]<=0)k[i][j-1]--;
					if(k[i][j+1]<=0)k[i][j+1]--;
				}
			}
		}
		for(int i=1;i<20;i++){
			for(int j=1;j<20;j++){
				if(k[i][j]<=0)sum-=k[i][j];
			}
		}
		cout <<sum <<endl;
	}            

    return 0;
}
