#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mode = 1e9 + 7;
const ll N = 1e6 + 7;
ll t, n, a[N],m;
string s1,s2;
bool s[10000000]
void solve(){
	
return;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
//    cin>>t;
//    while(t != 0){
//    	t--;
//    	solve();
//	}
	cin>>n>>m;
	if(n==1||m==1) cout<<"YES"<<endl;
	else if((n>=2*m-1)&&n%2==1) cout<<"YES"<<endl;
	else cout<<"NO"<<endl;
return 0;
}
                  