#include<bits/stdc++.h>
using namespace std;
string s;
int main() {
	ios::sync_with_stdio(false);
	int T;
	cin>>T;
	while(T--) {
		cin>>s;
		int ans = 0;
		int n = s.length();
		for(int i = 0; i < n; i++) {

			int a = i, b = i;
			while(a - 1 >= 0 && b + 1 < n && s[a - 1] == s[b + 1])
				a--, b++;
			if(b - a + 1 > 1)
				ans = max(ans, b - a + 1);

			a = b = i;
			int pos1l = -1, pos1r = -1;
			int pos2l = -1, pos2r = -1;
			int cnt = 2;
			while(a - 1 >= 0 && b + 1 < n) {
				if(s[a - 1] == s[b + 1])
					a--, b++;
				else {
					if(cnt <= 0) break;
					cnt--, a--, b++;
					if(cnt == 1)
						pos1l = a, pos1r = b;
					else pos2l = a, pos2r = b;
				}
			}

			if(cnt==0) {
				if(b - a + 1 > 1) {
					if(s[pos1l] == s[pos2l] && s[pos1r] == s[pos2r])
						ans = max(ans, b - a + 1);
					else if(s[pos1l] == s[pos2r] && s[pos2l] == s[pos1r])
						ans = max(ans, b - a + 1);
				}
			}

			if(i + 1 < n) {
				a = i, b = i + 1;
				if(s[a] == s[b]) {
					while(a - 1 >= 0 && b + 1 < n && s[a-1] == s[b+1])
						a--, b++;
					ans = max(ans,b-a+1);
				}

				a = i, b = i + 1, cnt = 2;
				
				if(s[a] != s[b]) {
					cnt--, pos1l = a, pos1r = b;
				}
				while(a - 1 >= 0 && b + 1 < n) {
					if(s[a - 1] == s[b + 1])
						a--, b++;
					else {
						if(cnt <= 0)break;
						cnt--, a--, b++;
						if(cnt == 1)
							pos1l = a, pos1r = b;
						else pos2l = a, pos2r = b;
					}
				}

				if(cnt==0) {
					if(s[pos1l] == s[pos2l] && s[pos1r] == s[pos2r])
						ans = max(ans, b - a + 1);
					else if(s[pos1l] == s[pos2r] && s[pos2l] == s[pos1r])
						ans = max(ans, b - a + 1);
				}
			}
		}
		cout<<ans<<"\n";
	}
	return 0;
}