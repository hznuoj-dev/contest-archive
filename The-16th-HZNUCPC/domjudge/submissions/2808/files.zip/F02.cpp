#include<bits/stdc++.h>

using std::min;
using std::pow;

typedef long long int ll;

ll n, m;

int main(){
	scanf("%lld%lld", &n, &m);
	if(1 == m){
		printf("YES\n");
		return 0;
	}
	if(m >= n){
		printf("NO\n");
		return 0;
	}
	
	ll i;
	ll iend = min(m, (ll)pow((ll)10, (ll)6));
	
	for(i = 2; i <= iend; i++){
		if(0 == n % i){
			printf("NO\n");
			return 0;
		}
	}
	
	printf("YES\n");
	
	return 0;
}
