n,m=map(int,input().split())
if m==1:
    print("YES")
elif n%2==0:
    print("NO")
else:
    min=n
    for i in range(3,n):
        if n%i==0:
            min=i
            break
    if min<=m:
        print("NO")
    else:
        print("YES")
