#include<bits/stdc++.h>
using namespace std;
#define int long long

int dp1[30][30];
int dp[30][30];
const int mod=1e9+7;
int qpow(int a,int b){
	int ans=1;
	int base=a;
	while(b){
		if(b%2) ans=ans*base%mod;
		base=base*base%mod;
		b=b/2;
	}
	return ans;
}
int sum1[27];
int sum2[27];
signed main(){
	string a,b;
	int res1=0,res2=0;
	cin>>a>>b;
	for(int i=0;i<a.length();i++){
		dp[a[i]-'a'][b[i]-'a']++;
		dp[a[i]-'a'][b[i]-'a']=dp[a[i]-'a'][b[i]-'a']%mod;
		dp1[a[i]-'a'][b[i]-'a']++;
		dp1[a[i]-'a'][b[i]-'a']=dp1[a[i]-'a'][b[i]-'a']%mod;
		sum1[a[i]-'a']++;
		if(sum1[a[i]-'a']==1)
		{
			res1++;
		}
		sum2[b[i]-'a']++;
		if(sum2[b[i]-'a']==1)
		{
			res2++;
		}
	}
	
	
	
	
	int sum=0,new1=res1,new2=res2;
	for(int i=0;i<26;i++){

		for(int j=0;j<26;j++){

			for(int i1=0;i1<26;i1++){
				
				for(int j1=0;j1<26;j1++){	
				    
					new1=res1;
					new2=res2;
					//if(i==i1&&j==j1) continue; 
					if(dp[i][j]&&dp1[i1][j1]){
						
						sum1[i]--;
						sum1[j]++;
						if(sum1[i]==0) new1--;
						if(sum1[j]==1) new1++;
						sum2[i]++;
						sum2[j]--;
						if(sum2[i]==1) new2++;
						if(sum2[j]==0) new2--;
						
						sum1[i1]--;
						sum1[j1]++;
						if(sum1[i1]==0) new1--;
						if(sum1[j1]==1) new1++;
						sum2[i1]++;
						sum2[j1]--;
						if(sum2[i1]==1) new2++;
						if(sum2[j1]==0) new2--;
						
						if(new2==new1){
							//printf("*** %lld %lld \n",dp[i][j],dp[i1][j1]);
							if(i==i1&&j==j1) sum=(sum+dp[i][j]*(dp1[i1][j1]-1)%mod*qpow(2,mod-2)%mod)%mod;
							else sum=(sum+dp[i][j]*dp1[i1][j1]%mod*qpow(2,mod-2)%mod)%mod;
						}
						
						sum1[i]++;
						sum1[j]--;
						sum2[i]--;
						sum2[j]++;
						
						sum1[i1]++;
						sum1[j1]--;
						sum2[i1]--;
						sum2[j1]++;
					}
					
							
	
				}
				
			}			//dp[i][j]=0;	
		}
		
	}
	printf("%lld\n",sum);
	
}