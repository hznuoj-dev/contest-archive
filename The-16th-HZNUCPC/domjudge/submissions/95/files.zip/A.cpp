#include<bits/stdc++.h>
using namespace std;
int n,p[105][105],f[105][105];
int main(){
	int T;
	scanf("%d",&T);
	while (T--){
		scanf("%d",&n);
		for (int i=1;i<=19;i++)
			for (int j=1;j<=19;j++) p[i][j]=0,f[i][j]=0;
		for (int i=1;i<=n;i++){
			int x,y,c;
			scanf("%d%d%d",&x,&y,&c);
			if (c==1){
				p[x+1][y]++;
				p[x-1][y]++;
				p[x][y+1]++;
				p[x][y-1]++;
			}
			f[x][y]=1;
		}
		long long ans=0;
		for (int i=1;i<=19;i++)
			for (int j=1;j<=19;j++)
				if (f[i][j]==0)ans+=p[i][j];
		printf("%lld\n",ans);
	}
}