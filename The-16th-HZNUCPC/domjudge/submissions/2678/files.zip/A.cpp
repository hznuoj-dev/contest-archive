#include "bits/stdc++.h"
using namespace std;
int board[25][25];
bool p[25][25];
int n;


int solve(int x,int y) {
	int sum=0;
	if (x >= 1 && x <= 19 && y>=1 && y<= 19) {
		if (board[x][y] != 1) {
			return 0;
		}

		if (x > 1) {
			if(board[x - 1][y] == 0) {
				sum += 1;
			}
		}
		if (x < 19) {
			if(board[x + 1][y] == 0) {
				sum += 1;
			}
		}
		if (y > 1) {
			if(board[x][y - 1] == 0) {
				sum += 1;
			}
		}
		if (y < 19) {
			if(board[x][y + 1] == 0) {
				sum += 1;
			}
		}
		return sum;
	}
}
int main() {
	int T;
	cin >> T;
	for(int i =1; i <= T; i ++) {
		
		memset(p,false,sizeof p);
		cin >> n;
		int x,y,c;
		for(int j = 1; j<=n; j++) {
			cin >> x >> y >> c;
			board[x][y] = c;
		}
		int sum=0;
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				sum+=solve(i,j);
			}
		}
		printf("%d\n",sum);
	}
}
