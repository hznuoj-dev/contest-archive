#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 2e5 + 5;
int n, a[N];
void solve() {
	ll a, b;
	cin >> a >> b;
	if(a <= b || a % b == 0) {
		cout << "NO\n";
	}
	else {
		cout << "YES\n";
	}
}
int main() {
	ios::sync_with_stdio(false);
	int T = 1;
	while(T--) {
		solve();
	}
	return 0;
}
//Fi30g7NOTTgu