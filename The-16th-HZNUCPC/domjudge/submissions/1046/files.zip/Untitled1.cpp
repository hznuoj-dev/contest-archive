#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
#define ll long long 
ll gcd(ll a, ll b)
{
	return b == 0 ? a : gcd(b, a % b);
}
ll ss(ll a1, ll a2, ll b1, ll b2)
{
	return gcd(abs(b2 - a2), abs(b1 - a1));
}
ll x[N], y[N];
int main()
{
	std::ios::sync_with_stdio(false); 
	cin.tie(0), cout.tie(0);
	/*long long n, m;
	cin >> n >> m;
	if (m == 1) 
	cout<<"YES"<<endl;
	else if(n<=m)
	cout<<"NO"<<endl;
	else{
		int fl=0;
		for(ll i=2;i<= n / i;i++)
		{
			if(n%i==0)
			{
				fl=1;
				if(i<=m)
				cout<<"NO"<<endl;
				else cout<<"YES"<<endl;
			}
		}
		if(fl==0)
		cout<<"YES"<<endl;
	}*/
	//cout << ss(3, 3, 2, 4) << endl;
	int n;
	cin >> n;
	ll ans = 0;
	for (int i = 1; i <= n; i ++ ) cin >> x[i] >> y[i];
	for (int i = 1; i <= n; i ++ )
	  for (int j = i + 1; j <= n; j ++ )
	    for (int k = j + 1; k <= n; k ++ )
	    {
	    	if (((x[j] - x[i]) * (y[k] - y[i]) - (y[j] - y[i]) * (x[k] - x[i])) != 0)
	    	ans = max(ans, ss(x[i], y[i], x[j], y[j]) + ss(x[i], y[i], x[k], y[k]) + ss(x[j], y[j], x[k], y[k]));
	    	//cout << i << " " << j << " " << k << " "<< ans << endl;
		}
	cout << ans << endl;
	return 0;
}