#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<ll,ll>pii;
const ll N=1e5+10,mod=1e9+7;
ll cs[N],ct[N],n;
char s[N],t[N];
map<ll,ll>mp;
ll C2(ll x) {
	return x*(x-1)/2;
}
ll adds(char x,char y) {
	ll res=0;
	cs[x]--;
	if(!cs[x]) {
		res--;
	}
	cs[y]++;
	if(cs[y]==1) {
		res++;
	}
	cs[x]++,cs[y]--;
	return res;
}
ll addt(char x,char y) {
	ll res=0;
	ct[x]--;
	if(!ct[x]) {
		res--;
	}
	ct[y]++;
	if(ct[y]==1) {
		res++;
	}
	ct[x]++,ct[y]--;
	return res;
}
int main() {
	scanf("%s%s",s+1,t+1);
	set<char>ss,st;
	ll n=strlen(s+1);
	for(ll i=1; i<=n; i++) {
		ss.insert(s[i]);
		st.insert(t[i]);
		cs[s[i]]++;
		ct[t[i]]++;

	}
	for(ll i=1; i<=n; i++) {
		ll x=adds(s[i],t[i]);
		ll y=addt(t[i],s[i]);
		mp[x-y]++;
	}
	ll a=ss.size(),b=st.size();
	if(a==b) {
		printf("%lld\n",C2(mp[0])%mod);
	} else if(abs(a-b)==1) {
		if(a>b) {
			printf("%lld\n",mp[-1]*mp[0]%mod);
		} else {
			printf("%lld\n",mp[1]*mp[0]%mod);
		}
	} else if(abs(a-b)==2) {
		if(a>b) {
			printf("%lld\n",(mp[-2]*mp[0]+C2(mp[-1]))%mod);
		} else {
			printf("%lld\n",(mp[2]*mp[0]+C2(mp[1]))%mod);
		}
	} else if(abs(a-b)==3) {
		if(a>b) {
			printf("%lld\n",(mp[-2]*mp[-1])%mod);
		} else {
			printf("%lld\n",(mp[2]*mp[1])%mod);
		}
	} else if(abs(a-b)==4) {
		if(a>b) {
			printf("%lld\n",C2(mp[-2])%mod);
		} else {
			printf("%lld\n",C2(mp[2])%mod);
		}
	} else {
		puts("0");
	}
}