#include<bits/stdc++.h>
using namespace std;
using ll = long long;

using hashv = pair<int,int>;

mt19937 mrand(random_device{}());

int rnd(int x) {
	return mrand() % x;
}
const ll mod1 = 1e9+7;
const ll mod2 = 1e9+9;

const int maxn = 5e3;

hashv operator+(hashv a,hashv b) {
	int c1 = a.first + b.first,c2 = a.second + b.second;
	if(c1 >= mod1)
		c1 -= mod1;
	if(c2 >= mod2)
		c2 -= mod2;
	return make_pair(c1,c2);
}

hashv operator-(hashv a,hashv b) {
	int c1 = a.first - b.first,c2 = a.second - b.second;
	if(c1 < 0)
		c1 += mod1;
	if(c2 < 0)
		c2 += mod2;
	return make_pair(c1,c2);
}

hashv operator*(hashv a,hashv b) {
	return make_pair(1LL * a.first * b.first % mod1,1LL  * a.second * b.second % mod2);
}
int n;
string s;
hashv pw[maxn+10],base;
hashv h[maxn + 10];
hashv h2[maxn+ 10];

hashv geth1(int l,int r) {
	return h[r] - h[l - 1] * pw[r - l + 1];
}
hashv geth2(int l,int r) {
	return h2[l] - h2[r + 1] * pw[r - l + 1];
}

void solve() {
	cin >> s;
	n = s.length();
	s = " " + s + "*";
	h[0] = make_pair(0,0);
	h2[n + 1] = make_pair(0,0);
	for(int i = 1; i<=n; i++) {
		h[i] = h[i - 1] * base + hashv(s[i],s[i]);
	}
	
	for(int i = n; i>=1; i--) {
		h2[i] = h2[i + 1] * base + hashv(s[i],s[i]);
	}
	int ans = 0;
	for(int i = 1; i<=n; i++) {
		
		int l = 1,r = min(i - 1,n - i);
		int res = 0;
		while(l <= r) {
			int mid = (l +r ) / 2;
			if(geth1(i - mid,i - 1) == geth2(i + 1,i + mid)) {
				l = mid + 1;
				res = mid;
			} else
				r = mid - 1;
		}
		//cout << "res1 " << res<<"\n";
		ans = max(ans,res * 2 + 1);
		if(i - res - 1 >= 1 && i + res + 1 <= n){
			char x = s[i - res - 1];
			char y = s[i + res + 1];
			l = res + 2,r = min(i - 1,n - i);
			int res2 = res + 2;
			while(l <= r) {
				int mid = (l + r) / 2;
				if(geth1(i - mid,i - res - 2) != geth2(i + res + 2,i + mid)) {
					r = mid - 1;
					res2 = mid;
				} else
					l = mid + 1;
			}
			if(res2 <= min(i - 1,n - i) && s[i - res2] == y && s[i + res2] == x)
				ans = max(ans,(res2) * 2 + 1);
			if(res2 > 0 && ((s[i] == x) || (s[i] == y))){
				if((i - res2 == 1 || i + res2 == n) && s[i - res2] == s[i + res2])
					res2++;
				ans = max(ans,(res2 - 1) * 2 + 1);
			}
		}
		
		//2nd part
		if(i > 1) {
			l = 1,r = min(i - 1,n - i + 1);
			res = 0;
			while(l <= r) {
				int mid = (l + r) / 2;
				if(geth1(i - mid,i - 1) == geth2(i,i + mid - 1)) {
					l = mid + 1;
					res = mid;
				} else
					r = mid - 1;
			}
			//cout << "res1 " << res<<"\n";
			ans = max(ans,res * 2);
			
			if(i - res - 1 >= 1 && i + res <= n){
				char x = s[i - res - 1];
				char y = s[i + res];
				l = res + 2,r = min(i - 1,n - i + 1);
				int res2;
				res2 = res + 2;
				while(l <= r) {
					int mid = (l + r) / 2;
					if(geth1(i - mid,i - res - 2) != geth2(i + res + 1,i + mid - 1)) {
						r = mid - 1;
						res2 = mid;
					} else
						l = mid + 1;
				}
				if(res2 <= min(i - 1,n - i + 1) && s[i - res2] == y && x == s[i + res2 - 1])
					ans = max(ans,(res2) * 2);	
			}
			
		}
	}
	if(ans == 1)
		ans = 0;
	cout << ans <<"\n";
}

int main() {
	ios::sync_with_stdio(false);
	int t;
	base = hashv(rnd(mod1),rnd(mod2));
	pw[0] = make_pair(1,1);
	for(int i = 1; i<=maxn; i++) {
		pw[i] = pw[i - 1] * base;
	}
	cin >> t;
	while(t--) {
		solve();
	}
	return 0;
}


/*
4
abccab
ihi
stfgfiut
palindrom

*/