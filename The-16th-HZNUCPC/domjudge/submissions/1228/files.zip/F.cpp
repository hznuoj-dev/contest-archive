#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct node{
	ll x;
	ll y;
}a[110];
void solve(){
    ll n;
    cin>>n;
    ll ans=0;
    for(ll i=1;i<=n;i++){
    	cin>>a[i].x>>a[i].y;
	}
    for(ll i=1;i<=n;i++){
    	for(ll j=i+1;j<=n;j++){
    		for(ll k=j+1;k<=n;k++){
    			ll x=(a[k].y-a[j].y)*(a[k].x-a[i].x)-(a[k].y-a[i].y)*(a[k].x-a[j].x);
    			ll y=(a[j].y-a[k].y)*(a[j].x-a[i].x)-(a[j].y-a[i].y)*(a[j].x-a[k].x);
    			ll z=(a[i].y-a[j].y)*(a[i].x-a[k].x)-(a[i].y-a[k].y)*(a[i].x-a[j].x);
    			if(x==0||y==0||z==0)continue;
    			ll now=0;
    			x=a[k].y-a[i].y;y=a[k].x-a[i].x;
    			if(y==0){
    				now+=abs(x);
				}
				else if(x==0)now+=abs(y);
				else {
					now+=__gcd(abs(x),abs(y));
				}
				x=a[k].y-a[j].y;y=a[k].x-a[j].x;
    			if(y==0){
    				now+=abs(x);
				}
				else if(x==0)now+=abs(y);
				else {
					now+=__gcd(abs(x),abs(y));
				}
				x=a[i].y-a[j].y;y=a[i].x-a[j].x;
    			if(y==0){
    				now+=abs(x);
				}
				else if(x==0)now+=abs(y);
				else {
					now+=__gcd(abs(x),abs(y));
				}
    			ans=max(now,ans);
			}
		}
	}
	cout<<ans<<endl;
}



int main(){
    ios::sync_with_stdio(false);
    int T=1;
    //cin>>T;
    while(T--){
        solve();
    }
    return 0;
}
