#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int,int>
const int N = 100010 , mod = 1e9+7;
int w[N];
int shu[50];
string a,b;
map<char,int> ma,mb;

int biana(int i){
	if(ma[a[i]]>=2 && ma[b[i]] == 0){
		return (int)1;
	}else if(ma[a[i]] >= 2 && ma[b[i]] >= 1 || ma[a[i]] == 1 && ma[b[i]] == 0){
		return (int)0;
	}else if(ma[a[i]] == 1 && ma[b[i]] >= 1){
		return (int)-1;
	}
}

int bianb(int i){
	if(mb[b[i]]>=2 && mb[a[i]] == 0){
		return (int)1;
	}else if(mb[b[i]] >= 2 && mb[a[i]] >= 1 || mb[b[i]] == 1 && mb[a[i]] == 0){
		return (int)0;
	}else if(mb[b[i]] == 1 && mb[a[i]] >= 1){
		return (int)-1;
	}
}

signed main(){
	cin >> a >> b;
	int n = a.size();
	int cnta = 0, cntb = 0;
	for(int i=0;i<n;i++){
		if(ma[a[i]] == 0){
			cnta ++;
		}
		ma[a[i]] ++;
		if(mb[b[i]] == 0){
			cntb ++;
		}
		mb[b[i]] ++;
	}
	if(abs(cntb - cnta) >= 5){
		cout << 0;
		return 0;
	}
	if(cntb > cnta){
		string zhuan = a;
		a = b;
		b = zhuan;
	}

	for(int i=0;i<n;i++){
		if(biana(i) == 0 && bianb(i) == 0){   
			w[i] = 1;
			shu[1] ++;
		}else if(biana(i) == 1 && bianb(i) == -1){
			w[i] = 2;
			shu[2] ++;
		}else if(biana(i) == -1 && bianb(i) == 1){
			w[i] = 3;
			shu[3] ++;
		}else if(biana(i) == 1 && bianb(i) == 0){
			w[i] = 4;
			shu[4] ++;
		}else if(biana(i) == 0 && bianb(i) == 1){
			w[i] = 5;
			shu[5] ++;
		}else if(biana(i) == -1 && bianb(i) == 0){
			w[i] = 6;
			shu[6] ++;
		}else if(biana(i) == 0 && bianb(i) == -1){
			w[i] = 7;
			shu[7] ++;
		}else if(biana(i) == 1 && bianb(i) == 1){
			w[i] = 8;
			shu[8] ++;
		}else if(biana(i) == -1 && bianb(i) == -1){
			w[i] = 9;
			shu[9] ++;
		}
	}
	int ans = 0;
	if(abs(cnta - cntb) == 4){
		for(int i=0;i<n;i++){
			if(ma[a[i]] == 2 || mb[i] == 2){
				if(w[i] == 3){
					shu[3] --;
				}
			}
		}
		ans = shu[3] % mod * (shu[3]-1) % mod / 2;
	}else if(abs(cnta - cntb) == 3){
		ans = shu[3] % mod * (shu[5] + shu[6]) % mod;
	}else if(abs(cnta - cntb) == 2){
		for(int i=0;i<n;i++){
			if(ma[a[i]] == 2 || mb[i] == 2){
				if(w[i] == 5){
					shu[5] --;
				}
				if(w[i] == 6){
					shu[6] --;
				}
			}
		}
		ans = (shu[3] % mod *(shu[1] + shu[8] + shu[9]) % mod + shu[5] % mod * shu[6] % mod + shu[5] % mod * (shu[5]-1) % mod / 2 + shu[6] % mod * (shu[6]-1) % mod / 2) % mod;
	}else if(abs(cnta - cntb) == 1){
		ans = ((shu[5] + shu[6]) % mod * (shu[1] + shu[8] + shu[9]) % mod + shu[3] % mod * (shu[4] + shu[7]) % mod) % mod;
	}else if(abs(cnta - cntb) == 0){
		for(int i=0;i<n;i++){
			if(ma[a[i]] == 2 || mb[i] == 2){
				if(w[i] == 1){
					shu[1] --;
				}
				if(w[i] == 8){
					shu[8] --;
				}
			}
		}
		ans = ((shu[1]+shu[8]+shu[9]) % mod * (shu[1]+shu[8]+shu[9]-1) % mod / 2 + shu[2] % mod * shu[3] %mod + (shu[4]+shu[7]) % mod * (shu[5]+shu[6]) % mod) % mod;
	}
	// taolun 2
	cout << ans;
	return 0;
}





