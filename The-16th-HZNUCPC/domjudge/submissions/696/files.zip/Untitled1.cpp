#include <bits/stdc++.h>
using namespace std;
int X[105],Y[105];
int gcd(int a,int b){
	return (a%b)?gcd(b,a%b):b;
}
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d %d",&X[i],&Y[i]);
	}
	long long ans=0;
	for(int i=1;i<=n;i++)
		for(int j=i+1;j<=n;j++)
			for(int k=j+1;k<=n;k++){
				int tx=X[i]-X[j];
				int ty=Y[i]-Y[j];
				int sx=X[k]-X[j];
				int sy=Y[k]-Y[j];
				if(1ll*tx*sy!=1ll*sx*ty){
					int t1=abs(X[i]-X[j]);
					if(X[i]!=X[j]&&Y[i]!=Y[j])t1=gcd(t1,abs(Y[i]-Y[j]));
					else if(X[i]==X[j])t1=abs(Y[i]-Y[j]);
					int t2=abs(X[j]-X[k]);
					if(X[j]!=X[k]&&Y[j]!=Y[k])t2=gcd(t2,abs(Y[j]-Y[k]));
					else if(X[j]==X[k])t2=abs(Y[j]-Y[k]);
					int t3=abs(X[k]-X[i]);
					if(X[i]!=X[k]&&Y[i]!=Y[k])t3=gcd(t3,abs(Y[k]-Y[i]));
					else if(X[k]-Y[i])t3=abs(Y[k]-Y[i]);
//					printf("%d %d %d\n",t1,t2,t3);
					long long x=0;
					x+=t1;
					x+=t2;
					x+=t3;
					ans=max(ans,x);
				}
			}
	printf("%lld",ans);
	return 0;
}