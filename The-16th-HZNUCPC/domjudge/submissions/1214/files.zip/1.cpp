#include<iostream>
#include<cstring>
using namespace std;
int mp[20][20];

int main(){
	int T;
	scanf("%d",&T);
	memset(mp,0,sizeof(mp));
	while(T--){
		int n,x,y,c;
		int a=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%d%d%d",&x,&y,&c);
			mp[x][y]=c;
		}
		for(int i = 1;i<=19;i++){
			for(int j = 1;j<=19;j++){
				if(mp[i][j] == 1){
					if(i-1>=1&&mp[i-1][j]==0) a++;
					if(i+1<=19&&mp[i+1][j]==0) a++;
					if(j-1>=1&&mp[i][j-1]==0) a++;
					if(j+1<=19&&mp[i][j+1]==0) a++;
			}
		}
	}
	printf("%d\n",a);
}
return 0;
}