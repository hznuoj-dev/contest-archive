#include<iostream>
using namespace std;

long long n,m;
int main(){
    cin>>n>>m;
	if (n == 1){
		cout<<"YES";
		return 0;
	}
    else if (n<=m){
        cout<<"NO";
        return 0;
    }
    else{
    	while(m){
        if (m == 1){
            cout<<"YES";
            return 0;
            
        }
        m = n%m;
    }
    cout<<"NO";

    }
    	
	}

