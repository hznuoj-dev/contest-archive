#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll min(ll x, ll y){
	if(x < y) return x;
	return y;
}
bool is_prime(ll x,ll m){
	ll len = min(sqrt(x), m);
//	cout << len << endl;
	for (int i=2;i <= len;i++){
		if (x%i==0){
			return false;
		}
	}
	return true;
}
//bool check(ll n,ll m){		//n vote
//	if(m == 1 ) return true;
//	ll ans = n % m;
//	if(ans == 0) return false;
//	return check(n, ans); 
//}



int main(){
	ll  n,m;
	while(cin>>n>>m){
		if(is_prime(n, m) && n > m){
			cout << "YES" << endl;
		}else{
			cout << "NO" << endl;
		}
		
	}
	return 0;
}
