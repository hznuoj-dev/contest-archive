#include<bits/stdc++.h>
using namespace std;
int isSu(long long x){
	if(x==1 ||x==0)return 0;
	for(int i=2;i<=sqrt(x);i++){
		if(x%i==0)return 0;
	}	
	return 1;
}
int main(){
	long long n,m,k,t;
	while(cin>>n>>m){
		if(n==1 || m==1){
			cout <<"YES"<<endl;
		}else{
			bool flag = true;
			if(n<m) flag =false;
			k=m;
			while(k>1){
				t = n%k;
				k = t%k;
			}
			if(k!=1)flag =false;
			
			
			
				if(flag){
					cout <<"YES"<<endl;
				}else{
					cout <<"NO"<<endl;
				}
			
			
			
			
		
		}
		
	}
	
	return 0;
}