#include<bits/stdc++.h>
using namespace std;
using ll =long long ;
const int N=300005;
int n,m,k;
int ans[N];
std::vector<std::pair<int,int>>vec[N][2];
const int inf=1e9;
int c[N<<2],lazy[N<<2];
inline void pushup(int k)
{
	c[k]=min(c[k<<1],c[k<<1|1]);
}
inline void pushdown(int k)
{
	if(lazy[k]!=inf)
	{
		lazy[k<<1]=min(lazy[k<<1],lazy[k]);
		lazy[k<<1|1]=min(lazy[k<<1|1],lazy[k]);
		c[k<<1]=min(c[k<<1],lazy[k]);
		c[k<<1|1]=min(c[k<<1|1],lazy[k]);
		lazy[k]=inf;
	}
}
void update(int L,int R,int l,int r,int k,int v)
{
	if(L<=l&&r<=R)
	{
		c[k]=min(c[k],v);
		lazy[k]=min(lazy[k],v);
		return;
	}
	pushdown(k);
	int m=(l+r)>>1;
	if(L<=m)update(L,R,l,m,k<<1,v);
	if(R>m)update(L,R,m+1,r,k<<1|1,v);
	pushup(k);
}
int query(int L,int R,int l,int r,int k)
{
	if(L<=l&&r<=R)return c[k];
	int m=(l+r)>>1;
	pushdown(k);
	int ans=inf;
	if(L<=m)ans=query(L,R,l,m,k<<1);
	if(R>m)ans=min(ans,query(L,R,m+1,r,k<<1|1));
	return ans;
}
int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(0);
	int T;
//	freopen("in.txt","r",stdin);
	int x;
	std::cin>>n>>m>>x;
	std::vector<int>all{x};
	for(int i=1; i<N<<2; i++)
		lazy[i]=inf,c[i]=inf;
	for(int i=1; i<=n; i++)
	{
		int t,l,r;
		std::cin>>t>>l>>r;
		vec[t][0].emplace_back(l,r);
		all.emplace_back(l);
		all.emplace_back(r);
	}
	for(int i=1; i<=n; i++)
	{
		int c,p;
		std::cin>>c>>p;
		vec[c][1].emplace_back(p,i);
		all.emplace_back(p);
	}
	
	sort(all.begin(),all.end());
	all.erase(unique(all.begin(),all.end()),all.end());
	
	auto get=[&](int l){
		return l=lower_bound(all.begin(),all.end(),l)-all.begin()+1;
	};
	
	x=get(x);
	
	int len=N-5;
	
	update(x,x,1,len,1,0);
	
	for(int t=1e5;t;t--)
	{
		for(auto [l,r]:vec[t][0])
		{
			l=get(l);
			r=get(r);
			int v=query(l,r,1,len,1);
			update(l,r,1,len,1,v+1);
		}
		
		for(auto [p,id]:vec[t][1])
		{
			p=get(p);
			ans[id]=query(p,p,1,len,1);
		}
		
	}
	for(int i=1;i<=m;i++)
		std::cout<<(ans[i]==inf?-1:ans[i])<<'\n';

	return 0;
}
