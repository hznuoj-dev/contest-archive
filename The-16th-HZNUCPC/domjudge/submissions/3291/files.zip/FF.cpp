#include "bits/stdc++.h"
using namespace std;

int main(){
	long long n,m;
	while(cin >> n >> m){
		if(n == 1 || m == 1){
			puts("YES");
			continue;
		}
		if(n % m == 0) puts("NO");
		else puts("YES");
	}
	return 0;
}
