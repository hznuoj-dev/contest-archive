#include<bits/stdc++.h>
using namespace std;
void solve()
{
	long long n,m;
	cin>>n>>m;
	if(n%m==0||(n<=m))
		cout<<"NO";
	else
		cout<<"YES";
}
signed main()
{
	solve();
	return 0;
}
