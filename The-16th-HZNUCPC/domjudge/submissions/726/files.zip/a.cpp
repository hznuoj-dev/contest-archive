#include<bits/stdc++.h>
#define int long long 
#define fs first
#define sc second
using namespace std;
const int N=1e5+5,M=1e6+5;
int n,m,T;
struct node{
	int x,y,op;
}a[405];
int c[25][25];
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
void work(){
	for (int i=1;i<=19;i++){
		for (int j=1;j<=19;j++){
			if (c[i][j]==1){
				for (int k=0;k<4;k++){
					int tx=i+dir[k][0],ty=j+dir[k][1];
					if (tx<1 || ty<1 || tx==20 || ty==20) continue;
					if (c[tx][ty]!=0) continue;
					c[tx][ty]=3;
				}
			}
		}
	}
}
void solve(){
	cin >> n;
	memset(c,0,sizeof c);
	int x,y,op;
	int ans=0;
	for (int i=0;i<n;i++){
		cin >> x >> y >> op;
		c[x][y]=op;
	}
	work();
	for (int i=1;i<=19;i++){
		for (int j=1;j<=19;j++){
			if (c[i][j]!=1) continue;
			for (int k=0;k<4;k++){
				int tx=i+dir[k][0],ty=j+dir[k][1];
				if (tx<1 || ty<1 || tx==20 || ty==20) continue;
				if (c[tx][ty]==3) ans++;
			}
		}
	}
	cout << ans << '\n';
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin >> T;
	while (T--){
		solve();
	}
	
	return 0;
}
/*
2
2
1 1 1
2 2 1
2
10 9 1
10 10 1


1
3
5 5 1
5 4 2
5 6 2

*/