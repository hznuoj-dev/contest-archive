#include <bits/stdc++.h>
using namespace std;
template<class T,class... A> void odn(T&& x, A&&... a) {cout<<x; (int[]){(cout<<' '<<a,0)...}; cout<<'\n';}
int mp[30][30];
void solve() {
    int n; cin>>n;
    memset(mp, 0, sizeof(mp));
    while (n--) {
        int x, y, c; cin>>x>>y>>c;
        mp[x][y] = c;
    }
    int ans = 0;
    for (int i = 1; i <= 19; i++)
        for (int j = 1; j <= 19; j++) if (!mp[i][j]){
            ans += mp[i-1][j] == 1;
            ans += mp[i+1][j] == 1;
            ans += mp[i][j-1] == 1;
            ans += mp[i][j+1] == 1;
            // mp[i+1][j] == 1 || mp[i][j-1] == 1 || mp[i][j+1] == 1;
            // if (mp[i-1][j] == 1 ||)
        }
    odn(ans);
}
signed main() {
    // freopen("i", "r", stdin);
    cin.tie(0)->sync_with_stdio(0);
    int T; cin>> T;
    while (T--)
        solve();
}