#include<bits/stdc++.h>
using namespace std;

int t,n;
int a[100][100];
int main()
{
	cin>>t;
	while(t--)
	{
		cin>>n;
		for(int i=0;i<=20;i++)
		{
			for(int j=0;j<=20;j++)a[i][j]=0;
		}
		while(n--)
		{
			int x,y,v;cin>>x>>y>>v;
			a[x][y]=v;
		}	
		for(int i=1;i<=19;i++)
		{
			a[i][0]=1;
			a[i][20]=1;
			a[0][i]=1;
			a[20][i]=1;	
		}
		int ans=0;
		for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				if(a[i][j]==1)
				{
					if(a[i-1][j]==0)ans++;
					if(a[i+1][j]==0)ans++;
					if(a[i][j-1]==0)ans++;
					if(a[i][j+1]==0)ans++;
				}
			}
		}
		cout<<ans<<"\n";
	}
	return 0;
}

