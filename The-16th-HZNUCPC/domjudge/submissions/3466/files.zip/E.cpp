#include <stdio.h>
int min(int a,int b){
	if (a > b) return b;
	else return a;
}
int max(int a,int b){
	if (a > b) return a;
	else return b;
}

int main(void){
	int n;
	scanf("%d",&n);
	int x[105]={0};
	int y[105]={0};
	int x1,y1,x2,y2;
	for (int i=0;i<n;i++){
		scanf("%d%d",&x[i],&y[i]);
	}
	int sum[105][105]={0};
	
	for (int i=0;i<n;i++){
		for (int j=i+1;j<n;j++){
			x1 = min(x[i],x[j]);
			x2 = max(x[i],x[j]);
			y1 = min(y[i],y[j]);
			y2 = max(y[i],y[j]);
			for(int t=x1;t<x2;t++){
				for(int k=y1;k<y2;k++){
					if (t==x1 && k==y1) continue;
					if ((t-x1)*(y2-y1) == (k-y1)*(y2-y1)){
						sum[i][j] += 1;
						sum[j][i] += 1;
					} 
				}
			}
		}
	}
	
	int max1=0;
	int sum1;
	
	for (int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if (i==j) continue;
			for(int k=0;k<n;k++){
				if(k==i ||k==j) continue;
				sum1 = sum[i][j]+sum[j][k]+sum[k][i]+3;
				if (sum1 > max1) max1 = sum1;
			}
		}
	}
	printf("%d",max1);
}
