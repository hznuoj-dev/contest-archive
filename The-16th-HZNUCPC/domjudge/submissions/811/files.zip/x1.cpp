#include<bits/stdc++.h>
#define int long long
#define maxn 110
using namespace std;
int x[maxn],y[maxn];
signed main(){
    int n;  cin >> n;
    long long maxx=0;
    for(int i=1;i<=n;++i)  cin >> x[i] >> y[i];
    for(int i=1;i<=n-2;++i){
    	for(int j=i+1;j<=n-1;++j){
    		for(int k=j+1;k<=n;++k){
    			int tx1,tx2,tx3,ty1,ty2,ty3;
    			tx1=abs(x[i]-x[j]);  tx2=abs(x[j]-x[k]);  tx3=abs(x[i]-x[k]);
    			ty1=abs(y[i]-y[j]);  ty2=abs(y[j]-y[k]);  ty3=abs(y[i]-y[k]);
    			int d1=__gcd(tx1,ty1),d2=__gcd(tx2,ty2),d3=__gcd(tx3,ty3);
    			d1=max(1ll*0,d1-1),d2=max(1ll*0,d2-1),d3=max(1ll*0,d3-1);
    			maxx=max(maxx,d1+d2+d3);
			}
		}
	}
	cout << maxx+3 << '\n';
    return 0;
}