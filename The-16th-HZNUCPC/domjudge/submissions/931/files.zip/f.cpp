#include<bits/stdc++.h>
#define int long long
#define fs first
#define sc second
using namespace std;
const int N=1e5+5,M=1e6+5;
int n,m,T;
int a[N];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin >> n >> m;
	if (m==1 || n==1){
		cout << "YES\n";
		return 0;
	}
	if (m>=n){
		cout << "NO\n";
		return 0;
	}
	if (n%2==0){
		cout << "NO\n";
	}
	else{
		if (n%m==0){
			cout << "NO\n";
		}
		else cout <<"YES\n";
	}
	return 0;
}
