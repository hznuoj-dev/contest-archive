#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll N=1e5+10,mod=1e9+7;
char s[N],t[N];


void solve(){
	ll n,m;cin>>n>>m;
	while(m!=1){
		if(n%m==0){
			cout<<"NO\n";
			return;
		}
		m=n%m;
	}
	cout<<"YES\n";
}
int main() {
	solve();
}