#include <bits/stdc++.h>
using namespace std;
typedef long long LL;
const int N=300005;
LL mod=1e9+7;
int a[105],b[105];
LL cx(LL x1,LL y1,LL x2,LL y2){
	return x1*y2-x2*y1;
}
LL cal(LL x,LL y){
	x=abs(x),y=abs(y);
	return __gcd(x,y);
}
int main(){
#ifndef ONLINE_JUDGE
	//freopen("in.txt","r",stdin);
#endif
//	int _;
//	scanf("%d",&_);
//	while(_--){
		int n;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%d%d",&a[i],&b[i]);
		}
		LL ans=0;
		for(int i=1;i<=n;i++){
			for(int j=i+1;j<=n;j++){
				for(int k=j+1;k<=n;k++){
					if(cx(a[j]-a[i],b[j]-b[i],a[k]-a[i],b[k]-b[i])==0)continue;
					LL cnt=cal(a[j]-a[i],b[j]-b[i])+cal(a[k]-a[i],b[k]-b[i])+cal(a[k]-a[j],b[k]-b[j]);
					ans=max(ans,cnt);
				}
			}
		}
		printf("%lld\n",ans);
//	}
    return 0;
}