#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,m;

void solve()
{
	cin>>n>>m;
	if(n==1)
	{
		cout<<"YES";
		return;
	}
	for(int i=2;i<=m&&i*i<=n;i++){
		if(n%i==0){
			cout<<"NO";
			return;		
		}
	}
	if(n<=m)
	{
		cout<<"NO";
		return;
	}
	while(n%m>0)
		m=n%m;
	if(m==1)cout<<"YES";
	else cout<<"NO";
}
int main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	ll t=1;
	//cin>>t;
	while(t--)
	{
		solve();
		//cout<<'\n';
	}
}