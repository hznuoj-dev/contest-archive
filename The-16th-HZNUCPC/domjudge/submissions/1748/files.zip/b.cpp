#include<bits/stdc++.h>
using namespace std;
#define int long long
inline int read(){
    int x=0,f=1;char c=getchar();
    while(!isdigit(c)){if(c=='-')f=-1;c=getchar();}
    while(isdigit(c))x=x*10+c-48,c=getchar();
    return x*f;
}
const int mod=1e9+7,inv2=(mod+1)/2;
char a[100005],b[100005];
int ca[30],cb[30],ans,c[30][30],sa,sb;
void da(char x){
    ca[x-'a']--;
    if(!ca[x-'a'])--sa;
}
void db(char x){
    cb[x-'a']--;
    if(!cb[x-'a'])--sb;
}
void ia(char x){
    if(!ca[x-'a'])++sa;
    ca[x-'a']++;
}
void ib(char x){
    if(!cb[x-'a'])++sb;
    cb[x-'a']++;
}
signed main(){
    cin>>(a+1)>>(b+1);
    int n=strlen(a+1);
    for(int i=1;i<=n;i++)ca[a[i]-'a']++,sa+=(ca[a[i]-'a']==1);
    for(int i=1;i<=n;i++)cb[b[i]-'a']++,sb+=(cb[b[i]-'a']==1);
    for(int i=1;i<=n;i++)c[a[i]-'a'][b[i]-'a']++;
    for(int i=1;i<=n;i++){
        da(a[i]);ia(b[i]);
        db(b[i]);ib(a[i]);
        c[a[i]-'a'][b[i]-'a']--;
        int ta=sa,tb=sb;
        for(char j='a';j<='z';j++){
            sa=ta;sb=tb;
            if(!ca[j-'a'])continue;
            da(j);ib(j);
            for(char k='a';k<='z';k++){
                if(!cb[k-'a'])continue;
                db(k);ia(k);
                ans=(ans+(sa==sb)*c[j-'a'][k-'a'])%mod;
                ib(k);da(k);
            }
            ia(j);db(j);
        }
        c[a[i]-'a'][b[i]-'a']++;
        da(b[i]);ia(a[i]);
        db(a[i]);ib(b[i]);
    }
    printf("%lld\n",ans*inv2%mod);
    return 0;
}