#include<bits/stdc++.h>
using namespace std;

using ll=long long;

struct P
{
	int u,v;
	int toint()
	{
		return u*26+v;
	}
};
int tong[26*26];

int js[26],jt[26];
int sizes()
{
	int res=0;
	for(int c=0;c<26;++c)
		if(js[c])++res;
	return res;
}
int sizet()
{
	int res=0;
	for(int c=0;c<26;++c)
		if(jt[c])++res;
	return res;
}

int ans;
const int mod=1e9+7;
void SV()
{
	string s,t;
	cin>>s>>t;
	int n=s.size();
	for(int i=0;i<n;++i)
	{
		js[s[i]-'a']++ , jt[t[i]-'a']++;
		
		P p={s[i]-'a',t[i]-'a'};
		tong[p.toint()]++;
	}
	
	for(int val1=0;val1<26*26;++val1)
		for(int val2=val1+1;val2<26*26;++val2)
		{
			if(tong[val1]==0 || tong[val2]==0)continue;
			
			int u1=val1/26 , v1=val1%26;
			int u2=val2/26 , v2=val2%26;
			
			--js[u1],++jt[u1] , ++js[v1],--jt[v1];
			--js[u2],++jt[u2] , ++js[v2],--jt[v2];
			
			if(sizes()==sizet())
			{
				ans+=1LL*tong[val1]*tong[val2]%mod;
				ans%=mod;
			}
			
			++js[u1],--jt[u1] , --js[v1],++jt[v1];
			++js[u2],--jt[u2] , --js[v2],++jt[v2];
		}
	
	for(int val=0;val<26*26;++val)
	{
		if(tong[val]<2)continue;
		
		int u=val/26 , v=val%26;
		--js[u],++jt[u] , ++js[v],--jt[v];
		--js[u],++jt[u] , ++js[v],--jt[v];
		
		if(sizes()==sizet())
		{
			ans+=1LL*tong[val]*(tong[val]-1)/2%mod;
			ans%=mod;
		}
		
		++js[u],--jt[u] , --js[v],++jt[v];
		++js[u],--jt[u] , --js[v],++jt[v];
	}
	
	cout<<ans<<"\n";
}
int main()
{
	ios::sync_with_stdio(0);
	SV();
	return 0;
}