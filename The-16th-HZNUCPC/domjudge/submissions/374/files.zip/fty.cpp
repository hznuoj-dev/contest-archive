#include<bits/stdc++.h>
#define rep(i,f,t) for(int i=f;i<t;i++)
#define ite(i,a) for(auto &i:a)
#define vi vector<int>
#define vc vector
#define pii pair<int,int>
#define ALL(a) (a.begin(),a.end())
#define endl '\n'
using namespace std;
#define int long long
typedef long long ll;
const int mod=1e9+7;
const int N=1e2+10;
int qmi(int a,int b){
	int res=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
pii arr[N];


pii operator -(pii a,pii b){
    return {a.first-b.first,a.second-b.second};
}

int operator ^(pii a,pii b){
    return a.first*b.second-a.second*b.first;
}

void solve(){
    int n;
    cin>>n;
    rep(i,0,n){
        int x,y;
        cin>>x>>y;
        arr[i]={x,y};
    }
    int mx=0;
    rep(i,0,n){
        rep(j,i+1,n){
            rep(k,j+1,n){
            	int tmp=0;
                int a,b;
                a=abs(arr[i].first-arr[j].first);
                b=abs(arr[i].second-arr[j].second);
                if(a&&b)
                	tmp+=__gcd(a,b);
                else tmp+=a+b;
                
                a=abs(arr[k].first-arr[j].first);
                b=abs(arr[k].second-arr[j].second);
                if(a&&b)
                	tmp+=__gcd(a,b);
                else tmp+=a+b;
                
                a=abs(arr[i].first-arr[k].first);
                b=abs(arr[i].second-arr[k].second);
                if(a&&b)
                	tmp+=__gcd(a,b);
                else tmp+=a+b;
                mx=max(mx,tmp);
            }
        }
    }
    cout<<mx<<endl;
}
signed main(){
	cin.tie(0)->sync_with_stdio(false);
	int tc=1;
	for(int i=1;i<=tc;i++){
		solve();
	}
}


/*
4
0 0
1 1
2 4
4 2


4
1 1
2 2
3 3
2 4

3
1 1
2 2
1 3


*/