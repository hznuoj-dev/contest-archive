#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m,k,t;
	cin>>n>>m;
	if(n==1 ||m==1){
		cout <<"YES"<<endl;
	}else{
		if(n%m==0 || n<m){
			cout <<"NO"<<endl;
		}else{
			cout <<"YES"<<endl;
		}
	}
	
	return 0;
}