#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll mode = 1e9 + 7;
const ll N = 1e6 + 7;
ll t, n, x[N], y[N];
int find(ll a, ll b){
	if(min(a, b) == 0) return max(a, b) - 1;
	return __gcd(a, b) -1;
	return 0;
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
    cin>>n;
	for(int i = 1; i <= n; i++){
		cin>>x[i]>>y[i];
	}
	ll ans = 0;
	int ok = 0;
	for(int i = 1; i < n - 1; i++){
		for(int j = i + 1; j < n; j++){
			ll x1 = abs(x[i] - x[j]);
			ll y1 = abs(y[i] - y[j]);
			for(int k = j + 1; k <= n; k++){
				ll mx = 0;
				ll x2 = abs(x[i] - x[k]);
				ll y2 = abs(y[i] - y[k]);
				ll x3 = abs(x[j] - x[k]);
				ll y3 = abs(y[j] - y[k]);
				double k1 = 1.0 * (x[i] - x[k]) / (y[i] - y[k]);
				double k2 = 1.0 * (x[i] - x[j]) / (y[i] - y[j]);
				if(k1 == k2){
					continue;
				}else{
					ok = 1;
					mx += find(x1, y1);
					mx += find(x2, y2);
					mx += find(x3, y3);
					ans = max(ans, mx);
				}	
			}
		}
	}
	if(ok) ans += 3;
	cout<<ans<<'\n';
return 0;
}