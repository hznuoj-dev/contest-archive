#include<bits/stdc++.h>
using namespace std;
int main(){
int c[21][21]={{5},0},cc[21][21]={{5},0};
int t,x,y,z,n;
scanf("%d",&t);
while(t--){
	int count=0,x1=0,y1=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
	scanf("%d %d %d",&x,&y,&z);
	if(z==1)
	c[x+1][y+1]=1,cc[++x1][++y1]=c[x+1][y+1];
	else
	c[x+1][y+1]=2,cc[++x1][++y1]=c[x+1][y+1];
	}
	for(int i=1;i<21;i++){
		for(int j=1;j<21;j++){
			if(cc[i][j]==1){
				if(c[i+1][j]==0)c[i+1][j]=5,count++;
				if(c[i-1][j]==0)c[i-1][j]=5,count++;
				if(c[i][j+1]==0)c[i][j+1]=5,count++;
				if(c[i][j-1]==0)c[i][j-1]=5,count++;
			}
		}
	}
	printf("%d\n",count);
}
}
