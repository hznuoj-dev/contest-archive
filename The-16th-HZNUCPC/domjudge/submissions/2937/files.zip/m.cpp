#include <iostream>
using namespace std;
int f[21][21],i,j;
int main() {
	for(i=0;i<21;i++){
		f[i][0]=3;
			f[0][i]=3;
			f[i][20]=3;
			f[20][i]=3;
	}
	for(int i=1;i<=19;i++)
		{
			for(int j=1;j<=19;j++)
			{
				f[i][j]=4;
			}
		}
		int n;
		cin >> n;
		while (n-- > 0) {
			int t;
			cin >> t;
			int ans = 0;
			while (t-- > 0){
				int x,y,c;
				cin >>x>>y>>c;
				f[x][y]=c;
				
		}
			for(int i=1;i<=19;i++)
			{
				for(int j=1;j<=19;j++)
				{
					if(f[i][j]==1)
					{
						if(f[i-1][j]==4)
						{
							ans++;
						}
						 if(f[i+1][j]==4)
						{
							ans++;
						}
						 if(f[i][j-1]==4)
						{
							ans++;
						}
						if(f[i][j+1]==4)
						{
							ans++;
						}
					}
					
						
					
				}
				
			}
			cout << ans << endl;
	}
}
