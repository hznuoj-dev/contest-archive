#include <iostream>
#include <cstdio>
#include <bits/stdc++.h>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;

const int N = 19 + 10;
int t, n;
bool a[N][N], f[N][N];
bool b[N][N];
int k;
int dx[4] = {1, -1, 0, 0}, dy[4] = {0, 0, 1, -1};
int hexx[N * N], hey[N * N];

void solve()
{
    int cnt = 0;
    for(int i = 0;i < k;i++)
    {
        for(int j = 0;j < 4;j++)
        {
            if(!f[hexx[i] + dx[j]][hey[i] + dy[j]] && !a[hexx[i] + dx[j]][hey[i] + dy[j]] && !b[hexx[i] + dx[j]][hey[i] + dy[j]] && hey[i] + dy[j] >= 0 && hey[i] + dy[j] <= 19 && hexx[i] + dx[j] >= 0 && hexx[i] + dx[j] <= 19)
            {
                cnt++;
                f[hexx[i] + dx[j]][hey[i] + dy[j]] = 1;
            }
        }
    }
    cout << cnt << "\n";
}

int main()
{
    cin >> t;
    for(int i = 0;i < t;i++)
    {
        memset(a, 0, sizeof(a));
        memset(b, 0, sizeof(b));
        memset(f, 0, sizeof(f));
        memset(hexx, 0, sizeof(hexx));
        memset(hey, 0, sizeof(hey));
        cin >> n;
        k = 0;
        for(int j = 0;j < n;j++)
        {
            int x, y, c;
            cin >> x >> y >> c;
            if(c == 1)
            {
                a[x][y] = 1;
                hexx[k] = x;
                hey[k] = y;
                k++;
            }
            else
            {
                b[x][y] = 1;
            }
        }
        solve();
    }
    return 0;
}