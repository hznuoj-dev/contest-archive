#include<bits/stdc++.h>
using namespace std;
#define int long long
#define rep(i,l,r) for(int i=l;i<=r;++i)
#define N 110
#define M 50
int n,m;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n>>m;
	for(int i=2;i*i<=n&&i<=m;i++){
		if(n%i==0)return(!puts("NO"));
	}
	puts("YES");
}