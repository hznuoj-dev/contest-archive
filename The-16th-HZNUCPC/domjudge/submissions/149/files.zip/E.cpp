#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N = 105;
int n,ans, a[2][N],b[N][N];
void solve() {
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[0][i]>>a[1][i];
	for(int i=1;i<=n;i++)
	for(int j=i+1;j<=n;j++)
	b[i][j]=__gcd(abs(a[1][j]-a[1][i]),(a[0][j]-a[0][i]))-1;
	for(int i=1;i<=n;i++)
	for(int j=i+1;j<=n;j++)
	for(int k=j+1;k<=n;k++)
	{
		if((a[1][j]-a[1][i])*(a[0][k]-a[0][i])==(a[1][k]-a[1][i])*(a[0][j]-a[0][i]))continue;
		ans=max(ans,3+b[i][j]+b[j][k]+b[i][k]);
	}
	cout<<ans<<"\n";
	return;
}
signed main() {
	ios::sync_with_stdio(false);
	int T = 1;
	while(T--) {
		solve();
	}
	return 0;
}