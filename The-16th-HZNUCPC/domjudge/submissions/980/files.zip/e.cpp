#include<bits/stdc++.h>
using namespace std;
#define int long long
#define x first 
#define y second
const int N=110;
pair<int,int>a[N];

bool check(int i,int j,int k)
{
	if(a[i]==a[j]||a[j]==a[k]||a[i]==a[k])return false; 
	int dx1=a[i].x-a[k].x;
	int dy1=a[i].y-a[k].y;
	int dx2=a[j].x-a[k].x;
	int dy2=a[j].y-a[k].y;
	if(dy1*dx2==dx1*dy2)
	{
		return 0;
	}
	else return 1;
}
signed main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i].first>>a[i].second;
	}
	
	int ans=0;int flag=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(i==j)continue;
			for(int k=1;k<=n;k++)
			{
				if(i==k||j==k)continue;
				if(!check(i,j,k))continue;
				else flag=1;
				int dx=abs(a[i].first-a[j].first);
				int dy=abs(a[i].second-a[j].second);
				int x=__gcd(dx,dy);
				int mx=x+1;
				dx=abs(a[j].first-a[k].first);
				dy=abs(a[j].second-a[k].second);
				x=__gcd(dx,dy);
				mx+=x+1;
				dx=abs(a[i].first-a[k].first);
				dy=abs(a[i].second-a[k].second);
				x=__gcd(dx,dy);
				mx+=x+1;
				mx-=3;
				ans=max(ans,mx);
			}
		}
	}
	if(flag) cout<<ans<<endl;
	else cout<<0<<endl;
}