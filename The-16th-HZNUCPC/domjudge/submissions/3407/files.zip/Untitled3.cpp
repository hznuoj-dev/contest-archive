#include<bits/stdc++.h>
using namespace std;
int main(){
	string s,ss;
	while(cin>>s>>ss){
		long long mod = 1e9+7;
		long long sum=1;
		long long a=0,b=0;
		for(int i=0;i<s.size();i++){
			if(s[i]==ss[i])a++;
			else b++;
		}
		if(a>=2)sum*=((a%mod)*(b%mod))%mod;
		
		sum*=(((a%mod)*((a-1)%mod))/2)%mod;
		cout<<sum%mod<<endl;
	}
	
	
	return 0;
}