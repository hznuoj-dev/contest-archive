#include<iostream>
#include<cstring>
#include<algorithm>
#include<unordered_map>

#define read(x) scanf("%d", &x)
#define readll(x) scanf("%lld", &x)
#define out(x) printf("%d", x)
#define out(x) printf("%lld", x)

using namespace std;

typedef long long LL;

const int N = 30;

string s, t;
unordered_map<char, int> ma1;
unordered_map<char, int> ma2;
LL a[N][N];

int dx[10]={0,0,0,-1,1,1,-1};
int dy[10]={0,1,-1,1,-1,0,0};

const int mod = 1e9+7;


int main(){
	cin >> s >> t;
	
	
	for(int i = 0; i<s.size(); i++){
		if(!ma1.count(s[i]))ma1[s[i]]=1;
		else ma1[s[i]]+=1;
	}
	
	for(int i = 0; i<t.size(); i++){
		if(!ma2.count(t[i]))ma2[t[i]]=1;
		else ma2[t[i]]+=1;
	}
	int sum1 = ma1.size();
	int sum2 = ma2.size();
	for(int i=0;i<s.size();i++){
		int l = 0,r=0;
		if(ma2.count(s[i])){
			if(ma1[s[i]]==1){
				l-=1;
			}
		}
		else{
			r+=1;
		}
		if(ma1.count(t[i])){
			if(ma2[t[i]]==1){
				r-=1;
			}
		}else{
			l+=1;
		}
		
		a[l+1][r+1]+=1;
	}
	LL res = 0;
	for(int i=0;i<7;i++){
		for(int j=0;j<7;j++){
			if(sum1+dx[i]+dx[j]==sum2+dy[i]+dy[j]){
				if(i==j)res+=(a[dx[i]+1][dy[i]+1]*(a[dx[j]+1][dy[j]+1]-1)/2)%mod;
				else res += (a[dx[i]+1][dy[i]+1]*a[dx[j]+1][dy[j]+1])%mod;
			}
		}
	}
	cout<<res<<endl;
	return 0;
}
