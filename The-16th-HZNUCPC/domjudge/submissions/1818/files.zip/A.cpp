#pragma GCC optimize(2)
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>
using namespace std;
const int inf = 1e9;
const int maxn = 3e5 + 7;
typedef long long ll;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
const ll mod = 1e9 + 7;
ll mp[30][30],a[30],b[30];
int main ()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int tt = 1;
    //cin >> tt;
    while (tt--)
    {
        string s,t;
        cin >> s >> t;
        int n = s.size();
        ll now = 0;
        for (int i = 0; i < n; ++i)
        {
            int x = s[i] - 'a';
            int y = t[i] - 'a';
            mp[x][y]++;
            a[x]++;
            b[y]++;
        }
        ll ans = 0;
        for (int i = 0; i < 26; ++i)
        {
            for (int j = 0; j < 26; ++j)
            {
                for (int w = 0; w < 26; ++w)
                {
                    for (int k = 0; k < 26; ++k)
                    {
                        --a[i];++a[j];--a[w];++a[k];
                        ++b[i];--b[j];++b[w];--b[k];
                        int c1 = 0,c2 = 0;
                        for (int q = 0; q < 26; ++q)
                        {
                            if (a[q] > 0) ++c1;
                            if (b[q] > 0) ++c2;
                        }
                        if (c1 == c2)
                        {
                            if (i == w && j == k) ans = (ans + mp[i][j]*(mp[w][k]-1)) ;
                            else ans = (ans + mp[i][j] * mp[w][k]) ;
                        }
                        ++a[i];--a[j];++a[w];--a[k];
                        --b[i];++b[j];--b[w];++b[k];
                    }
                }
            }
        }
        cout << (ans/2)%mod << "\n";
    }

}
