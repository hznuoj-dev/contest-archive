#include<bits/stdc++.h>
using namespace std;
using ll=long long;

char a[5010];
int n,ans;
void Main(){
	scanf("%s",a+1);
	a[0]='@';
	n=strlen(a+1);
	a[n+1]='%';
	ans=0;
	for (int i=1;i<=n;++i){
		int L=i,R=i;
		int t[4];
		int cur=0,tmp=0;
		for (int j=1;R-j>=0&&L+j<=n+1;++j){
			if (cur==0) tmp=j;
			if (a[L-j]==a[R+j]){
				if (cur==0) ans=max(ans,2*j+1);
				continue;
			}
			if (cur==2){
				ans=max(ans,2*j-1);
				break;
			}
			t[cur*2]=a[L-j]-'a';
			t[cur*2+1]=a[R+j]-'a';
			++cur;
			if (cur==2)
			if (t[0]==t[3]&&t[1]==t[2]||t[0]==t[2]&&t[1]==t[3]){
				ans=max(ans,2*j+1);
				continue;
			}else{
				if (tmp>1) ans=max(ans,2*tmp-1);
				break;
			}
		}
	}
	for (int i=1;i<n;++i){
		int L=i+1,R=i;
		int t[4];
		int cur=0,tmp=0;
		for (int j=1;L-j>=0&&R+j<=n+1;++j){
			if (cur==0) tmp=j;
			if (a[L-j]==a[R+j]){
				if (cur==0) ans=max(ans,2*j);
				continue;
			}
			if (cur==2){
				ans=max(ans,2*j-2);
				break;
			}
			t[cur*2]=a[L-j]-'a';
			t[cur*2+1]=a[R+j]-'a';
			++cur;
			if (cur==2)
			if (t[0]==t[3]&&t[1]==t[2]||t[0]==t[2]&&t[1]==t[3]){
				ans=max(ans,2*j);
				continue;
			}else{
				ans=max(ans,2*tmp-2);
				break;
			}
		}
	}
	printf("%d\n",ans);
}
int main()
{
	int T;
	scanf("%d",&T);
	while (T--)
	Main();
	return 0;
}