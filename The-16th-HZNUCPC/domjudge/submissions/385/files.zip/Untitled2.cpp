#include<bits/stdc++.h>
using namespace std;
int main()
{
    long long int i,j,x,n,m;
    scanf("%lld%lld",&n,&m);
    
    if(n%2==0)
    {
    	printf("NO");
	}
	else
	{
		if(sqrt(n)>=m)
			i=m;
		else
			i=sqrt(n);
		for(j=i;j>1;j--)
		{
			if(n%j==0)
			{
				printf("NO");
				j=-1;
				break;
			}
		}
		if(j==1)
			printf("YES");
	}
}