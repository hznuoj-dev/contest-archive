# include "bits/stdc++.h"
using namespace std;
# define int long long

// A - 2
int black[23][23];
int white[23][23];
int dir[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};

bool Judge(int x, int y){
	if(x >= 1 && x <= 19 && y >= 1 && y <= 19) return true;
	return false;
}

signed main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0); cout.tie(0);
	int t;
	scanf("%lld", &t);
	while(t--){
		memset(black, 0, sizeof(black));
		memset(white, 0, sizeof(white));
		int n;
		scanf("%lld", &n);
		while(n--){
			int x, y, c;
			scanf("%lld %lld %lld", &x, &y, &c);
			if(c == 1){
				black[x][y] = 1;
			}else{
				white[x][y] = 1;
			}
		}
		int ans = 0;
		for(int i = 1; i <= 19; i++){
			for(int j = 1; j <= 19; j++){
				for(int k = 0; k < 4; k++){
					int tx = i + dir[k][0];
					int ty = j + dir[k][1];
					if(Judge(tx, ty) && black[i][j] == 1){
						if(!white[tx][ty] && !black[tx][ty]) ans++;
					}
				}
			}
		}
		printf("%lld\n", ans);
	}
	
	
	return 0;
}