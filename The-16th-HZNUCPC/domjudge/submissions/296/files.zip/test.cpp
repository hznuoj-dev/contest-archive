#include<bits/stdc++.h>
#define ll long long
#define PII pair<int,int>
using namespace std;
const int INF = 0x3f3f3f3f;
struct node{
	int x;
	int y;
	int c;
}a[370];
bool vis[25][25];
int dx[] = {0,0,-1,1},dy[]={1,-1,0,0};
void solve(){
	int ans = 0;
	memset(vis,0,sizeof(vis));
	int n;
	cin>>n;
	for(int i = 1;i<=n;i++){
		cin>>a[i].x>>a[i].y>>a[i].c;
		vis[a[i].x][a[i].y] = 1;
	}
	for(int i = 1;i<=n;i++){
		if(a[i].c==1){
			int x = a[i].x,y = a[i].y;
			for(int j = 0;j<4;j++){
				int xx = x + dx[j],yy = y + dy[j];
				if(xx>=1&&xx<=19&&yy>=1&&yy<=19&&!vis[xx][yy]){
					ans ++;
				}
			}
		}
	}
	cout<<ans<<'\n';
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	int T = 1;
	cin>>T;
	while(T--) solve();
	return 0;
}
