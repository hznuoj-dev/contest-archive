import math
n = int(input())

point = []
for i in range(n):
    a,b = map(int,input().split())
    point.append([a,b])
ans = -1
for i in range(0,len(point)):
    for j in range(i+1,len(point)):
        for k in range(j+1,len(point)):
            if point[k][0] == point[j][0] and point[j][0] == point[i][0] and point[k][0] == point[i][0]:
                continue
            elif point[k][0] == point[j][0] or point[j][0] == point[i][0] or point[k][0] == point[i][0]:
                ans = max(ans,3+math.gcd(abs(point[k][0]-point[j][0]),abs(point[k][1]-point[j][1]))-1+
                math.gcd(abs(point[k][0]-point[i][0]),abs(point[k][1]-point[i][1]))-1+
                math.gcd(abs(point[j][0]-point[i][0]),abs(point[j][1]-point[i][1]))-1
                ) 
            elif (point[k][1] - point[j][1])/(point[k][0] - point[j][0]) == (point[k][1] - point[i][1])/(point[k][0] - point[i][0]):
                continue
            else:
                ans = max(ans,3+math.gcd(abs(point[k][0]-point[j][0]),abs(point[k][1]-point[j][1]))-1+
                math.gcd(abs(point[k][0]-point[i][0]),abs(point[k][1]-point[i][1]))-1+
                math.gcd(abs(point[j][0]-point[i][0]),abs(point[j][1]-point[i][1]))-1
                ) 
if ans==-1:
    print('0')
else:
    print(ans)