// #define DEBUG
#include <bits/stdc++.h>

using namespace std;
const int MOD = 1000000007;
const int INV2 = 500000004;
const int MAXN = 1e5 + 5;
#define int long long
#define endl '\n'

int q_pow(int a, int b) {
    int res = 1;
    for (; b; b >>= 1) {
        if (b & 1) res = res * a % MOD;
        a = a * a % MOD;
    }
    return res;
}

int typeNum[26][26] = {0};

void solve() {
    int res = 0;
    string a, b; cin >> a >> b;
    int n = (int)a.size();
    vector<int> cntA(26);
    vector<int> cntB(26);
    for (int i = 0; i < n; i ++ ) {
        cntA[a[i] - 'a'] ++;
        cntB[b[i] - 'a'] ++;
    }
    for (int i = 0; i < n; ++i) {
        typeNum[a[i] - 'a'][b[i] - 'a']++;
    }
    auto exchange = [&](int i, int j) {
        cntB[i]++, cntA[i]--, cntB[j]--, cntA[j]++;
    };
    for (int i = 0; i < 26; ++i) {
        for (int j = 0; j < 26; ++j) {
            if (typeNum[i][j] == 0) continue;
            for (int k = 0; k < 26; ++k) {
                for (int l = 0; l < 26; ++l) {
                    if (typeNum[k][l] == 0) continue;
                    exchange(i, j), exchange(k, l);
                    int szA = 0, szB = 0;
                    for (int i = 0; i < 26; i ++ ) {
                        if (cntA[i] > 0) szA ++;
                        if (cntB[i] > 0) szB ++;
                    }
                    if (szA == szB) {
                        if (i == k && j == l) {
                            res = (res + typeNum[i][j] * (typeNum[k][l] - 1) % MOD) % MOD;
                        }else {
                            res = (res + typeNum[i][j] * typeNum[k][l] % MOD) % MOD;
                        }
                    }
                    exchange(j, i), exchange(l, k);
                }
            }
        }
    }
    cout << res * INV2 % MOD << endl;
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    // cin >> T;
    // while (T--)
    {solve(); }
#ifdef DEBUG
    cerr << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}