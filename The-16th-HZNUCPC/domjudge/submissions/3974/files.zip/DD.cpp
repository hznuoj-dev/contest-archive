#include<bits/stdc++.h>
using namespace std;
#define rep(i,a,b) for(int i=a;i<=b;i++)
typedef long long ll;
typedef pair<ll,ll>pii;
const ll N=2e5+10;
vector<ll>g[N];
ll dfn[N],low[N],times,scc,id[N];
bool in[N];
stack<ll>stk;
vector<ll>v[N];
//pii a[N];

struct node{
	int t,l,r;
	bool operator<(const node& a)const{
		return t<a.t||(t==a.t&&r<a.r)||(t==a.t&&r==a.r&&l<a.l);
	}
}a[N];

struct Z{
	int l,r,w,add;
}tr[N<<2];
#define MID (tr[i].l+tr[i].r>>1)
#define ls i<<1
#define rs i<<1|1
void build(int i,int l,int r){
	tr[i]={l,r,0,0};
	if(l==r){
		return;
	}
	int mid=(l+r)>>1;
	build(ls,l,mid);
	build(rs,mid+1,r);
}
void pd(int i){
	if(tr[i].add){
		int w=tr[i].add;
		tr[ls].add+=w,tr[ls].w+=w;
		tr[rs].add+=w,tr[rs].w+=w;
		tr[i].add=0;
	}
}
void add(int i,int l,int r,int w){
	if(tr[i].l>=l&&tr[i].r<=r){
		tr[i].w+=w;
		tr[i].add+=w;
		return;
	}
	pd(i);
	if(l<=MID)add(ls,l,r,w);
	if(MID+1<=r)add(rs,l,r,w);
	tr[i].w=tr[ls].w+tr[rs].w;
}
int query(int i,int l,int r){
	if(tr[i].l>=l&&tr[i].r<=r)return tr[i].w;
	pd(i);
	int s=0;
	if(l<=MID)s+=query(ls,l,r);
	if(MID+1<=r)s+=query(rs,l,r);
}
int c[N],p[N],b[N],ans[N];
void solve(){
	int n,m,x;cin>>n>>m>>x;
	map<int,int> ot;
	rep(i,1,n){
		cin>>a[i].t>>a[i].l>>a[i].r;
		ot[a[i].l]=ot[a[i].r]=1;
	}
	sort(a+1,a+n+1);
	rep(i,1,m){
		cin>>c[i]>>p[i];
		ot[p[i]]=1;
		b[i]=i;
	}
	map<int,int> to;
	int tot=0;
	for(auto i : ot)to[i.first]=++tot;
	auto get=[&](int& x){
		x=to[x];
	};
	rep(i,1,n)get(a[i].l),get(a[i].r);
	rep(i,1,m)get(p[i]);
	
	build(1,1,tot);
	sort(b+1,b+m+1,[](int x,int y){
		return c[x]>c[y];
	});
	map<int,int> mp;
	int pos=n;
	rep(i,1,m){
		int id=b[i];
		int t=c[id];
		while(pos>=1&&a[pos].t>=t){
			
			int l=a[pos].l,r=a[pos].r;
			auto it=mp.lower_bound(l);
			int L=l,R=r;
			if(it!=mp.begin()){
				if(prev(it)->second>=l)l=prev(it)->second+1;
			}
			while(it!=mp.end()&&it->second<=r){
				add(1,it->first,it->second,-1);
				it=mp.erase(it);
			}
			
			if(it!=mp.end())R=it->first-1;
			mp[L]=R;
			add(1,L,R,1);
			pos--;
	    }
	    cout<<"FPPPP"<<i<<'\n';
	    for(auto j : mp){
	    	cout<<j.first<<' '<<j.second<<'\n';
		}
	    
	    int res=0;
	    if(prev(mp.end())->second!=x){
	    	res=-1;
		}
		else {
			auto it=mp.upper_bound(p[id]);
			if(it==mp.begin())res=-1;
			else {
				it=prev(it);
				if(it->second>=p[id]){
					res=query(1,it->first,x);
				}
				else res=-1;
			}
		}
		ans[id]=res;
    }
    rep(i,1,m)cout<<ans[i]<<"\n";
}
int main() {
	solve();
}
