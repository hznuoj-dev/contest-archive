# include "bits/stdc++.h"
using namespace std;
# define int long long

int n, ans;
int s[105][5];
int b[5][5];

int triangle(int x1, int y1, int x2, int y2){
	int tmp1 = abs(x2 - x1);
	int tmp2 = abs(y2 - y1);
	if(tmp1 == tmp2){
		return tmp1;
	}
	if(tmp1 == 0){
		return tmp2;
	}
	if(tmp2 == 0){
		return tmp1;
	}
	if(tmp2 > tmp1){
		if(tmp2 % tmp1 || tmp1 == 1){
			return 1;
		}else{
			return tmp2 / (tmp2 / tmp1);
		}
	}
	if(tmp1 > tmp2){
		if(tmp1 % tmp2 || tmp2 == 1){
			return 1;
		}else{
			return tmp1 / (tmp1 / tmp2);
		}
	}
}

bool judge(int x1, int y1, int x2, int y2, int x3, int y3){
	if(1.0*(y2 - y1) / (x2 - x1) != 1.0*(y3 - y1) / (x3 - x1)) return true;
	return false;
}

void dfs(int l, int begin){
	if(l == 3){
		if(!judge(b[0][0], b[0][1], b[1][0], b[1][1], b[2][0], b[2][1])) return ;
		int tmp = 0;
		tmp += triangle(b[0][0], b[0][1], b[1][0], b[1][1]);
		tmp += triangle(b[1][0], b[1][1], b[2][0], b[2][1]);
		tmp += triangle(b[0][0], b[0][1], b[2][0], b[2][1]);
		ans = max(ans, tmp);
		return ;
	}
	if(l > 3){
		return ;
	}
	for(int i = begin; i < n; i++){
		b[l][0] = s[i][0];
		b[l][1] = s[i][1];
		dfs(l+1, i+1);
	}
}

signed main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);

	while(cin >> n){
		for(int i = 0; i < n; i++){
			cin >> s[i][0] >> s[i][1];
		}
		ans = 0;
		dfs(0,0);
		cout << ans << endl;
	}
	return 0;
}