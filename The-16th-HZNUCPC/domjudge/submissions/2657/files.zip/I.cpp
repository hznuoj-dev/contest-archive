#include<bits/stdc++.h>
#define ll long long
#define rep(i,j,k) for(int i=(j);i<=(k);i++)

const int N = 7e3 + 5;

char s[N];

struct node{
	int x, y, k;
};

inline void solve() {
//	std::queue < node > q;
	scanf ( "%s", s + 1 );
	int n = strlen ( s + 1 );
	int ans = 0;
	rep ( i, 1, n ) {
//		f[i][i][0] = 1, q.push ( { i, i, 0 } );
//		printf ( "i = %d\n", i );
		int x = i, y = i, k = 0;
		int res = 1;
		std::pair < char, char > cur;
		while ( x > 1 && y < n ) {
			x--, y++;
//			printf ( "x = %d, y = %d\n", x, y );
			if ( s[x] == s[y] ) res += 2;
			else {
				if ( k == 0 ) {
					k++;
					cur = std::minmax ( s[x], s[y] );
					res += 2;
				} else if ( k == 1 ) {
					std::pair < char, char > now = std::minmax ( s[x], s[y] );
					if ( now.first == cur.first && now.second == cur.second ) k++, res += 2;
					else break;
				}
			} if ( k == 0 || k == 2 ) ans = std::max ( ans, res );
		}
	}
	rep ( i, 2, n ) {
		if ( s[i] == s[i - 1] ) {
//			f[i - 1][i][0] = 2, q.push ( { i - 1, i, 0 } ), ans = 2;
			int x = i - 1, y = i, k = 0;
			int res = 2;
			std::pair < char, char > cur;
			while ( x > 1 && y < n ) {
				x--, y++;
				if ( s[x] == s[y] ) res += 2;
				else {
					if ( k == 0 ) {
						k++;
						cur = std::minmax ( s[x], s[y] );
						res += 2;
					} else if ( k == 1 ) {
						std::pair < char, char > now = std::minmax ( s[x], s[y] );
						if ( now.first == cur.first && now.second == cur.second ) k++, res += 2;
						else break;
					}
				} if ( k == 0 || k == 2 ) ans = std::max ( ans, res );
			}
		}
		else {
//			f[i - 1][i][1] = 2, q.push ( { i - 1, i, 1 } ), p[i - 1][i] = std::minmax ( s[i - 1], s[i] );
			std::pair < char, char > cur = std::minmax ( s[i], s[i - 1] );
			int x = i - 1, y = i, k = 1;
			int res = 2;
			while ( x > 1 && y < n ) {
				x--, y++;
				if ( s[x] == s[y] ) {
					res += 2;
				} else if ( k == 1 ) {
					std::pair < char, char > now = std::minmax ( s[x], s[y] );
					if ( now.first == cur.first && now.second == cur.second ) k++, res += 2;
					else break;
				}
				if ( k == 2 ) ans = std::max ( ans, res );
			}
		}
	}
//	while ( !q.empty() ) {
//		node u = q.front(); q.pop();
//		int x = u.x, y = u.y, k = u.k;
//		if ( k == 0 || k == 2 ) ans = std::max ( ans, f[x][y][k] );
//		if ( x > 1 && y < n ) {
//			x--, y++;
//			if ( s[x] == s[y] ) {
//				f[x][y][k] = std::max ( f[x][y][k], f[x + 1][y - 1][k] + 2 );
//				p[x][y] = p[x + 1][y - 1];
//				q.push ( { x, y, k } );
//			}
//			else {
//				if ( k == 0 ) f[x][y][1] = std::max ( f[x][y][1], f[x + 1][y - 1][0] + 2 ), p[x][y] = std::minmax ( s[x], s[y] ), q.push ( { x, y, 1 } );
//				else if ( k == 1 && check ( x, y ) ) f[x][y][2] = std::max ( f[x][y][2], f[x + 1][y - 1][1] + 2 ), q.push ( { x, y, 2 } ); 
//			}
//		}
//	}
	for ( char kk = 'a' ; kk <= 'z' ; kk++ ) {
		rep ( i, 1, n ) {
			if ( s[i] == kk ) continue;
			std::pair < char, char > cur = std::minmax ( s[i], kk );
			int x = i, y = i, k = 1;
			int res = 1;
			while ( x > 1 && y < n ) {
				x--, y++;
				if ( s[x] == s[y] ) {
					res += 2;
				} else if ( k == 1 ) {
					std::pair < char, char > now = std::minmax ( s[x], s[y] );
					if ( now.first == cur.first && now.second == cur.second ) k++, res += 2;
					else break;
				}
				if ( k == 2 ) ans = std::max ( ans, res );
			}
		}
	}
	printf ( "%d\n", ans == 1 ? 0 : ans );
}

signed main() {
	int t; scanf ( "%d", &t );
	while ( t-- ) solve();
}