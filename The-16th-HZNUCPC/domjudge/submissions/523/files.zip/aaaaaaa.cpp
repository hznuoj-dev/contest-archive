#include<bits/stdc++.h>
using namespace std;
int n;int f[25][25];
void solve(){
	cin>>n;
	int x,y,k;
	memset(f,0,sizeof(f));
	queue<pair<int,int>>q;
	for(int i=0;i<n;i++){
		cin>>x>>y>>k;
		if(k==2){
			f[x][y]=1;
		}
		if(k==1){
			q.push({x,y});
			f[x][y]=1;
		}
	}
	int ans=0;
	while(!q.empty()){
		
		int a=q.front().first;
		int b=q.front().second;
		q.pop();
		if(a-1>=1&&a-1<=19){
			if(f[a-1][b]==0){
				ans++;
			}
		}
		if(a+1>=1&&a+1<=19){
			if(f[a+1][b]==0){
				ans++;
			}
		}
		if(b-1>=1&&b-1<=19){
			if(f[a][b-1]==0){
				ans++;
			}
		}
		if(b+1>=1&&b+1<=19){
			if(f[a][b+1]==0){
				ans++;
			}
		}
	}
	cout<<ans<<endl;
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}