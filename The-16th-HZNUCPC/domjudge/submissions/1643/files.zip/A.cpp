#include<bits/stdc++.h>
using namespace std;
#define int long long
struct ll{
	double x,y;
}q[105];
bool ck(int x){
	if(x<=2){
		return false;
	}
	for(int i=2;i<=sqrt(x);i++){
		if(x%i==0){
			return false;
		}
	}
	return true;
}
void solve(){
	int x,y;
	cin>>x>>y;
	if(x==1||y==1){
		cout<<"YES"<<endl;
		return ;
	}
	if(y>=x){
		cout<<"NO"<<endl;
		return ;
	}
	if(ck(x)){
		cout<<"YES"<<endl;
	}else{
		cout<<"NO"<<endl;
	}
	
	
}
signed main(){
//	int t;cin>>t;while(t--)
	solve();
	
	
	return 0;
}