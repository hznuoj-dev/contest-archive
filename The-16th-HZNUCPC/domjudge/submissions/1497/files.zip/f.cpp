#include <bits/stdc++.h>
using namespace std;

long long gcd(long long a,long long b){
	long long c;
	if(a<b){
		b+=a;
		a=b-a;
		b-=a;
	}
	while(a%b!=0){
		c=a%b;
		a=b;
		b=c;
	}
	return b;
}

int main(){
	long long n,m;
	scanf("%lld%lld",&n,&m);
	if(n==1||m==1)printf("YES");
    else if(n<=m)printf("NO");
    else {
    	if(gcd(n,m)==1)printf("YES");
    	else printf("NO");
	}
	return 0;
}