#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
#define per(i,x,y) for(int i=x;i>=y;i--)
#define FOR(i,x,y) for(char i=x;i<=y;i++)
#define random(a,b) rand()%(b-a+1)+a
using namespace std;
#define int long long
const int mod=1e9+7;
const int N=2e5+10;
int qmi(int a,int b) {
	int res=1;
	for(; b; b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
string a,b;
int ans=0;
int n;
void solve() {
	ans=0;
	map<char,int>x,y;
	FOR(i,'a','z')x[i]=0;
	FOR(i,'a','z')y[i]=0;
	for(auto ch:a)x[ch]++;
	for(auto ch:b)y[ch]++;
	map<pair<char,char>,int>mp;
	rep(i,0,a.size()-1) {
		mp[ {a[i],b[i]}]++;
	}
	for(auto [st1,cnt1]:mp)for(auto [st2,cnt2]:mp){
		auto []
	}
	FOR(i,'a','z')FOR(j,'a','z')FOR(k,'a','z')FOR(l,'a','z') {
		//cout<<i<<" "<<j<<" "<<k<<" "<<l<<"\n";
		if(x[i] and x[k] and y[j] and y[l]) {
			x[i]--,x[j]++,y[j]--,y[i]++;
			x[k]--,x[l]++,y[l]--,y[k]++;
			map<int,int>ca,cb;
			for(auto [q,w]:x)ca[w]++;
			for(auto [q,w]:y)cb[w]++;
			if(ca==cb) {
				pair<char,char>xx= {i,j};
				pair<char,char>yy= {k,l};
				//cout<<xx.first<<" "<<xx.second<<"\n";
				ans=ans+mp[xx]*mp[yy];
				if(xx==yy)ans-=mp[xx];
				//ans%=mod;
			}
			x[i]++,x[j]--,y[j]++,y[i]--;
			x[k]++,x[l]--,y[l]++,y[k]--;
		}
	}
	//cout<<ans/2;
	if(ans<0) ans+=mod;
	ans=ans*qmi(2,mod-2)%mod;
	cout<<ans;
}


int bl() {
	long long  res=0;
	map<char,int>x,y;
	FOR(i,'a','z')x[i]=0;
	FOR(i,'a','z')y[i]=0;
	for(auto ch:a)x[ch]++;
	for(auto ch:b)y[ch]++;

	n=a.size();
	for(int i=0; i<n; i++) {
		for(int j=i+1; j<n; j++) {
			x[a[i]]--,x[b[i]]++,x[a[j]]--,x[b[j]]++;
			y[a[i]]++,y[b[i]]--,y[a[j]]++,y[b[j]]--;
			map<int,int>ca,cb;
			for(auto [q,w]:x) if(w) ca[w]++;
			for(auto [q,w]:y) if(w) cb[w]++;
//			FOR(i,'a','z')cout<<x[i]<<' ';
//			cout<<endl;
//			FOR(i,'a','z')cout<<y[i]<<' ';
//			cout<<endl;
			if(ca==cb) {
				res=(res+1)%mod;
			}
			x[a[i]]++,x[b[i]]--,x[a[j]]++,x[b[j]]--;
			y[a[i]]--,y[b[i]]++,y[a[j]]--,y[b[j]]++;
		}
	}
	return res;
}


string getRand() {
	string res;
	rep(i,0,n) {
		res+=random(0,25)+'a';
	}
	return res;
}
signed main() {
	cin.tie(0)->sync_with_stdio(false);
	int tc=1;
	for(int i=1;i<=tc;i++){
		cin>>a>>b;
		solve();
	}
//	while(1) {
//		n=random(1,10);
//		a=getRand();
//		b=getRand();
//		solve();
//		int tmp=bl();
//		cout<<a<<' '<<b<<endl;
//		if(tmp!=ans) {
//			cout<<ans<<' '<<tmp<<endl;
//			cout<<a<<' '<<b<<endl;
//			break;
//		}
//	}
}