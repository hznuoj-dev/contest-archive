#include<bits/stdc++.h>
using namespace std;
const int mod=1e9+7;
typedef long long ll;
ll m,n,k,flag;
int main()
{
scanf("%lld%lld",&n,&m);
k=sqrt(n);flag=0;
if (n==1)
{
	puts("YES");
	return 0;
}
if (n<=m&&n>=2)
{
	puts("NO");
	return 0;
}
for (int i=2;i<=k;i++)
  {
  if (n%i==0) {flag=i;break;}
  }
if (flag==0) cout<<"YES"<<endl;
if (flag<=m) cout<<"NO"<<endl;
else  cout<<"YES"<<endl;


}