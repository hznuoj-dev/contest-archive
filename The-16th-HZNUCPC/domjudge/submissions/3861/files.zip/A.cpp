#include <bits/stdc++.h>
using namespace std;
int mp[100][100];
int dir[][2]={{0,1},{1,0},{0,-1},{-1,0}};
int n , t ,x ,y , c;

int main()
{
	cin>>t;
	while(t--)
	{
		int qi=0;
		cin>>n;
		memset(mp,0,sizeof(mp));
		for(int i=1 ; i<= n; i++)
		{
			cin>>x>>y>>c;
			mp[x][y]=c;
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1 ;j <= 19;j++)
			{
				if(mp[i][j] == 2){
					for(int k=0;k<4;k++)
					{
						if(mp[i+dir[k][0]][j+dir[k][1]]==0)
						{
							mp[i+dir[k][0]][j+dir[k][1]]=4;
						}
					}
				}
			}
		}
		for(int i=1;i<=19;i++)
		{
			for(int j=1 ;j <= 19;j++)
			{
				if(mp[i][j] == 1){
					for(int k=0;k<4;k++)
					{
						if((mp[i+dir[k][0]][j+dir[k][1]]==0 || mp[i+dir[k][0]][j+dir[k][1]]==4) && i+dir[k][0]>=1 && i+dir[k][0]<=19 && j+dir[k][1]>=1 && j+dir[k][1]<=19)
						{
							qi++;
							mp[i+dir[k][0]][j+dir[k][1]] = 4;
//							cout<< i+dir[k][0] <<j+dir[k][1]<<endl;
						}
					}
				}
			}
		}
		cout<<qi<<"\n";
//		for(int i=1;i<=19;i++)
//		{
//			for(int j=1 ;j <= 19;j++) cout<<mp[i][j];
//			cout<<"\n";
//		}		
	}
	return 0;
}

