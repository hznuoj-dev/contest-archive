n,m=map(int,input().split())
flag=False
if m==1:
    print('Yes')
elif n==1:
    print('YES')
else:
    for i in range(2,m//2):
        if i>=n:
            flag=True
            break
        if n%i==0:
            flag=True
            break
    if flag:
        print('NO')
    else:
        print('YES')