#include<iostream>
using namespace std;
int main()
{
	long long n,m;
	cin>>n>>m;
	if(n==1)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	else if(n<=m)
	{
		cout<<"NO"<<endl;
		return 0;
	}
	else 
	{
			for(long long i=2;i<=n/i;i++)
		    {
			if(n%i==0)
				{
				if(i<=m)cout<<"NO"<<endl;
				else cout<<"YES"<<endl;
				return 0;
				}
		    }
		cout<<"YES"<<endl;
	}
}