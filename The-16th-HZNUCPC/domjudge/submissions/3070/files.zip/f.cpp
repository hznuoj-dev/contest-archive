#include <iostream>
using namespace std;
typedef long long LL;
int g(LL j , LL k)
{
	
	LL t = j%k;
	if(t == 1) return 1;
	if(t == 0) return 0;
	return g(j,t) ;
}
int main(){
	LL n,m;
	cin>>n>>m;
	if(m == 1)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	if(g(n,m))
	{
		cout<<"YES"<<endl;
	}else
	{
		cout<<"NO"<<endl;
	}
	return 0;
}
