#include "bits/stdc++.h"
using namespace std;

int main(){
	long long n,m;
	while(cin >> n >> m){
		if(n == 1 || m == 1){
			cout << "YES" << endl;
			continue;
		}
		if(n <= m) cout << "NO" << endl;
		else{
			while(m > 1){
				m = n % m;
			}
			if(m == 1) cout << "YES" << endl;
			else cout << "NO" << endl;
		}
	}                 
	return 0;
}
