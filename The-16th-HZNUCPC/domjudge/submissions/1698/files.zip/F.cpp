#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	ll a, b;
	cin >> a >> b;
	if(a==1||b==1){
		cout << "YES\n";
	}else{
		while(b!=1&&b!=0){
			b=a%b;
		}
		if(b==0){
			cout<<"NO\n";
		}else{
			cout<<"YES\n";
		}
	}
	return 0;
}