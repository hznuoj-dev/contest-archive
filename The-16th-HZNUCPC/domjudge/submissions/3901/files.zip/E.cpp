#include<bits/stdc++.h>
#define int long long
using namespace std;
//int numf[10010][27]={0};
//int numb[10010][27]={0};
int p[20010];
void solve(){
	string s,s2="$";
	cin>>s;
	for(int i=0;i<s.length();i++){
		s2+='#';
		s2+=s[i];
	}
	memset(p,0,sizeof(p));
	s2+='#';
	s2+='%';
	int ans=0;
	int mx=0,mid=0;
	for(int i=1;i<s2.length()-1;i++){
		if(i<mx){
			p[i]=min(mx-i,p[2*mid-i]);	
		}
		else p[i]=1;
		int len=0;
		char a,b,c,d;
		int last_c=0,last_b=0; 
		
		while(s2[i+p[i]]==s2[i-p[i]]) p[i]++;
			if(i+p[i]>mx){
				mx=i+p[i];
				mid=i;
			}
		
		if(s2[i+p[i]]>='a'&&s2[i+p[i]]<='z'&&s2[i-p[i]]>='a'&&s2[i-p[i]]<='z'){  //第一次终结位
			b=s2[i-p[i]];
			c=s2[i+p[i]];
			len=1;
			while(s2[i+p[i]+len]==s2[i-p[i]-len]) //
			{	
				if(s2[i+p[i]+len]==b) last_b=len;
				else if(s2[i+p[i]+len]==c) last_c=len;
				len++;
			}
			if(s2[i+p[i]+len]>='a'&&s2[i+p[i]+len]<='z'&&s2[i-p[i]-len]>='a'&&s2[i-p[i]-len]<='z') //第二次终结位
			{
				if((b==s2[i+p[i]+len]&&c==s2[i-p[i]-len])||(b==s2[i-p[i]-len]&&c==s2[i+p[i]+len])){
					len++;
					while(s2[i+p[i]+len]==s2[i-p[i]-len]) len++;
					ans=max(ans,(p[i]+len)/2*2-(s2[i]!='#'));
				} 
				else{
						len=max(last_b,last_c);
						len=max(0ll,len);
						ans=max(ans,(p[i]+len)/2*2-(s2[i]!='#'));
				}
			}
			else{
					len=max(last_b,last_c);
					len=max(0ll,len); 
					ans=max(ans,(p[i]+len)/2*2-(s2[i]!='#'));
				}
		}
		else
		{
			ans=max(ans,p[i]/2*2-(s2[i]!='#'));
		}
	}
    if(ans<=1) cout<<0<<'\n';
    else
 	cout<<ans<<'\n';
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	cin>>t;
	while(t--){
		solve();
	}
}