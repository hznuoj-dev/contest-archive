#include<iostream>
using namespace std;
int main()
{
	long long n,m;
	int flag=0;
	cin>>n>>m;
    if(n == 1 || m == 1){
    	cout << "YES" << endl;
    	return 0;
	}
	if(n <= m){
		cout << "NO" << endl;
		return 0;
	}
	while(m != 1 && m != 0){
		m = n % m;
	}
	for (long long i=2;i*i<=n;i++)
	{
		if (i>m)
		break;
		else
		{
			if (n%i==0)
			{
				flag=1;
				break;
			}
		}
	}
	if (m&&!flag)
	   cout << "YES" << endl;
	 else
	   cout << "NO" << endl;
	return 0;
}