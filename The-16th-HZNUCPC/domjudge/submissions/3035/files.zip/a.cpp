#include<bits/stdc++.h>
using namespace std;
int dx[4]={0,0,1,-1},dy[4]={1,-1,0,0};
int x[400],y[400];
int main()
{
	int n;
	scanf("%d",&n);
	for (int nm=1;nm<=n;nm++)
	{
		int k,map[400][400],cnt=0;
		scanf("%d",&k);
		for(int i=1;i<=k;i++)
		{  	int a,b,t; 
			scanf("%d%d%d",&a,&b,&t);
		    if(map[a][b]==-1)
		    	cnt--;
			map[a][b]=-1;
		    
			for(int j=0;j<4;j++)
			{
				int sx=a+dx[j];
				int sy=b+dy[j];
				if(map[sx][sy] != -1)
				{
					map[sx][sy] = -1;
					cnt++;
				}
				
			}
		}
		printf("%d\n",cnt);
		
	}
	return 0;
}
