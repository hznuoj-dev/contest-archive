#include<iostream>
using namespace std;

typedef long long LL;


bool fact(LL n, LL m);

int main()
{
	LL n = 0;
	LL m = 0;
	
	
	while(cin >> n >> m){
	if(n<m)cout<<"NO";
	else if (fact(n, m))
	{
		cout << "YES\n";
	}
	else
	{
		cout << "NO\n";
	}
}
	return 0;
}

bool fact(LL n, LL m)
{
	if (m == 1)
	{
		return 1;
	}
	if (n % m == 0)
	{
		return 0;
	}
	return fact(n, n % m);
}
