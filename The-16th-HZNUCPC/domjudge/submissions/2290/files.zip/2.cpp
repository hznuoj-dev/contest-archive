#include <iostream>
#include <queue>
#include <vector>
#include <cstring>
#include <stack>
#include <algorithm>
#define maxn 200010
#define maxm 200010
#define ll long long
using namespace std;

int n, m, k;

inline int trans(int x) { return x > n ? x - n : x + n; }

int fa[maxn];
void init_fa(int n) { for (int i = 1; i <= n; ++i) fa[i] = i; } 
int find(int x) { return fa[x] == x ? x : fa[x] = find(fa[x]); } 
void merge(int x, int y) { 
	x = find(x), y = find(y);
	if (x == y) return ;
	fa[x] = y;
}

bool vis[maxn];
vector<int> A[maxn]; int a[maxn];

int f[maxn], g[maxn], tp[maxn];
struct node { 
	int pre, id, flag;
} b[maxn];
void work() { 
	for (int i = 1; i <= 2 * n; ++i) A[find(i)].push_back(i), a[find(i)] += i <= n;
	vector<int> vec;
	for (int i = 1; i <= 2 * n; ++i) { 
		if (vis[i] || !A[i].size()) continue;
		vec.push_back(i);
		vis[find(trans(i))] = 1;
	} 
	sort(vec.begin(), vec.end(), [](const int &u, const int &v) {
		return A[u].size() < A[v].size(); 
	});
	f[0] = 1; int sum = 0;  
	for (auto i : vec) { 
		for (int j = 0; j <= sum; ++j) g[j] = f[j];
		int v = a[i];
		for (int j = 0; j <= sum; ++j) {  
			if (!g[j] || f[j + v]) continue; 
			f[j + v] = 1;
			b[j + v] = { j, i, 0 };
		} v = A[i].size() - a[i];
		for (int j = 0; j <= sum; ++j) {  
			if (!g[j] || f[j + v]) continue; 
			f[j + v] = 1;
			b[j + v] = { j, i, 1 };
		}
		sum += A[i].size();
	}
	
	if (!f[k]) return cout << "NO" << "\n", void();
	int now = k; vector<int> ans;
	while (now) { 
		node t = b[now];
		for (auto u : A[t.id]) 
			if (!t.flag && u <= n || t.flag && u > n) 
				ans.push_back(u > n ? u - n : u);
		now = t.pre;
	}
	cout << "YES" << "\n";
	sort(ans.begin(), ans.end());
	for (auto u : ans) cout << u << " "; cout << "\n";
}

int main() { 
	ios::sync_with_stdio(false);
	cin.tie(nullptr); cout.tie(nullptr); 
	
	
	cin >> n >> k >> m; init_fa(2 * n);
	for (int i = 1; i <= m; ++i) { 
		int o, x, y; cin >> o >> x >> y;
		merge(x, y + o * n), merge(x + n, y + (o ^ 1) * n);
	}
	for (int i = 1; i <= n; ++i)
		if (find(i) == find(i + n)) return cout << "NO" << "\n", 0;
	work();
	return 0; 
} 