#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define MOD 1000000007;
#define int long long
const int N=110;
int x[N],y[N];
int gcd(int a,int b)
{
	if(b!=0) return gcd(b,a%b);
	return a;
}
void solve(){
	int n;
	cin>>n;
	int ans=0;
	for(int i=1;i<=n;i++)
		cin>>x[i]>>y[i];
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				int res=0;
				int ax1=abs(x[i]-x[j]),ay1=abs(y[i]-y[j]);
				int ax2=abs(x[i]-x[k]),ay2=abs(y[i]-y[k]); 
				int ax3=abs(x[j]-x[k]),ay3=abs(y[j]-y[k]);
				res=gcd(ax1,ay1)+gcd(ax2,ay2)+gcd(ax3,ay3);
				ans=max(ans,res);
			}
		}
	}
	cout<<ans<<endl;
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	solve();
	return 0;
}