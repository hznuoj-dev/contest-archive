#include<stdio.h>

int main()
{
	int m,a,b;
	scanf("%d %d",&a,&b);
	m=2;
	while (m!=1&&m!=0)
	{
		m=a%b;
		b=m;
		
	}
	if (m==1)
	 printf("YES");
	else
	 printf("NO");
}