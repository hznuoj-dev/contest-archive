#include<bits/stdc++.h>
using namespace std;
typedef pair<int, int> PII;
#define int long long
#define rep(i, a, n) for(int i = a; i <= n; i++)
#define x first
#define y second
#define endl '\n'

const int p=1e9+7;

int C(int x) {
	return (x*(x-1)/2)%p;
}

string A,B;
int sa[27];
int sb[27];
int lena,lenb;
int numa=0,numb=0;

void solve() {
	cin>>A>>B;
	lena=A.length();
	lenb=B.length();
	for(int i=0;i<lena;i++) {
		sa[A[i]-'a'+1]++;
	}
	for(int i=0;i<lenb;i++) {
		sb[B[i]-'a'+1]++;
	}
	for(int i=1;i<=26;i++) {
		if(sa[i]) numa++;
		if(sb[i]) numb++;
	}
	if(numa<numb) {
		swap(numa,numb);
		for(int i=1;i<=26;i++) {
			swap(sa[i],sb[i]);
		}
		swap(A,B);
	}
	int sum=0,sum1=0;
	if(numa-numb==4) {
		for(int i=0;i<lena;i++) {
			if(sa[A[i]-'a'+1]==1&&sa[B[i]-'a'+1]!=0) {
				sum++;	
			}
		}
		cout<<C(sum)<<endl;
	} else if(numa==numb) {
		for(int i=0;i<lena;i++) {
			if(sa[B[i]-'a'+1]!=0&&sb[A[i]-'a'+1]!=0||sa[B[i]-'a'+1]==0&&sb[A[i]-'a'+1]==0) {
				sum++;
			}
		}
		cout<<C(sum)<<endl;
	} else if(numa-numb==2) {
		for(int i=0;i<lena;i++) {
			if(sa[B[i]-'a'+1]!=0&&sb[A[i]-'a'+1]!=0||sa[B[i]-'a'+1]==0&&sb[A[i]-'a'+1]==0) {
				sum++;
			}
			if(sa[A[i]-'a'+1]==1&&sa[B[i]-'a'+1]!=0) {
				sum1++;	
			}
		}
	//cout<<sum<<' '<<sum1<<endl;
		cout<<sum*sum1%p<<endl;
	} else {
		cout<<0<<endl;
	}
	
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	solve();
}