#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
typedef long long ll;
ll n, k;
void solve()
{
	cin >> n >> k;
	for(int i = 2; i <= sqrt(n); i++){
		if(n % i == 0 && k >= i) {
			cout << "NO\n";
			return;
		}
	}
	cout << "YES\n";
}

int main()
{
	IOS
	int T = 1;
//	cin >> T;
	while(T--) 
		solve();	
	return 0;
}