#include <bits/stdc++.h>
#define ll long long
using namespace std;

bool is_prime(long long x){
	for (int i=2;i<sqrt(x)+1;i++){
		if (x%i==0){
			return false;
		}
	}
	return true;
}
//bool check(ll n,ll m){		//n vote
//	if(m == 1 ) return true;
//	ll ans = n % m;
//	if(ans == 0) return false;
//	return check(n, ans); 
//}



int main(){
	ll  n,m;
	while(cin>>n>>m){
//		bool f=true;
//		if ((n > m && is_prime(n))){
//			cout<<"YES"<<endl;
//			continue;
//		} 
//		while(m!=1){
//			ll ans=n%m;
//			if (ans==0){
//				f=false;
//				break;
//			}
//			m=ans;
//		}
//		if (f) cout<<"YES"<<endl;
//		else cout<<"NO"<<endl;
//		if(__gcd(n,m) == 1) cout << "YES" << endl;
//		else cout <<"NO" << endl;
		if((is_prime(n) && n > m) || n == 1 || m == 1 || (n % 2 == 1 && m == 2)){
			cout<<"YES"<<endl;
		}else{
			cout<<"NO"<<endl;
		}
	}
	return 0;
}
