#include<bits/stdc++.h>
#define int long long
using namespace std;
const int p=1000000007;
int a[200005],b[200005],n,mp[27][27],ans,aa[27],bb[27],sza,szb;
string s1,s2;
int quick_pow(int x,int n) {
	int res=1;
	while (n) {
		if (n&1) res=res*x%p;
		x=x*x%p;
		n>>=1;
	}
	return res;
}
signed main(){
	cin >> s1 >> s2;
	n=s1.length();
	for (int i=0;i<s1.length();++i) {
		a[i+1]=s1[i]-'a'+1;
		aa[a[i+1]]++;
		if (aa[a[i+1]]==1) sza++;
	}
	for (int i=0;i<s2.length();++i) {
		b[i+1]=s2[i]-'a'+1;
		bb[b[i+1]]++;
		if (bb[b[i+1]]==1) szb++;
	}
	for (int i=1;i<=n;++i) {
		mp[a[i]][b[i]]++;
		//cout << "mp[" << a[i] << "][" << b[i] << "]=" << mp[a[i]][b[i]];
	}
	for (int i1=1;i1<=26;++i1) {
		for (int j1=1;j1<=26;++j1) {
			if (!mp[i1][j1]) continue;
			//cout << "i1=" << i1 << ",j1=" << j1 << endl;
			int k1=mp[i1][j1];
			mp[i1][j1]--;
			
			aa[i1]--;aa[j1]++;
			if (aa[j1]==1) sza++;
			if (aa[i1]==0) sza--;
			
			bb[i1]++;bb[j1]--;
			if (bb[j1]==0) szb--;
			if (bb[i1]==1) szb++;
			
			for (int i2=1;i2<=26;++i2) {
				for (int j2=1;j2<=26;++j2) {
					if (!mp[i2][j2]) continue;
					int k2=mp[i2][j2];
					mp[i2][j2]--;
					
					aa[i2]--;aa[j2]++;
					if (aa[j2]==1) sza++;
					if (aa[i2]==0) sza--;
					
					bb[i2]++;bb[j2]--;
					if (bb[j2]==0) szb--;
					if (bb[i2]==1) szb++;
					
					
					if (sza==szb) {
						//cout << "k1=" << k1 << ",k2=" << k2 << endl;
						ans+=k1*k2%p;
						ans%=p;
					}
					aa[i2]++;aa[j2]--;
					if (aa[i2]==1) sza++;
					if (aa[j2]==0) sza--;
					
					bb[i2]--;bb[j2]++;
					if (bb[i2]==0) szb--;
					if (bb[j2]==1) szb++;
					
					
					mp[i2][j2]++;
				}
			}
			
			aa[i1]++;aa[j1]--;
			if (aa[i1]==1) sza++;
			if (aa[j1]==0) sza--;
			
			bb[i1]--;bb[j1]++;
			if (bb[i1]==0) szb--;
			if (bb[j1]==1) szb++;
			
			
			
			mp[i1][j1]++;
		}
	}
	ans=ans*quick_pow(2,p-2)%p;
	cout << ans;
}
/*



aaaa
aaaa


abca
aaaa




*/