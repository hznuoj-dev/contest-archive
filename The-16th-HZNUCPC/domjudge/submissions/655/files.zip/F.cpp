#include <bits/stdc++.h>

using namespace std;
using LL = long long;

const LL N = 1000010;

int main()
{
	LL n, m;
	cin >> n >> m;
	
	if(n==1)
	{
		cout<<"YES"<<endl;
		return 0;
	}
	
	LL d=2;
	while(d<N)
	{
		if(n%d==0)break;
		d++;
	}
	
	if(d>=N)
	{
		d=n;
	}
	
	if (m >= d) cout << "NO\n";
	else
	{
		cout<<"YES"<<endl;
	}
}