#include<bits/stdc++.h>
using namespace std;
//#define int long long
const int N=3e5+5;
long long n,m,flag=1,x;
int main(){
cin>>n>>m;
if(m==1)
{
	cout<<"YES"<<"\n";
	return 0;
}
else if(n==2)
{
	cout<<"NO"<<"\n";
	return 0;	
}
for(int i=2;i<=sqrt(n);i++)
{
	if(n%i==0)
	{
		flag=0;
		break;
	}
}
if(flag==1)
{
	if(m==n)
	{
		cout<<"NO"<<"\n";
	}
	else
	{
		cout<<"YES"<<"\n";
	}
}
else
{
	for(int i=2;i<=n/2;i++)
	{
		if(n%i==0)
		{
			x=i;
			break;
		}
	}
	if(x>m)
	{
		cout<<"YES"<<"\n";
	}
	else
	{
		cout<<"NO"<<"\n";
	}
	
}	
}