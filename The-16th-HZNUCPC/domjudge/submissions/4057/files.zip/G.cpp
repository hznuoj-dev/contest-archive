#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 2e5 + 5;
struct TwoSat {
	int n, color;
	vector<vector<int> > G;
	vector<bool> ans;
	vector<int> col;
	TwoSat(int n) : n(n), color(1), G(2 * n), ans(n), col(n) {}
	void Or(int u, bool f, int v, bool g) { //至少一个为真
		G[2 * u + !f].push_back(2 * v + g);
		G[2 * v + !g].push_back(2 * u + f);
	}
	void Implies(int u, bool f, int v, bool g){
		Or(u, !f, v, g);
	}
	void Xor(int u, bool f, int v, bool g){
		Or(u, f, v, g); Or(u, !f, v, !g);
	}
	void Same(int u, bool f, int v, bool g) {
		Xor(u, !f, v, g);
	}
	void Must(int u, bool f) {
		Or(u, f, u, f);
	}
	bool work() {
		vector<int> id(2 * n, -1), dfn(2 * n, -1), low(2 * n, -1), stk;
		map<pair<int, int>, int> mp;
		int now = 0, cnt = 0;
		function<void(int)> tarjan = [&](int u) {
			stk.push_back(u);
			dfn[u] = low[u] = now++;
			for(auto v : G[u]) {
				if(dfn[v] == -1) {
					tarjan(v);
					low[u] = min(low[u], low[v]);
				}
				else if(id[v] == -1) {
					low[u] = min(low[u], dfn[v]);
				}
			}
			if(dfn[u] = low[u]) {
				int v;
				do {
					v = stk.back();
					stk.pop_back();
					id[v] = cnt;
				} while(v != u);
				++cnt;
			}
		};
		for(int i = 0; i < 2 * n; i++) {
			if(dfn[i] == -1) tarjan(i);
		}
		for(int i = 0; i < n; i++) {
			if(id[2 * i] == id[2 * i + 1]) return false;
			ans[i] = id[2 * i] > id[2 * i + 1];
			
//			mp[{dfn[2 * i], dfn[2 * i + 1]}]++;
			int id_a = dfn[2 * i], id_b = dfn[2 * i + 1];
			if(id_a > id_b) swap(id_a, id_b);
			if(mp.count({id_a, id_b})) {
				col[i] = mp[{id_a, id_b}];
			}
			else {
				mp[{id_a, id_b}] = color;
				col[i] = color;
				color++;
			}
		}   
		return true;
	}
};
int n, q, m;                          
void solve() {
	cin >> n >> q >> m;
	TwoSat ts(n);
	for(int i = 1; i <= m; i++) {
		int k, a, b;
		cin >> k >> a >> b;
		a--; b--;
		if(k == 0) {
			ts.Implies(a, 1, b, 1);
			ts.Implies(a, 0, b, 0);
		}
		else {
			ts.Implies(a, 1, b, 0);
			ts.Implies(a, 0, b, 1);
		}
	}
	if(ts.work()) {
		vector<vector<int> > col_to_id(ts.color + 1);
		vector<int> col_val(ts.color + 1), dp(ts.color + 1), from(ts.color + 1), use(ts.color + 1);
		vector<pair<int, int> > col_2(ts.color + 1);
		for(int i = 0; i < n; i++) {
			col_to_id[ts.col[i]].push_back(i);
			if(ts.ans[i] == 0) col_2[ts.col[i]].first++;
			else col_2[ts.col[i]].second++;
//			cout << i << " " << ts.col[i] << " " << ts.ans[i] << "\n";
		}
		for(int i = 1; i <= ts.color; i++) {
			if(col_2[i].second > col_2[i].first) {
				swap(col_2[i].first, col_2[i].second);
				for(auto it : col_to_id[i]) {
					ts.ans[it] = 1 - ts.ans[it];
				}
			}
		}
		for(int i = 1; i <= ts.color; i++) {
			q -= col_2[i].second;
			col_val[i] = col_2[i].first - col_2[i].second;
		}
		if(q < 0) {
			cout << "NO\n";
			return;
		}
		if(q == 0) {
			cout << "YES\n";
			for(int i = 0; i < n; i++) {
				if(ts.ans[i]) cout << i + 1 << " ";
			}
			return;
		}
		dp[0] = 1;
		for(int c = 1; c <= q; c++) {
			if(col_val[c] == 0) continue;
			for(int j = q; j >= col_val[c]; j--) {
				dp[j] = dp[j] | dp[j - col_val[c]];
				if(dp[j - col_val[c]]) {
					use[j] = c;
					from[j] = j - col_val[c];
				}
			}
		}
		if(!dp[q]) {
			cout << "NO\n";
			return;
		}
		int idx = q;
		while(idx) {
			int c = use[idx];
			for(auto it : col_to_id[c]) {
				ts.ans[it] = 1 - ts.ans[it];
			}
			idx = from[idx];
		}
		cout << "YES\n";
		for(int i = 0; i < n; i++) {
			if(ts.ans[i]) cout << i + 1 << " ";
		}
		return;
	}
	else {
		cout << "NO\n";
	}
}
int main() {
	ios::sync_with_stdio(false);
	int T = 1;
	while(T--) {
		solve();
	}
	return 0;
}
/*
4 2 4
1 1 3
1 2 4
0 3 4
0 1 2

0 0 1 1

13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13

2 1 2
1 1 2
0 2 1
*/