#include<bits/stdc++.h>
using namespace std;
#define int long long
const int inf=1e15;
const int N=1e6+5;
const int mod=1e9+7;
int n,m,sum;
int a[25][25];
void run(){
	cin>>n;
	sum=0;
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			a[i][j]=0;
		}
	}
	while(n--){
		int x,y,z;
		cin>>x>>y>>z;
		if(z==1){
			a[x][y]=1;
		}
		else{
			a[x][y]=2;
		}
	}
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(a[i][j]==1){
				if(a[i+1][j]==0&&i+1<=19){
					sum++;
				}
				if(a[i-1][j]==0&&i-1>0){
					sum++;
				}
				if(a[i][j+1]==0&&j+1<=19){
					sum++;
				}
				if(a[i][j-1]==0&&j-1>0){
					sum++;
				}
			}
		}
	}
	cout<<sum<<'\n';
}
signed main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int t=1;
	cin>>t;
	while(t--){
		run();
	}
	return 0;
}