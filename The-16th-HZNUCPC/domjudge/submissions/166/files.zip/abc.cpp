#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using pt = complex<long long>;
#define x real()
#define y imag()
#define int ll
int point_covered(pt a, pt b) {
	assert(a != b);
	if (a.x == b.x) {
		return abs(a.y - b.y) - 1;
	}
	if (a.y == b.y) {
		return abs(a.x - b.x) - 1;
	}
	
	return __gcd(abs(a.y - b.y), abs(a.x - b.x)) - 1;
}

int cross(pt a, pt b) {
	return a.x * b.y - a.y * b.x;
}

int same_line(pt a, pt b, pt c) {
	return cross(b - a, c - a) == 0;
}

signed main() {
	int n, m;
	cin >> n >> m;
	if (n == 1 || m == 1) {
		cout << "YES\n";
	} else if (n <= m || n % m == 0) {
		cout << "NO\n";
	} else {
		for (int i = 2; i * i <= n; ++i) {
			if (n % i == 0) {
				if (i <= m || n / i <= m) {
			
					cout << "NO\n";
					return 0;
				}	
			}
		}
		cout << "YES\n";
	}
}


/*
4
0 0
1 1
2 4
4 2

4
1 1
2 2
3 3
2 4
*/