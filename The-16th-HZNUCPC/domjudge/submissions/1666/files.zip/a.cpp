#define DEBUG
#include <bits/stdc++.h>

using namespace std;
const int MOD = 1000000007;
const int INV2 = 500000004;
#define int long long
#define endl '\n'

int q_pow(int a, int b) {
    int res = 1;
    for (; b; b >>= 1) {
        if (b & 1) res = res * a % MOD;
        a = a * a % MOD;
    }
    return res;
}

void solve() {
    string a, b; cin >> a >> b;
    int n = (int)a.size();
    vector<int> cntA(26);
    vector<int> cntB(26);
    vector<int> dis(n + 1), fuck(5);
    int szA = 0, szB = 0;
    for (int i = 0; i < n; i ++ ) {
        cntA[a[i] - 'a'] ++;
        cntB[b[i] - 'a'] ++;
    }
    for (int i = 0; i < 26; i ++ ) {
        if (cntA[i] > 0) szA ++;
        if (cntB[i] > 0) szB ++;
    }
    for (int i = 0; i < n; i ++ ) {
        if (cntA[a[i] - 'a'] == 1) dis[i] ++;
        if (cntA[b[i] - 'a'] == 0) dis[i] --;
        if (cntB[a[i] - 'a'] == 0) dis[i] ++;
        if (cntB[b[i] - 'a'] == 1) dis[i] --;
        fuck[dis[i] + 2] ++;
    }
    // for (int i = 0; i < n; i ++ ) cout << dis[i] << ' ';
    // cout << endl;
    // for (int i = 0; i < 5; i ++ ) cout << fuck[i] << ' ';
    // cout << endl;
    int res = 0;
    for (int i = 0; i < n; i ++ ) {
        int d = szB - szA + dis[i];
        if (abs(d) > 2) continue;
        d = -d;
        res = (res + fuck[d + 2] - (dis[i] == d) + MOD) % MOD;
        // cout << i << ":" << res << endl;
    }
    // cout << q_pow(2, MOD - 2) << endl;
    cout << res * INV2 % MOD << endl;
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    // cin >> T;
    // while (T--)
    {solve(); }
#ifdef DEBUG
    cerr << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}