#include <bits/stdc++.h>

using namespace std;
using LL = long long;
int main()
{
	int T;
	cin >> T;
	while(T --)
	{
		int ans = 0;
		string s, s2 = "%$";
		cin >> s;
		for(int i = 0 ; i < s.size() ; ++ i)
		{
			s2 += '#';
			s2 += s[i];
		}
		s2 += "#&*";
//		cout <<s2 << endl;
		for(int i = 2 ; i < s2.size() - 2 ; ++ i)
		{
			unordered_map<char, int> st;
			if(s2[i] == '#')	//偶数回文串
			{
				int l = i - 1, r = i + 1;
				int f_l, f_r, s_l, s_r;
				vector<int> ve;
				while(s2[l] == s2[r]) ans = max(ans, i - l), l --, r ++;
//				cout <<ans << endl;
				if(!st[s2[l]])
				{
					st[s2[l]] ++;
					ve.push_back(s2[l]);
				}
				if(!st[s2[r]])
				{
					st[s2[r]] ++;
					ve.push_back(s2[r]);
				}
				// f_l = l, f_r = r;
				l --, r ++;
				while(s2[l] == s2[r]) l --, r ++;
				if(!st[s2[l]])
				{
					st[s2[l]] ++;
					ve.push_back(s2[l]);
				}
				if(!st[s2[r]])
				{
					st[s2[r]] ++;
					ve.push_back(s2[r]);
				}
				if(ve.size() == 2)
				{
					l --, r ++;
					while(s2[l] == s2[r] && s2[l] != '&') l --, r ++;
					ans = max(ans, i - l - 1);
				}
			}
			else //奇数回文串
			{
				st[s2[i]] ++;
				vector<int> ve;
				ve.push_back(s2[i]);
				
				int l = i - 1, r = i + 1;
				int f_l, f_r, s_l, s_r;
				while(s2[l] == s2[r]) ans = max(ans, i - l), l --, r ++;
				if(!st[s2[l]])
				{
					st[s2[l]] ++;
					ve.push_back(s2[l]);
				}
				if(!st[s2[r]])
				{
					st[s2[r]] ++;
					ve.push_back(s2[r]);
				}
				if(ve.size() == 2)
				{
					l --, r ++;
					while(s2[l] == s2[r]) l --, r ++;
					ans = max(ans, i - l - 1);
				}
				else if(ve.size() == 3)
				{
					l --, r ++;
					while(s2[l] == s2[r]) l --, r ++;
					if(!st[s2[l]])
					{
						st[s2[l]] ++;
						ve.push_back(s2[l]);
					}
					if(!st[s2[r]])
					{
						st[s2[r]] ++;
						ve.push_back(s2[r]);
					}
					l --, r ++;
					if(ve.size() == 3 && st[s2[i]] == 1)
					{
						while(s2[l] == s2[r]) l --, r ++;
						ans = max(ans, i - l - 1);
					}
				}
			}
//			if(ans == 49)
//			{
//				cout << i <<endl;
//			}
		}
		if(ans > 1) cout << ans << '\n';
		else cout << "0\n";
	}
	
	
	
}