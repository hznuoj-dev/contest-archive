#include<bits/stdc++.h>
using namespace std;
#define int long long
const int mod = 1e9 + 7;
const int N = 110;

void solve(){
	string str, str1;
	cin >> str >> str1;
	int a = 0, n = str.length();
	for(int i = 0; i < n; i++){
		if(str[i] == str1[i]){
			a ++;
		}
	}
	int ans = 1;
	if(n >= 4 && n - a <= 4){
		if(n - a == 1){
			ans = a * (a - 1) * (a - 2) / 3;
		}else if(n - a == 2){
			ans = a * (a - 1);
		}else if(n - a == 3){
			ans = 2 * a;
		}else{
			ans = 2;
		}
	}
	if(n == 2 || n == 1){
		cout << "1\n";
	}else if(n - a == 1){
		cout << max(ans, n * (n - 1) / 2) % mod << "\n";
	}else if(n - a == 2){
		ans = max(ans, a * (a - 1) / 2 + 1);
		if(a){
			ans = max(ans, (n * (n - 1) / 2 - a * (a - 1) / 2 - 1));
		}
		ans %= mod;
		cout << ans << "\n";
	}else{
		cout << max(ans, a * (a - 1) / 2) % mod << "\n";
	}     
	                                                 
}
signed main(){
	int t = 1;
//	cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
