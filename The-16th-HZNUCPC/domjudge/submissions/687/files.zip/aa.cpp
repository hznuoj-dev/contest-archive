#include <bits/stdc++.h>
using namespace std;
const int manx=1e5+10;
#define int long long
int gcd(int a,int b){
	if(a%b==0) return b;
	return gcd(b,a%b);
}
int d[105][105];
struct node{
	int  x,y;
}a[105];
int point(int i,int j){
	int ans;
	if(a[i].x==a[j].x){
		ans=abs(a[i].y-a[j].y);
	}else if(a[i].y==a[j].y){
		ans=abs(a[i].x-a[j].x);
	}else{
		ans=gcd(abs(a[i].x-a[j].x),abs(a[i].y-a[j].y));
	}
	
	
	return ans+1;
}
bool check(int i,int j,int k){
	if(a[i].x==a[j].x&&a[i].x==a[k].x){
		return 0;
	}else if(a[i].y==a[j].y&&a[i].y==a[k].y){
		return 0;
	}else if((a[j].y-a[i].y)*(a[k].x-a[i].x)==(a[k].y-a[i].y)*(a[j].x-a[i].x)){
		return 0;
	}
	return 1;
}
int solve(int i,int j,int k){
	if(!check(i,j,k)){
		return 0;
	}else{
		return d[i][j]+d[i][k]+d[j][k]-3;
	}
}
signed main(){
	int n;
	scanf("%lld",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld %lld",&a[i].x,&a[i].y);
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			d[i][j]=d[j][i]=point(i,j);
		}
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				ans=max(ans,solve(i,j,k));	
			}
		}
	}
	printf("%lld\n",ans);
	return 0;
}
