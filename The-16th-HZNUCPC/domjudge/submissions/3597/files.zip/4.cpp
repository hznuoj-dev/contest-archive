#include <iostream>
using namespace std;
int main()
{
	int i,h;
	long n,m;
	cin>>n>>m;
	h=0;
	if(m<n)
	{
		for(i=2;i<=m;i++)
		{
			if(n%i==0)
			{
				h=1;
				break;
			}
		}
	}
	else h=1;
	if(h==0||n==1)cout<<"YES\n";
	else cout<<"NO\n";
}