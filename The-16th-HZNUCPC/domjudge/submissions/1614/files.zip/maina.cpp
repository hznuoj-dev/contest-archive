#include <bits/stdc++.h>
#define N (int)110
#define dwan ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define int long long
typedef long long ll;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
typedef struct{
	int x,y;
}Pos; 
Pos pos[N];
void solve(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>pos[i].x>>pos[i].y;
	}
	int Max=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				int cnt=0;
				int num;
				int cha_x,cha_y;
				cha_x = (int)fabs(pos[i].x-pos[j].x);
				cha_y = (int)fabs(pos[i].y-pos[j].y);
				num = gcd(cha_x,cha_y);
				num--;
				cnt+=num;
				
				cha_x = (int)fabs(pos[i].x-pos[k].x);
				cha_y = (int)fabs(pos[i].y-pos[k].y);
				num = gcd(cha_x,cha_y);
				num--;
				cnt+=num;
				
				cha_x = (int)fabs(pos[j].x-pos[k].x);
				cha_y = (int)fabs(pos[j].y-pos[k].y);
				num = gcd(cha_x,cha_y);
				num--;
				cnt+=num;
				Max=max(Max,cnt);
			}
		}
	}
	cout<<Max+3<<endl;
}
signed main(int argc, char** argv) {
	dwan;
	int t = 1;
	//cin>>t;
	while(t--){
		solve();
	}
}