#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef pair<int,int>PII;
#define pb push_back
void solve(){
    int n,m;
    cin>>n>>m;
    if(m>=n){
        cout<<"NO"<<endl;
    }else{
        if(n%2==0){
            if(m==1)cout<<"YES"<<endl;
            else cout<<"NO"<<endl;
        }else{
            int cur=m;
            while(m!=1){
                m=n%m;
                if(m==0){
                    cout<<"NO"<<endl;
                    return ;
                }
            }
            cout<<"YES"<<endl;
        }
    }
    return ;
} 
signed main(){
    int t=1;
    while(t--){
        solve();
    }
    return 0;
}