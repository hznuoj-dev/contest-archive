#include "bits/stdc++.h"
using namespace std;

int main(){
	long long n,m;
	cin >> n >> m;
	if(n == 1 || m == 1){
		cout << "YES";
		return 0;
	}
	while(m > 1){
		m = n % m;
	}
	if(m == 1) cout << "YES";
	else puts("NO");
	return 0;
}
