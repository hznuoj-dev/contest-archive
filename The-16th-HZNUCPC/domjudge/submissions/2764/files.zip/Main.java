package oj;

import java.util.Scanner;

public class Main {
	public static void main(String[] args){
		Scanner in = new Scanner(System.in);
		long caipan = in.nextLong();
		long num = in.nextLong();
		if(num >= caipan){
			System.out.println("NO");
			System.exit(0);
		}
		while(Math.max(caipan, num) % Math.min(caipan, num) != 1){
			if(caipan % num == 0){
				System.out.println("NO");
				break;
			} else {
				if(Math.max(caipan, num) % Math.min(caipan, num) != 1){
					caipan = caipan % num;
				}
			}
		}
		if(Math.max(caipan, num) % Math.min(caipan, num) == 1){
			System.out.println("YES");
		}
	}
}
