#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int N= 1e5 + 10,mod=1e9+7;

#define int long long
int cnt[50][50];
int cnta[50],cntb[50];
int qmi(int a,int b,int p)
{
	int res=1;
	while(b)
	{
		if(b&1)res=res*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return res;
}

signed main()
{
	string a,b;
	cin>>a>>b;
	set<char>c,d;
	for(int i=0;i<a.size();i++)
	{
		int x=a[i]-'a',y=b[i]-'a';
		cnt[x][y]++;
		c.insert(a[i]);
		d.insert(b[i]);
		cnta[x]++,cntb[y]++;
	}
	int dt=c.size()-d.size();
//	cout<<dt<<endl;
	int ans=0;int p=0;
	for(int i=0;i<=25;i++)
	{
		for(int j=0;j<=25;j++)
		{
			for(int k=0;k<=25;k++)
			{
				for(int u=0;u<=25;u++)
				{
					p=0;
					int x=cnta[i],y=cntb[j];
					if(x==1)
					{
						p--;
					}
					if(cntb[i]==0)p--;
					if(y==1)p++;
					if(cnta[j]==0)p++;
					cnta[i]--,cnta[j]++;
					cntb[i]++,cntb[j]--;
					x=cnta[k],y=cntb[u];
					if(x==1)
					{
						p--;
					}
					if(cntb[k]==0)p--;
					if(y==1)p++;
					if(cnta[u]==0)p++;
					cnta[i]++,cnta[j]--;
					cntb[i]--,cntb[j]++;
					
					if(p==-dt)
					{
						if(i==k&&j==u)ans=(ans+(cnt[i][j]*(cnt[k][u]-1)%mod)*qmi(2,mod-2,mod)%mod)%mod;
						else 
						ans=(ans+cnt[i][j]*cnt[k][u]%mod*qmi(2,mod-2,mod)%mod)%mod;
						//cout<<p<<" "<<dt<<endl;
					//	cout<<i<<" "<<j<<" "<<k<<" "<<u<<" "<<cnt[i][j]<<" "<<cnt[k][u]<<" ";
					//	cout<<ans<<endl;
					}
				}
			}
		}
	}
	cout<<ans<<endl;
}