#include<bits/stdc++.h>
using namespace std;
long long n , m;

int main (){
	cin >> n >> m;
	if(n <= m){
		cout << "NO" << endl;
	}else {
		while(1){
			m = n % m;
			if(m == 0){
				cout << "NO" << endl;
				break;
			}else if(m == 1){
				cout << "YES" << endl;
				break;
			}
		}
	}
	return 0;
}