#include<bits/stdc++.h>
using namespace std;
const int N=1e6+7;
typedef long long ll;
ll T,f[100][100];
void run(){
	ll n,x,y,c;
	cin>>n;
	for(ll i=0;i<=99;i++){
		for(ll j=0;j<=99;j++){
			f[i][j]=0;
		}
	}
	for(ll i=1;i<=n;i++){
		cin>>x>>y>>c;
		f[x][y]=c;
	}
	ll ans=0;
	for(ll i=1;i<=19;i++){
		for(ll j=1;j<=19;j++){
			if(f[i][j]==1){
				if(f[i-1][j]==0&&i-1>=1){
					ans++;
				}
				if(f[i][j-1]==0&&j-1>=1){
					ans++;
				}
				if(f[i+1][j]==0&&i+1<=19){
					ans++;
				}
				if(f[i][j+1]==0&&j+1<=19){
					ans++;
				}
			}
		}
	}
	cout<<ans<<'\n';
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	cin>>T;
	while(T--){
		run();
	}
}