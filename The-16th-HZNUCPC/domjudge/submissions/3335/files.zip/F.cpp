#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll T;
ll qu(ll x,ll y){
	ll a=x/y;
	if(a==0){
		return y;
	}
	ll b=x-a*y;
	return b;
}
void run(){
	ll n,m;
	cin>>n>>m;
	if(n==1|| m ==1){
		cout<<"YES"<<'\n';
		return ;
	}
	ll c = m;
	while(c!=0){
		c =qu(n,c);
		cout << c << '\n';
		if(c == 1){
			cout << "YES" << '\n';
			return ;
		}
	}
	cout << "NO" << '\n';
	return ;
	
}
int main(){
	ios_base::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	T=1;
	while(T--){
		run();
	}
}