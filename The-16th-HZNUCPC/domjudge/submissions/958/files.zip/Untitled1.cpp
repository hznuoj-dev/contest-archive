#include<bits/stdc++.h>
using namespace std;
int Map[21][21];
int ans=0;
bool check1(int x,int y){
	if(Map[x-1][y]==1&&Map[x+1][y]==1&&Map[x][y+1]==1&&Map[x][y-1]==1){
		return true;
	}else{
		return false;
	}
}
void check2(int x,int y){
	if(!Map[x-1][y])ans++;
	if(!Map[x][y-1])ans++;
	if(!Map[x][y+1])ans++;
	if(!Map[x+1][y])ans++;
}
int main(){
	int t;
	cin>>t;
	while(t--){
		ans=0;
		for(int i=0;i<=20;i++){
			for(int j=0;j<=20;j++){
				if(i==0||j==0||j==20||i==20){
					Map[i][j]=1;
				}
			}
		}
		int n;
		cin>>n;
		while(n--){
			int x,y,c;
			cin>>x>>y>>c;
			Map[x][y]=c;
			if(c==2&&check1(x,y)){
				Map[x][y]=0;
			}
		}
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(Map[i][j]==1){
					check2(i,j);
				}
			}
		}
		cout<<ans<<'\n';
	}
	return 0;
}