#include <bits/stdc++.h>
using namespace std;
template<class T,class... A> void odn(T&& x, A&&... a) {cout<<x; (int[]){(cout<<' '<<a,0)...}; cout<<'\n';}
const int maxn = 5e3+5;
// bool pref[maxn][26], suff[maxn][26];
void solve() {
    string s; cin>> s;
    int n =s.size();
    // memset(pref, 0, sizeof(pref));
    // memset(suff, 0, sizeof(suff));
    // for (int i = 0; i < n; i++)
    //     for (int j = 0; j < 26; j++)
    //         pref[i][j] = (i==0?false:pref[i-1][j]) || s[i]-'a'==j;
    // for (int i = n-1; i >= 0; i--)
    //     for (int j = 0; j < 26; j++)
    //         suff[i][j] = (i==n-1?false:suff[i+1][j]) || s[i]-'a'==j;
    int ans = 0;
    for (int m = 0; m < n; m++) {
        vector<pair<int,int>> difp;
        for (int len = 3; len <= 1 + min(2*m, 2*(n-m-1)); len += 2) {
            int l = m-len/2, r = m+len/2;
            if (s[l] != s[r]) difp.push_back({l, r});
            if (difp.size() == 0) {
                ans = max(ans, len);
            } else if (difp.size() == 1) {
                char c = s[difp[0].first];
                bool cnt = s[m] == c; // || (l-1>=0 && pref[l-1][c-'a']) || (r+1<n && suff[r+1][c-'a']);
                c = s[difp[0].second];
                cnt |= s[m] == c; // || (l-1>=0 && pref[l-1][c-'a']) || (r+1<n && suff[r+1][c-'a']);
                if (cnt) ans = max(ans, len); 
            } else if (difp.size() == 2) {
                if ((s[difp[0].first] == s[difp[1].second] && s[difp[1].first] == s[difp[0].second]) || 
                    (s[difp[0].first] == s[difp[1].first] && s[difp[0].second] == s[difp[1].second]))
                    ans = max(ans, len);
            } else break;
            // odn(m, len, ans);
        }
    }
    for (int m = 0; m < n; m++) {
        vector<pair<int,int>> difp;
        for (int len = 2;; len += 2) {
            int l = m-len/2+1, r = m+len/2;
            if (l < 0 || r >= n) break;
            if (s[l] != s[r]) difp.push_back({l, r});
            if (difp.size() == 0) {
                ans = max(ans, len);
            } else if (difp.size() == 1) {
                // char c = s[difp[0].first];
                // bool cnt = s[m] == c; // || (l-1>=0 && pref[l-1][c-'a']) || (r+1<n && suff[r+1][c-'a']);
                // c = s[difp[0].second];
                // cnt |= s[m] == c; // || (l-1>=0 && pref[l-1][c-'a']) || (r+1<n && suff[r+1][c-'a']);
                // if (cnt) ans = max(ans, len); 
            } else if (difp.size() == 2) {
                if (s[difp[0].first] == s[difp[1].second] && s[difp[1].first] == s[difp[0].second])
                    ans = max(ans, len);
            } else break;
            // odn(m, len, ans);
        }
    }
    odn(ans);
}
signed main() {
    // freopen("i", "r", stdin);
    // cin.tie(0)->sync_with_stdio(0);
    int T; cin>> T;
    while (T--)
        solve();
}