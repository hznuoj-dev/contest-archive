#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int mod=1e9+7;
int s[30][30];
int ss[30][30];
int numa[30];
int numb[30];
int dp[30][30][30][30];
int ans;
int dis=0;
int n;
int cnta=0,cntb=0;
void dfs(int now,int a,int b,int c,int d)
{
	if(now==4)
	{
//		cout<<now<<endl;
		int zs,ys,zx,yx;
		if(a==0) zs=0;
		else if(a==1) zs=-1;
		else if(a==2) zs=1;
		
		if(b==0) ys=0;
		else if(b==1) ys=-1;
		else if(b==2) ys=1;
		
		if(c==0) zx=0;
		else if(c==1) zx=1;
		else if(c==2) zx=-1;
		
	 	if(d==0) yx=0;
		else if(d==1) yx=1;
		else if(d==2) yx=-1;
		
		if(zs+ys+zx+yx!=dis) return ;
		for(int i=0;i<26;i++)
		{
			for(int j=0;j<26;j++)
			{
				if(!s[i][j]) continue;
				numa[i]--;
				numb[j]--;
				numa[j]++;
				numb[i]++;
				int aa,bb;
				if(numa[i]>0&&numa[j]==1) aa=1;
				else if(numa[i]==0&&numa[j]>1) aa=2;
				else aa=0;
				
				if(numb[j]==0&&numb[i]>1) bb=2;
				else if(numb[i]==1&&numb[j]>0) bb=1;
				else bb=0;
				
				if(aa!=a||bb!=c)
				{
					numa[i]++;
					numb[j]++;
					numa[j]--;
					numb[i]--;
					continue;
				}
				for(int k=0;k<26;k++)
				{
					for(int e=0;e<26;e++)
					{
						if(!s[k][e]||dp[i][j][k][e]) continue;
						numa[k]--;
						numb[e]--;
						numa[e]++;
						numb[k]++;
						int cc,dd;
						if(numa[k]&&numa[e]==1) cc=1;
						else if(numa[k]==0&&numa[e]>1) cc=2;
						else cc=0;
						
						if(numb[e]==0&&numb[e]>1) dd=2;
						else if(numb[k]==1&&numb[k]>0) dd=1;
						else dd=0;
						
						if(cc!=b||dd!=d)
						{
							numa[k]++;
							numb[e]++;
							numa[e]--;
							numb[k]--;
							continue;
						}
						if((i==k)&&(j==e))
						{
							ans=(ans+(s[i][j]*(s[i][j]-1))/2)%mod;	
						}
						else 
						{
							ans=(ans+s[i][j]*s[k][e]%mod)%mod;	
						}
//						cout<<aa<<" "<<bb<<" "<<cc<<" "<<dd<<endl;
//						cout<<(char)(i+'a')<<" "<<(char)(j+'a')<<" "<<(char)(k+'a')<<" "<<(char)(e+'a')<<" "<<s[i][j]<<" "<<s[k][e]<<endl;
						dp[i][j][k][e]=dp[k][e][i][j]=1;
						numa[k]++;
						numb[e]++;
						numa[e]--;
						numb[k]--;
					}
				}
				numa[i]++;
				numb[j]++;
				numa[j]--;
				numb[i]--;
			}
		}
		return;
	}
	if(now==0)
	{
		dfs(1,0,-1,-1,-1);
		dfs(1,1,-1,-1,-1);
		dfs(1,2,-1,-1,-1);
	}
	else if(now==1)
	{
		dfs(2,a,0,-1,-1);
		dfs(2,a,1,-1,-1);
		dfs(2,a,2,-1,-1);
	}
	else if(now==2)
	{
		dfs(3,a,b,0,-1);
		dfs(3,a,b,1,-1);
		dfs(3,a,b,2,-1);
	}
	else 
	{
		dfs(4,a,b,c,0);
		dfs(4,a,b,c,1);
		dfs(4,a,b,c,2);
	}
}
void solve()
{
	ans=0;
	string a,b;
	cin>>a>>b;
	cnta=0,cntb=0;
	n=a.size();
	for(int i=0;i<n;i++)
	{
		numa[a[i]-'a']++;
		numb[b[i]-'a']++;
		s[a[i]-'a'][b[i]-'a']++;
		ss[b[i]-'a'][a[i]-'a']++;
	}
	for(int i=0;i<26;i++)
	{
		if(numa[i])cnta++;
		if(numb[i]) cntb++;
	}
	if(cntb>cnta)
	{
		swap(cntb,cnta);
		swap(a,b);
		swap(numa,numb);
		swap(ss,s);
	}
	dis=abs(cnta-cntb);
	dfs(0,-1,-1,-1,-1);
	cout<<ans<<endl;
}
signed main()
{
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	solve();
	return 0;
}