#include<bits/stdc++.h>
#define pb push_back
const int N=1e5+10;
using namespace std;
struct node{int x,y,w;}a[N];
bool cmp(node a,node b){return a.w<b.w;}
vector<int>p[N];
int n,q,m,k,fa[N],fb[N],sz[N],vis[N],used[N],b[N],c[N],t;
bitset<N>f;
bool flag=true;
int find(int x){return x==fa[x]?x:fa[x]=find(fa[x]);}
int main(){
	scanf("%d%d%d",&n,&q,&m);
	for(int i=1;i<=n;i++)
		fa[i]=i,fb[i]=0,sz[i]=1;
	for(int i=1;i<=m;i++)
	{
		int op,x,y;
		scanf("%d%d%d",&op,&x,&y);
		x=find(x),y=find(y);
		fb[x]=find(fb[x]);
		fb[y]=find(fb[y]);
		if(op)
		{
			//x!=y
			if(x==y)
			{
				flag=false;
				continue;
			}
			if(fb[x]==y)
			{
				continue;
			}
			//x - fb[y]
//			cout << x << " " << y << " " << fb[x] << " " << fb[y] << endl;
			if(fb[y])
			{
				fa[fb[y]]=x;
				sz[x]+=sz[fb[y]];
			}
			fb[y]=x;
			//fb[x] - y
			if(fb[x])
			{
				fa[y]=fb[x];
				sz[fb[x]]+=sz[y];
			}
			else
				fb[x]=y;
		}
		else
		{
			//x=y
			if(fb[x]==y)
			{
				flag=false;
				continue;
			}
			if(x==y)
			{
				continue;
			}
			fa[x]=y,sz[y]+=sz[x];
			if(fb[x])
			{
				if(fb[y])
				{
					fa[fb[x]]=fb[y];
					sz[fb[y]]+=sz[fb[x]];
				}
				else fb[y]=fb[x];
			}
		}
				
//			for(int j=1;j<=n;j++)
//				cout << sz[j] << (j==n?'\n':' ');
	}
	if(!flag)
	{
		puts("NO");
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		fa[i]=find(i);
		p[fa[i]].pb(i);
	}
	int s=0;
	for(int i=1;i<=n;i++)
		if(fa[i]==i&&!vis[i])
		{
			k++;
			fb[i]=find(fb[i]);
			vis[i]=1,vis[fb[i]]=1;
			if(sz[i]<=sz[fb[i]])
			{
				//x <- i,y <- fb[i]
				a[k].x=i,a[k].y=fb[i];
				s+=sz[i];
				a[k].w=sz[fb[i]]-sz[i];
			}
			else
			{
				//x <- fb[i],y <- i
				a[k].x=fb[i],a[k].y=i;
				s+=sz[fb[i]];
				a[k].w=sz[i]-sz[fb[i]];
			}
//			cout <<"check:"<<i<<" " << fb[i]<<" "<< sz[i] << " " << sz[fb[i]] << endl;
		}
	if(s>q)
	{
		puts("NO");
		return 0;
	}
	int qqq=q;
	q-=s;
	sort(a+1,a+1+k,cmp);
//	cout<<"Xmy"<<endl;
//	cout<<q<<endl;
//	for (int i=1;i<=k;i++) cout<<a[i].w<<endl;
//	cout<<"Xmy"<<endl;
	for (int i=1;i<=k;i++) b[a[i].w]++;
	f[0]=1;
	for (int i=1;i<=q;i++) f[i]=0;
	for (int i=1;i<=q;i++){
		t=b[i];
		int j=1;
		while (t){
			if (j>t) j=t;
			f|=f<<j*i;
			t-=j;
			j*=2;
		}
	}
//	for (int i=0;i<=q;i++) cout<<f[i]<<endl;
	if (f[q]){
		int now=q;
		for (int i=1;i<=q;i++){
			t=b[i];
			int j=1;
			while (t){
				if (j>t) j=t;
				if (now>=i*j && f[now-i*j]){
					now-=i*j;
					c[i]+=j;
				}
				t-=j;
				j*=2;
			}
		}
//		cout<<"Xmy"<<endl;
//		for (int i=1;i<=q;i++) cout<<c[i]<<endl;
//		puts("-----------------");
		puts("YES");
		int rr=0;
		for(int i=1;i<=k;i++)
		{
			if(c[a[i].w])
			{
				c[a[i].w]--;
				//y
				for(auto r:p[a[i].y])
				{
					rr++;
					printf("%d%c",r,rr==qqq?'\n':' ');
				}
			}
			else
			{
				//x
				for(auto r:p[a[i].x])
				{
					rr++;
					printf("%d%c",r,rr==qqq?'\n':' ');
				}
			}
		}
	}
	else
	{
		puts("NO");
		return 0;
	}
	return 0;
}