#include<bits/stdc++.h>
using namespace std;
#define int long long
int n,m;
signed main()
{
	cin >> n >> m;
	if(n == 1 || m == 1){
		cout << "YES\n";
		return 0;
	}
	if(n <= m){
		cout << "NO\n";
		return 0;
	}
	int flag = -1;
	for(int i = 2; i <= sqrt(n); ++i){
		if(n % i == 0){
			flag = i;
			break;
		}
	}
	if(flag == -1){
		cout << "YES\n";
	}else{
		if(flag <= m)cout << "NO\n";
		else cout << "YES\n";
	}
	return 0;
}