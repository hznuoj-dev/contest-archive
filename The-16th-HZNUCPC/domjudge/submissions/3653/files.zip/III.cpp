#include<bits/stdc++.h>
using namespace std;

#define int long long
#define ct(x) cout<<x<<'\n'
#define dg(x)  cout<<#x<<'='<<x<<'\n';
#define pii  pair<int,int> 
#define N 6000
#define double long double
#define ios ios::sync_with_stdio(0),cin.tie(0),cout.tie(0)
#define endl '\n'


/*
4
abccab
ihi
stfgfiut
palindrome


*/

int dp[N][N][3];
void solve(){
   string s;cin>>s;
   int n=s.size();
 
   for(int i=0;i<=n;i++)
     for(int j=0;j<=n;j++)
       for(int k=0;k<=1;k++){
       	 dp[i][j][0]=0;
       	  dp[i][j][1]=0;
       	   dp[i][j][2]=0;
	   }
      
       map<pair<int,int>,pair<char,char>> mp;
   
   int ans=0;
   
   for(int i=1;i<=n;i++){
   	dp[i][i][0]=1;
   	dp[i][i][1]=1;
   	dp[i][i][2]=1;
   	if(s[i]==s[i-1])
   	{
   		dp[i-1][i][0]=1;
   		dp[i-1][i][1]=1;
   		dp[i-1][i][2]=1;
	}
   	else{
   	   dp[i-1][i][1]=1;
   	   mp[{i-1,i}]={s[i],s[i-1]};
		 if(mp[{i-1,i}].second.first>mp[{i-1,i}].second.second)
		 swap(mp[{i-1,i}].second.first,mp[{i-1,i}].second.second);	  	
	   }
   	for(int j=1;j<=i-2;j++){
   		if(s[i]==s[j]){
   				dp[j][i][0]=dp[j+1][i-1][0];
   				dp[j][i][1]=dp[j+1][i-1][1];
   				dp[j][i][2]=dp[j+1][i-1][2];
   				mp[{j,i}]=mp[{j+1,i-1}];
	    }
	    else{
	    	 dp[j][i][1]=dp[j+1][i-1][0];
	    	 mp[{j,i}]={s[j],s[i]};
	    	 if(mp[{j,i}].second.first>mp[{j,i}].second.second)
	           swap({mp[{j,i}].second.first,mp[{j,i}].second.second});	  	
	                   	 
	    	 if(dp[j+1][i-1][1])
	    	 {
	    	    if(mp[{j,i}]==mp[{j+1,i-1}])
	    	    {
	    	    	dp[j][i][2]=1;
				}
			 }
		}
	   }
   }
   int ans=0;
   
   for(int i=1;i<=n;i++)
    for(int j=i;j<=n;j++){
    	if(dp[i][j][0]||dp[i][j][1]||dp[i][j][2])
    	ans=max(ans,j-i+1);
	}
//	if(ans==1)
//	ans=0;
	ct(ans);
}

signed main(){
	ios;
	int t=1; 
	 cin>>t;
	while(t--)
	solve();
	return 0;
}