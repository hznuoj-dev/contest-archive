#include<bits/stdc++.h>
using namespace std;
using ll=long long;



int main() {
	ll n,m;
	scanf("%lld%lld",&n,&m);
	bool ok=1;
	while(n%m!=0&&m!=1){
		m=n%m;
	}
	if(m!=1){
		puts("NO");
	}
	else puts("YES");
}