#include<bits/stdc++.h>
#define ios ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const ll N=5e3+7;
const ll mod =1e9+7;
const double eps=1e-6;
const ll MAXN=1010;
using namespace std;
struct Edge
{
	int s,t,v;
}edge[MAXN];
int n,m;
int father[MAXN];
int ans=0;
bool cmp(Edge &a,Edge &b)
{
	return a.v<b.v;
}
int find(int x)
{
	if(father[x]!=x)
	    father[x]=find(father[x]);
	return father[x];
}
void unionn(int a,int b)
{
	int fa,fb;
	fa=find(a);
	fb=find(b);
	father[fb]=fa;
}
bool pd(int a,int b)
{
	int fa,fb;
	fa=find(a);
	fb=find(b);
	return fa==fb;
}
void kruskal()
{
	sort(edge+1,edge+m+1,cmp);
	int last=0,cnt=0;
	for(int i=1;i<=m;++i)
	{
		int s,t,v;
		s=edge[i].s;
		t=edge[i].t;
		v=edge[i].v; 
		if(!pd(s,t))
		{
			unionn(s,t);
			if(v>last+1)
			{
				ans=last+1;
				return;
			}
			else
			  last=v;
		}
	}
	ans=last+1;
}
void slove()
{
	ios;
	cin>>n>>m;
	for(int i=1;i<=m;++i)
	  cin>>edge[i].s>>edge[i].t>>edge[i].v;
	for(int i=1;i<=n;++i)
	  father[i]=i;
	kruskal();
	cout<<ans;
}
int main(){
	slove();
}