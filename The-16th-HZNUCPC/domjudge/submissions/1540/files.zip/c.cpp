#include <bits/stdc++.h>

using i64 = long long;

int main() {
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	std::string a, b;
	std::cin >> a >> b;
	int n = a.length();
		
	int cnta[26]{};
	int cntb[26]{};
	int g[26][26]{};
	
	for (int i = 0; i < n; i++) {
		cnta[a[i] - 'a']++;
		cntb[b[i] - 'a']++;
		g[a[i] - 'a'][b[i] - 'a']++;
	}
	
	int sa = 26 - std::count(cnta, cnta + 26, 0);
	int sb = 26 - std::count(cntb, cntb + 26, 0);

	
	i64 ans = 0;
	for (int i = 0; i < n; i++) {
		g[a[i] - 'a'][b[i] - 'a']--;
		
		sa -= --cnta[a[i] - 'a'] == 0;
		sb -= --cntb[b[i] - 'a'] == 0;
		sa += ++cnta[b[i] - 'a'] == 1;
		sb += ++cntb[a[i] - 'a'] == 1;
//		std::cerr << sa << " " << sb << "!\n";
		for (int j = 0; j < 26; j++) {
			for (int k = 0; k < 26; k++) {
				if (g[j][k] > 0) {
//					std::cerr << j << " " << k << "\n";
					sa -= --cnta[j] == 0;
					sb -= --cntb[k] == 0;
					sa += ++cnta[k] == 1;
					sb += ++cntb[j] == 1;
//					std::cerr << sa << " " << sb << "!\n";
					if (sa == sb) {
						ans = (ans + g[j][k]) % 1000000007;	
					}					
					
					sa -= --cnta[k] == 0;
					sb -= --cntb[j] == 0;
					sa += ++cnta[j] == 1;
					sb += ++cntb[k] == 1;
//					std::cerr << sa << " " << sb << "!!\n";
				}
			}
		}
//		std::cerr << sa << " " << sb << "!!\n";
		sa -= --cnta[b[i] - 'a'] == 0;
		sb -= --cntb[a[i] - 'a'] == 0;
		sa += ++cnta[a[i] - 'a'] == 1;
		sb += ++cntb[b[i] - 'a'] == 1;
//		std::cerr << sa << " " << sb << "!!!\n";
	}
	
	std::cout << ans << "\n";

	return 0;
}
