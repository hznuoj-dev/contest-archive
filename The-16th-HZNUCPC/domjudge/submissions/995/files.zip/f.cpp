#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define MOD 1000000007;
void solve(){
	ll a,b;
	cin>>a>>b;
	bool pd=true;
	if(a<b) pd=false;
	if(a%2==0) pd=false;
	if(a%b==0) pd=false;
	if(a%2&&pd)
	{
		while(a%b!=0&&b!=1)
		{
			b=a%b;
			if(a%b==0&&b!=1)
			{
				pd=false;
				break;
			}
		}
	}
	
	if(pd){
		cout<<"YES";
	}else{
		cout<<"NO";
	}
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	
	solve();
	return 0;
}