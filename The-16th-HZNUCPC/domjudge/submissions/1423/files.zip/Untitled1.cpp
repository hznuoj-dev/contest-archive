#include<bits/stdc++.h>
using namespace std;
const int N = 1e6 + 10;
#define int long long 
#define endl '\n'
int a[N];
signed main(){
	int q;
	q=1;
	while(q --){
		int a, b;
		bool f = 0;
		cin >> a >> b;
		if (a == 1 || b == 1){
			cout << "YES" << endl;
			continue;
		}
		if (a <= b){
			cout << "NO" << endl;
			continue;
		}
		if (a % b == 0){
			cout << "NO" << endl;
			f = 1;
			continue;
		}
		while (b > 2){
			b -= a % b;
			if (b == 1){
				cout << "YES" << endl;	
				f = 1;
				break;
			}
			if (a % b == 0){
				cout <<	"NO" << endl;
				f = 1;
				break;
			}
		}
		if (!f)cout << "YES" << endl;
	}
	
	
	
	return 0;
}