#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
#define per(i,x,y) for(int i=x;i>=y;i--)
#define FOR(i,x,y) for(char i=x;i<=y;i++)
using namespace std;
#define int long long
const int mod=1e9+7;
const int N=2e5+10;
int qmi(int a,int b){
	int res=1;
	for(;b;b>>=1,a=a*a%mod)
		if(b&1)res=res*a%mod;
	return res;
}
void solve(){
	string a,b;cin>>a>>b;
	map<char,int>x,y;
	FOR(i,'a','z')x[i]=0;
	FOR(i,'a','z')y[i]=0;
	for(auto ch:a)x[ch]++;
	for(auto ch:b)y[ch]++;
	map<pair<char,char>,int>mp;
	rep(i,0,a.size()-1){
		mp[{a[i],b[i]}]++;
	}	
	int ans=0;
	FOR(i,'a','z')FOR(j,'a','z')FOR(k,'a','z')FOR(l,'a','z'){
		if(x[i] and x[k] and y[j] and y[l]){
			x[i]--,x[j]++,y[j]--,y[i]++;
			x[k]--,x[l]++,y[l]--,y[k]++;
			map<int,int>ca,cb;
			for(auto [q,w]:x)ca[w]++;
			for(auto [q,w]:y)cb[w]++;
			if(ca==cb){
				pair<char,char>xx={i,j};
				pair<char,char>yy={k,l};
				ans=ans+mp[xx]*mp[yy];
				if(xx==yy)ans-=mp[xx];
				ans%=mod;
			}
			x[i]++,x[j]--,y[j]++,y[i]--;
			x[k]++,x[l]--,y[l]++,y[k]--;
		}
	}
	if(ans<0)ans+=mod;
	ans=ans*qmi(2,mod-2)%mod;
	cout<<ans;
}
signed main(){
	cin.tie(0)->sync_with_stdio(false);
	int tc=1;
	for(int i=1;i<=tc;i++){
		solve();
	}
}