'''import math
n,m=map(int,input().split())
if m==1:
    print("YES")
elif(n%m==0 or n%2==0):
    print("NO")
else:
    min=n
    for i in range(2,int(pow(n,0.5))+1):
        if n%i==0:
            min=i
            break
    if min<=m:
        print("NO")
    else:
        print("YES")'''
import math
flag=False
n,m=map(int,input().split())
def fact(n,m):
    if m==1:
        return True
    else:
        min1=n
        for i in range(2,n):
            if n%i==0:
                min=i
                break
        if min<=m:
            return False
        else:
            return True
for i in range(m):
    if fact(n,i)==False:
        print("NO")
        flag=True
        break
if(flag==False):
    print("YES")
