#include<bits/stdc++.h>
#define ll long long
#define rep(i,j,k) for(int i=(j);i<=(k);i++)

const int N = 7e3 + 5;

char s[N];

inline void solve() {
	scanf ( "%s", s + 1 );
	int n = strlen ( s + 1 );
	int ans = 0;
//	printf ( "n = %d\n", n );
	rep ( i, 1, n ) {
//		printf ( "i = %d\n", i );
		int x = i, y = i, k = 0;
		int res = 1;
		std::pair < char, char > cur;
		while ( x > 1 && y < n ) {
			x--, y++;
//			printf ( "x = %d, y = %d\n", x, y );
			if ( s[x] == s[y] ) res += 2;
			else {
				if ( k == 0 ) {
					k++;
					cur = std::minmax ( s[x], s[y] );
					res += 2;
				} else if ( k == 1 ) {
					std::pair < char, char > now = std::minmax ( s[x], s[y] );
					if ( now.first == cur.first && now.second == cur.second ) k++, res += 2;
					else break;
				} else break;
			} if ( k == 0 || k == 2 ) ans = std::max ( ans, res );
		}
	}
	rep ( i, 2, n ) {
		if ( s[i] == s[i - 1] ) {
			int x = i - 1, y = i, k = 0;
			int res = 2;
			std::pair < char, char > cur;
			while ( x > 1 && y < n ) {
				x--, y++;
				if ( s[x] == s[y] ) res += 2;
				else {
					if ( k == 0 ) {
						k++;
						cur = std::minmax ( s[x], s[y] );
						res += 2;
					} else if ( k == 1 ) {
						std::pair < char, char > now = std::minmax ( s[x], s[y] );
						if ( now.first == cur.first && now.second == cur.second ) k++, res += 2;
						else break;
					} else break;
				} if ( k == 0 || k == 2 ) ans = std::max ( ans, res );
			}
		}
		else {
			std::pair < char, char > cur = std::minmax ( s[i], s[i - 1] );
			int x = i - 1, y = i, k = 1;
			int res = 2;
			while ( x > 1 && y < n ) {
				x--, y++;
				if ( s[x] == s[y] ) {
					res += 2;
				} else if ( k == 1 ) {
					std::pair < char, char > now = std::minmax ( s[x], s[y] );
					if ( now.first == cur.first && now.second == cur.second ) k++, res += 2;
					else break;
				}else break;
				if ( k == 2 ) ans = std::max ( ans, res );
			}
		}
	}
	for ( char kk = 'a' ; kk <= 'z' ; kk++ ) {
		rep ( i, 1, n ) {
			if ( s[i] == kk ) continue;
			std::pair < char, char > cur = std::minmax ( s[i], kk );
			int x = i, y = i, k = 1;
			int res = 1;
			while ( x > 1 && y < n ) {
				x--, y++;
				if ( s[x] == s[y] ) {
					res += 2;
				} else if ( k == 1 ) {
					std::pair < char, char > now = std::minmax ( s[x], s[y] );
					if ( now.first == cur.first && now.second == cur.second ) k++, res += 2;
					else break;
				} else break;
				if ( k == 2 ) ans = std::max ( ans, res );
			}
		}
	}
	printf ( "%d\n", ans == 1 ? 0 : ans );
}

signed main() {
//	freopen ( "use.txt", "r", stdin );
	int t; scanf ( "%d", &t );
	while ( t-- ) solve();
}