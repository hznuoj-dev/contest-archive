#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=105;
const int inf=0x3f3f3f3f;
int n,ans=-inf;
struct point{
	int x,y;
}p[maxn],pt[maxn];
int gcd(int a,int b){
	return b?gcd(b,a%b):a;
}
int grid_onedge(int n,point* p){
	
	int ret=0;
	for(int i=0;i<n;i++){
		ret+=gcd(abs(p[i].x-p[(i+1)%n].x),abs(p[i].y-p[(i+1)%n].y));
//		cout<<abs(p[i].x-p[(i+1)%n].x)<<endl;
	}
	return ret;
}
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>pt[i].x>>pt[i].y;
	}
	for(int i=1;i<=n;i++)
	{
		for(int j=i+1;j<=n;j++)
		{
			for(int k=j+1;k<=n;k++)
			{
				p[0]=pt[i];
				p[1]=pt[j];
				p[2]=pt[k];
				ans=max(ans,grid_onedge(3,p));
			}
		}
	}
	cout<<ans;
}