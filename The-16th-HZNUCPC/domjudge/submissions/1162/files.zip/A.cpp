#include<bits/stdc++.h>
using namespace std;
typedef struct B{
	int x;
	int y;
} pos,B;
int main()
{
	
    int a[21][21];
    int x,y,z,sum,i,j,k,t,n,m,q;
    scanf("%d",&t);
    scanf("%d",&n);
    
    
    for(q=1;q<=t;q++)
    {	
		for(i=0;i<=20;i++)
    	for(j=0;j<=20;j++)
    		a[i][j]=0;
		m=1;
		pos p[400];
    	for(j=1;j<=n;j++)
    	{
    		scanf("%d%d%d",&x,&y,&z);
			a[x][y]=z;
			if(z==1)
			{
				p[m].x=x;
				p[m].y=y;
				m=m+1;
			}
		}
		for(j=1;j<m;j++)
		{
			x=p[j].x;
			y=p[j].y;
			if(a[x-1][y]==0||x==1)
			{
			 a[x-1][y]=2;
		    }
		    if(a[x+1][y]==0||x==19)
			{
			 a[x+1][y]=2;
		    }
		    if(a[x][y-1]==0||y==1)
			{
			 a[x][y-1]=2;
		    }
		    if(a[x][y+1]==0||y==19)
			{
			 a[x][y+1]=2;
		    }
		}
		for(i=0;i<=20;i++)
    	for(j=0;j<=20;j++)
		{
			if(a[i][j]==2)
			{
				if(a[x-1][y]==1&&a[x+1][y]==1&&a[x][y-1]==1&&a[x][y+1]==1||x==0||x==20||y==0||y==20)
			{
				sum=sum-1;
			}
			sum=sum+1;
			}
			
		}
		printf("%d",sum);
	}
}