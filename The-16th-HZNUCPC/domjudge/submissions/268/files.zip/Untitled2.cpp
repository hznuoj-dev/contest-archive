#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,m,q,k;
signed main(){
	cin >> n >> m;
	q=sqrt(n);
	k=n;
	for (int i=2;i<=q;++i) {
		if (n%i==0) {
			k=i;break;
		}
	}
	if (k<=m) cout << "NO";
	else 	  cout <<"YES";
}