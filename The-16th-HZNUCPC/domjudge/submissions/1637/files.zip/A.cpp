#include<bits/stdc++.h>
using namespace std;
int mp[40][40];
int tmp[40][40];
int X[5]={0,1,-1,0};
int Y[5]={1,0,0,-1};
int bfs(int x,int y){
	for(int i=0;i<=20;i++){
		for(int j=0;j<=20;j++){
			tmp[i][j]=0;
		}
	}
	queue<int> qux,quy,tqux,tquy;
	tmp[x][y]=1;
	qux.push(x);
	quy.push(y);
	tqux.push(x);
	tquy.push(y);
	while(!qux.empty()){
		int jx=qux.front(),jy=quy.front();
		qux.pop();
		quy.pop();
		for(int i=0;i<4;i++){
			if(jy+Y[i]>=1&&jx+X[i]>=1&&jy+Y[i]<=19&&jx+X[i]<=19&&tmp[jx+X[i]][jy+Y[i]]==0){
				if(mp[jx+X[i]][jy+Y[i]]==mp[jx][jy]){
					tmp[jx+X[i]][jy+Y[i]]=1;
					qux.push(jx+X[i]);
					quy.push(jy+Y[i]);
					tqux.push(jx+X[i]);
					tquy.push(jy+Y[i]);
				}else if(mp[jx+X[i]][jy+Y[i]]==0){
					return 0;
				}	
			}
		}
	}
	while(!tqux.empty()){
		int jx=tqux.front(),jy=tquy.front();
		tqux.pop();
		tquy.pop();
		mp[jx][jy]=0;
	}
	return 1;
}
int main()
{
	int T;
	cin>>T;
	while(T--){
		for(int i=1;i<=20;i++){
			for(int j=1;j<=20;j++){
				mp[i][j]=0;
			}
		}
		int n;
		cin>>n;
		for(int i=0;i<n;i++){
			int x,y,c;
			cin>>x>>y>>c;
			int pd=0;
			mp[x][y]=c;	
			for(int q=0;q<4;q++){	
				if(y+Y[q]>=1&&x+X[q]>=1&&y+Y[q]<=19&&x+X[q]<=19){
					if(mp[x+X[q]][y+Y[q]]==0){
						pd++;
					}else if(mp[x+X[q]][y+Y[q]]!=mp[x][y]){
						pd+=bfs(x+X[q],y+Y[q]);
					}
				}	
			}
			if(pd==0){
				mp[x][y]=0;
			}
		}
//		for(int i=1;i<=19;i++){
//			for(int j=1;j<=19;j++){
//				cout<<mp[i][j]<<" ";
//			}cout<<endl;
//		}
		int ans=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(mp[i][j]==1){
					for(int q=0;q<4;q++){
						if(j+Y[q]>=1&&i+X[q]>=1&&j+Y[q]<=19&&i+X[q]<=19){
							if(mp[i+X[q]][j+Y[q]]==0){
								ans++;
							}
						}
					}
				}
			}
		}
		cout<<ans<<endl;
	}
	return 0;
}
//1
/*
1
6
1 1 1
2 1 1
1 2 1
3 1 2
2 2 2
1 3 2
*/