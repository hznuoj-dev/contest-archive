#include <bits/stdc++.h>
using namespace std;
using ll =long long ;
ll n,m,k,cnt,sum;
int raw[25][25];
struct pos{
	ll l,r,sum;
	
};
int q(int i,int j){
	int ans=0;
	if(i-1>=1 && raw[i-1][j]!=1){
		if(raw[i-1][j]!=2){
			ans++;
//			raw[i-1][j]=2;
		}
	}if(i+1<=19 && raw[i+1][j]!=1){
		if(raw[i+1][j]!=2){
			ans++;
//			raw[i+1][j]=2;
		}
	}if(j-1>=1 && raw[i][j-1]!=1){
		if(raw[i][j-1]!=2){
			ans++;
//			raw[i][j-1]=2;
		}
	}if(j+1<=19 && raw[i][j+1]!=1){
		if(raw[i][j+1]!=2){
			ans++;
//			raw[i][j+1]=2;
		}
	}
	return ans;
}
void solve(){
	memset(raw,0,sizeof(raw));
	cin >> n;
	int x,y,z,ans=0;
	while(n--){
		cin>>x>>y>>z;
		raw[x][y]=z;
	}
	for(int i=1;i<=19;i++){
		for(int j=1;j<=19;j++){
			if(raw[i][j]==1){
				ans+=q(i,j);
			}
		}
	}
	cout << ans << endl;
}
int main(){
	ll t;
	cin >> t;
	while(t--)
		solve();
}