dx = [0,0,-1,1]
dy = [-1,1,0,0]
T = int(input())
for i in range(T):
    n = int(input())
    g = [[0]*20 for k in range(20)]
    black = []
    for j in range(n): 
        a,b,c  = map(int,input().split())
        g[b][a] = 1
        if c == 1:
            black.append([a,b])
    ans = 0
    for k in black:
        for l in range(4):
            nx,ny = k[0]+dx[l],k[1]+dy[l]
            if nx>=1 and nx<=19 and ny>=1 and ny<=19 and g[ny][nx]!=1:
                ans+=1
    print(ans)
