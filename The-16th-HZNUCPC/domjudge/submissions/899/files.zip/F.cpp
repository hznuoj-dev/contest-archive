#include <bits/stdc++.h>

#define dbg(x...) \
    do { \
        std::cout << #x << " -> "; \
        err(x); \
    } while (0)

void err() {
    std::cout << std::endl;
}

template<class T, class... Ts>
void err(T arg, Ts &... args) {
    std::cout << arg << ' ';
    err(args...);
}

using ll = long long;
using ld = long double;
using ull = unsigned long long;
using i128 = __int128;

void run(int tCase) {
    ll n, m;
    std::cin >> n >> m;
    std::vector<ll> vec;
    for (ll i = 1; i * i <= n; ++i) {
        if (n % i) continue;
        vec.push_back(i);
        vec.push_back(n / i);
    }
    std::sort(vec.begin(), vec.end());
    if (*(--std::upper_bound(vec.begin(), vec.end(), m)) == 1) {
        std::cout << "YES\n";
    } else {
        std::cout << "NO\n";
    }
}

int main() {
    std::ios_base::sync_with_stdio(false);
    std::cin.tie(nullptr);
    int T = 1;
//    std::cin >> T;
    for (int t = 1; t <= T; ++t) {
        run(t);
    }
    return 0;
}