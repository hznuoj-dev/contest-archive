#include<iostream>
#include<cstring>
#include<algorithm>
#include<stack>
#include<queue>
#define endl '\n'
using namespace std;
const int N=1e6+10,INF=2e9;
typedef long long ll;
typedef unsigned long long ULL;
typedef pair<int,int> PII; 
bool solve(){
	ll n,m;
	cin>>n>>m;
	if(n<=m||n%m==0)return false;
	while(1){
		ll t=n-m*(n/m);
		if(t==1)return true;
		else m=t;
		if(n<=m||n%m==0)return false;
	}
}
int main(void){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int TT;
	TT=1;
	//cin>>TT;
	while(TT--){
		if(solve())cout<<"YES";
		else cout<<"NO";
	}
	return 0;
}