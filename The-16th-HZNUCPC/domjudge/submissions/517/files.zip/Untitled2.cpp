#include <bits/stdc++.h>
using namespace std;

int main()
{
	long long n,m;
	cin >> n >> m;
	if(m==1)
	{
		cout << "YES";
	}
	else 
	{
     int x=__gcd(n,m);
     if(x==1)
     {
     	cout << "YES";
	 }
	 else
	 {
		cout << "NO";
	 }
    }
   return 0;
}