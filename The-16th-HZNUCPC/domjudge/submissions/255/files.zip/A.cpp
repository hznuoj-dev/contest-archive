#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[23][23];
ll b[23][23];
ll dx[]={0,0,1,-1};
ll dy[]={1,-1,0,0};
void solve(){
    for(ll i=1;i<=22;i++){
    	for(ll j=1;j<=22;j++){
    		a[i][j]=0;
    		b[i][j]=0;
		}
	}
	ll n;
	cin>>n;
	for(ll i=1;i<=n;i++){
		ll x,y,z;
		cin>>x>>y>>z;
		if(z==1)a[x][y]=1;
		else a[x][y]=2;
	}
	for(ll i=1;i<=19;i++){
		for(ll j=1;j<=19;j++){
			for(ll k=0;k<4;k++){
				ll X=i+dx[k],Y=j+dy[k];
				if(X>=1&&X<=19&&Y>=1&&Y<=19&&a[X][Y]==0&&a[i][j]==1){
					b[X][Y]++;
				}
			}
		}
	}
	ll ans=0;
	for(ll i=1;i<=19;i++){
		for(ll j=1;j<=19;j++){
			if(b[i][j])ans+=b[i][j];
			
			
		}
		
	}
	cout<<ans<<endl;
}



int main(){
    ios::sync_with_stdio(false);
    int T=1;
    cin>>T;
    while(T--){
        solve();
    }
    return 0;
}
