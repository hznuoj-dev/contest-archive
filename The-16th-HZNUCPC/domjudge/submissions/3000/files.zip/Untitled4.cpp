#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int,int>
const int N = 10010;

signed main(){
	int a,b,c;
	cin >> a >> b;
	int flag = 0;
	if(a == 1 || b == 1){
		flag = 1;
	}else{ 
		c=sqrt(a);
		c=min(c,b);
		flag=1;
		for(int i=2;i<=c;i++){
			if(a%i==0){
				flag=0;
				break;
			}
		}
		if(a<=b)flag=0;
	}
	if(flag) cout << "YES" ;
	else cout << "NO";
	return 0;
}