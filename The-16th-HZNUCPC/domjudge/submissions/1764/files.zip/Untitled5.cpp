#include<bits/stdc++.h>
#define ll long long
#define PII pair<int,int>
#define x first
#define y second
using namespace std;
//const int INF,maxn;
PII p[110];
ll dis[110][110];
void solve(){
	int n;
	cin >> n;
	ll dx,dy,x0,y0,flag=0;
	cout << "e\n";
	for(int i=1;i<=n;i++){
		cin >> p[i].x >> p[i].y;
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			dx=abs(p[i].x-p[j].x),dy=abs(p[i].y-p[j].y);
			if(dx==0){
				dis[i][j] = abs(p[i].y-p[j].y)-1;
//				cout << "work " << p[i].x << " " << p[i].y << " " << p[j].x << " " << p[j].y << " " << dis[i][j] << endl;
				continue;
			}
			if(dy % dx==0){
				dis[i][j] = dx-1;
//				cout << "work " << p[i].x << " " << p[i].y << " " << p[j].x << " " << p[j].y << " " << dis[i][j] << endl;
				continue;
			}
			dis[i][j] = (dx-1)*dy/dx;
//			cout << "work " << p[i].x << " " << p[i].y << " " << p[j].x << " " << p[j].y << " " << dis[i][j] << endl;
		}
	}
	ll ans=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				if(p[i].x==p[j].x && p[j].x==p[k].x || (p[j].y-p[i].y)*(p[k].x-p[j].x) == (p[k].y-p[j].y)*(p[j].x-p[i].x)){
					continue;
				}
				ans = max(ans,dis[i][j]+dis[j][k]+dis[i][k]+3);
			}
		}
	}
	cout << ans << endl;
	return;
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	int T = 1;
//	cin>>T;
	while(T--) solve();
	return 0;
}
