#include<bits/stdc++.h>
#define int long long
#define PII pair<int,int>
using namespace std;
void solve()
{
	int n,m;
	cin>>n>>m;
	if(n==1||m==1){
		cout<<"NO"<<endl;
		return ;
	}
	if(n<=m){
		cout<<"NO"<<endl;
		return;
	}
	while(m){
		m=n%m;
		if(m==1){
			cout<<"YES"<<endl;
			return ;
		}
	}
	cout<<"NO"<<endl;
	
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
//	int _;cin>>_;while(_--)
	solve();
}