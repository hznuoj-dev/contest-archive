#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,m;
	while(cin>>n>>m){
		if(n%m!=0){
			cout <<"YES"<<endl;
		}else{
			cout <<"NO"<<endl;
		}
		
		
	}
	return 0;
}