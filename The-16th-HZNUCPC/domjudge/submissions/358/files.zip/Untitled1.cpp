#include <bits/stdc++.h>

using namespace std;
using LL = long long;

int dx[] = {1, 0, -1, 0}, dy[] = {0, 1, 0, -1};

void solve()
{
	vector<vector<int>> adj(30, vector<int>(30, -1));
	int n;
	cin >> n;
	for (int i = 1; i <= 19; ++ i)
		for (int j = 1; j <= 19; ++ j) adj[i][j] = 0;
	for (int i = 1; i <= n; ++ i)
	{
		int x, y, c;
		cin >> x >> y >> c;
		adj[x][y] = c;
	}
	int ans = 0;
	for (int i = 1; i <= 19; ++ i)
		for (int j = 1; j <= 19; ++ j)
		{
			if (adj[i][j] != 1) continue;
			for (int u = 0; u < 4; ++ u)
			{
				int x = dx[u] + i, y = dy[u] + j;
				if (adj[x][y] == 0) ans ++ ; 
			}
		}
	cout << ans << "\n";
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	
	int T;
	for (cin >> T; T -- ;)
		solve();
}