#include<bits/stdc++.h>
using namespace std;

int main(){
	long long n,m;
	while(scanf("%lld %lld",&n,&m)!=EOF){
		int f=0;
		while(f==0){
			long long x=n%m;
			if(x==1){
				f=1;
			}
			if(x==0){
				f=2;
			}
			m=x;
		}
		if(f==1){
			printf("YES\n");
		}else{
			printf("NO\n");
		}
	}
	return 0;
}
