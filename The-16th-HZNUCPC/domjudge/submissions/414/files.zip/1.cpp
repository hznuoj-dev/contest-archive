#include<iostream>
#include<cstring>
using namespace std;
int a[20][25];
int main(){
	int t;
	int sum=0;
	cin>>t;
	while(t--){
		sum=0;
		int n;
		int x,y,z;
		cin>>n;
		memset(a,0,sizeof a);
		for(int i=1;i<=n;i++){
			cin>>x>>y>>z;
			a[x][y]=z;
		}
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(a[i][j]==1){
					sum+=4;
					if(a[i-1][j]!=0||i==1)sum--;
					if(a[i][j+1]!=0||j==19)sum--;
					if(a[i+1][j]!=0||i==19)sum--;
					if(a[i][j-1]!=0||j==1)sum--;
				}
			}
		}
		cout<<sum<<endl;
	}
	return 0;
}