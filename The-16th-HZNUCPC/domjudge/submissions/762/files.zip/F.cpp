#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
	ll n,m;
	cin>>n>>m;
	if(m>=n) 
	{
		if(m==1)
			cout<<"YES";
		else	
			cout<<"NO";
		return 0;
	}
	int k;
	while(1)
	{
		k=n%m;
		if(k==0) 
		{
			cout<<"NO";
			return 0;
		}
		else if(k==1)
		{
			cout<<"YES";
			return 0;
		}
		m=k;
	}
}