#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int mod=1e9+7,M=1e6+5;
ll up,down,x[30],y[30],g[M];
ll mp[20];
void solve()
{
	string a,b;
	cin>>a>>b;
	ll ans=0;
	int len=a.size();
	set<char> st1,st2;
	memset(x,0,sizeof x);
	memset(y,0,sizeof y);
	for(int i=0;i<a.size();i++)
	{
		x[a[i]-'a']++;
		if(x[a[i]-'a']==1) up++;
		
	}
	for(int i=0;i<b.size();i++)
	{
		y[b[i]-'a']++;
		if(y[b[i]-'a']==1) down++;
		
	}
	for(int i=0;i<len;i++)
	{
		int m1,m2;
		m1=a[i]-'a';m2=b[i]-'a';
		if(m1==m2)
		{
			g[i]=0;
			mp[g[i]+10]++;
			continue;
		}
		int s1=0,s2=0;
		if(x[m1]==1) s1--;
		if(x[m2]==0) s1++;
		if(y[m2]==1) s2--;
		if(y[m1]==0) s2++; 
		g[i]=s1-s2;
		mp[g[i]+10]++;
	}
//	for(int i=0;i<len;i++) printf("%lld ",g[i]);
//	for(int i=8;i<=12;i++) printf("%lld ",mp[i]);
	int cha=up-down;
	if(cha==4)
	{
		ll k=mp[-2+10];
		ans=(k*(k-1))/2;
	}else if(cha==3)
	{
		ans=mp[-2+10]*mp[-1+10];
	}else if(cha==2)
	{
		//cout<<mp[8];
		ll k=mp[-1+10];
		ans=mp[-2+10]*mp[0+10]%mod+(k*(k-1))/2;
	}else if(cha==1)
	{
		ans=mp[-1+10]*mp[0+10]%mod+mp[-2+10]*mp[1+10]%mod;
	}else if(cha==0)
	{
		ans=mp[1+10]*mp[-1+10]%mod+mp[2+10]*mp[-2+10]%mod+(mp[0+10]*(mp[0+10]-1))/2;
	}else if(cha==-1)
	{
		ans=mp[1+10]*mp[0+10]%mod+mp[2+10]*mp[-1+10]%mod;
	}else if(cha==-2)
	{
		ans=mp[2+10]*mp[0+10]%mod+mp[1+10]*(mp[1+10]-1)/2;
	}else if(cha==-3)
	{
		ans=mp[1+10]*mp[2+10];
	}else if(cha==-4)
	{
		ans=mp[2+10]*(mp[2+10]-1)/2;
	}
	ans=((ans%mod)+mod)%mod;
	printf("%lld\n",ans);
}
int main()
{
	int t=1;
	//scanf("%d",&t);
	while(t--) solve();
	return 0;
}