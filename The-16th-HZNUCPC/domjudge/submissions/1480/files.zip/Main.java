package one;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;
import java.util.Scanner;

public class Main {
	public static void main(){
		Scanner scanner = new Scanner(System.in);
		int[] X=new int[]{0,0,-1,1};
		int[] Y=new int[]{1,-1,0,0};
		int n=scanner.nextInt();
		int m =scanner.nextInt();
		int[][] point = new int[m][3];    
		for(int k=0;k<n;k++){
		int[][] bool=new int[19][19];
		for(int i = 0;i<m;i++){
			point[i][0] = scanner.nextInt();
			point[i][1] = scanner.nextInt();
			point[i][2] = scanner.nextInt();
			if(point[i][2]==1){
				bool[i][2]=1;
			}else{
				bool[i][2]=2;
			}
		}
		int ans=0;
		int sum = 0;
		for(int i = 0;i<m;i++){
			if(bool[i][2]==1){//�ڵ�
			for(int j=0;j<4;j++){
				//x�����ڷ�Χ��
			int newX=point[i][0]+X[j];
			int newY=point[i][1]+Y[j];
			if(newX>=0&&newX<=18&&newY>=0&&newY<=18){
				if(bool[newX][newY]==0){
					ans++;
				}else if(bool[newX][newY]==2){
					bool[newX][newY]=0;
				}
			}
			}
			}
				
		}
		System.out.print(ans);
		}
	}
	

}
