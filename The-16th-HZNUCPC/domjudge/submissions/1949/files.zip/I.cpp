#include <bits/stdc++.h>
using namespace std;
#define ln '\n'

const int N = 1e4 + 5;
char s[N], str[N];
int cnt[N][26];

inline int find(int l, int r, char x) {
	if(l > r) return 0;
	return cnt[r][x - 'a'] - cnt[l - 1][x - 'a'] > 0;
}

inline void solve() {
	cin >> (s + 1);
	int n = strlen(s + 1);
	for(int i = 1; i <= n; i++) str[2 * i] = s[i];
	for(int i = 1; i <= n; i++) str[2 * i + 1] = '#';
	n<<=1;
	for(int i = 1; i <= n; i++) {
		for(int j = 0; j < 26; j++) cnt[i][j] = cnt[i - 1][j];
		if(str[i] != '#')
			cnt[i][str[i] - 'a']++; 
	}
	int ans = 0;
	for(int mid = 1; mid <= n; mid++) {
		int len = min(mid - 1, n - mid);
		vector<int>pos{};
		for(int i = 1, tmp = str[mid] != '#'; i <= len; i++) {
			tmp += str[mid + i] != '#';
			tmp += str[mid - i] != '#';
			if(str[mid + i] != str[mid - i]) 
				pos.push_back(i);
			if(pos.size() == 0 && tmp > 1)		
				ans = max(ans, tmp);
			else if(pos.size() == 1) {
				int l = mid - i - 1, r = mid + i;
				if(str[mid - pos[0]] == str[mid]) ans = max(ans, tmp);
				if(str[mid + pos[0]] == str[mid]) ans = max(ans, tmp);
			} else if(pos.size() == 2) {
				int p1 = mid - pos[1], p2 = mid - pos[0], p3 = mid + pos[0], p4 = mid + pos[1]; 	
				if(str[p1] == str[p2] && str[p3] == str[p4]) 
					ans = max(ans, tmp);
				if(str[p1] == str[p3] && str[p2] == str[p4])
					ans = max(ans, tmp);
//				break;
			} else if(pos.size() > 2) break;
		}
	}
	cout << ans << ln;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);

	int test;
	cin >> test;
	while(test--)
		solve();
}
/*
4
abccab
ihi
stfgfiut
palindrome
*/