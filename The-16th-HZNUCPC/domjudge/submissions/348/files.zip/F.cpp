#include<bits/stdc++.h>
#define int long long
using namespace std;



int doprime(int n){
	for(int i=2;i*i<=n;i++){
		if(n%i==0){
			return i;
		}
	}
	return n;
}
signed main(){
	int n,m;cin>>n>>m;
	int k=doprime(n);
	//cout<<k<<endl;
	if(m>=k){
		cout<<"NO"<<endl;
	}
	else{
		cout<<"YES"<<endl;
	}
}