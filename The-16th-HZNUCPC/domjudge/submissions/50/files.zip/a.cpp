#include <bits/stdc++.h>
using namespace std;
int n, _,col[30][30];
int hf(int x,int y){
	return col[x][y]==0&&x>=1&&x<=19&&y>=1&&y<=19;
}
int check(int x,int y){
	return hf(x+1,y)+hf(x,y+1)+hf(x-1,y)+hf(x,y-1);
}
int main() {
	scanf("%d" ,&_);
	while(_--) {
		scanf("%d" ,&n);
		while(n--){
			int x,y,z;
			scanf("%d%d%d",&x,&y,&z);
			col[x][y]=z;
		}
		int ans=0;
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(col[i][j]==1)ans+=check(i,j);				
			}
		}
		memset(col,0,sizeof(col));
		cout<<ans<<endl;
	}
	return 0;
}
