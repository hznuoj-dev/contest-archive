#include<bits/stdc++.h>
using namespace std;

struct node{
	int x,y;
	int f;	
}a[400];

int cun[400][400];
int main()
{
	int t;
	cin >> t;
	while(t--){
			for(int i=1;i<=400;i++){
			cun[i][0] = 1;
			for(int j=1;j<=400;j++){
				cun[0][j] = 1;
				cun[i][j]=0;
			}
	}
		int sum=0;
		int n;
		cin >> n;
		for(int i=1;i<=n;i++){
			cin>>a[i].x>>a[i].y>>a[i].f;
			cun[a[i].x][a[i].y]++;
		}
		for(int i=1;i<=n;i++){
			if(a[i].f==1){
				if(cun[a[i].x-1][a[i].y]==0){
					sum++;
				}
				if(cun[a[i].x+1][a[i].y]==0){
					sum++;
				}
				if(cun[a[i].x][a[i].y+1]==0){
					sum++;
				}
				if(cun[a[i].x][a[i].y-1]==0){
					sum++;
				}
			}
		}
	 	cout<<sum<<"\n";
	}

	return 0;
}