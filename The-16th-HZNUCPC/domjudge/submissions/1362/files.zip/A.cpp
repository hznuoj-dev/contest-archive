#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int N = 1e6 + 7;
int dx[] = {0,0,1,-1};
int dy[] = {1,-1,0,0};

void solve() {
	int n;
	vector<vector<int>> v(20,vector<int>(20,0));
	vector<pair<int,int>> p;
	cin >> n;
	for(int i = 0; i < n; i++){
		int x,y,op;
		cin >> x >> y >> op;
		v[x][y] = 1;
		if (op == 1){
			p.push_back({x,y});
		}
	}
	int ans = 0;
	for(auto [x,y] : p){
		for(int i = 0; i < 4; i++){
			int nex = x + dx[i];
			int ney = y + dy[i];
			if (nex >= 1 && nex <= 19 && ney >= 1 && ney <= 19 && !v[nex][ney]){
				ans++;
			}
		}
	}
	cout << ans << endl;
}
signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int Case = 1;
	cin >> Case;
	while (Case -- ) {
		solve();
	}
	return 0;
}