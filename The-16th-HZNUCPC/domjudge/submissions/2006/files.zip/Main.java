import java.io.*;
import java.util.StringTokenizer;


public class Main {
	int n,m,acnt,bcnt,i,l,r;
	int l0,r0,l1,r1,cnt;
	void solve()throws IOException{
		char[]s=("123"+in.ins()+"456").toCharArray();
		n=s.length-3;
		int ans=0;
		for(i=3;i<n;i++){
			l=i;
			r=i;
			while(s[l]==s[r]){
				l--;
				r++;
			}
			cnt=r-l-1;
			l0=l--;
			r0=r++;
			while(s[l]==s[r]){
				l--;
				r++;
			}
			l1=l--;
			r1=r++;
			if(s[l1]==s[r0]&&s[l0]==s[r1]){
				while(s[l]==s[r]){
					l--;
					r++;
				}
				ans=Math.max(ans, r-l-1);
			}else{
				if(cnt<=1)continue;
				if(s[i]==s[l0]||s[i]==s[r0]){
					ans=Math.max(ans, r1-l1-1);
				}else ans=Math.max(ans, cnt);
			}
		}
		for(i=4;i<n;i++){
			l=i-1;
			r=i;
			while(s[l]==s[r]){
				l--;
				r++;
			}
			cnt=r-l-1;
			l0=l--;
			r0=r++;
			while(s[l]==s[r]){
				l--;
				r++;
			}
			l1=l--;
			r1=r++;
			if(s[l1]==s[r0]&&s[l0]==s[r1]){
				while(s[l]==s[r]){
					l--;
					r++;
				}
				ans=Math.max(ans, r-l-1);
			}else{
				if(cnt<=1)continue;
				ans=Math.max(ans, cnt);
			}
		}
		out.println(ans);
	}
	int te;
	void run()throws IOException{
		int t=1;
		t=in.in();
		for(te=1;te<=t;te++){
			solve();
			out.flush();
		}
		out.close();
	}
	public static void main(String[]args)throws IOException{
		new Main().run();
	}
	In in=new In();
	PrintWriter out=new PrintWriter(new BufferedWriter(new OutputStreamWriter(System.out)));
	class In{
		StringTokenizer st=new StringTokenizer("");
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		String ins() throws IOException{
			while(!st.hasMoreTokens())st=new StringTokenizer(br.readLine());
			return st.nextToken();
		}
		int in()throws IOException{
			return Integer.parseInt(ins());
		}
	}
}
