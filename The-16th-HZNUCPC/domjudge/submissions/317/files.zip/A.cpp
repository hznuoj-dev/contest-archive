#include<bits/stdc++.h>
using namespace std;
int t,n,s[20][20],ans;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>t;
	while(t--){
		ans=0;
		memset(s,0,sizeof(s));
		cin>>n;
		for(int i=1;i<=n;i++){
			int x,y,c;cin>>x>>y>>c;
			s[x][y]=c;
		}
		for(int i=1;i<=19;i++){
			for(int j=1;j<=19;j++){
				if(s[i][j]==1){
					if(i-1>0&&(!s[i-1][j]))ans++;
					if(j-1>0&&(!s[i][j-1]))ans++;
					if(i+1<20&&(!s[i+1][j]))ans++;
					if(j+1<20&&(!s[i][j+1]))ans++;
				}
			}
		}
		cout<<ans<<"\n";
	}
	return 0;
}
