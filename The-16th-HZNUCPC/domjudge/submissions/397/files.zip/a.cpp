// #define DEBUG
#include <bits/stdc++.h>
#define ll long long
#define int long long

using namespace std;
const int MAXN = 105;
struct Point {
    int x, y;
    Point() {}
    Point(int a, int b) : x(a), y(b) {}
    Point operator - (Point const &b) const {
        return Point(x - b.x, y - b.y);
    }
    ll operator * (Point const &b) const {
        return x * b.y - y * b.x;
    }
    int getPointEdge(Point &b) {
        Point c = b - *this;
        // cout << __gcd(abs(c.x), abs(c.y)) - 1 << endl;
        return __gcd(abs(c.x), abs(c.y)) - 1;
    }
}p[MAXN];

ll getInsides(Point &a, Point &b, Point &c) {
    ll area = abs((b - a) * (c - a)) / 2;
    if (area == 0) return 0;
    ll edges = a.getPointEdge(b) + b.getPointEdge(c) + c.getPointEdge(a) + 3;
    return edges;
    // cout << area << ' ' << edges << endl;
    // return area - (edges / 2 - 1);
}

void solve() {
    int n;
    cin >> n;
    for (int i = 0; i < n; ++i) {
        cin >> p[i].x >> p[i].y ;
    }
    ll res = 0;
    for (int i = 0; i < n; ++i) {
        for (int j = i + 1; j < n; ++j) {
            for (int k = j + 1; k < n; ++k) {
                res = max(res, getInsides(p[i], p[j], p[k]));
                // cout << "============" << endl;
                // int temp = getInsides(p[i], p[j], p[k]);
                // cout << i << ' ' << j << ' ' << k << ":" << temp << endl;
            }
        }
    }
    cout << res << endl;
}

signed main(void) {
#ifdef DEBUG
    freopen("a.in", "r", stdin);
    freopen("a.out", "w", stdout);
    auto now = clock();
#endif
    ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
    cout << fixed << setprecision(6);
    solve();
#ifdef DEBUG
    cerr << double(clock() - now) / (double)CLOCKS_PER_SEC * 1000 << " ms." << endl;
#endif
    return 0;
}