#include <bits/stdc++.h>

using namespace std;
using ll = long long;
using pt = complex<long long>;
/*
#define x real()
#define y imag()

int point_covered(pt a, pt b) {
	assert(a != b);
	if (a.x == b.x) {
		return abs(a.y - b.y) - 1;
	}
	if (a.y == b.y) {
		return abs(a.x - b.x) - 1;
	}
	
	return __gcd(abs(a.y - b.y), abs(a.x - b.x)) - 1;
}

int cross(pt a, pt b) {
	return a.x * b.y - a.y * b.x;
}

int same_line(pt a, pt b, pt c) {
	return cross(b - a, c - a) == 0;
}
*/
#define int ll
const int maxn = 5e5 + 5;
struct dsu {
	int link[maxn];
	vector<int> good[maxn], bad[maxn];
//	int good[maxn], bad[maxn];
	void init(int n) {
		iota(link, link + n + 1, 0);
//		fill(good, good + n + 1, 0);
//		fill(bad, bad + n + 1, 0);
		for (int i = 0; i < n; ++i) {
			good[i].clear();
			bad[i].clear();
		}
	}
	
	void append(vector<int>& a, vector<int>& b) {
		if (a.size() < b.size()) {
			swap(a, b);
		}
		for (auto c : b) {
			a.push_back(c);
		}
	}
	
	int find(int x) {
		while (link[x] != x) {
			x = link[x];
		}
		return x;
	}
	

	int merge(int u, int v) {
		u = find(u);
		v = find(v);
		if (u == v) return false;
//		good[v] += good[u];
//		bad[v] += bad[u];
//		append(good[v], good[u]);
//		append(bad[v], bad[u]);
		link[u] = v;
		return true;
	}	
} ds;
int used_cnt[maxn];
void solve() {
	int n, q, m;
	cin >> n >> q >> m;
	ds.init(2 * n);

	while (m--) {
		int u, v, w;
		cin >> w >> u >> v;
		u--, v--;
		if (w == 0) {
			ds.merge(2 * u, 2 * v);
			ds.merge(2 * u + 1, 2 * v + 1);
		} else {
			ds.merge(2 * u, 2 * v + 1);
			ds.merge(2 * u + 1, 2 * v);
		}
	}
	for (int i = 0; i < n; ++i) {
		int t1 = ds.find(2 * i);
		int t2 = ds.find(2 * i + 1);
		ds.bad[t1].push_back(i);
		ds.good[t2].push_back(i);
	}
	
	
	vector<tuple<vector<int>, vector<int>>> candidate;
	for (int i = 0; i < n; ++i) {
		if (ds.find(2 * i) == ds.find(2 * i + 1)) {
			cout << "NO\n";
			return;
		}
	}

	vector<int> vis(2 * n);
	int s = 0;
	for (int i = 0; i < n; ++i) {
		int x = ds.find(2 * i);
		if (vis[x]) continue;
		vis[x] = 1;
		vis[ds.find(2 * i + 1)] = 1;
		
//		 cout << "good\n";
//		for (auto x : ds.good[x]) {
//			cout << x << " ";
//		}
//		cout << "\nbad\n";
//		for (auto x : ds.bad[x]) {
//			cout << x << " ";
//		}
//		cout << "\n---\n"; 
		
		candidate.push_back({std::move(ds.good[x]), std::move(ds.bad[x])});
	
		
	}
	

	
	map<int, int> cnt;
	for (auto& [good, bad] : candidate) {
		if (good.size() > bad.size()) {
			swap(good, bad);
		}
		s += good.size();
		int diff = bad.size() - good.size();
		cnt[diff]++;
	}	
	
	
	vector<pair<int, int>> store;
	for (int diff = 1; diff <= n; ++diff) {
		int num = cnt[diff];
		if (num == 0) continue;
//	for (auto [diff, num] : cnt) {
//		if (num == 0) c
//		vector<int> store;
		int cur = 1;
		while (cur < num) {
//			store.push_back(cur);
			store.emplace_back(diff, diff * cur);
			num -= cur;
			cur <<= 1;
		}
		if (num > 0) {
			store.emplace_back(diff, diff * num);
		}
		
	}
	
//	cout << "init " << s << "\n";
	int num_item = store.size();
//	for (auto [x, y] : store) {
//		cout << x << " " << y << "\n";
//	}
	vector<vector<int>> dp(num_item + 1, vector<int>(n + 1));
	dp[0][s] = 1;
//	vector<vector<pair<int, int>> p(num_item + 1, vector<int>(n + 1));
	for (int i = 0; i < num_item; ++i) {
		auto [group_size, val] = store[i];
		dp[i + 1] = dp[i];
		for (int j = val; j <= n; ++j) {
			if (dp[i][j - val]) {
				dp[i + 1][j] = 1;
//				p[i][j] = {i, j - val};
			}
		}
	}
	
	
	if (dp[num_item][q] == 0) {
		cout << "NO\n";
		return;
	}
	
	
	int cur = q;
	for (int i = num_item - 1; i >= 0; --i) {
		auto [group_size, val] = store[i];
		if (group_size == 0) {
			continue;
		}
		if (dp[i][cur - val]) {
			used_cnt[group_size] += val / group_size;
			cur -= val;
//			cout << "take " << val << "\n";
		} 
	}
	
	
	
	vector<int> is_good(n);
	
	for (auto& [good, bad] : candidate) {
		int diff = bad.size() - good.size();
		if (used_cnt[diff]) {
			used_cnt[diff]--;
			for (auto x : bad) {
				is_good[x] = 1;
			}
		} else {
			for (auto x : good) {
				is_good[x] = 1;
			}
		}
	}

	cout << "YES\n";
	for (int i = 0; i < n; ++i) {
		if (is_good[i]) {
			cout << i + 1<< " ";
		}
	}
	cout << "\n";
}

signed main() {
	ios::sync_with_stdio(false);
	solve();
	
}


/*
4 2 2
0 3 4
0 1 2

4 2 4
1 1 3
1 2 4
0 3 4
0 1 2

13 7 11
0 1 2
0 1 3
0 1 4
0 1 5
1 1 6
1 1 7
0 8 9
0 8 10
0 8 11
1 13 12
1 12 13
*/