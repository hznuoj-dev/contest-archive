#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 1e5 + 7;
int n,m;
int a[20][20],b[20][20];

bool p(int x)
{
	if(x==1) return 0;
	if(x==2) return 1;
	if(x%2==0) return 0;
	for(int i=3;i*i<=x;i++)
	{
		if(x%i==0) return 0;
	}
	return 1;
}

signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int T;
	T = 1;
	while(T --){
		cin>>n>>m;
		if(n==1||m==1) cout<<"YES\n";
		else if(n%m==0) cout<<"NO\n";
		else if(m==2)
		{
			if(n%2==0) cout<<"NO\n";
			else cout<<"YES\n";
		}
		else
		{
			if(n<=m) cout<<"NO\n";
			else
			{
				if(p(n)) cout<<"YES\n";
				else cout<<"NO\n";
			}
		}
	}
}