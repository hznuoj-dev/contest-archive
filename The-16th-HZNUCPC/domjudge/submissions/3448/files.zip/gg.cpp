#include<iostream>
using namespace std;
int main()
{
	long long m,a,b;
	cin>>a>>b;
	if (b=1)
	 m=1;
	 else{
     if (a%2!=0&&a%b!=0&&a>b)
      m=1;}
     
	if (m==1)
	 cout<<"YES";
	else
	 cout<<"NO";
}