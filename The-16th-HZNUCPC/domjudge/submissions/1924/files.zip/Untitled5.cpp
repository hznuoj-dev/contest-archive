#include<bits/stdc++.h>
#define ll long long
#define PII pair<int,int>
#define x first
#define y second
#define int long long
using namespace std;
//const int INF,maxn;
PII p[110];
ll dis[110][110];
ll gcd(ll a,ll b){
	return __gcd(a,b);
}
void solve(){
	int n;
	cin >> n;
	ll dx,dy,x0,y0,flag=0;
	for(int i=1;i<=n;i++){
		cin >> p[i].x >> p[i].y;
	}
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			dx=abs(p[i].x-p[j].x),dy=abs(p[i].y-p[j].y);
			if(dx==0){
				dis[i][j] = abs(p[i].y-p[j].y)-1;
				continue;
			}
			if(dy % dx==0){
				dis[i][j] = dx-1;
				continue;
			}
			dis[i][j] = (dx-1)/(dx/gcd(dx,dy));
		}
	}
	ll ans=0;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			for(int k=j+1;k<=n;k++){
				if(p[i].x==p[j].x && p[j].x==p[k].x || (p[j].y-p[i].y)*(p[k].x-p[j].x) == (p[k].y-p[j].y)*(p[j].x-p[i].x)){
					continue;
				}
				ans = max(ans,dis[i][j]+dis[j][k]+dis[i][k]+3);
			}
		}
	}
//	cout << dis[1][2] << " " << dis[1][3] << " " << dis[2][3] << endl;
	cout << ans << endl;
	return;
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	int T = 1;
	while(T--) solve();
	return 0;
}
