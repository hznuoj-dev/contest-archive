#include<bits/stdc++.h>
using namespace std;

int n;
long long x[103],y[103];
long long ans;
long long get(int a,int b)
{
    long long dx=abs(x[a]-x[b]),dy=abs(y[a]-y[b]);
    if(dx==0||dy==0)
    {
        return max(dx,dy)+1;
    }
    return __gcd(dx,dy)+1;
}
int check(int a,int b,int c)
{
    if((y[c]-y[a])*(x[c]-x[b])==(x[c]-x[a])*(y[c]-y[b]))return 1;
    return 0;
}
void sol()
{
    scanf("%d",&n);
    for(int i=1;i<=n;++i)
    {
        scanf("%lld%lld",&x[i],&y[i]);
    }
    ans=0;
    long long sum=0;
    for(int i=1;i<=n;++i)
    {
        for(int j=i+1;j<=n;++j)
        {
            for(int k=j+1;k<=n;++k)
            {
                if(check(i,j,k)==1)continue;
                sum=get(i,j)+get(i,k)+get(j,k)-3;
                //printf("[%lld]\n",sum);
                ans=max(ans,sum);
            }
        }
    }
    printf("%lld",ans);
}
int main()
{
    int t=1;
    //scanf("%d",&t);
    while(t--)
    sol();
    return 0;
}
