#include <bits/stdc++.h>
using namespace std;
const int N = 100010;
typedef long long ll;
#define int ll
const int B = 233;
const int M1 = 1e9+7;
const int M2 = 1e9+81;

ll hs[N],hs2[N],powb[N];
int t;
int mp[35][35];
int n;
signed main(){
	cin >> t;
	while(t--){
		memset(mp,0,sizeof mp);
		int ans = 0;
		cin >> n;
		for(int i = 1;i<=n;i++){
			int x,y,color;
			cin >> x >> y >> color;
			mp[x][y] = color;
		} 
		for(int i = 0;i<=30;i++){
			for(int j = 0;j<=30;j++){
				if(mp[i][j] == 1){
					if(mp[i+1][j] == 0 && (i+1) >= 1 && (i+1) <= 19 && j >= 1 && j <= 19){
						ans++;
					}
					if(mp[i-1][j] == 0 && (i-1) >= 1 && (i-1) <= 19 && j >= 1 && j <= 19){
						ans++;
					}
					if(mp[i][j-1] == 0 && (i) >= 1 && (i) <= 19 && (j-1) >= 1 && (j-1) <= 19){
						ans++;
					}
					if(mp[i][j+1] == 0 && (i) >= 1 && i <= 19 && (j+1) >= 1 && (j+1) <= 19){
						ans++;
					}
				}
			}
		}
		cout << ans << endl;
	}
}