#include<bits/stdc++.h>
using namespace std;
#define int long long 
int n,m;
void solve(){
	while(cin>>n>>m){
		if(n==1||m==1){
			cout<<"YES"<<endl;
		}else if(n<=m){
			cout<<"NO"<<endl;
		}else{
			int f=0;
			while(1){
				if(m==1)break;
				if(n%m==0){
					f=1;
					break;
				}
				m=n%m;
			}
			if(f==0){
				cout<<"YES"<<endl;
			}else{
				cout<<"NO"<<endl;
			}
		}
	}
}
signed main(){
	solve();
	return 0;
}