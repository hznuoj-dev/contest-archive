#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define MOD 1000000007;
ll func(ll n){
	for(int i=2;i<=n/i;i++){
		if(n%i==0) return i;
	}
	return 1e13;
}
void solve(){
	ll a,b;
	cin>>a>>b;
	bool pd=true;
	if(b==1){
		cout<<"YES";
		return;
	}
	if(a<=b){
		cout<<"NO";
		return;
	}
	ll tmp=func(a);
	if(tmp<=b){
		cout<<"NO";
	}else{
		cout<<"YES";
	}
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	solve();
	return 0;
}