import java.util.*;
import java.io.*;

public class Main {
	static StreamTokenizer sr=new StreamTokenizer(new BufferedReader(new InputStreamReader(System.in))); 
	
	static Scanner in = new Scanner(System.in);
	static int[][] dt ;
	static int[] dx={0,1,0,-1};
	static int[] dy={1,0,-1,0};
	public static void main(String[] args)  {
		// TODO Auto-generated method stub
		int t = in.nextInt();
		while (t -- > 0) {
			int ans = 0;
			
//			dt= new int[20][20];
//			int x, y, type;
//			int n = in.nextInt();
//			for (int i = 1; i <= n; i ++) {
//				x = in.nextInt();
//				y = in.nextInt();
//				type = in.nextInt();
//				if(dt[x][y]==0){
//					dt[x][y]=type;
//					for(int j=0;j<4;j++){
//						int X=x+dx[j],Y=y+dy[j];
//						if(X>0&&X<=19&&Y>0&&Y<=19&&dt[X][Y]!=0&&dt[X][Y]!=type){
//							int[][] st=new int[20][20];
//							if(!q(X,Y,type,st))dt[X][Y]=0;
//						}
//					}
////					for (int k = 1; k <= 19; k ++) {
////						for (int j = 1; j <= 19; j ++) {
////							System.out.print(dt[k][j]+" ");
////						}
////						System.out.println();
////					}
//					int[][] s=new int[20][20];
//					if(!p(x,y,type,s))dt[x][y]=0;
//				}
//			}
//			
////			for (int i = 1; i <= 19; i ++) {
////				for (int j = 1; j <= 19; j ++) {
////					System.out.print(dt[i][j]+" ");
////				}
////				System.out.println();
////			}
			dt = new int[20][20];
			int x, y, c, n = in.nextInt();
			for (int i = 1; i <= n; i ++) {
				x = in.nextInt();
				y = in.nextInt();
				c = in.nextInt();
				dt[x][y] = c;
			}
			
			for (int i = 1; i <= 19; i ++) {
				for (int j = 1; j <= 19; j ++) {
					if (dt[i][j] == 0) {
						if (i - 1 >= 1 && dt[i - 1][j] == 1) ans ++;
						if (j - 1 >= 1 && dt[i][j - 1] == 1) ans ++;
						if (i + 1 <= 19 && dt[i + 1][j] == 1) ans ++;
						if (j + 1 <= 19 && dt[i][j + 1] == 1) ans ++;
					}
				}
			}
			System.out.println(ans);
		}
	}
	public static boolean f(int x,int y){
		if (x - 1 >= 1 && dt[x - 1][y] == 0) return true;
		if (y - 1 >= 1 && dt[x][y - 1] == 0) return true;
		if (x + 1 <= 19 && dt[x + 1][y] == 0)return true;
		if (y + 1 <= 19 && dt[x][y + 1] == 0) return true;
		return false;
	}
	public static boolean q(int x,int y,int t,int[][] st){
		st[x][y]=1;
		for(int j=0;j<4;j++){
			int X=x+dx[j],Y=y+dy[j];
			if(X>0&&X<=19&&Y>0&&Y<=19&&st[X][Y]==0){
				if(dt[X][Y]==0)return true;
				if(dt[X][Y]!=t){
					if(q(X,Y,t,st))return true;
				}
			}
		}
		dt[x][y]=0;
		return false;
	}
	public static boolean p(int x,int y,int t,int[][] st){
		st[x][y]=1;
		for(int j=0;j<4;j++){
			int X=x+dx[j],Y=y+dy[j];
			if(X>0&&X<=19&&Y>0&&Y<=19&&st[X][Y]==0){
				if(dt[X][Y]==0)return true;
				if(dt[X][Y]==t){
					if(p(X,Y,t,st))return true;
				}
			}
		}
		dt[x][y]=0;
		return false;
	}

}
