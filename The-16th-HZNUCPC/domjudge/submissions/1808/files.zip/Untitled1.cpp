#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl "\n"
const int maxn=1e4+10;
/*int factor[maxn];
int fast_pow(int x,int y,int m)
{
	int res=1;
	x%=m;
	while(y)
	{
		if(y&1) res=(res*x)%m;
		x=(x*x)%m;
		y>>=1;
	}
	return res;
}
bool witness(int a,int n){
	int u=n-1;
	int t=0;
	
	
}
int miller_rabin(int n,int s)
{
	if(n<2) return0;
	if(n==2) return 1;
	if(n%2==0) return 0;
	for(int i=0;i<s&&i<n;i++)
	{
		int a=rand()%(n-1)+1;
		if(witness(a,n)) return 0;
	}
	return 1;
}

int mult_mod(int a,int b,int n){
	a%=n,b%=n;
	int ret=0;
	while(b){
		if(b&1){
			ret+=a;
			if(ret>=n) ret-=n;
		}
		a<<=1;
		if(a>=n) a-=n;
		b>>=1;
	}
	return ret;
	
}
int po(int n){
	int i=1,k=2;
	int c=rand()%(n-1)+1;
	int x=rand()%n;
	int y=x;
	while(true){
		i++;
		x=(mult_mod(x,x,n)+c)%n;
		int d=__gcd(y>x?y-x:x-y,n);
		if(d!=1&&d!=n) return d;
		if(y==x) return n;
		if(i==k) {
			y=x;k=k<<1;
		}
	}
}
void findfac(int n){
	int tol=0;
	if(miller_rabin(n)){
		factor[tol++]=n;
		return;
	}
	int p=n;
	while(p>=n) p=po(p);
	findfac(p);
	findfac(n/p);
}
*/
void solve(){
	int n,m,ans=0;
	int f=0;
	cin>>n>>m;
	if(n<m&&n!=1) cout<<"NO\n";
	else if(n==1||m==1) cout<<"YES\n";
	else if(n%m==0) cout<<"NO\n";
	else if(n%2==0) cout<<"NO\n";
	else{
		for(int i=2;i<=m;i++)
		{
			if(n%i==0){
				f=1;
				break;
			}
		}
		if(!f) cout<<"YES\n";
		else cout<<"NO\n";
	}
	
}
signed main(){
	int T;
	solve();
	return 0;
} 