#include <bits/stdc++.h>
using namespace std;
#define ll long long
const int mod=1e9+7;
string a,b;
ll num=0;
ll dp[100005];
int main(){
	cin>>a>>b;
	int lens = a.length();
	a = " " + a;
	b = " " + b;
	dp[0] = 1;
	for(int i = 1; i <= lens; i++) {
		if(a[i] == b[i]) {
			dp[i] = (dp[i - 1] + 1) % mod;
		} else {
			dp[i] = max(dp[i], dp[i - 1]);
		}
	}
	if(a == b) {
		ll sums = 0;
		for(int i = 1; i <= lens - 1; i++) {
			sums = (sums + i) % mod;
		}
		cout << sums % mod;
		return 0;
	}
	cout << (dp[lens] + 1) % mod;
	return 0;
}
