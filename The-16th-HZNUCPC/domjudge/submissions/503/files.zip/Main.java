import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StreamTokenizer;
import java.util.HashSet;


public class Main {
	static PrintWriter out=new PrintWriter(System.out);
	static BufferedReader ins =new BufferedReader(new InputStreamReader(System.in));
	static StreamTokenizer in =new StreamTokenizer(ins);
	public static void main(String[] args) throws IOException {
//		in.nextToken();
//		int n=(int)in.nval;
//		System.out.print(n);
		char[] arr1=ins.readLine().toCharArray();
		char[] arr2=ins.readLine().toCharArray();
		int length=arr1.length;
		HashSet<Character> set1 =new HashSet<>();
		HashSet<Character> set2 =new HashSet<>();
		for(int i=0;i<length;i++){
			set1.add(arr1[i]);
			set2.add(arr2[i]);
		}
		int size1=set1.size();
		int size2=set2.size();
		int min=Math.min(size1, size2);
		int max=Math.max(size1, size2);
		if(max==1){
			System.out.print((length)*(length-1)/2);
		}else{
			System.out.print((max-1)*(length-max+1));
		}
	}
}
