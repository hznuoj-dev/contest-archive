#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
const int N = 2e5 + 10, M = 2e5 + 10, inf = 0x3f3f3f3f;
struct nodet {
    int time;
    int kind; // 1 : bus, 2 :people
    int l, r; // bus
    int pos; // people
    int idx; // qry
    bool operator<(const nodet &o) {
        if (time == o.time) {
            if (kind != o.kind) return kind < o.kind;
            return (r > o.r);
        }
        return time > o.time;
    }
}qrys[N];
#define ls u << 1
#define rs u << 1 |1
#define lson tr[ls]
#define rson tr[rs]
struct node {
    int flag;
    int mn;
}tr[M << 2];
void build(int u, int l, int r) {
    tr[u].mn = tr[u].flag = inf;
    if (l == r) {
        return;
    }
    int mid = (l + r) >> 1;
    build(ls, l, mid);
    build(rs, mid + 1, r);
}

void pushup(int u) {
    tr[u].mn = min(rson.mn, lson.mn);
}
void pushdown(int u) {
    if (tr[u].flag != inf) {
        lson.mn = min(tr[u].flag, lson.mn);
        rson.mn = min(tr[u].flag, rson.mn);
        lson.flag = min(lson.flag, tr[u].flag);
        rson.flag = min(rson.flag, tr[u].flag);
        tr[u].flag = inf;
    }
}
int qry(int u, int l, int r, int L, int R) {
    if (l <= L && R <= r) {
        return tr[u].mn;
    }
    pushdown(u);
    int mid = (L + R) >> 1;
    int mn = inf;
    if (l <= mid) mn = min(mn, qry(ls, l, r, L, mid));
    if (r > mid) mn = min(mn, qry(rs, l, r, mid +1, R));
    pushup(u);
    return mn;
}
void modify(int u, int l, int r, int L, int R, int x) {
    if (l <= L && R <= r) {
        tr[u].mn = min(x, tr[u].mn);
        tr[u].flag = min(x, tr[u].flag);
        return;
    }
    pushdown(u);
    int mid = (L + R) >> 1;
    if (l <= mid) modify(ls, l, r, L, mid, x);
    if (r >mid) modify(rs, l, r, mid + 1, R, x);
    pushup(u);
}
int res[N];
int main(){
    int n, m, x;
    cin >> n >> m >>x;
    map<int, int> hash_;
    int hashidx = 0;
    for (int i = 1; i <= n; i++) {
        cin >> qrys[i].time >>qrys[i].l >> qrys[i].r;
        qrys[i].kind = 1;
        hash_[qrys[i].l];
        hash_[qrys[i].r];
    }
    hash_[x];
    for (int i =n + 1; i <= n + m; i++) {
        cin >> qrys[i].time >>qrys[i].pos;
        qrys[i].kind = 2;
        qrys[i].idx = i - n;
        hash_[qrys[i].pos];
    }
    for (auto &[_, y] : hash_) {
        y = ++hashidx;
    }
    build(1, 1, hashidx);
    modify(1, hash_[x], hash_[x], 1, hashidx, 0);
    // for (int i = 1; i <= hashidx; i++) {
    //             cout << qry(1, i, i, 1, hashidx) << ' ';
    //         }
    //         cout << '\n';
    sort(qrys +1, qrys +n + m +1);
    for (int i = 1; i <= n + m; i++) {
        if (qrys[i].kind == 1) {
            int l = hash_[qrys[i].l], r = hash_[qrys[i].r];
            int mn = qry(1, l, r, 1, hashidx);
            modify(1, l, r, 1, hashidx, mn + 1);
            // for (int i = 1; i <= hashidx; i++) {
            //     cout << qry(1, i, i, 1, hashidx) << ' ';
            // }
            // cout << '\n';
        } else {
            int pos = hash_[qrys[i].pos];
            int ok = qry(1, pos, pos, 1, hashidx);
            if (ok == inf) {
                ok = -1;
            }
            res[qrys[i].idx] = ok;
        }
    }
    for (int i = 1; i <= m; i++) {
        cout << res[i] <<'\n';
    }
}
