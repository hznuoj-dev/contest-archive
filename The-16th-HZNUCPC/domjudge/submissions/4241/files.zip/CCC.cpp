#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<char,char> pcc;
map<pcc,int> mpa,mpb;
const int N=1e5+100;
const ll p=1e9+7;
set<char> sta,stb;
map<char,int> ca,cb;
ll binpow(ll a,ll b,ll p){ll res=1%p;for(;b;b>>=1){if(b&1)res=res*a%p;a=a*a%p;}return res;}
#define mmi(a,b) binpow(a,b-2,b)
ll Lucas(ll n){return((n*(n-1))%p*mmi(2,p))%p;}
int res[10];
signed main(){
	string a,b;
	cin>>a>>b;
	a="#"+a,b="#"+b;
	int n=a.size()+1;
	for(int i=1;i<=n;i++){
		mpa[{a[i],b[i]}]++;
		mpb[{b[i],a[i]}]++;
		sta.insert(a[i]);
		stb.insert(b[i]);
		if(a[i]==b[i]) res[0]++;
		ca[a[i]]++,cb[b[i]]++;
	}
	int sza=sta.size(),szb=stb.size();
	for(auto p:mpa){//a
		for(auto op:mpb){//b
			if((p.first.first==op.first.second)&&(p.first.second==op.first.first)) continue;
			ll tmpa=0,tmpb=0;
			ll taa=ca[p.first.first],tab=ca[p.first.second],tba=cb[p.first.first],tbb=cb[p.first.second];
			if(tab==0) tmpa++,tab=1;
			if(taa==1) tmpa--,taa=0;
			if(tba==0) tmpb++,tba=1;
			if(tbb==1) tmpb--,tba=0;
			ll r=tmpa-tmpb;
			if(r>=0) res[r]+=p.second*op.second;
			else if(r==-1) res[3]+=p.second*op.second;
			else if(r==-2) res[4]+=p.second*op.second;
		}
	}
	if(sza==szb){
		ll ans=((Lucas(res[0])+(res[1]*res[3])%p)%p+((res[2]*res[4]))%p)%p;
		printf("%lld\n",ans%p);
	}
	if(sza-szb==1){
		ll ans=((res[0]*res[3])%p+(res[1]*res[4])%p)%p;
		printf("%lld\n",ans%p);
	}
	if(sza-szb==2){
		ll ans=((res[0]*res[4])%p+Lucas(res[3]))%p;
		printf("%lld\n",ans%p);
	}
	if(sza-szb==3){
		ll ans=(res[3]*res[4])%p;
		printf("%lld\n",ans%p);
	}
	if(sza-szb==4){
		ll ans=Lucas(res[4]);
		printf("%lld\n",ans%p);
	}
	if(sza-szb>4){
		puts("0");
	}
	return 0;
}
