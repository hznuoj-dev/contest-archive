#include<iostream>
#include<cstring>
#include<algorithm>

using namespace std;
typedef long long int ll;
ll n,m;

int main()
{
	cin>>n>>m;
	if(m>=n) cout<<"NO";
	else if(m == 1||n == 1) cout<<"YES";
	else if(n%2==0) cout<<"NO";
	else if(n%m == 0) cout<<"NO";
	else
	{
		ll x=n%m;
		while(1)
		{
			x=n%x;
			if(x==0) 
			{
				cout<<"NO";
				break;
			}
			if(x==1) 
			{
				cout<<"YES";
				break;
			}
		}
	
	} 
}