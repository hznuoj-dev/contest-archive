#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int mp[20][20],ans,n;
int dx[]={0,0,1,-1};
int dy[]={1,-1,0,0};
void Main(){
	scanf("%d",&n);
	memset(mp,0,sizeof mp);
	for (int i=1,x,y,c;i<=n;++i){
		scanf("%d%d%d",&x,&y,&c);
		mp[x][y]=c;
	}
	ans=0;
	for (int i=1;i<=19;++i)
		for (int j=1;j<=19;++j){
			if (mp[i][j]==1){
				for (int k=0;k<4;++k){
					int tx=i+dx[k];
					int ty=j+dy[k];
					if (tx<1||ty<1||tx>19||ty>19) continue;
					if (mp[tx][ty]==0){
						++ans;
//						mp[tx][ty]=2;
//				cout<<tx<<' '<<ty<<'\n';
					}
				}
			}
		}
	printf("%d\n",ans);
}
int main(){
	int T;
	scanf("%d",&T);
	while (T--){
		Main();
	}
	return 0;
}