#include <bits/stdc++.h>
using namespace std;
const int N=1e6+10;


int main()
{	
    long long n,m;cin>>n>>m;

	int flag=1;

	if(n<=m)flag=0;
	else if(m==1)flag=1;
	else if(n%m==0)flag=0;

	if(flag)printf("YES");
	else printf("NO");
	
	return 0;
}