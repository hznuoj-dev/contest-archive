#include<stdio.h>
#include<string.h>
int main() {
	int n;
	scanf("%d",&n);
	int i,len,max,q;
	char a[5000];
	getchar();
	for(i=0; i<n; i++) {
		gets(a);
		len=strlen(a);
		int x,y,z;
		max=0;
		int t;
		for(x=0; x<len-1; x++) {
			y=x;
			t=0;
			if(a[y]==a[y+1]&&a[y]!=a[y-1]) {
				z=y+1;
				q=0;
			} else {
				z=y;
				q=1;
				t--;
			}
			while(y>=0&&z<=len-1) {
				if(a[y--]!=a[z++])break;
				t++;
			}
			if(max<2*t+q)max=2*t+q;
			if(max==1)max=0;
		}
		printf("%d\n",max);
	}
}