#include  <bits/stdc++.h>

using namespace std;
typedef long long LL;
const int mod = 1e9 + 7;
void kizk(){
	string a, b; cin >> a >> b;
    int n = a.size();
    map<char, int> ma, mb;
    set<char> sa, sb;
    for(int i = 0; i < n; i ++)
    {
        ma[a[i]] ++ ;
        mb[b[i]] ++ ;
        sa.insert(a[i]);
        sb.insert(b[i]);
    }
    int sizea = sa.size(), sizeb = sb.size();
    map<int, int> mp;
    int d = sizeb - sizea;
    LL res = 0;
    for(int i = 0; i < n; i ++)
    {
        int cnta = ma[a[i]];
        int cntb = mb[b[i]];
        int da = 0, db = 0;
        if(cnta == 1)
            da -- ;
        if(ma[b[i]] == 0)
            da ++ ;
        if(cntb == 1)
            db -- ;
        if(mb[a[i]] == 0)
            db ++ ;
        int dx = da - db;
        res = (res + mp[d - dx]) % mod;
        mp[dx] ++ ;
    }

    cout << res << "\n";
}


int main(){
	std::ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int T; T = 1;
	// cin >> T;
	while(T --) kizk();
	return 0;
}