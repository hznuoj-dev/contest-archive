#include <bits/stdc++.h>

#define ll long long

using namespace std;
ll n,m;//ncai,mxuan
int main(){
	cin>>n>>m;
	if(m==1 || n==1){
	cout<<"YES"<<endl;
	return 0;
	}
	if(n<=m|| __gcd(n,m)!=1) {
	cout<<"NO"<<endl;
	return 0;
	}
	int p=0;
	while(m!=0 || m!=1){
		if(n==1 || m==1 || n%m==1) {
		cout<<"YES"<<endl;
		p=1; 
		break;
		}
		m=n%m;
	}
	if(m&&!p) cout<<"YES"<<endl;
	if(!m&&!p) cout<<"NO"<<endl;
	return 0;
}