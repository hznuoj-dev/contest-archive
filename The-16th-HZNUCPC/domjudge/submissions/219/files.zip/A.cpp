#include <bits/stdc++.h>
using namespace std;

const int kMaxN = 25;
const int dx[] = {1, 0, -1, 0},
          dy[] = {0, 1, 0, -1};
int vis[kMaxN][kMaxN];

int main() {
	ios::sync_with_stdio(false);
	int T;
	cin >> T;
	
	while (T--) {
		memset(vis, 0x00, sizeof vis);
		int n;
		cin >> n;
		for (int i = 1; i <= n; ++i) {
			int x, y, c;
			cin >> x >> y >> c;
			vis[x][y] = c;
		}
		int ans = 0;
		for (int i = 1; i <= 19; ++i)
			for (int j = 1; j <= 19; ++j) {
				if (vis[i][j] == 1) {
					for (int d = 0; d < 4; ++d) {
						int nx = i + dx[d], ny = j + dy[d];
						if (nx <= 0 || ny <= 0 || nx > 20 || ny > 20) continue;
						if (vis[nx][ny] == 0) {
//							vis[nx][ny] = 3;
//							cout << nx << " " << ny << "\n";	
							++ans;
						}
					}
				}
			}
//		for (int i = 1; i <= 19; ++i)
//			for (int j = 1; j <= 19; ++j)
//				ans += (vis[i][j] == 3);
		cout << ans << "\n";
	}
	return 0;
}