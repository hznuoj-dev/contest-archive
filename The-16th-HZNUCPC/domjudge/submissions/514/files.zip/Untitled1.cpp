#include "iostream"
using namespace std;
long long a,b,c,d,e,f;
int main(){
	while(cin>>a>>b){
		long long k=b;
		e=0;
		if(a%b!=0){
		while(k!=1&&e==0){
			c=a%k;
			d=a/k;
			k=a-d*k;
			if(c==0){
				e=1;
			}
			
		}
		if(k==1){
			cout<<"YES"<<endl;
		}else{
			cout<<"No"<<endl;
		}
	}else{
		cout<<"NO"<<endl;
	}
}
	return 0;
}