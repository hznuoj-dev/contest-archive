#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define debug(x) cerr<<#x<<" "<<x<<"\n"
unordered_map<int,int>mp[25];
int a[400],b[400],c[400];
int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};
void _solve(){
   int n,i,j;
   scanf("%d",&n);

   for(i=1;i<=19;i++)mp[i].clear();
   for(int i=1;i<=19;i++)mp[0][i]=mp[20][i]=mp[i][0]=mp[i][20]=3;
   for(i=1;i<=n;i++)
   {
       scanf("%d%d%d",&a[i],&b[i],&c[i]);
       mp[a[i]][b[i]]=c[i];
   }
   int sum=0;
   for(i=1;i<=n;i++)
   {
       if(c[i]==1)
       {
           for(j=0;j<4;j++)
           {
               int nx=a[i]+dx[j];
               int ny=b[i]+dy[j];
               if(!mp[nx].count(ny))
               {
                   //printf("nx=%d  ny=%d\n",nx,ny);
                   sum++;
               }
           }
       }
   }
   printf("%d\n",sum);
}

int main(){
    ios::sync_with_stdio(false);

    int T;cin>>T;while(T--)
    _solve();
}
