#pragma GCC optimize(2)
#include<bits/stdc++.h>
using namespace std;
#define quick_cin() cin.tie(0),cout.tie(0),ios::sync_with_stdio(false)
#define rep1(i,a,n) for(int i=(a);i<(n);++i)
#define rep2(i,a,n) for(int i=(a);i<=(n);++i)
#define per1(i,n,a) for(int i=(n);i>(a);--i)
#define per2(i,n,a) for(int i=(n);i>=(a);--i)
#define endl "\n"
typedef long long LL;
#define dbug(a) cout<<(a)<<"\n"
#define dbug2(a,b) cout<<(a)<<" "<<(b)<<"\n"
#define dbug3(a,b) cout<<(a)<<" "<<(b)<<" "<<(c)<<"\n"

#define int LL
int n,m;
int mp[110][100];
int ans=0;
int st[110][110];
int dx[]={0,0,1,-1},dy[]={1,-1,0,0};

void dfs(int x,int y)
{
	st[x][y]=1;
	rep1(i,0,4)
	{
		int nx=x+dx[i];
		int ny=y+dy[i];
		if(nx>=1&&nx<=19&&ny>=1&&ny<=19&&mp[nx][ny]==0)ans++;
		if(nx>=1&&nx<=19&&ny>=1&&ny<=19&&mp[nx][ny]==1&&!st[nx][ny])dfs(nx,ny);	
	}
}
void solve()
{
	memset(mp,0,sizeof mp);
	memset(st,0,sizeof st);
	ans=0;
	cin>>n;
	rep2(i,1,n)
	{
		int x,y,c;
		cin>>x>>y>>c;
		mp[x][y]=c;
	}	
	rep2(i,1,19)
	{
		rep2(j,1,19)
		if(!st[i][j]&&mp[i][j]==1)dfs(i,j);
	}
	dbug(ans);
}
signed main ()
{
	quick_cin();
	
	int T;
	cin>>T;
	while(T--)solve();
	return 0;
}