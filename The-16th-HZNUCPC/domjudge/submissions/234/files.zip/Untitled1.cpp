#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll mid=1e9+7;
int mp[20][20];
int xf[4]={0,1,0,-1};
int yf[4]={1,0,-1,0};
int main(){
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		for(int i=0;i<20;i++){
			for(int j=0;j<20;j++) mp[i][j]=0;
		}
		for(int i=0;i<n;i++){
			int x,y,c;
			cin>>x>>y>>c;
			mp[x][y]=c;
		}
		int sum=0;
		for(int i=0;i<20;i++){
			for(int j=0;j<20;j++){
				if(mp[i][j]==1){
					for(int k=0;k<4;k++){
						if(xf[k]+i>0&&xf[k]+i<20&&yf[k]+j>0&&yf[k]+j<20){
							if(mp[xf[k]+i][yf[k]+j]==0)sum++;
						}
					}
				}
			}
		}
		cout<<sum<<"\n";
	}
}