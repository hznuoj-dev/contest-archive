#include<bits/stdc++.h>
using namespace std;
const int N=2e5+7;
const int MOD=1e9+7;
#define int long long
int n;
int cnt[30][30],cnta[30],cntb[30];
char s[N],str[N];
int kuasum(int a,int b){
	int ans=1;
	while(b){
		if(b&1)ans=ans*a%MOD;
		b>>=1;
		a=a*a%MOD;
	}
	return ans;
}
int check(){
	int siza=0,sizb=0;
	for(int i=0;i<26;i++){
		if(cnta[i])siza++;
		if(cntb[i])sizb++;
	}
	return siza==sizb;
}
signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	cin>>(s+1)>>(str+1);n=strlen(s+1);
	for(int i=1;i<=n;i++){
		int x=s[i]-'a',y=str[i]-'a';
		cnt[x][y]++;cnta[x]++;cntb[y]++;
	}
	int ans1=0,ans2=0;
	for(int i=0;i<26;i++){
		for(int j=0;j<26;j++){
			if(!cnt[i][j])continue;
			int x=cnt[i][j];
			cnt[i][j]--;cnta[i]--;cnta[j]++;cntb[j]--;cntb[i]++;
			for(int k=0;k<26;k++){
				for(int o=0;o<26;o++){
					if(!cnt[k][o])continue;
					int y=cnt[k][o];
					cnt[k][o]--;cnta[k]--;cnta[o]++;cntb[o]--;cntb[k]++;
					if(check()){
						if(i==k&&j==o)ans1+=x*(x-1)/2;
						else ans2+=x*y;
						ans1%=MOD;ans2%=MOD;
					}
					cnt[k][o]++;cnta[k]++;cnta[o]--;cntb[o]++;cntb[k]--;
				}
			}
			cnt[i][j]++;cnta[i]++;cnta[j]--;cntb[j]++;cntb[i]--;
		}
	}
	ans2=ans2*kuasum(2,MOD-2)%MOD;
	ans1=(ans1+ans2)%MOD;
	cout<<ans1<<"\n";
	return 0;
}