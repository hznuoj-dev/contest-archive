#include <iostream>
#include <cstdio>
#include <bits/stdc++.h>
#include <cstdlib>
#include <cmath>
#include <stack>
using namespace std;
typedef long long ll;

ll n, m;
ll k=0;
bool e=0;
int main()
{
   cin >> n >> m;
   k = n % m;
   while(k > 1)
   {
       m = k;
       k = n % m;
   }
   if(k)
   {
       cout << "YES";
   }
   else
   {
       cout << "NO";
   }
   return 0;
}