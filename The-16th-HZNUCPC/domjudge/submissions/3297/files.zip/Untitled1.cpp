#include<bits/stdc++.h>
using namespace std;
//#define int long long 
typedef long long ll;

const int N=3e5+7,MOD=1e9+7,INF=0x3f3f3f3f;
int n,m,x,ans[N];
struct bus{
	int t,l,r;
}b[N];
bool cmpBus(bus a,bus b){
	if(a.t!=b.t) return a.t>b.t;
	if(a.r!=b.r) return a.r>b.r;
	return a.l>b.l;
}
struct per{
	int id,t,pos;
}p[N];
bool cmpPer(per a,per b){
	return a.t>b.t;
}

set<int> s;
unordered_map<int,int> mp;
void liSanHua(){
	s.insert(x);
	for(int i=1;i<=n;i++){
		s.insert(b[i].l);
		s.insert(b[i].r);
	}
	for(int i=1;i<=m;i++) s.insert(p[i].pos);
	int cnt=0;
	for(auto x:s){
		cnt++;
		mp[x]=cnt;
	}
	for(int i=1;i<=n;i++){
		b[i].l=mp[b[i].l];
		b[i].r=mp[b[i].r];
	}
	for(int i=1;i<=m;i++) p[i].pos=mp[p[i].pos];
	x=mp[x];
}

struct node{
	int l,r,minn,mark;
}t[N*4];
void up(int id){
	t[id].mark=INF;
	if(t[id].l==t[id].r) return;
	t[id].minn=min(t[id<<1].minn,t[id<<1|1].minn);
	t[id].mark=max(t[id<<1].mark,t[id<<1|1].mark);
}
void build(int id,int l,int r){
	t[id].l=l;
	t[id].r=r;
	if(l==r){
		if(l==x) t[id].minn=0;
		else t[id].minn=INF;
		t[id].mark=INF;
		return;
	}
	build(id<<1,l,(l+r)/2);
	build(id<<1|1,(l+r)/2+1,r);
	up(id);
}
void down(int id){
	if(t[id].l==t[id].r){
		t[id].minn=min(t[id].minn,t[id].mark);
//		t[id].mark=INF;
		return;
	}
	t[id<<1].mark=min(t[id<<1].mark,t[id].mark);
	t[id<<1|1].mark=min(t[id<<1|1].mark,t[id].mark);
	t[id<<1].minn=min(t[id<<1].minn,t[id].mark);
	t[id<<1|1].minn=min(t[id<<1|1].minn,t[id].mark);
}
void update(int id,int l,int r,int mark){
	if(t[id].l==l&&t[id].r==r){
		t[id].mark=min(t[id].mark,mark);
		t[id].minn=min(t[id].minn,mark);
		return;
	}
	if(mark>=t[id].mark) return;
	
	down(id);
	int mid=(t[id].l+t[id].r)/2;
	if(r<=mid){
		update(id<<1,l,r,mark);
	}else if(l>mid){
		update(id<<1|1,l,r,mark);
	}else{
		update(id<<1,l,mid,mark);
		update(id<<1|1,mid+1,r,mark);
	}
	up(id);
}
int query(int id,int l,int r){
	if(t[id].l==l&&t[id].r==r){
		return t[id].minn;
	}
	down(id);
	int mid=(t[id].l+t[id].r)/2;
	if(r<=mid){
		return query(id<<1,l,r);
	}else if(l>mid){
		return query(id<<1|1,l,r);
	}else{
		return min(query(id<<1,l,mid),query(id<<1|1,mid+1,r));
	}
}

void solve(){
	cin>>n>>m>>x;
	for(int i=1;i<=n;i++) cin>>b[i].t>>b[i].l>>b[i].r;
	for(int i=1;i<=m;i++){
		cin>>p[i].t>>p[i].pos;
		p[i].id=i;
	}
	liSanHua();
	sort(b+1,b+1+n,cmpBus);
	sort(p+1,p+1+m,cmpPer);
	build(1,1,x);
	for(int i=1,j=1;i<=m;i++){
		for(;j<=n&&b[j].t>=p[i].t;j++){
			int minn=query(1,b[j].l,b[j].r);
			update(1,b[j].l,b[j].r,minn+1);
		}
		int x=query(1,p[i].pos,p[i].pos);
		if(x==INF) x=-1;
		ans[p[i].id]=x;
	}
	for(int i=1;i<=m;i++) cout<<ans[i]<<'\n';
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0),cout.tie(0);
	int t = 1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}
/*
6 3 10
1 1 10
2 3 6
3 5 9
4 7 10
5 3 8
6 7 10
1 1
2 4
6 5

*/