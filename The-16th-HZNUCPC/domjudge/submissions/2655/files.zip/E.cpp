#include<iostream>
#include<cmath>
using namespace std;
#define int long long
struct poi{
int x,y;
};
int gcd(int a,int b){
	return b? gcd(b,a%b):a;
}
double dis(poi p1,poi p2){
	double r;
	r=sqrt(pow(p1.x-p2.x,2)+pow(p1.y-p2.y,2));
	return r;
} 
int cntp(poi p1,poi p2,double dis){
	int dx,dy;
	dx=abs(p1.x-p2.x);
	dy=abs(p1.y-p2.y);
	double k;
	int r;
	//cout<<"x1="<<p1.x<<"y1="<<p1.y<<endl;
	//cout<<"x2="<<p2.x<<"y2="<<p2.y<<endl;
	//cout<<"dx="<<dx<<",dy="<<dy<<endl;
	if(dx!=0&&dy!=0){
		r=dy/(dy/gcd(dx,dy));
		//r=dis/k;           
		//r=(int)(dy/k);
		//cout<<"k="<<k<<endl;
		//cout<<"dis="<<dis<<endl;
	}
	else if(dx==0)r=dy;
	else r=dx;
	//cout<<"cntp="<<r<<endl;
	return r;
}
signed main(){
	 int n;
	 cin>>n;
	 poi p[n];
	 for(int i=0;i<n;i++)cin>>p[i].x>>p[i].y;
	 
	 
	 double a,b,c;
	int maxcnt=0;
	int cnt=0;
	 for(int i=0;i<n;i++){
	 	for(int j=0;j<n;j++){
	 		for(int k=0;k<n;k++){
	 			if(i==j||i==k||j==k)continue;
	 			//cout<<endl<<endl<<"i="<<i<<",j="<<j<<",k="<<k<<endl;
	 			a=dis(p[i],p[j]);
	 			b=dis(p[i],p[k]);
	 			c=dis(p[j],p[k]);
	 			if(a+b>c && a+c>b && b+c>a){
				// cout<<a<<" "<<b<<" "<<c<<endl;
	 				cnt=0;
	 				cnt+=cntp(p[i],p[j],a);
	 				cnt+=cntp(p[i],p[k],b);
	 				cnt+=cntp(p[j],p[k],c);
	 				//cnt++;
	 				//cout<<"cnt="<<cnt;
	 				if(cnt>maxcnt)maxcnt=cnt;
			 }
		 }
	 }	
	
}
	cout<<maxcnt;

}