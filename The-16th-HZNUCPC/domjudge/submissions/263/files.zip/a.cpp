#include<bits/stdc++.h>
#define PII pair<int,int>
#define F first
#define S second
using namespace std;
typedef long long LL;

const int N = 1e5,mod = 1;
int q[30][30];
int dx[4] = {0,1,0,-1},dy[4] = {1,0,-1,0};
bool st[30][30];
int main()
{
	int T = 0;
	cin >> T;
	while(T --)
	{
		memset(q,0,sizeof q);
		memset(st,false,sizeof st);
		int n;
		cin >> n;
		for(int i = 1;i <= n;i ++)
		{
			int x,y,z;
			cin >> x >> y >> z;
			x ++;y ++;
			q[x][y] = z;
			if (z == 1) 
				for(int i = 0;i < 4;i ++)
				{
					st[x + dx[i]][y + dy[i]] = 1;
				}
		}
		int ans = 0;
		for(int i = 1;i <= 19;i ++)
			for(int j = 1;j <= 19;j ++)
			{
				if (st[i][j] && q[i][j] == 0) ans ++;
			}
			cout << ans << '\n';
	}	
	
	
		
	return 0;
}