#include<stdio.h>
int main()
{
	int n;
	int a, b;
	
	scanf("%d", &n);
	for(int i = 1; i <= n; i++){
		scanf("%d %d", &a, &b);
		printf("[");
		for(int j = 1; j <= b; j++){
			printf("#");
		}
		for(int j = 1; j <= a - b; j++){
			printf("-");
		}
		printf("] %d%%\n", b * 100 / a);
	}
	return 0;
} 
