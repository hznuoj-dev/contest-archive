#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(){
	int t,n,m,i,j,num=0;
	char a[100],b[100];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		while(n--){
			scanf("%s",a);
			m=strlen(a);
			for(i=0;i<m;i++){
				for(j=i+1;j<m;j++){
				if(a[i]!='.'&&a[j]==a[i]){
					a[j]='.';
					
				}	
				}
				
				
			}
			 for(i=0;i<m;i++){
					
					if(a[i]!='.'){
						num=num+1;
					}
				}
		}
		printf("%d\n",num);
		num=0; 
	}
	
}

