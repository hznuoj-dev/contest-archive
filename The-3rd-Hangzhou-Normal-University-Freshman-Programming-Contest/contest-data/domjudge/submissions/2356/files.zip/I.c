#include<stdio.h>
#include<string.h>
int main()
{
	int total=0;
	char a[20];
	int t=4;
	while(t--)
	{
		int num=0;
		scanf_s("%s",a);
		int len=strlen(a);
		int i;
		for( i=0;i<len;i++)
		{
			num+=a[i]-'0';
		}
		if(num>=16||num==6)
		{
			total++;
		}
	}
	switch(total)
	{
		case 0:printf("Bao Bao is so Zhai......");break;
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///");break;
		default :printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		
	}
}

	
	
	
	
	

