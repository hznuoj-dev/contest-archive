#include<stdio.h>
#include<string.h>
int main(void)
{
    char a[19],b[19],c[19],d[19];
    int e,f,g,h;
    int i=0,j=0;
    int sum=0;
    int time[4]={0};
    scanf("%s",a);e=strlen(a);
    scanf("%s",b);f=strlen(b);
    scanf("%s",c);g=strlen(c);
    scanf("%s",d);h=strlen(d);
    for(i=0;i<e;i++)
    {
    	time[0]=a[i]-48+time[0];
	}
	for(i=0;i<f;i++)
    {
    	time[1]=b[i]-48+time[1];
	}
	for(i=0;i<g;i++)
    {
    	time[2]=c[i]-48+time[2];
	}
	for(i=0;i<h;i++)
    {
    	time[3]=d[i]-48+time[3];
	}
	for(j=0;j<4;j++)
	{
		if(time[j]>=16||time[j]==6)
		sum++;
	}
	if(sum==1)
	printf("Oh dear!!");
	if(sum==2)
	printf("Bao Bao is good!!");
	if(sum==3)
	printf("Bao Bao is a SupEr man//////!");
	if(sum==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else
	printf("Bao Bao is so Zhai......");
	return 0;
}
