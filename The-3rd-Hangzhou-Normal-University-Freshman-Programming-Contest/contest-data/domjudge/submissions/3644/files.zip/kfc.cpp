#include<stdio.h>
int main(){
	char a[4];
	int i=0;
	for(i=0;i<=2;i++){
		scanf("%c");
	}
    printf(" __      _____ \n");
    printf("|  | ___/ ____\\____ \n");
    printf("|  |/  /\\  __\\/ ___\\ \n");
    printf("|     < |  | \\  \\___\n");
    printf("|__|_  \\|__|  \\___  >\n");
    printf("     \\/           \\/");
    
    return 0;}

