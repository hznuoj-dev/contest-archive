#include<bits/stdc++.h>
using namespace std;



int main ()
{
	printf ("__ _____\n| | ___/ ____\\____\n| |/ /\\ __\\/ ___\\\n| < | | \\ \\___\n|__|_ \\ |__| \\___ >\n\\/ \\/");
	
	
	return 0;
	
}
