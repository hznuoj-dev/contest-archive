#include<stdio.h>
#include<string.h>

int main(){
	char str1[10],str2[]="kfc";
	gets(str1);
	if(strcmp(str1,str2)==0){
		printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|     <  |  | \\ \\___\n");
		printf("|__|_  \\|__|  \\___   >\n");
		printf("     \\/            \\/\n");
	}
	return 0;
}
