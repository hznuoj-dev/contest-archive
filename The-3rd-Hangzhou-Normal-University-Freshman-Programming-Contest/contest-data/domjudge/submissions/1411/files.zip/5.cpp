#include <stdio.h>
#include<string.h>
int main(){
int t,a,b,n=0,s,i,p;
scanf("%d",&t);
while (t--){
	scanf("%d %d",&a,&b);
	s=a+b;
	if(s>=10000){
		s=9999-(s-9999);
	}
	if(a>s){
		p=a;
		a=s;
		s=p;
	}
	for(i=a;i<=s;i++){
		if((i%4==0&&i%100!=0)||i%400==0) n++;
	}
	printf("%d\n",n);
	n=0;
	
}
 return 0;
}
