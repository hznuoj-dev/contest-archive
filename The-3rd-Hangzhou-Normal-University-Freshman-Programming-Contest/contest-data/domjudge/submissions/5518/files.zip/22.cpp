#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
#pragma warning(disable:4996);
using namespace std;
#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
#pragma warning(disable:4996);
using namespace std;
long long m = 998244353;
int a[200000] = { 0 };
int main() {
	long long n, i, deep = 0, s = 1, x = 0, sum = 1, y = 0;
	scanf("%lld", &n);
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
	}
	sort(a, a + n);
	for (i = 1;; i++) {
		s = s * 2;
		if (n <= s - 1) {
			deep = s / 2 - 1;

			break;
		}
	}
	y = (deep + 1) / 2;
	x = n - deep;
	int t = a[deep];
	long long sss = 1, summ = 1, mm = 1;
	for (i = deep+1; i < n; i++) {
		if (a[i] == t) {
			mm = mm * sss;
			sss++;
		}
		else {
			t = a[i];
			summ = summ * mm;
			mm = 1;
		}
	}
	for (i = 1; i <= x; i++) {
		sum = (sum * y) % m;
	}
	printf("%lld\n", sum/summ);
	return 0;
}
