#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d%d",&n,&m);
		int i;
		i=m*100/n;
		printf("[");
		for(int k=1;k<=m;k++){
			printf("#");
		}
		for(int l=1;l<=n-m;l++){
				printf("-");
		}
		printf("]");
		printf("%d%%",i);
	}
	return 0;
}