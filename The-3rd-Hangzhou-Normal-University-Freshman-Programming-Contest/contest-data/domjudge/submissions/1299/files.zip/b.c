#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t,x,y,a,i; 
	    scanf("%d",&t);
	    while(t--){
	    	x=0;
	    	scanf("%d %d",&y,&a);
	    	if(y+a>9999) a-=2*(y+a-9999);
	    	if(a>=0){
	    		for(i=y;i<=y+a;i++){
	    			if((i%4==0&&i%100!=0)||i%400==0) x++;
				}
			}
			else {
	    		for(i=y+a;i<=y;i++){
	    			if((i%4==0&&i%100!=0)||i%400==0) x++;
				}
			}
			printf("%d\n",x);
		}
	    
	    
	return 0;
} 
