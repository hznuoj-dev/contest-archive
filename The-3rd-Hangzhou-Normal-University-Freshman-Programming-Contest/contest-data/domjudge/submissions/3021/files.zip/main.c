#include <stdio.h>
#include <stdlib.h>
int main() 
{
	char A;
	scanf("%s",A);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/\n");
		
	
	return 0;
}
