#include<stdio.h>
#include<string.h>
int main(){
	int count(char s[20]);
	int cnt=0;
	char a[20],b[20],c[20],d[20];
	scanf("%s %s %s %s",a,b,c,d);
	if(count(a)>=16||count(a)==6)cnt++;
	if(count(b)>=16||count(b)==6)cnt++;
	if(count(c)>=16||count(c)==6)cnt++;
	if(count(d)>=16||count(d)==6)cnt++;
	if(cnt==0)printf("Bao Bao is so Zhai......");
	if(cnt==1)printf("Oh dear!!");
	if(cnt==2)printf("Bao Bao is good!!");
	if(cnt==3)printf("Bao Bao is a SupEr man///!");
	if(cnt==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}

int count(char s[20]){
	int len,cnt=0;
	len=strlen(s);
	for(int i=0;i<len;i++){
		if(s[i]=='1')cnt+=1;
		if(s[i]=='2')cnt+=2;
		if(s[i]=='3')cnt+=3;
		if(s[i]=='4')cnt+=4;
		if(s[i]=='5')cnt+=5;
		if(s[i]=='6')cnt+=6;
		if(s[i]=='7')cnt+=7;
		if(s[i]=='8')cnt+=8;
		if(s[i]=='9')cnt+=9;
	}
	return cnt;
}
