#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=1e2+10;
const int M=1e5+10;
const int mod=998244353;
int hp1,hp2,atk1,atk2;
ll res1,res2;
int x1,y1,x2,y2;
bool check(int x,int y){
	return 1LL*x*(1+x)/2>=y;
}
bool check1(ll x,ll y,ll z){
	ll tmp=(1+x+x+y)*y/2;
	return tmp>=z;
}
bool check2(ll x,ll y){
	ll res=x*(1+x)/2;
	return res>=y;
}
void solve1(){
	res1=0;
	int l=1,r=hp1;
	while(l<=r){
		int mid=l+r>>1;
		if(check(mid,hp1)) r=mid-1;
		else l=mid+1;
	}
	x1=r+1;
	ll tmp=x1*(1+x1)/2-hp1;
	l=0,r=hp2;
	while(l<=r){
		int mid=l+r>>1;
		if(check1(x1,mid,hp2-tmp)){
			r=mid-1;
		} 
		else l=mid+1;
	}
	y1=r+1;
}
void solve2(){
	res1=0;
	int l=1,r=hp2;
	while(l<=r){
		int mid=l+r>>1;
		if(check(mid,hp2)) r=mid-1;
		else l=mid+1;
	}
	x2=r+1;
	ll tmp=x2*(1+x2)/2-hp2;
	l=0,r=hp1;
	while(l<=r){
		int mid=l+r>>1;
		if(check1(x2,mid,hp1-tmp)){
			r=mid-1;
		}
		else l=mid+1;
	}
	y2=r+1;
}
char a[M],b[M];
void cal1(){
	ll tmp=1LL*(x1+1+x1+y1)*y1/2;
	if(tmp>=hp2){
		for(int i=1;i<=x1;++i) a[i]='Q';
		for(int i=1;i<=y1;++i) a[x1+i]='W';
		a[x1+y1+1]='\0'; 
	}
	else{
		tmp=hp2-tmp;
		for(int i=1;i<=x1;++i){
			if(i==tmp) a[i]='W';
			else a[i]='Q';
		}
		for(int i=1;i<=y1;++i) a[x1+i]='W';
		a[x1+y1+1]='\0';
	} 
}
void cal2(){
	ll tmp1=1LL*(1+x2)*x2/2;
	tmp1-=hp2;
	ll tmp2=1LL*(x2+1+x2+y2)*y2/2;
	int l=0,r=tmp1;
	while(l<=r){
		int mid=l+r>>1;
		if(check2(mid,tmp2)) l=mid+1;
		else r=mid-1; 
	}
	ll tmp3=l-1;
	if((1+tmp3)*tmp3/2+tmp2>=hp1){
		for(int i=1;i<=tmp3;++i) b[i]='Q';
		for(int i=tmp3+1;i<=x2;++i) b[i]='W';
		for(int i=1;i<=y2;++i) b[i+x2]='Q';
		b[x2+y2+1]='\0';
	}
	else{
		tmp1=hp1-tmp2;
		for(int i=1;i<=x2;++i){
			if(i<tmp1-i||i==tmp1) b[i]='Q',tmp1-=i;
			else b[i]='W';
		} 
		for(int i=1;i<=y2;++i) b[i+x2]='Q';
		b[x2+y2+1]='\0'; 
	}
}
int main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0); 
	int T;cin>>T;
	while(T--){
		a[0]=b[0]='1';
		cin>>hp1>>hp2>>atk1>>atk2;
		solve1();
		solve2();
		res1=1LL*atk1*x1+atk2*(x1+y1);
		res2=1LL*atk2*x2+atk1*(x2+y2);
		cal1();
		cal2(); 
		if(res1<res2){
			printf("%lld %s\n",res1,a+1); 
		}
		else if(res2<res1){
			printf("%lld %s\n",res2,b+1);
		}
		else{
			if(strcmp(a,b)<0) printf("%lld %s\n",res1,a+1);
			else printf("%lld %s\n",res2,b+1); 
		}
	}
} 
