#include<stdio.h>
#include<string.h> 
int main()
{
	int sum=0,t=0;
	char a[20],b[20],c[20],d[20];
	scanf("%s %s %s %s",a,b,c,d);
	for(int i=0;i<strlen(a);i++)
	{
		sum+=a[i]-48;
	
	}
	if(sum>=16||sum==6)
	t+=1;
	sum=0;
	for(int i=0;i<strlen(b);i++)
	{
		sum+=b[i]-48;
	
	}
	if(sum>=16||sum==6)
	t+=1;
	sum=0;
	for(int i=0;i<strlen(c);i++)
	{
		sum+=c[i]-48;
	
	}
	if(sum>=16||sum==6)
	t+=1;
	sum=0;
	for(int i=0;i<strlen(d);i++)
	{
		sum+=d[i]-48;
	
	}
	if(sum>=16||sum==6)
	t+=1;
	sum=0;
	if(t==1){
		printf("Oh dear!!");
	}
	else if(t==2){
		printf("BaoBao is good!!");
	}
	else if(t==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else if(t==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	else if(t==0){
		printf("Bao Bao is so Zhai......");
	}	
 } 
