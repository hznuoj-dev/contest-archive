#include <stdio.h>
//#pragma warning(disable:4996)
//#include <process.h>
int main(){
	char a;
	scanf("%c",&a);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\ \n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  > \n     \\/           \\/\n");
	//system ("pause");
return 0;
}
