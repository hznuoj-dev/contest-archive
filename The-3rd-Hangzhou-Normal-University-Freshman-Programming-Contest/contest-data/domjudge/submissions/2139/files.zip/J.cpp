#include<bits/stdc++.h>
using namespace std;
map<char, int> s;
int main()
{
	int T,n,i,j,k;
	char t[100010];
	cin >> T;
	while(T--){
		cin >> n;
		k=0;
		for(i=1;i<=n;i++){
			scanf("%s",t);
			for(j=0;t[j]!='\0';j++){
				if(t[j]!='.') s[t[j]]++;
			}
			k+=s.size();
			s.clear();
		}
		cout << k << endl;
	}
}
