#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int s(long long int x)
{
    int h=0;
		while(x!=0){
		h+=x%10;
		x/=10;
	}
	return h;
}
int main(void){
	long long int a,b,c,d;
	int sum1,sum2,sum3,sum4,sum=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	if(s(a)>=16||s(a)==6)
	sum++;
	if(s(b)>=16||s(b)==6)
	sum++;
	if(s(c)>=16||s(c)==6)
	sum++;
	if(s(d)>=16||s(d)==6)
	sum++;
	switch(sum)
	{
		case 0:
			printf("Bao Bao is so Zhai......\n");
			break;
		case 1:
			printf("Oh dear!!\n");
			break;
		case 2:
		    printf("BaoBao is good!!\n");
		    break;
		case 3:
		    printf("Bao Bao is a SupEr man///!\n");
		    break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");   
			break;
		}
	return 0;
}
