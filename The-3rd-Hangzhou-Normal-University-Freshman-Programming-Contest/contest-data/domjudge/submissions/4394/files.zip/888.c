#include<stdio.h>
int main(void){
	int t,m,n,i;
	t>1;
	n>0;
	m<n;
	double a;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d", &n, &m);
		a=100*((1.0*m)/n);
		printf("[");
		for(i=0;i<n;++i){
			printf("#");
		}
		for(i=0;i<m-n;++i){
			printf("-");
		}
		printf("] ");
		printf("%.0f%%\n",a);
	}
	return 0;
}
