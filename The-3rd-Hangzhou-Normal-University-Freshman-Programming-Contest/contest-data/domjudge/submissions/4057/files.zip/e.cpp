#include <stdio.h> 
int main(void){
		printf(" _ _        _ _ _ _ _\n");
		printf("\n");
		printf("|   | _ _ _/  _ _ _ _\\_ _ _ _\n");
		printf("\n");
		printf("|   |/  /\\      _ _ \\/  _ _ _\\ \n");
		printf("\n");
		printf("|       <  |    |   \\  \\_ _ _\n");
		printf("\n");
		printf("|_ _|_  \\  | _ _|    \\_ _ _   >\n");
		printf("\n");
		printf("      \\/                    \\/\n");
	return 0;
}

