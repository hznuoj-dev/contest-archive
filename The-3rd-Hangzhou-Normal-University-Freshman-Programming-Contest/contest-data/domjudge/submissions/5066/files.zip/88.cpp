#include<stdio.h>
int main(void){
	int t,n,m,y;
	char a='#',b='-',c='%';
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		printf("[");
		for(int i=0;i<m;++i)
		printf("%c",a);
		y=n-m;
		for(int i=0;i<y;++i)
		printf("%c",b);
		printf("] ");
		printf("%.0lf",(double)m*100/n);
		printf("%c\n",c);
	}
	
}
