#include<stdio.h>
int main(){
	int a,b,c,d;
	int a1=0,b1=0,c1=0,d1=0;
	int a2=0,b2=0,c2=0,d2=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	while(a!=0){
		a1=a1+a%10;
		a=a/10;
	}
	if(a1==6||a1>=16){
		a2=a2+1;
	}
		while(b!=0){
		b1=b1+b%10;
		b=b/10;
	}
	if(b1==6||b1>=16){
		b2=b2+1;
	}
	while(c!=0){
	c1=c1+c%10;
		c=c/10;
	}
	if(c1==6||c1>=16){
		c2=c2+1;
	}
	while(d!=0){
		d1=d1+d%10;
		d=d/10;
	}
	if(d1==6||d1>=16){
		d2=d2+1;
	}
	if(a2+b2+c2+d2==1){
		printf("Oh dear!!");
	}
	if(a2+b2+c2+d2==2){
		printf("BaoBao is good!!");
	}
	if(a2+b2+c2+d2==3){
		printf("Bao Bao is a SupEr man///!");
	}
	if(a2+b2+c2+d2==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	if(a2+b2+c2+d2==0){
		printf("Bao Bao is so Zhai......");
	}
return 0;
}
