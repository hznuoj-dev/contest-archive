#include<stdio.h>
#include<string.h>
char s[100000];
int main()
{
	int lens,lenk;
	char kind[500];
	int T,n,flag;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%s",s);
		lens=strlen(s);
		for(int i=0;i<lens;i++){
			flag==0;
			if(s[i]!='.'){
			lenk=strlen(kind);
			for(int j=0;j<lenk;j++){
				if(s[i]==kind[j])
				    flag=1;
			}
			if(!flag)
			    kind[lenk]=s[i];
            }
		}
	}
		printf("%d\n",strlen(kind));
	}
	return 0;
}
