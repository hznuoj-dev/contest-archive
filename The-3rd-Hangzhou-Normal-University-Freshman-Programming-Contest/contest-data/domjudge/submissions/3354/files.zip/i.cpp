#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main(void) {
	int jd[20];
	int A, B, C, D,a=0,b=0,c=0,d=0,s=0,i;
	scanf("%d %d %d %d", &A, &B, &C, &D);
	for (i = 0; A > 0; i++) {
		jd[i] = A % 10;
		A = A / 10;
		a = a + jd[i];
	}
    if (a >= 16 || a == 6)
			s++;
	for (i = 0; B > 0; i++) {
			jd[i] = B % 10;
			B = B / 10;
			b = b + jd[i];
    }
		if (b >= 16 || b == 6)
			s++;
		for (i = 0; C > 0; i++) {
			jd[i] = C % 10;
			C = C / 10;
			c = c + jd[i];
		}
		if (c >= 16 || c == 6)
			s++;
		for (i = 0; D > 0; i++) {
			jd[i] = D % 10;
			D = D / 10;
			d = d + jd[i];
		}
		if (d >= 16 || d == 6)
			s++;
		if (s == 1)
			printf("Oh dear!!\n");
		if (s == 2)
			printf("BaoBao is good!!\n");
		if (s == 3)
			printf("Bao Bao is a SupEr man///!\n");
		if (s == 4)
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
		if (s == 0)
			printf("Bao Bao is so Zhai......\n");
		return 0;	
}
