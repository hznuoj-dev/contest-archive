#include <stdio.h>
#include <stdlib.h>



int main()
{
	int T,A,B,i;
	float C;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&A,&B);
		printf("[");
		for(i=1;i<=B;i++)
		{
			printf("#");
		}
		for(i=1;i<=A-B;i++)
		{
			printf("_");
		}
		C=(float)B/A*100;
		printf("] %.0f%%\n",C);
	}



	return 0;
}

