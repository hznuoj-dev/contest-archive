#include<stdio.h>
#include<string.h>
#include<math.h>
#pragma warning (disable:4996)
/*int main() {
	int n, T, m,p;//�ó������ܵĶ�����, �ܵ�ʱ��, �ܵ��ύ������Ŀ����
	int team, pro, time,q;//ʾ������, ��Ŀ��ź�ʱ���,ѯ������
	char a;

}*/
/*int main() {
	int a, b, c, d, i, k = 0, t;
	scanf("%d", &a);
	while (a--) {
		k = 0;
		scanf("%d %d", &b, &c);
		d = b + c;
		while  (d >= 10000) {
			d = d - 9999;
			d = 9999 - d;
		}
		if (b > d) {
			t = b;b = d;d = t;
		}
		for (i = b;i <= d;i++) {
			if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				k++;
		}
		printf("%d\n", k);
	}
}*/
/*int main() {
	int a;
	scanf("%d", &a);
	while (a--) {
		scanf ("%d",)
	}
}*/
/*int main() {
	char a[100];
	scanf("%s", &a);
	printf(
	    " __      _____\n"
	    "|  | ___/ ____\\____\n"
		"|  |/ /\\   __\\/ ___\\\n"
		"|    <  |  | \\  \\___\n"
		"|__|_ \\ |__|  \\___  >\n"
		"     \\/           \\/\n");
	return 0;
}*/
/*int main() {
	long long int a, b, c, d;
	long long int A=0, B=0, C=0, D=0,j = 0;
	scanf("%lld %lld %lld %lld", &a, &b, &c, &d);
	while (a > 0) {
		A = A + a % 10;
		a=a / 10;
	}
	while (b > 0) {
		B = B + b % 10;
		b = b / 10;
	}
	while (c > 0) {
		C = C + c % 10;
		c = c / 10;
	}
	while (d > 0) {
		D = D + d % 10;
		d = d / 10;
	}
	if (A >= 16 || A == 6)
		j++;
	if (B >= 16 || B == 6)
		j++;
	if (C >= 16 || C == 6)
		j++;
	if (D >= 16 || D == 6)
		j++;
	if (j == 1)
		printf("Oh dear!!");
	else if (j == 2)
		printf("BaoBao is good!!");
	else if (j == 3)
		printf("Bao Bao is a SupEr man///!");
	else if (j == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if (j==0)
		printf("Bao Bao is so Zhai......");
	return 0;
}*/
/*int main() {
	int a, b, c, d, f;
	scanf("%d", &a);
	while (a--) {
		scanf("%d %d", &b, &c);
		d = c * 100/b;
		f = b - c;
		printf("[");
		while (c--) {
			printf("#");
		}
		while (f--) {
			printf("-");
		}
		printf("] ");
		printf("%d", d);
		printf("%%\n");
	}
	return 0;
}*/
/*int main() {
	int T, n, j, g, c, k, d, e, q, i;
	char s[100], * p, b[100];
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		e = n;q = 0;
		while (n--) {
			scanf("%s", s);
			j = strlen(s);
			for (i = 1;i < j;i++) {
				if (s[i] == s[i - 1]) {
					for (k = i;k < j;k++) {
						s[k - 1] = s[k];
					}
					j = j - 1;i--;
				}
			}
			q = q + j;
		}
		printf("%d\n", q);
	}
	return 0;
}*/
/*int main() {
	int T, n, m, A, B, a[100], t,i, c[100];
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d", &n, &m);
		for (i = 1;i <=2* m;i=i+2) {
			scanf("%d %d", &A, &B);
			a[i] = A;a[i+1] = B;
		}
		for (i = 2;i <= 2 * m - 2;i = i + 2) {
			if (a[i - 1] == a[i + 1] && a[i] > a[i + 2]) {
				t = a[i];a[i] = a[i + 2];a[i + 2] = t;
			}
			else if (a[i] == a[i + 2] && a[i - 1] > a[i + 1]) {
				t = a[i - 1];a[i - 1] = a[i + 1];a[i + 1] = t;
			}
		}
		for (i = 1;i < 2 * m;i = i + 2) {
			printf("%d", a[i]);
		}
	}
	return 0;
}*/
/*int main() {
	int a, b, x[100], y[100], i, j;
	scanf("%d %d", &a, &b);
	for (i = 1;i <= a;i++) {
		scanf("%d", &x[i]);
	}
	for (i = 1;i <= a;i++) {
		scanf("%d", &y[i]);
	}
	
}*/
int main() {
	int T, n, m, i, j, g, d, flag, p;
	char s[100];
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		d = 0;p = 0;
		while (n--) {
			scanf("%s", &s);
			m = strlen(s);
			d = 1;flag = 0;
			for (i = 1;i< m;i++) {
				if (s[i] == '.')
					flag = 1;
				g = 0;
				for (j = 0;j < i;j++) {
					if (s[i] != s[j])
						g++;
				}
				if (g == i)
					d=d+1;
			}
			d = d - flag;
			p = p + d;
		}
		printf("%d\n", p);
	}
	return 0;
}