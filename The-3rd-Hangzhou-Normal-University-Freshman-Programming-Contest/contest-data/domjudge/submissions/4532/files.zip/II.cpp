#include<stdio.h>
int main(){
	long long a,b,c,d;
	int flag,i;
	flag=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	int s[5];
	s[0]=a;
	s[1]=b;
	 s[2]=c;
 s[3]=d;
	for(i=0;i<4;i++){
		int ans=0;
		while(s[i]!=0){
			ans+=s[i]%10;
			s[i]=s[i]/10;
		}
		if(ans>=16||ans==6){
			flag+=1;
		}
	}
	switch(flag){
		case 0:
			printf("Bao Bao is so Zhai......");
			break;
		case 1:
			printf("Oh dear!!");
			break;
		case 2:
			printf("BaoBao is good!!");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			break;
	}
}
