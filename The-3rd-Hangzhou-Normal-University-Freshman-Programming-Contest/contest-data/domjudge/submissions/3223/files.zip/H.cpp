#include <stdio.h>
int main ()
{
	int T;
	scanf("%d",&T);
	char str[]="%";
	while(T--)
	{
		int m,n,a,i;
		scanf("%d%d",&m,&n);
		a=n*100/m;
		printf("[");
		for(i=1;i<=n;i++)
		{
			printf("#");
		}
		for(i=1;i<=(m-n);i++)
		{
			printf("-");
		}
		printf("]");
		printf("%d",a);
		printf("%c",str[0]);
		printf("\n");
	}
	return 0;
}
