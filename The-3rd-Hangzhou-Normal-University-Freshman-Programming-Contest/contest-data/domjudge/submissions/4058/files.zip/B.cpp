#include<stdio.h>
int main(void){
	int t,y,a,x,p,num,i;
	scanf("%d",&t);
	while (t--){
		scanf("%d %d",&y,&a);
		x=y+a;
		if (x>=10000)
		  x=9999-(x-9999);
		if (x<=y){
			p=x;
			x=y;
			y=p;
		}
		num=0;
		for (i=y;i<=x;i++){
			if ((i%4==0&&i%100!=0)||(i%100==0&&i%400==0))
			  num=num+1;
		}
		printf("%d\n",num);
	}
	return 0;
} 
