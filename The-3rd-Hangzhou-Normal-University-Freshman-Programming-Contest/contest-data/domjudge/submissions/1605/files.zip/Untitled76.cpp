#include<stdio.h>
main()
{
    int T,Y,A,sum,temp;
    scanf("%d",&T);
    for(int i=0;i<T;i++){
       scanf("%d %d",&Y,&A);
       int g=0;
       sum=Y+A;
       if(sum>9999){
         sum=9999-(sum-9999);}
       if(sum<Y){
         temp=sum;
         sum=Y;
         Y=temp;}
       for(int j=Y;j<=sum;j++){
          if((j%4==0&&j%100!=0)||(j%400==0))
            g++;}
       printf("%d\n",g);}
}
