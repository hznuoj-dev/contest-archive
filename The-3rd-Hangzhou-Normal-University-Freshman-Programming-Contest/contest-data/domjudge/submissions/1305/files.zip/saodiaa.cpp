#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
char zf[10000010];
int a[10000010]={0};
int main()
{
	int t;
	int n;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		int sum=0;
		while(n--)
		{
			scanf("%s",zf);
			int len;
			len=strlen(zf);
			for(int i=0;i<len;i++)
			{
				if(zf[i]!='.')
				{
					int bz=(int)zf[i];
					a[bz]++;
				}
			}
			for(int i=0;i<=256;i++)
			{
				if(a[i]>0)
				{
					sum++;
					a[i]=0;
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
