#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int run(int x)
{
	int flag=0;
		if((x%4==0&&x%100!=0)||(x%400==0))
		flag=1;
	return flag;
 } 
int main()
{
	int T,Y,A,i,sum;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&Y,&A);
		sum=0;
		if(A>=0&&(Y+A)<10000)
		{
			for(i=Y;i<=(Y+A);++i)
			{
				if(run(i))
				sum++;
			}
			printf("%d\n",sum);
		}
		else if(A>0&&(Y+A)>=10000)
		{
			if((9999*2-Y-A)>Y){
			for(i=Y;i<=(9999*2-Y-A);++i)
			{
				if(run(i))
				sum++;
			}
			printf("%d\n",sum);
		}
		else{
			for(i=(9999*2-Y-A);i<=Y;++i)
			{
				if(run(i))
				sum++;
			}
			printf("%d\n",sum);
		}
		}
		else if(A<0)
		{
			for(i=(Y+A);i<=Y;++i)
			{
				if(run(i))
				sum++;
			}
			printf("%d\n",sum);
		}	
	}
	return 0;
}
