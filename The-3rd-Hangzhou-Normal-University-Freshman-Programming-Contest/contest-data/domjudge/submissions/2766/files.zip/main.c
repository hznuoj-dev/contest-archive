#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t;
	scanf("%d",&t);
	while(t--){
		int y, a, x, i, max, min, count=0;
		scanf("%d%d",&y,&a);
		x=y+a;
		if(x>9999)
		x=9999-(x-9999);
		if(x>y){
			max=x;
			min=y;
		}
		else{
			max=y;
			min=x;
		}
		for(i=min;i<=max;++i){
			if((i%4==0&&i%100!=0)||(i%400==0))
			count++;
		}
		printf("%d\n",count);
	}
	return 0;
}
