#include<stdio.h>
#include<string.h>
int main() {
	int T,n,x,i,sum;
	char a[100];
	sum = 0;
	scanf_s("%d", &T);
	while (T--) {
		scanf_s("%d", &n);
		while (n--) {
			scanf("%s", a);
			x = strlen(a);
			for (i = 0; i < strlen; i++) {
				if ((strcmp(a,".")!=0)) {
					sum += 1;
				}
			}
		}
		printf("%d\n", sum);
		sum = 0;
	}
	return 0;
}