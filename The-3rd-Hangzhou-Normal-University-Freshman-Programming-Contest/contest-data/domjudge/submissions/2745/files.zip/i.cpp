#include<bits/stdc++.h>
using namespace std;
int f(int a)
{
	int sum=0;
	int x;
	while(a!=0)
	{
		x=a%10;
		a=a/10;
		sum+=x;
	}
	if(sum>=16) return 1;
	else return 0;
}

int main()
{
	int a,b,c,d;
	cin>>a>>b>>c>>d;
	int ans=0;
	if(a==6||f(a)) ans++;
	if(b==6||f(b)) ans++;
	if(c==6||f(c)) ans++;
	if(d==6||f(d)) ans++;
	switch(ans){
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
		default:printf("�Bao Bao is so Zhai......");break;
	}
}
