#include<bits/stdc++.h>
using namespace std;

int qiu(long long int n)
{
	int sum=0;
	while(n)
	{
		sum+=n%10;
		n/=10;
	}
	return sum;
}

int main(void)
{
	long long int a,b,c,d;
	cin>>a>>b>>c>>d;
	int sum=0;
	if(qiu(a)>=16 || qiu(a)==6)sum++;
	if(qiu(b)>=16 || qiu(b)==6)sum++;
	if(qiu(c)>=16 || qiu(c)==6)sum++;
	if(qiu(d)>=16 || qiu(d)==6)sum++;
	if(sum==0) cout<<"Bao Bao is so Zhai......";
	if(sum==1) cout<<"Oh dear!!";
	if(sum==2) cout<<"BaoBao is good!!";
	if(sum==3) cout<<"Bao Bao is a SupEr man///!";
	if(sum==4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
	return 0;
}

