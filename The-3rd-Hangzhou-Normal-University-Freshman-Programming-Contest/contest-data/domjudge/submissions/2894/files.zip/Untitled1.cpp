#include<stdio.h>
#include<string.h>
int sum(int n){
	int i,j,len,x,y;
	char s[1000000];
	len=strlen(s);
	for(i=0;i<n;++i){
		scanf("%s",s);
	}
	for(i=0;i<n;++i){
		for(j=0;j<len;++j){
			if(s[j]!='.')
			    x=x+1;
		}
		if(x!=0)
		   y=y+1;
	}
	return y;
}
int main(void){
	int t,a,n;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		a=sum(n);
		printf("%d\n",a);
	}
	return 0;
} 
