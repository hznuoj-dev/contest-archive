#include<stdio.h>
/*
#define ARRAY_SIZE 100000
int main(){
     int m,n,i,p[ARRAY_SIZE],q[ARRAY_SIZE];
     scanf("%d %d",&m,&n);
     for(i=0;i<n;i++){
     	scanf("%d",&p[i]);
	 }
	 for(i=0;i<n;i++){
	 	scanf("%d",&q[i]);
	 }
	 
	 */
	 int main(){
	long long y,a,c;
	int t,i;
    scanf("%d",&t);
	while(t--){
	scanf("%lld %lld",&y,&a);
		c=y+a;
		int sum=0;
		if(c>9999){
		c=9999-(c-9999);
	if(c>y){
		for(i=y;i<=c;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
		{
				sum+=1;
		}
		}
	}
	if(c<y){
		for(i=c;i<=y;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
			sum+=1;
	}	
	}
	}
	else
		if(c>y){
		for(i=y;i<=c;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
		{
				sum+=1;
		}
		}
	}
	if(c<y){
		for(i=c;i<=y;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
			sum+=1;
	}	
	}

		printf("%d\n",sum);
}
	return 0;
} 
