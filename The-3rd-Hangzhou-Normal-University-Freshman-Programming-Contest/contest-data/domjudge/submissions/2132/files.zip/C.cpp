#include<bits/stdc++.h>
using namespace std;
long long int a[100005];
int main()
{
	int n; cin>>n;
	int maxx=0;
	for(int i=1; i<=n; i++)
	{
		int x; cin>>x;
		a[x]++;
		if(x>maxx) maxx=x; 
	}
	long long int sum=1;
	for(int i=1; i<maxx; i++)
	{
		sum=sum%998244353*a[i]%998244353;
	}
	printf("%lld",sum);
	return 0;
}


