#include <cstdio>
#include <iostream>
#include <cstring> 
using namespace std;
const int N = 1e5 + 10;
int a[N], b[N], dp[N];
int main () {
	int n, m;
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
	}
	for (int i = 1; i <= n; i++) {
		scanf("%d", &b[i]);
	}
	for (int i = 1; i <= n; i++) {
		for (int k = 1; b[i]; k = k * 2) {
			k = min(k, b[i]);
			b[i] -= k;
			for (int j = m; j >= a[i] * k; j--) {
				dp[j] = max(dp[j], dp[j - k * a[i]] + k * a[i]);
			}
		}
	}
	int ans = 0;
	for (int i = 1; i <= m; i++)
		if (i == dp[i])
			++ans;
	printf("%d\n", ans);
}
