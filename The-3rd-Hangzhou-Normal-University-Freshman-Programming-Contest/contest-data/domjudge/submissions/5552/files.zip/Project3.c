﻿#include <stdio.h>
int p[100000], w[100000] = { 0 };
int main() {
    int n, m, i, a[100], b[100], j, t=1, u=0, k, count = 0;
    scanf("%d %d", &n, &m);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++) {
        scanf("%d", &b[i]);
    }
    p[0] = 0;
    for (i = 0; i < n; i++) {
        for (k = 0; k <= u; k++) {
            for (j = 1; j <= b[i]; j++) {
                if (j * a[i] + p[k] > m)
                    break;
                if (w[j * a[i] + p[k]] != 1) {
                    p[t] = j * a[i] + p[k];
                    w[p[t]] = 1;
                    t++;
                }
            }
        }
        u = t - 1;
    }
    printf("%d", t - 1);
    return 0;
}