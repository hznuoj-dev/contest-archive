#include<stdio.h>
#include<string.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int n,score=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++)
		{
			char s[1000001],point=0;
			scanf("%s",s);
			getchar();
			for(int j=0;j<strlen(s);j++)
			{
				if(s[j]=='#')
				score++;
			}
		 }
		printf("%d\n",score);
	}
}
/*int f(int k)
{
	int l=0;
	while(k>1)
	{
		k=k/2;
		l++;
	}
	return l;
}
int main()
{
	int t;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	    int a;
		scanf("%d",&a);
	}
	

	return 0;
}
*/ 
/*
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int n,T,m,p;
	int team[501],problemid[501],timestamp[501],recod[501];
	scanf("%d %d %d %d",&n,&T,&m,&p);
	for(int i=0;i<m;i++)
	{
		char s[2];
		scanf("%d %d %d",&team[i],&problemid[i],&timestamp[i]);
		scanf("%s",s);
		if(s[0]=='A'&&s[1]=='C')
			recod[i]=1;
		else
			recod[i]=0;
	}
	int q;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		char q[10],a,b;
		scanf("%s",q);
		scanf("%d %d",&a,&b);
	}
	return 0;
}*/ 
