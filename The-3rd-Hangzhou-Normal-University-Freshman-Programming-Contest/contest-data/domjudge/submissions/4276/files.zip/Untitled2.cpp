#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int comp(const void *p,const void *q){
	return (*(char *)p-*(char *)q);
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			char s[1000005]="0";
			scanf("%s",s);
			//printf("%d\n",strlen(s[i]));
			qsort(s,strlen(s),sizeof(char),comp);
			//for(int j=0;j<strlen(s[i]);j++)
			//printf("%c",s[i][j]);
			//printf("\n");
			for(int k=0;s[k]!='\0';k++){
				if(s[k]!='.'&&k==0)
				m++;
				else if(s[k]!='.'&&k>0&&s[k]!=s[k-1])
				m++;
			}
		}
		printf("%d\n",m);
	}
}
