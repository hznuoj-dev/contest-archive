#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int n,m,i,j,k,p=0,w;
	char a[10000];
	scanf("%d",&n);
	while(n--){
		scanf("%s",a);
		m=strlen(a);
		p=p+m;
	} 
	printf("%d",p);
}
