#include<stdio.h>
int main(void){
	char a[3];
    scanf("%s",a);
	printf(" __      _____     \n");
	printf("|  | ___/ ____\\_____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/\n");
	return 0;
}
