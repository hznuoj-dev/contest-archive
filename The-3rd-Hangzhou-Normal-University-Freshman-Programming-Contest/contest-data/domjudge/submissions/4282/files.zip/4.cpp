#include<stdio.h>
#include<string.h>
int main(void)
{
	int t,i,f,j,l,k,q,w,h,z;
	char a[1000001];
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		h=0;
		scanf("%d",&f);
		for(j=1;j<=f;j++)
		{
			scanf("%s",&a);
			l=strlen(a);
			for(q=k=0;q<l;q++)
			{
				if(a[q])
				{
					a[k++]=a[q];
					for(w=q+1;w<l;w++)
					if(a[w]==a[q])
					a[w]='\0';
				}
			}
			a[k]='\0';
			for(z=0;z<strlen(a);z++)
			if(a[z]!='.')
			h=h+1;
			
		}
		printf("%d\n",h);
		
		
	}
	
 } 
