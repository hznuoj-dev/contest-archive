#include<iostream>
#include<cstring>
#include<algorithm>
using namespace std;
char str[1000000];
int  main()
{
    int j,len,k,level,i,sum,T;
    cin >> T;
    for(i=1;i<=T;i++)
    {
        sum=0;
        cin >> level;
        for(j=1;j<=level;j++)
        {
            memset(str,0,1000000);
            scanf("%s",str);
            len=strlen(str);
            sort(str,str+len);
            if(str[0]!='.')
            {
                sum++;
            }
            for(k=1;k<len;k++)
            {
                if(str[k]!=str[k-1] && str[k]!='.')
                {
                    sum++;
                }

            }

        }
        printf("%d\n",sum);
    }
    
    return 0;
}
