#include<bits/stdc++.h>
using namespace std;
int main()
{
	char a;
    cin >> a;
    puts(" __      _____");
    puts("|  | ___/ ____\____");
    puts("|  |/ /\   __\/ ___\ ");
    puts("|    <  |  | \  \___");
    puts("|__|_ \ |__|  \___  >");
    puts("     \/           \/"); 
}
