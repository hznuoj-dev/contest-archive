#include<stdio.h>
int main(){
	int t,n,m,i,s;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=0;i<m;i++){
			printf("#");
		}
		for(i=0;i<n-m;i++){
			printf("-");
		}
		s=100*m/n;
		printf("] %d%%\n",s);
	}
	return 0;
} 
