#include<stdio.h>
#include<string.h>
int main()
{
    char a[3];int i;
    char b[]="kfc";
	for(i=0;i<3;i++){
	scanf("%c",&a[i]);	
	}
	if(strcmp(a,b) == 0)
	printf(" __      _____");printf("\n");
	printf("|  | ___/ ____\\____");printf("\n");
	printf("|  |/ /\\   __\\/ ___\\ ");printf("\n");
	printf("|    <  |  | \\  \\___");printf("\n");
	printf("|__|_ \\ |__|  \\___  >");printf("\n");
	printf("     \\/           \\/");

	return 0;
}
