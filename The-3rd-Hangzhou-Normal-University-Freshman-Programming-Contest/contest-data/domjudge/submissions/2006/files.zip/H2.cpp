#include<stdio.h>
#include<math.h>
int main() {
	int t, a, b, i;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d %d", &a, &b);
		printf("[");
		for (i = 1; i <= b; i++)
			printf("#");
		for (i = 1; i <= a - b; i++)
			printf("_");
		printf("] ");
		printf("%.0d%%\n", floor(b * 100.0 / a+0.5));
	}
	return 0;
}