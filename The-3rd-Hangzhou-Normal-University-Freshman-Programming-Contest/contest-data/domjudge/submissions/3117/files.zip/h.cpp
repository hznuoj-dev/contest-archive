#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	int n,m;
	while(t--)
	{
		scanf("%d %d",&n,&m);
		printf("[");
		for(int i=1;i<=m;i++)
		printf("#");
		for(int i=m;i<=n;i++)
		printf("-");
		printf("]");
		printf(" %d%%\n",m*100/n);
	}
}
