#include<stdio.h>
int main(void){
	long long A=0,B=0,C=0,D=0;
	scanf("%ld %ld %ld %ld",&A,&B,&C,&D);
	int K=0,L=0,M=0,N=0;
	int i=0,t=0;
	for(i=0;i<19;++i){
		t=A%10;
		A=A/10;
		K=K+t;
	}
	i=0;
	t=0;
	for(i=0;i<19;++i){
		t=B%10;
		B=B/10;
		L=L+t;
	}
	i=0;
	t=0;
	for(i=0;i<19;++i){
		t=C%10;
		C=C/10;
		M=M+t;
	}
	i=0;
	t=0;
	for(i=0;i<19;++i){
		t=D%10;
		D=D/10;
		N=N+t;
	}
	int p=0;
	if(K>=16||K==6){p=p+1;}
	if(L>=16||L==6){p=p+1;}
	if(M>=16||M==6){p=p+1;}
	if(N>=16||N==6){p=p+1;}
	if(p==1)printf("Oh dear!!");
	if(p==2)printf("BaoBao is good!!");
	if(p==3)printf("Bao Bao is a SupEr man///!");
	if(p==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	if(p==0)printf("Bao Bao is so Zhai......");
	return 0;
}