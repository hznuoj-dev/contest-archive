#include<stdio.h>
#include<string.h>
int main()
{
	int s[3];
	for(int i=0;i<3;i++)
	scanf("%c",&s[i]);
	getchar();
	for(int i=0;i<3;i++)
	{
		if(s[0]=='k'&&s[1]=='f'&&s[2]=='c')
		break;
	}
	{	
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/");
}
}
/*int f(int k)
{
	int l=0;
	while(k>1)
	{
		k=k/2;
		l++;
	}
	return l;
}
int main()
{
	int t;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	    int a;
		scanf("%d",&a);
	}
	if((t+1)%2==0)

	return 0;
}
*/ 
/*
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int n,T,m,p;
	int team[501],problemid[501],timestamp[501],recod[501];
	scanf("%d %d %d %d",&n,&T,&m,&p);
	for(int i=0;i<m;i++)
	{
		char s[2];
		scanf("%d %%d %d",&team[i],&problemid[i],&timestamp[i]);
		scanf("%s",s);
		if(s[0]=='A'&&s[1]=='C')
			recod[i]=1;
		else
			recod[i]=0;
	}
	int q;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		char q[10],a,b;
		scanf("%s",q);
		scanf("%d %d",&a,&b);


	}
	return 0;
}*/ 
