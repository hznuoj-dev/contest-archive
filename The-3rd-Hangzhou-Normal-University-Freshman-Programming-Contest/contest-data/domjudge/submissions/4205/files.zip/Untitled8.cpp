#include <stdio.h>
int main(void){
	char str;
	scanf("%s",&str);
	printf(" __      _____       \n");
	printf("|  | ___/ ____\\___  \n");
	printf("|  |/ /\\   __\\/ ___\\ \n");
	printf("|    <  |  | \\  \\___ \n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/ \n");
	return 0;
}
