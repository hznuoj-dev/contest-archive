#include<stdio.h>
int a[1010][1010]={0};
int main(){
	int T,f;
	int n,m,d,b,c;
	scanf("%d",&T);
	while(T--){
	    int max=0,flag=1;
		int b[1010]={0};
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				a[i][j]=0;
			}
		}
		while(m--){
			scanf("%d%d",&f,&c);
			if(a[c][f]==0){
			a[c][f]=1;
			b[c]++;
			if(max<b[c]){
				max=b[c];
			}
		}
	}
		for(int i=0;i<=max;i++){
			for(int j=1;j<=n;j++){
			if(b[j]==i){
				if(flag==1){
				 printf("%d",j);
				 flag=0;
				}
				else
				 printf(" %d",j);
			}
		}
		}
		printf("\n");
 }
}
