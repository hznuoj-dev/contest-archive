#include<stdio.h>
int main()
{
    int t, i, j, a, b, s;
    scanf_s("%d", &t);
    while (t--)
    {
        scanf_s("%d %d", &i, &j);
        s = 0;
        if (i + j > 9999)
        {
            j = 9999 - (i + j - 9999);
        }
        else
        {
            j = i + j;
        }
        if (i > j)
        {
            b = i;
            a = j;
        }
        else
        {
            a = i;
            b = j;
        }
        for (; a <= b; a++)
        {
            if (((a % 4 == 0) && (a % 100 != 0)) || (a % 400 == 0))
            {
                s = s + 1;
            }
        }
        printf("%d\n", s);
    }
    return 0;
}