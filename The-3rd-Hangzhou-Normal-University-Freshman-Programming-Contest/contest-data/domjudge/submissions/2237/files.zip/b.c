/*#include<stdio.h>
int check(int y1,int y2);
int main()
{
    int t;
    int y,a,num;
    scanf("%d\n",&t);
    while(t--)
    {
        scanf("%d %d\n",&y,&a);
        if((y+a)<=9999&&(a>=0)){
            num=check(y,y+a);
        }
        else if((y+a)>9999){
            num=check(y,9999-(y+a-9999));
        }
        else if((y+a)<9999&&(a<0)){
            num=check(y+a,y);
        }
        printf("%d\n",num);
    }
}
int check(int y1,int y2)
{
    int num=0,i;
    for(i=y1;i<=y2;i++)
    {
        if((i%4==0&&i%100!=0)||(i%400==0))num++;
    }
    return num;
}
*/
#include<stdio.h>
int main()
{
    char a[5];
    scanf("%s\n",a);
    printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/\n");
}
