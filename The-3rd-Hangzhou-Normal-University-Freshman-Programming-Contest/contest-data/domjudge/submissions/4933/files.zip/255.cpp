#include<stdio.h>
#include<string.h>
int main()
{
	char s[1000];
	int n,a,bn[300]={0},t,sum;
	scanf("%d",&t);
	for(int k=0;k<t;k++)
	{
		sum=0;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		for(int q=0;q<300;q++)
		{
			bn[q]=0;
		}
		scanf("%s",s);
		a=strlen(s);
		for(int j=0;j<a;j++)
		{
			bn[int(s[j])]=bn[int(s[j])]+1;
		}
	
		for(int i=0;i<300;i++)
			{
				if(bn[i]!=0)
				{
					sum=sum+1;
				}
			}
	}
			printf("%d\n",sum);
	}
	return 0;
 } 
