#include<iostream>
#include<algorithm>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
const int maxn=1e3+10;
struct node{
	int num;
	int id;
	bool friend operator<(const node &a,const node &b){
		return a.num>b.num;
	} 
}a[maxn];
int n,m;
int main(){
	fcio;
	int T;
	while(cin>>T){
		while(T--){
			cin>>n>>m;
			for(int i=1;i<=n;++i){
				a[i].id=i;
			}
			while(m--){
				int x,y;
				cin>>x>>y;
				a[x].num++;
			}
			sort(a+1,a+1+n);
			for(int i=1;i<=n;++i){
				cout<<a[i].id;
				if(i!=n)cout<<" ";
				else cout<<endl;
			}
		}
	}
}

