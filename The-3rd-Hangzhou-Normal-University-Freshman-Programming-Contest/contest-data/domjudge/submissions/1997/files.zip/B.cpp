#include <stdio.h>
int main ()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int y,a,b,i,t,h,sum=0;
		scanf("%d %d",&a,&y);
		if((y+a)>9999)
		{
			i=y+a-9999;
			b=9999-i;
		}
		else
		{
			b=y+a;
		}
		if(a>b)
		{
			i=a;
			a=b;
			b=i;
		}
		for(t=a;t<=b;t++)
		{
			if(t%4==0&&t%100!=0)
			{
				sum+=1;
			}
			else if(t%400==0)
			{
				sum+=1;
			}
			else
			{
				sum=sum;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
