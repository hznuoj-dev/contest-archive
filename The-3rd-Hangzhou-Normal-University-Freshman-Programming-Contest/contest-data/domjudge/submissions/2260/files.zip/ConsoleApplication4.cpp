#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int main() {
	char n;
	scanf("%s",&n);
printf(" __      _____\n");
printf("|  | ___/ ____\\____\n");
printf("|  |/ /\\   __\\/ ___\\\n");
printf("|    <  |  | \\  \\___\n");
printf("|__|_ \\ |__|  \\___  >\n");
printf("     \\/           \\/	\n");
	return 0;
}
