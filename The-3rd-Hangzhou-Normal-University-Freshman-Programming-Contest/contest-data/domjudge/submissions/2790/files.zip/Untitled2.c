#include<stdio.h>
#include<stdio.h>
main() 
{
	int i,j,flag=0;
	int sum;
	char a[4][20];
	for(i=0;i<=3;i++)
	{
		sum=0;
		scanf("%s",a[i]);
		for(j=0;j<strlen(a[i]);j++)
		{
			
			sum=sum+a[i][j]-48;
		}
		
		
		if(sum==6||sum>=16)
		flag=flag+1;
	}

	if(flag==0)
	printf("Bao Bao is so Zhai......");
	if(flag==1)
	printf("Oh dear!!");
	if(flag==2)
	printf("BaoBao is good!!");
	if(flag==3)
	printf("Bao Bao is a SupEr man///!");
	if(flag==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");

}
