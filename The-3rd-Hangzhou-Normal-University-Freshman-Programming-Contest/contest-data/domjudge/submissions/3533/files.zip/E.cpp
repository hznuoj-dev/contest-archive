#include<stdio.h>
#include<string.h>
int main(){
	char a;
	char str1[100];
	char str2[]="kfc";
	gets(str1);
	a=strcmp(str1,str2);
	while(a==0)
	{

	printf(" __      _____\n\n");
 printf("|  | ___/ ____\\____\n\n");
 printf("|  |/ /\\   __\\/ ___\\\n\n");
 printf("|    <  |  | \\  \\___\n\n");
 printf("|__|_ \\ |__|  \\___  >\n\n");
 printf("     \\/           \\/");
	a=1;
}	}



