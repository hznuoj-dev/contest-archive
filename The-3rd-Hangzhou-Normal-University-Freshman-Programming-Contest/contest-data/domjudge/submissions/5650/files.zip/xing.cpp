if(scanf("%d %d %d %d",&a,&b,&c,&d)!=EOF){
	a=a;
	b=b;
	c=c;
	d=d;
   while(t--){
	e=a%10;
	f=b%10;
	g=c%10;
	h=d%10;
	sum=sum+e+f+g+h;
	if(sum>16||sum==6)
	count=count+1;
    }
    if(count==1)
printf("Oh dear!!\n");
else if (count==2)
printf("BaoBao is good!!\n");
else if(count==3)
printf("Bao Bao is a SupEr man\\\\\\!\n");
else if(count==4)
printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");

}

return 0;
}

