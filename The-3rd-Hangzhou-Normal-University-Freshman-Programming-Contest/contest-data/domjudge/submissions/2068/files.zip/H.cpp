#include<iostream>
#include<cmath>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
int main(){
	fcio;
	int T;
	while(cin>>T){
		while(T--){
			int n,m;
			cin>>n>>m;
			double ans=(double)m/n;
			cout<<"[";
			for(int i=1;i<=m;++i)cout<<"#";
			for(int i=1;i<=n-m;++i)cout<<"-";
			cout<<"] ";
			cout<<floor((ans*100))<<"%"<<endl;
		}
	}
}

