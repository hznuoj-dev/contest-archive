#include<stdio.h>
int main(void){
	int a,b,c,d,p,sum,i;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	p=0;
	sum=0;
	while(a!=0){
	  i=a%10;
	  a=a/10;
	  sum+=i;
    }
    if (sum>=16||sum==6)
      p=p+1;
    sum=0;
	while(b!=0){
	  i=b%10;
	  b=b/10;
	  sum+=i;
    }
    if (sum>=16||sum==6)
    p=p+1;
    sum=0;
	while(c!=0){
	  i=c%10;
	  c=c/10;
	  sum+=i;
    }
    if (sum>=16||sum==6)
    p=p+1;
    sum=0;
	while(d!=0){
	  i=d%10;
	  d=d/10;
	  sum+=i;
    }
    if (sum>=16||sum==6)
    p=p+1;
    if(p==1) 
	  printf("Oh dear!!");
	if(p==0) 
	  printf("Bao Bao is so Zhai......");
	if(p==2) 
	  printf("BaoBao is good!!");
	if(p==3) 
	  printf("Bao Bao is a SupEr man///!");
	if(p==4) 
	  printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
