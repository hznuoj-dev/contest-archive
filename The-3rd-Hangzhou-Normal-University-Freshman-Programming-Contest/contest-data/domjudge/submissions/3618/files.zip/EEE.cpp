#include<stdlib.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdio.h>


int main()
{
 char a[8];
 scanf("%s", a);
 if (a[0] == 'k' && a[1] == 'f' && a[2] == 'c' && a[3] == '\0') {
  printf(" __      _____\n\n");
  printf("|  | ___/ ____\\____\n\n");
  printf("|  |/ /\\   __\\/ ___\\\n\n");
  printf("|    <  |  | \\  \\___\n\n");
  printf("|__|_ \\ |__|  \\___  >\n\n");
  printf("     \\/           \\/");

 
 }
 return 0;
}
