#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int n,s=0;
	int m,a[102],b[102],k=1;
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;++i)
		scanf("%d",&a[i]);
	for(int i=0;i<n;++i)
		scanf("%d",&b[i]);
	while(k<=m)
	{
		int K=k;
		for(int j=n-1;j>=0;j=j-1)
		{
			if(K>=a[j])
			{
				if(K>a[j]*b[j])
					K=K-a[j]*b[j];
				else
					K=K%a[j];
			}
			if(K==0){
				s++;
				break;	
			}
		}
		k++;
	}
	printf("%d",s);
} 
