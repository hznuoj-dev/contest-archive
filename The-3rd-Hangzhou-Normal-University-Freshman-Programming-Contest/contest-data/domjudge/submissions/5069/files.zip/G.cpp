#include<stdio.h>
int main(void)
{
	int T,n,m;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&n,&m);
		int i,a[n],left,right;
		for(i=0;i<n;i++)
		{
			a[i]=i+1;
		}
		while(m--)
		{
			scanf("%d %d",&left,&right);
			if(left>right)
			{
				int t=a[left-1];
				a[left-1]=a[right-1];
				a[right-1]=t;
			}
		}
		for(i=0;i<n;i++)
		{
			if(i>0)
			printf(" ");
			printf("%d",a[i]);
		}
	}
}
