package ��ʦ��;

import java.util.Scanner;

public class B
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int n=sc.nextInt();
			for(int i=1;i<=n;i++)
			{
				int a=sc.nextInt();
				int b=sc.nextInt();
				int c=a+b;
				if(c-9999>0)
				{
					c=9999-(c-9999);
				}
				int max=Math.max(c,a);
				int min=Math.min(c, a);
				int count=0;
				for(int j=min;j<=max;j++)
				{
					if(j%4==0 &&j%100!=0) count++;
					if(j%100==0 && j%400==0) count++;
				}
				System.out.println(count);
			}
		}
	}
	
}
