#include<stdio.h>
#include<string.h>
void main()
{
	int x, A, B, C, D, l, L, p, P, i;
	char a[1000000000000000000], b[1000000000000000000], c[1000000000000000000], d[1000000000000000000];
	scanf("%s %s %s %s", &a, &b, &c, &d);
	x = 0;
	l = strlen(a);
	L = strlen(b);
	p = strlen(c);
	P = strlen(d);
	for (i = 1; i < l; i++)
	{
		A = a[i] + a[i - 1];
	}
	for (i = 1; i < l; i++)
	{
		B = b[i] + b[i - 1];
	}
	for (i = 1; i < l; i++)
	{
		C = c[i] + c[i - 1];
	}
	for (i = 1; i < l; i++)
	{
		D = d[i] + d[i - 1];
	}
	if (A >= 16 || A == 6)
		x++;
	if (B >= 16 || B == 6)
		x++;
	if (C >= 16 || C == 6)
		x++;
	if (D >= 16 || D == 6)
		x++;
	switch (x)
	{
	case 1:printf("Oh dear!!"); break;
	case 2:printf("BaoBao is good!!"); break;
	case 3:printf("Bao Bao is a SupEr man///!"); break;
	case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!"); break;
	case 0:printf("Bao Bao is so Zhai......"); break;
	}
}



























/*int n, T, m, p, q;
	int a[1000000][5],b[100000][15];
	int i, j, l, L;
	scanf("%d %d %d %d", &n, &T, &m, &p);
	for (i = 0; i < m; i++)
	{
		scanf("%d %d %d %c %c", &a[i][0], &a[i][1], &a[i][2], &a[i][3], &a[i][4]);
	}
	scanf("%d", &q);
	for (i = 0; i < q; i++)
	{
		scanf("%s", &b[i]);
		l = strlen(&b[i]);
		scanf("%d %d", &b[i][l + 1], &b[i][l + 2]);
	}
	for (i = 0; i < q; i++)
	{
		if (b[i][0] == 't'&&b[i][6] == 't')
		{
			printf("%d [%s] %")
		}
	}*/