#include <stdio.h>
int main()
{
	int t,n,m,c;
	char a=37;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		printf("[");
		for(c=1;c<=m;c++){
			printf("#");
		}
		for(c=1;c<=n-m;c++){
			printf("-");
		}
		printf("] ");
		printf("%d%c\n",m*100/n,a);
	}
	return 0;
}
