#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a=0,b=0,c=0,d=0,n=0,aa,bb,cc,dd;
	scanf("%d %d %d %d",&aa,&bb,&cc,&dd);
	while(aa>0){
		a+=aa%10;
		aa=aa/10;
	}
	while(bb>0){
		b+=bb%10;
		bb=bb/10;
	}
	while(cc>0){
		c+=cc%10;
		cc=cc/10;
	}
	while(dd>0){
		d+=dd%10;
		dd=dd/10;
	}
	if(a>=16||a==6)
	n+=1;
	if(b>=16||b==6)
	n+=1;
	if(c>=16||c==6)
	n+=1;
	if(d>=16||d==6)
	n+=1;
	if(n==1)
	printf("Oh dear!!");
	else if (n==2)
	printf("BaoBao is good!!");
	else if (n==3)
	printf("Bao Bao is a SupEr man///!");
	else if (n==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if (n==0)
	printf("Bao Bao is so Zhai......");
	return 0;
}


