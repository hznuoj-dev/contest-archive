#include<stdio.h>
#include<math.h>
#include<string.h>
long long J(int a){
	int i;
	long long x=1;
	for(i=1;i<=a;i++){
		x*=i;
	}
	return x;
}

long long C(int a,int b){
	long long x;
	x=J(a)/(J(b)*J(a-b));
	return x;
}

long long A(int a,int b){
	long long x;
	x=C(a,b)*J(b);
	return x;
}

int main(){
	int n,a[100001],num[100001]={0},i,z;
	long long x=1;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		num[a[i]]++;
	}
	z=a[n-1];
	if(z<3)
		x=1;
	else{
		    for(i=3;i<=z;i++){
		    x=(x*A(num[i-1],num[i]))% 998244353;
	    }
	}
	printf("%lld",x);
	return 0;
}