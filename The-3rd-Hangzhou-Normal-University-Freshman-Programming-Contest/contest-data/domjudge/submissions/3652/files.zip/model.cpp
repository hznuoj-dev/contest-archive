//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 1010;

int main() {

#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);

	int n, m;
	string s;
	cin >> n;
	m = n;
	while (n--){
		cin >> s;
	}
	printf("%d\n", m * s.length());

	return 0;
}
