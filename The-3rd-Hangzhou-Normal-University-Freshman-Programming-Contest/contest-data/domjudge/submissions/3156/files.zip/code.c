#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
	int t, i = 0, e, q, w;
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &q, &w);
		e = w * 100 / q;
		printf("[");
		for (i = 1; i <= w; i++) {
			printf("#");
		}
		for (i = w + 1; i <= q; i++) {
			printf("-");
		}
		printf("]");
		printf(" %d", e);
		printf("%%\n");
	}
	return 0;
}