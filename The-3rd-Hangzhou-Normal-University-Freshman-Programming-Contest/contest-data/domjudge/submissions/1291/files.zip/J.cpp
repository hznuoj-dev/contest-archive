#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<set>
#include<map>
#include<iostream>
using namespace std;
typedef long long int ll;
const int N=1e5+100;
char mp[110][1000010];
void run(){
	int n;scanf("%d",&n);
	int ans=0;
	for(int i=1;i<=n;i++){
		scanf("%s",mp[i]+1);
		map<char,int>mmp;
		for(int j=1;j<=1e6;j++){
			if(mp[i][j]=='\0')break;
			if(mp[i][j]=='.')continue;
			else{
				if(mmp[mp[i][j]])continue;
				else{
					mmp[mp[i][j]]=1;
					ans++;
				}
			}
		}
	}
	printf("%d\n",ans);
}
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		run();
	}
	return 0;
}
