
#include<stdio.h>
int main(){
	int T,Y,A,a,b,i,sum=0;
	int m;
	scanf("%d",&T);
	while(T--){
		sum = 0;
		scanf("%d %d",&Y,&A);
		b = Y + A;
		a = b - 9999;
		if(b<Y){
			m = Y;
			Y = b;
			b = m;
		}
		else{
			if(a>=1)
		    	b = 9999-a;
			else
		    	b = Y + A;
		}
		if(b<Y){
			m = Y;
			Y = b;
			b = m;
		}
		for(i=Y;i<=b;i++){
			if(i%400==0||(i%4==0&&i%100!=0)){
				sum += 1;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
