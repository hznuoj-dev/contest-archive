#include <stdio.h>
#include <stdlib.h>
int main (){
	int T,Y,A,sum,y,m,n,a;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&Y,&A);
		sum=Y+A;
		if(sum>=10000){
			sum=9999-(sum-9999);
		}
		m=Y/400;
		n=sum/400;
		if(Y>sum){
			a=(Y-sum)/100;
			y=(Y-sum)/4-a+(m-n);
		}
		else{
			a=(sum-Y)/100;
			y=(sum-Y)/4-a+(n-m);
		}
		if(Y%100==0||sum%100==0){
			if(Y%400==0||sum%400==0){
				y+=1;
			}
		}
		if((Y%4==0&&Y%100!=0)||(sum%4==0&&sum%100!=0)){
			y=y+1;
		}
		printf("%d\n",y);
	}
	return 0;
} 
