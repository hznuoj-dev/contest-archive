#include<stdio.h>
#include<string.h>
int main(){
char s[10];
gets(s);
if(s[0]=='k'&&s[1]=='f'&&s[2]=='c')
printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|   \\___ >\n     \\/           \\/\n");
return 0;
}
