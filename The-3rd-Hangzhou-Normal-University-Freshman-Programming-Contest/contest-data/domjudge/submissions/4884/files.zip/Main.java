import java.util.Scanner;

public class ff
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{
			int n=sc.nextInt();
			for(int i=0;i<n;i++)
			{
				int a=sc.nextInt();
				int b=sc.nextInt();
				System.out.print("[");
				for(int j=0;j<b;j++)
				{
					System.out.print("#");
				}
				if(a!=b) 
				{									
				for(int j=0;j<a-b;j++)
				{
					System.out.print("-");
				}
				}								
				System.out.print("]");
				double yzy=(((double)(b*100)/a));
				System.out.print(" ");
				System.out.printf("%.0f",yzy);
				System.out.println("%");
			}//System.out.println();
		}

	}

}
