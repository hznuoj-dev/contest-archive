#include<stdio.h>
int main(){
	int n;
	scanf("%d", &n);
	int a,b;
	int c;
	char hh = '%';
	while(n--){
		scanf("%d%d", &a,&b);
		c = int(b * 1.0 / a * 100);
		printf("[");
		for(int i = 0; i < b;i++){
			printf("#");
		}
		for(int i = 0; i< a-b; i++){
			printf("-");
		}
		printf("] %d%c\n", c, hh);
	}
} 
