#include<stdio.h>
int main()
{
	int t,n,m;
	double num;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		num=m*1.0/n;
		int sum=n-m;
		printf("[");
		while(m--) printf("#");
		while(sum--) printf("_");
		printf("]");
		printf(" %.0lf%%\n",num*100);
	}
	return 0;
}
