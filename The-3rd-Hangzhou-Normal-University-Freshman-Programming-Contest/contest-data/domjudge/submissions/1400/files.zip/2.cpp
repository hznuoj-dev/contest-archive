#include <stdio.h>
int main (){
	int t;
	int a,b,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		int c;
		c=a+b;
		if(c>=a){//a,c
			for(int i=a;i<=c;i++){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				}
			}
		}
		else{
			for(int i=c;i<=a;i++){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				}
			}	
		}
		printf("%d\n",x);
		
	}
	
	return 0;
} 
