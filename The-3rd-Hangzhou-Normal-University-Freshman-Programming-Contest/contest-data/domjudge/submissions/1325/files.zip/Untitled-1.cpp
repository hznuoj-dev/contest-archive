#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>


using namespace std;

int s[11111]={0};
int x , y, a;

void pro(){
	for(int i=0;i<11100;i++){
		if((i%4==0&&i%100!=0)||i%400==0){
			s[i]=1;
		}
	}
}



int main(){
	int t, sum;
	cin >> t;
	pro();
	while(t--){
		sum=0;
		cin >> y >> a;
		if(y+a>9999){
			x=9999-(y+a-9999);
		}
		else{
			x=y+a;
		}
		int temp;
		if(x<y){
			t=x;
			x=y;
			y=t;
		}
		for(;y<=x;y++){
			sum+=s[y];
		}
		cout << sum << endl; 
	}
    return 0;
}
