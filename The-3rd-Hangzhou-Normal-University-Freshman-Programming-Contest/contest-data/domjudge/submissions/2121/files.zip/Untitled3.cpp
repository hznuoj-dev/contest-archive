#include <stdio.h>
int main(void){
	int n,m;
	scanf("%d %d",&n, &m);
	int a[n],b[n];
	int i;
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(i=0;i<n;i++)
		scanf("%d",&b[i]);
	int sum=0,cnt=0;
	while(sum<m){
		for(i=0;i<n;i++){
			for(int k=0;k<b[i];k++){
				sum+=a[i];
				cnt++;
			}
		}
	}
	printf("%d\n",cnt);
	return 0;
}
