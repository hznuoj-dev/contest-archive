//����a,b,c,d
//����λ����
//λ����ӣ��жϺͣ�ȥ����count++��
//�����
#include<stdio.h>
int go(int x){
	int sum=0,a=0;
	while(x%10==0){
		a=x%10;
		sum+=a;
		x=x/10;
		
	}
	if(sum==6||sum>=16)
	return 1;
	else
	return 0; 
}
int main(void){
	long long int a,b,c,d;
	int count=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	count=go(a)+go(b)+go(c)+go(d);
	if(1==count)
	printf("Oh dear!!");
	else if(2==count)
	printf("BaoBao is good!!");
	else if(3==count)
	printf("Bao Bao is a SupEr man///!");
	else if(4==count)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(0==count)
	printf("Bao Bao is so Zhai......");
	return 0;
	
} 
 
