#include "stdio.h"
int main(){
	int t;int y1,a;
	while(scanf("%d",&t)!=EOF){
	while(t--){
		int co=0;
		scanf("%d %d",&y1,&a);
		int y2=0;
		if(y1+a>9999){
			int t1=(y1+a)-9999;
			y2=y1+t1;
		}else y2=a+y1;
		
		if(y1<y2){
			for(int i=y1;i<=y2;i++){
				if( (i%4==0&&i%100!=0) ||i%400==0) co++;
			}
		}else{
			for(int i=y2;i<=y1;i++){
					if( (i%4==0&&i%100!=0) ||i%400==0) co++;
			}
		}
		printf("%d\n",co);
	}
}
} 
