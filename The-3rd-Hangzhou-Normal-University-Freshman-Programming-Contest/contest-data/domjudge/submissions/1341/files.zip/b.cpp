#include <stdio.h> 
int main(void){
	int n,y1,y2,x,t,i,sum;
	scanf("%d",&n);
	while(n--){
		scanf("%d %d",&y1,&x);
		sum=0;
		y2=y1+x;
		if(y2>9999)y2=9999-(y2-9999);
		if(y2<y1){
			t=y1;
			y1=y2;
			y2=t;
		}
		for(i=y1;i<=y2;i++){
			if((i%4==0&&i%100!=0)||(i%400==0))++sum;
		}
		printf("%d\n",sum);
	}
	return 0;
}
