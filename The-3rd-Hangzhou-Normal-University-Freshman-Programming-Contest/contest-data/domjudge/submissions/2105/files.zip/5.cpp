#include <stdio.h>
#include<string.h>
int main(){
int t,a,b,i;
char p='%';
double s;
scanf("%d",&t);
while (t--){
	scanf("%d %d",&a,&b);
	printf("[");
	for(i=1;i<=a;i++){
		printf("#");
	}
	for(i=1;i<=a-b;i++){
		printf("-");
	}
	printf("] ");
	s=b*1.0/a*1.0;
	printf("%.0lf",s*100);
	printf("%c",p);
} 
 return 0;
}
