#include <iostream>
#include <queue>
#include <set>

#define MAX_N 100002

using namespace std;

int m[MAX_N];
int l[MAX_N];
int a[MAX_N][MAX_N];
int b;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n, q;
    int i, j, c;
    int k;
    priority_queue<int, vector<int>, greater<int>> s;

    cin >> n;
    for (i = 0; i < n; ++i) {
        cin >> m[i];
        for (j = 0; j < m[i]; ++j) {
            cin >> a[i][j];
        }
    }
    cin >> q;
    for (i = 0; i < q; ++i) {
        cin >> l[i];
        for (j = 0; j < l[i]; ++j) {
            cin >> b;
            for (k = 0; k < m[b - 1]; ++k) {
                s.push(a[b - 1][k]);
            }
        }
        cin >> k;
        for (c = 0; c < k - 1; ++c) {
            s.pop();
        }
        cout << s.top() << '\n';
        while (!s.empty()) {
            s.pop();
        }
    }

    return 0;
}