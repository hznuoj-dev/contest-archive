#include<bits/stdc++.h> 
using namespace std;
int main(){
	int T,key=0,fi[1024];
	for(int i=1;i<=1024;++i) fi[i]=0;
	scanf("%d",&T);
	for(int i=1;i<=T;++i){
		int sum=0,cs;
		scanf("%d",&cs);
		for(int j=0;j<=cs;++j){
			while(key==0) {
				char a=getchar();
				if(a==' '||a=='\n') key=1;
				else fi[a]=1;
			}key=0;
			fi['.']=0;
			for(int k=1;k<=1024;++k){
				sum=sum+fi[k];
				fi[k]=0;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
