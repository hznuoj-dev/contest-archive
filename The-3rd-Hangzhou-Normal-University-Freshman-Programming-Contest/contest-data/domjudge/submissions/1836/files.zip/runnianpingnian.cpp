#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int main()
{
	int t;
	int a,b;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&a,&b);
		int sum=0;
		if(a+b>9999)
		{
			sum=2*9999-a-b;
		}
		else
		{
			sum=a+b;
		}
		int temp;
		if(sum<a)
		{
			temp=a;
			a=sum;
			sum=temp;
		}
		int gs=0;
		for(int i=a;i<=sum;i++)
		{
			if((i%4==0&&i%100!=0)||(i%400)==0)
			{
				gs++;
			}
		}
		printf("%d\n",gs);
	}
	return 0;
}
