#include<stdio.h>
int main(void){
long int n,a,b,i,j;
scanf("%ld",&n);
while(n--){
scanf("%ld%ld",&a,&b);
printf("[");
i=a-b;
j=b;
while(j--)
printf("#");
while(i--)
printf("-");
printf("] ");
printf("%.lf%%",(double)b/(double)a*100);
if(n)
printf("\n");
} 
return 0;}
