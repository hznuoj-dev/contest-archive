#include<stdio.h>
int main()
{
double a,b,c,t,d;
scanf("%d",&d);
while(d--){
scanf("%lf%lf",&a,&b);
c=b/a*100;
printf("[");
for(int i=0;i<b;i++)printf("#");
for(int i=0;i<a-b;i++)printf("-");
printf("]");
printf(" %.0lf%%\n",c);
}
return 0;
}
