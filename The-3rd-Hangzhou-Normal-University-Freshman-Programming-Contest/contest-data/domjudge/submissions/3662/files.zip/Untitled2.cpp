#include<stdio.h>
#include<string.h>
int main()
{
	int t,w[100],n,i,l,j,count;
	char s[1000000];
	
	scanf("%d",&t);
	while(t--)
	{
		for (i=0;i<100;i++) 	w[i]=0;
		count=0;
		scanf("%d",&n);
		getchar();
		for(i=0;i<n;i++)
		{
			gets(s);
			l=strlen(s);
			for (j=0;j<l;j++)
			{
				w[s[j]-' ']++;
			}
		}
		w['.'-' ']=0;
		for (i=0;i<100;i++)
		{
			if (w[i]!=0) count++;
		}
		printf("%d\n",count);
		t--;
	}
	return 0;
}
