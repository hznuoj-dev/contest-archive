#include <stdio.h>
#include <string.h>
int main()
{
	char a[20],b[20],c[20],d[20];
	scanf("%s %s %s %s",&a,&b,&c,&d);
	int m=0,n=0;
	for(int i=0;i<strlen(a);i++)
		n+=(a[i]-'0');
	if(n>=16||n==6)
	m++;
	n=0;
	for(int i=0;i<strlen(b);i++)
	n+=(b[i]-'0');
	if(n>=16||n==6)
	m++;
	n=0;
	for(int i=0;i<strlen(c);i++)
	n+=(c[i]-'0');
	if(n>=16||n==6)
	m++;
	n=0;
	for(int i=0;i<strlen(d);i++)
	n+=(d[i]-'0');
	if(n>=16||n==6)
	m++;
	n=0;
	if(m==1)
	printf("Oh dear!!");
	else if(m==2)
	printf("BaoBao is good!!");
	else if(m==3)
	printf("Bao Bao is a SupEr man///!");
	else if(m==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(m==0)
	printf("Bao Bao is so Zhai......");
}
