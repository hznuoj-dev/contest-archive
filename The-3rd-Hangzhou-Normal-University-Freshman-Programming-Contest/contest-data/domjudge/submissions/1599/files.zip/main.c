#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int T,t;
	int n;
		int judge(int n)
	{
		if(n%4==0&&n%100!=0)
			return 1;
		else if(n%100==0&&n%400==0)
			return 1;
		else 
			return 0;
	}
	scanf("%d",&T);
	while(T--)
	{
	int x=0;
	int max,min,y,s;
	scanf("%d %d",&y,&s);
	max=y+s;
	min=y;
	if(max>9999)
	{
		max-=max-9999;
		if(max<min)
		{
		t=max;
		max=min;
		min =t;
		}
	
	}
	else if(min>max)
	{
		t=max;
		max=min;
		min =t;
	}
	int i;
	for(i=min;i<=max;i++)
	{
		x+=judge(i);
	}
	printf("%d\n",x);
	
	}
	
	return 0;
}
