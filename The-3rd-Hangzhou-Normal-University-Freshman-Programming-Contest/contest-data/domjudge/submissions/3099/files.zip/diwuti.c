#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
	int i,s,b,j,p;
	i=1;
	s=0;
	while(i<=4){
		char a[20]={0};
		scanf("%s",a);
		getchar(); 
		j=0;
		p=0;
		while(j<strlen(a)){
			b=a[j]-48;
			p=p+b;
			j=j+1;
		}
		if(p>=16||p==6)
			s=s+1;
		i=i+1;
	}
	if(s==0)
		printf("Bao Bao is so Zhai......\n");
	else if(s==1)
		printf("Oh dear!!\n");
	else if(s==2)
		printf("BaoBao is good!!\n");
	else if(s==3)
		printf("Bao Bao is a SupEr man///!\n");
	else if(s==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
