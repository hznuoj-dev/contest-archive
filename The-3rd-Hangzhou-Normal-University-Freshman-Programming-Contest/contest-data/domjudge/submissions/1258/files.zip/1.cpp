#include <bits/stdc++.h>
using namespace std;
int pan(int n) {
	return ((n%4==0&&n%100!=0)||n%400==0);
}
int main() {
	int t;
	cin>>t;
	for (int i=1;i<=t;i++) {
		int x,y,z,cnt=0;
		cin>>x>>y;
		if (x+y>=10000) {
			int t=x+y-9999;
			z=9999-t;
		}
		else z=x+y;
		if (x>z) swap(x,z);
		if (x<=0) x--;
		for (int j=x;j<=z;j++) {
			if (j==0) continue;
			if (pan(j)) cnt++;
		} 
		cout<<cnt<<endl;
	}
}
