#include<iostream>
#include<string>
using namespace std;
int main(){
    int t,n;
    string s;
    char a;
    cin>>t;
    while(t--){
    	cin>>n;
    	int sum=0;
    	while(n--){
    		int m=0;
    		cin>>s;
    		int l=s.size();
    		for(int j=0;j<l;j++){
    			if(s[j]!='.'){
    				a=s[j];
    				for(int i=j;i<l;i++){
    					if(s[i]==a){
    						s.replace(i,1,".");
						}
					}
					m=m+1;
				}
			}
			sum=sum+m;
		}
		cout<<sum<<endl;
	}
}
