#include<stdio.h>
#include<string.h>
int longth(char a, char k[]);
int main()
{
	int T, N, i, sum, j,longe;
	long rubbish;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d", &N);
		rubbish = 0;
	
		for (i = 0; i < N; i++)
		{		sum = 0;
		char k[1000000] = {};
		k[0] = '.';
		char s[100000]={};
			scanf("%s",s);
			longe = strlen(s);
			for (j = 0; j < longe; j++)
			{
				if (longth(s[j], k) == 1) sum += 1;
			}
			rubbish+=sum;
		}
		printf("%ld\n", rubbish);
	}
	return 0;
}

int longth(char a, char k[])
{
	int  i;
	int sum = 1;
	long longe;
	longe=strlen(k);
	for (i = 0; i <longe ; i++)
	{
		
		if (a == k[i]) sum = 0;
	}
	if (sum == 1) {
		k[longe] = a;
		k[longe+1] = '\0';
	}
	return(sum);
}

