#include<stdio.h>
int main()
{
	int T,x,n;
	scanf("%d",&T);
	while(T--){
		int Y,A,m,i;
		scanf("%d %d",&Y,&A);
		m=Y+A;
		x=0;
	if(m>9999){
		n=9999-(m-9999);
		if(n>Y){
				for(i=Y;i<=n;i++){
					if(i%4==0&&i%100!=0||i%400==0)
					x++;
				}
			}
		else
			for(i=n;i<=Y;i++){
				if(i%4==0&&i%100!=0||i%400==0)
					x++;
					}
				}
	else
		if(m>Y){
			for(i=Y;i<=m;i++){
				if(i%4==0&&i%100!=0||i%400==0)
					x++;
			}
		}
		else
			for(i=m;i<=Y;i++){
				if(i%4==0&&i%100!=0||i%400==0)
					x++;
			}
		printf("%d\n",x);
	}
	return 0;
}
