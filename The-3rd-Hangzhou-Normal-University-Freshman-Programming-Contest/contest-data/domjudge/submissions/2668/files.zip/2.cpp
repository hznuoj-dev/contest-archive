#include<stdio.h>
int run(int n){
	if ((n % 4 == 0 && n % 100 != 0) || (n % 400 == 0))
		return 1;
	else return 0;
}
int main(void) {
	int t, y, a, i, p;
	scanf_s("%d", &t);
	while (t--) {
		int x = 0;
		scanf_s("%d%d", &y, &a);
		if (a + y >= 10000)
			p = 9999 - (a + y - 9999);
		else p = y + a;
		if (p >= y) {
			for (i = y; i <= p; ++i) {
				if (run(i) == 1)
					x = x + 1;
			}
		}
		else for (i = p; i <= y; ++i) {
			if (run(i) == 1)
				x = x + 1;
		}
		printf("%d\n", x);
	}
	return 0;
}
