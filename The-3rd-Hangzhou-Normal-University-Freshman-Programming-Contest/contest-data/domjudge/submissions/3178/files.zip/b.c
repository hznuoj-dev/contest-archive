#include<stdio.h>
int main()
{
	int a,b,c,i,j,d;
	scanf("%d",&j);
	while(j--)
	{
		d=0;
		scanf("%d%d",&a,&b)
			c=a+b;
		if(b<0)
			for(i=c;i<=a;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					d++;
			}
		else if(c>9999)
			c=9999-(c-9999)
			for(i=a;i<=c;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					d++;
			}
		else
		{
			for(i=a;i<=c;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					d++;
			}
		}
		printf("%d\n",d);
	}
	return 0;
}