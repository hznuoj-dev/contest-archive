#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void){
	int y,a,point,m,i,t,x;
	scanf("%d",&t);
	while(t--)
	{
		point=0;
		scanf("%d%d",&y,&a);
		x=y+a;
		m=(x<y?x:y);
		for(i=m;i<x+y-m;++i)
		{
			if((i%100!=0&&i%4==0)||i%400==0)
			{
				++point;
				i+=3;
			}
			
		} 
		printf("%d\n",point);		
	}
	

	return 0;
} 
