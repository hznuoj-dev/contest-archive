#include<bits/stdc++.h>
using namespace std;
int main()
{
cout<<" __      _____"<<endl;
cout<<"|  | ___/ ____\____"<<endl;
cout<<"|  |/ /\   __\/ ___\ "<<endl
cout<<"|    <  |  | \  \___"<<endl;
cout<<"|__|_ \ |__|  \___  >"<<endl;
cout<<"     \/           \/"<<endl;
	return 0;
}


