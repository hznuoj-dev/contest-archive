#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char a[19],b[19],c[19],d[19];
	int x=0,y=0,m=0,n=0,i;
	int f1=0,f2=0,f3=0,f4=0;
	scanf("%s %s %s %s",a,b,c,d) ;
	for(i=0;i<strlen(a);++i){
		x=x+a[i]-48;
	}

	for(i=0;i<strlen(b);++i){
		y=y+b[i]-48;
	}
	for(i=0;i<strlen(c);++i){
		m=m+c[i]-48;
	}
	for(i=0;i<strlen(d);++i){
		n=n+d[i]-48;
	}
	if(x>=16||x==6)
	f1=1;
	if(y>=16||y==6)
	f2=1;
	if(n>=16||n==6)
	f3=1;
	if(m>=16||m==6)
	f4=1;
	
	if(f1+f2+f3+f4==0)
		printf("Bao Bao is so Zhai......\n") ;
	else if(f1+f2+f3+f4==1)
	printf("Oh dear!!\n");
	else if(f1+f2+f3+f4==2)
	printf("BaoBao is good!!\n");
	else if(f1+f2+f3+f4==3)
	printf("��Bao Bao is a SupEr man///!\n");
	else if(f1+f2+f3+f4==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
