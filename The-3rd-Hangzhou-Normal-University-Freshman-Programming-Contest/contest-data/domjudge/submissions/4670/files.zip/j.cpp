#include<stdio.h>
#include<string.h>
int main(){
    int n,t,i;
    scanf("%d",&n);
    while(n--){
        scanf("%d",&t);
        int sum=0;
        while(t--){
            int a[200]={0};char s[1000000];
            scanf("%s",&s);
            for(i=0;i<strlen(s);i++){
                if(s[i]!='.'){
                    if(a[(int)s[i]]==0){sum++;a[(int)s[i]]=1;}
                }
            }
        }
        printf("%d\n",sum);
    }
}
