#include <stdio.h>
int main()
{
	int t,i,j,a,b;
	double s;
	char c='%';
	while(scanf("%d",&t)){
		for(i=1;i<=t;i++){
		scanf("%d %d",&a,&b);
		printf("[");
		for(j=1;j<=b;j++){
			printf("#");
		}
		for(j=1;j<=a-b;j++){
			printf("-");
		}
		printf("] ");
        s=1.0*b/(a*1.0);
        printf("%.0lf\%c\n",100*s,c);
	}	
	}

	return 0;
}

