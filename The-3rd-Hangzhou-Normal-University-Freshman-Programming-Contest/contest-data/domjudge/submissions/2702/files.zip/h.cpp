#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
        int n1,n2;
        cin>>n1>>n2;
        int res=n1-n2;
        cout<<'[';
        for(int i=0;i<n2;i++) cout<<'#';
        for(int i=0;i<res;i++) cout<<'-';
        cout<<']'<<' ';
        int per=100*((double)n2/(double)n1);
        cout<<per<<'%'<<'\n';
    }
    return 0;
}