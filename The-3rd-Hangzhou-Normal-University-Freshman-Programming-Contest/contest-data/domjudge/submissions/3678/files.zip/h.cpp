#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int n,m,k,i,j;
	float a,b,c;
	scanf("%d",&n);
	while(n--){
		scanf("%f %f",&a,&b);
		c=b/a;
		printf("[");
		for(i=0;i<b;i++){
			printf("#");
		}
		for(i=0;i<a-b;i++){
			printf("-");
		}
     printf("] %.0f%%\n",c*100);
	}
	return 0;
}




