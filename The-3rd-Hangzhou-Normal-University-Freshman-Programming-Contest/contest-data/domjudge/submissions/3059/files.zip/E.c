#include<stdio.h>
int main(){
	char c;
	scanf("%c",&c);
	printf(" __      _____");
	printf("\n");
	printf("|");printf("  ");printf("|");printf(" ");printf("___");printf("/");printf(" ");printf("____\\____");
	printf("\n");
	printf("|");printf("  ");printf("|");printf("/ /");printf("\\   __\\");printf("/ ___");printf("\\");
	printf("\n");	
	printf("|    <  |  | \\ \\___");
	printf("\n");
	printf("|__|_ \\ |__| \\___ >");		
	printf("\n");
	printf("     \\");printf("/");printf("         ");printf("\\");printf("/");
return 0;
} 
