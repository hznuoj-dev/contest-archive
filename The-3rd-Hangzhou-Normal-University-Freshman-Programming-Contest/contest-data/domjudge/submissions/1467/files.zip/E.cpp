//
// Created by Kyooma on 2020/12/13.
//
#include <bits/stdc++.h>
using namespace std;
int main(){
    string s;
    cin>>s;
    printf(" __      _____\n");
    printf("|  | ___/ ____\\____\n");
    printf("|  |/ /\\   __\\/ ___\\\n");
    printf("|    <  |  | \\  \\___\n");
    printf("|__|_ \\ |__|  \\___  >\n");
    printf("     \\/           \\/\n");
}