#include<stdio.h>
#include<string.h>
int main(void)
{
	int T,t=0,sum=0,i,Y,A,B=0;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&Y,&A);
		if(Y+A>9999)
		B=9999-(Y+A-9999);
		else
		B=Y+A;
		if(Y>B)
		{
			t=Y;Y=B;B=t;
		}
		for(i=Y;i<=B;i++)
		{
			if(i%4==0&&i%100!=0||i%400==0)
			sum++;
		}
		printf("%d\n",sum);
		sum=0;
	}
	return 0;
}
