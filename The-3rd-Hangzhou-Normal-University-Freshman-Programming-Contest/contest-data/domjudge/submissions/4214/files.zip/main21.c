#include <stdio.h>

int main(void) {
	int a,b,c,d,n=0,m=0,l=0,s=0,h=0,p=0,q=0,r=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	while(a>0){
		n=a%10;
		a=a/10;
		m+=n;
	}
	while(b>0){
		p=b%10;
		b=b/10;
		l+=p;
	}
	while(c>0){
		q=c%10;
		c=c/10;
		s+=q;
	}
	while(d>0){
		r=d%10;
		d=d/10;
		h+=r;
	}
	if((m>=16&&l<16&&s<16&&h<16)||(l>=16&&m<16&&s<16&&h<16)||(s>=16&&l<16&&m<16&&h<16)||(h>=16&&l<16&&s<16&&m<16))
		printf("Oh dear!!\n");
	else if((m>=16&&l>=16&&s<16&&h<16)||(m>=16&&s>=16&&l<16&&h<16)||(m>=16&&h>=16&&l<16&&s<16)||(l>=16&&s>=16&&m<16&&h<16)||(l>=16&&h>=16&&m<16&&s<16)||(s>=16&&h>=16&&m<16&&l<16))
		printf("BaoBao is good!!\n");
	else if((m>=16&&l>=16&&s>=16&&h<16)||(m>=16&&l>=16&&h>=16&&s<16)||(l>=16&&s>=16&&h>=16&&m<16))
		printf("Bao Bao is a SupEr man///!\n");
	else if(m>=16&&l>=16&&s>=16&&h>=16)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	else if(m<16&&l<16&&s<16&&h<16)
		printf("Bao Bao is so Zhai......\n");
	return 0;
}
