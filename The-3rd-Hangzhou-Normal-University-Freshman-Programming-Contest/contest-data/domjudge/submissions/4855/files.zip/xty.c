#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main()
{
    int n, a, b,c,d,i,sum=0,x;
    scanf("%d", &n);
    while (n--)
    {
        scanf("%d %d", &a,&b);
        if (a + b > 9999)
        {
            c = a + b - 9999;
            d = 9999 - c;
            if (a > d)
            {
                x = a;
                a = d;
                d = x;
            }
            for (i = a;i <= d;++i)
            {
                if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
                {
                    sum += 1;
                }
            }
        }
        else
        {
            d = a + b;
            if (a > d)
            {
                x = a;
                a = d;
                d = x;
            }
            for (i = a;i <= d;++i)
            {
                if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
                {
                    sum += 1;
                }
            }
        }
        printf("%d\n", sum);
        sum = 0;
    }
    return 0;
}