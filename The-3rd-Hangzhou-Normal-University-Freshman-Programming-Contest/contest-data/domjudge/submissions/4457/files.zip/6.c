#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i,t,j,m,n,d;
	char s[10000000];
	scanf("%d",&t);
	while(t--){
		d=0;
		scanf("%d",&m);
		getchar();
		for(i=0;i<m;i++){
			scanf("%s",s);
			for(j=0;j<strlen(s);j++){
			if(s[n]!='.')
{
			for(n=j+1;n<strlen(s);n++){
					if(s[n]!='.'){
				
					if(s[j]==s[n])
					s[n]='.'; 
			}
		}
	}
		
			} 
				for(j=0;j<strlen(s);j++){
					if(s[j]!='.')
					d++;
				}
		}
		printf("%d\n",d);
	}
	
	return 0;
}

