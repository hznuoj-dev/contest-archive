#include<stdio.h>
int ans,x,a[100000];
int main(void){
	
	int n,i,s=1,y,p,b;
	scanf("%d",&n);
	ans=1;
	for(i=1;i<=n;i++){
		
		scanf("%d",&x);
		a[x]++;
	}
	for(i=2;i<=10000;i++){
		
		if(a[i]==0) break;
		else if(a[i-1]==1);
		else{
			
			x=1;
			b=a[i-1];
			p=a[i];
			while(p>0){
				
				if(p&1) x=x*b%998244353;
				b=b*b%998244353;
				p=p/2;
			}
			ans=ans*x%998244353;
		}
	}
	printf("%lld",ans);
}
