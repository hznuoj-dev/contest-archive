#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,s=0;
		scanf("%d",&n);
		char a[1000001];
		while(n--){
			scanf("%s",a);
			int lena,m=0,j;
			char lj[1000001];
			lena=strlen(a);
			for(int i=0;i<lena;i++){
				if(a[i]!='.'){
					for( j=0;j<m;j++){
						if(a[i]==lj[j]){
							break;
						}
					}
					if(j==m){
						lj[m]=a[i];
						m++;s++;
					}
				}
			}	
		}
		printf("%d\n",s);
	}
	
	
}
