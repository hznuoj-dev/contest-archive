#include <stdio.h>

int main(){
	int time;
	scanf("%d",&time);
	while(time--){
		int n;
		int sum = 0;
		scanf("%d",&n);
		getchar();
		while(n--){
			char arr[1000000];
			int point = 0;
			while(1){
				char c = getchar();
				if(c == '\n'){
					break;
				}else if(c != '.'){
					int flag = 0;
					for(int i = 0; i < point; i++){
						if(arr[i] == c){
							flag = 1;
							break;
						}
					}
					if(flag == 0){
						arr[point] = c;
						point++;
					}
				}
			}
			sum += point;
		}
		printf("%d\n",sum);
	}
}
