#include <iostream>

int main() {
	int T;
	int Y,A;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&Y,&A);
		int i;
		int sum=0;
		if(Y+A>9999){
			int x=Y+A-9999;
			A=9999-x;
		}
		else{
			A=Y+A;
		}
		if(Y>A){
			for(i=A;i<=Y;i++){
        		if((i%4==0&&i%100!=0)||(i%400==0))
					sum++;
			}
		}
		else{
			for(i=Y;i<=A;i++){
        		if((i%4==0&&i%100!=0)||(i%400==0))
					sum++;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}

