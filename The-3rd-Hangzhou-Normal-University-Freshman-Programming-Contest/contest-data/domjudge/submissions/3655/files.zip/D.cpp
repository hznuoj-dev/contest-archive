#include<iostream>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
int main(){
	fcio;
	int n;
	while(cin>>n){
		string s; 
		int num=0;
		for(int i=0;i<n;++i){
			cin>>s;
			num+=s.length();
		}
		cout<<num<<endl;
	}
}

