#pragma warning (disable:4996)
#include<stdio.h>
#include<string.h>
int main(void) {
	int a, b, c, i, j;
	int rn(int x);
	scanf("%d", &a);
	while (a--) {
		scanf("%d %d", &b, &c);
		if (c <= 0) {
			j = b + c;
			c = b;
			b = j;
		}
		if (b + c > 9999) {
			c = 9999 - (c + b - 9999);
			if (b > c) {
				j = b, b = c, c = j;
			}
		}
		j = 0;
		for (i = b; i <= c; i++)
			j += rn(i);
		printf("%d\n", j);
	}
	return 0;
}
int rn(int x) {
	int i, j;
	if (x % 400 == 0)
		return 1;
	else if (x % 4 == 0 && x % 100 != 0)
		return 1;
	else
		return 0;
}
