#include<stdio.h>
#include<string.h>
int main()
{
	char s[1000];
	int n,a,bn[128]={0},t,sum,flag[128]={0};
	scanf("%d",&t);
	for(int k=0;k<t;k++)
	{
			sum=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++)
		{
			for(int q=0;q<128;q++)
		{
			flag[q]=0;
		}
			for(int q=0;q<128;q++)
			{
				bn[q]=0;
			}
			scanf("%s",s);
			a=strlen(s);
			for(int j=0;j<a;j++)
		{
			if(int(s[j])!=46)
			{
				bn[int(s[j])]=bn[int(s[j])]+1;
			}
		}
		for(int i=0;i<128;i++)
			{
				if(bn[i]!=0&&flag[i]==0)
				{
					sum=sum+1;
					flag[i]=1;
				}
			}
	}
			printf("%d\n",sum);
	}
	return 0;
 } 
