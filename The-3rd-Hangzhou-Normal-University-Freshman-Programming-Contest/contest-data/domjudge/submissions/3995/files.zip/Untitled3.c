
#include<stdio.h>
#include<stdlib.h>
void main()
{
    int s=0;
    for(int i=0;i<=3;i++){
    int num;
    int sum = 0;
    int x,y;
    scanf("%d",&num);

    y = num;

    while (y != 0)
    {
        x = y % 10;
        sum += x;
        y = (int)(y / 10);
    }

    if(sum>=16||sum==6)s++;
}
if(s==1)printf("Oh dear!!\n");
if(s==2)printf("BaoBao is good!!\n");
if(s==3)printf("Bao Bao is a SupEr man///!\n");
if(s==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
if(s==0)printf("Bao Bao is so Zhai......\n");
return 0;}
