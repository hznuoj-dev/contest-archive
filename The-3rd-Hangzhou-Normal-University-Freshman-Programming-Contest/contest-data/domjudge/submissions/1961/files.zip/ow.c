#include<stdio.h>
int main()
{
	int i,j,t=0,sum=0;
	long long a[5];
	for(i=0;i<4;++i){
		scanf("%lld",&a[i]);
	}
	for(j=0;j<4;++j){
		t=0;
		while(a[j]>0){
			t+=a[j]%10;
			a[j]/=10;
		}	
		if(t>=16||t==6)
			sum++;
	}
	if(sum==0)
		printf("Bao Bao is so Zhai......");
	else if(sum==1)
		printf("Oh dear!!");
	else if(sum==2)
		printf("BaoBao is good!!");
	else if(sum==3)
		printf("Bao Bao is a SupEr man///!");
	else if(sum==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}
