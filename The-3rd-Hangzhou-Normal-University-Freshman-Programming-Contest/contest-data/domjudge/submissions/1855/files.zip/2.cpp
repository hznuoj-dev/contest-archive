#include <stdio.h>
#include <math.h>
int main (){
	int t;
	int a,b,x=0;
	int m,n;//if���������� 
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		int c,q;
		c=a+b;
		if(c>9999){
			int d=0;
			d=c-9999;
			m=a;
			n=a+d;
		
	     	if(m>=n){//n,m
			for(int i=n;i<=m;i++){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				}
		    	}
	    	}
	    	else{
		    	for(int i=m;i<=n;i++){
				  if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				 }
			     }	
		    }
		}
		else{
				if(a>=c){//c,a
			for(int i=c;i<=a;i++){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				}
		    	}
	    	}
	    	else{
		    	for(int i=a;i<=c;i++){
				  if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				 }
			     }	
		}
        }
			printf("%d\n",x);
		x=0;
	}
	
	return 0;
} 
