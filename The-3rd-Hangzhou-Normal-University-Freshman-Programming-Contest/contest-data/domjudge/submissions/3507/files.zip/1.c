#include <stdio.h>
#include<string.h>
int main(void) {
	int n=0,i,j,s;
	char a[4][19];
	for (i=0;i<=3;++i){
		s=scanf("%d",a[i]);
		s=0;
		for(j=0;j<strlen(a[i]);++j)
		s=s+(a[i][j]);
		if (s>=16||s==6)
		n=n+1;
	}
	if(n==0)
	printf("Bao Bao is so Zhai......");
	else if(n==1)
	printf("Oh dear!!");
	else if(n==2)
	printf("BaoBao is good!!");
	else if(n==3)
	printf("Bao Bao is a SupEr man///!");
	else if(n==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    return 0;}
