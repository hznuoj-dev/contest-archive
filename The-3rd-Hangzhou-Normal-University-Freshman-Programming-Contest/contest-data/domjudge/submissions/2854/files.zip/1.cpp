#include<stdio.h>
int main(void)
{
	int t,n,m,front,all;
	float percent;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		printf("[");
		front=m;
		all=n;
		while(n--)
		{
			if(n>=all-front)
			printf("#");
			else
			printf("-");
		}
		printf("] ");
		percent=((m*100.0)/all);
		printf("%.0f%%\n",percent);
	}
}
