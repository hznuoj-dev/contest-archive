#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
const int MAX=1e6+10;
char s[MAX];

int main()
{
	int n;
	scanf("%d",&n);
	int len=0;
	while(n--)
	{
		scanf("%s",s);
		len+=strlen(s);
	}
	printf("%d",len);
	return 0;
}
