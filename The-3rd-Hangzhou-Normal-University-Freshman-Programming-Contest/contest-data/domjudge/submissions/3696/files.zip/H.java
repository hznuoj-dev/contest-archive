import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);

		while (in.hasNext())
		{

			int a = in.nextInt();

			for (int i = 0; i < a; i++)
			{

				double b = in.nextDouble();
				double c = in.nextDouble();
				int h = (int) b;
				int p = (int) c;
				String tt = "-";
				String gg = "#";
				String ans = "";

				if (p % 2 == 0)
				{
					for (int j = 0; j < p / 2; j++)
					{
						ans = ans + "##";
					}
				} else
				{
					for (int j = 0; j < p / 2 + 1; j++)
					{

						if (j == p / 2)
						{
							ans = ans + "#";
						} else
						{
							ans = ans + "##";
						}
					}
				}
				int po = h - p;
				if (po % 2 == 0)
				{
					for (int j = 0; j < po / 2; j++)
					{
						ans = ans + "--";
					}
				} else
				{
					for (int j = 0; j < po / 2 + 1; j++)
					{
						if (j == po / 2)
						{
							ans = ans + "-";
						} else
						{
							ans = ans + "--";
						}
					}
				}

				System.out.print("[" + ans + "]");
				if (c == 0)
				{
					System.out.println(" " + 0 + "%");
				} else
				{
					System.out.println(" " + (int) (c * (100 / b)) + "%");
				}

			}

		}
	}

}

