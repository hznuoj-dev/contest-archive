#include<stdio.h>
int main(){
	int s=0,i,a,t;
	for(i=0;i<4;i++){
		scanf("%d",&a);
		t=0;
		while(a>0){
			t+=(a%10);
			a/=10;
		}
		if(t==6||t>=16)s++;
	}
	if(s==0)
		printf("Bao Bao is so Zhai......");
	else if(s==1)
		printf("Oh dear!!");
	else if(s==2)
		printf("BaoBao is good!!");
	else if(s==3)
		printf("Bao Bao is a SupEr man///!");
	else 
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		
	return 0;
} 
