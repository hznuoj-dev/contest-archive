
#include<string.h>
#include<stdlib.h>
#include<math.h>
int main() {
	int t, n, m;
	scanf("%d", &t);
	while (t--) {
		int sum = 0, ans = 0, a, i;
		scanf("%d%d", &n, &m);
		sum = n + m;
		if (sum > 9999) {
			a = sum - 9999;
			sum = 9999 - a;
		}
		if (n > sum) {
			for (i = sum; i <= n; i++) {
				if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) {
					ans++;
				}
			}
		}
		else {

			for (i = n; i <= sum; i++) {
				if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) {
					ans++;
				}
			}
		}
		printf("%d\n", ans);
	}
	return 0;
}
