#include<math.h> 
#include<stdio.h> 
#include<string.h>   
//using namespace std;
 int main()  
{	int a,b,l,n;char s[85];
	scanf("%d",&n);
	
	for(int i=1;i<=n;i++)
	{	scanf("%d %d",&a,&b);	
		l=a+b;
		if(l>=10000)l=9999-(l-9999);
		if(l<a){b=a;a=l;}else b=l;
		
		int cnt=0;
		for(int i=a;i<=b;i++)
		{	
			if(i%4==0&&i%100!=0||i%400==0)
			cnt++;
		}
		printf("%d\n",cnt);
	}
}
