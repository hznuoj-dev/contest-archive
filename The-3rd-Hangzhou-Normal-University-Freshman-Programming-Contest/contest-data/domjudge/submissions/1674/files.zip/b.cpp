#include<stdio.h>
int main()
{
	int t,i,num;
	scanf("%d",&t);
	while(t--)
	{ 
		num=0;
		int k,y,a,temp;
		scanf("%d %d",&y,&a);
		k=y+a;
		if(k>9999)
			k=9999-k+9999;
		if(y>k)
		{
			temp=y;
			y=k;
			k=temp;
		}
		for(i=y;i<=k;++i)
		{
			if(i%4==0&&i%100!=0||i%400==0)
				num=num+1;
		}
		printf("%d",num\n);
	}
}