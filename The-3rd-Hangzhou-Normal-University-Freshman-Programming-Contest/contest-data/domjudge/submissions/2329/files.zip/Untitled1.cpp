#include<stdio.h>
int main(void){
	int T,y1,a,y2,x,i,s=0,t;
	scanf("%d",&T);
	for(T>0;T--; ){
		scanf("%d %d",&y1,&a);
		y2=y1+a;
		while(y2>9999){
			i=y2-9999;
			y2=9999-i;
			if(y2<0);
			y2=y2*(-1);
		}
		if(y2<y1){
			t=y1;
			y1=y2;
			y2=y1;
		}
		for(y1;y1<=y2;y1++){
			if((y1%4==0&&y1%100!=0)||(y1%400==0))
			s=s+1;
		}
		printf("%d\n",s);
		s=0;
	}
	return 0;
}
