﻿#include <stdio.h>
int main() {
    int t, m, n;
    double p;
    scanf("%d", &t);
    while (t--) {
        scanf("%d %d", &n, &m);
        p = (double)m / (double)n;
        printf("[");
        n -= m;
        while (m--) {
            printf("#");
        }
        while (n--) {
            printf("-");
        }
        printf("] %.0lf%%\n", p * 100);
    }
    return 0;
}