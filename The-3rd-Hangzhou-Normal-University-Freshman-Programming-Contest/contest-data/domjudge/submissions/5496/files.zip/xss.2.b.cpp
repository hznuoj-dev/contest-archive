#include <stdio.h>

int main() {
    // insert code here...
    int t,y,a,b,x,i,j;
    scanf("%d",&t);
    while (t--){
        scanf("%d %d",&y,&a);
        i=y;
        j=a;
        x=0;
        if (y+a<=9999&&a>0){
            b=y+a;
            while (i<=b){
                if ((i%4==0&&i%100!=0)||i%400==0){
                    x=x+1;
                }
                i=i+1;
            }
            printf("%d\n",x);
        }
    
        if (y+a<=9999&&a<0){
            b=y+a;
            while (b<=i){
                if ((b%4==0&&b%100!=0)||b%400==0){
                    x=x+1;
                }
                b=b+1;
            }
            printf("%d\n",x);
        }
        if (y+a>9999){
            b=9999-(y+a-9999);
            if(b<=y){
                while (b<=y){
                    if ((b%4==0&&b%100!=0)||b%400==0){
                        x=x+1;
                    }
                    b=b+1;
                }
                printf("%d\n",x);
            }
            if(b>=y){
                while (y<=b){
                    if ((y%4==0&&y%100!=0)||y%400==0){
                        x=x+1;
                    }
                    y=y+1;
                }
                printf("%d\n",x);
            }
        }
        
    }
}

