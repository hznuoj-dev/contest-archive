#include<stdio.h>
int main(void){
	char nm[10000][10000];
	int num[10000];
	int h[10000];
	int a;
	int i,j,k,l,boom,m;
	scanf("%d",&a);
	for(i=0;i<a;i++){
		scanf("%d",&h[i]);
		num[i]=0;
		for(j=0;j<h[i];j++){
			m=0;
			while(1){
			scanf("%c",&nm[j][m]);
			m++;
			}
			for(j=0;j<h[i];j++){
			k=0;
			for(k=0;k<m;k++){
				boom=0;
				if(nm[j][k]!='.'){
					boom=1;
					for(l=0;l<k;l++){
						if (nm[j][l]==nm[j][k]){
							boom=0;
						}
					}		
				}
				if(boom==1){
					num[i]++;
				}
			}
		}
		}
		
	}
	for(i=0;i<a;i++){
		printf("%d\n",num[i]);
	}
return 0; 
} 

