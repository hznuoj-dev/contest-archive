#include<stdio.h>
int main(void){
	int i,ans=0,num=0,j,n,m;
	scanf("%d%d",&n,&m);
	int a[n],b[n];
	for(i=0;i<n;++i){
		scanf("%d",&a[i]);
	}
		for(j=0;j<n;++j){
			scanf("%d",&b[j]);
		}
	for(j=0;j<n;++j){	
	ans+=a[j]*b[j];
	}
for(i=1;i<=m;++i){
	if(ans>=i)
	num+=1;
}
printf("%d",num);
} 
