#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
const int maxn=1010;
int n,m,t,is,cnt,ans,p[maxn];
struct xx {
	int i,x;
} xx[maxn];
bool cmp(struct xx a,struct xx b) {
	return a.i<b.i;
}
int main() {
	ios::sync_with_stdio(false);
	cout<<fixed<<setprecision(0);
	cin>>t;
	while(t--) {
		cin>>n>>m;
		for(int i=1; i<=n; i++)xx[i].i=i,xx[i].x=i;
		for(int i=1; i<=n; i++) {
			int a,b;
			cin>>a>>b;
			if(xx[a].i<xx[b].i)continue;
			swap(xx[a].i,xx[b].i);
		}
		sort(xx+1,xx+1+n,cmp);
		for(int i=1; i<=n; i++)cout<<xx[i].x<<(i==n?"\n":" ");
	}
	return 0;
	//good job!
}
