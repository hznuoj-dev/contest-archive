import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int t=sc.nextInt();
			while(t-->0)
			{
				int y=sc.nextInt();
				int a=sc.nextInt();
				int end=y+a;
				int count=0;
				if(end>9999)
				{
					end=y+(end-9999);
				}
				if(end<y)
				{
					int x=end;
					end=y;
					y=x;
				}
				for(int i=y;i<=end;i++)
				{
					if((i%4==0&&i%100!=0)||i%400==0)
					{
						count++;
					}
				}
				System.out.println(count);
			}
		}
	}

}
