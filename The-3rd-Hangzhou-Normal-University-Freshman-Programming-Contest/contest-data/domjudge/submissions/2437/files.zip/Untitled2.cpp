#include<bits/stdc++.h>
using namespace std;
//Oh dear!!
//BaoBao is good!!
//Bao Bao is a SupEr man///!
//Oh my God!!!!!!!!!!!!!!!!!!!!!
//Bao Bao is so Zhai...... 
//ÿ��λ����>=16||==6 
int main()
{
    char a[100],b[100],c[100],d[100];
    int lena,lenb,lenc,lend;
    int suma=0,sumb=0,sumc=0,sumd=0;
    int i,flag=0;
    cin>>a>>b>>c>>d;
    lena=strlen(a);
    lenb=strlen(b);
    lenc=strlen(c);
    lend=strlen(d);
    for(i=0;i<=lena-1;i++){
    	suma+=(a[i]-'0');
	}
	for(i=0;i<=lenb-1;i++){
    	sumb+=(b[i]-'0');
	}
	for(i=0;i<=lenc-1;i++){
    	sumc+=(c[i]-'0');
	}
	for(i=0;i<=lend-1;i++){
    	sumd+=(d[i]-'0');
	}
	if(suma>=16||suma==6){
		flag++;
	}
	if(sumb>=16||sumb==6){
		flag++;
	}
	if(sumc>=16||sumc==6){
		flag++;
	}
	if(sumd>=16||sumd==6){
		flag++;
	}
	 if(flag==0){
	 	cout<<"Bao Bao is so Zhai...... "<<endl;
	 }else if(flag==1){
	 	cout<<"Oh dear!!"<<endl;
	 }else if(flag==2){
	 	cout<<"BaoBao is good!!"<<endl;
	 }else if(flag==3){
	 	cout<<"Bao Bao is a SupEr man///!"<<endl;
	 }else if(flag==4){
	 	cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;
	 }
    return 0;
}
