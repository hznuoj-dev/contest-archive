#include<stdio.h>
int main(){
	int n,a[100000],x;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&x);
		a[x]++;
	}
	if(n<=3){
		printf("1");
	}
	else 
	    printf("2"); 
} 
