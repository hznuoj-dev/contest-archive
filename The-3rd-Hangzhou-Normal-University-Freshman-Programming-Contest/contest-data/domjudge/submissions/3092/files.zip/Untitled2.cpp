#include <stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996) 
int main(){
	int t,n,s;
	char a[1000000];
	scanf("%d",&t);
	while(t--){
		s=0;
		int m=0,k,j;
		char b[1000000];
		scanf("%d",&n);
		while(n--){
			k=0;
			scanf("%s",a);
			for(int i=0;i<strlen(a);i++){
				if(a[i]!='.'){
					for(j=0;j<k;j++){
						if(b[j]==a[i])
						break;
					}
					if(j==k){
						b[k]=a[i];
						k++;
					}
				}
			}
			s+=k;
		}
		printf("%d\n",s);
	}
}
/*struct tijiao{
	int a;
	int b;
	int c;
	char d;
	char e;
}q[100001];
int paiming
void printft(int a,int b,int c){
	if(a==0){
		
	}
}
int main(){
	int n,t,m,p,w,i,j;
	char a[6][20]={"teamstatus","minrank","maxrank","account","submitcount","teamcount"};
	char b[20];
	scanf("%d %d %d %d",&n,&t,&m,&p);
	for(int i=0;i<m;i++){
		scanf("%d %d %d %c%c",&q.a,&q.b,&q.a,&q.c,&q.d,&q.e)
	}
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			if(q[j].c>q[j+1].c)
			q[100001]=q[j],q[j]=q[j+1],q[j+1]=q[100001];
		}
	}
	scanf("%d",&w);
	while(w--){
		scanf("%s%d %d",b,&i,&j);
		for(o=0;o<=5;o++){
			if(strcmp(a[o],b)==0)
			break;
		}
		printft(o,i,j);
		memset(b,0,sizeof(b));
	}
} */

