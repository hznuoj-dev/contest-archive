#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,n,i,j,len,sum;
	char s[1000000];
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d",&n);
		for(i=1;i<=n;i++){
			getchar(); 
			gets(s);
			len=strlen(s);
			for(j=0;j<len;j++){
				if(s[j]!='.'){
					sum=sum+1;
				}
			}
		}
		printf("%d\n",sum);
} 
	return 0;
}
