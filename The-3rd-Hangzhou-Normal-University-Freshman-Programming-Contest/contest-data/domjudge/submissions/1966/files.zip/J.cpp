#include<bits/stdc++.h>
using namespace std;

int main(void){

    int t;
    cin >> t;
    while(t--){
        int n;
        cin >> n;
        getchar();
        int times = 0;
        while(n--){
            set<char> st;
            char s;
            s = getchar();
            while(s != '\n') {if(s != '.') st.insert(s);s = getchar();}
            times += st.size();
        }
    cout << times << endl;
    }

    return 0;
}