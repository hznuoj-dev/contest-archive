#include <stdio.h>
#include <string.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int i,n,sum=0;
		char s[1000005];
		scanf("%d",&n);
		getchar();
		while(n--)
		{
			char a[100000]={0};
			gets(s);
			for(i=0;i<strlen(s);i++)
			{
				if(s[i]!='.')
				a[s[i]]++;
			}
			for(i=0;i<100000;i++)
			{
				if(a[i]!=0)
				sum++;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
