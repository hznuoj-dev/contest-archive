#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void){
	int t,n,i,a,b,x,y;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&a,&b);
		i=a-b,x=a,y=b;
		printf("[");
		while(b--)
		printf("#");
		while(i--)
		printf("-");
		printf("]");
		printf(" %d%%\n",(y*100)/x);
	}
	return 0;
} 
