#include <stdio.h>
int main()
{
	int t,n,m;
	scanf("%d",&t);
	while(t--)
	{
	scanf("%d%d",&n,&m);
	double f;
	int i;
	f=m*1.0/n*100;
	printf("[");
	for(i=0;i<m;i++)
	printf("#");
	for(i=0;i<n-m;i++)
	printf("-");
	printf("]");
	printf(" %.0lf%%\n",f);
	
}
	return 0;
}
