#include<stdio.h>
int he(int x){
	int o=0;
	while(x){
		o+=x%10;
		x/=10;
	}
	return o;
}
int main(){
	int sum=0,a,q=4;
	while(q--){
		scanf("%d",&a);
		if(he(a)>=16||he(a)==6) sum++;
	}
	if(sum==0) printf("Bao Bao is so Zhai......");
	else if(sum==1) printf("Oh dear!!");
	else if(sum==2) printf("BaoBao is good!!");
	else if(sum==3) printf("Bao Bao is a SupEr man///!");
	else if(sum==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    return 0;
}
