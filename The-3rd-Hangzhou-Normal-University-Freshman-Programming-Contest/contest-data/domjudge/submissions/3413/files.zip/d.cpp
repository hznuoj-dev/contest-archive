#include<iostream>
using namespace std;
int main()
{
    int count=0,t;
    cin>>t;
    getchar();
    for(int i=1;i<=t;i++)
    {
        while(getchar()!='\n')
        count++;
    }
    cout<<count<<endl;
    return 0;
}