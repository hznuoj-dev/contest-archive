#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996)
int main()
{
	float a,b,d;
	int i,c;
	scanf("%d",&c);
	while(c--)
	{
		scanf("%f%f",&a,&b);
		printf("[");
		for(i=1;i<=b;i++)
		{
			printf("#");
		}
		for(i=1;i<=a-b;i++)
		{
			printf("-");
		}
		d=b/a*100.0;
		printf("] %.0f%%\n",d);
	}
	return 0;
}
