#include<stdio.h>
int main(){
	long long a[4];
	int t,i,sum;
	t=0;
	for(i=1;i<=4;i++){
		sum=0;
		scanf("%lld",&a[i]);
		while(a[i]>0){
			sum=sum+a[i]%10;
			a[i]=a[i]/10;
		}
		if(sum>=16||sum==6){
			t=t+1;
		}
	}
	if(t==0){
		printf("Bao Bao is so Zhai......");
	}
	else if(t==1){
		printf("Oh dear!!");
	}
	else if(t==2){
		printf("BaoBao is good!!");
	}
	else if(t==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else if(t==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
}
