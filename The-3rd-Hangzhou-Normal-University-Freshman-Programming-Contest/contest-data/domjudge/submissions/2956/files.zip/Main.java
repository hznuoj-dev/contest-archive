import java.util.Scanner;
public class Main
{
    public static void main(String[] args)
    {
        Scanner in=new Scanner(System.in);
        while (in.hasNext())
        {
            int t=in.nextInt();
            for(int i=0;i<t;i++)
            {
                int y1=in.nextInt();
                int y2=in.nextInt();
                int y3=y1+y2;
                int h=0;
                if (y3>=10000)y3=9999-(y3-9999);
                if(y3<y1)
                {
                    int p=y1;y1=y3;y3=p;
                }
                System.out.println(y1+","+y3);
                for(int j=y1;j<=y3;j++)
                {
                    if(j%4==0 && j%100!=0 || j%400==0)
                    {
                        h+=1;
                    }
                }
                System.out.println(h);
            }
        }
    }
}
