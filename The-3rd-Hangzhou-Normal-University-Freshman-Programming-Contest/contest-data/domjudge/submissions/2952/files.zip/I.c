#include<stdio.h>
#include<string.h>
int main()
{
   int x=0,i;
   char a[100],b[100],c[100],d[100];
    scanf("%s %s %s %s",&a,&b,&c,&d);

int sum1=0,temp1=0;
   for(i=0;a[i]!='\0';i++)
   {
   temp1 = a[i]-48;
   sum1=sum1+temp1;
   }
   if(sum1==6||sum1>=16) x+=1;

int sum2=0,temp2=0;
   for(i=0;b[i]!='\0';i++)
   {
   temp2 = b[i]-48;
   sum2=sum2+temp2;
   }
    if(sum2==6||sum2>=16) x+=1;

int sum3=0,temp3=0;
   for(i=0;c[i]!='\0';i++)
   {
   temp3 = c[i]-48;
   sum3=sum3+temp3;
   }
    if(sum3==6||sum3>=16) x+=1;

int sum4=0,temp4=0;
   for(i=0;d[i]!='\0';i++)
   {
   temp4 = d[i]-48;
   sum4=sum4+temp4;
   }
    if(sum4==6||sum4>=16) x+=1;

if (x==0) printf("Bao Bao is so Zhai......");
if (x==1) printf("Oh dear!!");
if (x==2) printf("BaoBao is good!!");
if (x==3) printf("Bao Bao is a SupEr man///!");
if (x==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");

}


