#include <stdio.h>
int main(void)
{
	int T;
	long int y1,y2,num;
	scanf("%d\n",&T);
	while(T--)
	{
		scanf("%ld %ld\n",&y1,&num);
		y2=y1+num;
		if(y2>9999)
		{
			y2=9999-(y2-9999);
		}
		int temp;
		if(y1>y2)
		{
			temp=y1;
			y1=y2;
			y2=temp;
		}
		int year[y2-y1+1]={y1};
		int i,count=0;
		for(i=0;i<y2-y1+1;i++)
		{
			year[i+1]=year[i]+1;
			if(year[i]%4==0&&year[i]%100!=0||year[i]%400==0)
			{
				count++;
			}
		 } 
		 printf("%d\n",count);
		}
		
		return 0;
 } 
