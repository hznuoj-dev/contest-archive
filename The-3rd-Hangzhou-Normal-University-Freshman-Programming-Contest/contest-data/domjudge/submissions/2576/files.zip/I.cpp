#include<stdio.h>
int main(){
	int a,b,c,d;
	int m,x,y,z=0;
	int count1,count2,count3,count4;
	int sum=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	m+=a%10;
	a/=10;
	x+=b%10;
	b/=10;
	y+=c%10;
	c/=10;
	z+=d%10;
	d/=10;
	if(m==6||m>=16){
		count1=1;
	}else
	count1=0;
	if(x==6||x>=16){
		count2=1;
	}else
	count2=0;
	if(y==6||y>=16){
		count3=1;
	}else
	count3=0;
	if(z==6||z>=16){
		count4=1;
	}else
	count4=0;
sum=count1+count2+count3+count4;
if(sum==0){
	printf("Bao Bao is so Zhai......");
}
if(sum==1){
	printf("Oh dear!!");
}
if(sum==2){
	printf("BaoBao is good!!");
}
if(sum==3){
	printf("Bao Bao is a SupEr man///!");
}
if(sum==4){
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}
return 0;
} 
