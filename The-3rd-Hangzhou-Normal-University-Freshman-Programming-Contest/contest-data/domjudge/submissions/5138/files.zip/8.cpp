#include<stdlib.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdio.h>
int main()
{
 int n;
 int a, b;
 scanf("%d", &n);
 for (int k = 1; k <= n; k++) {
  scanf("%d %d", &a, &b);
  printf("[");
  for (int g = 1; g <= b; g++) {
   printf("#");
  }
  for (int f = 1; f <= a - b; f++) {
   printf("-");
  }
  printf("]");
  printf(" %d%c\n",b*100/a,'%');
 }
 return 0;
 }
