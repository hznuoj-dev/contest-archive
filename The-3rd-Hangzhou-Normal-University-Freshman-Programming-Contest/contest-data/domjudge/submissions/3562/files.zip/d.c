#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996);
int main(){
	int n,len,i;
	char q[100010];
	scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++){
		scanf("%s",&q);
	}
	len=strlen(q);
	printf("%d",n*len);
    return 0;
}