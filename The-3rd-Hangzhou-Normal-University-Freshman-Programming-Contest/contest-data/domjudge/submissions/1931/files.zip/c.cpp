#include<iostream>
#include<cmath>

using namespace std;
int level[100000];
int main()
{
    int n;
    cin >> n;
    int i,j=0,it1,it,sum;
    cin >> it;
    level[0]=1;
    sum=1;
    for(i=1;i<n;i++)
    {
        cin >> it1;
        if(it1 == it)
        {
            level[j]++;
        }
        else
        {
            j++;
            level[j]++;
        }
        it=it1;   
    }
    for(i=1;i<=j;i++)
    {
        sum=sum*pow(level[i]+1,level[i-1]-1);
    }
    cout << sum;
    
    return 0;
}