#include<bits/stdc++.h>
using namespace std;
int main(){
	int t;
	cin>>t;
	while(t--){
		int a,b;
		cin>>a>>b;
		int l=a;
		int r=a+b;
		if(l>r){
			int temp=l;
			l=r;
			r=temp;
		}
		if(r>=10000)r=9998;
		int cnt=0;
		for(int i=l;i<=r;i++){
			if(i%400==0){
				cnt++;
			}
			else if(i%4==0&&i%100!=0){
				cnt++;
			}
		}
		cout<<cnt<<endl;
	}
} 
