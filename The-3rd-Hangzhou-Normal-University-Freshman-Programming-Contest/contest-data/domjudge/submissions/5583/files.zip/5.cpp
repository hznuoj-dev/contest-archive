#include"stdio.h"
int main()
{
	int t,a,b,i,j,s=0;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&a,&b);
		printf("[");
	
			for(j=0;j<b;j++)
			{
				printf("#");
		    }
		  for(i=b;i<a;i++)
		  {
		  	printf("-");
		  }
		  printf("] ");
		  s=b*100.0/a*1.0;
		  printf("%d",s);
		  printf("%%\n");
		  
	}
	return 0;
 } 
