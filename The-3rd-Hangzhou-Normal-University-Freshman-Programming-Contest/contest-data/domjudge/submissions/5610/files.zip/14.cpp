#include<stdio.h>
#include<string.h>
int main()
{
	int a,b,c,d,i,sum=0;	char A[20],B[20],C[20],D[20];	int suma=0,sumb=0,sumc=0,sumd=0;	scanf("%d %d %d %d",&a,&b,&c,&d);	sprintf(A,"%d",a);	sprintf(B,"%d",b);	sprintf(C,"%d",c);	sprintf(D,"%d",d);	for(i=0;i<strlen(A);++i)	{		suma=suma+int(A[i]-'0');	}	for(i=0;i<strlen(B);++i)	{		sumb=sumb+int(B[i]-'0');	}	for(i=0;i<strlen(C);++i)	{		sumc=sumc+int(C[i]-'0');	}	for(i=0;i<strlen(D);++i)	{		sumd=sumd+int(D[i]-'0');	}	if(suma==6||suma>=16)		sum+=1;	if(sumb==6||sumb>=16)		sum+=1;	if(sumc==6||sumc>=16)		sum+=1;	if(sumd==6||sumd>=16)		sum+=1;	if(sum==0)		printf("Bao Bao is so Zhai......\n");	if(sum==1)		printf("Oh dear!!\n");	if(sum==2)		printf("BaoBao is good!!\n");	if(sum==3)		printf("Bao Bao is a SupEr man///!\n");	if(sum==4)		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");}
