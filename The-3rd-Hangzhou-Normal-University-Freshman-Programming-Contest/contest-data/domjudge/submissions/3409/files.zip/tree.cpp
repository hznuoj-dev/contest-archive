#include<stdio.h>
int he(int x);
int main(){
    int a,b,c,d,n=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(he(a))
	n++;
	if(he(b))
	n++;
	if(he(c))
	n++;
	if(he(d))
	n++;
	if(n==1)
	printf("Oh dear!!");
	else if(n==3)
	printf("Bao Bao is a SupEr man///!");
	else if(n==2)
	printf("BaoBao is good!!");
	else if(n==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(n==0)
	printf("Bao Bao is so Zhai......");
}
int he(int x)
{
	int sum=0;
	int s,mid,flag=0;
	do
	{
		s=x/10;
		mid=x%10;
		sum+=mid;
		x=s;//把s重新赋值给n
	}
	while(s!=0);
	if(sum>=16||sum==6)
	flag=1;
	return flag;
 } 
