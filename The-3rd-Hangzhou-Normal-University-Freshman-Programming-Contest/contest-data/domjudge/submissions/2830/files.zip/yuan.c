#include<stdio.h>
#pragma warning(disable:4996)
int main(){
	char a,b,c;
	scanf("%c%c%c",&a,&b,&c);
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/\n");
	system("pause");
}