import java.util.Scanner;                	 
public class Main 
{               	 
public static void main(String[] args) 
    {
        Scanner cin = new Scanner(System.in);
        while(cin.hasNext())
       {
           int a=cin.nextInt();
           for(int i=0;i<a;i++) 
           {
            	 int sum=0;
            	 int n=cin.nextInt();
            	 int m=cin.nextInt();
            	 m=n+m;
            	 if(m>9999)
            	 {
            		 m=9999-(m-9999);
            	 }
            	 if(n>m)
            	 {
            		 n=n+m;
            		 m=n-m;
            		 n=n-m;
            	 }
            	 for(i=n;i<=m;i++)
            	 {
            		 if((i%4==0 && i%100!=0) || i%400==0 )
            		 {
            			 sum=sum+1;
            		 }
            	 }
            	 System.out.println(sum);
          }             	             
       }
   }     
}
