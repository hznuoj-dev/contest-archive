#include <stdio.h>
//#pragma warning(disable:4996)
//#include <process.h>
int main(){
	int T,i,j,k;
	double m,n;
	scanf("%d",&T);
	for(i=1;i<=T;i++)
	{
	scanf("%lf %lf",&n,&m);
	printf("[");
	for(j=1;j<=m;j++)
		printf("#");
	for(k=0;k<n-m;k++)
		printf("-");
	printf("] %d%%\n",(int)((m/n)*100.00));
	}
//	system ("pause");
return 0;
}