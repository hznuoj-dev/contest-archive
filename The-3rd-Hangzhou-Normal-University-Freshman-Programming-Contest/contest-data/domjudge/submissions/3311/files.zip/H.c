#include<stdio.h>
int main(){
	int n,m,i,j,t;
	float sum;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d %d",&n,&m);
		printf("[");
		for(j=0;j<m;j++){
			printf("#");
		}
		for(j=0;j<n-m;j++){
			printf("-");
		}
		sum=100*m/n;
		printf("] %.0f%%\n",sum);
	}
	return 0;
} 
