#include<stdio.h>

int main()
{
	int m,n,t,i,y,z;
	scanf("%d",&t);
	for (i=1;i<=t;i++){
		int n,m,j;
		scanf("%d %d",&n,&m);
		int result[n],flag[n];
		for (y=0;y<n;y++){
			result[y]=0;
			flag[y]=0;
		}
		for (j=1;j<=m;j++){
			int a,b;
			scanf("%d %d",&a,&b);
			result[a-1]+=n;
			flag[a-1]=b-1; 
		}
		for (y=0;y<n;y++){
		    int mid=y;
		    for (z=0;z<n;z++){
		    	if (result[z]>result[mid]){
		    		mid=z;
				}
			}
			if (result[mid]==result[flag[mid]]){
				 if (mid<flag[mid]){
					result[mid]=0;
					printf("%d",mid+1);
				}else {
					result[flag[mid]]=0;
					printf("%d",flag[mid]+1);
			    }
			}else {  
			    result[mid]=0;
				printf("%d",mid+1); 
			} 
			if (y<n-1){
				printf(" ");
			}	
			}
			
		}
}
