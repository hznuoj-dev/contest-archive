#include<stdio.h>
#pragma warning(disable:4996)
int v(f);
int main() {
	long long a, b, c, d, bnt = 0;
	scanf("%d%d%d%d", &a, &b, &c, &d);
	if (v(a) >= 16 || v(a) == 6)bnt++;
	if (v(b) >= 16 || v(b) == 6)bnt++;
	if (v(c) >= 16 || v(c) == 6)bnt++;
	if (v(d) >= 16 || v(d) == 6)bnt++;
	switch (bnt) {
	case 0:printf("Bao Bao is so Zhai......"); break;
	case 1:printf("Oh dear!!"); break;
	case 2:printf("BaoBao is good!!"); break;
	case 3:printf("Bao Bao is a SupEr man///!"); break;
	case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!"); break;
	}
	return 0;
}


int v(f){
	int sum = 0,t;
	t = f;
	while (t!=0) {
		sum = sum + t % 10;
		t = t / 10;
	}
	return sum;
}