#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
char zf[100010];
int main()
{
	int n;
	scanf("%d",&n);
	scanf("%s",zf);
	int temp=strlen(zf);
	printf("%d\n",temp*n);
	return 0;
}
