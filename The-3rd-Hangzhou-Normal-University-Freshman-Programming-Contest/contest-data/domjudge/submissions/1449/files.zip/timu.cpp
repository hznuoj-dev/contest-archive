#include<bits/stdc++.h>
using namespace std;
int main()
{
 char t[100];
 scanf("%s",&t); 
 printf(" __      _____\n");
 printf("|  | ___/ ____\\____\n");
 printf("|  |/ /\\   __\\/ ___\\\n");
 printf("|    <  |  | \\  \\___\n");
 printf("|__|_ \\ |__|  \\___  >\n");
 printf("     \\/           \\/");
	return 0;
}
