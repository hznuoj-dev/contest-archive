#include<stdio.h>
f (int x){
	int s=0,n;
	while(x){
		n=x%10;
		s+=n;
		x/=10;
	}
	return s;
}
int main() {
	int a,b,c,d;
	int k=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(f(a)>=16||f(a)==6)
	k+=1;
	if(f(b)>=16||f(b)==6)
	k+=1;
	if(f(c)>=16||f(c)==6)
	k+=1;
	if(f(d)>=16||f(d)==6)
	k+=1;
	if(k==0)
	printf("Bao Bao is so Zhai......\n");
	else if(k==1)
	printf("Oh dear!!\n");
	else if(k==2)
	printf("BaoBao is good!!\n");
	else if(k==3)
	printf("Bao Bao is a SupEr man///!\n");
	else
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
