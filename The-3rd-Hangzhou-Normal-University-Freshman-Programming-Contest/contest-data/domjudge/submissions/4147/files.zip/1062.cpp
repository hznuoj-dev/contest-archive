#include<stdio.h>
int main(){
	char n[3];
	scanf("%s",n);
	if(n[0]=='k'&&n[1]=='f'&&n[2]=='c'){
    printf(" __      _____\n|  | ___/ ____\\____\n");
    printf("|  |/ /\\   __\\/ ___\\");
    printf("\n");
    printf("|    <  |  | \\  \\___\n");
    printf("|__|_ \\ |__|  \\___  >\n");
    printf("     \\/           \\/\n");
}
return 0;
}


