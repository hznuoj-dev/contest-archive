#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(void){
	char a[1][4];
	scanf("%s",a);
	printf(" __      _____\n\n"); 
	printf("|  | ___/ ____\\____\n\n");
	printf("|  |/ /\\   __\\/ ___\\\n\n");
	printf("|    <  |  | \\  \\___\n\n");
	printf("|__|_ \\ |__|  \\___  >\n\n");
	printf("     \\/           \\/\n");
	return 0;
}
