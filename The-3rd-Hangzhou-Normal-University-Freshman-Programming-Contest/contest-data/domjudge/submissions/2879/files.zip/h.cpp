#include<iostream>
using namespace std;
int main()
{
    int t;
    cin>>t;
    for(int i=1;i<=t;i++)
    {
        int m,n,res;
        cin>>n>>m;
        res=m*100/n;
        cout<<"[";
        for(int j=1;j<=n;j++)
        {
            if(j<=m) cout<<"#";
            else cout<<"-";
        }
        cout<<"] "<<res<<"%"<<endl;
    }
    return 0;
}