#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int cmp(const void* c1, const void* c2) {
	return *(char*)c1 - *(char*)c2;
}
	int main() {
		int i,t,n,sum;
		char str[1000001];
		scanf("%d",&t);
		while (t--) {
			sum = 0;
			scanf("%d",&n);
			while (n--) {
				int sum1 = 0;
				scanf("%s",str);
				qsort(str,strlen(str),sizeof(str[0]),cmp);
				if (str[0] != '.')
					sum1 = 1;
				for (i = 1;i < strlen(str);i++) {
					if (str[i] != '.' && str[i] != str[i - 1])
						sum1++;
				}
				sum += sum1;
			}
			printf("%d\n",sum);
		}
	}
