#include<bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("sample-J.1.in","r",stdin);
	int t; cin>>t;
	while(t--)
	{
		int n; cin>>n;
		getchar();
		int sum=0;
		while(n--)
		{
			char s[1000005]; gets(s);
			int asc[130]; memset(asc,0,sizeof(asc));
			for(int i=0; i<strlen(s); i++) if(s[i]!='.') asc[s[i]]++;
			int cnt=0;
			for(int i=0; i<=127; i++) if(asc[i]>0) cnt++;
			sum+=cnt;
		}
		printf("%d\n",sum);
	}
	return 0;
}


