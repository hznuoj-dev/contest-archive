#include<stdio.h>
#include<string.h>
int main(){
    int T,a,b;
    float s;
    scanf("%d",&T);
    while(T--){
    	scanf("%d%d",&a,&b);
    	s=b*100.0/a;
    	a=a-b;
    	printf("[");
    	while(b--) printf("#");
    	while(a--) printf("-");
    	printf("]%.0f%%\n",s);
	}
    return 0;
}
