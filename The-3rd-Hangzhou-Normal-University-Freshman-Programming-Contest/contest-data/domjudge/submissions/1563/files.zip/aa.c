#include<stdio.h>
#include<string.h>
#include<math.h>
int r(int y){
	if(y%400==0 || y%100!=0 && y%4==0){
		return 1;
	}else{
		return 0;
	}
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int y,a,s=0,y2;
		scanf("%d %d",&y,&a);
		y2=a+y;
		if(y2>9999) y2=y2-(y2-9999);

		if(y2>=y){
			for(int i=y;i<y2+1;i++){
				s+=r(i);
			}
		}else{
			for(int i=y2;i<y+1;i++){
				s+=r(i);
			}
		}
		if(t)printf("%d\n",s);
		else printf("%d",s);
	}
	
}
