#include<stdio.h>
int fun(int n)
{
	int sum = 0;
	 int s, mid, temp;
	 {
	 	s=n/10;
	 	mid=n%10;
	 	sum+=mid;
	 	n=s;
	 }
	while(s!=0);
	if(sum>=16||sum==6)
	return 1;
	else
	return 0;
}


int main()
{
	int a, b, c, d, A, B, C, D ,temp=0;
	scanf("%d%d%d%d", &a, &b, &c, &d);
	A = fun(a);
	B = fun(b);
	C = fun(c);	
	D = fun(d);
	temp =A+B+C+D;
	
	switch(temp)
	{
		case 0:printf("Bao Bao is so Zhai......");break;
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
	
	return 0;
}
