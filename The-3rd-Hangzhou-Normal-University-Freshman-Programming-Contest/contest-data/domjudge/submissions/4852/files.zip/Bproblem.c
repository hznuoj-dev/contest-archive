#include<stdio.h>
#pragma warning(disable:4996)
int main() {
	int a, b, c=0, d=0, e=0,g;
	scanf("%d", &g);
	while (g--) {
		scanf("%d %d", &a, &b);
		c = a + b;
		if (c > 9999) {
			d = c - 1;
		}
		if (a < 0) {
			c = a + b; d = b;

		else if (b < 0)
			c = a + b; d = a;
		}
		while (c <= d) {
			if ((c % 4 == 0 && c % 100 != 0) || (c % 400 == 0)) {
				e++;
				c++;
			}
		}
	      printf("%d", e);
		return 0;
	}