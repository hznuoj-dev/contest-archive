#include<stdio.h>
int main(void){
	int t;
	int n,m,p;
	char c='%';
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		p=m*100/n;
		printf("[");
		while(m--){
			printf("#");
		}
		n-=m;
		while(n--){
			printf("-");
		}
		printf("] ");
		printf("%d",p);
		printf("%c",c);
		printf("\n");
	}
}
