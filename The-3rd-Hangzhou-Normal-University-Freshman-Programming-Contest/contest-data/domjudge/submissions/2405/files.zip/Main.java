package xyz.leow;
import java.util.Scanner;

public class Main {
    public static void main(String[] arg)
    {
        Scanner in=new Scanner(System.in);
        while(in.hasNext())
        {
            int n=in.nextInt();
            int[] a=new int[n];
            for(int i=0;i<n;i++)
            {
            	int fs=in.nextInt();
            	int ls=in.nextInt();
            	int ts=fs+ls;
            	if(ts>9999)
            		ts=ts-10000+fs;
            	if(fs>ls)
            	{
            		int tmp=fs;
            		fs=ts;
            		ts=tmp;
            	}
            	for(int j=fs;j<=ts;j++)
            	{
            		if(j%4==0)
            		{
            			if(j%100!=0)
            				a[i]++;
            			else if(j%400==0)
            				a[i]++;
            		}
            	}
            }
            for(int i=0;i<n;i++)
            {
            	System.out.println(a[i]);
            }
        }
    }
}