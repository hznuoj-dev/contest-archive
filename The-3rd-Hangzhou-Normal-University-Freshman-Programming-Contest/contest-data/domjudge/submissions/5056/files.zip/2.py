n=int(input())
while n:
    s=0
    n=n-1
    m=int(input())
    for i in range(m):
        a=list((str(input())))
        a = sorted(set(a), key=a.index)
        if '.' in a:
            s=s+len(a)-1
        else:
            s=s+len(a)
    print(s)