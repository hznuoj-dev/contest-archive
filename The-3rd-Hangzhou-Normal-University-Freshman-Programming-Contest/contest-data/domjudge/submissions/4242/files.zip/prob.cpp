#include <stdio.h>
int main()
{
	int n,a,b,i,sum=0,min,max;
	scanf("%d",&n);
	while(n--)
	{
		sum=0;
		scanf("%d%d",&a,&b);
		if(a>9999)
		a=9999-(a-9999);
		if(a+b>=9999)
		b=9999-(a+b-9999);
		else
		b=a+b;
		a>b?(min=b,max=a):(min=a,max=b);
		for(i=min;i<=max;i++)
		{
			if(i%400==0||(i%4==0&&i%100!=0))
			sum++;
		}
		printf("%d\n",sum);
	}
	return 0;
}
