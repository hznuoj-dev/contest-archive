#include<stdio.h>
int main() {
	long long int a, b, c, d, temp;
	int flag1 = 0, flag2 = 0, flag3 = 0, flag4 = 0, flag = 0;
	int T = 18;
	scanf("%lld%lld%lld%lld", &a, &b, &c, &d);
		temp = a;
		while (temp != 0) {
			flag1 = flag1 + temp % 10;
			temp = temp / 10;
		}
		if (flag1 >= 16 || flag1 == 6)
			flag1 = 1;
		else
			flag1 = 0;
		temp = b;
		while (temp != 0) {
			flag2 = flag2 + temp % 10;
			temp = temp / 10;
		}
		if (flag2 >= 16 || flag2 == 6)
			flag2 = 1;
		else
			flag2 = 0;
		temp = c;
		while (temp != 0) {
			flag3 = flag3 + temp % 10;
			temp = temp / 10;
		}
		if (flag3 >= 16 || flag3 == 6)
			flag3 = 1;
		else
			flag3 = 0;
		temp = d;
		while (temp != 0) {
			flag4 = flag4 + temp % 10;
			temp = temp / 10;
		}
		if (flag4 >= 16 || flag4 == 6)
			flag4 = 1;
		else
			flag4 = 0;
	flag = flag1 + flag2 + flag3 + flag4;
	if (flag == 1)
		printf("Oh dear!!");
	else if (flag == 2)
		printf("BaoBao is good!!");
	else if (flag == 3) {
		printf("Bao Bao is a SupEr man///");
		printf("!");
	}
	else if (flag == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else
		printf("Bao Bao is so Zhai......");
	return 0;
}