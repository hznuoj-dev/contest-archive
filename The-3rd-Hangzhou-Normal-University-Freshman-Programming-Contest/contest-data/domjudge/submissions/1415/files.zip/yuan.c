#include<stdio.h>
#include<string.h>
int main(){
char s[100];
scanf("%s",s);
if(strcmp(s,"kfc")==0)
{
printf("__ _____\n");
printf("| | ___/ ____%c____\n",92);
printf("| |/ /%c __%c/ ___%c\n",92,92,92);
printf("| < | | %c %c___\n",92,92);
printf("|__|_ %c |__| %c___ %c\n",92,92,62);
printf("     %c/           %c/\n",92,92);
}

return 0;
}
