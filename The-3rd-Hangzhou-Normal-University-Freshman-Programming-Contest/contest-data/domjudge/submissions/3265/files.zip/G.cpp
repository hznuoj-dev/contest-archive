#include<bits/stdc++.h>
using namespace std;

int t;
int n, m;
bool b[10001];
int a[10001][10001];
int pin[10001];

int main ()
{
	scanf ("%d", &t);
	while (t--)
	{
		memset (b, 0, sizeof (b));
		memset (a, 0, sizeof (a));
		memset (pin, 0, sizeof (pin));
		scanf ("%d%d", &n, &m);
		while (m--)
		{
			int tmp1, tmp2;
			scanf ("%d%d", &tmp1, &tmp2);
			a[tmp2][++pin[tmp2]] = tmp1;
		}
		
		int N = n;
		bool pri = 0;
		while (N--)
		{
			for (int i = 1; i <= n; i++)
			{
				if (b[i]) continue;
				bool flag = 1;
				for (int j = 1; j <= pin[i] && flag; j++)
				{
					if (!b[a[i][j]]) flag = 0;
				}
				if (flag)
				{
					if (pri) printf (" ");
					printf ("%d", i);
					pri = 1;
					b[i] = 1;
					break;
				}
			}
		}
		
	}
	
	
	return 0;
	
}
