#include<bits/stdc++.h>
using namespace std;
int main(){
	int T;
	cin>>T;
	int m,n;
	double x;
	while(T--){
		cin>>m>>n;
		cout<<'[';
		for(int i=0;i<m;i++){
			if(i<n)cout<<'#';
			else cout<<'-';
		}
		cout<<']';
		x=(n*1.0)/(m*1.0)*1000;
		printf(" %d%%\n",(int)x/10);	

	}
	
	return 0;
} 
