#include<stdio.h>
int sum1(long long a){ 
int sum=0;
	while(a>0){ 
		sum+=a%10; 
		a=a/10; 
	} 
	return sum; 
}
int main(){
	long long int a[5],sum=0;  
	for(int i=1;i<=4;i++){
		scanf("%lld",&a[i]); 
		if(sum1(a[i])>=16||sum1(a[i])==6) sum++; 
	}
	switch(sum){
		case 1:printf("Oh dear!!");break; 
		case 2:printf("BaoBao is good!!");break; 
		case 3:printf("Bao Bao is a SupEr man///!");break; 
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!"); break; 
		default: printf("Bao Bao is so Zhai......") ;
	}
	return 0;
} 
