#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a, b, c, d, e, f, g, x, y;
	scanf("%d", &a);
	for(b=1;b<=a;b++){
        scanf("%d %d", &c, &d);
        f=c+d;
        if(f>9999)
        f=(9999*2)-f;
        if(c>f){
        	g=c;
        	c=f;
        	f=g;
		}
		for(x=c,e=0;x<=f;x++){
			if(x%100==0){
				if(x%400==0)
				   e=e+1;
			}
			else
			   if(x%4==0)
			      e=e+1;	  	
		}
		printf("%d\n", e);
    }
	return 0;
}
