#include<stdio.h>
#include<string.h>
char s[100000];
char kind[500];
int main()
{
	int lens,lenk;
	int T,n,flag,count;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		count=0;
		for(int i=0;i<n;i++){
			scanf("%s",s);
			//printf("%s",s);
		lens=strlen(s);
		for(int i=0;i<lens;i++){
			if(s[i]!='.'){
			flag==0;
			lenk=strlen(kind);
			for(int j=0;j<lenk;j++){
				if(s[i]==kind[j])
				    flag=1;
			}
			if(!flag)
			    kind[lenk]=s[i];
            }
		}
		count+=strlen(kind);
		//printf("%d\n",count);
		memset(kind,0,sizeof kind);
		memset(s,0,sizeof s);
		//printf("%d\n",strlen(s));
	}
		printf("%d\n",count);
	}
	return 0;
}
