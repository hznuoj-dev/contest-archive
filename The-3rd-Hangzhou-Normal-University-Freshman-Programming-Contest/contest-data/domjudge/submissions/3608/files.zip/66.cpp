#include <stdio.h>
int main(void){
	int t;
	long long i,d;
	double a,b,c;
	scanf("%d",&t);
	while(t--){
		scanf("%lf %lf",&a,&b);
		printf("[");
		for(i=1;i<=b;i++){
			printf("#");
		}
		for(i=1;i<=a-b;i++){
			printf("-");
		}
		c=b/a*100;
		d=c;
	    printf("]");
		printf(" %lld",d);
		printf("%%\n");
	}
	return 0; 
}
