#include <stdio.h>
int main()
{
	int t=1;
	while(t--)
	{
		t++;
	 } 
	return 0;
 } 
