#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int t;
    scanf("%d",&t);
    while(t--){
    	int n, i, count=0;
    	scanf("%d",&n);
    	for(i=1;i<=n;++i){
    		char a[1000000];
    		scanf("%s",a);
    		for(i=0;i<1000000;i++){
    			if(a[i]=='.'||a[i]==' ')
    		    count+=0;
    		    else
    		    count+=1;
			}
		}
		printf("%d\n",count);
	}
	return 0;
}
