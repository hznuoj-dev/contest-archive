#include<stdio.h>
#include<string.h>
long long dddd(int x,int y){
	long long o=1;
    if(x==1) return 1;
    else {
    	while(y--) o*=x;
	}
	return o;
}
int main(){
	int n,a[10010],c;
	long long sum=1;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&c);
	    a[c]++;
	}
	for(int i=1;i<c;i++){
		sum*=dddd(a[i],a[i+1]);
	}
	if(sum>=998244353) printf("998244353");
	else printf("%d",sum);
    return 0;
}
