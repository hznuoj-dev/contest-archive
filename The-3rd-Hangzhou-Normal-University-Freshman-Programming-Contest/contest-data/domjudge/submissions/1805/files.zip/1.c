#include <stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
#define PI 3.14159
#include<math.h>
#pragma warning(disable:4996)

char s[4] = { "kfc" }, str[4];
int  main() {
	gets(str);
	if (strcmp(str, s) == 0) {
		printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/\n");

	}
	return 0;
}
