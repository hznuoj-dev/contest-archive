#include <stdio.h>
int main()
{
    int sum=0;
	long long a[10]; 
	scanf("%lld%lld%lld%lld",&a[1],&a[2],&a[3],&a[4]);
	for(int i=1;i<=4;++i)
	{
		int sum1=0;
		while(a[i])
		{
			sum1+=a[i]%2;
			a[i]=a[i]/2;
		}
		if(sum1>=16||sum1==6)
		    sum+=1; 
	}
	switch(sum)
	{
		case 0:printf("Bao Bao is so Zhai......\n");break;
		case 1:printf("Oh dear!!\n");break;
		case 2:printf("BaoBao is good!!\n");break;
		case 3:printf("Bao Bao is a SupEr man///!\n");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");break;
	}
	return 0;
 } 
