#include<bits/stdc++.h>
using namespace std;
int main()
{
    int m,n,t,i,j;
    double s;
	cin>>t;
	for(i=1;i<=t;i++)
	{
	   cin>>m>>n;
	   cout<<"[";
	   for(j=1;j<=n;j++)
	   cout<<"#";
	   for(j=1;j<=m-n;j++)
	   cout<<"-";
	   cout<<"]";
	   s=n*100/m;
	   printf(" %.0lf%\n",s);
	} 
	return 0;
}
