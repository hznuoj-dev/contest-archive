#include<stdio.h>
int main(void){
	int t,y,a;
	int m,n,i,j=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&y,&a);
		m=y+a;
		if(m>9999)
			m=9999-(m-9999);
		if(m<y){
			n=y;
			y=m;
			m=n;
		}
		for(i=y;i<=m;++i){
			if((i%4==0&&i%100!=0)||(i%400==0))
				j+=1;
		}
		printf("%d\n",j);
		j=0;
	}
	return 0;
}
