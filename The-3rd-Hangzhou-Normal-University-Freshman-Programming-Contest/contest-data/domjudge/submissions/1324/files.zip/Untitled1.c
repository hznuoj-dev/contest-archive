#include<stdio.h>
#include<string.h>
int main(){
	char a[4][10000];
	scanf("%s %s %s %s",a[0],a[1],a[2],a[3]);
	int A,B,C,D,s=0,t=0;
	A=strlen(a[0]);
	B=strlen(a[1]);
	C=strlen(a[2]);
	D=strlen(a[3]);
	for(int i=0;i<A;i++){
		t=t+a[0][i]-'0';
	}
	if(t>=16||t==6)
	s++;
	t=0;
	for(int i=0;i<B;i++){
		t=t+a[1][i]-'0';
	}
	if(t>=16||t==6)
	s++;
	t=0;
	for(int i=0;i<C;i++){
		t=t+a[2][i]-'0';
	}
	if(t>=16||t==6)
	s++;
	t=0;
	for(int i=0;i<D;i++){
		t=t+a[3][i]-'0';
	}
	if(t>=16||t==6)
	s++;
	t=0;
	switch(s){
		case 0:printf(" Bao Bao is so Zhai......");break;
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
}
