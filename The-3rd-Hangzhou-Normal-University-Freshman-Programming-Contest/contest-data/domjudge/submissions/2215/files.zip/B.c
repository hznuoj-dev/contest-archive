#include<stdio.h>
#include<string.h>
int main()
{
int T,Y,A,y,a,b,i,x=0;
scanf("%d",&T);
while(T--)
{
    scanf("%d %d",&Y,&A);
    a=Y+A-9999;
  if(a>=0)
  {
    y=9999-a;
   }
   else if (a<0)
    y=Y+A;


   if(Y>=y)
     {for (i=y;i<Y;i++)
        {
          if((i%4==0&&i%100!=0)||i%400==0)
            x+=1;
        }
     }
     else if(Y<y)
     {
         for (i=Y;i<y;i++)
         {
             if((i%4==0&&i%100!=0)||i%400==0)
            x+=1;
         }
     }
     printf("%d\n",x);
     x=0;
}


}
