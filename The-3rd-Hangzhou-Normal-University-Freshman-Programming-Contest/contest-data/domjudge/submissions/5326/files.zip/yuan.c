#include<stdio.h>
#include<string.h>


#pragma warning(disable:4996��
int main(){
	int t;
	int m,n,tt;
	scanf("%d",&t);
	while(t--)
	{int i,y,e,k,r;
	char str[50001]={'\0'};
	char s[1002],d[1002],z,a;
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++)
		{
			str[i]=i+48;
		}
		getchar();
		for(i=1;i<=m;i++)
		{
			scanf("%c %c",&s[i],&d[i]);
			getchar();
		}
		for(i=1;i<=m;i++)
		{
			for(k=i;k<=m-1;k++)
			{
				if(s[i]>s[k+1])
				{
					z=s[i];
					s[i]=s[k+1];
					s[k+1]=z;
					z=d[i];
					d[i]=d[k+1];
					d[k+1]=z;
				}
			}
		}
		for(i=1;i<=m;i++)
		{
			
			
			for(tt=i+1;tt<=m;tt++)
			{
				if(d[tt]==d[i]&&s[i]>s[tt])
				{
					z=s[i];
					s[i]=s[tt];
					s[tt]=z;
				}
			}
            for(k=1;k<=n;k++)
			{
				if(str[k]==s[i])
					y=k;
				if(str[k]==d[i])
					e=k;
			}
			if(y>e)
			{
				a=s[i];
				for(r=y;r>e;r--)
				{
					str[r]=str[r-1];
				}
				str[e]=a;
			}
		}
	
		for(i=1;i<=n;i++)
		{
			if(i!=n)
				printf("%c ",str[i]);
			else 
					printf("%c\n",str[i]);
			                               
		}
}
	
return 0;
}
