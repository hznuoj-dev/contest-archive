#include<stdio.h>
int main()
{
    int t, y, a, i, s = 0;
    scanf("%d", &t);
    while (t--) {
        scanf("%d %d", &y, &a);
        if (a > 0) {
            if (y + a > 9999) {
                for (i = y;i <= 19998 - y - a;i++) {
                    if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0))s++;
                    else s += 0;
                }
            }
            else {
                for (i = y;i <= y + a;++i) {
                    if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0))s++;
                    else s += 0;
                }
            }
        }
        else if (a < 0) {
            s = 0;
            for (i = y + a;i <= y;++i) {
                if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0))s++;
                else s += 0;
            }
        }
        printf("%d\n", s);
    }
    return 0;
}
