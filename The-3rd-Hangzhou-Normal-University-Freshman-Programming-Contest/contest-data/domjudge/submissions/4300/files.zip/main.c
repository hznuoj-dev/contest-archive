#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int T;
	scanf("%d",&T);
	int x,y,sum=0;
	while(T--){
		scanf("%d%d",&x,&y);
		
		if(x+y<=9999&&y<0){
			if(x%400==0||(x%4==0&&x%100!=0))
		sum+=1; 
			if((x+y)%400==0||((x+y)%4==0&&(x+y)%100!=0))
		sum+=1; 
			printf("%d\n",(-y/4)+sum);
		}
	
		if(x+y<=9999&&y>0){
				if(x%400==0||(x%4==0&&x%100!=0))
		sum+=1; 
			if((x+y)%400==0||((x+y)%4==0&&(x+y)%100!=0))
		sum+=1; 
				printf("%d\n",sum+((y-x)/4));
		}
	
		if(x+y>9999){
				if(x%400==0||(x%4==0&&x%100!=0))
		sum+=1; 
			if((19998-x-y)%400==0||((19998-x-y)%4==0&&(19998-x-y)%100!=0))
		sum+=1; 
		}
		printf("%d\n",(x+y-9999)/4+sum);
	} 
	return 0;
}
