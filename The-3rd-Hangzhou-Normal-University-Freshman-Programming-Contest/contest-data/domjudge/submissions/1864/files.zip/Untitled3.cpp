#include <stdio.h>
int main(void){
	int T;
	scanf("%d",&T);
	while(T--){
		int Y,A;
		scanf("%d %d",&Y, &A);
		
	}
	return 0;
}
