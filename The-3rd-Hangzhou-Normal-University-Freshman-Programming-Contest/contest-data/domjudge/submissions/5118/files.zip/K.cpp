#include<iostream>
#include<vector>
#include<algorithm>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug cout<<"What fuck!!"<<endl
using namespace std;
const int maxn=1e5+10;
vector<int>vec[maxn];
int main(){
	fcio;
	int n;
	while(cin>>n){
//		cout<<"n=";
//		cout<<n<<endl;
		for(int i=1;i<=n;++i){
			int m;
			cin>>m;
			for(int j=0;j<m;++j){
				int x;
				cin>>x;
				vec[i].push_back(x);
			}
		}
//		for(int i=1;i<=n;++i){
//			for(int j=0;j<vec[i].size();++j){
//				cout<<vec[i][j]<<" ";
//			}
//			cout<<endl;
//		}
		int q;
		cin>>q;
		while(q--){
			int l;
			cin>>l;
			vector<int>G;
			while(l--){
				int id;
				cin>>id;
				for(int i=0;i<vec[id].size();++i){
					G.push_back(vec[id][i]);
				}
			}
			int k;
			cin>>k;
//			debug;
			sort(G.begin(),G.end());
//			for(int i=0;i<G.size();++i){
//				cout<<G[i]<<" ";
//			}
//			cout<<endl;
//			debug;
			cout<<G[k-1]<<endl;
		}
	}
}

