#include"stdio.h"
int main(void){
	long long s,ss,h,i,a[5];
	ss=0;
	for(i=1;i<=4;i++){
		scanf("%lld",&a[i]);
		s=0;
		while(a[i]>0){
			h=a[i]%10;
			s=s+h;
			a[i]=a[i]/10;
			if(s>=16){
				ss++;
				break;
			}
		}
		if(s==6){
			ss++;
		}
	}
	if(ss==0){
		printf("Bao Bao is so Zhai......");
	}
	else if(ss==1){
		printf("Oh dear!!");
	}
	else if(ss==2){
		printf("BaoBao is good!!");
	}
	else if(ss==3){
		printf("Bao Bao is a SupEr man///!");
	} 
	else if(ss==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
}
