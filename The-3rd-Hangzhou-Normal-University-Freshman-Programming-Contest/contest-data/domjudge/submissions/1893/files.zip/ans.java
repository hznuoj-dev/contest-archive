
import java.util.Arrays;
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{
			int in = sc.nextInt();
			for (int i = 0; i < in; i++)
			{
				int nian = sc.nextInt();
				int jian = sc.nextInt();
				int sign = 0;
				int jie = nian + jian;
				if(jie>=10000) {
					jie=9999-(jie-9999);
				}
				if (jie >= nian)
				{
					for (int j = nian; j <= jie; j++)
					{
						if (Main.run(j))
						{
							sign++;
						}
					}
				}

				else
				{
					for (int p = jie; p <= nian; p++)
					{
						if (Main.run(p))
						{
							sign++;
						}

					}
				}
				System.out.println(sign);
			}

		}

	}

	public static boolean run(int nian)
	{
		if (nian % 4 == 0 && nian % 100 != 0 || nian % 100 == 0 && nian % 400 == 0)
		{
			return true;
		}
		return false;
	}

}