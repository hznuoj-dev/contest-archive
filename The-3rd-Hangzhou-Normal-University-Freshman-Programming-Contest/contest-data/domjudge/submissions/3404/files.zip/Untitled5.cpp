#include<stdio.h>
 int main(){
 	int t,f,n=0,i,b;
 	char c;
 	scanf("%d",&t);
 	while(t--){
 		n=0;
 		scanf("%d",&f);
 		getchar();
 		while(f--){
 			i=0;
 			char a[1000];
 			while(scanf("%c",&c),c!=10&&c!=32){
 			  b=1; 
 				if(c!='.') {
				 for(int j=0;j<i;j++){
 			     	if(c==a[j]){
 			     		b=0;
 			     		break;
					  }
				    }
				    if(b==1){
				    	 a[i]=c;
				    i+=1;
					}
				   
				  }
			 }n+=i;	
		 }
		 printf("%d\n",n);
	 }
  
 } 
 
