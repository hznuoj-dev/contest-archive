#include<stdio.h>
int t,a,y,b,c,x=0;
int main(){
	scanf("%d",&t);
	while(t--){
	scanf("%d %d",&y,&a);
	b=a+y;
	if(b>9999){
		b=9999-a-y+9999;
	}
	if(y>b){
		c=y;
		y=b;
		b=c;
	}
	for(int i=y;i<=b;i++){
		if(((i%4==0)&&(i%100)!=0)||(i%400==0)){
			x=x+1;
		}
	}
	printf("%d\n",x);
	x=0;	
	}
	
	return 0;
} 
