#include <stdio.h> 
#include <string.h> 
int main(void){
	int t,n,m,i;
	char z='%';
	double f;
	scanf("%d",&t);
	while(t--){
	    scanf("%d %d",&n,&m);
	    f=100*m/n;
	    printf("[");
	    for(i=1;i<=n;i++){
		if(i<=m)
		   printf("#");
		else 
		   printf("-");
	    }
	    printf("] %.0f%c \n",f,z);
	}
	return 0;
}
 
