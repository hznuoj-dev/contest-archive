package xyz.leow;
import java.util.Scanner;

public class Main {
    public static void main(String[] arg)
    {
        Scanner in=new Scanner(System.in);
        while(in.hasNext())
        {
        	int n=in.nextInt();
        	String[] a=new String[n];
        	for(int i=0;i<n;i++)
        	{
        		a[i]="";
        		int tt=in.nextInt();
        		int wt=in.nextInt();
        		int sc=wt*100/tt;
        		tt-=wt;
        		while(wt-->0)
        		{
        			a[i]=a[i].concat("#");
        		}
        		while(tt-->0)
        		{
        			a[i]=a[i].concat("-");
        		}
        		a[i]="["+a[i]+"] "+String.valueOf(sc)+"%";
        	}
        	for(int i=0;i<n;i++)
        	{
        		System.out.println(a[i]);
        	}
        }
    }
}