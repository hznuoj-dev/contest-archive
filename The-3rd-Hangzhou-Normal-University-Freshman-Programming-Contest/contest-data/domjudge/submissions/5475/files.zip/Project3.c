﻿#include <stdio.h>
int p[1000000], w[1000000] = { 0 };
int main() {
    int n, m, i, a[100], b[100], j, t, u, k, count = 0;
    scanf("%d %d", &n, &m);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++) {
        scanf("%d", &b[i]);
    }
    u = 0;
    t = 1;
    p[0] = 0;
    for (i = 0; i < n; i++) {
        for (k = 0; k <= u; k++) {
            for (j = 0; j <= b[i]; j++) {
                if (j * a[i] + p[k] > m)
                    break;
                if (w[j * a[i] + p[k]] != 1) {
                    p[t] = j * a[i] + p[k];
                    w[p[t]] = 1;
                    t++;
                }
            }
        }
        u = t - 1;
    }
    for (i = 1; i <= m; i++) {
        if (w[i] == 1)
            count++;
    }
    printf("%d", count);
    return 0;
}