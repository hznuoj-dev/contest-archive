#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+100;
const int INF=0x3f3f3f3f;

int main(){
	int T; scanf("%d",&T);
	while(T--){
		int y1,y2,x;
		scanf("%d %d",&y1,&x);
		if(y1+x>9999){
			y2=9999-(y1+x-9999);
		}
		else y2=y1+x;
		if(y1>y2) swap(y1,y2);
		int ans=0;
		for(int i=y1;i<=y2;++i){
			if(i%400==0||i%4==0&&i%100) ans++;
		}
		printf("%d\n",ans);
	}
	return 0;
}
