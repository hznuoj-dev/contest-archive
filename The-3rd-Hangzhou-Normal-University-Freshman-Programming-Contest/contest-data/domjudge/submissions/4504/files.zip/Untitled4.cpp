#include<stdio.h>
int main(){
	int T, n, S=0, num=0;
	char s[1000000], ch;
	scanf("%d", &T);
	for(int i=0;i<T;++i){
		scanf("%d", &n);
		S=0;
		for(int j=0;j<=n;++j){
			int sum=0;
			while((ch=getchar())!='\n'){
				if(ch!='.'){
					int flag=1;
					for(int x=num;x<=sum+num;x++){
						if(ch==s[x]){
							flag=0;
						}
					}
					if(flag==1){
						s[sum+num]=ch;
						sum++;
					}
				}
			}
			S+=sum;
			num+=sum;
		}
		printf("%d\n", S);
	}
	return 0;
}
