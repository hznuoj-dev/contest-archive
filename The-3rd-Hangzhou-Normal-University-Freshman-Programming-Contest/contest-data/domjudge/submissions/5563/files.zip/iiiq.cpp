#include<stdio.h>
int main()
{
	long long int A,B,C,D;
	int imp=0,a=0,b=0,c=0,d=0;
	scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
	while(A!=0)
	{
		a+=A%10;
		A=A/10;
	}
	while(B!=0)
	{
		b+=B%10;
		B=B/10;
	}
	while(C!=0)
	{
		c+=C%10;
		C=C/10;
	}
	while(D!=0)
	{
		d+=D%10;
		D=D/10;
	}
	if(a>=16||a==6)imp+=1;
	if(b>=16||b==6)imp+=1;
	if(c>=16||c==6)imp+=1;
	if(d>=16||d==6)imp+=1;
	if(imp==0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	if(imp==1)
	{
		printf("Oh dear!!\n");
	}
	if(imp==2)
	{
		printf("BaoBao is good!!\n");
	}
	if(imp==3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	if(imp==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0; 
}

