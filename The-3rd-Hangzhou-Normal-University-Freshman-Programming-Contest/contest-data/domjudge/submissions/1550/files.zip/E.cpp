#include<bits/stdc++.h>
using namespace std;
int main(){
	string s;
	cin>>s;
	if(s=="kfc")
	cout<<
	" __      _____\n"<<
	"|  | ___/ ____\\____\n"<<
	"|  |/ /\\   __\\/ ___\\\n"<<
	"|    <  |  | \\  \\___\n"<<
	"|__|_ \\ |__|  \\___  >\n"<<
	"     \\/           \\/\n";
	
	return 0;
}
