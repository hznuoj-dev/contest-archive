#include<iostream>
int a[128];
using namespace std;
int main(){
	long long T,n,a,b,x,y,ans=0;
	cin >> T;
	while (T--){
		ans=0;
		cin >> a >> b;
		x=a;y=a+b;
		if (y>=10000) y=19998-y;
		if (x>y) {
			a=x;x=y;y=a;
		}
		for (int i=x;i<=y;++i){
			if (i%400==0||(i%4==0&&i%100!=0)) ans++;
		}
		cout << ans<<endl;
	}
    return 0;
}
