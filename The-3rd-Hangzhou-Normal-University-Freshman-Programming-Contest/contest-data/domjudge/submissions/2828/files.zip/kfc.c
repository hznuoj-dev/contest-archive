#include<stdio.h>
#pragma warning(disable:4996)
int main() {
    char a;
    scanf("%d", &a);
    printf(
        " __      _____\n"
        "|  | ___/ ____\\____\n"
        "|  |/ /\\   __\\/ ___\\\n"
        "|    <  |  | \\  \\___\n"
        "|__|_ \\ |__|  \\___  >\n"
        "     \\/           \\/\n");
    return 0;
}