#include<stdio.h>
int main()
{
	int A,B,C,D,a,b,c,d,i1=0,i2=0,i3=0,i4=0,p1,p2,p3,p4,m;
	scanf("%d %d %d %d",&A,&B,&C,&D);
	do{
	    a=A%10;
		A/=10;
		i1+=a;
	}while(A!=0);
	if(i1>=16||i1==6)
		p1=1;
	 else
		p1=0;
	do{
	    b=B%10;
		B/=10;
		i2+=b;
	}while(B!=0);
	if(i2>=16||i2==6)
		p2=1;
	 else
		p2=0;
	do{
	    c=C%10;
		C/=10;
		i3+=c;
	}while(C!=0);
	if(i3>=16||i3==6)
		p3=1;
	 else
		p3=0;
	do{
	    d=D%10;
		D/=10;
		i4+=d;
	}while(D!=0);
	if(i4>=16||i4==6)
		p4=1;
	 else
		p4=0;
		m=p1+p2+p3+p4;
		if(m==1)
		printf("Oh dear!!\n");
		else if(m==2)
		printf("BaoBao is good!!\n");
		else if(m==3)
		printf("Bao Bao is a SupEr man///!\n");
		else if(m==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
		else if(m==0)
		printf("Bao Bao is so Zhai......\n");
		return 0;
}
