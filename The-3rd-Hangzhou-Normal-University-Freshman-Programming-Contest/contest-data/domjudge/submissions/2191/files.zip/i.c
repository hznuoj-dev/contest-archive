#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b,c,d,n=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	if(a>=16||a==6)
	n+=1;
	if(b>=16||b==6)
	n+=1;
	if(c>=16||c==6)
	n+=1;
	if(d>=16||d==6)
	n+=1;
	if(n==1)
	printf("Oh dear!!");
	else if (n==2)
	printf("BaoBao is good!!");
	else if (n==3)
	printf("Bao Bao is a SupEr man///!");
	else if (n==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if (n==0)
	printf("Bao Bao is so Zhai......");
	return 0;
}


