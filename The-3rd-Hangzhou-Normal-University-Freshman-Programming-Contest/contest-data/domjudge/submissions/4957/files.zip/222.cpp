#include<stdio.h>
#include<string.h>
int main(){
	int T,n,b;
	scanf("%d",&T);
	while(T--){
		int s=0;
		char a[1000010];
		scanf("%d",&n);
		while(n--){
			int k=0;
			char c[1280]={'.'};
			scanf("%s",&a);
			int len=strlen(a);
			for(int i=0;i<len;i++){
				if(a[i]!='.'){
					b=0;
					for(int j=1;j<=k;j++){
						if(a[i]==c[j]){
						b=1;
						break;}
					}
					if(b==0){
						k++;
						c[k]=a[i];
					}
				}
				
			}
			s+=k;
		}
		printf("%d\n",s);
	}
}
