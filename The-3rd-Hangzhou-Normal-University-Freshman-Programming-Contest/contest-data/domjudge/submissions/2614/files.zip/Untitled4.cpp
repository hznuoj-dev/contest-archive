#include<stdio.h>
 int main(){
 	int t,a,b;
 	scanf("%d",&t);
 	while(t--){
 	scanf("%d %d",&a,&b);
 	printf("[");
	 for(int i=0;i<b;i++){
	 	printf("#");
	 }
	 for(int i=0;i<a-b;i++){
	 	printf("-");
	 }
	 printf("] %d%c\n",(int)(1.0*b/a*100),'%');
	 
	 }
 	
 	
 	
 }
