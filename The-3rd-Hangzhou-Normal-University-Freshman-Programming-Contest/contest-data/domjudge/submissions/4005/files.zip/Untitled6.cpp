#include<stdio.h>
int main(){
	int t,a,n,huan,start,end;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&n);
		int c[a+1];
		int b[a+1];
		for(int i=1;i<a+1;i++){
		  c[i]=i;
		  b[c[i]]=i;
		}
		 
	    while(n--){
	    	scanf("%d %d",&start,&end);
	    	if(b[start]>b[end]){
	    		huan=b[start];b[start]=b[end];b[end]=huan;
			}
		}
		for(int i=1;i<a+1;i++){ 
		  if(i!=a) 
			printf("%d ",b[i]);
			else
			 	printf("%d\n",b[i]);
		}
	}
} 
