#include<stdio.h>
#include<string.h>
int main()
{	char i[2];
	scanf("%s",&i);
	printf("__ _____\n");
	printf("| | ___/ ____\\____\n");
	printf("| |/ /\\ __\\/ ___\\\n");
	printf("| < | | \\ \\___\n");
	printf("|__|_ \\ |__| \\___ >\n");
	printf("\\/ \\/ \n");
	
}	







