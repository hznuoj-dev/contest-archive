#include<stdio.h>
int main()
{
	int T, i;
	double c, m, n;
	scanf("%d", &T);
	while(T--)
	{
		scanf("%lf %lf", &n, &m);
		c = (m/n)*100;
    	for(i = 1;i <= m;i++)
 		   	printf("#");
		for(i = m + 1;i <= n;i++)
		    printf("-");
		    if(i = n+1)
        		printf("]");
			printf(" %.0f%%\n", c);
	}
	return 0;
}