#include <stdio.h>
int main()
{
	long long  max = 998244353; 
    int n,x;
    scanf("%d",&n);
    int a[100010]={0};
    for(int i=1;i<=n;++i)
	{
		scanf("%d",&x);
		a[x]+=1;
	 } 
	long long sum=0,last;
	int i=0;
	while(a[i]==0)
	{
		++i;
	}
	sum=a[i];
	last=i;
	for(++i;i<=100000;++i)
	{
		if(a[i]!=0)
		{
			for(int j=1;j<=a[i];++j)
			{
				sum*=a[last];
				if(sum>=max)
				{
					sum=sum%max;
				}
				
			}
			last = i;
		}
	}
	sum=sum%max;
	printf("%lld\n",sum);
	return 0;
 } 
