#include<stdio.h>
int main()
{
	int r;
	int a,b,c;
	scanf("%d",&r);
	for(int i=0;i<r;i++){
		scanf("%d%d",&a,&b);
		c=b*100/a;
		printf("[");
		for(int i=0;i<b;i++){
			printf("#");
		}
		for(int i=0;i<a-b;i++){
			printf("-");
		}
		printf("] %d%%\n",c);
	}
	return 0;
}
