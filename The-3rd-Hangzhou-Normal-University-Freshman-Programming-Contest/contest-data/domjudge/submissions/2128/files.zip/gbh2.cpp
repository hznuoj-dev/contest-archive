#include<stdio.h>
int main() {
	int a,i,sum=0;
	for (i = 0;i < 4;i++) {
		scanf("%d", &a);
		if (a == 6 || a >= 16)
			sum++;
	}
	if (sum == 0)
		printf("Bao Bao is so Zhai......");
	else if (sum == 1)
		printf("Oh dear!!");
	else if (sum == 2)
		printf("BaoBao is good!!");
	else if (sum == 3)
		printf("Bao Bao is a SupEr man///!");
	else
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}