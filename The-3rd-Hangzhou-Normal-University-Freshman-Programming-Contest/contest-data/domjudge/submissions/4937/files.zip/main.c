#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
     int t;
     scanf("%d",&t);
	 while (t--){
	 	int a,b,i;
	 	scanf("%d %d",&a,&b);
	 	printf("[");
	 	for (i=0;i<b;++i){
	 		printf("#");
		 }
		 for (i=b;i<a;++i){
		 	printf("-");
		 }
		 printf("] %d%%",b*100/a);
		 printf("\n");
	 } 
	return 0;
}
