#include<stdio.h>
int main()
{
	int t,n,m,i,j;
	float a;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
		{
			printf("#");
		}
		for(i=m+1;i<=n;i++)
		{
			printf("-");
		}
		printf("] ");
		a=((m+0.00)/n)*100;
		printf("%.0f%%\n",a);
	}
}
