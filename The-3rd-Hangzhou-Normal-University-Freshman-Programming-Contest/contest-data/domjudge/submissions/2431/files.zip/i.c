#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main()
{
	char a[18];
	int i, m, sum;
	int total;
	total = 0;
	for (i = 0; i < 4; i++)
	{
		scanf("%s", &a);
		sum = 0;
		for (m = 0; m < strlen(a); m++)
		{
			sum = sum + a[m] - 48;
		}
		if (sum == 6 || sum >= 16)
		{
			total = total + 1;
		}
	}
	if (total == 0) printf("Bao Bao is so Zhai......");
	if (total == 1) printf("Oh dear!!");
	if (total == 2) printf("BaoBao is good!!");
	if (total == 3) printf("Bao Bao is a SupEr man///!");
	if (total == 4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}