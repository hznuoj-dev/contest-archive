#include<stdio.h>
int main(void)
{
	int a[4],i,been=0,sum;
	for(i=0;i<=3;i++)
	{
		sum=0;
		scanf("%d",&a[i]);
		while(a[i]>0)
		{
			sum+=a[i]%10;
			a[i]/=10;
		}
		if(sum>=16||sum==6)
		been+=1;
	}
	switch(been)
	{
	case 0:
	{
	printf("Bao Bao is so Zhai......\n");
	break;}
	case 1:
	{
	printf("Oh dear!!\n");
	break;}
	case 2:
		{
		printf("BaoBao is good!!\n");
		break;}
	case 3:
		{
		printf("Bao Bao is a SupEr man///!\n");
		break;}
	case 4:
		{printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
		break;}
	}
}
