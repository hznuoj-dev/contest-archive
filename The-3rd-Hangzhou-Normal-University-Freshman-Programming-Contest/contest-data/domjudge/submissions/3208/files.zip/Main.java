package xyz.leow;
import java.util.Scanner;

public class Main {
    public static void main(String[] arg)
    {
        Scanner in=new Scanner(System.in);
        String[] rs= {
        		"Bao Bao is so Zhai......",
        		"Oh dear!!",
        		"BaoBao is good!!",
        		"Bao Bao is a SupEr man///!",
        		"Oh my God!!!!!!!!!!!!!!!!!!!!!"
        };
        while(in.hasNext())
        {
        	int[] f=new int[4];
            for(int i=0;i<4;i++)
            {
            	String t=in.next();
            	int sum=0;
            	for(int j=0;j<t.length();j++)
            	{
            		sum+=Integer.parseInt(t.substring(j,j+1));
            	}
            	if(sum>15||sum==6)
            		f[i]=1;
            }
            System.out.println(rs[f[0]+f[1]+f[2]+f[3]]);
        }
    }
}