#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while( t-- ){
		int n, m, percent;
		scanf("%d%d", &n, &m);
		printf("[");
		for(int i = 0; i < m; i++){
			printf("#");
		}
		for(int i = 0;i < (n-m); i++){
			printf("-");
		}
		printf("]");
		percent = 100*m/n;
		printf("%d%%\n",percent);
	}
}
