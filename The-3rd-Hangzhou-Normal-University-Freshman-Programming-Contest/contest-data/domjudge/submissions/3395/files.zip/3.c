#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(){
	int t,n,m,i;
	double z;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&m,&n);
		printf("[");
		for(i=0;i<n;i++){
			printf("#");
		}
		for(i=0;i<m-n;i++){
			printf("-");
		}
		printf("] ");
		z=(n*1.0/m*1.0)*100;
		printf("%.0lf",z);
		char a[1]={"%"};
	printf("%c",a[0]);
		printf("\n");
		
	}
}

