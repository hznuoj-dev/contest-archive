#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int f(int n);
int main(int argc, char *argv[]) {
	int t,s,m,n,d,i;
	scanf("%d",&t);
	while(t--){
		s=0;
		scanf("%d%d",&m,&d);
		if(m+d>=9999){
			n=(m+d)%9999;
			if(9999-n>m){
			for(i=m;i<=9999-n;i++){
				s+=f(i);
			}
			printf("%d\n",s);
		}
		else{
			for(i=9999-n;i<=m;i++){
				s+=f(i);
		}
		printf("%d\n",s);
			} 
		}
			else{
				if(d>=0){
				
				for(i=m;i<=m+d;i++){
				s+=f(i);
			}
		}
		else{
			for(i=m+d;i<=m;i++){
				s+=f(i);
		}
			printf("%d\n",s);
				
				
			}
		}
	}
	return 0;
}
int f(int n){
	if(n%4==0&&n%100!=0||n%400==0)
	return 1;
	else
	return 0;
}
