#include <stdio.h>
#include <stdlib.h>

int sumDigits(long long n)
{
        int sum = 0,i=0;
        for ( i = 1;i<=10;i++ ){
            sum = sum + (n % 10);
            n = n / 10;
            if (n == 0)break;
			if (sum>=16)return 1;		
		}
		if(sum==6)return 1;else return 0;
}

int main()
{	long long A,B,C,D;
int cunt=0;
	scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
if(sumDigits(A))cunt=cunt+1;
if(sumDigits(B))cunt=cunt+1;
if(sumDigits(C))cunt=cunt+1;
if(sumDigits(D))cunt=cunt+1;
	switch(cunt)
	{
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
		case 0:printf("Bao Bao is so Zhai......");break;
	}
	return 0;
}

