#include<bits/stdc++.h>
using namespace std;
int main(){
	int t;
	scanf("%d",&t);
	string s;
	getline(cin,s);
	while(t--){
		int n;
		scanf("%d",&n);
		int cnt=0;
		getline(cin,s);
		while(n--){
			int a[129]={0};
			getline(cin,s);
			int m=s.size();
			for(int i=0;i<m;i++){
				if(s[i]!='.'&&a[s[i]]==0){
					cnt++;
					a[s[i]]=1;;
				}
			}
		}
		printf("%d\n",cnt);
	}
}
