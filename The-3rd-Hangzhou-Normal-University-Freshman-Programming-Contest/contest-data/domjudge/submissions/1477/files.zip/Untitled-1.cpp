#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>


using namespace std;

int main(){
	string a;
	cin >> a;
	printf(" __      _____\n"
"|  | ___/ ____\\____\n"
"|  |/ /\\   __\\/ ___\\\n"
"|    <  |  | \\  \\___\n"
"|__|_ \\ |__|  \\___  >\n"
     "     \\/           \\/\n");
     return 0;
}
