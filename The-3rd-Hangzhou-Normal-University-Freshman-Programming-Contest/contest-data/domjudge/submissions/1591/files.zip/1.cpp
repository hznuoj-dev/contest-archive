#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main()
{
    int t, a, b, c, min, max, i, k;
    scanf("%d", &t);
    while (t--)
    {
        k = 0;
        scanf("%d %d", &a, &b);
        c = a + b;
        if (c > 9999)
        {
            c = 9999 - (c - 9999);
        }
        min = c > a ? a : c;
        max = c > a ? c : a;
        for (i = min; i <= max; i++)
        {
            if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
            {
                k++;
            }
        }
        printf("%d\n", k);
    }
    return 0;
}