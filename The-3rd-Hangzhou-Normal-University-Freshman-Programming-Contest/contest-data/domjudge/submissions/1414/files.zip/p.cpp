#include<iostream>
using namespace std;
int main(){
	long long a1,b1,c1,d1,a2=0,b2=0,c2=0,d2=0,ans=0;
	cin >> a1 >> b1 >> c1 >> d1;
	while (a1){
		a2+=a1%10;
		a1/=10;
	}
	if (a2>=16||a2==6) ans++;
	while (b1){
		b2+=b1%10;
		b1/=10;
	}
	if (b2>=16||b2==6) ans++;
	while (c1){
		c2+=c1%10;
		c1/=10;
	}
	if (c2>=16||c2==6) ans++;
	while (d1){
		d2+=d1%10;
		d1/=10;
	}
	if (d2>=16||d2==6) ans++;
	if (ans==0) cout <<"Bao Bao is so Zhai......" <<endl;
	else if (ans==1) cout << "Oh dear!!"<<endl;
	else if (ans==3) cout << "Bao Bao is a SupEr man///!"<<endl;
	else if (ans==2) cout << "BaoBao is good!!"<< endl;
	else cout <<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;
    return 0;
}
