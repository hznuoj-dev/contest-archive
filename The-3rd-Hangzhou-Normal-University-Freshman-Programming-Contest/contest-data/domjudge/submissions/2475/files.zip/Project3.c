﻿#include <stdio.h>
#include<string.h>
char a[10000], b[10000];
int main() {
    int t, n, i, j, sum=0, kinds, p;
    scanf("%d\n", &t);
    while (t--) {
        sum = 0;
        scanf("%d\n", &n);
        while (n--) {
            kinds = 1;
            memset(a, '\0', 10000);
            gets(a);
            b[0] = '.';
            for (i = 0; a[i] != '\0'; i++) {
                if (a[i] != '.') {
                    p = 1;
                    for (j = 0; j < kinds; j++) {
                        if (a[i] == b[j]) {
                            p = 0;
                        }
                    }
                    if (p) {
                        kinds++;
                        b[kinds - 1] = a[i];
                    }
                }
            }
            sum += (kinds - 1);
        }
        printf("%d\n", sum);
    }
    return 0;
}