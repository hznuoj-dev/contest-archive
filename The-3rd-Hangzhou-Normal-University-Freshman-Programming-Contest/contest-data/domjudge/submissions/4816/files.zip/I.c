#include <stdio.h>
int f(int a) {
	int t;
	int cont = 0;
	while (a > 0) {
		t = a % 10;
		a /= 10;
		cont += t;
	}
	return cont;
}

int main() {
	int a, b, c, d;
	int sum;
	int a_sum = 0, b_sum = 0, c_sum = 0, d_sum = 0;
	scanf("%d %d %d %d", &a, &b, &c, &d);
	if (f(a) >= 16 || f(a) == 6) a_sum = 1;
	if (f(b) >= 16 || f(b) == 6) b_sum = 1;
	if (f(c) >= 16 || f(c) == 6) c_sum = 1;
	if (f(d) >= 16 || f(d) == 6) d_sum = 1;
	sum = a_sum + b_sum + c_sum + d_sum;
	if (sum == 1) printf("Oh dear!!\n");
	if (sum == 2) printf("BaoBao is good!!\n");
	if (sum == 3) printf("Bao Bao is a SupEr man///!\n");
	if (sum == 4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if (sum == 0) printf("Bao Bao is so Zhai......\n");
}
