#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+100;
const int INF=0x3f3f3f3f;
const ll MOD=998244353;
int n,m;
int in[N],ans[N];
int head[N],cnt=0;
void init(){
	memset(in,0,sizeof in);
	memset(head,-1,sizeof head);
	cnt=0;
}
struct Edge{
	int next,to;
}edge[N];
void add_Edge(int u,int v){
	edge[cnt].next=head[u];
	edge[cnt].to=v;
	head[u]=cnt++;
}
struct node{
	int id;
	node(int a){
		id=a;
	}
	bool friend operator<(const node &a,const node &b){
		return a.id>b.id;
	}
};
void bfs(){
	priority_queue<node>q;
	int pos=0;
	for(int i=1;i<=n;++i){
		if(in[i]==0)
			q.push(node(i));
	}
	while(!q.empty()){
		node u=q.top();
		q.pop();
		ans[++pos]=u.id;
		for(int i=head[u.id];~i;i=edge[i].next){
			Edge y=edge[i];
			in[y.to]--;
			if(in[y.to]==0)
				q.push(node(y.to));
		}
	}
	for(int i=1;i<=n;++i)
		printf("%d%c",ans[i],i==n?'\n':' ');
}
int main(){
	int T; scanf("%d",&T);
	while(T--){
		init();
		scanf("%d %d",&n,&m);
		while(m--){
			int u,v; scanf("%d %d",&u,&v);
			add_Edge(u,v);
			in[v]++;
		}
		bfs();
	}
	return 0;
}
