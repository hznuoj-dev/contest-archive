def judge(x):
    now=0
    while x>0:
        now=now+x%10
        x=x//10
    return now
def main():
    lst=list(map(int,input().split()))
    total=0
    for i in range(len(lst)):
        if judge(lst[i])>=16 or judge(lst[i])==6:
            total+=1
    if(total==1):
        print('Oh dear!!')
    elif(total==2):
        print('BaoBao is good!!')
    elif(total==3):
        print('Bao Bao is a SupEr man///!')
    elif(total==4):
        print('Oh my God!!!!!!!!!!!!!!!!!!!!!')
    elif(total==0):
        print('Bao Bao is so Zhai......')
main()
