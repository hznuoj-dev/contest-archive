#include<stdio.h>
int main(void)
{
int t;
int time;
long long int y=0,a=0;
long long int sum=0,sum1=0;
long long int i=0,j=0;
scanf("%d",&t);
for(time=0;time<t;time++)
{
	scanf("%lld %lld",&y,&a);
	sum=y+a;
	if(a<0)
	{
		for(i=sum;i<=y;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			j++;
		}
	}
	else
	{
	if(sum<=9999)
	{
		for(i=y;i<=sum;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			j++;
		}
	}
	else
	{
		sum1=9999-((y+a)-9999);
		for(i=y;i<=sum1;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			j++;
		}
	}
    }
	printf("%lld",j); 
	if(time!=t-1)
	printf("\n");
	sum=0;
	sum1=0;
	j=0;
}
return 0;
} 
