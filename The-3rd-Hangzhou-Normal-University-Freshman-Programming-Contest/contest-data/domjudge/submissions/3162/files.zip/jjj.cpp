#include<stdio.h>
#include<string.h>
char s[10000000];
int main(){
int t,i,j;
scanf("%d",&t);
while(t--){
	int n,count=0;
	scanf("%d",&n);
	while(n--){
		int f=1;
		scanf("%s",s);
		for(i=0;i<strlen(s);i++){
			if(s[i]!='.'){
				if(i==0)count++;
				else {
				for(j=0;j<i;j++){
				if(s[i]==s[j]){
				f=0;break;
				}	
			}
			if(f==1)count++;
				}
				f=1;
			}
		}
	}
	printf("%d\n",count);
}
	return 0;
}
