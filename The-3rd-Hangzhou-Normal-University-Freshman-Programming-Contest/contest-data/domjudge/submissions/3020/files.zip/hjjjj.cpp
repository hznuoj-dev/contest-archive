#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long a[6];
	for(int i=1;i<=4;i++)
		cin>>a[i];
	int count=0;
	for(int i=1;i<=4;i++){
		int sum=0;
		while(a[i]!=0){
			int bb=a[i]%10;
			a[i]/=10;
			sum+=bb;
		}
		if(sum>=16||sum==6)
			count++;
	}
	if(count==0)
		printf("Bao Bao is so Zhai......");
	else if(count==1)
		printf("Oh dear!!");
	else if(count==2)
		printf("BaoBao is good!!");
	else if(count==3)
		printf("Bao Bao is a SupEr man///!");
	else if(count==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
} 

