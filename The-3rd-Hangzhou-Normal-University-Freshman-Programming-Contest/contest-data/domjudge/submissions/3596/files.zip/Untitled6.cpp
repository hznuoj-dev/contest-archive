
#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>


using namespace std;


int main(){
	int t, i;
	int n, m;
	cin >> t;
	while(t--){
		cin >> n >> m;
		for(i=0;i<n;i++){
			if(i==0)cout << "[";
			if(i<m){
				cout << "#";
			}else cout << "-";
			
			if(i==n-1)cout << "] ";
		}
		double s=((double)m/(double)n)*100;
		printf("%.0f%%\n", s);
	}
	return 0;
}
