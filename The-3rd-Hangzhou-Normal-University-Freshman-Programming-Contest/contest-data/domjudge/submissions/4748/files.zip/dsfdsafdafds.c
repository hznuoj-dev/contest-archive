#include <string.h>
int ss(char x[]){
	long long int c,n=0;
	int y[200]={0};
	char t;
	for(c=0;c<strlen(x);c++){
		t=x[c];
		if(t!='.' && y[t]==0){
			y[t]=1;
			n++;
		}
	}
	return n;
}

int main()
{
	int t,n,c;
	scanf("%d",&t);
	char x[100000];
	while(t--){
		scanf("%d",&n);
		long long int s=0;
		for(c=1;c<=n;c++){
			scanf("%s",&x);
			s=s+ss(x);	
		}
		printf("%lld\n",s);
	}
	return 0;
}
