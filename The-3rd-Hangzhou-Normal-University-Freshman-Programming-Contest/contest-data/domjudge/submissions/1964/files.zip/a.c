#include <stdio.h>
//#pragma warning(disable:4996)
//#include<process.h>
int main()
{
	printf("hhh");
	int T,i,Y,A,A1,j,num=0;
	scanf("%d",&T);
	for(i=1;i<=T;i++)
	{
	scanf("%d %d",&Y,&A);
	if(Y+A>9999)
		A1=9999-A;
	else
		A1=A+Y;
	if(Y<=A1)
	{
	for(j=Y;j<=A1;j++)
	{
		num=0;
	if((j%4==0&&j%100!=0)||j%400==0)
		num++; 
	}
	}
	else
	{
	for(j=A1;j<=Y;j++)
	{
		num=0;
	if((j%4==0&&j%100!=0)||j%400==0)
		num++; 
	}
	}
	printf("%d\n",num);
	}
//system ("pause");
return 0;
}