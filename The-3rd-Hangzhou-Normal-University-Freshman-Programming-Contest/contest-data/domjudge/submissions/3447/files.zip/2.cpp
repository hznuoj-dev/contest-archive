#include<bits/stdc++.h>
using namespace std;
int main()
{
    char str[100];
    scanf("%s",str);
        printf(" __      ____\n");
        printf("|  | __/ ___\\___\n");
        printf("|  |/ /\\   _\\/ __\\\n");
        printf("|    <  |  |\\  \\__\n");
        printf("|_| \\ |_|  \\__  >\n");
        printf("     \\/           \\/\n");

    return 0;
}
