#include<stdio.h>

int main()
{
   int T;
   scanf("%d",&T);
   while(T--)
   {
   	long y1,y2,n,i,m1,m2,flog=0;
   	scanf("%ld %ld",&y1,&n);
   	y2=y1+n;
   	if(y2>=10000)
	   {
	
	   y2=9999-(y2-10000);
}
    if(y2>y1)
    {
    	m2=y2;
    	m1=y1;
	}
	else
	{
		m2=y1;
		m1=y2;
	}
	
   	
   	for(i=m1;i<=m2;i++)
   	{
   		if((i%4==0&&i%100!=0)||i%400==0)flog+=1;
   		
	   }
   	
   	printf("%ld",flog);
   	
   	
   }
	
	return 0;
}
