#include<stdio.h>
int main() {
	int t, a, b, i, m[1010], n[1010], c, d, k;
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &a, &b);
		for (i = 1;i <= a;i++) {
			m[i] = i;
			n[m[i]] = i;
		}
		while (b--) {
			scanf("%d %d", &c, &d);
			if (c > d) {
				k = m[n[d]];
				m[n[d]] = c;
				for (i = n[c];i > n[d]+1;i--)
					m[i] = m[i - 1];
				m[i] = k;
			}
		}
		for (i = 1;i < a;i++)
			printf("%d ", m[i]);
		printf("%d\n", m[i]);
	}
}

