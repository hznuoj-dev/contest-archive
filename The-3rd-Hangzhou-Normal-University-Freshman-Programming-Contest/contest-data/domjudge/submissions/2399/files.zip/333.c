#include<stdio.h>
int main(void){
	int a,b,c,d,n;
	scanf("%d %d %d %d",&a ,&b ,&c ,&d);
	int total1=0,total2=0,total3=0,total4=0,i=0;
	while(a!=0){
		n=a%10;
		total1+=n;
		a=a/10;
	}
	if(total1==6||total1>=16)
		i++;
	while(b!=0){
		n=b%10;
		total2+=n;
		b=b/10;
	}
	if(total2==6||total2>=16)
		i++;
	while(c!=0){
		n=c%10;
		total3+=n;
		c=c/10;
	}
	if(total3==6||total3>=16)
		i++;
	while(d!=0){
		n=d%10;
		total4+=n;
		d=d/10;
	}
	if(total4==6||total4>=16)
		i++;
	if(i==1)
		printf("Oh dear!!\n");
	if(i==2)
		printf("BaoBao is good!!\n");
	if(i==3)
		printf("Bao Bao is a SupEr man///");
	if(i==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if(i==0)
		printf("Bao Bao is so Zhai......\n");
	return 0;
}
