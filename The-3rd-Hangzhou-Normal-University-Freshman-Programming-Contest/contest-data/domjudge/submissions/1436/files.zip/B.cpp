#include<stdio.h>

int main()
{
	int n;
	int a, b, c;
	int max, min;
	int count;
	
	scanf("%d", &n);
	
	while(n--){
		scanf("%d %d", &a, &b);
		count = 0;
		c = a + b;
		if(c >= 10000){
			c = 9999 - (c - 9999);
		}
		if(a > c){
			max = a;
			min = c;
		} 
		else{
			max = c;
			min = a;
		}
		for(int i = min; i <= max; i++){
			if((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
			count++;
		}
		printf("%d\n", count);
	}
	return 0;
} 
