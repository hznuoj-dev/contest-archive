t=int(input())
for i in range(t):
    sum=0
    n=int(input())
    for j in range(n):
        s=input()
        t=[]
        for k in s:
            if k!='.' and k not in t and k!='\r':
                t.append(k)
        
        sum+=len(t)
        t.clear()
        
    print(sum)
    
