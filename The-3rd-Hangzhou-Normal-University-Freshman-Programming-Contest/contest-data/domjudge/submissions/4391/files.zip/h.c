#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t,n,m,a,i,bfb; 
	    
	    while(~scanf("%d",&t)){
	    	while(t--){
	    		scanf("%d %d",&n,&m);
	    		bfb=100*m/n;
	    		printf("[");
	    		for(i=0;i<m;i++){
	    			printf("#");
				}
				for(i=0;i<n-m;i++){
	    			printf("-");
				}
				printf("] %d%%",bfb); 
			
			}
		}
	    
	    
	return 0;
} 
