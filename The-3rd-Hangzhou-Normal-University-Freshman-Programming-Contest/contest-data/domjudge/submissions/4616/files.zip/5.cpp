#include<stdio.h>
int main(void)
{
	int t,i,j;
	int a,b;
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		scanf("%d %d",&a,&b);
		printf("[");
		for(j=1;j<=b;j++)
		printf("#");
		for(j=1;j<=(a-b);j++)
		printf("-");
		printf("] ");
		printf("%d",b*100/a);
		printf("%%\n");
		
		
	}
	
 } 
