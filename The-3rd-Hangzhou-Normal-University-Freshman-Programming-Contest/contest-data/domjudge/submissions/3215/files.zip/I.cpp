#include<stdio.h>
int jisuan(long long n)
{int c=0;
	while(n>0){
	c=c+n%10;
	n=n/10;		
	}
if(c>=16||c==6)	{
	return 1;
}
return 0;	
}
int main(){
long long A,B,C,D,e=0;
scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
e=jisuan(A)+jisuan(B)+jisuan(C)+jisuan(D);
if(e==2){printf("BaoBao is good!!");}
if(e==3){printf("Bao Bao is a SupEr man///!");}
if(e==4){printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");}
if(e==0){printf("Bao Bao is so Zhai......");}
if(e==1){printf("Oh dear!!");}
}

