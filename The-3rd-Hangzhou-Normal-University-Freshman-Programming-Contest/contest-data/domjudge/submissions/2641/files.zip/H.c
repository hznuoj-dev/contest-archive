#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void) {
	int t;
	scanf("%d",&t);
	while(t--) {
		int a,b,c,e;
		double d;
		scanf("%d %d",&a,&b);
		c=abs(a-b);
		d=(double)b/a;
		e=d*100;
		printf("[");
		for(int i=0; i<b; i++)
			printf("#");
		for(int i=0; i<c; i++)
			printf("-");
		printf("]");
		printf(" %d",e);
		printf("%%");
		printf("\n");

	}
	return 0;
}
