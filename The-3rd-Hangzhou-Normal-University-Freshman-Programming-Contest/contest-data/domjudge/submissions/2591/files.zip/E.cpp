#include <stdio.h>
int main ()
{
	char a;
	scanf("%s",a);
		printf(" --      -----     \n");
		printf("| | ___/ ____\\____\0");
		printf("\n");
		printf("| |/ /\\   __\\/ ___\0");
		printf("\\");
		printf("\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/\n");
	return 0;
 } 

