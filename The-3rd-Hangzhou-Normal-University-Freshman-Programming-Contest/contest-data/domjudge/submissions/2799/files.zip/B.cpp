#include<stdio.h>
int main()
{
	int x,T,Y,A,i,t,m;
	scanf("%d\n",&T);
	while(T--){
		scanf("%d %d",&Y,&A);
		m=Y+A;
		x=0;
		if(m>=10000){
		m=9999-(m-9999);}
		if(m<Y){
		t=Y;Y=m;m=t;}
		for(i=Y;i<=m;i++)
		{
			if(i%4==0&&i%100!=0||i%400==0)
			x++; 
		}
		printf("%d",x);
		printf("\n");
	} 
	return 0;
}
