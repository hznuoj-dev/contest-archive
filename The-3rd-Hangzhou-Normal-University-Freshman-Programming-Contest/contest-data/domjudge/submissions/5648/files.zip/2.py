t = int(input())
while t:
    t = t - 1
    n, m = map(int, input().split())
    b = []
    for i in range(m):
        a = list(map(int, input().split()))
        b = b + a
b.reverse()
b=sorted(set(b),key=b.index)
b.reverse()
for i in range(len(b)):
    print(b[i],end=' ')
