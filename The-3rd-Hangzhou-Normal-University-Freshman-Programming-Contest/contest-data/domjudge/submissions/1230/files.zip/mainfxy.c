#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int a,b,c,n,i,t;
	scanf("%d",&n);
	while(n--){
		t=0;
		scanf("%d%d",&a,&b);
		c=a+b;
		while(c>9999){
			c=9999-(c-9999);
		}
		if(a>c){
			b=a;
			a=c;
			c=b;
		}
		for(i=a;i<=c;i++){
			if(i%4==0&&i%100!=0||i%400==0)
			t++;
		}
		printf("%d\n",t);
	}
	return 0;
}
