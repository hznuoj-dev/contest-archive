#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<set>
#include<map>
#include<iostream>
#include<string>
using namespace std;
typedef long long int ll;
const int N=1e5+100;
void run(){
	string a;
	int cnt=0;
	for(int i=1;i<=4;i++){
		cin>>a;
		int ans=0;
		for(auto it:a){
			ans+=(it-'0');
		}
		if(ans>=16||ans==6)cnt++;
	}
	if(cnt==0)puts("Bao Bao is so Zhai......");
	if(cnt==1)puts("Oh dear!!");
	if(cnt==2)puts("BaoBao is good!!");
	if(cnt==3)puts("Bao Bao is a SupEr man///!");
	if(cnt==4)puts("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}
int main(){
	//int T;
	//scanf("%d",&T);
	//while(T--){
		run();
	//}
	return 0;
}
