#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;
char str[maxn];
int main(){
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		int ans=0;
		for(int i=0;i<n;i++){
			cin>>str;
			int len=strlen(str);
			int shu[2000];
			memset(shu,0,sizeof shu);
			for(int j=0;j<len;j++){
				if(str[j]=='.')continue;
				if(shu[str[j]]==0){
					shu[str[j]]=1;
					ans++;
				}
			}
		}
		printf("%d\n",ans);		
	}
}
