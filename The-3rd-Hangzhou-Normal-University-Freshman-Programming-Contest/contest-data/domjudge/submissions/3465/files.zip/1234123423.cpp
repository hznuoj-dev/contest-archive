#include <bits/stdc++.h>
using namespace std;
int main(){
	int t;
	cin>>t;
	while(t--){
		int a,b;
		cin>>a>>b;
		printf("[");
		int m,n;
		m=a;n=b;
		while(n--){
			printf("#");
		}
		int g=a-b;
		while(g--){
			printf("-");
		}
		printf("] ");
		printf("%.0f%%\n",b*1.0/a*100);
	}
}
