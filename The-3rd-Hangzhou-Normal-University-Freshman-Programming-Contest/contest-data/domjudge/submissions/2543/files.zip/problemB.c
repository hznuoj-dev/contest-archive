#include<stdio.h>
void main()
{
	int T, Y, A;
	int max, min, mid, i, j;
	scanf("%d", &T);
	while (T--)
	{
		j = 0;
		scanf("%d %d", &Y, &A);
		mid = Y + A;
		if (mid >= 10000)
		{
			mid = mid - 9999;
			mid = 9999 - mid;
			if (mid < Y)
			{
				min = mid;
				max = Y;
			}
			else
			{
				min = Y;
				max = mid;
			}
		}
		else 
		{
			if (mid < Y)
			{
				min = mid;
				max = Y;
			}
			else
			{
				min = Y;
				max = mid;
			}
		}
		for (i = min; i <= max; i++)
		{
			if ((i % 4 == 0 && i % 100 != 0) || (i % 100 == 0 && i % 400 == 0))
			{
				j++;
			}
		}
		printf("%d\n",j);
	}
}



























/*int n, T, m, p, q;
	int a[1000000][5],b[100000][15];
	int i, j, l, L;
	scanf("%d %d %d %d", &n, &T, &m, &p);
	for (i = 0; i < m; i++)
	{
		scanf("%d %d %d %c %c", &a[i][0], &a[i][1], &a[i][2], &a[i][3], &a[i][4]);
	}
	scanf("%d", &q);
	for (i = 0; i < q; i++)
	{
		scanf("%s", &b[i]);
		l = strlen(&b[i]);
		scanf("%d %d", &b[i][l + 1], &b[i][l + 2]);
	}
	for (i = 0; i < q; i++)
	{
		if (b[i][0] == 't'&&b[i][6] == 't')
		{
			printf("%d [%s] %")
		}
	}*/