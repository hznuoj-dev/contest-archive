//#include <bits/stdc++.h>
//typedef long long  ll;
//const int MAXN=1e2+5;
#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int k,n,m,x,y,i,T,j,t=0,sum,temp,s1,s2,s3,s4;
char c='%';
int main(){
   cin>>T;
   for(i=1;i<=T;i++){
    cin>>x>>y;
    cout<<"[";
    for(j=1;j<=y;j++)
        cout<<"#";
    for(j=1;j<=x-y;j++)
        cout<<"-";
    cout<<"] ";
    sum=y*100/x;
    cout<<sum<<c<<'\n';
   }
    return 0;
}

