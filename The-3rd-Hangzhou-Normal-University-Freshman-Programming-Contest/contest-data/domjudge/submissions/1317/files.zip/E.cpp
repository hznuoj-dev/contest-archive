#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
//#include<Windows.h>
using namespace std;
int main()
{
	char str[5];
	scanf("%s",str);
	if(strcmp(str,"kfc")==0)
	{printf(" __      _____\n"
		   "|  | ___/ ____\\____\n"
		   "|  |/ /\\   __\\/ ___\\\n"
		   "|    <  |  | \\  \\___\n"
		   "|__|_ \\ |__|  \\___  >\n"
		   "     \\/           \\/\n");
	}
	//system("pause");
	return 0;
}
