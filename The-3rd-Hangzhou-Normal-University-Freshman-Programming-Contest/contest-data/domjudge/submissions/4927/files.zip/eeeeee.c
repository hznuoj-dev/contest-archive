#include<stdio.h>
int main(){
char a[3];
	for(int i=0;i<2;i++){
		scanf("%c",&a[i]);
	}
	    printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/\n");
	
}
