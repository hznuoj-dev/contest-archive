#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
int n;
char s[10000001];
int lc;
int main(){
	scanf("%d",&n);
	while(n--){
		int count=0;
		scanf("%d",&lc);
		while(lc--){
			int flag=0;
			scanf("%s",s);
			int len=strlen(s);
			for(int i=0;i<len;i++){
				if(s[i]=='.') continue;
				flag=0;
				for(int j=0;j<i;j++){
					if(s[i]==s[j]) {
						flag=1;
					break;}
				}
				if(flag==0){
					count++;
				}
			}
			
		}
		printf("%d\n",count); 
	}
}
