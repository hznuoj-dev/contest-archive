#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int Run(int x){
	if((x%4==0 &&x%100!=0)||(x%400==0)){return 1;
	}else{return 0;
	}
}
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int a,b,c,d,i,x=0;
		scanf("%d%d",&a,&b);
		if(a+b>9999){
			c=a+b-9999;
			b=a+b-c;
		}else{
			b=a+b;
		}
		if(a>b){
			d=a;
			a=b;
			b=d;
		}
		for(i=a;i<=b;i++){
			if(Run(i)==1){x=x+1;
			}
		}
		printf("%d\n",x);
	}
}
