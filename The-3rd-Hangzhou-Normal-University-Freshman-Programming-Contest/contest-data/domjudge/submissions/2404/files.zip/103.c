#include<stdio.h>
int main(){
	long long a, b, c, d;
	int sum,zong=0;
	scanf("%lld%lld%lld%lld", &a, &b, &c, &d);
	sum = 0;
	while (a > 0) {
		sum += a % 10;
		a /= 10;
	}
	if (sum == 6 || sum >= 16) {
		zong++;
	}
	sum = 0;
	while (b > 0) {
		sum += b % 10;
		b /= 10;
	}
	if (sum == 6 || sum >= 16) {
		zong++;
	}
	sum = 0;
	while (c > 0) {
		sum += c % 10;
		c /= 10;
	}
	if (sum == 6 || sum >= 16) {
		zong++;
	}
	sum = 0;
	while (d > 0) {
		sum += d % 10;
		d /= 10;
	}
	if (sum == 6 || sum >= 16) {
		zong++;
	}
	if (zong == 0)
		printf("Bao Bao is so Zhai......");
	else if (zong == 1)
		printf("Oh dear!!");
	else if (zong == 2)
		printf("BaoBao is good!!");
	else if (zong == 3)
		printf("Bao Bao is a SupEr man///!");
	else if (zong == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}
