#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
int main(){
	int a,b,c,d,sum;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	int count=0;
	while(a>0){
		count+=a%10;
		a/=10;
	}
	if(count>=16||count==6) sum++;
	count=0;
	while(b>0){
		count+=a%10;
		b/=10;
	}
	if(count>=16||count==6) sum++;
 	count=0;
	while(c>0){
		count+=a%10;
		c/=10;
	}
	if(count>=16||count==6) sum++;
	 count=0;
	while(d>0){
		count+=a%10;
		d/=10;
	}
	if(count>=16||count==6) sum++;
	if(sum==1){
		printf("��Oh dear!!");
	}
	else if(sum==2) printf("BaoBao is good!!");
	else if(sum==3) printf("Bao Bao is a SupEr man///!");
	else if(sum==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else printf("Bao Bao is so Zhai......");
	
}
