#include<stdio.h>
int main()
{
	int t,n,m,i;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=0;i<m;i++){
			printf("#");
		}
		for(i=0;i<n-m;i++){
			printf("-");
		}
	double p,M,N;
	M=m;N=n;
	p=M/N;
	printf("] %.0f%%\n",p*100);
	}
	return 0;
}
