#include <stdio.h>
#include <stdlib.h>
#include<string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char s[100];
	int t=4;
	int SUM=0;
	
	int j;
	for(j=1;j<=4;j++){
		int slen=0;
		scanf("%s",s);
		slen=strlen(s);
		int sum=0;
		int i;
		for(i=0;i<slen;i++){
			sum=sum+(s[i]-'0');
		}
		if(sum>=16||sum==6){
		   SUM=SUM+1;	
		}
	}
	switch(SUM){
			case 1: printf("Oh dear!!\n");
			        break;
			case 2: printf("BaoBao is good!!\n");
			        break;
			case 3: printf("Bao Bao is a SupEr man///!\n");
			        break;
			case 4: printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
			        break;
			case 0: printf("Bao Bao is so Zhai......\n");
			        break;        
		}
	return 0;
}

