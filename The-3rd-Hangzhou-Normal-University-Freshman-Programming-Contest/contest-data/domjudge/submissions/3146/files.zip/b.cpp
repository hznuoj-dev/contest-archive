#include<stdio.h>
#include<string.h>
int main()
{
	int t,i,n,m,w;
	char a='%';
	double k;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		k=m*1.0/n;
		w=k*100;
		printf("[");
		for(i=0;i<m;i++)
		{
			printf("#");
		}
		for(i=0;i<n-m;i++)
		{
			printf("-");
		}
		printf("] ");
		printf("%d",w);
		printf("%c\n",a);
	}
	return 0;
} 
