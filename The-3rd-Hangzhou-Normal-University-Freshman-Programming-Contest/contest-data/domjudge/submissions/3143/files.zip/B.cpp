#include<bits/stdc++.h>
using namespace std;
int t[4];
int main()
{
	long long a,b,c,d;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	long long sum=0,x;
	while(a!=0)
	{
		x=a%10;
		sum=sum+x;
		a=a/10;
	}
	if(sum==6||sum>=16)t[1]=1;
	sum=0;
	while(b!=0)
	{
		x=b%10;
		sum=sum+x;
		b=b/10;
	}
	if(sum==6||sum>=16)t[2]=1;
	sum=0;
	while(c!=0)
	{
		x=c%10;
		sum=sum+x;
		c=c/10;
	}
	if(sum==6||sum>=16)t[3]=1;
	sum=0;
	while(d!=0)
	{
		x=d%10;
		sum=sum+x;
		d=d/10;
	}
	if(sum==6||sum>=16)t[4]=1;
	sum=0;
	int count=0;
	for(int i=1;i<=4;i++){
		if(t[i]==1)count++;
	}
	if(count==0)printf("Bao Bao is so Zhai......");
	else if(count==1)printf("Oh dear!!");
	else if(count==2)printf("BaoBao is good!!");
	else if(count==3)printf("Bao Bao is a SupEr man///!");
	else if(count==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
