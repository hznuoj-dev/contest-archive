 #include<stdio.h>
int main(){
	char str[5];
	scanf("%s",str);
	if(str[0]=='k'&&str[1]=='f'&&str[2]=='c')
	printf(" __      _____     \n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/"); 
	return 0;
}
