#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main(void) {
	int T,n,m,b=0;
	float a=0;
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d", &n, &m);
		printf("[");
		a = (m*1.0 / n )* 100;
		b = n - m;
		while (m > 0) {
			printf("#");
			m--;
		}
		while (b > 0) {
			printf("-");
			b--;
		}
		printf("] %.0f%%\n", a);
	}
	return 0;
}