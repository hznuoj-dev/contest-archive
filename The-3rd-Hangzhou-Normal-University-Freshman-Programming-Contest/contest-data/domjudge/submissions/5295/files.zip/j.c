#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996)
int main()
{
	char a[200][1000000],o[500];
	int b,c,d,i,j,m,n,k,y;
	scanf("%d",&b);
	while(b--)
	{
		scanf("%d",&c);
		d=0;
		k=0;
		for(i=0;i<500;i++)
			o[i]='.';
		for(i=1;i<=c;i++){
			getchar();
			m=0;
			scanf("%s",a[i]);
			n=strlen(a[i]);
			for(j=0;j<n;j++)
			{
				if(a[i][j]!='.')
				{
					for(y=1;y<=k;y++)
						if(a[i][j]!=o[y])
						{
							m++;
							k++;
							o[k]=a[i][j];
						}
				}
			}
			d=d+m;
		}
		printf("%d\n",d);
	}
	return 0;
}
