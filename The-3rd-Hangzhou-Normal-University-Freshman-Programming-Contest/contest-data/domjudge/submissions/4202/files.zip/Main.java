
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner shh = new Scanner(System.in);
		int js;
		while (shh.hasNext())
		{
			js=0;
			for (int i = 0; i < 4; i++)
			{
				String y= shh.next();
				if(y.length()<=2 && y.length()>=1)
					{
					int x=Integer.valueOf(y);
					if(x>=16 || x==6)js=js+1;
					}else if(y.length()>=3)
					{
						js=js+1;
					}
			}
			if(js==1)System.out.println("Oh dear!!");
			if(js==2)System.out.println("BaoBao is good!!");
			if(js==3)System.out.println("Bao Bao is a SupEr man///!");
			if(js==4)System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			if(js==0)System.out.println("Bao Bao is so Zhai......");
			
		}
   }
}
