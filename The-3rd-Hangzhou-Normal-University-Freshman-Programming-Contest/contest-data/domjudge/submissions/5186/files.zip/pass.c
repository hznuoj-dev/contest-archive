/*#include <stdio.h>
#pragma warning(disable:4996)
int main (){
	
	char a;

	scanf ("%c",&a);
	printf(" __     _____\n"
           "| | ___/ ____\\____\n"
           "| |/ /\\  __\\/ ___\\\n"
           "|   < | | \\ \\___\n"
           "|__|_ \\ |__| \\___ >\n"
           "     \\/          \\/\n");

	system ("pause");
	return 0;
}*/

/*#include <stdio.h>
#pragma warning(disable:4996)
int main (){

	long long a,b,c,d,a1=0,b1=0,c1=0,d1=0,suma=0,sumb=0,sumc=0,sumd=0,n=0;

	scanf ("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>0){
		a1=a%10;
		suma+=a1;
		a/=10;
	}
	if(suma>=16||suma==6)n++;
	while(b>0){
		b1=b%10;
		sumb+=b1;
		b/=10;
	}
	if(sumb>=16||sumb==6)n++;
	while(c>0){
		c1=c%10;
		sumc+=c1;
		c/=10;
	}
	if(sumc>=16||sumc==6)n++;
	while(d>0){
		d1=d%10;
		sumd+=d1;
		d/=10;
	}
	if(sumd>=16||sumd==6)n++;
	if(n==1)printf("Oh dear!!");
	else if(n==2)printf ("BaoBao is good!!");
	else if(n==3)printf ("Bao Bao is a SupEr man///!");
	else if(n==4)printf ("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(n==0)printf ("Bao Bao is so Zhai......");


	return 0;
}*/


/*#include <stdio.h>
#pragma warning(disable:4996)
int main(){

	int t,n=0,sum,i,j;
	char s[100][100],a;

	a='.';
	scanf ("%d",&t);
	while(t--){
		scanf ("%d",&n);
		for(i=0;i<n;i++)
			scanf ("%s",s[i]);
		for(i=0;i<n;i++){ 
			for(j=0;j<100;j++){
				if(s[i][j]!=a)n++;
			}
		}
	}
	printf ("%d",&n);

	system ("pause");
	return 0;
}*/

#include <stdio.h>
#pragma warning(disable:4996)
int main(){
	
	int t,n,m,a,b,i;
	int str[1000];

	scanf ("%d",&t);
	while(t--){
		scanf ("%d %d",&n,&m);
		str[n]='0';
		for(i=0;i<n-1;i++,m--){
			scanf ("%d %d",&a,&b);
				str[i]=a;
		}
		if(i==n-1)str[n-1]=b;
		for(i=0;i<n-1;i++)
			printf("%d ",str[i]);
		if(i==n-1)printf("%d\n",str[n-1]);
	}

		system ("pause");
	return 0;
}


/*#include<stdio.h>
#pragma warning(disable:4996)
int main(){

	int t,y,a,x,r1,r2,i,c;

	scanf ("%d",&t);
	while(t--){
		x=0;
		scanf("%d %d",&y,&a);

		if(y+a>9999){
	     	r1=y+a-9999;
			r2=9999-r1;
		}
		else r2=y+a;
	    if(r2<y){
		   c=y;y=r2;r2=c;
	    }
		for(i=y;i<=r2;i++){
			if((i%4==0&&i%100!=0)||i%400==0)x++;
		}
		printf ("%d\n",x);
	}


		return 0;
}*/

/*#include <stdio.h>
#include<math.h>

int main(){

	int t,i;
	double m,n;

    scanf("%d",&t);
	while(t--){
		scanf ("%lf %lf",&m,&n);
		printf ("[");
		for(i=0;i<n;i++){
			printf("#");
		}
		for(i=0;i<m-n;i++){
			printf ("-");
		}
		printf ("] %.0lf%%\n",n/m*100);
	}

		return  0;
}*/



/*#include <stdio.h>
#pragma warning(disable:4996)
int main (){

	int n,m,a[100000],b[100000],c[100000],x=0;
	int i,j;

	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
		scanf("%d",&b[i]);
	}
	for(i=n-1;i>=0;i--){
		for(j=0;j<100000;j++){
			while(b[i]>0){
				c[j]=a[i]*b[i];
				b[i]--;
			}
*/