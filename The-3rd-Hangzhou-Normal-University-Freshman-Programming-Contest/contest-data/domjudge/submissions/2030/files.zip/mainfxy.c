#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,a,b,c,i;
	scanf("%d",&n);
	while(n--){
		scanf("%d%d",&a,&b);
		printf("[");
		for(i=1;i<=a;i++){
			if(i<=b)
			printf("#");
			else
			printf("-");
		}
		printf("] ");
		c=b*100/a;
		printf("%d%%\n",c);
	}
	return 0;
}
