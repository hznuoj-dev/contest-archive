#include<stdio.h>
int main(void) {
	int t, a, b, c, i;
	char list[10002] = {'0'};
	scanf_s("%d", &t);
	while (t--) {
		scanf("%d%d", &a, &b);
		c = b * 100 / a;
		list[0] = '[';
		list[a + 1] = ']';
		for (i = 1; i <= b; ++i) {
			list[i] = '#';
		}
		for (i = b + 1; i < a + 1; ++i) {
			list[i] = '-';
		}
		printf("%s %d%%\n",list, c);
	}
	return 0;
}