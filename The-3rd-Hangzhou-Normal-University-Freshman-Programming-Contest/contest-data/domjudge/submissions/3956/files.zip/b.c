#include<stdio.h>
int main()
{
    int t;
    scanf("%d\n",&t);
    while(t--)
    {
        int y,a,y2,t,i,num=0;
        scanf("%d %d\n",&y,&a);
        if(y+a>9999){y2=9999-((y+a)-9999);}
        else y2=y+a;
        if(y>y2){t=y;y=y2;y2=t;}
        for(i=y;i<=y2;i++)
        {
            if((i%400==0)||((i%4==0)&&(i%100!=0)))num++;
        }
        printf("%d\n",num);
    }
}
