#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;

const int maxn=1e3+10;


int t;
int n,m; 
struct node
{
	int num;
	int rank;
}a[maxn];

bool cmp(node a,node b)
{
	return a.rank<b.rank;
}

int main()
{

	fcio;
//	fcin;
//	freopen("out.txt","w",stdout); 
	cin>>t;
	while(t--)
	{
		cin>>n>>m;
		for(int i=1;i<=n;i++)
		{
			a[i].num=i;
			a[i].rank=i;
		}
		
		for(int i=0;i<m;i++)
		{
			int p,q;
			cin>>p>>q;
			if(a[p].rank<a[q].rank) continue;
			else
			{
				a[p].rank=a[q].rank;
				a[q].rank++;
				for(int j=1;j<=n;j++)
				{
					if(a[j].rank>=a[q].rank)
					{
						a[j].rank++;
					}
				}
			}
		}
		
		sort(a+1,a+1+n,cmp);
		
		for(int i=1;i<=n;i++) cout<<a[i].num<<(i==n?'\n':' ');
	}
}
