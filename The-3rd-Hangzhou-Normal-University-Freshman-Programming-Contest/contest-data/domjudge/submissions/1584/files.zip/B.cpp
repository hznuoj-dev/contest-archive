#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int leapyear(int y,int x){
	int s=0,i;
	if(y<=x){
		for(i=y;i<=x;i++){
			if((i%4==0&&i%100!=0)||(i%400)==0){
				s+=1;
			}
		}
	}
	if(y>x){
		for(i=x;i<=y;i++){
			if((i%4==0&&i%100!=0)||(i%400)==0){
				s+=1;
			}
		}
	}
	return s;
}
int main(void) {
    int t,y,a,x;
    scanf("%d",&t);
    while(t--){
    	scanf("%d%d",&y,&a);
    	if(y+a<10000){
    		x=y+a;
		}
		if(y+a>=10000){
			x=9999-(y+a-9999);
		}
		printf("%d\n",leapyear(y,x)); 
	}
return 0;
}

