#include<stdio.h>
int main(){
int T;
int a,b;
double c;
scanf("%d ",&T);
while(T--){
scanf("%d %d",&b,&a);	
c=a*100.0/b;
printf("[");
b=b-a;
while(a>0){
	printf("#");
	a--;
}

while(b>0){
		printf("-");
		b--;
}
	printf("]%.0lf%%\n",c);
	
}	
	return 0;
}
