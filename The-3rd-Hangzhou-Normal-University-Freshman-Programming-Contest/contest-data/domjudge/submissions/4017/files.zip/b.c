#include<stdio.h>
double ac(int a,int b);
int main()
{
    int i,t,m,n,count;
    scanf("%d",&t);
    for(i=0;i<t;i++)
    {
      scanf("%d %d",&m,&n);
      if(m+n>9999){
            if((19998-n-m)>m)
            count=ac(m,19998-n-m);
            else  count=ac(19998-m-n,m);
    }
    else
       {
           if(n>0) count=ac(m,m+n);
        else
            count=ac(m+n,m);}
    printf("%d\n",count);}
    return 0;
}
double ac(int a,int b)
{
    int c,sum=0;
    for(c=a;c<=b;c++){
        if(c%4==0&&c%100!=0||c%400==0)
            sum++;
    }
    return sum;
}
