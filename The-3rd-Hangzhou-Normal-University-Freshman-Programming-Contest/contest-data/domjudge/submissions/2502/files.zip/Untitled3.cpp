#include<stdio.h>
#include<string.h>
int main(){
	char j[3];
	scanf("%s",j);
	if(j[0]=='k'&&j[1]=='f'&&j[2]=='c'){
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/\n");	
	}
}
