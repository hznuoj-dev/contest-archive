#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(){
	int t,m,n,x,y,z,i,a[1000],j,k,p,q,s,r;
	
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++){
			a[i]=i;
		}
		while(m--){
			scanf("%d%d",&x,&y);
			for(i=1;i<=n;i++){
				if(a[i]==x){
					j=i;
				}
				if(a[i]==y){
					k=i;
				}
				
			}
			for(p=1;p<=k&&j>k;p++){ 
			if(p==k){
					z=a[j];
					r=a[p];
					a[p]=z;
					for(s=j-1;s>=p+1;s--){
						a[s+1]=a[s];
					}
					a[p+1]=r;
				}
			else	if(a[p]>a[j]){
					z=a[j];
					r=a[p];
					a[p]=z;
					for(s=j-1;s>=p+1;s--){
						a[s+1]=a[s];
					}
					a[p+1]=r;
					
					break;
				}
				
			}
			
		}
		for(i=1;i<=n;i++){
			 printf("%d ",a[i]);
		} 
		printf("\n");
	}
}

