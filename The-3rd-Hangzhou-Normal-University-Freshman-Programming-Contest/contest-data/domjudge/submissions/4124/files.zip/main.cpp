 #include <set>
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <cmath>
#include <ctime>
#include <bitset>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const int maxn = 1e5 + 10;
const int mod = 0;
const int inf = 0x3f3f3f3f;

int gcd(int a, int b) 
{
	return b==0?a:gcd(b,a%b);
}
struct node
{
	int a;
	int b;
}p[maxn];

int v[maxn];
int cmp(node x,node y)
{
	return x.a<y.a;}
int main()
{
int n,m;
cin>>n>>m;
int q[maxn];
int ans=1;
memset(v,0,sizeof v);
memset(q,0,sizeof q);
for(int i=1;i<=n;i++)cin>>p[i].a;
for(int i=1;i<=n;i++)cin>>p[i].b;
sort(p+1,p+1+n,cmp);
//for(int i=1;i<=n;i++)cout<<p[i].a<<endl;
ll num=0;
for(int i=1;i<=p[1].b;i++)
{
	if(i*p[1].a<=m){v[i*p[1].a]=1;num++;
	q[ans++]=p[1].a*i;}}

for(int i=2;i<=n;i++)
{
	int mm=ans;
	for(int j=1;j<=p[i].b;j++)
	{
			for(int k=1;k<mm;k++){
			if(v[q[k]+p[i].a*j]==0&&q[k]+p[i].a*j<=m)
			{
				num++;
				//cout<<q[k]+p[i].a*j<<endl;
				v[q[k]+p[i].a*j]=1;
				q[ans++]=q[k]+p[i].a*j;
			}
			}
		if(v[p[i].a*j]==0&&p[i].a*j<=m)
		{
			num++;
			v[p[i].a*j]=1;
			q[ans++]=p[i].a*j;
			}
	
	}
	
}
cout<<num<<endl;
return 0;
}
/*
3 10
1 2 4
2 1 12 74 22 534 151 2 3 41 2 3 4*/