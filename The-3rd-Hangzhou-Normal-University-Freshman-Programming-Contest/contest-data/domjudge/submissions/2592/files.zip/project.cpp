 #include<stdio.h>
int main() {
int n,a,b,i,c,d,e;
scanf("%d",&n);
while(n--){
	d=0;
	scanf("%d%d",&a,&b);
	if(a+b>=10000){
		b=9999-(a+b-9999);
	}
	else
	b=a+b;
	if(a>b){
	c=a;
	a=b;
	b=c;	
	}
	for(i=a;i<=b;i++){
		if((i%4==0&&i%100!=0)||i%400==0){
			d=d+1;
		}
	}
	printf("%d\n",d);
}
	} 

