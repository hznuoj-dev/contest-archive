#include<stdio.h>
int main(void){
	int t,n,m,y;
	double p;
	char c='%';
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		y=n-m;
		p=(double)m*100/n;
		printf("[");
		while(m--){
			printf("#");
		}
		while(y--){
			printf("-");
		}
		printf("] ");
		printf("%.0f",p);
		printf("%c\n",c);
	}
}
