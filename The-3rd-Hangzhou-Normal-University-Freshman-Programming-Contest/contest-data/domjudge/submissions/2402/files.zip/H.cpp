#include<bits/stdc++.h>
using namespace std;
int main()
{
	int T,n,m,i;
	double t;
	cin >> T;
	while(T--){
		cin >> n >> m;
		t=1.0*m/n*100;
		printf("[");
		for(i=1;i<=m;i++) printf("#");
		for(i=1;i<=n-m;i++) printf("-");
		printf("] %.0f%%\n",t);
	}
}
