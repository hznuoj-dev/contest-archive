import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{
            int n=sc.nextInt();
            while(n-->0)
            {
            	int y=sc.nextInt();
            	int b=sc.nextInt();
            	int y2=y+b;
            	if(y2>9999)
            	{
            		y2=9999-(y2-9999);
            	}
            	int c=0;
            	if(y2<y)
            	{
            		y=y^y2;
            		y2=y^y2;
            		y=y^y2;		
            	}
            	for(int i=y;i<=y2;i++)
            	{
            		if(run(i))
            		{
            			c++;
            		}
            	}
            	System.out.println(c);
            	
            }
		}

	}
	public static boolean run(int x)
	{
		if(x%4==0&&x%400!=0)
		{
			return true;
		}
		return false;
	}

}
