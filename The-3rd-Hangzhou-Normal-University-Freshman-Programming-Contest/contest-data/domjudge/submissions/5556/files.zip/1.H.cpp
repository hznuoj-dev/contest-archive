#include <stdio.h>
int main(void){
	int t,a,b;
	double c;
	scanf("%d",&t);
	while(t--){
		int i;
		scanf("%d %d",&a,&b);
		printf("[");
		for(i=0;i<b;i++){
			printf("#");
		}
		for(i=0;i<a-b;i++){
			printf("-");
		}
		c=b*1.0/a*100;
		printf("] ");
		printf("%2.lf",c);
		printf("%%\n");
	}
}