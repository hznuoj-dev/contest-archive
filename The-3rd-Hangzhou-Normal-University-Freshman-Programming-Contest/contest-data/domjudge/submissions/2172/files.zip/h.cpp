#include<stdio.h>
int main(){
	int a,b,c,d;
	scanf("%d",&a);
	while(a--){
		scanf("%d%d",&b,&c);
		d=c*100/b;
		printf("[");
		b=b-c;
		while(c--){
			printf("#");
		}
		while(b--){
			printf("-");
		}printf("] ");
		printf("%d%%\n",d);
	}
	return 0;
}
