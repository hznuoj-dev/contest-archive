#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
int cnt=0;
int go(int a);
int main()
{
	int a,b,c,d;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	go(a);
	go(b);
	go(c);
	go(d);
	if(cnt==1)
	{
		printf("Oh dear!!");
	}
	else if(cnt==2)
	{
		printf("BaoBao is good!!");
	}
	else if(cnt==3)
	{
		printf("Bao Bao is a SupEr man///!");
	}
	else if(cnt==4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!")
	;}
	else printf("Bao Bao is so Zhai......");
	return 0;
}
int go(int a)
{
	int t=a,b=0;
	while(t>=10)
	{
		b+=t/10;
		t/=10;
	}
	if(b>=16||b==6)
	{
		cnt++;
		return 1;
	}
}
