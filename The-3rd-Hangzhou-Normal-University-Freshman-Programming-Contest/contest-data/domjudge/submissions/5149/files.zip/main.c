#include <stdio.h>
//#include <stdlib.h>

int cmp(const void *p, const void *q);

int a[100000][100000], c[100000];


int main(int argc, char *argv[]) {
	int n, m, q, l, k;
	int i, j, index, tmp, b;
	
	scanf("%d", &n);
	for(i = 0; i < n; ++i) {
		scanf("%d", &m);
		for(j = 0; j < m; ++j) {
			scanf("%d", &a[i][j]);
		}
	}
	 
	scanf("%d", &q);
	for(i = 1; i <= q; ++i) {
		scanf("%d", &l);
		index = 0;
		for(j = 1; j <= l; ++j) {
			scanf("%d", &b);
			tmp = 0;
			while(a[b - 1][tmp] != 0) {
				c[index] = a[b - 1][tmp];
				++tmp;
				++index;
			}
		}
		qsort(c, index, sizeof(int), cmp);
		scanf("%d", &k);
		printf("%d\n", c[k - 1]);
	}
	
	return 0;
}

int cmp(const void *p, const void *q) {
	return *(int *)p - *(int *)q;
}
