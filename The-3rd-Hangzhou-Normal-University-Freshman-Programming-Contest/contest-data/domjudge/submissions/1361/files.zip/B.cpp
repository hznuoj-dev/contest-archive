#include<bits/stdc++.h>
using namespace std;

int main(void){

    int n;
    cin >> n;
    while(n--){
        int l,r;
        cin >> l >> r;
        if(l + r > 9999) r = 9999 - (l + r - 9999);
        else r = l + r;
        if(l > r){
            l += r;
            r = l - r;
            l = l - r;
        }
        int times = 0;
        for(l;l <= r;l++){
            if((l % 4 == 0 && l % 100 != 0) || l % 400 == 0) times++;
        }
        cout << times << endl;
    }

    return 0;
}