#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	int a, b, c, d;
	int num;
	long long tmp;
	
	scanf("%d%d%d%d", &a, &b, &c, &d);
	num = 0;
	tmp = 0;
	while(a) {
		tmp += a % 10;
		a /= 10;
	}
	if(tmp == 6 || tmp >= 16) {
		++num;
	}
	
	tmp = 0;
	while(b) {
		tmp += b % 10;
		b /= 10;
	}
	if(tmp == 6 || tmp >= 16) {
		++num;
	}
	
	tmp = 0;
	while(c) {
		tmp += c % 10;
		c /= 10;
	}
	if(tmp == 6 || tmp >= 16) {
		++num;
	}
	
	tmp = 0;
	while(d) {
		tmp += d % 10;
		d /= 10;
	}
	if(tmp == 6 || tmp >= 16) {
		++num;
	}
	
	switch(num) {
		case 0:
			printf("Bao Bao is so Zhai......\n");break;
		case 1:
			printf("Oh dear!!\n");break;
		case 2:
			printf("BaoBao is good!!\n");break;
		case 3:
			printf("Bao Bao is a SupEr man///!\n");break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");break;
	}
	
	return 0;
}
