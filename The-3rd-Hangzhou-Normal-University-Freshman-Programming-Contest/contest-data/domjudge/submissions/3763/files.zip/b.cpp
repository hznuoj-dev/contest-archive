#include<stdio.h>
int main()
{
	long int a[4];
	int i;
	long int x=0,sum=0,ssum=0;

	for(i=0;i<4;i++){
	   scanf("%ld",&a[i]);
	   while(a[i]!=0){
	   	sum=0;
	   	x=a[i]%10;
	   	sum+=x;
	   	a[i]/=10;
	   }
	   if((sum>=16)||(sum==6))
	     ssum=ssum+1;
	    } 
	    if(ssum==1)
	      printf("Oh dear!!");
	    if(ssum==2)
	      printf("BaoBao is good!!");
	    if(ssum==3)
	      printf("Bao Bao is a SupEr man///!");
	    if(ssum==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		if(ssum==0)
		  printf("Bao Bao is so Zhai......");
			return 0;
 } 
