#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	long long a,b,c,d;
	int cnt,sum=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
     while(a>0)
	{
	 sum +=a%10;
	 a=a/10;	
	}
	if(sum==6|sum>=16)
	 cnt++;
	 sum=0;
	while(d>0)
	{
	 sum +=d%10;
	 d=d/10;	
	}
	if(sum==6|sum>=16)
	 cnt++;
	 sum=0;
	      while(b>0)
	{
	 sum +=b%10;
	 b=b/10;	
	}
	if(sum==6|sum>=16)
	 cnt++;
	 sum=0;
	      while(c>0)
	{
	 sum +=c%10;
	 c=c/10;	
	}
	if(sum==6||sum>=16)
	 cnt++;
	if(cnt==0)  printf("Bao Bao is so Zhai......");
	if(cnt==1)  printf("Oh dear!!");
	if(cnt==2)  printf("BaoBao is good!!");
	if(cnt==3)  printf("Bao Bao is a SupEr man///!");
	if(cnt==4)  printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
