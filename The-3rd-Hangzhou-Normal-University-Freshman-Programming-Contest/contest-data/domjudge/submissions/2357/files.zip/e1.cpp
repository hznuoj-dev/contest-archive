#include<stdio.h>
int main() {
	char a[100];
	int i,j;
	scanf("%s",a);
	printf("  --      -----\n");
	printf(" |  | ___/ ____\\____\n");
	printf("\n");
	printf(" |  |/ /\\   __\\/ ___\\\n");
	printf("\n");
	printf(" |    <  |  | \\  \\___\n");
	printf("\n");
	printf(" |__|_ \\ |__|  \\___  >\n");
	printf("\n");
	printf("      \\/           \\/");
	return 0;
}


