#include <stdio.h>
int main()
{
	int T,n,m,a,b,i;
	scanf("%d",&T);
	while(T--)
	{
	scanf("%d %d",&n,&m);
	int list[n];
	for(i=0;i<m;i++)
	{
		scanf("%d %d",&a,&b);
		list[i]=a;
		list[i+1]=b; 
	}
	for(i=0;i<=n-1;i++)
	{
		printf("%d",list[i]);
		if(i<n-1)
			printf(" ");
  	}
	}
}
