#include<stdio.h>
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d%d",&n,&m);
		int p;
		p=100.0*m/n;
		printf("[");
		for(int i=0;i<m;++i)
			printf("#");
		for(int i=0;i<n-m;++i)
			printf("-");
		printf("] %d%%",p);
		printf("\n");
	}
}
