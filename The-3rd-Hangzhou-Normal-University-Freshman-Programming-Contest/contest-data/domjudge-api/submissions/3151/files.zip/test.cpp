#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
const int maxn=110;
int n,m,t,is,cnt,ans;
set<char>q;
char p[maxn];
int main(){
    ios::sync_with_stdio(false);
    cout<<fixed<<setprecision(2);
    cin>>t;
	while(t--) {
        ans=0;
		cin>>n;
		q.clear();
		for(int i=1; i<=n; i++){
			cin>>p;
			for(int k=0;k<strlen(p);k++){
				if(p[k]!='.')q.insert(p[k]);
			}
			ans+=q.size();
			q.clear();
		}
		cout<<ans<<"\n";
	}

    return 0;
    //good job!
}
