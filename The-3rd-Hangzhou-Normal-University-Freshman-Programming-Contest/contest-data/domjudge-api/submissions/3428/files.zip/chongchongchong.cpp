#include<stdio.h>
int q[10010]={0},n,m,a[110],sum=0,b[110],t,d=0,c[110],o=0;
void ooo(int x){
	for(int i=0;i<=b[c[x]];i++){
   		t=o;
		o+=a[c[x]]*i;
		if(x<n) ooo(++x);
		q[o]++;
		o=t;
	}
}
int main(){
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);c[i]=i;
		for(int j=0;j<i;j++){
		    if(a[c[i]]>a[c[j]]) {
			    t=c[j];c[j]=c[i];c[i]=c[j];
		    } 
	    }
    }
	for(int i=0;i<n;i++){
		scanf("%d",&b[i]);
	}
	ooo(0);
	for(int i=1;i<=m;i++){
		if(q[i]) sum++;
	}
	printf("%d",sum);
	return 0;
} 
