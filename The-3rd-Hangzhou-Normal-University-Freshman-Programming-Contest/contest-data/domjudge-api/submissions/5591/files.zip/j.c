#include <stdio.h>
#include <string.h>
int main() {
	int t, n, i, j,m,q,l,c=0,d;
	static char a[1000000],b[1000000];
	scanf("%d", &t);
	while (t--) {
		c = 0;
		scanf("%d", &n);
		for (i = 0; i < n; i++) {
			scanf("%s", a);
			m = strlen(a);
			q = 0;
			for (j = 0; j < m; j++) {
				d = 0;
				if (a[j] != '.') {
					if (q == 0) {
						b[q] = a[j];
						q = 1;
					}
					else {
						for (l = 0; l< q; l++) {
							if (b[l] == a[j]) {
								break;
							}
							else {
								d++;
							}
						}
						if (d == q) {
							b[q] = a[j];
							q++;
						}
					}
				}
			}
			c = c + q;
			memset(a, '\0', sizeof(a));
			memset(b, '\0', sizeof(b));
		}
		printf("%d\n", c);
	}
}
