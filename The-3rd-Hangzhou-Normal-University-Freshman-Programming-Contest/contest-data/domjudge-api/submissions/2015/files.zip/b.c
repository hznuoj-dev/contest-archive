#include<stdio.h>
int main(){
	int x,a,b,s;
	scanf("%d",&x);
	while(x--){
		s=0;
		scanf("%d %d",&a,&b);
		b=a+b;
		if(b>9999){
			int c=b-9999;
			b=9999-c;
		}
		if (a>b){
			int c=a;
			a=b;
			b=c;
		}
		for(a;a<=b;a++){
			if(a%400==0 || (a%4==0 && a%100!=0)){
				s++;
			}
		}
		printf("%d\n",s);
	}
	return 0;
}

