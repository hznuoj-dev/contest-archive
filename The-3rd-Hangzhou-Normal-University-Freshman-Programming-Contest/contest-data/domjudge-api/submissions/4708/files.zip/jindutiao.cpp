#include<stdio.h>
#include<math.h>
int main(void){
	int T;
	scanf("%d",&T);
	if(T<=10&&T>=0)
	while(T--){
		int a,b,n;
		double x;	
		scanf("%d%d",&a,&b);
		if(a>=0&&a<=100000&&b>=0&&b<=a){
		printf("[");
		for(n=0;n<b;n++)
		printf("#");
		for(n=0;n<(a-b);n++)
		printf("-");
		printf("]");
		x=((double)b/(double)a)*100;
		printf(" %.0f%%\n",floor(x));}
	}
	return 0;
}
