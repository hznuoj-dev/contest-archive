#include<stdio.h>
int main(){
	int a,b,c,d;
	int x,s1=0,s2=0,s3=0,s4=0;
	int f=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	while(a>0){
		x=a%10;
		a=a/10;
		s1+=x; 
	}
	while(b>0){
		x=b%10;
		b=b/10;
		s2+=x;
	}
	while(c>0){
		x=c%10;
		c=c/10;
		s3+=x;
	}
	while(d>0){
		x=d%10;
		d=d/10;
		s4+=x;
	}
	if(s1==6||s2>=16){
		f+=1;
	}
	if(s2==6||s2>=16){
		f+=1;
	}
	if(s3==6||s3>=16){
		f+=1;
	}
	if(s4==6||s4>=16){
		f+=1;
	}
     if(f==1) printf("Oh dear!!");
     if(f==2) printf("BaoBao is good!!");
     if(f==3) printf("Bao Bao is a SupEr man///!");
     if(f==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
     if(f==0) printf("Bao Bao is so Zhai......");
     return 0;
}
