#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
int p[1230];
int main(){
	int t;
	int n,m;
	scanf("%d",&t);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++){
		p[i]=i;
	}
	while(m--){
		
		int a,b;
		
		scanf("%d %d",&a,&b);
		if(p[a]>p[b]&&a>b){//�������ǵ�����λ�ã�����������ֻ 
			int t=p[b];
			for(int i=b;i<=a-1;i++){
				p[i]=p[i+1];
			}
			p[a]=t;

		}
		else if(p[a]>p[b]&&a<b){
			int t=p[a];
			p[a]=p[b];
			p[b]=t;
		}
//		for(int i=1;i<=n;i++){
//		printf("%d%c",p[i],i==n?'\n':' ');
//	}
	}
//	for(int i=1;i<=n;i++){
//		printf("%d%c",p[i],i==n?'\n':' ');
	int count=1;
	while(count!=n+1){
		for(int i=1;i<=n;i++){
			if(p[i]==count){
				printf("%d%c",i,count==n?'\n':' ');
				count++;
			}
		}
	}
}
