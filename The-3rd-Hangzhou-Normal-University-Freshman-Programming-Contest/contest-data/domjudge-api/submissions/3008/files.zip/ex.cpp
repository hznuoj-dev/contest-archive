#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
const int maxn=1e5+10;
int n,m,t,is,cnt,ans;
bool jud(int x){
    int sum=0;
    while(x){
        sum+=(x%10);
        x/=10;
    }
    if(sum==6||sum>=16)return true;
    return false;
}
int main(){
    ios::sync_with_stdio(false);
    cout<<fixed<<setprecision(2);
    ll a,b,c,d,sum=0;
    cin>>a>>b>>c>>d;
    if(jud(a))++sum;
    if(jud(b))++sum;
    if(jud(c))++sum;
    if(jud(d))++sum;
    if(sum==0)cout<<"Bao Bao is so Zhai......"<<"\n";
    else if(sum==1)cout<<"Oh dear!!"<<"\n";
    else if(sum==2)cout<<"BaoBao is good!!"<<"\n";
    else if(sum==3)cout<<"Bao Bao is a SupEr man///!"<<"\n";
    else if(sum==4)cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<"\n";
    return 0;
    //good job!
}
