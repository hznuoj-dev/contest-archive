#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i, cnt=0;
	char a[100000];
	char b[100000];
	char c[100000];
	char d[100000];
	scanf("%s", a);
	scanf("%s", b);
	scanf("%s", c);
	scanf("%s", d);
    int len=strlen(a);
    int total=0;
    for(i=0;i<len;i++){
    	a[i]=a[i]-'0';
    	total+=a[i];
		}
    if(total>=16||total==6)
    cnt++;
    int x=strlen(b);
    int sum=0;
    for(i=0;i<x;i++){
    	b[i]=b[i]-'0';
    	sum+=b[i];
        }
    if(sum>=16||sum==6)
    cnt++;
	int y=strlen(c);
	int t=0;
	for(i=0;i<y;++i){
		c[i]=c[i]-'0';
		t+=c[i];
		}
	if(t>=16||t==16)
	cnt++;
	int z=strlen(d);
	int s=0;
	for(i=0;i<z;++i){
		d[i]=d[i]-'0';
		s+=d[i];
		}
	if(s>=16||s==16)
	cnt++;
	if(cnt==0)
	printf("Bao Bao is so Zhai......\n");
	else if(cnt==1)
	printf("Oh dear!!\n");
	else if(cnt==2)
	printf("BaoBao is good!!\n");
	else if(cnt==3)
	printf("Bao Bao is a SupEr man///!\n");
	else
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
