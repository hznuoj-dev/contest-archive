#include<bits/stdc++.h>
using namespace std;
#define MOD 998244353
long long int a[100005];
long long int jc(int n)
{
	int sum=1;
	for(int i=1; i<=n; i++) sum=sum*i%MOD;
	return sum%MOD;
}
long long int com(long long int m,long long int n)
{
	if(n<=m) return 1;
	return jc(n)%MOD/(jc(m)%MOD)/(jc(n-m)%MOD)%MOD;
}
int main()
{
	int n; cin>>n;
	int maxx=0;
	for(int i=1; i<=n; i++)
	{
		int x; cin>>x;
		a[x]++;
		if(x>maxx) maxx=x; 
	}
	long long int sum=1;
	for(int i=1; i<=maxx; i++)
	{
		//printf("a[i]=%d; a[i-1]=%d; com()=%d \n",a[i],a[i-1],com(a[i-1],a[i]));
		sum=sum%MOD*com(a[i-1],a[i])%MOD;
	}
	printf("%lld",sum);
	return 0;
}
