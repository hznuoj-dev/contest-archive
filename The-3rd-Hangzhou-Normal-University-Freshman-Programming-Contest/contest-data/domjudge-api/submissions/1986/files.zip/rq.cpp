#include<stdio.h>
int f(int year)
{
	if((year%4)==0&&(year%100)!=0)
		return 1;
	else if(year%400==0)
		return 1;
	else return 0;
}
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int Y,A,t=0,score=0;
		scanf("%d %d",&Y,&A);
		if((Y+A)>=9999)
			t=9999-(Y+A-9999);
		else
			t=Y+A;
		if(Y<=t)
		{
			for(int i=Y;i<=t;i++)
			{
				if(f(i))
					score=score+1;
			}
		}
		else{
			for(int j=t;j<=Y;j++)
			{
				if(f(j))
					score=score+1;
			}
		}
		printf("%d\n",score);
	}
}
/*
#include<stdio.h>
int main()
{
	int n,T,m,p;
	int team[501],problemid[501],timestamp[501],recod[501];
	scanf("%d %d %d %d",&n,&T,&m,&p);
	for(int i=0;i<m;i++)
	{
		char s[2];
		scanf("%d %%d %d",&team[i],&problemid[i],&timestamp[i]);
		scanf("%s",s);
		if(s[0]=='A'&&s[1]=='C')
			recod[i]=1;
		else
			recod[i]=0;
	}
	int q;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{

	}
	return 0;
}*/