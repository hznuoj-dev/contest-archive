#include<stdio.h>
#include<string.h>
int main(void){
    int t,n,i,b,sum;
    int c[128];
    char a[1000006];
    scanf("%d",&t);
    while(t--){
    	scanf("%d",&n);
    	sum=0;
    	while(n--){
    		scanf("%s",a);
    		b=strlen(a);
    		for(i=0;i<128;i++){
    			b[i]=0;
			}
			for(i=0;i<b;i++){
				if(a[i]=='.'){
					continue;
				}
				else if(b(a[i])==0){
					b(a[i])=1;
					sum++;
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
