#include <stdio.h>
int rn(int n){
	if (n%400==0||(n%4==0&&n%100!=0)) return 1;
	else return 0;
}
int main(){
	int i,t,y,a,ma,sum;
	scanf("%d",&t);
	while (t--){
		sum=0;
		ma=0;
		scanf("%d %d",&y,&a);
		if (a>=0){
		if (y+a>9999) {
			a=a-(9999-y);
			ma=9999-a;
		}
		else {
			ma=a+y;
		}
		if (ma>y){
		for (i=y;i<=ma;i++){
			if (rn(i)) sum++;
		}
		}
		else {
			for (i=ma;i<=y;i++){
			if (rn(i)) sum++;
		}
		}
		}
		else {
			for (i=y+a;i<=y;i++){
			if (rn(i)) sum++;
			}
		}
		printf("%d\n",sum);
	}
}
