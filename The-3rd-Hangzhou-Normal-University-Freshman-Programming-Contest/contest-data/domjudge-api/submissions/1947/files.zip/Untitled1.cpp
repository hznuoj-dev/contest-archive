#include<stdio.h>
int main(){
	char a[20];
	int n = 4, num = 0;
	int i,j,sum;
	while(n--){
		scanf("%s", a);
		getchar();
		sum = 0;
		for(i=0;a[i]!='\0';i++){
			sum += a[i]-48;
		}
		if(sum >= 16 || sum == 6){
			num++;
		}
	}
	if(num == 0){
		printf("Bao Bao is so Zhai......\n");
	}else if(num == 1){
		printf("Oh dear!!\n");
	}else if(num == 2){
		printf("BaoBao is good!!");
	}else if(num == 3){
		printf("Bao Bao is a SupEr man///!");
	}else if(num == 4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
} 
