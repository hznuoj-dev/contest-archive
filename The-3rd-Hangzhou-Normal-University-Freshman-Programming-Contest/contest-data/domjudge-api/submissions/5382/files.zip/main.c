#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int t;
    scanf("%d",&t);
    while(t--){
    	int n, m, a, i;
    	scanf("%d%d",&n,&m);
    	a=m*100/n;
    	for(i=0;i<=m;++i){
    		if(i==0)
    		printf("[");
    		else
    		printf("#");
		}
		for(i=m+1;i<=n+1;++i){
			if(i==n+1)
			printf("] ");
			else
			printf("-");
		}
		printf("%d%%\n",a);
	}
	return 0;
}
