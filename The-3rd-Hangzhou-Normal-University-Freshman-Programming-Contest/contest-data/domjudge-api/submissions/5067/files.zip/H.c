#include<stdio.h>
int main(void){
long int n,a,b,i,j,t;
scanf("%ld",&n);
while(n--){
scanf("%ld%ld",&a,&b);
if(b>a)
t=a,a=b,b=t;
printf("[");
i=a-b;
j=b;
while(j--)
printf("#");
while(i--)
printf("-");
printf("] ");
printf("%.lf%%\n",(double)b/(double)a*100);
} 
return 0;}

