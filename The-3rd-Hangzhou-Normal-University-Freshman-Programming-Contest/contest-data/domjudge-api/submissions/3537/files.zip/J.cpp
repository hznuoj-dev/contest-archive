#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int main(void) {
    int T;
	scanf("%d",&T);
	while(T--){
		int n,i,j,c=0;
		scanf("%d",&n);
		char s[n][81];
		int l[n];
		for(i=0;i<n;i++){
		    scanf("%s",&s[i]);
		    l[i]=strlen(s[i]);
	    }
	    c=0;
	    for(i=0;i<n;i++){
	    	for(j=0;j<l[i];j++){
	    		if(s[i][j]!='.'){
	    			int flag=1,k;
	    			for(k=j-1;k>=0;k--){
	    				if(s[i][j]==s[i][k]){
	    					flag=0;
						}
					}
					if(flag==1){
						c+=1;
					} 
				}
			}
		}
		printf("%d\n",c);
	} 
return 0;
}

