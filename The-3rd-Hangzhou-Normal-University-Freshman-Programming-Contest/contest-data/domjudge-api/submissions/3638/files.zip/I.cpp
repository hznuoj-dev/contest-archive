#include<stdio.h>
#include<math.h>
#include<string.h>

int main()
{
	char a[4][20];
	int s=0;
	for(int i=0;i<4;++i)
		scanf("%s",a[i]);
	for(int i=0;i<4;++i){
		int m=0;
		for(int j=0;j<strlen(a[i]);++j){
			m=m+a[i][j]-'0';
		}
		if(m>=16 || m==6)
			s++;
	}
	if(s==0)
		printf("Bao Bao is so Zhai......");
	else if(s==1)
		printf("Oh dear!!");
	else if(s==2)
		printf("BaoBao is good!!");
	else if(s==3)
		printf("Bao Bao is a SupEr man///!");
	else
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
} 
