#include<stdio.h>
main() 
{
	char a[10];
	scanf("%s",a);
	if(a[0]='k'&&a[1]=='f'&&a[2]=='c')
	{
		printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/");
	}

}
