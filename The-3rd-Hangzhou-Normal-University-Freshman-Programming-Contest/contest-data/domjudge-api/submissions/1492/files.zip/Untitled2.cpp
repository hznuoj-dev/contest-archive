#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6;
const int INF=0x3f3f3f3f;
ll dp[N];
int value[N];
int num[N];
int n,m;
int main(){
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;++i)
		scanf("%d",&value[i]);
	for(int i=1;i<=n;++i)
		scanf("%d",&num[i]);
	int ans=0;
	for(int i=1;i<=n;++i){
		for(int k=1;num[i];k=k<<1){
			k=min(num[i],k);
			num[i]-=k;
			int temp=value[i]*k;
			for(int j=m;j>=temp;--j){
				dp[j]=max(dp[j],dp[j-temp]+temp);
			}
		}
	}
	for(int i=1;i<=m;++i)
		//printf("%d %d\n",i,dp[i]);
		if(dp[i]==i) ans++;
	printf("%d\n",ans); 
	return 0;
}
