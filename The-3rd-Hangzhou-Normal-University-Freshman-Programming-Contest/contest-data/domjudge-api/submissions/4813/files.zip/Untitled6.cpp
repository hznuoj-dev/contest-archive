
#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>


using namespace std;

char s[1111111];


int main(){
	int n, i, l;
	long long count=0;
	cin >> n;
	for(i=0;i<n;i++){
		cin >> s;
		l=strlen(s);
		count +=l;
	}
	cout << count << endl;
	return 0;
}
