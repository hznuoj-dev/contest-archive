#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	long int a,b,c,d;
	int i,t=0;
	int sum=0;
	scanf("%ld %ld %ld %ld",&a,&b,&c,&d);
	for(i=0;a>0;i++){
		t=t+a%10;a=a/10;
	} 
	if(t==6||t>=16){
		sum=sum+1;
	}
	t=0;
	for(i=0;b>0;i++){
		t=t+b%10;b=b/10;
	} 
	if(t==6||t>=16){
		sum=sum+1;
	}
	t=0;
	for(i=0;c>0;i++){
		t=t+c%10;c=c/10;
	} 
	if(t==6||t>=16){
		sum=sum+1;

	}
	t=0;
	for(i=0;d>0;i++){
		t=t+d%10;d=d/10;
	} 
	if(t==6||t>=16){
		sum=sum+1;
	}
	t=0;
    if(sum==1){
    	printf("Oh dear!!\n");
	}
	else if (sum==2)
	{
		printf("BaoBao is good!!\n");
	}
	else if (sum==3)
	{
		printf("Bao Bao is a SupEr man//////!\n");
	}
	else if (sum==4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	else
	{
		printf("Bao Bao is so Zhai......\n");
	}
	return 0;
}
