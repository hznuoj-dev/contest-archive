#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int main(){
    int n,cs;
    cin>>n;
    char a[20];
    int cnt[200],ans;
    memset(cnt, 0, sizeof(cnt));
    while(n--){
        ans = 0;
        cin >> cs;
        while(cs--){
            cin >> a;
            for(int i= 0;i<strlen(a);i++){
                if(a[i]=='.')
                    continue;
                else{
                    if(cnt[a[i]]==0){
                    cnt[a[i]]++;
                    ans ++;
                    }
                }
            }
            memset(cnt, 0, sizeof(cnt));
            memset(a, 0, sizeof(a));
        }
        cout << ans <<endl;
    }
    return 0;
}

    

