#include<iostream>

using namespace std;

int main()
{
    int rate,tol,j,al,i,n;
    cin >> n;
    for(i=1;i<=n;i++)
    {
        cin >> tol >> al;
        cout << '[';
        for(j=0;j<al;j++)
        {
            cout <<'#';
        }
        for(j=0;j<(tol-al);j++)
        {
            cout << '-';
        }
        cout << "] ";
        rate=al*100/tol;
        cout << rate << '%' <<endl;


    }
    
    return 0;
}