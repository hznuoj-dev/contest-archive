#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n, sum=0;
	string s;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
    	cin>>s;
   		sum+=+s.length();
    }
    cout<<sum;
    return 0;
}
