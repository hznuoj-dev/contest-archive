#include<stdio.h>
int main(){
	int t;
	long long n,m;
	double a; 
	int b;
	if(scanf("%d",&t)){
		while(t--){
			if(scanf("%lld%lld",&n,&m)){
				a=m*1.0/n;
				b=a*100;
				printf("[");
				for(int i=0;i<m;i++){
					printf("#");
				}
				for(int j=0;j<n-m;j++){
					printf("-");
				}
				printf("]");
				printf(" ");
				printf("%d",b);
				printf("%%\n");
			}
		}
	}
	return 0;
} 
