#include <stdio.h>
#include <string.h>

int u[256];

int pd(int a)
{
	if(u[a]==0)
	{
		u[a]=1;
		return 1;
	}
	return 0;
}

int main(void)
{
	int t,n,shu,i;
	char a[1000010];
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		shu = 0;
		getchar();
		while(n--)
		{
			gets(a);
			for(i = 0;i <257;i++)
			{
				u[i]=0;
			}
			i = 0;
			while(a[i] != '\0')
			{
				if(a[i]!='.')
				{
					shu += pd(a[i]);
				}
				i++;
			}
		}
		printf("%d\n",shu);
	}
	
	return 0;
}
