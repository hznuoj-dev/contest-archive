#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int t;
	scanf("%d",&t);
	while(t--){
		int i,y,a,min=0,max=0,n=0;
		scanf("%d %d",&y,&a);
		   if (y+a>9999&&y>9999-y-a+9999){
		   min=9999-y-a+9999;	
		   max=y;}
		   else if(y+a>9999&&y<=9999-y-a+9999) {
		   min=y;
		   max=9999-y-a+9999;}
		   else if(y+a<=9999&&y<y+a) {
		  min=y;
		  max=y+a;	 }
		   else if (y+a<=9999&&y>=y+a) {
		   	min=y+a;
			   max=y;
		   }
		for (i=min;i<=max;++i){
			if ((i % 4==0 && i%100!=0)||( i%400)==0){
				n++;
			}		
		}
		printf("%d\n",n);
	} 
	return 0;
}
