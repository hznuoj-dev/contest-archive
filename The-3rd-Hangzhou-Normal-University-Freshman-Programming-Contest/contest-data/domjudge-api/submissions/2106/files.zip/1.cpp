#include<stdio.h>
#include<string.h>
int main()
{
	char s[25];
	int i, sum, cnt = 0, j;
	for (i = 0; i < 4; i++)
	{
		sum = 0;
		scanf("%s", s);
		for (j = 0; j < strlen(s); j++)
			sum += s[j] - '0';
		if (sum == 6 || sum >= 16)
			cnt++;
	}
	if (cnt == 0)
		printf("Bao Bao is so Zhai......");
	else if (cnt == 1)
		printf("Oh dear!!");
	else if (cnt == 2)
		printf("BaoBao is good!!");
	else if (cnt == 3)
		printf("Bao Bao is a SupEr man///!");
	else
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
