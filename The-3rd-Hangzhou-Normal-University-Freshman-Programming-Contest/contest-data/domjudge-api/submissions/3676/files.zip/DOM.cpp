#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int main(){
    
    int n,cs,temp;
    int len;
    cin>>n;
    char a[1000010];
    int cnt[500],ans;
    memset(cnt, 0, sizeof(cnt));
    while(n--){
        ans = 0;
        cin >> cs;
        while(cs--){
            cin >> a;
            len = strlen(a);
            for(int i= 0;i<len;i++){
                temp = a[i];
                if(a[i]=='.')
                    continue;
                else{
                    if(cnt[temp]==0){
                    cnt[temp]++;
                    ans ++;
                    }
                }
            }
            memset(cnt, 0, sizeof(cnt));
            memset(a, 0, sizeof(a));
        }
        cout << ans <<endl;
    }
    return 0;
    

