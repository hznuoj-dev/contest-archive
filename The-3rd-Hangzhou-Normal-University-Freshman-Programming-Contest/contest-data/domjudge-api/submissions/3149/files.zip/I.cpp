#include<stdio.h>
int sjzsf(long long x);
int main(){
	long long a,b,c,d;
	int i,num;
	num=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	if(sjzsf(a))
	num+=1;
	if(sjzsf(b))
	num+=1;
	if(sjzsf(c))
	num+=1;
	if(sjzsf(d))
	num+=1;
	if(num==1)
	printf("Oh dear!!");
	else if(num==2) 
	printf("BaoBao is good!!");
	else if(num==3)
	printf("Bao Bao is a SupEr man///!");
	else if(num==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else
	printf("Bao Bao is so Zhai......");
}
int sjzsf(long long x){
	int sum,b;
	sum=0;
	b=0;
	while(x!=0){
		b=b+x%10;
		x=x/10;
	}
	if(b>=16||b==6)
	return 1;
	else
	return 0;
} 
