#include<math.h>
#define PI 3.1415926
#include <string.h>
#include<stdio.h>
#include<ctype.h>

int check(int a,int b){
	int sum=0;
	for(;a<=b;a++){
		if((a%4==0&&a%100!=0)||(a%100==0&&a%400==0)){
			sum++;
		}
	}
	return sum;
}


int main()
{
	int T,a,b;
	scanf("%d",&T);
	while(T--){
		int year,y;
		scanf("%d %d",&year,&y);
		if(year+y>9999){
			b=9999-(year+y-9999);
			a=year;
		}
		else if(y>0){
			a=year;
			b=year+y;
		}
		else {
			a=year+y;
			b=year;
		}
		printf("%d\n",check(a,b));
	}
	




return 0;
}
