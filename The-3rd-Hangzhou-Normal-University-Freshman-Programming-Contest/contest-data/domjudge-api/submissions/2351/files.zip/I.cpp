#include <stdio.h>
int  ss(long long int x){
	long long int s=0;
	while(x>0){
		s+=x%10;
		x/=10;
	}
	if(s>=16 || s==6){
		return 1;
	}else{
		return 0;
	}
}

int main()
{
	long long int a,b,c,d,n=0;
	scanf("%lld",&a);
	scanf("%lld",&b);
	scanf("%lld",&c);
	scanf("%lld",&d);
	n=ss(a)+ss(b)+ss(c)+ss(d);
	switch(n){
		case 0:
			printf("Bao Bao is so Zhai......\n");
			break;
		case 1:
			printf("Oh dear!!\n");
			break;
		case 2:
			printf("BaoBao is good!!\n");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!\n");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
			break;
	} 
	return 0;
}
