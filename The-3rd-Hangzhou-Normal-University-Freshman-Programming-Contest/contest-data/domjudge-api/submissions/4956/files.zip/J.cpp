#include <stdio.h>
#include<string.h>
#define STRING_LENGTH 10000
int length(const char *str); 
int main ()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int sum=0;
		int n;
		scanf("%d",&n);
		
		while(n--)
		{
			int i,t,a=1,lengtha;
			char stra[STRING_LENGTH+1];
			char rub[STRING_LENGTH+1];
			scanf("%s",stra);
			lengtha=length(stra);
			for(i=0;i<lengtha;i++)
			{
				if(stra[i]!='.')
				{
					
					for(t=0;t<i;t++)
					{
						if(stra[i]==rub[t])
						a=0;
					}
					if(a==1)
					{
						rub[i]=stra[i];
						sum+=1;
					}
				}
				a=1;
			}	
		}
		printf("%d\n",sum);
	
	}
	return 0;
}
int length(const char *str)
{
	int i=0;
	while(str[i]!='\0')
		++i;
	return i;
}
