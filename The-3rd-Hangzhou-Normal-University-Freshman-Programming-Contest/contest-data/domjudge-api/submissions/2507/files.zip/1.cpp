#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,y,a;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        int coun=0;
        int s,s1,s2;
        cin>>y>>a;
        if(y+a>=10000)
        {
            s=9999-(y+a-9999);
            if(y<=s)
            {
                s1=y;
                s2=s;
            }
            else
            {
                s1=s;
                s2=y;
            }
        }
        else
        {
            if(a>=0)
            {
            s1=y;
            s2=y+a;
            }
            else
            {
                s1=y+a;
                s2=y;
            }
        }
        for(int j=s1;j<=s2;j++)
        {
            if((j%4==0&&j%100!=0)||j%400==0)
                coun++;
        }
        cout<<coun<<endl;
    }
    return 0;
}
