#include<stdio.h>
char a[102][1000001];
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		
		int n,s=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%s",a[i]);
		}
		for(int i=0;i<n;i++){
			for(int j=0;a[i][j]!='\0';j++){
				if(a[i][j]!='.'){
					s++;
					for(int k=j+1;a[i][k]!='\0';k++){
					if(a[i][k]==a[i][j]){
						a[i][k]='.';
					}
				}
			}
			}
		}
		printf("%d\n",s);
	}
}
