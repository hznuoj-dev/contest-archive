#include<stdio.h>
int main()
{
	int t,a,b,c,count,i;
	scanf("%d",&t);
	while(t--)
	{
		count=0;
		scanf("%d %d",&a,&b);
		if((a+b)>=10000)
		{
			b=9999*2-a-b;
		}
		else
		{
		  
		  b=a+b;
		  }
		if(a>b)
		{
			c=a;
			a=b;
			b=c;
		}
		for(;a<=b;a++)
		{
			if((a%4==0&&a%100!=0)||a%400==0)
		{
				count++;}
	
		}
		printf("%d\n",count);
	}
	
	
	
}
