#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(void){
	char a[20],b[20],c[20],d[20];
	scanf("%s %s %s %s",a,b,c,d);
	int sum=0,j,ta,tb,tc,td,flag=0;
	int lena,lenb,lenc,lend;
	lena=strlen(a);
	lenb=strlen(b);
	lenc=strlen(c);
	lend=strlen(d);
	for(j=0;j<lena;j++){
		if(a[j]=='6'){
			flag=1;
			break;
		}
		ta=ta+atoi(a[j]);
	}
	if(flag==1 || ta>=16) sum++;
	
	flag=0;
	for(j=0;j<lenb;j++){
		if(b[j]=='6'){
			flag=1;
			break;
		}
		tb=tb+atoi(b[j]);
	}
	if(flag==1 || tb>=16) sum++;
	
	flag=0;
	for(j=0;j<lenc;j++){
		if(c[j]=='6'){
			flag=1;
			break;
		}
		tc=tc+atoi(c[j]);
	}
	if(flag==1 || tc>=16) sum++;
	
	flag=0;
	for(j=0;j<lend;j++){
		if(d[j]=='6'){
			flag=1;
			break;
		}
		td=td+atoi(d[j]);
	}
	if(flag==1 || td>=16) sum++;
	
	if(sum==0)printf("Bao Bao is so Zhai......\n");
	else if(sum==1)printf("Oh dear!!\n");
	else if(sum==2)printf("BaoBao is good!!\n");
	else if(sum==3)printf("Bao Bao is a SupEr man////!\n");
	else printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
