#include <stdio.h>
int main(void)
{
	int T;
   double q,n,m;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%lf %lf\n",&n,&m);
		q=(1.0*m/n)*100;
		printf("[");
		while(m--)
		printf("#");
		while(n--)
		printf("-");
		printf("] %0.lf%%\n",q);
	
	}
	return 0;
}
