#include<stdio.h>
int main() {
	int t, a, b, c, d, s=0, i;
	scanf("%d", &t);
	while (t--)
	{
		s = 0;
		scanf("%d%d", &a, &c);
			b = a + c;
		if (b>9999)
		{
			b = 19998 - b;
		}
		if (a>b)
		{
			d = b;
			b = a;
			a = d;
		}
		for ( i = a; i <=b; i++)
		{
			if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				s++;
		}
		printf("%d\n", s);
	}
	return 0;
}