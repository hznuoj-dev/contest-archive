#include<stdio.h>
#include<string.h>
int main(){
	int n,len;
	scanf("%d",&n);
    char s[100010];
    for(int i=0;i<n;i++){
    	scanf("%s",s);
	}
	len=strlen(s);
	printf("%d",len*n);
    return 0;
}
