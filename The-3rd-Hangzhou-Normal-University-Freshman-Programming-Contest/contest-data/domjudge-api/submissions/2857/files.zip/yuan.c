#include<stdio.h>
#include<string.h>


int main(){
	int t;
	int m,n;
	scanf("%d",&t);
	while(t--)
	{
		int i,k,h;
		scanf("%d%d",&n,&m);
		k=100*m/n;
		printf("%c",91);
		for(i=0;i<m;i++)
		{
			printf("%c",35);
		}
		for(i=0;i<n-m;i++)
		{
			printf("-");
		}
		printf("%c",93);
		printf("%d%c\n",k,37);
	}


return 0;
}
