#include<stdio.h>
#include<string.h>
#define max 100
int main()
{
	int t,n,i,j,k,x,len,m,gs,cnt;
	char str[max+1],str1[max+1];
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		getchar();
		gs=0;
		for(k=1;k<=n;k++)
		{
			for(i=0;i<max+1;i++)  
			{
				str1[i]='.';
			}
			scanf("%s",str);
			getchar();
			len=strlen(str);  //$#$
			m=0;  
			cnt=0;
			for(i=0;i<len;i++)   //len=3
			{
				if(str[i]!='.') 
				{
					for(j=0;j<=m;j++)
					{
						if(str[i]==str1[j])  
						{
							break;
						}
					}
					 
					if(j>m)  //û����ͬ 
					{
						x=0; 
						while(str1[x]!='.') 
						{
							x+=1;
						} //��һ����Ϊ.�� 
						str1[x]=str[i]; //��¼�������� 
						cnt+=1;
					}
					m=x; //���һ������������ m=0 
				}
			}
			gs=gs+cnt;
		}
		printf("%d\n",gs);
	}
}

