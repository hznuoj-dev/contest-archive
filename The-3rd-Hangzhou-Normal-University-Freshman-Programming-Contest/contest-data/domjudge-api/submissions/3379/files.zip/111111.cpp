#include<stdio.h>
#include<string.h>
int main(void)
{
	int T,a,b,n,m,i,j,t;
	double k;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&n,&m);
		k=100.0*m/n;
		printf("[");
		for(i=1;i<=m;i++)
		{
			printf("#");
		}
		for(j=n-m+1;i<=n;i++)
		{
			printf("-");
		}
		printf("]");
		printf(" %.0lf%%\n",k);
	}
	return 0;
}
