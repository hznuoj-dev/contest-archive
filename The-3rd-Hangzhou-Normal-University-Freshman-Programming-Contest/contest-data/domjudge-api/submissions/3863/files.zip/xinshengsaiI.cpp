#include<stdio.h>
#include<string.h>
int main()
{
    char s = '%';
    int T, i;
    int n, m;
    double sum;
    scanf("%d", &T);
    while (T--)
    {
        sum = 0.0;
        scanf("%d%d", &n, &m);
        sum = (double)m / n * 100.0;
        printf("[");
        for (i = 1; i <= m; i++)
        {
            printf("#");
        }
        for (i = 1; i <= n - m; i++)
        {
            printf("-");
        }
        printf("] ");
        printf("%.0f", sum);
        printf("%c\n", s);
    }
    return 0;
}