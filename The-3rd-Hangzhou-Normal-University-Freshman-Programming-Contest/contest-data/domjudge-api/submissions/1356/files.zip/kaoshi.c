﻿#include <stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
#define PI 3.14159
#include<math.h>
#pragma warning(disable:4996)


int  main() {
	int f(int m, int n);
	int maxn(int x, int y);
	int minn(int x, int y);
	int t, y, a,x,l;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &y, &a);
		if (y + a > 9999) {
			x = y + a - 9999;
			l = 9999 - x;
		}
		else { l = y + a; }
		int k = f(minn(y,l),maxn(y,l));
		printf("%d\n", k);
	}
	return 0;
}
int f(int m, int n) {
	int sum = 0;
	for (int i = m;i <= n;++i) {
		if (i % 4 == 0 && i % 100 != 0) { sum+=1; }
		else if (i % 400 == 0) { sum += 1; }
	}	
		return sum;
	}
int maxn(int x, int y) {
	return x > y ? x : y;
}
int minn(int x, int y) {
	return x < y ? x : y;
}