# include<stdio.h>
int main()
{
	int t,y,a,y1,i,sum,temp;
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d%d",&y,&a);
		if(y+a>=10000)
			y1=19998-y-a;
		else
			y1=y+a;
		if(y>y1)
			{temp=y;y=y1;y1=temp;};
		for(i=y;i<=y1;++i){
			if(i % 4==0&&i % 100!=0||i % 400==0)
				sum++;
		}
		printf("%d\n",sum);
	}
}
