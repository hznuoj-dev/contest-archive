#include<stdio.h>
#include<math.h>
int main(){
	int T,i;
	long long n,m;
	double sum,num;
	scanf("%d",&T);
	while(T--){
		scanf("%lld %lld",&n,&m);
		sum=(double)m/(double)n;
		num=sum*100;
		for(i=0;i<n;i++){
			if(i==0)
			printf("[");
			if(i<m)
			printf("#");
			else
			printf("-");
			if(i==n-1)
			printf("] %.f%%\n",num);
		}
		//printf(" %.f%%\n",num);
	}
}
