#include<stdio.h>
int main() {
	long long a, b, c, d;
	int n, m;
	scanf("%lld %lld %lld %lld", &a, &b, &c, &d);
	n = 0;
	m = 0;
	while (a > 0)
	{
		m += a % 10;
		a = a / 10;
	}
	if (m >= 16 || m == 6)
		n++;
	m = 0;
	while (b > 0)
	{
		m += b % 10;
		b = b / 10;
	}
	if (m >= 16 || m == 6)
		n++;
	m = 0;
	while (c > 0)
	{
		m += c % 10;
		c = c / 10;
	}
	if (m >= 16 || m == 6)
		n++;
	m = 0;
	while (d > 0)
	{
		m += d % 10;
		d = d / 10;
	}
	if (m >= 16 || m == 6)
		n++;
	if (n == 0)
		printf("Bao Bao is so Zhai......\n");
	if (n == 1)
		printf("Oh dear!!\n");
	if (n == 2)
		printf("BaoBao is good!!\n");
	if (n == 3)
		printf("Bao Bao is a SupEr man///!\n");
	if (n == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}