#include<stdio.h>
int main(){
		int m=0;
		long long int a,b,c,d;
		scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
		long long int i,num1=0,num2=0,num3=0,num4=0;
		for(i=a;i>0;i=i/10){
			num1=i/10+num1;
		}
		for(i=b;i>0;i=i/10){
			num2=i/10+num2;
		}
		for(i=c;i>0;i=i/10){
			num3=i/10+num3;
		}
		for(i=d;i>0;i=i/10){
			num4=i/10+num4;
		}
		if(num1>=16||num1==6){
			m++;
		}
		if(num2>=16||num2==6){
			m++;
		}
		if(num3>=16||num3==6){
			m++;
		}
		if(num4>=16||num4==6){
			m++;
		}
		if(m==0){
			printf("Bao Bao is so Zhai......\n");
		}
		if(m==1){
			printf("Oh Dear!!\n");
		}
		if(m==2){
			printf("BaoBao is good!!\n");
		}
		if(m==3){
			printf("Bao Bao is a SupEr man///!\n");
		}
		if(m==4){
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
		}
	return 0;
}
