#include<stdio.h>
int main(void){
	int n;
	scanf("%d",&n);
	while(n--){
		int a;
		long long int b;
		scanf("%d %lld",&a,&b);
		long int c,d;
		c=a+b;
		d=c-9999;
		int e;
		if(d>0){
			e=9999-d;
		}else{
			e=c;
		}
		int t;
		if(e<a){
			e=t;
			t=a;
			a=e;
		}
		int i,sum=0;
	for(i=a;i<=e;i++){
		if((i%4==0&&i%100!=0)||(i%400==0)){
			sum=sum+1;
		}else{
			sum=sum+0;
		}
	}
	printf("%d\n",sum);
	}
	return 0; 
}
