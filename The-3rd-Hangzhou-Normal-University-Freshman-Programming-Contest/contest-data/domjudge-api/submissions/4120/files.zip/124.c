#include<stdio.h>
int main(){
	int T,a,b,n,m,c[1005],i;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&a,&b);
		for(i=1;i<a;i++){
			c[i]=i;
		}
		while(b--){
			scanf("%d %d",&n,&m);
			if(n>m){
				for(i=n;i>m;i--){
					c[i]=c[i-1];
				}
				c[m]=n;
			}
		}
	for(i=1;i<a;i++){
		printf("%d ",c[i]);
	}
	printf("%d",c[a]);
}
}
