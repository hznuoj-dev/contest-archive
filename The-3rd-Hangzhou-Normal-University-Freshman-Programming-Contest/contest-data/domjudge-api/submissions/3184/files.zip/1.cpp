#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 



int main(){
	int t,a,b,i;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		printf("[");
		for(i=1;i<=b;i++) printf("#");
		for(i=1;i<=(a-b);i++) printf("-");
		printf("] ");
		printf("%.0f%%\n",b*1.0/a*100);
	}
} 

