#include<stdio.h>
int main(){
	int T,year1,num,year2,i,sum;
	sum=0;
	scanf("%d",&T);
	while(T--){
		year2=0;
		sum=0;
		scanf("%d%d",&year1,&num);
		if(year1+num>9999){
			year2=9999-(year1+num-9999);
		}
		else
			year2=year1+num;

		if(year1>year2){
		for(i=year2;i<=year1;i++){
			if((i%4==0&&i%100!=0)||(i%400==0))
				sum=sum+1;
		}
		}
		if(year1<year2){
		for(i=year1;i<=year2;i++){
			if((i%4==0&&i%100!=0)||(i%400==0))
				sum=sum+1;
		}
		}
		printf("%d\n",sum);
	}
	return 0;
}
