#include <stdio.h>
#include <math.h>
int panduan(int a,int b){
	int n,i,m=0;
	if(a+b>9999){
		n=9999-(a+b-9999);
	}
	else{
		n=a+b;
	}
	if(a<=n){
		for(i=a;i<n+1;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				m++;
			}
		}
	}
	else{
		for(i=n;i<a+1;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				m++;
			}
		}
	}
	return m;
}
int main(){
	int t;
	scanf("%d",&t);
	int i;
	int a[t],b[t];
	for(i=0;i<t;i++){
		scanf("%d%d",&a[i],&b[i]);
		a[i]=panduan(a[i],b[i]);
	}
	for(i=0;i<t;i++){
		printf("%d\n",a[i]);
	}
}
