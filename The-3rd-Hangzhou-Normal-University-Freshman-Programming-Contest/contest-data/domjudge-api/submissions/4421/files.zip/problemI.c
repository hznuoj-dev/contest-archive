#include<stdio.h>
#include<string.h>
void main()
{
	int a, b, c, d, x;
	scanf("%d %d %d %d", &a, &b, &c, &d);
	x = 0;
	if (a >= 16 || a == 6)
		x++;
	if (b >= 16 || b == 6)
		x++;
	if (c >= 16 || c == 6)
		x++;
	if (d >= 16 || d == 6)
		x++;
	switch (x)
	{
	case 1:printf("Oh dear!!"); break;
	case 2:printf("BaoBao is good!!"); break;
	case 3:printf("Bao Bao is a SupEr man///!"); break;
	case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!"); break;
	case 0:printf("Bao Bao is so Zhai......"); break;
	}
}



























/*int n, T, m, p, q;
	int a[1000000][5],b[100000][15];
	int i, j, l, L;
	scanf("%d %d %d %d", &n, &T, &m, &p);
	for (i = 0; i < m; i++)
	{
		scanf("%d %d %d %c %c", &a[i][0], &a[i][1], &a[i][2], &a[i][3], &a[i][4]);
	}
	scanf("%d", &q);
	for (i = 0; i < q; i++)
	{
		scanf("%s", &b[i]);
		l = strlen(&b[i]);
		scanf("%d %d", &b[i][l + 1], &b[i][l + 2]);
	}
	for (i = 0; i < q; i++)
	{
		if (b[i][0] == 't'&&b[i][6] == 't')
		{
			printf("%d [%s] %")
		}
	}*/