#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void){
	int y,a,point,m,i,t,x,h;
	scanf("%d",&t);
	while(t--)
	{
		point=0,h=0,m=0,i=0,x=0;
		scanf("%d%d",&y,&a);
		x=y+a;
		if(x>9999)
		{
			h=2*9999-x;	
			x=h;		
		}
	 
		m=(x<y?x:y);
		for(i=m;i<=x+y-m;++i)
		{
			
			
				if(((i%100!=0&&i%4==0)||i%400==0)&&i!=0)
			{
			
				++point;
				
			}
				
		}
	
			printf("%d\n",point);
		
	}
		

	

	return 0;
} 
