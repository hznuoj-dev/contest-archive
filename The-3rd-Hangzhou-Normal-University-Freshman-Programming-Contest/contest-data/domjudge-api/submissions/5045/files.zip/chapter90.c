#include <stdio.h>
int main(void) {
	int t, n, m, i, j;
	double s;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &n, &m);
		printf("[");
		for (i = 0; i < m; i++) {
			printf("#");
		}
		for (i = m; i < n; i++) {
			printf("-");
		}
		printf("] ");
		if (m == 0) {
			s = 0;
		}
		else {
			s = (double)m / (double)n * 100;
		}
		printf("%.0f%%\n", s);
	}
}