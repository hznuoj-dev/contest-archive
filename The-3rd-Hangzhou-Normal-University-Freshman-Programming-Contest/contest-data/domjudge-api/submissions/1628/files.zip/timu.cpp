#include<bits/stdc++.h>
using namespace std;
int t[5]={0};
int change(int m)
{
   int sum=0;
   if(m==6) return 1;
   while(m>0)
   {
     sum=sum+m%10;
     m=m/10;
   }
   if(sum>=16)
   return 1;
   return 0;
}
int main()
{
   long long a,i,s=0;
   for(i=1;i<=4;i++)
   {
       scanf("%lld",&a);
	   t[i]=change(a);
   }
	s=t[1]+t[2]+t[3]+t[4];
	if(s==0) printf("Bao Bao is so Zhai......\n");
	if(s==1) printf("Oh dear!!\n");
	if(s==2) printf("BaoBao is good!!\n");
	if(s==3) printf("Bao Bao is a SupEr man///!\n");
	if(s==4) printf("��Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	
	
	return 0;
}
