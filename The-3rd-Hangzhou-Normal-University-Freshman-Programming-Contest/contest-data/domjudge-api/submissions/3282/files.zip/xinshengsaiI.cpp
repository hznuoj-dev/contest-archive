#include<stdio.h>
int main()
{
    int sum = 0,i,sum2=0,a[4];
     sum2 = 0;
    for (i = 1; i <= 4; i++)
    {
        scanf("%d", &a[i]);
    }
    for (i = 1; i <= 4; i++)
    {
        sum = 0;
        while (a[i])
        {
            sum += a[i] % 10;
            a[i] = a[i] / 10;
        }
        if (sum == 6 || sum >= 16)
        {
            sum2 += 1;
        }
    }
        if (sum2 == 1)
        {
            printf("Oh dear!!\n");
        }
        else if (sum2 == 0)
        {
            printf("Bao Bao is so Zhai......\n");
        }
        else if (sum2 == 2)
        {
            printf("BaoBao is good!!\n");
        }
        else if (sum2 == 3)
        {
            printf("Bao Bao is a SupEr man///!\n");
        }
        else if (sum2 == 4)
        {
            printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
        }
    return 0;
}