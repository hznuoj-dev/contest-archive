#include<stdio.h>
int main(void){
	int n,a,b,i;
	scanf("%d",&n);
	while(n--){
		scanf("%d %d",&a,&b);
		printf("[");
		for(i=1;i<=a;i++){
			if(i<=b) printf("#");
			else printf("-");
		}
		printf("] %d%%\n",b*100/a);
	}
}
