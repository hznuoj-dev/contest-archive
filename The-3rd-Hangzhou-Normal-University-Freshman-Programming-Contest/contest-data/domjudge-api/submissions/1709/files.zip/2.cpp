#include<stdio.h>
int main(){
	int t,i,b,flag;
	int y,a,sj,xj,c,temp;
	scanf("%d",&t);
	while(t--){
		c=0;
		flag=0;
		scanf("%d %d",&y,&a);
		sj=y+a;
		xj=y;
		b=sj;
		while(b>9999){
			b-=9999;
			flag=1;
		}	
		if(flag)sj=9999-b;
		if(sj<xj){
			temp=xj;
			xj=sj;
			sj=temp;
		}
		for(i=xj;i<=sj;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				c++;
			}
		}
		printf("%d\n",c);
	}
	return 0;	
}
