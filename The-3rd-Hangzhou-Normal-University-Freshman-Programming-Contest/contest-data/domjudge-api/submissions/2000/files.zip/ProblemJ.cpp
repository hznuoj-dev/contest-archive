#include <cstdio>
#include <cstring>

int occur[128];

int main() {
    int t;
    int n;
    int i;
    int counter;
    char rubbish;

    scanf("%d", &t);
    while (t--) {
        counter = 0;

        scanf("%d", &n);
        getchar();
        for (i = 0; i < n; ++i) {
            memset(occur, 0, 128 * sizeof(int));
            while ((rubbish = getchar()) != '\n') {
                if (rubbish == '.') {
                    continue;
                } else {
                    if (occur[rubbish] == 0) {
                        ++occur[rubbish];
                        ++counter;
                    }
                }
            }
        }
        
        printf("%d\n", counter);
    }
    return 0;
}