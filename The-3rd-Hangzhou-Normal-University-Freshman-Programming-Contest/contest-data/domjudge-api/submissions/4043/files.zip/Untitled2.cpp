#include<stdio.h>
#include<string.h>
int main()
{
	int t,w[100],n,i,l,j,count,k;
	char s[1000000];
	
	scanf("%d",&t);
	while(t>0)
	{
		count=0;
		scanf("%d",&n);
		getchar();
		for(i=0;i<n;i++)
		{
			for (k=0;k<100;k++) 	w[k]=0;
			gets(s);
			l=strlen(s);
			for (j=0;j<l;j++)
			{
				w[s[j]-' ']++;
				if (s[j]!='.' && w[s[j]-' ']==1)count++;
			}
				
		}
		
		printf("%d\n",count);
		t--;
	}
}
