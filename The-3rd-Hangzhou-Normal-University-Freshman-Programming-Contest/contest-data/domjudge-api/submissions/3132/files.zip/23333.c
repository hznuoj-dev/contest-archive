#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
int p[1230];
int main(){
	int t;
	int n,m;
	scanf("%d",&t);
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++){
		p[i]=i;
	}
	while(m--){
		
		int a,b;
		
		scanf("%d %d",&a,&b);
		if(p[a]>p[b]){
			int f;
			f=p[a];
			p[a]=p[b];
			p[b]=f;
		}
	}
	for(int i=1;i<=n;i++){
		printf("%d%c",p[i],i==n?'\n':' ');
	}
}
