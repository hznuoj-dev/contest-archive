#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char a[1000000000000000000];
	int sum1=0,i,sum2=0,t=4;
	while(t--){
		scanf("%s",a);
		for(i=0;i<strlen(a)-1;i++){
			sum1+=a[i];
		}
		if(sum1>=16||sum1==6)sum2++;
	}
	if(sum2==1)printf("Oh dear!!\n");
	if(sum2==2)printf("BaoBao is good!!\n");
	if(sum2==3)printf("Bao Bao is a SupEr man///!\n");
	if(sum2==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if(sum2==0)printf("Bao Bao is so Zhai......\n");
	
	return 0;
}
