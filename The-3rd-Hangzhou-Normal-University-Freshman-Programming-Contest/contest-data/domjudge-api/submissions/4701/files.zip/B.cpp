#include <stdio.h>
#include <stdlib.h>

int main()
{
    int year;
    int n,n1,n2;
    int f,l;
    int tmp,sum=0;

    while(scanf("%d",&n)!=EOF)
    {
    for(int i=0;i<n;i++){

	    scanf("%d%d",&n1,&n2);

		f = n1 + n2 ;
		l = n1>f? n1:f;


		if(f > l ){
			tmp = f;
			f = l;
			l = tmp;
		}
		if(n2<0)n1 = f;
		for(year=n1;year<l;year++ ){

		    if (year%400==0 || (year%4==0 && year%100!=0)){
		        sum++;
		    }
		}
		printf("%d\n",sum);
		sum = 0 ;
	}
    }
    return 0;
}
