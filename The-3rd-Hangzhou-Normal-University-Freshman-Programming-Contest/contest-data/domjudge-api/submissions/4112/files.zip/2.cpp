#include<stdio.h>
int main(void){
	int t;
	int y,a;
	int count=0;
	if(scanf("%d",&t)){
		while(t--){
		count =0;
		if(scanf("%d %d",&y,&a)){
				if(y+a>9999){
			//printf("%d\n",y);
			for(int k=y;k<=9998;k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
		else{
			if(y+a<=y){
				//printf("%d %d\n",jia,y);
				for( int k=y+a;k<=y;k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
		else{
		
			for(int k=y;k<=y+a;k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
	}
		}
		//printf("%d\n",jia);
	
	printf("%d\n",count);
	}
	}
	
	return 0;
} 
