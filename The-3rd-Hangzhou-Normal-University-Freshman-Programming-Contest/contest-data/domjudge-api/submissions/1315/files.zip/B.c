#include <stdbool.h>
#include "stdio.h"
#include "minmax.h"

bool isRunnian(int j);

int main(){
    int t,y,a;
    scanf("%d",&t);
    for (int i = 0; i < t; ++i) {
        scanf("%d  %d",&y,&a);
        int b=y+a,cont=0;
        if(b>9999){
            b=9999-(b-9999);
        }
        for (int j = min(y,b); j <= max(y,b); ++j) {
            if(isRunnian(j)==true){
                cont++;
            }
        }
        printf("%d\n",cont);
    }
}

bool isRunnian(int j) {
    if(j%400==0 || (j%4==0 && j%100!=0)){
        return true;
    }
    return false;
}
