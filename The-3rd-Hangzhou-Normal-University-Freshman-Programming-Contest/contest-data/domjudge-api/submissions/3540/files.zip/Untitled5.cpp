#include<stdio.h>
int main(void){
	int A,B,C,D,a=0,b=0,c=0,d=0;
	int count=0;
	scanf("%d %d %d %d",&A,&B,&C,&D);
	if(A!=0){
		while(A!=0){
			a+=A%10;
			A/=10;
		}
		if(a==6||a>=16)
		count++;
	}
		if(B!=0){
		while(B!=0){
			b+=B%10;
			B/=10;
		}
		if(b==6||b>=16)
		count++;
	}
		if(C!=0){
		while(C!=0){
			c+=C%10;
			C/=10;
		}
		if(c==6||c>=16)
		count++;
	}
		if(D!=0){
		while(D!=0){
			d+=D%10;
			D/=10;
		}
		if(d==6||d>=16)
		count++;
	}
	if(count==1)
	printf("Oh dear!!\n");
	if(count==2)
	printf("BaoBao is good!!\n");
	if(count==3)
	printf("Bao Bao is a SupEr man///!\n");
	if(count==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if(count==0)
	printf("Bao Bao is so Zhai......\n");
	return 0;
}
