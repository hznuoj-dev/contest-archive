import java.util.*;
public class Main
{
    public static void main(String[] args) 
    {
    	Scanner s=new Scanner (System.in);
		while (s.hasNext())
		{
			int g=0;
			for (int i=1;i<=4;i++)
			{
				long a=s.nextLong();
				int b=0;
				while (a!=0)
				{
					b+=a%10;
					a=a/10;
				}
				if (b>=16||b==6)g++;
			}
			if (g==0)System.out.println("Bao Bao is so Zhai......");
			else if (g==1)System.out.println("Oh dear!!");
			else if (g==2)System.out.println("BaoBao is good!!");
			else if (g==3)System.out.println("Bao Bao is a SupEr man///!");
			else if (g==4)System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		}
      
    }
}