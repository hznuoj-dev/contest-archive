#include <stdio.h>
int main(void){
	char a[4];
	int i;
	for(i=0;i<4;i++){
	scanf("%c",&a[i]);
	}
	if(a[0]=='k'&&a[1]=='f'&&a[2]=='c'){
		printf(" __      _____\n");
		printf("\n");
		printf("|  | ___/ ____\\____\n");
		printf("\n");
		printf("|  |/ /\\   __\\/  ___\\\n");
		printf("\n");
        printf("|    <  |  |  \\  \\___\n");
		printf("\n");
        printf("|__|_ \\ |__| \\___  >\n");
		printf("\n");
        printf("    \\/           \\/\n");
	}
	return 0;
}