#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int Run(int x){
	if((x%4==0 &&x%100!=0)||(x%400==0)){return 1;
	}else{return 0;
	}
}
int main(){
	char str;
	int x=0,a=0,b=0,c=0,d=0;
	str=getchar();
	while(str!=' '){
		a=a+str-'0';
		str=getchar();
	}
	str=getchar();
	while(str!=' '){
		b=b+str-'0';
		str=getchar();
	}
	str=getchar();
	while(str!=' '){
		c=c+str-'0';
		str=getchar();
	}
	str=getchar();
	while(str!=' ' && str!='\n'){
		d=d+str-'0';
		str=getchar();
	}
	if(a>=16||a==6){x=x+1;
	}
	if(b>=16||b==6){x=x+1;
	}
	if(c>=16||c==6){x=x+1;
	}
	if(d>=16||d==6){x=x+1;
	}
	if(x==0){printf("Bao Bao is so Zhai......");
	}else if(x==1){printf("Oh dear!!");
	}else if(x==2){printf("BaoBao is good!!");
	}else if(x==3){printf("Bao Bao is a SupEr man///!");
	}else if(x==4){printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	
}
