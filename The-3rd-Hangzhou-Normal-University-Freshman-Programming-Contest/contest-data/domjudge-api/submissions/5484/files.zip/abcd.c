#include<stdio.h>
int main(){
	long long a[3];
	int n,s,sum=0;
	scanf("%d %d %d %d",&a[0],&a[1],&a[2],&a[3]);	
	int i;
	for(i=0;i<4;i++){
		s=0;
		while(a[i]>0){
		n=a[i]%10;
		s+=n;
		a[i]/=10; 
	}	
	if(s>=16||s==6){
		sum++;
	}
	}
	switch(sum){
		case 0:printf("Bao Bao is so Zhai......\n");break;
		case 1:printf("Oh dear!!\n");break;
		case 2:printf("BaoBao is good!!\n");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");break;
		
	}
	return 0;
} 
