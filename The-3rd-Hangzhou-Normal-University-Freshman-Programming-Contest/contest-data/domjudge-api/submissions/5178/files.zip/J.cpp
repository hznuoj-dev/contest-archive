#include<stdio.h>
#include<string.h>
int main(){
	int T;
	long long l,i,j,k=-1,p=1,x=0,c;
	char a[1000000],b[1000000];
	scanf("%d",&T);
	while(T--){
		scanf("%lld",&c);
//		getchar();
		while(c>0){	
		scanf("%s",a);
		l=strlen(a)-1;
		for(i=0;i<=l;i++){
			if(a[i]!='.'){
				for(j=0;j<=k;j++){
					if(a[i]==b[j]){
					p=0;
					}
				}
				if(p==1){
					k=k+1;
					b[k]=a[i];
					x=x+1;
				}
				p=1;
			}
		} 
		k=-1;
		c=c-1;
	    }
	    printf("%lld\n",x);
	    x=0;
	}
}
