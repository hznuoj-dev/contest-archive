#include <stdio.h>
int main(void){
	int t;
	long long y,a,temp,i,b;
	scanf("%d",&t);
	getchar();
	while(t--){
		b=0;
		scanf("%lld %lld",&y,&a);
		getchar();
		a=y+a;
		if(a<y){
			temp=a;
			a=y;
			y=temp;
		}
		if(a>9999){
			a=9999-(a-9999);
		}
		for(i=y;i<=a;i++){
			if((i%4==0 && i%100!=0) || (i%400==0)){
				b=b+1;
			}
		}
		printf("%lld\n",b);
	}
	return 0;
} 
