#include<stdio.h>
#include<string.h>
int main(){
	char a[20];
	int count=0,sum,i,j,len;
	for(i=0;i<4;i++){
		sum=0;
		scanf("%s",a);
		len=strlen(a);
		for(j=0;j<len;j++){
			sum+=a[j]-48;
		}
		if(sum>=16||sum==6) count++;
	}
	if(count==0)
	printf("Bao Bao is so Zhai......\n");
	else if(count==1)
	printf("Oh dear!!\n");
	else if(count==2)
	printf("BaoBao is good!!\n");
	else if(count==3)
	printf("Bao Bao is a SupEr man///!\n");
	else
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
