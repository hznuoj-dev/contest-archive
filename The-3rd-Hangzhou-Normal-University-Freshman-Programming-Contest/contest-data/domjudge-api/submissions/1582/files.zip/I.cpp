#include<iostream>
#include<string>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
int main(){
	fcio;
	string s[4];
	cin>>s[0]>>s[1]>>s[2]>>s[3];
		int num=0;
		for(int i=0;i<4;++i){
			int u=0;
			for(int j=0;j<s[i].length();++j){
				u=u*10+(s[i][j]-'0');
			}
			if(u>=16||u==6)num++;
		}
		if(num==0)cout<<"Bao Bao is so Zhai......"<<endl;
		else if(num==1)cout<<"Oh dear!!"<<endl;
		else if(num==2)cout<<"BaoBao is good!!"<<endl;
		else if(num==3)cout<<"Bao Bao is a SupEr man///!"<<endl;
		else cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl; 
		return 0;
}

