#include<stdio.h>

int main()
{
	long long int a,b,c,d;
	int e=0,f=0,g=0,h=0;
	int sum=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(d>0)
	{
		h+=d%10;
		d/=10;
	}
	if(h>=16||h==6)
	sum++;
	
	while(a>0)
	{
		e+=a%10;
		a/=10;
	}
	if(e>=16||e==6)
	sum++;
	
	while(b>0)
	{
		f+=b%10;
		b/=10;
	}
	if(f>=16||f==6)
	sum++;
	
	while(c>0)
	{
		g+=c%10;
		c/=10;
	}
	if(g>=16||g==6)
	sum++;
	
	if(sum==1)
	printf("Oh dear!!");
	else if(sum==2)
	printf("BaoBao is good!!");
	else if(sum==3)
	printf("Bao Bao is a SupEr man///!");
	else if(sum==0)
	printf("Bao Bao is so Zhai......");
	else if(sum==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
	
	
}

