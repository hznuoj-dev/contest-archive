#include<bits/stdc++.h>
using namespace std;
int sum(char n);
int main()
{
	char a[20],b[20],c[20],d[20];
	int i,len,sum[4]={0},k=0;
	scanf("%s %s %s %s",a,b,c,d);
	for(i=0;a[i]!='\0';i++){
		sum[0]+=a[i]-'0';
	}
	for(i=0;b[i]!='\0';i++){
		sum[1]+=b[i]-'0';
	}
	for(i=0;c[i]!='\0';i++){
		sum[2]+=c[i]-'0';
	}
	for(i=0;d[i]!='\0';i++){
		sum[3]+=d[i]-'0';
	}
	for(i=0;i<4;i++){
		if(sum[i]>=16 || sum[i]==6) k++;
	}
	if(k==0){
		printf("Bao Bao is so Zhai......");
	}
	else if(k==1){
		printf("Oh dear!!");
	}
	else if(k==2){
		printf("BaoBao is good!!");
	}
	else if(k==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else if(k==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
}
