#include<stdio.h>
int main(void){
	int t,m,n,i;
	double a;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d", &m, &n);
		a=100*((1.0*n)/m);
		printf("[");
		for(i=0;i<n;++i){
			printf("#");
		}
		for(i=0;i<m-n;++i){
			printf("-");
		}
		printf("] ");
		printf("%.0f%%",a);
	}
	return 0;
}
