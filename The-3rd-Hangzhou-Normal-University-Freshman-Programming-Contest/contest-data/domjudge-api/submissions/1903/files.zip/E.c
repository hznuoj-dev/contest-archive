#include<stdio.h>
#include<math.h>
#define kfc kfc
#pragma warning(disable:4996)
int main()
{
	char kfc;
	scanf("%s", &kfc);
	printf("_ _ _ __ _ _\n");
	printf("|     | _ _ _/ _ _ _ _\_ _ _ _\n");
	printf("|     |/   /\      _ _\/  _ _ _\\n");
	printf("|         <   |     | \    \_ _ _\n");
	printf("| _ _ | _ \   | _ _ |  \_ _ _ >\n");
	printf("	   \ /     \ / ");
		return 0;
}