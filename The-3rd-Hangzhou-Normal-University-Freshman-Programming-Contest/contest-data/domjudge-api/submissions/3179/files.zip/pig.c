#include<stdio.h>
#include<string.h>
#include<math.h>
#pragma warning (disable:4996)
/*int main() {
	int n, T, m,p;//�ó������ܵĶ�����, �ܵ�ʱ��, �ܵ��ύ������Ŀ����
	int team, pro, time,q;//ʾ������, ��Ŀ��ź�ʱ���,ѯ������
	char a;

}*/
/*int main() {
	int a, b, c, d, i, k = 0, t;
	scanf("%d", &a);
	while (a--) {
		k = 0;
		scanf("%d %d", &b, &c);
		d = b + c;
		while  (d >= 10000) {
			d = d - 9999;
			d = 9999 - d;
		}
		if (b > d) {
			t = b;b = d;d = t;
		}
		for (i = b;i <= d;i++) {
			if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				k++;
		}
		printf("%d\n", k);
	}
}*/
/*int main() {
	int a;
	scanf("%d", &a);
	while (a--) {
		scanf ("%d",)
	}
}*/
/*int main() {
	char a[100];
	scanf("%s", &a);
	printf(
	    " __      _____\n"
	    "|  | ___/ ____\\____\n"
		"|  |/ /\\   __\\/ ___\\\n"
		"|    <  |  | \\  \\___\n"
		"|__|_ \\ |__|  \\___  >\n"
		"     \\/           \\/\n");
	return 0;
}*/
/*int main() {
	long long int a, b, c, d;
	long long int A=0, B=0, C=0, D=0,j = 0;
	scanf("%lld %lld %lld %lld", &a, &b, &c, &d);
	while (a > 0) {
		A = A + a % 10;
		a=a / 10;
	}
	while (b > 0) {
		B = B + b % 10;
		b = b / 10;
	}
	while (c > 0) {
		C = C + c % 10;
		c = c / 10;
	}
	while (d > 0) {
		D = D + d % 10;
		d = d / 10;
	}
	if (A >= 16 || A == 6)
		j++;
	if (B >= 16 || B == 6)
		j++;
	if (C >= 16 || C == 6)
		j++;
	if (D >= 16 || D == 6)
		j++;
	if (j == 1)
		printf("Oh dear!!");
	else if (j == 2)
		printf("BaoBao is good!!");
	else if (j == 3)
		printf("Bao Bao is a SupEr man///!");
	else if (j == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if (j==0)
		printf("Bao Bao is so Zhai......");
	return 0;
}*/
/*int main() {
	int a, b, c, d, f;
	scanf("%d", &a);
	while (a--) {
		scanf("%d %d", &b, &c);
		d = c * 100/b;
		f = b - c;
		printf("[");
		while (c--) {
			printf("#");
		}
		while (f--) {
			printf("-");
		}
		printf("] ");
		printf("%d", d);
		printf("%%\n");
	}
	return 0;
}*/
int main() {
	int T, n, i, j;
	char s[100],*p;
	scanf("%d", &T);
	while (T--) {
		i = 0;
		scanf("%d", &n);
		while (n--) {
			scanf("%s", s);
			p = &s;
			j = strlen(s);
			while (j--) {
				if (*p == '#')
					i++;
				p++;
			}
		}
		printf("%d\n", i);
	}
	return 0;
}