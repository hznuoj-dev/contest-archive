#include <stdio.h> 
#include <string.h> 
int main(void){
	int t,n,i,len,sum;
	char s[1000000];
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d",&n);
		while(n--){
			scanf("%s",s);
			len=strlen(s);
			int a[1000]={0};
			for(i=0;i<len;i++){
				a[s[i]]++;
				if(s[i]!='.'&&a[s[i]]==1){
					sum++;
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
 
