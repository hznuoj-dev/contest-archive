#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int n,i,j,a,b,c;
	char q;
	scanf("%d",&n);
	for(i=0;i<n;++i){
		q='%';
		scanf("%d%d",&a,&b);
		c=b*100/a;
		printf("[");
		for(j=1;j<=b;++j)
		printf("#");
		for(j=1;j<=(a-b);++j)
		printf("-");
		printf("] %d",c);
		printf("%c",q);
		printf("\n");
	}
	return 0;
}

