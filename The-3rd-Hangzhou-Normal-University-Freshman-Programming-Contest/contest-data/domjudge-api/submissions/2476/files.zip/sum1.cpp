#include<stdio.h>
#include<math.h>
int cip(int n) {
	if (n < 10)
	{
		return n;
	}
	else 
	{
		return n%10+cip(n/10);
	}
}
int main()
{
	int a,b,c,d,a1=0,b1=0,c1=0,d1=0,sum=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	if(cip(a)>=16||cip(a)==6)
	{
		a1=1;
	}
	if(cip(b)>=16||cip(b)==6)
	{
		b1=1;
	}
	if(cip(c)>=16||cip(c)==6)
	{
		c1=1;
	}
	if(cip(d)>=16||cip(d)==6)
	{
		d1=1;
	}
	sum=a1+b1+c1+d1;
	if(sum==1)
		printf("Oh dear!!");
	else if(sum==2)
		printf("BaoBao is good!!");
	else if(sum==3)
		printf("Bao Bao is a SupEr man//////!");
	else if(sum==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(sum==0)
		printf("Bao Bao is so Zhai......");
	return 0;
}

