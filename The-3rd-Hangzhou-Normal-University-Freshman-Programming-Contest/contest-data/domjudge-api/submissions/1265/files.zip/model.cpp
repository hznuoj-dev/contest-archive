//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 1010;

int main() {
	
#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);

	printf("__ _____\n| | ___/ ____\\____\n| |/ /\\ __\\/ ___\\\n| < | | \\ \\___\n|__|_ \\ |__| \\___ >\n\\/ \\/");

	return 0;
}
