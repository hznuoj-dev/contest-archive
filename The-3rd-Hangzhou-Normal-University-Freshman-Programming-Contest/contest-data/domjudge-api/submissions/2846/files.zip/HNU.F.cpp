#include<stdio.h>
#include<string>
#include<iostream>
using namespace std;
int main()
{
    string in;
    string a=" __      _____";
    string b="|  | ___/ ____\\\____";
    string c="|  |/ /\\\   __\\\/ ___";
    string d="|    <  |  | \\\  \\\___";
    string f="|__|_ \\\ |__|  \\\___  >";
    string g="     \\\/           \\\/";
    cin>>in;
    cout<<a<<endl;
    cout<<b<<endl;
    cout<<c;
    putchar(92);
    printf("\n");
    cout<<d<<endl;
    cout<<f<<endl;
    cout<<g<<endl;
    return 0;
}
