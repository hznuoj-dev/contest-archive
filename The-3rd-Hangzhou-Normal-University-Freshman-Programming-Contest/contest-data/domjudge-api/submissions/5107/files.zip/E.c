#include<stdio.h>
#include<math.h>
#pragma warning(disable:4996)
int main(void){
	scanf("kfc");
	printf(" __      _____     \n");
	printf("|  | ___\/ ____\\____\n");
	printf("|  |\/ \/\\   __\\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\\/           \\\/\n");
	return 0;
}
