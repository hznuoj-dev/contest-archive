#include <stdio.h>
int main(void)
{
	char ch;
	scanf("%c%c%c",&ch,&ch,&ch);
	printf(" _ _         _ _ _ _ _\n");
	
	printf("|   | _ _ _/ _ _ _ _ \\_ _ _ _\n");
			
	printf("|   | / /\\    _ _\\/ _ _ _ \\\n");
			
	printf("|      <  |   |  \\  \\_ _ _\n");
			
	printf("|_ _| _ \\ |_ _|    \\ _ _ _  >\n");
			
	printf("       \\/                  \\/\n");
			  
	return 0;
}
