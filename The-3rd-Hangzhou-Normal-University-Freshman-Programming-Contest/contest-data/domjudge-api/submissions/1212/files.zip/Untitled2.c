#include<stdio.h>
int main(){
	printf(" __      _____\n|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n     \\/           \\/");
	return 0;
} 
