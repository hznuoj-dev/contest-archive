#include<stdio.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--){
		int y,a,y2,i,sum;
		scanf("%d%d",&y,&a);
		y2=y+a;
		if(y2>9999){
			int b;
			b=y2-9999;
			y2=9999-b;}
		if(y2<y){
			int t;
			t=y2;
			y2=y;
			y=t;
		}
		for(i=y,sum=0;i<=y2;++i){
			if((i%400==0)||��(i%4==0)&&(i%100!=0)��){
				++sum;
			}
		}}
	printf("%d\n",sum);
}
return 0;}
}
