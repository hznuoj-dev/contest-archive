#include <stdio.h>
int main(){
	int t,m,n,i;
	double j;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++){
			if(i==1){
				printf("[");
			}
		    if(i<=m){
				printf("#");
			}
			else{
				printf("-");
			}
			if(i==n){
				j=(double)m/double(n)*100;
				printf("]%.0f%%\n",j);
			}
		}
	}
	return 0;
}
