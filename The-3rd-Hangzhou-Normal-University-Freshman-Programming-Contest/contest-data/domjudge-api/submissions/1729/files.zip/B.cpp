#include<stdio.h>
int main()
{
	int t, i, a, b, year, j, sum;
	scanf("%d", &t);
	while (t--)
	{
		sum = 0;
		scanf("%d %d", &year, &a);
		b = year + a;
		if (b > 9999)
			b = 9999 - b + 9999;
		if (year > b)
		{
			j = year;
			year = b;
			b = j;
		}
		for (i = year; i <= b; i++)
		{
			if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
				sum = sum + 1;
		}
		printf("%d\n", sum);
	}
}