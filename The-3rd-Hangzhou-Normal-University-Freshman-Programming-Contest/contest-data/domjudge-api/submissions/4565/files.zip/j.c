#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main() {
	int  f, t, k, n, i, d;
	char a[200], c;
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &k);
		d = 0;
		getchar();
		while (k--) {
			a[0] = '.';
			n = 0;
			while ((c = getchar()) != '\n') {
				i = 0;
				while (i <= n) {
					if (a[i] != c) {
						i++;
					}
					else {
						break;
					}
				}
				if (i > n) {
					n += 1;
					a[n] = c;
				}
			}
			d=d+n;
			for (i = 1; i <= n; i++) {
				a[i] = '\0';
			}
		}
		printf("%d\n", d);
	}
	return 0;
}