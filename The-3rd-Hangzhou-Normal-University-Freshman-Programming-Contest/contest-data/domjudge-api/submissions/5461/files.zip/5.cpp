#include <stdio.h>
#include<string.h>
int main() {
	int t,n,p,i,a[1008]= {0},b[1008]= {0},t1=1,j,o,k=1,q[1008]= {0},q1=0,q2=0, c[1008]= {0},d[1008],l,e[1008]= {0},max,m;
	scanf("%d",&t);
	while (t--) {
		scanf("%d %d",&n,&p);
		for(i=1; i<=p; i++) {
			scanf("%d %d",&a[t1],&b[t1]);
			t1++;
		}
		for(k=1; k<=p; k++) {
			for(i=k+1; i<=p; i++) {
				if(a[i]==a[k]&&b[i]==b[k]&&k!=i) q[i]=1;
			}
		}
		for(i=1; i<=p; i++) {
			q2=0;
			if(q[i]==0) {
				c[a[i]]=c[b[i]]+1;
				e[a[i]]=1;
				e[b[i]]=1;
				o=a[i];
				while (q1!=1) {
					q2=0;
					for(j=1; j<=p; j++) {
						if(b[j]==a[i]) {
							c[a[j]]+=1;
							a[i]=a[j];
							q2=1;
						}
					}
					if(q2==0) q1=1;
				}
				a[i]=o;
			}
			q1=0;
		}
		for(i=1; i<=n; i++) {
			d[i]=i;
		}
		max=c[1];
		for(i=1; i<=n; i++) {
			if(c[i]>max) max=c[i];
		}
		for(i=1; i<=n; i++) {
			if(e[i]==0) c[i]=-1;
		}

		for(i=1; i<=n; i++) {
			for(j=1; j<n; j++) {
				if(c[d[j]]<c[d[j+1]]) {
					l=d[j];
					d[j]=d[j+1];
					d[j+1]=l;
				}
			}
		}

		for(i=1; i<n; i++) {
			if(c[d[i]]==c[d[i+1]]&&d[i]>d[i+1]) {
				l=d[i];
				d[i]=d[i+1];
				d[i+1]=l;
			}
		}
		for(i=1; i<=n; i++) {
			if(c[d[i]]==-1) {
				m=d[i];
				for(j=1; j<=n; j++) {
					if(d[j]>d[i]) {
					l=j;
					break;}
				}
				for(k=i; k>=l+1; k--) {
					d[k]=d[k-1];
				}
				d[l]=m;
			}
		}
		for(i=1; i<=n; i++) {
			printf("%d ",d[i]);
		}
		printf("\n");
		t1=1;
		for(i=1; i<=n*n; i++) {
			c[i]=0;
			b[i]=0;
			a[i]=0;
			d[i]=1;
			e[i]=0;
		}


	}
	return 0;
}
