//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 10010;

int n, m, dp[MAXN];
vector<int>type, num, coin, ans;

bool cmp(int a, int b) {
	return a > b;
}

int main() {

#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);

	int n, m, a, cnt = 0;
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a);
		type.push_back(a);
	}
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a);
		num.push_back(a);
	}
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < num[i]; ++j) {
			coin.push_back(type[i]);
		}
	}
	sort(coin.begin(), coin.end());

	for (int k = 1; k <= m; ++k) {
		memset(dp, 0, sizeof(dp));
		for (int i = 0; i < coin.size(); ++i) {
			for (int j = k; j >= coin[i]; --j) {
				if (dp[j] <= dp[j - coin[i]] + coin[i]) {
					dp[j] = dp[j - coin[i]] + coin[i];
				}
			}
		}
		if (dp[k] == k){
			cnt++;
		}
	}
	printf("%d\n", cnt);

	return 0;
}
