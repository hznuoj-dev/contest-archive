#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char ch[10];
		scanf("%c%c%c",&ch[0],&ch[1],&ch[2]);
		
	if(ch[0]=='k'&&ch[1]=='f'&&ch[2]=='c'){
		printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");}
	return 0;
}
