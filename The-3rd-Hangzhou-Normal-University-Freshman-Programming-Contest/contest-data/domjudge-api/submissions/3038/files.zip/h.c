#include <stdio.h>
#include <string.h>

int main(void)
{
	int t,num,i,n,m;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&m);
		num = m*100.0/n;
		printf("[");
		for(i = 0;i < m;i++)
		{
			printf("#");
		}
		for(i = 0;i < n-m;i++)
		{
			printf("-");
		}
		printf("] %d%%\n",num);
	}
	
	return 0;
}
