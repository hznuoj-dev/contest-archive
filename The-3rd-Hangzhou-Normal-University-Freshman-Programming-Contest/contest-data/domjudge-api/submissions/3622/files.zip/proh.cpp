#include <stdio.h>
int main()
{
	long n,i,x,y;
	double p;
	scanf("%ld",&n);
	while(n--)
	{
		scanf("%ld%ld",&x,&y);
		char a[x+2];
		a[0]='[';
		a[x+1]=']';
		a[x+2]='\0';
		for(i=1;i<=x;i++)
		{
			if(i<=y)
			a[i]='#';
			else
			a[i]='-';
		}
		p=100.0*y/x;
		if(p>=1||p==0)
		printf("%s %.0lf%%\n",a,p);
		else if(p<1&&p>=0.1)
		printf("%s %.1lf%%\n",a,p);
		else if(p<0.1&&p>=0.01)
		printf("%s %.2lf%%\n",a,p);
		else if(p<0.01&&p>=0.001)
		printf("%s %.3lf%%\n",a,p);
	}
	return 0;
}
