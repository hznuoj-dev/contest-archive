#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d %d",&n,&m);
		int y[n+1][n+1],p[n+1];
		if(n==1)printf("1\n");
		else{
			while(m--){
				int a,b;
				scanf("%d %d",&a,&b);
				y[a][b]=1;
				y[b][a]=-1;
			}
			for(int i=1;i<=n;i++){
				p[i]=0;
			}
			for(int i=1;i<n+1;i++){
				for(int j=i+1;j<n+1;j++){
					if(y[i][j]==1 ){
						p[j]=p[i]-1;
					}else if(y[i][j]==-1){
						p[j]=p[i]+1;
					}
				}
			}
			int b[n+1],max,h;
			for(int i=1;i<=n;i++){
				b[i]=i;
			}
			for(int i=1;i<=n;i++){
				max=i;
				for(int j=i+1;j<=n;j++){
					if(p[max]<p[j]){
						max=j;
					}
				}
				if(max!=i){
					h=p[i],p[i]=p[max],p[max]=h;
					h=b[i],b[i]=b[max],b[max]=h;
				}
			}
			for(int i=1;i<n+1;i++){
				if(i!=1)printf(" %d",b[i]);
				else printf("%d",b[i]);
			}
			printf("\n");	
		}
		
	}
}
