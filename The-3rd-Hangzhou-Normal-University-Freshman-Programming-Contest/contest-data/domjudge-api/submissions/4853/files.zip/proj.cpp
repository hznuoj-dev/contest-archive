#include<stdio.h>
#include<string.h>
int main()
{
	int n,m,len,i,j,t=0,sum=0,flag=1;
	char a[10000];
	scanf("%d",&n);
	while(n--)
	{
		scanf("%d",&m);
		while(m--)
		{
			scanf("%s",a);
			len=strlen(a);
			for(i=0;i<len;i++)
			{
				if(i==1)
				{if(a[i]!='.')
				t++;
				}
				else//i>1
				{  if(a[i]!='.') 
				   {for(j=0;j<i&&flag;j++)//���� 
				    {
					if(a[i]!=a[j])
					flag=1;
					else if(a[i]==a[j])
					flag=0;
				    }
				    if(flag==1)
				    t++;
				   }
			    }
			}
			sum+=t;
			t=0;
		}
		printf("%d\n",sum);
		sum=0;
	}
	return 0;
}
