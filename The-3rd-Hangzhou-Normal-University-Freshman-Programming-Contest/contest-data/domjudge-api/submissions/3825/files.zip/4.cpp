#include <bits/stdc++.h>
using namespace std;
int a[114514];
int main() {
	int n,x;
	long long res=1;
	cin>>n;
	for (int i=1;i<=n;i++) {
		cin>>x;
		a[x]++;
	}
	int index=100000;
	while (a[index]==0) index--;
	for (int i=index;i>=2;i--) {
		for (int j=1;j<=a[i];j++) {
			res=(res%998244353)*(a[i-1]%998244353)%998244353;
		}
	}
	cout<<res;
}
