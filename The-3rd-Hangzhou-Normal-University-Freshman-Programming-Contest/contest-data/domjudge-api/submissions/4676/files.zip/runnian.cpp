#include<stdio.h>
int main()
{
int year,leap,a,b,c,t,d;
scanf("%d",&d);
while(d--){
        int k=0;
scanf("%d%d",&a,&b);
c=a+b;
if(c>9999)c=9999*2-c;
if(c<a){
    t=a;
    a=c;
    c=t;
}
for(year=a;year<=c;year++){
if(year%4==0)
{
if(year%100==0)
{
if(year%400==0)
leap=1;
else leap=0;
}
else leap=1;
}
else
leap=0;
if(leap)k++;
}
printf("%d\n",k);
}
return 0;
}
