#include<cstdio>
int main(){
	int T,n,a,b,x,y,ans=0;
	scanf("%d",&T);
	while (T--){
		scanf("%d%d",&a,&b);
		printf("[");
		for (int i=1;i<=b;++i){
			printf("#");
		}
		for (int i=b+1;i<=a;++i){
			printf("-");
		}
		printf("] ");
		if (a==b) printf("100%%");
		else printf("%d%%",b*100/a);
		printf("\n");
	}
    return 0;
}
