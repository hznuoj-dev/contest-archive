#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	int a;
	scanf("%d",&a);
	while(a--)
	{
		char c[1000000];
		int j,i,b,len,sum,sum1=0;
		scanf("%d",&b);
		gets(c);
		for(i=1;i<=b;i++)
		{
			sum=0;
			int f[256]={0};
			gets(c);
			len=strlen(c);
			for(j=0;j<len;j++)
			{
				if(c[j]!='.')
				{
					f[c[j]]=f[c[j]]+1;
				} 
			}
			for(j=0;j<=256;j++)
			{
				if(f[j]!=0)
				{
					sum=sum+1;
				}
			}
			sum1=sum1+sum;
		}
		printf("%d\n",sum1-b);
	}
 } 
