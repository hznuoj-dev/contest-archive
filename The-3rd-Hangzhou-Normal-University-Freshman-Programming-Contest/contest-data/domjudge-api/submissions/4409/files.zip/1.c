#include<stdio.h>
#include<string.h>
int main() {
	int t, n, i, j, len1, len2, sum = 0, all = 0, flag = 0;
	char s[1000000], m[10000], p, q;
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &n);
		all = 0;
		m[sum] = '.';
		sum = 0;
		while (n--) {
			getchar();
			gets(s);
			len1 = strlen(s);
			for (i = 0; i < len1; i++) {
				for (j = 0; j <= sum; j++) {
					p = m[j];
					q = s[i];
					if (q == p) {
						flag = 1;
					}
				}
				if (flag == 0) {
					sum += 1;
					m[sum] = q;
				}
				flag = 0;
			}
			all += sum;
			for (i = 1; i <= sum; i++) {
				m[sum] = ' ';
			}
			sum = 0;
		}
		printf("%d\n", all);
	}
}