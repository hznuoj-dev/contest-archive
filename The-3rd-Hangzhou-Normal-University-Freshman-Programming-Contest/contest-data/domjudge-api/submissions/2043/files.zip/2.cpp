#include <stdio.h>
#include <math.h>
int main (){
	int t;
	long a,b,x=0;
	long m,n;//if���������� 
	scanf("%d",&t);
	while(t--){
		scanf("%ld %ld",&a,&b);
		long c,q;
		c=a+b;
		if(c>9999){
			long d=0;
			d=c-9999;
			m=a;
			n=a+d;
		
	     	if(m>=n){//n,m
			for(long i=n;i<=m;i++){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				}
		    	}
	    	}
	    	else{
		    	for(long i=m;i<=n;i++){
				  if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				 }
			     }	
		    }
		}
		else{
				if(a>=c){//c,a
			for(long i=c;i<=a;i++){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				}
		    	}
	    	}
	    	else{
		    	for(long i=a;i<=c;i++){
				  if((i%4==0&&i%100!=0)||(i%400==0)){
					x+=1;
				 }
			     }	
		}
        }
			printf("%ld\n",x);
		x=0;
	}
	
	return 0;
} 
