//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 100010;

int n, m, dp[MAXN], vis[MAXN];
vector<int>tp, num, coin, ans;

int main() {

#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);
	
	memset(dp, 0, sizeof(dp));
	memset(vis, 0, sizeof(vis));

	int n, m, a, cnt = 0;
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a);
		tp.push_back(a);
	}
	for (int i = 0; i < n; ++i) {
		scanf("%d", &a);
		num.push_back(a);
	}
	for (int i = 0; i < n; ++i) {
		for (int j = 0; j < num[i]; ++j) {
			coin.push_back(tp[i]);
		}
	}
	sort(coin.begin(), coin.end());
	
	for (int i = 0; i < coin.size(); ++i) {
		for (int j = m; j >= coin[i]; --j) {
			if (dp[j] <= dp[j - coin[i]] + coin[i]) {
				dp[j] = dp[j - coin[i]] + coin[i];
			}
			if (dp[j] <= m && dp[j] > 0){
				vis[dp[j]] = 1;
			}
		}
	}
	for (int i = 1; i <= m; ++i){
		if (vis[i] == 1) cnt++;
	}
	printf("%d\n", cnt);

	return 0;
}
