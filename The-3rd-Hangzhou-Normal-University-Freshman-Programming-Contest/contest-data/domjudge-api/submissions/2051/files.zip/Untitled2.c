#include<stdio.h>
int main(){
	int t,y,a;
	int y2,sum,i;
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d%d",&y,&a);
		if(y+a>=10000)
			y2=9999-(y+a-9999);
		else
			y2=y+a;	
		if(y2<y){
			int n;
			n=y;
			y=y2;
			y2=n;
		}	
		for(i=y;i<=y2;i++){
			if((i%4==0&&i%100!=0)||i%400==0)
				sum++;
		}
		printf("%d\n",sum);
	}
	return 0;
} 
