#include<stdio.h>
int main()
{
	int a,b,c,d,A,B,C,D;
	int sum1=0,n=0;
	int sum2=0,sum3=0,sum4=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	A=a;B=b;C=c;D=d;
	while(a>0){
		A=a%10;
		sum1+=A;
		a=a/10;
	}
	if(sum1>=16||sum1==6){
		n++;
	}

	while(b>0){
		B=b%10;
		sum2+=B;
		b=b/10;
	}
	if(sum2>=16||sum2==6){
		n++;
	}

	while(c>0){
		C=c%10;
		sum3+=C;
		c=c/10;
	}
	if(sum3>=16||sum3==6){
		n++;
	}

	while(d>0){
		D=d%10;
		sum4+=D;
		d=d/10;
	}
	if(sum4>=16||sum4==6){
		n++;
	}

	if(n==0){
		printf("Bao Bao is so Zhai......\n");
	}else if(n==1){
		printf("Oh dear!!\n");
	}else if(n==2){
		printf("BaoBao is good!!\n");
	} else if(n==3){
		printf("Bao Bao is a SupEr man///!\n");
	}else if(n==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	 return 0;
 } 
