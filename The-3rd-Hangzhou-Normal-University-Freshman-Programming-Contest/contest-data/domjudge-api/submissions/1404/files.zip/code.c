#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
    int t,q,w,e=0,r=0,i,s;
    scanf("%d", &t);
    while (t--) {
        s = 0;
        scanf("%d %d", &q, &w);
        e = q + w;
        if (e >= 10000) {
            r = e - 9999;
            e = 9999 - r;
        }
        if (e < q) {
            for (i = e; i <= q; i++) {
                if ((i % 4 == 0&i%100!=0)||i%400==0) {
                    s++;
                }
            }
        }
        else {
            for (i = q; i <= e; i++) {
                if ((i % 4 == 0 & i % 100 != 0) || i % 400 == 0) {
                    s++;
                }
            }
        }
        printf("%d\n", s);
    }
    return 0;
}