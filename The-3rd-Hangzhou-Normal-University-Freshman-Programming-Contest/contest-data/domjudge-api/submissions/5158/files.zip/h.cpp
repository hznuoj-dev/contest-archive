#include<stdio.h>
int main(void){
	int n,a,b,i;
	scanf("%d",&n);
	while(n--){
		scanf("%d %d",&a,&b);
		printf("[");
		for(i=1;i<=a;i++){
			if(i<=b) printf("#");
			else printf("-");
		}
		printf("] %.0f%%\n",(float)b*1.0/a*100);
	}
}
