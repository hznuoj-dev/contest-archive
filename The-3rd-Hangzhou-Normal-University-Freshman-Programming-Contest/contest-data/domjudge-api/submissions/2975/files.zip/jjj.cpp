#include<stdio.h>
#include<string.h>
char s[1000000];
int main(){
int t,i,j;
scanf("%d",&t);
while(t--){
	int n,count=0,f=1;
	scanf("%d",&n);
	while(n--){
		scanf(" %[^\n]",s);
		for(i=0;i<strlen(s);i++){
			if(s[i]!='.'){
				if(i==0)count++;
				else {
				for(j=0;j<i;j++){
				if(s[i]==s[j]){
				f=0;break;
				}	
			}
			if(f==1)count++;
				}
			
			}
		}
	}
	printf("%d\n",count);
}
	return 0;
}
