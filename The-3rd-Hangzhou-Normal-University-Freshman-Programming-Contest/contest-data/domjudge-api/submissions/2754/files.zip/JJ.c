#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
char a[1000001];
int b[1000001];
int main(int argc, char *argv[]) {
	int t,n,sum,i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		sum=0;
		while(n--){
			scanf("%s",a);
			for(i=0;i<strlen(a);i++){
				if(a[i]!='.'){
					b[a[i]]=0;
				}
			}
			for(j=0;j<strlen(a);j++){
				if(a[j]!='.'){
					b[a[j]]+=1;
					if(b[a[j]]==1)
					sum+=1;
				}

			}
		}
		printf("%d\n",sum);
	}
	return 0;
}


