#include <stdio.h>
#include<string.h>
int main() {
long long t,m=0,i;
char s[10008];
scanf("%lld",&t);
for(i=1;i<=t;i++){
	scanf("%s",s);
	m+=strlen(s);
}
	printf("%lld",m);
	return 0;
}
