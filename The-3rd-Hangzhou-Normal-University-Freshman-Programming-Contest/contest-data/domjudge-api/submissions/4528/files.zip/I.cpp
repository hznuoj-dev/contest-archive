#include<stdio.h>

int main(){
	int A,B,C,D;
	scanf("%d %d %d %d",&A,&B,&C,&D);
	int a=0,b=0,c=0,d=0;
	int count=0;
	while(A!=0){
		a = a + A%10;
		A = A / 10;
	}
	if(a>=16||a==6){
		count++;
	}
	while(B!=0){
		b = b + B%10;
		B = B / 10;
	}
	if(b>=16||b==6){
		count++;
	}
	while(C!=0){
		c = c + C%10;
		C = C / 10;
	}
	if(c>=16||c==6){
		count++;
	}
	while(D!=0){
		d = d + D%10;
		D = D / 10;
	}
	if(d>=16||d==6){
		count++;
	}
	if(count==1){
		printf("Oh dear!!\n");
	}else if(count==2){
		printf("BaoBao is good!!\n");
	}else if(count==3){
		printf("Bao Bao is a SupEr man///!\n");
	}else if(count==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}else{
		printf("Bao Bao is so Zhai......\n");
	}
	
	return 0;
}
