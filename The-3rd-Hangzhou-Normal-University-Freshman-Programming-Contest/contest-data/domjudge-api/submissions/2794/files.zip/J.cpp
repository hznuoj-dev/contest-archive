#include<bits/stdc++.h>
using namespace std;
int x[128];
int main()
{
	int t;
	cin>>t;
	while(t)
	{
		int n;
		string s;
		cin>>n;
		int count=0;
		int k=1;
		while(k<=n)
		{
			cin>>s;
			int i=0;
			while(i<=s.length()-1)
			{
				if(s[i]!='.')
				{
					if(x[s[i]]!=k)
					{
						count++;
						x[s[i]]=k;
					}
				}
				i++;
			}
			k++;	
		}
		int i=0;
		while(i<=127)
		{
			x[i]=0;
			i++;
		}
		cout<<count;
		if(--t) cout<<endl;
	}
}

