#include<stdio.h>
#include<string.h>
int main()
{
	int t,x,i,j,n,count,sum;
	char a[10000];
	scanf("%d",&t);
	while(t--)
	{
       count=0;
      scanf("%d",&x);
	  while(x--)
	  {
	   scanf("s",a);
	   sum=0;
	   n=strlen(a);
       for(i=0;i<n;i++)
       {
	    if(a[i]=='.')
	    {
	    	sum++;
		}
		for(j=0;j<i;j++)
        
          if(a[i]==a[j]) break;
           if(j>=i) count++;
          }
		if(sum>0)
		{
		count--;  }
	  }  
	   printf("%d\n",count);
    }
 
	}


