#include<stdio.h>
#include<math.h>
#include<string.h>
int yesorno(int x)
{
	if (x % 4 == 0 && x % 100 != 0 || x % 400 == 0)
		return 1;
	else
		return 0;
}
int main()
{
	int total, t, year, addyear,lastyear, yichu,  i,z;
	scanf("%d", &t);
	while (t--)
	{
		total = 0;
		scanf("%d %d", &year, &addyear);
		lastyear = year + addyear;
		if (lastyear > 9999)
		{
			yichu = lastyear - 9999;
			lastyear = 9999 - yichu;
		}
		if (year > lastyear)
		{
			z= year;
			year = lastyear;
			lastyear = z;
		}
		for (i = year; i <= lastyear; i++)
		{
			if (yesorno(i) == 1)
				total++;
		}
		printf("%d\n", total);
	}
}
