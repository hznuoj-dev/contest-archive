#include<bits/stdc++.h>
using namespace std;
int cut(long long int n)
{
	int res=0;
	while(n)
	{
		res+=n%10;
		n/=10;
	}
	return res;
}
int main()
{
	long long int a, b, c, d;
	cin>>a>>b>>c>>d;
	int cnt=0;
	if(cut(a)==6 || cut(a)>=16) cnt++;
	if(cut(b)==6 || cut(b)>=16) cnt++;
	if(cut(c)==6 || cut(c)>=16) cnt++;
	if(cut(d)==6 || cut(d)>=16) cnt++;
	if(cnt==0) printf("Bao Bao is so Zhai......");
	else if(cnt==1) printf("Oh dear!!");
	else if(cnt==2) printf("BaoBao is good!!");
	else if(cnt==3) printf("Bao Bao is a SupEr man///!");
	else if(cnt==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}


