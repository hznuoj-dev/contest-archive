#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main(void)
{
	int n,i,j,n1,n2,s;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		s=0;
		scanf("%d%d",&n1,&n2);
		if(n1+n2<=9999)
		{
			if(n1+n2<n1)
			{
				for(j=n1+n2;j<=n1;j++)
				{
					if((j%4==0&&j%100!=0)||j%400==0)
						s+=1;
				}
			}
			else
			{
				for(j=n1;j<=n1+n2;j++)
				{
					if((j%4==0&&j%100!=0)||j%400==0)					
						s+=1;
				}
			}
		}
		else
		{
			if(19998-n1-n2<n1)
			{
				for(j=19998-n1-n2;j<=n1;j++)
				{
					if((j%4==0&&j%100!=0)||j%400==0)					
						s+=1;					
				}
			}
			else
			{
				for(j=n1;j<=19998-n1-n2;j++)
				{
					if((j%4==0&&j%100!=0)||j%400==0)					
						s+=1;					
				}
			}
		}
		printf("%d\n",s);
	}
	return 0;
}


