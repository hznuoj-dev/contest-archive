


#include<stdio.h>
#include<string.h>
char m[100000][100];
int main()
{
	int n,i,j,f;
	int len,sum=0;
	int p[27];
	scanf("%d",&n);
	for(i=0;i<=26;i++)
		p[i]=0;
	for(i=1;i<=n;i++)
	{
		scanf("%s",m[i]);
		len=strlen(m[i]);
		for(j=0;j<len;j++)
		{
			f=m[i][j]-96;
			p[f]++;
		}
		sum+=len;
	}
	for(i=1;i<=26;i++)
	{
		if(p[i]>0)
		sum+=p[i]-1;
	}
	printf("%d\n",sum);
	return 0;
}

