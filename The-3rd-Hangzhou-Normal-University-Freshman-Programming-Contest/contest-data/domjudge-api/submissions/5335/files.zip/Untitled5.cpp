#include<stdio.h>
int main(){
	int T,n,m,x;
	float t;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&m);
	    printf("[");
	    for(int i=0;i<m;i++){
	    	printf("#");
		}
		for(int i=0;i<n-m;i++){
	    	printf("-");
		}
		printf("]");
		t=m/(float)n;
		x=t*100;
		printf(" %d%%\n",x);
	}
}
