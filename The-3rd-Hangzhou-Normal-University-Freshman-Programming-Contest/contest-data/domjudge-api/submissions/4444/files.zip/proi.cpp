#include<stdio.h>
int main()
{
	int a[5],i,sum=0,x,t=0;
	for(i=1;i<=4;i++)
	{
		scanf("%d",&a[i]);
		sum=0;
		while(a[i]!=0)
		{
			x=a[i]%10;
			a[i]=a[i]/10;
			sum+=x;
		}
		if(sum==6||sum>=16)
		t++;
	}
	if(t==0)
	printf("Bao Bao is so Zhai......");
	else if(t==1)
	printf("Oh dear!!");
	else if(t==2)
	printf("BaoBao is good!!");
	else if(t==3)
	printf("Bao Bao is a SupEr man///!");
	else if(t==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
