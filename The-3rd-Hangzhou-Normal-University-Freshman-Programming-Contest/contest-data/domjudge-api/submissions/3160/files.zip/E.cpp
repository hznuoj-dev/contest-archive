#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<set>
#include<map>
#include<iostream>
#include<string>
#include<queue>
using namespace std;
typedef long long int ll;
const int N=1e5+100;
int main(){
	//init();
	//int T;
//	scanf("%d",&T);
//	while(T--){
	//	run();
//	}
	puts(" __      _____");
	puts("|  | ___/ ____\\____");
	puts("|  |/ /\\   __\\/ ___\\");
	puts("|    <  |  | \\  \\___");
	puts("|__|_ \\ |__|  \\___  >");
	puts("     \\/           \\/");
	return 0;
}

