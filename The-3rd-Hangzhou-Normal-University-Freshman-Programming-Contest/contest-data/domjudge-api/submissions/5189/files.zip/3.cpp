#include"stdio.h"
#include"string.h"
 
int main()
{
  int t,n,i,j,x,len=0;
  char a[1000000];
  int s[100];
  scanf("%d",&t);
  while(t--)
  {
  	scanf("%d",&n);
  	len=0;
  	for(i=0;i<n;i++)
  	{   
  	   for(x=0;x<100;x++)
		  s[x]=0;
  		scanf("%s",a);
  		for(j=0;j<strlen(a);j++)
  		{
  		   if(a[j]!='.')
  		   {
  		  
  		   	if(s[a[j]-'!']==0)
  		   	 len++;
  		   	s[a[j]-'!']=1;
		   }
		  
		}
		
	}
	printf("%d\n",len);
	
  }
  return 0;
  	
}
