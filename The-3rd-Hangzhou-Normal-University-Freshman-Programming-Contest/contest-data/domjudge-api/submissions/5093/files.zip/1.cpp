#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;

const int maxn=1e3+10;
struct node
{
	int num;
	int pri;
	vector<int>fa;
}a[maxn];

bool cmp(node a,node b)
{
	if(a.pri==b.pri) return a.num<b.num;
	else return a.pri>b.pri;
}

int t;
int n,m;
int main()
{
//	fcin;
	cin>>t;
	while(t--)
	{
		cin>>n>>m;
		
		for(int i=1;i<=n;i++)
		{
			a[i].num=i;
			a[i].pri=0;
			a[i].fa.clear();
		}
		while(m--)
		{
			int p,q;
			cin>>p>>q;
			a[p].pri=a[q].pri+1;
			a[q].fa.push_back(p); 
			if(a[p].fa.size())
			{
				for(int i=0;i<a[p].fa.size();i++)
				{
					a[a[p].fa[i]].pri=a[p].pri+1;
				}
			}
		}
		
		sort(a+1,a+n+1,cmp);
		for(int i=1;i<=n;i++)
		{
			cout<<a[i].num<<(i==n?'\n':' ');
		}
	}
	return 0;
}
