#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int sum,n,bu,cen,i,j,q,w,len,sum1=0;
	char str[101][1000];
    scanf("%d",&n);
    getchar(); 
    for(bu=0;bu<n;++bu){
    	sum1=0;
    	scanf("%d",&cen);
    	getchar();
    	for(i=0;i<cen;++i){
    	scanf("%s",str[i]);
    	getchar();
        }
    	for(j=0;j<cen;++j){
    		sum=0;
    		len=strlen(str[j]);
    		for(q=0;q<len-1;++q){
    			for(w=q+1;w<len;++w){
    				if(str[j][q]==str[j][w]){ 
    				str[j][w]=str[j][len-1];
    				len--;
    				w--;
    				} 
				}
			}
			for(q=0;q<len;++q){
				if(str[j][q]!='.')
				sum++; 
			}
			sum1+=sum;
		}
		printf("%d\n",sum1);
	}
	return 0;
}
