#include<stdio.h>
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int Y,A,s,m;
		int sum=0,i;
	   scanf("%d %d",&Y,&A);
		s=Y+A;
		if(10000<=s){
			s=9999-(s-10000);
		}
		if(Y>s){
			m=s;
			s=Y;
			Y=m;
		} 
		for(i=Y;i<s;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				sum++;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
} 

