#include<iostream>

using namespace std;

int main()
{
    int i,n,j,year,year1,cou=0,add;
    cin >> n;
    for(i=1;i<=n;i++)
    {
        cou=0;
        cin >> year >>add;
        year1=year+add;
        if(year1>=10000)
        {
            year1=9999-(year1-9999);
        }
        if(year1<year)
        {
            j=year;
            year=year1;
            year1=j;            
        }
        for(j=year;j<=year1;j++)
        {
            if(j>0)
            {
                if(j%400==0 ||(j%4==0 && j%100!=0))
                    cou++;
            }
            else
            {
                j--;
                if(j%400==0 ||(j%4==0 && j%100!=0))
                    cou++;
            }
        }
        cout << cou << endl;
        
    }
    
    return 0;
}