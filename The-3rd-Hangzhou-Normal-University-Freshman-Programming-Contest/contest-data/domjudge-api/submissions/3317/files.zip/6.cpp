#include<stdio.h>
int main(){
	int kt[4];
	int i,r,sum,c=0,n;
	scanf("%d %d %d %d",&kt[0],&kt[1],&kt[2],&kt[3]);
	for(i=1;i<=4;i++){
		sum=0;
	 n=kt[i];
	while(n>0){
		r=n%10;
		sum+=r;
		n/=10;
	}
	if(sum>=16||sum==6){
		c++;
	}
	}
	if(c==0){
		printf("Bao Bao is so Zhai......");
	}
	if(c==1)printf("Oh dear!!");
	if(c==2)printf("BaoBao is good!!");
	if(c==3)printf("Bao Bao is a SupEr man///!");
	if(c==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
} 
