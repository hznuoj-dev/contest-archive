#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t,n,i,x[100],j,k,sum;
	char y[1000000];
	    scanf("%d",&t);
	    while(t--){
	    	sum=0;
	    	scanf("%d",&n);
	    	for(i=0;i<n;i++){
	    		scanf("%s",&y);
	    		for(j=0;y[j];j++){
	    			for(k=0;k<j;k++){
	    				if(y[j]==y[k]) break;
					}
					if(k==j&&y[j]!='.') sum++;
				}
			}
			printf("%d\n",sum);
		}
	return 0;
} 
