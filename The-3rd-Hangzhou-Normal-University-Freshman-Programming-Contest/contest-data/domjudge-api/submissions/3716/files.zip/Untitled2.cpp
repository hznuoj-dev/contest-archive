#include<stdio.h>
int main(void){
	long long int a[4];
	int sum=0,b,s=0,i;
	for(i=0;i<4;i++){
	scanf("%d",&a[i]);
	while(a[i]>0){
		b=a[i]%10;
		sum=sum+b;
		a[i]=a[i]/10;
	}
	if(sum>=16||sum==6){
		s=s+1;
	}
	sum=0;
	}
	if(s==0)
		printf("Bao Bao is so Zhai......");
	if(s==1)
		printf("Oh dear!!");
	if(s==2)
		printf("BaoBao is good!!");
	if(s==3)
		printf("Bao Bao is a SupEr man///!");
	if(s==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
