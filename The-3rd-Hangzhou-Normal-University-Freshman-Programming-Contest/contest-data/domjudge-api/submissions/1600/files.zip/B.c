#include<stdio.h>
int main()
{
	int t,cnt;
	int y,a,min,max,i,temp;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&y,&a);
		min=y;
		max=y+a;
		if(max>=10000)
		{
			max=9999-(max-9999);
		}
		if(max<min)
		{
			temp=max;
			max=min;
			min=temp;
		 } 
		cnt=0;
		for(i=min;i<=max;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
				cnt+=1;
		}
		printf("%d\n",cnt);
	}
}
