import java.util.ArrayList;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class J {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        for (int i = 0; i < t; i++) {//每房
            int n = in.nextInt(), cont = 0;
            for (int j = 0; j < n; j++) {//每层
                Set<String> list = new HashSet<>();
                String str = in.next();
                str = str.replace(".", "");
                for (int i1 = 0; i1 < str.length(); i1++) {//每个垃圾
                    list.add(str.substring(i1,i1+1));
                }
                System.out.println(list);
                cont+=list.size();
            }
            System.out.println(cont);
        }
    }
}
