#include<stdio.h>
int isprime(int a);
int main(){
	int T,a,b,c,end,i,sum;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&a,&b);
		sum=0;
		c=a+b;
		if(c>9999)
		end=9999-(c-9999);
		else
		end=c;
		if(end>a){
		for(i=a;i<=end;i++){
			if(isprime(i))
			sum=sum+1;
		} 
	    }
		else
		{
		for(i=end;i<=a;i++){
		if(isprime(i)==1)
		sum+=1;
		}
	    }
		printf("%d\n",sum);
	}
} 
int isprime(int a){
	if((a%4==0&&a%100!=0)||(a%400==0))
	return 1;
	else
	return 0;
}
