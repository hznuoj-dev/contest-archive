#include<bits/stdc++.h>
using namespace std;
bool rn(int n){
	if(n%400==0||n%4==0&&n%100!=0) return true;
	return false;
}

int main(){
	string s;
	cin>>s;
	if(s[0]==107&&s[1]==102&&s[2]==99&&s.size()==3){
		printf(" __      _____\n"
			"|  | ___/ ____\\____\n"
			"|  |/ /\\   __\\/ ___\\\n"
			"|    <  |  | \\   \\___\n"
			"|__|_ \\ |__|   \\___  >\n"
			"     \\/           \\/");
	}
}
