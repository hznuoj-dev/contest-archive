#include <stdio.h>
#include<string.h>

int main() {
	int T;
	scanf("%d",&T);
	while(T--){
		int n;
		scanf("%d",&n);
		int sum=0;
		while(n--){
			char ch[1000000]={};
			int x=0;
			char str[1000000];
			scanf("%s",str);
			int i,j;
			for(i=0;i<strlen(str);++i){
				if(str[i]!='.'){
					int flag=1;
					for(j=0;j<strlen(ch);++j){
						if(ch[j]==str[i]){
							flag=0;
							break;
						}
					}
					if(flag==1){
						ch[x]=str[i];
						x++;
					}
				}
			}
			sum=sum+x;
		}
		printf("%d\n",sum);
	}
	return 0;
}

