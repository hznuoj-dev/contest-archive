#include<stdio.h>
int main(){
	int T;
	int n,m,d,b,c;
	scanf("%d",&T);
	while(T--){
	    int max=0,flag=1;
		int a[1010]={0};
		scanf("%d%d",&n,&m);
		while(m--){
			scanf("%d%d",&b,&c);
			a[c]++;
			if(max<a[c]){
				max=a[c];
			}
		}
		for(int i=0;i<=max;i++){
			for(int j=1;j<=n;j++){
			if(a[j]==i){
				if(flag==1){
				 printf("%d",j);
				 flag=0;
				}
				else
				 printf(" %d",j);
			}
		}
		}
		printf("\n");
}
}
