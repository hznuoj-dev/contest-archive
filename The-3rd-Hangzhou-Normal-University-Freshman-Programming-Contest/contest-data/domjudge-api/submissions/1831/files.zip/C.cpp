#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main(){
	int n,k,i,a,b,c,h,y,temp;
	char s[100];
	scanf("%s",s);
	printf(" --      -----\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\ \n");
	printf("|    <  |  |  \\ \\___\n");
	printf("|__|_ \\ |__|   \\___ >\n");
	printf("    \\/            \\/\n");




	getchar();
	getchar();
	return 0;
}
//int cmp(const void*p,const void*q){
//return((struct kx*)q)->average -(struct kx*)p)->average)
//}