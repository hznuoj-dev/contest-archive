#include<iostream>
using namespace std;

int main(){
    int a[4];
    int b,c,h=0;
	for(int i=0;i<=3;i++){
		cin>>a[i];
	}
	for(int i=0;i<=3;i++){
		b=a[i];
		int s=0;
		while(b>0){
			c=b%10;
			s=s+c;
			b=b/10;
		}
		if(s>=16||s==6){
			h=h+1;
		}
	}
	if(h==0)
		cout<<"Bao Bao is so Zhai......"<<endl;
	else if(h==1)
		cout<<"Oh dear!!"<<endl;
	else if(h==2)
		cout<<"BaoBao is good!!"<<endl;
	else if(h==3)
		cout<<"Bao Bao is a SupEr man///!"<<endl;
	else
		cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;
	return 0;
}

