//
//  main.cpp
//  c++_02
//
//  Created by 李尚鑫 on 2020/12/7.
//
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include <map>
using namespace std;
const int N = 1005;
int fa[N];
int ans[N];
int buf[N];
int findfa(int x) {
    return fa[x];
}

void unin(int u,int v) {
    if (fa[v]==v) {
        fa[v] = u;
        return ;
    }
    if (fa[v]<u) {
        fa[u] = fa[v];
        fa[v] = u;
    }else {
        fa[fa[v]] = u;
    }
}
void ini (int size) {
    for (int i=1; i<=size; i++) {
        fa[i] = i;
        buf[i] = 0;
    }
}
int flag;
void fun(int x,int n) {
    if (flag==x) return ;
    for (int i=1; i<=n; i++) {
        if (i==x) continue;
        if (findfa(i)==x) {
            printf(" %d",i);
            return fun(i,n);
        }
    }
}
int main () {
    int t;
    scanf("%d",&t);
    while (t--) {
        int n,m;
        cin >> n >> m;
        ini(n);
        while (m--) {
            int x,y;
            cin >> x >> y;
            unin(x,y);
            buf[x]++;
        }
        int dp = buf[1];
        for (int i=2; i<=n; i++) {
            if (dp>buf[i]) flag = i;
        }
        for (int i=1; i<=n; i++) {
            if (findfa(i)==i) {
                printf("%d",i);
                fun(i,n);
                //printf(" %d",flag);
                break;
            }
        }
    }
}
