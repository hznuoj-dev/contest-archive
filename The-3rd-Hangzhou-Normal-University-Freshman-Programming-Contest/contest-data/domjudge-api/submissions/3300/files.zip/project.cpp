#include<stdio.h>
#include<string.h>
#include<math.h>
int main() {
long long a;
int i,d,b;
d=0;
for(i=1;i<=4;i++){
	b=0;
	scanf("%lld",&a);
	while(a>0){
		b=b+a%10;
		a=a/10;
	}
	if(b>=16||b==6){
		d=d+1;
	}
}
if(d==0){
	printf("Bao Bao is so Zhai......\n");
}
else
if(d==1){
	printf("Oh dear!!\n");
}
else
if(d==2){
	printf("BaoBao is good!!\n");
}
else
if(d==3){
	printf("Bao Bao is a SupEr man///!\n");
}
else
printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
} 

