#include <iostream>
using namespace std;

int takeapart(long long int n)
{
    int res = 0;
    while (n != 0)
    {
        res += n % 10;
        n /= 10;
    }
    return res;
}

int main()
{
    long long int a, count = 0;
    for (int i = 1; i <= 4; i++)
    {
        cin>>i;
        if(takeapart(i)>=16||takeapart(i)==6) count++;
    }
    switch (count)
    {
        case 0:cout<<"Bao Bao is so Zhai......"<<endl;break;
        case 1:cout<<"Oh dear!!"<<endl;break;
        case 2:cout<<"BaoBao is good!!"<<endl;break;
        case 3:cout<<"Bao Bao is a SupEr man///!"<<endl;break;
        case 4:cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;break;
    }
    return 0;
}