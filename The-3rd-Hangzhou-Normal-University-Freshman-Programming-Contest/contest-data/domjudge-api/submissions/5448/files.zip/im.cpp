#include<stdio.h>
#include<math.h>
int main()
{
	int s,sum,b,x,i,m,n,d,a;
	x=0;
	for(i=0;i<4;i++)
	{
		s=0;
		sum=0;
		scanf("%d",&a);
		d=a;
		while(d/10!=0){
		s++;
		d=d/10;}
		s++;
		for(b=s;b>=1;b--){
			m=pow(10,b);
			n=pow(10,b-1);
			sum=sum+(a%m)/n;
		}
		if(sum==6||sum>=16)
		x++;
	}
	if(x==1)
	printf("Oh dear!!");
	else if(x==2)
	printf("BaoBao is good!!");
	else if(x==3)
	printf("Bao Bao is a SupEr man///!");
	else if(x==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(x==0)
	printf("Bao Bao is so Zhai......");
	printf("\n");
	return 0;
}
