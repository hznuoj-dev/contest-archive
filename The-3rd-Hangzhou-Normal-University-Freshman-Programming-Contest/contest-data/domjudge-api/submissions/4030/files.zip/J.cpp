#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void)
{
	int t,n,i,j,sum,x;
	char aii[200];
	scanf("%d",&t);
	while(t--)
	{x=0;
	scanf("%d",&n);
	getchar();
	while(n--)
	{  sum=0;
		fgets(aii);
		for(j=0;j<strlen(aii);++j)
		{
			if(aii[j]!='.'){
		for(i=0;i<strlen(aii);++i)
		{
			if(aii[j]==aii[i]&&j!=i&&aii[j]!='.')
			{
				aii[i]='.';
			}
		}
		aii[j]='.';
		sum=sum+1;}
		}
		x=x+sum;
	}
	printf("%d\n",x);
	}
	return 0;
}