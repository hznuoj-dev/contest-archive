#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m,s,i;
		scanf("%d %d",&n,&m);
		s=m*100/n;
		printf("[");
		for(i=0;i<m;i++){
			printf("#");
		}
		for(;i<n;i++){
			printf("-");
		}
		printf("] %d%%\n",s);
	}
	
	
}
