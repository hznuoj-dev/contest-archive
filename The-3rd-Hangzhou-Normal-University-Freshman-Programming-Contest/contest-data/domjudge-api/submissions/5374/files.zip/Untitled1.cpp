#include <stdio.h>
#include <string.h>
typedef struct ybzl
{
	int a;
	int b;
}YB;
int main()
{
	int i,j,n,k,m,h,je,sum=0,t,flag=0;
	scanf("%d %d",&n,&m);
	YB yb[n+1],yb1[n+1];
	for(i=1;i<=n;i++)
	{
		scanf("%d",&yb[i].a);
	}
	for(i=1;i<=n;i++)
	{
		scanf("%d",&yb[i].b);
	}
	for(i=1;i<=n;i++)
	{
		for(j=i;j<=n;j++)
		{
			if(yb[j].a>yb[j+1].a)
			{
				t=yb[j].a;
				yb[j].a=yb[j+1].a;
				yb[j+1].a=t;
				t=yb[j].b;
				yb[j].b=yb[j+1].b;
				yb[j+1].b=t;
			}
		}
 }
	for(i=1;i<=m;i++)
	{
		flag=0;
		for(h=n;h>0;h--)
		{
			for(j=h;j>0;j--)
			{
				je=i;
				for(k=1;k<=n;k++)
				{
					yb1[k].a=yb[k].a;
					yb1[k].b=yb[k].b;
				}
				while(yb1[j].b>0&&je>=yb1[j].a)
				{
					je-=yb1[j].a;
					yb1[j].b--;
				}
				if(je==0)
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			break;
		}
		if(flag==1)
		sum++;
	}
	printf("%d\n",sum);
	return 0;
}
