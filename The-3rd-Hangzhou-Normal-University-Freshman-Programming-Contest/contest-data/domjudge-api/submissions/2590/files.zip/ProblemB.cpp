#include <iostream>
using namespace std;

inline bool IsLeapYear(int year) {
    return ((year % 4 == 0) && (year % 100 != 0)) || (year % 400 == 0);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int t;
    int lower, upper;
    int offset;
    int i, counter;

    cin >> t;
    while (t--) {
        counter = 0;

        cin >> lower >> offset;
        upper = 19998 - (lower + offset);
        if (upper < lower) {
            swap(lower, upper);
        }

        for (i = lower; i <= upper; ++i) {
            if (IsLeapYear(i)) {
                ++counter;
            }
        }

        cout << counter << '\n';
    }
    return 0;
}