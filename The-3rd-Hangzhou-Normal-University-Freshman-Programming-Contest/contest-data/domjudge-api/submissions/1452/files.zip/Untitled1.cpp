#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
using namespace std;

int main(){
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/\n");
	
} 

