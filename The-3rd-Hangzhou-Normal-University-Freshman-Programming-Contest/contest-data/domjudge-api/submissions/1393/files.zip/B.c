#include<stdio.h>
int main() {
	int i, j, k, t;
	int run(int j, int k);
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &j, &k);
		if (j + k > 9999) {
			i = j + k - 9999;
			if (9999 - i < j) {
				k = j;
				j = 9999 - i;
			}
			else {
				k = 9999 - i;
			}
		}
		else {
			if (k < 0) {
				i = k;
				k = j;
				j += i;
			}
			else {
				k += j;
			}
		}
		printf("%d\n", run(j, k));
	}
	return 0;
}
int run(int j, int k) {
	int i, n;
	n = 0;
	for (i = j; i <= k;i++) {
		if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0) {
			n++;
		}
	}
	return n;
}