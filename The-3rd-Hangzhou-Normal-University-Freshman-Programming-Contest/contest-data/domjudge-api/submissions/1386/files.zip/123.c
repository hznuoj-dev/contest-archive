#include<stdio.h>
int main(){
	int T,a,b,c,i,t;
	scanf("%d",&T);
	while(T--){
		int sum=0;
		scanf("%d %d",&a,&b);
		if(b<0){
			c=a;
			a=a+b;
		}
		if(b>0){
		if(a+b>9999){
			c=9999-(a+b-9999);
		}
		else 
		c=a+b;
	}
	if(a>c){
		t=a;
		a=c;
		c=t;
	}
	for(i=a;i<=c;i++){
		if((i%4==0&&i%100!=0)||(i%400==0)){
			sum++;
		}
	}
	printf("%d\n",sum);
	}
}
