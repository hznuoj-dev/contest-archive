#include<stdio.h>
int main(void){
int n,a,b,i,j;
scanf("%d",&n);
while(n--){
scanf("%d%d",&a,&b);
printf("[");
i=a-b;
j=b;
while(j--)
printf("#");
while(i--)
printf("-");
printf("] ");
printf("%.f%%\n",(float)b/(float)a*100);
	
} return 0;}
