#include <stdio.h>
int main()
{
	int j,t,i;
	double a,b,s;
	char c='%',e='[',z=']';
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		scanf("%lf %lf",&a,&b);
		printf("%c",e);
		for(j=1;j<=b;j++){
			printf("#");
		}
		for(j=1;j<=a-b;j++){
			printf("-");
		}
		printf("%c ",z);
		printf("%.0lf%c\n",100*b/a,c);
	}

	return 0;
}


