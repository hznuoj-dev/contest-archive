#include<stdio.h>
int main(void){
	int i=0,s=0;
	for(i=0;i<4;i++){
		int m,r,t,sum=0;
		scanf("%d",&m);
		while(m!=0){
			r=m%10;
			sum+=r;
			m/=10; 
		}
	if(16<=m||6==m){
		s++;
	}
}
	if(s==0){
		printf("Bao Bao is so Zhai......");
	}
	if(s==1){
		printf("Oh dear!!");
	}if(s==2){
		printf("BaoBao is good!!");
	}if(s==3){
		printf("Bao Bao is a SupEr man///!");
	}if(s==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
		
	
	return 0;
}
