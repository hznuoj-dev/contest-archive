#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    while(t--)
    {
    	int a,b,c,i,temp=0,q;
    	scanf("%d %d",&a,&b);
    	c=a+b;
    	if(c>9999)
    	{
    		c=9999-(a+b-9999);
		}
		if(c<a)
		{
		    q=a;
			a=c;
			c=q;	
		}
		for(i=a;i<=c;i++)
		{
		    if((i%4==0&&i%100!=0)||i%400==0)
			temp++;
			else
			temp=temp;	
		}
		printf("%d\n",temp);
		temp=0;
	}
    return 0;
}
 



