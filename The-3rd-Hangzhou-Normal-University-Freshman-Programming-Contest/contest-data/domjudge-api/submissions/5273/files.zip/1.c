#include<stdio.h>
int main(){
	
	long long a,b,c,d,e;
	e=0;
	int x,sum;
	sum=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	
	while(a>0){
		x=a%10;
		a=a/10;
		e=e+x;
	}
	if(e>=16||6==e){
		sum++;
	}
	e=0;
	while(b>0){
		x=b%10;
		b=b/10;
		e=e+x;
	}
	if(e>=16||6==e){
		sum++;
	}
	
	e=0;
	while(c>0){
		x=c%10;
		c=c/10;
		e=e+x;
	}
	if(e>=16||6==e){
		sum++;
	}
	
	e=0;
	while(d>0){
		x=d%10;
		d=d/10;
		e=e+x;
	}
	if(e>=16||6==e){
		sum++;
	}
	if(0==sum){
		printf("Bao Bao is so Zhai......");
	}
	if(1==sum){
		printf("Oh dear!!");
	}
	if(2==sum){
		printf("BaoBao is good!!");
	}
	if(3==sum){
		printf("Bao Bao is a SupEr man///!");
	}
	if(4==sum){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	
	return 0;
}
