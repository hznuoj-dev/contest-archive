#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	int t;
	scanf("%d",&t);
	while(t--){
		int n,i,b=0,d=0;
		scanf("%d",&n);
		for(i=0;i<n;++i){
			char a[i];
			scanf("%s",&a[i]);
			if(a[i]=='#')
				b++;
		}
		printf("%d\n",b);
		int s;
		scanf("%d",&s);
		for(i=0;i<s;++i){
			char c[i];
			scanf("%s",&c[i]);
			if(c[i]=='#')
				d++; 
		}
		printf("%d",d);
	}
	return 0;
}
