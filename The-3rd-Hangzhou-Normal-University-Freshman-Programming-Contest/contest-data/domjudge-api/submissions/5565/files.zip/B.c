#include <stdio.h>
#include <string.h>
#include <math.h>
int main(void){
	int t,y,a,k,i,j,add,f;
	scanf("%d",&t);
	while(t--){
		add=0;
		scanf("%d %d",&y,&a);
		if(y+a>9999){
			k=y+a-9999;
			k=9999-k;
		}
		else{
			k=a+y;
		}
		if(k<y){
			a=k;
			k=y;
			y=a;
		}
		for(i=y;i<=k;i++){
			if(((i%4==0)&&(i%100!=0))||(i%400==0)){
				add=add+1;
	        }
	        if(i==0){
	        	add=add-1;
	        	k=k+1;
			}
		}
		printf("%d\n",add);
	}
	return 0;
} 
