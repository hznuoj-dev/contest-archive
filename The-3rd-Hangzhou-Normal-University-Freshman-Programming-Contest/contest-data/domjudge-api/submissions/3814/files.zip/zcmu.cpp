#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int r,a,len,sum,n,t,d[10000];
	char b[10000];
	scanf("%d",&r);
	for(int i=0;i<r;i++){
		scanf("%d",&a);
		sum=0;
		for(int i=0;i<a;i++){
			n=0;
			t=0;
			scanf("%s",b);
			len=strlen(b);
			for(int i=0;i<len;i++){
				d[i]=0;
				if(b[i]=='.') t=1;
				for(int j=0;j<i;j++){
					if(b[j]==b[i])d[i]++;
				} 
			}
			for(int i=0;i<len;i++){
				if(d[i]==0)n++;
			}
			sum+=n-t;
		}
		printf("%d\n",sum);
		
	}
	return 0;
}
