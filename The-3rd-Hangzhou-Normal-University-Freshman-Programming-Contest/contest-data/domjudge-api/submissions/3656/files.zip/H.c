#include<stdio.h>
int main()
{
	int t,n,m,i,b;
	float a;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
		{
			printf("#");
		}
		for(i=m+1;i<=n;i++)
		{
			printf("-");
		}
		printf("] ");
		a=((m+0.00)/n)*100;
		b=a;
		printf("%d%%\n",b);
	}
}
