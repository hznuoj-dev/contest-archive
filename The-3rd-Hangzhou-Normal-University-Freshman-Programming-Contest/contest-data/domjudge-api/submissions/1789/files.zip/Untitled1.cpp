#include<stdio.h>
 int main(){
 	int f(int s,int e); 
 	int t,a[2],s,e;
 	scanf("%d",&t);
 	while(t--){
 		scanf("%d %d",&a[0],&a[1]);
 		if(a[0]+a[1]>9999)
 		a[1]=9999-(a[0]+a[1]-9999);
 		else
 		a[1]=a[0]+a[1];
 		if(a[0]<a[1])
 		printf("%d\n",f(a[0],a[1]));
 		else
 				printf("%d\n",f(a[1],a[0]));
		  }
 	
 } 
 int f(int s,int e){
 	int n=0;
 	for(int i=s;i<=e;i++){
 		if(i%400==0||(i%4==0&&i%100!=0))
 		n+=1;
	 }
	 return n;
 }
