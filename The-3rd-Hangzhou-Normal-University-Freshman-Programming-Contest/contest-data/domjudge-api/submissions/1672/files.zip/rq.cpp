#include<stdio.h>
int f(int year)
{
	if((year%4==0&&year%100!=0)||(year%400==0))
		return 1;
}
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int Y,A,t,score=0;
		scanf("%d %d",&Y,&A);
		if((Y+A)>=9999)
			t=9999-(Y+A-9999);
		else
			t=Y+A;
		if(Y<=t)
		{
			for(int i=Y;Y<=t;Y++)
			{
				if(f(i))
					score++;
			}
		}
		else{
			for(int i=t;t<Y;t++)
			{
				if(f(i))
					score++;
			}
		}
		printf("%d\n",score);
	}
}