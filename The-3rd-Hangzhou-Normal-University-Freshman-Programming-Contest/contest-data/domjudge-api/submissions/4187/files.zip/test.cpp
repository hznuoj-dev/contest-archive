#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
const int maxn=1010;
int n,m,t,is,cnt,ans,p[maxn];
bool x[maxn][maxn];
int main(){
    ios::sync_with_stdio(false);
    cout<<fixed<<setprecision(0);
    cin>>t;
    while(t--){
        cin>>n>>m;
        memset(x,false,sizeof(x));
        for(int i=1;i<=n;i++)p[i]=i;
        for(int i=1;i<=m;i++){
            int a,b;
            cin>>a>>b;
            if(!x[a][b]&&a<b)continue;
            if(x[a][b]&&a>b)continue;
            if(!x[a][b])swap(p[a],p[b]);
            x[a][b]=true;
        }
        for(int i=1;i<=n;i++)cout<<p[i]<<(i==n?"\n":" ");
    }
    return 0;
    //good job!
}
