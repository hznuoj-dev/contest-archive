#include<stdio.h>
int longth(long long value);
int main()
{
	long long a,b,c,d;
	int i,j,re=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	if(longth(a)>=16||longth(a)==6) re++;
	if(longth(b)>=16||longth(b)==6) re++;
	if(longth(c)>=16||longth(c)==6) re++;
	if(longth(d)>=16||longth(d)==6) re++;
	if(re==1) printf("Oh dear!!\n");
	if(re==2) printf("BaoBao is good!!\n");
	if(re==3) printf("Bao Bao is a SupEr man///\n");
	if(re==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if(re==0) printf("Bao Bao is so Zhai......\n");
	return 0;
}

int longth(long long value)
{
	int sum=0;
	for(;value>0;)
	{
		sum += value%10;

        value = value / 10;
	}
	return(sum);
}

