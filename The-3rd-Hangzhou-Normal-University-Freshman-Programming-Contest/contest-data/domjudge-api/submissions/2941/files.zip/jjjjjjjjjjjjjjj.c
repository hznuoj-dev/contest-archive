#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
	char s[10000000];
int main(int argc, char *argv[]) {
	int t,n,i,x,y,c;

	scanf("%d",&t);
	while(t--){
		c=0;
		x=0;
		scanf("%d",&n);
		int b[10000]={0};
		while(n--){
			scanf("%s",s);
		
	
		for(i=0;i<strlen(s);++i){
			if(s[i]!='.'&&b[s[i]]==0){
				b[s[i]]=1;
				c=c+1;
			}
		}
		x=x+c;
		c=0;
		}
		printf("%d\n",x);
	}
	
	
	
	return 0;
}
