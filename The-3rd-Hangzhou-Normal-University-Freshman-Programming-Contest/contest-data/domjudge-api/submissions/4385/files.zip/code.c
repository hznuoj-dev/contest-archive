#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
	int t, n, m, i, a[10000], b[10000], c[1001], j, q = 0;
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &n, &m);
		for (i = 1; i <= n; i++) {
			c[i] = i;
		}
		for (i = 0; i < m; i++) {
			scanf("%d %d", &a[i], &b[i]);
			if (a[i] > b[i]) {
				c[b[i]] = a[i];
				q = c[b[i] + 1];
				c[b[i] + 1] = b[i];
				for (j = b[i] + 1; j < a[i]; j++) {
					c[j + 1] = q;
					q = c[j + 2];
				}
			}
		}
		for (i = 1; i <= n; i++) {
			if (i != n) {
				printf("%d ", c[i]);
			}
			else {
				printf("%d", c[i]);
			}
		}
	}
	return 0;
}