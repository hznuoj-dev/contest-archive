#include<stdio.h>
#include<string.h>
int main()
{
	char str;
	scanf("%s",&str);
	printf(" --      -----");
	printf("\n");
	printf("|  | ___/ ____\\____");
	printf("\n");
	printf("|  |/ /\\   __\\/ ___\\");
	printf("\n");
	printf("|    <  |  | \\  \\___");
	printf("\n");
	printf("|__|_ \\ |__|  \\___  >");
	printf("\n");
	printf("     \\/           \\/");
	printf("\n");
}