#pragma warning (disable:4996)
#include<stdio.h>
#include<string.h>
int main(void) {
	int a, b, c, i, j;
	double k;
	scanf("%d", &a);
	while (a--) {
		scanf("%d %d", &b, &c);
		printf("[");
		for (i = 1; i <= c; i++)
			printf("#");
		for (i = 1; i <= b-c; i++)
			printf("-");
		printf("]");
		printf(" %d%%\n", c * 100 / b);
	}
}