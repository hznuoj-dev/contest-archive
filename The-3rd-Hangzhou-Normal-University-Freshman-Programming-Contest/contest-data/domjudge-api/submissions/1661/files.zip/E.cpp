#include<stdio.h>
int main() {
	char s[4];
	scanf("%s", s);
	if (s[0] == 'k' && s[1] == 'f' && s[2] == 'c')
	{
		printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/\n");
	}
	return 0;
}