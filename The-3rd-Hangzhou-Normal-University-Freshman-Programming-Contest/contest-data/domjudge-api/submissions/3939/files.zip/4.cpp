#include<stdio.h>
#include<string.h>
#include<iostream>
using namespace std;
int main()
{
    char a[10000],b[10000],c[10000],d[10000];
    scanf("%s %s %s %s",a,b,c,d);
    int l1,l2,l3,l4,coun=0;
    int s1=0,s2=0,s3=0,s4=0;
    l1=strlen(a);
    l2=strlen(b);
    l3=strlen(c);
    l4=strlen(d);
    for(int i1=0;i1<l1;i1++)
    {
        s1=s1+(a[i1]-'0');
    }
       if(s1>=16||s1==6)
        coun++;
    for(int i2=0;i2<l1;i2++)
    {
        s2=s2+(b[i2]-'0');
    }
        if(s2>=16||s2==6)
        coun++;
    for(int i3=0;i3<l1;i3++)
    {
        s3=s3+(c[i3]-'0');
    }
        if(s3>=16||s3==6)
        coun++;
    for(int i4=0;i4<l1;i4++)
    {
        s4=s4+(d[i4]-'0');
    }
    if(s4>=16||s4==6)
        coun++;
        if(coun==0)
            printf("Bao Bao is so Zhai......\n");
        if(coun==1)
            printf("Oh dear!!\n");
        if(coun==2)
            printf("BaoBao is good!!\n");
        if(coun==3)
            printf("Bao Bao is a SupEr man///!\n");
        if(coun==4)
            printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
    return 0;
}
