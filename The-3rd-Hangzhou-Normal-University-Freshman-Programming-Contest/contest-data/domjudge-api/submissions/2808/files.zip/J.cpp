#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int n,k,i,h,y,t,temp,j,sum;
	char a[10000001],b[10000001];
	scanf("%d",&t);
	while(t--){
     scanf("%d",&n);
	 for(i=1;i<=n;i++){
		 scanf("%s",a);
		 h=0;sum=0;
		 for(k=0;k<=strlen(a)-1;k++){
			 for(j=0;j<=h;j++){
				 if(b[j]!=a[k]&&j==h){
					 if(a[k]!='.'){
						 b[h]=a[k];
						 h+=1;
					 }
                 }
		 }

		 }
		 sum+=h;
	    }
	 printf("%d\n",sum);
	}

	return 0;
}
//int cmp(const void*p,const void*q){
//return((struct kx*)q)->average -(struct kx*)p)->average)
//}