#include <stdio.h>
int main()
{
    int year,a,b,c,i,n,count=0;
    
    if(scanf("%d",&n)!=EOF)
    n=n;
    while(n--){ 
	    count=0;
	    if(scanf("%d %d",&year,&a)!=EOF){
			year=year;
			a=a;
		}
	
    	b=year+a;
		if(b>9999)
		b=b-(b-9999);
    	if(b<year)
		{
    		c=year;
    		year=b;
    		b=c;
		}
		if(year==b) {
			if(b%400==0)
            count=count+1;
            else
            {
             if(b%4==0&&b%100!=0)
             count=count+1;
             else
             count=count+0;
            }
			
		}
		else{
			for(i=year;i<=b;i++){
    	    if(i%400==0)
            count=count+1;
            else
            {
             if(i%4==0&&i%100!=0)
             count=count+1;
             else
             count=count+0;
            }
            }
		}
    
	printf("%d\n",count);
	}
   	
    return 0;
}
