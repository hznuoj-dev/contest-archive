import java.util.Scanner; 
public class Main {
	
	public static void main(String[] args) 
	{
		Scanner x=new Scanner(System.in);
		while(x.hasNext())
		{
			int s[]=new int[4];
			for(int i=0;i<s.length;i++)
			{
				s[i]=x.nextInt();
			}
			int a=0;
			int m=0;
			int b=0;
			for(int i=0;i<s.length;i++)
			{
				m=s[i];
				a=0;
				while(m>0)
				{
					m=m%10;
					a=a+m;
					m=m/10;
				}
				if(a>=16 || a==6)
				{
					b=b+1;
				}
			}
			if(b==4)
			{
				System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			}
			else if(b==3)
			{
				System.out.println("Bao Bao is a SupEr man///!");
			}
			else if(b==2)
			{
				System.out.println("BaoBao is good!!");
			}
			else if(b==1)
			{
				System.out.println("Oh dear!!");
			}
			else
			{
				System.out.println("Bao Bao is so Zhai......");
			}
		}

	}

}
