#include <stdio.h>
int main()
{
	int i,t,y,a,start,end;
	scanf("%d",&t);
	while(t--)
	{
		int sum=0;
		scanf("%d %d",&y,&a);
		start=y;
		if(y+a>=10000)
		{
			end=y-(y+a-9999);
		}
		if(end<start)
		{
			y=end;
			end=start;
			start=y;
		}
		for(i=start;i<=end;++i)
		{
			if((i%4==0&&i%100!=0)||(i%400==0))
			sum++;
		}
		printf("%d\n",sum);
	}
	
}
