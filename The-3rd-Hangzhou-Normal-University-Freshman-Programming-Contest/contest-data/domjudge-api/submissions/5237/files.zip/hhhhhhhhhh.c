#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d%d",&n,&m);
		int i;
		i=m*100/n;
		printf("[");
		if(m==0){
			for(int i=0;i<n;i++){
				printf("-");
			}
		}
				for(int j=1;j<=m;j++){
             printf("#");
		}
		for(int j=1;j<=n-m;j++){
			if(j==n-m){
				printf("-]")
			}
			else
			{
				printf("-");
			}
		}
		printf("%d%%",i);
	}
	return 0;
}