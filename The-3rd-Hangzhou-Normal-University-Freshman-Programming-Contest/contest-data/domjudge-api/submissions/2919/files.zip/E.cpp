#include<stdio.h>
int main(void){
	char a[100];
	scanf("%s",a);
	char a1[20]={" --      -----"};
	char a2[20]={"|  | ---/ ----\\\----"};
	char a3[30]={"|  |/ /\\   --\\/ ---\\"};
	char a4[30]={"|    <  |  | \\\  \\\---"};
	char a5[30]={"|--|- \\\ |--|  \\\--- >"};
	char a6[30]={"     \\\/           \\\/"};
	printf("%s",a1);
	printf("\n");
	printf("%s",a2);
	printf("\n");
	printf("%s",a3);
	printf("\n");
	printf("%s",a4);
	printf("\n");
	printf("%s",a5);
	printf("\n");
	printf("%s",a6);
	
     return 0;
}
