import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			int a=in.nextInt();
			int b=in.nextInt();
			int c=in.nextInt();
			int d=in.nextInt();
			int sum=0;
			int t=0;
			if(a<10)
			{				
				if(a==6)
				{
					sum++;
				}
			}
			else
			{
				t=0;
				while(a!=0)
				{
					t=t+a%10;
					a=a/10;
				}
				if(t==16)
				{
					sum++;
				}
			}
			if(b<10)
			{
				if(b==6)
				{
					sum++;
				}
			}
			else
			{
				t=0;
				while(b!=0)
				{
					t=t+b%10;
					b=b/10;
				}
				if(t==16)
				{
					sum++;
				}
			}
			if(c<10)
			{
				if(c==6)
				{
					sum++;
				}
			}
			else
			{
				t=0;
				while(c!=0)
				{
					t=t+c%10;
					c=c/10;
				}
				if(t==16)
				{
					sum++;
				}
			}
			if(d<10)
			{
				if(d==6)
				{
					sum++;
				}
			}
			else
			{
				t=0;
				while(d!=0)
				{
					t=t+d%10;
					d=d/10;
				}
				if(t==16)
				{
					sum++;
				}
			}
			if(sum==0)
			{
				System.out.println("Bao Bao is so Zhai......");
			}
			if(sum==1)
			{
				System.out.println("Oh dear!!");
			}
			if(sum==2)
			{
				System.out.println("BaoBao is good!!");
			}
			if(sum==3)
			{
				System.out.println("Bao Bao is a SupEr man///!");
			}
			if(sum==4)
			{
				System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			}
		}
	}
}
