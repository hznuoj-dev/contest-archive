#include"stdio.h"
#include"string.h"
int main(void){
	int T,n,floor,lena,lenb;
	int i,k,s,flag;
	char a[100],b[100];
	scanf("%d",&T);
	while(T>0){
		scanf("%d",&n);     
		s=0;                
		for(floor=1;floor<=n;floor++){     //��ǰ¥�� 
			scanf("%s",a);
			lena=strlen(a);
			for(i=0;i<lena;i++){           //ÿ�����������
			    if(a[i]!='.'){
			    	for(k=0;k<lenb;k++){
					flag=1;
					if(a[i]==b[k]){        //���� 
						flag=0;
						break;
					}
				}
				if(flag==1){
					s++;
					b[k]=a[i];
					lenb++;
				}
				} 
				
			}
			for(k=0;k<=lenb;k++){
				b[k]=' ';
			} 
			for(i=0;i<=lena;i++){
				a[i]=' ';
			}
		}
		printf("%d\n",s);
		T--;
	}
	return 0;
}
