#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int T,n,i,j,k,q,m,p;
	char a[100001],b[1000001];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
	p=0;
		while(n--){
			j=0;k=0;
			scanf("%s",a);
			m=strlen(a);
			for(i=0;i<m;i++){
				if(a[i]!='.'){
				char *p=strchr(a,a[i]);
					if(p==&a[i]) k++;
					
				}
			}
		
			p=p+k;
		}
		printf("%d\n",p);
	}
}
