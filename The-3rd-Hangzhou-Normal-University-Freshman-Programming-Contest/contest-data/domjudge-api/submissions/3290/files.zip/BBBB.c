#include <stdio.h>
#include <stdlib.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int T,Y=0,A=0,B=0,i,m,n;
	scanf("%d",&T);
	for(i=0;i<T;i++){
		int x=0;
		scanf("%d %d",&Y,&A);
	    if(Y+A>9999){
	    	B=9999-(Y+A-9999);
		}
		if(B<Y){
			m=B;
			B=Y;
			Y=m;
		}
		for(n=0;n<(B-Y);n++){
			if(Y%4==0&&Y%100!=0||Y%400==0){
				x++;
			}
			Y=Y+1;
		}
		printf("%d\n",x);
	} 
	return 0;
}
