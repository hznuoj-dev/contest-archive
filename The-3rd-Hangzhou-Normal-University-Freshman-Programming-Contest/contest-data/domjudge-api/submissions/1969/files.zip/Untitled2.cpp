#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+100;
const int INF=0x3f3f3f3f;
char a[50];
char b[50];
char c[50];
char d[50];
int add;
int main(){
	scanf("%s %s %s %s",a,b,c,d);
	int temp=0;
	for(int i=0;i<strlen(a);++i){
		temp+=a[i]-'0';
	}
	if(temp==6||temp>=16) add++;
	temp=0;
	for(int i=0;i<strlen(b);++i){
		temp+=b[i]-'0';
	}
	if(temp==6||temp>=16) add++;
	temp=0;
	for(int i=0;i<strlen(c);++i){
		temp+=c[i]-'0';
	}
	if(temp==6||temp>=16) add++;
	temp=0;
	for(int i=0;i<strlen(d);++i){
		temp+=d[i]-'0';
	}
	if(temp==6||temp>=16) add++;
	if(add==0){
		printf("Bao Bao is so Zhai......\n");
	}
	else if(add==1){
		printf("Oh dear\n");
	}
	else if(add==2){
		printf("BaoBao is good!!\n");
	}
	else if(add==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	return 0;
}
