#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(){
	int t,m,n,x[1000],y[1000],z,i,a[1000],j,k,p,q,s,r,c=0,d;
	
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		d=m;
		for(i=1;i<=n;i++){
			a[i]=i;
		}
		for(c=1;c<=m;c++){
			scanf("%d%d",&x[c],&y[c]);
			for(i=1;i<=n;i++){
				if(a[i]==x[c]){
					j=i;
				}
				if(a[i]==y[c]){
					k=i;
				}
				if(j<k){
					x[d+1]=x[c];
					y[d+1]=y[c];
					d=d+1;
				}
				
			}
			for(p=1;p<=k&&j>k;p++){ 
			if(p==k){
					z=a[j];
					r=a[p];
					a[p]=z;
					for(s=j-1;s>=p+1;s--){
						a[s+1]=a[s];
					}
					a[p+1]=r;
				}
			else	if(a[p]>a[j]){
					z=a[j];
					r=a[p];
					a[p]=z;
					for(s=j-1;s>=p+1;s--){
						a[s+1]=a[s];
					}
					a[p+1]=r;
					
					break;
				}
				
			}
			}
			if(d>m){
				for(c=d;c>m;c--){
			for(i=1;i<=n;i++){
				if(a[i]==x[c]){
					j=i;
				}
				if(a[i]==y[c]){
					k=i;
				}
				
				
			}	
			}
			
			for(p=1;p<=k&&j>k;p++){ 
			if(p==k){
					z=a[j];
					r=a[p];
					a[p]=z;
					for(s=j-1;s>=p+1;s--){
						a[s+1]=a[s];
					}
					a[p+1]=r;
				}
			else	if(a[p]>a[j]){
					z=a[j];
					r=a[p];
					a[p]=z;
					for(s=j-1;s>=p+1;s--){
						a[s+1]=a[s];
					}
					a[p+1]=r;
					
					break;
				}
				
			}
			}
			
			
		
		for(i=1;i<=n;i++){
		if(i==n){
			 	printf("%d",a[i]);
			 }
			 else printf("%d ",a[i]);
			 
		} 
		printf("\n");
	}
}

