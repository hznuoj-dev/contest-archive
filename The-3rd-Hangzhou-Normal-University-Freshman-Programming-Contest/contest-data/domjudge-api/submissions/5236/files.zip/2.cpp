#include<stdio.h>
int main(){
	int t;
	long y,a;
	int count=0;
	if(scanf("%d",&t)){
		while(t--){
		count =0;
		if(scanf("%ld %ld",&y,&a)){
				if(y+a>9999){
			for(int k=y;k<=9999-(y+a-9999);k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
		else{
			if(y+a<=y){	
				for( int k=y+a;k<=y;k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
		else{
			for(int k=y;k<=y+a;k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
	}
		}
		//printf("%d\n",jia);
	
	printf("%d\n",count);
	}
	}
	
	return 0;
} 
