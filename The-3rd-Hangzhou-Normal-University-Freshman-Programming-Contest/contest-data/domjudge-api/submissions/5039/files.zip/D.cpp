
#include<iostream>
using namespace std;
#include<string>
int main()
{
	int T,a=0;
	string s;
	cin>>T;
	while(T--)
	{
	cin>>s;
	a+=s.size();
	}
	cout<<a<<endl;
	system("pause");
}