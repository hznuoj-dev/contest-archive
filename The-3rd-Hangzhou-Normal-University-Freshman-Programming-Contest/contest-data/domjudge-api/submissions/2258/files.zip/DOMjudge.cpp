#include<stdio.h>
int pd(long long j)
{
int sum=0;
   while(j>0)
   {
       sum+=j%10;
       j=j/10;
   }
   if(sum==6||sum>=16)return 1;
   else return 0;
}

int main()
{
    long long a[4];
    int gs=0;
    scanf("%lld%lld%lld%lld",&a[0],&a[1],&a[2],&a[3]);
    for(int i=0;i<4;i++)
    {
        if(pd(a[i])==1)gs++;
    }
    if(gs==0)printf("Bao Bao is so Zhai......");
    else if(gs==1)printf("Oh dear!!");
    else if(gs==2)printf("BaoBao is good!!");
    else if(gs==3)printf("Bao Bao is a SupEr man///!");
    else printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    return 0;
}
