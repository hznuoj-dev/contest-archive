#include<stdio.h>
int main()
{
	int T,n,m,i,j;
	scanf_s("%d", &T);
	while (T--)
	{
		scanf_s("%d %d", &n, &m);
		i = n - m;
		j = m;
		printf("[");
		while (m--)
		{
			printf("#");
		}
		while (i--)
		{
			printf("-");
		}
		printf("] ");
		printf("%d", (j * 100) / n);
		printf("%%\n");
	}
	return 0;
}