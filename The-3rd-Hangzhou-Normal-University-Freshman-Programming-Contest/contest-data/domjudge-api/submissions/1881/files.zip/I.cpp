#include<bits/stdc++.h> 
using namespace std;
int main(){
	int key=0,ta=0,tb=0,tc=0,td=0;
	while(key==0) {
		char a=getchar();
		if(a==' '||a=='\n') key=1;
		else ta=ta+a-48;
	}key=0;
	
	
	while(key==0) {
		char b=getchar();
		if(b==' '||b=='\n') key=1;
		else tb=tb+b-48;
	}key=0;
	
	
	while(key==0) {
		char c=getchar();
		if(c==' '||c=='\n') key=1;
		else tc=tc+c-48;
	}key=0;
	
	
	while(key==0) {
		char d=getchar();
		if(d==' '||d=='\n') key=1;
		else td=td+d-48;
	}key=0;
	int t=0;
	if(ta==6||ta>=16) ++t;
	if(tb==6||tb>=16) ++t;
	if(tc==6||tc>=16) ++t;
	if(td==6||td>=16) ++t;
	if(t==1) printf("Oh dear!!\n");
	if(t==2) printf("BaoBao is good!!\n");
	if(t==3) printf("Bao Bao is a SupEr man///!\n");
	if(t==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if(t==0) printf("Bao Bao is so Zhai......\n");
	return 0;
}
