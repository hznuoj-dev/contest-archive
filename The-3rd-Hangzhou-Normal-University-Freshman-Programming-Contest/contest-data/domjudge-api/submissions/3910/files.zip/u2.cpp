#include<stdio.h>
int main(void){
	int t,m,n ,i;
	char c[100000];
	double a;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&m,&n);
		a=(double)n/m*100.0;
	    for(i=0;i<n;++i)
	        c[i]='#';
	    for(i=n;i<m;++i)
	        c[i]='-';
	    printf("[%s] %.0f\%",c,a);
	}
	return 0;
}
