#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int main()
{
	long long a,b,c,d;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	int sum=0;
	int gs=0;
	while(a>0)
	{
		gs+=a%10;
		a/=10;
	}
	if(gs>=16||gs==6)
	{
		sum++;
	}
	gs=0;
	while(b>0)
	{
		gs+=b%10;
		b/=10;
	}
	if(gs>=16||gs==6)
	{
		sum++;
	}
	gs=0;
	while(c>0)
	{
		gs+=c%10;
		c/=10;
	}
	if(gs>=16||gs==6)
	{
		sum++;
	}
	gs=0;
	while(d>0)
	{
		gs+=d%10;
		d/=10;
	}
	if(gs>=16||gs==6)
	{
		sum++;
	}
	if(sum==0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	else if(sum==1)
	{
		printf("Oh dear!!\n");
	}
	else if(sum==2)
	{
		printf("BaoBao is good!!\n");
	}
	else if(sum==3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	else
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	return 0;
}
