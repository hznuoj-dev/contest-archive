#include<stdio.h>
int main(void){
int nm[10000];
int mm[10000];
int a,i,s,j;
scanf("%d",&a);
for(i=0;i<a;i++){
	scanf("%d%d",&nm[i],&mm[i]);
}
for(i=0;i<a;i++){
	printf("[");
	s=mm[i];
	for(j=0;j<nm[i];j++){
		if(s>0){
			printf("#");
			s=s-1;
	}	
		else{
			printf("-");
		}
		
	}
	printf("]");
	printf(" %d%%\n",(100*mm[i])/nm[i]);
}



} 
