#include<stdio.h>
int main()
{
    int t;
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
        double m,n;
        scanf("%lf%lf",&m,&n);
        double re;
        re=(n/m)*100;
        printf("[");
        for(int j=0;j<n;j++)
            printf("#");
        for(int j=0;j<m-n;j++)
            printf("-");
        printf("]");
        printf(" ");
        printf("%.0lf",re);
        putchar(37);
        printf("\n");
    }
    return 0;
}
