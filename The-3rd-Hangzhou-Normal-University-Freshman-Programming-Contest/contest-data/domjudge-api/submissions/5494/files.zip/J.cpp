#include<stdio.h>
#include<string.h>
int main(void){
    int T,n,flag;
	long long int i,j,h,jc,len,laji;
	char ss[100001];
	char k[100001];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
			laji=0;	
			while(n--){
	        flag=0;
			scanf("%s",ss);
			len=strlen(ss);
			jc=0;
			for(i=0;i<len;i++){
				if(ss[i]!='.'){
					k[jc]=ss[i];
					laji++;
					h=i;
					jc++;
					break;
				}
			}
			for(i=h+1;i<len;i++){
			
				if(ss[i]!='.'){
					for(j=0;j<=jc;j++){
						if(ss[i]==k[j])break;
					}
					if(j>jc){
						jc++;
						k[jc]=ss[i];
						laji++;
					}
				}
			}
			
		}
	printf("%lld\n",laji);
	}
	return 0;
}
