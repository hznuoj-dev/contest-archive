#include<stdio.h>
int main(){
	int n,a,b,c;
	int s;
	int nian=0;
	int max,min;
	scanf("%d",&n);
	for(int N=1;N<=n;N++){
		scanf("%d %d",&a,&b);
		s=a+b;
		if(s>9999)c=s-9999,s=s-c;
		if(s>a)max=s,min=a;
		if(s<=a)max=a,min=s;
	while(min<=max){
		if((min%4==0&&min%100!=0)||min%400==0){
			nian++;
		}	
		min++;
	}
	printf("%d\n",nian);
	nian=0;
	}
} 
