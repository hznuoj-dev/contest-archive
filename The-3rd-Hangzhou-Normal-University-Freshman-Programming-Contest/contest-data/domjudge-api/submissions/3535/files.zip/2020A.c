#include<stdio.h>

int main(){
	int t, y1, a, temp, y2;
	int i, n;
	scanf("%d", &t);
	while( t-- ){
		scanf("%d%d", &y1, &a);
		temp = a + y1;
		if(temp>y1)
		{
			n=0;
			y2 = 9999-(temp-9999);
			for(i=y1;i<=y2;i++){
				if(((i%100!= 0)&&(i%4==0))||(i%400==0))
				n++;
				
			}
			
		}
		else if(temp<y1)
		{

			n = 0;
			for(i=temp;i<=y1;i++)
			    if(((i%100!= 0)&&(i%4==0))||(i%400==0))
				n++;
		}
		else
		printf("0");
		printf("%d\n", n);
		
	}
	return 0;
	
} 
