#include<stdio.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int a,b;
		scanf("%d %d",&a,&b);
		printf("[");
		for(int i=0;i<b;i++)
		printf("#");
		for(int j=0;j<(a-b);j++)
		printf("-");
		printf("]");
		printf(" %d%%\n",(int)(100*1.0*b/a));

	}
}
/*int f(int k)
{
	int l=0;
	while(k>1)
	{
		k=k/2;
		l++;
	}
	return l;
}
int main()
{
	int t;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	    int a;
		scanf("%d",&a);
	}
	

	return 0;
}
*/ 
/*
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int n,T,m,p;
	int team[501],problemid[501],timestamp[501],recod[501];
	scanf("%d %d %d %d",&n,&T,&m,&p);
	for(int i=0;i<m;i++)
	{
		char s[2];
		scanf("%d %d %d",&team[i],&problemid[i],&timestamp[i]);
		scanf("%s",s);
		if(s[0]=='A'&&s[1]=='C')
			recod[i]=1;
		else
			recod[i]=0;
	}
	int q;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		char q[10],a,b;
		scanf("%s",q);
		scanf("%d %d",&a,&b);
	}
	return 0;
}*/ 
