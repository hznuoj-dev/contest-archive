import java.util.ArrayList;
import java.util.Scanner;

public class J {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        ArrayList<String> [] arrayLists= new ArrayList[t];
        for (int i = 0; i < t; i++) {
            int n=in.nextInt(),cont=0;
            for (int j = 0; j < n; j++) {
                String str= in.next();
                str=str.replaceAll(".","");
                for (int i1 = 0; i1 < str.length(); i1++) {
                arrayLists[i].add(str.substring(i1,1));
                }
                cont+= arrayLists.length;
            }
            if(t==1) {
                System.out.println(cont);
            }else {
                System.out.println(cont/2);
            }
        }
    }
}
