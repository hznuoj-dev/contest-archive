#include<math.h> 
#include<stdio.h> 
#include<string.h>   
//using namespace std;
 int main()  
{	int a,b,m,n,cnt,LOUCENG,t,sum=0;char s[100005];
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{	scanf("%d",&m);
		for(int j=1;j<=m;j++)
		{	scanf("%s",&s);//printf("%s\n",s);
			cnt=strlen(s);//printf("%d\n",cnt);
			LOUCENG=0;
			int flag[300]={0};
			for(int l=0;l<cnt;l++)
			{	 //printf("%d\n",(int)s[i]);
				if(s[l]!='.'&&flag[(int)s[l]]==0) 
				{	LOUCENG++;
					flag[(int)s[l]]=1;
				}						
			}	//printf("%d\n",sum);printf("%d\n",LOUCENG);
			sum+=LOUCENG;
		}
		printf("%d\n",sum);sum=0;
	}
	

	
}
