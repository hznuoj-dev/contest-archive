#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main(int argc, char *argv[]) {
int T,n,i,j;
char a;
long long m;
double num;
a='%';
scanf("%d",&T);
while(T--){
	scanf("%d%lld",&n,&m);
	printf("[");
	for(i=1;i<=m;i++){
		printf("#");
	}
	for(i=m+1;i<=n;i++){
		printf("-");
	}
	printf("] ");
	num=(m*100.0)/n;
	printf("%.0llf",num);
	printf("%c",a);
if(T!=0)	printf("\n");
}
	return 0;
}





