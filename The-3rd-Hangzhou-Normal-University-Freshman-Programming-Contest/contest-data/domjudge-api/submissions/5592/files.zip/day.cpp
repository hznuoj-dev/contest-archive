#include<stdio.h>
int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int y;
		int cnt = 0;
		int a, end = 0, i;
		scanf("%d", &y);
		scanf("%d", &a);
		end = y + a;
		if (y > end) {
			i = y;
			y = end;
			end = i;
		}
		if (end > 9999)
			end = 9999 - (end - 9999);
		for (i = y; i <= end; i++) {
			if (i%4==0&&i%100!=0||i%400==0)
				cnt++;
			
		}
			printf("%d\n", cnt);
	}
	return 0;
}