#include<stdio.h>
#pragma warning(disable:4996)
int main() {
	int a, b, c, d, i;
	scanf("%d", &a);
	while (a--) {
		scanf("%d %d", &b, &c);
		d = (c * 100) / b;
		i = b - c;
		printf("[");
		while (c--) 
		{
			printf("#");
		}
		while (i--) {
			printf("-");
		}
		printf("]");
		printf("%d", d);
		printf("%%\n");
	}
	return 0;
}