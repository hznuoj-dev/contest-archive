#include<bits/stdc++.h>
using namespace std;
int main()
{
	int T,n,m,i;
	int t;
	cin >> T;
	while(T--){
		cin >> n >> m;
		t=m*100/n;
		printf("[");
		for(i=1;i<=m;i++) printf("#");
		for(i=1;i<=n-m;i++) printf("-");
		printf("] %d%%\n",t);
	}
}
