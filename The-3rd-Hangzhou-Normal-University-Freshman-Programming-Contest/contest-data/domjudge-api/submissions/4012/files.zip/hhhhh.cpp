#include<stdio.h>
int main(){
	int x,y,z,m,count=0;
	scanf("%d%d%d%d",&x,&y,&z,&m);
	if(x>=16||x==6)
	count++;
	if(y>=16||y==6)
	count++;
	if(z>=16||z==6)
	count++;
	if(m>=16||m==6)
	count++;
	if(count==1)
	printf("Oh dear!!") ;
	if(count==2)
	printf("BaoBao is good!!") ;
	if(count==3)
	printf("Bao Bao is a SupEr man///!") ;
	if(count==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!") ;
	if(count==0)
	printf("Bao Bao is so Zhai......") ;
	
return 0;
}
