#include<stdio.h>
#pragma warning(disable:4996)
#include<math.h>
#include<string.h>
int main(){
	int t,i,j;
	float m,n,p;
	while(~scanf("%d",&t)){
	   while(t--){
		 scanf("%f %f",&m,&n);
		 p=(n/m)*100;
		 printf("[");
		 for(i=0;i<n;i++){
			 printf("#");
		 }
		 for(i=0;i<m-n;i++){
			 printf("-");
		 }
		 printf("] ");
		 printf("%.0f%%\n",p);
	}
   }
	return 0;
}