#include <stdio.h>
int main(){
	char y[3];
	int n;
	for(n=0;n<3;n++){
		scanf("%c",&y[n]);
	}
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/  /\\    __\\/ ___\\ \n");
	printf("|    <   |  | \\ \\___\n");
	printf("|__|_ \\ |__|  \\___ >\n");
	printf("    \\/           \\/\n");
	return 0;
}
