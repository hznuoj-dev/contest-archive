#include<stdio.h>
char s[3];
int main(){
	scanf("%s",s);
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/          \\/\n");
	
	
	return 0;
}
