#include<stdio.h>
#include<stdlib.h>
int main (void){
	int t,n,m,a,b,x,i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
	int num[n];
		for(i=0;i<n;i++)
		num[i]=i+1;
		while(m--){
			scanf("%d%d",&a,&b);
        if(num[a-1]>num[b-1])
        x=num[a-1],num[a-1]=num[b-1],num[b-1]=x;
}
for(i=0;i<n;i++)
for(j=0;j<n;j++)
if(num[j]==i+1)
printf("%d ",j+1);
printf("\n");}
return 0;	}

