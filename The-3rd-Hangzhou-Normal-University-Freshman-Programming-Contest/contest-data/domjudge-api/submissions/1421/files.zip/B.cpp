#include<stdio.h>

int isrun(int x)
{
	if((x%400==0)||(x%4==0&&x%100!=0))
	{
		return 1;
	}
	
	else
	{
		return 0;
	}
}

int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int y;
		int a;
		
		scanf("%d%d",&y,&a);
		int total=y+a;
		if(total>9999)
		{
			int chao=total-9999;
			total-=chao;
		}
		int up=total>y?total:y;
		int down=total<y?total:y;
		int num=0;
		for(int i=down;i<=up;i++)
		{
			if(isrun(i))
			{
				num++;
			}
		}
		printf("%d\n",num);
	}	
	
	
	
}
