#include<stdio.h>
int main() {
	int a, b,n,sum,q,i;
	scanf("%d", &n);
	while (n--) {
		scanf("%d %d", &a, &b);
		sum = 0;
		if (a + b > 9999) {
			q = a + b - 9999;
		}
		else {
			q = a + b;
			for (i = a; i <= q; i++) {
				if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) {
					sum = sum + 1;
				}
			}
		}
		if (a < q&&sum==0) {
			for (i = a; i <= q; i++) {
				if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) {
					sum = sum + 1;
				}
			}
		}
		else if (a > q && sum == 0) {
			for (i = q; i <= a; i++) {
				if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) {
					sum = sum + 1;
				}
			}
		}
		printf("%d\n", sum);
	}
}