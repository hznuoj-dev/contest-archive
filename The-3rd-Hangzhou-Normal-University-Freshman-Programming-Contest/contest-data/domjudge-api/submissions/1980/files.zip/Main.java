
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		  while (sc.hasNext())
	      {
			  int n=sc.nextInt();
			  for(int i=0;i<n;i++)
			  {
				  int a=sc.nextInt();
				  int b=sc.nextInt();
				  int kk=a+b;
				  if(kk>9999) {kk=9999-(kk-9999);}
				  int min=kk>a?a:kk;
				  int max=kk>a?kk:a;
				  int sum=0;
				  for(int j=min;j<=kk;j++)
				  {
					  if((j%4==0&&j%100!=00)||(j%400==0))
					{
						  sum++;
					}
				  }
				  System.out.println(sum);
			  }System.out.println();
	      }

	}

}
