#include<stdio.h>
int main()
{
	char a[4];
	scanf("%c",a);

		printf(" __ _____\n| | ___/ ____\\____\n| |/ /\\ __\\/ ___\\\n| < | | \\ \\___\n|__|_ \\ |__| \\___ >\n     \\/         \\/\n");

	 return 0;
 } 
