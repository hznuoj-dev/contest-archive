#include<stdio.h>
int main()
{
   int T,a,b,c,jia,jian,k,i,rn=0;
   scanf("%d",&T);
   while(T--)
   {
       scanf("%d%d",&a,&c);
       jia=a+c;
       if(jia>9999) 
       {
           jian=jia-9999;
           b=9999-jian;
       }
       else b=jia;
       if(a>b) 
       {
           k=a;
           a=b;
           b=k;
       }
       for(i=a;i<=b;i++)
       {
           if(i%4==0&&i%100!=0||i%400==0) rn=rn+1;
       }
       printf("%d\n",rn);
       rn=0;
   }

	return 0;
}
