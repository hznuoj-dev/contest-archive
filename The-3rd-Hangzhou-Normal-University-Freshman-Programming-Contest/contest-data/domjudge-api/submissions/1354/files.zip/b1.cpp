#include<stdio.h>
int main() {
	int t,x1,x2,n,i,m,sum=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&x1,&n);
		x2=x1+n;
		if(x2<x1){
			m=x1;
			x1=x2;
			x2=m;
		}
		if(x2>9999)
		x2=9999-(x2-9999);
		sum=0;
		for(i=x1;i<=x2;++i){
			if((i%4==0&&i%100!=0)||(i%400==0))
			sum+=1;
		}
		printf("%d\n",sum);
	}
	return 0;
}


