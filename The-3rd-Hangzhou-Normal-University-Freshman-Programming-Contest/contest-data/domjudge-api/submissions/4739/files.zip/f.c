#include<stdio.h>
int n,m,i,j,k,t;
int a[100000],b[100000];

int pd(int s)
{
	int i,j;
	i = 0;
	while(s!=0 && i < n)
	{
		if(a[i]<=s && s >0)
		{
			j = 1;
			while(a[i]*j<=s && b[i]>=j)
			{
				j++;
			}
			j--;
			s -= a[i]*j;
		}
		i++;
	}
	if(s == 0)
	{
		return 1;
	}
	return 0;
}

int main(void)
{
	
	scanf("%d %d",&n,&m);
	for(i = 0;i < n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i = 0;i < n;i++)
	{
		scanf("%d",&b[i]);
	}
	for(i = 0;i < n-1;i++)
	{
		k = i;
		for(j = i+1;j< n;j++)
		{
			if(a[j]>a[k])
			{
				k = j;
			}
		}
		if(k != i)
		{
			t = a[i];
			a[i] = a[k];
			a[k] = t;
			t = b[i];
			b[i] = b[k];
			b[k] = t;
		}
	}
	k = 0; 
	for(i = 1;i <= m;i++)
	{
		k += pd(i);
	}
	
	printf("%d\n",k);
	return 0;
}
