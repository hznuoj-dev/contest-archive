//
//  main.c
//  e
//
//  Created by 蔡欣怡 on 2020/12/13.
//

#include <stdio.h>

int main(void) {
    // insert code here...
    char str[10];
    scanf("%s",str);
    printf(" --      -----         \n");
    printf("|  | ___/ ____\\____   \n");
    printf("|  |/ /\\   __\\/ ___\\\n");
    printf("|    <  |  | \\  \\___ \n");
    printf("|__|_ \\ |__|  \\___  >\n");
    printf("     \\/           \\/ \n");
    return 0;
           }
