

#include<stdio.h>

int main() {
	
	int t,m,n;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&m,&n);
		printf("[");
		for(int i=1;i<=n;i++)
		{
		   printf("#");
		}
		for(int j=n+1;j<=m;j++)
			{
				printf("-");
		 	}
	    printf("] ");
		printf("%d%%\n",n*100/m);
	}
	
	return 0;
}




	
	
