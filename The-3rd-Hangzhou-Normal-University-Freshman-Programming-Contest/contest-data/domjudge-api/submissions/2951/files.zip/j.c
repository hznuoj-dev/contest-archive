#include<stdio.h>
#include<string.h>
int main()
{
	int T,n;
	char s[1000000],Kfloor[100];
	int floor[101];
	int i,j,t,len,sum;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		sum=0;
		for(i=1;i<=n;i++)
			floor[i]=0;

		for(i=1;i<=n;i++)
		{
			scanf("%s",s);
			len=strlen(s);

			for(j=0;j<len;j++)
			{
				if(s[j]!='.')
				{
					for(t=1;t<=floor[i];t++)
					{
						if(s[j]==Kfloor[t])
							break;
					}
					if(t>floor[i])
					{
					    floor[i]++;
						Kfloor[floor[i]]=s[j];
					}
				}
			}
		    sum+=floor[i];
		}
		printf("%d\n",sum);
	}
	return 0;
}
