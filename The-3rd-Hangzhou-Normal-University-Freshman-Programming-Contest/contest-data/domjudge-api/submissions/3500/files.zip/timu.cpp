#include<bits/stdc++.h>
using namespace std;
int num[300]={0};
int main()
{
    int m,t,i,j,q,sum;
	char n[1000005];
	cin>>t;
	for(i=1;i<=t;i++)
	{
	   cin>>m;
	   sum=0;
	    for(q=1;q<=m;q++)
	    { 
		  scanf("%s",&n);
		  for(j=0;j<=strlen(n)-1;j++)
	      {
		    if(num[n[j]]==0 && n[j]!='.' ) 
		    {
		      num[n[j]]++;sum++;
			} 
	      }
		 for(j=0;j<=strlen(n)-1;j++)
	     if(num[n[j]]==1) num[n[j]]=0; 
		} 
	   cout<<sum<<endl;
	}
	return 0;
}
