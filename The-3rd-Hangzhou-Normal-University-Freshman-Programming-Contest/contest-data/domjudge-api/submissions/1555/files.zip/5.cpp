#include <stdio.h>
#include<string.h>
int main(){
long long  a,b,c,d,p=0,s=0;
scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
while (a){
	p=a%10;
	s+=p;
	a/=10;
}
if (s==6||s>=16) p+=1;
s=0;
while (b){
	p=b%10;
	s+=p;
	b/=10;
}
if (s==6||s>=16) p+=1;
s=0;
while (c){
	p=c%10;
	s+=p;
	c/=10;
}
if (s==6||s>=16) p+=1;
s=0;
while (d){
	p=d%10;
	s+=p;
	d/=10;
}
if(d==1) printf("Oh dear!!");
if(d==0) printf("Bao Bao is so Zhai......");
if(d==2) printf("BaoBao is good!!");
if(d==3) printf("Bao Bao is a SupEr man///!");
if(d==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
 return 0;
}
