#include<stdio.h>
#include<string.h>
int main() {
	int T, n, x, i, sum,flag;
	char a[100000];
	sum = 0;
	flag = 0;
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		while (n--) {
			scanf("%s", a);
			x = strlen(a);
			for (i = 0; i < x; i++) {
				if (a[i] != '.') {
					flag = 1;
				}
			}
			sum += flag;
			flag = 0;
		}
		printf("%d\n", sum);
		sum = 0;
	}
	return 0;
}