#include<stdio.h>
int main (void){
	int t,y,a,i,k,sum,b;
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d%d",&y,&a);
		if(y+a<9999){
			if(a<=0){
				for(i=y+a;i<=y;i++){
				if(i%4==0&&i%100!=0||i%400==0)
				sum++;
				}
			}
			else{
				for(i=y;i<=y+a;i++){
				if(i%4==0&&i%100!=0||i%400==0)
				sum++;
				}
			}
		}
		else{
			b=9999-(y+a-9999);
			for(i=y;i<=b;i++){
				if(i%4==0&&i%100!=0||i%400==0)
				sum++;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
