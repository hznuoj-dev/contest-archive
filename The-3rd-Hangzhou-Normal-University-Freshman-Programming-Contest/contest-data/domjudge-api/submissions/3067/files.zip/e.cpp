#include <stdio.h>
#include <math.h>
#include<iostream>

           using namespace std;
int main (){
	char a[100];
	cin.getline(a,100);
	printf(" --      -----     \n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/ \n");
	return 0;
}
