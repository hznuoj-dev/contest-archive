#include<stdio.h>
int main(){
	int x,y,z,m,count=0,sum1=0,sum2=0,sum3=0,sum4=0;
	scanf("%d%d%d%d",&x,&y,&z,&m);
	while(x>0){
		sum1+=x%10;
		x/=10;
	}
	if(sum1>=16||sum1==6)
	count++;
	while(y>0){
		sum2+=y%10;
		y/=10;
	}
	if(sum2>=16||sum2==6)
	count++;
	while(z>0){
		sum3+=z%10;
		z/=10;
	}
	if(sum3>=16||sum3==6)
	count++;
	while(m>0){
		sum4+=m%10;
		z/=10;
	}
	if(sum4>=16||sum4==6)
	count++;
	if(count==1)
	printf("Oh dear!!") ;
	if(count==2)
	printf("BaoBao is good!!") ;
	if(count==3)
	printf("Bao Bao is a SupEr man///!") ;
	if(count==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!") ;
	if(count==0)
	printf("Bao Bao is so Zhai......") ;
	
return 0;
}
