from sys import *
a,b,c,d=list(map(str,input().split()))
n=0
if sum(int(i) for i in a)>=16 or sum(int(i) for i in a)==6:
    n=n+1
if sum(int(i) for i in b)>=16 or sum(int(i) for i in b)==6:
    n=n+1
if sum(int(i) for i in c)>=16 or sum(int(i) for i in c)==6:
    n=n+1
if sum(int(i) for i in d)>=16 or sum(int(i) for i in d)==6:
    n=n+1
if(n==0):
    print("Bao Bao is so Zhai......")
elif(n==1):
	print("Oh dear!!")
elif(n==2):
	print("BaoBao is good!!")
elif(n==3):
	print("Bao Bao is a SupEr man///!")
elif(n==4):
	print("Oh my God!!!!!!!!!!!!!!!!!!!!!")
