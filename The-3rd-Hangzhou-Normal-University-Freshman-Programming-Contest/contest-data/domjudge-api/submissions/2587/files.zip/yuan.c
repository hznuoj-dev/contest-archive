#include<stdio.h>
#include<string.h>


int main(){
	int t,n;
	
	scanf("%d",&t);
	while(t--)
	{
		int i,m,y,sum=0;
		char str[1000001];
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			int g,k;
	
			scanf("%s",str);
			m=strlen(str);
			for(g=0;g<m;g++)
			{
				
				if(str[g]!='.')
				{
					for(k=0;k<m;k++)
					{
						
						if(str[k]==str[g]&&k!=g)
						{
							str[k]='.';
							
						}
					}
				}
			}
			for(g=0;g<m;g++)
			{
				
				if(str[g]!='.')
					sum++;
		
			}
		}
		
		printf("%d\n",sum);
	}


return 0;
}
