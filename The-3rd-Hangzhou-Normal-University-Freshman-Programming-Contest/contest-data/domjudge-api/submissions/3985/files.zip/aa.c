#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d %d",&n,&m);
		int y[n+1][n+1],p[n];
		if(n==1)printf("1\n");
		else{
			while(m--){
				int a,b;
				scanf("%d %d",&a,&b);
				y[a][b]=1;
				y[b][a]=-1;
			}
			if(y[1][2]==-1){
				p[0]=2,p[1]=1;
			}else{
				p[0]=1,p[1]=2;
			}
			int s=1;
			for(int i=3;i<n+1;i++){
				int f=0;
				for(int j=0;j<=s;j++){
					if(y[p[j]][i]==-1){
						s++;
						for(int k=s;k>j;k--){
							p[k]=p[k-1];
						}
						p[j]=i;f=1;
						break;
						
					}
				}
				if(!f){
					s++;
					p[s]=i;
				}
			}
			for(int i=0;i<n;i++){
				if(i)printf(" %d",p[i]);
				else printf("%d",p[i]);
			}
			printf("\n");	
		}
		
	}
}
