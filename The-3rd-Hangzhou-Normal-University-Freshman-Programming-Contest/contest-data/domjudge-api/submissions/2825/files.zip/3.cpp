#include<stdio.h>
int main(void)
{
	int i,x,y,s,h;
	int a[4];
	h=0;
	for(i=0;i<4;i++)
	scanf("%d",&a[i]);
	for(i=0;i<4;i++)
	{
	y=a[i];
	while(y!=0)
	{
		x=y%10;
		s=s+x;
		y=y/10;
	}
	if(s>=16||s==6)
	h=h+1;
	s=0;
    }
    if(h==0)
    printf("Bao Bao is so Zhai......");
    if(h==1)
    printf("Oh dear!!");
	if(h==2)
    printf("BaoBao is good!!");
    if(h==3)
    printf("Bao Bao is a SupEr man///!");
    if(h==4)
    printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
 } 
