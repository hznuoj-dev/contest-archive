#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char str[4];
    scanf("%s", str);
    printf(" __      _____\n| | ___/ ____\\____\n| |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___ >\n     \\/           \\/\n");
	return 0;
}
