#include<stdio.h>
#include<string.h>

void wogiao(int count){
	switch(count){
		case 0:printf("Bao Bao is so Zhai......");break;
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
}

int caculate(char *str){
	int res = 0;
	for(int i = 0; i < strlen(str);i++){
		res+= str[i]-'0';
	}
	return res;
}
int judge(int res){
	return res >=16 || res ==6;
}
int main(){
	char a[19],b[19],c[19],d[19];
	scanf("%s%s%s%s",a,b,c,d);
	int res = 0,count = 0;
	count+=judge(caculate(a));
	count+=judge(caculate(b));
	count+=judge(caculate(c));
	count+=judge(caculate(d));
	wogiao(count);
}
