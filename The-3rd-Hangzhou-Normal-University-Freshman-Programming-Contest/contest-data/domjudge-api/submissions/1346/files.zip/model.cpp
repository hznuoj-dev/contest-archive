//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 1010;

int main() {
	
#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);
	
	int a[4], num = 0, b, sum, cnt = 0;
	for (int i = 0; i < 4; ++i){
		scanf("%d", &a[i]);
		b = a[i];
		sum = 0;
		while (b > 0){
			sum += b % 10;
			b /= 10;
		}
		if (sum >= 16 || sum == 6){
			cnt++;
		}
	}
	if (cnt == 0){
		printf("Bao Bao is so Zhai......\n");
	}else if (cnt == 1){
		printf("Oh dear!!\n");
	}else if (cnt == 2){
		printf("BaoBao is good!!\n");
	}else if (cnt == 3){
		printf("Bao Bao is a SupEr man///!\n");
	}else if (cnt == 4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	

	return 0;
}
