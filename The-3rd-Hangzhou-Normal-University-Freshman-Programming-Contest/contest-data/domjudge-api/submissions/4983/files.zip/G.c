#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int t,i,j,e,n,m,a[1001],x,y,q,w,tmp;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		for(i=1;i<=1001;i++){
			a[i]=i;
		}
		for(i=0;i<m;i++){
			scanf("%d %d",&x,&y);
			for(e=1;e<=n;e++){
				if(a[e]==x){
					q=e;
				}
				if(a[e]==y){
					w=e;
				}
			}
			if(a[q]>a[w]){
				tmp=a[w];
				a[w]=a[q];
				for(j=q;j>=w+2;j--){
					a[j]=a[j-1];
				}
				a[j]=tmp;
			}
		}
		for(i=1;i<=n-1;i++){
			printf("%d ",a[i]);	
		}
		printf("%d\n",a[n]);
	}
}
