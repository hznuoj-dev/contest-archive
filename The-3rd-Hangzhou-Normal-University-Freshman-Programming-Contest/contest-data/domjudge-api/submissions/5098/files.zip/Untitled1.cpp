#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(void){
	long long int T,i,n,m;
    scanf("%lld",&T);
    while(T--)
	{
		scanf("%lld %lld",&n,&m);
		printf("[");
	    for(i=1;i<=n;++i)
	    {
	    	if(i<=m)
	    	printf("#");
	    	else
	    	printf("-");
		}
		if(T!=0)
		printf("] %.0f%%\n\n",m*1.0/n*100);
		else
		printf("] %.0f%%\n",m*1.0/n*100);
	}
	return 0;
}
