#include<stdio.h>

int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int m,n;
		scanf("%d %d",&m,&n);
		double p;
		p = 1.0*n/m;
		int i;
		printf("[");
		for(i=0;i<n;i++){
			printf("#");
		}
		for(i=0;i<m-n;i++){
			printf("-");
		}
		printf("] %.0f%%\n",p*100);
	}
	return 0;
}
