#include<stdio.h>
#include<string.h> 
int main(void)
{
	char a[10];
	scanf("%s",a);
	int b=strcmp(a,"kfc"); 
	if(b==0)
	{
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __ \\/ ___\\\n");
	printf("|    <  |  | \\ \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/\n");
}
else
	return 0;
	
}
