﻿#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include <cstring>
#include<math.h>
#include<stdlib.h>
#include <time.h>
#include<iostream>
#include<limits.h>
#include<algorithm>
#include<queue>
#include<stack>
#include <map>
#include<set>
#include<cstdio>
#define RE0 return 0;
#define print printf
using namespace std;

typedef struct stu
{
	int number;
	char name[15];
	int location;
	double w;
}  STU;

int cmp(const void* p, const void* q)
{
	int pa = *((int*)p);
	int qa = *((int*)q);
	return qa - pa;
}

int constructcmp(const void* p, const void* q)
{
	return ((STU*)q)->number - ((STU*)p)->number;
}

int main()
{
	print(" __      _____\n");
	print("|  | ___/ ____\\____\n");
	print("|  |/ /\\   __\\/ ___\\\n");
	print("|    <  |  | \\  \\___\n");
	print("|__|_ \\ |__|  \\___  >\n");
	print("     \\/           \\/\n");
	RE0
}