#include <bits/stdc++.h>
using namespace std;
int main()
{
	int a,b,m,n,cnt;
	scanf("%d",&m);
	for(int i=0;i<m;i++){
		cnt=0;
		scanf("%d%d",&a,&b);
		if(b>0){
			b=a+b;
			if(b>9999){
				n=b-9999;
				b=9999-n;
			}
			if(a<b){
					for(int j=a;j<=b;j++){
					if((j%4==0&&j%100!=0)||j%400==0){
						cnt++;
					}
				}
			}
			if(b<a) {
				for(int j=b;j<=a;j++){
					if((j%4==0&&j%100!=0)||j%400==0){
						cnt++;
					}
				}
			}
		}
		else {
			b=a+b;
			for(int j=b;j<=a;j++){
				if((j%4==0&&j%100!=0)||j%400==0){
					cnt++;
				}
			}
		}
		printf("%d\n",cnt);
	}
	
	
	return 0;
} 
