#include<stdio.h>
#include<string.h>
int main (void){
	int sum=0,i,al,bl,cl,dl,e=0,f=0,g=0,h=0,k;
	char a[100],b[100],c[100],d[100];
	scanf("%s%s%s%s",a,b,c,d);
	al=strlen(a);
	bl=strlen(b);
	cl=strlen(c);
	dl=strlen(d);
	for(i=0;i<al;i++){
		k=int(a[i])-48;
		e+=k;
	}
	if(e>=16||e==6)
	sum++;
	for(i=0;i<bl;i++){
		k=int(b[i])-48;
		f+=k;
	}
	if(f>=16||f==6)
	sum++;
	for(i=0;i<cl;i++){
		k=int(c[i])-48;
		g+=k;
	}
	if(g>=16||g==6)
	sum++;
	for(i=0;i<dl;i++){
		k=int(d[i])-48;
		h+=k;
	}
	if(h>=16||h==6)
	sum++;	
	switch(sum){
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
		case 0:printf("Bao Bao is so Zhai......");break;
	}		
	return 0;
}
