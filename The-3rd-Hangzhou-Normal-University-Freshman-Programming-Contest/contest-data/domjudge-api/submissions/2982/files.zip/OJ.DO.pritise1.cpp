#include<stdio.h>
int main(void)
{
	int T;
	scanf("%d", &T);
	while(T--)
	{
		int Y, A, a, b, t, i, cnt=0;
		scanf("%d%d", &Y, &A);
		a = Y;
		b = Y + A;
		if(b > 9999)
		b = 9999*2-Y-A;
		if(a > b)
		{
			t = a;
			a = b;
			b = t;
		}
		for(i = a; i <= b; i++)
		{
			if((i % 4 == 0 && i % 100 != 0 )|| i % 400 == 0)
			  cnt += 1;
		}
		printf("%d\n", cnt);
	}
	return 0;
}  
