#include<stdio.h>
int main(){
	int t,a,b,c;
	scanf("%d",&t);
	int x=t;
	int arr[t-1];
	while(t>0){
		arr[t-1]=0;
		scanf("%d %d",&a,&b);
		b=a+b;
		if(b>9999){
			b=9999-b+9999;
		}
		if(a>b){
			c=a;
			a=b;
			b=c;
		}
		for(a;a<=b;a++){
		if((a%400==0)||(a%4==0&&a%100!=0)){
			arr[t-1]++;
		} 
	}
	t--;
}
int i;
	for(i=x-1;i>=0;i--){
		printf("%d\n",arr[i]);
	}
return 0;
}
