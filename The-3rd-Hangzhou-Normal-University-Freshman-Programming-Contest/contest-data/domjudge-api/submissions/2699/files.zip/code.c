#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
    char q[10];
    scanf("%s", q);
    printf("__ _____
        | | ___ / ____\____
        | |/ /\ __\ / ___\
        | < | | \ \___
        | __ | _ \ | __ | \___ >
        \ / \ /")
    return 0;
}