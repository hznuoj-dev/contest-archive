#include<stdio.h>
int main()
{
	long long int a,b,c,d;
	long long int  dight,sum=0,e,f,g,count=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	do
	{
		dight=a%10;
		sum+=dight;
		a/=10;
	}while(a);
	if(sum>=16||sum==6)
	count++;
	sum=0;
	do
	{
		e=b%10;
		sum+=e;
		b/=10;
	}while(b);
	if(sum>=16||sum==6)
	count++;
	sum=0;
	do
	{
    	f=c%10;
		sum+=c;
		c/=10;
	}while(c);
	if(sum>=16||sum==6)
	count++;
	sum=0;
	do
	{
		g=d%10;
		sum+=g;
		d/=10;
	}while(d);
	if(sum>=16||sum==6)
	count++;
	if(count==0)
	printf("Bao Bao is so Zhai......\n");
	if(count==1)
	printf("Oh dear!!\n");
		if(count==2)
	printf("BaoBao is good!!\n");
	if(count==3)
	printf("Bao Bao is a SupEr man///!\n");
		if(count==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}






