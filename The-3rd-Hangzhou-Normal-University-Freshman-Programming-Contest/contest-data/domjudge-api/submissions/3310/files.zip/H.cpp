#include<stdio.h>
int main() {
	int T, a, b;
	int c, d;
	scanf("%d", &T);
	while (T--) {
		scanf("%d%d", &a, &b);
		c = 100*b / a;
		d = a - b;
		printf("[");
		while (b--) {
			printf("#");
		}
		while (d--) {
			printf("-");
		}
		printf("] %d%%\n", c);
	}
	return 0;
}