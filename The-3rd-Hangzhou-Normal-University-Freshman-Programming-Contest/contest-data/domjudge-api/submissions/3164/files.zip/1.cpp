#include<stdio.h>
int he(int n) {
	int t = 0;
	while (n > 0) {
		t = t + n % 10;
		n = n / 10;
	}
	return t;
}
int main(void) {
	long long int a, b, c, d;
	int x = 0;
	scanf("%lld%lld%lld%lld", &a, &b, &c, &d);
	if (he(a) >= 16 || he(a) == 6)
		x = x + 1;
	if (he(b) >= 16 || he(b) == 6)
		x = x + 1;
	if (he(c) >= 16 || he(c) == 6)
		x = x + 1;
	if (he(d) >= 16 || he(d) == 6)
		x = x + 1;
	if (x == 1)
		printf("Oh dear!!\n");
	else if (x == 2)
		printf("BaoBao is good!!\n");
	else if (x == 3)
		printf("Bao Bao is a SupEr man///!\n");
	else if (x == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	else printf("Bao Bao is so Zhai......\n");
	return 0;
}