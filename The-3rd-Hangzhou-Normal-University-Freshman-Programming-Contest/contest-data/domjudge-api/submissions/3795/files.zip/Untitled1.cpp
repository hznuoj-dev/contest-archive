#include <stdio.h>
#define max 998244353
int main()
{
    int n,x;
    scanf("%d",&n);
    int a[100010]={0};
    for(int i=1;i<=n;++i)
	{
		scanf("%d",&x);
		a[x]+=1;
	 } 
	long long sum=a[1];
	for(int i=2;i<=100000;++i)
	{
		if(a[i])
		{
			for(int j=1;j<=a[i];++j)
			{
				sum*=a[i-1];
				if(sum>=max)
				{
					sum=sum%max;
				}
			}
		}
		else
		   break;
	}
	sum=sum%max;
	printf("%lld\n",sum);
	return 0;
 } 
