#include<stdio.h>
#include<string.h>
#include<math.h>
int main() {
int n,a,b,i,c;
scanf("%d",&n);
while(n--){
scanf("%d%d",&a,&b);
printf("[");
for(i=1;i<=b;i++){
	printf("#");
}
for(i=1;i<=a-b;i++){
	printf("-");
}
printf("]");
c=b*100/a; 
printf(" %d%%\n",c); 
}
}




