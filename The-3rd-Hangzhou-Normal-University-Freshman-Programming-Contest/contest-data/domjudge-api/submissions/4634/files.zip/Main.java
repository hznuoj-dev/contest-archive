import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			int n=in.nextInt();
			for(int i=1;i<=n;i++)
			{
				double a=in.nextDouble();
				double b=in.nextDouble();
					double c=(b/a)*100;
					String s="";
					for(int j=1;j<=b;j++)
					{
						s=s+"#";
					}
					for(int j=1;j<=a-b;j++)
					{
						s=s+"-";
					}
					String t="%";
					System.out.printf("[%s] %.0f%s\n",s,c,t);									
			}		
		}
	}	
}
