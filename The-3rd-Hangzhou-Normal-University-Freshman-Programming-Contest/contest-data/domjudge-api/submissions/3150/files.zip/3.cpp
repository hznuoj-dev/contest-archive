#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    float n,m,s;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        cin>>n>>m;
        for(int j=1;j<=m;j++)
        {
            printf("#");
        }
        for(int j=1;j<=n-m;j++)
        {
            printf("-");
        }
        s=m/n*100;
        printf("%.0f%\n",s);
    }
    return 0;
}
