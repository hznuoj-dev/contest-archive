#include<stdio.h>
#include<string.h>
int main(){
	int T,n,len,B;
	scanf("%d",&T);
	while(T--){
		int cnt=0;
		char s[1000005];
		scanf("%d",&n);
		while(n--){
			int k=0;
			char c[1000]={'.'};
			scanf("%s",s);
			len=strlen(s);
			for(int i=0;i<len;i++){
				
				if(s[i]!='.'){
					B=0;
					for(int j=1;j<=k;j++){
						if(s[i]==c[j])B=1;break;
					}
					if(B==0){
						k++;
						c[k]=s[i];
					}
				}
				
			}
			cnt+=k;
		}
		printf("%d\n",cnt);
	}
}
