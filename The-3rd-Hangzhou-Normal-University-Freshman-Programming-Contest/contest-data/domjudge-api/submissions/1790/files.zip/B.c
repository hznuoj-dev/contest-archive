#include <stdio.h>

int main(void)
{
	int T, Y, A, i, cnt, max, min;
	
	scanf("%d", &T);
	while(T--)
	{
		cnt = 0;
		scanf("%d%d", &Y, &A);
		A += Y;
		if(A > 9999)
			A = 19998 - A;
		
		max = A > Y ? A : Y;
		min = A > Y ? Y : A;
		for(i = min; i <= max; ++i)
		{
			if((i % 4 == 0) && (i % 100 != 0) || (i % 400 == 0))
				cnt++;
		}
		printf("%d\n", cnt);
	}
	
	return 0;
}
