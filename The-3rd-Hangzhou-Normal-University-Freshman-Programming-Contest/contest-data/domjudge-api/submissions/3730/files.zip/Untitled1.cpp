#include <stdio.h>
#include <string.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int i,n,sum=0;
		char s[1000005];
		scanf("%d",&n);
		getchar();
		while(n--)
		{
			char a[1000]={0};
			gets(s);
			for(i=0;i<strlen(s);i++)
			{
				if(s[i]!='.')
				a[(int)s[i]]++;
			}
			for(i=0;i<1000;i++)
			{
				if(a[i]!=0)
				sum++;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
