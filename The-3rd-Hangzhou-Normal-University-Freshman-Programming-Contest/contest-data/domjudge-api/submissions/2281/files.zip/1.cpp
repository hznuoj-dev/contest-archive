#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#include <cmath>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)
#define ll long long
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)

using namespace std;
int t;
int n,m;

int main()
{
//	fcin;
	cin>>t;
	while(t--)
	{
		cin>>n>>m;
		cout<<"[";
		for(int i=0;i<m;i++) cout<<'#';
		for(int i=0;i<n-m;i++) cout<<'-';
		cout<<"] ";
		cout<<m*100/n<<'%'<<endl;	
	}	
}
