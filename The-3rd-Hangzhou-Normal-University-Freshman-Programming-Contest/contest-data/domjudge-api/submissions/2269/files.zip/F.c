#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int sum,n,bu,cen,i,j,q,w;
	char str[1000][100000];
    scanf("%d",&n);
    for(bu=0;bu<n;++bu){
    	sum=0;
    	scanf("%d",&cen);
    	for(i=0;i<cen;++i)
    	scanf("%s",str[i]);
    	for(j=0;j<cen;++j){
    		for(q=0;q<strlen(str[j]);++q){
    			for(w=q+1;w<strlen(str[j]);++w){
    				if(str[j][q]==str[j][w])
    				str[j][w]=='.';
				}
			}
			for(q=0;q<strlen(str[j]);++q){
				if(str[j][q]!='.')
				sum++;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
