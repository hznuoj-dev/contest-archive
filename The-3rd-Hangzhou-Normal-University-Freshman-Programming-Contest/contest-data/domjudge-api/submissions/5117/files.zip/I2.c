#include <stdio.h>

int main(void)
{
	char a[4][18];
	int sum[4], i, j, t;
	
	scanf("%s %s %s %s", a[0], a[1], a[2], a[3]);
	for(j = 0; j < 4; ++j)
	{
		t = 0;
		for(i = 0; i < 18; ++i)
		{
			if(a[j][i] == 0)
				break;
			t = t - 48 + a[j][i];
		}
		if(t >= 16 || t == 6)
			sum[j] = 1;
		else
			sum[j] = 0;
	}
	t = sum[0] + sum[1] + sum[2] + sum[3];
	if(t == 1)
		printf("Oh dear!!");
	else if(t == 2)
		printf("BaoBao is good!!");
	else if(t == 3)
		printf("Bao Bao is a SupEr man///!");
	else if(t == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(t == 0)
		printf("Bao Bao is so Zhai......");
	
	
	return 0;
}
