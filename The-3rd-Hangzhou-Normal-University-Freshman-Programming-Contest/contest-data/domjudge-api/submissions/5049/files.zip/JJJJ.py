t=int(input())
i=0
for i in range(0,t):
    floor=int(input())
    ans=0
    for i in range(0,floor):
        s=input()
        set1=set()
        for ch in s:
            if ch=='.':
                ans+=0
            else:
                set1.add(ch)
        ans+=len(set1)
    print(ans)
