#include <stdio.h>
#include <math.h>
int main (){
	char a[100];
	gets(a);
	printf(" --      -----     \n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/ \n");
	return 0;
}
