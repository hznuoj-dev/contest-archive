#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int T;
	scanf("%d",&T);
	while(T--){
		double n,m;
		scanf("%lf %lf",&n,&m);
		int a;
		a=(int)((m/n)*100);
		printf("[");
		int i;
		for(i=1;i<=m;i++){
			printf("#");
		}
		for(i=1;i<=n-m;i++){
			printf("-");
		}
		printf("]%d%%\n",a);
	}
	return 0;
}
