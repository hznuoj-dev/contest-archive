#include<stdio.h>
#include<stdlib.h>
int hh(const void* a, const void* b) {
	return *(int*)a - *(int*)b;
}
int main(void) {
	int t, k[100000];
	long long x = 1, y = 1, z = 1, w;
	scanf("%d", &t);
	for (int i = 0; i < t; i++) {
		scanf("%d", &k[i]);
	}
	qsort(k, t, sizeof(int), hh);
	for (int i = 1; i < t; i++) {
		if (k[i] != k[i - 1]) {
			if (x == 1) {
				x = y;
				y = 1;
			}
			else if (y == 1) {
				z = z * x;
				x = y;
				y = 1;
			}
			else {
				z = z * (x - 1) * (y + 1);
				x = y;
				y = 1;
			}
		}
		else {
			y++;
		}
		if(i==t-1&&k[i]!=2){
			if(x==1){
				z=z*y;
			}
			else if(y==1){
				z=z*x;
			}
			else{
				z=z*(x-1)*(y+1);
			}
		}
	}
	printf("%lld", z);
}
