#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t;
	int x;
	
	int n,m;
	cin>>t;
	while(t--)
	{
		int ans=0;
		cin>>n>>m;
		x=n+m;
		if(x>=10000) 
		{
			x=x-9999;
			x=9999-x;
		}
		int min=n;
		int max=x;
		if(n>x)
		{
			min=x;
			max=n;
		}
		for(int i=min;i<=max;i++)
		{
			if(i%4==0&&i%100!=0||i%400==0) ans++;
		}
		cout<<ans<<endl;
	}
}
