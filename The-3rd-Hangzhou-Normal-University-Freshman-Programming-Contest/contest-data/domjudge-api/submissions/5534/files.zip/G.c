#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int mi,mj,mt,xh,xj,t,i,j,e,n,m,a[1001],x[1001],y[1001],q,w,tmp;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		for(i=1;i<=1001;i++){
			a[i]=i;
		}
		for(i=0;i<m;i++){
			scanf("%d %d",&x[i],&y[i]);
		}
		for(mi=0;mi<m;mi++){
				for(mj=mi+1;mj<m;mj++){
					if(x[mi]>x[mj]){
						tmp=x[mi];x[mi]=x[mj];x[mj]=tmp;
						tmp=y[mi];y[mi]=y[mj];y[mj]=tmp;
					}
				}
			}
			mt=m;
		for(xh=0;xh<m;xh++){
			if(x[xh]==x[xh+1]&&y[xh]==y[xh+1]){
				for(xj=xh+1;xj<mt-1;xj++){
					x[xj]=x[xj+1];y[xj]=y[xj+1];
				}
				mt--;
			}
		}
		for(xh=0;xh<mt;xh++){
			for(e=1;e<=n;e++){
				if(a[e]==x[xh]){
					q=e;
				}
				if(a[e]==y[xh]){
					w=e;
				}
			}
			if(a[q]>a[w]){
				tmp=a[w];
				a[w]=a[q];
				for(j=q;j>=w+2;j--){
					a[j]=a[j-1];
				}
				a[j]=tmp;
			}
		}
		
		for(i=1;i<=n-1;i++){
			printf("%d ",a[i]);	
		}
		printf("%d\n",a[n]);

	}
}
