#include<stdio.h>
int main(){
	long long a,b,c,d,sa=0,sb=0,sc=0,sd=0,p=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>0){
		sa=sa+a%10;
		a=a/10;
	}
		while(b>0){
		sb=sb+b%10;
		b=b/10;
	}
		while(c>0){
		sc=sc+c%10;
		c=c/10;
	}
		while(d>0){
		sd=sd+d%10;
		d=d/10;
	}
	     if(sa==6||sa>=16)
	     p=p+1;
	     	 if(sb==6||sb>=16)
		 p=p+1;
		 if(sc==6||sc>=16)
		 p=p+1;
		 	if(sd==6||sd>=16)
	     p=p+1; 
	     	if(p==0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	else if(p==1)
	{
		printf("Oh dear!!\n");
	}
	else if(p==2)
	{
		printf("BaoBao is good!!\n");
	}
	else if(p==3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	else 
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");

} 
