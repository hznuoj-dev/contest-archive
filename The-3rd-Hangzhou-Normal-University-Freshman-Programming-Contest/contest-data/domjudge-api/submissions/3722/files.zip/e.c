#include<stdio.h>
#include<string.h>
int main(){
	char a[2];
	char b[2]={'k','f','c'};
	int i;
	
	for(i=0;i<2;++i){
		scanf("%c\n",a[i]��;
	}
	if(serncmp(a,b,3)=0){
		printf("__ _____
| | ___/ ____\\\____
| |/ /\\\ __\\\/ ___\\\
| < | | \\\ \\\___
|__|_ \\\ |__| \\\___ >
\\\/ \\\/");
return 0;
}