#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
    int T,a,b,i;
    scanf("%d",&T);
    while(T--){
    	scanf("%d%d",&a,&b);
    	printf("[");
    	for(i=1;i<=b;i++){
    		printf("#");
		}
		for(i=b;i<a;i++){
			printf("-");
		}
		printf("] ");
		printf("%d",b*100/a);
		printf("%%\n");
	}
	return 0;
}
