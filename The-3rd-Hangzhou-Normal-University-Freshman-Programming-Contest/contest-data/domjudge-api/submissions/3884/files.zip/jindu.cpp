#include<stdio.h>
int main()
{
	int t,n,m,a,b;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		a=100*m/n;
		b=n-m;
		printf("[");
		while(m--)
		{
		printf("#");}
		
		while(b--)
		{
			printf("-");
		}
		printf("]");
		printf(" %d%%\n",a);
	}
}
