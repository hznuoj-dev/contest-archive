import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		while(in.hasNext())
		{
			String a=in.next();
			
			if (a.equals("kfc"))
			{
				System.out.println(" __      _____\r\n"
						+ "|  | ___/ ____\\____\r\n"
						+ "|  |/ /\\   __\\/ ___\\\r\n"
						+ "|    <  |  | \\  \\___\r\n"
						+ "|__|_ \\ |__|  \\___  >\r\n"
						+ "     \\/           \\/\r\n");
				
			}
		}
	}

}
