#include<stdio.h>
int main(void){
int a,b,c,d,i,s=0;
scanf("%d%d%d%d",&a,&b,&c,&d);
i=0;
while(a){
	i+=a%10;
	a/=10;
}
if(i>=16||i==6)
s+=1;
i=0;
while(b){
	i+=b%10;
	b/=10;
}
if(i>=16||i==6)
s+=1;
i=0;
while(c){
	i+=c%10;
	c/=10;
}
if(i>=16||i==6)
s+=1;
i=0;
while(d){
	i+=d%10;
	d/=10;
}
if(i>=16||i==6)
s+=1;
switch(s){
	case 0:puts("Bao Bao is so Zhai......");
		break;
	case 1:puts("Oh dear!!");
	    break;
	case 2:puts("BaoBao is good!!");
		break;
	case 3:puts("Bao Bao is a SupEr man///!");
		break;
	case 4:puts("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		break;
	}
return 0;}
