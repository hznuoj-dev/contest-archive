#include<stdio.h>

int main(){
	int T,Y,A,n=0;
	scanf("%d",&T);
	while(T--){
		n=0;
		scanf("%d%d",&Y,&A);
		int m = Y+A;
		if(m>9999)
			m = 9999-(m-9999);
		if(m > Y){
			for(int i=Y;i<=m;++i){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					n++;
				}
			}
		}
		else{
			for(int i=m;i<=Y;++i){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					n++;
				}
			}
		}
		printf("%d\n",n);
	}
    return 0;
}

