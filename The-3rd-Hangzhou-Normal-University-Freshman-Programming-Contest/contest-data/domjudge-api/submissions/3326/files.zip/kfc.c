#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(viod){
	char str[100];
	gets(str);
	printf(" __       _____             \n");
	printf("\n");
	printf("|  | ___/  ____ \\____      \n");
	printf("\n");
	printf("|  |/ /\\    __\\/  ___ \\  \n");
	printf("\n");
	printf("|    <   |  | \\  \\___     \n");
	printf("\n");
	printf("|__|_ \\  |__|   \\___  >   \n");
	printf("\n");
	printf("     \\/            \\/     \n");
	return 0; 
}
