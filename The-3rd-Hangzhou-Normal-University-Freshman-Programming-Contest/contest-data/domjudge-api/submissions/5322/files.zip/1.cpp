#include<stdio.h>
#include<vector>
using namespace std;
int main()
{
	vector<int> vec;
	int T, i, n, m, x, y, a, b, t;
	scanf("%d", &T);
	while (T--)
	{
		vec.clear();
		scanf("%d%d", &n, &m);
		vec.push_back(0);
		for (i = 1; i <= n; i++)
			vec.push_back(i);
		while (m--)
		{
			scanf("%d%d", &x, &y);
			if (vec[x] > vec[y])
			{
				t = vec[x];
				vec.insert(vec.begin() + vec[y], x);
				vec.erase(vec.begin() + t + 1);
			}
		}
		for (i = 1; i <= n - 1; i++)
			printf("%d ", vec[i]);
		printf("%d\n", vec[n]);
	}
	return 0;
}
