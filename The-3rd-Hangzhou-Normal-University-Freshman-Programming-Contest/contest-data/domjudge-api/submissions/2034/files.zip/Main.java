import java.util.Scanner;


public class Main 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			String s=sc.nextLine();
			if(s.equals("kfc"))
			{
				for(int i=1;i<=6;i++)
				{
					switch(i)
					{
					case 1:System.out.println(" --   -----");break;
					case 2:System.out.println("|"+"  "+"|"+"__"+"/"+" "+"___"+"\\"+"___");break;
					case 3:System.out.println("|"+"  "+"|"+"/"+" "+"/"+"\\"+"   "+"__"+"\\"+"/"+" "+"___"+"\\");break;
					case 4:System.out.println("|"+"    "+"<"+"  "+"|"+"  "+"|"+" "+"\\"+"  "+"\\"+"___");    break;         
					case 5:System.out.println("|"+"__"+"|"+"_"+" "+"\\"+" "+"|"+"__"+"|"+"  "+"\\"+"___"+"  "+">");break;
					case 6:System.out.println("     "+"\\"+"/"+"          "+"\\"+"/");break;
					}
					
						}
			}
					
		}

	}

}
