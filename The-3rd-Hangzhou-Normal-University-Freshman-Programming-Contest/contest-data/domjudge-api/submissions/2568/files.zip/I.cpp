#include <stdio.h>
#include <string.h>
int main(void){
	int l,sum=0,x=0;
	char a[300],b[300],c[300],d[300];
	scanf("%s %s %s %s",&a,&b,&c,&d);
	l=strlen(a);
	for(int i=0;i<l;i++){
		sum=sum+a[i];
	}
	if((sum>=16)||(sum==6)){
		x=x+1;
	}
	sum=0;
	for(int i=0;i<l;i++){
		sum=sum+b[i];
	}
	if((sum>=16)||(sum==6)){
		x=x+1;
	}
	sum=0;
	for(int i=0;i<l;i++){
		sum=sum+c[i];
	}
	if((sum>=16)||(sum==6)){
		x=x+1;
	}
	sum=0;
	for(int i=0;i<l;i++){
		sum=sum+d[i];
	}
	if((sum>=16)||(sum==6)){
		x=x+1;
	}
	if(x==1){printf("Oh dear!!");}
	else if(x==2)printf("BaoBao is good!!");
	else if(x==3)printf("Bao Bao is a SupEr man///!");
	else if(x==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else
	 printf("Bao Bao is so Zhai......");
}
