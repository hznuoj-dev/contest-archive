#include<stdio.h>

int sum(int num) {
    int sum = 0;
    while (num > 0) {
        sum += num % 10;
        num /= 10;
    }
    return sum;
}

int isVisited(int num) {
    if (sum(num) >= 16 || sum(num) == 6) {
        return 1;
    }
    return 0;
}

int main() {
    int a, b, c, d;
    scanf("%d %d %d %d", &a, &b, &c, &d);
    int count = 0;
    count = isVisited(a) + isVisited(b) + isVisited(c) + isVisited(d);
    if (count == 1) {
        printf("Oh dear!!\n");
    } else if (count == 2) {
        printf("BaoBao is good!!\n");
    } else if (count == 3) {
        printf("Bao Bao is a SupEr man///!\n");
    } else if (count == 4) {
        printf("“Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
    } else {
        printf("Bao Bao is so Zhai......\n");
    }
    return 0;
}


