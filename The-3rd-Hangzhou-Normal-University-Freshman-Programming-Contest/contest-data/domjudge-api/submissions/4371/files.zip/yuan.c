#pragma warning (disable:4996)
#include<stdio.h>
#include<string.h>
int main(void) {
	int  i, j, m, n,jj,u,k,p;
	int flag,sum,max=0;
	int a[100001];
	int b[1001] = { 0 };
	scanf("%d %d", &n, &m);
	for (i = 1; i <= n; i++) 
		scanf("%d", &a[i]);
	for (i = 1; i <= n; i++) {
		scanf("%d", &j);
		b[a[i]] = j;
		max += a[i] * j;
	}
	sum = 0;
	for (j = 1; j <= m; j++) {
		p = j;
		flag = 0;
		jj = 1000;
		k = b[jj];
		while (p > 0 && jj>0) {
			if (b[jj] == 0) {
				b[jj] = k;
				jj--;
				k = b[jj];
			}
			else if (p >= jj) {
				p -= jj;
				b[jj]--;
			}
			else {
				b[jj] = k;
				jj--;
				k = b[jj];
			}
		}
		b[jj] = k;
		if (p == 0)
			flag = 1;
		else {
			u = max - j;
			flag = 0;
			jj = 1000;
			k = b[jj];
			while (u > 0 && jj > 0) {
				if (b[jj] == 0) {
					b[jj] = k;
					jj--;
					k = b[jj];
				}
				else if (u >= jj) {
					u -= jj;
					b[jj]--;
				}
				else {
					b[jj] = k;
					jj--;
					k = b[jj];
				}
			}
			if (u == 0)
				flag = 1;
		}
		if (flag) {
			sum++;
		}
	}
	printf("%d\n", sum);
	return 0;
}