//
//  main.c
//  i
//
//  Created by 蔡欣怡 on 2020/12/13.
//

#include <stdio.h>
int f(long long n){
    int s=0;
    while(n){
        s=s+n%10;
        n=n/10;
    }
    return s;
}
int main() {
    // insert code here...
    long long a,b,c,d;
    int sum1=0;
    (void)scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
    if(f(a)==6||f(a)==16)
        sum1++;
    if(f(b)==6||f(b)==16)
        sum1++;
    if(f(c)==6||f(c)==16)
        sum1++;
    if(f(d)==6||f(d)==16)
        sum1++;
    switch(sum1){
        case 0:
            printf("Bao Bao is so Zhai......\n");
            break;
        case 1:
            printf("Oh dear!!\n");
            break;
        case 2:
            printf("BaoBao is good!!\n");
            break;
        case 3:
            printf("BaoBao is good!!\n");
            break;
        case 4:
            printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
            break;
        default:
            printf("非法输入\n");
            break;
    }
    return 0;
}
