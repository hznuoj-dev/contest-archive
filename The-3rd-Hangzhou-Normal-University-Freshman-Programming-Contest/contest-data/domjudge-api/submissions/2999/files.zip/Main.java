
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		  while (sc.hasNext())
	      {
			int n=sc.nextInt();
			for(int i=0;i<n;i++)
			{
				int sum=0;
				int nn=sc.nextInt();
				for(int j=0;j<nn;j++)
				{					
					String a=sc.next();
					for(int k=0;k<a.length();k++)
					{
						if(a.substring(k,k+1).equals(".")==true)
						{
							continue;
						}
						else
						{
							sum++;
							a=a.replace(a.substring(k,k+1), ".");
						}
					}
				}
				System.out.println(sum);
			}
	      }			  
	}

}
