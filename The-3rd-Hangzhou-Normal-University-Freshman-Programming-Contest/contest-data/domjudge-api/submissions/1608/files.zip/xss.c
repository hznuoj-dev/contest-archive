#include<stdio.h>
int main()
{
	int t, y, a, year, i, n;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d%d", &y, &a);

		year = y + a;
		if (year > 9999)
		{
			year = 9999 - (year - 9999);
		}
		n = 0;
		if (y <= year)
		{
			for (i = y;i <= year;++i)
			{

				if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				{
					n = n + 1;
				}
			}
		}
		else
		{
			for (i = year;i <= y;++i)
			{

				if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				{
					n = n + 1;
				}
			}
		}
		printf("%d\n", n);
	}
}