#include<stdio.h>
int main() {
	int t, m, n,i,j;
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &m, &n);
		printf("[");
		for (i = 1; i <= n; i++) {
			
			printf("#");
		}
		for (i = n+1; i <= m; i++) {
			
			printf("-");
			
		}
		printf("] ");
		printf("%.0f", n*100.0 / m);
		printf("%%\n");
	}
}