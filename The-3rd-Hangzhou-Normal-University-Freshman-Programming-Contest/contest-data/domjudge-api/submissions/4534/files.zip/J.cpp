#include<bits/stdc++.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	getchar();
	int a[130];
	int cnt=0;
	while(t--)
	{
		int h;
		cin>>h;
		getchar();
		while(h--)
		{
			string s;
			getline(cin,s);
			for(int i=0;i<s.length();i++)
			{
				if(s[i] != '.' && a[s[i]] == 0)  {
					a[s[i]] ++;
					cnt++;
				}
			}	
		}
		cout<<cnt+1<<endl;
		
	}
	
	
	return 0;
}
