#include<stdio.h>
int main(void){
	int n=0,a,w;
	for(int i=1;i<=4;i++){
		scanf("%d",&a);
		w=0;
		while(a>0){
			w+=a%10;
			a=a/10;
		}
		if(w>=16||w==6){n++;}
	} 
	if(n==0){printf("Bao Bao is so Zhai......");}
	else if(n==1){printf("Oh dear!!");}
	else if(n==2){printf("BaoBao is good!!");}
	else if(n==3){printf("Bao Bao is a SupEr man///!");}
	else if(n==4){printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");}
}
