#include<bits/stdc++.h>
using namespace std;
int p(int i,int j)
{
    if(i>j) return i;
    else return j;
}
int d(int i,int j)
{
    if(i>j) return j;
    else return i;
}
int main()
{   int t,a,b,c,sum,i;
    cin>>t;
    while(t--)
    {    sum=0;
        cin>>a>>b;
        c=a+b;
        if(c>=9999) {c=c-9999;c=9999-c;}
        for(i=d(a,c);i<=p(a,c);i++)
        {
            if(i%4==0&&i%100!=0||i%400==0) sum++;
        }
        cout<<sum<<endl;
    }
    return 0;
}
