#include<stdio.h>
#pragma warning(disable:4996)
int main(){
	long long T,a,b,c,d,i,sum=0;
	scanf("%lld",&T);
	while(T--){
		scanf("%lld %lld",&a,&b);
		c=a+b;sum=0;
		if(c>=10000){
			c=9999-(c-9999);
			if(c<a){
				a=d;a=c;c=d;
			}
			for(i=a;i<=c&&i>=a;i++){
				if((i%4==0&&i%100!=0)||i%400==0) sum+=1;
			}
		}
		else{
			if(c<a){
				d=a;a=c;c=d;
			}
 			for(i=a;i<=c&&i>=a;i++){
				if((i%4==0&&i%100!=0)||i%400==0) sum+=1;
			}
		}
		printf("%lld\n",sum);
	}
}