#include<bits/stdc++.h>
using namespace std;


int main(void)
{
	int t;
	cin>>t;
	while(t--)
	{
		int n,m;
		cin>>n>>m;
		printf("[");
		for(int i=1;i<=m;++i)
		 printf("#");
		for(int i=1;i<=n-m;++i)
		 printf("-");
		printf("] ");
		printf("%.0lf",(double)m/n*100);
		printf("%\n");
	}
	return 0;
}

