
import java.util.Arrays;
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{  int ans=0;
			int a=sc.nextInt();
			int b=sc.nextInt();
			int c=sc.nextInt();
			int d=sc.nextInt();
                if(daan(a)) {
                	ans++;
                }
                if(daan(b)) {
                	ans++;
                }
                if(daan(c)) {
                	ans++;
                }
                if(daan(d)) {
                	ans++;
                }
			  if(ans==0) {
				  System.out.println("Bao Bao is so Zhai......");
			  }
			  if(ans==1) {
				  System.out.println("Oh dear!!");
			  }
			  if(ans==2) {
				  System.out.println("BaoBao is good!!");
			  }
			  if(ans==3) {
				  System.out.println("Bao Bao is a SupEr man///!");
			  }
			  if(ans==4) {
				  System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			  }
		}

	}
    public static boolean daan(int n) {
    	int ans=0;int p=0;
    	while(n!=0) {
    		ans+=n%10;
    		n=n/10;
    	}
    	if(ans>=16||ans==6) {
    		return true;
    	}
    	
    	return false ;
    	
    }
}