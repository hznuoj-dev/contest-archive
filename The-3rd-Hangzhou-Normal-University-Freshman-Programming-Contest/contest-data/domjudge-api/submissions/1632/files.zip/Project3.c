﻿#include <stdio.h>
int main() {
    int n, year1, t, year2, l, r, i, sum;
    scanf("%d", &t);
    while (t--) {
        sum = 0;
        scanf("%d %d", &year1, &n);
        if (year1 + n <= 9999)
            year2 = year1 + n;
        else
            year2 = 9999 - (year1 + n - 9999);
        if (year1 < year2) {
            l = year1;
            r = year2;
        }
        else {
            l = year2;
            r = year1;
        }
        for (i = l; i <= r; i++) {
            if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0) {
                sum++;
            }
        }
        printf("%d\n", sum);
    }
    return 0;
}