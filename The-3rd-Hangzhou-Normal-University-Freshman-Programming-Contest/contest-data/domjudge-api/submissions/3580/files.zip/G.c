#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int i;
		int n,m;
		scanf("%d",&n);
		scanf("%d",&m);
		int a[n+1];
		for(i=0;i<=n;i++)
		{
			a[i]=i;
		}
		while(m--)
		{
			int x,y;
			scanf("%d %d",&x,&y);
			int win;
			int los;
			for(i=1;i<=n;i++)
			{
				if(a[i]==x)
				{
					win=i;
				}
				if(a[i]==y)
				{
					los=i;
				}
			}
			if(win>los)
			{
				int p=a[win];
				for(i=win;i>los;i--)
				{
					a[i]=a[i-1];
				}
				a[los]=p;
			}
		}
		for(i=1;i<=n;i++)
		{
			if(i==1){printf("%d",a[i]);
			}
			
			else
			{
				printf(" %d",a[i]);
			}
		}
		printf("\n");
		
		
	}
	
	
}
