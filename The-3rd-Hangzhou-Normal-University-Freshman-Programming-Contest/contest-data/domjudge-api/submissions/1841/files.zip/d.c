#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	 int n,m=1; 
	char x[100];
	    scanf("%d",&n);
	    
	    scanf("%s",x);	
		    m=strlen(x);
		
		
	   printf("%d\n",n*m);	    
	return 0;
} 
