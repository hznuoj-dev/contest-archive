#include<iostream>
#include<cmath>

using namespace std;
int level[10001];
int main()
{
    int n;
    cin >> n;
    int i,j=0,it1,it,sum;
    sum=1;
    for(i=0;i<n;i++)
    {
        cin >> it1;
        level[it1]++; 
        if(level[it1]==1)
        j++; 
    }
    for(i=2;i<=j;i++)
    {
        sum=sum*pow(level[i]+1,level[i-1]-1);
    }
    cout << sum;
    
    return 0;
}