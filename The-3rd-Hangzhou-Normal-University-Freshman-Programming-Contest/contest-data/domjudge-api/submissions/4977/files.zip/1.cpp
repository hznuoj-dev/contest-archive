#include<stdio.h>
int main(void) {
	int t, c, a, b, i;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &a, &b);
		c = (b * 100.0) / a;
		for (i = 1; i <= a; i++) {
			if (i == 1) {
				printf("[");
			}
			if (i <= b) {
				printf("#");
			}
			if (i > b) {
				printf("-");
			}
			if (i == a) {
				printf("] %d%%\n", c);
			}
		}
	}
	return 0;
}
