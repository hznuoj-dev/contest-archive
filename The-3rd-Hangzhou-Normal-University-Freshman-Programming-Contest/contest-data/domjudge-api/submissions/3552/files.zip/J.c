#include<stdio.h>
int main(void){
long int t,n,s,ss;
char a;
scanf("%ld",&t);
while(t--){
	ss=0;
	scanf("%ld ",&n);
	while(n--){
		int b[50]={0};s=0;
		while(scanf("%c",&a),a!='\n'){
			if(a!='.'&&b[(int)a]==0)
			s++,b[(int)a]++;
		}
		ss+=s;
	}
	printf("%ld\n",ss);
}

return 0;}
