#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int n,s=0;
	long long int m,a[102],b[102];
	scanf("%d%lld",&n,&m);
	for(int i=0;i<n;++i)
		scanf("%lld",&a[i]);
	for(int i=0;i<n;++i)
		scanf("%lld",&b[i]);
	for(long long int i=1;i<=m;++i)
	{
		for(int j=n-1;j>=0;--j)
		{
			if(i>a[j])
			{
				if(i>a[j]*b[j])
					i=i-a[j]*b[j];
				else
					i=i%a[j];
			}
			if(i==0){
				s++;
				break;	
			}
		}
	}
	printf("%d",s);
} 
