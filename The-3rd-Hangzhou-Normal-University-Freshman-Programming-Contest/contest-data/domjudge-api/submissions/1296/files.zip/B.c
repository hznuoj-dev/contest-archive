#include<stdio.h>
int run(int n) {
	if((n%4==0&&n%100!=0)||n%400==0)
		return 1;
	else
		return 0;
}
int main(void) {
	int n,sum=0,a,b,c;
	scanf("%d",&n);
	while(n--) {
		scanf("%d %d",&a,&b);
		c=a+b;
		if(c<a) {
			int temp;
			temp=c;
			c=a;
			a=temp;
		}
		if(c>9999) {
			int d;
			d=c-9999;
			c=9999-d;
		}
				if(c<a) {
			int temp;
			temp=c;
			c=a;
			a=temp;
		}
		for(int i=a; i<=c; i++) {
			if(run(i))
				sum+=1;
			else
				sum+=0;
		}
		printf("%d\n",sum);
		sum=0;
	}
	return 0;
}
