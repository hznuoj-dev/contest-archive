#include<stdio.h>
#include<string.h>
char s[1000005];
int main()
{
	int n, sum = 0;
	scanf("%d", &n);
	while (n--)
	{
		scanf("%s", &s);
		sum += strlen(s);
	}
	printf("%d\n", sum);
	return 0;
}
