#include<stdio.h>
#include<string.h>
int main()
{
	int t, a, b, i;
	double c;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d %d", &a, &b);
		c = 1.0*b / a * 100;
		printf("[");
		for (i = 0; i < b; i++)
		{
			printf("#");
		}
		for (i = 0; i < a - b; i++)
		{
			printf("-");
		}
		printf("] %.0f%%\n", c);
	}
}
