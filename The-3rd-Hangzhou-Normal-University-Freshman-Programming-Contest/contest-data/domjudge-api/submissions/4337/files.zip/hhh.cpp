#include<stdio.h>
int main(){
	int i,j,t,y;
	float x;
    int n,m;
	scanf("%d\n",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		x=1.0*m/n;
		y=x*100;
		printf("[");
		for(i=0;i<m;i++){
		
		   printf("#");
	}
		for(i=0;i<n-m;i++){
		
		  printf("-");
	}
		printf("]");
		printf(" %d%%\n",y);
		}
		printf("\n");
		return 0;
	
	
}
