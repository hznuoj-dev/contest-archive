#include<stdio.h>
#include<string.h>
int main(){
	long long int a,b,c,d;
	int f=0,t=0,x;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>0){
		x = a % 10;
		t += x;
		a /= 10;
	}
	if(t==6||t>=16)
	    f += 1;
	t = 0;
	while(b>0){
		x = b % 10;
		t += x;
		b /= 10;
	}
	if(t==6||t>=16)
	    f += 1;
	t = 0;
	while(c>0){
		x = c % 10;
		t += x;
		c /= 10;
	}
	if(t==6||t>=16)
	    f += 1;
	t = 0;
	while(d>0){
		x = d % 10;
		t += x;
		d /= 10;
	}
	if(t==6||t>=16)
	    f += 1;
	if(f==0)
	    printf("Bao Bao is so Zhai......");
	else if(f==1)
		printf("Oh dear!!");
	else if(f==2)
		printf("BaoBao is good!!");
	else if(f==3)
		printf("Bao Bao is a SupEr man///!");
	else
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}



