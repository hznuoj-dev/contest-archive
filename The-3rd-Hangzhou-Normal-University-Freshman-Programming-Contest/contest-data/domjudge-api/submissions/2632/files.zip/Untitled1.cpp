#include<stdio.h>
int function(char a[], int len, char b){
	int i = 0;
	for(i=0;i<len;i++){
		if(b == a[i]) return 1;
	}
//	printf("-------------------\nstring is %s, len is %d\nthe char is %c\n-------------------\n", a, len, b); 
	return 0;
}

int main(){
	int t;
	int n;
	int i,j;
	char s[10];
	char temp[10] = {0};
	int num; // ���������� 
	int len_temp = 0;  // ��һ����ֹ����������� 
	scanf("%d", &t);
	while(t--){
		num = 0;
		scanf("%d", &n);
		
		while(n--){
			temp[10] = {0};
			len_temp = 0;
			scanf("%s", s);
//			printf("---------------\n");
			for(i=0;s[i]!='\0';i++){
				
				if(s[i] != '.'){
//					printf("%c ", s[i]);
					if(function(temp, len_temp, s[i]) == 0){
						num++;
						temp[len_temp] = s[i];
						len_temp++;
					}
				}
			}
//			printf("\n-------------\n");
//			printf("num = %d\n", num);
//			printf("%d %s\n", len_temp, temp);
		}
		printf("%d\n", num);
	}
	
} 
