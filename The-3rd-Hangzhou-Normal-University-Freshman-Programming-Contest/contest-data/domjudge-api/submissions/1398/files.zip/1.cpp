#include <bits/stdc++.h>
using namespace std;

int main() {
	string a,b,c,d;
	int cnt=0,a1=0,b1=0,c1=0,d1=0;
	cin>>a>>b>>c>>d;
	for (int i=0;i<a.length();i++) {
		a1+=(a[i]-48);
	}
	if (a1>=16||a1==6) cnt++;
	for (int i=0;i<b.length();i++) {
		b1+=(b[i]-48);
	}
	if (b1>=16||b1==6) cnt++;
	for (int i=0;i<c.length();i++) {
		c1+=(c[i]-48);
	}
	if (c1>=16||c1==6) cnt++;
	for (int i=0;i<d.length();i++) {
		d1+=(d[i]-48);
	}
	if (d1>=16||d1==6) cnt++;
	if (cnt==4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
	else if (cnt==3) cout<<"Bao Bao is a SupEr man///!";
	else if (cnt==2) cout<<"BaoBao is good!!";
	else if (cnt==1) cout<<"Oh dear!!";
	else cout<<"Bao Bao is so Zhai......";
}
