package h;

import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner a=new Scanner(System.in);
		while(a.hasNext())
		{
			String x=a.next();
			if(x.equals("kfc"))
			{
				System.out.println("__      _____");
				System.out.println("|  | ___/ ____\\____");
				System.out.println("|  |/ /\\   __\\/ ___\\");
				System.out.println("|    <  |  | \\  \\___");
				System.out.println("|__|_ \\ |__|  \\___  >");
				System.out.println("    \\/           \\/");
			}
		}
	}
}