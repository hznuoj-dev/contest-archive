#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	int a,b,c,d,e,i;
	scanf("%d",&a);
	while(a--)
	{
		int sum=0;
		scanf("%d%d",&b,&c);
		d=b+c;
		if(d>=10000)
		{
			d=9999-(d-9999);
		}
		if(d<b)
		{
			e=d;
			d=b;
			b=e;
		}
		for(i=b;i<=d;i++)
		{
			if(i%400==0||i%4==0&&i%100!=0)
			{
				sum=sum+1;
			}
		}
		printf("%d\n",sum);
	}
 } 
