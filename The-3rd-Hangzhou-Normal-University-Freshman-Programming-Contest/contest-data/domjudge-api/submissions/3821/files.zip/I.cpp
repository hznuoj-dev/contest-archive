#include<iostream>
#include<string>
using namespace std;
int main(){
	long long a[4],sum=0,m=0;
	cin>>a[0]>>a[1]>>a[2]>>a[3];
	for(int i=0;i<4;i++){
		while(a[i]>0){
		sum=sum+a[i]%10;
		a[i]=a[i]/10;
    	}
    	if(sum==6||sum>=16){
		    m=m+1;
    	}
    	sum=0;
	}
	if(m==0){
		cout<<"Bao Bao is so Zhai....."<<endl;
	}
	else if(m==1){
		cout<<"Oh dear!!"<<endl;
	}
	else if(m==2){
		cout<<"BaoBao is good!!"<<endl;
	}
	else if(m==3){
		cout<<"Bao Bao is a SupEr man///!"<<endl;
	}
	else
	    cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;
}
