#include<cstdio>
#include<algorithm>
using namespace std;
#include<string.h>
/*struct info{
	int how;
	int num;
	int n0;
}yingbi[111]
;
bool cmp(info x, info y){
	return x.how-y.how;
}
int main (){
	int n, t, i, m, a[111], all, b[111],time=0, all0=0;
	scanf("%d%d",&n, &all);
	for(i=0;i<n;i++){
		scanf("%d",&yingbi[i].how);
	}
	for(i=0;i<n;i++){
		scanf("%d",&yingbi[i].num);
		yingbi[i].n0=yingbi[i].num;
	}
	sort(yingbi,yingbi+n, cmp);
	for(i=0;i<n;i++){
		for(int j=i;j<n;j++){
			if(all0+yingbi[j].how<all){
				all0=all0+a[j];
			}
			else {
				all0=0;
				time++;
			}
		}
		for(int k=0;k<n;k++){
			yingbi[k].num=yingbi[k].n0;
		}
	}
	printf("%d")
	return 0;
}*/
int main(){
	long long int a,b,c,d, alla=0, allb=0, allc=0, num=0, alld=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	while(a){
		alla=a%10;
		a=a/10;
	}
	if(alla>=16||alla==6)num++;
	while(b){
		allb=b%10;
		b=b/10;
	}if(allb>=16||allb==6)num++;
	while(c){
		allc=c%10;
		c=c/10;
	}if(allc>=16||allc==6)num++;
	while(d){
		alld=d%10;
		d=d/10;
	}if(alld>=16||alld==6)num++;
	if(num==0)printf("Bao Bao is so Zhai......");
	if(num==1)printf("Oh dear!!");
	if(num==2)printf("BaoBao is good!!");
	if(num==3)printf("Bao Bao is a SupEr man///!");
	if(num==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	system("pause");
}