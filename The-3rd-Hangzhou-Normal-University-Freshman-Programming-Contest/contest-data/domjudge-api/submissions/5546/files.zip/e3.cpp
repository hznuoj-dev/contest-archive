#include<stdio.h>
 int main(void)
 {
 	int a,b,c,n,i=0,y;
 	scanf("%d",&n);
 	while(n--)
 	{
 		scanf("%d%d",&a,&b);
 		if(b>=0)
 		c=a+b;
 		if(b<0)
 		c=a,a=a+b;
 		for(i=a,y=0;i<c;i++)
 		{
 			if(i%100==0&&i%400==0)
 			y++;
 			if(i%100!=0&&i%4==0)
 			y++;
		 }
		 printf("%d\n",y);
	 }
 	 return 0;
 }
