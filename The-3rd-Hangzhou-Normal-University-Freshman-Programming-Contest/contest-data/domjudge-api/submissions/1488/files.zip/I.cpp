#include "stdio.h"
int main(){
	long long int a,b,c,d;
	int t,sum=0,co=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>0){
		t=a%10;
		sum+=t;
		a/=10;
	}
	if(sum>16||sum==16||sum==6) co++;
	sum=0;
	
	while(b>0){
		t=b%10;
		sum+=t;
		b/=10;
	}
	if(sum>16||sum==16||sum==6) co++;
	sum=0;
	while(c>0){
		t=c%10;
		sum+=t;
		c/=10;
	}
	if(sum>16||sum==16||sum==6) co++;
		sum=0;
	while(d>0){
		t=d%10;
		sum+=t;
		d/=10;
	}
	if(sum>16||sum==16||sum==6) co++;
	if(co==0) printf("Bao Bao is so Zhai......");
	else if(co==1) printf("Oh dear!!");
	else if(co==2) printf("BaoBao is good!!");
	else if(co==3) printf("Bao Bao is a SupEr man///!");
	else  printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
} 
