#include<stdio.h>
int main(){
	char s[10000001];
	int t,n;
	int count=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		while(n--){
			for(int i=0;i<10000001;++i){
				scanf("%c",&s[i]);
				if(s[i]!='.'){
					count+=1;	
				}

			}
				
		}
		printf("%d",count);
	}
		
	return 0;
}
