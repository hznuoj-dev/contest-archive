#include <stdio.h>
#include <math.h>
int panduan(int x){
	int i=1,j=0;
	int a[18],m=0;
	while(pow(10,i)<x){
		if(i==1){
			a[i]=x%10;
		}
		else{
			a[i]=(x%(int)pow(10,i) - x%(int)pow(10,i-1))/pow(10,i-1);
		}
		i++;
	}
	a[i]=x/pow(10,i-1);
	for(j=1;j<i+1;j++){
		m+=a[j];
	}
	if(m>=16||m==6){
		return 1;
	}
	else{
		return 0;
	}
}
int main(){
	int a,b,c,d,m=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(panduan(a)){
		m++;
	}
	if(panduan(b)){
		m++;
	}
	if(panduan(c)){
		m++;
	}
	if(panduan(d)){
		m++;
	}
	if(m==1){
		printf("Oh dear!!");
	}
	else{
		if(m==2){
			printf("BaoBao is good!!");
		}
		else{
			if(m==3){
				printf("Bao Bao is a SupEr man///!");
			}
			else{
				if(m==4){
					printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
				}
				else{
					printf("Bao Bao is so Zhai......");
				}
			}
		}
	}
}
