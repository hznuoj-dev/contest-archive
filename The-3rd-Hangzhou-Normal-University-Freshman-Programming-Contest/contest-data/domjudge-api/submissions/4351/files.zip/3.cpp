#include <stdio.h>
#include <string.h>
int main(){
	int t, sum=0;
	scanf("%d", &t);
	while(t--){
		char a[100001];
		scanf("%s", a);
		sum+=strlen(a);
	}
	printf("%d", sum);
}






































