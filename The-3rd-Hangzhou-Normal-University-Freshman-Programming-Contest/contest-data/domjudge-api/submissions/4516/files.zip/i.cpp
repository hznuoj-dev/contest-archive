#include <stdio.h>
#include <string.h>
int main (void){
	char a[20];
	char b[20];
	char c[20];
	char d[20];
    scanf("%s %s %s %s",a,b,c,d);
    int sum1=0,sum2=0,sum3=0,sum4=0;
    int sum=0;
    
	for (int i=0;i<strlen(a);i++){
		sum1=sum1+(int)(a[i])-48;
	}
	for (int i=0;i<strlen(b);i++){
		sum2=sum2+(int)(b[i])-48;
	}
	for (int i=0;i<strlen(c);i++){
		sum3=sum3+(int)(c[i])-48;
	}
	for (int i=0;i<strlen(d);i++){
		sum4=sum4+(int)(d[i])-48;
	}
	
	if (sum1>=16 || sum1==6) sum+=1;
	if (sum2>=16 || sum2==6) sum+=1;
	if (sum3>=16 || sum3==6) sum+=1;
	if (sum4>=16 || sum4==6) sum+=1;
	
	if(sum==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	else if (sum==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else if (sum==2){
		printf("BaoBao is good!!");
	}
	else if (sum==1){
		printf("Oh dear!!");
	}
	else printf("Bao Bao is so Zhai......");
	return 0;
}
