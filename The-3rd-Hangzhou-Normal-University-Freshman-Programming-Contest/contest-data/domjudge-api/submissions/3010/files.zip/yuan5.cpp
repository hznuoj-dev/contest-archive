#include<cstdio>
#include<cstring>
#include<cmath>;
using namespace std;
char a[100001];
int main(){
	int t,i;
	double fenzi,fenmu;
	scanf("%d",&t);
	while(t--){
		scanf("%lf%lf",&fenmu, &fenzi);
		printf("[");
		for(i=1;i<=fenzi;i++)printf("#");
		for(int j=1;j<=fenmu-fenzi;j++)printf("-");
		printf("] ");
		int n=fenzi*100/fenmu;
		int a=37;
		printf("%d%c\n",n,a);
	}
}
