#include<bits/stdc++.h>
using namespace std;
int t,x,y;
void max(int a,int b);
int main()
{
	int T,a,k=0;
	cin >> T;
	while(T--){
		cin >> y >> a;
		x=y+a;
		if(x>9999){
			t=x-9999;
			x=9999-t;
		}
		max(x,y);
		for(int i=x;i<=y;i++){
			if(i%4==0 && i%100!=0 || i%400==0){
				k++;
			}
		}
		cout << k << endl;
	}
}
void max(int a,int b){
	if(x>y){
		t=y;
		y=x;
		x=t;
	}
}
