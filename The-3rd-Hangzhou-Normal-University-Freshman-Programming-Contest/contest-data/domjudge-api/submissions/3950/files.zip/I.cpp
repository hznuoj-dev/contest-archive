#include<iostream>
#include<string>
using namespace std;
int main(){
	string a[4];
	int sum=0,m=0,s;
	cin>>a[0]>>a[1]>>a[2]>>a[3];
	for(int i=0;i<4;i++){
		s=a[i].size();
		for(int j=0;j<s;j++){
		sum=sum+(int)a[i][j];
    	}
    	if(sum==6||sum>=16){
		    m=m+1;
    	}
    	sum=0;
	}
	if(m==0){
		cout<<"Bao Bao is so Zhai....."<<endl;
	}
	else if(m==1){
		cout<<"Oh dear!!"<<endl;
	}
	else if(m==2){
		cout<<"BaoBao is good!!"<<endl;
	}
	else if(m==3){
		cout<<"Bao Bao is a SupEr man///!"<<endl;
	}
	else
	    cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;
}
