#include<stdio.h>
#include<math.h>
int main(){
	int T,i;
	long long n,m;
	double sum,num;
	scanf("%d",&T);
	while(T--){
		scanf("%lld %lld",&n,&m);
		sum=(double)m/(double)n;
		num=sum*100;
		printf("[");
		for(i=0;i<m;i++)
		printf("#");
		for(i=m;i<n;i++){
			printf("-");
		}
		if(i==n) 
		printf("]");
		printf(" %.f%%",num);
		if(T>0)
		printf("\n");
	}
}
