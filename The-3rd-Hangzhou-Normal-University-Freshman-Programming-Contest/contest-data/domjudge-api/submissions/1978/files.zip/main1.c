#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
/*
int main(int argc, char *argv[]) {
	int T;
	scanf("%d",&T);
	while(T--)
	{
		long long y,a,b;
		int x=0;
		scanf("%lld %lld",&y,&a);
		b=a+y;
		if(b>9999)
		{
			b=y+y+a-9999;
		}
		int i;
		for(i=y;i<=b;i++)
		{
			if(i/4.0==0&&i/100!=0)
			{
				x++;
			}
			if(i/400==0)
			x++;
		}
		printf("%d",x);
	}
	return 0;
}
*/
int main()
{
	char c[4];
	scanf("%s",c);
	//printf(" __     _____\n| | ___/ ____\\____ \n| |/ /\\ __\\/ ___\\\n|   < | | \\ \\___\n|__|_ \\ |__| \\___ >\n     \\/         \\/");
	printf("__      _____\n");
	printf("| | ___/ ____\\____\n");
	printf("| |/ /\\   __\\/ ___\\\n");
	printf("|   < |  | \\   \\___\n");
	printf("|__|_ \\ |__| \\___  >\n");
	printf("     \\/          \\/");
	







	
	





	return 0;
}
