#include<bits/stdc++.h>
using namespace std;

int t;
int a, b, c;

int main ()
{
	scanf ("%d", &t);
	while (t--)
	{
		scanf ("%d%d", &a, &b);
		c = 1.0 * b / a * 100;
		printf ("[");
		for (int i = 1; i <= b; i++) printf ("#");
		for (int i = 1; i <= a - b; i++) printf ("-");
		printf ("] ");
		printf ("%d%\n", c);
	}
	
	
	return 0;
	
}
