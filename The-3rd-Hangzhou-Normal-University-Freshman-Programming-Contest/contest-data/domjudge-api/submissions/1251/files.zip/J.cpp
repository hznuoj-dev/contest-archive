#include<bits/stdc++.h>
using namespace std;

int t;
int n;
char s[10000001];
int ans;
bool b[1001];

int main ()
{
	scanf ("%d", &t);
	while (t--)
	{
		ans = 0;
		scanf ("%d", &n);
		while (n--)
		{
			memset (b, 0, sizeof (b));
			scanf ("%s", s);
			int l = strlen (s);
			for (int i = 0; i < l; i++)
			{
				b[s[i]] = 1;
			}
			for (int i = 0; i <= 256; i++)
			{
				if (i != '.' && b[i]) ans++;
			}
		}
		printf ("%d\n", ans);
	}
	
	
	return 0;
	
}
