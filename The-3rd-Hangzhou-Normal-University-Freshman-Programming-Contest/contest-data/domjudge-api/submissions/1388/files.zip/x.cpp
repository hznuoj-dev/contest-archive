#include<stdio.h>
#include<math.h>
#include<string.h>
int f(int a,int b){
	int i,t=0;
	for(i=a;i<=b;i++){
		if((i%4==0&&i%100!=0)||i%400==0)
			t++;
	}
	return t;
}

int main(){
	int t,T,y,x,a,b;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&y,&x);
		a=y;
		b=y+x;
		if(b>9999)
			b=9999-(b-9999);
		if(a>b)
			t=a,a=b,b=t;
		printf("%d\n",f(a,b));
	}
	return 0;
}