#pragma warning (disable:4996)
#include<stdio.h>
#include<string.h>
int main(void) {
	int a, b, c, i, j,m;
	char w[1000000];
	int ww[127] = {0};
	scanf("%d", &a);
	while (a--) {
		scanf("%d", &b);
		c = 0;
		getchar();
		while (b--) {
			gets(w);
			j = strlen(w);
			for (i = 0; i < j; i++) {
				if (w[i] != '.') {
					m = w[i];
					ww[m] = 1;
				}
			}
			for (i = 1; i <= 126; i++) {
				c += ww[i];
				ww[i] = 0;
			}
		}
		printf("%d\n", c);
	}
	return 0;
}