#include <bits/stdc++.h>

using namespace std;

bool is(int x) {
    if (x % 4)return 0;
    if (x % 100 == 0) {
        if (x % 400 == 0)return 1;
        return 0;
    }
    return 1;
}

int main() {
    int T, x, y, ans;

    cin >> T;
    while (T--) {
        ans = 0;
        cin >> x >> y;
        if (x + y > 9999) {
            y = 9999 * 2 - x - y;
        } else y = x + y;
        if (x > y)swap(x, y);
        for (int i = x; i <= y; i++)ans += is(i);
        cout << ans << endl;
    }
    return 0;
}
