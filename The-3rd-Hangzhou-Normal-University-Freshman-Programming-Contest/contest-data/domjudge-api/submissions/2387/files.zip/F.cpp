#include<iostream>
#include<vector>
#include<algorithm>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
const int maxn=1e5+10;
int ans;
int a[maxn],b[maxn];
int vis[maxn];
//vector<int>vec;
int n,m;
void dfs(int x,int sum){
	if(sum>m)return;
	if(x>n)return;
	if(!vis[sum]&&sum){
		vis[sum]=1;
//		vec.push_back(sum);
		ans++;
	}
	if(b[x]){
		b[x]--;
		dfs(x,sum+a[x]);
		b[x]++;
	}
	dfs(x+1,sum);
}
int main(){
	fcio;
	while(cin>>n>>m){
		ans=0;
		for(int i=1;i<=n;++i)cin>>a[i];
		for(int i=1;i<=n;++i)cin>>b[i]; 
		dfs(1,0);
		cout<<ans<<endl;
//		sort(vec.begin(),vec.end());
//		for(int i=0;i<vec.size();++i){
//			cout<<vec[i]<<" ";
//		}
//		cout<<endl;
	}
}

