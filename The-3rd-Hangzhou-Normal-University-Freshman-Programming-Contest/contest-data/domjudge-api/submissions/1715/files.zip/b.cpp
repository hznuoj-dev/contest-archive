#include <stdio.h>
int main(){
	int t,y,a,x,z,i,max,min;
	scanf("%d",&t);
	while(t--){
		int s=0;
		scanf("%d%d",&y,&a);
		x=y+a;
		if(x>9999){
			z=9999-(x-9999);
		}
		else{
		z=x;
		} 
		    
		    if(z>y){
		    	max=z;
		    	min=y;
			}
			else{
				max=y;
				min=z;
			}
		for(i=min;i<=max;i++){
			if((i%4==0&&i%100!=0)||i%400==0){
		       s=s+1;
	        }
		} 
		printf("%d\n",s);
	}
	return 0;
} 
