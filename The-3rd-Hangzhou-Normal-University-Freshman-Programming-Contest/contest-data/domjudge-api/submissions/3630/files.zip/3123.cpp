#include<bits/stdc++.h>
using namespace std;
int main()
{   int t,a,b,c,d,flag,i,j,k;
    int x[1010],len;
    scanf("%d",&t);
    while(t--)
    {
        cin>>a>>b;len=0;
        while(b--)
        {
            cin>>c>>d;flag=0;
            for(i=0;i<len;i++)
            {
                if(x[i]==d) {j=i;flag=1;break;}
            }

            if(flag==1)
            {   k=j;
              for(i=j-1;i>=0;i--)
              {
                if(x[i]>c) {k=i;break;}
              }
                for(i=len-1;i>=k;i--)
                    x[i+1]=x[i];
                 x[k]=c;
                 len++;
            }
            else
            {   if(x[len-1]!=c&&len>0)
              {
                x[len]=c;x[len+1]=d;
                len+=2;
               }
                else if(x[len-1]==c&&len>0) {x[len]=d;len++;}
                else if(len==0) {x[0]=c;x[1]=d;len+=2;}

            }

        }
        for(i=0;i<len;i++)
        {
            if(i==0) printf("%d",x[i]);
            else printf(" %d",x[i]);
        }
        cout<<endl;
    }
    return 0;
}
