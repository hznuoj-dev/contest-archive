#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
    int A, B, C, D;
    int i = 0, j = 1, f, c = 0;
    scanf("%d%d%d%d", &A, &B, &C, &D);
    j = A;
    while (j)
    {
        f = j % 10;
        c += f;
        j = j / 10;

        i++;
    }
    int q, e = 0, r = 1;
    r = B;
    while (r)
    {
        q = r % 10;
        e += q;
        r = r / 10;

        i++;
    }
    int z, v = 0, b = 1;
    b = C;
    while (b)
    {
        z = b % 10;
        v += z;
        b = b / 10;

        i++;
    }
    int u, o = 1, p = 0;
    o = D;
    while (o)
    {
        u = o % 10;
        p += u;
        o = o / 10;

        i++;
    }
    if ((c >= 16 || c == 6) && (e >= 16 || e == 6) && (v >= 16 || v == 6) && (p >= 16 || p == 6))
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    if ((c < 16 && c != 6) && (e < 16 && e != 6) && (v < 16 & v != 6) && (p < 16 && p != 6))
        printf("Bao Bao is so Zhai......");
    if ((c < 16 && c != 6) && (e >= 16 || e == 6) && (v >= 16 || v == 6) && (p >= 16 || p == 6))
        printf("Oh dear!!");
    else if ((c >= 16 || c == 6) && (e < 16 && e != 6) && (v >= 16 || v == 6) && (p >= 16 || p == 6))
            printf("Oh dear!!");
    else if ((c >= 16 || c == 6) && (e >= 16 || e == 6) && (v < 16 && v != 6) && (p >= 16 || p == 6))
            printf("Oh dear!!");
    else if ((c >= 16 || c == 6) && (e >= 16 || e == 6) && (v >= 16 || v == 6) && (p < 16 & p != 6))
            printf("Oh dear!!");
    if ((c >= 16 || c == 6) && (e < 16 & e != 6) && (v < 16 & v != 6) && (p < 16 && p != 6))
        printf("Bao Bao is a SupEr man///");
    else if ((c < 16 && c != 6) && (e >= 16 || e == 6) && (v < 16 && v != 6) && (p < 16 && p != 6))
        printf("Bao Bao is a SupEr man///");
    else if ((c < 16 && c != 6) && (e < 16 && e != 6) && (v >= 16 || v == 6) && (p < 16 && p != 6))
        printf("Bao Bao is a SupEr man///");
    else if ((c < 16 && c != 6) && (e < 16 && e != 6) && (v < 16 && v != 6) && (p >= 16 || p == 6))
        printf("Bao Bao is a SupEr man///");
    if ((c < 16 && c != 6) && (e < 16 && e != 6) && (v >= 16 || v == 6) && (p >= 16 || p == 6))
        printf("BaoBao is good!!");
    else if ((c < 16 && c != 6) && (e >= 16 || e == 6) && (v < 16 & v != 6) && (p >= 16 || p == 6))
        printf("BaoBao is good!!");
    else if ((c < 16 && c != 6) && (e >= 16 || e == 6) && (v >= 16 || v == 6) && (p < 16 && p != 6))
        printf("BaoBao is good!!");
    else if ((c >= 16 || c == 6) && (e < 16 && e != 6) && (v < 16 && v != 6) && (p >= 16 || p == 6))
        printf("BaoBao is good!!");\
    else if ((c >= 16 || c == 6) && (e < 16 && e != 6) && (v >= 16 || v == 6) && (p < 16 && p != 6))
        printf("BaoBao is good!!");
    else if ((c >= 16 || c == 6) && (e >= 16 || e == 6) && (v < 16 && v != 6) && (p < 16 && p != 6))
        printf("BaoBao is good!!");
    return 0;
}