#include<stdio.h>
#include<string.h>
int main(void)
{
	char s[5]={0};
	scanf("%s",s);
	if(strcmp(s,"kfc")==0)
	{
		printf(" __       _____\n");
		printf("|  |  ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/\n");	
	}
	
	return 0;
}
