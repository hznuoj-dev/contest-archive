//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 1010;

map<char, int>mp;

int main() {
	
#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);
	
	int t, n, sum = 0, cnt = 0;
	string s;
	cin >> t;
	while (t--){
		mp.clear();
		sum = 0;
		cin >> n;
		for (int i = 0; i < n; ++i){
			mp.clear();
			cin >> s;
			cnt = 0;
			for (int j = 0; j < s.length(); ++j){
				if (s[j] != '.'){
					if (!mp.count(s[j])){
						cnt++;
						mp[s[j]] = 1;
					}
				}
			}
			sum += cnt;
		}
		printf("%d\n", sum);
	}
	

	return 0;
}
