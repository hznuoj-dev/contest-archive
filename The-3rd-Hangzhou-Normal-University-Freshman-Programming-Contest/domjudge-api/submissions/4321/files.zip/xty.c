#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main()
{
    int n, m,x,i,j=0,sum=0,sum1=0,s=0;
    char a[10000],b,c[100];
    scanf("%d", &n);
    while (n--)
    {
        scanf("%d", &m);
        while (m--)
        {
            scanf("%s", a);
            scanf("%c", &b);
            x = strlen(a);
            for (i = 0;i < x;++i)
            {
                if (a[i] != '.')
                {
                    c[0] = a[i];
                    sum += 1;
                    break;
                }
            }
            for(i+=1;i<x;++i)
            {
                if(a[i]!='.')
                {
                    for (j = 0;j < sum;++j)
                    {
                        if (a[i] == c[j])
                        {
                            break;
                        }
                        else if (a[i] != c[j])
                        {
                            s += 1;
                        }
                    }
                    if (s == sum)
                    {
                        c[sum] = a[i];
                        sum += 1;
                        s = 0;
                    }
                }
            }
            sum1 += sum;
            sum = j=0;
        }
        printf("%d\n", sum1);
        j = sum = sum1 = 0;
    }
    return 0;
}