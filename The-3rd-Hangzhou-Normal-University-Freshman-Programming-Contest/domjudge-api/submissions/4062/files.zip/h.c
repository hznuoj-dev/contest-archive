#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d%d",&n,&m);
		double i;
		i=m*100/n;
		printf("[");
		for(int j=1;j<=m;j++){
			printf("#");
		}
		for(int j=1;j<=n-m;j++){
			printf("-");
		}
		printf("]");
		printf("%.0lf%%\n",i);
	}
return 0;
}
