#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void)
{
	long long a,b,c,d,i,j,flag=0,x,sum;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	sum=0;
	while(a!=0)
	{
		sum=sum+a%10;
		a=a/10;
	}
	if(sum>=16sum==6)
	{
		flag=flag+1;
	}
	sum=0;
	while(b!=0)
	{
		sum=sum+b%10;
		b=b/10;
	}
	if(sum>=16sum==6)
	{
		flag=flag+1;
	}
	sum=0;
	while(c!=0)
	{
		sum=sum+c%10;
		c=c/10;
	}
	if(sum>=16sum==6)
	{
		flag=flag+1;
	}
	sum=0;
	while(d!=0)
	{
		sum=sum+d%10;
		d=d/10;
	}
	if(sum>=16||sum==6)
	{
		flag=flag+1;
	}
	if(flag==0)
	{
		printf("Bao Bao is so Zhai......");
	}
	if(flag==1)
	{
		printf("Oh dear!!");
	}
	if(flag==2)
	{
		printf("BaoBao is good!!");
	}
	if(flag==3)
	{
		printf("Bao Bao is a SupEr man///!");
	}
	if(flag==4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	return 0;
}