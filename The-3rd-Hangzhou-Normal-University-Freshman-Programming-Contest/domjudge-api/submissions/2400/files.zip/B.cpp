#include<bits/stdc++.h>
using namespace std;
int isleap(int min,int max){
	int cnt=0;
	for(int i=min;i<=max;i++){
		if(i%400==0||(i%4==0&&i%100!=0))cnt++;
	}
	return cnt;
}
int main(){
	int t;
	int min,max;
	int year,y;
		cin>>t;
	while(t--){
		cin>>year>>y;
		min=year;
		max=year+y;
		if(min>max)swap(min,max);
		if(max>9999)max=9999*2-max; 
		cout<<isleap(min,max)<<endl;
	}
	
	return 0;
} 
