#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 



int main(){
	int a,i,n=0,k;
	for(i=1;i<=4;i++){
		k=0;
		scanf("%d",&a);
		while(a>0){
			k+=(a%10),a/=10;
		}
		if(k>=16||k==6)
		n++;
	}
	switch (n){
		case 1:
			printf("Oh dear!!");
			break;
		case 2:
			printf("BaoBao is good!!");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			break;
		case 0:
			printf("Bao Bao is so Zhai......");
			break;
		
	}
} 

