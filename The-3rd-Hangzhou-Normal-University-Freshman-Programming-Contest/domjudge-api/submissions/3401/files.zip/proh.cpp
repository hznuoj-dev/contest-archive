#include <stdio.h>
int main()
{
	int n,i,x,y;
	double p;
	scanf("%d",&n);
	while(n--)
	{
		scanf("%d%d",&x,&y);
		char a[x+2];
		a[0]='[';
		a[x+1]=']';
		a[x+2]='\0';
		for(i=1;i<=x;i++)
		{
			if(i<=y)
			a[i]='#';
			else
			a[i]='-';
		}
		if(x!=0)
		p=100.0*y/x;
		else
		p=0;
		printf("%s %.0lf%%\n",a,p);
	}
	return 0;
}
