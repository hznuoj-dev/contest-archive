#include<bits/stdc++.h>
using namespace std;
int main(){
	long long a[5];
	int cnt=0;
	for(int i=0;i<4;i++){
		cin>>a[i];
		int temp=0;
		while(a[i]>0){
			temp+=a[i]%10;
			a[i]/=10;
		}
		if(temp==6||temp>=16)cnt++; 
	}
	if(cnt==0){
		printf("Bao Bao is so Zhai......\n");
	}
	else if(cnt==1){
		printf("Oh dear!!\n");
	}
	else if(cnt==2){
		printf("BaoBao is good!!\n");
	}
	else if(cnt==3){
		printf("Bao Bao is a SupEr man///!\n");
	}
	else printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}
