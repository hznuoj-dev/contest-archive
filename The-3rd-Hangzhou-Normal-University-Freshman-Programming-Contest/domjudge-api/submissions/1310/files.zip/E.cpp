#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int len;
	char a[10001];
	scanf("%s",a);
	len=strlen(a);
	if(len==3 &&a[0]=='k'&&a[1]=='f'&&a[2]=='c'){
		printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/\n");
	}
}
