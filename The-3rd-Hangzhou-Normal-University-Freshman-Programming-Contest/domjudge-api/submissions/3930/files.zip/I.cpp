#include<bits/stdc++.h>
using namespace std;

int main()
{
	int cnt=0;
	string s;
	getline(cin,s);
	int num=0,shu;
	for(int i=0;i<s.length();i++)
	{
		if(s[i]>='0' && s[i]<='9')
		{
			shu=s[i]-'0';
			num=num+shu;
		}
		if(s[i]==' ') {
			if(num>=16 || num==6) cnt ++;
			num=0;
		}
	}
	if(cnt==0) cout<<"Bao Bao is so Zhai......"<<endl;
	else if(cnt==1) cout<<"Oh dear!!"<<endl;
	else if(cnt==2) cout<<"BaoBao is good!!"<<endl;
	else if(cnt==3) cout<<"Bao Bao is a SupEr man///!"<<endl;
	else if(cnt==4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;
	
	return 0;
}
