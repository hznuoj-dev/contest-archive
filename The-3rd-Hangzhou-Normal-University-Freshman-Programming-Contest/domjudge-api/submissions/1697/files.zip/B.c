#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int t,y,a,x,temp,i,s=0;
	scanf("%d",&t);
	while(t--){
		s=0;
		scanf("%d %d",&y,&a);
		if(y+a>9999){
			a=-(y+a-9999);
			x=9999+a;
		}
		else{
			x=y+a;
		}
		if(x>y){
			temp=x;x=y;y=temp;
		}
		for(i=x;i<=y;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				s++;
			}
		}
		printf("%d\n",s);
	}
}
