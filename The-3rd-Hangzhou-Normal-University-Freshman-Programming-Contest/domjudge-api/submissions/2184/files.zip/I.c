#include<stdio.h>
int sum(int n) {
	int m,cnt=0;
	while(n>0) {
		m=n%10;
		cnt+=m;
		n=n/10;
	}
	return cnt;
}
int main(void) {
	int a[4],b=0;
	for(int i=0; i<4; i++) {
		scanf("%d",&a[i]);
		if(sum(a[i])>=16||sum(a[i])==6)
		b+=1;
	}
	if(b==0) 
	printf("Bao Bao is so Zhai......");
	if(b==1)
	printf("Oh dear!!");
	if(b==2)
	printf("BaoBao is good!!");
	if(b==3)  
	printf("Bao Bao is a SupEr man///!");
	if(b==4) 
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!"); 
	return 0;
}
