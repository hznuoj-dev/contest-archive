#include<stdio.h>
#include<string.h>
int main(){
	int s=0;
	for(int i=0;i<=3;i++){
    char num[18],*p=num;
    int sum=0;
    scanf("%s",num);
    while(*p)sum+=(*p++-'0');
    if(sum>=16||sum==6)s++;
}
if(s==1)printf("Oh dear!!");
if(s==2)printf("BaoBao is good!!");
if(s==3)printf("Bao Bao is a SupEr man///!");
if(s==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
if(s==0) printf("��Bao Bao is so Zhai......");
return 0;
}
