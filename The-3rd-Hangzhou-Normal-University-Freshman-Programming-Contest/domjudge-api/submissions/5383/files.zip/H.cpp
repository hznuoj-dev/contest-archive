#include <stdio.h>//behijd
#include <string.h>
int main (){
	int t,n,m;
	if(scanf("%d",&t)!=1){
	}
	while(t--){
		if(scanf("%d %d",&n,&m)!=1){
		printf("[");
		for(int i=0;i<m;i++){
			printf("#");
		}
		for(int j=0;j<n-m;j++){
			printf("_");
		}
		printf("] ");
		double e=(double)m/n;
		printf("%.lf",e*100);
		printf("%%");
		printf("\n");
	}
	}

	return 0;
}
