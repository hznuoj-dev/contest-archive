#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;
int  a,b,c[1005],l,mid,sum=0,n,m,t=0,x,w,v,y,j;
struct r
{
    int u, v, t;
};
r p[1005];
int main()
{
    cin>>l;
    for(int i=1; i<=l; i++)
    {
        cin>>n>>m;
        sum=0;
        t=0;
        for(j=1;j<=n;j++){
        	 c[j]=0;
        	 sum=sum+j;
		}
        for(int j=1; j<=m; j++)
        {
            cin>>p[j].u>>p[j].v;
            c[p[j].u]++;
        }
        for(int j=1; j<=n; j++)
            if(p[j].v>0)
                c[p[j].u]+=c[p[j].v];
        for(int j=n; j>=0; j--){
        	
            for(int k=1; k<=n; k++)
                if(c[k]==j){
                	if(t==n-1)
					break;
                    cout<<k<<" ";
					t++;
					sum-=k;	                	
				}
			}
		if(sum!=0)
		cout<<sum<<'\n';
    }
    return 0;
}

