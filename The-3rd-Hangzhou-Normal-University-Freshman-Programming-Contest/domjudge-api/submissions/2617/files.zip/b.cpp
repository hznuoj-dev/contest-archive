#include<stdio.h>
int main()
{
	int r,a,b,c,d,count=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
		r=0;
		while(a>0)
		{
			r+=a%10;
			a/=10;
		}
		if((r>=16)||(r==6))
		{
			count++;
		}
		r=0;
		while(b>0)
		{
			r+=b%10;
			b/=10;
		}
		if((r>=16)||(r==6))
		{
			count++;
		}
		r=0;
		while(c>0)
		{
			r+=c%10;
			c/=10;
		}
		if((r>=16)||(r==6))
		{
			count++;
		}
		r=0;
		while(d>0)
		{
			r+=d%10;
			d/=10;
		}
		if((r>=16)||(r==6))
		{
			count++;
		}
		r=count;
		if(r==0)
		printf("Bao Bao is so Zhai......\n");
		if(r==1)
		printf("Oh dear!!\n");
		if(r==2)
		printf("BaoBao is good!!\n");
		if(r==3)
		printf("Bao Bao is a SupEr man///!\n");
		if(r==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
} 
