#include<stdio.h>

int main()
{
	int n,m,i,j,x,y,z,count=0;
	char a[n],b[n];//����� ���� 
	scanf("%d %d",&n,&m);//Ӳ��������������ļ۸�
	gets(a);
	gets(b);
//for (i=0;i<n;i++){
//		scanf("%d ",&a[i]);
//	} 
//	for (i=0;i<n;i++){
//		scanf("%d",&b[i]);
//	} 
//	for (i=0;i<n;i++){
//		printf("%d %d\t",a[i],b[i]);
//	} 
//	for (i=1;i<=m;i++){
//		for (x=0;x<=i/a[0][0];x++){
//			for (y=0;j<=i/a[0][1];y++){
//				for (z=0;z<=i/a[0][2];z++){
//					if (x*a[0][0]+y*a[0][1]+z*a[0][2]==i){
//						if (x<=a[1][0] && y<=a[1][1] &&z<=a[1][2]){
//							count++;
//							printf("%d %d %d",x,y,z);
//						}
//					}
//				}
//			}
//		}
//	}
	printf("%d",count);
	return 0;
 } 
