#include<string.h>
#include<stdio.h>
int main()
{
	int t,n,m,i;
	double num=0;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		num=(double)m/n*100;
		printf("[");
		for(i=1;i<=m;++i)
			printf("#");
		for(i=m+1;i<=n;++i)
			printf("-");
		printf("]%d%%\n",(int)num);
	}
}