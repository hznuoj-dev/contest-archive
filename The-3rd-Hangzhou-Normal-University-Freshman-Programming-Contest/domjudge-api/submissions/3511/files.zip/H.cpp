#include<iostream>
#include<string>
using namespace std;
int main(){
	int t,a,b;
	cin>>t;
	while(t--){
		cin>>a>>b;
		cout<<"[";
		for(int i=0;i<a;i++){
			if(i<b)
			cout<<"#";
			else
			cout<<"-";
		}
		cout<<"] ";
		cout<<b*100/a<<"%"<<endl;
	}
}
