#include<stdio.h>
#include<process.h>
int main(){
int T,Y,A;

scanf("%d",&T);
while(T--)
{
	int sun=0;
	int a,b,i,c;
	scanf("%d%d",&Y,&A);
	a=Y+A;
	if(a>9999)
		{
			b=a-9999;
			a=9999-b;
	}
	if(a<Y)
	{
	c=a;
	a=Y;
	Y=c;
	}
	for(i=Y;i<=a;i++)
	{
		if(i%4==0&&i%100!=0||i%400==0)
		{sun++;
		}
	}
	printf("%d\n",sun);
}

system("pause");
return 0;
}