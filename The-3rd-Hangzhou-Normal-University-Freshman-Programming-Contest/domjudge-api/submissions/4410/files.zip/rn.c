#include<stdio.h>
int main(){
	int t,y,n,sum;
	scanf("%d",&t);
	int s[t-1];
	int i,j;
	for(i=0;i<t;i++){
		scanf("%d %d",&y,&n);
		sum=y+n;
		s[i]=0;
		if(n>=0&&sum<10000){
			for(j=y;j<=sum;j++){
				if((j%4==0&&j%100!=0)||(j%400==0)){
					s[i]++;
				}
			}
		}
		if(sum>=10000){
			sum=y-(sum-9999);
			for(j=sum;j<=y;j++){
				if((j%4==0&&j%100!=0)||(j%400==0)){
					s[i]++;
				}
			}
		}
}
for(i=0;i<t;i++){
	printf("%d\n",s[i]);
}
return 0;
}
