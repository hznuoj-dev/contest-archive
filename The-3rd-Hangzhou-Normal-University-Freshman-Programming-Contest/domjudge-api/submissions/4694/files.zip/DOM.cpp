#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int n,m,i,j;
int a[150],b[150];
int c[500],s = 0;
int flag[100005]={0};
int ans = 0;

int su(int x)//判断是否为素数
{
    int i;
    if(x==0||x==1) return 0;
    for(i=2;i*i<=x;i++)
    {
        if(x%i==0) return 0;
    }
    return 1;
}

int digit(const void *_a,const void *_b){
    int *a = (int*)_a;
    int *b = (int*)_b;
    return *a-*b;
}

void dfs(int i,int sum,int t){
    
    if(i==s){
        if(flag[sum]==0){
            flag[sum] = 1;
            if(sum<=m&&sum>=1){
                //cout << "sum = "<< sum << endl;
                ans ++;
            }
        }
        return;
    }
    dfs(i+1,sum+c[i],t+1);
    dfs(i+1,sum,t);
}
int main(){
    
    cin >> n >> m;
    for(int i =0;i<n;i++)
    cin >> a[i];
    
    qsort(a,n,sizeof(a[0]),digit);
    for(int i=0;i<n;i++){
    cin >> b[i];
        s += b[i];
    }
    int cnt = 0;
    for(i =0;i<n;i++){
        for(j=0;j<b[i];j++)
        c[cnt++] = a[i];
    }
    
   for(int i =0;i<s;i++)
   //cout << c[i] << endl;
    dfs(0,0,0);
    cout << ans << endl;
    return 0;
}


