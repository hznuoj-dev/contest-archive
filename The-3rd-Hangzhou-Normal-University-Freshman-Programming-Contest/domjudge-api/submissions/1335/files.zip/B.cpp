#include<stdio.h>
int main(void){
	int T,i,y,a,t,x,sum;
	scanf("%d",&T);
	while(T--){
		x=0;
		scanf("%d%d",&y,&a);
		sum=y+a;
		if(sum>9999){
			sum=9999-(sum-9999);
		}
		if(y>sum){
			t=y;
			y=sum;
			sum=t;
		} 
		for(i=y;i<=sum;i++){
			if((i%4==0 && i%100!=0)||(i%100==0 && i%400==0)){
				x=x+1;
			}
		}
		printf("%d\n",x);
	}
	return 0;
}
