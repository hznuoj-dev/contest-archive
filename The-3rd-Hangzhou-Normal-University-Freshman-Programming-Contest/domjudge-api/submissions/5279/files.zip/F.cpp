#include<iostream>
#include<string>
using namespace std;
int main(){
	int t,m,n=0,a[101],b[101],c[100001]={0};
	cin>>t>>m;
	int sum=0;
	for(int i=0;i<2;i++){
		cin>>a[i];
		c[a[i]]=1;
	}
	for(int j=0;j<t;j++){
		cin>>b[j];
		n+=b[j];
		sum=sum+b[j]*a[j];
	}
	cout<<sum<<endl;
}
