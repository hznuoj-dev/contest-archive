#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+100;
const int INF=0x3f3f3f3f;
bool vis[500];
char s[N];
int main(){
	int T; scanf("%d",&T);
	while(T--){
		int ans=0;
		int n; scanf("%d",&n);
		while(n--){
			memset(vis,false,sizeof vis);
			scanf("%s",s);
			for(int i=0;i<strlen(s);++i){
				if(s[i]!='.'&&!vis[s[i]]){
					vis[s[i]]=true;
					ans++;
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
