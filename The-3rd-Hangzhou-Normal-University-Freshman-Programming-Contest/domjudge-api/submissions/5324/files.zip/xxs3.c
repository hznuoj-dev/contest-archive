#include<stdio.h>
int main()
{
	int t, n, m, k;
	double jindu;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d%d", &n, &m);
		jindu = (m * 1.0 / n ) * 100;
		printf("[");
		k = m;
		while (m--)
		{
			printf("#");
		}
		if (k != n)
		{
			while (n--)
			{
				printf("-");
			}
		}
		printf("]");
		printf("%.0lf%%\n", jindu);
		
		
	}
}