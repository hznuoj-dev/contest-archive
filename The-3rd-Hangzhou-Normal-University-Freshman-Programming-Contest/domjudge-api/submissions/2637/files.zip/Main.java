package ft;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        Scanner x=new Scanner(System.in);
		while(x.hasNext())
		{
			String g[]= {"Bao Bao is so Zhai......","Oh dear!!","BaoBao is good!!","Bao Bao is a SupEr man///!","Oh my God!!!!!!!!!!!!!!!!!!!!!"};
			String s[]=new String[4];
			for(int i=0;i<s.length;i++)
			{
				s[i]=x.next();
			}
			int a=0;
			String m="";
			int b=0;
			
			for(int i=0;i<s.length;i++)
			{
				m=s[i];
				a=0;
				int c=0;
				while(c<m.length())
				{
					String v=m.substring(c, c+1);
					int r=Integer.parseInt(v);
					a=a+r;
					c=c+1;
				}
				if(a>=16 || a==6)
				{
					b=b+1;
				}
			}
			System.out.println(g[b]);
		}

	}

}
