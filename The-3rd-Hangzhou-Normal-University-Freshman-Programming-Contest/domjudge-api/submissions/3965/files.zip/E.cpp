#include<stdio.h>
int main(void) {
	char a;
	scanf("%c", &a);
	if (a = 'kfc') {
		printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/\n");
	}
	else
	 return 0;
}
