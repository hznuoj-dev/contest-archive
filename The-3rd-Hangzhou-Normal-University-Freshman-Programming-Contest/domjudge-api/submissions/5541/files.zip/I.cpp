#include<stdio.h>
#include<string.h>
int num[500];
int main()
{
	int t;
	int n;
	int count;
	char x;
	int s;
	
	scanf("%d", &t);
	for(int i = 1; i <= t; i++){
		count = 0;
		scanf("%d", &n);
		getchar();
		for(int j = 1; j <= n; j++){
			memset(num, 0, 500);
			for(int o = 1;; o++){
				scanf("%c", &x);
				if(x == '\n') break;
				s = (int)x;
				if(num[s] == 0 && x != '.'){
					count++;
					num[s]++;
				}
			}
		}
		printf("%d\n", count);
	}
	return 0;
}
