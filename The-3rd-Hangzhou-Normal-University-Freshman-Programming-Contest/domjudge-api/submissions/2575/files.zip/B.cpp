#include<bits/stdc++.h>
using namespace std;
int main()
{
	char k,f,c;
	scanf("%c%c%c",&k,&f,&c);
	printf(" __      _____       ");
	printf("\n");
	printf("|  | ___/ ____\\____  ");
	printf("\n");
	printf("|  |/ /\\   __\\/ ___ \\");
	printf("\n");
	printf("|    <  |  | \\  \\___ ");
	printf("\n");
	printf("|__|_ \\ |__|  \\___  >");
	printf("\n");
	printf("     \\/           \\/ ");
	printf("\n");
	return 0;
}
