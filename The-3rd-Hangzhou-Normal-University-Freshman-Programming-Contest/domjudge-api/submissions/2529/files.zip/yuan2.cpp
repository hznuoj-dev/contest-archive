#include<cstdio>
#include<cstring>
#include<cmath>;
char a[100001];
int main(){
	int year, n, m, year1, year2, month, day, d;
	scanf("%d",&n);
	while(n--){
		m=0;
		scanf("%d%d",&year1,&year2 );
		year2=year1+year2;
		if(year1>year2){
			int z=year2;
			year2=year1;
			year1=z;
		}
		if(year2>9998)year2=9998;
		for(int i=year1;i<=year2;i++){
			if((i%4==0&&i%100!=0)||(i%100==0&&i%400==0))m++;
		}
		printf("%d\n",m);
	}
}
