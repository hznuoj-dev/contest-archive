#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int i,j,x,t,s,n,tmp,flag;char a[99][9999],b[999];
	scanf("%d",&t);
	while(t--){
		s=0;tmp=0;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%s",a[i]);
		}
		for(i=0;i<n;i++){
			tmp=0;b[999]="";flag=1;
			for(j=0;j<strlen(a[i]);j++){
				if(a[i][j]!='.'){
					for(x=0;x<tmp;x++){
						if(a[i][j]==b[x]){
							flag=0;
						}
					}
					if(flag==1){
						b[tmp]=a[i][j];tmp++;s++;
					}
				}
			}
		}
		printf("%d\n",s);
	}
}
