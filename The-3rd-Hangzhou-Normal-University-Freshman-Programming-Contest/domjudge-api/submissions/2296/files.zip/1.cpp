#include<stdio.h>
#include<math.h>
#include<string.h>
int main(void){
	int i,b[100001];
	for (i=1;i<=10000;i++){
		if ((i%4==0&&i%100!=0)||i%400==0){
			b[i]=1;
		}
	}
	int t;
	scanf("%d",&t);
	while(t--){
		long long y,a,x,sum=0,k;
		scanf("%lld %lld",&y,&a);
		if (y+a>9999) x=19998-a-y;
		else x=y+a;
		if (x<y){
			k=x;x=y;y=k;
		}
		for (i=y;i<=x;i++){
			if (b[i]==1) sum++;
		}
		printf("%lld\n",sum);	
	} 
	
	
	
	return 0;
}


  
