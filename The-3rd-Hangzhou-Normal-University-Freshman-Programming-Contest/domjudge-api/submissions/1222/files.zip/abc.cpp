#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void)
{
	int t,i,j,a,b,n,sum;
	scanf("%d",&t);
	while(t--)
	{sum=0;
		scanf("%d %d",&a,&b);
		b=b+a;
		if(b>=10000)
		{
			b=9999-(b-9999);
		}
		if(a>b)
		{
			n=a;
			a=b;
			b=n;
		}
		for(i=a;i<=b;++i)
		{
			if(i%4==0&&i%100!=0||i%400==0)
			{
				sum=sum+1;
			}
		}
		printf("%d\n",sum);
	}
	
	return 0;
}