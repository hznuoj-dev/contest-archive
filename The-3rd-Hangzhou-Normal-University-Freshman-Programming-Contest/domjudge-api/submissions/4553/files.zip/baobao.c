#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int A=0,B=0,C=0,D=0;
	int x=0;
	int suma=0,sumb=0,sumc=0,sumd=0;
	scanf("%d %d %d %d",&A,&B,&C,&D);
	while(A!=0){
		suma+=(A%10);
		A/=10;	
	}
	if(suma>=16||suma==6){
		x++;
	}
	while(B!=0){
		sumb+=(B%10);
		B/=10;	
	}
	if(sumb>=16||sumb==6){
		x++;
	}
	while(C!=0){
		sumc+=(C%10);
		C/=10;	
	}
	if(sumc>=16||sumc==6){
		x++;
	}
	while(D!=0){
		sumd+=(D%10);
		D/=10;	
	}
	if(sumd>=16||sumd==6){
		x++;
	}
	if(x==1){
		printf("Oh dear!!");
		
	}
	if(x==2){
		printf("BaoBao is good!!");
	}
	if(x==3){
		printf("Bao Bao is a SupEr man///!");
	}
	if(x==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	if(x==0){
		printf("Bao Bao is so Zhai......");
	}
	return 0;
}
