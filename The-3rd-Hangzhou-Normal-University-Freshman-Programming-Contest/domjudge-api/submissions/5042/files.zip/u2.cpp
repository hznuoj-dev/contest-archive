#include<stdio.h>
int main(void){
	int t,m,n,i;
	double a;
	char ch,c[100000];
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&m,&n);
		for(i=0;i<m;++i){
			if(i<n)
			   c[i]='#';
			else if(i>=n&&i<m)
			  c[i]='-';
		}
		a=(double)n/m*100.0;
		ch='%';
		printf("[%s] %.0f%c\n",c,a,ch);
	}
	return 0;
}
	
