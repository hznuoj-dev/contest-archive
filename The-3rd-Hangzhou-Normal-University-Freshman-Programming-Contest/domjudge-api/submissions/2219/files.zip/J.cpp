#include<bits/stdc++.h>
using namespace std;
int main()
{
	//freopen("sample-J.1.in","r",stdin);
	int t; cin>>t;
	while(t--)
	{
		int n; cin>>n;
		getchar();
		int sum=0;
		while(n--)
		{
			string s; getline(cin,s);
			int asc[130]; memset(asc,0,sizeof(asc));
			for(int i=0; i<s.length(); i++) if(s[i]!='.') asc[s[i]]++;
			int cnt=0;
			for(int i=' '; i<=127; i++) if(asc[i]>0) cnt++;
			//printf("%d ",cnt);
			sum+=cnt;
		}
		printf("%d\n",sum);
	}
	return 0;
}


