#include<stdio.h>

int main(){
	int t,m,n;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&m,&n);
		printf("[");
		for(int i=0;i<n;i++){
			printf("#");
		}
		for(int i=n;i<m;i++){
			printf("-");
		} 
		float x = (float)n*1.0/m;
		printf("] %.0f%%\n",x*100);
	}
    return 0;
}

