#include<stdio.h>
#include<string.h>
int main()
{
    int t,n,i;
    scanf("%d\n",&t);
    while(t--)
    {
        int num=0;
        scanf("%d\n",&n);
        while(n--)
        {
            char s[10000004],b[10000004]=".";
            int x;
            gets(s);
            for(i=0,x=0;i<strlen(s);i++)
            {
                if(s[i]!='.'&&strchr(b,s[i])==NULL)
                {
                    num++;
                    b[x]=s[i];
                    x++;
                }
            }
        }
        printf("%d\n",num);
    }
}
