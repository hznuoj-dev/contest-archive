#include<stdio.h>
#include<string.h>
int main(){
	int a,b=0;
	scanf("%d",&a);
	char c[1000000/a];
	while(a--){
		scanf("%s",c);
		b+=strlen(c);
	}printf("%d",b);
	return 0;
}
