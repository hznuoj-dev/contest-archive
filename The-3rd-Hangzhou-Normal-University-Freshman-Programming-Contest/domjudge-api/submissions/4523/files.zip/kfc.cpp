//kfc
#include "stdio.h"
int main()
{
	char ch[4];
	gets(ch);
	printf("  _ _             _ _ _ _ _\n");
	printf("\n");
	printf("|     |   _ _ _ /   _ _ _ _ \\a _ _ _ _       \n");
	printf("\n");
	printf("|     | /   / \\       _ _ \\ /   _ _ _ \\         \n");
	printf("\n");
	printf("|         <     |     |   \\     \\ _ _ _       \n");
	printf("\n");
	printf("| _ _ | _   \\   | _ _ |     \\ _ _ _     >      \n");
	printf("\n");
	printf("          \\ /                     \\ /     \n");
	return 0;
}
