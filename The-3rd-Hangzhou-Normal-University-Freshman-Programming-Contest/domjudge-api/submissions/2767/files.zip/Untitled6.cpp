#include<stdio.h>
#include<stdlib.h>


#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>


using namespace std;


char s[1111111];

int r[1111111]={0};
int main(){
	int t, n, i, j, k, l;
	cin >> t;
	while(t--){
		int count=0,f;
		cin >> n;
		for(i=0;i<n;i++){
			f=0;
			scanf("%s",s);
			getchar();
			l=strlen(s);
			for(k=0;k<l;k++){
				if(s[k]!='.'){
				if(f==0){
				   r[f]=i;
					count ++;
					f++;
				}else{
					for(j=0;j<f;j++){
						if(s[r[j]]==s[k])break;
						
					}if(j==f-1){
								r[f]=s[k];
								f++;
								count++;
							}
				}
			}
			}
			
		}
		cout << count << endl;
	}
	return 0;
}
