#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
const int MAX=1e6+5;
char str[MAX];
map <char,int>mp;
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,m;
		scanf("%d%d",&n,&m);
		printf("[");
		for(int i=1;i<=m;i++)
		{
			printf("#");
		}
		for(int i=1;i<=n-m;i++)
		{
			printf("-");
		}
		printf("] ");
		printf("%d%%\n",m*100/n);
	}
	return 0;
}

