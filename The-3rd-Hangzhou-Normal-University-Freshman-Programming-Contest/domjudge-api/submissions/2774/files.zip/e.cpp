#define _CRT_SECURE_NO_WARNINGS

#include<stdio.h>
int main(void) {
	int T, Y, A, s, i, sum = 0;
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d", &Y, &A);
		s = Y + A;
		if (s >= 10000) {
			s = 9999 - (s - 9999);
		}
		if (s >=Y&& s < 10000) {
			for (i = Y; i <= s; i++) {
				if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
					sum++;
			}
		}
		if (s < Y) {
			for (i = s; i <= Y; i++) {
				if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
					sum++;
			}
		}
		printf("%d\n", sum);
		sum = 0;
	}
	return 0;
}