#include <stdio.h>
int main(void)
{
	int t,i,q,a,b,x,c,s;
	scanf("%d",&t);
	for(q=1;q<=t;q++)
	{
		scanf("%d %d",&a,&x);
		if((a+x)>9999)
		b=9999-(a+x-9999);
		else
		b=a+x;
		if(a>b){
		c=a;a=b;b=c;}
		s=0;
		for(i=a;i<=b;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
			s=s+1;
		}
		printf("%d\n",s);
	}
 } 
