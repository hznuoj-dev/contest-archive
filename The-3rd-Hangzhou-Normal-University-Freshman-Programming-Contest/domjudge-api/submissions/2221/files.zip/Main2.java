import java.util.Scanner;

public class Main2
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{
			String kfs=sc.next();
			if(kfs.equals("kfc")) {
				System.out.println(" __      _____");
				System.out.println("|  | ___/ ____\\____");
				System.out.println("|  |/ /\\   __\\/ ___\\");
				System.out.println("|    <  |  | \\  \\___");
				System.out.println("|__|_ \\ |__|  \\___  >");
				System.out.println("     \\/           \\/");
			}
			
			
//			__ _____
//			| | ___/ ____\____
//			| |/ /\ __\/ ___\
//			| < | | \ \___
//			|__|_ \ |__| \___ >
//			\/ \/
		}

	}

}
