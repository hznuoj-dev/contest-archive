#include<stdio.h>
int main(){
	int t,n,m,a,b;
	int c[10000][2],d[10000]={0};
	int i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		for(i=0;i<m;i++){
			scanf("%d%d",&c[i][0],&c[i][1]);
			if(d[c[i][1]-1]!=0&&d[c[i][0]-1]==0){
				d[c[i][1]-1]++;
				d[c[i][0]-1]=d[c[i][1]-1]-1;
			}	
			else if(d[c[i][1]-1]==0&&d[c[i][0]-1]!=0)
				d[c[i][1]-1]=d[c[i][0]-1]+1;
			else if(d[c[i][1]-1]!=0&&d[c[i][0]-1]!=0){
				d[c[i][1]-1]=d[c[i][0]-1]+1;
				for(j=0;j<m;j++){
					if(d[c[i][1]-1]==d[c[j][1]-1])
						d[c[i][0]-1]=d[c[i][1]-1]-1;
				}
			}
			else
				d[c[i][1]-1]++;
		}
		i=0;
		while(i<n){
			for(j=0;j<n;j++){
				if(d[j]==i){
					printf("%d",j+1);
					break;
				}
			}
			i++;
			if(i!=n)printf(" ");
		}
	}
	return 0;
} 
