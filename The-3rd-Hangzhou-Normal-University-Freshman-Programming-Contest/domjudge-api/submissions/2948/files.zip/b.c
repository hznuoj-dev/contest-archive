#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
	long long int a,b,c,i,j,t,m;
	scanf("%lld",&t);
	while(t--)
	{
		j=0;
		scanf("%lld %lld",&a,&b);
		c=a+b;
        if(b<0)
         {
				 for(i=a;i<=c;i++)
				 {
					 if((i%4==0&&i%100!=0)||i%400==0)
						 j++;
				 }
				 break;
               }
        if(c>9999)
           {
            c=9999-(c-9999); 
           }
		for(i=a;i<=c;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
				j++;
		}
		printf("%lld\n",j);
	}
	return 0;
}