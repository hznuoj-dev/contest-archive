//
// Created by Kyooma on 2020/12/13.
//
#include <bits/stdc++.h>
#define ll long long
using namespace std;
int rua(ll a){
    int res=0;
    while(a){
        res+=a%10;
        a/=10;
    }
    return res;
}
int main(){
    ll a[4];
    int cnt=0;
    scanf("%lld%lld%lld%lld",&a[0],&a[1],&a[2],&a[3]);
    for(int i=0;i<4;i++){
        if(rua(a[i])>=16 || rua(a[i])==6) cnt++;
    }
    switch (cnt) {
        case 1:printf("Oh dear!!\n");break;
        case 2:printf("BaoBao is good!!\n");break;
        case 3:printf("Bao Bao is a SupEr man///!\n");break;
        case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");break;
        case 0:printf("Bao Bao is so Zhai......\n");break;
    }
}
