#include <stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996) 
int main(){
	long int h1,h2,a1,a2,t,h,m,m1,m2,a;
	long long int s=0;
	scanf("%ld",&t);
	while(t--){
		int y=0;
		scanf("%ld %ld %ld %ld",&h1,&h2,&a1,&a2);
		h=h1+h2;
		a=a1+a2;
		for(int i=2;;i++){
			if(i*(i+1)/2>=h){
		     	m=i;
		        break;
			}
		}
		for(int i=2;;i++){
			if(i*(i+1)/2>=h1){
				m1=i;
				break;
			}
		}
		for(int i=2;;i++){
			if(i*(i+1)/2>=h2){
				m2=i;
				break;
			}
		}
		s=m2*a+(m-m2)*a1;
		if(m1*a+(m-m1)*a2<s){
			s=m1*a+(m-m1)*a2;
			y=1;
		}
		printf("%lld ",s);
		if(y==0){
			long int p=m2*(m2+1)/2-h2;
			for(int i=1;i<p;i++){
				printf("W");
			}
			if(p!=0)
			printf("Q");
			for(int i=p+1;i<=m2;i++)
			printf("W");
			for(int i=m2+1;i<=m;i++){
				printf("Q");
			}
		} 
		if(y==1){
			long int p=m1*(m1+1)/2-h1;
			printf("W");
			for(int i=2;i<p-1;i++){
				printf("Q");
			}
			printf("W");
			for(int i=p;i<=m1;i++)
			printf("Q");
			for(int i=m1+1;i<=m;i++)
			printf("W");
		}
		printf("\n");
	}
	return 0;
}
/*struct tijiao{
	int a;
	int b;
	int c;
	char d;
	char e;
}q[100001];
int paiming
void printft(int a,int b,int c){
	if(a==0){
		
	}
}
int main(){
	int n,t,m,p,w,i,j;
	char a[6][20]={"teamstatus","minrank","maxrank","account","submitcount","teamcount"};
	char b[20];
	scanf("%d %d %d %d",&n,&t,&m,&p);
	for(int i=0;i<m;i++){
		scanf("%d %d %d %c%c",&q.a,&q.b,&q.a,&q.c,&q.d,&q.e)
	}
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			if(q[j].c>q[j+1].c)
			q[100001]=q[j],q[j]=q[j+1],q[j+1]=q[100001];
		}
	}
	scanf("%d",&w);
	while(w--){
		scanf("%s%d %d",b,&i,&j);
		for(o=0;o<=5;o++){
			if(strcmp(a[o],b)==0)
			break;
		}
		printft(o,i,j);
		memset(b,0,sizeof(b));
	}
} */
