#include<iostream>
using namespace std;
int a[1001];
int c[1001];
void change(int x,int y,int n);
int main(){
	int T,n,m,x,y,p1,p2;
	cin >> T;
	while (T--){
		cin >> n >> m;
		for (int i=1;i<=n;++i){
			a[i]=i;
		}
		for (int i=1;i<=m;++i){
			cin >> x >> y;
			for (int j=1;j<=n;++j){
				if (a[j]==x) p1=j;
				if (a[j]==y) p2=j;
			}
			if (p1>p2) {
				change(p2,p1,n);
			}
		}
		for (int i=1;i<=n;++i){
			if (i==1) cout << a[i];
			else cout << ' ' << a[i];
		}
		cout << endl;
	}
    return 0;
}
void change(int x,int y,int n){
	for (int i=x;i<=y-1;++i){
		c[i]=a[i];
	}
	for (int i=y;i<=n;++i){
		a[i-y+x]=a[i];
	}
	for (int i=n-y+x+1;i<=n;++i){
		a[i]=c[i+y-n-1];
	}
}
