t=int(input())
for i in range(t):
    sum=0
    n=int(input())
    for j in range(n):
        s=input()
        t=[]
        for k in s:
            if k!='.':
                if k not in t:
                    t.append(k)
        sum+=len(t)
    print(sum)
