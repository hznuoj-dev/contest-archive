#include <iostream>
using namespace std;
int main()
{
    char s[4];
    gets(s);
    cout << " __      _____ " << endl
         << "|  | ___/ ____\\____" << endl
         << "|  |/ /\\   __\\/ ___\\" << endl
         << "|    <  |  |  \\  \\___" << endl
         << "|__|_ \\ |__|   \\___  >" << endl
         << "     \\/            \\/" << endl;
    system("pause");
    return 0;
}