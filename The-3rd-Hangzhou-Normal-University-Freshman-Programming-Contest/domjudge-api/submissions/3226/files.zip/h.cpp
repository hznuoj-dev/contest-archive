#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int n,m,k,i,j;
	double a,b,c;
	scanf("%d",&n);
	while(n--){
		scanf("%lf %lf",&a,&b);
		c=b/a;
		printf("[");
		for(i=0;i<b;i++){
			printf("#");
		}
		for(i=0;i<a-b;i++){
			printf("-");
		}
     printf("] %.0lf%%\n",ceil(c*100));
	}
}





