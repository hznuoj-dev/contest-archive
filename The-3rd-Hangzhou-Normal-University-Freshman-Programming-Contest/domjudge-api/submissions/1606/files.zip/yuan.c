#include<stdio.h>
#include<string.h>
#include<process.h>
int dd(int x);
int main(){
int a,b,c,d;
int t=0;
scanf("%d%d%d%d",&a,&b,&c,&d);
t=dd(a)+dd(b)+dd(c)+dd(d);
switch(t)
{
case 1:printf("Oh dear!!");break;
case 2:printf("BaoBao is good!!");break;
case 3:printf("Bao Bao is a SupEr man%c%c%c!",92,92,92);break;
case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
default:printf("Bao Bao is so Zhai......");break;
}
system("pause");
return 0;
}
int dd(int x)
{
	int n,m,sum=0;
	while(x>0)
	{
		n=x%10;
		sum+=n;
		x/=10;

	}
	if(sum>=10||sum==6)
	{
		return 1;
	}
	else
		return 0;

}
