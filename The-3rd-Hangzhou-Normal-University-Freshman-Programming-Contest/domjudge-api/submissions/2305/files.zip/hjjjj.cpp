#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[102];
	int b[102];
	for(int i=1;i<=n;i++){
		cin>>a[i]>>b[i];
	}
	for(int j=1;j<=n;j++){
		int z=a[j]+b[j];
		int m;
		int x=a[j];
		if(z<x)
		{
			m=z;
			z=x;
			x=m;
		}
		if(z>=10000){
			int kkk=z-9999;
			z=9999-kkk;
		}
		int mmm;
		if(z<x)
		{
			mmm=z;
			z=x;
			x=mmm;
		}
		int sum=0;
		for(int i=x;i<=z;i++){
			int leap=0;;
		if(i%4==0)
		{
		if(i%100!=0)
			leap=1;
		if(i%400==0)
			leap=1;
     	}
		if(leap==1)
			sum++;
		}
		printf("%d\n",sum);
	}
} 

