#include <stdio.h>
#include <stdlib.h>
#include<string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main() {
char a[19],b[19],c[19],d[19];
int sum=0,num,len,i;
scanf("%s",a);
scanf("%s",b);
scanf("%s",c);
scanf("%s",d);

puts(c);
len=strlen(a);
num=0;
for(i=0;i<len;i++){
	num+=a[i]-'0';
}
if(num>=16||num==6)  sum++;



len=strlen(b);
num=0;
for(i=0;i<len;i++){
	num+=a[i]-'0';
}
if(num>=16||num==6)  sum++;




len=strlen(c);
num=0;
for(i=0;i<len;i++){
	num+=a[i]-'0';
}
if(num>=16||num==6)  sum++;



len=strlen(d);
num=0;
for(i=0;i<len;i++){
	num+=a[i]-'0';
}
if(num>=16||num==6)  sum++;


if(sum==1)  printf("Oh dear!!");
if(sum==2)  printf("BaoBao is good!!");
if(sum==3)  printf("Bao Bao is a SupEr man///!");
if(sum==4)  printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
if(sum==0)  printf("Bao Bao is so Zhai......");
	return 0;
}





