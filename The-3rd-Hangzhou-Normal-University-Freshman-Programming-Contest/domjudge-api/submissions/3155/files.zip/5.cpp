#include<stdio.h>
int main(){
	int t;
	int n,m,i;
	double r;
	while(~scanf("%d",&t)){
	while(t--){
		scanf("%d %d",&n,&m);
		r=m*1.0/n;
		printf("[");
		for(i=1;i<=m;i++){
			printf("#");
		}
		for(i=1;i<=n-m;i++){
		printf("-");} 
		if(t>1)printf("] %.0lf%%\n",r*100);
		else printf("] %.0lf%%",r*100);
	}
	}
	return 0;
}
