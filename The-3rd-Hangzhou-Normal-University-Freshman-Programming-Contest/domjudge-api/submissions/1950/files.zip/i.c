#include <stdio.h>
#include <string.h>

int main(void)
{
	int n=0,i,j,a[4]={0};
	char s[4][20];
	scanf("%s %s %s %s",&s[0],&s[1],&s[2],&s[3]);
	for(i = 0;i < 4;i++)
	{
		j = 0;
		while(s[i][j]!='\0' && s[i][j]!='\n')
		{
			a[i] += (s[i][j]-'0');
			j++;
		}
		if(a[i]>=16 || a[i]==6)
		{
			n++;
		}
	}
	if(n ==0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	else if(n ==1)
	{
		printf("Oh dear!!\n");
	}
	else if(n == 2)
	{
		printf("BaoBao is good!!\n");
	}
	else if(n == 3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	else if(n == 4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	

	return 0;
}
