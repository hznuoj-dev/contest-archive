#include<stdio.h>
#include<string.h>
void main()
{
	char a[4];
	scanf("%s", &a);
	if (a[0] == 'k')
	{
		printf(" __      _____\n");
		printf("|  | ___/ ____\\\____\n");
		printf("|  |/ /\\\   __\\\/ ___\\\ \n");
		printf("|    <  |  | \\\  \\\___\n");
		printf("|__|_ \\\ |__|  \\\___  >\n");
		printf("     \\\/           \\\/\n");
	}
}



























/*int n, T, m, p, q;
	int a[1000000][5],b[100000][15];
	int i, j, l, L;
	scanf("%d %d %d %d", &n, &T, &m, &p);
	for (i = 0; i < m; i++)
	{
		scanf("%d %d %d %c %c", &a[i][0], &a[i][1], &a[i][2], &a[i][3], &a[i][4]);
	}
	scanf("%d", &q);
	for (i = 0; i < q; i++)
	{
		scanf("%s", &b[i]);
		l = strlen(&b[i]);
		scanf("%d %d", &b[i][l + 1], &b[i][l + 2]);
	}
	for (i = 0; i < q; i++)
	{
		if (b[i][0] == 't'&&b[i][6] == 't')
		{
			printf("%d [%s] %")
		}
	}*/