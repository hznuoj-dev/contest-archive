#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char s[105][1000005];
int comp(const void *p,const void *q){
	return (*(char *)p-*(char *)q);
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			char a;
			scanf("%s",s[i]);
			//printf("%d\n",strlen(s[i]));
			qsort(s,strlen(s[i]),sizeof(char),comp);
			//for(int j=0;j<strlen(s[i]);j++)
			//printf("%c",s[i][j]);
			//printf("\n");
			for(int k=0;k<strlen(s[i]);k++){
				if(s[i][k]!='.'&&k==0)
				m++;
				else if(s[i][k]!='.'&&k>0&&s[i][k]!=s[i][k-1])
				m++;
			}
		}
		printf("%d\n",m);
	}
}
