#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char a[1000]; 
	char b[1000]; 
	char c[1000]; 
	char d[1000]; 
	int i,j,sum=0,sum1=0;
	scanf("%s%s%s%s",a,b,c,d);
		for(j=0;j<strlen(a);++j){
			sum+=a[j]-'0';
		}
		if(sum>=16||sum==6)
		sum1++;
		sum=0;
		for(j=0;j<strlen(b);++j){
			sum+=b[j]-'0';
		}
		if(sum>=16||sum==6)
		sum1++;
		sum=0;
		for(j=0;j<strlen(c);++j){
			sum+=c[j]-'0';
		}
		if(sum>=16||sum==6)
		sum1++;
		sum=0;
		for(j=0;j<strlen(d);++j){
			sum+=d[j]-'0';
		}
		if(sum>=16||sum==6)
		sum1++;
		sum=0;
		if(sum1==1)
		printf("Oh dear!!\n");
		else if(sum1==2)
		printf("BaoBao is good!!\n");
		else if(sum1==3)
		printf("Bao Bao is a SupEr man///!\n");
		else if(sum1==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
		else if(sum1==0)
		printf("Bao Bao is so Zhai......\n");
	return 0;
}
