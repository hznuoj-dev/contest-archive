#include<bits/stdc++.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		double  m,n;
		cin>>m>>n;
		int per=100.0*n/m;
		cout<<'[';
		for(int i=0;i<n;i++)
		{
			cout<<'#';
		}
		for(int j=0;j<m-n;j++)
		{
			cout<<'-';
		}
		cout<<']'<<' '<<per<<'%'<<endl;
		
		
		
	}
	
	
	return 0;
}
