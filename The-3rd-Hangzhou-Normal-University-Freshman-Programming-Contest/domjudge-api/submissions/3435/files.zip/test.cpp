#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
const int maxn=110;
int n,m,t,is,cnt,ans;
bool bo(int a){
    if((a%4!=0)||(a%100==0&&a%400!=0))return false;
    return true;
}
int jud(int l,int r){
    int sum=0;
    for(int i=l;i<=r;i++){
        if(bo(i))++sum;
    }
    return sum;
}
int main(){
    ios::sync_with_stdio(false);
    cout<<fixed<<setprecision(0);
    cin>>t;
	while(t--) {
        int l,r;
        cin>>n>>m;
        int x=n+m;
        if(x>9999)x=9999-(x-9999);
        if(x<n)l=x,r=n;
        else l=n,r=x;
        //cout<<"l="<<l<<" r="<<r<<"\n";
        cout<<jud(l,r)<<"\n";
	}
    return 0;
    //good job!
}
