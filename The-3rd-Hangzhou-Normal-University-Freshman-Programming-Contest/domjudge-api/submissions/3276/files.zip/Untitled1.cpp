#include <stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b;
		scanf("%d %d",&a,&b);
		printf("[");
		for(int i=0;i<b;i++)
		printf("#");
		for(int i=b;i<a;i++)
		printf("-");
		printf("] ");
		int m;
		m=(int)(b*1.0/a*100);
		printf("%d%%\n",m);
	}
}
