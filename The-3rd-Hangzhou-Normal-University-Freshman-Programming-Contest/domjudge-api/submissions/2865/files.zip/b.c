/*#include<stdio.h>
int check(int y1,int y2);
int main()
{
    int t;
    int y,a,num;
    scanf("%d\n",&t);
    while(t--)
    {
        scanf("%d %d\n",&y,&a);
        if((y+a)<=9999&&(a>=0)){
            num=check(y,y+a);
        }
        else if((y+a)>9999){
            num=check(y,9999-(y+a-9999));
        }
        else if((y+a)<9999&&(a<0)){
            num=check(y+a,y);
        }
        printf("%d\n",num);
    }
}
int check(int y1,int y2)
{
    int num=0,i;
    for(i=y1;i<=y2;i++)
    {
        if((i%4==0&&i%100!=0)||(i%400==0))num++;
    }
    return num;
}
*/
/*#include<stdio.h>
int main()
{
    int n,price[100],num[100],i,kind=0;
    long m;
    scanf("%d %ld\n",&n,&m);
    for(i=0;i<n;i++){scanf("%d",&price[i]);}
    for(i=0;i<n;i++){scanf("%d",&num[i]);}
    
}
*/
#include<stdio.h>
int main()
{
    int t,i;
    long n,m;
    scanf("%d\n",&t);
    while(t--)
    {
        scanf("%ld%ld\n",&n,&m);
        printf("[");
        for(i=1;i<=m;i++){printf("#");}
        for(i=1;i<=n-m;i++){printf("-");}
        printf("]");
        printf(" %d%%\n",(int)(m*100/n));
    }
}
