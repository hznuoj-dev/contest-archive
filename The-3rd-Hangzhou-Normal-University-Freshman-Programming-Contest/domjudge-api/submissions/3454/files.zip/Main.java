package xyz.leow;
import java.util.Scanner;

public class Main {
    public static void main(String[] arg)
    {
        Scanner in=new Scanner(System.in);
        while(in.hasNext())
        {
        	int n=in.nextInt();
        	for(int i=0;i<n;i++)
        	{
        		int sum=0;
        		int floor=in.nextInt();
        		for(int j=0;j<floor;j++)
        		{
        			String mess=in.next();
        			String index=".";
        			for(int k=0;k<mess.length();k++)
        			{
        				String trash=mess.substring(k,k+1);
        				if(!index.contains(trash))
        				{
        					index=index.concat(trash);
        					sum++;
        				}
        			}
        		}
        		System.out.println(sum);
        	}
        }
    }
}