#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s;
	cin>>s;
	cout<<" __      _____";
	cout<<endl;
	cout<<"|  | ___/ ____\\____";
	cout<<endl;
	cout<<"|  |/ /\\   __\\/ ___\\";
	cout<<endl;
	cout<<"|    <  |  | \\  \\___";
	cout<<endl;
	cout<<"|__|_ \\ |__|  \\___  >"<<endl;
	cout<<"     \\/           \\/";
}

