#include<bits/stdc++.h>
using namespace std;
int judge(int a,int b)
{
    int i,sum=0;
    if(b>9999) b=9999;
	for(i=a;i<=b;i++)
    {
	    if( (i%4==0 && i%100!=0 )|| i%400==0)
	    sum++;
	}
   return sum;
}

int main()
{
   int a,b,i,t,j,m;
   cin>>t;
   for(i=1;i<=t;i++)
   {
     cin>>a,cin>>b;
     b=a+b;
	 if(a>b) 
	 {
	    m=a;a=b;b=m;
	 }
	   cout<<judge(a,b);
	   if(i!=t) cout<<endl;
   }
	
	return 0;
}
