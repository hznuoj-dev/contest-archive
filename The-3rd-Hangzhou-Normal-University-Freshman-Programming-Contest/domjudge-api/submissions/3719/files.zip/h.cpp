#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int n,i;
	int a,b;
	double c;
	scanf("%d",&n);
	while(n--){
		scanf("%d %d",&a,&b);
		c=(double)b/a;
		printf("[");
		for(i=0;i<b;i++){
			printf("#");
		}
		for(i=0;i<a-b;i++){
			printf("-");
		}
     printf("] %.0lf%%\n",c*100);
	}
	return 0;
}




