#include <stdio.h>
#include <string.h>

int main(void)
{
	int t,n,m,a,b,num[1001],i,ai,bi,z;
	int *(numb)[1001];
	int *win;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		for(i = 0;i< n;i++)
		{
			num[i]= i+1;
			if(i != n-1)
			numb[i]= &num[i+1];
		}
		win = &num[0];
		numb[n-1]=NULL;
		while(m--)
		{
			scanf("%d %d",&a,&b);
			/*if(numb[b-1] == win)
			{
				win = &num[a-1];
				numb[a-2]=numb[a-1];
				numb[a-1]=&num[b-1];
			}
			else
			{
				numb[b-2]=&num[a-1];
				numb[a-2]=numb[a-1];
				numb[a-1]=&num[b-1];
			}*/
			for(i = 0;i < n;i++)
			{
				if(num[i]==a)
				{
					ai= i;
				}
				else if(num[i] == b)
				{
					bi = i;
				}
				
			}
			if(bi < ai)
			{
				
				z = a;
				for(i = ai;i >bi;i--)
				{
					num[i] = num[i-1];
				}
				num[bi]=a;
			} 
		}
		for(i = 0;i < n;i++)
		{
			
			if(i == 0)
			{
				printf("%d",num[i]);
			}
			else
			{
				printf(" %d",num[i]);
			}
		}
		
		
		/*printf("%d",num[*win-1]);
		z = num[*win-1];
		while(numb[z]!=NULL)
		{
			printf(" %d",num[*numb[z]-1]);
			z = num[*numb[z]-1];
		}*/
		
			
		printf("\n");
	}
	
	
	return 0;
}
