#include<stdio.h>
#include<string.h>
int main(void)
{
	int t=0,suma=0,sumb=0,sumc=0,sumd=0,A,B,C,D,i;
		scanf("%d %d %d %d",&A,&B,&C,&D);
		while(A>0)
		{
			suma=suma+A%10;
			A=A/10;
		}
		if(suma>=16||suma==6)
		t++;
		while(B>0)
		{
			sumb=sumb+B%10;
			B=B/10;
		}
		if(sumb>=16||sumb==6)
		t++;
		while(C>0)
		{
			sumc=sumc+C%10;
			C=C/10;
		}
		if(sumc>=16||sumc==6)
		t++;
			while(D>0)
		{
			sumd=sumd+D%10;
			D=D/10;
		}
		if(sumd>=16||sumd==6)
		t++;
	switch(t)
	{
		case 0:printf("Bao Bao is so Zhai......\n");break;
		case 1:printf("Oh dear!!\n");break;
		case 2:printf("BaoBao is good!!\n");break;
		case 3:printf("Bao Bao is a SupEr man///!\n");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");break;
	}
	return 0;
}
