#include<math.h>
#define PI 3.1415926
#include <string.h>
#include<stdio.h>
#include<ctype.h>

int check(int a){
	int sum=0;
	while(a>0){
		sum+=a%10;
		a=a/10;
	}
	if(sum>=16||sum==6)return 1;
	else return 0;
}


int main()
{
	int sum=0;
	int a,b,c,d;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	if(check(a))sum++; 
	if(check(b))sum++;
	if(check(c))sum++;
	if(check(d))sum++;
	if(sum==1)printf("Oh dear!!");
	if(sum==2)printf("BaoBao is good!!");
	if(sum==3)printf("Bao Bao is a SupEr man///!");
	if(sum==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	if(sum==0)printf("Bao Bao is so Zhai......");

	
return 0;
}
