#include <bits/stdc++.h>

using namespace std;

int main() {
    int T, x, y;
    cin >> T;
    while (T--) {
        cin >> x >> y;
        cout << "[";
        for (int i = 1; i <= y; i++)cout << '#';
        for (int i = 1; i <= x - y; i++)cout << "-";
        cout << "] " << y * 100 / x << "%" << endl;
    }
    return 0;
}
