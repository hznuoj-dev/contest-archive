#include <bits/stdc++.h>
using namespace std;
int main()
{
	char a,b,c;
	scanf("%c%c%c",&a,&b,&c);
	printf(" __      _____");
	printf("\n");
	printf("|  | ___/ ____\\____");
	printf("\n");
	printf("|  |/ /\\   __\\/ ___\\");
	printf("\n");
	printf("|    <  |  | \\  \\___");
	printf("\n");
	printf("|__|_ \\ |__|  \\___  >");
	printf("\n");
	printf("     \\/           \\/");
	printf("\n");
	
	
	
	return 0;
}
/* __     _____
| | ___/ ____\____
| |/ /\    __\/ ___\
|    <  |  | \  \___
|__|_ \ |__|  \___  >
     \/           \/*/
