n = int(input())
while n:
    n = n - 1
    a, b = map(float, input().split())
    c = b / a *100
    print('[',end='')
    print('#'*int(b),end='')
    print('-'*int(a-b),end='')
    print(']',format(c,".0f"),end='')
    print('%')