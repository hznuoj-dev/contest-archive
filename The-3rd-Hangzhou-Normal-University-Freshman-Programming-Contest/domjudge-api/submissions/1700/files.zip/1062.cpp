#include <stdio.h>
#include <string.h>
int main()
{
	int i,j,n,len,sum;
	char s[4][20];
	for(i=0;i<4;i++){
		scanf("%s",&s[i]);
	}
	n=0;
	for(i=0;i<4;i++){
		sum=0;
		len=strlen(s[i]);
		for(j=0;j<len;j++){
			sum=sum+(s[i][j]-'0');
		}
		if(sum==6||sum>=16){
			n++;
		}
	}
	if(n==0){
		printf("Bao Bao is so Zhai......");
	}else if(n==1){
		printf("Oh dear!!");
	}else if(n==2){
		printf("BaoBao is good!!");
	}else if(n==3){
		printf("Bao Bao is a SupEr man///!");
	}else if(n==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}

	return 0;
}

