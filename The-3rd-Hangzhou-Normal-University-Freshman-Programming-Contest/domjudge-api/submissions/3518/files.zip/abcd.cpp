#include<stdio.h>
int main(){
	long long int a,b,c,d,f1=0,f2=0,f3=0,f4=0;
	int fla1=0,fla2=0,fla3=0,fla4=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	while(a>0){
	f1=f1+a%10;
	a=a/10;}
	if(f1==6||f1>=16)
	fla1=1;
	while(b>0){
	f2=f2+b%10;
	b=b/10;}
	if(f2==6||f2>=16)
	fla2=1;
	while(c>0){
	f3=f3+c%10;
	c=c/10;}
	if(f3==6||f3>=16)
	fla3=1;
	while(d>0){
	f4=f4+d%10;
	d=d/10;}
	if(f4==6||f4>=16)
	fla4=1;
	if(fla1+fla2+fla3+fla4==1)
	printf("Oh dear!!");
	if(fla1+fla2+fla3+fla4==2)
	printf("BaoBao is good!!");
	if(fla1+fla2+fla3+fla4==3)
	printf("Bao Bao is a SupEr man///!");
	if(fla1*fla2*fla3*fla4==1)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	if(fla1+fla2+fla3+fla4==0)
	printf("Bao Bao is so Zhai......");
	return 0;
} 
