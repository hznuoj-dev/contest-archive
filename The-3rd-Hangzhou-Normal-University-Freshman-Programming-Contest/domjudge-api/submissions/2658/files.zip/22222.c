#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
int main(){
	int n;
	double a,b;
	scanf("%d",&n);
	while(n--){
		scanf("%lf %lf",&a,&b);
		printf("[");
		for(int i=1;i<=(int)b;i++){
			printf("#");
		}
		for(int i=1;i<=(int)(a-b);i++){
			printf("-");
		}
		printf("]");
		printf(" %.0f%%\n",b/a*100);
		
	} 
}
