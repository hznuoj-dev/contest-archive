#include <stdio.h>
#include<string.h>
int main() {
long long t,m=0,i;
char s[1008][1008];
scanf("%lld",&t);
for(i=1;i<=t;i++){
	scanf("%s",s[i]);
	m+=strlen(s[i]);
}
	printf("%lld",m);
	return 0;
}
