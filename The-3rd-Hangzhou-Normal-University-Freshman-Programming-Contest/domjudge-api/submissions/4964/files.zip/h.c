#include <stdio.h>
int main(void)
{
	int t,n,m,i,a;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		i=n-m;
		printf("[");
		a=m;
		while(m--)
		{
			printf("#");
	    }
	    
	    while(i--)
		{
			printf("_");
	    }
	    printf("]%d%%\n",a*100/n);
	    
	}
	return 0;
}
