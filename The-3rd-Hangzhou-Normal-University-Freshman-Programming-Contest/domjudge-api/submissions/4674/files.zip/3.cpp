#include<bits/stdc++.h>
int main()
{
	int a,cnt=0;
	for(int i=0;i<4;i++){
		int sum=0;
		scanf("%d",&a);
		while(a!=0){
			sum+=a%10;
			a/=10;
		}
		if(sum>=16||sum==6){
			cnt++;
		}
	}
	if(cnt==1){
		printf("Oh dear!!");
	}
	if(cnt==2){
		printf("BaoBao is good!!");
	}
	if(cnt==3){
		printf("BaoBao is a SupEr man///!");
	}
	if(cnt==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	if(cnt==0){
		printf("Bao Bao is so Zhai......");
	}
	return 0;
 } 
