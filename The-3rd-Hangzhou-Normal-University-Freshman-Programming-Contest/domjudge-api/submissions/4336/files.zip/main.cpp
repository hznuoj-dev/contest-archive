#include <bits/stdc++.h>

using namespace std;

const int N = 1e5 + 1;
int dp[111][N];
int a[111], b[111];

int main() {
    int n, m;
    cin >> n >> m;
    dp[0][0] = 1;
    for (int i = 1; i <= n; i++)cin >> a[i];
    for (int i = 1; i <= n; i++)cin >> b[i];
    for (int i = 1; i <= n; i++) {
        for (int j = 0; j < m; j++) {
            if (dp[i - 1][j])
                for (int k = 0; k <= b[i]; k++) {
                    if (j + k * a[i] > m)break;
                    //cout<<k<<" "<<j + k * a[i]<<endl;
                    dp[i][j + k * a[i]] = 1;
                }
        }
    }
    int ans = 0;
    for (int i = 1; i <= m; i++) {
        if (dp[n][i])ans++;
    }
    cout << ans;
    return 0;
}
