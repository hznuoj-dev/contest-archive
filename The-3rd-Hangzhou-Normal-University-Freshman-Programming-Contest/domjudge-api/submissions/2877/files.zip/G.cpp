#include<bits/stdc++.h>
using namespace std;
int fa[10010];
vector <int> G[10010];
int main()
{
	int T,n,m,a,b,i,t;
	cin >> T;
	while(T--){
		cin >> n >> m;
		for(i=1;i<=n;i++){
			fa[i]=i;
		}
		for(i=1;i<=m;i++){
			cin >> a >> b;
			if(fa[b]!=b){
				fa[a]=fa[b];
				G[fa[b]].pop_back();
				G[fa[b]].push_back(a);
			}
			fa[b]=a;
			G[a].push_back(b);
		}
		for(i=1;i<=n;i++){
			if(fa[i]==i){
				t=i;
				cout << t << " ";
				while(G[t].size()!=0){
					cout << G[t].back() << " ";
					t=G[t].back();
				}
			}
		}
	}
}
