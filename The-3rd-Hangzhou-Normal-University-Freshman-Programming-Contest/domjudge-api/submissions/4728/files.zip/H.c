#include<stdio.h>
#include<string.h>
int main()
{
   int T,i;float a,b;
   scanf("%d",&T);
   while(T--)
   {
       scanf("%f %f",&a,&b);
       printf("[");
       for(i=0;i<b;i++) {printf("#");}
       for(i=0;i<(a-b);i++) {printf("-");}
       printf("]");
       printf(" %0.f%%\n",b/a*100);


   }
}


