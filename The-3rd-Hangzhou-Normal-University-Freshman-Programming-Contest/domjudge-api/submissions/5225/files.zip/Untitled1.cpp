#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	int a;
	scanf("%d",&a);
	while(a--)
	{
		int m,n,i,j;
		scanf("%d%d",&m,&n);
		int b[10000]={0},c,d,s[10000]={0};
		for(i=1;i<=n;i++)
		{
			scanf("%d%d",&c,&d);
			b[c]=b[c]+1;
		}
		for(i=1;i<=m;i++)
		{
			for(j=1;j<=m;j++)
			{
				if(b[i]>b[j]||b[i]==b[j]&&i<j)
				{
					s[i]=s[i]+1;
				}
			}
		}
		for(i=1;i<=m;i++)
		{
			printf("%d",m-s[i]);
		}
	}
 } 
