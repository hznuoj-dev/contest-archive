#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>

int temp(int n){
	int flag=0;
	if((n%4==0&&n%100!=0)||n%400==0) flag=1;
	return flag;
}
int main(){
	int t;
	scanf("%d",&t);
	int a,b;
	while(t--){
		int count=0;
		scanf("%d %d",&a,&b);
		int g=a+b;
		if(g>9999){
			b=9999-(g-10000);
		}
		else b=g;
		if(a>b){
			int m=a;
			a=b;
			b=m;
		}
		
		for(int i=a;i<=b;i++){
			if(temp(i)){
				count++;
			}
		}
		printf("%d\n",count);
		
	}
} 
