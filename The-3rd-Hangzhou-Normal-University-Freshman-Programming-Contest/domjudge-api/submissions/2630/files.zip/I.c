#include<time.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
#include<stdio.h>

int main()
{
	//int compar(const void  *a,const void *b);
	int weihe(long x);
	long long A,B,C,D;
	int sum=0;
	scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
	if(weihe(A)>=16 || weihe(A)==6)
		sum++;
	if(weihe(B)>=16 || weihe(B)==6)
		sum++;
	if(weihe(C)>=16 || weihe(C)==6)
		sum++;
	if(weihe(D)>=16 || weihe(D)==6)
		sum++;
	if(sum==0)
		printf("Bao Bao is so Zhai......\n");
	else if(sum==1)
		printf("Oh dear!!\n");
	else if(sum==2)
		printf("BaoBao is good!!\n");
	else if(sum==3)
	    printf("Bao Bao is a SupEr man///!\n");
	else
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}
	int weihe(long x)
	{
		int i,t=0;
		while(x>=10)
		{
			i=x%10;
			t=t+i;
			x=x/10;
		}
		t=t+x;
		return t;
	}


/*
int compar(const void  *a,const void *b)
{
	return *(int*)a-*(int*)b;
}
*/