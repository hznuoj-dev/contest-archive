#include<stdio.h>
int main(){
	int T,n,m,i;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=0;i<m;++i){
			printf("#");
		}
		for(i=m;i<n;++i){
			printf("-");
		}
		printf("] ");
		printf("%d%%\n",m*100/n);
	}

	return 0;
}
