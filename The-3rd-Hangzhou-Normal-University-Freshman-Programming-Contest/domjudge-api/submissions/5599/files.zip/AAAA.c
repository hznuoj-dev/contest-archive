#include <stdio.h>
#include <stdlib.h>
#include<math.h>
int main()
{
int i;
int num;
int n=0,x=0;
int sum=0;
int x1=0;



 for( i =0;i<4;i++){
	scanf("%d",&num);
	n = (int)log10(num) + 1;
   // printf("%d\n", n);


    for (i = 0; i < n; i++) {
    	x += (int)(num / (int)pow(10, n - i - 1)) % 10;
    }
    x1 ++;
	if(x>=16 || x == 6)sum ++;
	x = 0 ;
	if(x1 == 4)break;
 }

 if(sum ==0){
  printf("Bao Bao is so Zhai.....\n");
 }else if(sum == 1 ){
  printf("Oh dear!!.....\n");
 }else if(sum == 2 ){
  printf("BaoBao is good!!.....\n");
 }else if(sum == 3 ){
  printf("Bao Bao is a SupEr man///!.....\n");
 }else if(sum ==4 ){
  printf("Oh my God!!!!!!!!!!\n");
 }
	return 0;
}
