#include<stdio.h>
int main(void){
	char a[100];
	scanf("%s",a);
	char a1[20]={" __      _____"};
	char a2[20]={"|  | ___/ ____\\\____"};
	char a3[30]={"|  |/ /\\   __\\/ ___\\"};
	char a4[30]={"|    <  |  | \\\  \\\___"};
	char a5[30]={"|__|_ \\\ |__|  \\\___ >"};
	char a6[30]={"     \\\/           \\\/"};
	printf("%s",a1);
	printf("\n");
	printf("%s",a2);
	printf("\n");
	printf("%s",a3);
	printf("\n");
	printf("%s",a4);
	printf("\n");
	printf("%s",a5);
	printf("\n");
	printf("%s",a6);
	
     return 0;
}
