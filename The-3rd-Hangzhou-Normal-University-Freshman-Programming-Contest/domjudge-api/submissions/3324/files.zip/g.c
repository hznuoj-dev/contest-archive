#include <stdio.h>
#include <string.h>

int main(void)
{
	int t,n,m,a,b,num[1001],i,ai,bi,z;
	//int *numb[1001];
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		for(i = 0;i< n;i++)
		{
			num[i]= i+1;
			//if(i != n-1)
			//numb[i]= &num[i+1];
		}
		while(m--)
		{
			scanf("%d %d",&a,&b);
			for(i = 0;i < n;i++)
			{
				if(num[i]==a)
				{
					ai= i;
				}
				else if(num[i] == b)
				{
					bi = i;
				}
				
			}
			if(bi < ai)
			{
				
				z = a;
				for(i = ai;i >bi;i--)
				{
					num[i] = num[i-1];
				}
				num[bi]=a;
			} 
		}
		for(i = 0;i < n;i++)
		{
			if(i == 0)
			{
				printf("%d",num[i]);
			}
			else
			{
				printf(" %d",num[i]);
			}
		}
		printf("\n");
	}
	
	
	return 0;
}
