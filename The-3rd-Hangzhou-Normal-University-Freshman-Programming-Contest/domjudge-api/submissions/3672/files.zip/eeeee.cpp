#include<iostream>
#include<algorithm>
int a[102][100002],b[102],ans1[100002],ans2[100002];
using namespace std;
int main(){
	int n,m,k=0,s=0;
	cin >> n >> m;
	for (int i=1;i<=n;++i){
		cin >> a[i][1];
	}
	for (register int i=1;i<=n;++i){
		cin >> b[i];
		for(register int j=1;j<=b[i];++j) {
			a[i][j]=j*a[i][1];
		}
	}
	for (register int i=1;i<=n;++i){
		k=0;
		for (register int j=1;j<=100000;++j){
			if (ans1[j]==1) {
				k++;
				ans2[k]=j;
			}
		}
		for (register int p=0;p<=b[i];++p){
			for (register int q=0;q<=k;++q){
				if (a[i][p]+ans2[q]<=m) {
					ans1[a[i][p]+ans2[q]]=1;
				}
			}
		}
	}
	for (int i=1;i<=m;++i){
		if (ans1[i]) s++;
	}
	cout << s << endl;
    return 0;
}
