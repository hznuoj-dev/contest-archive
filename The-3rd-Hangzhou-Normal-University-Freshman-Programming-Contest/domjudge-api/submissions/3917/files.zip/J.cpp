#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int n,k,i,h,y,t,temp,j,sum;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		sum=0;
		for(i=1;i<=n;i++){
			char a[10001]={},b[10001]={};
			scanf("%s",a);
			h=0;
			for(k=0;k<=strlen(a)-1;k++){
				if(h!=0){
				for(j=0;j<=h;){
					if(b[j]!=a[k]){
						j++;
					}
					if(j=h+1&&a[k]!='.'){
                       b[h]=a[k],h+=1;
					   break;
					}
				}
				}
				else if(h==0){
					if(a[k]!='.')
						b[h]=a[k],h+=1;
				}
			}
			sum+=h;
		}
		printf("%d\n",sum);
	}
	return 0;
}
//int cmp(const void*p,const void*q){
//return((struct kx*)q)->average -(struct kx*)p)->average)
//}