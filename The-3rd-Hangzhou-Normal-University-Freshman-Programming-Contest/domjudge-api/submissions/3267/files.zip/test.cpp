#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
const int maxn=110;
int n,m,t,is,cnt,ans;
int main(){
    ios::sync_with_stdio(false);
    cout<<fixed<<setprecision(0);
    cin>>t;
	while(t--) {
        cin>>n>>m;
        cout<<"[";
        for(int i=1;i<=m;i++)cout<<"#";
        for(int i=1;i<=n-m;i++)cout<<"-";
        cout<<"] ";
        cout<<floor(m*100/n);
        cout<<"%\n";
	}
    return 0;
    //good job!
}
