#include <stdio.h>
#include <string.h>
int main()
{
	char s[3]; 
	scanf("%s",s); 
	
	printf(" __      _____       \n");
	printf("\n");
	printf("|  | ___/ ____");
	printf("\\____  \n");
	printf("\n");
	printf("|  |/ /");
	printf("\\   __\\/ ___\\ \n");
	printf("\n");
	printf("|    <  |  | \\  \\___ \n");
	printf("\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("\n");
	printf("     \\/           \\/ \n");
	printf("\n");

	
	return 0;
}
