#include<stdio.h>
int main(void){
	int t,n,m,y;
	char a='#',b='-',c='%';
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		printf("[");
		for(int i=0;i<m;++i)
		printf("#");
		y=n-m;
		for(int i=0;i<y;++i)
		printf("-");
		printf("]");
		printf(" %.0lf",(double)m/n*100);
		printf("%c\n",c);
	}
}
