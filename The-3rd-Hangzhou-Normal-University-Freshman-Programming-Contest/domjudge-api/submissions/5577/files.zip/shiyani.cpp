#include<stdio.h>
int main()
{
	long long a,b,c,d;
	int s[5],total;
	int i,j;
	j=0;
	for(i=0;i<4;i++) 
	{
		scanf("%lld",&s[i]);}
	for(i=0;i<4;i++){
		total=0;
		while(s[i]!=0)
		{
			total+=s[i]%10;
			s[i]/=10;
		}
		if(total>=16||total==6)
			j+=1;
	}
	
	switch(j)
	{
		case 1:
			printf("Oh dear!!");
			break;
		case 2:
			printf("BaoBao is good!!");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			break;
		case 0:
			printf("Bao Bao is so Zhai......");
			break;
	}
}
