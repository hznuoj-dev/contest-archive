#include<stdio.h>
#include<string.h>
int main()
{
    char str1[100];
    long long sum = 0,i,j,sum2=0;
    sum = 0; sum2 = 0;
    for (i = 1; i <= 4; i++)
    {
        gets_s(str1);
        for (j = 0; j < strlen(str1); ++j)
        {
            sum += str1[j] - '0';
        }
        if (sum == 6 || sum >= 16)
        {
            sum2 += 1;
        }
        if (sum2 == 1)
        {
            printf("Oh dear!!\n");
        }
        else if (sum2 == 0)
        {
            printf("Bao Bao is so Zhai......\n");
        }
        else if (sum2 == 2)
        {
            printf("BaoBao is good!!\n");
        }
        else if (sum2 == 3)
        {
            printf("Bao Bao is a SupEr man///!\n");
        }
        else if (sum2 == 4)
        {
            printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
        }
    }
    return 0;
}