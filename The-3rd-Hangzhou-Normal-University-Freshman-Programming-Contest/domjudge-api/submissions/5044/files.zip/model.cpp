//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 100010;

int n, m, dp[110][MAXN], vis[MAXN], tp[MAXN], num[MAXN];

int main() {

#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);

	memset(dp, 0, sizeof(dp));
	memset(vis, 0, sizeof(vis));

	int n, m, a, cnt = 0, index = 0;
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &tp[i]);
	}
	for (int i = 1; i <= n; ++i) {
		scanf("%d", &num[i]);
	}

	for (int i = 1; i <= n; ++i) {
		for (int k = 0; k <= num[i]; ++k) {
			for (int j = m; j >= k * tp[i]; --j) {
				if (dp[i][j] <= dp[i - 1][j - k * tp[i]] + k * tp[i]) {
					dp[i][j] = dp[i - 1][j - k * tp[i]] + k * tp[i];
				}
//				printf("dp[%d][%d]=%d\n",i, j, dp[i][j]);
				if (dp[i][j] <= m && dp[i][j] > 0 && vis[dp[i][j]] == 0) {
					vis[dp[i][j]] = 1;
					cnt++;
				}
			}
		}
	}
//	for (int i = 1; i <= m; ++i) {
////		printf("%d ", dp[i][]);
//		if (vis[i] == 1) cnt++;
//	}
	printf("%d\n", cnt);

	return 0;
}
