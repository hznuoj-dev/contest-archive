#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t)
	{
		int count=0;
		int y,a;
		cin>>y>>a;
		if(y+a>=10000)
		{
			a=9999-(y+a-10000);
		}
		else 
		{
			a=y+a;
		}
		int i=fmin(a,y);
		while(i<=fmax(a,y))
		{
			if(i%4==0&&i%100!=0||i%400==0)count++;
			i++;
		}
		cout<<count;
		if(--t) cout<<endl;
	}
}
