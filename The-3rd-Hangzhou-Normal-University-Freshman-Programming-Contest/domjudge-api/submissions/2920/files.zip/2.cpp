#include<stdio.h>
int main()
{
	char str1;
	scanf("%s",&str1);
	puts(" _ _        _ _ _ _ _");
	printf("\n");
	puts("|   | _ _ _/ _ _ _ _ \\_ _ _ _");
	printf("\n");
	puts("|   |/   /\\    _ _ \\/   _ _ _ \\ ");
	printf("\n");
	puts("|      <   |   |  \\    \\_ _ _");
	printf("\n");
	puts("|_ _|_  \\  |_ _|    \\_ _ _    >");
	printf("\n");
	puts("       \\/                \\/");
	
	
	
	
}
