#include<stdio.h>
int main()
{
    char k[3];
    scanf("%s",k);
    if(k[0]=='k'&&k[1]=='f'&k[2]=='c')
    {
        puts(" __      _____");
        puts("|  | ___/ ____\\____");
        puts("|  |/ /\\   __\\/ ___\\");
        puts("|    <  |  | \\  \\___");
        puts("|__|_ \\ |__|  \\___  >");
        puts("     \\/           \\/");
    }
    return 0;
}
