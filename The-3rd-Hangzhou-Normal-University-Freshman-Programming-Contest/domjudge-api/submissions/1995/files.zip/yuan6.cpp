#include<cstdio>
#include<algorithm>
using namespace std;
#include<string>
char a[100001];
int main(){
	int t, n, i, b[222];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int rubi=0;
		for(i=0;i<n;i++){
			for(int j=0;j<222;j++)b[j]=0;
			scanf("%s",a);
			for(int j=0;j<strlen(a);j++){
				if(a[j]!='.'){
					b[a[j]]++;
				}
			}
			for(int k=0;k<222;k++){
				if(b[k]!=0)rubi++;
			}
		}
		printf("%d\n",rubi);
	}
}
