import java.util.ArrayList;
import java.util.Scanner;

public class H {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        ArrayList<String> list = new ArrayList<>();
        int t=in.nextInt();
        for (int i = 0; i < t; i++) {
            int n=in.nextInt(),m=in.nextInt();
            System.out.print("[");
            for (int j = 1; j <= n; j++) {
                if(j<=m){
                    System.out.print("#");
                }else {
                    System.out.print("-");
                }
            }
            int p= (int)((double)m/(double)n*100);
            System.out.println("] "+p+"%");
        }
    }
}
