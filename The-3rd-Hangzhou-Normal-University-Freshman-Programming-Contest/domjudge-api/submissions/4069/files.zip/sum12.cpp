#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main(void)
{
	long long i,j,l,k,q,e=1;
	char c,a[1000000],b[1000000];
	int t,n,p=0,sum=0;
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		scanf("%d",&n);
		for(j=1;j<=n;j++)
		{
			scanf("%s",b);
			l=strlen(b);
			for(q=0;q<l;q++)
			{
				c=b[q];
				if(c!='.')
				{
					for(k=1;k<e;k++)
					{
						if(c==a[k])
						{
							p=1;
						}
					}
					if(p==0)
					{
						a[e]=c;
						e++;
					}
					p=0;	
				}
			}
			sum=sum+e-1;
			e=1;
		}
		printf("%lld",sum);
		if(i<t)
		{
			printf("\n");
		}
		sum=0;
	}	
	return 0;
}


