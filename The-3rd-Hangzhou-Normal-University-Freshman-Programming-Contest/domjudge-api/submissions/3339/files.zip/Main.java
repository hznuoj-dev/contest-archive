import java.util.*;
public class Main
{
    public static void main(String[] args) 
    {
    	Scanner s=new Scanner (System.in);
		while (s.hasNext())
		{
			long a=s.nextLong();
			long b=s.nextLong();
			long c=s.nextLong();
			long d=s.nextLong();
			int g=0;
			if (a>=16||a==6)g++;
			if (b>=16||b==6)g++;
			if (c>=16||c==6)g++;
			if (d>=16||d==6)g++;
			if (g==0)System.out.println("Bao Bao is so Zhai......");
			else if (g==1)System.out.println("Oh dear!!");
			else if (g==2)System.out.println("BaoBao is good!!");
			else if (g==3)System.out.println("Bao Bao is a SupEr man///!");
			else if (g==4)System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		}
      
    }
}