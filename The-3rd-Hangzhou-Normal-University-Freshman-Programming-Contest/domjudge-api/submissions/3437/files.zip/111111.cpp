#include<stdio.h>
#include<string.h>
int main(void)
{
	int T,n,m,i,j,t;
	int k;
	scanf("%d",&T);
	for(t=1;t<=T;t++)
	{
		scanf("%d %d",&n,&m);
		k=100.0*m/n;
		printf("[");
		for(i=1;i<=m;i++)
		{
			printf("#");
		}
		for(j=n-m+1;i<=n;i++)
		{
			printf("-");
		}
		printf("]");
		printf(" %d%%\n",k);
	}
	return 0;
}
