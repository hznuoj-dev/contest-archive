#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996)
int main()
{
	double a,b,d;
	int i,c;
	scanf("%d",&c);
	while(c--)
	{
		scanf("%lf%lf",&a,&b);
		printf("[");
		for(i=1;i<=b;i++)
		{
			printf("#");
		}
		for(i=1;i<=a-b;i++)
		{
			printf("-");
		}
		d=(b/a)*100.0;
		printf("] %.0lf%%\n",d);
	}
	return 0;
}
