#include<stdio.h>
#include<math.h>
int main(void){
	int a,b,c,d,e,f,g,h,i,j=1;
	scanf("%d",&a);
	while(a--){
		scanf("%d %d",&b,&c);
		if(b+c<=9999){d=b+c;}
		else if(b+c>9999){e=b+c-9999;d=9999-e;}
		if(d<b){
			f=d;d=b;b=f;
		}
		h=b-b%4;i=d-d%4;g=(i-h)/4;
		if(b%4==0){g=g+1;}
        while(j<10000){
        	if(j%100==0&&j%400!=0){
        		if(b<=j&&d>=j){g=g-1;}
			}
			j=j+1;	    
		}
		printf("%d\n",g);
		j=0;
	}
	return 0;
} 
