#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
const int MAX=1e6+5;
char str[MAX];
map <char,int>mp;
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int cnt=0;
		int n;
		scanf("%d",&n);
		while(n--)
		{
			mp.clear();
			scanf("%s",str);
			for(int i=0;i<strlen(str);i++)
			{
				if(str[i]!='.')
					mp[str[i]]++;
			}
			for(auto it=mp.begin();it!=mp.end();it++)
			{
				cnt++;
			}
		}
		printf("%d\n",cnt);
	}
	return 0;
}

