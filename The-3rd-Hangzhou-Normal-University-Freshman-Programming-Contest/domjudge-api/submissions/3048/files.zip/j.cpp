#include <stdio.h> 
#include <string.h> 
int main(void){
	int t,n,i,len,sum;
	int a[100];
	char s[1000000];
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d",&n);
		while(n--){
			scanf("%s",s);
			len=strlen(s);
			for(i=0;i<100;i++){
				a[i]=0;
		    }
			for(i=0;i<len;i++){
				if(s[i]=='.')a[s[i]]++;
			}
			for(i=0;i<100;i++){
				if(a[i]!=0)sum++;
		    }
		}
		printf("%d\n",sum);
	}
	return 0;
}
 
