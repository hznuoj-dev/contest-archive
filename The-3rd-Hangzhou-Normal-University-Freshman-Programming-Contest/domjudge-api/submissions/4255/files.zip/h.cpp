#include<stdio.h>
int main()
{
	int t,i,j;
	int m,n;
	float c;
	int h;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&m,&n);
		c=(n*1.0/m*1.0)*100;
		printf("[");
		for(i=1;i<=n;i++){
		printf("#");
	}
		for(j=n+1;j<=m;j++){
			printf("-");
		}
			printf("]");
			h=c;
		printf(" %d%%\n",h);
	} 
}
