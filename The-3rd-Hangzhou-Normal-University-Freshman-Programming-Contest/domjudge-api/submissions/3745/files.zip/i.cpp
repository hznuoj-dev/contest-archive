#include<stdio.h>
int main(){
int t;
scanf("%d",&t);
int a,b;
int i,j;
while(t--){
scanf("%d  %d",&a,&b);
printf("[");
for(i=1;i<=b;i++){
	printf("#");
}
for(j=b+1;j<=a;j++){
	printf("-");
}
printf("] ");
printf("%d%%\n",b*100/a);
}
return 0;
}

