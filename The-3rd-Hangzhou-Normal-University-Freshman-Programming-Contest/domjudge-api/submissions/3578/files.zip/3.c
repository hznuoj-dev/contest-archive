#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(){
	int t,n,m,i,z;
	
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&m,&n);
		printf("[");
		for(i=0;i<n;i++){
			printf("#");
		}
		for(i=0;i<m-n;i++){
			printf("-");
		}
		printf("] ");
		z=(n*1.0/m)*100;
		printf("%d",z);
		char a[1]={"%"};
	printf("%c",a[0]);
		printf("\n");
		
	}
}

