#pragma warning (disable:4996)
#include<stdio.h>
#include<string.h>
int main(void) {
	int  i, j, m, n,jj,u,k,p;
	int flag,sum,max=0;
	int a[100001];
	int b[100001] = { 0 };
	scanf("%d %d", &n, &m);
	for (i = 1; i <= n; i++) 
		scanf("%d", &a[i]);
	for (i = 1; i <= n; i++) {
		scanf("%d", &j);
		b[i] = j;
		max += a[i] * j;
	}
	for (i = 1; i < n; i++) {
		k = i;
		for (j = i + 1; j <= n; j++) {
			if (a[j] < a[k])
				k = j;
		}
		if (k != i) {
			p = a[k], a[k] = a[i], a[i] = p;
			p = b[k], b[k] = b[i], b[i] = p;
		}
	}
	sum = 0;
	for (j = 1; j <= m; j++) {
		p = j;
		flag = 0;
		jj = n;
		k = b[jj];
		while (p > 0 && jj>0) {
			if (b[jj] == 0) {
				b[jj] = k;
				jj--;
				k = b[jj];
			}
			else if (p >= a[jj]) {
				p -=a[jj];
				b[jj]--;
			}
			else {
				b[jj] = k;
				jj--;
				k = b[jj];
			}
		}
		b[jj] = k;
		if (p == 0)
			flag = 1;
		else {
			u = max - j;
			flag = 0;
			jj = n;
			k = b[jj];
			while (u > 0 && jj > 0) {
				if (b[jj] == 0) {
					b[jj] = k;
					jj--;
					k = b[jj];
				}
				else if (u >= a[jj]) {
					u -= a[jj];
					b[jj]--;
				}
				else {
					b[jj] = k;
					jj--;
					k = b[jj];
				}
			}
			if (u == 0)
				flag = 1;
		}
		if (flag) {
			sum++;
		}
	}
	printf("%d\n", sum);
	return 0;
}