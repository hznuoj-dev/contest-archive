import java.util.*;
public class Main
{
    public static void main(String[] args) 
    {
    	Scanner s=new Scanner (System.in);
		while (s.hasNext())
		{
			int n=s.nextInt();
			for (int x=1;x<=n;x++)
			{
				int a=s.nextInt();
				int b=s.nextInt();
				StringBuffer ans=new StringBuffer("[");
				for (int i=1;i<=a;i++)
				{
					if (i<=b)
						ans=ans.append("#");
					else
						ans=ans.append("-");
				}
				System.out.println(ans+"] "+(b*100/a)+"%\n");
			}
		}
    }
}