#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	char str[]="kfc";
scanf("%s",&str);
printf(" __      _____\n");
printf("\|  \| ___\/ ____\\____\n");
printf("\|  \|\/ \/\\   __\\\/ ___\\\ \n");
printf("\|    <  \|  \| \\  \\___ \n");
printf("\|__\|_ \\ \|__\|  \\___  > \n");
printf("     \\\/          \\\/ \n");
	return 0;
}








