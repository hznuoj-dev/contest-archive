import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int count=0;
			for(int i=1;i<=4;i++)
			{
				String shuru=sc.next();
				int sum=0;
				for(int j=0;j<shuru.length();j++)
				{
					sum=sum+Integer.parseInt(shuru.substring(j,j+1));
				}
				if(sum==6||sum>=16) count++;
			}
			if(count==1)System.out.println("Oh dear!!");
			if(count==2)System.out.println("BaoBao is good!!");
			if(count==3)System.out.println("Bao Bao is a SupEr man///!");
			if(count==4)System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			if(count==0)System.out.println("Bao Bao is so Zhai......");
		}
	}
}
