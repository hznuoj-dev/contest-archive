#include<cstdio>
#include<algorithm>
#include<cstring>
using namespace std;
struct info{
	int how;
	int num;
	int n0;
}yingbi[111];
bool cmp(info x, info y){
	return x.how-y.how;
}
char a[10000][11];
int main (){
	int t, len;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		scanf("%s",a[i]);
	}
	printf("%d",t*strlen(a[0]));
}