#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int solve(int l,int r);
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int y,a;
		int dis;
		scanf("%d%d",&y,&a);
		if(y+a>=10000){
			dis=y+a-9999;
		}
		else{
			dis=a;
		}
		printf("%d\n",solve(y,y+dis));
	}
	return 0;
}
int solve(int l,int r)
{
	int ans=0;
	if(l>r){
		int tmp;
		tmp=l;
		l=r;
		r=tmp;
	}
	for(int i=l;i<=r;i++){
		if(i%4==0&&i%100!=0||i%400==0)
		ans++;
	}
	return ans;
}
