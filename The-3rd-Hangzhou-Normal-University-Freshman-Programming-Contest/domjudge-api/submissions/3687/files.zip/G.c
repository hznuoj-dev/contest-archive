#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int t,i,n,m,a[1001],x,y,tmp;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		for(i=1;i<=1001;i++){
			a[i]=i;
		}
		for(i=0;i<m;i++){
			scanf("%d %d",&x,&y);
			if(a[x]>a[y]){
				tmp=a[x];a[x]=a[y];a[y]=tmp;
			}
		}
		for(i=1;i<=n-1;i++){
			printf("%d ",a[i]);	
		}
		printf("%d\n",a[n]);
	}
}
