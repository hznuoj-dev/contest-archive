#include<stdio.h>
int rn(int x) {
	if ((x % 4 == 0 && x % 100 != 0) || x % 400 == 0)
		return 1;
	return 0;
}
int main() {
	int t,sum;
	scanf("%d", &t);
	while (t--) {
		sum = 0;
		int a1, b,c,a2;
		scanf("%d%d", &a1, &b);
		c = a1 + b;
		if (c > 9999) {
			c -= 9999;
			a2 = 9999 - c;
		}
		else
			a2 = c;
		if (a2 < a1) {
			c = a1;
			a1 = a2;
			a2 = c;
		}
		int i;
		for (i = a1;i <= a2;i++) {
			if (rn(i)) {
				sum++;
			}
		}
		printf("%d\n", sum);
	}
}
