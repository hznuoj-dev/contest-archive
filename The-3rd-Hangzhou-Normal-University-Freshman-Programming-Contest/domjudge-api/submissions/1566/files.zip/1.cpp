#include<stdio.h>
int main(){
	int T,a,b,r,yu,t,x=0;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&a,&r);
		b=a+r;
		if(b>9999){
			yu=10000-b;
			b=9999-yu;
		}
		if(a>b){
			t=a;
			a=b;
			b=t;
		}
		for(;a<=b;a++){
			if(a%4==0&&a%100!=0||a%400==0) x=x+1;
		}
		printf("%d\n",x);
		x=0;
	} 
} 
