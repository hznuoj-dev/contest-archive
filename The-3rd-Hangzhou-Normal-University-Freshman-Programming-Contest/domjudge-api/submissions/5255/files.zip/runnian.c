#include"stdio.h"
int year(int b,int c){
int i;
int d=0; 
for(i=b;i<=c;++i)
	{
		if((i%4==0&&i%100!=0)||(i%400==0)){
		++d;
		i=i+3;
		}
	}
return d;	
}
int main()
{
int a;
if(scanf("%d",&a)){
while(a--)
{
	int b,c;
	if(scanf("%d%d",&b,&c)){
	if(b<=c){
	c=9999-(c-9999);
	printf("%d\n",year(b,c));
	} 
	else
	{
	c=b+c;
	if(b<=c){
	c=9999-(c-9999);
	if(c>b){	
	int t=0;
		t=c;
		c=b;
		b=t;
	}
	printf("%d\n",year(b,c));
	} 
	else
	{
		int t=0;
		t=c;
		c=b;
		b=t;
	c=9999-(c-9999);
	printf("%d\n",year(b,c));
	}
	}
}
}
}
return 0;
}
