#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<set>
#include<map>
#include<iostream>
#include<string>
#include<queue>
using namespace std;
typedef long long int ll;
const int N=1e5+100;
int main(){
	int n;
	scanf("%d",&n);
	int ans=0;
	for(int i=1;i<=n;i++){
		string a;
		cin>>a;
		ans+=a.length();
	}
	printf("%d\n",ans);
}

