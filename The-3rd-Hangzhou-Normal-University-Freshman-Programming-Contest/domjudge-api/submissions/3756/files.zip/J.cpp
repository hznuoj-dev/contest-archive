#include<cstdio>
#include<vector>
#include<set>
using namespace std; 
int main(void){
	int T,n;
	char s[1000005];
	scanf("%d",&T);
	while(T--){
		int cnt=0;
		scanf("%d",&n);
		getchar();
		set<char>b;
		for(int i=1;i<=n;i++){
			scanf("%s",s);
			for(int j=0;s[j]!='\0';j++){
				if(s[j]!='.'){
					b.insert(s[j]);
				}
			}
			for(set<char>::iterator i=b.begin();i!=b.end();i++)
		    cnt++;
		    b.clear();
		}
		printf("%d\n",cnt);
	}
	return 0;
}
