#include<stdio.h>
int main(void)
{
	printf(" _      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n\\n|    <  |  | \\  \\___\n\\n|__|_ \\ |__|  \\___  >\n\\n     \\/           \\/\n");
	return 0;
}
