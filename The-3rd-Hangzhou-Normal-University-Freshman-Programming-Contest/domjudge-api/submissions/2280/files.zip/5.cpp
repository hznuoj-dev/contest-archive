#include <stdio.h>
#include <string.h>
int main(){
	int t;
	scanf("%d", &t);
	while(t--){
		int n, sum=0, i, j, k, l, flag=0;
		scanf("%d", &n);
		while(n--){
			char a[100001];
			scanf("%s", a);
			l=strlen(a);
			for(j=0;j<l;j++){
				if(a[j]!='.'){
					flag=0;
					for(k=0;k<j;k++){
						if(a[k]==a[j]){
							flag=1;
							break;
						}
					}
					if(flag==0){
						sum++;
					}
				}
			}
		}
		printf("%d\n", sum);
	}
}





























