#include<stdio.h>
int main(){
	int n;
	int a,b;
	int c;
	float j;
	scanf("%d",&n);
	for(int N=1;N<=n;N++){
		scanf("%d %d",&a,&b);
		j=a;
		if(b!=0)c=(b/j)*100;
		if(b==0)c=0;
		printf("["); 
		for(int B=1;B<=b;B++){
			printf("#");
		}
		for(int A=1;A<=a-b;A++){
			printf("_");
		}
		printf("]");
	    printf(" %d",c);
	    printf("%%\n");
	}
}
