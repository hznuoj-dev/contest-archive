#include<stdio.h>
int main()
{
	int t,i;
	double a,b,c;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lf %lf",&a,&b);
		printf("[");
		for(i=1;i<=b;++i)
		{
			printf("#");
		}
		for(i=1;i<=a-b;++i)
		{
			printf("-");
		}
		printf("] ");
		c=(b/a)*100;
		printf("%d",(int)c);
		printf("%c\n",37);
	}
	return 0;
}
