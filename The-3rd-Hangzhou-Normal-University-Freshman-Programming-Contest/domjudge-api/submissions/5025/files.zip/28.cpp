#include<stdio.h>
int main(){
	int i,j,s,l,t,m,n;
	double p;
	char ch='%';
	scanf("%d",&t);
	for(i=1;i<=t;++i){
		scanf("%d%d",&m,&n);
		p=n*1.0/m;
		printf("[");
		for(j=0;j<n;++j){
			printf("#");
		}
		for(j=0;j<m-n;++j){
			printf("-");
		}
		printf("] ");
		printf("%.0f",p*100);
		printf("%c",ch);
		printf("\n");
	}
	return 0;
}

