#include<stdio.h>
int main()
{
	int a,b,c,d,sum=0,t=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	while(a!=0)
	{
		t=t+a%10;
		a/=10;
	}
	if(t>=16||t==6)
	sum++;
	t=0;
	while(b!=0)
	{
		t=t+b%10;
		b/=10;
	}
	if(t>=16||t==6)
	sum++;
	t=0;
	while(c!=0)
	{
		t=t+c%10;
		c/=10;
	}
	if(t>=16||t==6)
	sum++;
	t=0;
	while(d!=0)
	{
		t=t+d%10;
		d/=10;
	}
	if(t>=16||t==6)
	sum++;
	if(sum==1)
	printf("Oh dear!!\n");
	else if(sum==2)
	printf("BaoBao is good!!\n");
	else if(sum==3)
	printf("Bao Bao is a SupEr man///!\n");
	else if(sum==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	else if(sum==0)
	printf("Bao Bao is so Zhai......\n");
	
}
