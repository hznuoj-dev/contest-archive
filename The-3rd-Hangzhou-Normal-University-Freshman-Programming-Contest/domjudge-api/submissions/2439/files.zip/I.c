#include<stdio.h>
#include<string.h>
int judge(char x[20])//ȷ��ÿ��λ��ӵĺ�
{
	int sum = 0;
	int len = strlen(x);
	int i;
	for (i = 1; i <= len; i++)
	{
		sum += x[i] - '0';
	}
	printf("%d", sum);
	return sum;
}
int main()
{
	char a[20], b[20], c[20], d[20];
	scanf("%s%s%s%s", &a, &b, &c, &d);
	int x[4];
	int skt = 0;
	x[0] = judge(a); x[1] = judge(b); x[2] = judge(c); x[3] = judge(d);
	for (int i = 0; i < 4; i++)
	{
		if (x[i] >= 16 || x[i] == 6)
			skt++;
	}
	switch (skt)
	{
		case 0; printf("Bao Bao is so Zhai......"); break;
			case 1; printf("Oh dear!!"); break;
				case 2; printf("BaoBao is good!!"); break;
					case 3; printf("Bao Bao is a SupEr man///!"); break;
						case 4; printf("Oh my God!!!!!!!!!!!!!!!!!!!!!"); break;
	}
	return 0;
}