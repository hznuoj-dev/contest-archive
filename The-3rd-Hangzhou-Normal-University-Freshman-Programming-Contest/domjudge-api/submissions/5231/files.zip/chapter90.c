#include <stdio.h>
int main(void) {
	int t, n, m, i, j;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &n, &m);
		printf("[");
		for (i = 0; i < m; i++) {
			printf("#");
		}
		for (i = m; i < n; i++) {
			printf("-");
		}
		printf("] ");
		if (m == 0) {
			printf("%d%%\n", m);
		}
		else {
			printf("%d%%\n", m*100/n);
		}
	}
}