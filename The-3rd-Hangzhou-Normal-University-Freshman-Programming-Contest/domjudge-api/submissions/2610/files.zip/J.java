import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int n=sc.nextInt();
			for(int i=1;i<=n;i++)
			{
				int a=sc.nextInt();
				int count=0;
				for(int j=1;j<=a;j++)
				{
					String s=sc.next().replace(".","");
					while(s.length()>0)
					{
						s=s.replace(s.substring(0,1),"");
						count++;
					}
				}
				System.out.println(count);
			}
		}
	}
	
}
