#include<stdio.h>
int main(){
	long long a[4];
	int t=0,i,sum;
	for(i=1;i<=4;i++){
		sum=0;
		scanf("%d",&a[i]);
		while(a[i]>0){
			sum=sum+a[i]%10;
			a[i]=a[i]/10;
		}
		if(sum>=16||sum==6){
			t=t+1;
		}
	}
	switch(t){
		case 0:printf("Bao Bao is so Zhai......");
		break;
		case 1:printf("Oh dear!!");
		break;
		case 2:printf("BaoBao is good!!");
		break;
		case 3:printf("Bao Bao is a SupEr man///!");
		break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		break;
	}
}
