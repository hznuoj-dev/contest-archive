#include<bits/stdc++.h>
using namespace std;
int main(){
	int cnt=0;
	string s;
	for(int i=0;i<4;i++){
		cin>>s;
		int sum=0,n=s.size();
		for(int j=0;j<n;j++){
			sum+=s[j]-48;
			if(sum>=16) break;
		}
		if(sum>=16||sum==6) cnt++;
	}
	if(cnt==0) printf("Bao Bao is so Zhai......");
	else if(cnt==1) printf("Oh dear!!");
	else if(cnt==2) printf("BaoBao is good!!");
	else if(cnt==3) printf("Bao Bao is a SupEr man///!");
	else printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}
