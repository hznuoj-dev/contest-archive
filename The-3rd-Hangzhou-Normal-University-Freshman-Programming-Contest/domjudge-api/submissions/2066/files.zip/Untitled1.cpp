#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
using namespace std;

int main(){
	int t;
	int a,b,i;
	double s=0.0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		printf("[");
		for(i=1;i<=b;i++)printf("#");
		for(i=1;i<=a-b;i++)printf("-");
		printf("] ");
		s=(b*1.0)/(a*1.0)*100;
		printf("%.0f%\n",s);
	}
} 

