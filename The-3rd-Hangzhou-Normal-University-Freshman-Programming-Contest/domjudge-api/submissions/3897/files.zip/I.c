#include<stdio.h>
int main(void){
	int nm[100];
	int num=0;
	int i;
	unsigned long long a,b,c,d;
	scanf("%llu%llu%llu%llu",&a,&b,&c,&d);
	nm[0]=nm[1]=nm[2]=nm[3]=0;
	while(1){
		nm[0]=nm[0]+a%10;
		a=a/10;
		if(a==0){
			break;
		}
	}
	while(1){
		nm[1]=nm[1]+b%10;
		b=b/10;
		if(b==0){
			break;
		}	
	}
	while(1){
		nm[2]=nm[2]+c%10;
		c=c/10;
		if(c==0){
			break;
	}
}
	while(1){
		nm[3]=nm[3]+d%10;
		d=d/10;
		if(d==0){
			break;
		}
	}
	for(i=0;i<4;i++){
		if(nm[i]>16||nm[i]==16||nm[i]==6){
			num++;
		}
	}
	if (num==0){
		printf("Bao Bao is so Zhai......");
	}
	if (num==1){
		printf("Oh dear!!");
	}
	if(num==2){
		printf("BaoBao is good!!");
	}
	if(num==3){
		printf("Bao Bao is a SupEr man///!");
	}
	if(num==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
}


 
