#include<stdio.h>
int main()
{
	int t,year,n,i,m;
	scanf("%d",&t);
	while(t--)
	{
		int sum=0;
		scanf("%d%d",&year,&n);
		m=year+n;
		for(i=(m<year?m:year);i<(m<year?year:m);++i)
		{
			if(i>0&&(i%4==0&&i%100!=0)||i%400==0)
			sum++;
			if(i<0&&(i%4==1||i%400==1))
			sum++;
		}
		printf("%d\n",sum);
	}
}


