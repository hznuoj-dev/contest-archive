#include<stdio.h>
#include<string.h>
int main(){
	char s[100];
	scanf("%s",s);
	if(strcmp(s,"kfc")==0){
		printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\");printf("\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("  \\/           \\/");
	}
	return 0;
}
