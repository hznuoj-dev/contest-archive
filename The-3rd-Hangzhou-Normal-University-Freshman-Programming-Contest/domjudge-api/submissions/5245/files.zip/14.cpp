#include<stdio.h>
int main()
{
	int t,n,m,i,j;	double x;	scanf("%d",&t);	while(t--)	{		scanf("%d %d",&n,&m);		printf("[");		for(i=0;i<m;++i)		{			printf("#");		}		for(j=0;j<n-m			;++j)		{			printf("-");		}		x=double(m)/double(n)*100;		printf("] %d%%\n",int(x));	}}
