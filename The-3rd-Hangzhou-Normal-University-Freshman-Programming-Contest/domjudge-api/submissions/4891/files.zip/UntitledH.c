#include<stdio.h>
#define N 10
int main()
{
	int t,x[N],y[N],i,j;
	scanf("%d",&t);
	for (i=0;i<t;i++)
	{
		scanf("%d%d",&x[i],&y[i]);
	}
	for (i=0;i<t;i++)
	{
		printf("[");
		for (j=0;j<y[i];j++) printf("#");
		for (j=0;j<x[i]-y[i];j++) printf("-");
		printf("] %d%%\n", 100*y[i]/x[i]);
	}
}
