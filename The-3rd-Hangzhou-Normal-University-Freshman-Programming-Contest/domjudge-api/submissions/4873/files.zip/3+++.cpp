#include<bits/stdc++.h>
using namespace std;
int main()
{
	char a[20];
	int cnt=0,n;
	for(int i=1;i<=4;i++){
		double sum=0;
		cin>>a;
		n=strlen(a);
		for(int j=0;j<n;j++){
			sum+=a[j]-'0';
		}
		if(sum>=16||sum==6){
			cnt++;
		}
	}
	if(cnt==1){
		printf("Oh dear!!");
	}
	if(cnt==2){
		printf("BaoBao is good!!");
	}
	if(cnt==3){
		printf("Bao Bao is a SupEr man///!");
	}
	if(cnt==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	if(cnt==0){
		printf("Bao Bao is so Zhai......");
	}
	return 0;
 } 
