#include<stdio.h>
int main(){
	int t,y,a,i,j;
	
	scanf("%d",&t); 
	for(i=1;i<=t;i++){
		int x=0;
		scanf("%d %d",&y,&a);
		if(a<0){
			for(j=y+a;j<=y;j++){
				if((j%4==0&&j%100!=0)||j%400==0){
					x++;
				}
			}
		}
		else{
			for(j=y;j<=y+a-1;j++){
				if((j%4==0&&j%100!=0)||j%400==0){
					x++;
				}
			}
		}
		printf("%d\n",x);
	}
	return 0;
}
