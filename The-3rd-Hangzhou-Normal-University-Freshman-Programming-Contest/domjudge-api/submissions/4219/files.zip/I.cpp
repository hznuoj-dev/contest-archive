#include<stdio.h>
int main(void){
	char A[20];
	int cnt=0;
	for(int i=0;i<=3;i++){
          int sum=0;
          scanf("%s",A);
          for(int j=0;A[j]!='\0';j++){
		  sum+=A[j]-'0';
		  
		  if(sum==6||sum>=16) cnt++;
	}
}
	if(cnt==1) printf("Oh dear!!");
	else if(cnt==2) printf("��BaoBao is good!!");
	else if(cnt==3) printf("Bao Bao is a SupEr man///");
	else if(cnt==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else printf("Bao Bao is so Zhai......");
	
	return 0;
} 
