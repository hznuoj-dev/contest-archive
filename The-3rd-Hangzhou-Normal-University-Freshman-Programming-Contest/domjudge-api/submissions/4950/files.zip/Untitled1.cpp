#include<stdio.h>
int main()
{
	long long int a,b,c,d,ret1=0,ret2=0,ret3=0,ret4=0,h,i,j,k;
	long long int dight=0,sum=0,e,f,g,count=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	do
	{
		dight=a%10;
		ret1=ret1*10+dight;
		a/=10;
	}while(a);
	do
	{
		h=ret1%10;
		sum+=h;
		ret1/=10;
	}while(ret1);
	if(sum>=16||sum==6)
	count++;
	sum=0;
	do
	{
		e=b%10;
	ret2=ret2*10+e;
		b/=10;
	}while(b);
	do
	{
		i=ret2%10;
		sum+=i;
		ret2/=10;
	}while(ret2);
	if(sum>=16||sum==6)
	count++;
	sum=0;
	do
	{
    	f=c%10;
	ret3=ret3*10+f;
		c/=10;
	}while(c);
	do
	{
		j=ret3%10;
		sum+=j;
		ret3/=10;
	}while(ret3);
	if(sum>=16||sum==6)
	count++;
	sum=0;
	do
	{
		g=d%10;
		ret4=ret4*10+g;
		d/=10;
	}while(d);
	do
	{
		k=ret4%10;
		sum+=k;
		ret4/=10;
	}while(ret4);
	if(sum>=16||sum==6)
{
	count++;
}
	if(count==0)
	printf("Bao Bao is so Zhai......");
	if(count==1)
	printf("Oh dear!!");
	if(count==2)
	printf("BaoBao is good!!");
	if(count==3)
	printf("Bao Bao is a SupEr man///!");
	if(count==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}

