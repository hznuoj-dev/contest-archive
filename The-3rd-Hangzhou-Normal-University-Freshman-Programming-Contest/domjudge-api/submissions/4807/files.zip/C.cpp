#include<iostream>
#include<vector>
#include<algorithm>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug cout<<"What fuck!"<<endl
typedef long long ll;
using namespace std;
const int mod=998244353;
const int maxn=1e5+10;
ll a[maxn];
vector<ll>vec;
int main(){
	fcio;
	ll n;
	while(cin>>n){
		vec.clear();
		for(ll i=1;i<=n;++i){
			cin>>a[i];
		}
		sort(a+1,a+1+n);
		ll num=1;
		ll ans=1;
		for(ll i=1;i<=n;++i){
			if(a[i]==a[i+1]){
				num++;
			}
			else{
				vec.push_back(num);
				num=1;
			}
		}
//		debug;
//		for(ll i=0;i<vec.size();++i){
//			cout<<vec[i]<<" ";
//		}
//		cout<<endl;
//		debug;
		if(vec.size()<=2)cout<<1<<endl;
		else{
			for(ll i=2;i<vec.size();++i){
				if(vec[i-1]==1)continue;
				ans=((ans%mod)*(vec[i-1]%mod)*(vec[i]%mod))%mod;
			}	
			cout<<ans%mod<<endl;
		}
	}
}

