#include<stdio.h>
#include<string.h>
int main(){
	int T,n,i,j,flag,t,sum;
	char s[1000002];
	scanf("%d",&T);
	while(T--)
	{sum=0;
		scanf("%d",&n);
		while(n--){
			scanf("%s",s);
			t=0;
			for(i=0;i<strlen(s);i++){
					flag=0;
				if(s[i]!='.'){
					flag=1;
					for(j=0;j<i;j++){
						if(s[j]==s[i]){
							flag=0;
							break;
						}
					}
					if(flag==1)
					t++;
				}
			}
			sum+=t;
		}
		printf("%d\n",sum);
	}
}
