#include<bits/stdc++.h>
using namespace std;
int main(){
	int m=4;
	int n=0;
	int cnt=0;
	while(m--){
	n=0;
	char s[19];
	scanf("%s",s);
	int len=strlen(s);
	for(int i=0;i<len;i++)
	{
		n+=s[i]-'0';
	}
	if(n>=16||n==6)cnt++;
	}
	switch(cnt){
		case 1:
			cout<<"��Oh dear!!"<<endl;
			break;
		case 0:
			cout<<"Bao Bao is so Zhai......"<<endl;
			break;
		case 2:
			cout<<"BaoBao is good!!"<<endl;
			break;
		case 3:
			cout<<"��Bao Bao is a SupEr man///!"<<endl;
		case 4:
			cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;
			break;
	}
	
	return 0;
} 
