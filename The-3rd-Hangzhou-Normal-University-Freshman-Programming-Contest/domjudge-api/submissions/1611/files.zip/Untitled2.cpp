#include<stdio.h>
int main(){
	int n,t,i;
	int a,b,sum;
	scanf("%d",&n);
	while(n--){
		sum=0;
		scanf("%d%d",&a,&b);
		b=a+b;
		if(b>9999){
			b=9999-(b-9999);
		}
		if(a>b){
			t=a;
			a=b;
			b=t;
		}
		for(i=a;i<=b;i++){
			if(i==0){
				continue;
			}
			if(i%4==0&&i%100!=0||i%400==0){
				sum++;
			}
		}
		printf("%d\n",sum);
	}
}
