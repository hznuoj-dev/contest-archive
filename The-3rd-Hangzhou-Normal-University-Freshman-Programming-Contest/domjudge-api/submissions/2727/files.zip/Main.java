package ft;

import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner a = new Scanner(System.in);
		while (a.hasNext())
		{
			int c= a.nextInt();
			int x=0;
			int y=0;
			int n=0;
			int r=0;
			while (c-- > 0)
			{
				r=0;
				x =a.nextInt();
				y = a.nextInt();
				n = 0;
				if (x + y >= 10000)
				{
					n = 9999 - ((x + y) - 9999);
					if (x < n)
					{
						for (int i = x; i <= n; i++)
						{
							if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
							{
								r = r + 1;
							}
						}
					} else
					{
						for (int i =n; i <=x; i++)
						{
							if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
							{
								r = r + 1;
							}
						}
					}
					
				}else {
					if (x < x + y)
					{
						for (int i = x; i <= x + y; i++)
						{
							if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
							{
								r= r + 1;
							}
						}
					} else
					{
						for (int i = x + y; i <= x; i++)
						{
							if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
							{
								r = r + 1;
							}
						}
					}
				}
				System.out.println(r);
			}

		}
	}
}
