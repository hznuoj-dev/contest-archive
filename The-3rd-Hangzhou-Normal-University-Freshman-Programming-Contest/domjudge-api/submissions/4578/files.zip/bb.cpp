#include<stdio.h>
int main()
{
	int t,y,a,s=0,n;
		int i=0;
	scanf("%d",&t);
	while(t--)
	{
		s=0;
		i=0;
		scanf("%d%d",&y,&a);
		s=y+a;
		if(s>9999)
		{
			s=s-(s-9999);
		}
		if(s>y)
		{
			for(int n=y;n<s;n++)
			{
		
				if(n%4==0&&n%100!=0||n%400==0)
				i++;
			}
			printf("%d\n",i);
		}
		if(s<y)
		{
			for(int n=s;n<y;n++)
			{
		
				if(n%4==0&&n%100!=0||n%400==0)
				i++;
			}
			printf("%d\n",i);
		}
		
	}
	return 0;
}
