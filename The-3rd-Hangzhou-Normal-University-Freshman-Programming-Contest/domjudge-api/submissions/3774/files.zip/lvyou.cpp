#include<stdio.h>
int f(int n)
{
	int x,sum=0;
	while(n>0)
	{
		x=n%10;
		sum+=x;
		n/=10;
	}
	return sum;
}
int main()
{
	int A,B,C,D,a,b,c,d,num=0;
	scanf("%d %d %d %d",&A,&B,&C,&D);
	a=f(A);
	b=f(B);
	c=f(C);
	d=f(D);
	if(a>=16||a==6) 
		num++;
	if(b>=16||b==6) 
	    num++;
	if(c>=16||c==6) 
	    num++;
	if(d>=16||d==6) 
	    num++;		
	if(num==0)
	printf("Bao Bao is so Zhai......");
	if(num==1)
	printf("Oh dear!!");
	if(num==2)
	printf("BaoBao is good!!");
	if(num==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
}
