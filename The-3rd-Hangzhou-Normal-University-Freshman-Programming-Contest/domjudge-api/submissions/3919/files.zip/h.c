#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996)
int main()
{
double a,b,c,d,t;
scanf("%lf",&t);
     while(t--)
  { 
    scanf("%lf%lf",&a,&b);
	printf("[");
	for(c=1;c<=b;c++)
	{
		printf("#");
	}
	for(c=1;c<=a-b;c++)
	{
		printf("-");
	}
	printf("]%.0lf%\n",b/a*100);
  }
	return 0;
}