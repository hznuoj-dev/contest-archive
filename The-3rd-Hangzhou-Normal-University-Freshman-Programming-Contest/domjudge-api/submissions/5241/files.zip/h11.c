#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d%d",&n,&m);
		int i;
		i=m*100/n;
		printf("[");
		for(int j=1;j<=m;j++){
			printf("#");
		}
		for(int j=1;j<=n-m;j++){
				printf("-");
		}
		printf("]%d%%",i);
	}
	return 0;
}