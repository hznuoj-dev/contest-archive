#include<stdio.h>
int judge(int x)//�жϵ���һ������ǲ�������
{
	if (x % 4 == 0 && x % 100 != 0 || x % 400 == 0)
	{
		return 1;
	}
	else
		return 0;
}
int main()
{
	int t;
	int y, a;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d%d", &y, &a);
		int x = 0;
		//ȷ������
		int k=0;
		int r1, r2, i;
		if (y + a > 9999)
		{
			k = y + a - 9999;
			r1 = 9999 - k; r2 = y;
		}
		else
		{
			r1 = y; r2 = y + a;
		}
		if (r1 > r2)
		{
			int t = r1; r1 = r2; r2 = r1;
		}
		for ( i = r1; i <= r2; i++)
		{
			k = judge(i);
			if(k==1)
			x++;
		}
		printf("%d\n", x);
	}
	return 0;
}
