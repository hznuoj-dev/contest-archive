#include<stdio.h>
#include<math.h>
int main(){
    int t,a,b,c,m;
    scanf("%d",&t);
    while(t--){
    	m=0;
    	scanf("%d %d",&a,&b);
    	printf("[");
    	for(int i=0;i<b;i++){
    		printf("#");
		}
		for(int i=0;i<a-b;i++){
			printf("-");
		}
		printf("] ");
		printf("%d",b*100/a);
		char d='%';
		printf("%c\n",d);
	}
}
