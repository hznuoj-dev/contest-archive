#include<stdio.h>
int main(){
	int t;
	int m,n,b;
	int i;
	float x;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&m,&n);
		printf("[");
		for(i=0;i<n;i++){
			printf("#");
		}
		for(i=0;i<m-n;i++){
			printf("-");
		}
		printf("] ");
		x=(n+0.00)/(m+0.00)*100;
		b=x;
		printf("%d%%",b);
		printf("\n");
	}
	}
