import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        System.out.println("__ _____\n" +
                           "| | ___/ ____\\____\n" +
                           "| |/ /\\ __\\/ ___\\\n" +
                           "| < | | \\ \\___\n" +
                           "|__|_ \\ |__| \\___ >\n" +
                           "\\/ \\/");
    }
}