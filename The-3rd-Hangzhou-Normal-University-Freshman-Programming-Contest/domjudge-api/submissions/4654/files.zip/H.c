#include <stdio.h>

int main() {
	int T;
	scanf("%d",&T);
	while(T--){
		double a,b;
		scanf("%lf %lf",&a,&b);
		int x=(int)((b/a)*100);
		printf("[");
		int i;
		for(i=0;i<b;++i){
			printf("#");
		}
		for(i=0;i<a-b;++i){
			printf("-");
		}
		printf("] %d%%\n",x);
	}
	return 0;
}

