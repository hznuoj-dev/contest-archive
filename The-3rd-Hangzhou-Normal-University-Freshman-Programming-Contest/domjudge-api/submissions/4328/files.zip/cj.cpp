#include<stdio.h>
int main() {
	char str[4];
	gets(str);
	printf(" __      _____       \n");
	printf("\n");
	printf("|  | ___/ ____ \\ ____\n");
	printf("\n");
	printf("|  |/ /\\    __\\/ ___\\  \n");
	printf("\n");
	printf("|    <  |  | \\  \\ ___\n");
	printf("\n");
	printf("|__|_ \\  |__|  \\ ___  >\n");
	printf("\n");
	printf("     \\ /           \\ /\n");
	printf("\n");
	return 0;
}