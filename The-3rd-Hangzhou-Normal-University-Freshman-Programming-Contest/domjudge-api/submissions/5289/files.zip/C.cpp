#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+5;
long long fastPower(long long b,long long p,long long k){
    long long result=1;
    while(p){
        if(p%2==0){
            p=p/2;
            b=b*b%k;
        }
		else{
            p=p-1;
            result=result*b%k;
            p=p/2;
            b=b*b%k;
        }
    }
    return result;
}
int tre[maxn];
int main(){
	int n,a,res=1;
	cin >> n;
	while(n--){
		cin >> a;
		tre[a]++;
	}
	for(int i=2;i<=a;i++){
		res*=fastPower(tre[i-1],tre[i],998244353);
	}
	res%=998244353;
	cout << res << endl;
return 0;
}
