num = int(input())
i = 0
le = []
while i < num:
    n = 0
    li = list(map(int,input().split()))
    b = sum(li)
    if b <= 9999:
        li[1]=b
    else:
        li[1]=19998-b
    li.sort()
    for m in range(li[0],li[1]+1):
        if m % 100 ==0:
            if m % 400 ==0:
                n += 1
        elif m % 4 ==0:
                n += 1
    le.append(n)
    i += 1
for p in le:
    print(p)


                    