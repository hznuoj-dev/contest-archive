#include<stdio.h>
int main(){
	int i,j,n,k,t,count=0;
	int year1,year2;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %d",&year1,&k);
		year2=year1+k;
		if(year2>=10000){
			year2=9999-(year2-9999);
		}
		if(year1>year2){
			t=year1;
			year1=year2;
			year2=t;
		}
		for(j=year1;j<=year2;j++){
			if(j%4==0&&j%100!=0){
				count++;
			}
			else if(j%100==0&&j%400==0)
			count++;
		}
		printf("%d\n",count);
		count=0;
	}
} 
