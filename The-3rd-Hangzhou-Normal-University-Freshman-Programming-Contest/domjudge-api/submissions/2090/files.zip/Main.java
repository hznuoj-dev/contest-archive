import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner((System.in));
        while (in.hasNext())
        {
            int num = 0;
            for (int i = 1; i <= 4; i++)
            {
                long n = in.nextLong();
                long sum = 0;
                while (n != 0)
                {
                    long a = n % 10;
                    n = n / 10;
                    sum = sum + a;
                }
                if (sum >= 16 || sum == 6)
                {
                    num++;
                }
            }
            if (num == 0)
            {
                System.out.println("Bao Bao is so Zhai......");
            }
            else if (num == 1)
            {
                System.out.println("Oh dear!!");
            }
            else if (num == 2)
            {
                System.out.println("BaoBao is good!!");
            }
            else if (num == 3)
            {
                System.out.println("Bao Bao is a SupEr man///!");
            }
            else if (num == 4)
            {
                System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
            }
        }
    }
} 