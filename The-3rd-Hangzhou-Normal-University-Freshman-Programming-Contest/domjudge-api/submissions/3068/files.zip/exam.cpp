#include<stdio.h>
#include<math.h>
#include<string.h>
char a[10000000];
int main()
{
	int T,n,i,j;
	scanf("%d",&T);
	while(T--)
	{
		int sum=0;
		scanf("%d",&n);
		while(n--)
		{
			int x=0;
			char b[10000];
			scanf("%s",a);
			for(i=0;i<strlen(a);i++)
			{
				int judge=0,t;
				if(a[i]=='.') continue;
				for(j=0;j<x;j++)
				{
					if(a[i]==b[j])
					{
						judge=1;
						break;
					}
				}
				if(judge!=1)
				{
					b[x]==a[i];
					x++;
				}
			}
			sum+=x;
		}
		printf("%d\n",sum);
	}
}
