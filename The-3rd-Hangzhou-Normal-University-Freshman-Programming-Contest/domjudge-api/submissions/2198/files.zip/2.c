#include<stdio.h>
int main()
{
	int t, a, b, sum, i, j;
	int nyear;
	scanf("%d", &t);
	while (t--)
	{
		sum = 0;
		nyear = 0;
		scanf("%d %d", &a, &b);
		sum = a + b;
		if (sum <= 0)
			break;
		else
		{
			if (b < 0)
			{
				for (i = sum;i <= a;i++)
				{
					if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
						nyear++;
				}
			}
			else
			{
				if (sum < 10000)
				{
					for (i = a;i <= sum;i++)
					{
						if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
							nyear++;
					}
				}
				else
				{
					sum = 9999 - (sum - 9999);
					if (sum <= 0)
						break;
					else {
						if (sum < a)
						{
							for (i = sum;i <= a;i++) {
								if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
									nyear++;
							}
						}
						else {
							for (i = a;i <= sum;i++) {
								if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0)
									nyear++;
							}
						}
					}
				}
			}
		}
		printf("%d\n", nyear);
	}
}