#include <stdio.h>
#include <string.h>
typedef struct ybzl
{
	int a;
	int b;
}YB;
int main()
{
	int i,j,n,k,m,je,sum=0,t;
	scanf("%d %d",&n,&m);
	YB yb[n+1],yb1[n+1];
	for(i=1;i<=n;i++)
	{
		scanf("%d",&yb[i].a);
	}
	for(i=1;i<=n;i++)
	{
		scanf("%d",&yb[i].b);
	}
	for(i=1;i<=n;i++)
	{
		for(j=i;j<=n;j++)
		{
			if(yb[j].a>yb[j+1].a)
			{
				t=yb[j].a;
				yb[j].a=yb[j+1].a;
				yb[j+1].a=t;
			}
		}
 }
	for(i=1;i<=m;i++)
	{
	for(k=1;k<=n;k++)
	{
		yb1[k].a=yb[k].a;
		yb1[k].b=yb[k].b;
	}
		je=i;
		for(j=n;j>0;j--)
		{
			while(yb1[j].b>0&&je>=yb1[j].a)
			{
				je-=yb1[j].a;
				yb1[j].b--;
			}
			if(je==0)
			{
				sum++;
				break;
			}
		}
	}
	printf("%d\n",sum);
	return 0;
}
