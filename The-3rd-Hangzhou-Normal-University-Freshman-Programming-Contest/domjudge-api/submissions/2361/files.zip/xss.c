#include<stdio.h>

int main()
{
	char zfc[99];
	int i;
	gets(zfc);
	
	if (strcmp(zfc,"kfc")==0)
	{
		
		i = 0;
			switch (i)
			{
			case 0:printf(" __      _____\n");
			case 1:printf("|  | ___/ ____\\____\n");
			case 2:printf("|  |/ /\\   __\\/ ___\\\n");
			case 3:printf("|    <  |  | \\  \\___\n");
			case 4:printf("|__|_ \\ |__|  \\___  >\n");
			case 5:printf("     \\/           \\/\n");
			}
		
	    
	}
}