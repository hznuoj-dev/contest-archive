#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
	int a,b,c,i,j,m;
	scanf("%d",&j);
	while(j--)
	{
		m=0;
		scanf("%d%d",&a,&b)
			c=a+b;
		if(b<0)
			for(i=c;i<=a;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					m++;
			}
		else if(c>9999){
			c=9999-(c-9999);
			for(i=a;i<=c;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					m++;
			}
		}
		else
		{
			for(i=a;i<=c;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					m++;
			}
		}
		printf("%d\n",m);
	}
	return 0;
}