#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
int k,n,m,x,y,i,j,t=0,sum,temp,s1,s2,s3,s4;
long long a,b,c,d;
char lou[1000100],e;
int main(){
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        scanf("%d",&m);
        for(j=1;j<=m;j++){
            scanf("%s",&lou);
            if(lou[0]!='.')
                sum++;
            for(k=1;k<strlen(lou);k++){
                if(lou[k]=='.')
                    continue;
                for(x=0;x<k;x++){
                    if(lou[k]!=lou[x])
                        t=1;
                        else {
                            t=0;
                            break;
                        }
                }
                    if(t==1)
                        sum=sum+1;
                    t=0;
            }
        }
        printf("%d\n",sum);
        sum=0;
    }
    return 0;
}
