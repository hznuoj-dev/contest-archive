#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int T,n,i,len;
	char a[100001];
	scanf("%d",&T);
	while(T--){
		int sum=0;
		scanf("%d",&n);
		while(n--){
			int b[100001]={0};
			 scanf("%s",a);
			 len=strlen(a);
			 for(i=0;i<len;i++){
			 	if(a[i]!='.'&&b[(int)a[i]]==0){
			 		sum++;
			 		b[(int)a[i]]++;
				 }
			 }
		}
		printf("%d",sum);
		if(T>0)
		printf("\n");
	}
	return 0;
}
