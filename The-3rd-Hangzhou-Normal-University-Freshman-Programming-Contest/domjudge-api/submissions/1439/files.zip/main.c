//
//  main.c
//  live
//
//  Created by 李允帆 on 2020/12/13.
//


#include<stdio.h>
int main()
{
    int t;
    int y,a,i,num;
    scanf("%d\n",&t);
    while(t--)
    {
        num=0;
        scanf("%d%d\n",&y,&a);
        if((y+a)<=9999&&(y+a)>=y){
            for(i=y;i<=(y+a);i++)
            {
                if((i%4==0&&i%100!=0)||(i%400==0))num++;
            }
        }
        else if((y+a)>9999){
            for(i=y;i<=9999-(y+a-9999);i++)
            {
                if((i%4==0&&i%100!=0)||(i%400==0))num++;
            }
        }
        else{
            for(i=y+a;i<=y;i++)
            {
                if((i%4==0&&i%100!=0)||(i%400==0))num++;
            }
        }
        printf("%d\n",num);
    }
}
