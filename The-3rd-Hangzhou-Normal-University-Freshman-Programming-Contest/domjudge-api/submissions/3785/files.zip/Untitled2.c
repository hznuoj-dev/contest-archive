#include<stdio.h>
#include<stdio.h>
main() 
{
	char a[100000],b[10][1000];
	int t,T,sum,i,j,flag;
	scanf("%d",&t);
	while(t--)
	{
		sum=0;
		scanf("%d",&T);
		while(T--)
		{
			scanf("%s",a);
			for(i=0;i<strlen(a);i++)
			{
				flag=1;
				b[T][0]='.';
				for(j=0;j<strlen(b[T]);j++)
				{
					if(a[i]==b[T][j])
					flag=0;
				}
				
				if(flag==1)
				{
					b[T][j]=a[i];
					sum=sum+1;
				}
				
			}
		}
		printf("%d\n",sum);
	 } 

}
