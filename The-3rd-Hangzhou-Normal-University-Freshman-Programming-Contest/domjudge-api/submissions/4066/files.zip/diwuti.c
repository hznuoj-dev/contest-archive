#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(void){
	int i,t,n,p,b,j;
	scanf("%d",&t);
	while(t--){
		p=0;
		scanf("%d",&n);
		for(i=1;i<=n;++i){
			char s[1000001]={0};
			int a[257]={0};
			if(i==1)
				getchar();
			scanf("%c",&s[0]);
			for(j=0;s[j]!='\n';j++){
				b=s[j];
				if(a[b]==0&&b!=46){
					p=p+1;
					a[b]=1;
				}
				if(p==256)
					break;
				scanf("%c",&s[j+1]);
			}
		}
		printf("%d\n",p);
	}
	return 0;
}
