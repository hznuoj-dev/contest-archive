#include<bits/stdc++.h>
using namespace std;
#define ll long long


int main(void){
	ll n;
	cin>>n;
	while(n--){
		double a,b,c;
		cin>>a>>b;
		cout<<"[";
		for(int k=0;k<b;k++)
			cout<<"#";
		for(int k=0;k<a-b;k++)
			cout<<"-";
		cout<<"] ";
		c=b/a;
		printf("%.0f",c*100);
		cout<<"%"<<endl;
		
	}
}
