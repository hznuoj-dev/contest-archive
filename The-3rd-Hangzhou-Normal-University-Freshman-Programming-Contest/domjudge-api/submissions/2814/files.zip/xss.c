#include<stdio.h>
#include<string.h>
int main()
{
	char a[99], b[99], c[99], d[99];
	int lena, lenb, lenc, lend, i, n, k;
	char* p;
	
	scanf("%s%s%s%s", &a, &b, &c, &d);
	lena = strlen(a);
	lenb = strlen(b);
	lenc = strlen(c);
	lend = strlen(d);
	k = 0;
	n = 0;
	p = &a;
	for (i = 0;i < lena;++i)
	{
		n = n + *(p + i)-48;
	}
	if (n >= 16 || n == 6)
	{
		k = k + 1;
	}
	n = 0;
	p = &b;
	for (i = 0;i < lenb;++i)
	{
		n = n + *(p + i) - 48;
	}
	if (n >= 16 || n == 6)
	{
		k = k + 1;
	}
	n = 0;
	p = &c;
	for (i = 0;i < lenc;++i)
	{
		n = n + *(p + i) - 48;
	}
	if (n >= 16 || n == 6)
	{
		k = k + 1;
	}
	n = 0;
	p = &d;
	for (i = 0;i < lend;++i)
	{
		n = n + *(p + i) - 48;
	}
	if (n >= 16 || n == 6)
	{
		k = k + 1;
	}
	switch (k)
	{
	case 0:printf("Bao Bao is so Zhai......");
		break;
	case 1:printf("Oh dear!!");
		break;
	case 2:printf("BaoBao is good!!");
		break;
	case 3:printf("Bao Bao is a SupEr man///!");
		break;
	case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		break;
	}
}