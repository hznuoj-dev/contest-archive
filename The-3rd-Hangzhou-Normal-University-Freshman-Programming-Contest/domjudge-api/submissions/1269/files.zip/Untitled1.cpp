#include <cstdio>
#include <iostream>
#include <cstring> 
using namespace std;
const int N = 1e5 + 10;

int main () {
	char s[100];
	int ans = 0;
	for (int i = 0; i < 4; i++) {
		scanf(" %s", s);
		int len = strlen(s), temp = 0;
		for (int j = 0; j < len; j++) 
			temp += (s[j] - '0');
		if (temp == 6 || temp >= 16)
			++ans;
	}
	if (ans == 0)
		printf("Bao Bao is so Zhai......\n");
	else if (ans == 1)
		printf("Oh dear!!\n");
	else if (ans == 2)
		printf("BaoBao is good!!");
	else if (ans == 3)
		printf("Bao Bao is a SupEr man///!\n");
	else if (ans == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}
