#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int main(void) {
    int a[4],i,t,s=0,c=0;
    for(i=0;i<4;i++){
    	s=0;
    	scanf("%d",&a[i]);
    	while(a[i]!=0){
    		t=a[i]%10;
    		s+=t;
    		a[i]/=10;
		}
		if(s>=16||s==6){
			c+=1;
		}
	}
	if(c==0){
		printf("Bao Bao is so Zhai......");
	}
	if(c==1){
		printf("Oh dear!!");
	}
	if(c==2){
		printf("BaoBao is good!!");
	}
	if(c==3){
		printf("Bao Bao is a SupEr man//////!");
	}
	if(c==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
return 0;
}

