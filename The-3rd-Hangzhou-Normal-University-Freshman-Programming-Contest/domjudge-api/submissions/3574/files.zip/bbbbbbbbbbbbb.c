#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int T,Y=0,A=0,x=0,i,k;
	scanf("%d",&T);
	for(i=0;i<T;i++){
		int B=0;
		scanf("%d%d",&Y,&A);
		B=Y+A; 
		if(B>9999){
			int n=0;
			n=Y+A-9999;
			B=9999-n; 
		}
		if(B<Y){
			int m;
			m=B;
			B=Y;
			Y=m;
		}
		for(k=Y;k<=B;k++){
			if((k%4==0&&k%100!=0)||(k%400==0)){
				x++;
			}
		}
	} 
	printf("%d",x);
	return 0;
}
