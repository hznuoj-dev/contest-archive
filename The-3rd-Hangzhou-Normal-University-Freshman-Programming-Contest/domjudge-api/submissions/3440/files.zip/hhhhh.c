#include<stdio.h>
#pragma warning(disable:4996)
#include<math.h>
#include<string.h>
int main(){
	int a,b,c,d,sum=0,i,k=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	while(a>0){
		k=k+a%10;
		a=a/10;
	}
	if(k>=16||k==6){
		sum++;
	}
	k=0;
	while(b>0){
		k=k+b%10;
		b=b/10;
	}
	if(k>=16||k==6){
		sum++;
	}
	k=0;
	while(c>0){
		k=k+c%10;
		c=c/10;
	}
	if(k>=16||k==6){
		sum++;
	}
	k=0;
	while(d>0){
		k=k+d%10;
		d=d/10;
	}
	if(k>=16||k==6){
		sum++;
	}
	k=0;
	if(sum==0)
		printf("Bao Bao is so Zhai......");
	else if(sum==1)
		printf("Oh dear!!");
	else if(sum==2)
		printf("BaoBao is good!!");
	else if(sum==3)
		printf("Bao Bao is a SupEr man///!");
	else if(sum==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	system("pause");
	return 0;
}