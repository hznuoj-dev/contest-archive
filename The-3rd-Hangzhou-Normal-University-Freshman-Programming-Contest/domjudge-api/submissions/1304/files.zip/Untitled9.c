#include <stdio.h>
#include <string.h>
int num(char a[]){
	int i,l,sum=0;
	l=strlen(a);
	for(i=0;i<l;i++){
		sum=sum+a[i]-'0';
	}
	return sum;
}
int main(){
	int a[4][20],s=0,i;
	scanf("%s%s%s%s",a[0],a[1],a[2],a[3]);
	for(i=0;i<4;i++){
		if(num(a[i])>=16||num(a[i])==6){
			s++;
		}
	}
	switch(s){
		case 1:printf("Oh dear!!");
				break;
		case 2:printf("BaoBao is good!!");
				break;
		case 3:printf("Bao Bao is a SupEr man///!");
				break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
				break;
		case 0:printf("Bao Bao is so Zhai......");
				break;
	}
	return 0;
}
