#include <stdio.h>
int rank[1001][1001];
int main(){
	int t,n,m,name[2],i,s,j,x,a[1001],b[1001],c[1001],d,e,sum,p,o;
	scanf("%d",&t);
	while(t--){
		e=0;
		d=0;
		sum=0;
		s=0;
		p=1;
		o=1;
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++){
			a[i]=-1;
			for(j=1;j<=n;j++){
				rank[i][j]=0;
			}			
		}
		while(m--){
			scanf("%d%d",&name[0],&name[1]);
			rank[name[0]][name[1]]=1;
			a[name[0]]=0;
			a[name[1]]=0;
		}
		for(j=1;j<=n;j++){
			if(a[j]==0){
				sum++;
			}				
		}
		for(i=1;i<=n;i++){
			for(j=1;j<=n;j++){
				if(rank[i][j]==1){
					if(a[j]>a[i])
						a[i]=a[j];
					a[j]=a[i]+1;
				}
			}			
		}
		while(1){
			for(j=1;j<=n;j++){
				if(a[j]==e){
					b[d+1]=j;
					d++;
				}				
			}
			e++;
			if(d==sum){
				break;
			}
		}
		for(j=1;j<=n;j++){
			if(a[j]==-1){
				s++;
				c[s]=j;			
			}
		}
		for(j=1;j<=n;j++){
			if(c[p]<b[o]&&p<=s){
				printf("%d ",c[p]);
				p++;
			}
			else if(c[p]>b[o]&&o<=sum){
				printf("%d ",b[o]);
				o++;
			}
			else if(p>s){
				printf("%d ",b[o]);
				o++;
			}
			else if(o>sum){
				printf("%d ",c[p]);
				p++;
			}
		}
		printf("\n");
	}
	return 0;
}
