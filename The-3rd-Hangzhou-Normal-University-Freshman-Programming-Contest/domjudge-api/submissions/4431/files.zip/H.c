#include<stdio.h>
#include<math.h>
int main()
{int t;


scanf("%d",&t);
	while(t--)
	{
		int i;
		int m,n;
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
		{
			printf("#");
		}
		for(i=1;i<=(n-m);i++)
		{
			printf("-");
		}
		printf("] ");
		double a=(double)m/(double)n;
		
		
		double c=a*100;
		int b=(int)c;
		if(b==10)
		{
			b=100;
		}
		printf("%d",b);
		printf("%%\n");
	}
	

	
	
	

}
