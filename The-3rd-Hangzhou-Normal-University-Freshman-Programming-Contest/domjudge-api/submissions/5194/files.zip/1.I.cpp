#include <stdio.h>
#include <stdlib.h>
#include <string.h>
char a[20],b[20],c[20],d[20];
int main(void){
	scanf("%s %s %s %s",a,b,c,d);
	int i,count1=0,count2=0,count3=0,count4=0,flag=0;
	for(i=0;i<strlen(a);i++){
		count1+=a[i]-48;
	}
	if(count1>=16 || count1==6)
		flag+=1;
	for(i=0;i<strlen(b);i++){
		count2+=b[i]-48;
	}
	if(count2>=16 || count2==6)
		flag+=1;
	for(i=0;i<strlen(c);i++){
		count3+=a[i]-48;
	}
	if(count3>=16 || count3==6)
		flag+=1;
	for(i=0;i<strlen(d);i++){
		count4+=d[i]-48;
	}
	if(count4>=16 || count4==6)
		flag+=1;
	if(flag==0)
		printf("Bao Bao is so Zhai......\n");
	if(flag==1)
		printf("Oh dear!!\n");
	if(flag==2)
		printf("BaoBao is good!!\n");	
	if(flag==3)
		printf("Bao Bao is a SupEr man///!\n");
	if(flag==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}