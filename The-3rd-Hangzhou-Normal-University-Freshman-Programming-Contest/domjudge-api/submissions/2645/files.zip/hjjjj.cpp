#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int a[15];
	int b[15];
	for(int i=1;i<=n;i++){
		cin>>a[i]>>b[i];
	}
	for(int i=1;i<=n;i++){
		printf("[");
		for(int j=1;j<=b[i];j++){
			printf("#");
		}
		for(int j=1;j<=a[i]-b[i];j++){
			printf("-");
		}
		printf("] ");
		double xx=100*b[i]/a[i];
		printf("%.0f%\n",xx);
	}
} 

