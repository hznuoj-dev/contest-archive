#include<bits/stdc++.h>
using namespace std;

int n, m, cnt, ans;
bool f[100001];

struct MONEY
{
	int a, b;
} mo[101];

bool cmp (MONEY x, MONEY y)
{
	return x.a < y.a;
}

void dfs (int x, int y)
{
	for (int i = x; i <= n; i++)
	{
		if (mo[i].b)
		{
			mo[i].b--;
			y += mo[i].a;
			f[y] = 1;
			if (y > m) return;
			dfs (x, y);
			y -= mo[i].a;
			mo[i].b++;
		}
		else dfs (x + 1, y);
	}
}

int main ()
{
	scanf ("%d%d", &n, &m);
	for (int i = 1; i <= n; i++) scanf ("%d", &mo[i].a);
	for (int i = 1; i <= n; i++) scanf ("%d", &mo[i].b);
	sort (mo + 1, mo + n + 1, cmp);
	dfs (1, 0);
	for (int i = 1; i <= 100000; i++) if (f[i]) ans++;
	printf ("%d", ans);
	
	
	return 0;
	
}
