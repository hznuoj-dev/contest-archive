#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
using namespace std;
int x[100001]={0};
typedef struct{
	int a,b;	
}lw;
lw y[100];
int main(){
	int n,m,i,sum=0,min=100001;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&y[i].a);
		if(min>y[i].a)min=y[i].a;
	}
	for(i=0;i<n;i++){
		scanf("%d",&y[i].b);
		sum=sum+y[i].b*y[i].a;
	}
	if(sum>m)sum=m;
	printf("%d\n",sum-min+1);
	return 0;
}

