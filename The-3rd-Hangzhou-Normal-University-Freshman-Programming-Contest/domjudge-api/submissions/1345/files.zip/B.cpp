#include<stdio.h>
int main() {
	int t, a, b, c;
	int n, x;
	scanf("%d", &t);
	while (t--)
	{
		n = 0;
		scanf("%d %d", &a, &b);
		c = a + b;
		if (c > 9999)
			c = 9999 - (c - 9999);
		if (a > c)
		{
			x = a;
			a = c;
			c = x;
		}

		for (int i = a; i <= c; i++)
		{
			if (i % 400 == 0 || (i % 4 == 0 && i % 100 != 0))
				n++;
		}
		printf("%d\n", n);
	}
	return 0;
}