#include <iostream>
#include <cstring>
#include <cstdio>
using namespace std;
int main()
{
    char s[4];
    getchar();
    getchar();
    getchar();
    getchar();
    cout << " __      _____ " << endl
         << "|  | ___/ ____\\____" << endl
         << "|  |/ /\\   __\\/ ___\\" << endl
         << "|    <  |  |  \\  \\___" << endl
         << "|__|_ \\ |__|   \\___  >" << endl
         << "     \\/            \\/" << endl;
    return 0;
}