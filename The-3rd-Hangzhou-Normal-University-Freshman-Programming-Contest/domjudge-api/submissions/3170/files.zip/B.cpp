#include<stdio.h>
int isLeap(int x){
if ((x%4==0 && x%100!=0)||x%400==0)
{return 1;}//runnian
else 
return 0;	//ƽ�� 
 } 
int main(){
int T,a,b,c=0,d=0,i,e=0,f=0;
scanf("%d",&T);
while(T--){
	scanf("%d %d",&a,&b);//[a,c]Ϊ��� 
	c=a+b;
	if(c>=10000){
		d=c-9999;
		c=9999-d;
	}
	if(c<a){
	f=c;
	c=a;
	a=f;	
	}
	
	for (i=a;i<=c;i++) {
		e=e+isLeap(i);
	}
printf("%d\n",e);
e=0;

}
}


