#include<stdio.h>
#include<string.h>
int main()
{int repeat=4,sum2=0;
while(repeat--)
{  int i=0,sum=0;
    char str[50000];
while ((str[i]=getchar())!='\0'&&str[i]!=EOF)
 i++;
 str[i]='\0';
  int flag=0;
    for(i=0;str[i]!='\0';i++){    
   sum+=(int)str[i] ;       
}
if(sum==6||sum>=16) sum2++;
}
if (sum2==1)printf("Oh dear!!\n");
else if (sum2==2)printf("BaoBao is good!!\n");
else if (sum2==3)printf("Bao Bao is a SupEr man///!\n");
 else if (sum2==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
else  printf("Bao Bao is so Zhai......\n");
return 0;
} 
