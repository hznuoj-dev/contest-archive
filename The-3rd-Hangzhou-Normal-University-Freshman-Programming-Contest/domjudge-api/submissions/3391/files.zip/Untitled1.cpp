#include<stdio.h>
#include<math.h>
int judge(int year){
	if(year==0) return 0;
	return (year%4==0&&year%100!=0)||(year%100==0&&year%400==0);
}

int change(int year){
	return year>9999 ? abs(9999-(year-9999)) : year;
}
int getbig(int a,int b){
	return a>b?a:b;
}
int getmin(int a,int b){
	return a>b?b:a;
}


int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b,min,max;
		scanf("%d%d",&a,&b);
		a = change(a);
		b = change(a+b);
		min = getmin(a,b);
		max = getbig(a,b);
		//printf("%d %d\n",min,max);
		int count = 0;
		for(int i = min;i< max;i++){
			if(judge(i)){
				count++;
			}
		}
		printf("%d\n",count);
	}
}

 
