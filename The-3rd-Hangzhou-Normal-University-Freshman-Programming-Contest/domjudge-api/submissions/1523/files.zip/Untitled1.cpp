#include<stdio.h>

int judge(int year){
	return (year%4==0&&year%100!=0)||(year%400==0);
}

int change(int year){
	if(year<=1) return 1;
	else return year>=9999 ? 9999-(year-9999) : year;
}
int getbig(int a,int b){
	return a>b?a:b;
}
int getmin(int a,int b){
	return a>b?b:a;
}


int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b,min,max;
		scanf("%d%d",&a,&b);
		a = change(a);
		b = change(a+b);
		min = getmin(a,b);
		max = getbig(a,b);
		printf("%d %d\n",min,max);
		int count = 0;
		for(int i = min;i< max;i++){
			if(judge(i)){
				count++;
			}
		}
		printf("%d\n",count);
	}
}

 
