#include<iostream>
#include<string>
using namespace std;
int main(){
	string a;
	int T,n,ans=0;
	cin >> n;getchar();
	while (n--) {
		cin >> a;getchar();
		ans+=a.length();
	}
	cout << ans;
    return 0;
}
