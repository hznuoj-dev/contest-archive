#include <stdio.h>
#include <math.h>
int panduan(int x){
	int a[18],i=0,m=0;
	do{
		if(i=0){
			a[i]=x % (int)pow(10,i+1);
		}
		else{
			a[i]=(x%(int)pow(10,i+1)-x%(int)pow(10,i))/pow(10,i);
		}
		i++;
	}while(x/pow(10,i)>10);
	a[i]=x/pow(10,i);
	for(int j=0;j<=i;j++){
		m+=a[j];
	}
	if(m>=16||m==6){
		return 1;
	}
	else{
		return 0;
	}
}
int main(){
	int a,b,c,d,m=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(panduan(a)){
		m++;
	}
	if(panduan(b)){
		m++;
	}
	if(panduan(c)){
		m++;
	}
	if(panduan(d)){
		m++;
	}
	if(m==1){
		printf("Oh dear!!");
	}
	else{
		if(m==2){
			printf("BaoBao is good!!");
		}
		else{
			if(m==3){
				printf("Bao Bao is a SupEr man///!");
			}
			else{
				if(m==4){
					printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
				}
				else{
					printf("Bao Bao is so Zhai......");
				}
			}
		}
	}
}
