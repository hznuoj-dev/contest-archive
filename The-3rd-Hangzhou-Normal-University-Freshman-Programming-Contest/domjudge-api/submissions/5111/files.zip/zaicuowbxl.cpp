#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	for(int N=1;N<=n;N++){
		int a,b,c;
		scanf("%d %d",&a,&b);
		printf("[");
		for(int B=1;B<=b;B++){
			printf("#");
		}
		for(int A=1;A<=a-b;A++){
			printf("_");
		}
		printf("]");
		c=b*100/a;
		printf(" %d%%\n",c);
		c=0;
	}
}
