package ft;
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner a = new Scanner(System.in);
		while (a.hasNext())
		{			
			int s=0;
			int x=a.nextInt();
			for(int i=0;i<x;i++)
			{
				s=0;
				int y=a.nextInt();
				for(int j=0;j<y;j++)
				{
                    String h=a.next();
    				h=h.replace(".", "");
    				String n[]=new String[h.length()];
    				for(int k=0;k<h.length();k++)
    				{
    					int l=1;
    					String r=h.substring(k, k+1);
                        for(int o=0;o<n.length;o++)
    					{
    						if(r.equals(n[o]))
    						{
    							l=0;
    							break;
    						}
    					}
    					if(l!=0)
    					{
    						n[k]=r;
    						s=s+1;
    					}
    				}
				}
				System.out.println(s);
			}
		}
	}
}
