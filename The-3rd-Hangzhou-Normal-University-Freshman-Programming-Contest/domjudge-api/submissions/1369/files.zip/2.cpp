#include<stdio.h>
int isLeap(int *x);
int main()
{
int t,p,o,ans;
scanf("%d",&t);
while(t--)
{
	ans=0;
int n,m,b;
scanf("%d%d",&n,&m);
n=o;
n=n+m;
if(n>=9999){
	p=n-9999;
	m=9999-p;
	if(o>=m){
		for(int i=m;i<=o;++i){
			if(isLeap(&i)==366)
			ans+=1;
		}
		printf("%d\n",ans);
	}
	else{
			for(int i=o;i<=m;++i){
			if(isLeap(&i)==366)
			ans+=1;
		}
		printf("%d\n",ans);
	}
}
else{
	if(o<=n){
		for(int i=o;i<=n;++i){
			if(isLeap(&i)==366)
			ans+=1;
		}
		printf("%d\n",ans-1);
	}
	else{
			for(int i=n;i<=o;++i){
			if(isLeap(&i)==366)
			ans+=1;
		}
		printf("%d\n",ans);
	}
}
}
}
int isLeap(int *x){
	return *x%4==0&&*x%100!=0||*x%400==0?366:365;
}

