#include<stdio.h>
int rn(int y)
{
	if((y%4==0&&y%100!=0)||y%400==0)
	    return 1;
	else
	    return 0;
}

int main(void)
{
	int i,T,Y,A,B;
	scanf("%d",&T);
	
	while(T--)
	{
		scanf("%d %d",&Y,&A);
		B = Y+A;
		if(B>9999)
		    B = 9999-(B-9999);
		if(B<Y)
		{
		    int t=B;B=Y;Y=t; 
		} 
			
		int rn(int y);
		int count=0;
		for(i=Y;i<=B;i++)
		{
			if(rn(i))
			count++;
		}
		printf("%d\n",count);
	}	
}
