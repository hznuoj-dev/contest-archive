#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void) {
	int A, B, C, D;
	scanf("%d %d %d %d", &A, &B, &C, &D);
	int j = 0;
	if (al(A)) j++;
	if (al(B)) j++;
	if (al(C)) j++;
	if (al(D)) j++;
	if (j == 1) {
		printf("Oh dear!!");
	}
	else if (j == 2) {
		printf("BaoBao is good!!");
	}
	else if (j == 3) {
		printf("Bao Bao is a SupEr man///!");
	}
	else if (j == 4) {
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	else {
		printf("Bao Bao is so Zhai......");
	}
}
int al(int n) {
	int sum = 0;
	while (n > 0) {
		sum += n % 10;
		n /= 10;
	}
	if (sum >= 16 || sum == 6) return 1;
	else return 0;
}