#include<stdio.h>
#include<stdio.h>
main() 
{
	char a[1000000];
	int t,T,sum,i,j,flag;
	scanf("%d",&t);
	while(t--)
	{
		sum=0;
		scanf("%d",&T);
		while(T--)
		{
			scanf("%s",a);
			for(i=0;i<strlen(a);i++)
			{
				flag=1;
				for(j=0;j<i;j++)
				{
					if(a[j]==a[i])
					flag=0;
				}
				if(a[i]!='.'&&flag==1)
				sum=sum+1;
			}
		}
		printf("%d\n",sum);
	 } 

}
