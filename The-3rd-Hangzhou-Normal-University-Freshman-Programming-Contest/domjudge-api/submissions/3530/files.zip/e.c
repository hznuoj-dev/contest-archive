#include <stdio.h>
int main(void)
{
	char charArray[3];
	int i;
	for(i=0;i<3;++i)
		scanf("%c", &charArray[i]);
	
	printf(" __      _____\n");

	printf("|  | ___/ ____ \\____\n");
			
	printf("|  |/ /\\   __\\/ ___\\\n");
				
	printf("|    <   |  | \\ \\___\n");
		
	printf("|__|_ \\ |__|   \\___ >\n");
			
	printf("     \\/             \\/\n");
			  
	return 0; 
} 
