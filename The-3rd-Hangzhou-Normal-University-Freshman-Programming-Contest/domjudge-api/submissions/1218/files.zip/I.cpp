#include<bits/stdc++.h>
using namespace std;

char a[101], b[101], c[101], d[101];
int suma, sumb, sumc, sumd, cnt;
char print[11][1001] = {"Bao Bao is so Zhai......", "Oh dear!!", "BaoBao is good!!", "Bao Bao is a SupEr man///!", "Oh my God!!!!!!!!!!!!!!!!!!!!!"};

int main ()
{
	scanf ("%s %s %s %s", a, b, c, d);
	int la, lb, lc, ld;
	la = strlen (a);
	lb = strlen (b);
	lc = strlen (c);
	ld = strlen (d);
	for (int i = 0; i < la; i++) suma += a[i] - '0';
	for (int i = 0; i < lb; i++) sumb += b[i] - '0';
	for (int i = 0; i < lc; i++) sumc += c[i] - '0';
	for (int i = 0; i < ld; i++) sumd += d[i] - '0';
	if (suma >= 16 || suma == 6) cnt++;
	if (sumb >= 16 || sumb == 6) cnt++;
	if (sumc >= 16 || sumc == 6) cnt++;
	if (sumd >= 16 || sumd == 6) cnt++;
	printf ("%s", print[cnt]);
	
	return 0;
	
}
