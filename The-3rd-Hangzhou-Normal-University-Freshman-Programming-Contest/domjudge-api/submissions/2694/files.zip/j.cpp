#include <iostream>
using namespace std;

int main()
{
    int t, levels, count, store[129];
    char ch;
    cin >> t;
    for (int i = 1; i <= t; i++)
    {
        count = 0;
        cin >> levels;
        getchar();
        for (int j = 1; j <= levels; j++)
        {
            for (int k = 1; k <= 128; k++)
            {
                store[k] = 0;
            }
            while ((ch = getchar()) != '\n')
            {
                store[(int)ch]++;
            }
            for (int k = 1; k <= 128; k++)
            {
                if (store[k] != 0 && (char)k != '.')
                    count++;
            }
        }
        cout << count << endl;
    }
    return 0;
}