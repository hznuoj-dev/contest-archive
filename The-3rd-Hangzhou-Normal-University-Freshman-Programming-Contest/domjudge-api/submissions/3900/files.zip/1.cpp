#include<bits/stdc++.h>
int pd(int n)
{
	int re;
	return re=(n%4==0&&n%100!=0||n%400==0);
}
int main()
{
	int n,a,b;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int sum=0;
		scanf("%d%d",&a,&b);
		b=a+b;
		if(b>9999){
			b=9999-(b-9999);
		}
		if(a>b){
			int tmp;
			tmp=a;a=b;b=tmp;
		}
		for(int j=a;j<=b;j++){
			if(pd(j)==1){
				sum++;
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
