#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main()
{
	int t,n,i,j,sum;
	char s[1000][1000];
	scanf("%d",&t);
	while(t--)
	{
		sum=0;
		scanf("%d",&n);
		for(i=1;i<=n;i++)
		{
			scanf("%s",s[i]);
		}
		for(i=1;i<=n;i++)
		{
			if(strcmp(s[i],".")!=0)
			{
				sum++;
			}
			for(j=i;j<=n;j++)
			{
				if(s[j]==s[i])
				{
					strcpy(s[j],".");
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
