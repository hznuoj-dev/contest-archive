#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
const int MAX=1e5+10;
vector <int> a[MAX];
vector <int> temp;
int main()
{
	int n,aNum;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int m;
		scanf("%d",&m);
		for(int j=1;j<=m;j++)
		{
			int t;
			scanf("%d",&t);
			a[i].push_back(t);
		}
	}
//	{
//		for(int i=1;i<=n;i++)
//		{
//			for(int j=0;j<a[i].size();j++)
//			{
//				printf("%d ",a[i][j]);
//			}
//			puts("");
//		}
//	}
	int q;
	scanf("%d",&q);
	while(q--)
	{
		int m,k;
		temp.clear();
		scanf("%d",&m);
		for(int i=1;i<=m;i++)
		{
			scanf("%d",&aNum);//������
			for(int j=0;j<a[aNum].size();j++)
			{
				temp.push_back(a[aNum][j]);
			} 
		}
		sort(temp.begin(),temp.begin()+temp.size());
//		for(int i=0;i<temp.size();i++)
//		{
//			printf("%d ",temp[i]);
//		}
//		printf("\n");
		scanf("%d",&k);
		printf("%d\n",temp[k-1]);
	}
	return 0;
}
