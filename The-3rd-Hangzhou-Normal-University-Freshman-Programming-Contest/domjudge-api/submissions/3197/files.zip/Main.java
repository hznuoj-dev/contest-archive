import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int count=0;
		while(sc.hasNext())
		{
			
			String[]a=new String[4];
			for(int i=0;i<a.length;i++)
			{
				a[i]=sc.next();
				int sum=0;
				for(int j=0;j<a[i].length();j++)
				{
					sum+=Integer.parseInt(String.valueOf(a[i].charAt(j)));
				}
				if(sum>=16||sum==6)count++;
			}
			if(count==1)
			{
				System.out.println("Oh dear!!");
			}else if(count==2)
			{
				System.out.println("BaoBao is good!!");
			}else if(count==3)
			{
				System.out.println("Bao Bao is a SupEr man///!");
			}else if(count==4)
			{
				System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			}else if(count==0)
			{
				System.out.println("Bao Bao is so Zhai......");
			}
		}
	}

}