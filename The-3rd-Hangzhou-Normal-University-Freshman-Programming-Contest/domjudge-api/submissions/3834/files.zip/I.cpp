#include<stdio.h>
#include<string.h>
int main(){
	char a[20]={0};
	int T=4,sum,x=0,k,h,l;
	while(T--){
	scanf("%s",a);
	l=strlen(a)-1;
	for(k=0;k<=l;k++){
		h=(int)a[k]-48;
		sum=sum+h; 
//		printf("%c %d ",a[k],h);
	}
	if(T==3) sum=sum-27;
//	printf("%d\n",sum);
	if(sum>=16||sum==6){
		x=x+1;
	}
	sum=0;
}
if(x==0) printf("Bao Bao is so Zhai......");
if(x==1) printf("Oh dear!!");
if(x==2) printf("BaoBao is good!!");
if(x==3) printf("Bao Bao is a SupEr man///!");
if(x==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}
