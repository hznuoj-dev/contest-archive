#include <stdio.h>
#include <string.h>
int fun(int x){
	if(x==0){
		return 0;
	}
	else{
		return x%10+fun(x/10);
	}
}
int main(void){
	int a,b,c,d;
	int s=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	if(fun(a)>=16||fun(a)==6){
		s++;
	}
	if(fun(b)>=16||fun(b)==6){
		s++;
	}
	if(fun(c)>=16||fun(c)==6){
		s++;
	}
	if(fun(d)>=16||fun(d)==6){
		s++;
	}
	switch(s){
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
		default:printf("Bao Bao is so Zhai......");break;
	}
	return 0;
}
