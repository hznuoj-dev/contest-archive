#include<stdio.h>
int main() {
	int t, m, n, a, b, sum[1001], i, j, flag[1001][1001];
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &m, &n);
		for (i = 1; i <= m; i++) {
			sum[i] = 0;
		}
		for (i = 1; i <= m; i++) {
			for (j = 1; j <= m; j++) {
				flag[i][j] = 0;
			}
		}
		while (n--) {
			scanf("%d %d", &a, &b);
			if (flag[a][b] == 1) {
				flag[a][b] = 1;
			}
			else {
				sum[a] += 1;
				flag[a][b] = 1;
			}
		}
		for (i = m; i >= 0; i--) {
			for (j = 1; j <= m; j++) {
				if (sum[j] == i) {
					printf("%d ", j);
				}
			}
		}
		printf("\n");
	}
}