#include<stdio.h>
#include<string.h>
int main()
{
	int t,n,i,m,c,j;
	char a[1000000],r;
	scanf("%d",&t);
	while(t--)
	{
		c=0;
		scanf("%d",&n);
		for(m=0;m<n;m++)
		{
			scanf("%s",a);
			for(i=0;i<strlen(a);i++)
			{
				if(a[i]!='.')
				{
				for(j=0;j<i;j++)
				{
					if(a[i]==a[j])
					{
						break;
					}
				}
				if(i==j)
				c++;
				}
			}
		}
		printf("%d\n",c);
	}
	return 0;
}
