#include<stdio.h>
int main(){
 int t,n,m,i;
 scanf("%d",&t);
 while(t--){
 	scanf("%d%d",&n,&m);
 	printf("[");
 	for(i=1;i<=m;i++){
 		printf("#");
	 }
	 	for(i=m+1;i<=n;i++){
 		printf("_");
	 }
	 printf("] ");
	 printf("%d%\n",m*100/n);
 }
} 
