#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int m,n,k,i,h,y,t,temp,j,sum;
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		scanf("%d%d",&n,&m);
		h=m*1.0/n*100;
		printf("[");
		for(k=1;k<=m;k++){
			printf("#");
		}
		for(k=1;k<=n-m;k++){
			printf("_");
		}
		printf("] ");
		printf("%d",h);
		printf("%%");
		printf("\n");
	}

	return 0;
}
//int cmp(const void*p,const void*q){
//return((struct kx*)q)->average -(struct kx*)p)->average)
//}