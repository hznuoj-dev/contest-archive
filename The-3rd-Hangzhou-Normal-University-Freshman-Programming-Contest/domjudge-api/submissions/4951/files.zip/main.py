fw, fw1 = input().split()
coinValue = list(map(int, input().split()))
coinMount = list(map(int, input().split()))
mountSet = {0}
for i in range(0, len(coinValue)):
    for j in range(0, coinMount[i]):
        tmpSet = set()
        for k in mountSet:
            newValue = k + coinValue[i]
            if newValue > int(fw1):
                break
            else:
                tmpSet.add(newValue)
        for v in tmpSet:
            mountSet.add(v)
        tmpSet.clear()

print(len(mountSet)-1)
