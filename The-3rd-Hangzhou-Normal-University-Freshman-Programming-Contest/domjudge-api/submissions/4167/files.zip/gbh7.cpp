#include<stdio.h>
#include<stdlib.h>
#include<string.h>
void removeDuplicate(char str[]) {
	int len = strlen(str);
	int ascii[128] = { 0 };
	int p = 0;
	int i;

	for (i = 0; i < len; i++) {
		if (ascii[str[i]] == 0) {
			ascii[str[i]] = 1;
			str[p++] = str[i];
		}
	}
	str[p] = '\0';
}
int main() {
	int i, t, n, sum;
	char str[1000001];
	scanf("%d", &t);
	while (t--) {
		sum = 0;
		scanf("%d", &n);
		while (n--) {
			int sum1 = 0;
			scanf("%s", str);
			removeDuplicate(str);
			for (i = 0;i < strlen(str);i++) {
				if(str[i]!='.')
					sum1++;
			}
			sum += sum1;
		}
		printf("%d\n", sum);
	}
}

