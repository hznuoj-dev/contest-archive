#include"stdio.h"
#include"string.h"

int main()
{
	int i,len=0,c=0;
	char A[20],B[20],C[20],D[20];
	scanf("%s %s %s %s",A,B,C,D);
	for (i=0;i<strlen(A);i++)
	{
		len+=A[i]-'0';
		
		
	}
	if(len>=16 || len==6)
	  c++;
	  len=0;
		for (i=0;i<strlen(B);i++)
	{
		len+=B[i]-'0';
	
		
	}
	if(len>=16 || len==6)
	  c++;
	  len=0;
		for (i=0;i<strlen(C);i++)
	{
		len+=C[i]-'0';
		
		
	}
	if(len>=16 || len==6)
	  c++;
	  len=0;
		for (i=0;i<strlen(D);i++)
	{
	    len+=D[i]-'0';
		
	}
	if(len>=16 || len==6)
	  c++;
	
	if(c==0)
	printf("Bao Bao is so Zhai......\n");
	else if (c==1)
	printf("Oh dear!!\n");
	else if (c==2)
	printf("BaoBao is good!!\n");
	else if (c==3)
	printf("Bao Bao is a SupEr man///!\n");
	else
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	
	
}
