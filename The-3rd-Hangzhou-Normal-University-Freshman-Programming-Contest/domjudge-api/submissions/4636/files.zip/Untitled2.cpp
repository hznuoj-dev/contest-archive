#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m=0,c=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			c++;
			char a[1000005],s[50]="0",j=0;
			scanf("%s",a);
			for(int l=0;l<strlen(a);l++){
				if(a[l]!='.'){
					int b=1;
					for(int k=0;k<strlen(s);k++){
						if(a[l]==s[k]){
						b=0;
						break;
					}
					}
					if(b==1){
					m++;
					s[j++]=a[l];
				    }
				}
			}
		}
		printf("%d\n",m);
		//printf("%d\n",c);
	}
}
