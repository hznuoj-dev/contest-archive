#include<stdio.h>
main()
{
    int A,B,C,D,g=0,a,b,c,d,sum1=0,sum2=0,sum3=0,sum4=0;
    while(scanf("%d %d %d %d",&A,&B,&C,&D)!=EOF){
    while(A!=0){
		sum1=sum1+A%10;
		A=A/10;}
    while(B!=0){
		sum2=sum2+B%10;
		B=B/10;}
    while(C!=0){
		sum3=sum3+A%10;
		C=C/10;}
    while(D!=0){
		sum4=sum4+A%10;
		D=D/10;}
       if(sum1>=16||sum1==6)
         g++;
       if(sum2>=16||sum2==6)
         g++;
       if(sum3>=16||sum3==6)
         g++;
       if(sum4>=16||sum4==6)
         g++;
       if(g==0)
         printf("Bao Bao is so Zhai......\n");
       else if(g==1)
         printf("Oh dear!!\n");
       else if(g==2)
         printf("BaoBao is good!!\n");
       else if(g==3)
         printf("Bao Bao is a SupEr man///!\n");
       else
         printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}
}
