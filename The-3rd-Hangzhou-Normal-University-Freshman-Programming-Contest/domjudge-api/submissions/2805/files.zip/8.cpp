#include<stdio.h>
int main(void){
	int t,n,m;
	double p;
	char c='%';
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		p=(double)m*100/n;
		printf("[");
		while(m--){
			printf("#");
		}
		n-=m;
		while(n--){
			printf("-");
		}
		printf("] ");
		printf("%.0f",p);
		printf("%c\n",c);
	}
}
