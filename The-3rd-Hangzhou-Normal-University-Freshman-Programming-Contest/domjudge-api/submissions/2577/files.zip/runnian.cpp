#include<stdio.h>
int ans=0;
 int isleapyear(int y){
 	if((y%4==0&&y%100!=0)||(y%400==0)){
 		ans+=1;
	 }
	 return ans;
 }
int main(){
	int T,Y,A,s1,s2,i;
	scanf("%d",&T);
	while(T--){
		ans=0;
		s1=0;
		s2=0;
		scanf("%d %d",&Y,&A);
		s1=Y+A;
		if(s1>9999){
			s2=s1-9999;
			s1=9999-s2;
		}
		if(A>0&&s1<Y){
		for(i=s1;i<=Y;i++){
			isleapyear(i);
		}
	}
	   if(A>0&&s1>Y){
	   	for(i=Y;i<=s1;i++){
	   		isleapyear(i);
		   }
	   }
	    if(A<0){
	    	for(i=s1;i<=Y;i++){
	    		isleapyear(i);
			}
		}
		printf("%d\n",ans);
	}
} 
