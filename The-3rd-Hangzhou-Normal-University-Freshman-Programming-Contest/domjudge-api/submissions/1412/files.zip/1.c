#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int min(int p,int q){
	if(p>q)
	return q;
	else return p;
}
int max(int p,int q){
	if(p>q)
	return p;
	else return q;
}
int main(){
	int n,x,y,z,i,num=0;
	scanf("%d",&n);
	while(n--){
		scanf("%d%d",&x,&y);
		z=x+y;
		if(z>9999){
			z=9999-(z-9999);
		}
		for(i=min(x,z);i<=max(x,z);i++){
		if(i%4==0&&i%100!=0){
			num=num+1;
		}
		else if(i%100==0&&i%400==0){
			num=num+1;
		}	
		}
		printf("%d\n",num);
		num=0;
	}
}

	
