#include <stdio.h>
int main(void)
{
	int T,i;
   double q,n,m;
	scanf("%d",&T);
	for(i=1;i<T;i++)
	{
		scanf("%lf %lf\n",&n,&m);
		q=m/n*100;
		printf("[");
		while(m--)
		printf("#");
		while(n--)
		printf("-");
		printf("] %0.lf%%\n",q);
	
	}
	return 0;
}
