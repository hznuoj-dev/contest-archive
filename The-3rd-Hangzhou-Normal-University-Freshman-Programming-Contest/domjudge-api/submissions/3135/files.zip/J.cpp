#include <stdio.h>
#include <string.h>
int main(void){
	int t,i,j,k,n;
	scanf("%d",&t);
	int sum=0;
	for(i=1;i<=t;i++){
		scanf(" %d",&n);
		char str[1000000];
		for(j=0;j<n;j++){
			scanf("%s",str);
			int a[1000]={0};
			for(k=0;str[k]!='\0';k++){
				if(str[k]!='.'&&a[str[k]]==0){
					sum++;
					a[str[k]]=1;
				}
			}
		}
		printf("%d\n",sum);
		sum=0;
	}
	return 0;
}
