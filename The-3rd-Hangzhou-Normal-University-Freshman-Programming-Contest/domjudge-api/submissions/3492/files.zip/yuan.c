#include<stdio.h>
#pragma warning(disable:4996)
int main(){
	float T,a,b,c,i,j,x=0;
	scanf("%f",&T);
	while(T--){
		scanf("%f %f",&a,&b);
		c=a-b;
		printf("[");
		for(i=1;i<=b;i++){printf("#");}
		for(j=1;j<=c;j++){printf("-");}
		printf("]");
		printf("%.0f%%\n",b/a*100);
	}
}