#include<stdio.h>
	 int main(){
	int y,a,c;
	int t,i;
    scanf("%d",&t);
	while(t--){
	scanf("%d %d",&y,&a);
		c=y+a;
		int sum=0;
		if(c>9999){
		c=9999-(c-9999);
	if(c>y){
		for(i=y;i<=c;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
		{
				sum+=1;
		}
		}
	}
	if(c<y){
		for(i=c;i<=y;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
			sum+=1;
	}	
	}
	}
	else
		if(c>y){
		for(i=y;i<=c;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
		{
				sum+=1;
		}
		}
	}
	if(c<y){
		for(i=c;i<=y;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
			sum+=1;
	}	
	}

		printf("%d\n",sum);
}
	return 0;
} 
