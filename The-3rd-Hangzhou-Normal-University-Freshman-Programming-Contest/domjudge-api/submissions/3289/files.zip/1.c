#include <stdio.h>
#include<math.h>
int main(void) {
	int a[4],x,y,z,n=0,i;
	for (i=0;i<=3;++i){
		scanf("%d",&a[i]);
		x=a[i]%10;
		y=a[i]/10%10;
		z=a[i]/100;
		if (x+y+z>=16||z+y+x==6)
		n=n+1;
	}
	if(n==0)
	printf("Bao Bao is so Zhai......");
	else if(n==1)
	printf("Oh dear!!");
	else if(n==2)
	printf("BaoBao is good!!");
	else if(n==3)
	printf("Bao Bao is a SupEr man///!");
	else if(n==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    return 0;}
