#include<stdio.h>
int main()
{
	long long int A,B,C,D;
	int cnt=0,a=0,b=0,c=0,d=0;
	scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
	while(A!=0)
	{
		a+=A%10;
		A=A/10;
	}
	while(B!=0)
	{
		b+=B%10;
		B=B/10;
	}
	while(C!=0)
	{
		c+=C%10;
		C=C/10;
	}
	while(D!=0)
	{
		d+=D%10;
		D=D/10;
	}
	if(a>=16||a==6)cnt+=1;
	if(b>=16||b==6)cnt+=1;
	if(c>=16||c==6)cnt+=1;
	if(d>=16||d==6)cnt+=1;
	if(cnt==0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	else if(cnt==1)
	{
		printf("Oh dear!!\n");
	}
	else if(cnt==2)
	{
		printf("BaoBao is good!!\n");
	}
	else if(cnt==3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	else 
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}
