#include<stdio.h>
#include<string.h>
int main(void){

	long int T,n,i,j,jc,len,laji;
	char s[100001];
	char k[100001];
	scanf("%ld",&T);
	while(T--){
		scanf("%ld",&n);
			laji=0;	
			while(n--){
	    
			scanf("%s",s);
			len=strlen(s);
			for(i=0;i<len;i++){
				if(i==0 && s[i]!='.'){
					laji++;
					k[0]=s[0];
					jc=0;
				}
				if(i!=0 && s[i]!='.'){
					for(j=0;j<=jc;j++){
						if(s[i]==k[j])break;
					}
					if(j>jc){
						jc++;
						k[jc]=s[i];
						laji++;
					}
				}
			}
			
		}
	printf("%ld\n",laji);
	}
	return 0;
}
