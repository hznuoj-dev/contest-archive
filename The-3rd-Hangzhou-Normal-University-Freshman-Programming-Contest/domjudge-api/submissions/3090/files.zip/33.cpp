#include<stdio.h>
int main(){
    int T,y,a,b,t,s;
	scanf("%d",&T);
	while(T--){
		s=0;
		scanf("%d%d",&y,&a);
		b=y+a;
		if(b>9999){
			t=b-9999;
			b=9999-t;
		}
		if(b>=y){
		for(int i=y;i<=b;i++){
			if((i%4==0&&i%100!=0)||i%400==0)	
			s=s+1;
		}
		printf("%d\n",s);}
		else{
		for(int i=b;i<=y;i++){
			if((i%4==0&&i%100!=0)||i%400==0)	
			s=s+1;
		}
		printf("%d\n",s);	
		}
	} 
}
