#include<stdio.h>
int main(){
	int T;
	long long Y,A;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&Y,&A);
		int a,b,i;
		a=Y+A;
		int sum=0;
		if(a<Y){
			b=a;
			a=Y;
			Y=b;
		}
		if(a>9999){
			a=9999*2-a;	
		}
        for(i=Y;i<=a;i++){
        	if((i%4==0&&i%100!=0)||(i%400==0))
				sum++;
			}
		printf("%d\n",sum);
	}
	return 0;
} 
