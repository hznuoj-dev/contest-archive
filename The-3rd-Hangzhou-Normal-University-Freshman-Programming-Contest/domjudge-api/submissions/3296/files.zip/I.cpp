#include<stdio.h>
int sum1(long long a){ 
int sum=0;
	while(a>0){ 
		sum+=a%10; 
		a=a/10; 
	} 
	return sum; 
}
int main(){
	long long int a,b,c,d; 
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d); 
	if(sum1(a)>=16||sum1(a)==6) printf("Oh dear!!\n"); 
 else if(sum1(b)>=16||sum1(b)==6) printf("BaoBao is good!!\n");  
		else if(sum1(c)>=16||sum1(c)==6) printf("Bao Bao is a SupEr man///!\n"); 
	else if(sum1(d)>=16||sum1(d)==6) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n"); 
	else printf("Bao Bao is so Zhai......") ;
	
} 
