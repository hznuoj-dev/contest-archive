#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;
	cin>>n;
	while(n--){
		int x;
		cin>>x;
		int cnt=0;
		char a[2000000];
		char laji[500];
		for(int i=1;i<=x;i++){
			int m=0;
						
						scanf("%s",a);
						int len=strlen(a);
						for(int j=0;j<len;j++){
				if(a[j]!='.'){
					int ok=1;
					for(int k=0;k<m;k++){
						if(laji[k]==a[j]){
							ok=0;
						}
					}
					if(ok){
						cnt++;
						laji[m++]=a[j];
					}
				}
			}
		}
		cout<<cnt<<endl;
	}
	return 0;
}
