#include<stdlib.h>
#include<time.h>
#include<math.h>
#include<string.h>
#include<stdio.h>
int main()
{
	//int compar(const void  *a,const void *b);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\ \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/\n");
	return 0;
}

/*
int compar(const void  *a,const void *b)
{
	return *(int*)a-*(int*)b;
}
*/