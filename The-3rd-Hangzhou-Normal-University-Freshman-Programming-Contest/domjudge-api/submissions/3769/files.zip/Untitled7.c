#include<stdio.h>
#include<math.h>
int main(){
	int t;
	scanf("%d",&t);
	char p='%';
	while(t--){
		double a,b;
		scanf("%lf %lf",&b,&a);
		double c=floor(a*100*1.0/b);
		printf("[");
		for(int i=1;i<=a;i++)
		printf("#");
		for(int i=1;i<=b-a;i++)
		printf("-");
		printf("] ");
		printf("%.0f%c\n",c,p);
	}
}
