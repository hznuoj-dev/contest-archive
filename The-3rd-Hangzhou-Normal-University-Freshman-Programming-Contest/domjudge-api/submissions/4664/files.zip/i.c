#include <stdio.h>
int main(void)
{
	long long int a,b,c,d,a1=0,b1=0,c1=0,d1=0,i=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>0)
    {
	    a1=a1+a%10;
    	a=a/10;
    }
    while(b>0)
    {
	    b1=b1+b%10;
    	b=b/10;
    }
    while(c>0)
    {
	    c1=c1+c%10;
    	c=c/10;
    }
    while(d>0)
    {
	    d1=d1+d%10;
    	d=d/10;
    }
	if(a1>=16||a1==6)
	{
		i++;
	}
	if(b1>=16||b1==6)
	{
	
		i++;
	}
	if(c1>=16||c1==6)
	{
		i++;
	}
	if(d1>=16||d1==6)
	{
		i++;
	}
	
    if(i==0)
    {
		printf("Bao Bao is so Zhai......\n");
	}	
    else if(i==1)
    {	
		printf("Oh dear!!\n");
	}	
    else if(i==2)
    {	
		printf("BaoBao is good!!\n");
	}
    else if(i==3)
    {
		printf("Bao Bao is a SupEr man///!\n");
	}	
    else if(i==4)
    {
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	
	return 0;
}
