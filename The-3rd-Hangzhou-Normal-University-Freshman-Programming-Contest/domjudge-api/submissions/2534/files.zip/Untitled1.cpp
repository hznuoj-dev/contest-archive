#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	long long a,len,sum=0;
	char b[100000];
	scanf("%lld",&a);
	gets(b);
	while(a--)
	{
		gets(b);
		len=strlen(b);
		sum=sum+len; 
	}
	printf("%lld",sum);
 } 
