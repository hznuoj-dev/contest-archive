#include <stdio.h>

int main(){
	int time;
	scanf("%d",&time);
	while(time--){
		int m,n;
		scanf("%d %d",&m,&n);
		int result = n*100/m;
		printf("[");
		for(int i = 0; i < n; i++){
			printf("#");
		}
		for(int i = 0; i < m-n; i++){
			printf("-");
		}
		printf("]%d%\n",result);
	}
}
