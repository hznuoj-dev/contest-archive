#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int f(int n);
int main(int argc, char *argv[]) {
	int a,b,c,d,s=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(f(a)>=16||f(a)==6)
	s++; 
		if(f(b)>=16||f(b)==6)
	s++; 
		if(f(c)>=16||f(c)==6)
	s++; 
		if(f(d)>=16||f(d)==6)
	s++; 
	if(s==0)
	printf("Bao Bao is so Zhai......");
	else if(s==1)
	printf("Oh dear!!");
	else if(s==2)
		printf("BaoBao is good!!");
	else if(s==3)
		printf("Bao Bao is a SupEr man///!");
	else if(s==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
	return 0;
}
int f(int n){
	int s=0;
	while(n){
		s+=n%10;
		n=n/10;
	}
	return s;
}
