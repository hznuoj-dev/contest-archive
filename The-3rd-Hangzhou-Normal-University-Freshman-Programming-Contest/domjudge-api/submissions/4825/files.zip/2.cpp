#include<stdio.h> 
int main(){
	int a,b,c,d,x=0,t;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	int A=a;
	int B=b;
	int C=c;
	int D=d;
	int i,sum;
	sum=0;
	for(i=10;i<A*10;i*=10){
		t=a%i;
		sum+=t;
		a=a/i;	
	}
	if(sum>=16||sum==6)
	x=x+1;
		sum=0;
	for(i=10;i<B*10;i*=10){
		t=b%i;
		sum+=t;
		b=b/i;	
	}
	if(sum>=16||sum==6)
	x=x+1;
		sum=0;
		for(i=10;i<C*10;i*=10){
		t=c%i;
		sum+=t;
		c=c/i;	
	}
	if(sum>=16||sum==6)
	x=x+1;
		sum=0;
		for(i=10;i<D*10;i*=10){
		t=d%i;
		sum+=t;
		d=d/i;	
	}
	if(sum>=16||sum==6)
	x=x+1;
	if(x==0)
	printf("Bao Bao is so Zhai......\n");
	else if(x==1)
	printf("Oh dear!!\n");
	else if(x==2)
	printf("BaoBao is good!!\n");
	else if(x==3)
	printf("Bao Bao is a SupEr man///!\n");
	else if(x==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
return 0;	
}
