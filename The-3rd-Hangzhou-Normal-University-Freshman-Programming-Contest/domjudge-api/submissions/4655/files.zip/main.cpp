//#include <bits/stdc++.h>
//typedef long long  ll;
//const int MAXN=1e2+5;
#include <cstdio>
#include <algorithm>
#include <iostream>
#include <string.h>
using namespace std;
int  b,c,d,l,mid,sum=0,n,m=0,x,w,v,y,ans,x2,y2;
char t[1000100],a[1000100];
int main()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>w;
        for(int i=1; i<=w; i++)
        {
            cin>>a;
            c=strlen(a);
            for(int i=0; i<c; i++)
            {
                if(a[i]!='.'&&m==0)
                {
                    t[m]=a[i];
                    m++;
                    continue;
                }
                if(a[i]!='.')
                    for(int j=0; j<m; i++)
                        if(a[i]==t[j])
                            break;
                        else if( j==m-1)
                        {
                            t[m]=a[i];
                            m++;
                        }
            }
            sum+=m;
            m=0;
        }
        cout<<sum<<'\n';
        sum=0;
    }
    return 0;
}


