#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d%d",&n,&m);
	    printf("[");
		double i;
		i=m*100/n;

		if(m==0){
			for(int i=1;i<n;i++){
				printf("-");
			}
		}
				for(int j=1;j<=m;j++){
			if (j==1)
			{
				printf("[#");
			}
            else
             printf("#");
		}
		for(int j=1;j<=n-m;j++){
			if(j==n-m){
				printf("-]")
			}
			else
			{
				printf("-");
			}
		}
		printf("%lf%%",i);
	}
	return 0;
}