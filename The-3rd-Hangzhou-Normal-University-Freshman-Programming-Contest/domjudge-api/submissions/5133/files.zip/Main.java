import java.util.*;
public class Main
{
    public static void main(String[] args) 
    {
    	Scanner s=new Scanner (System.in);
		while (s.hasNext())//.表示没有垃圾，其他任何字符都表示垃圾，每种字符表示一种垃圾 要求计算整个豪宅每层楼垃圾种类的总和
		{
			int t=s.nextInt();
			for (int i=1;i<=t;i++)
			{
				int n=s.nextInt();
				int sum=0;
				for (int j=1;j<=n;j++)
				{
					String a=s.next().replace(".","");
					Set<Character>list=new TreeSet<>();
					for (int x=1;x<=a.length();x++)
					{ 
						list.add(a.charAt(x-1));
					}
					System.out.println(list);
					sum=sum+list.size();
				}
				System.out.println(sum);
				
			}
		}
    }
}