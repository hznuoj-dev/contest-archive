#include <stdio.h>
#include <math.h> 
int main(){
	int t;
	scanf("%d", &t);
	while(t--){
		int m, n, i;
		scanf("%d%d", &m, &n);
		double x;
		int y;
		x=(double)(n*100)/(double)m;
		y=(int)x*1;
		printf("[");
		m=m-n;
		while(n--){
			printf("#");
		}
		while(m--){
			printf("-");
		}
		printf("] "); 
		printf("%d%%\n", y);
	}
}



































