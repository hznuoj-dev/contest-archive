#include<stdio.h>
 int main(void)
 {
 	long int a,b,c,d,i1,i2,i3,i4,i=0;
 	scanf("%ld%ld%ld%ld",&a,&b,&c,&d);
 	for(i1=0;a!=0;)
 	{
 		i1=i1+(a%10);
 		a=a/10;
	 }
	 for(i2=0;b!=0;)
 	{
 		i2=i2+(b%10);
 		b=b/10;
	 }
	 for(i3=0;c!=0;)
 	{
 		i3=i3+(c%10);
 		c=c/10;
	 }
	 for(i4=0;d!=0;)
 	{
 		i4=i4+(d%10);
 		d=d/10;
	 }
	 if(i1==6||i1>=16)
	 i++;
	 if(i2==6||i2>=16)
	 i++;
	 if(i3==6||i3>=16)
	 i++;
	 if(i4==6||i4>=16)
	 i++;
	 if(i==1)
	 printf("Oh dear!!");
	 if(i==2)
	 printf("BaoBao is good!!");
	 if(i==3)
	 printf("Bao Bao is a SupEr man///!");
	 if(i==4)
	 printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	 if(i==0)
	 printf("Bao Bao is so Zhai......");
 	 return 0;
 }
