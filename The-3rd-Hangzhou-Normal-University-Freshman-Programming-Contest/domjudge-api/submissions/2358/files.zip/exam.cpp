#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	char a[19],b[19],c[19],d[19];
	int out=0,i,sum=0;
	scanf("%s %s %s %s",a,b,c,d);
	for(i=0;i<strlen(a);i++) sum+=a[i]-'0';
	if(sum>=16||sum==6) out++;
	sum=0;
	for(i=0;i<strlen(b);i++) sum+=b[i]-'0';
	if(sum>=16||sum==6) out++;
	sum=0;
	for(i=0;i<strlen(c);i++) sum+=c[i]-'0';
	if(sum>=16||sum==6) out++;
	sum=0;
	for(i=0;i<strlen(d);i++) sum+=d[i]-'0';
	if(sum>=16||sum==6) out++;
	out==0?printf("Bao Bao is so Zhai......"):out==1?printf("Oh dear!!"):out==2?printf("BaoBao is good!!"):out==3?printf("Bao Bao is a SupEr man///!"):printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}
