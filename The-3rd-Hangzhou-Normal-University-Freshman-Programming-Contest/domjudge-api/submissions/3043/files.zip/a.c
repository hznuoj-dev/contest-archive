#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include <string.h>
int main()
{
    int t, n, m,i;
    scanf("%d", &t);
    while (t--) {
        scanf("%d %d", &n, &m);
        printf("[");
        for (i = 1;i <= n;i++) {
            if (i <= m) {
                printf("#");
            }
            else {
                printf("-");
            }
        }
        printf("]");
        if(n)
        printf("%d", m* 100 / n );
        printf("%c\n",37);
    }
    return 0;
}