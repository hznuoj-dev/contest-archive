#include<stdio.h>
int main()
{
	int T,Y,A,i,j;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&Y,&A);
		j=0;
		if(A>0)
		{
			for(i=1;i<=A;++i)
			{
				Y=Y+1;
				if(Y>9999)
					break;
				else if((Y%4==0 && Y%100!=0) || (Y%400==0))
					++j;
			}
		}
		else
		{
			for(i=-1;i>=A;--i)
			{
				Y=Y-1;
				if(Y>9999)
					break;
				 else if((Y%4==0 && Y%100!=0) || (Y%400==0))
					++j;
			}
		}
		printf("%d\n",j);
	}
	return 0;
}