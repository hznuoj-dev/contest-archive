#include <stdio.h>
int main(void){
	int t,y,a,b=0,i=0,c=0,count=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&y,&a);
		if(y+a>9999)
			b=9999-(y+a-9999);
		else
			b=y+a;
		if(b<=y){
			c=y;
			y=b;
			b=c;
		}
		for(i=y;i<=b;i++){
			if((i%4==0 && i%100!=0)||(i%400==0))
				count+=1;
		}
		printf("%d\n",count);
		b=0,c=0,count=0;
	}
	return 0;
}