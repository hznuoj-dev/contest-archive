#include <stdio.h>
int rank[1001][1001];
int main(){
	int t,n,m,name[2],i,j,x,a[1001],d,e;
	scanf("%d",&t);
	while(t--){
		e=0;
		d=0;
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++){
			a[i]=0;
			for(j=1;j<=n;j++){
				rank[i][j]=0;
			}			
		}
		while(m--){
			scanf("%d%d",&name[0],&name[1]);
			rank[name[0]][name[1]]=1;
		}
		for(i=1;i<=n;i++){
			for(j=1;j<=n;j++){
				if(rank[i][j]==1){
					if(a[j]>a[i])
						a[i]=a[j];
					a[j]=a[i]+1;
				}
			}			
		}
		while(1){
			for(j=1;j<=n;j++){
				if(a[j]==e){
					printf("%d ",j);
					d++;
				}				
			}
			e++;
			if(d==n){
				break;
			}
		}
		printf("\n");
	}
	return 0;
}
