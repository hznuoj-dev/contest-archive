#include<stdio.h>
int main(){
	int t,n,m,i;
	double p;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=1;i<=m;i++){
			printf("#");
		}
		for(i=1;i<=n-m;i++){
			printf("-");
		}
		printf("]");
		p=(double)m/n;
		printf(" %.0f%%\n",p*100);
	}
}
