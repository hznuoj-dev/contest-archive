#include<stdio.h>

int tongji(int x);
int main()
{
	int x;
	int count = 0;
	
	for(int i = 1; i <= 4; i++){
		scanf("%d", &x);
		if(tongji(x) == 6 || tongji(x) >= 16){
			count++;
		} 
	}
	if(count == 0){
		printf("Bao Bao is so Zhai......");
	} 
	if(count == 1){
		printf("Oh dear!!");
	} 
	if(count == 2){
		printf("BaoBao is good!!");
	} 
	if(count == 3){
		printf("Bao Bao is a SupEr man///!");
	} 
	if(count == 4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	} 
	return 0;
} 
int tongji(int x)
{
	int result = 0;
	while(x != 0){
		result += x % 10;
		x /= 10;
	}
	return result;
}
