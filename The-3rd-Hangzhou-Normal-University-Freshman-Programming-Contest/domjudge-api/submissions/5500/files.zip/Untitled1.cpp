#include<stdio.h>
int main()
{
	int t;
		double n,m,a=0,w=0,q=0;
	scanf("%d",&t);
	while(t--)
{
	a=0;
	scanf("%lf%lf",&n,&m);
	q=n;
	w=m;
      printf("[");
    while(m--)
    {
    	printf("#");
	}
	a=q-w;
	while(a--)
	{
	printf("-");
}
    printf("]");
	printf(" %.lf%%",w/q*100);

}
	return 0;
}
