#include<stdio.h>
#include<string.h>


int main(){
	int t,n;
	
	scanf("%d",&t);
	while(t--)
	{
		int i,m,y,sum=0;
		char str[101];
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			int g,k;
			int va[300]={0};
			scanf("%s",str);
			m=strlen(str);
			for(g=0;g<m;g++)
			{
				k=str[g];
				if(str[g]!='.')
				{va[k]++;}
			}
			for(y=0;y<=300;y++)
		{
			if(va[y]>0)
			{
			sum++;
			}
		}

		}
		
		printf("%d\n",sum);
	}


return 0;
}

