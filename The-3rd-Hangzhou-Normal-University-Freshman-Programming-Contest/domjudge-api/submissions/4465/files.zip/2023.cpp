#include<stdio.h>
int main()
{
	int r;
	double a,b,c;
	scanf("%d",&r);
	for(int i=0;i<r;i++){
		scanf("%lf%lf",&a,&b);
		c=b/a*100;
		printf("[");
		for(int i=0;i<b;i++){
			printf("#");
		}
		for(int i=0;i<a-b;i++){
			printf("-");
		}
		printf("] %.0lf%%\n",c);
	}
	return 0;
}
