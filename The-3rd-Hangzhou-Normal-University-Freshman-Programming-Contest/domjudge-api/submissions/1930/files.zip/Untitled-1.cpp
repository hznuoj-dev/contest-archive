#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>


using namespace std;

char A[22], B[22], C[22], D[22];


int main(){
	int i, a=0, b=0, c=0, d=0, la, lb, lc, ld, max;
	scanf("%s %s %s %s", A, B, C, D);
	getchar();
	la=strlen(A);lb=strlen(B);lc=strlen(C);ld=strlen(D);
	
	for(i=0;i<la;i++)a+=A[i]-48;
	for(i=0;i<lb;i++)b+=B[i]-48;
	for(i=0;i<lc;i++)c+=C[i]-48;
	for(i=0;i<ld;i++)d+=D[i]-48;
	
	
	
//	cout << a << b <<c <<d;
	
	int f=0;
	if(a>=16||a==6)f++;
	if(b>=16||b==6)f++;
	if(c>=16||c==6)f++;
	if(d>=16||d==6)f++;
	if(f==0)cout << "Bao Bao is so Zhai......\n";
	else if(f==1) cout << "Oh dear!!\n";
	else if(f==2) cout << "BaoBao is good!!\n";
	else if(f==3) cout << "Bao Bao is a SupEr man///!\n";
	else if(f==4) cout << "Oh my God!!!!!!!!!!!!!!!!!!!!!\n";
	return 0;
}
