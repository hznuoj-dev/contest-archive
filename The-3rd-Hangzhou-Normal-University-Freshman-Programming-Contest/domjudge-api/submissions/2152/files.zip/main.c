#include <stdio.h>
#include <stdlib.h>
#include <math.h>


int main(void){
	int n,a,b,s,p,i,j;
	scanf("%d",&n);
	n=n-1;
	scanf("%d",&a);
	s=1;
	while(n--){
		scanf("%d",&b);
		p=abs(b-a);
		j=1;
		for(i=a;i>a-p&&s<998244353;--i){
			
			s=s*i/j;
			j=j+1;
		}
		if(s>=998244353)
			break;
		a=b;
		
	}
	printf("%d\n",s);
	
	return 0;
}
