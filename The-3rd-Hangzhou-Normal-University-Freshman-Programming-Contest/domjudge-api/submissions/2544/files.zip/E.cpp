#include <stdio.h>
int main(void)
{
	char z[3];
	scanf("%s",z);
	printf(" __      _____\n");
	printf(" | | ___/ ____\\____\n");
	printf(" | |/ /\\   __\\/ ___\\ \n");
	printf(" |   <   |  | \\  \\___\n");
	printf(" |__|_ \\ |__|  \\___   >\n");
	printf("      \\/           \\/\n");
    return 0;
}
