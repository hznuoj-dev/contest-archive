#include<stdio.h>
int main(){
	char p='%';
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b;
		scanf("%d %d",&b,&a);
		int c,d,s=0;
		for(int i=1;i<=a;i++){
			if(a%i==0&&b%i==0)
			s=i;
		}
		c=a/s,d=b/s;
		if(a==0){
			printf("[");
			for(int i=1;i<=b;i++)
			printf("#");
			printf("]");
			printf(" 0%c\n",p);
		}else if(d==8){
		
		
			printf("[");
	for(int i=1;i<=a;i++)
	printf("#");
	for(int i=1;i<=b-a;i++)
	printf("-");
	printf("]");
	printf(" %.1f%c\n",1.0*c*100/d,p);
}
		else {
		printf("[");
	for(int i=1;i<=a;i++)
	printf("#");
	for(int i=1;i<=b-a;i++)
	printf("-");
	printf("]");
	printf(" %.0f%c\n",1.0*a*100/b,p);
}
}
}
