#include<stdio.h>
int main(){
int t;
scanf("%d",&t);
while(t--){
   int a,s,y,z,count=0;
    scanf("%d%d",&y,&a);
	if(a<0){
	s=a+y;
	for(int i=s;i<=y;i++){
		if(i%4==0&&i%100!=0||i%400==0){
		count=count+1;
		}
	}
}
	else  if(a>=0){
		s=a+y;
		if(s>=9999){
			z=s-9999;
			if(9999-z>=y){
			for(int i=y;i<=9999-z;i++){
		if(i%4==0&&i%100!=0||i%400==0){
		count=count+1;
		   }
	    }
     }
}
			else if(9999-z<y){
			for(int i=9999-z;i<=y;i++){
		if(i%4==0&&i%100!=0||i%400==0){
		count=count+1;
		}
			}
	    }
	}
	printf("%d\n",count);
}
return 0;
}