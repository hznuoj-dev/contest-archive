#include<stdio.h>
int main() {
	int T;
	int m, n, h,x,y;
	scanf("%d", &T);
	while (T--) {
		scanf("%d%d", &m, &n);
		x = m; y = n;
		h = m - n;
		printf("[");
		while (n > 0) {
			printf("#");
			n--;
		}
		while (h > 0) {
			printf("-");
			h--;
		}
		printf("] ");
		printf("%d%%", y*100 / x );
		printf("\n");
	}
	return 0;
}