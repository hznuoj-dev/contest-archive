#include <stdio.h>
#include <math.h>
int main()
{
	long long  max = 998244353; 
    long long n,x;
    scanf("%d",&n);
    long long a[100010]={0};
    for(int i=1;i<=n;++i)
	{
		scanf("%d",&x);
		a[x]+=1;
	 } 
	long long sum=0;
	sum=a[1];
	for(int i=2;i<=100000;++i)
	{
		if(a[i]!=0)
		{
			for(int j=1;j<=a[i];++j)
			{
			
			    sum = sum * a[i-1];
				if(sum>=max)
				{
					sum=sum%max;
				}
		    }
		}
		else
		   break; 
	}
	sum=sum%max;
	printf("%lld\n",sum);
	return 0;
 } 
