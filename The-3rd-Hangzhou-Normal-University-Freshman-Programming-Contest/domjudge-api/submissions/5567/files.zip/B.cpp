#include<stdio.h>
#include<math.h>
int main(){
    int t,a,b,c;
    scanf("%d",&t);
    while(t--){
    	int m=0;
    	scanf("%d %d",&a,&b);
    	c=9999-(a+b-9999);
    	if(c<0)
    	    c=1;
    	if(a>c){
    		for(int i=c;i<=a;i++){
    			if(i%4==0&&i%100!=0||i%400==0){
    				m++;
				}
			}
		}
		else{
			for(int i=a;i<=c;i++){
    			if(i%4==0&&i%100!=0||i%400==0){
    				m++;
				}
			}
		}
		printf("%d\n",m);
	}
}
