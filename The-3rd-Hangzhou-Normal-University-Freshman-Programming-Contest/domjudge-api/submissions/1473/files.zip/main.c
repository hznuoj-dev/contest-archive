#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int isp(int i);
int main(int argc, char *argv[]) {
	int t,y,a,b,x,i,m;
	scanf("%d",&t);
	while(t--){
		
		scanf("%d %d",&y,&a);
		if(y+a>=10000)
			b=9999-(a+y-9999);
	 	else
	 		b=a+y;
		m=0;

	if(y>b){
	
	x=y;
	y=b;
	b=x;	
	}
	for(i=y;i<=b;++i){
		if(isp(i))
			m++;
	}
	printf("%d\n",m);
}
	return 0;
}
int isp(int i){
	if(i%400==0||i%4==0&&i%100!=0)
		return 1;
	else
		return 0;
	
	
}
