#include<math.h> 
#include<stdio.h> 
#include<string.h>   
//using namespace std;
 int main()  
{	char s[85];
	scanf("%s",&s);
	
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/\n");
}
