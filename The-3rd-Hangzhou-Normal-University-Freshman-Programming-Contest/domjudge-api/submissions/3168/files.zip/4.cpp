#include <bits/stdc++.h>
using namespace std;
int main() {
	int n,res=0;
	cin>>n;
	for (int i=1;i<=n;i++) {
		string s;
		cin>>s;
		res+=s.length();
	}
	cout<<res;
}
