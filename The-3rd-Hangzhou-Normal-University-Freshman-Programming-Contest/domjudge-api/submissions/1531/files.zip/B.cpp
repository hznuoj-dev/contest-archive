#include <stdio.h>
int main (void){
	int t,i,j,m,n;
	int s=0;
	int y,a,y2;
	scanf("%d ",&t);
	for(i=1;i<=t;i++){
		scanf("%d %d",&y,&a);
		y2=y+a;
		if(y>9999){
			y=9999-(y-9999);
		}
		if(y2>9999){
			y2=9999-(y2-9999);
		}
		if(y>y2){
			m=y2;
			n=y;
		}
		else{
			m=y;
			n=y2;
		}
		for(j=m;j<=n;j++){
			if((j%400==0)||(j%4==0&&j%100!=0)){
				s++;
			}
		}
		printf("%d\n",s);
		s=0;
	}
}
