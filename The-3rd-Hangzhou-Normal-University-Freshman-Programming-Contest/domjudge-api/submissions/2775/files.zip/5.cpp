#include<stdio.h>
int main(){
	int t;
	int n,m,i;
	double r;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		r=m*1.0/n;
		printf("[");
		for(i=1;i<=m;i++){
			printf("#");
		}
		for(i=1;i<=n-m;i++){
		printf("-");} 
		printf("]%.0lf%c\n",r*100,'%');
	}
	return 0;
}
