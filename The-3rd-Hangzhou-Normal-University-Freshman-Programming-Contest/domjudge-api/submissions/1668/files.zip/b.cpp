#include<stdio.h>
int main()
{
	int T,Y,A,B=0,C=0,D=0,m=0,n=0;
	scanf("%d\n",&T);
	while(T--)
	{
		int x=0;
		scanf("%d %d\n",&Y,&A);
		m=Y+A;
		if(m>9999){
			n=m-9999;
			B=9999-n;
			if(Y<=B){
				for(C=Y;C<=B;C++){
					if((C%4==0)&&(C%100!=0)||(C%400==0))
					  x=x+1;
				}	
			}
			else{
				for(C=B;C<=Y;C++){
					if((C%4==0)&&(C%100!=0)||(C%400==0))
					  x=x+1;
				}
			}
		}
		else{
			D=Y+A;
			for(C=Y;C<=D;C++){
				if((C%4==0)&&(C%100!=0)||(C%400==0))
					x=x+1;
			}
		}
		printf("%d\n",x);
	}
	printf("\n");
	return 0;
 } 
