#include<stdio.h>
int main(void)
{
int t=1;
int time=0;
int y=0,a=0;
int sum=0,sum1=0;
int i,j=0;
scanf("%d",&t);
for(time=0;time<t;time++)
{
	scanf("%d %d",&y,&a);
	sum=y+a;
	if(a<=0)
	{
		for(i=sum;i<=y;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			{
				j++;
			}
		}
	}
	else
	{
	if(sum<=9999)
	{
		for(i=y;i<=sum;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			{
				j++;
			}
		}
	}
	else
	{
		sum1=9999-((y+a)-9999);
		if(sum1>=y)
		{
		for(i=y;i<=sum1;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			{
				j++;
			}
		}
	    }
	    else
	    {
	    for(i=sum1;i<=y;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			{
				j++;
			}
		}	
		}
	}
    }
	printf("%d",j); 
	if(time!=t-1)
	printf("\n");
	sum=0;
	sum1=0;
	j=0;
}
return 0;
} 
