import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		while (in.hasNext())
		{
			int t = in.nextInt();
			for (int i = 0; i < t; i++)
			{
				int y = in.nextInt();
				int a = in.nextInt();
				if (y + a > 9999) a = 9999 - (y + a - 9999);
				else a = y + a;
				int start=Math.min(a, y);
				int end=Math.max(a,y);
				int count=0;
				for(int j=start;j<=end;j++) 
                                                                {
					if ((j % 4 == 0 && j % 100 != 0) || j % 400 == 0) count++;
				}
				System.out.println(count);
			}
		}
	}
}
