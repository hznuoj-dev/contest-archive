#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void)
{
	int t,a,b,i;
	char c='%';
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&a,&b);
		printf("[");
		for(i=1;i<=b;++i)
		{
			printf("#");
		}
		for(i=1;i<=a-b;++i)
		{
			printf("-");
		}
		printf("] ");
		printf("%d",b*100/a);
		printf("%c\n",c);
	}

	return 0;
}