#include<bits/stdc++.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	getchar();
	int a[130];
	
	while(t--)
	{
		int cnt=0;
		int h;
		cin>>h;
		getchar();
		while(h--)
		{
			string s;
			getline(cin,s);
			for(int i=0;i<s.length();i++)
			{
				if(s[i] != '.' && a[s[i]] == 0)  {
					a[s[i]] ++;
					cnt++;
				}
			}	
			memset(a,0,sizeof(a));
		}
		cout<<cnt<<endl;
		
	}
	
	
	return 0;
}
