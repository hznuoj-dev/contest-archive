#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
	int t, n, m, i, a[10000], b[10000], c[1001], j, q = 0;
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &n, &m);
		for (i = 1; i <= n; i++) {
			c[i] = i;
		}
		for (i = 0; i < m; i++) {
			scanf("%d %d", &a[i], &b[i]);
			if (a[i] > b[i]) {
				for (j = b[i]; j < a[i]; j++) {
					c[b[i]] = a[i];
					c[a[i]] = b[i];
				}
			}
		}
		for (i = 1; i <= n; i++) {
			if (i != n) {
				printf("%d ", c[i]);
			}
			else {
				printf("%d", c[i]);
			}
		}
	}
	return 0;
}