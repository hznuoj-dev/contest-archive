#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int n, a, b, i, j;
	double m;
	scanf("%d", &n);
	while (n--)
	{
		scanf("%d %d", &a, &b);
		m = ((b * 1.0) / (a * 1.0)) * 100;
		printf("[");
		for (i = 0; i < b; ++i)
		{
			printf("#");
		}
		for (j = 0; j < a - b; ++j)
		{
			printf("-");
		}
		printf("] %d%%\n", (int)m);
	}
	return 0;
}