 #include <set>
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <cmath>
#include <ctime>
#include <bitset>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const int maxn = 1e5 + 10;
const int mod = 0;
const int inf = 0x3f3f3f3f;

int gcd(int a, int b) 
{
	return b==0?a:gcd(b,a%b);
}
bool check(int a){
	if(a%4==0&&a%100!=0||(a%400==0))return true;
	return false;
}
int main()
{
	int p[maxn];
    int t;
cin>>t;
string s;
while(t--)
{
	int num=0;
	int n;
	cin>>n;
	while(n--){
		cin>>s;
		int ans=0;
		memset(p,0,sizeof p);
		for(int i=0;i<s.length();i++){
			if(s[i]!='.')
			{
				if(p[int(s[i])]==0)
				{
				p[int(s[i])]=1;
				//cout<<s[i]<<" "<<p[int(s[i])]<<endl;
				ans++;
				}
			}
		}
		num+=ans;
	}
	cout<<num<<endl;
}
	return 0;
}
