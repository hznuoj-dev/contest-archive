#include<stdio.h>
int main(void){
	int n,a,b,c,i,s,t;
	scanf("%d",&n);
	while(n--){
		s=0;
		scanf("%d%d",&a,&b);
		c=a+b;
		if(c>=10000)
		c=9999*2-c;
		if(a>c)
		t=a,a=c,c=t;
	for(i=a;i<=c;i++){
		if((i%4==0&&i%100!=0)||i%400==0)
		s++;
	}
	printf("%d\n",s);
	}
	
	
	
	
	
	return 0;
}
