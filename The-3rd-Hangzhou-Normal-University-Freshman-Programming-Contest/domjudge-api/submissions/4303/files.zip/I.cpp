#include <stdio.h>
#include<string.h>
#define STRING_LENGTH 10000
int length(const char *str); 
int main ()
{
	int lengtha,lengthb,lengthc,lengthd,i;
	int suma=0,sumb=0,sumc=0,sumd=0,sum=0;
	int a,b,c,d;
	char stra[STRING_LENGTH+1];
	char strb[STRING_LENGTH+1];
	char strc[STRING_LENGTH+1];
	char strd[STRING_LENGTH+1];

	scanf("%s",stra);
	scanf("%s",strb);
	scanf("%s",strc);
	scanf("%s",strd);

	lengtha=length(stra);
	lengthb=length(strb);
	lengthc=length(strc);
	lengthd=length(strd);

	for(i=0;i<lengtha;i++)
	{
		a=stra[i];
		suma+=a-48;	
	}
	if(suma>=16||suma==6)
	sum+=1;
	
	for(i=0;i<lengthb;i++)
	{
		b=strb[i];
		sumb+=b-48;	
	}
	if(sumb>=16||sumb==6)
	sum+=1;
	
	for(i=0;i<lengthc;i++)
	{
		c=strc[i];
		sumc+=c-48;	
	}
	if(sumc>=16||sumc==6)
	sum+=1;
	
	for(i=0;i<lengthd;i++)
	{
		d=strd[i];
		sumd+=d-48;	
	}
	if(sumd>=16||sumd==6)
	sum+=1;
	
	if(sum==0)
	printf("Bao Bao is so Zhai......");
	else if(sum==1)
	printf("Oh dear!!");
	else if(sum==2)
	printf("BaoBao is good!!");
	else if(sum==3)
	printf("Bao Bao is a SupEr man///!");
	else
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
	return 0;
}
int length(const char *str)
{
	int i=0;
	while(str[i]!='\0')
		++i;
	return i;
}

