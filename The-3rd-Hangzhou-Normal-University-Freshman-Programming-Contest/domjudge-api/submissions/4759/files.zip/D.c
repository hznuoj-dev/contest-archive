#include<stdio.h>
#include<string.h>
int main(void){
int n,len,i,s=0,flag=1;
char a[10000];
scanf("%d",&n);
getchar();
while(n--){
gets(a);
len=strlen(a);
for(i=0;i<len/2-1;i++){
	if(a[i]!=a[len-1-i]){
		flag=0;break;
	}
}
if(flag)
s++;}
printf("%d",s);
	return 0;
}
