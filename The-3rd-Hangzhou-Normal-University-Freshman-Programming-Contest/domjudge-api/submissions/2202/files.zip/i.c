#include <stdio.h>
#include <string.h>
int pd(char *a){
	int s=0,i;
	int len=strlen(a);
	for (i=0;i<len;i++){
		s+=a[i]-'0';
	}
	if (s==6||s>=16) return 1;
	else return 0;
}
int main(){
	char b[20];
	char c[20];
	char d[20];
	char e[20];
	int sum=0;
	int t=4;
	scanf("%s %s %s %s",b,c,d,e);
	sum+=pd(c);
	sum+=pd(b);
	sum+=pd(d);
	sum+=pd(e);
	switch(sum){
		case 0:printf("Bao Bao is so Zhai......");break;
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
}
