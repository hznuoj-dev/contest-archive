#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int main(){
    int temp,ans,sum;
    ans = sum = 0;
    string a,b,c,d;

    cin >> a >> b >> c >> d;
    for(int i =0;i<a.size();i++){
        temp = a[i] - '0';
        sum += temp;
    }
    if(sum>=16||sum==6)
        ans ++;
    sum = 0;
    for(int i =0;i<b.size();i++){
        temp = b[i] - '0';
        sum += temp;
    }
    if(sum>=16||sum==6)
        ans ++;
    sum = 0;
    for(int i =0;i<c.size();i++){
        temp = c[i] - '0';
        sum += temp;
    }
    if(sum>=16||sum==6)
        ans ++;
    sum = 0;
    for(int i =0;i<d.size();i++){
        temp = d[i] - '0';
        sum += temp;
    }
    if(sum>=16||sum==6)
        ans ++;
    
 
    
    switch(ans){
        case 1:
            cout << "Oh dear!!" << endl;
            break;
        case 2:
            cout << "BaoBao is good!!" << endl;
            break;
        case 3:
            cout << "Bao Bao is a SupEr man///!" << endl;
            break;
        case 4:
            cout << "Oh my God!!!!!!!!!!!!!!!!!!!!!" << endl;
            break;
        default:
            cout << "Bao Bao is so Zhai......" << endl;
            break;
    }
    return 0;
}

    

