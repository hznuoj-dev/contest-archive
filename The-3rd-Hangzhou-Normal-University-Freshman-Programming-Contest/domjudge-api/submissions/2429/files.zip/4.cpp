#include <stdio.h>
int main(void){
	long long a,b,c,d,e,f,g,h,i;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	e=0,f=0,g=0,h=0,i=0;
	while(a>0){
		e=e+a%10;
		a=a/10;
	}
	while(b>0){
		f=f+b%10;
		b=b/10;
	}
	while(c>0){
		g=g+c%10;
		c=c/10;
	}
	while(d>0){
		h=h+d%10;
		d=d/10;
	}
	if(e>=16||e==6){
		i=i+1;
	}
	if(f>=16||f==6){
		i=i+1;
	}
	if(g>=16||g==6){
		i=i+1;
	}
	if(h>=16|h==6){
		i=i+1;
	}
	if(i==0){
		printf("Bao Bao is so Zhai......");
	}
	else if(i==1){
		printf("Oh dear!!");
	}
	else if(i==2){
		printf("BaoBao is good!!");
	}
	else if(i==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else if(i==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	return 0;
} 
