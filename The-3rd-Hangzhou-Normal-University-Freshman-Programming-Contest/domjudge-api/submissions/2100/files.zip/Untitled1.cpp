#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	long long i,j,sum,a,b,sum1=0;
	for(i=1;i<=4;i++)
	{
		scanf("%lld",&a);
		sum=0;
		while(a!=0)
		{
			b=a%10;
			a=a/10;
			sum=sum+b; 
		}
		if(sum>=16||sum==6)
		{
			sum1=sum1+1;
		}
	}
	if(sum1==0)
	{
		printf("Bao Bao is so Zhai......");
	}
	if(sum1==1)
	{
		printf("Oh dear!!");
	}
	if(sum1==2)
	{
		printf("BaoBao is good!!");
	}
	if(sum1==3)
	{
		printf("Bao Bao is a SupEr man///!");
	}
	if(sum1==4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
 } 
