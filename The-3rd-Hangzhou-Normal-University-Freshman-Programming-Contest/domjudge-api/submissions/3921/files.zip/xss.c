#include<stdio.h>
#include<string.h>
int main()
{
	int t, n, c, i, h, len, j, f, m;
	char a[99][999],s[100000];

	scanf("%d", &t);
	c = 0;
	while (t--)
	{
		scanf("%d", &n);
		m = 0;
		
		while (n--)
		{
			scanf("%s", &a[c]);
			len = strlen(a[c]);
			h = 0;
			
			for (i = 0;i < len;++i)
			{
				if (a[c][i]!='.')
				{
					f = 1;
					for (j = 0;j < h;++j)
					{
						if (s[j] ==a[c][i])
						{
							f = 0;
						}
					}
					if (f == 1)
					{
						m += 1;
						s[h] = a[c][i];
						h = h + 1;
					}
				}
				
			}
			c += 1;
		}
		printf("%d\n", m);
	}
}