#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int hh(const void*a,const void*b){
	return *(char*)a-*(char*)b;
} 
int main(void){
	int t,n;
	char w[1000000];
	scanf("%d",&t);
	while(t--){
		int nn=0,kk;
		scanf("%d ",&n);
		for(int zz=0;zz<n;zz++){
			kk=0;
			nn++;
			gets(w);
			int ww=strlen(w);
			qsort(w,ww,sizeof(char),hh);
			for(int i=0;i<ww;i++){
				if(w[i]=='.'){kk=1;}
				if(w[i]!=w[i-1]&&i>=1){nn++;}
			}
			if(kk==1){nn--;}
		}
		printf("%d\n",nn);
	}
	return 0; 
}

