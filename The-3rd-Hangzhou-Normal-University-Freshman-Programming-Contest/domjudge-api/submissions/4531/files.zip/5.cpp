#include <stdio.h>
#include <string.h>
int main(void){
	int t,n;
	long long len,i,j,k,h,l;
	char a[10000],b[10000];
	scanf("%d",&t);
	getchar();
	while(t--){
		scanf("%d",&n);
		getchar();
		l=0;
		while(n--){
			j=0;
			scanf("%s",&a);
			getchar();
			len=strlen(a);
			for(i=0;i<len;i++){
				h=0;
				if(a[i]!='.'){
					for(k=1;k<=j;k++){
						if(a[i]==b[k]){
							h=h+1;
						}
					}
					if(h==0){
					j=j+1;
					b[j]=a[i];
					l=l+1;
				}	
				}
			}
		}
		printf("%lld\n",l);
	}
	return 0;
} 
