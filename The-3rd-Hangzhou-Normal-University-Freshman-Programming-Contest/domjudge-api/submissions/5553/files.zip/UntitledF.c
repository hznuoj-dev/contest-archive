#include<stdio.h>
int main()
{
	int n,i,j;
	long m,a[100],b[100],c[100],s[10000],count=0,x;
	for (i=0;i<100;i++) {a[i]=0;b[i]=0;c[i]=0;}
	for(i=0;i<10000;i++) s[i]=0;
	scanf("%d%ld",&n,&m);
	for (j=0;j<n;j++)
	{
		scanf("%ld",&a[j]);
	}
	for (j=0;j<n;j++)
	{
		scanf("%ld",&b[j]);
	}
	while(c[n]==0)
	{
		x=0;
		c[0]++;
		for (i=0;i<n;i++)
			if (c[i]>b[i]) {c[i]=0;c[i+1]++;}
		for (i=0;i<n ;i++)
			x+=a[i]*c[i];
		if (s[x]==0 && c[n]==0 && x<=m){count++;s[x]=1;};
	}
	printf("%ld\n",count);
}

