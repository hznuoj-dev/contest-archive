#include <stdio.h>
int main()
{
	int n,i,x,y;
	double p;
	scanf("%d",&n);
	while(n--)
	{
		scanf("%d%d",&x,&y);
		char a[x+2]={0};
		a[0]='[';
		a[x+1]=']';
		a[x+2]='\0';
		for(i=1;i<=x;i++)
		{
			if(i<=y)
			a[i]='#';
			else
			a[i]='-';
		}
		p=100.0*y/x;
		printf("%s %.0lf%%\n",a,p);
	}
	return 0;
}
