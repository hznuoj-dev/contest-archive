//
//  main.cpp
//  c++_02
//
//  Created by 李尚鑫 on 2020/12/7.
//

#include <iostream>
#include <cmath>
#include <string>
using namespace std;

int main () {
    int n,cnt = 0;
    cin >>n;
    while (n--) {
        string s;
        cin >> s;
        cnt += s.length();
    }
    cout << cnt << endl;
}
