#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void){
	long long int a,b,c,d;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	long long int sum1=0,sum2=0,sum3=0,sum4=0;
	while(a!=0){
		sum1 +=a%10;
        a/=10;
	}
	printf("%d\n",sum1);
	while(b!=0){
		sum2 +=b%10;
        b/=10;
	}
	printf("%d\n",sum2);
	while(c!=0){
		sum3 +=c%10;
        c/=10;
	}
	printf("%d\n",sum3);
	while(d!=0){
		sum4 +=d%10;
        d/=10;
	}
	printf("%d\n",sum4);
	int x,y,z,q,p;
	if(sum1 >=16||sum1==6){
		x=1;
	}else{
		x=0;
	}
	printf("%d\n",x);
	if(sum2>=16||sum2==6){
		y=1;
	}else{
		y=0;
	}
	printf("%d\n",y);
	if(sum3>=16||sum3==6){
		z=1;
	}else{
		z=0;
	}
	printf("%d\n",z);
    if(sum4>=16||sum4==6){
		q=1;
	}else{
		q=0;
	}
	printf("%d\n",q);
	p=x+y+z+q;
	printf("%d\n",p);
	if(p==0){
		printf("Bao Bao is so Zhai......\n");
	}else if(p==1){
		printf("Oh dear!!\n");
	}else if(p==2){
		printf("Bao Bao is good!!\n");
	}else if(p==3){
		printf("Bao Bao is a SupEr man\/\/\/!\n");
	}else if(p==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	return 0;
}
