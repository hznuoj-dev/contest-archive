#include<stdio.h>
#include<math.h>
#pragma warning(disable:4996)
int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		float n, m,b;
		int temp;
		char a[100000] = { '\0' };
		scanf("%f%f", &n, &m);
		temp = n;
		int cnt = 0,v;
		while (temp!=0) {
			temp/=10;
			cnt++;
		}
		v = pow(10, cnt-1);
		b = m / n*v;
		int i;
		for (i = 0; i < m; i++) {
			a[i] = '#';
		}
		for (; i < n; i++) {
			a[i] = '-';
		}
		printf("[%s] %.0f%%\n", a, b);
	}
	return 0;
}