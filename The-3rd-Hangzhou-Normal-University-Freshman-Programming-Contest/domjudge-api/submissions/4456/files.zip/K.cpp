#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<set>
#include<map>
#include<iostream>
#include<string>
#include<queue>
using namespace std;
typedef long long int ll;
const int N=1e5+100;
vector<int>v[N];
vector<int>vc;
int k;
bool solve(int mid){
	int ans=0;
	for(auto it:vc){
		//ans=ans+upper_bound(v[it].begin(),v[it].end(),mid)-v[it].begin();
		int l=0,r=v[it].size()-1,m;
		if(mid>=v[it][r]){
			ans+=v[it].size();
		}
		else{
		int pos=-1;
		while(r>=l){
			m=l+r>>1;
			if(v[it][m]>mid)r=m-1,pos=m;
			else l=m+1;
		}
		ans+=(pos);
		}
	
	}
	return ans>=k;
}
int n;
int q;
void init(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int num;scanf("%d",&num);
		for(int j=1;j<=num;j++){
			int cx;scanf("%d",&cx);
			v[i].push_back(cx);
		}
		sort(v[i].begin(),v[i].end());
	}

	scanf("%d",&q);
}
int main(){
	init();
	while(q--){
		int num;scanf("%d",&num);
		for(int i=1;i<=num;i++){
			int cx;scanf("%d",&cx);
			vc.push_back(cx);
		}
		scanf("%d",&k);
		int l=1,r=60,mid;
		int ans=-1;
		while(r>=l){
			mid=l+r>>1;
			if(solve(mid))ans=mid,r=mid-1;
			else l=mid+1;
		}
		printf("%d\n",ans);
		vc.clear();
	}
}

