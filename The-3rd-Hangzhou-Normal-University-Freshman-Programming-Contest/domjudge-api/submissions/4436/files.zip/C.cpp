#include<iostream>
#include<vector>
#include<algorithm>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug cout<<"What fuck!"<<endl
using namespace std;
const int mod=998244353;
const int maxn=1e5+10;
int a[maxn];
vector<int>vec;
int main(){
	fcio;
	int n;
	while(cin>>n){
		vec.clear();
		for(int i=1;i<=n;++i){
			cin>>a[i];
		}
		sort(a+1,a+1+n);
		int num=1;
		int ans=1;
		int cnt=0;
		for(int i=1;i<=n;++i){
			if(a[i]==a[i+1]){
				num++;
			}
			else{
				vec.push_back(num);
				num=1;
			}
		}
		if(vec.size()<=2)cout<<1<<endl;
		else{
			for(int i=1;i<vec.size()-1;++i){
				ans=((ans%mod)*(vec[i]%mod)*(vec[i+1]%mod))%mod;
			}	
			cout<<ans%mod<<endl;
		}
	}
}

