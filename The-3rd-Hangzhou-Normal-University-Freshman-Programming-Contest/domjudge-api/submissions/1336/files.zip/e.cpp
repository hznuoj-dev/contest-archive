﻿1>------ 已启动生成: 项目: asd, 配置: Debug Win32 ------
1>  abc.cpp
1>c:\users\stu\desktop\新建文件夹\abc.cpp(7): warning C4996: 'scanf': This function or variable may be unsafe. Consider using scanf_s instead. To disable deprecation, use _CRT_SECURE_NO_WARNINGS. See online help for details.
1>          c:\program files (x86)\microsoft visual studio 11.0\vc\include\stdio.h(290) : 参见“scanf”的声明
1>  asd.vcxproj -> C:\Users\stu\Desktop\新建文件夹\asd\Debug\asd.exe
========== 生成: 成功 1 个，失败 0 个，最新 0 个，跳过 0 个 ==========
