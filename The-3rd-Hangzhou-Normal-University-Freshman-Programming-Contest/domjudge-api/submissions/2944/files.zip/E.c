#include <stdio.h>

int main(void) {
	char c;
    scanf("%c",&c);
    printf(" __      _____      ");
    printf("\n");
    printf("|  | ___/ ____\\____ ");
    printf("\n");
	printf("|  |/ /\\   __\\/ ___\\");
	printf("\n"); 
	printf("|    <  |  | \\  \\___");
	printf("\n");
	printf("|__|_ \\ |__|  \\___ >");
	printf("\n");
	printf("     \\/          \\/ ");  
	printf("\n");  
    return 0;

}

