import java.util.*;
public class Main//b
{
    public static void main(String[] args) 
    {
    	Scanner s=new Scanner (System.in);
		while (s.hasNext())
		{
			int n=s.nextInt();
			for (int i=1;i<=n;i++)
			{
				int q=s.nextInt();
				int h=s.nextInt();
				int a=q+h;
				if (a-9999>0)
				{
					a=9999+9999-a;
				}
				int max=Math.max(a, q);
				int min=Math.min(a, q);
				int g=0;
				for (int j=min;j<max;j++)
				{
					if (j%4==0&&j%100!=0||j%400==0)
						g++;
				}
				System.out.println(g);
			}
		}
      
    }
}