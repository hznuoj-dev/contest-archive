#include<stdio.h>
#include<string.h>

#pragma warning(disable:4996��
int main(){
	int t;
	int m,n,tt;
	scanf("%d",&t);
	while(t--)
	{int i,y,e,k,r;
	char str[5]={'\0'};
	char s[1002],d[1002],z,a;
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++)
		{
			str[i]=i+48;
		}
		getchar();
		for(i=1;i<=m;i++)
		{
			scanf("%c %c",&s[i],&d[i]);
			getchar();
		}
	
		for(i=1;i<=m;i++)
		{
			
             for(k=1;k<=n;k++)
			{
				if(str[k]==s[i])
					y=k;
				if(str[k]==d[i])
					e=k;
			}
			if(y>e)
			{
				a=s[i];
				for(r=y;r>e;r--)
				{
					str[r]=str[r-1];
				}
				str[e]=a;
			}
		}
	
		for(i=1;i<=n;i++)
		{
			if(i!=n)
				printf("%c ",str[i]);
			else
					printf("%c\n",str[i]);
			                               
		}
}

return 0;
}
