#include<stdio.h>
#include<string.h>
int main(){
	int i,j,m,n,s,l,p;
	char a[10000];
	int b[10000];
	p=0;
	
	for(j=0;j<4;++j){
		s=0;
		scanf("%s",a);
		l=strlen(a);
		for(i=0;i<l;++i){
			b[i]=int(a[i]-'0');
		}
	for(i=0;i<l;++i){
			s=s+b[i];
		}
		if(s>=16||s==6){
			p=p+1;
		}
	}
	if(p==0){
		printf("Bao Bao is so Zhai......\n");
	}
	else if(p==1){
		printf("Oh dear!!\n");
	}
	else if(p==2){
		printf("BaoBao is good!!\n");
	}
	else if(p==3){
		printf("Bao Bao is a SupEr man///!\n");
	}
	else if(p==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	return 0;
}
