#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int n,k,i,h,y,t,temp;
	char a[30];
	k=0;
	for(t=1;t<=4;t++){
		scanf("%s",a);
		h=0;
		for(i=0;i<=strlen(a)-1;i++){
			h+=a[i]-48;   
		}
		if(h>=16||h==6)
			k+=1;
	}
	if(k==0)
		printf("Bao Bao is so Zhai......\n");
	if(k==1)
		printf("Oh dear!!\n");
	if(k==2)
		printf("BaoBao is good!!\n");
	if(k==3)
		printf("Bao Bao is a SupEr man///!\n");
	if(k==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");

	return 0;
}
//int cmp(const void*p,const void*q){
//return((struct kx*)q)->average -(struct kx*)p)->average)
//}