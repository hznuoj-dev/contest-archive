#include<bits/stdc++.h>
using namespace std;

	char a[100009];
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int sum=0;
		int n;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			int mp[1000]={0};
			scanf("%s",a);
			int len=strlen(a);
			for(int j=0;j<len;j++){
				if(a[j]!='.'){
					if(mp[a[j]]==0){
						mp[a[j]]=1;
						sum++;
					}
				}
			}
		}
		printf("%d\n",sum);
	}
}

