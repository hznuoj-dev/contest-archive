#include <stdio.h>
int main()
{
	char s[20];
	scanf("%s",s);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");
	return 0;
 } 
