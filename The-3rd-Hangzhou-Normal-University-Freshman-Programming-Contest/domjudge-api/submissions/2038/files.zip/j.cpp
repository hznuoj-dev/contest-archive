#include<stdio.h>
#include<string.h>
char bb[1000000];
char aa[10000]={};
int main(){
	int a,b=0,c,n,f=0,sum=0;
	scanf("%d",&n);
	while(n--){
		sum=0;
		scanf("%d",&a);
		while(a--){
			b=0;
			scanf("%s",bb);
			getchar();
			c=strlen(bb);
			for(int i=0;i<c;i++){
				if(bb[i]!='.'){
					f=0;
					for(int j=0;j<b;j++){
						if(bb[i]==aa[j])f=1;
					}
					if(!f){	
						aa[b]=bb[i];
						b++;
					}
				}
			}sum+=b;	
		}printf("%d\n",sum);
	}
	return 0;
}
