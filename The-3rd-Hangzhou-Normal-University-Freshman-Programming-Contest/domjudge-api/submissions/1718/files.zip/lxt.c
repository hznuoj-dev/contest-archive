#include<stdio.h>
int main()
{
	int T, Y, A, i, j, sum, temp;
	scanf("%d", &T);
	sum = 0;
	while (T--) {
		scanf("%d%d", &Y, &A);
		i = Y + A;
		if (i > 9999) {
			i = 19998 - i;
		}
		if (Y > i) {
			temp = Y;
			Y = i;
			i = temp;
		}
		for (j = Y; j <= i; j++) {
			if (((j % 4 == 0) && (j % 100 != 0)) || (j % 400 == 0)) {
				sum += 1;
			}
		}
		printf("%d\n", sum);
		sum = 0;
	}
	return 0;
}