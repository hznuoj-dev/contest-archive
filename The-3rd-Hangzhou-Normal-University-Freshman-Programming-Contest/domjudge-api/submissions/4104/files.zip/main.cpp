//#include <bits/stdc++.h>
//typedef long long  ll;
//const int MAXN=1e2+5;
#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;
int  a,b,c[1005],d[1005][1005],l,mid,sum=0,n,m,t=0,x,w,v,y,ans,x2,y2;
struct r
{
    int u, v, t;
};
r p[1005];
int main()
{
    while(~scanf("%d",&l))
    {
        cin>>n>>m;
        for(int i=1; i<=m; i++)
        {
            cin>>p[i].u>>p[i].v;
            c[p[i].u]++;
        }
        for(int i=1; i<=n; i++)
            if(p[i].v>0)
                c[p[i].u]+=c[p[i].v];
        for(int j=n; j>=0; j--)
            for(int i=1; i<=n; i++)
                if(c[i]==j)
                    cout<<i<<" ";
    }
    return 0;
}


