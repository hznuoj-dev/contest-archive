#include<stdio.h>
#include<string.h>

int dd(  char x[]);
int main(){
char a[100],b[100],c[100],d[100];
int t=0;
scanf("%s%s%s%s",a,b,c,d);
t=dd(a)+dd(b)+dd(c)+dd(d);
switch(t)
{
case 1:printf("Oh dear!!");break;
case 2:printf("BaoBao is good!!");break;
case 3:printf("Bao Bao is a SupEr man%c%c%c!",92,92,92);break;
case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
default:printf("Bao Bao is so Zhai......");break;
}

return 0;
}
int dd(char x[])
{
	int n,m,sum=0,i;
	m=strlen(x);
	for(i=0;i<m;i++)
	{
		sum+=x[i]-48;
	}
	if(sum>=10||sum==6)
	{
		return 1;
	}
	else
		return 0;

}
