#include<stdio.h>
int main(){
int t;
scanf("%d",&t);
int a,b;
int i,j;
while(t--){
scanf("%d  %d",&a,&b);
printf("[");
for(int i=1;i<=b;i++){
	printf("#");
}
for(int j=b;j<=a;j++){
	printf("-");
}
printf("] ");
printf("%d%%\n",b*100/a);

}
return 0;
}
