#include<stdio.h>
#include<string.h>
	char a[100009];
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int sum=0;
		int n;
		int mp[1000]={0};
		scanf("%d",&n);
		int i;
		for(i=0;i<n;i++){
			scanf("%s",a);
			int len=strlen(a);
//			printf("%d\n",len);	
			int j;
			for(j=0;j<len;j++){
				if(a[j]!='.'){
					if(mp[a[j]]==0){
						printf(">??");
						mp[a[j]]=1;
						sum++;
					}
				}
			}
		}
		printf("%d\n",sum);
	}
}

