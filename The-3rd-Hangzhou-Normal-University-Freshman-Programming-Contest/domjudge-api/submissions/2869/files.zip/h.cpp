#include<bits/stdc++.h>
int main(){
	int t;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		double n,m,num;
		scanf("%lf%lf",&n,&m);
		num=m/n*100;
		printf("[");
		for(int j=0;j<m;j++){
			printf("#");
		}
		for(int k=0;k<n-m;k++){
			printf("-");
		} 
	printf("] %.0lf",num);
	printf("\%\n");
	}
	return 0;
} 
