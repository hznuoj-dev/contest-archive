#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<set>
using namespace std;
set<char>didt;
char str[10001000];
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,ans=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%s",str);
			didt.clear();
			for(int j=0;j<strlen(str);j++){
				if(str[j]=='.')continue;
				else{
					didt.insert(str[j]);
				}
			}
			ans+=didt.size();
		}
		printf("%d\n",ans);
	}
	return 0;
}
