#include <stdio.h>
int main(void){
	int T;
	scanf("%d",&T);
	while(T--){
		int Y,A,X;
		int cnt=0;
		scanf("%d%d",&Y, &A);
		X=Y+A;
		if(X>9999){
			int q;
			q=X-9999;
			X=9999-q;
		}
		if(Y>X){
			int y=Y;
			Y=X;
			X=y;
		}
		for(int i=Y;i<=X;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				cnt++;
			}
		}
		printf("%d\n",cnt);
	}
}
