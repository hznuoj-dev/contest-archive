#include<bits/stdc++.h>
using namespace std;
int main(){
	int t;
	int min1,max1;
	int year,y;
		cin>>t;
	while(t--){
		cin>>year>>y;
		if(y>=0)
		{
			min1=year;
			max1=year+y;
		}else{
			min1=year+y;
			max1=year;
		}
		if(max1>9999)max1=9999*2-max1; 
		if(min1>max1)
		{
			int t=min1;
			min1=max1;
			max1=t;
		}
		int cnt=0;
		for(int i=min1;i<=max1;i++){
		if((i%400==0)||(i%4==0&&i%100!=0))cnt++;
	}
	
		cout<<cnt<<endl;
	}
	
	return 0;
} 
