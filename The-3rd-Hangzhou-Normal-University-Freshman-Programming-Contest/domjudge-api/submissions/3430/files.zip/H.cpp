#include<stdio.h>
#include<string.h>
int main(){
	int T,a,b,c;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&a,&b);
		c=100.0*b/a;
		printf("[");
		for(int k=1;k<=a;k++){
			if(k<=b) printf("#");
			else printf("-");
		}
		printf("]%d%%\n",c);
	}
}
