#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int main(){
	int n,k,i,a,b,c,h,y,temp;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d%d",&y,&a);
		   b=y+a;
		if(b>9999){
			c=b-9999;
			b=9999-c;
		}
		if(y>b){
			temp=y;
			y=b;
			b=temp;
		}
		h=0;
		for(k=y;k<=b;k++){
			if((k % 4 == 0 && k % 100 != 0)||k%400==0)
				h+=1;
		}
		printf("%d\n",h);
	}

	return 0;
}
//int cmp(const void*p,const void*q){
//return((struct kx*)q)->average -(struct kx*)p)->average)
//}