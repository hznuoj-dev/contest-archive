#include<stdio.h>
#pragma warning(disable:4996)
int main(){
	int a[4],x,y=0,i;
	for(i=0;i<4;i++){scanf("%d",&a[i]);}
	for(i=0;i<4;i++){
		x=0;
		for(;;){
			x+=a[i]%10;
		    a[i]=a[i]/10;
		    if(a[i]<1){
				if(x>=16||x==6){y=y+1;}
			    break;
		}
		}
	}
	if(y==1){printf("Oh dear!!");}
	else if(y==2){printf("BaoBao is good!!");}
	else if(y==3){printf("Bao Bao is a SupEr man///!");}
	else if(y==4){printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");}
	else if(y==0){printf("Bao Bao is so Zhai......");}
	system("pause");
}