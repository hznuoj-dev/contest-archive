#include<stdio.h>
int num(long long int a){
	int x=0,y=0;
	while(a){
		x+=a%10;
		a=a/10;
	}
	if(x>=16||x==6)
	    y++;
	return y;
}
int main(void){
	long long int a,b,c,d;
	int a1,b1,c1,d1,z;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	a1=num(a);
	b1=num(b);
	c1=num(c);
	d1=num(d);
	switch(a1+b1+c1+d1){
		case 0:
			printf("Bao Bao is so Zhai......\n");
			break;
		case 1:
			printf("Oh dear!!\n");
			break;
		case 2:
			printf("BaoBao is good!!\n");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!\n");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
			break;
	}
	return 0;
}
