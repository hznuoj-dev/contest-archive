#include <stdio.h>
int main(void){
	printf(" __      _____\n");
	printf("|  | ___/ ____");
	printf("\\");
	printf("____\n");   
	printf("|  |/ /");
	printf("\\");
	printf("   __");
	printf("\\");
	printf("/ ___");
	printf("\\\n");
	printf("|    <  |  | ");
	printf("\\");
	printf(" \\");
	printf("___\n");
	printf("|__|_ ");
	printf("\\");
	printf(" |__|  ");
	printf("\\");
	printf("___ >\n");
	printf("     ");
	printf("\\");
	printf("/         ");
	printf("\\");
	printf("/\n");
	return 0; 
}
