#include<stdio.h>
int sum(int a,int b){
	int c=0;
	for(int i=a;i<=b;i++){
		if((i%4==0&&i%100!=0)||i%400==0)c++;
	}return c;
}
int main(){
	int n,a,b,c=0,d,max=0,min=0;
	scanf("%d",&n);
	while(n--){
		c=0;
		scanf("%d%d",&a,&b);
		d=a+b;
		if(d>9999)d=9999-(d-9999);
		if(a>d){
			max=a;
			min=d;
		}
		else {
			max=d;min=a;
		}
		printf("%d\n",sum(min,max));
	}
	return 0;
} 
