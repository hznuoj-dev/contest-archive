#include<stdio.h>
int main(void){
	char a[3];
	gets(a);
	printf(" --      ----\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\ \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/\n");
    
	return 0;
}
