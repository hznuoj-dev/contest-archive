#include<bits/stdc++.h>
using namespace std;
char x[100];
int pd(char *p1)
{
    int sum=0,i=0;
    while(*(p1+i)!='\0')
    {
        sum+=*(p1+i)-'0';
        i++;
    }
    return sum;
}
int main()
{
    int i,sum=0,t=4;
    while(t--)
    {
        scanf("%s",x);
        if(pd(x)>=16||pd(x)==6) sum++;
    }
    if(sum==1) cout<<"Oh dear!!";
    else if(sum==2) cout<<"BaoBao is good!!";
    else if(sum==3) cout<<"Bao Bao is a SupEr man///!";
    else if(sum==4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
    else if(sum==0) cout<<"Bao Bao is so Zhai......";
    return 0;
}
