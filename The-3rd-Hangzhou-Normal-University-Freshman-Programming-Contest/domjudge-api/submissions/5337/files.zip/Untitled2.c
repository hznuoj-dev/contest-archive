#include<stdio.h>
#include<string.h>
int main() 
{
	int t,i,a,b;

	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&a,&b);
		printf("[");
		for(i=1;i<=b;i++)
		{
			printf("#");
		}
		for(i=1;i<=(a-b);i++)
		{
			printf("-");
		}
		
		printf("]");
		printf(" %.0f\%%\n",((b*1.00)/a)*100);
		
	}
	return 0;

}

