/*#include <stdio.h>
#pragma warning(disable:4996)
int main (){
	
	char a;

	scanf ("%c",&a);
	printf(" __     _____\n"
           "| | ___/ ____\\____\n"
           "| |/ /\\  __\\/ ___\\\n"
           "|   < | | \\ \\___\n"
           "|__|_ \\ |__| \\___ >\n"
           "     \\/          \\/\n");

	system ("pause");
	return 0;
}*/

#include <stdio.h>
#pragma warning(disable:4996)
int main (){

	long long a,b,c,d,a1=0,b1=0,c1=0,d1=0,suma=0,sumb=0,sumc=0,sumd=0,n=0;

	scanf ("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>0){
		a1=a%10;
		suma+=a1;
		a/=10;
	}
	if(suma>=16||suma==6)n++;
	while(b>0){
		b1=b%10;
		sumb+=b1;
		b/=10;
	}
	if(sumb>=16||sumb==6)n++;
	while(c>0){
		c1=c%10;
		sumc+=c1;
		c/=10;
	}
	if(sumc>=16||sumc==6)n++;
	while(d>0){
		d1=d%10;
		sumd+=d1;
		d/=10;
	}
	if(sumd>=16||sumd==6)n++;
	if(n==1)printf("Oh dear!!");
	else if(n==2)printf ("BaoBao is good!!");
	else if(n==3)printf ("Bao Bao is a SupEr man///!");
	else if(n==4)printf ("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(n==0)printf ("Bao Bao is so Zhai......");
	system ("pause");

	return 0;
}