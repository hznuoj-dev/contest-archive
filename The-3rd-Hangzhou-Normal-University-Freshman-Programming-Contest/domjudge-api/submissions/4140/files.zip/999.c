#include <stdio.h>
#include <stdlib.h>


int main(int argc, char *argv[]) {
	int T;
	scanf("%d",&T);
	while(T--)
	{
		long long y,a,b;
		long long x=0;
		scanf("%lld %lld",&y,&a);
		if(y>0)
		b=a+y;
		
		if(b>9999)
		{
			b=y+y+a-9999;
			if(b>9999)
			{
				b=y+y+a-9999;
				if(b>9999)
				{
					b=y+y+a-9999;
					if(b>9999)
					{
						b=y+y+a-9999;
				
					}
				}
			}
		}

		int i,t;
		if(b<y)
		{
			t=b;
			b=y;
			y=t;
		}
		
		for(i=y;i<=b;i++)
		{
		
			if(((i%4==0)&&(i%100!=0))||i%400==0)
			{
				x++;
			}
			
		}
		printf("%lld\n",x);
	}
	return 0;
}

/*
int main()
{
	int n,h=0,c=0,num=0;
	long long m,i,j;
	scanf("%d %lld",&n,&m);
	long long a[4][110];
	for(i=0;i<n;++i)
	{
			scanf("%lld",&a[0][i]);
	}
	for(j=0;j<n;++j)
	{
		scanf("%lld",&a[1][j]);
	}
	for(i=0;i<n;++i)
	{
		for(j=0;j<n;++j)
		{
			
			long long sum = 0;
			sum += a[0][i];
			if(sum>=m)
			{
				num++;
				sum=0;
				h++;
				i=h;
			}
		}
	}
	printf("%d\n",num);
	
	return 0;
}*/
/*int main(void)
{
	int T,a,b;
	char a[4][1010]
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&n,&m);
		while(m--)
		{
			scanf("%d %d",&a,&b)
			if(a<b)
		}
		
	}
	return 0;
}*/
