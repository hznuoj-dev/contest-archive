 #include <set>
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <cmath>
#include <ctime>
#include <bitset>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const int maxn = 1e5 + 10;
const int mod = 0;
const int inf = 0x3f3f3f3f;
int vis[1010][1010];

int gcd(int a, int b) 
{
	return b==0?a:gcd(b,a%b);
}
int main()
{
	/*int n;
	cin>>n;
	int a,b;

	while(n--)
	{
		cin>>a>>b;



	}*/
	string s;
	cin>>s;
	cout<<" __      _____"<<endl;	cout<<"|  | ___/ ____\\____"<<endl;	cout<<"|  |/ /\\   __\\/ ___\\"<<endl;	cout<<"|    <  |  |  \\ \\___"<<endl;	cout<<"|__|_ \\ |__|   \\___  >"<<endl;	cout<<"     \\/            \\/"<<endl;



	return 0;
}
