#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,m;
	int i;
	int sum=0;
	int m1[10];
	int n1[10];
	cin>>n>>m;

	for(i=0;i<n-1;i++){
    cin>>m1[i];
	}

	for(i=0;i<n-1;i++){
		cin>>n1[i];
	}
	for(i=0;i<n;i++){
		sum +=m1[i]*n1[i] ;
	}
	cout<<sum<<'\n';
	return 0;
}
