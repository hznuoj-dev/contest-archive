//
// Created by Kyooma on 2020/12/13.
//
#include <bits/stdc++.h>
using namespace std;
char k[100009];
int main(){
    int t;
    long long cnt=0;
    scanf("%d",&t);
    getchar();
    while(t--){
        scanf("%s",k);
        cnt+=strlen(k);
    }
    printf("%lld\n",cnt);
}
