#include<stdio.h>
int main(){
	long long A,B,C,D;
	int a=0,b=0,c=0,d=0,suma=0,sumb=0,sumc=0,sumd=0,q=0,w=0,e=0,r=0;
	scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
	int total=0;
	

		while(A){
			a=A%10;
			suma+=a;
			A=A/10;
		}
	if((suma>=16)||(suma==6))
	q=q+1;
	
		while(B){
			b=B%10;
			sumb+=b;
			B=B/10;
		}
	if((sumb>=16)||(sumb==6))
	w=w+1;
	
	while(C){
			c=C%10;
			sumc+=c;
			C=C/10;
		}
	if((sumc>=16)||(sumc==6))
	e=e+1;
	
		while(D){
			d=D%10;
			sumd+=d;
			D=D/10;
		}
	if((sumd>=16)||(sumd==6))
	r=r+1;
	
	total=q+w+e+r;
	
	if(total==1)
	printf("Oh dear!!\n");
	
	if(total==2)
	printf("BaoBao is good!!\n");
	
	if(total==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	
	if(total==0)
	printf("Bao Bao is so zhai......\n");
	
	if(total==3)
	printf("Bao Bao is a SupEr man///!\n");
	
}
