#include<stdio.h>
int main(void){
	long long int a,b,c,d;
	int num=0,ans=0,e;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	do{
	e=a%10;
	num+=e;
	a/=10;
	}while(a>0);
	if(num>=16||num==6)
		ans+=1;
		 num=0;
		do{
	
	e=b%10;
	num+=e;
	b/=10;
	}while(b>0);
	if(num>=16||num==6)
		ans+=1;
		 num=0;
		 	do{ 
	e=c%10;
	num+=e;
	c/=10;
	}while(c>0);
	if(num>=16||num==6)
		ans+=1;
		 num=0;
		 	do{ 
	e=d%10;
	num+=e;
	d/=10;
	}while(d>0);
	if(num>=16||num==6)
		ans+=1;
		 if(ans==0){
		 	printf("Bao Bao is so Zhai......");
		 }
		 	else if(ans==1){
		 		printf("Oh dear!!");
			 }
			 else if(ans==2){
			 	printf("BaoBao is good!!");
			 }
			 else if(ans==3){
			 	printf("Bao Bao is a SupEr man///!");
			 }
			 else 
			 printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
} 
