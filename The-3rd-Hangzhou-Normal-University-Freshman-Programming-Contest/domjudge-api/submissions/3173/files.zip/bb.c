#include <stdio.h>
int main()
{
	int t,y,a,i,j;
	scanf("%d",&t);
	while(t--)
	{
	scanf("%d %d",&y,&a);
	int num=0,count=0;
	num=y+a;
	if(a<0) 
	{
		for(i=num;i<=y;i++)
		if(i%4==0&&i%100!=0 || i%400==0 )
		count++;
	}
	else{
	if(num<=9999)
	{
		for(i=y;i<=num;i++)
		if(i%4==0&&i%100!=0 || i%400==0 )
		count++;
	}	
	else{
		num=9999*2-num;
		if(num>y){
		for(i=y;i<=num;i++)
		if(i%4==0&&i%100!=0 || i%400==0 )
		count++;}
		else{
			for(i=num;i<=y;i++)
		if(i%4==0&&i%100!=0 || i%400==0 )
		count++;
		}
	}
}
	printf("%d\n",count);	
}
	return 0;
}
