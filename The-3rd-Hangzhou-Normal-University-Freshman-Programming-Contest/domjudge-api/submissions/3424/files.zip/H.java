import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);

		while (in.hasNext())
		{

			int a = in.nextInt();

			for (int i = 0; i < a; i++)
			{

				double b = in.nextDouble();
				double c = in.nextDouble();

				String tt = "-";
				String ans = "";

				for (int j = 0; j < c; j++)
				{
					ans = ans + "#";
				}
				for (double j = c; j < b; j++)
				{
					ans = ans + "-";
				}

				System.out.print("[" + ans + "]");
				if (c == 0)
				{
					System.out.println(" " + 0 + "%");
				} else
				{
					System.out.println(" " + (int) (c * (100 / b)) + "%");
				}

			}

		}
	}

}
