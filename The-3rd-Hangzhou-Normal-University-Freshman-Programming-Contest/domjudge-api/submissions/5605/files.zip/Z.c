#include<stdio.h>
#include<string.h>
int main(){
	int T,n,i,sum,x,length,j;
	char a[1000000],b[10000];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(x=1;x<=n;x++){
			sum=0;
			scanf("%s",a);
			length=strlen(a);
			for(i=1;i<=length;i++){
				for(j=1;j<=sum;j++){
					if(b[j]!=a[i])
						break;
				}
			}
			if(j>sum){
				sum=sum+1;
				b[sum]=a[i];
			}
		
		}
	printf("%d\n",sum+1);
	}
      return 0;
}