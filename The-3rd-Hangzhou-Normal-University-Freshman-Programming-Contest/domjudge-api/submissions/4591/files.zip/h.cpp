#include <stdio.h> 
#include <string.h> 
int main(void){
	int t;
	char z='%';
	double f,n,m,i;
	scanf("%d",&t);
	while(t--){
	    scanf("%lf %lf",&n,&m);
	    f=m/n*100;
	    printf("[");
	    for(i=1;i<=n;i++){
		if(i<=m)
		   printf("#");
		else 
		   printf("-");
	    }
	    printf("] %.0f%c \n",f,z);
	}
	return 0;
}
 
