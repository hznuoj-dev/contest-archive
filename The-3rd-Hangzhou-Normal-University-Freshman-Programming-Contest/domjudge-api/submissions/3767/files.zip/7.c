#include <stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
#define PI 3.14159
#include<math.h>
#pragma warning(disable:4996)

char s[1000000];
int b[256];
int  main() {
	int t,n;
	
	scanf("%d", &t);
	while (t--) {
		int sum = 0,len;
		scanf("%d", &n);
		while(n--){
			int g = 0;
			scanf("%s", s);len = strlen(s);
			for (int i = 0;i < 256;i++)b[i] = 0;			
			for (int j = 0;j < len;j++) {
				if (s[j] != '.') {
					b[s[j]] += 1;
				}
			}
			for (int k = 0;k < 256;k++) {
				if (b[k] > 0)g += 1;
			}
			sum += g;
		}
		printf("%d\n", sum);
	}
	return 0;
}
