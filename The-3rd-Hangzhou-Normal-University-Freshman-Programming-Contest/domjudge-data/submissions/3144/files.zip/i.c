#include<stdio.h>
#pragma warning(disable:4996)
int main() {
	long long int a, b, c, d, r, i=0, k, l, m;
	long long int sum = 0,o=0,p=0,e=0;
	scanf("%lld %lld %lld %lld", &a, &b, &c, &d);
	sum = 0, o = 0, p = 0, e = 0;
	while (a!=0){
		r = a % 10;
		a = a / 10;
		sum += r;
	}
	while (b != 0) {
		k = b % 10;
		b /= 10;
		o += k;
	}
	while (c != 0) {
		l = c % 10;
		c /= 10;
		p += l;
	}
	while (d != 0) {
		m = d % 10;
		d /= 10;
		e += m;
	}
	for (i = 0; i <= 4; i++) {
		if (sum >= 16 || o >= 16 || p >= 16 || e >= 16 || sum == 6 || o == 6 || p == 6 || e == 6)
			i++;
	}
		if (i == 1)
			printf("Oh dear!!");
		else if (i == 2)
			printf("BaoBao is good!!");
		else if (i == 3)
			printf("Bao Bao is a SupEr man///!");
		else if (i == 4)
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		else if (i == 0)
			printf("Bao Bao is so Zhai......");
	}
return 0;
}