#include <stdio.h>

int flag(char s, char *f)
{
	int i;
	for(i = 0; i < 128; ++i)
	{
		if(s == f[i])
			return 0;
		else if(f[i] == '\0')
			return 1;
	}
	
}

int main(void)
{
	int T, n, i, j, cnt;
	char s[1000001], f[128];
	
	scanf("%d", &T);
	while(T--)
	{
		cnt = 0;
		scanf("%d", &n);
		while(n--)
		{
			i = j = 0;
			f[j] = '\0';
			scanf("%s", s);
			while(s[i] != 0)
			{
				if(s[i] != '.' && flag(s[i], f))
				{
					cnt++;
					f[j++] = s[i];
					f[j] = '\0';
				}
				++i; 
			}
		}
		printf("%d", cnt);
	}
	
	
	return 0;
}
