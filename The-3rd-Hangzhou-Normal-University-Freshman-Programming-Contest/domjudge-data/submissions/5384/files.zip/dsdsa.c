#include<stdio.h>
#include<string.h>
int main()
{
	int t,m;
	int i, n;
	char a[100], b[100];
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d %d", &m, &n);
		for (i = 0; i < n; i++)
		{
			a[i] = '#';
		}
		for (i = 0; i < m-n; i++)
		{
			b[i] = '-';
		}
		a[n] = '\0';
		b[m-n] = '\0';
		if(m!=0)printf("[%s%s] %.0f%%\n", a, b, (n*1.0 / m) * 100);
		else printf("[%s%s] 0%", a, b);
	}
	return 0;
}
