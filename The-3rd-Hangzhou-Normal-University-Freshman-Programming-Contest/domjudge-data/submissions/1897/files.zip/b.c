#include<stdio.h>
int main()
{
	int year,a,b,m,n,i,t,res;
    scanf("%d",&t);
    while(t--){
    res=0;
    scanf("%d %d",&year,&a);
	m=year;
	
	b=year+a-9999;
	if(b>0){
		n=9999-b;
	}else{
		n=m+a;
	}

	 if(m>n){
	 	for(i=n;i<m-1;i++){
	 		if(i%4==0){
	 			res++;
			 }
		 }
	 }
	 if(n>m){
	 	for(i=m;i<n-1;i++){
	 		if(i%4==0){
	 			res++;
			 }
		 }
	 }
	 printf("%d\n",res);
	}
	 return 0;
 } 
