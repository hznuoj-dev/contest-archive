#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 




int main(){
	int t,n,m,mm,i,ii,a,b,max,ad,h=1;
	scanf("%d",&t);
	while(t--){
		h=1; 
		scanf("%d %d",&n,&m);
		int per[n+1][m+1];
		for(i=0;i<=n;i++){
			for(ii=0;ii<=m;ii++){
				per[i][ii]=0;
			}
		}
		mm=m;
		while(mm--){
			scanf("%d %d",&a,&b);
			per[a][0]+=1;
			for(i=1;i<=m;i++){
				if(per[a][i]==0){
					per[a][i]=b;
					break;
				}
			}
			for(i=1;i<=n;i++){
				for(ii=1;ii<=m;ii++){
					if(per[i][ii]==a){
						per[i][0]++;
						break;
					}
				}
			}
		}
		
		
		for(i=1;i<=n;i++){
			max=-1;
			for(ii=1;ii<=n;ii++){
				if(per[ii][0]>max) max=per[ii][0],ad=ii;
			}
			if(h)
			printf("%d",ad),h=0;
			else
			printf(" %d",ad);
			per[ad][0]=-1;
		}
		puts("");
	}
	
} 



