#include <bits/stdc++.h>
using namespace std;
int main() {
	int t;
	cin>>t;
	for (int i=1;i<=t;i++) {
		int x,y;
		cin>>x>>y;
		cout<<"[";
		for (int j=1;j<=y;j++) cout<<"#";
		for (int j=1;j<=x-y;j++) cout<<"-";
		cout<<"] ";
		double z=y*1.0/x*100;
		printf("%d",int(z));
		cout<<"%"<<endl;
	}
}
