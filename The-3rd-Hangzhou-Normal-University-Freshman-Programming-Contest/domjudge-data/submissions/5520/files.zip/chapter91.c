#include <stdio.h>
int main(void) {
	static int t, n, m, i, j, a[1000000], b[1000000],c[1000];
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &n, &m);
		for (i = 1; i <= n; i++) {
			c[i] = i;
		}
		for (i = 0; i < m; i++) {
			scanf("%d%d", &a[i], &b[i]);
		}
		for (i = 0; i < m; i++) {
			if (a[i] > b[i]) {
				j = c[a[i]];
				c[a[i]] = c[b[i]];
				c[b[i]] = j;
			}
		}
		for (i = 1; i <= n; i++) {
			printf("%d", c[i]);
			if (i < n) {
				printf(" ");
			}
		}
	}
}