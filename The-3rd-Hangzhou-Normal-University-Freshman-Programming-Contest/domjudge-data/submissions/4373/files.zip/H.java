import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		while (in.hasNext())
		{

			int a = in.nextInt();

			for (int i = 0; i < a; i++)
			{

				double b = in.nextDouble();
				double c = in.nextDouble();
				int h = (int) b;
				int p = (int) c;
			
				System.out.print("[");
				
				StringBuffer buffer=new StringBuffer();
				
				for (int j = 0; j < b; j++)
				{
					if (j<c)
					{
						buffer.append("#");
					}else {
						buffer.append("-");
					}
				}
				
				System.out.print(buffer);
				
				System.out.print("]"+" ");
				if (c == 0)
				{
					System.out.println(" " + 0 + "%");
				} else
				{
					System.out.println(" " + (int) (c * (100 / b)) + "%");
				}

			}

		}

	}

}
