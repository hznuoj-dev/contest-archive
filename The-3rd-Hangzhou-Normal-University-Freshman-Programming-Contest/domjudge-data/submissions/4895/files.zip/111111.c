#include<stdio.h>
int main(void){
	int T=0;
	scanf("%d",&T);
	while(T--){
		long i=0,x=0,Y=0,A=0,B=0;
		scanf("%ld %ld",&Y,&A);
		B=9999+9999-(Y+A);
		if(A==0){
			if(i%4==0&&i%100!=0){x=1;}
			else if(i%400==0){x=1;}
			else{x=0;}
		}
		else if(Y+A>=10000){
			for(i=Y;i<=B;i++){
				if(i%4==0&&i%100!=0){x=x+1;}
				else if(i%400==0){x=x+1;}
				else{x=x;}
			}
		}
		else if(A<0){
			for(i=Y+A;i<=Y;i++){
				if(i%4==0&&i%100!=0){x=x+1;}
				else if(i%400==0){x=x+1;}
				else{x=x;}
			}
		}
		else{
			for(i=Y;i<=Y+A;i++){
				if(i%4==0&&i%100!=0){x=x+1;}
				else if(i%400==0){x=x+1;}
				else{x=x;}
			}
		}
		printf("%ld\n",x);
	}
	return 0;
}