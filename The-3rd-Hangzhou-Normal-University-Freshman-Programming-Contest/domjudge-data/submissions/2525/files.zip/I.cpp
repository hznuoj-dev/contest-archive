#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long int a,b,c,d;
	cin>>a>>b>>c>>d;
	int sum1=0,sum2=0,sum3=0,sum4=0;
	int x;
	while(a)
	{
		x=a%10;
		sum1+=x;
		a/=10;
	}
	while(b)
	{
		x=b%10;
		sum2+=x;
		b/=10;
	}
	while(c)
	{
		x=c%10;
		sum3+=x;
		c/=10;
	}
	while(d)
	{
		x=d%10;
		sum4+=x;
		d/=10;
	}
	int count=0;
	if(sum1>=16||sum1==6) count++;
	if(sum2>=16||sum2==6) count++;
	if(sum3>=16||sum3==6) count++;
	if(sum4>=16||sum4==6) count++;
	if(count==1) cout<<"Oh dear!!";
	if(count==2) cout<<"BaoBao is good!!";
	if(count==3) cout<<"Bao Bao is a SupEr man///!";
	if(count==4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
	if(count==0) cout<<"Bao Bao is so Zhai......";
}

