﻿#include <stdio.h>
int a[1001][1001];
int main() {
    int t, n, m, i, b[1001] = { 0 }, p, q, c[1001] = { 0 }, j;
    scanf("%d", &t);
    while (t--) {
        for (i = 0; i < 1001; i++) {
            for (j = 0; j < 1001; j++) {
                a[i][j] = 0;
            }
        }
        scanf("%d %d", &n, &m);
        while (m--) {
            scanf("%d %d", &p, &q);
            if (a[q][p] != 1) {
                b[q]++;
                a[q][p] = 1;
                c[p]++;
                for (i = 1; i <= n; i++) {
                    if (a[p][i] == 1) {
                        c[i]++;
                    }
                }
            }
        }
        for (j = 1; j <= n; j++) {
            p = 1;
            for (i = 1; i <= n; i++) {
                if (c[i] > c[p]) {
                    p = i;
                }
            }
            if (j != n) {
                printf("%d ", p);
                c[p] = -1;
            }
            else
                printf("%d\n", p);
        }
    }
    return 0;
}