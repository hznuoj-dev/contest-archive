#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
const int maxn=1010;
int n,m,t,is,cnt,ans,p[maxn];
int main(){
    ios::sync_with_stdio(false);
    cout<<fixed<<setprecision(0);
    cin>>t;
    while(t--){
        cin>>n>>m;
        for(int i=1;i<=n;i++)p[i]=i;
        for(int i=1;i<=m;i++){
            int a,b;
            cin>>a>>b;
            if(a>b)swap(p[a],p[b]);
        }
        for(int i=1;i<=n;i++)cout<<p[i]<<(i==n?"\n":" ");
    }
    return 0;
    //good job!
}
