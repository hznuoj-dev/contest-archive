#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
    	int n,s=0;
    	cin>>n;
    	while(n--){
    		char a[1000001],b[1000001];
    		int i=-1;
    			cin>>a;
    			for(int p=0;p<strlen(a);p++){
    			if(a[p]!='.'){
				    int flag=1;
    				for(int j=0;j<=i;j++){
    					if(b[j]==a[p])
    	          	       flag=0;
					}
					if(flag==1){
						 
					     b[i+1]=a[p];
					     i=i+1;
					     
					}
				}
			}
			s=s+i+1;			
	}
	cout<<s<<endl;
}
	return 0;
}

