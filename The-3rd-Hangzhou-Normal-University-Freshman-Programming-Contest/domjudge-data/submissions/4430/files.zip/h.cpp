#include<bits/stdc++.h>
using namespace std;
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b,c=0;
		scanf("%d %d",&a,&b);
		c=b*100/a;
		int i;
		printf("[");
		for(i=0;i<b;i++) printf("#");
		for(;i<a;i++) printf("-");
		printf("] %d\%\n",c);
	}
	return 0;
}
