#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int Run(int x) {
	if((x%4==0 &&x%100!=0)||(x%400==0)) {
		return 1;
	} else {
		return 0;
	}
}
int main() {
	int T;
	scanf("%d",&T);
	while(T--) {
		int n;
		scanf("%d",&n);
		int i,j,k,x=0;
		char str[1000001];
		for(i=1; i<=n; i++) {
			scanf("%s",str);
			int len=strlen(str);
			for(j=0; j<=len-1; j++) {
				if(str[j]=='.') {
					
				} else {
					int f=1;
					for(k=0; k<=j-1; k++) {
						if(str[k]==str[j]) {
							f=0;
							break;
						}
					}
					if(f==1) {
						x=x+1;
					}
				}
			}
		}
		printf("%d\n",x);
	}
}
