#include<bits/stdc++.h>
using namespace std;

int t;
int y, a, x;
int ans;

int RUN (int c)
{
	if ((!(c % 4) && (c % 100)) || !(c % 400)) return 1;
	return 0;
}

int main ()
{
	scanf ("%d", &t);
	while (t--)
	{
		ans = 0;
		scanf ("%d%d", &y, &a);
		x = y + a;
		if (x > 9999) x = 9999 - (x - 9999);
		if (x > y) swap (x, y);
		//printf ("%d %d\n", x, y);
		for (int i = x; i <= y; i++) ans += RUN (i);
		printf ("%d\n", ans);
	}
	
	
	return 0;
	
}
