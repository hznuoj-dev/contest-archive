#include<stdio.h>
int gn(unsigned int data)
{
	int total = 0, n=0;
	while (data != 0) {
		n = data % 10;
		total += n;
		data = data / 10;
	}
	return total;
}
int main()
{
    long long a, b, c, d;
	int i=0;
	scanf("%lld %lld", &a, &b);
	scanf("%lld %lld", &c, &d);
	if (gn(a) == 6 || gn(a) >= 16)
		i++;
    if (gn(b) == 6 || gn(b) >= 16)
		i++;
	if (gn(c) == 6 || gn(c) >= 16)
		i++;
	if (gn(d) == 6 || gn(d) >= 16)
		i++;
	if (i == 1) {
		printf("Oh dear!!");
	}
	if (i == 2) {
		printf("BaoBao is good!!");
	}
	if (i == 3) {
		printf("Bao Bao is a SupEr man///!");
	}
	if (i == 4) {
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	if (i == 0) {
		printf("Bao Bao is so Zhai......");
	}
	return 0;
}
