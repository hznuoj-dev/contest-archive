#include <stdio.h>
#include <stdlib.h>
int main(void){
	int t;
	double n,m,a,s;
	scanf("%d",&t);
	while(t--){
		scanf("%lf%lf",&n,&m);
		a=n-m;
		s=m/n*100;
		printf("[");
		while(m--){
			printf("#");
		}
		while(a--){
			printf("-");
		}
		printf("] %.0f%%\n",s);
	}
	
	
	return 0;
}
