#include<stdio.h>
int main(void){
	int n,m;
	scanf("%d",&n);
	for(m=0;m<n;m++){
		int a;
		long long int b;
		scanf("%d %lld",&a,&b);
		long int c,d;
		c=a+b;
		d=c-9999;
		//printf("%ld %ld\n",c,d); 
		int e;
		if(d>0){
			e=9999-d;
		}else{
			e=c;
		}
		//printf("%d\n",e);
		long long int t=0;
		if(e<a){
			t=e;
			e=a;
			a=t;
		}
		//printf("%d %d\n",a,e);
		int i,sum=0;
	for(i=a;i<=e;i++){
		if((i%4==0&&i%100!=0)||(i%400==0)){
			sum=sum+1;
		}else{
			sum=sum+0;
		}
	}
	printf("%d\n",sum);
	}
	return 0; 
}
