#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,n,sum,i;
	char s1[1000000];
	int s2[10000000],*m;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		sum=0;
		while(n--){
			gets(s1);
			for(i=0;i<strlen(s1);i++){
				*m=s1[i];
				if(s1[i]!='.'&&s2[m]!=1)sum++;
				if(s1[i]!='.'&&s2[m]==0)s2[m]=1;
			}
		} 
		printf("%d\n",sum);
	} 
	
	return 0;
}
