#include<stdio.h>
#include<math.h>
int main(){
	int t,y,a;
	int x,i;
	int z,b,c;
	int d[i];
	int count=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&y,&a);
		z=y+a;
		if(z>9999){
			b=z-9999;
			c=9999-b;
			if(c>y){
				for(i=y;i<=c;++i){
					scanf("%d",&d[i]);
					if(d[i]%4==0||d[i]%100!=0||d[i]%400==0){
						count+=1;
					}
				}
				printf("%d",count);
			}
			
		}
		if(z<=9999){
		if(z>y){
				for(i=y;i<=z;++i){
					scanf("%d",&d[i]);
					if(d[i]%4==0||d[i]%100!=0||d[i]%400==0){
						count+=1;
					}
					printf("%d",count);
				}
			}
			if(z<y){
					for(i=z;i<=y;++i){
					scanf("%d",&d[i]);
					if(d[i]%4==0||d[i]%100!=0||d[i]%400==0){
						count+=1;
					}
				}
				printf("%d",count);
			}
				
		}
	
		return 0;
	}
}
