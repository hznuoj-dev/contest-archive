#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,count;
	scanf("%d",&n);
	for(int g=1;g<=n;g++)
	{
		count=0;
		int i,j,x,y,q,r;
		scanf("%d %d",&x,&y);
		if((x+y)>9999){
			j=9999-(x+y-9999);
			i=x;
			q=min(i,j);
			r=max(i,j);
		}
		else{
			i=x;
			j=x+y;
			q=min(i,j);
			r=max(i,j);
		}
		for(int p=q;p<=r;p++){
			if(p%400==0||p%4==0&&p%100!=0)
			count++;
		}
		printf("%d",count);
	}
	
	return 0;
}
