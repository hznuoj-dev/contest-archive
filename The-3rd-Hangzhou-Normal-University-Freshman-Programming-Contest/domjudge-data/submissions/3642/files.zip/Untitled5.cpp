#include<stdio.h>
#include<string.h>
int main(){
 char a[80];
 int n,sum=0,t=0;
 gets(a);
 n=strlen(a);
 for(int i=0;i<n;i++){
 	if(a[i]!=' '){
 		sum=sum+(a[i]-'0');
	 }
	 else{
	 	if(sum==6||sum>=6){
	 		t++;
		 }
	 sum=0;
	 }
 }
 if(sum==6||sum>=6){
	 		t++;
		 }
		 
 switch(t){
 	case 1:
 		printf("Oh dear!!");
 		break;
 	case 2:
 		printf("BaoBao is good!!");
 		break;
 	case 3:
 		printf("Bao Bao is a SupEr man///!");
 		break;
	case 4:
	    printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	    break;
	case 0:
	    printf("Bao Bao is so Zhai......");
	    break;
 }
}
