#include<stdio.h>
#include<string.h>
#pragma warning (disable:4996)

int main(){
	long long int a;
	int sum=0,n=4,i,j=0,len;
	char q[20];
	while(n--){
		sum=0;
	    scanf("%s",&q);
		len=strlen(q);
		for(i=0;i<len;i++){
		    sum=sum+(q[i]-'0');
		}
		if(sum>=16||sum==6){j++;}
	}
	if(j==0){printf("Bao Bao is so Zhai......");}
	if(j==1){printf("Oh dear!!");}
	if(j==2)printf("BaoBao is good!!\n");
	if(j==3)printf("Bao Bao is a SupEr man///!");
	if(j==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    return 0;
}