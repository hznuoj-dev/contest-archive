#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
const int MAX=1e5+10;
int cishu[MAX];
int a[MAX];
int main()
{
	int n;
	long long cnt=1;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
	}
	sort(a+1,a+1+n);
	
//	{
//		for(int i=1;i<=n;i++)
//		{
//			printf("%d",a[i]);
//		}
//	}
	for(int i=1;i<=n;i++)
	{
		if(a[i]>1)
		{
			cnt+=cishu[a[i]-1]-1;
			cishu[a[i]]++;
		}
		else cishu[a[i]]++;
	}
	printf("%lld",cnt);
	
	return 0;
}

