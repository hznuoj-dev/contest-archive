#include<stdio.h>
int main() {
	long long int a, t = 4, sum, total = 0;
	while (t--) {
		sum = 0;
		scanf("%lld", &a);
		while (a > 0) {
			sum = sum + a % 10;
			a = a / 10;
		}
		if (sum >= 16 || sum == 6) {
			total = total + 1;
		}
	}
	switch (total) {
	case 0: printf("Bao Bao is so Zhai......");
		break;
	case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		break;
	case 2:printf("BaoBao is good!!");
		break;
	case 1:printf("Oh dear!!");
		break;
	case 3:printf("Bao Bao is a SupEr man///!");
		break;
	}
}