#include<bits/stdc++.h>
using namespace std;
int main()
{   int t,t1,sum,i,sum1;
    string x;
    int y[201]={0};
    cin>>t;
    while(t--)
    {
        cin>>t1;sum1=0;
        while(t1--)
        {   memset(y,0,sizeof(y));sum=0;
            cin>>x;
            for(i=0;i<x.length();i++)
            {
                if(x[i]=='.') continue;
                y[x[i]]++;
            }
        for(i=0;i<=200;i++)
           if(y[i]>0) sum++;
           sum1+=sum;
        }

        cout<<sum1<<endl;
    }
    return 0;
}
