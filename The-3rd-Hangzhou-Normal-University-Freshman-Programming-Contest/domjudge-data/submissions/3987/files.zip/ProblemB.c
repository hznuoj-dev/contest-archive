#include<stdio.h>
int main(void)
{
	int T, Y, A, sum, i;
	scanf("%d", &T);
	while(T--)
	{
		scanf("%d%d", &Y, &A);
		sum = Y + A;
		if(sum > 9999)
    		sum = 9999 - (sum - 9999);
    	if(A >= 0)
    	{
   			int x = 0;
			for(i = Y;i <= sum;i++)
   	        {
	    	    if(((i % 4 == 0) && (i % 100 != 0)) || (i % 400 == 0))
    		        x = x + 1;
    	    }
        	printf("%d\n", x);
        }
        else if(A < 0)
        {
   	        int x = 0;
			for(i = sum;i <= Y;i++)
            {
            	 if(((i % 4 == 0) && (i % 100 != 0)) || (i % 400 == 0))
		            x = x + 1;
		    }
		    printf("%d\n", x);
        }
    }
	return 0;
}
