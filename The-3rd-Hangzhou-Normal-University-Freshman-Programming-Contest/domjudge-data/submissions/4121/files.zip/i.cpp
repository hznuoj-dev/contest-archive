#include<stdio.h>
char a[100]="Oh dear!!";
char b[100]="BaoBao is good!!";
char c[100]="Bao Bao is a SupEr man///!";
char d[100]="Oh my God!!!!!!!!!!!!!!!!!!!!!";
char e[100]="Bao Bao is so Zhai......";
long long int i,f,g,h;
long long int A,B,C,D,sum1=0,sum2=0,sum3=0,sum4=0,time=0;
int main(){
	scanf("%lld %lld %lld %lld",&i,&f,&g,&h);
	while(i>0){
		A=i%10;
		sum1+=A;
		i=i/10;
	}
	if((sum1==6)||(sum1>=16)){
	time=time+1;	
	}
	while(f>0){
		B=f%10;
		sum2+=B;
		f=f/10;
	}
	if((sum2==6)||(sum2>=16)){
	time=time+1;
	}
	while(g>0){
		C=g%10;
		sum3+=C;
		g=g/10;
	}
	if((sum3==6)||(sum3>=16)){
	time=time+1;
	}
	while(h>0){
		D=h%10;
		sum4+=D;
		h=h/10;
	}
	if((sum4==6)||(sum4>=16)){
	time=time+1;
	}
	if(time==1){printf("%s\n",a);
	}
	if(time==2){printf("%s\n",b);
	}
	if(time==3){printf("%s\n",c);
	}
	if(time==4){printf("%s\n",d);
	}
	if(time==0){printf("%s\n",e);
	}
	return 0;
} 
