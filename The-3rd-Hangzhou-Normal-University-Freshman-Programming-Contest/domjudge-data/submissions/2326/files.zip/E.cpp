#include<stdio.h>
#include<string.h>
int main(){
	char a;
	char str1[100];
	char str2[]="kfc";
	gets(str1);
	a=strcmp(str1,str2);
	while(a==0)
	{

	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n    \\/            \\/");
	a=1;
}	}
