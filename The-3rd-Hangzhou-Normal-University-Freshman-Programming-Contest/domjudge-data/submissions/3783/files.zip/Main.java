import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		while(in.hasNext()) {
			int t=in.nextInt();
			for(int i=0;i<t;i++) {
				int y=in.nextInt();
				int a=in.nextInt();	
				if(y+a>9999)  a=9999-(y+a-9999);
				else  a=y+a;
				int d=Math.max(y, a)-Math.min(y, a)+1;
				d=d/4-d/100+d/400;
				System.out.println(d);
			}
		}
	}
}
