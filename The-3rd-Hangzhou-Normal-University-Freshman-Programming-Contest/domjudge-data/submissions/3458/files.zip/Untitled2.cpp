#include<stdio.h>
int main(void){
	long long int a[4];
	int sum=0,b,s=0,i;
	for(i=0;i<4;i++){
	scanf("%d",&a[i]);
	while(a[i]>0){
		b=a[i]%10;
		sum=sum+b;
		a[i]=a[i]/10;
	}
	if(sum>=16||sum==6){
		s=s+1;
	}
	sum=0;
	}
	switch(s){
		case 0:
			printf("Bao Bao is so Zhai......");
			break;
		case 1:
			printf("Oh dear!!");
			break;
		case 2:
			printf("BaoBao is good!!");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			break;
	}
	return 0;
}
