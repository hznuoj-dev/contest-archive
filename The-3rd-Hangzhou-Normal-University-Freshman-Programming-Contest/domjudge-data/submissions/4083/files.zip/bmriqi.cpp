#include<iostream>
using namespace std;
int main(){
	int t,a,b,c;
	cin>>t;
	while(t--){
		cin>>a>>b;
		int sum=0;
		if(a+b>9999){
			c=9999-(a+b-9999);
		}
		else
		    c=a+b;
		if(a<c){
			for(int i=a;i<=c;i++){
				if(i%4==0&&i%100!=0||i%400==0)
				    sum++;
			}
		}
		else{
			for(int i=c;i<=a;i++){
				if(i%4==0&&i%100!=0||i%400==0)
				    sum++;
			}
		}
		if(sum>2424){
			sum=2424;
		}
		cout<<sum<<endl;
	}
} 
