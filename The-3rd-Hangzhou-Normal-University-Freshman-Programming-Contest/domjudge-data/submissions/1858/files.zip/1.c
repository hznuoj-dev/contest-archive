#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int Run(int x) {
	if((x%4==0 &&x%100!=0)||(x%400==0)) {
		return 1;
	} else {
		return 0;
	}
}
int main() {
	int T;
	scanf("%d",&T);
	while(T--){
		int a,b,c;
		scanf("%d%d",&a,&b);
		c=b;
		char str[a+2];
		int n,i;
		for(i=0;i<=a+1;i++){
			if(i==0){printf("[");
			}else if(i==a+1){printf("]");
			}else{
				if(b>0){printf("#");
				}else{printf("-");
				}
				b=b-1;
			}
		}
		printf(" ");
		printf("%d",c*100/a);
		printf("%%\n");
	}
}
