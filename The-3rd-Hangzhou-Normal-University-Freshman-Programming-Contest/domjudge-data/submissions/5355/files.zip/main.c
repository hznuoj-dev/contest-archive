//
//  main.c
//  bc
//
//  Created by 蔡欣怡 on 2020/12/13.
//

#include <stdio.h>
int isLeap(long long x);
int main(void) {
    // insert code ere...
    long long t=0;
    if(scanf("%lld",&t)){};
    while(t--){
        long long a=0,b=0,n;
        int sum1=0;
        scanf("%lld %lld",&a,&b);
        n=a+b;
        if(b>0){
            if(n>9999){
                n=9999-(n-9999);
                for(long long i=a;i<=n;i++){
                    if(isLeap(i))
                        sum1++;
                }
            }
            else
                for(long long i=a;i<=n;i++){
                    if(isLeap(i))
                        sum1++;
                }
        }
        if(b<=0){
            for(long long i=n;i<=a;i++){
                if(isLeap(i))
                    sum1++;
            }
        }
        printf("%d\n",sum1);
    }
    return 0;
}
int isLeap(long long x){
    if((x%4==0&&x%100!=0)||x%400==0)
        return 1;
    else
        return 0;
}
