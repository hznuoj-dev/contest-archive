#include<stdio.h>
int main(void){
	long int a,b,c,d;
	int count=0;
	int sum1=0,sum2=0,sum3=0,sum4=0;
	scanf("%ld %ld %ld %ld",&a,&b,&c,&d);
	while(a>9||b>9||c>9||d>9){

	sum1+=a%10;
	a/=10;
	
	sum2+=b%10;
	b/=10;
	
	sum3+=c%10;
	c/=10;
	
	sum4+=d%10;
	d/=10;
}
	if(sum2>=16||sum2==6)
		count++;
	if(sum1>=16||sum1==6)
		count++;
	if(sum3>=16||sum3==6)
		count ++;
	if(sum4>=16||sum4==6)
		count ++;
	
	if(count==1) printf("Oh dear!!");
	if(count==2) printf("BaoBao is good!!");
	if(count==3) printf("Bao Bao is a SupEr man///!");
	if(count==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	if(count==0) printf("Bao Bao si so Zhai......") ;	
	return 0;

}
