#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,y,a,y1,y2,i,sum;
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d%d",&y,&a);
		if(y+a>9999){y1=y;y2=9999-(y+a-9999);}
		else{y1=y;y2=y+a;}
		for(i=y1;i<=y2;i++){
			if((i%4==0&&i%100!=0)||i%400==0)sum++;
		}
		printf("%d\n",sum);
	} 
	return 0;
}
