#include<stdio.h>
int main(void){
	int n,m;
	float percent;
	int t,i;

	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		percent=(int)(m*1.0/n*100);
		printf("[");
		for(i=0;i<m;i++)printf("#");
		for(m;m<n;m++)printf("-");
		printf("] %.0f%%\n",percent);
	}
	return 0;
}
