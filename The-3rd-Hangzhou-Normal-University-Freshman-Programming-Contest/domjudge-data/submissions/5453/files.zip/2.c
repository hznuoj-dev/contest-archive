#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
char a[100000];
int main(){
	int t,n,sum=0;
	scanf("%d",&t);
	while(t--){
		scanf("%s",a);
		n=strlen(a);
		sum=sum+n;
	}
	printf("%d",sum);
	
}

	
