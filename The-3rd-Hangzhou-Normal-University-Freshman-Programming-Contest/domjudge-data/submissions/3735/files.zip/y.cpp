#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int T,n,m,x[1000],i,j,a,b,t;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++)
			x[i]=i;
		while(m--){
			scanf("%d%d",&a,&b);
			if(x[a]>x[b])
				t=x[a],x[a]=x[b],x[b]=t;
		}
		for(i=1;i<=n;i++){
			for(j=1;j<=n;j++){
				if(x[j]==i&&i!=n)
					printf("%d ",j);
				else if(x[j]==i&&i==n)
					printf("%d",j);
			}
		}
		printf("\n");
	}
	return 0;
}