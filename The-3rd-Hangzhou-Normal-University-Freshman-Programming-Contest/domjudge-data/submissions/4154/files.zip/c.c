#include<stdio.h>
#include<string.h>
#include<math.h>
int com(int x,int y){
	if(y==1) return x;
	else if(x==1) return 1;
	else {
	
		return (x*com(x-1,y-1));
	}
}

struct nu{
	int a;
	int b;
};
int main()
{
	int n,i,j,t,sum=1; 
	struct nu x[100000];
	for(i=0;i<100000;i++){
	    	x[i].a=i;
	    	x[i].b=0;
		}
	    scanf("%d",&n);
	    for(i=0;i<n;i++){
	    	scanf("%d",&t);
	    	for(j=1;j<n;j++){
	    		if(t==x[j].a) x[j].b++;
			}
		}	    
		for(i=1;i<n-1;i++){
			sum*=com(x[i].b,x[i+1].b);
		}
		printf("%d\n",sum);
	return 0;
} 
