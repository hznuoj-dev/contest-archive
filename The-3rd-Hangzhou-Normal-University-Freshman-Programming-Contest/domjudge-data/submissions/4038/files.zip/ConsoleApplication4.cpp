﻿#include <stdio.h>
#include<string.h>
#include<stdlib.h>
char a[1001], b[1000001];
int main() {
	int n, i, j, k, t;
	scanf("%d", &t);
	while (t--) {
		int sum = 0;
		scanf("%d", &n);
		while (n--) {
			scanf("%s", a);
			k = 0;
			for (i = 0; i < strlen(a); i++) {
				if (a[i] != '.') {
					for (j = 0; j < k; j++) {
						if (b[j] == a[i])
							break;
					}
					if (j == k) {
						b[k] = a[i];
						sum++;
						k++;
					}
				}
			}
		}
		printf("%d\n", sum);
	}
}
