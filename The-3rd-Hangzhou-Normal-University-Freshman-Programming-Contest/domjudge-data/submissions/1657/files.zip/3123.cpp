#include<bits/stdc++.h>
using namespace std;
int main()
{   int x[4],i=0,t=4,sum=0;
    while(t--)
    {
        cin>>x[i];
        i++;
    }
    for(i=0;i<4;i++)
    {
        if(x[i]/10+x[i]%10>=16||x[i]/10+x[i]%10==6) sum++;
    }
    if(sum==1) cout<<"Oh dear!!";
    else if(sum==2) cout<<"BaoBao is good!!";
    else if(sum==3) cout<<"Bao Bao is a SupEr man///!";
    else if(sum==4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
    else if(sum==0) cout<<"Bao Bao is so Zhai......";
    return 0;
}
