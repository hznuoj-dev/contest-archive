#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int t,i,j,e,n,m,a[1001][1],x,y,q,w,tmp;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		for(i=1;i<=1001;i++){
			a[i][0]=i;
		}
		for(i=0;i<m;i++){
			scanf("%d %d",&x,&y);
			for(e=0;e<n;e++){
				if(a[e][0]==x){
					q=e;
				}
				if(a[e][0]==y){
					w=e;
				}
			}
			if(a[q][0]>a[w][0]){
				tmp=a[w][0];
				a[w][0]=a[q][0];
				for(j=q;j>=w+2;j--){
					a[j][0]=a[j-1][0];
				}
				a[j][0]=tmp;
			}
		}
		for(i=1;i<=n-1;i++){
			printf("%d ",a[i][0]);	
		}
		printf("%d\n",a[n][0]);
	}
}
