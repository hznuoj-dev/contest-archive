#include<stdio.h>
int main(void){
	int t;
	int y,a,b;
	int x=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&y,&a);
		b=y+a;
		if(b>9999)b=9999-(b-9999);
		if(b>y){
			for(y;y<=b;y++){
				if((y%4==0&&y%100!=0)||(y%400==0))x+=1;
			}
			printf("%d\n",x);
		}
		else{
			for(b;b<=y;b++){
				if((b%4==0&&b%100!=0)||(b%400==0))x+=1;
			}
			printf("%d\n",x);
		}
		x=0;
	}
	return 0;
}
