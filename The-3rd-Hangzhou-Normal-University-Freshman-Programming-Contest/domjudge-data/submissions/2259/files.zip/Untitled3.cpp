#include<stdio.h>
#include<math.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b;
		scanf("%d%d",&a,&b);
		printf("[");
		for(int i = 0; i<b;i++){
			printf("#");
		}
		for(int j = 0;j < (a-b);j++){
			printf("-");
		}
		printf("]");
		printf(" %.0f%%\n", floor((b*100.0)/(a*1.0)));
	}
}
