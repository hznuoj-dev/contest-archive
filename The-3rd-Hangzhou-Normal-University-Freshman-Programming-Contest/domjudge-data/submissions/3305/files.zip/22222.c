#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
int main(){
	int n;
	int a,b;
	scanf("%d",&n);
	while(n--){
		scanf("%d %d",&a,&b);
		printf("[");
		for(int i=1;i<=b;i++){
			printf("#");
		}
		for(int i=1;i<=(a-b);i++){
			printf("-");
		}
		printf("]");
		printf(" %.0f%%\n",b*1.0/a*100);
		
	} 
}
