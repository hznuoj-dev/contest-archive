#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int n,x;
	char s[1000001];
	scanf("%d",&n);
	x=n;
	while(n--){
		scanf("%s",s);
	}
	printf("%d",x*strlen(s));
	return 0;
}