import java.util.*;
public class Main
{
	public static void main(String[] args) 
	{
        Scanner in = new Scanner(System.in);
        while(in.hasNext()) 
        {
          int b[] = new int[4];
          int z = 0;
          for(int a = 0;a<4;a++) 
          {
        	  b[a] = in.nextInt();
        	  if(b[a]>=16 || b[a]==6) 
        	  {
        		  z++;
        	  }
          }
          switch(z) 
          {
          case 1 : System.out.println("Oh dear!!");break;
          case 2 : System.out.println("BaoBao is good!!");break;
          case 3 : System.out.println("Bao Bao is a SupEr man!");break;
          case 4 : System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
          case 0 : System.out.println("Bao Bao is so Zhai......");break;
          }
          
        }
	}
}