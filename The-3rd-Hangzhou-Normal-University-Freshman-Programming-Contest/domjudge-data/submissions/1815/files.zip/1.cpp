#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#include <cmath>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)
#define ll long long
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)

using namespace std;

string s;

bool judge(int y)
{
	if((y%4==0&&y%100!=0)||y%400==0) return true;
	return false;
}

int main()
{
//	fcin;
	fcio;
	int t;
	cin>>t;
	
	int y,a;
	
	while(t--)
	{
		int cnt=0;
		int res=0;
		cin>>y>>a;
		if(y+a<9999) res=y+a;
		else
		{
			res=9999-(y+a-9999);
		}
		for(int i=min(res,y);i<=max(res,y);i++)
		{
			if(judge(i))
			{
				cnt++;
			}
		}
		cout<<cnt<<endl;
	}
}
