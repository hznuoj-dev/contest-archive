#include <stdio.h>
int min(int a,int b){
	return a<=b?a:b;
}
int max(int a,int b){
	return a>=b?a:b;
}
int main(){
	int t,y,a,he,i,sum;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&y,&a);
		sum=0;
		he=y+a;
		if(y+a>=10000){
			he=9999-(he-9999);
		}
		for(i=min(y,he);i<=max(y,he);i++){
			if((i%4==0&&i%100!=0)||(i%400==0))
				sum++;
		}
		printf("%d\n",sum);
	}
	return 0;
}
