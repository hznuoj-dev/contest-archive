#include <stdio.h>
int main(void) {
	long long int a, b, c, d;
	int aa[20], bb[20], cc[20], dd[20];
	int aaa=0,bbb=0,ccc=0,ddd=0;
	int q=0, w=0, e=0, r=0,s=0;
	scanf("%lld%lld%lld%lld", &a, &b, &c, &d);
	while (a > 0) {
		aa[aaa] = a % 10;
		q = q + aa[aaa];
		a = a / 10;
		aaa++;
	}
	while (b > 0) {
		bb[bbb] = b % 10;
		w = w + bb[bbb];
		b = b / 10;
		bbb++;
	}
	while (c > 0) {
		cc[ccc] = c % 10;
		e = e + cc[ccc];
		c = c / 10;
		ccc++;
	}
	while (d > 0) {
		dd[ddd] = d % 10;
		r = r + dd[ddd];
		d = d / 10;
		ddd++;
	}
	if (q == 6 || q >= 16) {
		s = s + 1;
	}
	if (w == 6 || w >= 16) {
		s = s + 1;
	}
	if (e == 6 || e >= 16) {
		s = s + 1;
	}
	if (r == 6 || r >= 16) {
		s = s + 1;
	}
	if (s == 0) {
		printf("Bao Bao is so Zhai......\n");
	}
	if (s == 1) {
		printf("Oh dear!!\n");
	}
	if (s == 2) {
		printf("BaoBao is good!!\n");
	}
	if (s == 3) {
		printf("Bao Bao is a SupEr man///!\n");
	}
	if (s == 4) {
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
}