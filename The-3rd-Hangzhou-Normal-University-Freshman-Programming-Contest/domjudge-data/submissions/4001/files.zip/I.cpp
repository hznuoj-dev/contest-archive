#include<iostream>
#include<string>
using namespace std;
int main(){
	string a[4];
	int sum=0,m=0,s;
	cin>>a[0]>>a[1]>>a[2]>>a[3];
	for(int i=0;i<4;i++){
		s=a[i].size();
		for(int j=0;j<s;j++){
		sum=sum+(int)a[i][j]-'0';
    	}
    	if(sum==6||sum>=16){
		    m=m+1;
    	}
    	sum=0;
	}
	if(m==0){
		cout<<"Bao Bao is so Zhai.....";
	}
	else if(m==1){
		cout<<"Oh dear!!";
	}
	else if(m==2){
		cout<<"BaoBao is good!!";
	}
	else if(m==3){
		cout<<"Bao Bao is a SupEr man///!";
	}
	else
	    cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
}
