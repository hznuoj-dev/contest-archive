#include<stdio.h>
int main()
{
	int i,t;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		int a,b,c,d,x=0;
		scanf("%d %d",&a,&b);
		c=a+b;
		if(c>9999)
		{
			d=c-9999;
			c=9999-d;
		}
		if(c<a)
		{
			d=a;
			a=c;
			c=d;
		}
		for(d=a;d<=c;d++)
		{
			if(d%4==0)
			x++;
			if(d%100==0&&d%400!=0)
			x--;
		}
		printf("%d\n",x);
	}
	return 0;
}
