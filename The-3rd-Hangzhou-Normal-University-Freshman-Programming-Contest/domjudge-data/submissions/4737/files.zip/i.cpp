#include<bits/stdc++.h>
using namespace std;
int main(){
	char str[5][20];
	int count=0;
	scanf("%s%s%s%s",str[1],str[2],str[3],str[4]);
	for(int i=1;i<5;i++){
		int sum=0;
		for(int j=0;j<20;j++){
			if(str[i][j]=='\0')
			break;
			sum+=str[i][j]-'0';
		}
		if(sum>=16)
		count++;
	}
	if(count==0)
	printf("Bao Bao is so Zhai......\n");
	else if(count==1)
	printf("Oh dear!!\n");
	else if(count==2) 
	printf("BaoBao is good!!\n");
	else if(count==3)
	printf("Bao Bao is a SupEr man///!\n");
	else
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
