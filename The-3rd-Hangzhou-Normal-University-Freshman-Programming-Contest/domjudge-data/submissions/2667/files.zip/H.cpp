#include<stdio.h>
int main()
{
	int T,i;
	scanf("%d",&T);
	float a,b;
	int re,st;
	for(i=0;i<T;i++){
		scanf("%f%f",&a,&b);
		re=(int)(b/a*100);
		printf("[");
		for(int j=0;j<re/10;j++)
		    printf("#");
		st=a-b;
		//printf("%d\n",st);
		while(st--){
		    printf("-");
	    }
		printf("] %d%%\n",re);
	}
	return 0;
}
