#include<stdio.h>
int main(){
	long long a,b,c,d,i,m,s1=0,s2=0,s3=0,s4=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
int count=0;
while(a!=0){
	m=a%10;a=a/10;s1+=m;
}
if(s1>=16||s1==6)count++;
while(b!=0){
	m=b%10;b=b/10;s2+=m;
}
if(s2>=16||s2==6)count++;
while(c!=0){
	m=c%10;c=c/10;s3+=m;
}
if(s3>=16||s3==6)count++;
while(d!=0){
	m=d%10;d=d/10;s4+=m;
}
if(s4>=16||s4==6)count++;

if(count==0)printf("Bao Bao is so Zhai......");
else if(count==1)printf("Oh dear!!");
else if(count==2)printf("BaoBao is good!!");
else if(count==3)printf("Bao Bao is a SupEr man///!");
else if(count==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
