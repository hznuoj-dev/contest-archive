#include<stdio.h>
int main(){
	int t,i;
	int y,a,sj,xj,c;
	scanf("%d",&t);
	while(t--){
		c=0;
		scanf("%d %d",&y,&a);
		sj=y+a;
		xj=y;
		if(sj>=10000){
			sj=9999-(sj-9999);
		}
		if(sj<xj){
			t=xj;
			xj=sj;
			sj=t;
		}
		for(i=xj;i<=sj;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				c++;
			}
		}
		printf("%d\n",c);
	}
	return 0;	
}
