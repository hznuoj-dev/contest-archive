#include<bits/stdc++.h>
using namespace std;
int main()
{   int t;
    float c,a,b,d;
    cin>>t;
    while(t--)
    {
        cin>>a>>b;
        c=b/a*100;
        c=(int)c;
        d=a-b;
        cout<<"[";
        while(b--)
        {
            cout<<"#";
        }
        while(d--)
        {
            cout<<"-";
        }
        cout<<"]";
        printf("%.0f%%\n",c);
    }
    return 0;
}
