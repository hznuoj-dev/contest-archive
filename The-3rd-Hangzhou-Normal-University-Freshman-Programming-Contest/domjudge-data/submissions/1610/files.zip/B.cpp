#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
int v,n,m,x,y,i,j,t=0,sum,temp,s;
char c[100]; 
int main(){
    scanf("%s",&c);
    printf(" __      _____\n"
		   "|  | ___/ ____\____ \n"
		   "|  |/ /\   __\/ ___\ \n"
		   "|    <  |  | \  \___ \n"
		   "|__|_ \ |__|  \___  > \n"
			"    \/           \/\n");
    return 0;
}
