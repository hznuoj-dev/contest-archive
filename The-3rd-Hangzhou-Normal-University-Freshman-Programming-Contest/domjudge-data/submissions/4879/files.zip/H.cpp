#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int main(void) {
    int t,i;
    scanf("%d",&t);
    while(t--){
    	double n,m,a;
    	scanf("%lf%lf",&n,&m);
    	a=m/n;
    	for(i=1;i<=n;i++){
    		if(i==1){
    			printf("[");
				if(m!=0){
					printf("#");
				}
			}
			if(i>1&&i<=m){
				printf("#");
			}
			if(i>m&&i<n){
				printf("-");
			}
			if(i==n){
				if(n!=m){
					printf("-");
				}
				printf("]");
			}
		}
    	printf("%.0f%%\n",a*100);
	}
return 0;
}

