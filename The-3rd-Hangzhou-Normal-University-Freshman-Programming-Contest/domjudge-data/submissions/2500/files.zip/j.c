#include <stdio.h>
#include <string.h>
int pd(char *a){
	int len=strlen(a);
	char b[1000010];
	int num=0;
	int i,leb=0,j;
	for (i=0;i<len;i++){
		if (a[i]!='.'){
			int h=1;
			for (j=0;j<leb;j++){
				if (b[j]==a[i]) {
					h=0;
					break;
				}
			}
			if (h) {
				num++;
				b[leb]=a[i];
				leb++;
			}
		}
	} 
	return num;
}
int main(){
	int n,t,i,sum;
	scanf("%d",&t);
	while (t--){
		scanf("%d",&n);
		sum=0;
		while (n--){
			char a[1000010];
			scanf("%s",a);
			sum+=pd(a);
		}
	    printf("%d",sum);
	}
}
