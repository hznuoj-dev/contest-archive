#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int aaa(char a){
	int i,ans;
		if(a=='1')
		return 1;
		if(a=='2')
	return 2;
		if(a=='3')
return 3;
		if(a=='4')
	return 4;
		if(a=='5')
	return 5;
		if(a=='6')
	return 6;
		if(a=='7')
return 7;
		if(a=='8')
return 8;
		if(a=='9')
	return 9;
		if(a=='0')
	return 0;
	};
int main() {
	char a[20];char b[20];char c[20];char d[20];
	scanf("%s", a); scanf("%s", b); scanf("%s", c); scanf("%s", d);
	int sum = 0,x = 0;
	int len = strlen(a);
	for (int i = 0; i <len; i++) {
		int n = aaa(a[i]);
		sum = sum + n;
	}
	if (sum >= 16 || sum == 6)
		x = x + 1;
	sum = 0; len = strlen(b);
	for (int i = 0; i <len; i++) {
		sum = sum + aaa(b[i]);
	}
	if (sum >= 16 || sum == 6)
		x = x + 1;
	sum = 0; len = strlen(c);
	for (int i = 0; i <len; i++) {
		sum = sum + aaa(c[i]);
	}
	if (sum >= 16 || sum == 6)
		x = x + 1;
	sum = 0; len = strlen(d);
	for (int i = 0; i <len; i++) {
		sum = sum + aaa(d[i]);
	}
	if (sum >= 16 || sum == 6)
		x = x + 1;
	if (x == 1)
		printf("Oh dear!!");
	else if (x == 2)
		printf("BaoBao is good!!");
	else if (x == 3)
		printf("Bao Bao is a SupEr man///!");
	else if (x == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else
		printf("Bao Bao is so Zhai......");
}
