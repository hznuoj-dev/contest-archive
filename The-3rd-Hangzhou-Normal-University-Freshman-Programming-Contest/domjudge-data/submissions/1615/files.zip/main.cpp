#include <bits/stdc++.h>
using namespace std;
typedef long long  ll;
const int MAXN=2e4+5;
ll a,b,c,d,l,mid,r,sum=0,n,m,t=0,k,x,w,v,y,ans,x2,y2;
int main()
{
#ifdef zzy
    freopen("main.h","r",stdin);
#endif // zzy
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>a>>b;
        if(a+b>9999)
        {
            l=a;
            r=9999-a-b+9999;
        }
        else
        {
            l=a;
            r=a+b;
        }
        l=min(l,r);
        r=max(l,r);
        for(int i=l; i<=r; i++)
        {
            if(i%4==0&&i%100!=0)
                sum++;
            if(i%400==0)
                sum++;
        }
        cout<<sum<<'\n';
        sum=0;
    }


    return 0;
}

