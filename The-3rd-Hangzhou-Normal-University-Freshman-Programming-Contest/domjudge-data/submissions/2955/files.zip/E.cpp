#include <stdio.h>
#define string_length 3
int main ()
{
	char str[4];
	scanf("%s",str);
		printf(" --      -----     \n");
		printf("|  | ___/ ____\\____\0");
		printf("\n");
		printf("|  |/ /\\   __\\/ ___\0");
		printf("\\");
		printf("\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/\n");
	return 0;
 } 

