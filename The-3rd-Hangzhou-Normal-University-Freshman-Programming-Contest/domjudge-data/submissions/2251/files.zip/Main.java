import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			int n=in.nextInt();
			for(int i=1;i<=n;i++)
			{
				int a=in.nextInt();
				int b=in.nextInt();
				int c=a+b;
				int d=0;
				int sum=0;
				if(c>9999)
				{
					d=c-9999;
					if((9999-d)>a)
					{
						for(int j=a;j<=9999-d;j++)
						{
							if(run(j))
							{
								sum++;
							}
						}
					}
					else
					{
						for(int j=9999-d;j<=a;j++)
						{
							if(run(j))
							{
								sum++;
							}
						}
					}									
				}
				else
				{
					if(a<c)
					{
						for(int j=a;j<=c;j++)
						{
							if(run(j))
							{
								sum++;
							}
						}
					}
					else
					{
						for(int j=c;j<=a;j++)
						{
							if(run(j))
							{
								sum++;
							}
						}
					}
				}
				System.out.println(sum);
			}
		}
	}
	public static boolean run(int n)
	{
		if(n%100==0)
		{
			if(n%400==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		else
		{
			if(n%4==0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
}
