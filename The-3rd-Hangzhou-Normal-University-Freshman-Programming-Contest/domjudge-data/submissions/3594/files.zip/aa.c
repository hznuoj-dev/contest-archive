#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d %d",&n,&m);
		int y[n+1][n+1],p[n];
		while(m--){
			int a,b;
			scanf("%d %d",&a,&b);
			y[a][b]=1;
			y[b][a]=-1;
		}
		for(int i=0;i<n;i++){
			p[i]=i+1;
		}
		for(int i=0;;i++){
			int f=0,h;
			for(int k=0;k<n;k++){
				for(int j=0;k+j<n-1;j++){
					if(y[p[k]][p[k+j+1]]==-1){
						h=p[k],p[k]=p[k+j+1],p[k+j+1]=h;
						f=1;
					}else if(y[p[k]][p[k+j+1]]!=1 && p[k]>p[k+j+1]){
						h=p[k],p[k]=p[k+j+1],p[k+j+1]=h;
						f=1;
					}
				}	
			}
			
			if(!f) break;
		}
		for(int i=0;i<n;i++){
			if(i)printf(" %d",p[i]);
			else printf("%d",p[i]);
		}
		printf("\n");
	}
}
