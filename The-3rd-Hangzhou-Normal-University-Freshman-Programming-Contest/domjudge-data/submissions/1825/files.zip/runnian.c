#include"stdio.h"
int main()
{
int a;
scanf("%d",&a);
while(a--)
{
	int b,c,i,d=0;
	scanf("%d%d",&b,&c);
	if(b<=c){
	for(i=b;i<=c;++i)
	{
		if((i%4==0&&i%100!=0)||(i%400==0))
		++d;
	}
	} 
	else
	{
	c=b+c;
	if(b<=c){
	for(i=b;i<=c;++i)
	{
		if((i%4==0&&i%100!=0)||(i%400==0))
		++d;
	}
	} 
	else
	{
		int t=0;
		t=c;
		c=b;
		b=t;
		for(i=b;i<=c;++i)
	{
		if((i%4==0&&i%100!=0)||(i%400==0))
		++d;
	}
	}
	}
	if(b>9999||c>9999) 
	d=d+1;
	printf("%d\n",d);
}
return 0;
 }
