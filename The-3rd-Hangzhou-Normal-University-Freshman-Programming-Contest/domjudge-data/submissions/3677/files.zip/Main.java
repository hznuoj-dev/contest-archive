package work;

import java.math.BigInteger;
import java.util.Arrays;
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{
			int ans = 0;
			BigInteger a = new BigInteger(sc.next());
			BigInteger b = new BigInteger(sc.next());
			BigInteger c = new BigInteger(sc.next());
			BigInteger d = new BigInteger(sc.next());
			if (daan(a))
			{
				ans++;
			}
			if (daan(b))
			{
				ans++;
			}
			if (daan(c))
			{
				ans++;
			}
			if (daan(d))
			{
				ans++;
			}
			if (ans == 0)
			{
				System.out.println("Bao Bao is so Zhai......");
			}
			if (ans == 1)
			{
				System.out.println("Oh dear!!");
			}
			if (ans == 2)
			{
				System.out.println("BaoBao is good!!");
			}
			if (ans == 3)
			{
				System.out.println("Bao Bao is a SupEr man///!");
			}
			if (ans == 4)
			{
				System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			}
		}

	}

	public static boolean daan(BigInteger n)
	{
		BigInteger ans = new BigInteger("0");
		BigInteger a2 = new BigInteger("10");
		BigInteger a22 = new BigInteger("15");
		BigInteger ans2 = new BigInteger("0");
		BigInteger an3 = new BigInteger("6");
		while (true)
		{

			ans = ans.add(n.mod(a2));
			n = n.divide(a2);

			if (n.equals(ans2))
			{
				break;
			}
		}

		if (ans.compareTo(a22) > 0 || ans.equals(an3))
		{
			return true;
		}

		return false;

	}
}
