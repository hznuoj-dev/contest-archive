#include<stdio.h>
int main(){
int t;
scanf("%d",&t);
int a,b;
int k;
while(t--){
int m=0;
scanf("%d %d",&a,&b);
k=a+b;
if(k>=10000){
k=9999-(k-10000);	
}
int t;
if(a>k){
t=a;
a=k;
k=t;	
}
for(int i=a;i<=k;i++){
	if((i%4==0&&i%100!=0)||(i%400==0)){
		m+=1;
	}
}
printf("%d\n",m);	
}
}
