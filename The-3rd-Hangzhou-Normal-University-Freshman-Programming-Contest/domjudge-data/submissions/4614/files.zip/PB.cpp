#include <stdio.h>
int main()
{
int T;
scanf("%d",&T);
while(T--){
int y1, y2, i, count;

scanf("%d", &y1);
scanf("%d",&y2);
count= 0;
for(i = y1; i <= y2; i++)
if
(((i % 4 == 0) && (i % 100 != 0)) || i % 400 == 0)
			count++;
    printf("%d\n", count);
}
	return 0;
 
}
