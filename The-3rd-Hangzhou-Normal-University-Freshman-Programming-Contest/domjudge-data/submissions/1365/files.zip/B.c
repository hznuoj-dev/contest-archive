#include<stdio.h>
int main()
{
	int T,A,Y;
	int i,year,sum,t;
	scanf("%d",&T);
	while(T--)
	{
		sum=0;
		scanf("%d %d",&Y,&A);
		year=Y+A;
		if(year>9999)
			year=9999-(year-9999);
		if(Y>year)
		{
			t=Y;
			Y=year;
			year=t;
		}
		for(i=Y;i<=year;i++)
		{
			if((i%4==0 && i%100!=0) || (i%400==0))
				sum++;
		}
		printf("%d\n",sum);
	}
	return 0;
}
