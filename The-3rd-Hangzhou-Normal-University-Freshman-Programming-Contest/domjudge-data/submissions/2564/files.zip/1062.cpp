#include <stdio.h>
#include <string.h>
char s[100][1000000];
int main()
{
	int t,i,n,j,sum,l,len,o,p,m;
	char flag[200];
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		sum=0;
		scanf("%d",&n);
		for(j=0;j<n;j++){
			p=0;
			l=0;
			scanf("%s",&s[j]);
			len=strlen(s[j]);
			for(o=0;o<len;o++){
				if(s[j][o]=='.'){
					l=l;
				}else{
					flag[p]=s[j][o];
					p++;
					for(m=0;m<p-1;m++){
						if(flag[m]==flag[p-1]){
							break;
						}
					}
					if(m==p-1||p==1){
						l++;
					}
				}
			}
			sum=sum+l;
		}
		printf("%d\n",sum);
	}
	return 0;
}

