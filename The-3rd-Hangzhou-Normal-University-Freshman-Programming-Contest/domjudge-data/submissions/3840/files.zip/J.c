#include<stdio.h>
#include<string.h>
int main(){
	int n,i,j,t,r,len,cnt;
	char s[1000000];
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d",&n);
		cnt=0;
		for(j=0;j<n;j++){
			int count[300]={0};
			scanf("%s",s);
			len=strlen(s);
			for(r=0;r<len;r++){
				if(s[r]!='.'){
					count[s[r]]++;
					if(count[s[r]]==1) cnt++;
				}
			}
		}
		printf("%d\n",cnt);
	} 
	return 0;
}
