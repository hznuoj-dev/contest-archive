#include<stdio.h>
int main(void)
{
	int n = 4;
	int sum = 0,  cnt = 0;
	while(n--)
	{
	   long long int a, i, j;
	   scanf("%lld", &a);
	   while(a != 0)
	   {
	   	  i = a % 10;
	   	  cnt += i; 
	   	  j = a / 10;
	   	  a = j;
	   }
	   if(cnt >= 16 || cnt == 6)
	    sum++;
	}
	if(sum == 1)
	  printf("Oh dear!!\n");
	else if(sum == 2)
	  printf("BaoBao is good!!\n");
	else if(sum == 3)
	  printf("Bao Bao is a SupEr man///!\n");
	else if(sum == 4)
	  printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	else
	  printf("Bao Bao is so Zhai......\n");
	return 0;
 } 
