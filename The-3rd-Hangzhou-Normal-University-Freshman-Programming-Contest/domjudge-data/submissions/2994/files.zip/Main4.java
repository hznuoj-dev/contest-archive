import java.util.Scanner;

public class Main4
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{
           long a=sc.nextLong();
           long b=sc.nextLong();
           long c=sc.nextLong();
           long d=sc.nextLong();
           int sum=0;
           if(daxiao(a))
           {
        	   sum++;        	   
           }
           if(daxiao(b))
           {
        	   sum++;        	   
           }
           if(daxiao(c))
           {
        	   sum++;        	   
           }
           if(daxiao(d))
           {
        	   sum++;        	   
           }
           switch(sum)
           {
           case 4:
        	   System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
        	   break;
           case 3:
        	   System.out.println("Bao Bao is a SupEr man///!");
        	   break;
           case 2:
        	   System.out.println("BaoBao is good!!");
        	   break;
           case 1:
        	   System.out.println("Oh dear!!");
        	   break;
           case 0:
               System.out.println("Bao Bao is so Zhai......");
               break;
           }
           
        		   
		}

	}
	public static boolean daxiao(long x)
	{
		long sum=0;
		while(x>0)
		{
			sum=x%10+sum;
			x=x/10;
		}
		if(sum>=16||sum==6)
		{
			return true;
		}
		return false;
	}

}
