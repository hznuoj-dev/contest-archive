#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main() {
	int  f, t, k, n, i, sum;
	char a[200], c;
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &k);
		sum = 0;
		getchar();
		while(k--) {
			a[0] = '.';
			n = 0;
			while ((c = getchar()) != '\n') {
				i = 0;
				while (i <= n) {
					if (a[i] != c) {
						i++;
					}
					else {
						break;
					}
				}
				if (i > n) {
					n += 1;
					a[n] = c;
				}
			}
			sum += n;
			for (i = 1; i <= n; i++) {
				a[i] = '\0';
			}
		}
		printf("%d\n", sum);
	}
	return 0;
}