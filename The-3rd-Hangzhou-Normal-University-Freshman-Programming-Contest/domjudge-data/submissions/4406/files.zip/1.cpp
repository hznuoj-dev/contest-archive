#include<stdio.h>
int main(void) {
	int t, a, b, c, i;
	scanf("%d", &t);
	while (t--) {
		char list[10001] = { '0' };
		scanf("%d%d", &a, &b);
		c = b * 100 / a;
		list[0] = '[';
		list[a + 1] = ']';
		for (i = 1; i <= b; ++i) {
			list[i] = '#';
		}
		for (i = b + 1; i < a + 1; ++i) {
			list[i] = '-';
		}
		printf("%s%d%%\n", list, c);
	}
	return 0;
}
