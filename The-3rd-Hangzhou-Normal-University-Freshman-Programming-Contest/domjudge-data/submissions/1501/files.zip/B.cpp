#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<set>
#include<map>
#include<iostream>
#include<string>
using namespace std;
typedef long long int ll;
const int N=1e5+100;
bool ju(int n){
	if(n%4==0 && n%100!=0)return 1;
	if(n%400==0)return 1;
	return 0;
}
void run(){
	int a,b;
	scanf("%d%d",&a,&b);
	int c=a+b;
	if(c>9999){
		int cha=c-9999;
		c=9999-cha;
	}
	int ans=0;
	for(int i=min(a,c);i<=max(a,c);i++){
		if(ju(i))ans++;
	}
	printf("%d\n",ans);
}
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		run();
	}
	return 0;
}
