#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
	long long int a,b,c,i,j,d;
	scanf("%lld",&j);
	while(j--)
	{
		d=0;
		scanf("%lld%lld",&a,&b)
			c=a+b;
		if(b<0)
			for(i=c;i<=a;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					d++;
			}
		else if(c>9999)
			c=9999-(c-9999)
			for(i=a;i<=c;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					d++;
			}
		else
		{
			for(i=a;i<=c;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					d++;
			}
		}
		printf("%d\n",d);
	}
	return 0;
}