#include<bits/stdc++.h>
using namespace std;

int main()
{
	int t,h,temp;
    int len;
    cin>>t;
    char a[20];
    int cnt[200],ans;
    memset(cnt, 0, sizeof(cnt));
    while(t--)
	{
        ans = 0;
        cin >> h;
        while(h--){
            cin >> a;
            len = strlen(a);
            for(int i= 0;i<len;i++){
                temp = a[i];
                if(a[i]=='.')
                    continue;
                else{
                    if(cnt[temp]==0){
                    cnt[temp]++;
                    ans ++;
                    }
                }
            }
            memset(cnt, 0, sizeof(cnt));
            memset(a, 0, sizeof(a));
        }
        cout << ans <<endl;
    }
	return 0;
}
