#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
	char w[1001];
	scanf("%s", w);
	if (strcmp(w, "kfc") == 0) {
		printf("__ _____\n");
		printf("| | ___/ ____\\____\n");
		printf("| |/ /\\ __\\/ ___\\\n");
		printf("| < | | \\ \\___\n");
		printf("|__|_ \\ |__| \\___ >\n");
		printf("\\/ \\/\n");
	}
}