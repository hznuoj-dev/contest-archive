#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996)
int main()
{	
	int a,b,c,d,e=0,m=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	while(a>0)
	{
		e=e+a%10;
		a=a/10;
	}
	if(e==6||e>=16)
		m++;
	e=0;
	while(b>0)
	{
		e=e+b%10;
		b=b/10;
	}
	if(e==6||e>=16)
		m++;
	e=0;
	while(c>0)
	{
		e=e+c%10;
		c=c/10;
	}
	if(e==6||e>=16)
		m++;
	e=0;
	while(d>0)
	{
		e=e+d%10;
		d=d/10;
	}
	if(e==6||e>=16)
		m++;
	e=0;
	if(m==0)
		printf("Bao Bao is so Zhai......");
		if(m==1)
			printf("��Oh dear!!");
		if(m==2)
			printf("BaoBao is good!!");
		if(m==3)
			printf("��Bao Bao is a SupEr man///!");
		if(m==4)
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}