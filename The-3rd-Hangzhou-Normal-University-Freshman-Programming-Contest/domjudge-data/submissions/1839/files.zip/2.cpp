#include<stdio.h>
int main(){
	int judge(int n,int m);
	int t,a,b,c;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		if((a+b)>=10000)c=9999-(a+b-9999);
		else c=a+b;
		printf("%d\n",judge(a,c));
	}
}

int judge(int n,int m){
	int cnt=0;
	if(m<n){int t=m;m=n;n=t;}
	for(int i=n;i<=m;i++){
		if((i%4==0&&i%100!=0)||i%400==0)cnt++;
	}
	return cnt;
}
