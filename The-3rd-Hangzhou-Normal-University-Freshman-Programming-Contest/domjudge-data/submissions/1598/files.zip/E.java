import java.util.Scanner;

public class E {
    public static void main(String[] args) {
        Scanner in= new Scanner(System.in);
        String kfc=in.next();
        System.out.println(" __      _____");
        System.out.println("|  | ___/ ____\\____");
        System.out.println("|  |/ /\\   __\\/ ___\\");
        System.out.println("|    <  |  | \\  \\___");
        System.out.println("|__|_ \\ |__|  \\___  >");
        System.out.println("     \\/           \\/");
    }
}
