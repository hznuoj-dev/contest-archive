#include<stdio.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int a1,a2,i,f=0,b,c;
		scanf("%d %d",&a1,&c);
		a2=a1+c;
		if(a2>=9999){
			a2=9999-(a2-9999);
		}
		
		if(a2<a1)
		{
			b=a2;
			a2=a1;
			a1=b;
		}
		
		for(i=a1;i<=a2;i++)
		{
			
			if((i%4==0&&i%100!=0)||i%400==0)
			{
				f+=1;
			}
			
			
		}
		
		printf("%d\n",f);
		f=0;
		
	}
	return 0;
	
}
