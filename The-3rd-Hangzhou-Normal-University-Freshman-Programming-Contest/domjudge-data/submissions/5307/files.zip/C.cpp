#include<bits/stdc++.h> 
using namespace std;
int main(){
	long long int n,lief=1,ans=1,a[10086];
	scanf("%lld",&n);
	for(int i=1;i<=n;++i){
		int x;
		scanf("%d",&x);
		a[x]++;
		if(x>=lief) lief=x;
	}
	for(int i=2;i<=lief;++i){
		long long int k=0;
		for(int j=a[i];j<=2*a[i-1];++j){
			++k;
			ans=ans*j/k;
		}
		ans=ans/2;
	}
	printf("%lld",ans);
	return 0;
}
