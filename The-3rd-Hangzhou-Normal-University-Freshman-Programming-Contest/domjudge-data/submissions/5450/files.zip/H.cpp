#include<stdio.h>
int main(){
	int T,a,b,i,m;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&a,&b);
		for(i=1;i<=a;i++){
			if(i==1)
			printf("[");
			if(i<=b)
			printf("#");
			else
			printf("-");
			if(i==a)
			printf("]"); 
		}
		m=b*100/a;
		printf(" %d%%\n",m);
	}
} 
