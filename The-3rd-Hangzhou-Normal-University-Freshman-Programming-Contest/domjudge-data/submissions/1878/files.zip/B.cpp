#include <stdio.h>
int main()
{
	int t,c,j,a,b,s,n,x;
	scanf("%d",&t);
	for(c=1;c<=t;c++){
		scanf("%d %d",&a,&b);
		s=a+b;
		n=0;
		if(s>9999){
			s=9999*2-s;
		}
		if(a>s){
			x=a;a=s;s=x;
		}
		for(j=a;j<=s;j++){
			if(j%4==0 && j%100!=0 || j%400==0){
				n++;
			}
		}
		printf("%d\n",n);
	}
	return 0;
}
