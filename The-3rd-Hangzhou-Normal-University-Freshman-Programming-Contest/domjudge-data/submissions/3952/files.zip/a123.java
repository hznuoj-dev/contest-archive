import java.math.BigInteger;
import java.util.Scanner;


public class a123
{

	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			int jishu=0;
			int jishu2=0;
			BigInteger a=in.nextBigInteger();
			BigInteger b=in.nextBigInteger();
			BigInteger c=in.nextBigInteger();
			BigInteger d=in.nextBigInteger();
			BigInteger g=new BigInteger("10");
			BigInteger g2=new BigInteger("0");
			BigInteger g3=a;
			BigInteger g4=b;
			BigInteger g5=c;
			BigInteger g6=d;
			BigInteger leijia=new BigInteger("0");
			BigInteger leijia2=new BigInteger("0");
			BigInteger leijia3=new BigInteger("0");
			BigInteger leijia4=new BigInteger("0");
			BigInteger shiliu=new BigInteger("16");
			BigInteger liu=new BigInteger("6");
			
		    for(int i=0;i<a.bitCount();i++)
		    {
		    	g2=g3.mod(g);
		        g3=g3.divide(g);
		        leijia=leijia.add(g2);
		        
		    }
		    for(int i=0;i<b.bitCount();i++)
		    {
		    	g2=g4.mod(g);
		        g4=g4.divide(g);
		        leijia2=leijia2.add(g2);
		        
		    }
		    for(int i=0;i<c.bitCount();i++)
		    {
		    	g2=g5.mod(g);
		        g5=g5.divide(g);
		        leijia3=leijia3.add(g2);
		        
		    }
		    for(int i=0;i<d.bitCount();i++)
		    {
		    	g2=g6.mod(g);
		        g6=g6.divide(g);
		        leijia4=leijia4.add(g2);
		        
		    }
		    if((leijia.compareTo(shiliu)==1|leijia.compareTo(shiliu)==0)|leijia.compareTo(liu)==0)
		    {
		    	jishu=jishu+1;
		    }
		     if((leijia2.compareTo(shiliu)==1|leijia2.compareTo(shiliu)==0)|leijia2.compareTo(liu)==0)
		    {
		    	jishu=jishu+1;
		    }
		     if((leijia3.compareTo(shiliu)==1|leijia3.compareTo(shiliu)==0)|leijia3.compareTo(liu)==0)
		    {
		    	jishu=jishu+1;
		    }
		     if((leijia4.compareTo(shiliu)==1|leijia4.compareTo(shiliu)==0)|leijia4.compareTo(liu)==0)
		    {
		    	jishu=jishu+1;
		    }
		    if(jishu==0)
		    {
		    	System.out.println("Bao Bao is so Zhai......");
		    }
		    if(jishu==1)
		    {
		    	System.out.println("Oh dear!!");
		    }
		    if(jishu==2)
		    {
		    	System.out.println("BaoBao is good!!");
		    
		    }if(jishu==3)
		    {
		    	System.out.println("Bao Bao is a SupEr man///!");
		    }
		    if(jishu==4)
		    {
		    	System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		    }
		}

	}

}
