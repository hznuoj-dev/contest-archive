#include <stdio.h>
int main(void){
	int n;
	scanf("%d",&n);
	while(n--){
		int m,n,i;
		int a,cnt=0;
		scanf("%d %d",&m, &n);
		a=m+n;
		if(m>a){
			int b=m;
			m=a;
			a=b;
		}
		for(i=m;i<a;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				cnt++;
			}
		}
		printf("%d\n",cnt);
	}
	return 0;
}
