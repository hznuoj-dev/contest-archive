#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int n,a[100000],b[10000]={0};
	int i,j,t;
	long long sum;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[a[i]]++;
	}
	i=3;
	sum=1;
	while(b[i]!=0)
	{
		t=1;
		for(j=1;j<=b[i];j++)
			t*=2;
		if(b[i]%2==0)
			t=t-b[i]/2;
		sum=sum*t;
		i++;
	}
	printf("%lld\n",sum);
	
	return 0;
}
