#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	char a[100];
	scanf("%s",a);
	if (strcmp(a,"kfc")==0) 
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");
	return 0;
}
