#include "stdio.h"
#include "math.h"
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d %d",&n,&m);
		printf("[");
		for(int i=1;i<=m;i++){
			printf("#");
		}
		for(int i=1;i<=(n-m);i++){
			printf("-");
		}
		printf("] ");
		double ree=(1.0*m)/(1.0*n)*100;
		double re=floor(ree);
		printf("%.lf%%\n",re);
	}
} 


//[##--------] 20%
