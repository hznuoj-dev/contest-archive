#include<stdio.h>
int f(int k)
{
	int c=0;
	while(k>0)
	{
		c+=k%10;
		k=k/10;
	}
	return c;
}
int main()
{
	int A,B,C,D,score=0;
	char s[100]={"Bao Bao is so Zhai......"};
	char o[100]={"Bao Bao is a SupEr man///!"};
	char p[100]={"BaoBao is good!!"};
	char q[100]={"Oh dear!!"};
	char r[100]={"Oh my God!!!!!!!!!!!!!!!!!!!!!"};
	scanf("%d%d%d%d",&A,&B,&C,&D);
	if(f(A)>=16||f(A)==6)
	score++;
	if(f(B)>=16||f(B)==6)
	score++;
	if(f(C)>=16||f(C)==6)
	score++;
	if(f(D)>=16||f(D)==6)
	score++;
	if(score==0)
	puts(s);
	else if(score==1)
	puts(q);
	else if(score==2)
	puts(p);
	else if(score==3)
	puts(o);
	else if(score==4)
	puts(r);
}
/*int f(int k)
{
	int l=0;
	while(k>1)
	{
		k=k/2;
		l++;
	}
	return l;
}
int main()
{
	int t;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
	    int a;
		scanf("%d",&a);
	}
	

	return 0;
}
*/ 
/*
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int n,T,m,p;
	int team[501],problemid[501],timestamp[501],recod[501];
	scanf("%d %d %d %d",&n,&T,&m,&p);
	for(int i=0;i<m;i++)
	{
		char s[2];
		scanf("%d %d %d",&team[i],&problemid[i],&timestamp[i]);
		scanf("%s",s);
		if(s[0]=='A'&&s[1]=='C')
			recod[i]=1;
		else
			recod[i]=0;
	}
	int q;
	scanf("%d",&q);
	for(int i=0;i<q;i++)
	{
		char q[10],a,b;
		scanf("%s",q);
		scanf("%d %d",&a,&b);
	}
	return 0;
}*/ 
