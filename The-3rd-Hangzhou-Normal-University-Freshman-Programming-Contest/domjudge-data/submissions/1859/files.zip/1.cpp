#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 

int k(int year){
	int flag=0;
	if((year%4==0&&year%100!=0)||year%400==0)
	flag=1;
	return flag;
}

int main(){
	int t,year,year1,x,n=0,i,ii;
	scanf("%d",&t);
	while(t--){
		n=0;
		scanf("%d %d",&year,&x);
		year1=year+x;
		if(year1>year)
		x=year,year=year1,year1=x;
		year=9999-year%9999;
		for(i=year1;i<=year;i++){
			if(k(i))
			n++;
		}
		printf("%d\n",n);
	}
} 

