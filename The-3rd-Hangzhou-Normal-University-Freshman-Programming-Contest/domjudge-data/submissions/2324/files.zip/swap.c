#include<stdio.h>
int main(void){
	int a,b,y,n;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		int cnt=0;
		scanf("%d %d",&a,&b);
		y=a+b;
		if(y>9999)
		y=y-10000+9999; 
		while (y>9999){
				y=y-10000;
		}
			if(y<a){
				for(int j=y;j<=a;j++){
				if(j%4==0&&j%100!=0||j%400==0) {
				cnt++;
				}
			}
		}
			if(y>a){
			for(int j=a;j<=y;j++){
				if(j%4==0&&j%100!=0||j%400==0) cnt++;
		}
	}
	
	printf("%d\n",cnt);
}
return 0;
}


