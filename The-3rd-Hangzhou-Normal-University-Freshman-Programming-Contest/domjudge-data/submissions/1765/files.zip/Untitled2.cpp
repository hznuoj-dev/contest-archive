#include<stdio.h>
int main(void){
	long long int A,B,C,D,sum=0,a,s=0;
	scanf("%d%d%d%d",&A,&B,&C,&D);
	while(A>0){
		a=A%10;
		sum=sum+a;
		A=A/10;
	}
	if(sum>=16||sum==6){
		s=s+1;
	}
	sum=0;
	while(B>0){
		a=B%10;
		sum=sum+a;
		B=B/10;
	}
	if(sum>=16||sum==6){
		s=s+1;
	}
	sum=0;
	while(C>0){
		a=C%10;
		sum=sum+a;
		C=C/10;
	}
	if(sum>=16||sum==6){
		s=s+1;
	}
	sum=0;
	while(D>0){
		a=D%10;
		sum=sum+a;
		D=D/10;
	}
	if(sum>=16||sum==6){
		s=s+1;
	}
	switch(s){
		case 0:
			printf("Bao Bao is so Zhai......");
			break;
		case 1:
			printf("Oh dear!!");
			break;
		case 2:
			printf("BaoBao is good!!");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			break;
	}
	return 0;
}
