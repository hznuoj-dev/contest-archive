#include<stdio.h>
#include<string.h>
int judge(int x){
	int sum=0;
	while(x){
		sum+=x%10;
		x/=10;
	}
	if(sum>=16||sum==6)
	return 1;
	else
	return 0;
}
int main(void){
	int sum=0;
	int a,b,c,d;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	if(judge(a))
	sum++;
	if(judge(b))
	sum++;
	if(judge(c))
	sum++;
	if(judge(d))
	sum++;
	switch(sum){
		case 0:
			printf("Bao Bao is so Zhai......");break;
		case 1:
			printf("Oh dear!!");break;
		case 2:
			printf("BaoBao is good!!");break;
		case 3:
			printf("Bao Bao is a SupEr man///!");break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
} 
