#include<stdio.h>
#include<math.h>
#include<string.h>
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
	   long long n,m,i,j;
	   double x,y;
	   scanf("%lld %lld",&n,&m);
	   printf("[");
	   for (i=1;i<=m;i++) printf("#");
	   for (i=1;i<=n-m;i++) printf("-");
	   printf("] ");
	   x=m*100.0/n;
	   y=fmod(x,1.0);
	   if (y*10>=5) x--;
	   printf("%.0lf",x);
	   printf("%%\n");
	
	} 
	return 0;
}


  
