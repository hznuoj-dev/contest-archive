#include<stdio.h>
int main(void){
	int T,i;
	int n,m;
	float s;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&m);
		s=m*100/n;
		printf("[");
		for(i=1;i<=m;i++){
			printf("#");
		}
		for(i=m;i<n;i++){
			printf("-");
		}
		printf("]");
		printf(" ");
		printf("%.f%%",s);
		printf("\n");
	}
	return 0;
}
