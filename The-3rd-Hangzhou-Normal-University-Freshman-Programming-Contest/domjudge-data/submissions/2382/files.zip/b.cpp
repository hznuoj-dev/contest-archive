#include<bits/stdc++.h>
using namespace std;
bool Isrn(int year){
  return year%4==0&&year%100!=0||year%400==0;
} 
int main(){
	int n,y,a;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d%d",&y,&a); 
		int year=y+a,temp,count=0;
		if(year>=10000){
			year=9999-(year%9999);
			
		}
		
		if(year<y){
		temp=y;
			y=year;
			year=temp;
		}
		for(int j=y;j<=year;j++){
			if(Isrn(j))
			count++;
		}
		printf("%d\n",count);
	} 
	return 0;
}
