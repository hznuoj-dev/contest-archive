#include<stdio.h>
int main(){
	int t,j,i,y,a,m,ti,count;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		count=0;
		scanf("%d %d",&y,&a);
		m=y+a;
		if(m>9999){
			m=m-9999;
			m=9999-m;
		}
		if(m<y){
			ti=m; 
			m=y;
			y=ti;
		}
		for(j=y;j<=m;j++){
			if(j%400==0||j%4==0&&j%100!=0){
				count++;
			}
			if(j==0) count--;
		}
		printf("%d\n",count);
	}
	return 0;
}

