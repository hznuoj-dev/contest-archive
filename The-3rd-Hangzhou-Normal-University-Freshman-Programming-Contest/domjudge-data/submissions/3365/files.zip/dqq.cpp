#include<stdio.h>
#include<string.h>
int main(void)
{
	int T,n,t=1,sum=0,i,j;
	char s[1000010]={0},c;
	scanf("%d",&T);
	while(T--)
	{
		sum=0;
		scanf("%d",&n);
		while(n--)
		{
			scanf("%s",s);
			for(i=0;i<strlen(s);i++)
			{
				if(s[i]!='.')
				{
					for(j=0;j<i;j++)
					{
						if(s[j]==s[i])
						{
							t=0;
							break;
						}
					}
					if(t==1)
					sum++;
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
