#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main() {
	int T;
	long long n,m;
	long long i;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%lld %lld",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
			printf("#");
		for(i=1;i<=n-m;i++) 
			printf("-"); 
		printf("] %.0Lf%c\n" ,(double)m/n*100.0,'%');
	} 
	return 0;
}                                                                      
