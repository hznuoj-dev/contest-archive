#include<stdio.h>
int main()
{
	int t, a, b, x, y, i, cnt;
	scanf("%d", &t);
	while (t--)
	{
		cnt = 0;
		scanf("%d%d", &a, &b);
		if (a + b > 9999)
			b = 19998 - a - b;
		else
			b = a + b;
		x = a < b ? a : b;
		y = a > b ? a : b;
		for (i = x; i <= y; i++)
		{
			if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0))
				cnt++;
		}
		printf("%d\n", cnt);
	}
	return 0;
}
