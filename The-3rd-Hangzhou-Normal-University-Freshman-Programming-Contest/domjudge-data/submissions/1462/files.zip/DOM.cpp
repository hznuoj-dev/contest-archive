#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int main(){
    int left,right;
    int year,plus;
    int n,cnt;
    cin >> n;
    while(n--){
        cnt = 0;
        cin >> year >> plus;
        if(plus>=0){
            left = year;
            right = year + plus;
        }else{
            left = year + plus;
            right = year;
        }
            
        if(right>9999)
            right = 9999*2 - right;
        
        int temp;
        if(left>right){
            temp = right;
            right = left;
            left = temp;
        }
        for(int i = left ;i<=right;i++){
            if((i % 4 == 0 && i%100 != 0 )||(i%400 == 0))
                cnt ++;
        }
        
        cout << cnt << endl;
    }
    return 0;
}
    

