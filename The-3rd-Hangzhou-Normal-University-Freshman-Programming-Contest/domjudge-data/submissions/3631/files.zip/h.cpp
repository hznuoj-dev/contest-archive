#include<stdio.h>
int main()
{
	int t,n,m;
	double num;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		int x=m;
		int sum=n-m;
		printf("[");
		while(m--) printf("#");
		while(sum--) printf("-");
		printf("]");
		printf(" %d%%\n",x*100/n);
	}
	return 0;
}
