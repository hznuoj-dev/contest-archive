#include <stdio.h>

int main(){
	long long int a,b,c,d;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	int nums = 0;
	int sum = 0;
	while(a > 0){
		int temp = a % 10;
		sum += temp;
		a = a / 10;
	}
	if(sum >= 16 || sum == 6){
		nums++;
	}
	sum = 0;
	
	while(b > 0){
		int temp = b % 10;
		sum += temp;
		b = b / 10;
	}
	if(sum >= 16 || sum == 6){
		nums++;
	
	}
	sum = 0;
	
	while(c > 0){
		int temp = c % 10;
		sum += temp;
		c = c / 10;
	}
	if(sum >= 16 || sum == 6){
		nums++;
	
	}
	sum = 0;
	while(d > 0){
		int temp = d % 10;
		sum += temp;
		d = d / 10;
	}
	if(sum >= 16 || sum == 6){
		nums++;
	}
	
	if(nums == 0){
		printf("Bao Bao is so Zhai......");
	}else if(nums == 1){
		printf("Oh dear!!");
	}else if(nums == 2){
		printf("BaoBao is good!!");
	}else if(nums == 3){
		printf("Bao Bao is a SupEr man///!");
	}else if(nums == 4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
}
