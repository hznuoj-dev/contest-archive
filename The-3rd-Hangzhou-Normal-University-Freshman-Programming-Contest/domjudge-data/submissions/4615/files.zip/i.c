#include<stdio.h>
int main()
{
	int s, n, i, a, b, c, d;
	scanf("%d %d %d %d", &a, &b, &c, &d);
	n = 0;
	s = 0;
	while (a > 0)
	{
		i = a % 10;
		n = n + i;
		a = a / 10;
	}
	if ((n == 6) || (n >= 16))
	{
		s = s + 1;
	}
	n = 0;
	while (b > 0)
	{
		i = b % 10;
		n = n + i;
		b = b / 10;
	}
	if ((n == 6) || (n >= 16))
	{
		s = s + 1;
	}
	n = 0;
	while (c > 0)
	{
		i = c % 10;
		n = n + i;
		c = c / 10;
	}
	if ((n == 6) || (n >= 16))
	{
		s = s + 1;
	}
	n = 0;
	while (d > 0)
	{
		i = d % 10;
		n = n + i;
		d = d / 10;
	}
	if ((n == 6) || (n >= 16))
	{
		s = s + 1;
	}
	if (s == 0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	else if (s == 1)
	{
		printf("Oh dear!!\n");
	}
	else if (s == 2)
	{
		printf("BaoBao is good!!\n");
	}
	else if (s == 3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	else
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	return 0;
}