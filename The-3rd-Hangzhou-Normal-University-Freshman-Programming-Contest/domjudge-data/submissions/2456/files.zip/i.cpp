#include<stdio.h>
#include<string.h>
char ch[20];
int main()
{
	int ans=0,i;
	int time=4;
	while(time--)
	{
		int num=0;
		scanf("%s",ch);
		int len=strlen(ch);
		for(i=0;i<len;i++) if(ch[i]>='0'&&ch[i]<='9') num+=ch[i]-'0';
		if(num>=16||num==6) ans++;
	}
	if(ans==0) printf("Bao Bao is so Zhai......\n");
	else if(ans==1) printf("Oh dear!!\n");
	else if(ans==2) printf("BaoBao is good!!\n");
	else if(ans==3) printf("Bao Bao is a SupEr man///!\n");
	else if(ans==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
