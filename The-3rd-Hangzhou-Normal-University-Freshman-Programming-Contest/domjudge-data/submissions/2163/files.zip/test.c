#include <stdio.h>

int main(){
	int time;
	scanf("%d",&time);
	int years, n;
	
	while(time--){
		int nums =  0;
		scanf("%d %d",&years,&n);
		int result;
		if(years+n > 9999){
			result = 19998-years-n;
		}else{
			result = years+n;
		}
		if(years > result){
			int temp = years;
			years = result;
			result = temp;
		}
		for(int i = years; i <= result; i++){
			if(i % 4 == 0 && i % 100 != 0 || i % 400 == 0){
				nums++;
			}
		}
		printf("%d\n",nums);
	}
}
