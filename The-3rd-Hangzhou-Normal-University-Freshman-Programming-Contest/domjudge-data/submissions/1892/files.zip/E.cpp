#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int main(void) {
    char c[81];
    scanf("%s",&c);
    if(strcmp(c,"kfc")==0){
    	printf(" __      _____\n|  | ___/ ____\\____\n");
    	printf("|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n");
    	printf("|__|_ \\ |__|  \\___  >\n     \\/           \\/");
	}
return 0;
}

