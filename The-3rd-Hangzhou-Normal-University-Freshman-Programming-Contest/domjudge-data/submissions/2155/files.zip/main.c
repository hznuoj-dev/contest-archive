#include <stdio.h>
#include <stdlib.h>

int isLeap(int y);

int main(int argc, char *argv[]) {
	int t, y, a;
	int ymin, ymax, tmp, i, x;
	
	scanf("%d", &t);
	while(t--) {
		x = 0;
		scanf("%d%d", &y, &a);
		tmp = y + a;
		if (tmp > 9999) {
			tmp -= tmp - 9999;
		}
		ymin = y < tmp ? y : tmp;
		ymax = y > tmp ? y : tmp;
		for(i = ymin; i <= ymax; ++i) {
			if(isLeap(i)) {
				++x;
			}
		}
		printf("%d\n", x);
	}
	
	return 0;
}

int isLeap(int y) {
	return ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0);
}
