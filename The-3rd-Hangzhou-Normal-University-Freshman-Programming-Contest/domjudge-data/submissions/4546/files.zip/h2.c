#include<stdio.h>
#pragma warning(disable:4996)
#include<math.h>
#include<string.h>
int main(){
	int t,i,j;
	double m,n,p;
	scanf("%d",&t);
	while(t--){
		scanf("%lf %lf",&n,&m);
		p=(n/m)*100+0.5;
		printf("[");
		for(i=0;i<m;i++){
			printf("#");
		}
		for(i=0;i<n-m;i++){
			printf("-");
		}
		printf("] ");
		printf("%.0lf%%\n",p);
	}
	return 0;
}