#include<stdio.h>
int main(void)
{
int t;
long long int n,m;
double per;
int res;
int i=0,j=0;
scanf("%d",&t);
while(t--)
{
scanf("%lld %lld",&n,&m);
per=m*1.0/n;
res=per*100;
printf("[");
for(i=0;i<m;i++)
printf("#");
for(j=0;j<(n-m);j++)
printf("-");
printf("] %d%%\n",res);
}
return 0;
} 
