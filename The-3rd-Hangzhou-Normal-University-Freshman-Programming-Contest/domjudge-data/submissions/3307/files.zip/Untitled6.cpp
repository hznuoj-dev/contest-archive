
#include<iostream>
#include<cstdio>
#include<cstring>
#include<string>


using namespace std;


char s[1111111];

int r[1111111];
int main(){
	int t, n, i, j, k, l;
	cin >> t;
	while(t--){
		int count=0,f;
		cin >> n;
		for(i=0;i<n;i++){
			f=0;
			scanf("%s",s);
			getchar();
			l=strlen(s);
			for(k=0;k<l;k++){
				if(s[k]!='.'){
					if(f==0){
						r[f]=k;
						f++;
						count++;
					}else{
						int flag=1;
						for(j=0;j<f;j++){
							if(s[k]==s[r[j]]){
								flag=0;
								break;
							}
						}if(flag==1){
							r[f]=k;
							f++;
							count++;
						}
					}
				}
			}
		}
		cout << count << endl;
	}
	return 0;
}
