#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int n,m,i,j;
int a[150],b[150];
int c[500],sum = 0;
int flag[100005]={0};
int ans = 0;
void dfs(int i,int sum,int t){
    
    if(i==n+1){
        if(flag[sum]==0){
            flag[sum] = 1;
            if(sum<=m&&sum>=1){
                //cout << "sum = "<< sum << endl;
                ans ++;
            }
        }
        return;
    }
    dfs(i+1,sum+c[i],t+1);
    dfs(i+1,sum,t);
}
int main(){
    
    cin >> n >> m;
    for(int i =0;i<n;i++)
    cin >> a[i];
    
    for(int i=0;i<n;i++){
    cin >> b[i];
        sum += b[i];
    }
    int cnt = 0;
    for(i =0;i<n;i++){
        for(j=0;j<b[i];j++)
        c[cnt++] = a[i];
    }
    
    dfs(0,0,0);
    cout << ans << endl;
    return 0;
}

