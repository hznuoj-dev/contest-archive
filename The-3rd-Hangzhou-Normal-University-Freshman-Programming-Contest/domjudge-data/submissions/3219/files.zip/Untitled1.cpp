#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	long long a,i,j=2,sum=1,b;
	scanf("%lld",&a);
	if(a<=3)
	{
		for(i=1;i<=a;i++)
		{
			scanf("%lld",&b);
		}
		printf("1");
	}
	else
	{
		scanf("%lld",&b);
		long long d[100000]={0};
		for(i=2;i<=a;i++)
		{
			scanf("%lld",&b);
			d[b]=d[b]+1;
		}
		if(d[3]==0)
		{
			printf("1");
		}
		else
		{	
			while(d[j]!=0)
			{
				sum=sum*d[j];
				j=j+1;
			}
			printf("%lld",sum%998244353);
		}
	}
 } 
