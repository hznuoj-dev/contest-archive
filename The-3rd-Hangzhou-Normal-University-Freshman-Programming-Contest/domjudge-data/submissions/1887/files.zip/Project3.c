﻿#include <stdio.h>
int main() {
    int a, b, c, d, n = 0, sum = 0;
    scanf("%d %d %d %d", &a, &b, &c, &d);
    while (a > 0) {
        sum += (a % 10);
        a /= 10;
    }
    if (sum >= 16 || sum == 6) {
        n++;
    }
    sum = 0;
    while (b > 0) {
        sum += (b % 10);
        b /= 10;
    }
    if (sum >= 16 || sum == 6) {
        n++;
    }
    sum = 0;
    while (c > 0) {
        sum += (c % 10);
        c /= 10;
    }
    if (sum >= 16 || sum == 6) {
        n++;
    }
    sum = 0;
    while (d > 0) {
        sum += (d % 10);
        d /= 10;
    }
    if (sum >= 16 || sum == 6) {
        n++;
    }
    if (n == 4)
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    if (n == 3)
        printf("Bao Bao is a SupEr man//////!");
    if (n == 2)
        printf("BaoBao is good!!");
    if (n == 1)
        printf("Oh dear!!");
    if (n == 0)
        printf("Bao Bao is so Zhai......");
    return 0;
}