#include<string.h>
#include<stdio.h>
int main()
{
	int  i,k=0,num=0;
		char a[20],b[20],c[20],d[20];
	scanf("%s%s%s%s",a,b,c,d);
	int len1=strlen(a),len2=strlen(b),len3=strlen(c),len4=strlen(d);
	for(i=0;i<len1;++i)
	{
		k=k+a[i]-48;
	}
	if(k>=16||k==6)
		num=num+1;
	k=0;
	for(i=0;i<len2;++i)
	{
		k=k+b[i]-48;
	}
	if(k>=16||k==6)
		num=num+1;
	k=0;
	for(i=0;i<len3;++i)
	{
		k=k+c[i]-48;
	}
	if(k>=16||k==6)
		num=num+1;
	k=0;
	for(i=0;i<len4;++i)
	{
		k=k+d[i]-48;
	}
	if(k>=16||k==6)
		num=num+1;
	if(num==0)
		printf("Bao Bao is so Zhai......");
	if(num==1)
		printf("Oh dear!!");
    if(num==2)
			printf("BaoBao is good!!");
	if(num==3)
				printf("Bao Bao is a SupEr man///!");
	if(num==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}