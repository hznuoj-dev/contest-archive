#include<stdio.h>
#include<string.h>
int judge(char *z)//ȷ��ÿ��λ��ӵĺ�
{
	int sum = 0;
	int len = strlen(z);
	int i;
	for (i = 1; i <= len; i++)
	{
		sum += z[i] - '0';
	}
	return sum;
}
int main()
{
	char a[20], b[20], c[20], d[20];
	scanf("%s%s%s%s", &a, &b, &c, &d);
	int x[4];
	int skt = 0;
	x[0] = judge(a); x[1] = judge(b); x[2] = judge(c); x[3] = judge(d);
	for (int i = 0; i < 4; i++)
	{
		if (x[i] >= 16 || x[i] == 6)
			skt++;
	}
	if (skt == 0) printf("Bao Bao is so Zhai......");
	if (skt == 1) printf("Oh dear!!");
	if (skt == 2) printf("BaoBao is good!!");
	if (skt == 3) printf("Bao Bao is a SupEr man///!");
	if (skt == 4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
	return 0;
}
