#include <stdio.h>
#include <stdlib.h>
int main()
{
	long int A=0,B=0,i=0,j=0;
	int T=0;
	double C;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%ld %ld",&A,&B);
		printf("[");
		for(i=1;i<=B;i++)
		{
			printf("#");
		}
		for(j=1;j<=A-B;j++)
		{
			printf("-");
		}
		C=((double)B/(double)A)*100.0;
		printf("] %.3f%%",C);
		if(T!=0)printf("\n");
	}



	return 0;
}
