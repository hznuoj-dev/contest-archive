#include<stdio.h>
#pragma warning(disable:4996)
int a,b,c,d,sum=0,pre=0;
int main()
{
scanf("%d%d%d%d",&a,&b,&c,&d);
while(a!=0)
  {
   sum+=a%10;
   a/=10;
  }
if((sum>=16)||(sum==6))
   {
   pre=pre+1;
   sum=0;
  }
while(b!=0)
  {
   sum+=b%10;
   b/=10;
  }
if((sum>=16)||(sum==6))
   {
   pre=pre+1;
   sum=0;
   }
   while(c!=0)
  {
   sum+=c%10;
   c/=10;
  }
if((sum>=16)||(sum==6))
   {
   pre=pre+1;
   sum=0;
   }
   while(d!=0)
  {
   sum+=d%10;
   d/=10;
  }
if((sum>=16)||(sum==6))
   {
   pre=pre+1;
   }
   	if(pre==1)
   	printf("Oh dear!!");
   	elseif(pre==2)
   	printf("BaoBao is good!!");
   	elseif(pre==3)
   	printf("Bao Bao is a SupEr man///!");
   	elseif(pre==4)
   	pringf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
   	else
   	printf("Bao Bao is so Zhai......");
   	return 0;
	
	
	
	
	
}
