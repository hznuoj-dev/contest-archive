#include<string.h>
#include<stdio.h>


int main()
{
 int sum = 0;
 int he = 0;
 int a;
 for (int k = 1; k <= 4; k++) {
  scanf("%d", &a);
  while (a != 0) {
   he += (a % 10);
   a /= 10;
  }
  if (he >= 16 || he == 6)sum++;
  he = 0;
 }
 if (sum == 0)printf("Bao Bao is so Zhai......");
 else if (sum == 1)printf("Oh dear!!");
 else if (sum == 2)printf("BaoBao is good!!");
 else if (sum == 3)printf("Bao Bao is a SupEr man///!");
 else if (sum == 4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
 

 return 0;
}
