#include<stdio.h>
#include<math.h>
int main(){
    int t,a,b,c,m;
    scanf("%d",&t);
    while(t--){
    	m=0;
    	scanf("%d %d",&a,&b);
    	c=a+b;
    	if (c>9999)
    	c=9999-(a+b-9999);
    	if(a>c){
    		for(int i=c;i<=a;i++){
    			if(i%4==0&&i%100!=0||i%400==0){
    				m++;
				}
			}
		}
		else{
			for(int i=a;i<=c;i++){
    			if(i%4==0&&i%100!=0||i%400==0){
    				m++;
				}
			}
		}
		if(m>2424)
		m=2424;
		printf("%d\n",m);
	}
}
