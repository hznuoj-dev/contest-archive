#include<stdio.h>
#include<string.h>
#define maxn 1000005

int letter[2000];

int main()
{
	int t,n,i;
	scanf("%d",&t);
	while(t--)
	{
		int num=0; 
		scanf("%d",&n);
		while(n--)
		{
			int ans=0;
			memset(letter,0,sizeof(letter));
			char str[maxn]={};
			scanf("%s",str);
			int len=strlen(str);
			for(int i=0;i<len;i++) if(str[i]!='.') letter[str[i]]++;
			for(int i=0;i<len;i++) 
			if(letter[str[i]])
			{
				letter[str[i]]=0;
				ans++;
			}
			num+=ans;
		}
		printf("%d\n",num);
	}
	return 0;
}
