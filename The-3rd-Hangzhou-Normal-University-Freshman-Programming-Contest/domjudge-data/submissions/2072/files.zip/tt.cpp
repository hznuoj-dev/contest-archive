#include <bits/stdc++.h>

using namespace std;

int num(int x) {
    int t = 0;
    while (x) {
        t += x % 10;
        x /= 10;
    }
    return t;
}

int main() {
    int x, c = 0;
    for (int i = 1; i <= 4; i++) {
        cin >> x;
        if (num(x) >= 16 || num(x) == 6)c++;
    }
    switch (c) {
        case 0:
            printf("Bao Bao is so Zhai......");
            break;
        case 1:
            printf("Oh dear!!");
            break;
        case 2:
            printf("BaoBao is good!!");
            break;
        case 3:
            printf("Bao Bao is a SupEr man///!");
            break;
        case 4:
            printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
            break;
    }
    return 0;
}