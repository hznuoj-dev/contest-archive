#include<stdio.h>
int main()
{
	long long A,B,C,D;
	int flog=0,i,a=0,b=0;
    scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
    
    for(i=1;A!=0;i++)
    {
    	a=A%10;
    	A=A/10;
    
        b+=a;
	}
	if(b>=16||b==6){flog=flog+1;} 

	a=b=0;
	    for(i=1;B!=0;i++)
    {
    	a=B%10;
    	B=B/10;
    
        b+=a;
	}
	if(b>=16||b==6){flog=flog+1;} 

		a=b=0;
	    for(i=1;C!=0;i++)
    {
    	a=C%10;
    	C=C/10;
    
        b+=a;
	}
	if(b>=16||b==6)
	{
	flog=flog+1;
	}

		a=b=0;
	    for(i=1;D!=0;i++)
    {
    	a=D%10;
    	D=D/10;
    
        b+=a;
	}
	if(b>=16||b==6){flog=flog+1;} 

 if(flog==0)printf("Bao Bao is so Zhai......");
 else if(flog==1)printf("Oh dear!!");
  else if(flog==2)printf("BaoBao is good!!");
   else if(flog==3)printf("Bao Bao is a SupEr man///!");
    else printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
 
	

	
	return 0;
}
