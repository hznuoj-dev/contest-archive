#include"stdio.h"
int main()
{
	int a;
	if(scanf("%d",&a))
	{
		while(a--){
			int b,c,i;
			if(scanf("%d%d",&b,&c)){
			printf("[");
			for(i=1;i<=c;++i)
			printf("#");
			for(i=1;i<=b-c;++i)
			printf("-");
			printf("]");
			printf(" ");
			double d;
			d=c*1.0000/b*100;
			printf("%.0f%%\n",d);
			}
		}
	}
	return 0;
 } 
