#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#define STRING_LENGTH 80
char str[STRING_LENGTH + 1];
int readString(char str[STRING_LENGTH + 1]) {
	int ch, i,b=0,  j, c = 0, d = 0, sum = 0;
	while ((ch = getchar()) != '\n') {
		for (i = 0; i < STRING_LENGTH; i++) {
			str[i] = ch;
			b++;
		}
	}
		for (i = 0; i < b; i++) {
			if (str[i] != '.')
				for (j = 0; j < i; j++) {
					if (str[i] != str[j])
						c = 0;
					d = d + c;
				}
			if (d == 0)
				sum++;
		}
		return sum;
}
int main(void) {
	int T, s = 0, n,count=0;
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		while (n--) {
			count = readString(str);
			s = s + count;
		}
		printf("%d\n", count);
		count = 0;
	}
}
	