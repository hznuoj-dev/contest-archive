#include <stdio.h>

int main(void)
{
	int T, n, m, i;
	
	scanf("%d", &T);
	while(T--)
	{
		scanf("%d%d", &n, &m);
		printf("[");
		for(i = 1; i <= n; ++i)
		{
			if(i <= m)
				printf("#");
			else
				printf("-");
		}
		m = 100.0 * m / n;
		printf("] %d%%\n", m);
	}
	
	return 0;
}
