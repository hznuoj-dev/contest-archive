#include<stdio.h>
int is(int n){
	if(n%400==0||n%4==0&&n%100!=0)
	    return 1;
	return 0;
}
int main()
{
	int T,a,b,t;
	int hight,low;
	scanf("%d",&T);
	while(T--){
		int count=0;
		scanf("%d%d",&a,&b);
		if(a+b>=10000){
			hight=9998;
			low=a;
		}
		else{
			hight=a+b;
			low=a;
		}
		if(hight<low){
			t=hight;
			hight=low;
			low=t;
		}
		for(int i=low;i<=hight;i++){
			if(is(i))   count++;
		}
		printf("%d\n",count);
	}
	return 0;
 } 
