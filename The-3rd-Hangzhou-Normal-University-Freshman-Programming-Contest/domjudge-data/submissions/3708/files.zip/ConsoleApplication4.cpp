﻿#include<stdio.h>
#include<string.h>
int main() {
	int t, n, m, we;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &n, &m);
		printf("[");
		for (int i = 1; i <= m; i++) {
			printf("#");
		}
		for (int i = 1; i <= n - m; i++) {
			printf("-");
		}
		printf("]");
		we = m * 100 / n;
		printf(" %d%%\n", we);
	}
}
