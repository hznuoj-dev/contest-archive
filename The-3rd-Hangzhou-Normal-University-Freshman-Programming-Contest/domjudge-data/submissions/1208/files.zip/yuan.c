#include<stdio.h>
#include<stdlib.h>
#include<math.h>
/*include<algorithm>
using namespace std;*/
#include<string.h>
int main (){
	int n, t, i;
	char a[10];
	scanf("%s",a);
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/\n");
	return 0;
}