//
//  main.cpp
//  c++_02
//
//  Created by 李尚鑫 on 2020/12/7.
//
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
using namespace std;

int main () {
    int t;
    cin >> t;
    while (t--) {
        double x,y;
        cin >> x >> y;
        double buf = y/x;
        cout << "[";
        for (int i=0; i<y; i++) cout << "#";
        for (int i=0; i<x-y; i++) cout << "-";
        cout << "]";
        buf*=100;
        if ((buf/10)>=5) buf-=1;
        printf("%.0f%%\n",buf);
    }
}
