#include<iostream>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
const int mod=998244353;
const int maxn=1e5+10;
int a[maxn];
int main(){
	fcio;
	int n;
	while(cin>>n){
		for(int i=1;i<=n;++i){
			cin>>a[i];
		}
		int last=1;
		int now=1;
		int ans=0;
		for(int i=2;i<=n;++i){
			if(a[i]==a[i+1]){
				now++;
			}
			else{
				if(last==1){
					ans+=1;
					continue;
				}
				ans=(ans%mod+((last%mod)*(now%mod))%mod)%mod;
				last=now;
				now=1;
			}
		}
//		if(a[n]==a[n-1]){
//			ans=(ans%mod+((last%mod)*(now%mod))%mod)%mod;
//		}
		cout<<ans%mod<<endl;
	}
}

