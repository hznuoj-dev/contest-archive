#include<bits/stdc++.h>
using namespace std;

long long mix(int x,int y){
    long long res = 1,a = y;
    while(x){
        if(x & 1) res = res * a % 998244353;
        a = a * a % 998244353;
        x >>= 1;
    }
    return res;
}

int main(void){

    int n,i = 0,max = 0;
    long long sum = 1;
    cin >> n;
    int num[n + 1];
    memset(num,0,sizeof(num));
    while(++i <= n){
        int now;
        cin >> now;
        if(now > max) max = now;
        num[now]++;
    }
    for(i = 2;i <= n;i++){
        sum = (sum * mix(num[i],num[i-1])) % 998244353;
    }
    cout << sum;

    return 0;
}