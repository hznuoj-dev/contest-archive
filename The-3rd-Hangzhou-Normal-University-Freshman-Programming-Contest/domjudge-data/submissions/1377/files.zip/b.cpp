#include<stdio.h>
int main(){
	int t,start,end,a,k,s,i;
	scanf("%d",&t); 
	while(t--){
		scanf("%d %d",&start,&a);
		end=(start+a)<=9999?start+a:9999-(start+a-9999);
		if(start>end){
			s=start,start=end,end=s;
		}
		k=0;
		for(i=start;i<=end;i++){
			if((i%4==0&&i%100!=0)||i%400==0){
				k=k+1;
			}
		}
		printf("%d\n",k);
	}
} 
