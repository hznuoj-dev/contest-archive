#include<stdio.h>
int main(void){
	double t,n,m;
	int i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%lf %lf",&n,&m);
		for(i=0;i<n+3;i++){
			if(i==0)
			printf("[");
			else if(i<=m)
			printf("#");
			else if(i>m&&i<=n)
			printf("-");
			else if(i==n+1)
			printf("]");
			else if(i==n+2)
			printf(" %0.lf%%\n",m/n*100);
		}
	}return 0;
}
