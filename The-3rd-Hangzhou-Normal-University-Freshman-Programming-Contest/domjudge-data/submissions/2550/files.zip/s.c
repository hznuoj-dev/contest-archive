#include<stdio.h>
int main(){
	int T,i=0,a,b,c,d,x=0;
	scanf("%d",&T);
	for(i=0;i<=T;i++){
	scanf("%d %d",&a,&b);
	if(b<0){
		d=b;
		b=a;
		a=a+d;
	}
	else if(a+b>9999){
	b=a+b-9999;
	}
	else
		b=a+b;
	c=a;
	for(c=a;c<=b;c++){
		if(c%4==0&&c%100!=0||c%400==0)
			x=x+1;
	
	
	}
	
	printf("%d\n",x);
	x=0;
	}

	
return 0;
}