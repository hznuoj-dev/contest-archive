#include<bits/stdc++.h>
using namespace std;
#define ll long long


int main(void){
	ll n;
	cin>>n;
	while(n--){
		int a,b;
		cin>>a>>b;
		cout<<"[";
		for(int k=0;k<b;k++)
			cout<<"#";
		for(int k=0;k<a-b;k++)
			cout<<"-";
		cout<<"] ";

		printf("%d",b*100/a);
		cout<<"%";
		if(n>0)
			cout<<endl;
		
	}
}

