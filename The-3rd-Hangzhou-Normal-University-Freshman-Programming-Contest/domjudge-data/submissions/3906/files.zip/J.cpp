#include<stdio.h>
#include<string.h>
int main(){
	int T,n,f=-1,l,i,j;
	int sum=0;
	char str[1000000];
	scanf("%d",&T);
	while(T--){
		f = -1,sum=0;
		scanf("%d",&n);
		while(n--){
			scanf("%s",str);
			l =strlen(str);
			for(j=0;j<l;++j){
				f = -1;
				if(str[j]!='.'){
					f = 0;
					for(i=0;i<j;i++){
						if(str[j]==str[i])
							f = -1;
					}
				}
				if(f!=-1)
			   		sum += 1;
			}
		
		}
		printf("%d\n",sum);
	}
	return 0;
}



