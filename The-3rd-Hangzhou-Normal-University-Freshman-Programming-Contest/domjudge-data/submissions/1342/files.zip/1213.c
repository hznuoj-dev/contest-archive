#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int n,i,a,c,b,max,min,sum,j;
    scanf("%d",&n);
    for(j=0;j<n;++j){
    	sum=0;
    	scanf("%d%d",&a,&b);
    	c=a+b;
    	if(c>9999)
    	c=9999-(c-9999);
    	if(a>c){
    		max=a;
    		min=c;
		}
		else{
			max=c;
			min=a;
		}
		for(i=min;i<=max;++i){
			if(((i%4==0)&&(i%100!=0))||(i%400==0))
			sum++;
		}
		printf("%d\n",sum);
	}
	return 0;
}
