#include<stdio.h>
int main(void){
	int n;
	double a,b;
	scanf("%d",&n);
	while(n--){
		scanf("%lf%lf",&a,&b);
		printf("[");
		for(int i=1;i<=a;i++){
			if(i<=b){printf("#");}
			else{printf("-");}
		}
		printf("] %.0f",100*b/a);
		printf("%%\n");
	}
}
