#include<stdio.h>
#include<string.h>
int main()
{
	long long n,m,len,i,j,t=0,sum=0,flag=1;
	char a[99999];
	scanf("%lld",&n);
	while(n--)
	{
		scanf("%lld",&m);
		while(m--)
		{
			scanf("%s",a);
			len=strlen(a);
			for(i=0;i<len;i++)
			{
				flag=1;
				if(i==0)
				{if(a[i]!='.')
				t++;
				}
				else//i>1
				{  for(j=0;j<i&&flag;j++)//���� 
				    {
					if(a[i]!=a[j]&&a[i]!='.')
					flag=1;
					else
					flag=0;
				    }
				    if(flag!=0)
				    t++;
			    }
			}
			sum+=t;
			t=0;
		}
		printf("%lld\n",sum);
		sum=0;
	}
	return 0;
}
