#include<stdio.h>
int main(){
	char y[3];
	scanf("%s",&y[3]);
	printf(" __      _____       \n");    
	printf("|  | ___/ ____\\____  \n");
	printf("|  |/ /\\   __\\/ ___\\ \n");
	printf("|    <  |  | \\  \\___ \n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/ \n");
	return 0;
}
