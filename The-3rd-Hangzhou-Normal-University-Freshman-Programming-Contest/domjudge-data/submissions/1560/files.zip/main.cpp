//
//  main.cpp
//  c++_02
//
//  Created by 李尚鑫 on 2020/12/7.
//
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
using namespace std;
const int N = 20;
char buf[N];
int main () {
    int cnt = 0;
    for (int i=0; i<4; i++) {
        scanf("%s",buf);
        vector <int> vec;
        for (int j=0; j<strlen(buf); j++) {
            int tmp = buf[j] - '0';
            vec.push_back(tmp);
        }
        int sum = 0;
        for (auto k : vec) {
            sum += k;
        }
        if (sum>=16 || sum==6) cnt++;
    }
    
    if (cnt==0) cout << "Bao Bao is so Zhai......" << endl;
    if (cnt==1) cout << "Oh dear!!" << endl;
    if (cnt==2) cout << "BaoBao is good!!" << endl;
    if (cnt==3) cout << "Bao Bao is a SupEr man///!" << endl;
    if (cnt==4) cout << "“Oh my God!!!!!!!!!!!!!!!!!!!!!" << endl;
    
}
