#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int T;
	int n,m,i;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
		printf("#");
		for(i=m-n;i<=m-1;i++)
		printf("-");
		printf("] %.0lf", (m/(n*1.0))*100);
		puts("%");
			}
		
	return 0;
}
