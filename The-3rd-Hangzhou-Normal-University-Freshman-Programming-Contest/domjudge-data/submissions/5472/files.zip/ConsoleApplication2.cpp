﻿#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include <cstring>
#include<math.h>
#include<stdlib.h>
#include <time.h>
#include<iostream>
#include<limits.h>
#include<algorithm>
#include<queue>
#include<stack>
#include <map>
#include<set>
#include<cstdio>
#define RE0 return 0;
#define print printf
using namespace std;

typedef struct stu
{
	int number;
	char name[15];
	int location;
	double w;
}  STU;

int cmp(const void* p, const void* q)
{
	int pa = *((int*)p);
	int qa = *((int*)q);
	return qa - pa;
}

int constructcmp(const void* p, const void* q)
{
	return ((STU*)q)->number - ((STU*)p)->number;
}

int rn[10005];

void judge()
{
	int i;
	for (i = 1; i <= 9999; ++i)
	{
		if (i % 400 == 0 || (i % 4 == 0 && i % 100 != 0))
		{
			rn[i] = 1;
		}
		else
		{
			rn[i] = 0;
		}
	}
}

int main()
{
	int n, i, start, year, x, y, end, t, j;
	scanf("%d", &n);
	judge();
	for (i = 0; i < n; ++i)
	{
		scanf("%d %d", &start, &year);
		x = start + year;
		if (x >= 10000)
		{
			y = x - 9999;
			end = 9999 - y;
		}
		else
		{
			end = x;
		}
		if (end < start)
		{
			t = end;
			end = start;
			start = t;
		}
		int sum = 0;
		for (j = start; j <= end; ++j)
		{
			sum += rn[j];
		}
		printf("%d\n", sum);
	}
	RE0
}