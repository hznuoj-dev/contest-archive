#include<stdio.h>
int main(){
	int t,y,a;
	int m=0,x;
	int y2;
	scanf("%d",&t);
	while(t--){
		x=0;
		scanf("%d %d",&y,&a);
		m=y+a;
		if(m<0) break;
		if(m>9999){
			y2=9999-(m-9999);
			if(y>=y2){
				for(int i=y2;i<=y;i++){
					if((i%4==0&&i%100!=0)||i%400==0){
						x=x+1;
					}
				}
			}
			else{
				for(int i=y;i<=y2;i++){
					if((i%4==0&&i%100!=0)||i%400==0){
						x=x+1;
						}
				}
			}
		} 
	    else {
		if(m>=y){
			for(int i=y;i<=m;i++){
				if((i%4==0&&i%100!=0)||i%400==0){
					x=x+1;
					}
			}
		}
		else{
			for(int i=m;i<=y;i++){
				if((i%4==0&&i%100!=0)||i%400==0){
						x=x+1;
					}
			}
		}
	}
	printf("%d\n",x);
 } 
 return 0;
}
