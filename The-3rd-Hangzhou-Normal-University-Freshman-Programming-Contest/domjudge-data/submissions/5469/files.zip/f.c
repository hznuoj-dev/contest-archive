#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#pragma warning(disable:4996);
int main(){
	int n,m,i,z,sum=0,j,t=50000,s=0;
	int *p,*q,*w;
	int a[101]={0};
	scanf("%d %d",&n,&m);
	p=(int *)malloc((m+1)*sizeof(int));
	q=(int *)malloc((m+1)*sizeof(int));
	w=(int *)malloc((m+1)*sizeof(int));
	for(i=0;i<m;i++){
	   p[i]=q[i]=w[i]=0;
	}
	for(i=0;i<n;i++){
	    scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
	    scanf("%d",&z);
		p[a[i]]=z;
	}
	for(i=0;i<m;i++){
	   if(p[i]!=0){
		   q[i]==1;
	   }
	   w[i]=p[i];
	}
	while(t--){
		for(i=0;i<m;i++){
		   if(q[i]!=0)continue;
		   for(j=0;j<i;j++){
			   if(j<=a[j]){
			   if(p[i-a[j]]!=0){
			      q[i]=1;
				  p[i]=1;
				  p[a[j]]--;
				  p[i-a[j]]--;
			   }
			   }
		   }
		}
		for(i=0;i<m;i++){
		   p[i]=w[i];
		}
	}
	
	for(i=0;i<m;i++){
		
	   if(q[i]!=0)sum++;
	}
	printf("%d",sum);
    free(p);
	free(q);
	free(w);
    return 0;
}