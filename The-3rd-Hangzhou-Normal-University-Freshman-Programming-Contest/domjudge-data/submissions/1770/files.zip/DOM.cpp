#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int main(){
    char ch;
    int temp,ans,sum;
    ans = sum = 0;
    ch = getchar();
    while(ch!='\n'){
        if(ch==' '){
            if(sum>=16||sum==6)
                ans ++;
            sum = 0;
        }else{
            temp = ch - '0';
            sum += temp;
        }
        ch = getchar();
    }
    switch(ans){
        case 1:
            cout << "Oh dear!!" << endl;
            break;
        case 2:
            cout << "BaoBao is good!!" << endl;
            break;
        case 3:
            cout << "Bao Bao is a SupEr man///!" << endl;
            break;
        case 4:
            cout << "Oh my God!!!!!!!!!!!!!!!!!!!!!" << endl;
            break;
        default:
            cout << "Bao Bao is so Zhai......" << endl;
            break;
    }
    return 0;
}
    

