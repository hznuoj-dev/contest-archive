#include<stdio.h>
int main(void){
	int t,a,b,n;
	scanf("%d",&t);
	while(t--){
		n=0;
	    scanf("%d%d",&a,&b);
	    if(a+b>9999){b=9999-(a+b-9999);}
	    else{b=a+b;}
	    if(a>b){
	    	a=a+b;
	    	b=a-b;
	    	a=a-b;
		}
	    for(int i=a;i<=b;i++){
	    	if((i%4==0&&i%100!=0)||i%400==0){
	    		n++;
			}
		}
		printf("%d\n",n);
    }
}
