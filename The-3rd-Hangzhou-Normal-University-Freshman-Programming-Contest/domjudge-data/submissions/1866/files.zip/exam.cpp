#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int T,i,a,b,add;
	scanf("%d",&T);
	while(T--)
	{
		int sum=0;
		scanf("%d %d",&a,&add);
		b=a+add;
		if(b>9999) b=9999-(b-9999);
		if(b<a)
		{
			for(i=b;i<=a;i++)
			{
				if(i%4==0&&i%100!=0||i%400==0) sum++;
			}
		}
		else
		{
			for(i=a;i<=b;i++)
			{
				if(i%4==0&&i%100!=0||i%400==0) sum++;
			}
		}
		printf("%d\n",sum);
	}
}
