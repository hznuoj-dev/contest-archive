#include<stdio.h>
int main(void){
	int nm[100000];
	int mm[100000];
	int num=0;
	int s=0;
	int b=0;
	int a=0,i;
	scanf("%d",&a);
	for(i=0;i<a;i++){
		scanf("%d%d",&nm[i],&mm[i]);
	}
	for(i=0;i<a;i++){
		num=0;
		s=nm[i]+mm[i];
		if (s>9999){
			mm[i]=9999-(s-9999);
		}
		else{
			mm[i]=s;
		}
		if(nm[i]>mm[i]){
			b=nm[i];
			nm[i]=mm[i];
			mm[i]=b;
		}
		for(s=nm[i];s<=mm[i];s++){
			if( ((0 == s%4)&&(0 != s%100)) ||(0 == s %400) ){
				num++;	
			}
		}
		printf("%d\n",num);
			 
	} 
}
