 #include <set>
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <cmath>
#include <ctime>
#include <bitset>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const int maxn = 1e5 + 10;
const int mod = 0;
const int inf = 0x3f3f3f3f;
int vis[1010][1010];

int gcd(int a, int b) 
{
	return b==0?a:gcd(b,a%b);
}
int check(int a){
	int sum=0;
	while(a)
	{
		sum+=a%10;
		a/=10;
	}
	return sum;
}
int main()
{
int p;
int ans=0;
for(int i=1;i<=4;i++)
{
	cin>>p;
	if(check(p)>=16||check(p)==6)ans++;}
if(ans==0)cout<<"Bao Bao is so Zhai......";
else if(ans==1)cout<<"Oh dear!!";
else if(ans==2)cout<<"BaoBao is good!!";
else if(ans==3)cout<<"Bao Bao is a SupEr man///!";
else if(ans==4)cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";


	return 0;
}
