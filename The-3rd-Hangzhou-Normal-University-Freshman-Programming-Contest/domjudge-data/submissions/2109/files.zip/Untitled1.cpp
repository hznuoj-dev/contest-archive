#include <stdio.h>
#include <string.h>
int judge(char *p,int j);
int main()
{
	char a[20],b[20],c[20],d[20];
	scanf("%c %c %c %c",&a,&b,&c,&d);
	int m=0;
	m+=judge(a,strlen(a));
	m+=judge(b,strlen(b));
	m+=judge(c,strlen(c));
	m+=judge(d,strlen(d));
	if(m==1)
	printf("Oh dear!!");
	else if(m==2)
	printf("BaoBao is good!!");
	else if(m==3)
	printf("Bao Bao is a SupEr man///!");
	else if(m==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(m==0)
	printf("Bao Bao is so Zhai......");
}
int judge(char *p,int j){
	int n;
	for(;p<p+n;p++)
	n+=(*p-'0');
	if(n>=16||n==6)
	return 1;
	else
	return 0;
}
