#include<cstdio>
#include<set>

using namespace std;

int s[10001][10001]={0};
int n,m,k;

void px(int j);

 multiset<int>a;

 int main()
{
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        scanf("%d",&m);
        for(int t=0;t<m;t++)
        {
            scanf("%d",&s[i][t]);
        }
    }
    int q,l;
    scanf("%d",&q);
    while(q>0)
    {
        scanf("%d",&l);
        px(l);
        q--;
    }
    return 0;
}

void px(int j)
{
    while(j>0)
    {
    int z,x,t;
    scanf("%d",&z);
    for(x=0;x<1000001;x++)
    {
    if(s[z-1][x]==0)break;
    a.insert(s[z-1][x]);
    }
    j--;
    }
    scanf("%d",&k);
    int js=1;
    for(multiset<int>::iterator i =a.begin();i!=a.end();i++)
    {
        if(js==k)
        {
        printf("%d\n",*i);
        break;
        }
        js++;
    }
    a.clear();
    return;
}
