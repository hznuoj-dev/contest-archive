/*#include<stdio.h>
int check(int y1,int y2);
int main()
{
    int t;
    int y,a,num;
    scanf("%d\n",&t);
    while(t--)
    {
        scanf("%d %d\n",&y,&a);
        if((y+a)<=9999&&(a>=0)){
            num=check(y,y+a);
        }
        else if((y+a)>9999){
            num=check(y,9999-(y+a-9999));
        }
        else if((y+a)<9999&&(a<0)){
            num=check(y+a,y);
        }
        printf("%d\n",num);
    }
}
int check(int y1,int y2)
{
    int num=0,i;
    for(i=y1;i<=y2;i++)
    {
        if((i%4==0&&i%100!=0)||(i%400==0))num++;
    }
    return num;
}
*/
/*#include<stdio.h>
int main()
{
    int n,price[100],num[100],i,kind=0;
    long m;
    scanf("%d %ld\n",&n,&m);
    for(i=0;i<n;i++){scanf("%d",&price[i]);}
    for(i=0;i<n;i++){scanf("%d",&num[i]);}
    
}
*/
#include<stdio.h>
int check(long long a);
int main()
{
    long long a,b,c,d;
    int num=0;
    scanf("%lld%lld%lld%lld\n",&a,&b,&c,&d);
    if(check(a)==1)num++;
    if(check(b)==1)num++;
    if(check(c)==1)num++;
    if(check(d)==1)num++;
    if(num==1)printf("Oh dear!!\n");
    if(num==2)printf("BaoBao is good!!\n");
    if(num==3)printf("Bao Bao is a SupEr man///!\n");
    if(num==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
    if(num==0)printf("Bao Bao is so Zhai......\n");
}
int check(long long a)
{
    long long x,sum=0;
    int flag=0;
    for(x=a;x>=1;x/=10)
    {
        sum+=x%10;
    }
    if(sum>=16||sum==6)flag=1;
    return flag;
}
