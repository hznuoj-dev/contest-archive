import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner((System.in));
        while (in.hasNext())
        {
            int n = in.nextInt();
            for (int i = 1; i <= n; i++)
            {
                double a = in.nextInt();
                double b = in.nextInt();
                System.out.print("[");
                StringBuilder c = new StringBuilder();
                for (int j = 1; j <= a; j++)
                {
                    if (j <= b)
                        c.append("#");
                    else
                        c.append("-");
                }
                System.out.print(c + "]");
                double d = b / a * 100;
                int f = (int) d;
                System.out.println(" " + f + "%");
            }
        }
    }
}