package ����;

import java.util.Scanner;

public class B
{

	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		while(in.hasNext())
		{
			
			int p=in.nextInt();
			
			for (int i = 0; i <p; i++)
			{
				int a=in.nextInt();
				int b=in.nextInt();
				
				int g=0;
				int x=0;
				if (a+b>=10000)
				{
					 x=a+b-9999;
					 g=9999-x;
				}else {
					g=a+b;
				}
				int xx=0;
				if (a>g)
				{
					xx=g+a;
					g=a;
					a=xx-g;
				}
				
				int sum=0;
				for (int j = a; j <=g; j++)
				{
					if ((j%4==0&&j%100!=0)||(j%400==0))
					{
						sum++;
					}
				}
				System.out.println(sum);
				
			}
		}
	}

}
