#include<stdio.h>
#include<math.h>
int main(){
	int t,i;
	float a,b,ans=0.0;
	scanf("%d",&t);
	while(t--){
		scanf("%f %f",&a,&b);
		printf("[");
		for(i=0;i<b;i++){
			printf("#");
		}
		for(i=0;i<a-b;i++){
			printf("-");
		}
		printf("] ");
		ans=b/a;
		int c;
		c=floor (ans*100);
		printf("%d%%\n",c);
	}
}
