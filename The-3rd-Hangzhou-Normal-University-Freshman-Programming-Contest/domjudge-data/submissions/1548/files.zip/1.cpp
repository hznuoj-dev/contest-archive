#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)
#define ll long long

using namespace std;

string s;

int main()
{
//	fcin;
	int t;
	int n;
	cin>>t;
	while(t--)
	{
		int res=0;
		
		cin>>n;
		for(int k=0;k<n;k++)
		{
			set<char>st;
			cin>>s;
			for(int i=0;i<s.size();i++)
			{
				if(s[i]!='.') st.insert(s[i]);
			}
			res+=st.size();
		}
		cout<<res<<endl;
	}
	
}

