#include<stdio.h>
#pragma warning(disable:4996)
int main(){
char a;
scanf("%c",&a);
printf(" --      -----      \n"
	   "|  | ___/ ____\____ \n"
	   "|  |/ /\   __\/ ___\\  \n"
	   "|   <  |  | \ \___ \n "
	   "|__|_ \ |__|  \___  >\n"
       "     \\/           \\/");

return 0;
}