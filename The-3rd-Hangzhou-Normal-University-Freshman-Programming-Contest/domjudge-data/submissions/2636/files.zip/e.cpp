#include <stdio.h>
#include <math.h>
int main (){
	char a[100];
	gets(a);
	printf(" --      -----      \n");
	printf("|  | ___/ ____\\___ \n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/ \n");
	return 0;
}/*
__ _____
| | ___/ ____\\____
| |/ /\\ __\\/ ___\\
| < | | \\ \\___
|__|_ \\ |__| \\___ >
\\/ \\/
*/

