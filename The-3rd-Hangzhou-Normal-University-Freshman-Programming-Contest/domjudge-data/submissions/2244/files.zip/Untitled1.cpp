

#include<stdio.h>
#include<math.h>
#include <stdlib.h>
int main()
{
	int a[4],i;
	for(i=0;i<3;i++)
	{
		scanf("%c",&a[i]);
	}
	if(a[0]=='k'&&a[1]=='f'&&a[2]=='c')
	{
	printf(" __      _____");
	printf("\n");
	printf("|  | ___/ ____\\____");
	printf("\n");
	printf("|  |/ /\\   __\\/ ___\\");
	printf("\n");
	printf("|    <  |  |  \\  \\___");
	printf("\n");
	printf("|__|_ \\ |__|   \\___  >");
	printf("\n");
	printf("    \\/             \\/");
	}
	printf("\n");
}
