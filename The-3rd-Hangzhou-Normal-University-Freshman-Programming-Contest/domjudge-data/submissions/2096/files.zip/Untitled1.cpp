#include <cstdio>
#include <iostream>
#include <cstring> 
#include <map>
#include <vector>
#include <algorithm>
#include <queue>
#include <functional>
using namespace std;
const int N = 1e6 + 10;
int n, m, num_edge, sum;
int ans[N], head[N], indegree[N]; 
struct Edge{
	int next, to;
}edge[N];
void add_edge(int from, int to) {
	edge[num_edge].next = head[from];
	edge[num_edge].to = to;
	head[from] = num_edge++;
}
void init() {
	num_edge = sum = 0;
	memset(head, -1, sizeof head);
	memset(indegree, 0, sizeof indegree);
}
void topo() {
	priority_queue<int, vector<int>, greater<int> >q;
	for (int i = 1; i <= n; i++) {
		if (indegree[i] == 0) {      
			--indegree[i];                                                             
			q.push(i);
		}
	}
	while (!q.empty()) {
		int u = q.top();
		q.pop();
		ans[++sum] = u;
		for (int i = head[u]; i != -1; i = edge[i].next) {
			int v = edge[i].to;
			--indegree[v];
			if (indegree[v] == 0) {
				--indegree[v];
				q.push(v);
			}
		}
	}
	for (int i = 1; i <= sum; i++) {
		printf("%d", ans[i]);
		printf(i == sum? "\n" : " ");
	} 
}
int main () {
	int T;
	scanf("%d", &T);
	while (T--) {
		init();
		scanf("%d%d", &n, &m);
		for (int i = 1; i <= m; i++) {
			int u, v;
			scanf("%d%d", &u, &v);
			add_edge(u, v);
			++indegree[v];
		}
		topo(); 
	}
	return 0;
}
