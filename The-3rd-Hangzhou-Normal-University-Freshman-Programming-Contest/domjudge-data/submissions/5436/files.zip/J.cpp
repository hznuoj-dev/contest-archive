#include<stdio.h>
#include<math.h>
#include<string.h>
char a[1000000],b[11][100][100];
int main()
{
	int t,n,s,m;
	scanf("%d",&t);
	for(int k=0;k<t;++k)
	{
		m=0;
		scanf("%d",&n);
		for(int i=0;i<=n;++i)
		{
			gets(a);
			s=0;
			for(int j=0;j<strlen(a);++j)
			{
				if(a[j]!='.')
				{
					int f=1;
					for(int y=0;y<strlen(b[k][i]);++y)
					{
						if(a[j]==b[k][i][y]){
							f=0;
							break;
						}
					}
					if(f==1)
						s++;
				}
			}
			m+=s;
		}
		printf("%d\n",m);	
	} 
	return 0;
} 
