#include <iostream>
using namespace std;

int daisuke(int l, int h)
{
    int count = 0;
    for (int i = l; i <= h; i++)
    {
        if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
        {
            count++;
        }
    }
    return count;
}

int main()
{
    int t;
    cin >> t;
    for (int i = 1; i <= t; i++)
    {
        int l, h, delta;
        cin >> l >> h;
        delta = l + h;
        if (l + h > 9999)
        {
            delta = 9999 - (delta - 9999);
        }
        else if (h < 0)
        {
            int temp = l;
            l = delta;
            delta = temp;
        }
        if (delta < l)
        {
            int temp = l;
            l = delta;
            delta = temp;
        }
        cout << daisuke(l, delta) << endl;
    }
    system("pause");
    return 0;
}