#include<stdio.h>
int main(){
	int view[4];
	char time0[100]={ "Bao Bao is so Zhai......"};
	char time1[100]={"Oh dear!!"};
	char time2[100]={"BaoBao is good!!"};
	char time3[100]={"Bao Bao is a SupEr man///!"};
	char time4[100]={"Oh my God!!!!!!!!!!!!!!!!!!!!!"};
	int i,j,n,k=0;
	int count=0;
    for(i=0;i<4;i++){
    	scanf("%d",&view[i]);
	}
	for(i=0;i<4;i++){
	while(view[i]>0){
		k=k+view[i]%10;
		view[i]=view[i]/10;
	}
	if(k>=16||k==6){
		count=count+1;
	}
	k=0;
}
    if(count==0)
    printf("%s",time0);
    else if(count==1)
    printf("%s",time1);
    else if(count==2)
    printf("%s",time2);
    else if(count==3)
    printf("%s",time3);
    else if(count==4)
    printf("%s",time4);
}
