#include<bits/stdc++.h>
using namespace std;
int run(int x){
	if((x%4==0 && x%100!=0) || x%400==0)return 1;//yes
	return 0;
}
int main(){
	int T;
	cin >> T;
	while(T--){
		int x,y,z=0,sum=0;
		cin >> x >> y;
		if((x+y)>9999)z=(x+y-9999);
		int r=x+y-z;
		if(x>r)swap(x,r);
		for(int i=x;i<=r;i++)if(run(i)==1)sum++;
		cout << sum << endl;
	}
	return 0;
}
