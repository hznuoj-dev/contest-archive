#include<stdio.h>
#include<math.h>
#include<string.h>
int num(long long n);
int main(){
	long long a,b,c,d;
	int sum1=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	if(num(a)==1)
	sum1++;
	if(num(b)==1)
	sum1++;
	if(num(c)==1)
	sum1++;
	if(num(d)==1)
	sum1++;
	if(sum1==0)
	printf("Bao Bao is so Zhai......");
	if(sum1==1)
	printf("Oh dear!!");
	if(sum1==2)
	printf("BaoBao is good!!");
	if(sum1==3)
	printf("Bao Bao is a SupEr man///!");
	if(sum1==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
}
int num(long long n){
	int sum=0;
	while(n>0){
		sum=sum+n%10;
		n=n/10;
	}
	if(sum>=16||sum==6)
	return 1;
	else
	return 0;
}
