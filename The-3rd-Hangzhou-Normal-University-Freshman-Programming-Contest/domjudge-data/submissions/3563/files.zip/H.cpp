#include <stdio.h>
int main(void)
{
	int T;
	long int n,m;
	float q;
	scanf("%d",&T);
	while(T)
	{
		scanf("%ld %ld\n",&n,&m);
		q=(float)m/n;
		printf("[");
		while(m--)
		printf("#");
		while(n--)
		printf("-");
		printf("] %d%%\n",q*100);
		T--;
	
	}
	return 0;
}
