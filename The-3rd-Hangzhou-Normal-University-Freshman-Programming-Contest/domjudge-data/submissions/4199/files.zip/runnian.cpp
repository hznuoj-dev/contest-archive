#include<stdio.h>
int main(){
    int n,a,b,t,x;
    scanf("%d",&n);
    while (n--){
        int sum=0;
        scanf("%d %d",&a,&b);
        x=a+b;
        if(x>=10000) {x=x-9999;x=9999-x;}
        if(a>x) {t=a;a=x;x=t;}
        for(int i=a;i<=x;i++){
            if(i%4==0&&i%100!=0)
                sum++;
            else if(i%400==0)
                sum++;
        }
        printf("%d\n",sum);
    }
}
