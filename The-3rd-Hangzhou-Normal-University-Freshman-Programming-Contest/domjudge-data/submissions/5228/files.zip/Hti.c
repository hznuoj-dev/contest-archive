#include <stdio.h>
#include <stdlib.h>
int main(void){
	int t,i;
	double n,m,a,s;
	while(scanf("%d",&t)!=EOF){
		while(t--){
			s=0;
			scanf("%lf%lf",&n,&m);
			a=n-m;
			s=m/n*100;
			printf("[");
			i=1;
			while(i<=m){
				printf("#");
				i=i+1;
			}
			i=1;
			while(i<=a){
				printf("-");
				i=i+1;
			}
			printf("] %.0f%%\n",s);
		}
	}
		
	
	
	return 0;
}
