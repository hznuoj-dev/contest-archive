#include<stdio.h>
#include<math.h>
int main(void){
	long long a,b,c,d,e,f=0,g=0,h=0,i=0,j=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>=10){
		e=a%10;
		a=(a-e)/10;
		f=f+e;
	}
	f=f+a;
	if(f>=16||f==6)
	    g=g+1;
	while(b>=10){
		e=b%10;
		b=(b-e)/10;
		h=h+e;
	}
	h=h+b;
	if(h>=16||h==6)
	    g=g+1;
	while(c>=10){
		e=c%10;
		c=(c-e)/10;
		i=i+e;
	}
	i=i+c;
	if(i>=16||i==6)
	    g=g+1;
	while(d>=10){
		e=d%10;
		d=(d-e)/10;
		j=j+e;
	}
	j=j+d;
	if(j>=16||j==6)
	    g=g+1;
    if(g==0)
        printf("Bao Bao is so Zhai......\n");
    else if(g==1)
        printf("Oh dear!!\n");
    else if(g==2)
        printf("BaoBao is good!!\n");
    else if(g==3)
        printf("Bao Bao is a SupEr man///!\n");
    else if(g==4)
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
    return 0;
}
