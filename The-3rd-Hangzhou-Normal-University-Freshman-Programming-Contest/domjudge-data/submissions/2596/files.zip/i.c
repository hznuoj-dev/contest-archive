#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main() {
	int n[4] = { 0 }, i, k, sum;
	char s[30];
	for (i = 0; i < 4; i++) {
		k = 0;
		sum = 0;
		scanf("%s", &s);
		k = strlen(s);
		while (k--) {
			sum += s[k] - 48;
		}
		if (sum == 6 || sum >= 16) {
			n[i] = 1;
		}
	}
	sum = 0;
	for (i = 0; i < 4; i++) {
		sum += n[i];
	}
	switch (sum) {
	case 0:printf("Bao Bao is so Zhai......");
		break;
	case 1:printf("Oh dear!!");
		break;
	case 2:printf("BaoBao is good!!");
		break;
	case 3:printf("Bao Bao is a SupEr man///!");
		break;
	case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		break;
	}
	return 0;
}