#include <stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
#define PI 3.14159
#include<math.h>
#pragma warning(disable:4996)


int  main() {
	int t;
	int a, b,i,n;
	float m;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &a, &b);
		m = (float)b / (float)a;
		n = (int)(m * 100);
		printf("[");
		for (i = 1;i <= b;i++) {
			printf("#");
		}
		for (i = 1;i <= a-b;i++) {
			printf("-");
		}
		printf("]");
		printf(" %d%c\n", n,37);
	}
	
	return 0;
}
