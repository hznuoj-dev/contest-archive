#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
using namespace std;
typedef struct{
	int a,b;
}lw;
lw y[100];
int cmp(const void*p,const void*q);
int main(){
	int n,m,i,j,sum=0,min=100001,ss=0;
	scanf("%d %d",&n,&m);
	
	for(i=0;i<n;i++){
		scanf("%d",&y[i].a);
		if(min>y[i].a)min=y[i].a;
	}
	for(i=0;i<n;i++){
		scanf("%d",&y[i].b);
		sum=sum+y[i].b*y[i].a;
	}
	if(sum>m)sum=m;
	qsort(y,n,sizeof(y[0]),cmp);
	for(i=n-1;i>=0;i--){
		for(j=0;j<i;j++){
			if(i!=j){
				if(y[i].a%y[j].a!=0)ss++;
			}
		}
	}
	printf("%d\n",sum-min+1-ss);
}
int cmp(const void*p,const void*q){
	return (*(lw*)p).a-(*(lw*)q).a;
}

