#include<stdio.h>
int main()
{
	int i,t,y,a,z,x;
	scanf("%d",&t);
	for(i=0;i<t;++t)
	{
		x=0;
		scanf("%d %d",&y,&a);
		if(y+a>9999)
			z=9999-(y+a-9999);
		else
			z=y+a;
		if(y<z)
		{
			for(i=y;i<z;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					x++;
			}
		}
		if(y>z)
		{
			for(i=z;i<y;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					x++;
			}
		}
		printf("%d\n",x);
	}
}








