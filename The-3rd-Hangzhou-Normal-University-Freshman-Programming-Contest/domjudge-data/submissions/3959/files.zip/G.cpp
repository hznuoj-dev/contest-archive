#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int k,n,m,x,y,i,T,j,t=0,sum,temp,s1,s2,s3,s4;
int a[5000],b[5000],c[5000],d;
int find(int x){
    int x_root=x;
    if(x_root==a[x])
        return x_root;
    return a[x_root]=find(a[x_root]);
}
void S(int x,int y){
    b[y]=b[y]+b[x];
}
bool cmp(int x,int y){
return b[x]>b[y];
}
int main(){
   cin>>T;
   for(i=1;i<=T;i++){
        cin>>n>>m;
        for(j=1;j<=n;j++){
            a[j]=c[j]=j;
            b[j]=1;
        }
        for(j=1;j<=m;j++){
            cin>>x>>y;
            if(find(y)!=find(x))
            a[find(y)]=find(x);
            S(y,x);
        }
        sort(c+1,c+1+n,cmp);
        for(j=1;j<n;j++)
            cout<<c[j]<<" ";
        cout<<c[j];
   }
    return 0;
}
