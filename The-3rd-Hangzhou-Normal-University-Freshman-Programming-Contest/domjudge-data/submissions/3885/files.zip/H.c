#include<stdio.h>
#include<math.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int i;
		int m,n;
		scanf("%d %d",&m,&n);
		printf("[");
		for(i=1;i<=n;i++)
		{
			printf("#");
		}
		for(i=1;i<=(m-n);i++)
		{
			printf("-");
		}
		printf("] ");
		double a=(double)n/(double)m;
		
		
		double c=a*100;
		int b=floor(c+0.5);
		if(b==10)
		{
			b=100;
		}
		printf("%d",b);
		printf("%%\n");
	}
	
	

}
