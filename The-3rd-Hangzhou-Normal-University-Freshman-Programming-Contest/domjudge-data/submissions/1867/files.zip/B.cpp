#include<stdio.h>
int fib(int z); 
int main(){
	int i,t,x,m,n,s,a,b,j;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		s=0;
		scanf("%d%d",&a,&b);
		b=a+b;
		if(b>9999)b=9999-(b-9999);
		if(a>b){t=a;a=b;b=t;
		}
		for(j=a;j<=b;j++){
			if(fib(j)==1)s++;
			
		}
		printf("%d\n",s);
		
	}
	return 0;
	
} 
int fib(int z){
	if((z%4==0&&z%100!=0)||z%400==0)
	return 1;
	else return 0;
	
	
	
	
}
