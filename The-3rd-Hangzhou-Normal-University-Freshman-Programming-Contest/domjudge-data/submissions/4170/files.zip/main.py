fw,fw1 = input().split()
coinValue = list(map(int, input().split()))
coinMount = list(map(int, input().split()))
mountSet = {0}
for i in range(0, len(coinValue)):
    for j in range(0, coinMount[i]):
        tmpSet = set()
        for k in mountSet:
            newValue = k + coinValue[i]
            tmpSet.add(newValue)
        for v in tmpSet:
            mountSet.add(v)
        tmpSet.clear()
fw1 = int(fw1)
count = 0
for v in mountSet:
    if v < fw1:
        count = count+1
print(count-1)
