#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int n,a[100000],b[10000]={0};
	int i,t;
	long long sum;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[a[i]]++;
	}
	i=3;
	sum=1;
	while(b[i]!=0)
	{
		sum=sum*(b[i]+1);
		i++;
	}
	printf("%lld\n",sum);
	
	return 0;
}
