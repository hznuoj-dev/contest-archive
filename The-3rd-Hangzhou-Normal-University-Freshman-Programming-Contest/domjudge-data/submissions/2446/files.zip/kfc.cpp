#include<stdio.h>
int panduan(int x);
int main(){
    int T;
    scanf("%d",&T);
    while(T--){
    	int y,z,n=0,d,f;
		scanf("%d%d",&y,&z);
		if((y+z)<=9999){
			if(y<=y+z){
				d=y+z;
				f=y;
			}
			else if(y>y+z){
				d=y;
				f=y+z;
			}
			for(;f<=d;f++){
				if(panduan(f))
				n++;
			}
		}
		else if((y+z)>9999){
			if(y<=(9999-(y+z-9999))){
				f=y;
				d=(9999-(y+z-9999));
			}
			else if(y>(9999-(y+z-9999))){
				f=(9999-(y+z-9999));
				d=y;
			}
			for(;f<=d;f++){
				if(panduan(f))
				n++;
			}
		}
		printf("%d\n",n);
	}
}
int panduan(int x){
	if(x%400==0 || (x%4==0 && x%100!=0))
	return 1;
	else return 0;
	
}
