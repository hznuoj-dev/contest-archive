#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	int T,m,n,t,i,j;
	scanf("%d",&T);
	while((T>=1)&&(T<=10)){
	scanf("%d %d",&n,&m);
	while((n>=1)&&(n<=100000)&&(m>=0)&&(m<=n)){
	t=(m*100)/n;
	printf("[");	
    for(i=1;i<=m;i++){
    printf("#");	
	}
	for(j=m+1;j<=n;j++){
		printf("-");
	}
	printf("] ");
	printf("%d%%\n",t);
	break;
}
    T=T-1; 
}
	return 0;
}
