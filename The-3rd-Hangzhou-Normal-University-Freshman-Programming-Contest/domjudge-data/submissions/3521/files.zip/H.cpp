#include <stdio.h>
int main()
{
	int t,i;
	int m,n,a,b;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&m,&n);
		printf("[");
		for(i=1;i<=n;i++)
		{
			printf("#");
		}
		for(i=1;i<=m-n;i++)
		{
			printf("-");
		}
		printf("]");
		printf(" %d",100*n/m);
		printf("%%\n");
	}
	return 0;
}
