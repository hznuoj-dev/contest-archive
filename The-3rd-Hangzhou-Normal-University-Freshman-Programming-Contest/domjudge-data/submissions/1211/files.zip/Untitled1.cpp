#include <cstdio>
#include <iostream>
#include <cstring> 
using namespace std;
const int N = 1e5 + 10;
char s[N];
int main () {
	int n;
	scanf("%d", &n);
	int ans = 0;
	scanf(" %s", s);
	int len = strlen(s);
	ans = len * n;
	for (int i = 2; i <= n; ++i) 
		scanf(" %s", s); 
	printf("%d\n", ans);
}
