#include<stdio.h>
int main(){
	int t,n,i,a,b,x;
	scanf("%d",&t);
	while(t--){
		x=0;
		scanf("%d%d",&a,&b);
		if(a+b>9999){
			n=9999-(a+b-9999);
		}else{
			n=a+b;
		}
		if(a>n){
			b=a;
			a=n;
			n=b;
		}
		for(i=a;i<=n;i++){
			if((i%400==0)||(i%4==0&&i%100!=0)) x++;
		}
		printf("%d\n",x);
	}
	return 0;
}
