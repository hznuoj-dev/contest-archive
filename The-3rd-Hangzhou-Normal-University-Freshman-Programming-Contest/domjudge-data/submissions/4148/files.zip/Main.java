import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner in = new Scanner(System.in);
		while (in.hasNext())
		{
			int t = in.nextInt();
			for (int i = 0; i < t; i++)
			{
				int y = in.nextInt();
				int a = in.nextInt();
				if (y + a > 9999)
					a = 9999 - (y + a - 9999);
				else
					a = y + a;
				int y1 = y / 4 - y / 100 + y / 400;
				int a1 = a / 4 - a / 100 + a / 400;
				int r = Math.max(a1, y1) - Math.min(a1, y1);
				if ((y % 4 == 0 && y % 100 != 0) || y % 400 == 0)
					r++;
				if ((a % 4 == 0 && a % 100 != 0) || a % 400 == 0)
					r++;
				System.out.println(r);
			}
		}
	}
}
