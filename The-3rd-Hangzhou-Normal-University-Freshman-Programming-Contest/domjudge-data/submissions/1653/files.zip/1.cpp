#include<stdio.h>
#include<math.h>
#include<string.h>
int main(void){
	char s[3];
	gets(s);
	if (s[0]=='k'&&s[1]=='f'&&s[2]=='c'){
	    printf(" __      _____\n");
	    printf("|  | ___/ ____\\____\n");
	    printf("|  |/ /\\   __\\/ ___\\\n");
	    printf("|    <  |  | \\  \\___\n");
	    printf("|__|_ \\ |__|  \\___  >\n");
	    printf("     \\/           \\/\n");
		
		
		
	} 
	
	
    return 0;	
}

  
