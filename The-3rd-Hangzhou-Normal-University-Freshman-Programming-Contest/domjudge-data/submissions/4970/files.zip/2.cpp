#include<stdio.h> 
int main(){
	int a,b,c,d,x=0,t;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	int A=a;
	int B=b;
	int C=c;
	int D=d;
	int i,sum;
	sum=0;
	for(i=10;i<A*10;i*=10){
		t=a%10;
		sum+=t;
		a=a/10;
		if(a==10)
		sum=sum+1;	
	}
	if(sum>=16||sum==6)
	x=x+1;
		sum=0;
	for(i=10;i<B*10;i*=10){
		t=b%10;
		sum+=t;
		b=b/10;	
		if(b==10)
		sum=sum+1;
	}
	if(sum>=16||sum==6)
	x=x+1;
		sum=0;
		for(i=10;i<C*10;i*=10){
		t=c%10;
		sum+=t;
		c=c/10;	
		if(c==10)
		sum=sum+1;
	}
	if(sum>=16||sum==6)
	x=x+1;
		sum=0;
		for(i=10;i<D*10;i*=10){
		t=d%10;
		sum+=t;
		d=d/10;
		if(d==10)
		sum=sum+1;	
	}
	if(sum>=16||sum==6)
	x=x+1;
	if(x==0)
	printf("Bao Bao is so Zhai......\n");
	else if(x==1)
	printf("Oh dear!!\n");
	else if(x==2)
	printf("BaoBao is good!!\n");
	else if(x==3)
	printf("Bao Bao is a SupEr man///!\n");
	else if(x==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
return 0;	
}
