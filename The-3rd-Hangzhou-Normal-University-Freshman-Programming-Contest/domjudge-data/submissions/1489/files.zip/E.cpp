#include<bits/stdc++.h>
using namespace std;
int main(){
	string s;
	getline(cin,s);
cout << "	__ _____" << endl;
cout << "| | ___/ ____\____" << endl;
cout << "| |/ /\ __\/ ___";
cout << (char)92 << endl;
cout << "| < | | \ \___" << endl;
cout << "|__|_ \ |__| \___ >" << endl;
cout << "\/ \/" << endl;
return 0;
}
