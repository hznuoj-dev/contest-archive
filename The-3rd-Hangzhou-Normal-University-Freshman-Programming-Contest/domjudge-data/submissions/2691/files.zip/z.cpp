#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int T,a,b,i;
	double c;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&a,&b);
		c=100*b/(double)a;
		printf("[");
		for(i=1;i<=b;i++)
			printf("#");
		for(i=1;i<=a-b;i++)
			printf("-");
		printf("] ");
		printf("%d%%",(int)c);
		printf("\n");
	}
	return 0;
}