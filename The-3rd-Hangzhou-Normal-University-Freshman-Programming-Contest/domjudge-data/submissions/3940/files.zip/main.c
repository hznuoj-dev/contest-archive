#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int main() {
int T,n,i;
char a;
long long m;
int num;
a='%';
scanf("%d",&T);
while(T--){
	scanf("%d%lld",&n,&m);
	printf("[");
	for(i=1;i<=m;i++){
		printf("#");
	}
	for(i=m+1;i<=n;i++){
		printf("-");
	}
	printf("] ");
	num=(m*100.0)/n;
	printf("%d",num);
	printf("%c",a);
	printf("\n");
}
	return 0;
}





