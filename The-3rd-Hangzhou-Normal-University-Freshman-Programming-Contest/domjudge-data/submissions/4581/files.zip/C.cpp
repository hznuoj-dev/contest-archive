#include<stdio.h>
long long ans,x,a[100000];
long long f(long long x,long long n,long long mod);
long long g(long long x){
	
	int i,s=1;
	for(i=2;i<=x;i++) s=s*i%998244353;
	return s;
}
int main(void){
	
	long long n,i,t,s,y,p=998244353;
	scanf("%lld",&n);
	ans=1;
	for(i=1;i<=n;i++){
		
		scanf("%lld",&x);
		a[x]++;
	}
	for(i=2;i<=10000;i++){
		
		y=a[i-1];
		x=a[i];
		if(a[i]==0) break;
		else{
			
			t=y-1;
			y=x+y-1;
			if(y-t<t) t=y-t;
			s=g(y)*f(g(y-t),p-2,p)%p*f(g(t),p-2,p)%p;
		}
		ans=ans*s%p;
	}
	printf("%lld",ans);
}
long long f(long long x,long long n,long long mod){
	
	long long s=1;
	while(n){
		
		if(n&1) s=s*x%mod;
		x=x*x%mod;
		n=n/2;
	}
	return s;
}
