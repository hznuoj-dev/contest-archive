#include<stdio.h>
int main(void){
int n,a,b,i,j,t;
scanf("%d",&n);
while(n--){
scanf("%d%d",&a,&b);
if(b>a)
t=a,a=b,b=t;
printf("[");
i=a-b;
j=b;
while(j--)
printf("#");
while(i--)
printf("-");
printf("] ");
printf("%.lf%%\n",(double)b*100.0/(double)a);
} 
return 0;}

