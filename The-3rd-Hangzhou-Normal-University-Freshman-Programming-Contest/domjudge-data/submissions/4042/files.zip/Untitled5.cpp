#include<stdio.h>
#include<string.h>
char b[10000010];
int main(){
	int T,n,n2,flag;
	int total,sum;
	char a[1000010];
	scanf("%d",&T);
	while(T--){
		total=0;
		scanf("%d",&n);
		while(n--){
		sum=0;
		    for(int i=0;i<10000000;i++){
		    	b[i]='.';
			} 
			scanf("%s",a);
			n2=strlen(a);
			for(int i=0;i<n2;i++){
				if(a[i]!='.'){
				flag=1;
				for(int j=0;j<sum;j++){
				if(b[j]==a[i]){
					flag=0;
				}	
				}
				if(flag==1){
					sum++;
					b[sum]=a[i];
				}	
				}
			}
			total+=sum;
		}
		printf("%d\n",total);
	}
}
