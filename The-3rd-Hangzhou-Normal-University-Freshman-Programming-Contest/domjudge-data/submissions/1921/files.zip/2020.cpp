#include<stdio.h>
void faker(int m,int n){
	int sum=0;
	for(int i=m;i<=n;i++){
	    int t=0;
		if(i%4==0){
	    	t=1;
		    if(i%100==0){
			    t=0;
			    if(i%400==0){
				    t=1;
		    	}
	    	}
    	}
    	if(t==1)sum++;
	}
	printf("%d\n",sum);
}
int main()
{
	int r,m,n,t;
	scanf("%d",&r);
	for(int i=0;i<r;i++){
		scanf("%d%d",&m,&n);
		if(m>n&&m+n>9999||n>9999){
			n=9999-(m+n-9999);
			if(m>n){
				t=m;m=n;n=t;
			}
			faker(m,n);
		}
		else if(m<n&&n<9999) faker(m,n);
		else if(n<0&&m+n>0){
			n=m+n;
			if(m>n){
				t=m;m=n;n=t;
			}
			faker(m,n);
		}
		else if(n<0&&n+m<0){
			n=1-(m+n-1);
			if(m>n){
				t=m;m=n;n=t;
			}
			faker(m,n);
		}
	}
	return 0;
}
