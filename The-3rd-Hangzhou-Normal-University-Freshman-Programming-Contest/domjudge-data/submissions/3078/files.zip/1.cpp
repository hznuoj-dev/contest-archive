#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main()
{
    int sz[5], i, c = 0, d;
    (void)scanf("%d %d %d %d", &sz[1], &sz[2], &sz[3], &sz[4]);
    for (i = 1; i <= 4; i++)
    {
        d = 0;
        while (sz[i] > 0)
        {
            d = d + sz[i] % 10;
            sz[i] = sz[i] / 10;
        }
        if (d >= 16 || d == 6)
        {
            c++;
        }
    }
    if (c == 1)
    {
        printf("Oh dear!!");
    }
    if (c == 2)
    {
        printf("BaoBao is good!!");
    }
    if (c == 3)
    {
        printf("Bao Bao is a SupEr man//////!");
    }
    if (c == 4)
    {
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    }
    if (c == 0)
    {
        printf("Bao Bao is so Zhai......");
    }
    return 0;
}