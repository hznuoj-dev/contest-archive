#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
	int a,b,c,i,j,t;
	scanf("%d",&t);
	while(t--)
	{
		j=0;
		scanf("%d%d",&a,&b);
		c=a+b;
		if(c>9999)
			{
				c=9999-(c-9999)
		}
		while(c<1)
		{
			c=a+c;
		}
		if(a>c)
		{
			b=a;
			a=c;
			c=b;
		}
		for(i=a;i<=c;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
				j++;
		}
		printf("%d\n",j);
	}
		return 0;
}