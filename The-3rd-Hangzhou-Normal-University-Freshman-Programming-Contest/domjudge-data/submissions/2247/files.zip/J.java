import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		while(in.hasNext())
		{
			String a=in.nextLine();
			
			
			String num[]=a.split(" +");
			
			int gg=0;
			for (int i = 0; i < num.length; i++)
			{
				String b=num[i];
				int sum=0;
				for (int j = 0; j < b.length(); j++)
				{
					String c=b.substring(j, j+1);
					sum+=Integer.parseInt(c);
				}
				if (sum>=16||sum==6)
				{
					gg++;
				}
			}
			
			
			if (gg==0)
			{
				System.out.println("Bao Bao is so Zhai......");
			}
			if (gg==1)
			{
				System.out.println("Oh dear!!");
			}
			if (gg==2)
			{
				System.out.println("BaoBao is good!!");
			}
			if (gg==3)
			{
				System.out.println("Bao Bao is a SupEr man///!");
			}
			if (gg==4)
			{
				System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			}
			
		}
	}

}
