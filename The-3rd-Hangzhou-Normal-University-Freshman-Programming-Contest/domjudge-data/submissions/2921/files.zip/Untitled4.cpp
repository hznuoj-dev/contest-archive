#include<stdio.h>
int main(void){
	int T,i;
	int n,m;
	double num;
	char ch='%';
	scanf("%d",&T);
	while(T>0){
		scanf("%d %d",&n,&m);
	printf("[");
	for(i=0;i<m;++i){
		printf("#");
	}
	if(m!=n){
	for(i=0;i<n;++i){
		printf("-");
	}
}
	num=1.0*m/n*100;
	printf("] ");
	printf("%d",(int)num);
	printf("%c\n",ch);
	T--;
	}
	return 0;
}
