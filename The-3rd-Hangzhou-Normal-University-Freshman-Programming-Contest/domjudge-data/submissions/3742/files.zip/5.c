#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	long long t,i,j,n,m,s;
	char q='%';
	scanf("%d",&t);
	while(t--)
{
	scanf("%d%d",&m,&n);
	s=n*100/m;
	printf("[");
	for(i=1;i<=m;i++){
	if(i<=n)
	printf("#");
	else
	printf("-");}
	
	printf("]");
	printf(" %d",s);
	printf("%c\n",q);}
	return 0;
}

