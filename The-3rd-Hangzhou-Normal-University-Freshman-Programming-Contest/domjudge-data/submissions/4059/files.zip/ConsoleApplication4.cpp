﻿#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int main() {
	int n,i,j,k,count,t;
	scanf("%d",&t);
	while(t--){
		count=0;
		scanf("%d",&n);
		while(n--){
			char a[2000],b[200000];
		scanf("%s",a);
		k=0;
		for(i=0;i<strlen(a);i++){
			if(a[i]!='.'){
			for(j=0;j<k;j++){
			if(b[j]==a[i])
			break;
			}
			if(j==k){
			b[k]=a[i];
			count++;
			k++;
		}
	}
}
}
printf("%d\n",count);
}
return 0;
}
