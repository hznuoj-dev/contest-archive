#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=1e2+10;
const int M=1e5+10;
const int mod=998244353;
int n,m; 
int a[N],b[N];
ll dp[M]={0};
int main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0); 
	cin>>n>>m;
	for(int i=1;i<=n;++i) cin>>b[i];
	for(int i=1;i<=n;++i) cin>>a[i];
	for(int i=1;i<=n;++i){
		for(int k=1;a[i];k<<=1){
			k=min(k,a[i]);
			a[i]-=k;
			for(int j=m;j>=b[i]*k;--j){
				dp[j]=max(dp[j],dp[j-b[i]*k]+b[i]*k);
			}
		} 
	}
	int ans=0;
	for(int i=1;i<=m;++i){
		ans+=i==dp[i];
	}
	printf("%d\n",ans);
} 
