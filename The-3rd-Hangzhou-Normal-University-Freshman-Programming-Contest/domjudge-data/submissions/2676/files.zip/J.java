import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		while(in.hasNext())
		{
			int a=in.nextInt();
			
			

			for (int i = 0; i < a; i++)
			{
				int b=in.nextInt();
				int ppp=0;
				String[] zifu=new String[b];
				for (int j = 0; j < b; j++)
				{
					String str=in.next();
					zifu[j]=str;
				}
				
				for (int j = 0; j < zifu.length; j++)
				{
					zifu[j]=zifu[j].replace(".", "");
					String f=zifu[j];
					while(f.length()>0)
					{
						f=f.replace(f.substring(0, 1), "");
						ppp++;
					}
				}
				System.out.println(ppp);
				
			}
		}
	}

}