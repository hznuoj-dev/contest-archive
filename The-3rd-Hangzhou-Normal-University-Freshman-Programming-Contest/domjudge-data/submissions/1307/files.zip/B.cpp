//
// Created by Kyooma on 2020/12/13.
//
#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
        int x,y,cnt=0;
        cin>>x>>y;
        y=x+y;
        if(y>9999) y=9999-(y-9999);
        for(int i=min(x,y);i<=max(x,y);i++){
            if((i%4==0 && i%100!=0) || i%400==0) cnt++;
        }
        cout<<cnt<<"\n";
    }
}
