#include<bits/stdc++.h>
using namespace std;
int h(int year)
{
	if((year%4==0&&year%100!=0)||year%400==0) return 1;
	else return 0;
}
int main()
{
	int t,y,a,num;
	int low,upper;
	scanf("%d",&t);
	while(t--)
	{
		int ans=0;
		scanf("%d %d",&y,&a);
		if(a>0)
		{
			if(y+a<10000)
			{
				low=y;
				upper=y+a;
				for(int i=low;i<=upper;i++)
					if(h(i)) ans++;
			}
			else if(y+a>=10000)
			{
				num=y+a;
				while(num>9999) num-=9999;
				low=min(y,9999-num);
				upper=max(y,9999-num);
				for(int i=low;i<=upper;i++)
					if(h(i)) ans++;
			}
		}
		else if(a<=0)
		{
			low=y+a;
			upper=y;
			for(int i=low;i<=upper;i++)
				if(h(i)) ans++;	
		}
		printf("%d\n",ans);	
	}
	return 0;
}
