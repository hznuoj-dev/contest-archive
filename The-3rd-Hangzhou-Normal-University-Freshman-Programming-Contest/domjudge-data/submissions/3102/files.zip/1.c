#include <stdio.h>
#include<math.h>
int main(void) {
	int n,a,b,s,i,m;
	s=scanf("%d",&n);
	while(n--){
		s=scanf("%d%d",&a,&b);
		if (a+b>9999)
		b=9999-(a+b)%9999;
	else
	b=a+b;
		s=fmax(a,b);
		m=0;
		for (i=a+b-s;i<=s;++i){
		if(i%400==0 || (i%4==0 && i%100!=0))
			m=m+1;
	}
	printf("%d\n",m);}
    return 0;}
