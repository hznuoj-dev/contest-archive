#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{	
	
		int n,m,p;
		scanf("%d %d",&n,&m);
		p=m*100/n;
		printf("[");
		for(int i=0;i<m;i++)
		{
			printf("#");
		}
		for(int i=m;i<n;i++)
		{
			printf("-");
		}
		printf("]");
		printf(" ");
		printf("%d%%\n",p);
	}
 } 
 

