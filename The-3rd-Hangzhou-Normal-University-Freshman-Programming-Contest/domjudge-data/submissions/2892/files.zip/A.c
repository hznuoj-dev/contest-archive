#include<stdio.h>

int ch(int x);

int main()
{
	int x[4];
	int i;
	int sum=0;
	scanf("%d %d %d %d",&x[0],&x[1],&x[2],&x[3]);
	for(i=0;i<4;i++){
		int a,b=0,c=0;
		while(x[i]!=0){
			a=x[i]%10;
			b+=a;
			x[i]=x[i]/10;
		}
		if(b>=16||b==6)
			sum++;
	}
	if(sum==0)
		printf("Bao Bao is so Zhai......\n");
	if(sum==1)
		printf("Oh dear!!\n");
	if(sum==2) 
		printf("BaoBao is good!!\n");
	if(sum==3) 
		printf("Bao Bao is a SupEr man///!\n");
	if(sum==4) 
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}