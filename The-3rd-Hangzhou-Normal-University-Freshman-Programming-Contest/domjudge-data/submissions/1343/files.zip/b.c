#include <stdio.h>
#include <stdlib.h>

int pd(int year)
{
	if(year%4==0)
	{
		if(year%100==0)
		{
			if(year%400==0)
			{
				return 1;
			}
		}
		else
		{
			return  1;
		}
	}

	return 0;
	
	
}

int main(void)
{
	int t,y,a,total,up,min,max,i;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&y,&a);
		min = y;
		if(y+a>9999)
		{
			up = y+a-9999;
		}
		else
		{
			up = a;
		}
		max = y+up;
		if(min>max)
		{
			total = min;
			min = max;
			max = total;
		}
		total = 0;
		for(i = min;i <=max;i++)
		{
			if(pd(i))
			{
				total++;
			}
		}
		printf("%d\n",total);
	}	
	
	return 0;
 } 
