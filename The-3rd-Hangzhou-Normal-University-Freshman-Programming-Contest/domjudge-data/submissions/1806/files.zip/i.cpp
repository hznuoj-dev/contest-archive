#include <bits/stdc++.h>
using namespace std;

int analy(int n){
    int res=0;
    while(n){
        res+=n%10;
        n/=10;
    }
    return res;
}
int main() {
    int n[4];
    for(int i=0;i<4;i++) cin>>n[i];
    int count=0;
    for(int i=0;i<4;i++){
        if(analy(n[i])==6||analy(n[i])>=16) count++;
    }
    if(count==0) cout<<"Bao Bao is so Zhai......"<<'\n';
    else if(count==1) cout<<"Oh dear!!"<<'\n';
    else if(count==2) cout<<"BaoBao is good!!"<<'\n';
    else if(count==3) cout<<"Bao Bao is a SupEr man///!"<<'\n';
    else if(count==4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<'\n';
    return 0;
}