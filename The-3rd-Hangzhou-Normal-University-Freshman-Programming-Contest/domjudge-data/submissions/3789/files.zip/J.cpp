#include<bits/stdc++.h>
using namespace std;
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int cnt=0,n;
		char s[1000020];
		char map[100];
		scanf("%d",&n);
		while(n--){
			int m=0;
			scanf("%s",s);
			int len=strlen(s);
			for(int i=0;i<len;i++){
				if(s[i]!='.'){
					int ok=1;
					for(int j=0;j<m;j++){
						if(map[j]==s[i])ok=0;
					}
					if(ok){
						cnt++;
						map[m++]=s[i];
					}
				}
			}

		}
		cout<<cnt<<endl;
		
		
		
		
	}
	
	
	return 0;
} 
 
