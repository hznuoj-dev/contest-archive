#include<iostream>
#include<set>
#include<cstring>
using namespace std;
char a[1000010];
set<char>q;
int main(){
	int t;
	cin>>t;
	while(t--){
		int n,ans=0;
		cin>>n;
		q.clear();
		for(int i=1;i<=n;i++){
			cin>>a;
			for(int k=0;k<strlen(a);k++){
				if(a[k]!='.')q.insert(a[k]);
			}
			ans+=q.size();
			q.clear();
		}
		cout<<ans<<"\n";
	}
	return 0;
}

