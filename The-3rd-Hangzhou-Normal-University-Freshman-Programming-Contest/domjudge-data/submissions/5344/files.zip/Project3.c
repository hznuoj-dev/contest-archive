﻿#include <stdio.h>
int p[100000], w[100000] = { 0 };
int main() {
    int n, m, i, a[100], b[100], j, t, u, k, count = 0;
    scanf("%d %d", &n, &m);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    for (i = 0; i < n; i++) {
        scanf("%d", &b[i]);
    }
    for (i = 0; i <= b[0]; i++) {
        p[i] = i * a[0];
        w[p[i]] = 1;
    }
    u = b[0];
    t = u + 1;
    for (i = 1; i < n; i++) {
        for (k = 0; k <= u; k++) {
            for (j = 0; j <= b[i]; j++) {
                if (w[j * a[i] + p[k]] != 1) {
                    p[t] = j * a[i] + p[k];
                    w[p[t]] = 1;
                    t++;
                }
            }
        }
        u = t - 1;
    }
    for (i = 1; i <= m; i++) {
        if (w[i] == 1)
            count++;
    }
    printf("%d", count);
    return 0;
}