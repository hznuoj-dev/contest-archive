#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	double T,m,n,t,i,j;
	scanf("%lf",&T);
	while((T>=1)&&(T<=10)){
	scanf("%lf %lf",&n,&m);
	while((n>=1)&&(n<=100000)&&(m>=0)&&(m<=n)){
	t=(m/n)*100;
	printf("[");	
    for(i=1;i<=m;i++){
    printf("#");	
	}
	for(j=m+1;j<=n;j++){
		printf("-");
	}
	printf("] ");
	printf("%.0f%%\n",t);
	break;
}
    T=T-1; 
}
	return 0;
}
