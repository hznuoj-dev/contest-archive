#include<stdio.h>
int main() {
	int t, m, n, a, b, q[100000], p[100000], i, j;
 	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &n, &m);
		for (i = 1; i <= n; i++) {
			q[i] = 1;
		}
		for (i = 1; i <= m; i++) {
			scanf("%d %d", &a, &b);
			q[a] += 1;
			for (j = 1; j <= m; j++) {
				if (q[j] >= q[a] && j != a) {
					q[j] += 1;
				}
			}
		}
		for (i = n; i >0; i--) {
			for (j = 1; j <= n; j++) {
				if (q[j] == i) {
					printf("%d ", j);
				}
			}
		}
		printf("\n");
	}
}