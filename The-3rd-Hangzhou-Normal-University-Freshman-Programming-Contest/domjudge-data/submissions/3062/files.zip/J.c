#include<stdio.h>
#include<string.h>


int main()
{
	int k;
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int j;
		int i;
		int n;
		scanf("%d",&n);
		int a[n];
		getchar();
		char s[1000000];
		int total=0;
		for(i=0;i<n;i++)
		{
			gets(s);
			int num=0;
			int len=strlen(s);
			for(k=0;k<len;k++)
			{ 
			    
				if(s[k]!='.')
				{
					num++;
					for(j=k+1;j<len;j++)
					{
						if(s[j]==s[k])
						{
							s[j]='.';
						}
					}
				}
				
			}total+=num;
		}
		printf("%d\n",total); 
		
			
		
		
		
		
		
		
	}
}
