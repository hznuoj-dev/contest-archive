#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t;
    float n,m,s;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        cin>>n>>m;
        for(int j=1;j<=m;j++)
        {
            if(j==1)
                printf("[#");
            else
                printf("#");
        }
        for(int j=1;j<=n-m;j++)
        {
            if(j==n-m)
            printf("-]");
            else
                 printf("-");
        }
        s=m/n*100;
        printf(" %d%%\n",(int)s);
    }
    return 0;
}
