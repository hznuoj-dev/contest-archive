﻿#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int main() {
	int t;
	double n, m;
	scanf("%d", &t);
	while (t--) {
		scanf("%lf%lf", &n, &m);
		double w = (m / n)*100;
		printf("[");
		for (int i = 0; i < n; i++) {
			if (i < m)
				printf("#");
			else
				printf("-");
		}
		printf("]");
		printf(" %.0lf", w);
		printf("%%");
		printf("\n");
	}
}