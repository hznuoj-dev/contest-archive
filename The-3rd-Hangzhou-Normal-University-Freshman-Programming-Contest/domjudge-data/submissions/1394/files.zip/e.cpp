#include<stdio.h>
#include<string.h>
int main(){
	char a[4];
	scanf("%s",a);
	if(strcmp(a,"kfc")==0)
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");
	return 0;
} 
