#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6+100;
const int INF=0x3f3f3f3f;

int main(){
	int T; scanf("%d",&T);
	while(T--){
		int n,m; scanf("%d %d",&n,&m);
		int ans=(int)(100.0*m/n);
		printf("[");
		for(int i=1;i<=m;++i)
			printf("#");
		for(int i=m+1;i<=n;++i)
			printf("-");
		printf("] %d%%\n",ans);
	}
	return 0;
}
