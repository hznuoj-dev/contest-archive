#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,b,cnt=0,t;
	char a[100005],c[100005];
	
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		cin>>b;
		for(int j=1;j<=b;j++){
			cin>>a;
			for(int k=0;k<strlen(a);k++){
				if(a[k]=='.'){
					continue;
				}
				else{
					for(t=0;t<k;t++){
						if(a[k]==a[t]){
							break;
						}
					}
					if(t==k){
						cnt++;
					}
				}
			}
		}
		cout<<cnt<<endl;
		cnt=0;
	}
	return 0;
}
