#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void) {
	int T;
	scanf("%d", &T);
	while (T--) {
		int n;
		int sum = 0;
		scanf("%d", &n);
		while (n--) {
			char cc[10005];
			char c;
			int i = 0;
			c = getchar();
			while (1) {
				c = getchar();
				int j;
				int flag = 1;
				if (c == '\n') break;
				else if (c != '.') {
					for (j = 0; j < i; j++) {
						if (c == cc[j]) {
							flag = 0;
							break;
						}
					}
					if (flag) {
						cc[i] = c;
						i++;
					}
				}
			}
			sum += i;
		}
		printf("%d\n", sum + 1);
	}
}