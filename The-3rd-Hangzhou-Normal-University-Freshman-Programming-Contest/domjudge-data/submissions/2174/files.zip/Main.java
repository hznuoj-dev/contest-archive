

import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner shh = new Scanner(System.in);
		int x, b, ns, rn;
		while (shh.hasNext())
		{
			int y = shh.nextInt();
			
			while (y-- > 0)
			{
				rn=0;
				x = shh.nextInt();
				b = shh.nextInt();
				max = 0;
				ns = 0;
				if (x + b >= 10000)
				{
					ns = 9999 - ((x + b) - 9999);
					if (x < ns)
					{
						for (int i = x; i <= ns; i++)
						{
							if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
							{
								rn = rn + 1;
							}
						}
					} else
					{
						for (int i =ns; i <=x; i++)
						{
							if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
							{
								rn = rn + 1;
							}
						}
					}
					
				}else {
					if (x < x + b)
					{
						for (int i = x; i <= x + b; i++)
						{
							if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
							{
								rn = rn + 1;
							}
						}
					} else
					{
						for (int i = x + b; i <= x; i++)
						{
							if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
							{
								rn = rn + 1;
							}
						}
					}
				}
				System.out.println(rn);
			}

		}
	}
}
