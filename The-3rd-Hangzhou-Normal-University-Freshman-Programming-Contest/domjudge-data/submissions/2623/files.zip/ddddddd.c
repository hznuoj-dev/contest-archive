#include<stdio.h>

int gj(int x);
int main(){
	int a,b,c,d,s=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	s+=gj(a);
	s+=gj(b);
	s+=gj(c);
	s+=gj(d);
	switch(s){
		case 0:printf("Bao Bao is so Zhai......");break;
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
	return 0;
}
int gj(int x){
	int i=0;
	while(x){
		i=i+x%10;
		x/=10;
	}
	if (i>=16 || i==6){
		return 1;
	}else{
		return 0;
	}
}
