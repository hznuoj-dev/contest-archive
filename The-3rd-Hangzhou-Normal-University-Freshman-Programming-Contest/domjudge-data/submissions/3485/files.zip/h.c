#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main()
{
	int t;
	int i, m, n;
	float x, y;
	float z;
	scanf("%d", &t);
	for (i = 0; i < t; i++)
	{
		scanf("%f %f", &x, &y);
		printf("[");
		for (m = 0; m < y; m++)
		{
			printf("#");
		}
		for (n = 0; n < (x-y); n++)
		{
			printf("-");
		}
		
		z = y/x*1.0;
		z = z * 100.0;
		printf("] %.0f%%\n", z);
	}
	return 0;
}