#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	int a;
	scanf("%d",&a);
	while(a--)
	{
		int i;
		float m,n;
		float sum;
		scanf("%f%f",&m,&n);
		printf("[");
		for(i=1;i<=n;i++)
		{
			printf("#");
		}
		for(i=1;i<=m-n;i++)
		{
			printf("-");
		}
		printf("] ");
		sum=n/m*100;
		printf("%.0f%%\n",sum); 
	}
 } 
