#include"stdio.h"
int main(void){
	int i,a,b,T,s,t;
	int min,max;
	scanf("%d",&T);
	while(T>0){
		scanf("%d%d",&a,&b);
		min=a;
		if(a+b>9999){
			max=9999-(a+b-9999);
		}
		else{
			max=a+b;
		}
		if(min>max){
			t=min;min=max;max=t;
		}
		s=0;
		for(i=min;i<=max;i++){
			if((i%4==0&&i%100!=0)||i%400==0){
				if(i!=0){
					s++;
				}
			}
		}
		printf("%d\n",s);
		T--;
	}
} 
