#include<stdio.h>
#include<string.h>
int main()
{
	int t,y,a,x=0,m,n,l,i;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&y,&a);
		if(a>0)
		{
		m=y;
		n=y+a;	
		}
		else
		{
		m=y+a;
		n=y;	
		}
		if(y+a>9999)
		{
			n=9999*2-y-a;
		}
		if(m>n)
		{
			n=l;
			n=m;
			m=l;
		} 
		for(i=m;i<=n;i++)
		{
		if (i%400==0||(i%4==0 && i%100!=0)) 
 	    { 
 	        x+=1;
 	    } 
		}
		if(m==0||n==0)
		{
			x-=1;
		}
		printf("%d\n",x);
		x=0;
		i=0;
	}
	return 0;
} 
