#include<stdio.h>
#include<string.h>
int main(void){
	int t,n,ans,i,j,f;
	char s[100002],b[100002];
	scanf("%d",&t);
	while(t--){
		ans=0;
		scanf("%d",&n);
		while(n--){
			j=0;
			scanf("%s",s);
			for(i=0;i<strlen(s);++i){
				if(s[i]=='.')
				continue;
				else{
				b[j]=s[i];
					for(i=0;i<strlen(b);++i){
						if(b[i]==b[j])
						f+=1;
					}
					if(f)
					continue;
					else
					j+=1;
					f=0;
				}	
			}
			ans+=j;
	}
	printf("%d",ans);
	} 
}
