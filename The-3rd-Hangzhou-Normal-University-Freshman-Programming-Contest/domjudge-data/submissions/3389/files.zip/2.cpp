#include<stdio.h>
int main()
{
	int an[10],sum,sum1=0;
	scanf("%d%d%d%d",&an[1],&an[2],&an[3],&an[4]);
	for(int i=1;i<=4;i++)
	{
		sum=0;
		while(an[i]>0)
		{
			sum=sum+an[i]%10;
			an[i]=an[i]/10;
		}
		if(sum>=16||sum==6)
		{
			sum1=sum1+1;
		}
	}
	if(sum1==1)
	{
		printf("Oh dear!!");
	}
	if(sum1==2)
	{
		printf("BaoBao is good!!");
	}
	if(sum1==3)
	{
		printf("Bao Bao is a SupEr man///!");
	}
	if(sum1==4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	if(sum1==0)
	{
		printf("Bao Bao is so Zhai......");
	}
	return 0;
 } 
