#include<stdio.h>
int main(){
int t,i,j,p;double m,n; 
char s='%';
scanf("%d",&t);
while(t--){
	scanf("%lf %lf",&n,&m);
	p=m/n*100;
	printf("[");
	for(i=1;i<=m;i++){
printf("#");
	}
	for(i=m+1;i<=n;i++){
		printf("-");
	}
	printf("] ");
	printf("%d",p);
	printf("%c",s);
	printf("\n");
}
	return 0;
}
