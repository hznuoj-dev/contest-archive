#include<stdio.h>
#include<string.h>
int main(void){

char s[1000];
//gets(s);
printf(" __      _____");
printf("\n");
printf("|  | ___/ ____\\____");
printf("\n");
printf("|  |/ /\\   __\\/ ___\\");
printf("\n");
printf("|    <  |  | \\  \\___");
printf("\n");
printf("|__|_ \\ |__|  \\___  >");
printf("\n");
printf("     \\/          \\/");
printf("\n");
return 0;
}
