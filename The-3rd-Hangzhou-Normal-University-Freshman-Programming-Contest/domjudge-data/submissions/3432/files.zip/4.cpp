#include <bits/stdc++.h>
using namespace std;
int a[114514];
int main() {
	int n,x;
	long long res=1;
	cin>>n;
	for (int i=1;i<=n;i++) {
		cin>>x;
		a[x]++;
	}
	int index=100000;
	while (a[index]==0) index--;
	for (int i=index;i>=2;i--) {
		if (a[i-1]==1) res*=1;
		else res*=a[i]*a[i-1];
		res%=998244353;
	}
	cout<<res;
}
