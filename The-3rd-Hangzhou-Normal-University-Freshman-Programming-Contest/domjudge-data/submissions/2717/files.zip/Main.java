
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		  while (sc.hasNext())
	      {
			  String a=sc.next();
			  String b=sc.next();
			  String c=sc.next();
			  String d=sc.next();
			  int A=a.length()-1;
			  int sum=0;
			  int t=0;
			  if(a.length()==1)
			  {
				  int aa=Integer.parseInt(a);
				  if(aa==6) {sum++;}
			  }
			  if(b.length()==1)
			  {
				  int bb=Integer.parseInt(b);
				  if(bb==6) {sum++;}
			  }
			  if(c.length()==1)
			  {
				  int cc=Integer.parseInt(c);
				  if(cc==6) {sum++;}
			  }
			  if(d.length()==1)
			  {
				  int dd=Integer.parseInt(d);
				  if(dd==6) {sum++;}
			  }
			  
			  ////
			  if(a.length()>1)
			  {				  			 
			  for(int i=0;i<a.length();i++)
			  {
				  int aa=Integer.parseInt(a.substring(i,i+1)); 
				  t+=aa;
			  }
			  if(t>=16||t==6)
			  {
				  sum++;
			  }
			  t=0;
			  }
			  
			  if(b.length()>1)
			  {				  			 
			  for(int i=0;i<b.length();i++)
			  {
				  int bb=Integer.parseInt(b.substring(i,i+1)); 
				  t+=bb;
			  }
			  if(t>=16||t==6)
			  {
				  sum++;
			  }
			  t=0;
			  }
			  
			  if(c.length()>1)
			  {				  			 
			  for(int i=0;i<c.length();i++)
			  {
				  int cc=Integer.parseInt(c.substring(i,i+1)); 
				  t+=cc;
			  }
			  if(t>=16||t==6)
			  {
				  sum++;
			  }
			  t=0;
			  }
			  
			  if(d.length()>1)
			  {				  			 
			  for(int i=0;i<d.length();i++)
			  {
				  int dd=Integer.parseInt(d.substring(i,i+1)); 
				  t+=dd;
			  }
			  if(t>=16||t==6)
			  {
				  sum++;
			  }
			  t=0;
			  }
			  
			  
			  
			  
			  ////
			  if(sum==0)
			  {
				  System.out.println("Bao Bao is so Zhai......");
			  }
			  if(sum==1)
			  {
				  System.out.println("Oh dear!!");
			  }
			  if(sum==2)
			  {
				  System.out.println("BaoBao is good!!");
			  }
			  
			  if(sum==3)
			  {
				  System.out.println("Bao Bao is a SupEr man///!");
			  }
			  if(sum==4)
			  {
				  System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			  }
	      }

	}

}
