#include<stdio.h>
#include<string.h>
int main()
{
    int t,n,zl[128],sum=0,zd=0;
    char lj[1000001];
    scanf("%d",&t);
    while(t>0)
    {
        scanf("%d",&n);
        while(n>0)
        {
            for(int i=33;i<=127;i++)
            {
                zl[i]=0;
            }
            scanf("%s",&lj);
                for(int t=0;t<strlen(lj);t++)
              {
                zl[lj[t]]++;
              }
            for(int i=33;i<=127;i++)
            {
                if(i==46)continue;
                if(zl[i]!=0)sum++;
            }
            zd+=sum;
            sum=0;
            n--;
        }
        printf("%d\n",zd);
        zd=0;
        t--;
    }
    return 0;
}
