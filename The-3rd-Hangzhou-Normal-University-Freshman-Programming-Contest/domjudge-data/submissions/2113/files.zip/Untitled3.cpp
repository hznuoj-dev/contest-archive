#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b;
		scanf("%d%d",&a,&b);
		printf("[");
		for(int i = 0; i<b;i++){
			printf("#");
		}
		for(int j = 0;j < (a-b);j++){
			printf("-");
		}
		printf("]");
		printf(" %2.0f%%\n", (b*100.0)/(a*1.0));
	}
}
