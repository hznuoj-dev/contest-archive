#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
int main(){
	int n;
	scanf("%d",&n);
	int sum=0;
	while(n--){
		
		char s[100001];
		scanf("%s",s);
		int len=strlen(s);
		sum+=len;
	}
	printf("%d",sum);
}
