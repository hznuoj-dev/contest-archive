#include<stdio.h>
#include<math.h>
#include<string.h>

int main()
{
	int t;
	long long int n, m;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lld%lld",&n,&m);
		printf("[");
		for(int i=0;i<m;++i)
			printf("#");
		for(int i=0;i<n-m;++i)
			printf("-");
		printf("] %d",m*100/n);
		printf("%%\n");
		
	}
	return 0;
} 
