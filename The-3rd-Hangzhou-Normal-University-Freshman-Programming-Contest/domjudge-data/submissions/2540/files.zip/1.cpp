#include<stdio.h>
#include<math.h>
#include<string.h>
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
	    int n,a[100000],i,j,sum=0;
	    char s[1000000];
		scanf("%d",&n);
		while(n--){
			scanf("%s",s);
			for (i=0;i<strlen(s);i++){
				int f=1;
				for (j=0;j<i;j++){
					if (s[j]==s[i]) {
						f=0;break;
					}
				}
				if (s[i]!='.'&&f) sum++;
			}
		}
		printf("%d\n",sum);
	} 
	
	
	
	return 0;
}


  
