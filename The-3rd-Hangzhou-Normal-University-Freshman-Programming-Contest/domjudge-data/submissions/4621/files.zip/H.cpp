#include <stdio.h>
int main(){
	int T,i;
	int a,b;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&a,&b);
		for(i=1;i<=a;i++){
			if(i==1){
				printf("[");
			}
		    if(i<=b){
				printf("#");
			}
			if(i>b){
				printf("-");
			}
			if(i==a){
         	printf("] %d%%\n",b*100/a);
			}
		}
	}
	return 0;
}
