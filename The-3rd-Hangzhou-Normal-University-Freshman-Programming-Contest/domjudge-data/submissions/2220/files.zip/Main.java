package ����ʦ����Ŀ;

import java.util.Scanner;
public class BBM������
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			int t=in.nextInt();
			for(int i=0;i<t;i++)
			{
				int x=0;
				int y1=in.nextInt();
				int y2=in.nextInt();
				int y3=y1+y2;
				if(y3>=10000)
				{
					y3=9999-(y3-9999);
				}
				if(y3<y1)
				{
					int p=y1;y1=y3;y3=p;
				}
				for(int j=y1;j<=y3;j++)
				{
					if(j%4==0 && j%100!=0 || j%400==0)
					{
						x+=1;
					}
				}
				System.out.println(x);
			}
		}
	}
}
