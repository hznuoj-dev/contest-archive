#include<stdio.h>
int whether(int s);
int a[100], b[100];
int n, m;
int main(){
	scanf("%d%d", &n, &m);
	for(int i=0;i<n;++i){
		scanf("%d", &a[i]);
	}
	for(int i=0;i<n;++i){
		scanf("%d", &b[i]);
	}
	int sum=0;
	for(int s=0;s<m;++s){
		if(whether(s)==1){
			sum++;
		}
	}
	printf("%d", sum);
	return 0;
}
int whether(int s){
	int i=n, j=n;
	while(i>=0){
		j=b[i];
		while(j>0){
			if(s>a[i]&&j>0){
				s-=a[i];
				j--;
			}
			else
				i--;
				break;
		}
	}
	if(s>0){
		return 0;
	}
	else
		return 1;
}
