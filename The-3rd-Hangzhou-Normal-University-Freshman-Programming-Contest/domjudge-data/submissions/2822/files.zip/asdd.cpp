#include<stdio.h>
int main(){
	int n,x,y,max,min,i,count=0;
	scanf("%d",&n);
	while(n--){
		scanf("%d%d",&x,&y);
		if(x+y>9999)
		y=9999-(x+y-9999);
		else
		y=x+y;
		if(x>y)
		{max=x;
		min=y;
		}
		else
		{max=y;
		min=x;
		}
		for( i=min;i<=max;i++)
		{
			if(i%4==0&&i%100!=0||i%400==0)
			count++;
		}
		printf("%d\n",count);
		count=0;
	}
	return 0;
	
} 
