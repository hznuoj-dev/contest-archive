#include<stdio.h>
#include<math.h>
#include<string.h>
int main(void){
	long long a,b,c,d;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	int n=0;
	int sum=0; 
	while(a>0){
		sum+=a%10;
		a=a/10;
		
	}
	if (sum>=16||sum==6) n++;
	
    sum=0; 
	while(b>0){
		sum+=b%10;
		b=b/10;
		
	}
	if (sum>=16||sum==6) n++;
	
	sum=0; 
	while(c>0){
		sum+=c%10;
		c=c/10;
		
	}
	if (sum>=16||sum==6) n++;
	
	sum=0; 
	while(d>0){
		sum+=d%10;
		d=d/10;
		
	}
	if (sum>=16||sum==6) n++;
	
	if (n==0) printf("Bao Bao is so Zhai......");
	if (n==1) printf("Oh dear!!");
	if (n==2) printf("BaoBao is good!!");
	if (n==3) printf("Bao Bao is a SupEr man///!");
	if (n==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
	
	
	return 0;
}


  
