#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		float a,b;
		int x,y;
		scanf("%f%f",&a,&b);
		printf("[");
		for(x=1;x<=b;x++){
			printf("#"); 
		}
		for(x=1;x<=(a-b);x++){
			printf("-"); 
		}
		printf("]");
		printf("%.0f%%\n",b/a*100);
	}
	return 0;
}
