//
// Created by Kyooma on 2020/12/13.
//
#include <bits/stdc++.h>
using namespace std;
int f[1009];
struct p{
    int num;
    int dip;
};
p p1[1009];
vector<int> g[1009];
void dfs(int a){
    p1[a].dip=p1[f[a]].dip+1;
    for(int i=0;i<g[a].size();i++){
        int v=g[a][i];
        dfs(v);
    }
}
bool com(p a,p b){
    if(a.dip!=b.dip) return a.dip>b.dip;
    return a.num<b.num;
}
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,m,k;
        scanf("%d%d",&n,&m);
        for(int i=0;i<=n;i++){
            g[i].clear();
            p1[i].num=i;
            p1[i].dip=0;
            f[i]=0;
        }
        for(int i=0;i<m;i++){
            int x,y;
            scanf("%d%d",&x,&y);
            f[x]=y;
            g[y].push_back(x);
        }
        for(int i=1;i<=n;i++){
            if(!f[i]){
                k=i;
                break;
            }
        }
        dfs(k);
        sort(p1+1,p1+n+1,com);
        for(int i=1;i<=n;i++){
            printf("%d%c",p1[i].num,i==n?'\n':' ');
        }

    }
}
