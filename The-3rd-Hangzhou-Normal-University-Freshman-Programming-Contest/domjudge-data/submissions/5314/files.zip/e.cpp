#include<string.h>
#include<stdio.h>
int main()
{
	int t,n;
	char a[1000000],b[1000001];
	scanf("%d",&t);
	while(t--)
	{
		int num=0;
		scanf("%d",&n);
		while(n--)
		{
			int i,j;
			scanf("%s",a);
			int len =strlen(a);
			for(i=0;i<len;++i)
			{
				int flag=0;
				b[i+1]=a[i];
				for(j=1;j<=i;++j)
				{
					if(a[i]==b[j])
						flag=1;
				}
				if(a[i]!='.'&&flag==0)
					num=num+1;
			}
		}
		printf("%d",num);
	}
}