#include <stdio.h>
#include <stdlib.h>
int she(double n){
	int s;
	s=n;
	if(n-s>=0.5)
		return s+1;
	else if(n-s<0.5)
		return s;
}
int main(void){
	int t;
	double n,m,a,s;
	scanf("%d",&t);
	while(t--){
		scanf("%lf%lf",&n,&m);
		a=n-m;
		s=m/n*100;
		printf("[");
		while(m--){
			printf("#");
		}
		while(a--){
			printf("-");
		}
		printf("] %d%%\n",she(s));
	}
	
	
	return 0;
}
