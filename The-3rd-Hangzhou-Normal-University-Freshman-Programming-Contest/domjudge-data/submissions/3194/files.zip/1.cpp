#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int lv(a)
{
	int a1, sum = 0;
	if (a < 10)
	{
		if (a == 6)
		{
			return 1;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		while (a >= 10)
		{
			a1 = a % 10;
			sum += a1;
			a /= 10;
		}
		sum += a;
		if (sum >= 16 || sum == 6)
		{
			return 1;
		}
		else
		{
			return 0;
		}

	}
}
int main()
{
	int a, b, c, d, sum = 0;
	scanf("%d %d %d %d", &a, &b, &c, &d);
	sum += lv(a);
	sum += lv(b);
	sum += lv(c);
	sum += lv(d);
	if (sum == 0)
	{
		printf("Bao Bao is so Zhai......");
	}
	else if (sum == 1)
	{
		printf("Oh dear!!");
	}
	else if (sum == 2)
	{
		printf("BaoBao is good!!");
	}
	else if (sum == 3)
	{
		printf("Bao Bao is a SupEr man///!");
	}
	else if (sum == 4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	return 0;
}