#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long int a,b,c,d;
	cin>>a>>b>>c>>d;
	int sum1=0,sum2=0,sum3=0,sum4=0;
	while(a)
	{
		sum1+=a%10;
		a/=10;
	}
	while(b)
	{
		sum2+=b%10;
		b/=10;
	}
	while(c)
	{
		sum3+=c%10;
		c/=10;
	}
	while(d)
	{
		sum4+=d%10;
		d/=10;
	}
	int count=0;
	if(sum1>=16) count++;
	if(sum2>=16) count++;
	if(sum3>=16) count++;
	if(sum4>=16) count++;
	if(count==1) cout<<"Oh dear!!";
	if(count==2) cout<<"BaoBao is good!!";
	if(count==3) cout<<"Bao Bao is a SupEr man///!";
	if(count==4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
	if(count==0) cout<<"Bao Bao is so Zhai......";
}

