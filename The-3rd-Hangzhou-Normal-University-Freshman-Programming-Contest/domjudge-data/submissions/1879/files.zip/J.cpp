#include<iostream>
#include<string>
#include<map>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
map<char,int>mp;
int main(){
	fcio;
	int T;
	while(cin>>T){
		while(T--){
			int n;
			cin>>n;
			int num=0;
			for(int i=0;i<n;++i){
				string s;
				cin>>s;
				mp.clear();
				for(int j=0;j<s.length();++j){
					if(s[j]!='.'&&!mp[s[j]]){
						mp[s[j]]=1;
					}
				} 
				num+=mp.size();
			} 
			cout<<num<<endl;
		}
	}
}

