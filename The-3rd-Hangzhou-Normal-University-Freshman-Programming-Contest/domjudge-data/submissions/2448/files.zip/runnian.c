#include"stdio.h"
int main()
{
int a;
if(scanf("%d",&a)){
while(a--)
{
	int b,c,i,d=0;
	if(scanf("%d%d",&b,&c)){
	if(b<=c){
	if(c>9999)
	c=b+(c-9999);
	for(i=b;i<=c;++i)
	{
		if((i%4==0&&i%100!=0)||(i%400==0))
		++d;
	}
	} 
	else
	{
	c=b+c;
	if(b<=c){
	if(c>9999)
	c=b+(c-9999);
	for(i=b;i<=c;++i)
	{
		if((i%4==0&&i%100!=0)||(i%400==0))
		++d;
	}
	} 
	else
	{
		int t=0;
		t=c;
		c=b;
		b=t;
		if(c>9999)
	c=b+(c-9999);
		for(i=b;i<=c;++i)
	{
		if((i%4==0&&i%100!=0)||(i%400==0))
		++d;
	}
	}
	}
	printf("%d\n",d);
}
}
}
return 0;
 }
