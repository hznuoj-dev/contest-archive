#include<stdio.h>
int main()
{
    int t,n,a,b,i,linka,linkb;
    long m;
    scanf("%d\n",&t);
    while(t--)
    {
        int link[1001],*p=link;
        scanf("%d %ld\n",&n,&m);
        for(i=1;i<=n;i++){*(p+i)=i;}
        while(m--)
        {
            linka=0;linkb=0;
            scanf("%d %d\n",&a,&b);
            for(i=n;i>=1;i--)
            {
                if(*(p+i)==a)linka=i;
                if(*(p+i)==b){linkb=i;break;}
                if(i<=linka)
                {
                    *(p+i)=*(p+i-1);
                }
            }
            if(linka>linkb)*(p+linkb)=a;
        }
        printf("%d",link[1]);
        for(i=2;i<=n;i++){printf(" %d",*(p+i));}
        printf("\n");
    }
}


