#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
const int MAX=1e5+10;
int cishu[MAX];
int a[MAX];
int main()
{
	int n,cnt=1;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int temp;
		scanf("%d",&temp);
		cishu[temp]++;
		a[i]=temp;
	}
	sort(a+1,a+n+1);
	for(int i=2;i<=n;i++)
	{
		if(cishu[a[i]-1])
			cnt+=cishu[a[i]-1]-1;
	}
	printf("%d",cnt);
}
