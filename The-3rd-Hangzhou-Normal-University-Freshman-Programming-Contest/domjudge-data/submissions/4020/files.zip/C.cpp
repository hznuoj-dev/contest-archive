#include<bits/stdc++.h>
using namespace std;
int a[100005];
long long int ca(int x,long long y)
{
	long long sum=y;
	int i=1;
	while(i<=a[x])
	{
		sum=sum*a[x-1];
		sum%=998244353;
		i++;
	}
	return  sum%998244353;
}
int main()
{
	int n;int max=0;
	cin>>n;
	while(n)
	{
		int  x;
		cin>>x;
		if(x>max) max=x;
		a[x]++;
		n--;
	}
	long long sum=1;
	if(max!=1)
	{
		int i=2;
		while(i<=max)
		{
			sum=ca(i,sum);
			i++;
		}
	}
	cout<<sum;
}

