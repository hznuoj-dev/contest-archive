#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
using namespace std;
int f(int a);
int main(){
	int n,a,b,c=0,i,t,s,k=0;
	scanf("%d",&n);
	while(n--){
		s=0;
		scanf("%d %d",&a,&b);
		c=a+b;
		if(c>9999){
			c=9999-(c-9999);
		}
		if(a>c){
			t=a;a=c;c=t;
		}
		for(i=a;i<=c;i++){
			if(i==0)continue;
			if(f(i)==1)s++;
		}
		printf("%d\n",s);
	}
} 
int f(int a){
	int b;
	b=abs(a);
	if(b%4==0&&b%100!=0||b%400==0){
		return 1;
	}else{
		return 0;
	}
}
