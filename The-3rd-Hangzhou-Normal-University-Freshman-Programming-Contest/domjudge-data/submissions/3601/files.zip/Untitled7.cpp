#include <stdio.h>
int main(void){
	int T;
	scanf("%d",&T);
	while(T--){
		int n,m;
		double x;
		char y='%' ;
		scanf("%d %d",&n, &m);
		x=m*100/n;
		printf("[");
		for(int i=0;i<m;i++){
			printf("#");
		}
		for(int j=m;j<n;j++){
			printf("-");
		}
		printf("] ");
		printf("%.0f%c\n",x,y);
	} 
	return 0;
}
