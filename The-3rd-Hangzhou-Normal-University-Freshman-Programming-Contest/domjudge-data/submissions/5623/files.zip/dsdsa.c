#include<stdio.h>
int main()
{
	int t,m,i,j,n;
	char a[100002], b[100002];
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d %d", &m, &n);
		for (i = 0; i < n; i++)
		{
			a[i] = '#';
		}
		for (j = 0; j < m-n; j++)
		{
			b[j] = '-';
		}
		a[n] = '\0';
		b[m-n] = '\0';
		if(m!=0)printf("[%s%s] %.0f%%\n", a, b, (n*1.0 / m) * 100);
		else printf("[%s%s] 0%\n", a, b);
	}
	return 0;
}
