#include<stdio.h>
#include<string.h>
int main(void){
	int T=0;
	scanf("%d",&T);
	while(T--){
		int n=0,t=0,m=0;
		char c[10000000];
		scanf("%d",&n);
		for(m=0;m<n;++m){
			int b=0,i=0,j=0;
			gets(c);
			gets(c);
			b=strlen(c);
			for(i=0;i<b;++i){
				for(j=0;j<b;++j){
					if(c[i]!='.'&&c[i]!=c[j])t=t+1;
				}
			}
		}
		printf("%d\n",t);
	}
	return 0;
}