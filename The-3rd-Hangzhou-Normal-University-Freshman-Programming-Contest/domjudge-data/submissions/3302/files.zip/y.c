#include<stdio.h>
#include<string.h>

int cmp(const void *a,const void *b){
	//ǿ������ת��
	return (*(char *)a)-(*(char *)b);  
} 
int main(){
	int n,m;
	scanf("%d",&n);
	int c=0,i,j,o=0,t;
	char s[1000],b[1000];
	while(n--){
		scanf("%d",&m);
		for (i=0;i<m;i++){
			scanf("%s",&s);
			int k=strlen(s);
			for (j=0;j<k;j++){
				if (s[j]!='.'){
					b[c]=s[j];
					c++;
				}
		   }
		qsort(b,c,sizeof(b[0]),cmp);
		o=1;
		for (t=0;t<c;t++){
		   		if (b[t]!=b[t+1] && b[t+1]!=NULL){
		   			o++;
				}
			}
		}
		printf("%d\n",o);
		c=0;
	}
}
