#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b,d,s=0;
		scanf("%d %d",&a,&b);
		int c=a+b;
		if(c>9999){
			b=9999-(c-9999);
		} else b=a+b;
		if(a>b){
			d=a;
			a=b;
			b=d;
		}
		for(int i=a;i<=b;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				s++;
			}
		}
		 printf("%d\n",s);
	}
}
