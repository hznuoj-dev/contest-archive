#include<stdio.h>
#include<string.h>
int main(){
	int t,n,i,j,k;
	int sum,a;
	char s[1000001],ch[1000001]={0};
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d",&n);
		getchar();
		for(i=0;i<n;i++){
			a=0;
			scanf("%s",s);
			getchar();
			for(j=0;j<strlen(s);j++){
				if(s[j]!='.'){
					for(k=0;k<a;k++){
						if(s[j]==ch[k])break; 
					}
					if(k==a)
						ch[a++]=s[j];
				}
			}
			for(k=0;k<a;k++){
				ch[i]='.';
			}
			sum+=a;
		}
		printf("%d\n",sum);
	}
	return 0;
} 
