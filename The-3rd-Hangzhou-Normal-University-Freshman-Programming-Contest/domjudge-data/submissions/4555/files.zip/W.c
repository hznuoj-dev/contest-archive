#include<stdio.h>
int main(){
	int m,n,T,x,y,num;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&m);
		printf("[");
		for(x=1;x<=m;x++)
			printf("#");
		for(y=m+1;y<=n;y++)
			printf("-");
		printf("] ");

		num=(m/(n*1.0))*100;
		printf("%d%%\n",num);
	}
	return 0;
}
