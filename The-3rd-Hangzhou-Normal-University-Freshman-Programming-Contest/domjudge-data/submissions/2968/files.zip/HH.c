#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,n,m,a,i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		a=m*100/n;
		printf("[");
		for(j=0;j<m;j++){
			printf("#");
		}
		for(i=0;i<n-m;i++){
			printf("-");
		}
		printf("] ");
		printf("%d%%\n",a);
	}
	return 0;
}

