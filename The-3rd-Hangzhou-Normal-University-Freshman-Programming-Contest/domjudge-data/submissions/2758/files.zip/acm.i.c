#include<stdio.h>
int main(){
	long long a,b,c,d;
	int s1=0,s2=0,s3=0,s4=0;
	int f=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>0){
		s1+=a%10;
		a=a/10;
	}
	while(b>0){
		s2+=b%10;
		b=b/10;
	}
	while(c>0){
		s3+=c%10;
		c=c/10;
	}
	while(d>0){
		s4+=d%10;
		d=d/10;
	}
	if(s1==6||s2>=16){
		f+=1;
	}
	if(s2==6||s2>=16){
		f+=1;
	}
	if(s3==6||s3>=16){
		f+=1;
	}
	if(s4==6||s4>=16){
		f+=1;
	}
     if(f==1) printf("Oh dear!!\n");
     if(f==2) printf("BaoBao is good!!\n");
     if(f==3) printf("Bao Bao is a SupEr man///!\n");
     if(f==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
     if(f==0) printf("Bao Bao is so Zhai......\n");
     return 0;
}
