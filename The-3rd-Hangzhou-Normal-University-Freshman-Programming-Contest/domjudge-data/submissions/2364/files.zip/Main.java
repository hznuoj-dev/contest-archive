package ft;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
        Scanner x=new Scanner(System.in);
		while(x.hasNext())
		{
			String g[]= {"Bao Bao is so Zhai......","Oh dear!!","BaoBao is good!!","Bao Bao is a SupEr man///!","Oh my God!!!!!!!!!!!!!!!!!!!!!"};
			int s[]=new int[4];
			for(int i=0;i<s.length;i++)
			{
				s[i]=x.nextInt();
			}
			int a=0;
			int m=0;
			int b=0;
			for(int i=0;i<s.length;i++)
			{
				m=s[i];
				a=0;
				while(m>0)
				{
					a=a+m%10;
					m=m/10;
				}
				if(a>=16 || a==6)
				{
					b=b+1;
				}
			}
			System.out.println(g[b]);
		}

	}

}
