#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(){
	
	scanf("kfc");
	printf("__ _____\n\n| | ___/ ____\\____\n\n| |/ /\\ __\\/ ___\\\n\n| < | | \\ \\___\n\n|__|_ \\ |__| \\___ >\n\n     \\/         \\/\n");
} 
