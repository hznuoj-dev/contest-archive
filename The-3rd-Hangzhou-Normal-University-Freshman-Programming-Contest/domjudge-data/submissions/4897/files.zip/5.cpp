#include<bits/stdc++.h>
using namespace std;
int main()
{
    int t,n;
    cin>>t;
    for(int i=0;i<t;i++)
    {
        int coun=0;
        cin>>n;
        for(int z=0;z<n;z++)
        {
            char a[1000000];
            int len;
            scanf("%s",a);
            len=strlen(a);
              sort(a,a+len);
              for(int j=0;j<len;j++)
               {
                 if(j==0)
                   {
                      if(a[j]!='.')
                       coun++;
                    }
                else
                 {
                 if(a[j]!='.'&&a[j]!=a[j-1])
                    coun++;
                 }
               }
        }
        printf("%d\n",coun);
    }
    return 0;
}
