#include<bits/stdc++.h>
using namespace std;

int main(void){

    int a[5];
    string s;
    int times = 0;
    for(int i = 1;i <= 4;i++){
        cin >> s;
        int sum = 0,j = 0;
        while(s[j] != '\0') sum += (s[j] - '0'),j++;
        if(sum >= 16 || sum == 6) times++;
    }
    if(times == 0) cout << "Bao Bao is so Zhai......";
    else if(times == 1) cout << "Oh dear!!";
    else if(times == 2) cout << "BaoBao is good!!";
    else if(times == 3) cout << "Bao Bao is a SupEr man///!";
    else cout << "Oh my God!!!!!!!!!!!!!!!!!!!!!";

    return 0;
}