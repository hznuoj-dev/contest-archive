


#include<stdio.h>
#include<string.h>
int main()
{
	int T,a,b;
	float f;
	int i;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&a,&b);
		printf("[");
		for(i=1;i<=b;i++)
			printf("#");
		for(i=1;i<=a-b;i++)
			printf("-");
		f=b*(1.0)/a*100;
		printf("] %.0f%\n",f);
	}
	return 0;
}

