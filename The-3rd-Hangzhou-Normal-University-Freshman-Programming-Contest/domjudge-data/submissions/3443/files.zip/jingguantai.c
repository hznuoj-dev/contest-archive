#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
int a[18],b[18],c[18],d[18];

int t1=0,t2=0,t3=0,t4=0,i=0,sum=0;
scanf("%d%d%d%d",&a[18],&b[18],&c[18],&d[18]);
for(i=0;i<18;i++){
	t1+=a[i];
	if(t1>=16||t1==6)
	sum+=1;
	else
	sum+=0;
}
for(i=0;i<18;i++){
	t2+=b[i];
	if(t2>=16||t2==6)
	sum+=1;
	else
	sum+=0;
}
for(i=0;i<18;i++){
	t3+=c[i];
	if(t3>=16||t3==6)
	sum+=1;
	else
	sum+=0;
}
for(i=0;i<18;i++){
	t4+=d[i];
	if(t4>=16||t4==6)
	sum+=1;
	else
	sum+=0;
}

if(sum=0)
printf("Bao Bao is so Zhai......\n");
else if(sum=1)
printf("Oh dear\!\! \n");
else if(sum=2)
printf("BaoBao is good\!\! \n");
else if(sum=3)
printf("Bao Bao is a SupEr man\/\/\/\!\n");
else if(sum=4)
printf("Oh my God\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!\!");
	return 0;
}
