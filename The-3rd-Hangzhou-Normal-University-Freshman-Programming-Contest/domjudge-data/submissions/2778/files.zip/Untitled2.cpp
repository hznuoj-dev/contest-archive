#include <stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996) 
int main(){
	int a,b,s=0;
	for(int i=0;i<4;i++){
		scanf("%d",&a);
		b=0;
		while(a){
			b+=a%10;
			if(b==6){
			   s++;
			   break;
			}
			a=a/10;
			if(b>16||b==6){
			   s++;
			   break;
			}
		}
		
	}
	if(s==0){
		printf("Bao Bao is so Zhai......\n");
	}
	if(s==1){
		printf("Oh dear!!\n");
	}
	if(s==2){
		printf("BaoBao is good!!\n");
	}
	if(s==3){
		printf("Bao Bao is a SupEr man///!\n");
	}
	if(s==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
}
/*struct tijiao{
	int a;
	int b;
	int c;
	char d;
	char e;
}q[100001];
int paiming
void printft(int a,int b,int c){
	if(a==0){
		
	}
}
int main(){
	int n,t,m,p,w,i,j;
	char a[6][20]={"teamstatus","minrank","maxrank","account","submitcount","teamcount"};
	char b[20];
	scanf("%d %d %d %d",&n,&t,&m,&p);
	for(int i=0;i<m;i++){
		scanf("%d %d %d %c%c",&q.a,&q.b,&q.a,&q.c,&q.d,&q.e)
	}
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			if(q[j].c>q[j+1].c)
			q[100001]=q[j],q[j]=q[j+1],q[j+1]=q[100001];
		}
	}
	scanf("%d",&w);
	while(w--){
		scanf("%s%d %d",b,&i,&j);
		for(o=0;o<=5;o++){
			if(strcmp(a[o],b)==0)
			break;
		}
		printft(o,i,j);
		memset(b,0,sizeof(b));
	}
} */

