#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	char a[20],b[20],c[20],d[20];
	scanf("%s %s %s %s",a,b,c,d);
	int ta=strlen(a),tb=strlen(b),tc=strlen(c),td=strlen(d);
	int i,sum[4]={0},t[4]={0},cnt=0;
	for(i=0;i<ta;i++)
		sum[0]+=a[i]-'0';
	for(i=0;i<tb;i++)
		sum[1]+=b[i]-'0';
	for(i=0;i<tc;i++)
		sum[2]+=c[i]-'0';
	for(i=0;i<td;i++)
		sum[3]+=d[i]-'0';
	for(i=0;i<4;i++)
	{
		if(sum[i]>=16||sum[i]==6) t[i]=1;
	}
	for(i=0;i<4;i++)
	{
		if(t[i]==1)
		cnt++;
	}
	switch(cnt)
	{
	   case 0:printf("Bao Bao is so Zhai......");break;
	   case 1:printf("Oh dear!!");break;
	   case 2:printf("BaoBao is good!!");break;
	   case 3:printf("Bao Bao is a SupEr man///!");break;
	   case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;	
	}
	return 0;
}
