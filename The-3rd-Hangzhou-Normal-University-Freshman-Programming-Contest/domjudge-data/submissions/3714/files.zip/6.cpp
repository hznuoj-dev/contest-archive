#include<stdio.h>
int main()
{
	int t,year,n,i,m;
	scanf("%d",&t);
	while(t--)
	{
		int sum=0,min,max;
		scanf("%d%d",&year,&n);
		m=year+n;
		if(m<=9999)
		{
			if(m<year)
		{
			min=m;max=year;
		}
		else
		{
			min=year;max=m;
		}
		for(i=min;i<max;++i)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
			sum++;
		}
		printf("%d\n",sum);
		}
		
	}
	return 0;
}


