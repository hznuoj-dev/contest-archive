#include<stdio.h>
#include<stdlib.h>
int main (void){
	int t,n,m,a,b,i,j,x=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
	int c[n];
		for(i=0;i<n;i++)
		c[i]=0;
		while(m--){
			scanf("%d%d",&a,&b);
			c[b-1]++;
		}
		for(i=0;i<n;i++){
        for(j=0;j<n;j++){
        if(c[j]==x)
		printf("%d",j+1);
		}
		x++;
		}
        
}
return 0;	}

