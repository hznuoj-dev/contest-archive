#include<stdio.h>
#include<string.h>
int main(){
    int T,f,len,d,sum;
    char s[100010],q[100010];
    scanf("%d",&T);
    while(T--){
    	sum=0;
    	scanf("%d",&f);
    	while(f--){
    		d=0;
    		scanf("%s",s);
    		len=strlen(s);
    		for(int i=0;i<len;i++){
    			if(s[i]!='.') {
				    d++;q[d]=s[i];
    				for(int j=0;j<d;j++){
    					if(s[i]==q[j]) {
    						d--;break;
						}
					}
    				
				}
			}
			sum+=d;
		}
		printf("%d\n",sum);
	}
    return 0;
}
