#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main(void){
	int t,i,s,s1,y,a,p;
	scanf("%d",&t);
	while(t--){
		s=0;
		scanf("%d%d",&y,&a);
		s1=y+a;
		if(s1>9999){
			p=s1-9999;
			s1=9999-p;
		}
		if(y<=s1){
			for(i=y;i<=s1;++i){
				if(i%4==0&&i%100!=0||i%400==0)
					s=s+1;
				
			}
		}
		else{
			for(i=s1;i<=y;++i){
				if(i%4==0&&i%100!=0||i%400==0)
					s=s+1;
				
			}
		}
		printf("%d",s);
	}
	
	
	return 0;
}
