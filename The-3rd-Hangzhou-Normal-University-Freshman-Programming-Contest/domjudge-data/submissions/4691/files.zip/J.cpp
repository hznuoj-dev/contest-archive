#include<stdlib.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdio.h>


int main()
{
 int n, sum = 0,sumcen=0;
 int laji[128] = { 0 };
 char a;
 scanf("%d", &n);
 int cen;
 for (int k = 1; k <= n; k++) {
  scanf("%d", &cen);
  getchar();
  for (int j = 1; j <= cen; j++) {
   while (scanf("%c", &a), a != '\n') {
    if (a != '.'&&a!='\n')
     laji[(int)a] = 1;
   }
   for (int i = 0; i <= 127; i++) {

    if (laji[i] != 0)sum++;
   }
   sumcen += sum;
   sum = 0;
   for (int i = 0; i <= 127; i++) {

    laji[i] = 0;
   }
  }
  
  printf("%d\n", sumcen);
  sumcen = 0;
 }
 return 0;
}
