#include<stdio.h>
int main()
{
	int a, b, c, d;
	int atemp=0, btemp=0, ctemp=0, dtemp=0;
	int sum;
	sum = 0;
	scanf("%d %d %d %d", &a, &b, &c, &d);
	while (a > 0)
	{
		atemp += a % 10;
		a = (a - a % 10) / 10;
	}
	if (atemp >= 16 || atemp == 6)
		sum++;
	while (b > 0)
	{
		btemp += b % 10;
		b = (b - b % 10) / 10;
	}
	if (btemp >= 16 || btemp == 6)
		sum++;
	while (c > 0)
	{
		ctemp += c % 10;
		c = (c - c % 10) / 10;
	}
	if (ctemp >= 16 || ctemp == 6)
		sum++;
	while (d > 0)
	{
		dtemp += d % 10;
		d = (d - d % 10) / 10;
	}
	if (dtemp >= 16 || dtemp == 6)
		sum++;
	if (sum == 0)
		printf("Bao Bao is so Zhai......");
	else if (sum == 1)
		printf("Oh dear!!");
	else if (sum == 2)
		printf("BaoBao is good!!");
	else if (sum == 3)
		printf("Bao Bao is a SupEr man///!");
	else
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
}