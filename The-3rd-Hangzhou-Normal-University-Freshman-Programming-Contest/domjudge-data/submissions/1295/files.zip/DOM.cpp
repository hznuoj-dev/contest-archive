#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int main(){
    char a[5];
    scanf("%s",a);
    if(a[0]=='k'){
        cout << " __      _____" << endl;
        cout << "|  | ___/ ____\\____"<<endl;
        cout << "|  |/ /\\   __\\/ ___\\" << endl;
        cout << "|    <  |  | \\  \\___" << endl;
        cout << "|__|_ \\ |__|  \\___  >" << endl;
        cout << "     \\/           \\/" << endl;
    }
    return 0;
}
    

