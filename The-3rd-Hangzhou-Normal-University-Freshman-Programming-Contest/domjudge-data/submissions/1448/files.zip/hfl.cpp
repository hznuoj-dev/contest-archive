#include<stdio.h>
#include<stdlib.h>
int main(void)
{
   int n,l,r,i,j,c,a,b,sum=0;
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
   		scanf("%d %d",&a,&b);
   		if(a>b)
   		{
   			c=a+b;
   			if(c>=9999)
   			{
   				c=c-9999;
   				l=a;
   				r=9999-c;
   			}
   			else if(c<9999)
   			{
   				l=c;
   				r=a;
   			}
   		}
   		else
   		{
   			l=a;
   			r=b;
		}
	sum=0;	
   	for(j=l;j<=r;j++)
   	{
   		if ((j%4==0)&&(j%100!=0)||(j%400==0))
   			sum++;
	}
	printf("%d\n",sum);
	}
	return 0;
}

