#include<stdio.h>
int main(){
	int T,n,m;
	int x;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&m);
		x=100*m/n;
		printf("[");
		for(int i=0;i<m;i++){
			printf("#");
		}
		for(int i=n-m;i>0;i--)
		printf("-");
		printf("] ");
		printf("%d%%\n",x);
	}
}
