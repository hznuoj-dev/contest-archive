#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t,n,m,a,i,bfb,k; 
	    
	    while(~scanf("%d",&t)){
	    	k=1;
	    	while(t--){
	    		scanf("%d %d",&n,&m);
	    		bfb=100*m/n;
	    		if(k==0) printf("\n");
	    		printf("[");
	    		for(i=0;i<m;i++){
	    			printf("#");
				}
				for(i=0;i<n-m;i++){
	    			printf("-");
				}
				printf("] %d%%",bfb); 
			k=0;
			}
		}
	    
	    
	return 0;
} 
