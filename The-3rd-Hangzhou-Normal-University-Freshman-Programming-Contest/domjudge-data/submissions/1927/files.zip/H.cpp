//
// Created by Kyooma on 2020/12/13.
//
#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    while(t--){
        int x,y;
        double k;
        string s="";
        cin>>x>>y;
        k=100.0*y/x;
        for(int i=0;i<x;i++){
            if(i<y) s+="#"; else s+="-";
        }
        cout<<"["<<s<<"] ";
        printf("%.0lf%%\n",k);
    }
}