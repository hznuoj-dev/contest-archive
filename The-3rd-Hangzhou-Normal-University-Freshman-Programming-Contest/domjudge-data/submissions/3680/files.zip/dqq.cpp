#include<stdio.h>
#include<string.h>
int main(void)
{
	int T,i,n,m;
	float t;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
		{
			printf("#");
		}
		for(i=1;i<=(n-m);i++)
		{
			printf("-");
		}
		printf("] ");
		t=(m*1.0)/n*100;
		printf("%d",(int)t);
		printf("%%\n");
	}
	return 0;
}
