#include <stdio.h>
 int main(){
 	int repeat;
	 scanf("%d",&repeat);
	 while(repeat--){
	 	int i,j,a,sum=0,b,t;
	 	scanf("%d%d",&i,&a);
	 	b=i+a;
	 	if(b<i) {t=b;b=i;i=t;}
	 	if(b>9999) b=9999; 
	 	for(j=i;j<=b;j++){
	 		if(j%4==0&&j%100!=0||j%400==0) sum++;	
		 }
	 	
	 	printf("%d\n",sum);
	 	
	 	
	 } 
	 return 0;
 	
 
}
