#include<stdio.h>
#include<string.h>
#define max 1000001
int main(){
	int t,n;
	char a[max],b[max];
	int len,i,j,s=0,m,k;
	int count;
	scanf("%d",&t);
	while(t--){
		s=0;
		scanf("%d",&n);
		while(n--){
			for(i=0;i<max;i++){
				b[i]='.';
			}
			scanf("%s",a);
			len=strlen(a);
			count=0;
			m=0;
			for(i=0;i<len;i++){
				if(a[i]!='.'){
					for(j=0;j<=m;j++){
						if(a[i]==b[j]){
							break;
						}
					}
					if(j>m){
						k=0;
						while(b[k]!='.'){
							k+=1;
						}
						b[k]=a[i];
						count+=1;
					}
					m=k;
				}
			}
			s+=count;
		}
		printf("%d\n",s);
		s=0;
	}
} 
