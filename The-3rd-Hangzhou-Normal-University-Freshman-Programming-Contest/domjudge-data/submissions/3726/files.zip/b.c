#include <stdio.h>
int main() {
	int t;
	scanf("%d", &t);
	int a, b, c;//a�ǵ�һ�����
	int cont = 0;
	int a_2;
	int j;
	while(t--) {
		scanf("%d %d", &a, &b);
		int sum = 0;
		if (b < 0) {
			b = -b;
			c = a - b;
			if (c < 10000) a_2 = c;
		else {
			while (c >= 10000) {
			cont++;
			c--;
			}
			a_2 = 9999 - cont;// a_2�ǵڶ������ 
	        }
		//���Եõ�����[a_2, a]
		for (j = a_2; j <= a; j++) {
			if ((j % 4 == 0 && j % 100 != 0) || j % 400 == 0) sum++;
		     } 
		}
		
		else{
			c = a + b;
		if (c < 10000) a_2 = c;
		else {
			while (c >= 10000) {
			cont++;
			c--;
			}
			a_2 = 9999 - cont;// a_2�ǵڶ������ 
		}
		//���Եõ�����[a, a_2] 
		for (j = a; j <= a_2; j++) {
			if ((j % 4 == 0 && j % 100 != 0) || j % 400 == 0) sum++;
		}
		}
		
			printf("%d\n", sum);
	}
	return 0;
} 
