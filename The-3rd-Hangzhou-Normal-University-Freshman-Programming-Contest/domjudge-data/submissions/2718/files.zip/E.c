#include<stdio.h>
#include<string.h>
int main()
{
	char a;
	scanf("%s",&a);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/\n");
	return 0;
} 
