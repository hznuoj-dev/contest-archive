#include<stdio.h>
int rn(int year)
{
    if(year%4==0&&year%100!=0 || year%400==0)
    {
        if(year<0 && year%3200==0)
            return 0;
        else
            return 1;
    }
    else
    {
        return 0;
    }
}
int main()
{
    int t;
    scanf("%d",&t);
    for(int i=0;i<t;i++)
    {
        int count=0;
        int y,a;
        scanf("%d%d",&y,&a);
        int year1,year2;
        year1=y;
        year2=y+a;
        int k;
        k=y+a-9999;
        if(k>0)
            year2=year2-k;
        int temp;
        if(year2<year1)
        {
            temp=year2;
            year2=year1;
            year1=temp;
        }
        for(int l=year1;l<=year2;l++)
        {
            if(rn(l))
                count++;
        }
        printf("%d\n",count);
    }
    return 0;
}
