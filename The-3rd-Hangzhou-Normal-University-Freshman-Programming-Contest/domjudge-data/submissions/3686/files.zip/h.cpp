#include<iostream>
using namespace std;

int main(){
    int a,b,c,h=0,t;
    cin>>t;
    while(t--){
    	cin>>a>>b;
    	cout<<"[";
    	for(int i=0;i<b;i++){
    		cout<<"#";
		}
		for(int i=0;i<a-b;i++){
			cout<<"-";
		}
		cout<<"] ";
		c=b*100/a;
		cout<<c<<"%"<<endl;
	}

	return 0;
}

