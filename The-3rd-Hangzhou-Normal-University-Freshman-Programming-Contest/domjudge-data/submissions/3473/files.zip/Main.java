package demo;

import java.util.Scanner;

public class Main
{
	public static void main(String[] args) 
	{
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			int n=in.nextInt();
			while (n-->0)
			{
				int sum=0;
				int a=in.nextInt();
				int b=in.nextInt();
				b+=a;
				if (b>9999)b=9999-(b-9999);
				if (a>b){a=a^b;b=a^b;a=a^b;}
				for (int i=a;i<=b;i++)
				{
					if ((i%4==0 && i%100!=0) || i%400==0)sum++;
				}
				System.out.println(sum);
			}
		}
	}
}
