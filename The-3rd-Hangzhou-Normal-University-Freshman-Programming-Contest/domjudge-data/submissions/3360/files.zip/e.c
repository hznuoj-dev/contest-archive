#include<stdio.h>
int main(){
	char a;
	scanf("%s",a);
	printf(" __       _____\n");
	printf("|  |  ___/ ____\____\n");
	printf("|  | / /\   __\/ ___\\\n");
	printf("|    <   |  | \  \___\n");
	printf("|__|_ \  |__|  \___  >\n");
	printf("     \/            \/\n");
}