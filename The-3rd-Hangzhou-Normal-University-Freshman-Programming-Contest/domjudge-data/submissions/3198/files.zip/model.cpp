//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 1010;

priority_queue <int,vector<int>,less<int> >pq;
queue<int>q;
vector<int>edge[MAXN], ans;
int in[MAXN];

int main() {

#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);

	int t, n, m, a, b;
	scanf("%d", &t);
	while(t--) {
		memset(in, 0, sizeof(in));
		ans.clear();
		for (int i = 0; i < MAXN; ++i){
			edge[i].clear();
		}
		scanf("%d%d", &n, &m);
		while (m--) {
			scanf("%d%d", &a, &b);
			in[a]++;
			edge[b].push_back(a);
		}
		for (int i = 1; i <= n; ++i) {
			if (in[i] == 0) {
				pq.push(i);
			}
		}
		while (!pq.empty()) {
			int d = pq.top();
			pq.pop();
			ans.push_back(d);
			for (int i = 0; i < edge[d].size(); ++i) {
				int y = edge[d][i];
				in[y]--;
				if (in[y] == 0) {
					pq.push(y);
				}
			}
		}
		reverse(ans.begin(), ans.end());
		for(int i = 0; i < ans.size(); ++i){
			if (i) printf(" ");
			printf("%d", ans[i]);
		}	
		printf("\n");

	}


	return 0;
}
