#include <stdio.h>
int main(){
	int t;
	scanf("%d", &t);
	while(t--){
		int m, n, i;
		scanf("%d%d", &m, &n);
		double x;
		x=(double)(n*100)/(double)m;
		printf("[");
		m=m-n;
		while(n--){
			printf("#");
		}
		while(m--){
			printf("-");
		}
		printf("] "); 
		printf("%.0f%%\n", x);
	}
}



































