#include<stdio.h>
#include<math.h>
	char a[1]={'%'};
int main(){
	int T,n,m,i;
	double sum,num;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&n,&m);
		sum=(double)m/(double)n;
		num=sum*100;
		printf("[");
		for(i=0;i<m;i++)
		printf("#");
		for(i=m;i<n;i++){
			printf("-");
		}
		if(i==n) 
		printf("]");
		printf(" %.f",num);
		puts(a);
		//if(T>0)
		//printf("\n");
	}
}
