#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,m;
		scanf("%d%d",&n,&m);
		int ans=m*100/n;
		printf("[");
		for(int i=1;i<=m;i++){
			printf("#");
		}
		for(int i=m+1;i<=n;i++){
			printf("-");
		}
		printf("]");
		printf(" %d%\n",ans);
	}
	return 0;
}
