/*#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct submit {
	int team;
	int prob;
	int time;
	char str[3]; 
};

int timecmp(const void *p, const void *q);



int main(int argc, char *argv[]) {
	int n, t, m, p, q;
	int i, time, id, index;
	char cmd[16];
	
	scanf("%d %d %d %d", &n, &t, &m, &p);
	
	struct submit sub[m];
	
	int team_ac[n];
	
	for(i = 0; i < m; ++i) {
		scanf("%d %d %d %s", &sub[i].team, &sub[i].prob, &sub[i].time, sub[i].str);
	}
	qsort(sub, m, sizeof(struct submit), timecmp);
	scanf("%d", &q);
	for(i = 1; i <= q; ++i) {
		index = 0;
		scanf("%s %d", cmd, time);
		if(!strcmp(cmd, "teamstatus")) {
			//teamstatus
			scanf("%d", &id);
			
		}else if(!strcmp(cmd, "minrank")) {
			//minrank
			scanf("%d", &id);
			
		}else if(!strcmp(cmd, "maxrank")) {
			//maxrank
			scanf("%d", &id);
			
		}else if(!strcmp(cmd, "account")) {
			//account
			int r;
			scanf("%d", &id);
			r = 0;
			while (sub[index].time <= time) {
				if(sub[index].prob == id && !strcmp(sub[index].str, "AC")) ++r;
				++index;
			}
			printf("%d\n", r);
			
		}else if(!strcmp(cmd, "submitcount")) {
			//submitcount
			int r;
			scanf("%d", &id);
			r = 0;
			while (sub[index].time <= time) {
				if(sub[index].prob == id) ++r;
				++index;
			}
			printf("%d\n", r);
			
		}else if(!strcmp(cmd, "teamcount")) {
			//teamcount
			int j, r;
			scanf("%d", &id);
			r = 0;
			memset(team_ac, 0, sizeof(team_ac));
			while (sub[index].time <= time) {
				if(!strcmp(sub[index].str, "AC")) ++team_ac[sub[index].team - 1];
				++index;
			}
			for(j = 0; j < n; ++j) {
				if(team_ac[j] == id) ++r;
			}
			printf("%d\n", r);
		}
	}
	
	return 0;
}

int timecmp(const void *p, const void *q) {
	struct submit *s1 = (struct submit *)p;
	struct submit *s2 = (struct submit *)q;
	return s1->time - s2->time;
}*/

#include <stdio.h>

int main() {
	int test;
	scanf("%d", &test);
	printf("Hello ACM / *CPC!!\n");
}



