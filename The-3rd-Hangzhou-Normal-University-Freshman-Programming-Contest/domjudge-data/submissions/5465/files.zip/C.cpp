#include<bits/stdc++.h>
using namespace std;
long long int a[1000005];
long long int ca(long long int x,long long int y)
{
	long long int sum=y;
	int i=1;
	while(i<=a[x])
	{
		sum%=998244353;
		sum=sum*a[x-1];
		sum%=998244353;
		i++;
	}
return sum%998244353;
}
int main()
{
	int n;int max=1;
	cin>>n;
	a[1]=1;
	while(n)
	{
		int  x;
		scanf("%d",&x);
		if(x+1>max) max=x+1;
		a[x+1]++;
		n--;
	}
	long long int sum=1;
	if(max!=2)
	{
		int i=3;
		while(i<=max)
		{
			sum=ca(i,sum);
			i++;
		}
	}
	cout<<sum;
}

