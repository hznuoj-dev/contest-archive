﻿#include <stdio.h>
#include<math.h>
int main() {
	int t,y,a;
	scanf("%d", &t);
	while (t--) {
		int sum = 0;
		int x = 0;
		scanf("%d%d", &y, &a);
		sum = y + a;
		if (sum > 9999) {
			sum = 9999 - (sum - 9999);
		}
		if (sum > y) {
			for (int i = y; i <= sum; i++) {
				if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) {
					x = x + 1;
				}
			}
		}
		else {
			for (int i = sum; i <= y; i++) {
				if (i % 4 == 0 && i % 100 != 0 || i % 400 == 0) {
					x = x + 1;
				}
			}
		}
		printf("%d\n", x);
	}
}