#include<stdio.h>
#pragma warning(disable:4996)
int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		float n, m,b;
		char a[100002] = { '\0' };
		scanf("%f%f", &n, &m);
		b = m / n*100;
		int i;
		for (i = 0; i < m; i++) {
			a[i] = '#';
		}
		for (; i < n; i++) {
			a[i] = '-';
		}
		printf("[%s] %.0f%%\n", a, b);
	}
}