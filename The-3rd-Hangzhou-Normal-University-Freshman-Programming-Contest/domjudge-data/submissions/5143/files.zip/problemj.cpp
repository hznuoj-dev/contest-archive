#include<stdio.h>
#include<string.h>
int main(){ 
    int i,j,n,k,m,p,q,l=0;
    int count=0;
    char ru[1000];
    char t[1000];
    scanf("%d",&n);
    for(i=0;i<n;i++){
    	scanf("%d",&m);
    	for(j=0;j<m;j++){
    	for(q=0;q<1000;q++){
    		t[q]='.';
		    }
    	scanf("%s",ru);
    	k=strlen(ru);
    	for(p=0;p<k;p++){
    		for(q=0;q<100;q++){
            if(ru[p]!=t[q]&&ru[p]!='.'){
			t[l]=ru[p];
    			l++;
			}
			else {
			l=0;
			break;
		    }
		}
		if(l>0)
		count++;
        }
        }
        printf("%d\n",count);
        count=0;
        l=0;
	}


}

