#include<stdio.h>
#include<string.h>
char m[10000];
int l;
int compare(char c){
	for(int i = 0;i<l;i++)
		if(c==m[i]) return 0;
	m[l]=c;
	l++;
	return 1;
}
int main() {
	freopen("1.txt","r",stdin);
	int t,x,i,j,n,count,sum;
	char a[10000];
	scanf("%d",&t);
	while(t--) {
		count=0;
		scanf("%d",&x);
		while(x--) {
			l = 0;
		    memset(m,0,sizeof(m));
			scanf("%s",&a);
			n=strlen(a);
			for(int i = 0;i<n;i++)	if(a[i]!='.')  count+=compare(a[i]);
		}
		printf("%d\n",count);
	}

}


