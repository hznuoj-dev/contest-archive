/*#include<stdio.h>
int main(){
	int num,num1,num2,num3,num4,x1,x2,x3,x4,sum;
	num=0;
	sum=0;
	scanf("%d%d%d%d",&num1,&num2,&num3,&num4);
		while(num1!=0){
			x1=num1%10;
			sum+=x1;
			num1=num1/10;
		}
     if(sum>=16||sum==6){
		 num=num+1;
	 }
	 sum=0;
		while(num2!=0){
			x2=num2%10;
			sum+=x2;
			num2=num2/10;
		}
		if(sum>=16||sum==6){
		 num=num+1;
	 }
	 sum=0;
		while(num3!=0){
			x3=num3%10;
			sum+=x3;
			num3=num3/10;
		}
		if(sum>=16||sum==6){
		 num=num+1;
	 }
	 sum=0;
		while(num4!=0){
			x4=num4%10;
			sum+=x4;
			num4=num4/10;
		}
		if(sum>=16||sum==6){
		 num=num+1;
	 }
	if(num==1)
		printf("Oh dear!!\n");
	if(num==2)
		printf("BaoBao is good!!\n");
	if(num==3)
		printf("Bao Bao is a SupEr man///!\n");
	if(num==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if(num==0)
		printf("Bao Bao is so Zhai......\n");
	return 0;
}
#include<stdio.h>
#include<string.h>
int main(){
	int T,n,i,sum,Nsum,x,length;
	char a[1000000];
	scanf("%d",&T);
	while(T--){
		Nsum=0;
		scanf("%d",&n);
		for(x=1;x<=n;x++){
			sum=0;
			for(i=1;i<=1000000;i++){
			scanf("%s",a);
			}
			length=strlen(a);
            if(a[1]!='.')
				sum=1;
			for(i=2;i<=length;i++){
				if(a[i]!=a[1]&&a[i]!='.')
					sum=sum+1;
			}
		
			Nsum+=sum;
		}
		printf("%d\n",Nsum);
	}
		return 0;
	}
	*/
#include<stdio.h>
int main(){
	int m,n,T,x,y,num;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&n,&m);
		printf("[");
		for(x=1;x<=m;x++)
			printf("#");
		for(y=m+1;y<=n;y++)
			printf("-");
		printf("]");
		num=(m/(n*1.0))*100;
		printf("%d%%\n",num);
	}
	return 0;
}


	
