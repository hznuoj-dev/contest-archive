#include<stdio.h>
int main(){
	int i,j,m,n,r,t,s,a,b,x,y;
	
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d%d",&a,&b);
		printf("[");
		for(j=1;j<=b;j++)
		printf("#");
		for(j=1;j<=a-b;j++)
		printf("-");
		printf("] ");
		printf("%d%%\n",b*100/a);
		
		
		
		
	} 
	
	return 0;
	
	
	
	
} 
