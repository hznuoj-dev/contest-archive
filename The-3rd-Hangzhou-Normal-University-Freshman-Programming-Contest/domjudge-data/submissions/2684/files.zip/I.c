#include <stdio.h>
#include <stdlib.h>
int main()
{
	long int T,A,B,i;
	float C;
	scanf("%ld",&T);
	while(T--)
	{
		scanf("%ld %ld",&A,&B);
		printf("[");
		for(i=1;i<=B;i++)
		{
			printf("#");
		}
		for(i=1;i<=A-B;i++)
		{
			printf("-");
		}
		C=(float)B/A*100;
		printf("] %.0f%%",C);
		if(T!=0)printf("\n");
	}



	return 0;
}

