#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int t,m,n,i,j,p,a,b;
	int x[1000];
	    scanf("%d",&t);
	    while(t--){
	    	scanf("%d %d",&m,&n);
	    	for(i=1;i<=m;i++){
	    		x[i]=i;
			}
			for(p=0;p<n;p++){
	    	scanf("%d %d",&a,&b);
	    	for(i=1;i<=m;i++){
	    		if(a==x[i]) break;
			}
			for(j=1;j<=m;j++){
	    		if(b==x[j]) break;
			}
			if(i>j){
				x[i]=b;
				x[j]=a;
			}
			}
			for(i=1;i<m;i++){			
			printf("%d ",x[i]);
		}
		printf("%d",x[m]);
		}
	    
	return 0;
} 
