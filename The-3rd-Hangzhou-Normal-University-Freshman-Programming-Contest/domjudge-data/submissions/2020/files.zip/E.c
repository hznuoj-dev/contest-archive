#include <stdio.h>

int main(void)
{
	char ch[4];
	gets(ch);
	
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");
	
	return 0;
} 
