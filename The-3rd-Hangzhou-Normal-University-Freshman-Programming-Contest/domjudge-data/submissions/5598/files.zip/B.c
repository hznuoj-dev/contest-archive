#include<stdio.h>
#include<math.h>
#pragma warning(disable:4996)
int main()
{
 int T;
 scanf("%d",&T);
 while(T--)
 {
 	int y,x,a,sum=0,i,t;
    scanf("%d %d",&y,&a);
    if (y+a>9999) {
   	     x=19998-y-a;
    }
    else x=y+a;
    if (x<y){
    	t=x;x=y;y=t;
	}
    for(i=y;i<=x;i++){
	if ((i % 4 == 0 && i% 100 != 0) ||(i % 400 == 0))
	 sum++;
    }
    printf("%d\n",sum);
 }
 return 0;
}
