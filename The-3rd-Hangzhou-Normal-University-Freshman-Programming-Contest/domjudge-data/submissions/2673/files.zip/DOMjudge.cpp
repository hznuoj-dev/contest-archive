#include<stdio.h>
int main()
{
    int t,n,m;
    scanf("%d",&t);
    while(t>0)
    {
        scanf("%d%d",&n,&m);
        printf("[");
        for(int i=0;i<m;i++)
        {
            printf("#");
        }
        for(int i=m;i<n;i++)
        {
            printf("-");
        }
        printf("] %d%%\n",m*100/n);
    t--;
    }
    return 0;
}
