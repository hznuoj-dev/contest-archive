#include<bits/stdc++.h>
using namespace std;
#define ll long long

int runnian(int n)
{
    if(((n%100!=0) && (n%4==0)) || ( n % 400==0)){
        return 1;
    }
    else{
        return 0;
    }
}

int main(void){
	int n;
	cin>>n;
	while(n--){
	int a,b,count=0;;
	cin>>a>>b;
	if(a+b>9999){
		b=a+b-9999+a+b;
	} 
	else
		b=b+a;
	if(b>a){
		int sign=a;
		a=b;
		b=sign;
	}
	for(int k=b;k<=a;k++){
		if(runnian(k))
			count++;
	}
	cout<<count<<endl;
}
}
