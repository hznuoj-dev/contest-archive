#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main()
{
    char sz[5][20];
    int i,a,b=0,j,c=0;
    scanf("%s %s %s %s", &sz[1], &sz[2], &sz[3], &sz[4]);
    for (i = 1; i <= 4; i++)
    {
        b = 0;
        a = strlen(sz[1]);
        for (j = 1; j <= a; j++)
        {
            b = b + sz[i][j] - 48;
        }
        if (b >= 16 || b == 6)
        {
            c++;
        }
    }
    if (c == 1)
    {
        printf("Oh dear!!");
    }
    if (c == 2)
    {
        printf("BaoBao is good!!");
    }
    if (c == 3)
    {
        printf("Bao Bao is a SupEr man//////!");
    }
    if (c == 4)
    {
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    }
    if (c == 0)
    {
        printf("Bao Bao is so Zhai......");
    }
    return 0;
}