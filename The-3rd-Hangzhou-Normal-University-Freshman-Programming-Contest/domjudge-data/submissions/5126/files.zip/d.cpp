#include<stdio.h>
#include<string.h>
char m[1000001];
int main(void){
	int n,len=0;
	scanf("%d",&n);
	while(n--){
		scanf("%s",m);
		len+=strlen(m);
	}
	printf("%d\n",len);
}
