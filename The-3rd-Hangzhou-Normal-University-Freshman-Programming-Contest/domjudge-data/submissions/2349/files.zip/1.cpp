#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 



int main(){
	int t,year,year1,x,n=0,i,ii;
	scanf("%d",&t);
	while(t--){
		n=0;
		scanf("%d %d",&year,&x);
		year1=year+x;
		if(year1>year)
		x=year,year=year1,year1=x;
		if(year>=9999) 
		year=9999-year+9999;
		if(year1>year)
		x=year,year=year1,year1=x;
		for(i=year1;i<=year;i++){
			if((i%4==0&&i%100!=0)||i%400==0)
			n++,i+=3;
		}
		printf("%d\n",n);
	}
} 

