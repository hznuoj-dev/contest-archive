#include <stdio.h>
int main()
{
	int t,i,j,n;
	int a,b,c,o;
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		n=0;
		scanf("%d %d",&a,&b);
		c=a+b;
		if(c>9999){
			c=9999-(c-9999);
		}
		if(a>c){
			o=a;
			a=c;
			c=o;
		}
		for(j=a;j<=c;j++){
			if((j%4==0&&j%100!=0)||(j%400==0)){
				n++;
			}
		}
		printf("%d\n",n);
	}

	return 0;
}

