#include<stdio.h>
int main(void){
	int a,b,c,d,count=0;
	int sum1=0,sum2=0,sum3=0,sum4=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>9){
	sum1+=a%10;
	a=a/10;
	if(sum1>=16||sum1==6)
	count ++;
	}
	
	while(b>9){
	sum2+=b%10;
	b=b/10;
	if(sum2>=16||sum2==6)
	count ++;
	}
	
	while(c>9){
	sum1+=c%10;
	c=c/10;
	if(sum3>=16||sum3==6)
	count ++;
	}
	
	while(d>9){
	sum4=d%10;
	d=d/10;
	if(sum4>=16||sum4==6)
	count ++;
	}
	
		if(count==1) printf("Oh dear!!");
		if(count==2) printf("BaoBao is good!!");
		if(count==3) printf("Bao Bao is a SupEr man/////!");
		if(count==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		if(count==0) printf("Bao Bao si so Zhai......") ;	
	
	return 0;

}
