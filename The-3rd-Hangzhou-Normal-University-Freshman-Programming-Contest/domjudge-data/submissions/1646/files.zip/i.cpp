#include<stdio.h>
int aa(int a){
	int c=0,d=0;
	while(a>0){
		d+=a%10;
		a/=10;
	}
	if(d>=16||d==6) c++;
	return c;
}
int main(){
	int a,b,c,d,e=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	e=aa(a)+aa(b)+aa(c)+aa(d);
	switch(e){
		case 0:printf("Bao Bao is so Zhai......");break;
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
	return 0;
} 
