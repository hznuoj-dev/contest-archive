#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
using namespace std;
char s[1000001];
int main(){
	int t,n,len,i,m=0,b;
	scanf("%d",&t);
	while(t--){
		b=0;
		scanf("%d",&n);
		while(n--){
			m=0;
			int a[128]={0};
			scanf("%s",s);
			len=strlen(s);
			for(i=0;i<len;i++){
				if(s[i]!='.')a[s[i]]++;
			}
			for(i=0;i<128;i++){
				if(a[i]!=0)m++;
			}
			b=b+m;
		}
		printf("%d\n",b);
	}
	return 0;
} 

