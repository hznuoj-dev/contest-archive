#include<stdio.h>
#include<string.h>
int main(){
    int T,f,len,d;
    char s[100010];
    scanf("%d",&T);
    while(T--){
    	d=0;
    	scanf("%d",&f);
    	while(f--){
    		scanf("%s",s);
    		len=strlen(s);
    		for(int i=0;i<len;i++){
    			if(s[i]!='.') {
    				d++;
				}
			}
		}
		printf("%d\n",d);
	}
    return 0;
}
