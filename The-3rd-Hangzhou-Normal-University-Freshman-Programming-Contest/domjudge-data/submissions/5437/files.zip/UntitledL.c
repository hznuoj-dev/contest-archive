#include<stdio.h>
int main()
{
	int i,s[100],a[100],n;
	long t;
	double hq,hw,aq,aw,sum,dem,dem1,hq1,hw1;
	scanf("%ld",&t);
	while(t>0)
	{
		dem1=0;
		for(i=0;i<100;i++) s[i]=0;
		sum=0;
		scanf("%lf%lf%lf%lf",&hq,&hw,&aq,&aw);
		for (i=1;;i++)
		{
			sum+=i;
			if (sum>=hq+hw) break;
		}
		n=i;
		while (s[n]==0)
		{
			hq1=hq;
			hw1=hw;
			dem=aq+aw;
			s[0]++;
			for (i=0;i<n;i++)
				if (s[i]==2) {s[i]=0;s[i+1]++;}
			for (i=0;i<n;i++)
			{
				if (s[i]==0) hq1-=i+1;
				else hw1-=i+1;
				if (hq1>0) dem+=aq;
				if (hw1>0) dem+=aw;
			}
			if (hq1<=0 && hw1<=0 && (dem<dem1 || dem1==0)) {dem1=dem;for (i=0;i<n;i++) a[i]=s[i];}
		}
		printf("%.0lf ",dem1);
		for (i=0;i<n;i++)
		{
			if (a[i]==0) printf("Q");
			else printf("W");
		}
		printf("\n");
		t--;
	}
	return 0;
}
