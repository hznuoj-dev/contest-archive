//
//  main.c
//  算日期
//
//  Created by 蔡欣怡 on 2020/12/13.
//

#include <stdio.h>
int isLeap(int x);
int main(void) {
    // insert code ere...
    int t=0;
    scanf("%d",&t);
    while(t--){
        int a=0,b=0,n;
        int sum1=0;
        scanf("%d %d",&a,&b);
        n=a+b;
        if(n>9999){
            n=9999-(n-9999);
            for(int i=a;i<=n;i++){
                if(isLeap(i)){
                    sum1++;
                }
            }
        }
        if(n>a&&n<=9999){
            for(int i=a;i<=n;i++){
                if(isLeap(i)){
                    sum1++;
                }
            }
        }
        if(n<=a){
            for(int j=n;j<=a;j++){
                if(isLeap(j)){
                    sum1++;
                }
            }
        }
        printf("%d\n",sum1);
    }
    return 0;
}
int isLeap(int x){
    if((x%4==0&&x%100!=0)||x%400==0)
        return 1;
    else
        return 0;
}
