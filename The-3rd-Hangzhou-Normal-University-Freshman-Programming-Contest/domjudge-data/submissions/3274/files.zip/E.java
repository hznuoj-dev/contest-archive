public class Main
{
	public static void main(String[] args)
	{
		System.out.println("__ _____");
		System.out.println("| | ___/ ____\\____");
		System.out.println("| |/ /\\ __\\/ ___\\");
		System.out.println("| < | | \\ \\___");
		System.out.println("|__|_ \\ |__| \\___ >");
		System.out.println("\\/ \\/");
	}
	
}
