#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t)
	{
		int x,y;
		cin>>x>>y;
		cout<<"[";
		int a=y;
		while(a)
		{
			cout<<"#";
			a--;
		}
		int z=x-y;
		while(z)
		{
			cout<<"-";
			z--;
		}
		cout<<"] ";
		int s=(y*100)/x;
		cout<<s<<"%";
		if(--t) cout<<endl;
	}
}

