#include<bits/stdc++.h>
using namespace std;
int mapp[1005][1005];
int a[1005];
int main()
{
	int t; cin>>t;
	while(t--)
	{
		memset(mapp,0,sizeof(mapp));
		int n, m; cin>>n>>m;
		while(m--)
		{
			int x, y; cin>>x>>y;
			mapp[x-1][y-1]=1;
		}
		
		for(int j=0; j<n; j++)
  		{
        	a[j]=0;
        	for(int i=0; i<n; i++)
        	{
            	if(mapp[i][j]==1) a[j]++;
        	}
    	}
    	for(int j=0; j<n; j++)
   	 	{
        	a[j]=0;
        	for(int i=0; i<n; i++)
        	{
            	if(mapp[i][j]==1) a[j]++;
        	}
    	}
    	
    	for(int i=1; i<=n; ++i)
   		{
        	int j=0;
        	while(j<n && a[j]!=0) j++;
        	cout<<j+1<< " ";
        	a[j]=1005;
        	for(int k=0; k<n; k++)
        	{
            	if(mapp[j][k]==1) a[k]--;
        	}
    	}
	}
    return 0;
}

