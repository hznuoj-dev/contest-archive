#include<stdio.h>
int main(){
	char c='%';
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b;
		scanf("%d %d",&b,&a);
		if(a==0){
			printf("[");
			for(int i=1;i<=b;i++)
			printf("#");
			printf("]");
			printf("0%c\n",c);
		}else{
		
		printf("[");
	for(int i=1;i<=a;i++)
	printf("#");
	for(int i=1;i<=b-a;i++)
	printf("-");
	printf("]");
	printf(" %.0f%c\n",1.0*a*100/b*1,c);
}
}
}
