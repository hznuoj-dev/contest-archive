




import java.util.Scanner;
public class ADF
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
			while(in.hasNext())
			{
				int a=in.nextInt();
				for(int i8=0;i8<a;i8++)
				{
					int a2=in.nextInt();
					int a3=in.nextInt();
					int a8=0;
					
					
					int a5=0;
					int jishu=0;
					
					if(a2+a3>9999)
					{
						int a4=a2+a3-9999;
						 a5=9999-a4;
					}else
					{
						a5=a2+a3;
						
					}
					if(a2<=a5)
					{
					for(int i=a2;i<=a5;i++)
					{
						if(i%4==0&&i%100!=0|i%400==0)
						{
							jishu=jishu+1;
							
						}
					}
					}
					 if(a2>a5)
					{   
						for(int i=a5;i<=a2;i++)
						{
							if(i%4==0&&i%100!=0|i%400==0)
							{
								jishu=jishu+1;
								
							}
						}
					}
					 
					System.out.println(jishu);
				}
			}
	}
}
        