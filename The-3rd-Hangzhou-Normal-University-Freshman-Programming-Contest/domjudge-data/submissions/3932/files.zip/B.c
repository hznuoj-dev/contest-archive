#include<stdio.h>
#include<math.h>
#pragma warning(disable:4996)
int main()
{
  int T,sum=0,Y,a,t,i;
  scanf("%d",&T);
  while(T--)
  {
  	scanf("%d %d",&Y,&a);
	 if(a<0)  
  	{
  		t=Y;
  		Y=Y+a;
  		a=t;
	  }
  	else if(Y+a>9999)
  	{
	  a=9999-(Y+a-9999);
	  if(Y+a>9999)
	    a=9999-(Y+a-9999);
  	  if(a<Y)  
  	  {
  		t=a;
  		a=Y;
  		Y=t;
	  }
    }
    if(a<Y)  
  	  {
  		t=a;
  		a=Y;
  		Y=t;
	  }
  	for(i=Y;i<=a;i++)
  	 {
	   if ((i%400==0 )||(i%4==0 && i%100!=0))
	   sum=sum+1;
     }
  	printf("%d\n",sum);
  	sum=0;
  }
return 0;

}
