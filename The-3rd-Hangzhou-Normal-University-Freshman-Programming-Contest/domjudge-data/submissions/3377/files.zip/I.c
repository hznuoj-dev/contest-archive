#include <stdio.h>
int sight(int num);
int main(void) {
    int a,b,c,d,sum=0;
    scanf("%d%d%d%d",&a,&b,&c,&d);
    if(sight(a)==1||sight(b)==1||sight(c)==1||sight(d)==1){
    	sum++;
	}
	switch(sum){
		case 0:printf("Bao Bao is so Zhai......");
		break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		break;
		case 3:printf("Bao Bao is a SupEr man///!");
		break;
		case 2:printf("BaoBao is good!!");
		break;
		case 1:printf("Oh dear!!");
		break;
	}
    return 0;

}
int sight(int num){
	int x=0,ret=0;
	if(num!=0){
		x+=num%10;
		num/=10;
	}
	if(x>=16||x==6){
		ret=1;
	}
	return ret;
}
