#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int main()
{
	int t;
	int n,m;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&m);
		printf("[");
		for(int i=1;i<=m;i++)
		{
			printf("#");
		}
		for(int i=1;i<=n-m;i++)
		{
			printf("-");
		}
		printf("] ");
		double sum=(double)m/(double)n;
		printf("%.0f%%\n",sum*100);
	}
	return 0;
}
