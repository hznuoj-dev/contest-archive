#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
using namespace std;

int main(){
	char x[20];
	int len,i,j,a=0,s;
	for(i=1;i<=4;i++){
		s=0;
		scanf("%s",x);
		len=strlen(x);
		for(j=0;j<len;j++){
			s=s+x[j]-'0';
		}
		if(s>=16||s==6)a++;
	}
	if(a==0){
		printf("Bao Bao is so Zhai......\n");
	}else if(a==1){
		printf("Oh dear!!\n");
	}else if(a==2){
		printf("BaoBao is good!!\n");
	}else if(a==3){
		printf("Bao Bao is a SupEr man///!\n");
	}else if(a==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	
} 

