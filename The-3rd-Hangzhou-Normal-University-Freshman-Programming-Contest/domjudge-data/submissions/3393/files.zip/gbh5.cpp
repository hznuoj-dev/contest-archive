#include<stdio.h>
int main(){
	char str[3];
	scanf("%s",str);
	if (str[0] == 'k' && str[1] == 'f' && str[2] == 'c') {
		printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/");
	}
}
