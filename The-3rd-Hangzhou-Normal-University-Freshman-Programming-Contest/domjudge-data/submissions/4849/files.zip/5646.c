#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
    long long a, b, c, d;
    int s1 = 0, s;
    scanf("%lld %lld %lld %lld", &a, &b, &c, &d);
    s = 0;
    while (a > 0) {
        s = s + a % 10;
        a = a / 10;
    }
    if (s >= 16 || s == 6) {
        s1++;
    }
    s = 0;
    while (b > 0) {
        s = s + b % 10;
        b = b / 10;
    }
    if (s >= 16 || s == 6) {
        s1++;
    }
    s = 0;
    while (c > 0) {
        s = s + c % 10;
        c = c / 10;
    }
    if (s >= 16 || s == 6) {
        s1++;
    }
    s = 0;
    while (d > 0) {
        s = s + d % 10;
        d = d / 10;
    }
    if (s >= 16 || s == 6) {
        s1++;
    }
    if (s1 == 0) {
        printf("Bao Bao is so Zhai......\n");
    }
    if (s1 == 1) {
        printf("Oh dear!!\n");
    }
    if (s1 == 2) {
        printf("BaoBao is good!!\n");
    }
    if (s1 == 3) {
        printf("Bao Bao is a SupEr man///!\n");
    }
    if (s1 == 4) {
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
    }
    return 0;
}