#include<bits/stdc++.h>
using namespace std;

int main(void){

    int a[5];
    cin >> a[1] >> a[2] >> a[3] >> a[4]; 
    int times = 0;
    for(int i = 1;i <= 4;i++){
        if(a[i] >= 16 || a[i] == 6) times++;
    }
    if(times == 0) cout << "Bao Bao is so Zhai......";
    else if(times == 1) cout << "Oh dear!!";
    else if(times == 2) cout << "BaoBao is good!!";
    else if(times == 3) cout << "Bao Bao is a SupEr man///!";
    else cout << "Oh my God!!!!!!!!!!!!!!!!!!!!!";

    return 0;
}