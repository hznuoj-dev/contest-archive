#include<stdio.h>
int sun(int year, int n);
int main()
{
	int T, year, a, n, sum;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d %d", &year, &a);
		n = year + a;
		if (n < 10000)
		{
			sum=sun(year, n);
		}
		else
		{
			n = 9999 * 2 - n;
			sum=sun(year, n);
		}
		printf("%d\n", sum);
	}
	return 0;
}
int sun(int year, int n)
{
	int m, i;
	int sum = 0;
	if (year > n)
	{
		m = n;
		n = year;
		year = m;
	}
	for (i = year; i <= n; i++)
	{
		if (i % 400 == 0 || (i % 4 == 0 && i % 100 != 0)) sum += 1;
	}
	return(sum);
}
