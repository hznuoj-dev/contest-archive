#include <stdio.h>
int main(void){
	printf("3");
	return 0;
}
