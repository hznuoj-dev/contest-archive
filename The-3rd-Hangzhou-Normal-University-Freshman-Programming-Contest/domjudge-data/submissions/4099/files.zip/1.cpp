#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 

char  c[100003];

int main(){
	int t,a,b,i;
	double n;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		for(i=0;i<b;i++)
		c[i]='#';
		for(i;i<a;i++)
		c[i]='-';
		printf("[%s] %.0f%%\n",c,b*1.0/a*100);
	}
} 


