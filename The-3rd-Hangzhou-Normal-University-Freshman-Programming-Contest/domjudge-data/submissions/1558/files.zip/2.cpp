#include<stdio.h>
int main(void){
	int t,y,a,sum;
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d %d",&y,&a);
		a+=y;
		if(a>=10000){
			a-=(a-9999);
		}
		else if(a<=0) a--;
		if(y>a){
			for(int i=a;i<=y;i++){
				if(i==0){
					i++;
					continue;
				}
				if(i%400==0||(i%4==0&&i%100!=0)){
					sum++;
				}
			}
		}
		else{
			for(int i=y;i<=a;i++){
				if(i%400==0||(i%4==0&&i%100!=0)){
					sum++;
				}
			}
		}
		printf("%d\n",sum);
	}
}
