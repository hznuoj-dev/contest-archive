#include<stdio.h>
int isLeapYear(int x);
int main(void){
	int T;
	scanf("%d\n",&T);
	while(T--){
		int a,b,s,m;
		int sum=0,i;
		scanf("%d %d",&a,&b);
		s=a+b;
		if(10000<=s){
			s=9999-(s-10000);
		}
		if(a>s){
			m=s;
			s=a;
			a=m;
		} 
		for(i=a;i<s;i++){
			if(isLeapYear(i)){
				sum++;
			}
		}
		printf("%d\n",sum);
	}
	
	return 0;
} 
int isLeapYear(int x){
	if((x%4==0&&x%100!=0)||(x%400==0)){
		return 1;
	}else return 0;
	}
