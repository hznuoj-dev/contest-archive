#include<stdio.h>
int main()
{
	char x='%';
	int t,n,m;
	scanf("%d",&t);
	for(int i=0;i<t;i++)
	{
		scanf("%d%d",&n,&m);
		printf("[");
		for(int j=0;j<m;j++)
		{
			printf("#");
		}
		for(int k=0;k<n-m;k++)
		{
			printf("-");
		}
		printf("] ");
		printf("%d%c\n",int(m*100.0/n),x);
	} 
	return 0;
 } 
