#include <stdio.h>
#include <string.h>
int main()
{
	char a[4][20];
	scanf("%s %s %s %s",a[0],a[1],a[2],a[3]);
	int i,j,sum,q=0;
	for(i=0;i<4;i++)
	{
		sum=0;
		for(j=0;j<strlen(a[i]);j++)
		{
			sum+=(int)a[i][j]-48;
		}
		if(sum>=16||sum==6)
		q++;
	}
	if(q==0)
	printf("Bao Bao is so Zhai......\n");
	else if(q==1)
	printf("Oh dear!!\n");
	else if(q==2)
	printf("BaoBao is good!!\n");
	else if(q==3)
	printf("Bao Bao is a SupEr man///!\n");
	else if(q==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}
