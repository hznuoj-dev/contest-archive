#include <stdio.h>//behijd
#include <string.h>
int main (){
	int t,n,m;
	(void)scanf("%d",&t);
	while(t--){
		if(scanf("%d %d",&n,&m)!=1){
		printf("[");
		for(int i=0;i<m;i++){
			printf("#");
		}
		for(int j=0;j<n-m;j++){
			printf("-");
		}
		printf("] ");
		double e=(double)m/n;
		printf("%.f",e*100);
		printf("%%\n");
	}
	}

	return 0;
}
