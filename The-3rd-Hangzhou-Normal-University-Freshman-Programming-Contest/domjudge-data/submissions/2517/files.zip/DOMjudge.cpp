#include<stdio.h>
int main()
{
    int t,y,d,jh,dy;
    scanf("%d",&t);
    while(t>0)
    {
        int sum=0;
        scanf("%d%d",&y,&d);
        if(y+d>9999)dy=9999-(y+d-9999);
        else dy=y+d;
        if(y>dy)
        {
          jh=y;
          y=dy;
          dy=jh;
        }
        for(int i=y;i<=dy;i++)
        {
            if(i%4==0&&i%100!=0||i%400==0)sum++;
        }
        printf("%d\n",sum);
        t--;
    }
    return 0;
}
