#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main() {
	int  f, t;
	long i, m, n;
	scanf("%d", &t);
	while (t--) {
		scanf("%ld %ld", &n, &m);
		f = 100 * m / n;
		printf("[");
		for (i = 0; i < n; i++) {
			if (i < m) {
				printf("#");
			}
			else printf("-");
		}
		printf("] %d%%", f);
	}
	return 0;
}