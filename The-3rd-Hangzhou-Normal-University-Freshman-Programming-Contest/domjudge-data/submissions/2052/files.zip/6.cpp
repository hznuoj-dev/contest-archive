#include<stdio.h>
int main()
{
	int t,year,n,i,m;
	scanf("%d",&t);
	while(t--)
	{
		int sum=0;
		scanf("%d%d",&year,&n);
		m=year+n;
		for(i=(m<year?m:year);i<=(m<year?year:m);i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
			sum++;
		}
		printf("%d",sum);
	}
}


