#include <bits/stdc++.h>
using namespace std;

int year(int n){
    if(n%400==0||(n%4==0&&n%100!=0))
        return 1;
    else return 0;
}

int main(){
    int t,n1,n2;
    cin>>t;
    while(t--){
        cin>>n1>>n2;
        int n3=n1+n2;
        int res,count=0;
        if(n3>9999) {
            res = n3 - 9999;
            n3=9999-res;
        }
        if(n3<n1) swap(n1,n3);
        for(int i=n1;i<=n3;i++)
            if(year(i)) count++;
        cout<<count<<'\n';
    }
    return 0;
}