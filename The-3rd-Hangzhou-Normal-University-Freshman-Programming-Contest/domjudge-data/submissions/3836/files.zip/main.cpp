#include <bits/stdc++.h>

using namespace std;

int main() {
    int n;
    string s;
    cin>>n;
    cin>>s;
    cout<<n*s.length();
    return 0;
}
