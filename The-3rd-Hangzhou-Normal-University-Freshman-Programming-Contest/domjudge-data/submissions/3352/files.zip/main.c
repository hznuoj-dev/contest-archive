#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t;
	long long a,b,cnt=0,num;
	scanf("%d",&t);
	while(t--){
	     cnt=0;
		scanf("%lld %lld",&a,&b);		
		if(b>=0){
			if(a+b<=9999){
				num=a+b;
				for(a;a<=num;a++){		
				if((a%4==0&&a%100!=0)||a%400==0)
				   cnt++;
			}
	}
			
		else	if(a+b>9999){
				b=19999-b-a;
				if(a<=b)
					{
					for(a;a<=b;a++){
				if((a%4==0&&a%100!=0)||a%400==0)
				   cnt++;
			   }
			}
			
				else 
				for(b;b<=a;b++){ 
				if((b%4==0&&b%100!=0)||b%400==0)
				   cnt++;
		}
	}
			} 
		if(b<0){ 
			b=a+b;
			for(b;b<=a;b++){ 
				if((b%4==0&&b%100!=0)||b%400==0)
				   cnt++;
				   } 
		}		
		   
		printf("%lld\n",cnt);
		
   }
	return 0;
}
