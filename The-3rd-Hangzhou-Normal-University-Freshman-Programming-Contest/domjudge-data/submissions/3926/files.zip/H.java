import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int n=sc.nextInt();
			for(int i=1;i<=n;i++)
			{
				double zong=sc.nextInt();
				int wc=sc.nextInt();
				StringBuffer ans=new StringBuffer("[");
				for(int j=1;j<=wc;j++)
				{
					ans=ans.append("#");
				}
				for(int j=wc;j<=zong;j++)
				{
					ans=ans.append("-");
				}
				ans=ans.append("]");
				System.out.printf("%s %.0f%%\n",ans,wc/zong*100);
			}
		}
	}
	
}
