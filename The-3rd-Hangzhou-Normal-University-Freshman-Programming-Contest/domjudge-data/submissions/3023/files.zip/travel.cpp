#include<stdio.h>
int main()
{
	int t=4,count=0,sum=0;
	long long a,b=0;
	while(t--)
	{
		scanf("%lld",&a);
		if(a==6)
		{
		count++;}
		else{
		while(a>0)
		{
			b=a%10;
			sum+=b;
			a=a/10;
			
		}
		if(sum>=16||sum==6)
		{
			count++;
		}
		}
	}
	if(count==1) printf("Oh dear!!");
	if(count==2) printf("BaoBao is good!!");
	if(count==3) printf("Bao Bao is a SupEr man///!");
	if(count==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	if(count==0) printf("Bao Bao is so Zhai......");
	
}
