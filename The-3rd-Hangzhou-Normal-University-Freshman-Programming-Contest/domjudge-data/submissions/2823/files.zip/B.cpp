#include<bits/stdc++.h> 
using namespace std;
int main(){
	int T;
	scanf("%d",&T);
	for(int i=1;i<=T;++i){
		int Y,A,sum=0;
		scanf("%d%d",&Y,&A);
		int sma,big,cup;
		sma=Y;
		big=Y+A;
		if(big>9999) big=9999-(big-9999);
		if(big<sma){cup=big;big=sma;sma=cup;}
		for(int j=sma;j<=big;++j){
			if(j%4==0&&j%100!=0) ++sum;
			if(j%400==0) ++sum;
		}
		printf("%d\n",sum);
	}
	
	return 0;
}
