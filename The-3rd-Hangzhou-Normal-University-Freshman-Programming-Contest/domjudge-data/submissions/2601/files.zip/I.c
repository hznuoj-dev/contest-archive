#include "stdio.h"

int isJi(long pInt[4]);

int main() {
    long array[4];
    scanf("%d %d %d %d", &array[0], &array[1], &array[2], &array[3]);
    switch (isJi(array)) {
        case 1:
            printf("Oh dear!!");
            break;
        case 2:
            printf("BaoBao is good!!");
            break;
        case 3:
            printf("Bao Bao is a SupEr man///!");
            break;
        case 4:
            printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
            break;
        default:
            printf("Bao Bao is so Zhai......");
            break;
    }


}

int isJi(long pInt[4]) {
    int cont = 0;
    for (int i = 0; i < 4; i++) {
        int sum = 0;
        while (pInt[i] > 0) {
            sum += (pInt[i] / 10);
            pInt[i] /= 10;
        }
        if (sum >= 16 || sum == 6) {
            cont++;
        }
    }
    return cont;
}
