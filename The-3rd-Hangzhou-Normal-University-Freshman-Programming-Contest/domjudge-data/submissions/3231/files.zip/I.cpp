#include<stdio.h>
int main()
{
	long long a[4];
	scanf("%lld%lld%lld%lld",&a[0],&a[1],&a[2],&a[3]);
	int count=0,sum;
	for(int i=0;i<4;i++){
	    sum=0;
	    while(a[i]>0){
	        sum+=a[i]%10;
	        a[i]/=10;
		}
		if(sum>=16||sum==6)
		    count++;
	}
	if(count==0)
	    printf("Bao Bao is so Zhai......\n");
	else if(count==1)
	    printf("Oh dear!!\n");
	else if(count==2)
	    printf("BaoBao is good!!\n");
	else if(count==3)
	    printf("Bao Bao is a SupEr man///!\n");
	else
	    printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
