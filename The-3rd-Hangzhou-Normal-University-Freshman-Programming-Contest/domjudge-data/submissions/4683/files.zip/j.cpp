#include<stdio.h>
#include<string.h>

int main(void){
	int T;
	scanf("%d",&T);
	while(T--){
		int n;
		scanf("%d",&n);
		int sum=0;
		while(n--){
			char s[1000];
			scanf("%s",s);
			int k=0;
			char p[1000]={'.'};
			for(int i=0;i<strlen(s);++i){				
				if(s[i]!='.'){
					int flag=1;
					
					for(int j=0;j<strlen(p);++j){
						if(s[i]==p[j]){
							flag=0;
							break;
						}
					}
					if(flag){
						
						p[k]=s[i];
						k++;
						sum++;
						
					};
				}
			}
			k=0;
			
		}
		printf("%d\n",sum);
	}
}
