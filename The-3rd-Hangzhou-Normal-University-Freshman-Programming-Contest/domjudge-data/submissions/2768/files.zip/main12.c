#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int T;
	scanf("%d",&T);
	while(T--)
	{
		long long y,a,b;
		long long x=0;
		scanf("%lld %lld",&y,&a);
		if(y>0)
		b=a+y;
		
		if(b>9999)
		{
			b=y+y+a-9999;
		}
		int i,t;
		if(b<y)
		{
			t=b;
			b=y;
			y=t;
		}
			if(b>9999)
		{
			b=y+y+a-9999;
		}
		if(b<y)
		{
			t=b;
			b=y;
			y=t;
		}
		for(i=y;i<=b;i++)
		{
		
			if(((i%4==0)&&(i%100!=0))||i%400==0)
			{
				x++;
			}
			
		}
		printf("%lld\n",x);
	}
	return 0;
}

/*
int main()
{
	char c[20];
	
	
	return 0;
}*/
