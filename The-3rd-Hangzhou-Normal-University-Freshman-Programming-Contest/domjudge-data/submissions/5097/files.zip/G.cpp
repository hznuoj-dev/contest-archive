#include<stdio.h>
#include<string.h>
int main() {
	int t, n, m, a, b;
	int i, j, k;
	int e[200][200] = { 0 }, v[200] = { 0 };
	scanf("%d", &t);
	while (t--)
	{
		memset(v, 0, sizeof(v));
		scanf("%d %d", &n, &m);
		while (m--)
		{
			scanf("%d %d", &a, &b);
			e[a][b] = 1;
		}
		for (k = 1; k <= n; k++)
		{
			for (i = 1; i <= n; i++)
			{
				for (j = 1; j <= n; j++)
				{
					if (e[i][k] == 1 && e[k][j] == 1)
						e[i][j] = 1;
				}
			}
		}
		for (i = 1; i <= n; i++)
		{
			for (j = 1; j <= n; j++)
			{
				if (e[i][j] == 1)
					v[i]++;
			}
		}
		for (i = n - 1; i >= 0; i--)
		{
			for (j = 1; j <= n; j++)
			{
				if (v[j] == i)
					printf("%d ", j);
			}
		}
	}
	return 0;
}