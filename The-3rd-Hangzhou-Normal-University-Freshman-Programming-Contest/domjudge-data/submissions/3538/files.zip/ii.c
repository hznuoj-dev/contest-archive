#include<stdio.h>
int main(){
	long long a,b,c,d;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	int	count=0;
	int i=0,z=0,x=0,v=0;
	while(a>0){
	i=i*10+a%10;
	a=a/10;
	}
	if(i>=16||i==6){
	count++;
	}
	while(b>0){
	z=z*10+b%10;
	b=b/10;
	}
	if(z>=16||z==6){
	count++;
	}
	while(c>0){
	x=x*10+c%10;
	c=c/10;
	}
	if(x>=16|x==6){
	count++;
	}
	while(d>0){
	v=v*10+d%10;
	d=d/10;
	}
	if(v>=16||v==6){
	count++;
	}
	if(count==1){
	printf("Oh dear!!");
	}
	else if(count==2){
	printf("BaoBao is good!!");
	}
	else if(count==3){
	printf("Bao Bao is a SupEr man///!");
	}
	else if(count==4){
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	else if(count==0){
	printf("Bao Bao is so Zhai......");
	}
}