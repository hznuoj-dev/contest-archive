#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main (void){
    long long t,i,j,n,l,k,b,z=1,p=0,zong=0;
    char s,y[99999],d[99999];
    scanf("%lld",&t);
    for(i=1;i<=t;i++){
        scanf("%lld",&n);
        for(j=1;j<=n;j++){
            scanf("%s",&d);
            l=strlen(d);
            for(b=0;b<l;b++){
                s=d[b];
                if(s!='.'){
                for(k=1;k<z;k++){
                    if(y[k]==s){
                        p=1;
                    }
                }
                if(p==0){
                    y[z]=s;
                    z+=1;
			    }
                p=0; 
                }
            }
        zong+=z-1;
        z=1;
        }
    printf("%lld",zong);
    if(i!=t)
    printf("\n");
    zong=0;
    } 
    return 0;
}
