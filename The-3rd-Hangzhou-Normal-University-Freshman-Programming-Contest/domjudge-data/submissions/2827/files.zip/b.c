#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
	long long int a,b,c,i,j,t,m;
	scanf("%lld",&t);
	while(t--)
	{
		j=0;
		scanf("%lld %lld",&a,&b);
		c=a+b;
        if(c>0&&b<0)
         {
                 m=c;
                 c=a;
                 a=m;
               }
        if(c>9999)
           {
            c=9999-(c-9999); 
            while(c<0)
             {
               c=a+c;
             }
              if(c<a)
               {
                 m=c;
                 c=a;
                 a=m;
               }
           }
		for(i=a;i<=b;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
				j++;
		}
		printf("%lld\n",j);
	}
	return 0;
}