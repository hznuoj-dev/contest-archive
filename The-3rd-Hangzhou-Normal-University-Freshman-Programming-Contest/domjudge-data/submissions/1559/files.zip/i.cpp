#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main(void){
	ll count=0,sign=0;
	string a,b,c,d;
	cin>>a>>b>>c>>d;
	for(auto k=a.begin();k!=a.end();k++){
		count=count+*k-'0';
	} 
	if(count>=16||count==6)
		sign++;
	count=0;
	for(auto k=b.begin();k!=b.end();k++){
		count=count+*k-'0';
	} 
	if(count>=16||count==6)
		sign++;
	count=0;
	for(auto k=c.begin();k!=c.end();k++){
		count=count+*k-'0';
	} 
	if(count>=16||count==6)
		sign++;
	count=0;
	for(auto k=d.begin();k!=d.end();k++){
		count=count+*k-'0';
	} 
	if(count>=16||count==6)
		sign++;
	count=0;
	
	if(sign==0){
		cout<<"Bao Bao is so Zhai......";
	}
	if(sign==1){
		cout<<"Oh dear!!";
	}
	if(sign==2){
		cout<<"BaoBao is good!!";
	}
	if(sign==3){
		cout<<"Bao Bao is a SupEr man///!"; 
	}
	if(sign==4){
		cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
	}
	
	
}
