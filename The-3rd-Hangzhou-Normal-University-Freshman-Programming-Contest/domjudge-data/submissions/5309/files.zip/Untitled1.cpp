#include<stdio.h>
int main()
{
	int t;
		float n,m,a=0,w=0,q=0;
	scanf("%d",&t);
	while(t--)
{
	a=0;
	scanf("%f%f",&n,&m);
	q=n;
	w=m;
      printf("[");
    while(m--)
    {
    	printf("#");
	}
	a=q-w;
	while(a--)
	{
	printf("-");
}
    printf("]");
	printf("  %.f%%",w/q*100);
	printf("\n");
}
	
}
