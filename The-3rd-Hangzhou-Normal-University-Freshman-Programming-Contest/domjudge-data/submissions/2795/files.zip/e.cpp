#include<stdio.h>
int main()
{
	long long e,b,c,d;
	scanf("%lld %lld %lld %lld",&e,&b,&c,&d);
	int x=0,y,z=0;
	int a[4]={0,0,0,0};
	while(e>0)
	{
		y=e%10;
		a[1]=a[1]+y;
		e=e/10;
		if(a[1]>=16&&a[1]==6)
		{
			z++;
			break;
		}
	}
	while(b>0)
	{
		y=b%10;
		a[2]=a[2]+y;
		b=b/10;
		if(a[2]>=16&&a[2]==6)
		{
			z++;
			break;
		}
	}
	while(c>0)
	{
		y=c%10;
		a[3]=a[3]+y;
		c=c/10;
		if(a[3]>=16&&a[3]==6)
		{
			z++;
			break;
		}
	}
	while(d>0)
	{
		y=d%10;
		a[4]=a[4]+y;
		d=d/10;
		if(a[4]>=16&&a[4]==6)
		{
			z++;
			break;
		}
	}
	if(z==1)
	printf("Oh dear!!\n");
	else if(z==2)
	printf("BaoBao is good!!\n");
	else if(z==3)
	printf("Bao Bao is a SupEr man///!\n");
	else if(z==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	else if(z==0)
	printf("Bao Bao is so Zhai......\n");
	return 0;
}
