#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t; cin>>t;
	while(t--)
	{
		int m, n; cin>>m>>n;
		printf("[");
		for(int i=1; i<=n; i++) printf("#");
		for(int i=1; i<=m-n; i++) printf("-");
		printf("] ");
		printf("%.0lf%%\n",floor(n*100.0/m));
	}
	return 0;
}


