#include<stdio.h>
#include<string.h>

void main() {
	int t;
	scanf("%d",&t);
	while(t--) {
		int n,sum=0;
		scanf("%d",&n);
		while(n--) {
			char str[100000];
			int num[256]= {0};
			scanf("%s",str);
			for(int i=0; i<strlen(str); i++)
				if(str[i]!='.')
					num[(int)str[i]]++;
			for(int i=0; i<256; i++) {
				if(num[i]>=1)
					sum++;
			}

		}
		printf("%d\n",sum);
	}


}

