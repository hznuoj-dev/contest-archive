#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int T,a,b;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&a,&b);
		printf("[");
		int i=0,j=0;
		for(i=0;i<b;i++)
		printf("#");
		for(j=0;j<(a-b);j++)
		printf("-");
		printf("]");
		printf("%d",100*b/a);
		printf("%% \n");
	
		
	}
	return 0;
}
