﻿#include <stdio.h>
int main() {
    int t, m, n,p;
    scanf("%d", &t);
    while (t--) {
        scanf("%d %d", &n, &m);
        p =(double)m/(double)n*100;
        printf("[");
        n -= m;
        while (m--) {
            printf("#");
        }
        while (n--) {
            printf("-");
        }
        printf("] %d%%\n",p);
    }
    return 0;
}