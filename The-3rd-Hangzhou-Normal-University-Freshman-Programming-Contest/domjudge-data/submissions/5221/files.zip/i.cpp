#include<stdio.h>
int main()
{
	int a,b,i=0,j=0,sum;
	while(j<4){
		sum=0;
		scanf("%d",&a);
		if(a>=10){
		while(a>=10){
			b=a%10;
			a=a/10;
			sum+=b;}
		}
		sum+=a;
		if(sum>=16||sum==6){
			i++;
		}
	j++;}
		if(i==1){
			printf("Oh dear!!\n");
		}
		else if(i==2){
			printf("Bao Bao is good!!\n");
		}
		else if(i==3){
			printf("Bao Bao is am SupEr man!!\n");
		}
		else if(i==4){
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
		}
		else if(i==0){
			printf("Bao Bao is so Zhai......\n");
		}
	return 0;
}
