#include<stdio.h>
int main(){
	int T,a,b,n,m,c[1005],d[1005],i,j,t;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&a,&b);
		for(i=1;i<=a;i++){
			d[i]=i;
		}
		for(i=1;i<=a;i++){
			c[i]=0;
		}
		while(b--){
			scanf("%d %d",&n,&m);
			c[n]++;
		}
		for(i=1;i<=a-1;i++){
			for(j=i+1;j<=a;j++){
				if(c[i]<c[j]){
					t=c[i];
					c[i]=c[j];
					c[j]=t;
					t=d[i];
					d[i]=d[j];
					d[j]=t;
				}
			}
		}
		for(i=1;i<=a-1;i++){
			for(j=i+1;j<=a;j++){
				if(c[i]=c[j]&&d[i]>d[j]){
					t=d[i];
					d[i]=d[j];
					d[j]=t;
				}
		}
	}
	for(i=1;i<=a;i++){
		printf("%d ",d[i]);
	}
}
}
