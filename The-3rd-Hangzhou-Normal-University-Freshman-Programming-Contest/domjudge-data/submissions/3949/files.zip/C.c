#include<stdio.h>
#include<string.h>
int main()
{
	int t,m,n;
	scanf("%d",&t);
	while(t--){
		int i,p;
		scanf("%d %d",&n,&m);
		p=(m*100)/n;
		printf("[");
		for(i=0;i<m;i++)
			printf("#");
		for(i=0;i<n-m;i++)
			printf("-");
		printf("] ");
		printf("%d%%\n",p);
	}
	return 0;
}