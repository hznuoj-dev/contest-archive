#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	int T,i,j,n,m,a;
	char ch[1000001];
	scanf("%d",&T);
	while(T--){
		m=0;
		scanf("%d",&n);
		gets(ch);
		while(n--){
			gets(ch);
			a=strlen(ch);
			for(i=0;i<a;i++){
				if(ch[i]!='.'){
					m++;
					for(j=i+1;j<a;j++){
						if(ch[j]==ch[i])
							ch[j]='.';
					}
				}
			}
		}
		printf("%d\n",m);
	}
	return 0;
}