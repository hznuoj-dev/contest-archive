#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int T=0,i=0;
	long n=0,m=0;
	double pro=0.0;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%ld %ld",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
		printf("#");
		for(i=1;i<=n-m;i++)
		printf("-");
		pro =m*1.0/n;
		printf("] %.lf", pro*100.0);
		printf("%c\n",'%');
}
	return 0;
}                                                                          
