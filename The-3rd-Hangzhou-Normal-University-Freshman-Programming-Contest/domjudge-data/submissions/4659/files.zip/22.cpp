#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
#pragma warning(disable:4996);
using namespace std;

int main() {
	
	int t,m,n,x,y,s=0,i,p;
	scanf("%d", &t);
	while (t--) {
		int a[2000];
		int b[2000] = { 0 };
		s = 2;
		scanf("%d %d", &n, &m);
		scanf("%d %d", &x, &y);
		a[0] = x;
		a[1] = y;
		b[x] = 1;
		b[y] = 1;
		m--;
		
		while (m--) {
			
			scanf("%d %d", &x, &y);
			if (b[x] == 0 && b[y] == 0) {
				a[s] = x;
				a[s + 1] = y;
				s = s + 2;
				b[x] = 1;
				b[y] = 1;
			}
			else if (b[x] == 1 && b[y] == 0) {
				p = -1;
				for (i = 0; i < s; i++) {
					if (a[i] == x) {
						p = i + 1;
					}
				}
				s = s + 1;
				for (i = s; i > p; i--) {
					a[i] = a[i - 1];
				}
				a[p] = y;
				b[y] = 1;
			}
			else if (b[x] == 0 && b[y] == 1) {
				p = -1;
				for (i = 0; i < s; i++) {
					if (a[i] == y) {
						p = i;
					}
				}
				s = s + 1;
				for (i = s; i > p; i--) {
					a[i] = a[i - 1];
				}
				a[p] = x;
				b[x] = 1;
			}
		}
		printf("%d", a[0]);
		for (i = 1; i < s; i++) {
			printf(" %d", a[i]);
		}
		if (s < n) {
			for (i = 1; i <= n; i++) {
				if (b[i] == 0)printf(" %d", i);
			}
		}
		printf("\n");
	}
	return 0;
}