#pragma warning (disable:4996)
#include<stdio.h>
#include<string.h>
int main(void) {
	int a, b, c, i, j, t, o;
	char w[1000001];
	scanf("%d", &a);
	c = 0;
	while (a--) {
		scanf("%s", w);
		b = strlen(w);
		c += b;
	}
	printf("%d\n", c);
	return 0;
}