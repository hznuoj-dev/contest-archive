#include<stdio.h>
int main(){
	int T,i,x,j;
	int Y,year2,A,total;
	scanf("%d",&T);
	while(T--){
		total=0;
		year2=0;
		i=0;
		j=0;
		x=0;
		scanf("%d %d",&Y,&A);
		total=Y+A;
		if(total>9999)
		year2=9999-(total-9999);
		else year2=total;
		i=year2-Y;
		if(i>=0){
		
		for(;Y<=year2;Y+=1){
			if((Y%4==0&&Y%100!=0)||(Y%400==0))
			x+=1;
		}
		printf("%d\n",x);}
		else {for(;year2<=Y;year2+=1)
		{
			if((year2%4==0&&year2%100!=0)||(year2%400==0))
			x+=1;
		}
		printf("%d\n",x);
		}	
		
	}
}
