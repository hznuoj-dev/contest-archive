#include<stdio.h>
int t,n,m,i,x;
int main(){
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		x=m*100/n;
		for(i=1;i<=n;i++){
			if(i==1){printf("[");
			}
		    if(i<=m){
				printf("#");
			}
			if(i>m){
				printf("-");
			}
			if(i==n){
			printf("] %d%%\n",x);
			}	
		}
			
	}
	return 0;
}
