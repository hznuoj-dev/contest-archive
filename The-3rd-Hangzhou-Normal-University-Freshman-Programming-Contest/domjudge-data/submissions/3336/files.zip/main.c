#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,n,m,i;
	double a;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		a=(double)m/n;
		printf("[");
		for(i=1;i<=n;i++){
			if(i<=m)printf("#");
			else printf("-");
		}
		printf("]");
		printf("%.lf%%\n",a*100);
	} 
	return 0;
}
