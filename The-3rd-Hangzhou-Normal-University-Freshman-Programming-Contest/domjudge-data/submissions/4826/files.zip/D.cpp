#include<bits/stdc++.h> 
using namespace std;
int main(){
	string s;
	int a;
	scanf("%d",&a);
	for(int i=1;i<=a;++i) scanf("%s",&s);
	printf("%d",a);
	return 0;
}
