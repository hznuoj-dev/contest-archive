import java.util.Arrays;
import java.util.Scanner;


public class RTY1
{

	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		while(in.hasNext())
		{
			int a=in.nextInt();
			for(int i=1;i<=a;i++)
			{
				double b=in.nextDouble();
				double c=in.nextDouble();
				int qushu=0;
				int xiaozhi=0;
				double f=c/b;
				StringBuffer p=new StringBuffer();
				if(b>c)
				{
					qushu=(int)b;
					xiaozhi=(int)c;
				}
				else
				{
					qushu=(int)c;
					xiaozhi=(int)b;
				}
				String shuzu1[]=new String[qushu];
				for(int i2=0;i2<shuzu1.length;i2++)
				{
					shuzu1[i2]="-";
				}
				for(int i3=0;i3<xiaozhi;i3++)
				{   
					shuzu1[i3]="#";
				}
				for(int i4=0;i4<shuzu1.length;i4++)
				{
					p.append(shuzu1[i4]);
				}
				
				double u=f*100;
				int u2=(int)u;
				
				System.out.println("["+p+"]"+" "+u2+"%");
				
				
				
			}
		}

	}

}
