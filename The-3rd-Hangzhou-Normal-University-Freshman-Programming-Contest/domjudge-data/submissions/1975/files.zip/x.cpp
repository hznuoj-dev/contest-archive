#include<stdio.h>
#include<math.h>
#include<string.h>
int main(){
	char a[20];
	int i,x,z=0,n=4;
	while(n--){
		scanf("%s",a);
		x=0;
		for(i=0;i<strlen(a);i++){
			x=x+a[i]-'0';
		}
		if(x>=16||x==6)
			z++;
	}
	if(z==0)
		printf("Bao Bao is so Zhai......\n");
	else if(z==1)
		printf("Oh dear!!\n");
	else if(z==2)
		printf("BaoBao is good!!\n");
	else if(z==3)
		printf("Bao Bao is a SupEr man///!\n");
	else
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
    return 0;
}