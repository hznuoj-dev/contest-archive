#include<bits/stdc++.h>
using namespace std;
int isleap(int min,int max){
	int cnt=0;
	for(int i=min;i<=max;i++){
		if(i%400==0||(i%4==0&&i%100!=0))cnt++;
	}
	return cnt;
}
int main(){
	int t;
	int min,max;
	int year,y;
		cin>>t;
	while(t--){
		cin>>year>>y;
		if(y<0)
		{
			min=year+y;
			cout<<isleap(min,year)<<endl;
		 } 
		else {
			max=year+y;
			if(max>9999)max=10000-max%9999;
			cout<<isleap(year,max)<<endl;
		}
		
	}
	
	return 0;
} 
