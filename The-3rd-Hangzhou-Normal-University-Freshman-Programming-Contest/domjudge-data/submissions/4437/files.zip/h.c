#include<stdio.h>
int main()
{
	long long n,m,i;
	int t;
	scanf("%d",&t);
	while(t--){
		scanf("%lld %lld",&n,&m);
		printf("[");
		for(i=0;i<m;i++){
			printf("#");
		}
		for(i=0;i<n-m;i++){
			printf("-");
		}
	double p,M,N;
	M=m;N=n;
	p=M/N;
	printf("] %.0f%%\n",p*100);
	}
	return 0;
}
