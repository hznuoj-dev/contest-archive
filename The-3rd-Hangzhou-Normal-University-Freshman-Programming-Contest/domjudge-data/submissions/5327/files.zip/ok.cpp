#include<stdio.h>
#include<string.h>
char s[1000000];
int main(){
	int n,f=0,k,len;
	scanf("%d",&n);
	for(int N=1;N<=n;N++){
		scanf("%d",&k);
		for(int K=1;K<=k+1;K++){
		gets(s);
		len=strlen(s);
		for(int j=0;j<=len-1;j++){
			if(s[j]!='.')f++;	
		}
		continue;
		}
		printf("%d",f);
		if(N!=n)printf("\n");
		f=0;
	}
}
