#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
void bubble(int a[],int b[],int n); 
int main(int argc, char *argv[]) {
	long n,c=0,m,i,j,zong,f,a[101],b[101],zuida[100000]={0},gs[105]={0}; 
	scanf("%ld %ld",&n,&m);
	for(i=1;i<=n;++i){
		scanf("%ld",&a[i]);
	}
	for(i=1;i<=n;++i){
		scanf("%ld",&b[i]);
	
	}
	bubble(a,b,n);
	
	while(j<=n){
		zong=0;
	for(i=1;i<=n;++i){	
		zong=gs[i]*a[i]+zong;
		}
		gs[1]++;
			j=1;
		while(gs[j]>b[j])
			{
				gs[j+1]++;
				gs[j]=0;
				j++;
			} 
		zuida[zong]=1;	
			
	}

	for(i=1;i<=m;++i){
		if(zuida[i]==1)
		c++;
	}
	printf("%ld\n",c);
	return 0;
}
void bubble(int a[],int b[],int n){
	int t,i,j;
	for(i=1;i<=n;++i){
		for(j=1;j<=n-i;++j){
			if(b[j]<b[j+1]){
				t=b[j];
				b[j]=b[j+1];
				b[j+1]=t;
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}	
}







