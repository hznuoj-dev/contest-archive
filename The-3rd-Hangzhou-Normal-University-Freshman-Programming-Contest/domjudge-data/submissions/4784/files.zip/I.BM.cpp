#include<stdio.h>
int main(){
		int m=0;
		long long int A,B,C,D;
		scanf("%lld%lld%lld%lld",&A,&B,&C,&D);
		long long int i,num1=0,num2=0,num3=0,num4=0;
		for(i=A;i>0;i=i/10){
			num1=i%10+num1;
		}
		for(i=B;i>0;i=i/10){
			num2=i%10+num2;
		}
		for(i=C;i>0;i=i/10){
			num3=i%10+num3;
		}
		for(i=D;i>0;i=i/10){
			num4=i%10+num4;
		}
		if(num1>=16||num1==6){
			m++;
		}
		if(num2>=16||num2==6){
			m++;
		}
		if(num3>=16||num3==6){
			m++;
		}
		if(num4>=16||num4==6){
			m++;
		}
		if(m==0){
			printf("Bao Bao is so Zhai......\n");
		}
		else if(m==1){
			printf("Oh dear!!\n");
		}
		else if(m==2){
			printf("BaoBao is good!!\n");
		}
		else if(m==3){
			printf("Bao Bao is a SupEr man///!\n");
		}
		else if(m==4){
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
		}
	return 0;
}
