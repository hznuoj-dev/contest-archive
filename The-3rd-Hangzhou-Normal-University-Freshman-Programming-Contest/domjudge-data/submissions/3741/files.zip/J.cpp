#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<map>
using namespace std;
map<char,int>didt;
map<char,int>::iterator it;
char str[1000100];
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,ans=0;
		scanf("%d",&n);
		for(int i=1;i<=n;i++){
			scanf("%s",str);
			didt.clear();
			for(int j=0;j<strlen(str);j++){
				if(str[j]=='.')continue;
				else{
					it=didt.find(str[j]);
					if(it==didt.end()){
						ans++;
						didt[str[j]]=1;
					}
				}
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
