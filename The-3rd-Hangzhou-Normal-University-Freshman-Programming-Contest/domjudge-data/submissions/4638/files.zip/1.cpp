#include<stdio.h>
#include<math.h>
#include<string.h>
int main(void){
	int t;scanf("%d",&t);
	while(t--){
		int n,m,a[10000],i,j,k,x,y,t;
		scanf("%d %d",&n,&m);
		for (i=1;i<=10000;i++) a[i]=i;
		for (i=1;i<=m;i++){
			scanf("%d %d",&x,&y);
			for (j=1;j<=n;j++) if (a[j]==x) break;
			for (k=1;k<=n;k++) if (a[k]==y) break;
			if (j>k) {
				t=a[j];a[j]=a[k];a[k]=t;
			}	
		}
		for (i=1;i<=n;i++) {
			printf("%d",a[i]);
			if (i!=n) printf(" ");
			else printf("\n");
		} 
		
		
		
	}
	
	
	return 0;
}


  
