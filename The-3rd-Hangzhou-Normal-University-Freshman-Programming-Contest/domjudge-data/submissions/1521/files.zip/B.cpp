#include <stdio.h>
int main ()
{
	int n,a,b,i,t,j,sum;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d %d",&a,&b);
		sum=0;
		b=a+b;
	if(b>9999)
	{
		b=9999-(b-9999);
	}
	if(b<a)
	{
		t=a;
		a=b;
		b=t;
	}
	for(j=a;j<=b;j++)
	{
		if((j%4==0&&j%100!=0)||(j%400==0))
		sum=sum+1;
		
	}
	printf("%d\n",sum);
}
}
