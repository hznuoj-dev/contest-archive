 #include <set>
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <cmath>
#include <ctime>
#include <bitset>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const int maxn = 1e5 + 10;
const int mod = 0;
const int inf = 0x3f3f3f3f;

int gcd(int a, int b) 
{
	return b==0?a:gcd(b,a%b);
}
bool check(int a){
	if(a%4==0&&a%100!=0||(a%400==0))return true;
	return false;
}
int main()
{
int n;

cin>>n;
while(n--)
{
	int ans=0;
	int a,b;
	cin>>a>>b;
	b=a+b;
	if(b>=10000)
	{b=9999*2-b;
	if(b<a){
	int t;
	t=a,a=b,b=t;
	//a=b-a;
	}
	}
	else if(b<a){
		int t;
		t=a,a=b,b=t;
		//cout<<a<<b;
	}
	//cout<<a<<" "<<b<<endl;
	for(int i=a;i<=b;i++)
		if(check(i))ans++;
	cout<<ans<<endl;

}



	return 0;
}
