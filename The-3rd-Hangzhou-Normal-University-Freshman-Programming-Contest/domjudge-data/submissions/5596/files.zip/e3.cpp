#include<stdio.h>
 int main(void)
 {
 	int a,b,c=0,n,i=0,y=0,z=0;
 	scanf("%d",&n);
 	while(n--)
 	{
 		scanf("%d%d",&a,&b);
 		if(b>=0)
 		c=a+b;
 		if(b<0)
 		c=a,a=a+b;
 		if(c>9999)
 		c=c-(c-9999);
 		if(c<a)
 		z=c,c=a,a=z;
 		for(i=a,y=0;i<=c;i++)
 		{
 			if(i%100==0&&i%400==0)
 			y++;
 			if(i%100!=0&&i%4==0)
 			y++;
		 }
		 printf("%d\n",y);
	 }
 	 return 0;
 }
