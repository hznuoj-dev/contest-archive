#include <stdio.h> 
int f(int x){
	int flag=0,sum=0;
	while(x>0){
		sum=sum+x%10;
		x/=10;
	}
	if(sum>=16||sum==6)flag=1;
	return flag;
}
int main(void){
	int a,b,c,d,count=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	if(f(a))count++;
	if(f(b))count++;
	if(f(c))count++;
	if(f(d))count++;
	switch(count){
		case 1:printf("Oh dear!!");
		case 2:printf("BaoBao is good!!");
		case 3:printf("Bao Bao is a SupEr man///!");
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		case 0:printf("Bao Bao is so Zhai......");
	}
	return 0;
}
 
