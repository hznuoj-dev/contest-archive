#include<stdio.h>
int main()
{
	int t,p,a;
	double n,m;
	scanf("%d",&t);
	while(t--){
		scanf("%lf%lf",&n,&m);
		a=m/(n/100);
		p=n-m;
		printf("[")	;
		while(m--)
			printf("#");
		while(p--)
			printf("-");
		printf("]");
		printf(" %d%%\n",a);
	}
}
