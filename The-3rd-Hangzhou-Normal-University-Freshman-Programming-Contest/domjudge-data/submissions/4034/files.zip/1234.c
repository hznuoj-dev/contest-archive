#include<stdio.h>
#include<math.h>
#pragma warning(disable:4996)
int main() {
	int t;
	float n, m, b;
	scanf("%d", &t);
	while (t--) {
		char a[100010] = { NULL};
		scanf("%f%f", &n, &m);
		b = m / n*100;
		int i;
		for (i = 0; i < m; i++) {
			a[i] = '#';
		}
		for (; i < n; i++) {
			a[i] = '-';
		}
		printf("[%s] %.0f%%\n", a, b);
	}
	return 0;
}