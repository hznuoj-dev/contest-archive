#include<stdio.h>
int main()
{
    int T, x, y,z, sum = 0,i,t;
    scanf("%d", &T);
    while (T--)
    {
        sum = 0;
        scanf("%d%d", &x, &y);
        z = x + y;
        if (z > 9999)
        {
            z = 9999 - (z - 9999);
        }
        if (x > z)
        {
            t = x;
            x = z;
            z = t;
        }
        for (i = x; i <= z; ++i)
        {
            if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
            {
                sum += 1;
            }
        }
        printf("%d\n", sum);
    }
    return 0;
}