 #include<stdio.h>
 int main(void)
 {
 	int t,y1,y2,i,a=0,n,b;
 scanf("%d",&t);
 	while(scanf("%d %d",&y1,&n) !=EOF)
 	{
 		t--;
 	
 		
 		y2=y1+n;
 		if(y2>=10000){
 			y2=9999-(y2-10000);
		 }
 		
 		if(y2<y1)
 		{
 			b=y2;
 			y2=y1;
 			y1=b;
 			
		 }
 		
 		for(i=y1;i<=y2;i++)
 		{
 			if((i%4==0&&i%100!=0)||i%400==0){
 				a+=1;
			 }
		 }
 		
 		printf("%d\n",a);
 		a=0;
 		
 		
 		if(t==0)break;
	 }
 	
 	
 	
 	
 	return 0;
 	
 	
 	
 	
 }
