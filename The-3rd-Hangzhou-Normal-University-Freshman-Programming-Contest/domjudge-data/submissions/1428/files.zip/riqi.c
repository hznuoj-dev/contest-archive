#include<stdio.h>
int main(void)
{
int t;
long long int y,a;
long long int sum;
long long int i,j=0;
scanf("%d",&t);
while(t--)
{
	scanf("%lld %lld",&y,&a);
	sum=y+a;
	if(a<0)
	{
		for(i=sum;i<=y;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			j++;
		}
	}
	else
	{
	if(sum<=9999)
	{
		for(i=y;i<=sum;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			j++;
		}
	}
	else
	{
		sum=9999-((y+a)-9999);
		for(i=y;i<=sum;i++)
		{
			if((i%400==0)||(i%4==0&&i%100!=0))
			j++;
		}
	}
    }
	printf("%lld\n",j); 
	sum=0;
	j=0;
	}
return 0;
} 
