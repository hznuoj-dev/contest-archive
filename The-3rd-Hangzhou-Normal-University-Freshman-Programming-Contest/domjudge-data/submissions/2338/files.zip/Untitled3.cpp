#include<stdio.h>
 int main(){
 	int a[4],s,n=0;
 	scanf("%d %d %d %d",&a[0],&a[1],&a[2],&a[3]);
 	for(int i=0;i<4;i++){
 		s=0;
	while(a[i]>0){
		s+=a[i]%10;
		a[i]=a[i]/10;
	}
	if(s>=16||s==6)
	n+=1;
	 } 
	 if(n==1) printf("Oh dear!!");
	 else if(n==2) printf("BaoBao is good!!");
	  else if(n==3) printf("Bao Bao is a SupEr man///!");
	   else if(n==4 )printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	    else printf("Bao Bao is so Zhai......");
 } 
