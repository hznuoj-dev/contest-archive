#include <bits/stdc++.h>
using namespace std;
int main(){
    int t,n;
    cin>>t;
    while(t--){
        cin>>n;
        int count=0;
        while(n--){
            string land;
            char table[114514];
            int mark=0,next=0;
            cin>>land;
            for(int i=0;i<land.size();i++){
                char ch=land[i];
                if(ch=='.') mark=1;
                int flag=0;
                for(int j=0;j<next;j++){
                    if(ch==table[j]){
                        flag=1;
                        break;
                    }
                }
                if(flag==0) table[next++]=ch;
            }
            count+=(next-mark);
        }
        cout<<count<<'\n';
    }
    return 0;
}