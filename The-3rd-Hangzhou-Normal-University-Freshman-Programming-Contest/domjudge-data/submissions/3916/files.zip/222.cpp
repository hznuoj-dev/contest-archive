#include<stdio.h>
#include<string.h>
int main(){
    int T,n,b,s,ss;
    char a[100001];
	scanf("%d",&T);
	while(T--){
		
		ss=0;
		scanf("%d",&n);
		while(n--){
			s=0;
		    int c[130]={0};
			scanf("%s",&a);
			
			int len=strlen(a);
			for(int i=0;i<len;i++){
				if(a[i]!='.'){
					b=a[i]-'0';
					c[b]++;
					if(c[b]==1){
					s=s+1;
					}
				}
			}
			ss+=s;
		}
	printf("%d\n",ss);	
	} 
}
