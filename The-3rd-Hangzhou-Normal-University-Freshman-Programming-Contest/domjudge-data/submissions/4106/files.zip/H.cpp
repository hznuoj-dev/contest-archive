#include <stdio.h>
int main(void){
	float T,a,b,bb,sum,x;
	int y;
	scanf("%d",&T);
	while(T--){
		scanf("%f %f",&a,&b);
		printf("[");
		bb=b;
		while(bb--){
			printf("#");
		}
		sum=a-b;
		while(sum--){
			printf("-");
		}
		printf("] ");
		x=b/a*100;y=x;
		printf("%d%%\n",y);
	}
}
