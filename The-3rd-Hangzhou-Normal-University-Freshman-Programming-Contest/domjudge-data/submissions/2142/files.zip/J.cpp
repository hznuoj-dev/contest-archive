#include<bits/stdc++.h>
using namespace std;


int a[300];

int main(void)
{
	int t;
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		int n,sum=0;
		scanf("%d",&n);
		getchar();
		while(n--)
		{
			for(int i=0;i<=299;++i)
				a[i]=0;
			char in='a';
			while(in!='\n')
			{
				scanf("%c",&in);
				if(in!='.') ++a[in];
			}
			
			for(int i=0;i<=299;++i)
			{
				if(a[i]>0) ++sum;
			}
			--sum;
		}
		printf("%d\n",sum);
	}
	return 0;
}

