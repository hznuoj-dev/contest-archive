#include <stdio.h>
#include <string.h>
char s[1000010];
int main()
{
    int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,sum=0;
		scanf("%d",&n);
		for(int i=1;i<=n;++i)
		{
			int a[1200]={0};
			scanf("%s",s);
			int slen = strlen(s),x;
			for(int i=0;i<slen;++i)
			{
				if(s[i]!='.')
				{
					x=s[i];
					a[x]=1;
			   }
			}
			for(int i=0;i<=1199;++i)
		    {
		 	if(a[i]!=0)
		 	  sum+=1; 
		    }
		 } 
		 printf("%d\n",sum);
	 } 
	return 0;
 } 
