#include <iostream>
using namespace std;

int main()
{
    int t, levels, count;
    char store[129], ch;
    cin >> t;
    for (int i = 1; i <= t; i++)
    {
        count = 0;
        cin >> levels;
        getchar();
        for (int j = 1; j <= levels; j++)
        {
            for (int j = 1; j <= 128; j++)
            {
                store[j] = 0;
            }
            while ((ch = getchar()) != '\n')
            {
                store[ch]++;
            }
            for (int k = 1; k <= 128; k++)
            {
                if (store[k] != 0 && (char)k != '.')
                    count++;
            }
        }
        cout << count << endl;
    }
    return 0;
}