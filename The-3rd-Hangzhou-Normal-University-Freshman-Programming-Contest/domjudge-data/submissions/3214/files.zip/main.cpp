//#include <bits/stdc++.h>
//typedef long long  ll;
//const int MAXN=1e2+5;
#include <cstdio>
#include <algorithm>
#include <iostream>
using namespace std;
int  a[10],b,c,d,l,mid,r,sum[10],n=0,m,t=0,k,x,w,v,y,ans,x2,y2;
int main()
{
    for(int i=1;i<=4;i++)
    cin>>a[i];
    for(int i=1;i<=4;i++)
    while(a[i]>0)
    {
        sum[i]+=a[i]%10;
        a[i]/=10;

    }
    for(int i=1;i<=4;i++)
        if(sum[i]==6||sum[i]>=16)
        n++;

    if(n==1)
        cout<< "Oh dear!!";
    else if(n==2)
        cout<< "BaoBao is good!!";
    else if(n==3)
        cout<< "Bao Bao is a SupEr man///!";
    else if(n==4)
        cout<< "Oh my God!!!!!!!!!!!!!!!!!!!!!";
    else if(n==0)
        cout<<"Bao Bao is so Zhai......";
    return 0;
}


