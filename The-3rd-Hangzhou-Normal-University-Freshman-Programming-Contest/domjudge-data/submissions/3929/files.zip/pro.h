#include<stdio.h>
int main()
{
	int t;
	scanf("%d", &t);
	while (t--)
	{
		long int n, m;
		int per;
		scanf("%ld %ld", &n, &m);
		per = (10000 * m) / (100 * n);
		printf("[");
		for (int i = 0; i < m; i++)
			printf("#");
		for (int i = 0; i < n - m; i++)
			printf("-");
		printf("]");
		printf(" %d", per);
		printf("%%");
		printf("\n");
	}
}