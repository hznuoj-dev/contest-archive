//
//  main.cpp
//  c++_02
//
//  Created by 李尚鑫 on 2020/12/7.
//
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
using namespace std;

int main () {
    int t;
    cin >> t;
    while (t--) {
        int x,y,buf,cnt = 0;
        cin >> x >> y;
        if (x+y>9999) {
            buf = 9999-(x+y-9999);
            if (buf>=x) {
                for (int i=x; i<=buf; i++) {
                    
                    if ((i%4==0 && i%100!=0) || i%400==0) cnt++;
                }
                cout << cnt << endl;
                continue;
            }
            if (buf<=0) {
                for (int i=buf; i<=x; i++) {
                    
                    if ((i%4==0 && i%100!=0) || i%400==0) cnt++;
                }
                cout << cnt << endl;
                continue;
            }
            if (buf<x) {
                for (int i=buf; i<=x; i++) {
                    
                    if ((i%4==0 && i%100!=0) || i%400==0) cnt++;
                }
                cout << cnt << endl;
                continue;
            }
        }
        buf = x+y;
        if (y<0) {
            for (int i=x+y; i<=x; i++) {
                
                if ((i%4==0 && i%100!=0) || i%400==0) cnt++;
            }
            cout << cnt << endl;
            continue;
        }
        for (int i=x; i<=x+y; i++) {
            
            if ((i%4==0 && i%100!=0) || i%400==0) cnt++;
        }
        cout << cnt << endl;
    }
}
