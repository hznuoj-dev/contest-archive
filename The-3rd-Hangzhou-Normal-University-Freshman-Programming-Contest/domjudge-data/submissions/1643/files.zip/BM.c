#include<stdio.h>
int main(){
	char s[100];
	scanf("%s",s);
	printf("__ _____\n");
	printf("| | ___/ ____\\____\n");
	printf("| |/ /\\ __\\/ ___\\\n");
	printf("| < | | \\ \\___\n");
	printf("|__|_ \\ |__| \\___ >\n");
	printf("     \\/          \\/");
}
