#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main (){
	long long int A,B,C,D,m;
	int i,j,sum,bao;
	int a1[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},b1[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},c1[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0},d1[20]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	scanf("%d %d %d %d",&A,&B,&C,&D);
	j=0;
	for(i=18;i>=0;i--){
		m=pow(10,i);
		if(A/m<10&&A/m!=0){
			a1[j]=A/m;
			A=A-a1[j]*m;
			j++;
		}
	}
	for(i=0;i<=20;i++){
		if(a1[i]>10){
			a1[i]=0;
		}
	}
	j=0;
	for(i=18;i>=0;i--){
		m=pow(10,i);
		if(B/m<10&&B/m!=0){
			b1[j]=B/m;
			B=B-b1[j]*m;
			j++;
		}
	}
	for(i=0;i<=20;i++){
		if(b1[i]>10){
			b1[i]=0;
		}
	}
	j=0;
	for(i=18;i>=0;i--){
		m=pow(10,i);
		if(C/m<10&&C/m!=0){
			c1[j]=C/m;
			C=C-c1[j]*m;
			j++;
		}
	}
	for(i=0;i<=20;i++){
		if(c1[i]>10){
			c1[i]=0;
		}
	}
	j=0;
	for(i=18;i>=0;i--){
		m=pow(10,i);
		if(D/m<10&&D/m!=0){
			d1[j]=D/m;
			D=D-d1[j]*m;
			j++;
		}
	}
	for(i=0;i<=20;i++){
		if(d1[i]>10){
			d1[i]=0;
		}
	}
	j=0;
	bao=0;
	sum=0;
	for(i=0;i<=20;i++){
		sum=sum+a1[i];
	}
	if(sum>=16||sum==6){
		bao=bao+1;
	}
	sum=0;
	for(i=0;i<=20;i++){
		sum=sum+b1[i];
	}
	if(sum>=16||sum==6){
		bao=bao+1;
	}
	sum=0;
	for(i=0;i<=20;i++){
		sum=sum+c1[i];
	}
	if(sum>=16||sum==6){
		bao=bao+1;
	}
	sum=0;
	for(i=0;i<=20;i++){
		sum=sum+d1[i];
	}
	if(sum>=16||sum==6){
		bao=bao+1;
	}
	switch(bao){
		case 0:printf("Bao Bao is so Zhai......");break;
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man\/\/\/!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
	return 0;
}
