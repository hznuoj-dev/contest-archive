#include<stdio.h>
#include<string.h>
int main()
{
	int t, n, i, j;
	char a[999], x;
	scanf("%d", &t);
	while (t--)
	{
		int sum = 0;
		scanf("%d", &n);
		while (n--)
		{
			scanf("%s", a);
			int l = strlen(a);
			for (i = 0; i <= l - 1; i++)
			{
				for (j = i + 1; j < l; j++)
				{
					if (a[i] == a[j])
						a[j] = '.';
				}
			}
			int num = 0;
			for (i = 0; i < l; i++)
			{
				if (a[i] != '.')
					num++;
			}
			sum += num;
		}
		printf("%d\n", sum);
	}
	return 0;
}