#include <stdio.h>
#include <math.h>
int year(int num);
int main(void) {
    int t,x=0,i,j,a;
	scanf("%d",&t); 
	int array[t][3];
	for(i=0;i<t;i++){
		for(j=0;j<2;j++){
			scanf("%d",&array[i][j]);
		}
	}
	for(i=0;i<t;i++){
		if(array[i][1]<0){
			array[i][2]=array[i][0]-abs(array[i][1]);
		}
		else{
			array[i][2]=array[i][0]+array[i][1];
		}
		if(array[i][2]>9999){
			array[i][2]=9999-(array[i][2]-9999);
		}
	}
	for(i=0;i<t;i++){
		if(array[i][0]>array[i][2]){
			for(a=array[i][2];a<=array[i][0];a++){
			    if(year(a)==1){
			    	x++;
				}
		    }
		}
		else{
			for(a=array[i][0];a<=array[i][2];a++){
			    if(year(a)==1){
			    	x++;
				}
		    }
		}
		printf("%d\n",x);
		x=0;
	}
    return 0;

}
int year(int num){
	int ret=0;
	if(num%4==0&&num%100!=0||num%400==0){
		ret=1;
	}
	return ret;
}

