#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main() 
{
	int T=0;
	long long n=0,m=0;
	long long i=0;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%lld %lld",&n,&m);
		putchar('[');
		for(i=1;i<=m;i++)
			putchar('#');
		for(i=1;i<=n-m;i++) 
			putchar('-'); 
		printf("] %.0Lf" ,(double)m/n*100.0);
		putchar('%');
		putchar('\n');
	} 
	return 0;
}                                                                      
