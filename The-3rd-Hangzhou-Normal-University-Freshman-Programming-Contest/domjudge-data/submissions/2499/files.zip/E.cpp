#include"stdio.h"
int main(void){
	char ch[10];
	scanf("%s",&ch);
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___ >\n");
	printf("     \\/          \\/");
    return 0;

}   
