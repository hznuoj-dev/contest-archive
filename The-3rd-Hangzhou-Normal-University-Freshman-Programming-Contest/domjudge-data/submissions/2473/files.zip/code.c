#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
    char a[20], b[20], c[20], d[20];
    int q = 0, w = 0, e = 0, r = 0, s = 0, i;
    scanf("%s %s %s %s", a, b, c, d);
    for (i = 0; a[i] != '\0'; i++) {
        q = q + a[i] - 48;
    }
    if (q == 6 || q >= 16) {
        s++;
    }
    for (i = 0; b[i] != '\0'; i++) {
        w = w + b[i] - 48;
    }
    if (w == 6 || w >= 16) {
        s++;
    }
    for (i = 0; c[i] != '\0'; i++) {
        e = e + c[i] - 48;
    }
    if (e == 6 || e >= 16) {
        s++;
    }
    for (i = 0; d[i] != '\0'; i++) {
        r = r + d[i] - 48;
    }
    if (r == 6 || r >= 16) {
        s++;
    }
    if (s == 0) {
        printf("Bao Bao is so Zhai......");
    }
    else if (s == 1) {
        printf("Oh dear!!");
    }
    else if (s == 2) {
        printf("BaoBao is good!!");
    }
    else if (s == 3) {
        printf("Bao Bao is a SupEr man///!");
    }
    else if (s == 4) {
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    }
    return 0;
}