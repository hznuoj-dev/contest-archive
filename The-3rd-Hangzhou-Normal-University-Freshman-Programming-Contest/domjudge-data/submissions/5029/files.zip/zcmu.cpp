#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int r,a,len,sum,n,m,d[10000];
	char b[10000],c[10000];
	scanf("%d",&r);
	for(int i=0;i<r;i++){
		scanf("%d",&a);
		sum=0;
		for(int i=0;i<a;i++){
			n=0;
			m=0;
			scanf("%s",b);
			len=strlen(b);
			for(int i=0;i<len;i++){
				if(b[i]=='#')n++;
				if(b[i]=='@')m++;
			}
			if(n>0)sum++;
			if(m>0)sum++;
		}
		printf("%d\n",sum);
	}
	return 0;
}
