#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+100;
const int INF=0x3f3f3f3f;
vector<int>v[N];
int a[N];
int f(int x,int m){
	int add=0;
	for(int i=1;i<=m;++i){
		add+=lower_bound(v[a[i]].begin(),v[a[i]].end(),x)-v[a[i]].begin();
	}
	return add;
}
int main(){
	int n; scanf("%d",&n);
	for(int i=1;i<=n;++i){
		int m; scanf("%d",&m);
		while(m--){
			int num; scanf("%d",&num);
			v[i].push_back(num);
		}
		sort(v[i].begin(),v[i].end());
	}
	int q; scanf("%d",&q);
	while(q--){
		int m,aim;
		scanf("%d",&m);
		for(int i=1;i<=m;++i) scanf("%d",&a[i]);
		scanf("%d",&aim);
		int l=1,r=1e9;
		int ans=0;
		while(l<=r){
			int mid=l+r>>1;
			if(f(mid,m)<=aim-1){
				ans=mid;
				l=mid+1;
			}
			else{
				r=mid-1;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
