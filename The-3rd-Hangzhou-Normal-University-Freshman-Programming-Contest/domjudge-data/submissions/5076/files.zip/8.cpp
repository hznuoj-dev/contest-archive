#include<stdio.h>
int main()
{
	double a[10][2];
	int n,i,k,j;
	double s;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		for(j=0;j<2;j++){
			scanf("%lf",&a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		printf("[");
		for(j=0;j<a[i][1];j++){
			printf("#");
		}
		for(j=0;j<a[i][0]-a[i][1];j++){
			printf("-");
		}
		printf("]");
		s=(a[i][1])/(a[i][0])*100;
		printf("%.0f",s);
		printf("%c",'%');
		printf("\n");
	}
 }
