#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include <string.h>
int main()
{
    int t, y, a, x, m, i, s;
    scanf("%d", &t);
    while (t--) {
        s = 0;
        scanf("%d %d", &y, &a);
        x = y + a;
        if (x > 9999) {
            x = 9999 - (x - 9999);

        }
        if (x > y) {
            m = y;
            y = x;
            x = m;

        }
        for (i = x;i <= y;i++) {
            if (i % 4 == 0) {
                if (i % 100 == 0) {
                    if (i % 400 == 0) {
                        s++;
                        continue;
                    }
                    else {
                        continue;
                    }
                }
                else {
                    s++;
                    continue;
                }
            }
            else {

                continue;
            }
        }
        printf("%d\n", s);
        printf("%d\n", x);
        printf("%d\n", y);
    }
    return 0;
}