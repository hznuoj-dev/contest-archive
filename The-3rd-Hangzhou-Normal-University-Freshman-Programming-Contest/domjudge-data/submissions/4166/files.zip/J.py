T=int(input())
for i in range(T):
    n=int(input())
    x = 0
    for i in range(n):
        list1 =[]
        new=[]
        list1 = input()
        for i in list1:
            if i !='.':
                if i not in new:
                    new.append(i)
        x+=len(new)
    print(x)

os._exit(0)
