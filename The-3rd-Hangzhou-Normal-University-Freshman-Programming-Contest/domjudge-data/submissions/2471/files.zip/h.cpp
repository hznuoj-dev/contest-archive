#include<bits/stdc++.h>
using namespace std;
#define ll long long


int main(void){
	ll n;
	cin>>n;
	while(n--){
		ll a,b;
		double c;
		cin>>a>>b;
		cout<<"[";
		for(int k=0;k<b;k++)
			cout<<"#";
		for(int k=0;k<a-b;k++)
			cout<<"-";
		cout<<"] ";
		c=(double)b/(double)a;
		printf("%.0f",c*100);
		cout<<"%";
		if(n>0)
			cout<<endl;
		
	}
}

