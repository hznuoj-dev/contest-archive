#include<stdio.h>
int main()
{
	long long a,b,c,d;
	long long acp[5];
	for(int j=0;j<4;j++)
	{
		scanf("%lld",acp[j]);
	}
	int s=0,imp,i;
	for(int m=0;m<4;m++)
	{
		imp=acp[m];
		s=0;
		while(imp!=0) 
		{ 
			s=s+imp%10;
			imp=imp/10;
		} 
		if(s>=16||s==6)
		i++;
	}
	if(i==0)
	printf("Bao Bao is so Zhai......");
	if(i==1)
	printf("Oh dear!!");
	if(i==2)
	printf("BaoBao is good!!");
	if(i==3)
	printf("Bao Bao is a SupEr man///!");
	if(i==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
