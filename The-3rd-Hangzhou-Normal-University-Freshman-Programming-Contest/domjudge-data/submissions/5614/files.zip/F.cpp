#include<bits/stdc++.h>
using namespace std;
int dp[21][1010];
int w[21],c[21];
int main()
{
	int n,v;
	cin>>n>>v;
	for(int i=1;i<=n;++i)
		cin>>c[i]>>w[i];
	for(int i=1; i<=n; i++)
	{
		for(int j=0; j<=v; j++)
		{
			for(int k=0; k<=w[i]; k++)
			{
				if(j>=c[i]*k)
					dp[i][j]=max(dp[i-1][j-c[i]*k]+w[i]*k,dp[i][j]);
			}
		}
	}
	/*for(int i=1; i<=v; i++)
	{
		for(int j=1; j<=v; j++)
		{
			 printf("%d ",dp[i][j]);
		}
		printf("\n");	
	}*/
	cout<<dp[n][v]<<endl;
	return 0;
}
/*
int main()
{
	int n,v;
	cin>>n>>v;
	for(int i=1;i<=n;++i)
		cin>>w[i]>>c[i]>>w[i];
	for(int i=1; i<=n; i++)
	{
		for(int j=0; j<=v; j++)
		{
			for(int k=0; k<=w[i]; k++)
			{
				if(j>=c[i]*k)
					dp[i][j]=max(dp[i-1][j-c[i]*k]+w[i]*k,dp[i][j]);
			}
		}
	}
	cout<<dp[n][v]<<endl;
	return 0;
	*/
