#include<stdio.h>
int pd(int y){
	if(y%100!=0&&y%4==0||y%400==0) return 1;
	else return 0; 
}
int main(){
	int t; 
	scanf("%d",&t); 
	int year,a; 
	for(int i=1;i<=t;i++){
		int sum=0; 
		scanf("%d %d",&year ,&a); 
		int x=year,y=year+a; 
		if(y>9999){
			y-=y-9999; 
		}   
		if(x>y){
			int temp=x; 
			x=y;
			y=temp;
		}
		for(int j=x;j<=y;j++){
			if(pd(j)) sum++; 
		}
		printf("%d\n",sum); 
	} 
	 
	return 0;
} 
