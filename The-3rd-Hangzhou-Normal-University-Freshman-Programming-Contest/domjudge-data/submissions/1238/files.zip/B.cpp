#include<iostream>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
int main(){
	fcio;
	int T;
	while(cin>>T){
		while(T--){
			int x,y,a;
			cin>>x>>a;
			int cnt=x+a;
			if(cnt<=9999)y=cnt;
			else{
				y=9999-(cnt-9999);
			}
			//cout<<x<<" "<<y<<endl;
			if(x>y){
				swap(x,y);
			}
			int num=0;
			for(int i=x;i<=y;++i){
				if((i%4==0&&i%100!=0)||(i%400==0))
					num++;
			}
			cout<<num<<endl;
			
		}
	}
}

