 #include <set>
#include <map>
#include <deque>
#include <queue>
#include <stack>
#include <cmath>
#include <ctime>
#include <bitset>
#include <cstdio>
#include <string>
#include <vector>
#include <cstdlib>
#include <cstring>
#include <iostream>
#include <algorithm>
typedef long long ll;
typedef unsigned long long ull;
using namespace std;
const int maxn = 1e5 + 10;
const int mod = 0;
const int inf = 0x3f3f3f3f;

int gcd(int a, int b) 
{
	return b==0?a:gcd(b,a%b);
}
bool check(int a){
	if(a%4==0&&a%100!=0||(a%400==0))return true;
	return false;
}
int main()
{
int n;
cin>>n;
while(n--){
	int a,b;
	cin>>a>>b;
	cout<<"[";
	for(int i=0;i<b;i++)
		cout<<"#";
	for(int i=1;i<=a-b;i++)
		cout<<"-";
	cout<<"] ";
	printf("%.0f%%\n",b*1.0/a*100);

}
	return 0;
}
