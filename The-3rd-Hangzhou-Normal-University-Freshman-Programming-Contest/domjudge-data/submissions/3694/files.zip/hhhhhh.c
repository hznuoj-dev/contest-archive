#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,a,b,i;
	float x;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&a,&b);
		printf("[");
		for(i=1;i<=b;++i){
			printf("#");
			
		}
		for(i=1;i<=a-b;++i){
			printf("-");
		}
		printf("] ");
		x=b*1.0/a;
		printf("%.0f%%\n",x*100);
	} 
	
	return 0;
}
