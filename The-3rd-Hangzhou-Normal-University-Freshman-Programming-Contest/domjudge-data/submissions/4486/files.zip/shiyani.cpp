#include<stdio.h>
int main()
{
	long a,b,c,d;
	int sumA,sumB,sumC,sumD;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	sumA=0;
	while(a>0)
	{
		sumA=a%10;
		a/=10;
	if(sumA>=16||sumA==6)
		printf("Oh dear!!\n");	
	}
	
	sumB=0;
	while(b>0)
	{
		sumB=b%10;
		b/=10;
	if(sumB>=16||sumB==6)
		printf("Oh dear!!\n");	
	}

	sumC=0;
	while(c>0)
	{
		sumC=c%10;
		c/=10;
	if(sumC>=16||sumC==6)
		printf("Oh dear!!\n");	
	}
	
	sumD=0;
	while(d>0)
	{
		sumD=d%10;
		d/=10;
	if(sumD>=16||sumD==6)
		printf("Oh dear!!\n");	
	}
	if(sumA>=16||sumA==6&&sumB>=16||sumB==6||sumA>=16||sumA==6&&sumC>=16||sumC==6||sumA>=16||sumA==6&&sumD>=16||sumD==6||sumB>=16||sumB==6&&sumD>=16||sumD==6||sumB>=16||sumB==6&&sumC>=16||sumC==6||sumC>=16||sumC==6&&sumD>=16||sumD==6)
	{
		printf("BaoBao is good!!");	
	}
	if(sumA>=16||sumA==6&&sumB>=16||sumB==6&&sumC>=16||sumC==6||sumA>=16||sumA==6&&sumB>=16||sumB==6&&sumD>=16||sumD==6||sumA>=16||sumA==6&&sumC>=16||sumC==6&&sumD>=16||sumD==6||sumB>=16||sumB==6&&sumC>=16||sumC==6&&sumD>=16||sumD==6)
	{
		printf("Bao Bao is a SupEr man///!");
	}
	if(sumA>=16||sumA==6&&sumB>=16||sumB==6&&sumC>=16||sumC==6&&sumD>=16||sumD==6)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	else
	{
		printf("Bao Bao is so Zhai......");
	}
	return 0;
}
