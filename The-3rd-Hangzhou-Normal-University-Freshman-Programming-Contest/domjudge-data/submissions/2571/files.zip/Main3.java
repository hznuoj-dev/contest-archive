import java.util.Scanner;

public class Main3
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{
          int t=sc.nextInt();
          while(t-->0)
          {
        	  int n=sc.nextInt();
        	  int sum=0;
        	  while(n-->0)
        	  {
        		  String lj=sc.next().replace(".", "");
        		  while(lj.equals("")==false)
        		  {
        			  lj=lj.replace(lj.charAt(0)+"", "");
        			  sum++;
        		  }       		  
        	  }
        	  System.out.println(sum);
        			  
          }
		}

	}

}
