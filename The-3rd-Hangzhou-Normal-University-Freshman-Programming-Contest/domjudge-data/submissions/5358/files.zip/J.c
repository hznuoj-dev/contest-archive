#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,n,i,j,y,len,sum;
	int k=0;
	char s[1000000];
	scanf("%d",&t);

	while(t--){
		scanf("%d",&n);
		sum=0;
		for(i=1;i<=n;i++){	
			getchar(); 
			gets(s);
			len=strlen(s);
			/*for(y=0;y<strlen(a);y++)
			{
				a[y]='\0';
			}*/
			char a[1000]={};
			for(j=0;j<len;j++){
				if(s[j]!='.'){
					int w=0;
					for(w=0;w<k;w++)
					{
						if(s[j]==a[w])
						{
							break;
						}
					}
					if(w==k)
					{
						a[k]=s[j];
						k++;
						sum=sum+1;
					}
		
				}
			}
		}
		printf("%d\n",sum);	
} 
	return 0;
}
