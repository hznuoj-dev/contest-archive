#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int n,k,i,h,y,t,temp,j,sum;
	char a[1000001],b[1000001];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		sum=0;
		while(n--){
			h=0;
			scanf("%s",a);
			temp=strlen(a)-1;
			for(k=0;k<=temp;k++){
				if(a[k]!='.'){
					if(h==0)
						b[h]=a[k],h+=1;
					if(h!=0){
						for(j=0;j<=h-1;j++){
							if(a[k]==b[j])
								break;
							if(j==h-1){
								b[h]=a[k],h+=1;
								break;
							}
						}
					}
				}
			}
			sum+=h;
		}
		printf("%d\n",sum);
	}
	return 0;
}
//int cmp(const void*p,const void*q){
//return((struct kx*)q)->average -(struct kx*)p)->average)
//}