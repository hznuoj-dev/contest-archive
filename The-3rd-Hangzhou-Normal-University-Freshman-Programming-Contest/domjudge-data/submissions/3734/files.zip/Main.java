import java.util.Scanner;

public class main
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner((System.in));
        while (in.hasNext())
        {
            int n = in.nextInt();
            for (int i = 0; i <= n; i++)
            {
                double a = in.nextInt();
                double b = in.nextInt();
                System.out.print("[");
                for (int j = 1; j <= b; j++)
                {
                    System.out.print("#");
                }
                for (int j = 1; j <= a - b; j++)
                {
                    System.out.print("-");
                }
                System.out.print("]");
                double c = b / a * 100;
                int d = (int) c;
                System.out.println(d + "%");
            }
        }
    }
} 