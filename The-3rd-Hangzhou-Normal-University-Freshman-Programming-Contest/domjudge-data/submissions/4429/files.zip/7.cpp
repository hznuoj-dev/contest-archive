#include<stdio.h>
#include<stdlib.h>
int comp(const void*p,const void*q);
int main(void){
	int t,n,m,i,j,max=0;
	scanf("%d",&t);
	while(t--)
	scanf("%d%d",&n,&m);
	int s[n][2],a[n+1],b[n+1];
	for(i=0;i<n;++i){
		for(j=0;j<2;++j){
			scanf("%d",&s[i][j]);
		}
	}
	for(i=0;i<n+1;++i)
	a[i]=0;
	for(i=0;i<n;++i){
			a[s[i][0]]+=1;
			a[s[i][1]]-=1;
	}
	for(i=1;i<n+1;++i)
	b[i]=a[i];
	qsort(b,n+1,sizeof(int),comp);
	do{
	for(i=1;i<=n;++i){
		if(a[i]==b[n])
		printf("%d ",i);
	}
	n-=1;
}while(n>0);
}
int comp(const void*p,const void*q){
	return (*(int *)p-*(int *)q);
} 
