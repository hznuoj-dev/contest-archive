#include <stdio.h>
int main()
{
	int j,t,i;
	double a,b,s;
	char c='%';
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		scanf("%lf %lf",&a,&b);
		printf("[");
		for(j=1;j<=b;j++){
			printf("#");
		}
		for(j=1;j<=a-b;j++){
			printf("-");
		}
		printf("] ");
		printf("%.0lf%c\n",100*b/a,c);
	}

	return 0;
}

