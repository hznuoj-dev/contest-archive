#include<stdio.h>
int main(){
	int T,i,x,j;
	int year1,year2,num,total;
	scanf("%d",&T);
	while(T--){
		total=0;
		year2=0;
		i=0;
		j=0;
		x=0;
		scanf("%d %d",&year1,&num);
		total=year1+num;
		if(total>9999)
		year2=9998;
		else year2=total;
		i=year2-year1;
		if(i>=0){
		
		for(;i>=0;i-=1,year1+=1){
			if((year1%4==0&&year1%100!=0)||(year1%400==0))
			x+=1;
		}
		printf("%d\n",x);}
		else {for(;year2<=year1;year2+=1)
		{
			if((year2%4==0&&year2%100!=0)||(year2%400==0))
			x+=1;
		}
		printf("%d\n",x);
		}	
		
	}
}
