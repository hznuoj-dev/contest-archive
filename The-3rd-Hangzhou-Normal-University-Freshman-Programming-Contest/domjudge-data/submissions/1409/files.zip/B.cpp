#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
int v,n,m,x,y,i,j,t=0,sum,temp,s;
int main(){
    scanf("%d",&n);
    for(i=1;i<=n;i++){
        scanf("%d%d",&x,&y);
        sum=x+y;
        if(sum>9999){
            sum=sum-9999;
            sum=9999-sum;
        }
        if(sum<x){
            temp=sum;
            sum=x;
            x=temp;
        }
        for(j=x;j<=sum;j++){
            if((j%4==0&&j%100!=0)||j%400==0)
                s++;
        }
        printf("%d\n",s);
        s=0;
    }
    return 0;
}
