




import java.util.Scanner;
public class ADF
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		
		    int xiabiao=0;
		    int qishidian=0;
			while(in.hasNext())
			{
				String a=in.next();
				if(a.equals("kfc"))
				{   
					System.out.println("__ _____\n" +
                           "| | ___/ ____\\____\n" +
                           "| |/ /\\ __\\/ ___\\\n" +
                           "| < | | \\ \\___\n" +
                           "|__|_ \\ |__| \\___ >\n" +
                           "\\/ \\/");
					
				}
	}
}
}
        