/*#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main()
{
	int t, x, y, z;
	int sum;
	int mid;
	int i, n;
	scanf("%d",&t);
	for (i = 0; i < t; i++)
	{
		sum = 0;
		scanf("%d %d", &x, &y);
		z = x + y;
		if (z > 9999) z = 9999 - (z - 9999);
		if (x > z)
		{
			mid=x; x = z; z = mid;
		}
		for (n = x; n <= z; n++)
		{
			if (n % 4 == 0 && n % 100 != 0) sum = sum + 1;
			if (n % 100 == 0 && n % 400 == 0) sum = sum + 1;
		}
		printf("%d\n", sum);
		
	}
	return 0;
}
#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main()
{
	char a[18];
	int i, m;
	for(i=0;i<4;i++)
	{
		scanf("%s", &a);*/

#include<stdio.h>
#pragma warning (disable:4996)
#include<string.h>
int main()
{
	int a[3];
	gets(a);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  |\ \  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");
	return 0;
}