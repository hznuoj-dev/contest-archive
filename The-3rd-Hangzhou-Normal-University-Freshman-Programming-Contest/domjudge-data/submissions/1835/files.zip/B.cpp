#include<stdio.h>
int main()
{
	int t,y,a,sum;
	scanf("%d",&t);
	for(int i=0;i<t;i++)
	{
		sum=0;
		scanf("%d%d",&y,&a);
		if(y+a<10000)
		{
			if(a<=0)
			{
				for(int j=y+a;j<=y;j++)
				{
					if((j%4==0&&j%100!=0)||j%400==0)
					{
						sum=sum+1;
					}
				}
			}
			else if(a>0)
			{
			
				for(int j=y;j<=y+a;j++)
				{
					if((j%4==0&&j%100!=0)||j%400==0)
					{
						sum=sum+1;
					}
				}
			}
		}
		else
		{
			for(y;y<=y-(y+a-9999);y++)
			{
				if((y%4==0&&y%100!=0)||y%400==0)
				{
					sum=sum+1;
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
 } 
