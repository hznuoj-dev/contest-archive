#include <stdio.h>
#pragma warning(disable:4996)
//#include <process.h>
int main(){
/*	int T,i,j,n,len,k,m=0,x;
	char s[1000000];
	scanf("%d",&T);
	for(i=1;i<=T;i++)
	{
		m=0;
	scanf("%d",&n);
	for(j=1;j<=n;j++)
	{
		scanf("%s",&s);
		len=strlen(s);
		for(k=1;k<len;k++)
		{
			if((int)s[0]!=(int)s[k])
				for(x=0;x<k;x++)
				{
					if((int)s[x]==(int)s[k])
						break;
				}
				if(((int)s[x]!=(int)s[k])&&x==k-1)
					m++;
     	}
	}
			printf("\n%d\n",s[0]);

	if((int)s[0]==46)
	printf("%d\n",m-1);
	else if((int)s[0]!=46)
			printf("%d\n",m);
	}*/
	int T,i,j,k;
	double m,n;
	scanf("%d",&T);
	for(i=1;i<=T;i++)
	{
	scanf("%lf %lf",&n,&m);
	printf("[");
	for(j=1;j<=m;j++)
		printf("#");
	for(k=1;k<=n;k++)
	printf("-");
	printf("]  %d%%\n",(int)((m/n)*100.00));
	}
//	system ("pause");
return 0;
}
