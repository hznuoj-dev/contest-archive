#include<bits/stdc++.h>
using namespace std;

int main(void){

    int t;
    cin >> t;
    while(t--){
        int a,b;
        cin >> a >> b;
        int x = b * 100 / a;
        cout << "[";
        for(int i = 1;i <= a;i++){
            if(i <= b) cout << "#";
            else cout << "-";
        }
        cout << "] " << x << "%" << endl;
    }

    return 0;
}