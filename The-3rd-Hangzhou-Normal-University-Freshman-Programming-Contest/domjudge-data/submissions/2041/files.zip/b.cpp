#include<stdio.h>
int main(){
	int m,n,t,c,d,s,i;
	scanf("%d",&t);
	while(t--){
		s=0;
		scanf("%d %d",&m,&n);
		c=m+n;
		if(c>9999)
			d=9999-(c-9999);
			if(c<=9999&&n>0)
			d=c;
			if(c<9999&&n<0){
				d=m;
				m=c;
			}
		for(i=m;i<=d;i++){
			if((i%4==0&&i%100!=0)||(i%400==0))
			s=s+1;
		} 
		printf("%d\n",s);
	}
} 
