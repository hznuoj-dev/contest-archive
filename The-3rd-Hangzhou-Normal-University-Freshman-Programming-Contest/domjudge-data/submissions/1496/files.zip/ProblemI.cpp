#include <iostream>
using namespace std;
using LL = unsigned long long;

LL CountBits(LL num) {
    LL sum = 0;

    while (num > 0) {
        sum += num % 10;
        num /= 10;
    }

    return sum;
}

int main() {
    ios::sync_with_stdio(false);
    LL a[4], result, counter = 0;

    cout << CountBits(15) << '\n';
    cin >> a[0] >> a[1] >> a[2] >> a[3];

    for (int i = 0; i < 4; ++i) {
        result = CountBits(a[i]);
        if (result >= 16 || result == 6) {
            ++counter;
        }
    }

    switch (counter)
    {
        case 0:
            cout << "Bao Bao is so Zhai......";
            break;
        case 1:
            cout << "Oh dear!!";
            break;
        case 2:
            cout << "BaoBao is good!!";
            break;
        case 3:
            cout << "Bao Bao is a SupEr man///!";
            break;
        case 4:
            cout << "Oh my God!!!!!!!!!!!!!!!!!!!!!";
            break;
        
        default:
            break;
    }
    
    return 0;
}