#include <stdio.h>
#include <math.h>
int main (){
	long long a,b,c,d,p=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	int n=0,all[5];
	for(all[0]=0;a!=0;){
		p=a%10;
		all[0]=all[0]+p;
		a=a/10;
	}
	p=0;
	for(all[1]=0;b!=0;){
		p=b%10;
		all[1]+=p;
		b=b/10;
	}
	p=0;
	for(all[2]=0;c!=0;){
		p=c%10;
		all[2]+=p;
		c=c/10;
	}
	p=0;
	for(all[3]=0;d!=0;){
		p=d%10;
		all[3]+=p;
		d=d/10;
	}
	p=0;
    for(int i=0;i<=3;i++){
    	if(all[i]>=16||all[i]==6){
    		n=n+1;
		}
	}
	printf("%d %d %d %d %d\n",n,all[0],all[1],all[2],all[3]);
	if(n==0){
		printf("Bao Bao is so Zhai......");
	}
	else if(n==1){
		printf("Oh dear!!");
	}
	else if(n==2){
		printf("BaoBao is good!!");
	}
	else if(n==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else if(n==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}

	return 0;
}
