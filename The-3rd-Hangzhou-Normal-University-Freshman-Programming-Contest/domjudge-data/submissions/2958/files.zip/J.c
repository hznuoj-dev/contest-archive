#include<stdio.h>
#include<string.h>
int main()
{
	int t, a, sum1, sum2, i, j, c;
	char b[1000000];
	scanf("%d", &t);
	while (t--)
	{
		sum2 = 0;
		scanf("%d", &a);
		for (i = 0; i < a; i++)
		{
			sum1 = 0;
			scanf("%s", b);
			for (j = 0; j < strlen(b); j++)
			{
				if (b[j] != '.')
				{
					for (c = j - 1; c >= 0; c--)
					{
						if (b[j] == b[c])
							break;
					}
					if (c < 0)
					{
						sum1++;
					}
				}
			}
			sum2 = sum1 + sum2;
		}
		printf("%d\n", sum2);
	}

}