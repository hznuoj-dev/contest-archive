#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(){
	int a,b,c,d,num=0,sum=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	while(a>=10){
		sum=sum+a%10;
		a=a/10;
	}
	sum=a+sum;
	if(sum>=16||sum==6){
		num=num+1;
	}
	sum=0;
	while(b>=10){
		sum=sum+b%10;
		b=b/10;
	}
	sum=b+sum;
	if(sum>=16||sum==6){
		num=num+1;
	}
	sum=0;
	while(c>=10){
		sum=sum+c%10;
		c=c/10;
	}
	sum=c+sum;
	if(sum>=16||sum==6){
		num=num+1;
	}
	sum=0;
	while(d>=10){
		sum=sum+d%10;
		d=d/10;
	}
	sum=d+sum;
	if(sum>=16||sum==6){
		num=num+1;
	}
	sum=0;
	if(num==1){
		printf("Oh dear!!");
	}
	else if(num==2){
		printf("BaoBao is good!!");
	}
	else if(num==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else if(num==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	else if(num==0){
		printf("Bao Bao is so Zhai......");
	}

	
}

	
