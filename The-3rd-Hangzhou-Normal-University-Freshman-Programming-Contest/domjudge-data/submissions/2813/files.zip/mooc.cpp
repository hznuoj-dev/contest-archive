#include<math.h> 
#include<stdio.h> 
#include<string.h>   
//using namespace std;
 int main()  
{	int b,c,d,cnt,sum=0;int a;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	//printf("%.0lf",cnt);
	cnt=0;
	while(a!=0)
	{	
		cnt+=a%10;
		a/=10;
	}if(cnt>=16||cnt==6)sum++;
	cnt=0;
	while(b!=0)
	{	
		cnt+=b%10;
		b/=10;
	}if(cnt>=16||cnt==6)sum++;
	cnt=0;
	while(c!=0)
	{	
		cnt+=c%10;
		c/=10;
	}if(cnt>=16||cnt==6)sum++;
	cnt=0;
	while(d!=0)
	{	
		cnt+=d%10;
		d/=10;
	}if(cnt>=16||cnt==6)sum++;
	
	if(sum==0)printf("Bao Bao is so Zhai......");
	if(sum==1)printf("Oh dear!!");
	if(sum==2)printf("BaoBao is good!!");
	if(sum==3)printf("Bao Bao is a SupEr man///!");
	if(sum==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
}
