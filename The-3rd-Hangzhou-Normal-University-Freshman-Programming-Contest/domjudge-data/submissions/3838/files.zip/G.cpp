#include<stdio.h>
int main(){
   int T,k,q,n,l,i,m,x;
   int a[100],b[100];
   int t[1000];
   scanf("%d",&T);
   while(T--){
   scanf("%d %d",&n,&m);
   k=m;
   for(i=1;i<=n;i++){
   	t[i]=i;
   } 
    while(m--){
   	scanf("%d %d",&a[m],&b[m]);
	    for(x=k;x>m;x--){
   	 	    if(b[x]==b[m])
   	 	    {
   	 	      if(a[x]>a[m]&&t[a[x]]<t[a[m]]){
   	 	      	q=t[a[x]];
   	 	      	t[a[x]]=t[a[m]];
   	 	      	t[a[m]]=q;
				}	
			}
		}
   	if(a[m]>b[m]&&t[a[m]]>t[b[m]])
   	{
   	 q=t[a[m]];
   	 t[a[m]]=t[b[m]];
   	 t[b[m]]=q;
   	    
    }
    }
    for(l=1;l<=n;l++){
    	printf("%d",t[l]);
    	if(l!=n)
    	printf(" ");
	}  
   }
}
