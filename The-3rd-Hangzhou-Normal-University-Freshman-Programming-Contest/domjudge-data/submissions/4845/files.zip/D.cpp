#include<bits/stdc++.h> 
using namespace std;
int main(){
	string s;
	int a;
	scanf("%d",&a);
	printf("%d",a);
	return 0;
}
