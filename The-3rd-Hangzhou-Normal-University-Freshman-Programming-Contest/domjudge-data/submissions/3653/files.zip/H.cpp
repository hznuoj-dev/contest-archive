#include<stdio.h>
int main(){
	int t; 
	scanf("%d",&t); 
	 
	for(int i=1;i<=t;i++){
		int n,m; 
		scanf("%d %d",&n,&m);  
		char a[n+10]={}; 
		a[0]='[',a[n+1]=']'; 
		for(int i=1;i<=n;i++){
			if(i<=m) a[i]='#'; 
			 else a[i]='-'; 
		}  
		printf("%s %.0f%%\n",a,(float)m/n*100.0); 
	} 
	return 0; 
}
