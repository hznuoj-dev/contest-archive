package ��ʦ��������;

import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		  while (sc.hasNext())
	      {
			  String kft=sc.next();
			  if(kft.equals("kfc"))
			  System.out.println( 
					  " __      _____\n"+
			          "|  | ___/ ____\\____\n"+
					  "|  |/ /\\   __\\/ ___\\\n"+
					  "|    <  |  | \\  \\___\n"+
					  "|__|_ \\ |__|  \\___  >\n"+
					  "     \\/           \\/"
);
	      }

	}

}
