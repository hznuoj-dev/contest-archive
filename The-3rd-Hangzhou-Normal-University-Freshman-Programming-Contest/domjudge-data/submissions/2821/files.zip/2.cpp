#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
const int MAX=1e5+10;
int cishu[MAX];
int main()
{
	int n;
	long long cnt=1;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		int a;
		scanf("%d",&a);
		if(a>1)
		{
			cnt+=cishu[a-1]-1;
			cishu[a]++;
		}
		else cishu[a]++;
	}
	printf("%lld",cnt);
	
	return 0;
}

