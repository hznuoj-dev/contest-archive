#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
int t,x,y,k,sum,i;
scanf("%d",&t);
while(t--){
	sum=0;
	scanf("%d%d",&x,&y);
	if(x+y>=10000){
		k=x+y-9999;
		k=9999-k;
	}
	else  k=x+y;
	if(k<0)   k=-k;
	if(k<x){
		y=x;
		x=k;
		k=y;
	}
	for(i=x;i<=k;i++){
		if((i%4==0&&i%100!=0)||(i%100==0&&i%400==0))sum++; 
	}
	printf("%d",sum);
	if(t!=0) printf("\n");
} 
	return 0;
}
