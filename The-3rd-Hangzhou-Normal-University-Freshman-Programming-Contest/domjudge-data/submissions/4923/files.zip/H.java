import java.util.Scanner;

public class H {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t=in.nextInt();
        for (int i = 0; i < t; i++) {
            int n=in.nextInt(),m=in.nextInt();
            System.out.print("[");
            System.out.print(repeatString("",m+1,"#"));
            System.out.print(repeatString("",n-m+1,"-"));
            System.out.print("] ");
            System.out.println((int)((double)m/(double)n*100)+"%");
        }
    }
    public static String repeatString(String str, int n, String seg) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < n; i++) {
            sb.append(str).append(seg);
        }
        return sb.substring(0, sb.length() - seg.length());
    }
}
