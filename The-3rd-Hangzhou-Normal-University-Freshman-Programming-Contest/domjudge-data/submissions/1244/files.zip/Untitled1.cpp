#include <stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m,f,x=0;
		scanf("%d %d",&n,&m);
		if(n+m>9999)
			f=n+m-9999+n;
		else
		f=n+m;
		int a;
		if(f<n){
			a=f;
			f=n;
			n=a;
		}
		for(int i=n;i<=f;i++){
			if((i%4==0&&i%100!=0)||i%400==0)
			x++;
		}
		printf("%d\n",x);
	}
}
