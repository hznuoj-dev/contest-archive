#include<stdio.h>
#include<string.h>
#include<algorithm>
using namespace std;
char s[1000005];
int main()
{
	int t, n, cnt, sum, i, j;
	scanf("%d", &t);
	while (t--)
	{
		sum = 0;
		scanf("%d", &n);
		while (n--)
		{
			cnt = 0;
			scanf("%s", s);
			sort(s, s + strlen(s));
			i = 0;
			while (i < strlen(s))
			{
				if(s[i]=='.')
				    i++;
				else
				{
					j = i;
					i++;
					cnt++;
					while (s[i] == s[j])
						i++;
				}
			}
			sum += cnt;
		}
		printf("%d\n", sum);
	}
	return 0;
}
