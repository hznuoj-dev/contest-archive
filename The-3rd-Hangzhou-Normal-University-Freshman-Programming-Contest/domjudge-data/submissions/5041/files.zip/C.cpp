//
// Created by Kyooma on 2020/12/13.
//
#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll mod=998244353;
int a[100009];
ll qpw(ll a,ll b){
    ll res=1;
    while(b){
        if(b&1) res=res*a%mod;
        b/=2;
        a=a*a%mod;
    }
    return res;
}
int main(){
    int n,max=0;
    ll res=1;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        int x;
        scanf("%d",&x);
        a[x]++;
        if(x>max) max=x;
    }
    for(int i=3;i<=a[2];i++){
        res=res*i%mod;
    }
    for(int i=3;i<=max;i++){
        res=res*qpw(a[i-1],a[i])%mod;
    }
    printf("%lld\n",res);
}
