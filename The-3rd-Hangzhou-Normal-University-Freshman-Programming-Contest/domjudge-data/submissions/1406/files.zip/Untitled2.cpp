#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int,int> pii;
const int N=1e5+10;
const int mod=998244353;
unordered_map<int,bool>vis;
vector<int>vec[N];
vector<int>num;
vector<int>query;
int k;
bool check(int x){
	int ans=0;
	for(auto v:query){
		ans+=lower_bound(vec[v].begin(),vec[v].end(),x+1)-vec[v].begin();
	}
	return ans<k;
}
int main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0); 
	int n;cin>>n;
	for(int i=1;i<=n;++i){
		int m;cin>>m;
		vec[i].resize(m);
		for(auto& v:vec[i]){
			cin>>v;
			vis[v]=true;
		}
		sort(vec[i].begin(),vec[i].end());
	}
	num.resize(vis.size());int cnt=-1;
	for(auto v:vis){
		num[++cnt]=v.first;
	}
	sort(num.begin(),num.end());
	int q;cin>>q;
	while(q--){
		int m;cin>>m;
		query.resize(m);
		for(auto &v:query) cin>>v;cin>>k;
		int l=0,r=cnt;
		while(l<=r){
			int mid=l+r>>1;
			if(check(num[mid])) l=mid+1;
			else r=mid-1;
		}
		printf("%d\n",num[l]);
	}
	
	return 0;
} 
