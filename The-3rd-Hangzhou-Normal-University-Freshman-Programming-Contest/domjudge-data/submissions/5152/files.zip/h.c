#include<stdio.h>
int main(){
	int a,x,y,i;
	float b,c,e;
	if (scanf("%d", &a)) {
	while(a--){
		if(scanf("%d%d",&x,&y));
		{
		
		b=x;
		c=y;
		e=c/b*100;}
		printf("[");
		for(i=0;i<c;i++){
			printf("#");
		}
		for(i=0;i<b-c;i++){
			printf("-");
		}
		printf("]");
			printf(" %.0lf%%\n",e);
	}
}
	return 0;
}
