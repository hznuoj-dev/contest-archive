#include<stdio.h>
int main(){
	int i,j,n,k,T,m;
	int rank1[1000]={0},a[1000];
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&n,&m);
		for(i=0,j=0;i<m;i++,j=j+2){
			scanf("%d %d",&a[j],&a[j+1]);
		}
		for(i=0;i<n+2;i++){
		if(i%2==0)
		rank1[i]=1;
		}
		for(i=0;i<n;i++){
			if(rank1[i]==1){
				if(i==0){
					printf("%d ",i+1);
				}
				else if(i!=0)
				printf("%d ",i);
				if(i=n-1)
				printf("%d",i+1);
			}
		}
		
	}
}
