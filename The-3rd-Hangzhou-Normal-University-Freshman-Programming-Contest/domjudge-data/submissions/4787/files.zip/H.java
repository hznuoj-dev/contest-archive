import java.util.Scanner;

public class H {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t=in.nextInt();
        String[] array1= new String[t];
        int[] array2= new int[t];
        for (int i = 0; i < t; i++) {
            int n=in.nextInt(),m=in.nextInt();
            array1[i]="[";
            for (int j = 1; j <= n; j++) {
                if(j<=m){
                    array1[i]=array1[i]+"#";
                }else {
                    array1[i]=array1[i]+"-";
                }
            }
            array2[i]= (int)((double)m/(double)n*100);
            array1[i]=array1[i]+"] ";
        }
        for (int i = 0; i < t; i++) {
            System.out.println(array1[i]+array2[i]+"%");
        }
    }
}
