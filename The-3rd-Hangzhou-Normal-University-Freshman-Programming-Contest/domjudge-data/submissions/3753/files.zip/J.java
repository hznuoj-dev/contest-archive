import java.util.HashSet;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int n=sc.nextInt();
			for(int i=1;i<=n;i++)
			{
				int a=sc.nextInt();
				int count=0;
				for(int j=1;j<=a;j++)
				{
					String s=sc.next().replace(".","");
					HashSet<Character> geshu=new HashSet<Character>();
					for(int z=0;z<s.length();z++)
					{
						geshu.add(s.charAt(z));
					}
					count=count+geshu.size();
				}
				System.out.println(count);
			}
		}
	}
	
}
