#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
    int t, y, a, x, m, i, s;
    scanf("%d", &t);
    while (t--) {
        s = 0;
        scanf("%d %d", &y, &a);
        x = y + a;
        if (x > 9999) {
            x = 19998 - x;

        }
        if (x > y) {
            m = y;
            y = x;
            x = m;

        }
        for (i = x;i <= y;i++) {
            if (i % 4 == 0) {
                if (i % 100 == 0) {
                    if (i % 400 == 0) {
                        s++;
                        continue;
                    }
                    else {
                        continue;
                    }
                }
                else {
                    s++;
                    continue;
                }
            }
            else {

                continue;
            }
        }
        printf("%d\n", s);

    }
    return 0;
}