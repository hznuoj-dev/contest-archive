#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d%d",&n,&m);
		int i;
		i=m*100/n;
		for(int j=1;j<=m;j++){
			if (j==1)
			{
				printf("[#");
			}
            else
             printf("#");
			
		}
		for(int j=1;j<=n-m;j++){
			if(j==n-m){
				printf("-]")
			}
			else
			{
				printf("-");
			}
		}
		printf("%d%%\n",i);
	}
	return 0;
}