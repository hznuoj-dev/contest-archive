#include<stdio.h>
#include<string.h>
#include<math.h>
#pragma warning (disable:4996)
/*int main() {
	int n, T, m,p;//�ó������ܵĶ�����, �ܵ�ʱ��, �ܵ��ύ������Ŀ����
	int team, pro, time,q;//ʾ������, ��Ŀ��ź�ʱ���,ѯ������
	char a;

}*/
/*int main() {
	int a, b, c, d, i, k = 0, t;
	scanf("%d", &a);
	while (a--) {
		k = 0;
		scanf("%d %d", &b, &c);
		d = b + c;
		while  (d >= 10000) {
			d = d - 9999;
			d = 9999 - d;
		}
		if (b > d) {
			t = b;b = d;d = t;
		}
		for (i = b;i <= d;i++) {
			if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				k++;
		}
		printf("%d\n", k);
	}
}*/
/*int main() {
	int a;
	scanf("%d", &a);
	while (a--) {
		scanf ("%d",)
	}
}*/
/*int main() {
	char a[100];
	scanf("%s", &a);
	printf(
	    " __      _____\n"
	    "|  | ___/ ____\\____\n"
		"|  |/ /\\   __\\/ ___\\\n"
		"|    <  |  | \\  \\___\n"
		"|__|_ \\ |__|  \\___  >\n"
		"     \\/           \\/\n");
	return 0;
}*/
int main() {
	char a[20], b[20], c[20], d[20];
	int A, B, C, D, i, x = 0, y = 0, z = 0, k = 0, j = 0;
	scanf("%s %s %s %s", &a, &b, &c, &d);
	A = strlen(a);B = strlen(b);C = strlen(c);D = strlen(d);
	for (i = 1;i <= A;i++) {
		x = x + (int)a[i];
	}
	for (i = 1;i <= B;i++) {
		y = y + (int)b[i];
	}
	for (i = 1;i <= C;i++) {
		z= z + (int)c[i];
	}
	for (i = 1;i <= D;i++) {
		k = k + (int)d[i];
	}
	if (x >= 16 && x == 6)
		j++;
	if (y >= 16 && y == 6)
		j++;
	if (z >= 16 && z == 6)
		j++;
	if (k >= 16 && k == 6)
		j++;
	if (j == 1)
		printf("Oh dear!!");
	else if (j == 2)
		printf("BaoBao is good!!");
	else if (j == 3)
		printf("Bao Bao is a SupEr man///!");
	else if (j == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else
		printf("Bao Bao is so Zhai......");

}