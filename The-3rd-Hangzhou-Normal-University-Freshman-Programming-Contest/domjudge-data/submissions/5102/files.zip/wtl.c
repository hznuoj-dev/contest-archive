#include<stdio.h>
#pragma warning(disable:4996)
#include<math.h>
#include<string.h>
int main(){
	int t,i,j;
	double m,n,p;
	while(~scanf("%d",&t)){
		while(t--){
			scanf("%lf %lf",&m,&n);
			p=(n/m)*100+0.5;
			printf("[");
			for(i=0;i<n;i++){
				printf("#");
			}
			for(i=0;i<m-n;i++){
				printf("-");
			}
			printf("] ");
			printf("%.0lf%\n",p);
		}
	}
	return 0;
}