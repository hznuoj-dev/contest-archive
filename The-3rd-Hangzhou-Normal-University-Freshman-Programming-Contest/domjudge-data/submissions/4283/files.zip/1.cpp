#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;

const int maxn=1e3+10;

vector<int>a[maxn];

bool vis[maxn];

bool flag;

void dfs(int q)
{
	if(a[q].size()==0)
	{
		
		if(!vis[q])
		{
			if(flag) cout<<' '<<q;
			else cout<<q;
			flag=true;
		}
		vis[q]=true;
	}
	else
	{
		for(int i=0;i<a[q].size();i++)
		{
			if(!vis[a[q][i]]) dfs(a[q][i]);
		}
		if(!vis[q])
		{
			if(flag) cout<<' '<<q;
			else cout<<q;
			flag=true;
		}
		vis[q]=true;
	}
}

int main()
{
	fcio;
//	fcin;
//	freopen("out.txt","w",stdout);
	int t;
	cin>>t;
	while(t--)
	{
		memset(vis,false,sizeof vis);
		flag=false;
		int n,m;
		for(int i=1;i<=n;i++) a[i].clear();
		cin>>n>>m;
		while(m--)
		{
			int p,q;
			cin>>p>>q;
			a[q].push_back(p);
		}
		
		for(int i=1;i<=n;i++)
		{
			if(!vis[i]) dfs(i);
		}
		
	}
}
