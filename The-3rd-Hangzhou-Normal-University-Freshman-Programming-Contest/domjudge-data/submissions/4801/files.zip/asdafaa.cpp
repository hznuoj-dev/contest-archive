#include <stdio.h>
#include <stdlib.h>

int main()
{
	int n,m;
	int i,j;
	int sum=0;
	int m1[10]={0};
	int n1[10]={0};
	scanf("%d %d",&n,&m);

	for(i=0;i<n-1;i++){
		scanf("%d%",&m1[i]);
	}

	for(i=0;i<n-1;i++){
		scanf("%d%",&n1[i]);
	}
	for(i=0;i<n;i++){
		sum +=m1[i]*n1[i] ;
	}
	printf("%d",sum);
	return 0;
}
