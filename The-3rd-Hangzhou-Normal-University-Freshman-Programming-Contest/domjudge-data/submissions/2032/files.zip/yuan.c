#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
int main() {
    int t, q, w, e = 0, r = 0, i, s;
    scanf("%d", &t);
    while (t--) {
        scanf("%d %d", &q, &w);
        if (q + w > 9999) {
            e = q + w;
            r = q + w - 9999;
            e = 9999 - r;
        }
        if (e > q) {
            i = e, e = q, q = i;
        }
        s = 0;
        for (i = e; i <= q; i++) {
            if ((i % 4 == 0 & i % 100 != 0) || i % 400 == 0) {
                s++;
            }
        }
        printf("%d\n", s);
    }
    return 0;
}
