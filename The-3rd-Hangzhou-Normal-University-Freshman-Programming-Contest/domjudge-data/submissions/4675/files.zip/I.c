#include <stdio.h>
#include <stdlib.h>
int sum(int x){
	long long i=1000000000000000000,t=0;
    while(x/i==0){
    	i=i/10;
	}
	while(i!=1){
		t=t+x%i;
		x=x/i;
		i=i/10;
	}
	t=t+x;
	return t;
}
int main(void) {
	long long  A,B,C,D,j=0;
	scanf("%d %d %d %d",&A,&B,&C,&D);
	if((sum(A)>=16)||(sum(A)==6)){
	j=j+1;	
	}
	else if((sum(B)>=16)||(sum(B)==6)){
	j=j+1;	
	}
	else if((sum(C)>=16)||(sum(C)==6)){
	j=j+1;	
	}
	else if((sum(D)>=16)||(sum(D)==6)){
	j=j+1;	
	}
	if(j==1){
		printf("Oh dear!!");
	}
	if(j==2){
		printf("BaoBao is good!!");
	}
	if(j==3){
		printf("Bao Bao is a SupEr man///!");
	}
	if(j==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	if(j==0){
		printf("Bao Bao is so Zhai......");
	}
	return 0;
}
