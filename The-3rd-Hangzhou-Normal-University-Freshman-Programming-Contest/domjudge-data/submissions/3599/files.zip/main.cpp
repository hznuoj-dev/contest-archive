//
//  main.cpp
//  c++_02
//
//  Created by 李尚鑫 on 2020/12/7.
//
#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <vector>
#include <map>
using namespace std;
const int N = 1000005;

int main () {
    int t;
    scanf("%d",&t);
    while (t--) {
        int x,cnt = 0;
        scanf("%d",&x);
        for (int i=0; i<x; i++) {
            char m[N];
            map < int,map<char,int> > mp;
            cin >> m;
            for (int j=0; m[j]!='\0'; j++) {
                mp[i][m[j]]++;
                if (m[j]!='.' && mp[i][m[j]]==1) {
                    cnt++;
                    mp[i][m[j]]++;
                }
            }
        }
        printf("%d\n",cnt);
    }
}
