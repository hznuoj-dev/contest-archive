#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int main(void) {
    int T;
    scanf("%d",&T);
	while(T--){
		int n,i,j,k,c=0;
		scanf("%d",&n);
		for(i=0;i<n;i++){
		    char s[81];
		    int l[n]; 
			scanf("%s",s);
			l[i]=strlen(s);
			for(j=0;j<l[i];j++){
				if(s[j]!='.'){
					int flag=1;
					for(k=j-1;k>=0;k--){
						if(s[k]==s[j]){
							flag=0;
							break;
						}
					}
					if(flag==1){
						c+=1; 
					}
				}
			}
	} 
				printf("%d\n",c);
}
return 0;
} 

