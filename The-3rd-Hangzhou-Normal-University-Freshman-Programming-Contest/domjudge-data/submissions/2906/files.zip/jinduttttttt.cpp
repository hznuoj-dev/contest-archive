#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int main()
{
	int t;
	double n,m;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lf %lf",&n,&m);
		printf("[");
		for(double i=1;i<=m;i++)
		{
			printf("#");
		}
		for(double i=1;i<=n-m;i++)
		{
			printf("-");
		}
		printf("] ");
		double sum=0;
		sum=m/n*100;
		printf("%.0lf",sum);
		printf("%%");
		printf("\n");
	}
	return 0;
}
//[##--------] 20%
