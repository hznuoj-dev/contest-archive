#include<iostream>
#include<algorithm>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug cout<<"What fuck!"<<endl
using namespace std;
const int mod=998244353;
const int maxn=1e5+10;
int a[maxn];
int main(){
	fcio;
	int n;
	while(cin>>n){
		for(int i=1;i<=n;++i){
			cin>>a[i];
		}
		sort(a+1,a+1+n);
		int last=1;
		int now=1;
		int ans=1;
		int cnt=0;
		for(int i=2;i<=n;++i){
			if(a[i]==a[i-1]){
				now++;
			}
			else{
//				debug;
//				cout<<"last="<<last<<endl;
//				cout<<"now="<<now<<endl;
//				debug;
				last=a[i-1];
				if(now==1){
					continue;
				}
				ans=((ans%mod)*(now%mod))%mod;
				now=1;
			}
		}
//		if(a[n]==a[n-1]){
//			ans=(ans%mod+((last%mod)*(now%mod))%mod)%mod;
//		}
		if(last!=1)	ans=((ans%mod)*(now%mod))%mod;
		cout<<ans%mod<<endl;
	}
}

