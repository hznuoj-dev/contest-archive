#include<stdio.h>
int main(){
	int T,a,b,n,m,c[1005],i,j,t;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&a,&b);
		for(i=1;i<a;i++){
			c[i]=i;
		}
		while(b--){
			scanf("%d %d",&n,&m);
			if(n>m){
				for(i=m;i<n;i++){
					c[i+1]=c[i];
				}
				c[m]=n;
			}
		}
	for(i=1;i<=n;i++){
		printf("%d ",c[i]);
	}
}
}
