#include<stdio.h>
int main(){
	int t;
	int n,m;
	int w=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		w=(m*100)/n;
	printf("[");
	for(int i=1;i<=m;i++){
		printf("#");
	}
	for(int i=1;i<=n-m;i++){
		printf("-");
	}
	printf("]");
	printf(" %d",w);
	printf("%%\n");
}
return 0;
}
