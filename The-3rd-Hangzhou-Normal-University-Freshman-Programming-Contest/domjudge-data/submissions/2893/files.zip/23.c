#include<stdio.h>
#include<string.h>
int main(){
char a[10^18],b[10^18],c[10^18],d[10^18];
int sum=0,i,s;
scanf("%s%s%s%s",a,b,c,d);
s=0;
for(i=0;i<strlen(a);i++){
	s+=a[i]-'0';
	if(s>=16||s==6){
		sum++;
	}
}
s=0;
for(i=0;i<strlen(b);i++){
	s+=b[i]-'0';
	if(s>=16||s==6){
		sum++;
	}
}
s=0;
for(i=0;i<strlen(c);i++){
	s+=c[i]-'0';
	if(s>=16||s==6){
		sum++;
	}
}
s=0;
for(i=0;i<strlen(d);i++){
	s+=d[i]-'0';
	if(s>=16||s==6){
		sum++;
	}
}
switch(sum){
	case 0:printf("Bao Bao is so Zhai......");break;
	case 1:printf("Oh dear!!");break;
	case 2:printf("BaoBao is good!!");break;
	case 3:printf("Bao Bao is a SupEr man///!");break;
	case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	
}
return 0;
}
