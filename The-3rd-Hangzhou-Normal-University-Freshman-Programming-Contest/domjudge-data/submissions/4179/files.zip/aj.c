#include<stdio.h>
#include<string.h>
int main(void)
{
int t;
int n;
char a[100][1000000];
long long int len[100];
int i=0,j=0,g=0;
char z;
int sh=0;
int sum=0;
scanf("%d",&t);
while(t--)
{
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		gets(a[i]);
		len[i]=strlen(a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<len[i];j++)
		{
		if(a[i][j]!='.')
		{
			z=a[i][j];
			for(g=0;g<len[i];g++)
			{
				if(z==a[i][g])
				sh++;
			}
			if(sh==0)
			sum++;
		}
		}
	}
	printf("%d\n",sum);
}
return 0;
} 
