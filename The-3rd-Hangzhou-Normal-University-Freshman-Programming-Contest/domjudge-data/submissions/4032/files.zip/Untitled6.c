#include<stdio.h>
#include<math.h>
int main(void){
	int a,b,c,d,e,f,g;
	char h,i,j,k,l,m,n;
	scanf("%d",&a);
	while(a--){
		scanf("%d %d",&b,&c);
		d=100*c/b;
		e=b-c;
		printf("[");
		while(c--){
			printf("#");
		}
		while(e--){
			printf("-");
		}
		printf("] %d%%\n",d);
	}
	return 0;
}
