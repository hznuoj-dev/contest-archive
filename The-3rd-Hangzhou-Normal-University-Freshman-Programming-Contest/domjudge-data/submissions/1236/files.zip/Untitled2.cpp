#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6;
const int INF=0x3f3f3f3f;
int n;
char s[N];
int main(){
	scanf("%d",&n);
	int ans=0;
	while(n--){
		scanf("%s",s);
		ans+=strlen(s);
	}
	printf("%d\n",ans);
	return 0;
}
