#include<stdio.h>
#include<string.h>
#include<math.h>
char s[100005];
int main(){
	int t,i,sum,x;
	scanf("%d", &t);
	int n,m;
	int a[500];
	while (t--) {
		sum = 0;
		scanf("%d", &n);
		while (n--) {
			scanf("%s", s);
			x=strlen(s);
			for (i = 0;i < x;i++) {
				if (s[i] == '.')
					;
				else {
					m = s[i];
					a[m] = 1;
				}
			}
			for (i = 1;i <= 300;i++) {
				if (a[i] == 1) {
					sum++;
				}
			}
			memset(a,0,sizeof a);
		}
		printf("%d\n", sum);
	}
}
