#include <stdio.h>
#include <stdlib.h>
int main() {
	int T=0,A=0,B=0,C=0,i=0,sum=0;
	scanf("%d",&T) ;
	while(T--)
	{
		sum=0;
		scanf("%d %d",&A,&B);
		C=A+B;
		if(C>9999) C=9999-C+9999;
		if(A>C)
		{
			B=A;
			A=C;
			C=B;
		}
		for(i=A;i<=C;i++)
		{
			if(i % 4 == 0 &&i % 100 != 0 ||i % 400 == 0)
			{
				sum=sum+1;
			}
		}
		printf("%d\n",sum);
		
	}
	return 0;
}
