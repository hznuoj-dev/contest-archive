#include<stdio.h>
int main ()
{
	long long A,B,C,D;
	scanf("%lld%lld%lld%lld",&A,&B,&C,&D);
	int regit=0 ;
 	if (A>16||A==6)
 	regit++;
	if(B>16||B==6)
	regit ++;
	if(C>16||C==6)
	regit ++;
	if(D>16||D==6)
	regit ++;
	if(regit ==0)
	printf("Bao Bao is so Zhai......");
	else if (regit == 1)
	printf("Oh dear!!");
	else if (regit ==2)
	printf("BaoBao is good!!");
	else if (regit ==3)
	printf("Bao Bao is a SupEr man///!");
	else 
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!") ;
	return 0;
}
