#include<stdio.h>
int main()
{
	char a[50];
	int c=92;
	gets(a);
	printf(" __ _____\n");
           printf("| | ___/ ____%c____\n",c);
           
           printf("| |/ /%c __%c/ ___%c\n",c,c,c);
           
           printf("| < | | %c %c___\n",c,c);
           printf("|__|_ %c |__| %c___ >\n",c,c);
            printf("     %c/ %c/         \n",c,c);
        
	
	
	
	
	return 0;
	
}




