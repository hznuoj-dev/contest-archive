#include<stdio.h>
int main(){
	long long a[10],b,c=0,d,x,y,j,i,k,m,n;
	for(i=1;i<=4;i++){
		scanf("%lld",&a[i]);
		b=0;
		while(a[i]>0){
			b=b+a[i]%10;
			a[i]=a[i]/10;
			
		}
		if(b==6||b>=16)c++;
		
	}
	if(c==1)printf("Oh dear!!");
	else if(c==2)printf("BaoBao is good!!");
	else if(c==3)printf("Bao Bao is a SupEr man///!");
	else if(c==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else printf("Bao Bao is so Zhai......");
	
	
	return 0;
	
	
	
	
} 
