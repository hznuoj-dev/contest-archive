//#include<cstdio>
//#include<cstdlib>
//#include<string.h>
//#include<iostream>
//#include<set>
//#include<map>
//#include<stack>
//#include<queue>
//#include<vector>
//#include<string>
//#include<cmath>
//#include<algorithm>
#include<bits/stdc++.h>

using namespace std;

const double eps = 1e-10;
const int INF = 0x3f3f3f3f;
const int MAXN = 100010;

int n, m, dp[MAXN], vis[MAXN], tp[MAXN], num[MAXN], coin[MAXN * 100];

int main() {

#ifdef LWB
	freopen("data.in", "r", stdin);
#endif

	ios_base::sync_with_stdio(false);

	memset(dp, 0, sizeof(dp));
	memset(vis, 0, sizeof(vis));

	int n, m, a, cnt = 0, index = 0;
	scanf("%d%d", &n, &m);
	for (int i = 0; i < n; ++i) {
		scanf("%d", &tp[i]);
	}
	for (int i = 0; i < n; ++i) {
		scanf("%d", &num[i]);
	}

	for (int i = 0; i < n; ++i) {
		for (int k = 0; k <= num[i]; ++k) {
			for (int j = m; j >= tp[i]; --j) {
				if (dp[j] <= dp[j - k * tp[i]] + k * tp[i]) {
					dp[j] = dp[j - k * tp[i]] + k * tp[i];
				}
				if (dp[j] <= m && dp[j] > 0) {
					vis[dp[j]] = 1;
				}
			}
		}

	}
	for (int i = 1; i <= m; ++i) {
		if (vis[i] == 1) cnt++;
	}
	printf("%d\n", cnt);

	return 0;
}
