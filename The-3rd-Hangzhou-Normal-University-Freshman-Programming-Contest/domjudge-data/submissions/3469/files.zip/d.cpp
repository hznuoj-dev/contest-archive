//
// Created by ShintaroTM on 12/13/2020.
//

#include <bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin>>t;
    int count=0;
    while(t--){
        string str;
        cin>>str;
        count+=str.size();
    }
    cout<<count<<endl;
    return 0;
}