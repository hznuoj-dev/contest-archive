#include<bits/stdc++.h>
using namespace std;
int nian(int a,int b){
	int cnt=0;
	for(int i=a;i<=b;i++){
	if(((i%4==0)&&(i%100!=0))||(i%400==0)){
		cnt++;
	}
}
	return cnt;
}
int main(){
	int n,N;
	int a,b;
	cin>>N;
	for(n=1;n<=N;n++){
		cin>>a>>b;
		if(b>=0){
			b=a+b;
		}else{
			int k;
			k=a;
			a=a+b;
			b=k;
		}
		if(b>=10000){
			b=9999-(b-9999);
		}
		int t;
		if(a>b){
			t=a;
			a=b;
			b=t;
		}
		cout<<nian(a,b)<<endl;
	}
	return 0;
}
