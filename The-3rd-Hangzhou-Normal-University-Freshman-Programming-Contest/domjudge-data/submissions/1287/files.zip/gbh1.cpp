#include<stdio.h>
int main() {
	int i,t,a,b,c,sum,n;
	scanf("%d",&t);
	while (t--) {
		sum = 0;
		scanf("%d %d",&b,&a);
		c = b;
		b = a + b;
		if (b > 9999)
			b = 19998 - b;;
		if (b < c) {
			n = b;
			b = c;
			c = n;
		}
		for (i = c;i <= b;i++) {
			if ((i % 4 == 0 && i % 100 != 0) || i % 400 == 0)
				sum++;
		}
		printf("%d\n",sum);
	}
}