#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int t,i,j,n,m;
	int f=0;
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		scanf("%d%d",&n,&m);
		f=1.0*m/n*100;
		printf("[");
		for(j=1;j<=m;j++)
		printf("#");
		for(j=1;j<=n-m;j++)
		printf("-");
		printf("]");
		printf(" %d%%\n",f);
	}
	return 0;
}
