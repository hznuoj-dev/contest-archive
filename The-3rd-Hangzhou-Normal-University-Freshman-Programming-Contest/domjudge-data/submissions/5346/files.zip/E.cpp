#include<stdio.h>
#include <string.h>

int main(){
	char str[10] ;
	gets(str);
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__|  \\___  >\n");
	printf("     \\/           \\/\n\n");      
    return 0;
}

