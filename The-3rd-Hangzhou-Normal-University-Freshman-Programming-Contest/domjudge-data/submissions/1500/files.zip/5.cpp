#include <stdio.h>
int main(){
	int a, b, c, d, A=0, B=0, C=0, D=0, sum=0;
	scanf("%d%d%d%d", &a, &b, &c, &d);
	while(a){
		A+=a%10;
		a=a/10;
	}
	if(A>=16||A==6){
		sum++;
	}
	while(b){
		B+=b%10;
		b=b/10;
	}
	if(B>=16||B==6){
		sum++;
	}
	while(c){
		C+=c%10;
		c=c/10;
	}
	if(C>=16||C==6){
		sum++;
	}
	while(d){
		D+=d%10;
		d=d/10;
	}
	if(D>=16||D==6){
		sum++;
	}
	if(sum==0){
		printf("Bao Bao is so Zhai......");
	}
	if(sum==1){
		printf("Oh dear!!");
	}
	if(sum==2){
		printf("BaoBao is good!!");
	}
	if(sum==3){
		printf("Bao Bao is a SupEr man///");
	}
	if(sum==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
}






























