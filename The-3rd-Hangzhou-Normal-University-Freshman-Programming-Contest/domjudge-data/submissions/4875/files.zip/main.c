#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int i,t,j,m,n,d,d1;
	char s[10000000];
	scanf("%d",&t);
	while(t--){
		d1=0;
		scanf("%d",&m);
		getchar();
		for(i=0;i<m;i++){
			d=0;
		puts(s);
			for(j=0;j<strlen(s);j++){
				if(s[j]!='.'){
					d++;
				for(n=j+1;n<strlen(s);n++){
					if(s[j]==s[n])
					s[n]='.'; 
			}
		}
		
			} 
			d1+=d;	
		}
		printf("%d\n",d1);
	}
	
	return 0;
}

