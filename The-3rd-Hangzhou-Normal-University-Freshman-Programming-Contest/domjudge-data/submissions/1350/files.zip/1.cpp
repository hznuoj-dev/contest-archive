#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)
#define ll long long

using namespace std;

ll a;
ll cnt;
int main()
{
	for(int i=0;i<4;i++)
	{
		cin>>a;
		ll sum=0;
		while(a>0)
		{
			ll p=a%10;
			sum+=p;
			a/=10;
			
			if(sum==6||sum>=16) cnt++;
		}
	}
	if(cnt>=4) cout<<"Oh my God!!!!!!!!!!!!!!!!!!!!!"<<endl;
	else if(cnt>=3) cout<<"Bao Bao is a SupEr man///!"<<endl;
	else if(cnt>=2) cout<<"BaoBao is good!!"<<endl;
	else if(cnt>=1) cout<<"Oh dear!!"<<endl;
	else cout<<"Bao Bao is so Zhai......"<<endl;
	
	
}


