#include <stdio.h>
int main(void){
	int T;
	scanf("%d",&T);
	while(T--){
		int Y,A,i;
		int B,cnt=0;
		scanf("%d %d",&Y, &A);
		B=Y+A;
		if(Y>B){
			int Z=Y;
			Y=B;
			B=Z;
		}
		if(Y>0&&B>0){
			for(i=Y;i<B;i++){
				if((i%4==0&&i%100!=0)||(i%400==0)){
					cnt++;
				}
			}
	    }
		printf("%d\n",cnt);
	}
	return 0;
}
