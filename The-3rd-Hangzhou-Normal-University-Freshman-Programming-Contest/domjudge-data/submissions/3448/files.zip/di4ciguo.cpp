#include<stdio.h>
int main ()
{
	int t,m,n,a,b;
	float c;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		a=m;//stand for # 
		b=n-m;//stand for -
		c=100*((float)m/(float)n);
		
		printf("[");
		for(int i =1;i<=a;i++)
		printf("#");
		for(int i=1;i<=b;i++){
			printf("-");
		}printf("] %d%%\n",(int)c);
	} 
	
	return 0;
}
