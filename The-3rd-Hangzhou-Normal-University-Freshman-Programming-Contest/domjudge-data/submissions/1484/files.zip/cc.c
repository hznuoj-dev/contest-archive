#include<stdio.h>
#include<math.h>
#include<string.h>
int main(void) {
	int T;
	int Y;
	int A;
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d", &Y, &A);
		int sum;
		sum = Y + A;
		if (sum > 9999) {
			sum -= 9999;
			sum = 9999 - sum;
		}
		int i;
		int output = 0;
		if (Y > sum) {
			int c = Y;
			Y = sum;
			sum = c;
		}
		for (i = Y; i <= sum; i++) {
			if (isP(i)) output++;
		}
		printf("%d\n", output);
	}
}
int isP(int n) {
	if (n % 400 == 0 || (n % 4 == 0 && n % 100 != 0)) {
		return 1;
	}
	else {
		return 0;
	}
}