#include<stdio.h>
int main(){
	int t, temp;
	int y,a;
	int m,n;
	int num, i;
	scanf("%d", &t);
	while(t--){
		num = 0;
		scanf("%d%d", &y, &a);
		m = y;
		if(y + a >= 10000){
			n = 9999 - (y + a - 9999);
		}else{
			n = y + a;
		}
		if(m > n){
			temp = m;
			m = n;
			n = temp;
		}
		for(i=m;i<=n;i++){
			if((i % 4 == 0 && i % 100 !=0) || i % 400 == 0){
				num ++;
			}
		}
		printf("%d\n", num); 
	}
} 
