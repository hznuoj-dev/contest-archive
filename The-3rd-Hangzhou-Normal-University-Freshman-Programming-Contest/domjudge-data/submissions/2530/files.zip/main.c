#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	int t;
	scanf("%d",&t);
	while(t--){
		int y,a,b,i,c=0;
		scanf("%d %d",&y,&a);
		b = y + a;
		if((y > 9999)||(b < 0))
			break;
		else{	
			if(b > 9999){
				b = 9999 - ( b - 9999 );
				if(b < 0)
					break;
				else{ 
					if(b > y){ 
						for(i = y;i <= b;++i){
							if((i % 4 == 0 && i % 100 != 0)||(i % 400 == 0))
								c++;
						}	
					}
					else{
						for(i = b;i <= y;++i){
							if((i % 4 == 0 && i % 100 != 0)||(i % 400 == 0))
								c++;
						}
					}
				}
			}
			else {
				if(a <= 0){
					for(i = b;i <= y;++i){
						if((i % 4 == 0 && i % 100 != 0)||(i % 400 == 0))
							c++;
					}
				}
				else{
					for(i = y;i <= b;++i){
						if((i % 4 == 0 && i % 100 != 0)||(i % 400 == 0))
							c++;
					}
				}
			}	
		}
	printf("%d\n",c);	
	}
	return 0;
}
