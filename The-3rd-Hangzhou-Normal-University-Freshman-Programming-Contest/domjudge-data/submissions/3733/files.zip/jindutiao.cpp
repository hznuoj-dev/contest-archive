#include<stdio.h>
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int a,b,n;
		double x;	
		scanf("%d%d",&a,&b);
		printf("[");
		for(n=0;n<b;n++)
		printf("#");
		for(n=0;n<(a-b);n++)
		printf("_");
		printf("]");
		x=((double)b/(double)a)*100;
		printf(" %.0f%%\n",x);
	}
}
