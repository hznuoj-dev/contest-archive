#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int flo[128]; 

int main(int argc, char *argv[]) {
	int t, n;
	int i;
	long long sum;
	
	scanf("%d", &t);
	while(t--) {
		sum = 0;
		scanf("%d", &n);
		getchar();
		for(i = 1; i <= n; ++i) {
			char ch;
			int j;
			
			memset(flo, 0, sizeof(flo));
			while(ch = getchar(), ch != '\n') {
				if(ch != '.') {
					++flo[ch];
				}
			}
			for(j = 0; j < 128; ++j) {
				if(flo[j]) ++sum;
			}
		}
		printf("%d\n", sum);
	}
	
	return 0;
}
