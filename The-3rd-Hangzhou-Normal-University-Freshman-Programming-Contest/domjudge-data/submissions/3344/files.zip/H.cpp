#include<stdio.h>
#include<math.h>
int main(){
	int T,i;
	long long n,m,sum;
	scanf("%d",&T);
	while(T--){
		scanf("%lld %lld",&n,&m);
		m=m*100;
		sum=m/n;
		for(i=0;i<n;i++){
			if(i==0)
			printf("[");
			if(i<m/100)
			printf("#");
			else
			printf("-");
			if(i==n-1)
			printf("] %d%%\n",sum);
		}
	}
}
