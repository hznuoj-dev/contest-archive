#include<iostream>
#include<string>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;
int main(){
	fcio;
	string s;
	cin>>s;
	cout<<"__ _____"<<endl;
	cout<<"| | ___/ ____\\____"<<endl;
	cout<<"| |/ /\\ __\\/ ___\\"<<endl;
	cout<<"| < | | \\ \\___"<<endl;
	cout<<"|__|_ \\ |__| \\___ >"<<endl;
	cout<<"\\/ \\/"<<endl;
}

