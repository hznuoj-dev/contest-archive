#include<stdio.h>
int main(void){
	int T,Y,A,num,y,x=0,i,sum;
	scanf("%d",&T);
	while(T>0){
	scanf("%d %d",&Y,&A);
	num=Y+A;
	if(num>=10000){
	y=9999-(num-9999);
	if(y<=Y){
	sum=Y-y+1;
	for(i=0;i<sum;++i){
		if((y%4==0&&y%100!=0)||(y%400==0)){
		x+=1;}
		y+=1;
		}
	}
	if(y>Y){
	sum=y-Y+1;
		for(i=0;i<sum;++i){
		if((Y%4==0&&Y%100!=0)||(Y%400==0)){
		x+=1;}
		Y+=1;
		}
	}
}
	if(num<=9999){
	sum=Y-num+1;
	for(i=0;i<sum;++i){
		if((Y%4==0&&Y%100!=0)||(Y%400==0)){
		x+=1;}
		Y+=1;
		}
	}
	printf("%d\n",x);
	T--;
	x=0;
	}
	return 0;
}
