#include<stdio.h>
#include<math.h>
int main()
{
	int s,sum,a,b,x,i,m,n;
	for(i=0;i<4;i++)
	{
		s=0;
		sum=0;
		scanf("%d",&a);
		while(a/10!=0){
		s++;
		a=a/10;}
		s++;
		for(b=s;b>=1;b--){
			m=pow(10,b+1);
			n=pow(10,b);
			sum=sum+(a%m)/n; 
		}
		if(sum==6||sum>=16)
		x++;
	}
	if(x==1)
	printf("Oh dear!!");
	else if(x==2)
	printf("BaoBao is good!!");
	else if(x==3)
	printf("Bao Bao is a SupEr man///!");
	else if(x==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else if(x==0)
	printf("Bao Bao is so Zhai......");
	printf("\n");
	return 0;
}
