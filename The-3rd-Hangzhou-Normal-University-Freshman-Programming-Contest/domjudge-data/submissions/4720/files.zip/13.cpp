#include<stdio.h>
#include<stdlib.h>
int main()
{
	int i,j,t,y,a,z,x;
	scanf("%d",&t);
	for(i=0;i<t;++i)
	{
		scanf("%d %d",&y,&a);
		if(y+a>9999)
		{
			z=9999-(y+a-9999);
		}
		else if(y+a>0&&y+a<=9999)
		{
			z=y+a;
		}
		else
		{
			z=y+a-1;
		}
		printf("%d\n",z);
		if(z>=1)
		{
		x=(abs(y-z)+1)/4-abs((y-z)+1)/100+abs((y-z)+1)/400;
		}
		else
		{
			x=(abs(z+1)/4+1)-(abs(z+1)/100+1)+(abs(z+1)/400+1)+y/4-y/100+y/400;
		}
		printf("%d\n",x);
	}
}
