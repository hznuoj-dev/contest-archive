n=int(input())
while n:
    s=0
    n=n-1
    m=int(input())
    for i in range(m):
        a=list((str(input())))
        b = ['']
        for j in range(len(a)):
            if a[j]!='.'and a[j] not in b:
                s=s+1
                b=b+[a[j]]
    print(s)