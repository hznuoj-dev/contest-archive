#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int n,s=0;
	scanf("%d",&n);
	while(n--){
		char a[1000000];
		scanf("%s",a);
		int lena;
		lena=strlen(a);
		s+=lena;
	}
	printf("%d",s);
}
