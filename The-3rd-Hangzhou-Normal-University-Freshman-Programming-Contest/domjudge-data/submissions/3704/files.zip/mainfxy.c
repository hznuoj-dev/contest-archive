#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	char a[10000],c[100000];
	int p[100000]={0};
	int n,i,t=0,b,num=0,j,f;
	scanf("%d",&n);
	while(n--){
		scanf("%s",a);
		b=strlen(a);
		for(i=0;i<b;i++){
			f=0;
			for(j=0;j<t;j++){
				if(a[i]==c[j]){
					p[j]++;
					f=1;
					break;
				}
			}
			if(f==0){
				c[t]=a[i];
				t++;
				p[t-1]++;
			}
		}
	}
	for(i=0;i<t;i++){
		num+=p[i]*(p[i]+1)/2;
	}
	printf("%d",num);
	return 0;
}
