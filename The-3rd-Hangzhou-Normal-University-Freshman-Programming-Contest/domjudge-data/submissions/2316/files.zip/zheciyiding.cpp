#include<stdio.h>
int main ()
{
	int t,Y,A,small,big,newone,i,regit,bigbig;
	regit=0;
	scanf("%d",&t);
	while (t--){
		scanf("%d%d",&Y,&A);//Y is originoal
		small=Y+A;  // Y is from 1 to 9999 and 
		big=19998-Y-A;
		bigbig = Y+A-19996;  // A  from -9998 to 19996 
		if(small<=9999)//from Y to newone
		newone = small;
		else if (small>9999&&small<=19997)
		newone = big;
		else 
		newone =bigbig;  
		if(newone>Y){
			for (i=Y;i<=newone;i++){
				if(i%4==0&&i%100!=0||i%400==0)
				regit++;
				}
			}
				//printf("%d %d %d\n",i,newone,regit);	
		else 
		{
			for (i=Y;i>=newone;i--){
				if((i%4==0&&i%100!=0)||(i%400==0))
				regit++;
			}
		}
		printf("%d\n",regit);
		regit =0;
	}
	return 0;
 } 
