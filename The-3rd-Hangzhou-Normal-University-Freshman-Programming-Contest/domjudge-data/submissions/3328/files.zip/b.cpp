#include<stdio.h>
int main(){
	int m,n,t,max,min,s,i;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&m,&n);
		min=m;
		max=min+n;
		if(max>9999){
			max=9999-(max-9999);
		}
			if(max<min){
				t=min;
				min=max;
				max=t;
			}
			s=0;
		for(i=min;i<=max;i++){
			if((i%4==0&&i%100!=0)||(i%400==0))
			s=s+1;
		} 
		printf("%d\n",s);
	}
} 
