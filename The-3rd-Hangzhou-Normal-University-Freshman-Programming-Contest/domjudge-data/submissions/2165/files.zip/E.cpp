#include<bits/stdc++.h>
using namespace std;
int main(){
	string s;
	getline(cin,s);
    cout << " __      _____" << endl;
    cout << "|  | ___/ ____" << (char)92 << "____" << endl;
    cout << "|  |/ /" << (char)92 << "   __" << (char)92 << "/ ___" << (char)92 << "" << endl;
    cout << "|    <  |  | " << (char)92 << "  " << (char)92 << "___" << endl;
    cout << "|__|_ " << (char)92 << " |__|  " << (char)92 << "___  >" << endl;
    cout << "     " << (char)92 << "/           " << (char)92 << "/" << endl;
return 0;
}
