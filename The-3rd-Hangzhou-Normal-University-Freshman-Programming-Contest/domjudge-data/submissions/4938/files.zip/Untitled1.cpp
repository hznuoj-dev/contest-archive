
#include <stdio.h>
#include <math.h>
int main()
{
	long long  max = 998244353,sum=1; 
    long long n,x;
    scanf("%lld",&n);
    long long a[100010]={0};
    for(int i=1;i<=n;++i)
	{
		scanf("%lld",&x);
		if(x!=1)
		{
			sum*=a[x-1];
			if(sum>=max)
			   sum=sum%max;
		}
		a[x]+=1;
	 } 
	sum=sum%max;
	printf("%lld\n",sum);
	return 0;
 } 
