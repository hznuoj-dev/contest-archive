import java.util.Scanner;

import static java.lang.Integer.max;
import static java.lang.Integer.min;

public class B {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int t = in.nextInt();
        int[] array= new int[t];
        for (int i = 0; i < t; ++i) {
            int y = in.nextInt(), a = in.nextInt();
            int b = y + a, cont = 0;
            if (b > 9999) {
                b = 9999 - (b - 9999);
            }
            for (int j = min(y, b); j <= max(y, b); ++j) {
                if (isRunnian(j)) {
                    cont++;
                }
            }
            array[i]=cont;
        }
        for (int i = 0; i < array.length; i++) {
            System.out.println(array[i]);
        }
    }

    public static boolean isRunnian(int r) {
        if (r % 400 == 0 || (r % 4 == 0 && r % 100 != 0)) {
            return true;
        }
        return false;
    }
}
