#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	int C(int a,int b);
	int n,a[100000],b[10000]={0};
	int i,t;
	long long sum;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[a[i]]++;
	}
	i=3;
	sum=1;
	while(b[i]!=0)
	{
		t=C(b[i-1]-1,b[i]+b[i-1]-1);
		sum=sum*t;
		i++;
	}
	printf("%lld\n",sum);
	
	return 0;
}
int C(int a,int b)
{
	int y1,y2,p,q;
	y1=y2=1;
	if(b-a<a)
	    a=b-a;
	for(p=1;p<=a;p++)
		y1*=p;
	for(p=b;p>b-a;p--)
		y2*=p;
	return y2/y1;
}