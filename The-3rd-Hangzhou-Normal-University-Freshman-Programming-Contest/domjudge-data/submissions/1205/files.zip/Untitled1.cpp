#include <cstdio>
#include <iostream>
using namespace std;
int main () {
	int T;
	scanf("%d", &T);
	while (T--) {
		int y, a;
		scanf("%d%d", &y, &a);
		int x = y + a;
		bool flag = false;
		while (x > 9999) {
			flag = true;
			x -= 9999;
		}
		if (flag) 
			x = 9999 - x;
		if (x > y)
			swap(x, y);
		int ans = 0;
		for (int i = x; i <= y; i++) {
			if (i % 4 == 0 && i % 100 != 0) 
				++ans;
			else if (i % 400 == 0)
				++ans;
		}
		printf("%d\n", ans);
	}
	system("pause");
}
