#include <stdio.h>
int sum(int a,int b);
int main (void){
	int nian1,nian2,nian3,shu;
	signed int t;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&nian1,&shu);
		if(shu>0){
			nian2=nian1+shu;
			if(nian2>10000) nian3=9999*2-nian2;
			else nian3=nian2;
			if(nian1>nian3){
				int t;
				t=nian1;nian1=nian3;nian3=t;
			} 
			printf("%d\n",sum(nian1,nian2));
		} 
		else if(shu=0){
			printf("%d\n",sum(nian1,nian1));
		}
		else{
			nian2=nian1+shu;
			printf("%d ",shu);
		}
	}
	return 0;
}
int sum(int a,int b){
	int s=0;
	for(int i=a;i<=b;i++){
		if((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) s+=1;
	}
	return s;
}
