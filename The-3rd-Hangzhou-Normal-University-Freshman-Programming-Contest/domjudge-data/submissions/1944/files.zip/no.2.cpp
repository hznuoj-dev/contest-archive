#include<stdio.h>
#include<math.h>
#include<string.h>
int yesorno(int x)
{
	if (x % 4 == 0 && x % 100 != 0 || x % 400 == 0)
		return 1;
	else
		return 0;
}
int main()
{
	int total, t, year, addyear, yichu, t, i;
	scanf_s("%d", &t);
	while (t--)
	{
		total = 0;
		scanf_s("%d %d", &year, &addyaer);
		lastyear = year + addyear;
		if (lastyear > 9999)
		{
			yichu = lastyear - 9999;
			lastyear = 9999 - yichu;
		}
		if (year < lastyear)
		{
			t = year;
			year = lastyear;
			lastyear = t;
		}
		for (i = year; i <= lastyear; i++)
		{
			if (yesorno == 1)
				total++;
		}
		printf("%d\n", total);
	}
}
