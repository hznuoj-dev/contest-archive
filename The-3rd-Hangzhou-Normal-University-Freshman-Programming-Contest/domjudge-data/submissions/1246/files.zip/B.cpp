#include<bits/stdc++.h>
using namespace std;


int main(void)
{
	int n;
	cin>>n;
	while(n--)
	{
		int y,a;
		cin>>y>>a;
		int tr;
		if(y+a>9999) tr=9999-(y+a-9999);
		else tr=y+a;
		int sum=0;
		if(tr>=y) 
		{
		for(int i=y;i<=tr;++i)
					if(i%4==0 && i%100!=0 || i%400==0) sum++;
				}
		else for(int i=tr;i<=y;++i)
					if(i%4==0 && i%100!=0 || i%400==0) sum++;
		cout<<sum<<endl;
	}
	
	
	return 0;
}

