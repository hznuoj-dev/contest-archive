#include <cstdio>
#include <iostream>
#include <cstring> 
#include <map>
#include <vector>
#include <algorithm>
using namespace std;
const int N = 1e5 + 10;
vector<int>a[N], b[N];
int n, q;
int m[N], l[N], k[N];
bool check(int mid, int id) {
	int B_size = b[id].size(), sum = 0;
	for (int i = 0; i < B_size; i++) {
		int x = b[id][i];
		int pos = lower_bound(a[x].begin(), a[x].end(), mid) - a[x].begin();
		sum += pos;
	}
	if (sum <= k[id] - 1)
		return true;
	else
		return false;
}
int solve(int id) {
	int l = 1, r = 1e9, ans;
	while (l <= r) {
		int mid = (l + r) >> 1;
		if (check(mid, id)) {
			l = mid + 1;
			ans = mid;
		} else
			r = mid - 1;
	}
	return ans;
}
int main () {
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		int x;
		scanf("%d", &m[i]);
		for (int j = 1; j <= m[i]; j++) {
			scanf("%d", &x);
			a[i].push_back(x);
		}
		sort(a[i].begin(), a[i].end());
	}
	scanf("%d", &q);
	for (int i = 1; i <= q; i++) {
		int x;
		scanf("%d", &l[i]);
		for (int j = 1; j <= l[i]; j++) {
			scanf("%d", &x);
			b[i].push_back(x);
		}
		sort(b[i].begin(), b[i].end());
		scanf("%d", &k[i]);
	}
	for (int i = 1; i <= q; i++) 
		printf("%d\n", solve(i));
}
