#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
const int maxn = 100005;
const int inf = 0x3f3f3f3f;
const int mod = 1e9 + 7;

int main() {



    return 0;
}