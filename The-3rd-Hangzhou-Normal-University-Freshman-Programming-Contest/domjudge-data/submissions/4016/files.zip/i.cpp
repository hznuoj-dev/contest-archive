#include<iostream>

using namespace std;

int main()
{
    int tes,sum,i,res=0;
    for(i=1;i<=4;i++)
    {   
        sum=0;
        cin >> tes;
        while(tes>0)
        {
            sum+=tes%10;
            tes/=10;
        }
        if(sum>=16 || sum==6)
        {
            res++;
        }


    }
    switch(res)
    {
        case 0:{
            cout << "Bao Bao is so Zhai......";
            break;
        }
        case 1:{
            cout << "Oh dear!!";
            break;
        }
        case 2:{
            cout << "Bao Bao is good!!";
            break;
        }
        case 3:{
            cout << "Bao Bao is a Super mam!!";
            break;
        }
        case 4:{
            cout <<"Oh my god!!";
            break;
        }

    }
    
    return 0;
}