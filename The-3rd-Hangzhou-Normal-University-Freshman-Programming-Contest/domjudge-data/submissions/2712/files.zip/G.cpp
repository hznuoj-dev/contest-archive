#include<iostream>
#include<algorithm>
#include<map>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug cout<<"what fuck"<<endl
using namespace std;
const int maxn=1e3+10;
struct node{
	int num;
	int id;
	bool friend operator<(const node &a,const node &b){
		if(a.num==b.num)return a.id<b.id;
		else return a.num>b.num;
	} 
}a[maxn];
map<pair<int,int>,int>mp;
int n,m;
int main(){
	fcio;
	int T;
	while(cin>>T){
		while(T--){
			cin>>n>>m;
			for(int i=1;i<=n;++i){
				a[i].id=i;
				a[i].num=0;
			}
			mp.clear();
			while(m--){
				int x,y;
				cin>>x>>y;
//				debug;
//				cout<<mp[make_pair(x,y)]<<endl;
//				debug;
				if(!mp[make_pair(x,y)]){
					mp[make_pair(x,y)]=1;
					a[x].num++;
				}
			}
			sort(a+1,a+1+n);
//			for(int i=1;i<=n;++i){
//				cout<<a[i].id<<" "<<a[i].num<<endl;
//			}
			for(int i=1;i<=n;++i){
				cout<<a[i].id;
				if(i!=n)cout<<" ";
				else cout<<endl;
			}
		}
	}
}

