#include<stdio.h>
int main(void)
{
	int T,y,a,x=0,endy,ty,ta,i;
	scanf("%d",&T);
	while(T--)
	{
		x=0;
		scanf("%d %d",&y,&a);
		ty=y+a;
		if(ty>=10000)
		{
			ta=ty-9999;
			endy=9999-ta;
		}else{
			endy=ty;
			
		}
		if(endy<y)
			{ty=endy;
			endy=y;
			y=ty;
			}
		for(i=y;i<=endy;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
			x+=1;
		}
		printf("%d\n",x);
	}
}
