#include<stdio.h>
#include<string.h>
#define N 100
#pragma warning(disable:4996)
int main() {
	int i, len, f = 0,t,g;
	char a[10000];
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &g);
		while (g--) {
			scanf("%c", &a);
			len = strlen(a);
			for (i = 0; i < len; i++) {
				if (a[i] != '.')
					f++;
			}
			if (f != 0)
				printf("%d", f);
			else if (f == 0)
				printf("0");
		}
	}
	return 0;
}