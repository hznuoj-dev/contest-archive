#include <stdio.h>
#include<stdbool.h>
#include<string.h>
#include<stdlib.h>
#define PI 3.14159
#include<math.h>
#pragma warning(disable:4996)


int  main() {
	int f(long long x);
	long long a, b, c, d;
	int k = 0;
	scanf("%lld%lld%lld%lld", &a, &b, &c, &d);
	if (f(a) == 6 || f(a) >= 16)k++;
	else if (f(b) == 6 || f(b) >= 16)k++;
	else if (f(c) == 6 || f(c) >= 16)k++;
	else if (f(d) == 6 || f(d) >= 16)k++;
	if (k == 0)printf("Bao Bao is so Zhai......\n");
	else if (k == 1)printf("Oh dear!!\n");
	else if (k == 2)printf("BaoBao is good!!\n");
	else if (k == 3)printf("Bao Bao is a SupEr man///!\n");
	else if (k == 4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
int f(long long x) {
	int m=0;
	while (x > 0) {
		m += x % 10;
		x = x / 10;
	}
	return m;
}