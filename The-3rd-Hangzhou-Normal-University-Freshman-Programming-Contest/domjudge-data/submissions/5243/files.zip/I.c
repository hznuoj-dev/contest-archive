#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	int i,sum,s,m,n;
	char a[20]={'\0'};
	sum=0;
	for(i=1;i<=4;i++){
		s=0;
		scanf("%s",a);
		for ( m = 0, n = strlen(a) - 1; n >= 0; ){
		s = a[n--] - '0'+s;
	}
	if(s>=16||s==6)
	   sum++;	
	}
	switch(sum){
		case 0:
			printf("Bao Bao is so Zhai......\n");
			break;
		case 1:
		    printf("Oh dear!!\n")	;
		    break;
		case 2:
		    printf("BaoBao is good!!\n");
			break;
		case 3:
		    printf("Bao Bao is a SupEr man///!\n");
			break;
		case 4:
		    printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
			break;		    
	}
	return 0;
}
