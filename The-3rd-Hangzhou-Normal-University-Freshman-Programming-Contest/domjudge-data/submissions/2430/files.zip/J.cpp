#include<iostream>
using namespace std;
#include<set>
#include<string>
int main()
{
	set<char> st;
	int T,n;
	int a=0;
	string s;
	cin>>T;
	while(T--)
	{
		cin>>n;
		while(n--)
		{
			cin>>s;
			for(int i=0;i<s.size();i++)
			{
				if(s[i]!='.')
				st.insert (s[i]);
			}
			a+=st.size();
			st.clear();
		}
		cout<<a<<endl;
		a=0;
	}
	
}