#include<stdio.h>
int qu(int i)
{
	int sum = 0;
	while (i > 0)
	{
		sum = sum + i % 10;
		i = i / 10;
	}
	return sum;
}
int main()
{
	int a, b, c, d, h = 0;
	scanf("%d %d %d %d", &a, &b, &c, &d);
	if (qu(a) >= 16 || qu(a) == 6)
		h++;
	if (qu(b) >= 16 || qu(b) == 6)
		h++;
	if (qu(c) >= 16 || qu(c) == 6)
		h++;
	if (qu(d) >= 16 || qu(d) == 6)
		h++;
	switch (h)
	{
	case 0:
		printf("Bao Bao is so Zhai......");
		break;
	case 1:
		printf("Oh dear!!");
		break;
	case 2:
		printf("Bao Bao is good!!");
		break;
	case 3:
		printf("Bao Bao is a SupEr man///!");
		break;
	case 4:
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		break;
	}
	return 0;
}
