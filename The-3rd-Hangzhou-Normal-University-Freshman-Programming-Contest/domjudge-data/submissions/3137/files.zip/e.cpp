#include<stdio.h>
int main()
{
	long long e,b,c,d;
	scanf("%lld %lld %lld %lld",&e,&b,&c,&d);
	int x=0,y,z=0;
	int t=0,g=0,u=0,i=0;
	while(e>0)
	{
		y=e%10;
		t=t+y;
		e=e/10;
		if(t>=16||t==6)
		{
			z++;
			break;
		}
	}
	while(b>0)
	{
		y=b%10;
		g=g+y;
		b=b/10;
		if(g>=16||g==6)
		{
			z++;
			break;
		}
	}
	while(c>0)
	{
		y=c%10;
		u=u+y;
		c=c/10;
		if(u>=16||u==6)
		{
			z++;
			break;
		}
	}
	while(d>0)
	{
		y=d%10;
		i=i+y;
		d=d/10;
		if(i>=16||i==6)
		{
			z++;
			break;
		}
	}
	if(z==1)
	printf("Oh dear!!\n");
	else if(z==2)
	printf("BaoBao is good!!\n");
	else if(z==3)
	printf("Bao Bao is a SupEr man///!\n");
	else if(z==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	else if(z==0)
	printf("Bao Bao is so Zhai......\n");
	return 0;
}
