#include<bits/stdc++.h>
using namespace std;
int main()
{
   int n,i;
   char m[1000005];
   cin>>n;
   for(i=1;i<=n;i++)
   {
      cin>>m;
   }
   cout<<n;
   return 0;
}
