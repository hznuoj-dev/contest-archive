#include <stdio.h>
#include <math.h>
#include <string.h>
int main()
{
	long long a,m,sum=0,n,t;
	scanf("%lld%lld",&a,&m);
	long long b[a],c[a],d[a];
	long long i,j;
	for(i=1;i<=a;i++)
	{
		scanf("%lld",&b[i]);
	}
	for(i=1;i<=a;i++)
	{
		scanf("%lld",&c[i]);
	}
	for(i=1;i<a;i++)
	{
		for(j=1;j<=a-i;j++)
		{
			if(b[j]>b[j+1])
			{
				t=b[j];
				b[j]=b[j+1];
				b[j+1]=t;
				t=c[j];
				c[j]=c[j+1];
				c[j+1]=t;
			}
		}
	}
	for(i=1;i<=m;i++)
	{
		n=i;
		for(j=1;j<=a;j++)
		{
			d[j]=c[j];
		}
		for(j=a;j>=1;j--)
		{
			while(n-b[j]>=0&&d[j]!=0&&n!=0)
			{
				n=n-b[j];
				if(n==0)
				{
					sum=sum+1;
				}
				d[j]=d[j]-1;
			}
		}
	}
	printf("%lld\n",sum);
 } 
