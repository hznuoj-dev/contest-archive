#include<string.h>
#include<stdio.h>
char a[1000000],b[1000001];
int main()
{
	int t,n;	
	scanf("%d",&t);
	while(t--)
	{
		int num=0;
		scanf("%d",&n);
		while(n--)
		{
			int i,j;
			scanf("%s",a);
			int len=strlen(a);
			for(i=0;i<len;++i)
			{
				int k=1,h=1,flag=0;
				if(i=0)
				{
					b[h]=a[i];
					h=h+1;
				}
				else
				{
                  for(k=1;k<h;++k)
				  {
					  if(a[i]!=b[k])
						  b[h]=a[i];
					  h=h+1;
				  }
				}
				for(j=1;j<=h;++j)
				{
					if(a[i]==b[j])
						flag=1;
				}
				if(a[i]!='.'&&flag==0)
					num=num+1;
			}
		}
		printf("%d\n",num);
	}
}