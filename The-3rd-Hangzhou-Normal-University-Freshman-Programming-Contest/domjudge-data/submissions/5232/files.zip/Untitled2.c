#include<stdio.h>
#include<string.h>
main() 
{
	char a[100000];
	int t,T,sum,i,j,flag;
	scanf("%d",&t);
	while(t--)
	{
		sum=0;
		scanf("%d",&T);
		while(T--)
		{	
			char b[1000]={'\0'};
			scanf("%s",a);
			for(i=0;i<strlen(a);i++)
			{
				
				flag=1;
				b[0]='.';
				for(j=0;j<strlen(b);j++)
				{
					
					if(a[i]==b[j])
					flag=0;
				}
				
				if(flag==1)
				{
					b[j]=a[i];
					sum=sum+1;
				
				}
				
			}
		}
		printf("%d\n",sum);
	 } 

}
