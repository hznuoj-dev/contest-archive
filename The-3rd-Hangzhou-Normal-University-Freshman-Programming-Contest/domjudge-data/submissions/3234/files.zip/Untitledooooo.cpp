#include<stdio.h>
int check(int n){
	int t=0;
	while(n>0){
		t=t+n%10;
		n/=10;
	}
	if(t>=16||t==6){
		return 1;
	}
	else{
		return 0;
	}
}
int main(){
	int a,b,c,d;
	int f;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	f=check(a)+check(b)+check(c)+check(d);
	if(f==1)printf("Oh dear!!\n");
	if(f==2)printf("BaoBao is good!!\n");
	if(f==3)printf("Bao Bao is a SupEr man///!\n");
	if(f==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if(f==0)printf("Bao Bao is so Zhai......\n");
}
