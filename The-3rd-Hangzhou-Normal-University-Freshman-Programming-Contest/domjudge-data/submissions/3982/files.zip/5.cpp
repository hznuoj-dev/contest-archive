#include<stdio.h>
int main(){
	int t,k;
	int n[10],m[10],i;
	double r;
	while(~scanf("%d",&t)){
		for(k=0;k<t;k++){
			scanf("%d %d",&n[k],&m[k]);
		}
		for(k=0;k<t;k++){ 
		r=m[k]*1.0/n[k];
		printf("[");
		for(i=1;i<=m[k];i++){
			printf("#");
		}
		if(n[k]-m[k]>=1){
		for(i=1;i<=n[k]-m[k];i++){
		printf("-");
		}
		}
		if(k<t-1){
		printf("] %.0lf%%\n",r*100);}
		else printf("] %.0lf%%",r*100);	
	} 
	}
	return 0;
}
