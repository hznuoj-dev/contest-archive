#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{
	char a[20];
	int len,sum,n=0;
	for(int i=0;i<4;i++){
		sum=0;
		scanf("%s",a);
    	len=strlen(a);
    	for(int i=0;i<len;i++){
    		sum+=a[i]-'0';
    	}
    	if(sum>=16||sum==6) n++;
	}
	if(n==0)printf("Bao Bao is so Zhai......\n");
	if(n==1)printf("Oh dear!!\n");
	if(n==2)printf("BaoBao is good!!\n");
	if(n==3)printf("Bao Bao is a SupEr man///!\n");
	if(n==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	return 0;
}
