#include<stdio.h>
#include<math.h>
#pragma warning(disable:4996)
#define kfc kfc
int main()
{
char kfc;	
printf("__      _____\n");
printf("| | ___/ ____\\\ \____\n");
printf("| |/ /\ \\ __\ \\/  ___ \\");
printf("\n");
printf("|   <   |  |\\ \ \\___\n");
printf("|__|_ \\ |__| \\___  >\n");
printf("     \\/          \\/\n");
return 0;
	
}
