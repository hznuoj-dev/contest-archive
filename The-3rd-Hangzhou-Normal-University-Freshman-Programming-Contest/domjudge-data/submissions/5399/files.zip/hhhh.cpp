#include<stdio.h>
#include<string.h>
int main()
{	char i[2];
	scanf("%s",&i);
	
	if(i[0]=='k'&&i[1]=='f'&&i[2]=='c')
	printf("__ _____\n");
	printf("| | ___/ ____\\____\n");
	printf("| |/ /\\ __\\/ ___\\\n");
	printf("| < | | \\ \\___\n");
	printf("|__|_ \\ |__| \\___ >\n");
	printf("\\/ \\/ \n");
	
}	







