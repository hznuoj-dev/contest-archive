#include<stdio.h>
#include<string.h>
int main(){
    int T,a,b,s;
    scanf("%d",&T);
    while(T--){
    	scanf("%d%d",&a,&b);
    	s=b*100/a;
    	a=a-b;
    	printf("[");
    	while(b--) printf("#");
    	while(a--) printf("-");
    	printf("] %d%%\n",s);
	}
    return 0;
}
