#include<iostream>
#include<algorithm>
#include<map>
#include<cstring>
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug cout<<"what fuck"<<endl
using namespace std;
const int maxn=1e3+10;
int n,m;
struct node{
	int rank;
	int id;
	bool friend operator<(const node &a,const node &b){
		if(a.rank==b.rank)return a.id<b.id;
		else return a.rank>b.rank;
	}
}a[maxn];
map<pair<int,int>,int>mp;
int vis[maxn]; 
int main(){
	fcio;
	int T;
	while(cin>>T){
		while(T--){
			memset(vis,0,sizeof vis);
			cin>>n>>m;
			for(int i=1;i<=n;++i){
				a[i].id=i;
				a[i].rank=n;
			} 
			mp.clear();
			int maxx=0;
			while(m--){
				int x,y;
				cin>>x>>y;
				vis[x]=vis[y]=1;
				if(mp[make_pair(x,y)])continue;
				if(x==y)continue;
				mp[make_pair(x,y)]=1;
				a[x].rank=a[y].rank+1;
				maxx=max(maxx,a[x].rank);
			}	
			for(int i=1;i<=n;++i){
				if(!vis[i])
					a[i].rank=maxx;
			}
			sort(a+1,a+1+n);
			for(int i=1;i<=n;++i){
				cout<<a[i].id;
				if(i!=n)cout<<" ";
				else cout<<endl;
			}
		}
	}
	return 0;
}

