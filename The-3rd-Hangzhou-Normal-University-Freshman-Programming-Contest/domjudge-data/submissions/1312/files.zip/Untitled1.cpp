#include <cstdio>
#include <iostream>
#include <cstring> 
#include <map>
using namespace std;
const int N = 1e6 + 10;
map<char, bool>vis;
char s[N];
int main () {
	int T;
	scanf("%d", &T);
	while (T--) {
		int n, ans = 0;
		scanf("%d", &n);
		for (int i = 1; i <= n; i++) {
			scanf(" %s", s);
			int len = strlen(s);
			int temp = 0;
			vis.clear();
			for (int j = 0; j < len; j++) {
				if (s[j] == '.')
					continue;
				if (!vis[s[j]]) {
					++temp;
					vis[s[j]] = true;
				}
			}
			ans += temp;
		}
		printf("%d\n", ans);
	}
}
