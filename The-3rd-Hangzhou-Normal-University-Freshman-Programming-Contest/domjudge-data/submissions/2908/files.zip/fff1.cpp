#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
    int i, m, j, n, k;
    char w[1001];
    m = 0;
    for (i = 1; i <= 4; i++) {
        scanf("%s",w);
        n = strlen(w);
        k = 0;
        for (j = 0; j < n; j++)
            k += w[j] - 48;
        if (k == 6 || k >= 16)
            m++;
    }
    if (m == 0)
        printf("Bao Bao is so Zhai......\n");
    else if (m == 1)
        printf("Oh dear!!\n");
    else if (m == 2)
        printf("BaoBao is good!!\n");
    else if (m == 3)
        printf("Bao Bao is a SupEr man///!\n");
    else
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
}

