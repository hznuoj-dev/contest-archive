#include <stdio.h>
#include <string.h>
int main() {
	int t,i,k,v;
	double m=0,n=0;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%lf %lf",&n,&m);
		printf("[");
		for(k=0;k<m;k++){
			printf("#");
		}
		for(v=0;v<(n-m);v++){
			printf("-");
		}
		printf("]");
		printf(" ");
		printf("(m/n*100)%.0f%%");
	} 
	return 0;
}
