
#include<stdio.h>
#include<math.h>
#include <stdlib.h>
int main()
{
	int t,year1,n,year2,x=0,i;
	scanf("%d",&t);
	while(t--)
	{
		x=0;
		year2=0;
		scanf("%d%d",&year1,&n);
		year2=year1+n;
		if(year2<=9999)
		{
		if(year2>=year1)
		{
			for(i=year1;i<=year2;i++)
			{
				if((i%4==0&&i%100!=0)||(i%400==0))
					x+=1;
			}
		}
		else
		{
			for(i=year2;i<=year1;i++)
			{
				if((i%4==0&&i%100!=0)||(i%400==0))
					x+=1;
			}
		}
		}
		else if(year2>9999)
		{
			year2=9999-(year2-9999);
			if(year2>=year1)
			{
				for(i=year1;i<=year2;i++)
				{
					if((i%4==0&&i%100!=0)||(i%400==0))
						x+=1;
				}
			}
			else
			{
				for(i=year2;i<=year1;i++)
				{
					if((i%4==0&&i%100!=0)||(i%400==0))
						x+=1;
				}
			}

		}
		printf("%d\n",x);
	}
}

