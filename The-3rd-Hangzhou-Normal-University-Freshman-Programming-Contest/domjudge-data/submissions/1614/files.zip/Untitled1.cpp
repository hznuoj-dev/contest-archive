#include<stdio.h>
int main ()
{
	int t,Y,A,small,big,newone,i,regit;
	regit=0;
	scanf("%d",&t);
	while (t--){
		scanf("%d%d",&Y,&A);//Y is originoal
		small=Y+A;
		big=19999-Y-A;
		if(small>9999)//from Y to newone
		newone = big;
		else 
		newone = small;//judge of newone
		if(newone>Y){
			for (i=Y;i<=newone;i++){
				if(i%4==0&&i%100!=0||i%400==0)
				regit++;}
			}
		else {
			for (i=Y;i>=newone;i--){
				if(i%4==0&&i%100!=0||i%400==0)
				regit++;
			}
		}
		printf("%d\n",regit);
		regit =0;
	}
	return 0;
 } 
