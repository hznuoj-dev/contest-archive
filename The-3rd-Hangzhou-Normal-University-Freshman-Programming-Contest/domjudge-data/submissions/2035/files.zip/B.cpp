#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
int v,n,m,x,y,i,j,t=0,sum,temp,s1,s2,s3,s4;
long long a,b,c,d;
int find(int n){
    if(n==6||n>=16)
        return 1;
    return 0;
}
int main(){
    scanf("%Ld%Ld%Ld%Ld",&a,&b,&c,&d);

    while(a>0){
        s1=s1+a%10;
        a/=10;
    }
    while(b>0){
        s2=s2+b%10;
        b/=10;
    }
    while(c>0){
        s3=s3+c%10;
        c/=10;
    }
    while(d>0){
        s4=s4+d%10;
        d/=10;
    }
    sum=find(s1)+find(s2)+find(s3)+find(s4);
    if(sum==4)
        printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    else if(sum==3)
        printf("Bao Bao is a SupEr man///!");
    else if(sum==2)
        printf("BaoBao is good!!");
    else if(sum==1)
        printf("Oh dear!!");
    else if(sum==0)
        printf("Bao Bao is so Zhai......");
    return 0;
}
