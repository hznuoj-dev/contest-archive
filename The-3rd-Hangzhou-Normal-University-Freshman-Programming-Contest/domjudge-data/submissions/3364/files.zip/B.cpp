#include<stdio.h>

int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int Y,A;
		scanf("%d %d",&Y,&A);
		int max=0,min=0,add=0;
		add = Y+A;
		int i,count=0;
		if(add>9999){
			add = 9999 - (add-9999);
		}
		if(add>Y){
			max = add;
			min = Y;
		}else{
			max = Y;
			min = add;
		}
		for(i=min;i<=max;i++){
			if(i%4==0&&i%100!=0||i%100==0&&i%400==0){
				count++;
			}
		}
		printf("%d\n",count);
	}
	return 0;
}
