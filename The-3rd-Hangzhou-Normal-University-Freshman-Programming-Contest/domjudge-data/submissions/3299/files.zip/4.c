#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
char del(char s[],int j);
int main(int argc, char *argv[]) {
	int t,i,j,q,m,n,s=0;
	char a[1000000]={'\0'},b[10000],c[10000];
	scanf("%d",&t);
	while(t--){
		s=0;
		j=0;
		scanf("%d",&n);
		getchar();
		for(m=1;m<=n;m++){
		    j=0;
			scanf("%s",a);
			for(i=0;i<=strlen(s)-1;i++){
				if(a[i]!='.'){
				b[j]=a[i];
				j++;
			
			}
			}
			strcpy(c,del(b,j));
			s+=strlen(c);
		}
		printf("%d",s);
	} 

	return 0;
}
char del(char s[],int j){
	int i,q;
	for(q=0;q<j;q++){
					for(i=q+1;i<j;i++){
					if(s[i]==s[q]){
						for(i=q;s[i]!='\0';i++){
							s[q-1]=s[i];
						}
						s[q-1]='\0';
					}	
					}
					}
					return s;
					
}
