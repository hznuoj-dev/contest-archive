#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int T,i,j,k,a[9999],p1,p2,m,n,l;
	scanf("%d",&T);
	for(i=1;i<=T;i++)
	{
		scanf("%d%d",&n,&m);
		for(j=1;j<=n;j++)
		{
			a[j]=j;
		}
		for(j=1;j<=m;j++)
		{
			scanf("%d%d",&p1,&p2);
			if(p1>p2)
			{
				l=a[p1];
				for(k=p1-1;k>=p2;k--)
				{
					a[k+1]=a[k];
				}
				a[p2]=l;
			}
		}
		for(j=1;j<=n;j++)
		{
			printf("%d",a[j]);
			if(j!=n)
			printf("��");
		}
	}
	return 0;
}

