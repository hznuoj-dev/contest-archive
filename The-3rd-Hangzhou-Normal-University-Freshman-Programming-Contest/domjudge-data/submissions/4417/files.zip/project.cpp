#include<stdio.h>
#include<string.h>
int t, n, s, i, len, s1;
int b[128];
char a[1000005];
int main() {
    scanf("%d", &t);
    while (t--) {
        scanf("%d", &n);
        s1 = 0;
        while (n--) {

            scanf("%s", a);
            len = strlen(a);
            for (i = 0;i <= 127;i++) {
                b[i] = 0;
            }
            for (i = 0;i < len;i++) {
                if (a[i] == '.') {
                    continue;
                }
                else if (b[a[i]] == 0) {
                    b[a[i]] = 1;
                    s1++;
                }
            }
        }
        printf("%d\n", s1);
    }
    return 0;
}



