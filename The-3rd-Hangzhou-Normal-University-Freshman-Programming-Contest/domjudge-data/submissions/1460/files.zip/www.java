import java.util.Scanner;
public class www
{
  
    public static void main(String[] args) 
    {
        Scanner s=new Scanner(System.in);
       while(s.hasNext())
       {  
    	String a=s.next();
    	if(a.equals("kfc"))
    	{
    	System.out.println(" --      -----");
    	System.out.println("|  | ___/ ____\\____");
    	System.out.println("|  |/ /\\  __\\/ ___\\");
    	System.out.println("|    <  |  | \\  \\___");
    	System.out.println("|__|_ \\ |__|  \\___  >");
    	System.out.println("     \\/           \\/");
    	}
       }
         
     }
  
}