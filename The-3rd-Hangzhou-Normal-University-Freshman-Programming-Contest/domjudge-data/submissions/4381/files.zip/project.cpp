#include<stdio.h>
#include<string.h>
int t, n, s, i, d;
int b[128];
char a[1000010];
int main() {
    scanf("%d", &t);
    while (t--) {
        scanf("%d", &n);
        d = 0;
        while (n--) {
         scanf("%s", a);
            for (i = 0;i <= 127;i++) {
                b[i] = 0;
            }
            for (i = 0;i < strlen(a);i++) {
                if (a[i] == '.') {
                    continue;
                }
                else 
				if (b[a[i]] == 0) {
                    b[a[i]] = 1;
                   d=d+1;
                }
            }
        }
        printf("%d\n", d);
    }
    return 0;
}


