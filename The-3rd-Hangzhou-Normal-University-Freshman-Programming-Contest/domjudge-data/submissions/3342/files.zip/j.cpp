#include<stdio.h>
#include<string.h>
int main(){
 int t,a,h;
 char b[1000010],sum,sum2;
 scanf("%d",&t);
 while(t--){
 	scanf("%d",&a);
 	getchar();
 	sum2=0;
 	while(a--){
 		sum=0;
 		int c[100000]={0};
        scanf("%s",b);
 		h=strlen(b);
 		for(int i=0;i<h;i++){
 			if(b[i]!='.'&&c[b[i]-'a'+'a']==0){
 			sum++;
			 c[b[i]-'a'+'a']++;}
		 }
		 sum2+=sum;
	 }
	 printf("%d\n",sum2);
} }
