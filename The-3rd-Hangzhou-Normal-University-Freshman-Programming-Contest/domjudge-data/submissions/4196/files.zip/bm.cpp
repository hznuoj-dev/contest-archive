#include<bits/stdc++.h>
using namespace std;
int main(){
	
	int t;
	scanf("%d",&t);
	priority_queue<int> q[t+1];
	int a[t+1];
	for(int i=1;i<=t;i++){
		int n;
		scanf("%d",&n);
		for(int j=1;j<=n;j++){
			int m;
			scanf("%d",&m);
			q[i].push(m);
		}
		a[i]=n;
	}//����5 4 3 2 1 top,pop
	scanf("%d",&t);
	for(int i=0;i<t;i++){
	 	int m,cnt=0;
	 	scanf("%d",&m);
		priority_queue<int> p1,p2;
	 	for(int j=0;j<m;j++){
	 		int b;
			scanf("%d",&b);
			cnt+=a[b];
			while(!q[b].empty()){
				p1.push(q[b].top());
				p2.push(q[b].top());
				q[b].pop();
			}
			while(!p1.empty()){
				q[b].push(p1.top());
				p1.pop();
			}
		}
		scanf("%d",&m);
		cnt-=m;
		while(cnt--) p2.pop();
		printf("%d\n",p2.top());
		while(!p2.empty()) p2.pop();
	}
	
}
