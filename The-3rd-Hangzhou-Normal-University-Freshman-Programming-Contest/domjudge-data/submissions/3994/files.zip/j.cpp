#include<stdio.h>
#include<string.h>
char s[100001];
char a[100001];
int main(void){
	int t,n,i,len,j,k=1,flag,sum=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		sum=0;
		for(i=1;i<=n;i++){
			memset(a,0,sizeof(a));
			k=0;
			scanf("%s",s);
			len=strlen(s)-1;
			for(j=0;j<=len;j++){
				flag=0;
				if(s[j]!='.'){
					for(int l=1;l<=k;l++){
						if(s[j]==a[l]){
							flag=1;
						}
					}
					if(!flag){
					    sum++;
					    k++;
					    a[k]=s[j];
					}
				}
			}
		}
		printf("%d\n",sum);
	}
}
