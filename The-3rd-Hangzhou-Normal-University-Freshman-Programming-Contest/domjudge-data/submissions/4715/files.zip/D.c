#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int i,n,s=0;char a[99999]="";
	scanf("%d",&n);
	if(n==1){
		scanf("%s",a);
		printf("1");
	}
	else {
		for(i=0;i<n;i++){
			scanf("%s",a);
			s+=strlen(a);
		}
		printf("%d",s);
	}
}
