#include<bits/stdc++.h>
using namespace std;
main()
{scanf("kfc");

printf("__ _____\n");
printf("| | ___/ ____\____\n");
printf("| |/ /\ __\/ ___\n");
printf("| < | | \ \___\n");
printf("|__|_ \ |__| \___ >\n");
printf("     \/          \/  \n");

}
