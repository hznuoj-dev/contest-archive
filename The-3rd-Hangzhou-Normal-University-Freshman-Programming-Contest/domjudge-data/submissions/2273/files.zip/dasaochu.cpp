#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int T,n,i,j,k,q,m,p;
	char a[100001],b[1000001];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
	p=0;
		while(n--){
			j=0;
			scanf("%s",a);
			m=strlen(a);
			for(i=0;i<m;i++){
				if(a[i]!='.'){
					b[j]=a[i];
					j++;
				}
			}
			k=j;
			for(i=0;i<j;i++){
				for(q=0;q<j;q++){
					if(b[i]==b[q]&&i!=q){
						k--;b[i]='.';
						break;
					}
				}
			}
			p=p+k;
		}
		printf("%d\n",p);
	}
}
