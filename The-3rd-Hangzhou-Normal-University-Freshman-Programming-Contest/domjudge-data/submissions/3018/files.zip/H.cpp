#include<bits/stdc++.h>
using namespace std;
int main(){
	int T;
	cin >> T;
	while(T--){
		int n,m;
		cin >> n >> m;
		cout << "[";
		for(int i=1;i<=m;i++)cout << "#";
		for(int i=1;i<=(n-m);i++)cout << "-";
		cout << "] ";
		double l=(double)m/(double)n*100;
		int r=l;
		int p=(l+0.5);
		if(p>r)l--;
		printf("%.0f%\n",l);
	}
	
return 0;
}
