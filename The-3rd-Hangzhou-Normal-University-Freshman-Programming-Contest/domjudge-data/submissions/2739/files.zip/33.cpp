#include<stdio.h>
#include<string.h>
int main(){
	char a[20],b[20],c[20],d[20];
	int s1=0,s2=0,s3=0,s4=0,x1=0,x2=0,x3=0,x4=0,y;
	scanf("%s",&a);
	scanf("%s",&b);
	scanf("%s",&c);
	scanf("%s",&d);
	int len1=strlen(a);
	int len2=strlen(b);
	int len3=strlen(c);
	int len4=strlen(d);
	for(int i=0;i<len1;i++){
		y=a[i]-'0';
		s1=s1+y;
	}
	if(s1>=16||s1==6)
	x1=1;
	for(int i=0;i<len2;i++){
		y=b[i]-'0';
		s2=s2+y;
	}
	if(s2>=16||s2==6)
	x2=1;
	for(int i=0;i<len3;i++){
		y=c[i]-'0';
		s3=s3+y;
	}
	if(s3>=16||s3==6)
	x3=1;
	for(int i=0;i<len4;i++){
		y=d[i]-'0';
		s4=s4+y;
	}
	if(s4>=16||s4==6)
	x4=1;
	if(x1+x2+x3+x4==1)
	printf("Oh dear!!\n");
	else if(x1+x2+x3+x4==2)
	printf("BaoBao is good!!\n");
	else if(x1+x2+x3+x4==3)
	printf("Bao Bao is a SupEr man///!\n");
	else if(x1+x2+x3+x4==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	else if(x1+x2+x3+x4==0)
	printf("Bao Bao is so Zhai......\n");
}
