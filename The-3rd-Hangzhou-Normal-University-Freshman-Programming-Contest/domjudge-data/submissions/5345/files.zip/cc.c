#include<stdio.h>
#include<string.h>
#include<math.h>
int main() {
	int i;
	char m[20];
	scanf("%d", &i);
	int n = i;
	while (i--) {
		scanf("%s", m);
	}
	printf("%d", strlen(m) * n);
}