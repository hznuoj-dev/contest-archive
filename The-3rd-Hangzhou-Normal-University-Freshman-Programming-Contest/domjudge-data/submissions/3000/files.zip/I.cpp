#include<iostream>
#include<cstdio>
#include<cstring>
#include<algorithm>
using namespace std;
char a[20],b[20],c[20],d[20];
int main()
{
	int ans=0,sum=0;
	scanf("%s %s %s %s",a,b,c,d);
	for(int i=0;i<strlen(a);i++){
		sum+=a[i]-48;
	}
	if(sum==6||sum>=16)ans++;
	sum=0;
	for(int i=0;i<strlen(b);i++){
		sum+=b[i]-48;
	}
	if(sum==6||sum>=16)ans++;
	sum=0;
	for(int i=0;i<strlen(c);i++){
		sum+=c[i]-48;
	}
	if(sum==6||sum>=16)ans++;
	sum=0;
	for(int i=0;i<strlen(d);i++){
		sum+=d[i]-48;
	}
	if(sum==6||sum>=16)ans++;
	if(ans==0){
		printf("Bao Bao is so Zhai......");
	}
	else if(ans==1){
		printf("Oh dear!!");
	}
	else if(ans==2){
		printf("BaoBao is good!!");
	} 
	else if(ans==3){
		printf("Bao Bao is a SupEr man///!");
	}
	else if(ans==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	return 0;
}
