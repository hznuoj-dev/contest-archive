#include<stdio.h>
int main(){
	int t,a,b,i;
	float ans;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		printf("[");
		for(i=0;i<b;i++){
			printf("#");
		}
		for(i=0;i<a;i++){
			printf("-");
		}
		printf("] ");
		ans=1.0*b/a;
		printf("%.0f%%\n",ans*100);
	}
}
