#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    int t,n,m,i;
	double a;
	scanf("%d",&t);
	while(t--&&t<=10){
		scanf("%d%d",&n,&m);
		a=(double)m/n;
		for(i=1;i<=n;i++){
			if(i==1)printf("["); 
			if(i<=m)printf("#");
			else printf("-");
		}
		printf("] %.lf%%\n",a*100);
	} 
	return 0;
}
