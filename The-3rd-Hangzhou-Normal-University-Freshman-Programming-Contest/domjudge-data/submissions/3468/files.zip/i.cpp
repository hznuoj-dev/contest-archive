#include<stdio.h>
int suan(long long i){
	int j=i,a,b=0;
	for(a=0;j>0;a++){
		j/=10;
	}
	for(;a>0;a--){
		b+=i%10;
		i/=10;
	}
	if(b>=16||b==6) return 1;
	else return 0;
}
int main(void){
	int sum=0;
	long long a,b,c,d;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	if(suan(a)) sum++;
	if(suan(b)) sum++;
	if(suan(c)) sum++;
	if(suan(d)) sum++;
	switch(sum){
		case 0:
			printf("Bao Bao is so Zhai......");
			break;
		case 1:
			printf("Oh dear!!");
			break;
		case 2:
			printf("BaoBao is good!!");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			break;
	}
	return 0;
} 
