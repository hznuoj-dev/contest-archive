#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
	int a,b,c,i,j,t;
	scanf("%d",&t);
	while(t--)
	{
		j=0;
		scanf("%d%d",&a,&b);
		if(a+b>9999)
			{
				b=9999-(a+b-9999);
				if(a<b)
					c=b;
				b=a;
				a=c;
		}
		while(a+b<a)
		{	c=b+a;
		b=a;
		a=c;
		}
		for(i=a;i<=b;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
				j++;
		}
		printf("%d\n",j);
	}
		return 0;
}