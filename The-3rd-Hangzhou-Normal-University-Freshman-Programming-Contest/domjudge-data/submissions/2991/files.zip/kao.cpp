#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int t,i,j,n,m;
	double f;
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		scanf("%d%d",&n,&m);
		f=1.0*m/n;
		printf("[");
		for(j=1;j<=m;j++)
		printf("#");
		for(j=1;j<=n-m;j++)
		printf("-");
		printf("]");
		printf(" %.0lf%%",f);
	}
	return 0;
}
