#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main(void){
	int a,b,c,d,x=0,y=0,m=0,n=0,point=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	while(a>0)
	{
		x+=a%10;
		a/=10; 
	}
	if(x>=16||x==6)
	point+=1;
	while(b>0)
	{
		y+=b%10;
		b/=10; 
	}
	if(y>=16||y==6)
	point+=1;
	while(c>0)
	{
		m+=c%10;
		c/=10; 
	}
	if(m>=16||m==6)
	point+=1;
	while(d>0)
	{
		n+=d%10;
		d/=10; 
	}
	if(n>=16||n==6)
	point+=1;
	if(point==0)
	printf("Bao Bao is so Zhai......\n");
	else if(point==1)
	printf("Oh dear!!\n");
	else if(point==2)
	printf("BaoBao is good!!\n");
	else if(point==3)
	printf("Bao Bao is a SupEr man///!\n");
	else if(point==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	
	
	return 0;
} 
