#include<stdio.h>
#pragma warning(disable:4996)
#include<math.h>
#include<string.h>
int main(){
	int t,y,x,a,i,k,sum;
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d %d",&y,&a);
		x=y+a;
		if(x>9999){
			x=9999-(x-9999);
		}
		if(x>y){
			k=x;x=y;y=k;
		}
		for(i=x;i<=y;i++){
			if(i%4==0&&i%100!=0)
				sum++;
			else if(i%400==0)
				sum++;
		}
		printf("%d\n",sum);
	}
	return 0;
}