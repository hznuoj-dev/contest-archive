#include<stdio.h>
#include<string.h>
#pragma warning (disable:4996)

int main(){
	int t,n,len,i,d,sum0,sum1;
	char q[1000001];
	int a[500];
	scanf("%d",&t);
	while(t--){
	    scanf("%d",&n);
		getchar();
		sum1=0;
		while(n--){
			memset(a,0,sizeof(a));
			sum0=0;
		    scanf("%s",q);
			len=strlen(q);
			for(i=0;i<len;i++){
				if(q[i]!='.'){
				   d=(int)q[i];
				   a[d]=1;
				}
			}
			for(i=0;i<500;i++){
				if(a[i]!=0){
				   sum0++;
				}
			}
			sum1+=sum0;
		}
		printf("%d\n",sum1);
	}
	system("pause");
    return 0;
}