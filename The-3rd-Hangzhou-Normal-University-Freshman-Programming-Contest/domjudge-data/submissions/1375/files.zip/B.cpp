#include<stdio.h>
int main(void){
	int T;
	scanf("%d",&T);
	while(T--){
		int Y,A,Z,sum=0;
		scanf("%d%d",&Y,&A);
		if(Y+A>9999){
			Z=9999-(Y+A-9999); 
		}
		else
			Z=Y+A;
		if(Z<Y){
			int t;
			t=Z;
			Z=Y;
			Y=t;
		}
		for(int i=Y;i<=Z;++i){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				sum++;
			}
		}
		printf("%d\n",sum);
	}
}
