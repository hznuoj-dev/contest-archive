#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int Run(int x){
	if((x%4==0 &&x%100!=0)||(x%400==0)){return 1;
	}else{return 0;
	}
}
int main(){
	char str[256];
	gets(str);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");
}
