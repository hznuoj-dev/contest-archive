#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
	int t, i = 0;
	double e, q, w;
	scanf("%d", &t);
	while (t--) {
		scanf("%lf %lf", &q, &w);
		e = w / q * 100;
		printf("[");
		for (i = 1; i <= w; i++) {
			printf("#");
		}
		for (i = w + 1; i <= q; i++) {
			printf("-");
		}
		printf("]");
		printf(" %.0f", e);
		printf("%%\n");
	}
	return 0;
}