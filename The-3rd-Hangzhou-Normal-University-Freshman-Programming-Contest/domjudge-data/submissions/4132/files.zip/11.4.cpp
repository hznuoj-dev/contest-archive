#include<stdio.h>
int main(void){
    int t,n,m,i,k;
    scanf("%d",&t);
    while(t--){
    	scanf("%d%d",&n,&m);
    	k=100*(1.0)*m/n;
    	printf("[");
    	for(i=1;i<=m;i++){
    		printf("#");
		}
		for(i=1;i<=n-m;i++){
			printf("-");	
		}
		printf("]");
		printf("%d",k); 
		printf("%%\n");
	}
	return 0;
}
