#include<stdio.h>
#include<string.h>
#include<math.h>
char s[100005];
int main(){
	int t;
	scanf("%d", &t);
	while (t--) {
		int n, m,i,j;
		scanf("%d%d", &n, &m);
		printf("[");
		for (i = 1;i <= m;i++)
			printf("#");
		for (i = 1;i <= n - m;i++)
			printf("-");
		j = m *100/n;
		printf(" %d%%]\n", j);
	}
}
