#include"stdio.h"
int main()
{
	int t;
	int a,b,c=0,d=0,i,s=0;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&a,&b);
		if ((a+b>=10000))
		{
		
			d=a+b-(a+b-9999);
		    c=a;
		}
		else
		 {
		 
		   d=a+b;
		   c=a;
	     }
		  s=0;
	   if (b<0)
	   {
	   	c=a+b;
	   	d=a;
	   }
		for (i=c;i<=d;i++)
		{
			if(i%400==0)
                a=1;
          else
         {
           if(i%4==0&&i%100!=0)
               a=1;
           else
              a=0;
        }
           if(a==1)
         {
           s++;
          }

 
    
		}
		printf("%d\n",s);
	}
	return 0;
 } 
