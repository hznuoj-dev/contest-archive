#include<stdio.h>
#include<string.h>
int suan(char i[20]){
	int a,b,sum=0;
	a=strlen(i);
	for(b=0;b<a;b++){
		sum+=i[b]-48;
	}
	if(sum>=16||sum==6) return 1;
	else return 0;
}
int main(void){
	int sum=0;
	char a[20],b[20],c[20],d[20];
	scanf("%s %s %s %s",a,b,c,d);
	if(suan(a)) sum++;
	if(suan(b)) sum++;
	if(suan(c)) sum++;
	if(suan(d)) sum++;
	switch(sum){
		case 0:
			printf("Bao Bao is so Zhai......\n");
			break;
		case 1:
			printf("Oh dear!!\n");
			break;
		case 2:
			printf("BaoBao is good!!\n");
			break;
		case 3:
			printf("Bao Bao is a SupEr man///!\n");
			break;
		case 4:
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
			break;
	}
	return 0;
} 
