#include<stdio.h>
int main(void){
	char a[4];
	scanf("%s",a);
	printf(" _      _____     \n");
	printf("| | ___/ ____\\____\n");
	printf("| |/  /\\  __\\/ ___\\\n");
	printf("|   <  |  | \\  \\___\n");
	printf("|__|_\\ |__|  \\___ >\n");
	printf("    \\/         \\/\n");
	return 0;
}
