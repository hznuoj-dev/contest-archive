#include<stdio.h>
#pragma warning(disable:4996)
int main()
{
	long long int a,b,c,i,j,t;
	scanf("%d",&t);
	while(t--)
	{
		j=0;
		scanf("%lld %lld",&a,&b);
		if(a+b>9999)
			b=9999-(a+b-9999);
		if(a+b<a)
		{	c=b+a;
		b=a;
		a=c;
		}
		for(i=a;i<=b;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
				j++;
		}
		printf("%lld\n",j);
	}
	return 0;
}