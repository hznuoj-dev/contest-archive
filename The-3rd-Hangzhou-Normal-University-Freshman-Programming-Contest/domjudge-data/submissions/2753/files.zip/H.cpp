#include<bits/stdc++.h>
using namespace std;
int main(){
	int T;
	cin >> T;
	while(T--){
		int n,m;
		cin >> n >> m;
		cout << "[";
		for(int i=1;i<=m;i++)cout << "#";
		for(int i=1;i<=n;i++)cout << "-";
		cout << "] ";
		double l=(double)m/(double)n*100;
		printf("%.0f%\n",l);
	}
	
return 0;
}
