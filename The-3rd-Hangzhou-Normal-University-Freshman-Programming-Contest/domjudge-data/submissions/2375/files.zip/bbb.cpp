#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int y,a,x=0,m,i,k;
		scanf("%d %d",&y,&a);
		k=y+a;
		while(k>9999*2){
			k=k-9999;
		}
		while(k<=0){
			k=k+9999;
		}
if(k>0&&k<=9999)m=k;
else if(k>9999){
	m=2*9999-k;
}

		if(m>y){
		for(i=y;i<=m;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
		x++;
		}
		}
		
		else if(m<y){
			for(i=m;i<=y;i++){
			if(i%400==0||(i%4==0&&i%100!=0))
		x++;
		}}
		
		else if(m==y){
			if(m%400==0||(m%4==0&&m%100!=0))
			x++;
		}
		printf("%d\n",x);
	}
	return 0;
}
