#include <stdio.h>
#include <string.h>
int main()
{
    int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,m;
		scanf("%d%d",&n,&m);
		double x;
		x=(double)m/(double)n; 
		printf("[");
		for(int i=1;i<=m;++i)
		{
			printf("#");
		}
		for(int i=1;i<=n-m;++i)
		{
			printf("-");
		}
		printf("] %.f%%\n",x*100.0);
	 } 
	return 0;
 } 
