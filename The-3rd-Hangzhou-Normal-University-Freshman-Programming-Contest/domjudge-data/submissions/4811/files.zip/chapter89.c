#include <stdio.h>
int main(void) {
	int t, y, a, x, i, j, n, m;
	scanf("%d", &t);
	while (t--) {
		j = 0;
		scanf("%d%d", &y, &a);
		a = a + y;
		if (a > 9999) {
			m = 9999 - (a - 9999);
		}
		else {
			m = a;
		}
		if (y == m) {
			if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) {
				printf("1\n");
			}
			else {
				printf("0\n");
			}
		}
		else if (y > m) {
			for (i = m; i <= y; i++) {
				if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) {
					j++;
				}
			}
			printf("%d\n", j);
		}
		else {
			for (i = y; i <= m; i++) {
				if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) {
					j++;
				}
			}
			printf("%d\n", j);
		}
	}
	return 0;
}