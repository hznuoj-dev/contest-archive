#include<math.h>
#define PI 3.1415926
#include <string.h>
#include<stdio.h>
#include<ctype.h>




int main()
{
	while(scanf("kfc")!=EOF){
	printf("__	_____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\  \\___\n");
	printf("|__|_ \\ |__| \\___  >\n");
	printf("     \\/           \\/\n");
	return 0;
	}
return 0;
}
