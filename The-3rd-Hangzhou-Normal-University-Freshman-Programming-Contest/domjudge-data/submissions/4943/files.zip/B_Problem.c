#include<stdio.h>

int main() {
    int T, Y, A;
    int a, count;
    scanf("%d", &T);
    while (T--) {
        count = 0;
        scanf("%d  %d", &Y, &A);
        a = Y + A;
        if (a > 9999) {
            a = 9999;
        }

        int start = 0, end = 0;
        if (a > Y) {
            start = Y;
            end = a;
        } else {
            start = a;
            end = Y;
        }
         if (start < 1) {
            start = 1;
        }

        for (; start <= end; start++) {
            if (start % 100 != 0 && start % 4 == 0) {
                count += 1;
            } else if (start % 400 == 0) {
                count += 1;
            } else {
                count += 0;
            }
        }
        printf("%d\n", count);
    }
    return 0;

}
