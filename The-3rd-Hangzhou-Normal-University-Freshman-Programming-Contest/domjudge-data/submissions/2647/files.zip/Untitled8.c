#include <stdio.h>
int main(){
	int t,m,n,i;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		printf("[");
		for(i=0;i<n;i++){
			if(i<m)
				printf("#");
			else
				printf("-");
		}
		printf("] %.0f%c\n",m*1.0/n*100,37);
	}
	return 0;
}
