#include<stdio.h>
int main(){
	int n,m,a[101],b[101],sum=0,c=0,k,jj;
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n;i++){
		scanf("%d",&b[i]);
	}
	for(int j=0;j<n-1;j++){
	for(int i=n-1;i>=j;i--){
		if(a[i]<a[i-1]){
			k=a[i];a[i]=a[i-1];a[i-1]=k;
			k=b[i];b[i]=b[i-1];b[i-1]=k;
		}
	}}
	for(int i=1;i<=m;i++){
	    jj=i;
		for(int j=n-1;j>=0;j--){
			c=0;
			while(jj>=a[j]&&c<b[j]){
			jj-=a[j];
			c++;
			if(jj==0)goto A; 
			if(jj<a[0]){
				jj+=a[j];
				continue; 
			}
		}
		}A:if(jj==0){
		sum++;}
	}
	printf("%d",sum);
	return 0;
}
