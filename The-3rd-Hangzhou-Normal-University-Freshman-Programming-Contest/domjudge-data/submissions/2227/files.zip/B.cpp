#include<stdio.h>
int main(void){
	int T,Y,A,i;
	scanf("%d",&T);
	while(T--){
		int x=0,max;
		scanf("%d %d",&Y,&A);
		if(Y+A>=10000) max=9999-(Y+A-9999);
		else max=A+Y;
		for(i=Y;i<=max;i++){
			if((i%4==0&&i%100!=0)||(i%400==0))
			x++;
		}
		printf("%d\n",x);
	}
	return 0;
}
