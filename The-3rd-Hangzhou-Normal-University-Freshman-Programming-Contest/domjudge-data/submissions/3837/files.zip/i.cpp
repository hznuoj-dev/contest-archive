#include<stdio.h>
int main(){
	int A,B,C,D;
	int t,sum;
	t=0;
	scanf("%d",&A);
	sum=0;
	while(A>0){
		sum=sum+A/10;
		A=A/10;
	}
	if(sum>=16||sum==6){
		t=t+1;
	}
	scanf("%d",&B);
	sum=0;
	while(B>0){
		sum=sum+B/10;
		B=B/10;
	}
	if(sum>=16||sum==6){
		t=t+1;
	}
	scanf("%d",&C);
	sum=0;
	while(C>0){
		sum=sum+C/10;
		C=C/10;
	}
	if(sum>=16||sum==6){
		t=t+1;
	}
	scanf("%d",&D);
	sum=0;
	while(D>0){
		sum=sum+D/10;
		D=D/10;
	}
	if(sum>=16||sum==6){
		t=t+1;
	}
	if(t==0){
		printf("Bao Bao is so Zhai......\n");
	}
	else if(t==1){
		printf("Oh dear!!\n");
	}
	else if(t==2){
		printf("BaoBao is good!!\n");
	}
	else if(t==3){
		printf("Bao Bao is a SupEr man///!\n");
	}
	else if(t==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
}
