#include<stdio.h>
#include<string.h>
int main()
{
	int t, n, i;
	char a[99999], b[257] = { 0 };
	scanf("%d", &t);
	while (t--)
	{
		int sum = 0;
		scanf("%d", &n);
		while (n--)
		{
			scanf("%s", a);
			int l = strlen(a);
			int num = 0;
			for (i = 0; i < l; i++)
			{
				if (b[a[i]] == 0 && a[i] != '.')
				{
					b[a[i]] = 1;
					num++;
				}
			}
			sum += num;
			for (i = 0; i <= 256; i++)
				b[i] = 0;

		}
		printf("%d\n", sum);
	}
	return 0;
}