#include"stdio.h"
int main()
{
    long long a,b,c,d,sum1=0,sum2=0,sum3=0,sum4=0,i=0;
	 
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a>0)
	{
		sum1=sum1+a%10;
		a=a/10;
	}	
		if(sum1==6||sum1>16||sum1==16)
		{
			i=i+1;
		}
		while(b>0)
	{
		sum2=sum2+b%10;
		b=b/10;
	}
	if(sum2==6||sum2>16||sum2==16)
		{
			i=i+1;
		}
		while(c>0)
	{
		sum3=sum3+c%10;
		c=c/10;
	}
	if(sum3==6||sum3>16||sum3==16)
		{
			i=i+1;
		}
		while(a>0)
	{
		sum4=sum4+a%10;
		c=c/10;
	}
	if(sum4==6||sum4>16||sum4==16)
		{
			i=i+1;
		}
	if(i==0)
	{
		printf("Bao Bao is so Zhai......");
	}	
	if(i==1)
	{
		printf("Oh dear!!");
	}	
	if(i==2)
	{
		printf("BaoBao is good!!");
	}
	if(i==3)
	{
		printf("Bao Bao is a SupEr man///!");
	}
	if(i==4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}			
	return 0;	
} 
