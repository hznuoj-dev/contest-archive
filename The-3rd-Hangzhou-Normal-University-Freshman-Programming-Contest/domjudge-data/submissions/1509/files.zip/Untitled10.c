#include <stdio.h>
#include <string.h>
char s[1000000],b[1000000];
int num(char s[]){
	int i,l,j,d=0,f,sum=0;
	l=strlen(s);
	for(i=0;i<l;i++){
		f=1;
		if(s[i]!='.'){
			for(j=0;j<d;j++){
				if(s[i]==b[j]){
					f=0;
					break;
				}
			}
			if(f){
				sum++;
				b[d]=s[i];
				d++;
			}
		}
	}
	return sum;
}
int main(){
	int t,n,sumz;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		sumz=0;
		while(n--){
			scanf("%s",s);
			sumz+=num(s);
		}
		printf("%d\n",sumz);
	}
	return 0;
}
