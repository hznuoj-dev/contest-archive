#include<stdio.h>
#include<string.h>
int main(){
	int n,m;
	char a[1000];
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
      scanf("%s",a);}
      m=strlen(a);
      printf("%d",n*m);
}
