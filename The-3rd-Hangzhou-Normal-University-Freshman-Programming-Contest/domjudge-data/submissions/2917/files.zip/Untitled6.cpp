#include <stdio.h>
int main(void){
	int A,B,C,D;
	scanf("%d %d %d %d",&A, &B, &C, &D);
	int a[4]={A,B,C,D};
	int cnt=0;
	char p1[]="Oh dear!!";
	char p2[]="BaoBao is good!!";
	char p3[]="Bao Bao is a SupEr man///!";
	char p4[]="Oh my God!!!!!!!!!!!!!!!!!!!!!";
	char p5[]="Bao Bao is so Zhai......";
	for(int i=0;i<4;i++){
		int x,sum=0,n=a[i];
		while(n){
			x=n%10;
			sum+=x;
			n/=10;
		}
		if(sum>=16||sum==6){
			cnt++;
		}
	}
	if(cnt==1)
		printf("%s\n",p1);
	else if(cnt==2)
	    printf("%s\n",p2);
	else if(cnt==3)
	    printf("%s\n",p3);
	else if(cnt==4)
	    printf("%s\n",p4);
	else if(cnt==0)
	    printf("%s\n",p5);
	return 0;

}
