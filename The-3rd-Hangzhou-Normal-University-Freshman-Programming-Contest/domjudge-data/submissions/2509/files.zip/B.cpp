#include <stdio.h>
int main()
{
	int m,n,q;
	int i,t,sum;
	scanf("%d",&t);
	while(t--)
	{
		sum=0;
		scanf("%d %d",&m,&n);
		if(m+n<10000&&n>=0)
		{
			for(i=m;i<=m+n;i++)
			{
				if((i%4==0&&i%100!=0)||(i%400==0))
				{
					sum++;
				}
			}
		}
		else if(m+n<10000&&n<0)
		{
			for(i=m+n;i<=m;i++)
			{
				if((i%4==0&&i%100!=0)||(i%400==0))
				{
					sum++;
				}
			}
		}
		else if(m+n>=10000)
		{
			q=9999*2-m-n;
			if(q>m)
			{
				for(i=m;i<=q;i++)
				{
					if((i%4==0&&i%100!=0)||(i%400==0))
				    {
					    sum++;
				    }
				}
			}
			else
			{
			    for(i=q;i<=m;i++)
				{
					if((i%4==0&&i%100!=0)||(i%400==0))
				    {
					    sum++;
				    }
				}	
			}
		}
		printf("%d\n",sum);
	}
	
	return 0;
}
