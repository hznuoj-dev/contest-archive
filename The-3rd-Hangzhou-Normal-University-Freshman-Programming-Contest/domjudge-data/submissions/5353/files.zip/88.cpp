#include<stdio.h>
int main(void){
	int t,n,m,y;
	double p;
	char a='#',b='-',c='%';
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		printf("[");
		for(int i=0;i<m;++i)
		printf("#");
		y=n-m;
		for(int i=0;i<y;++i)
		printf("-");
		printf("]");
		p=(double)m/n*100;
		if((p*n/100)>m)
		printf(" %.0lf",p-1);
		else
		printf(" %.0lf",p);
		printf("%c\n",c);
	}
}
