#include<stdio.h>
#pragma warning(disable:4996)
int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		float n, m,b;
		char a[100001] = { '\0' };
		scanf("%f%f", &n, &m);
		b = m / n*100;
		int i;
		for (i = 0; i < m; i++) {
			a[i] = '#';
		}
		for (; i < n; i++) {
			a[i] = '-';
		}
		printf("[%s]", a);
		if(b>=1)printf(" %.0f%%\n",b);
		if(b==0)printf(" %.0f%%\n", b);
		if (b >= (0.0001) && b < (0.001))printf(" %.3f%%\n", b);
		 if (b >= (0.001)&&b < (0.01))printf(" %.2f%%\n", b);
		 if(b>=(0.01)&&b<(0.1))	printf(" %.2f%%\n", b);
		if (b >= (0.1)&&b <1)	printf(" %.1f%%\n", b);
	}
	return 0;
}