#include<iostream>
int a[128];
using namespace std;
int main(){
	long long T,n,ans=0;
	cin >> T;
	char p;
	while (T--){
		ans=0;
		cin >> n;getchar();
		for (register int i=1;i<=n;++i){
			p=getchar();
			while (p!='\n'){
				if (p!='.') a[p]++;
				p=getchar();
			}
			for (register int j=0;j<=127;++j){
				if (a[j]!=0) ans++;
				a[j]=0;
			}
		}
		cout << ans << endl;
	}
    return 0;
}
