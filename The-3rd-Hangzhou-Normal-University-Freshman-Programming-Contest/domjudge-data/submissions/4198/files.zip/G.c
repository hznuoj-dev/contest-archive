#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int t,i,j,n,m,a[1001]={0},x,y,tmp;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		for(i=1;i<=1001;i++){
			a[i]=i;
		}
		for(i=0;i<m;i++){
			scanf("%d %d",&x,&y);
			if(a[x]>a[y]){
				tmp=a[y];
				a[y]=a[x];
				for(j=x;j>=y+2;j--){
					a[j]=a[j-1];
				}
				a[j]=tmp;
			}
		}
		for(i=1;i<=n-1;i++){
			printf("%d ",a[i]);	
		}
		printf("%d\n",a[n]);
	}
}
