#include<bits/stdc++.h>
using namespace std;
int num[300]={0};
int main()
{
    int m,t,i,j,q,sum,flag;
	char n;
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
	   scanf("%d\n",&m); 
	   sum=0;
	    for(q=1;q<=m;q++)
	    { 
		   while(1)
		    {
		      scanf("%c",&n); 
			  if(n=='\n') break;
			  if(n!='.' && num[n]==0)
		       {
			      num[n]++;
			      sum++;
			   }
		    }
	       
		   for(j=0;j<300;j++)
	       { 
		     if(num[j]==1) num[j]=0; 
		   }
		} 
	   printf("%d\n",sum);
	}
	return 0;
}
