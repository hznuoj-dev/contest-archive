#include <stdio.h>
#include<stdlib.h>
#include<string.h>
#include <iostream>
#include <string>
#include <algorithm>
#include <math.h>
using namespace std;
int main(){
    int n ;
    cin >> n;
    int y,x,a;
    double ans;
    while(n--){
        cin >> y >> x;
        ans = x/(y+0.0);
        ans *= 100.0;
        a = ans;
        cout << "[";
        for(int i =0;i<x;i++)
        cout << "#";
        for(int i =0;i<y-x;i++)
        cout << "-";
        cout << "] ";
        printf("%d%%\n",a);
    }
    return 0;
}
    

