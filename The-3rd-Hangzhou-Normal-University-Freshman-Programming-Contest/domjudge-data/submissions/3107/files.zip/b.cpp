#include <stdio.h>
int shuchu(int a,int b){
	printf("[");
	for(int i=1;i<=b;i++){
		printf("#");
	}
	for(int i=1;i<=a-b;i++){
		printf("-");
	}
	printf("]");
	printf(" ");
	printf("%d",b*100/a);
	printf("%%\n");
}
int main(){
	int t;
	scanf("%d",&t);
	int m[t],n[t];
	for(int i=0;i<t;i++){
		scanf("%d%d",&m[i],&n[i]);
	}
	for(int i=0;i<t;i++){
		shuchu(m[i],n[i]);
	}
}
