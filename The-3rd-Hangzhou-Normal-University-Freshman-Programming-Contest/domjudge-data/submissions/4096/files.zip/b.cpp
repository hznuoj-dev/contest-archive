#include <stdio.h>
#include <math.h>
int panduan(int x){
	int a[18],i=0,m=0;
	do{
		if(i=0){
			a[i]=x % (int)pow(10,i+1);
		}
		else{
			a[i]=(x%(int)pow(10,i+1)-x%(int)pow(10,i))/pow(10,i);
		}
		i++;
	}while(x/pow(10,i)>10);
	a[i]=x/pow(10,i);
	//for(int j=0;j<i+1;j++){
	//	printf("%d",a[j]);
	//}
	for(int j=0;j<=i;j++){
		m+=a[j];
	}
	return m;
}
int main(){
	int a,b,c,d,m=0;
	scanf("%d%d%d%d",&a,&b,&c,&d);
	//printf("%d",panduan(a));
	if(panduan(a)>=16||panduan(a)==6){
		m=m+1;
	}
	if(panduan(b)>=16||panduan(b)==6){
		m++;
	}
	if(panduan(c)>=16||panduan(c)==6){
		m++;
	}
	if(panduan(d)>=16||panduan(d)==6){
		m++;
	}
	if(m==1){
		printf("Oh dear!!");
	}
	if(m==2){
		printf("BaoBao is good!!");
	}
	if(m==3){
		printf("Bao Bao is a SupEr man///!");
	}
	if(m==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	if(m==0){
		printf("Bao Bao is so Zhai......");
	}
}
