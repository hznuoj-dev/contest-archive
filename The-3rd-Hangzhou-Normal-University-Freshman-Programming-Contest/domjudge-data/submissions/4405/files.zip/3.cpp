#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,a,b;
	double s;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%d",&a,&b);
		printf("[");
		for(int j=1;j<=b;j++){
			printf("#");
		}
		for(int j=1;j<=a-b;j++){
			printf("_");
		}
		printf("] %d",b*100/a);
		printf("%\n");
	}
} 
