#include<stdio.h>
int min(int a,int b);
int c(int j,int k);
int main()
{
	int n,m,p,q,x,y=0,z=0,g=0;
	scanf("%d %d",&n,&m);
	int a[1000],b[1000];
	for(p=1;p<=n;p++)
	{
		scanf("%d",&a[p]);
		g=g+c(n,p);
	}
	for(p=1;p<=n;p++)
	{
		scanf("%d",&b[p]);
		printf("%dttt\n",b[p]);
		if(b[p]!=1)
		{
			y=y+b[p]-1;
		}
	}	
	printf("%d\n",y+g);
	return 0;
}
int c(int j,int k)
{
	int a=1,b=1;
	k=min(k,j-k);				
	if(k==0)
	return 1;
	for(int i=j;i>=j-k+1;i--)
		a=a*i;
	for(int i=1;i<=k;i++)
		b=b*i;
	return a/b;
}
 int min(int v,int l)
 {
 	if(v>l)
 	return l;
 	else
 	return v;
 }
