#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(void){
	int i,t,n,p,b,j;
	scanf("%d",&t);
	while(t--){
		p=0;
		scanf("%d",&n);
		for(i=1;i<=n;++i){
			char s[10000001]={0};
			int a[257]={0};
			scanf("%s",s);
			for(j=0;j<strlen(s);++j){
				b=s[j];
				a[b]=1;
			}
			for(j=0;j<257;++j){
				if(a[j]==1&&j!=46)
					p=p+1;			
			}
			
		}
		
		printf("%d\n",p);
	}
	return 0;
}
