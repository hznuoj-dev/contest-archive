#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main() {
	int T,i;
	double n,m;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%lf %lf",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
		printf("#");
		for(i=1;i<=n-m;i++)
		printf("-");
		printf("] %.0lf", m/n*100);
		puts("%");
			}
		
	return 0;
}
