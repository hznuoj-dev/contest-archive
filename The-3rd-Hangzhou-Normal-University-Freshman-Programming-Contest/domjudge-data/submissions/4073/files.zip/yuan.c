#include<stdio.h>
#pragma warning(disable:4996)
int main(){
	long double T,a,b,c,i,j;
	scanf("%lf",&T);
	while(T--){
		scanf("%lf %lf",&a,&b);
		c=a-b;
		printf("[");
		for(i=1;i<=b;i++){printf("#");}
		for(j=1;j<=c;j++){printf("-");}
		printf("] ");
		printf("%.0lf%%",b/a*100);
		printf("\n");

	}
}