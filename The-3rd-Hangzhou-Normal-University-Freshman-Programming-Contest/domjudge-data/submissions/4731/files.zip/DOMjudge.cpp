#include<stdio.h>
#include<string.h>
int main()
{
int n,sum=0;
scanf("%d",&n);
char a[10000];
while(n>0)
{
    scanf("%s",a);
    sum+=strlen(a);
    n--;
}
printf("%d",sum);
return 0;
}
