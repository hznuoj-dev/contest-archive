#include<stdio.h>
#include<string.h>
#include<math.h>
char ch[100002];
int main() {
	int n,sum,a;
	sum = 0;
	scanf("%d", &n);
	while (n--) {
		scanf("%s", ch);
		a= strlen(ch);
		sum += a;
	}
	printf("%d", sum);
}