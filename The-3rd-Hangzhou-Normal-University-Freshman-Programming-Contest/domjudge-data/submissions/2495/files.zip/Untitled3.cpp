#include <stdio.h>
int main()
{
	int T;
	scanf("%d",&T);
	int xx[20000]={0};
	for(int i=-10000;i<=9999;++i)
	{
		if(i%4==0&&i%100!=0||i%400==0)
		    xx[i+10000]=1;
	}
	while(T--)
	{
		int t,a,sum=0;
		scanf("%d%d",&t,&a);
		a=t+a;
		if(a>9999)
		  a=9999-a+9999;
		if(t>a)
		{
			int temp=t;
			t=a;
			a=temp;
		}
		for(int i=t;i<=a;++i)
		{
			if(xx[i+10000])
			   sum+=1;
		}
		printf("%d\n",sum);
	}
	return 0;
 } 
