#include<stdio.h>
int main(){
	long long T,a,b,r,yu,t,x=0;
	scanf("%lld",&T);
	while(T--){
		scanf("%lld %lld",&a,&r);
		b=a+r;
		if(b>9999){
			yu=10000-b;
			b=9999-yu;
		}
		if(a>b){
			t=a;
			a=b;
			b=t;
		}
		for(;a<=b;a++){
			if((a%4==0&&a%100!=0)||a%400==0) x=x+1;
		}
		printf("%lld\n",x);
		x=0;
	} 
} 
