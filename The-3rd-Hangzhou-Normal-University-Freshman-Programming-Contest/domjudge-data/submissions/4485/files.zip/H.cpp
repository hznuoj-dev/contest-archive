#include<stdio.h>
int main(void){
	int T,m,n;
	double sum;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&n,&m);
		sum=1.0*m/n*100;
		printf("[");
		for(int i=0;i<m;i++)
		printf("#");
		for(int i=0;i<n-m;i++)
		printf("-");
		printf("]");
		printf(" %.0f%%\n",sum);
	}
	return 0;
}
