#include<stdio.h>
#include<string.h>
int main(void)
{
int t;
int n;
char a[100][1000001];
int i=0,j=0,g=0;
char z;
int sh=0;
int sum=0;
scanf("%d",&t);
while(t--)
{
	scanf("%d",&n);
	getchar();getchar(); 
	for(i=0;i<n;i++)
	{
		scanf("%s",a[i]);
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<strlen(a[i]);j++)
		{
		if(a[i][j]!='.')
		{
			z=a[i][j];
			for(g=0;g<strlen(a[i]);g++)
			{
				if(z==a[i][g])
				sh++;
			}
			if(sh==0)
			sum++;
		}
		}
	}
	printf("%d\n",sum);
	sum=0;
	i=0;j=0;g=0;sh=0;
}
return 0;
} 
