#include<stdio.h>
int main()
{
	int t,a,b,i;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&a,&b);
		printf("[");
		for(i=1;i<=b;i++)
		printf("#");
		for(i=b+1;i<=a;i++)
		printf("_");
		printf("] %d%%",(int)((b*1.0/a)*100));

	}
	return 0;
}


