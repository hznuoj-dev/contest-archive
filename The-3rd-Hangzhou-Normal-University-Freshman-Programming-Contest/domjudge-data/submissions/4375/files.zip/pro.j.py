def main():
    t=int(input())
    while t>0:
        total=0
        n=int(input())
        while n>0:
            flag=1
            rubbish=list()
            trash=list(input())
            for i in range(len(trash)):
                if trash[i]!='.':
                    for j in range(len(rubbish)):
                        if trash[i]==rubbish[j]:
                            flag=-1
                            break
                    if flag==1:
                        rubbish.append(trash[i])
                        total+=1
            n=n-1
        print(total)
        t=t-1
main()
            
