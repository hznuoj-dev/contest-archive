//#include <bits/stdc++.h>
//typedef long long  ll;
//const int MAXN=1e2+5;
#include <cstdio>
#include <algorithm>
#include <iostream>
#include <string.h>
using namespace std;
int  a,b,c,d,l,mid,sum=0,n,m,x,w,v,y,ans,x2,y2;
int main()
{
    cin>>n;
    for(int i=0; i<=n; i++)
    {
        cin>>a>>b;
        d=a-b;
        cout<<"[";
        for(int i=1; i<=b; i++)
            cout<<"#";
        for(int i=1; i<=d; i++)
            cout<<"-";
        cout<<"]";
        c=b*100/a;
        cout<<c;
        cout<<"%"<<'\n';
    }
    return 0;
}


