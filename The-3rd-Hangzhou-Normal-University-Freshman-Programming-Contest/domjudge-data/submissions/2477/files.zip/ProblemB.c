#include<stdio.h>
int main()
{
	int T, Y, A, sum, i;
	scanf("%d", &T);
	while(T--)
	{
		scanf("%d %d", &Y, &A);
		sum = Y + A;
		if(sum > 9999)
    		sum = 9999 - (sum - 9999);
    	if(A >= 0)
    	{
   			int j = 0;
			for(i = Y;i <= sum;i++)
   	        {
	    	    if((i % 4 == 0) && (i % 100 != 0) || (i % 400 == 0))
    		        j = j + 1;
   			    else
		            j = j;
    	    }
        	printf("%d\n", j);
        }
        else if(A < 0)
        {
   	        int j = 0;
			for(i = sum;i <= Y;i++)
            {
            	 if((i % 4 == 0) && (i % 100 != 0) || (i % 400 == 0))
		            j = j + 1;
		        else
		            j = j;
		    }
		    printf("%d\n", j);
        }
    }
	return 0;
}
