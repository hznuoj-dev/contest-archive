#include<stdio.h>
#include<string.h>

int main(void)
{
	int n,m,i,k,sum=0;
	char a[1000000];
	scanf("%d",&n);
	getchar();
	for(i = 0;i < n;i++)
	{
		scanf("%s",a);
		if(i == 0)
		 m = strlen(a);
	}
	k = m*n;
	if(m!= 1)
	{
		if(k%2==0)
		{
			for(;k > 0;k -= 2)
			{
				sum += k;
			}	
		}
		else
		{
			for(;k>0;k--)
			{
				sum+=k;
			}
		}
	}
	else
	{
		sum = k;
	}
	printf("%d\n",sum);
	return 0;
}
