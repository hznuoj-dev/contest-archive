#include<cstdio>
#include<cmath>
#include<cstring>
#include<cstdlib>
#include<string>
#include<algorithm>
#include<set>
#include<list>
#include<map>
#include<iostream>
using namespace std;
char s[1000001];
int main(){
	int n;
	int len,i,sum=0;
	int a[26]={0};
	scanf("%d",&n);
	while(n--){
		scanf("%s",s);
		len=strlen(s);
		sum=sum+len;
		
	}
	printf("%d\n",sum);
}

