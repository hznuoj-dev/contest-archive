#include<iostream>
#include<string.h>
using namespace std;

int main(){
	string s;
    cin >> s;
    cout << " __      _____" << endl;
    cout << "|  | ___/ ____\\____" << endl; 
    cout << "|  |/ /\\   __\\/ ___\\" << endl;
    cout << "|    <  |  | \\  \\___" << endl;
    cout << "|__|_ \\ |__|  \\___  >" << endl;
    cout << "     \\/           \\/" << endl;
	return 0;
}

