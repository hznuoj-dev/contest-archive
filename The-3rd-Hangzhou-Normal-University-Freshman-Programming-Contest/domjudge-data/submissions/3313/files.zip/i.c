#include<stdio.h>
#include<stdlib.h>
#include<string.h.>
int main()
{
	int s, i, n;
	char a[73];
	gets(a);
	n = 0;
	s = 0;
	for (i = 0; i < 72; i++)
	{
		if (0<a[i]<9)
		{
			n = n + a[i];
		}
		else if ((a[i] == ' ') && (n >= 16))
		{
			n = 0;
			s = s + 1;
		}
		else
		{
			n = 0;
		}
	}
	if (s == 0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	else if (s == 1)
	{
		printf("Oh dear!!\n");
	}
	else if (s == 2)
	{
		printf("BaoBao is good!!\n");
	}
	else if (s == 3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	else
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	return 0;
}