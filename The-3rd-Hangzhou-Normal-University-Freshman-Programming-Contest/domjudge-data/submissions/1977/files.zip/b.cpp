#include<stdio.h>
int main()
{
	int t,a,b,i,j;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&a,&b);
		j=0;
		if(b>0)
		{
			for(i=1;i<=b;++i)
			{
				a=a+1;
				if(a>9999)
					break;
				else if((a%4==0 && a%100!=0) || (a%400==0))
					++j;
			}
		}
		else
		{
			for(i=-1;i>=b;--i)
			{
				a=a-1;
				if(a>9999)
					break;
				 else if((a%4==0 && a%100!=0) || (a%400==0))
					++j;
			}
		}
		printf("%d\n",j);
	}
	return 0;
}