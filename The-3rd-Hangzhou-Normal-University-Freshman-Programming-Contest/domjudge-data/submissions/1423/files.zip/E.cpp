#include<stdio.h>
int main(void){
	char str1[100];
	scanf("%s",str1);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");
	
}
