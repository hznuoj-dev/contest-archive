#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define db double
const int maxn=1e5+10;
int n,m,t,is,cnt,ans,p[maxn];
int main(){
    ios::sync_with_stdio(false);
    cout<<fixed<<setprecision(2);
    string s;
    cin>>s;
    cout<<" __      _____"<<"\n";
    cout<<"|  | ___/ ____\\____"<<"\n";
    cout<<"|  |/ /\\   __\\/ ___\\"<<"\n";
    cout<<"|    <  |  | \\  \\___"<<"\n";
    cout<<"|__|_ \\ |__|  \\___  >"<<"\n";
    cout<<"     \\/           \\/"<<"\n";
    return 0;
    //good job!
}