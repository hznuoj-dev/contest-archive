import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner sc = new Scanner(System.in);
        while (sc.hasNext())
        {
            int n = sc.nextInt();
            for (int i = 1; i <= n; i++)
            {
                int a = sc.nextInt();
                int b = sc.nextInt();
                int c = a + b;
                int sum = 0;
                if (c > 9999)
                {
                    c = 9999 - (c - 9999);
                }
                if (a > c)
                {
                    b = c;
                    c = a;
                    a = b;
                }
                for (int j = a; j <= c; j++)
                {
                    if (run(j))
                    {
                        sum++;
                    }
                }
                System.out.println(sum);
            }
        }
    }
    
    private static boolean run(int num)//数字反转
    {
        return (num % 4 == 0 && num % 100 != 0) || num % 400 == 0;
    }
}