#include<stdio.h>
int main(void){
	int t,a,b,d,c,i,flag=1,j;
	scanf("%d",&t);
	for(j=1;j<=t;j++){
		scanf("%d %d",&a,&b);
		d=0;
		c=a+b;
		if(b>0){
			if(c<=9999){
			for(i=a;i<=c;i++){
				if((i%4==0&&i%100!=0)||i%400==0)
				d++;
			}}
			if(c>9999){
					for(i=a;i<=9999;i++){
				if((i%4==0&&i%100!=0)||i%400==0)
				d++;
			}}
		}
		else{
			for(i=c;i<=a;i++){
				if((i%4==0&&i%100!=0)||i%400==0)
				d++;
			}
		}
		printf("%d\n",d);
	}
	return 0;
} 
