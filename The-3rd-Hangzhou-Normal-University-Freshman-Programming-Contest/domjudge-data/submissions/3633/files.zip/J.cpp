#include<bits/stdc++.h>
using namespace std;
int asc[200];
int main(){
	int T;
	cin >> T;
	while(T--){
		int n;
		cin >> n;
		getchar();
		int sumn[n+1]={0};
		for(int i=1;i<=n;i++){
			memset(asc,0,sizeof(asc));
			char ch;
			while(1){
				scanf("%c",&ch);//cout << "ch=" << ch << endl;
				if(ch=='\n')break;
				if(ch!='.')asc[ch]++;
				if(asc[ch]==1){
					sumn[i]++;
				}
			}
		}
		int summ=0;
		for(int i=1;i<=n;i++)summ+=sumn[i];
		cout << summ << endl;
	}
return 0;
}
