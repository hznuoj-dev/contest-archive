#include<stdio.h>
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		long int num1,num2;
		scanf("%ld%ld",&num1,&num2);
		if(num1+num2>=10000){
			num2=9999*2-num1-num2;
		}
		else{num2=num1+num2;
		}
		if(num1>num2){
		long int a=num1;
		num1=num2;
		num2=a;
		}
		long int i,m=0; 
		for(i=num1;i<=num2;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				m=m+1;
			}
		}
		printf("%ld",m);
	}
	return 0;
}
