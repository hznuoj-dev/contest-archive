#include<stdio.h>
int main()
{
	int t, n, m, k, l, i;
	double jindu;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d%d", &n, &m);
		jindu = (m * 1.0 / n ) * 100;
		printf("[");
		k = m;
		l = n - k;
		while (m--)
		{
			printf("#");
		}
			while (l--)
			{
				printf("-");
			}
		printf("]%.0lf%%\n", jindu);
		
		
	}
}