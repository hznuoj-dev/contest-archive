#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	int t,y,a,L,R,s;
	scanf("%d",&t);
	while(t--){
		s=0;
		scanf("%d%d",&y,&a);
		if(a<0){
			L=y+a;
			R=y;
		}
		else{
			L=y;
			R=y+a;
		}
		if(R>9999){
			int x=R-(R-9999);
			if(x<L){
				R=L;
				L=x;
			}
			else
				R=x;
		}
		if(L<=0)
			L--;
		if(L%4!=0){
			L=L+4-(L%4);
		}
		for(int i=L;i<=R;i+=4)
		{
			if(i%100!=0 || i%400==0)
				s++;
		}
		printf("%d\n",s);
	}
	return 0;
}
