import java.util.Scanner;


public class Main 
{

	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int n=sc.nextInt();
			int count=0;
			for(int i=1;i<=n;i++)
			{
				int a=sc.nextInt();
				int b=sc.nextInt();
				if(a>=1&&a<=9999 && -9998<=b&& b<=19996)
				{
					int c=a+b;
					if(c>9999){c=(-1)*(c-9999)+9999;};
					for(int j=Math.min(a,c);j<=c;j++)
					{
						if(j%4==0 && j%100!=0){count++;};
						if(j%400==0){count++;};
					}
				}
				System.out.println(count);
				count=0;
				
			
			}
					
		}

	}

}
