#include <stdio.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	int Y,T,A,a,b,i,x;
	int start,end;
	scanf("%d",&T);
	while(T--){
		x=0;
		scanf("%d%d",&Y,&A);
		if (Y+A>=9999){
			a=Y;
			b=9999*2-Y-A;
			if(a>b){
				end=a;
				start=b;
			}
			else{
				start=a;
				end=b;
			}
		}
		else{
			a=Y;
			b=Y+A;
			if(a>b){
				end=a;
				start=b;
			}
			else{
				start=a;
				end=b;
		}
	    }
		for(i=start;i<=end;++i){
			if((i%4==0&&i%100!=0)||(i%400==0))
			  x++;
		}
		printf("%d\n",x);
	}
	return 0;
}
