#include<iostream>
#include<cstring>
using namespace std;

int main()
{
    int len,sum,j,i,res=0;
    char str[18];
    
    for(i=1;i<=4;i++)
    {   
        memset(str,0,18);
        sum=0;
        scanf("%s",str);
        len=strlen(str);
        for(j=0;j<len;j++)
        {
            sum=sum+(int)str[j]-48;
        }
        if(sum>=16 || sum==6)
        {
            res++;
        }


    }
    switch(res)
    {
        case 0:{
            cout << "Bao Bao is so Zhai......";
            break;
        }
        case 1:{
            cout << "Oh dear!!";
            break;
        }
        case 2:{
            cout << "BaoBao is good!!";
            break;
        }
        case 3:{
            cout << "Bao Bao is a SupEr man///!";
            break;
        }
        case 4:{
            cout <<"Oh my God!!!!!!!!!!!!!!!!!!!!!";
            break;
        }

    }
    
    return 0;
}