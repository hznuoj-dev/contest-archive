#include<bits/stdc++.h>
using namespace std;

int main(void){

    int n,times = 0;
    cin >> n;
    char ch;
    getchar();
    while(n--){
        while((ch = getchar()) != '\n' && ch >= 'a' && ch <= 'z') times++;
    }
    cout << times;

    return 0;
}