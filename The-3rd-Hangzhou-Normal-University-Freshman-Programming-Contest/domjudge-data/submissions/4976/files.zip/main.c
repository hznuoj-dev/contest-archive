#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main() {
	int T,j,g;
	int length,x,t;
	char a[100000];
	scanf("%d",&T);
	while(T--)
	{	
		int i;
		scanf("%d",&length);
		t=0;
		for(i=1;i<=length;i++)
		{
			int b[256]={0};
			scanf("%s",a);
			x=strlen(a);
			for(j=0;j<=x-1;j++)
			{		
				if(a[j]!='.')
				{
					g =a[j];
					b[g]=1;
				}
			}
			for(j=0;j<=256;j++)
			{
				if(b[j]==1)
				t+=1;
			} 
		}
		printf("%d\n",t);
	} 

	return 0;
}                                                                      
