#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996);
int main(){
	int n,len;
	char q[100010];
	scanf("%d",&n);
	getchar();
	while(n--){
		scanf("%s",&q);
	}
	len=strlen(q);
	printf("%d",n*len);
	
    return 0;
}