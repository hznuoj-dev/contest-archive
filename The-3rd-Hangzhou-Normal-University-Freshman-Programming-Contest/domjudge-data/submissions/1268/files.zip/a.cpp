#include<stdio.h>
#include<string.h>
#include<math.h>
int f(int x);
int f(int x){
	if((x%4==0&&x%100!=0)||x%400==0){
		return 1;}
		else return 0;
	
}
int main(){
	int i,a,b,c,d,m,n;
	scanf("%d",&n);
	while(n--){
		m=0;
		scanf("%d %d",&a,&b);
		if(a+b>=10000){
			c=9999-a-b+9999;
		}
		else c=a+b;
		if(a<c){
		
		for(i=a;i<=c;i++){
			if(f(i)==1) m++;
		}}
		else{
				for(i=c;i<=a;i++){
			if(f(i)==1) m++;
		}
		}
		printf("%d\n",m);
	}
} 
