#include<stdio.h>
int main(void){
	int t;
	double p,n,m;
	char c='%';
	scanf("%d",&t);
	while(t--){
		scanf("%lf%lf",&n,&m);
		p=m/n;
		
		printf("[");
		while(m--){
			printf("#");
		}
		n-=m;
		while(n--){
			printf("-");
		}
		printf("] ");
		printf("%.0f",p*100);
		printf("%c\n",c);
	}
}
