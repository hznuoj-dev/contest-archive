#include<stdio.h>
#pragma warning(disable:4996)
#include<math.h>
#include<string.h>
char s[1000001];
int main(){
	int t,n,len,i,j,sum;
	int a[300];
	for(i=0;i<=300;i++){
		a[i]=0;
	}
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d",&n);
		while(n--){
			scanf("%s",s);
			len=strlen(s);
			for(i=0;i<len-1;i++){
				j=(int)(s[i]);
				if(s[i]!='.'&&a[j]==0){
					sum++;
					a[j]=1;
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}
