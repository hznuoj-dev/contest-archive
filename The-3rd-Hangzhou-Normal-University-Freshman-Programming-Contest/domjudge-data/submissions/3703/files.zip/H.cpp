#include "stdio.h"
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m;
		scanf("%d %d",&n,&m);
		printf("[");
		for(int i=1;i<=m;i++){
			printf("#");
		}
		for(int i=1;i<=(n-m);i++){
			printf("-");
		}
		printf("] ");
		printf("%.lf%%\n",(1.0*m/n)*100);
	}
} 



