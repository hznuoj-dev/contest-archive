#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include <cstring>
#include<math.h>
#include<stdlib.h>
#include <time.h>
#define RE0 return 0;
#define print printf
using namespace std;
int main()
{
	print(" __      _____\n");
	print("|  | ___/ ____\\____\n");
	print("|  |/ /\\   __\\/ ___\\\n");
	print("|    <  |  | \\  \\___\n");
	print("|__|_ \\ |__|  \\___  >\n");
	print("     \\/           \\/\n");
	RE0
}
