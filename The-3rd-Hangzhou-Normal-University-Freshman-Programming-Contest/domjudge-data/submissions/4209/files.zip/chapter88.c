#include <stdio.h>
int main(void) {
	int t, y, a, x, i, j, n, m;
	scanf("%d", &t);
	while (t--) {
		j = 0;
		scanf("%d%d", &y, &a);
		a = a + y;
		n = a - 9999;
		m = 9999 - n;
		while (m < 1 || m>9999) {
			if (m < 1) {
				m = 9999 - m;
			}
			if (m > 9999) {
				n = m - 9999;
				m = 9999 - n;
			}
		}
		if (y == m) {
			if ((y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)) {
				printf("1\n");
			}
		}
		else if (y > m) {
			for (i = m; i <= y; i++) {
				if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) {
					j++;
				}
			}
			printf("%d\n", j);
		}
		else {
			for (i = y; i <= m; i++) {
				if ((i % 4 == 0 && i % 100 != 0) || (i % 400 == 0)) {
					j++;
				}
			}
			printf("%d\n", j);
		}
	}
	return 0;
}