#include<math.h> 
#include<stdio.h> 
#include<string.h>   
//using namespace std;
 int main()  
{	int a,b,m,n,cnt,LOUCENG,t,sum=0;char s[100005];
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{	scanf("%d %d",&a,&b);
		printf("[");
		for(int j=1;j<=b;j++)printf("#");
		for(int j=1;j<=a-b;j++)printf("-");
		printf("]");
		printf(" %d",b*100/a);
		printf("%%\n");
	}
	

	
}
