#include<stdio.h>

int main()
{
	int t,y,a,z,n;
	
	scanf("%d",&t);
	for(int i=1;i<=t;i++)
	{	int sum=0;
		scanf("%d %d",&y,&a);
		z=y+a;
		if(z>9999)
		{
			z=9999-(z-9999);
		}
		if(z<y)
		{
			n=z;
			z=y;
			y=n;
		}
		for(int i=y;i<=z;i++)
		{
			if(i%400==0||(i%4==0&&i%100!=0))
			sum++;
		}
		printf("%d\n",sum);
	}
 } 
 

