#include<stdio.h>
#include<stdlib.h>
int hh(const void*a,const void*b){
	return *(int*)a-*(int*)b;
}
int main(void){
	int n,k[100000],w=0;
	long long x=1,y=1,z=1;
	scanf("%d",&n); 
	for(int i=0;i<n;i++){
		scanf("%d",&k[i]);
	}
	qsort(k,n,sizeof(int),hh);
	for(int i=1;i<n-1;i++){
		if(k[i]==2){w++;}
		if(k[i]==k[i+1]){
			y++;
		}
		else{
			z=z*x*y;
			x=y;
			y=1;
		}
	}
	printf("%lld",z/w);
}
