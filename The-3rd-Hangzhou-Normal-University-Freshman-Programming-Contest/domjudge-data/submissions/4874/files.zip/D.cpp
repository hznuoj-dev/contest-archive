#include<bits/stdc++.h> 
using namespace std;
int main(){
	string s;
	int a,ans=1;
	scanf("%d",&a);
	for(int i=1;i<=a-1;++i) ans=ans*2;
	printf("%d",ans);
	return 0;
}
