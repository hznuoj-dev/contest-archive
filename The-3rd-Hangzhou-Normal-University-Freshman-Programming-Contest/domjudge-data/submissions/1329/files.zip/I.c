#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	long long int a,b,c,d,s=0,sum=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	while(a!=0){
		s+=a%10;
		a/=10;
	}
	if(s>=16||s==6){
		sum++;
	}
	s=0;
	while(b!=0){
		s+=b%10;
		b/=10;
	}
	if(s>=16||s==6){
		sum++;
	}
	s=0;
	while(c!=0){
		s+=c%10;
		c/=10;
	}
	if(s>=16||s==6){
		sum++;
	}
	s=0;
		while(d!=0){
		s+=d%10;
		d/=10;
	}
	if(s>=16||s==6){
		sum++;
	}
	s=0;
	if(sum==1)printf("Oh dear!!");
	if(sum==2)printf("BaoBao is good!!");
	if(sum==3)printf("Bao Bao is a SupEr man///");
	if(sum==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	if(sum==0)printf("��Bao Bao is so Zhai......");
}
