import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner s=new Scanner (System.in);
		while (s.hasNext())
		{
			int n=s.nextInt();
			for (int i=1;i<=n;i++)
			{
				int q=s.nextInt();
				int h=s.nextInt();
				int g=0;
				if (h<0)
				{
					int qq=q+h;
					for (int j=qq;j<q;j++)
					{
						if (j%4==0&&j%100!=0||j%400==0)
						{
							g++;
						}
					}
				}
				else if (q+h>10000)
				{
					int qq=q-h;
					for (int j=qq;j<h;j++)
					{
						if (j%4==0&&j%100!=0||j%400==0)
						{
							g++;
						}
					}
				}
				else
				{
					for (int j=q;j<h;j++)
					{
						if (j%4==0&&j%100!=0||j%400==0)
						{
							g++;
						}
						
					}
				}
				System.out.println(g);
			}
		}
	}
}
