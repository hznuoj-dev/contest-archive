#include<iostream>
using namespace std;
int main()
{
	int T;
	int Y,A,B;
	int n=0,i;
	cin>>T;
	while(T--)
	{
		cin>>Y>>A;
		B=Y+A;
		if(B>9999)
		{
			B=19998-B;
			if(Y>B)
			{
				int temp=Y;
				Y=B;
				B=temp;
			}
			for(i=Y;i<=B;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					n+=1;
			}
		}
		else
		{
			if(Y>B)
			{
				int temp=Y;
				Y=B;
				B=temp;
			}
			for(i=Y;i<=B;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					n+=1;
			}
		}
		cout<<n<<endl;
		n=0;
	}
	system("pause");
}