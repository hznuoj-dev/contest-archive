#include<stdio.h>
int main(void){
	char a[100];
	gets(a);
	printf(" --      -----\n|  | ---/ ----\\\----\n|  |/ /\\   --\\/ ---\\\n|    <  |  | \\\  \\\---\n|--|- \\\ |--|  \\\--- >\n     \\\/           \\\/");
     return 0;
}
