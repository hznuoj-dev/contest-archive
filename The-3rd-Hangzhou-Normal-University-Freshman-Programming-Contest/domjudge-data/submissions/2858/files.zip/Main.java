import java.math.BigInteger;
import java.util.Scanner;
public class Main
{
	public static void main(String[] args)
	{
		Scanner in=new Scanner(System.in);
		while(in.hasNext())
		{
			int t=0;
			String a1=in.next();
			String b1=in.next();
			String c1=in.next();
			String d1=in.next();
			int sum1=0;
			int sum2=0;
			int sum3=0;
			int sum4=0;
			char a[]=a1.toCharArray();
			char b[]=b1.toCharArray();
			char c[]=c1.toCharArray();
			char d[]=d1.toCharArray();
			for(int i=0;i<a.length;i++)
			{
				sum1=sum1+a[i]-'0';
			}
			for(int i=0;i<b.length;i++)
			{
				sum2=sum2+b[i]-'0';
			}
			for(int i=0;i<c.length;i++)
			{
				sum3=sum3+c[i]-'0';
			}
			for(int i=0;i<d.length;i++)
			{
				sum4=sum4+d[i]-'0';
			}
//			System.out.println(sum1);
//			System.out.println(sum2);
//			System.out.println(sum3);
//			System.out.println(sum4);
			if(sum1>=16||sum1==6)
			{
				t++;
			}
			if(sum2>=16||sum2==6)
			{
				t++;
			}
			if(sum3>=16||sum3==6)
			{
				t++;
			}
			if(sum4>=16||sum4==6)
			{
				t++;
			}
			if(t==0)
			{
				System.out.println("Bao Bao is so Zhai......");
			}
			if(t==1)
			{
				System.out.println("Oh dear!!");
			}
			if(t==2)
			{
				System.out.println("BaoBao is good!!");
			}
			if(t==3)
			{
				System.out.println("Bao Bao is a SupEr man///!");
			}
			if(t==4)
			{
				System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			}
		}
	}
}