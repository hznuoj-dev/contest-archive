#include<stdio.h>
int main()
{
   int a[4],x=0,t=0,i;
   for(i=0;i<4;i++)
   {
      scanf("%d",&a[i]);
   }
   for(i=0;i<4;i++)
   {
      while(a[i]>0)
      {
          x=x+a[i]%10;
          a[i]=a[i]/10;
      }
      if(x>=16||x==6) t=t+1;
      x=0;
    } 
    if(t==0) printf("Bao Bao is so Zhai......");
    else if(t==1) printf("Oh dear!!");
    else if(t==2) printf("BaoBao is good!!");
    else if(t==3) printf("Bao Bao is a SupEr man///!");
    else printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
    
	return 0;
}
