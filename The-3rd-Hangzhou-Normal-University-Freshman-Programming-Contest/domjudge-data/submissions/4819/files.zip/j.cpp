#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 
int t,n;
char s[1000002],a[1000002];
int main(){
	int x,len,i,ii,a1,f;
	scanf("%d",&t);
	while(t--){
		x=0,a1=0;
		scanf("%d",&n);
		getchar();
		while(n--){
			a[0]='\0',a1=0;
			gets(s);
			len=strlen(s);
			for(i=0;i<len;i++){
				f=0;
				if(s[i]!='.'){
					if(a1==0)
					a[a1]=s[i],x++,a1++;
					else{
						for(ii=0;ii<a1;ii++){
							if(a[ii]==s[i])
							f=1;
						}
						if(f==0)
						a[a1]=s[i],x++,a1++;
					}
				}
			}
		}
		printf("%d\n",x);
	}
	return 0;
}
