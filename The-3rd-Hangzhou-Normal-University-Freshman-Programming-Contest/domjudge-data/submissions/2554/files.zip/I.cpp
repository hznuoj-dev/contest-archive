#include<bits/stdc++.h>
using namespace std;
int main(){
	char a[20],b[20],c[20],d[20];
	int suma=0,sumb=0,sumc=0,sumd=0,sumn=0;
	scanf("%s",a);
	scanf("%s",b);
	scanf("%s",c);
	scanf("%s",d);
	for(int i=0;i<strlen(a);i++)suma+=a[i]-'0';
	for(int i=0;i<strlen(b);i++)sumb+=b[i]-'0';
	for(int i=0;i<strlen(c);i++)sumc+=c[i]-'0';
	for(int i=0;i<strlen(d);i++)sumd+=d[i]-'0';
	if(suma==6 || suma>=16)sumn++;
	if(sumb==6 || sumb>=16)sumn++;
	if(sumc==6 || sumc>=16)sumn++;
	if(sumd==6 || sumd>=16)sumn++;
	if(sumn==0)cout << "Bao Bao is so Zhai......" << endl;
	else if(sumn==1)cout << "Oh dear!!" << endl;
	else if(sumn==2)cout << "BaoBao is good!!" << endl;
	else if(sumn==3)cout << "Bao Bao is a SupEr man///!" << endl;
	else if(sumn==4)cout << "Oh my God!!!!!!!!!!!!!!!!!!!!!" << endl;
return 0;
}
