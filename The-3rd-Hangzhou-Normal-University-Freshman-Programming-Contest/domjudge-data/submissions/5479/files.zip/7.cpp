#include <cstdio>
#include <queue>
#include <vector>
#include <functional>
using namespace std;
vector<int>s[1005];
int in[1005];
priority_queue<int, vector<int>, greater<int> > Q;
int main(){
	int n, m,t,cnt=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		for (int i=1;i<=n;i++){
			s[i].clear();
			in[i] = 0;
		}
		
		
		while (m--){
			int A,B;
			scanf("%d %d",&A,&B);
			s[A].push_back(B);
			in[B]++;
		}
		
		
		while (!Q.empty()) Q.pop();
		for (int i=1;i<=n;i++){
			if (in[i]==0)
				Q.push(i);
		}
		
		while (Q.empty()==false){
			int p=Q.top();
			Q.pop();
			cnt++;
			printf("%d%c", p, (cnt-n)?' ':'\n');
			for (int i=0;i<s[p].size();i++){
				in[s[p][i]]--;
				if (in[s[p][i]] == 0)
					Q.push(s[p][i]);
			}
		}
	}
}
