#include<stdio.h>
int main(void) {
	int t, c, a, b, i, j;
	scanf("%d", &t);
	while (t--) {
		char list[10002] = { '0' };
		scanf("%d%d", &a, &b);
		c = (b * 100.0) / a;
		list[0] = '[';
		list[a + 1] = ']';
		for (i = 1; i <= b; ++i) {
			list[i] = '#';
		}
		for (j = b + 1; j < a + 1; ++j) {
			list[j] = '-';
		}
		printf("%s %d%%\n", list, c);
	}
	return 0;
}
