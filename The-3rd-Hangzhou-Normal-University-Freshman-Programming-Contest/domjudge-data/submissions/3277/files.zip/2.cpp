#include<stdio.h>
int isLeap(int *x);
int main()
{
int t,y,a,p,o,ans;
scanf("%d",&t);
while(t--){
	ans=0;
	scanf("%d%d",&y,&a);
	o=y;
	y+=a;
	if(y>9999){
		p=y-9999;
		a=9999-p;
		if(a>=o){
			for(int i=o;i<=a;++i){
			if(isLeap(&i)==366)
			ans+=1;
			}
		}
			else{
			for(int i=a;i<=o;++i){
			if(isLeap(&i)==366)
			ans+=1;
				}
			}
		}
		else{
			if(y>=o){
				for(int i=o;i<=y;++i){
						if(isLeap(&i)==366)
			ans+=1;
				}
			}
			else{
				for(int i=y;i<=o;++i){
						if(isLeap(&i)==366)
			ans+=1;
				}
			}
		}
		printf("%d\n",ans);
	}
}
int isLeap(int *x){
	return *x%4==0&&*x%100!=0||*x%400==0?366:365;
}
