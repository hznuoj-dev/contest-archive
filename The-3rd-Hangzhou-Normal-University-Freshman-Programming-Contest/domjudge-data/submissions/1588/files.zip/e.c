#include <stdio.h>
#include <string.h>

int main(void)
{
	char s[100];
	scanf("%s",s);
	if(strcmp(s,"kfc")==0)
	{
		printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/\n");
	}
}
