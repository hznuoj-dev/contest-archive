#include<stdio.h>
int main(void){
	int a;
    scanf("%d",&a);
    printf(" __ _____\n");
    printf("| | ___/ ____\\____\n");
    printf("| |/ /\\ __\\/ ___\\\n");
    printf("| < | | \\ \\___\n");
    printf("|__|_ \\ |__| \\___ >\n");
    printf("     \\/ \\/\n");
	return 0;
}
