#include<stdio.h>
#include<string.h>
int main(){
char a[30],b[30],c[30],d[30];
int sum=0,h,m;
scanf("%s %s %s %s",a,b,c,d);
h=strlen(a);
m=0;
for(int i=0;i<h;i++){
	m+=a[i]-'0';
}
	if(m==6||m>=16)
	sum++;
h=strlen(b);
m=0;
for(int i=0;i<h;i++){
	m+=b[i]-'0';
}
	if(m==6||m>=16)
	sum++;
h=strlen(c);
m=0;
for(int i=0;i<h;i++){
	m+=c[i]-'0';
}
	if(m==6||m>=16)
	sum++;
h=strlen(d);
m=0;
for(int i=0;i<h;i++){
	m+=d[i]-'0';
}
	if(m==6||m>=16)
	sum++;
if(sum==2)printf("BaoBao is good!!\n");
if(sum==1)printf("Oh dear!!\n");
if(sum==3)printf("Bao Bao is a SupEr man///!\n");
if(sum==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");	
if(sum==0)printf("Bao Bao is so Zhai......\n");
} 
