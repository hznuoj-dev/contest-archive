#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main()
{
    int sz[128];
    int t, n, i, b, c, d, j;
    char a[1000];
    scanf("%d", &t);
    while (t--)
    {
        c = 0;
        for (i = 0; i <= 128; i++)
        {
            sz[i] = 0;
        }
        scanf("%d", &n);
        gets_s(a);
        for (i = 1; i <= n; i++)
        {
            for (j = 0; j <= 128; j++)
            {
                sz[j] = 0;
            }
            b = 0;
            gets_s(a);
            d = strlen(a);
            for (j = 0; j < d; j++)
            {
                if (a[j] != '.')
                    sz[a[j]] = 1;
            }
            for (j = 0; j <= 128; j++)
            {
                if (sz[j] == 1)
                {
                    b++;
                }
            }
            c = c + b;
        }
        printf("%d\n", c);
    }
    return 0;
}
