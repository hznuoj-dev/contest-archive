#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
char a[1000010],b[1000010];
int main(int argc, char *argv[]) {
	int n,t,i,j,k,p,m,f;
	scanf("%d",&n);
	while(n--){
		scanf("%d",&t);
		while(t--){
			p=0;
			scanf("%s",a);
			m=strlen(a);
			for(j=0;j<m;j++){
				f=0;
			if(a[j]!='.'){
				for(i=0;i<p;i++){
					if(a[j]==b[i]){
						f=1;
						break;
					} 
				}
				if(f==0){
					k++;
					b[p]=a[j];
					p++;
				}
			}
		}
	}
	printf("%d\n",k);
	k=0;
	}
	return 0;
}
