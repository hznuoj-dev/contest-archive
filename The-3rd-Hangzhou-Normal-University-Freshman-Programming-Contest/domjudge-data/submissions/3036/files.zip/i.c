#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	int x=0,y=0,z=0,p=0,i=0;
	long long int a,b,c,d;
	    scanf("%ld %ld %ld %ld",&a,&b,&c,&d);
	    while(a){
	    	x+=a%10;
	    	a/=10;
		}
	    while(b){
	    	y+=b%10;
	    	b/=10;
		}
		while(c){
	    	z+=c%10;
	    	c/=10;
		}
		while(d){
	    	p+=d%10;
	    	d/=10;
		}
		if(x>=16||x==6) i++;
		if(y>=16||y==6) i++;
		if(z>=16||z==6) i++;
		if(p>=16||p==6) i++;
		if(i==4) printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
		else if(i==3) printf("Bao Bao is a SupEr man///!\n");
		else if(i==2) printf("BaoBao is good!!\n");
		else if(i==1) printf("Oh dear!!\n");
		else printf("Bao Bao is so Zhai......\n");
	return 0;
} 
