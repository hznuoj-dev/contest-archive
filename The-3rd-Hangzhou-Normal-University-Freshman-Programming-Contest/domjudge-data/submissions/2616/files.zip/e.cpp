#include<iostream>
using namespace std;

int main(){
	char a[5];
    cin >> a[5];
    cout << " --      -----         " << endl;
    cout << "|  | ___/ ____\\____   " << endl; 
    cout << "|  |/ /\\   __\\/ ___\\" << endl;
    cout << "|    <  |  | \\  \\___ " << endl;
    cout << "|__|_ \\ |__|  \\___  >" << endl;
    cout << "     \\/           \\/ " << endl;
	return 0;
}

