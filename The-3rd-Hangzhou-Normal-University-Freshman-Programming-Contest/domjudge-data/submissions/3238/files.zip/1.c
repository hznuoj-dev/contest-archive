#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main() {
	int T;
	scanf("%d",&T);
	while(T--) {
		int n,m;
		scanf("%d%d",&n,&m);
		int a[n+1],b[n+1],i,j,t;
		for(i=1; i<=n; i++) {
			a[i]=i;
			b[i]=i;
		}
		for(i=1; i<=m; i++) {
			int x,y;
			scanf("%d%d",&x,&y);
			if(a[x]<a[y]) {
			} else {
				t=a[x];
				a[x]=a[y];
				a[y]=t;
				t=b[a[x]];
				b[a[x]]=b[a[y]];
				b[a[y]]=t;
				for(i=a[x]; i<a[y]; i++) {
					for(j=a[x]; j<=i; j++) {
						if(b[i]>b[j]) {
							t=b[i];
							b[i]=b[j];
							b[j]=t;
						}
					}
				}
			}
		}
		for(i=1;i<=n-1;i++){
			printf("%d ",b[i]);
		}
		printf("%d\n",b[n]);
	}
}
