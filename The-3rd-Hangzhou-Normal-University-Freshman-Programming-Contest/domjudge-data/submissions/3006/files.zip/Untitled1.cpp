#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(void){
	int T,i,n,m;
    scanf("%d",&T);
    while(T--)
	{
		scanf("%d%d",&n,&m);
		printf("[");
	    for(i=1;i<=n;++i)
	    {
	    	if(i<=m)
	    	printf("#");
	    	else
	    	printf("-");
		}
		printf("]%.0f%%\n",m*1.0/n*100);
	}
	return 0;
}
