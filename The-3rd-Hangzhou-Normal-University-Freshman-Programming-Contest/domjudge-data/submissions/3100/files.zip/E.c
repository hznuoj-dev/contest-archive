#include <stdio.h>
#include <stdlib.h>
int main (){
	char hbb[5];
	scanf("%s",&hbb);
	if(hbb[0]=='k'&&hbb[1]=='f'&&hbb[2]=='c'){
		printf(" __      _____\n");
		printf("|  | ___/ ____\\____\n");
		printf("|  |/ /\\   __\\/ ___\\\n");
		printf("|    <  |  | \\  \\___\n");
		printf("|__|_ \\ |__|  \\___  >\n");
		printf("     \\/           \\/     \n");
	}
	return 0;
}
