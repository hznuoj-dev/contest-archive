package ft;
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner a = new Scanner(System.in);
		while (a.hasNext())
		{			
			int s=0;
			int x=a.nextInt();
			for(int i=0;i<x;i++)
			{
				s=0;
				int y=a.nextInt();
				String cs[]=new String[y];
				for(int j=0;j<y;j++)
				{
                    cs[j]=a.next();
				}
				
				for(int j=0;j<cs.length;j++)
				{
					
					String h[]=new String[cs[j].length()];
					for(int k=0;k<cs[j].length();k++)
					{
						int l=1;
						String r=cs[j].substring(k, k+1);
						if(r.equals("."))
						{
							h[k]=cs[j].substring(k, k+1);
						}
						else
						{
							for(int o=0;o<h.length;o++)
							{
								if(r.equals(h[o]))
								{
									l=0;
								}
							}
							if(l!=0)
							{
								h[k]=cs[j].substring(k, k+1);
								s=s+1;
							}
						}
					}	
				}
				System.out.println(s);
			}
		}
	}
}
