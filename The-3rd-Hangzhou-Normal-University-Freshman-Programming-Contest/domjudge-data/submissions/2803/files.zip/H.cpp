#include<stdio.h>
#include<math.h>
int main()
{
	int T,i;
	scanf("%d",&T);
	float a,b;
	int re,st;
	for(i=0;i<T;i++){
		scanf("%f%f",&a,&b);
		re=b/a*100;
		re=floor(re+0.5);
		printf("[");
		for(int j=0;j<re/10;j++)
		    printf("#");
		st=a-b;
		while(st--){
		    printf("-");
	    }
		printf("] %d%%\n",re);
	}
	return 0;
}
