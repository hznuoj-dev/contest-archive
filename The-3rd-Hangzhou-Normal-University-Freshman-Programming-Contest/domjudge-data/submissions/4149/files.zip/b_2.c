#include <stdio.h>
int main() {
	int t;
	scanf("%d", &t);
	int a, b, c;//a�ǵ�һ�����
	int a_2;
	int j;
	while(t--) {
		scanf("%d %d", &a, &b);
		int sum = 0;
		int cont = 0;
		c=a+b;
		if(c>=9999){
			c-=(c-9999);
		}
		if(a>c){
		int	tmp=a;
			a=c;
			c=tmp;
		}
		int ans=0;
		for(int i=a;i<=c;i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				ans++;
			}
		}
		
		
		
			printf("%d\n", ans);
	}
	return 0;
}

