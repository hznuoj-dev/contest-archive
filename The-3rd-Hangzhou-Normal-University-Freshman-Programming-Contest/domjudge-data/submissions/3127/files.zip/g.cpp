#include<bits/stdc++.h>
using namespace std;

int main(void){
	int e;
	cin>>e;
	while(e--){
		map<int,int>mm;
		int n,m;
		cin>>n>>m;
		int a,b;
		for(int k=1;k<n;k++){
			mm[k]=1;
		}
		for(int k=0;k<m;k++){
			cin>>a>>b;
			mm[a]+=mm[b];
		}
		auto c=mm.end();
		c--;
		for(;c!=mm.begin();c--)
			cout<<c->first<<" ";
		cout<<mm.begin()->first<<endl;
	}
} 
