#include<stdio.h>
#include<string.h>
int main()
{
	int t,n;
	char s[100000];
	scanf("%d",&t);
	while(t--){
		int i,j,k;
		int sum=0;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%s",s);
			for(j=0;j<strlen(s);j++){
				if(s[j]!='.'){
					for(k=0;k<j;k++){
						if(s[j]==s[k]){
							sum--;
							break;
						}
					}sum++;
				}
			}
		}printf("%d\n",sum);
	}
	return 0;
}