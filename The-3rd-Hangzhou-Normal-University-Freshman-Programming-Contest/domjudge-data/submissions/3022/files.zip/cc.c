#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void) {
	int T;
	scanf("%d", &T);
	while (T--) {
		int n, m;
		scanf("%d %d", &n, &m);
		int i;
		printf("[");
		for (i = 0; i < n; i++) {
			if (i < m) {
				printf("#");
			}
			else {
				printf("-");
			}
		}
		int c = 100 * m / n;
		printf("] %d%%\n", c);
	}
}