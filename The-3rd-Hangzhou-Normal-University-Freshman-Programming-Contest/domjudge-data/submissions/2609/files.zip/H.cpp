#include<iostream>
using namespace std;
int main()
{
	int T;
	int a,b;
	cin>>T;
	while(T--)
	{
		cin>>a>>b;
		cout<<"[";
		for(int i=1;i<=b;i++)
		{
			cout<<"#";
		}
		for(int j=b+1;j<=a;j++)
		{
			cout<<"-";
		}
		cout<<"]";
		int c=b*100/a;
		cout<<c<<"%"<<endl;
	}
	
}