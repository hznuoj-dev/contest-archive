#include <stdio.h>
int main(){
	int t,x,y;
	scanf("%d",&t);
	while (t--){
		scanf("%d %d",&y,&x);
		double s=1.0*x/y;
		printf("[");
		while (x--){
			printf("#");
		}
		y-=x;
		while (y--){
			printf("-");
		}
		printf("]%.0lf%%\n",s*100);
	}
}
