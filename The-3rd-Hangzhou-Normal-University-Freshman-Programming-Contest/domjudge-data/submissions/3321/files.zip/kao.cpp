#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int qu(long long x)
{
	int i,j=0;
	for(i=1;;i++)
	{
		j+=x%10;
		x=x/10;
		if(x==0)
		break;
	}
	return j;
}
int main()
{
	long long i,j,w[99],g=0;
	scanf("%lld%lld%lld%lld",&w[1],&w[2],&w[3],&w[4]);
	for(i=1;i<=4;i++)
	{
		if(qu(w[i])>=16||qu(w[i])==6)
		g+=1;
	}
	switch(g)
	{
	case 0:printf("Bao Bao is so Zhai......");break;
	case 1:printf("Oh dear!!");break;
	case 2:printf("BaoBao is good!!");break;
	case 3:printf("Bao Bao is a SupEr man//////!");break;
	case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
	}
	return 0;
}
