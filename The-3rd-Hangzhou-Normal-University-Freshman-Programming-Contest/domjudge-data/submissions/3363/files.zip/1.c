#include<stdio.h>
int main() {
	int a, b, c, d;
	int m1, m2, m3, m4;
	m1 = 0; m2 = 0; m3 = 0; m4 = 0;
	int sum = 0;
	scanf("%d%d%d%d", &a, &b, &c, &d);
	while (a > 0) {
		m1 += a % 10;
		a = a / 10;
	}
	while (b > 0) {
		m2 += b % 10;
		b = b / 10;
	}
	while (c > 0) {
		m3 += c % 10;
		c = c / 10;
	}
	while (d > 0) {
		m4 += d % 10;
		d = d / 10;
	}
	if ((m1 >= 16) || (m1 == 6)) {
		sum += 1;
	}
	if ((m2 >= 16) || (m2 == 6)) {
		sum += 1;
	}
	if ((m3 >= 16) || (m3 == 6)) {
		sum += 1;
	}
	if ((m4 >= 16) || (m4 == 6)) {
		sum += 1;
	}
	if (sum == 0) {
		printf("Bao Bao is so Zhai......");
	}
	if (sum == 1) {
		printf("Oh dear!!");
	}
	if (sum == 2) {
		printf("BaoBao is good!!");
	}
	if (sum == 3) {
		printf("Bao Bao is a SupEr man///!");
	}
	if (sum == 4) {
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
	return 0;
}