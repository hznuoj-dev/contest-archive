#include<stdio.h>
#pragma warning (disable:4996)
int judge(int n);
int main(){
	int t,a,b,c,temp,i,sum=0;
	scanf("%d",&t);
	while(t--){
	    scanf("%d %d",&a,&b);
		if(a+b>9999){
		    b=a+b-9999;
			b=9999-b;
		}
		c=b;
		if(c<=a){
		   temp=c;c=a;a=temp;
		}
		sum=0;
		for(i=a;i<=c;i++){
			if(judge(i)){
			   sum++;
			}
		}
		printf("%d\n",sum);
	}
    return 0;
}
int judge(int n){
	if(n%4==0&&n%100!=0||n%400==0){
	    return 1;
	}
	else return 0;
}