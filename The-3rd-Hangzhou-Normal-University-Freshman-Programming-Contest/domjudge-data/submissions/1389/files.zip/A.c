#include<stdio.h>

int leap(int a,int b);

int main()
{
	int t;
	int y,a,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&y,&a);
		x=y+a;
		if(x>=10000){
			x=9999-(y+a-9999);
		}
		printf("%d\n",leap(y,x));
	}
	return 0;
}
int leap(int a,int b){
	int temp;
	int i;
	int sum=0;
	if(a>b){
		temp=b;
		b=a;
		a=temp;
	}
	for(i=a;i<=b;i++){
		if((i%4==0&&i%100!=0)||i%400==0)
			sum++;
	}return sum;
}