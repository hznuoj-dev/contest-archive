#include<stdio.h>
int main(){
	int t, a, b;
	scanf("%d", &t);
	for(int i=0;i<t;++i){
		scanf("%d%d", &a, &b);
		printf("[");
		for(int j=0;j<a;++j){
			if(j<b){
				printf("#");
			}
			else
				printf("-");
		}
		printf("] %d", (b*100)/a);
		printf("%%\n");
	}
	return 0;
}
