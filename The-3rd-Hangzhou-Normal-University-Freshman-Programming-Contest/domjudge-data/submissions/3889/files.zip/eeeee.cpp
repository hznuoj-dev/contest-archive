#include<iostream>
#include<algorithm>
int a[102][100002],b[102],ans1[100002],ans2[100002];
using namespace std;
int main(){
	int n,m,k,s=0;
	cin >> n >> m;
	for (int i=1;i<=n;++i){
		cin >> a[i][1];
	}
	for (register int i=1;i<=n;++i){
		cin >> b[i];
		for(register int j=0;j<=b[i];++j) {
			a[i][j]=j*a[i][1];
			if (a[i][j]>m) {
				b[i]=j-1;
				break;
			}
		}
	}
	for (register int i=1;i<=n;++i){
		k=0;
		for (register int j=1;j<=m;++j){
			if (ans1[j]==1) {//������ֵ���� 
				k++;
				ans2[k]=j;
			}
		}
		for (register int p=0;p<=b[i];++p){
			for (register int j=0;j<=k;++j){
				if (a[i][p]+ans2[j]<=m) {
					ans1[a[i][p]+ans2[j]]=1;
				}
				else break;
			}
		}
	}
	for (int i=1;i<=m;++i){
		if (ans1[i]) s++;
	}
	cout << s << endl;
    return 0;
}
