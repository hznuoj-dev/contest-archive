#include<bits/stdc++.h>
using namespace std;

int n;
int a[1000001], maxn;
long long ans;

int main ()
{
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		int tmp;
		scanf ("%d", &tmp);
		a[tmp]++;
		if (tmp > maxn) maxn = tmp;
	}
	ans = 1;
	for (int i = 1; i <= maxn; i++)
		ans = (ans + (a[i] * a[i-1] - 1)) %  998244353;
	printf ("%d", ans);
	
	
	
	return 0;
	
}
