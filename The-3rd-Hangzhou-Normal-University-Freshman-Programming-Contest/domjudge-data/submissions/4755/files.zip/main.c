#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */
int judge(char ch)
{	
	int n=0;
	if(ch=='1')
	n+=1;
	if(ch=='2')
	n+=2;
	if(ch=='3')
	n+=3;
	if(ch=='4')
	n+=4;
	if(ch=='5')
	n+=5;
	if(ch=='6')
	n+=6;
	if(ch=='7')
	n+=7;
	if(ch=='8')
	n+=8;
	if(ch=='9')
	n+=9;
	if(ch=='0')
	n+=0;
	return n;
}
int main() {
	int t,num,i,x,j;
	char a[20],b[20],c[20],d[20];
	scanf("%s",a);
	scanf("%s",b);
	scanf("%s",c);
	scanf("%s",d);
	t=0;
	for(i=1;i<=4;i++)
	{	
		if(i==1)
		{
		num=0;
		x=strlen(a);
		for(j=0;j<=x-1;j++)
		num+=judge(a[j]);
		if(num>=16||num==6)
		t=t+1; 
		}
		if(i==2)
		{
		num=0;
		x=strlen(b);
		for(j=0;j<=x-1;j++)
		num+=judge(b[j]);
		if(num>=16||num==6)
		t=t+1; 
		}
		if(i==3)
		{
		num=0;
		x=strlen(c);
		for(j=0;j<=x-1;j++)
		num+=judge(c[j]);
		if(num>=16||num==6)
		t=t+1; 
		}
		if(i==4)
		{
		num=0;
		x=strlen(d);
		for(j=0;j<=x-1;j++)
		num+=judge(d[j]);
		if(num>=16||num==6)
		t=t+1; 
		}
	}
	if(t==0)
	printf("Bao Bao is so Zhai......");
	if(t==1)
	printf("Oh dear!!");
	if(t==2)
	printf("BaoBao is good!!");
	if(t==3)
	printf("Bao Bao is a SupEr man///!");
	if(t==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	
	
	
	return 0;
}                                                                      
