#include<stdio.h>
int main()
{
	int a,b,c,d,A,B,C,D;
	int sum=0,n=0;
	scanf("%d",&a);
	A=a;B=b;C=c;D=d;
	while(a>0){
		A=a%10;
		sum+=A;
		a=a/10;
	}
	if(sum>16||sum==6){
		n++;
	}
	sum=0;
	while(b>0){
		B=b%10;
		sum+=B;
		b=b/10;
	}
	if(sum>16||sum==6){
		n++;
	}
	sum=0;
	while(c>0){
		A=c%10;
		sum+=C;
		c=c/10;
	}
	if(sum>16||sum==6){
		n++;
	}
	sum=0;
	while(d>0){
		A=d%10;
		sum+=D;
		d=d/10;
	}
	if(sum>16||sum==6){
		n++;
	}
	if(n==0){
		printf("Bao Bao is so Zhai......\n");
	}else if(n==1){
		printf("Oh dear!!\n");
	}else if(n==2){
		printf("BaoBao is good!!\n");
	} else if(n==3){
		printf("Bao Bao is a SupEr man///!\n");
	}else if(n==4){
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	 return 0;
 } 
