#include <iostream>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char** argv) {
	int i,m,n;
	scanf("%d",&i);
	for(int j=0;j<i;j++)
	{
		scanf("%d %d",&m,&n);
		double a;
		a=m*1.0/n*100;
		printf("[");
		for(int w=0;w<m;w++)
		{
			printf("#");
		}
		for(int w=0;w<n-m;w++)
		{
			printf("-");
		}
		printf("]");
		printf(" %.2f",a);
		printf("%\n");
	 } 
	return 0;
}
