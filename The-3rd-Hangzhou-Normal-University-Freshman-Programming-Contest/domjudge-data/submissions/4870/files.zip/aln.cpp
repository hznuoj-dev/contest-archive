#include <stdio.h>
#include <string.h>
int main()
{
	char A[10],B[10],C[10],D[10];
	char str[10]={'\0'};
	int flag=0,n,sum,count,i;
	while(scanf("%s %s %s %s",A,B,C,D)!=EOF);
	{
	for(i=0;i<strlen(str);i++)
      {
        count++;
        sum += i%10;
        i/= 10;
      }
      if(sum>=16||sum==6)
      flag=flag+1;
	}
	if(flag==1)
	printf("Oh dear!!");
	if(flag==2)
	printf("BaoBao is good!!");
	if(flag==3)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	if(flag==4)
	printf("Bao Bao is so Zhai......");
	
 } 
