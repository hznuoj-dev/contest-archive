#include <bits/stdc++.h>

using namespace std;

string s;

int calc() {
    int c=0;
    map<char,bool> mp;
    for(int i=0;i<s.length();i++){
        if(s[i]!='.') {
            if(!mp[s[i]]){
                c++;mp[s[i]]=1;
            }
        }
    }
    return c;
}

int main() {
    int T, n, ans;

    cin >> T;
    while (T--) {
        cin >> n;
        getline(cin, s);
        ans = 0;
        for (int i = 1; i <= n; i++) {
            getline(cin, s);
            ans+=calc();
        }
        cout<<ans<<endl;
    }
    return 0;
}
