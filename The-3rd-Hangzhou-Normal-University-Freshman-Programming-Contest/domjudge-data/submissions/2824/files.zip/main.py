t = int(input())

for i in range(0, t):
    floors = int(input())
    count = 0
    amap = set()
    for j in range(0, floors):
        string = input()
        for ch in string:
            if ch != '.':
                amap.add(ch)
        count = count + len(amap)
        amap.clear()
    print(count)

