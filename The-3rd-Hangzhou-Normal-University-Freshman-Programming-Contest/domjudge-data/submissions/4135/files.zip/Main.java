import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner((System.in));
        while (in.hasNext())
        {
            int n = in.nextInt();
            for (int i = 1; i <= n; i++)
            {
                double a = in.nextInt();
                double b = in.nextInt();
                System.out.print("[");
                
                for (int j = 1; j <= a; j++)
                {
                    if (i <= b)
                        System.out.print("#");
                    else
                        System.out.print("-");
                }
                System.out.print("]");
                double c = b / a * 100;
                int d = (int) c;
                System.out.println(" " + d + "%");
            }
        }
    }
}