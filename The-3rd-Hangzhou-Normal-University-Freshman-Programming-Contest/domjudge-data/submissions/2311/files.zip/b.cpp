#include<bits/stdc++.h>
using namespace std;
bool rn(int n){
	if(n%400==0||n%4==0&&n%100!=0) return true;
	return false;
}

int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int a,b,c,cnt=0;
		scanf("%d %d",&a,&b);
		b+=a;
		if(b>9999){
			c=b-9999;
			b=9999-c;
		}
		if(a>b) swap(a,b);
		if(a%4!=0) a=a+4-a%4;
		if(b%4!=0) b-=b%4;
		if(!rn(a)) a+=4;
		if(!rn(b)) b-=4;
		if(a>b) cnt=0;
		else if(a==b){
			if(rn(a)) cnt=1;
			
		}else{
			cnt=(b-a)/4+1;//��ȥ100������ 
			c=b/100-a/100;
			a/=400;
			b/=400;
			c=c-b+a;
			cnt-=c;
		}
		printf("%d\n",cnt);
	}
}
