#include<stdio.h>
int main(void){
    int y,a,t,x=0,m,i;
    scanf("%d",&t);
    while(t--){
    	scanf("%d %d",&y,&a);
    	m=y+a;
    	if(m>=10000)
    	   m=9999-(m-9999);
    	if(y<=m){
     	   for(i=y;i<=m;++i){
    		   if((i%4==0&&i%100!=0)||(i%400==0)){
    			   x++;
			   }	
		    }
	    }
	    if(y>m){
	    	for(i=m;i<=y;++i){
	    		if((i%4==0&&i%100!=0)||(i%400==0)){
	    			x++;
				}
			}
		}
		printf("%d\n",x);
		x=0;
	}
	return 0;
}
