#include<stdio.h>
int main() {
	int t, m, n, a, b, sum[1001], i, j, flag1[1001],flag2[1001];
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &m, &n);
		for (i = 1; i <= m; i++) {
			sum[i] = 0;
		}
		while (n--) {
			scanf("%d %d", &a, &b);
			if (flag1[a]==1&&flag2[b] == 1) {
				flag1[a] == 1 && flag2[b] == 1;
			}
			else {
				sum[a] += 1;
				flag1[a] = 1;
				flag2[b] = 1;
			}
		}
		for (i = m; i >= 0; i--) {
			for (j = 1; j <= m; j++) {
				if (sum[j] == i) {
					printf("%d ", j);
				}
			}
		}
	}
}