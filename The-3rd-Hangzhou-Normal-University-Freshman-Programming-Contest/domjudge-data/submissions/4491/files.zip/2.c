#include<stdio.h>
#include<string.h>
int main(void){
	int n,m;
	char a[1000000];
	scanf("%d ",&n);
	int w=n;
	while(n--){
		scanf("%s",a);
	}
	m=strlen(a);
	printf("%d",m*w);
}
