#include<stdio.h>
#include<string.h>
struct t{
	int problem[15]={0},timestamp[100000];
	int total=0;
};
int main(){
	char a[3];
	int n,T,m,p,i,j,k;
	struct t team[510];
	scanf("%d%d%d%d",&n,&T,&m,&p);
	while(m--){
		scanf("%d%d%d",&i,&j,&k);
        team[i].total++;
        scanf("%s",&a);
        if(a=="AC"){
        	team[i].problem[j]=1;
        	
		}
	}
} 
