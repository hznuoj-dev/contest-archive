#include <stdio.h>
#include <stdlib.h>
#include <string.h>


int main() {
	int T;
	long int n,m;
	long int i;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%ld %ld",&n,&m);
		printf("[");
		for(i=1;i<=m;i++)
		{
			printf("#");
		}
		for(i=1;i<=n-m;i++)
		{
			printf("-");
		}
		printf("] %.lf%c\n" ,(double)m/n*100.0,'%');
	} 
	return 0;
}                                                                      
