#include <bits/stdc++.h>
using namespace std;
int main()
{   int t,sum=0;
    string x;
    cin>>t;
    while(t--)
    {
        cin>>x;
        sum+=x.length();
    }
    cout<<sum;
    return 0;
}
