#include<stdio.h>
int main(){
	int t;
	int y,a;
	int count=0;
	int jia,i;
	scanf("%d",&t);
	while(t--){
		count =0;
		scanf("%d %d",&y,&a);
		jia=y+a;
		//printf("%d\n",jia);
		if(jia>9999){
			//printf("%d\n",y);
			for(int k=y;k<=9998;k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
		else{
			if(jia<=y){
				//printf("%d %d\n",jia,y);
				for( int k=jia;k<=y;k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
		else{
		
			for(int k=y;k<=jia;k++){
				if((k%4==0&&k%100!=0)||(k%400==0)){
					count++;
				}
			}
		}
	}
	printf("%d\n",count);
	}
	return 0;
} 
