a = int(input())
i = 0
list1 = []
while i <= a:
    i += 1
    s = '['
    b = input()
    c, e = b.split()
    print(c, e)
    s += int(e) * '#'
    s += (int(c) - int(e)) * '-'
    s += ']'
    ss = float(e) / float(c)*100
    print(s, ('%.f' % ss),'%')