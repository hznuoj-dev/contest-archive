#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 

char  c[100003];

int main(){
	int t,a,b,i;
	double n;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		for(i=0;i<b;i++)
		c[i]='#';
		for(i;i<a;i++)
		c[i]='-';
		c[i]='\0';
		n=b*1.0/a*100;
		printf("[%s] %.0f%%\n",c,n);
		
	}
} 


