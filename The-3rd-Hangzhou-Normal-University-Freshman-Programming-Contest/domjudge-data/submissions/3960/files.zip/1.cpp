#include<stdio.h>
int main()
{
	int i,j,t,y,a,z,x;
	scanf("%d",&t);
	for(i=0;i<t;++t)
	{
		scanf("%d %d",&y,&a);
		if(y+a>9999)
		{
			z=9999-(y+a-9999);
		}
		else
		{
			z=y+a;
		}
		if(y>=z)
		{
			x=(y-z+1)/4-(y-z+1)/100+(y-z+1)/400;
		}
		else
		{
			x=(z-y+1)/4-(z-y+1)/100+(z-y+1)/400;
		}
		printf("%d\n",x);
	}
}
