#include<stdio.h>
int main() {
	int T, Y, A;
	int B, temp;
	int sum, i;
	scanf("%d", &T);
	while (T--) {
		sum = 0;
		scanf("%d%d", &Y, &A);
		B = Y + A;
		if (B > 9999)B = 9999-(B - 9999);
		if (Y > B) {
			temp = Y;
			Y = B;
			B = temp;
		}
		for (i = Y;Y <= B;Y++) {
			if ((Y % 4 == 0 && Y % 100 != 0) || Y % 400 == 0) {
				sum++;
			}
		}
		printf("%d\n", sum);
	}
}