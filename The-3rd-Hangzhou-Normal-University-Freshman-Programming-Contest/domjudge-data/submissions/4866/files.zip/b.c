#include<stdio.h>
int main()
{
    int t,n,a,b,i,linka=0,linkb=0;
    long m;
    scanf("%d\n",&t);
    while(t--)
    {
        int link[1001];
        scanf("%d %ld\n",&n,&m);
        for(i=1;i<=n;i++){link[i]=i;}
        while(m--)
        {
            scanf("%d %d\n",&a,&b);
            for(i=1;i<=n;i++)
            {
                if(link[i]==a)linka=i;
                if(link[i]==b)linkb=i;
            }
            if(linkb<linka)
            {
                t=link[linka];
                for(i=linka;i>=linkb+1;i--)
                {
                    link[i]=link[i-1];
                }
                link[linkb]=t;
            }
        }
        printf("%d",link[1]);
        for(i=2;i<=n;i++){printf(" %d",link[i]);}
        printf("\n");
    }
}
