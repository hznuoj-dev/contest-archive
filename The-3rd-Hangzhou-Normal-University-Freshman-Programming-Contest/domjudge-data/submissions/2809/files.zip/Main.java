import java.util.*;
public class Main//b
{
    public static void main(String[] args) 
    {
    	Scanner s=new Scanner (System.in);
		while (s.hasNext())
		{
			String a=s.next();
			if (a.equals("kfc"))
			{
				System.out.println("__ _____\r\n"
						+ "| | ___/ ____\\____\r\n"
						+ "| |/ /\\ __\\/ ___\\\r\n"
						+ "| < | | \\ \\___\r\n"
						+ "|__|_ \\ |__| \\___ >\r\n"
						+ "\\/ \\/");
			}
		}
      
    }
}