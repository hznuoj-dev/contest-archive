#include<stdio.h>
int main()
{
	int t, n, m, i, j, win, lose, k, xuanshou[99];
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d%d", &n, &m);
		for (i = 1;i <= n;++i)
		{
			xuanshou[i] = i-1;
		}
		while (m--)
		{
			scanf("%d%d", &win, &lose);
			if (xuanshou[win] > xuanshou[lose])
			{
				k = xuanshou[win];
				xuanshou[win] = xuanshou[lose];
				xuanshou[lose] = k;
			}

		}
		for (i = 0;i < n;++i)
		{
			for (j = 1;j <= n;++j)
			{
				if (xuanshou[j] == i)
				{
					printf("%d", j);
				}
			}
			printf(" ");
		}
	}
}