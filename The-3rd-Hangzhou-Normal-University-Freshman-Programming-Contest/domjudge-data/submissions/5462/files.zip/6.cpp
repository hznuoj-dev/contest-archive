#include<stdio.h>
#include<string.h>
int count[1000000],r[1000000];
int main(){
	int t,m,n;int i,j;int a,b,temp;
	scanf("%d",&t);
while(t--){
	
for(i=0;i<1000000;i++){
	count[i]=0;r[i]=0;
}

int c[1000];
	scanf("%d %d",&n,&m);
	for(i=0;i<m;i++){
		scanf("%d %d",&a,&b);
		count[a]++;count[b]++;
		if(r[b]!=0){
		r[a]=r[b]+1;
		for(j=0;j<1000000;j++){
			if(r[j]>r[a]&&count[a]>1)r[j]++;
		}
		}
		else if(r[b]==0) {r[a]++;
				for(j=0;j<1000000;j++){
			if(r[j]>r[a]&&count[a]>1)r[j]++;
		}
		}
	}
	int k=0;
	for(i=0;i<n;i++){
	for(j=k;j<=1000000;j++){
		if(count[j]>0){
			c[i]=j;
			count[j]=0;
			k=j+1;
			break;
		}
	}
	}
	
	for(i=1;i<n;i++){
	for(j=0;j<n-1;j++){
		if(r[c[j]]<r[c[j+1]]||(r[c[j]]==r[c[j+1]]&&c[j]>c[j+1])){
		temp=c[j];c[j]=c[j+1];c[j+1]=temp;	
		}
	}
	}
	for(i=0;i<n;i++){
		printf("%d ",c[i]);
	}
	printf("\n");
}
	
	return 0;
}

