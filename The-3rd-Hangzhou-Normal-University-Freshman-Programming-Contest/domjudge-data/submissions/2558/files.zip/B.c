#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,a,b,c,sum,i,d,e;
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d %d",&a,&b);
		if(a+b>=10000){
			c=a+b-9999;
			d=9999-c;
		}
		else if(a+b<=9999){
			d=a+b;
		}
		if(d<a){
			e=a;
			a=d;
			d=e;
		}
		for(i=a;i<=d;i++){
			if(i%4==0&&i%100!=0){
				sum=sum+1;
			}
			else if(i%400==0){
				sum=sum+1;
			}
		}
		printf("%d\n",sum);
	} 
	return 0;
}
