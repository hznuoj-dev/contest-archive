#include<stdio.h>
int main(){
	int t,b;
	long y;
	long long a;
	int count;
	if(scanf("%d",&t)){
		while(t--){
			count =0;
			if(scanf("%ld %lld",&y,&a)){
				if(y+a>9999){
					b=y+a-9999;
					if(y>=9999-b)
						for(int k=9999-b;k<=y;k++){
							if((k%4==0&&k%100!=0)||(k%400==0)){
					            count++;
						}
					}
				}
					else{
							for(int k=y;k<=9999-b;k++){
							if((k%4==0&&k%100!=0)||(k%400==0)){
					            count++;
						}
					}
					}
			}
				else{
					if(y+a>=y){
						for(int k=y;k<=y+a;k++){
							if((k%4==0&&k%100!=0)||(k%400==0)){
					            count++;
						}
					}
				}
				else{
					for(int k=y+a;k<=y;k++){
							if((k%4==0&&k%100!=0)||(k%400==0)){
					            count++;
						}
					}
				}	
				}
				printf("%d\n",count);
			}
			
		}
	return 0;
} 
