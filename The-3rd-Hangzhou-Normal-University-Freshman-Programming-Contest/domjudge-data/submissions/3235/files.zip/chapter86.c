#include <stdio.h>
int main(void) {
	double t, n, m,s,i,j;
	scanf("%lf", &t);
	while(t--){
		scanf("%lf%lf",&n,&m);
		printf("[");
		for (i = 0; i < m; i++) {
			printf("#");
		}
		for (i = m; i < n; i++) {
			printf("-");
		}
		printf("] ");
		if (n / m == 3) {
			s = 33;
		}
		else {
			s = m / n * 100;
		}
		printf("%.0lf%%\n", s);
	}
}