#include<bits/stdc++.h> 
using namespace std;
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		float z,t;
		scanf("%d%d",&z,&t);
		printf("[");
		for(int tt=1;tt<=t;++tt) printf("#");
		for(int zt=1;zt<=n-t;++zt) printf("-");
		printf("} ");
		float f=t/z*100;
		int d=f;
		printf("%d",d);
		printf("%\n");
	}
	return 0;
}
