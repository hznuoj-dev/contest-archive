#include<math.h>
#define PI 3.1415926
#include <string.h>
#include<stdio.h>
#include<ctype.h>




int main()
{
	int T;
	scanf("%d",&T);
	while(T--){
		int a,b,c,d,e;
		scanf("%d %d",&a,&b);
		c=a;
		d=b;
		e=a-b;
		printf("[");
		while(b--){
			printf("#");
		}
		while(e--){
			printf("-");
		}
		printf("] ");
		printf("%d%%\n",d*100/c);
	}
	
	
return 0;
}
