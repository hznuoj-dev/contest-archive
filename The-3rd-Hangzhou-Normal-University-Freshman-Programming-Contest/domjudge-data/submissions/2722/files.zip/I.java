import java.util.Scanner;

public class I {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        long[] array = new long[4];
        for (int i = 0; i < 4; i++) {
            array[i] = in.nextLong();
        }
        switch (isJi(array)) {
            case 1:
                System.out.println("Oh dear!!");
                break;
            case 2:
                System.out.println("BaoBao is good!!");
                break;
            case 3:
                System.out.println("Bao Bao is a SupEr man///!");
                break;
            case 4:
                System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
                break;
            default:
                System.out.println("Bao Bao is so Zhai......");
                break;
        }
    }

    public static int isJi(long[] array) {
        int cont = 0;
        for (int i = 0; i < 4; i++) {
            int sum = 0;
            while (array[i] > 0) {
                sum += (array[i] % 10);
                array[i] /= 10;
            }
            if (sum >= 16 || sum == 6) {
                cont++;
            }
        }
        return cont;
    }
}
