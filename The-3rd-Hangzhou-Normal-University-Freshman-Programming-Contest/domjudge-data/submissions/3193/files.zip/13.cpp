#include<bits/stdc++.h>
using namespace std;
main(){
int t,Y,A,sum,two,i,summ=0,n;
scanf("%d\n",&t);
for(int k=1;k<=t;k++){
scanf("%d %d",&Y,&A);  
sum=Y+A;
two=sum;
if(sum>9999)
{sum=sum-9999;   
two=9999-sum; }
for(i=Y;i<=two;i++){
       if ((i%4==0)&&(i%100!=0)||(i%400==0)){
        summ=summ+1;
       }
}
  printf("%d\n",summ);
  summ=0;
}

}

