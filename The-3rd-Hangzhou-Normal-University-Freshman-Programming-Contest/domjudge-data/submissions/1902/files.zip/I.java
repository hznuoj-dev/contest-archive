
import java.util.Scanner;

public class Main
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		while(sc.hasNext())
		{
			int count=0;
			for(int i=1;i<=4;i++)
			{
				int shuru=sc.nextInt();
				int sum=0;
				int a=0;
				while(shuru>0)
				{
					a=shuru%10;
					shuru=shuru/10;
					sum=a+sum;
				}
				if(sum>=16 || sum==6) count++;
			}
			if(count==1)System.out.println("Oh dear!!");
			if(count==2)System.out.println("BaoBao is good!!");
			if(count==3)System.out.println("Bao Bao is a SupEr man///!");
			if(count==4)System.out.println("Oh my God!!!!!!!!!!!!!!!!!!!!!");
			if(count==0)System.out.println("Bao Bao is so Zhai......");
		}
	}
	
}
