#include<stdio.h>
int main(){
	int t,n,m,a[10010],b[10010],c[10010],d[1];
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		for(int i=1;i<=n;i++){
			c[i]=i;
		}
		for(int i=1;i<=m;i++){
			scanf("%d%d",&a[i],&b[i]);	
		}
		for(int i=1;i<=m-1;i++){
			for(int j=2;j<=m;j++){
				if(a[j]>a[i]||(a[j]==a[i]&&b[j]>b[i])){
					c[0]=a[j];
					a[j]=a[i];
					a[i]=c[0];
					d[0]=b[j];
					b[j]=b[i];
					b[i]=d[0];
				}
			}
		}
		for(int i=1;i<=m;i++){
			if(c[a[i]]>c[b[i]]){
			c[c[b[i]]]=a[i];
			c[c[a[i]]]=b[i];}
			}
			for(int i=1;i<=n;i++){
				if(c[i]==0&&i!=n)
				printf("%d ",i);
				else if(c[i]==0&&i==n)
				printf("%d\n",i);
				if(c[i]!=0&&i!=n)
				printf("%d ",c[i]);
				else if(c[i]!=0&&i==n)
				printf("%d\n",c[i]);
			}
		}
	}
