#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)

using namespace std;

int main()
{
	string s;
	cin>>s;
	cout<<" __      _____"<<endl;
	cout<<"|  | ___/ ____\\____"<<endl;
	cout<<"|  |/ /\\   __\/   ___\\"<<endl;
	cout<<"|     < |  |  \\  \\___"<<endl;
	cout<<"|__|_ \\ |__|   \\___  >"<<endl;
	cout<<"     \\/            \\/"<<endl;
}


