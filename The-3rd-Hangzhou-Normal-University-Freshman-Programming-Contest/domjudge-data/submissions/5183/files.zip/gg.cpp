#include<stdio.h>
#include<string.h>
#include<math.h>

int main(){
	int T,n,m,i,j,x,y,ii,k;
	int a[101][101]={0},b[1001]={0},c[1001]={0};
	scanf("%d",&T);
	while(T--){
	 	scanf("%d %d",&n,&m);
		while(m--){
			scanf("%d %d",&x,&y);
		a[x][y]=1;
		}
		for(i=1;i<=n;i++){
			for(j=1;j<=n;j++){
				if(a[i][j]==1){
					for(ii=1;ii<=n;ii++){
						if(a[j][ii]==1){
							a[i][ii]=1;
						}
					}
				}
			}
		}
		for(i=1;i<=n;i++){
			c[i]=i;
			for(j=1;j<=n;j++){
				b[i]=b[i]+a[i][j];
			}
		}
	
		
		for(i=1;i<n;i++){
			for(j=1;j<n;j++){
				if(b[j]<b[j+1]){
					
					k=b[j];
					b[j]=b[j+1];
					b[j+1]=k;
					k=c[j];
					c[j]=c[j+1];
					c[j+1]=k;
				}
			}
		}
		
	}
	for(i=1;i<=n;i++){
			printf("%d ",c[i]);
		}

}
