#include <stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996) 
int main(){
	char a[3];
	scanf("%s",a);
	printf(" __      _____\n");
	printf("|  | ___/ ____\\____\n");
	printf("|  |/ /\\   __\\/ ___\\\n");
	printf("|    <  |  | \\ \\___\n");
	printf("|__|_ \\ |__| \\___  >\n");
	printf("     \\/          \\/\n");
}
/*int main(){
	int t,y,a,b,c;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&y,&a);
		b=y+a;
		if(b>9999){
			b=9999+9999-b;
		}
		if(b<y){
			c=b;
			b=y;
			y=c;
		}
		int s=0;
		for(int i=y+10000;i<=b+10000;i++){
			if((i%4==0&&i%100!=0)||i%400==0)
			s++;
		}
		printf("%d\n",s);
	}
}*/
/*struct tijiao{
	int a;
	int b;
	int c;
	char d;
	char e;
}q[100001];
int paiming
void printft(int a,int b,int c){
	if(a==0){
		
	}
}
int main(){
	int n,t,m,p,w,i,j;
	char a[6][20]={"teamstatus","minrank","maxrank","account","submitcount","teamcount"};
	char b[20];
	scanf("%d %d %d %d",&n,&t,&m,&p);
	for(int i=0;i<m;i++){
		scanf("%d %d %d %c%c",&q.a,&q.b,&q.a,&q.c,&q.d,&q.e)
	}
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			if(q[j].c>q[j+1].c)
			q[100001]=q[j],q[j]=q[j+1],q[j+1]=q[100001];
		}
	}
	scanf("%d",&w);
	while(w--){
		scanf("%s%d %d",b,&i,&j);
		for(o=0;o<=5;o++){
			if(strcmp(a[o],b)==0)
			break;
		}
		printft(o,i,j);
		memset(b,0,sizeof(b));
	}
} */

