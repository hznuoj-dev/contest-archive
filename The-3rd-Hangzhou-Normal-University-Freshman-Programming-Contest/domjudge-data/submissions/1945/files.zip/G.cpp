#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<set>
#include<map>
#include<iostream>
#include<string>
#include<queue>
using namespace std;
typedef long long int ll;
const int N=1e3+100;
int in[N];
int mp[1100][1100];
void run(){
	int n,m;
	memset(in,0,sizeof(int));
	memset(mp,0,sizeof(int));
	vector<int>e[N];
	priority_queue<int,vector<int >,greater<int > >q;
	vector<int>ans;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=m;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		if(mp[a][b]==1)continue;
		mp[a][b]=1;
		in[b]++;
		e[a].push_back(b);
	}
	for(int i=1;i<=n;i++){
		if(in[i]==0)q.push(i);
	}
	while(!q.empty()){
		int p=q.top();
		q.pop();
		ans.push_back(p);
		for(int i=0;i<e[p].size();i++){
			int it=e[p][i];
			in[it]--;
			if(in[it]==0)q.push(it);
		}
	}
	for(int i=0;i<ans.size();i++){
		if(i==ans.size()-1)printf("%d\n",ans[i]);
		else printf("%d ",ans[i]);
	}
}
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		run();
	}
	return 0;
}
