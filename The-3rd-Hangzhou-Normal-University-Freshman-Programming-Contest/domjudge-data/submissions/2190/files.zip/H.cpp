#include<cstdio>
#include<algorithm>
#include<cstring>
#include<vector>
#include<set>
#include<map>
#include<iostream>
#include<string>
#include<queue>
using namespace std;
typedef long long int ll;
const int N=1e3+100;
int in[N];
int mp[1100][1100];
void run(){
	int n,m;
	scanf("%d%d",&n,&m); 
	printf("[");
	for(int i=1;i<=m;i++){
		printf("#");
	}
	for(int i=1;i<=n-m;i++){
		printf("-");
	}
	int ans=m*100/n;
	printf("] %d%\n",ans);
}
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		run();
	}
	return 0;
}
