//kfc
#include "stdio.h"
int main()
{
	int flag,i1=0,i2=0,i3=0,i4=0,sum1=0,sum2=0,sum3=0,sum4=0,flag1=0,flag2=0,flag3=0,flag4=0;
	long long A,B,C,D;
	scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
	while(A!=0)
	{i1=A%10;
		A=A/10;
		sum1+=i1;}
	while(B!=0)
	{i2=B%10;
		B=B/10;
		sum2+=i2;}
	while(C!=0)
	{i3=C%10;
		C=C/10;
		sum3+=i3;}
	while(D!=0)
	{i4=D%10;
		D=D/10;
		sum4+=i4;}
	if(sum1>=16||sum1==6)
	flag1=1;
	else
	flag1=0;
	if(sum2>=16||sum2==6)
	flag2=1;
	else
	flag2=0;
	if(sum3>=16||sum3==6)
	flag3=1;
	else
	flag3=0;
	if(sum4>=16||sum4==6)
	flag4=1;
	else
	flag4=0;
	flag=flag1+flag2+flag3+flag4;
	if(flag==1)
	printf("Oh dear!!\n");
	if(flag==2)
	printf("Bao Bao is good!!\n");
	if(flag==3)
	printf("Bao Bao is a SupEr man///!\n");
	if(flag==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	if(flag==0)
	printf("Bao Bao is so Zhai......\n");
	return 0;
	 
 } 
