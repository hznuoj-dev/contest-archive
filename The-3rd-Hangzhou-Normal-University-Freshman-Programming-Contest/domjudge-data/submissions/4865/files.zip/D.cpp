#include<bits/stdc++.h>
using namespace std;
int main(){
	int T,n;
	cin >> T;
	int p=T;
	getchar();
	while(T--){
		string s;
		getline(cin,s);
		n=s.size();
	}
	cout << n*p << endl;
return 0;
}
