import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class Main
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner((System.in));
        while (in.hasNext())
        {
            int n = in.nextInt();
            for (int i = 1; i <= n; i++)
            {
                int sum = 0;
                int n2 = in.nextInt();
                Set<String> hashSet = new HashSet<String>();
                for (int k = 1; k <= n2; k++)
                {
                    String n3 = in.next();
                    for (int l = 0; l < n3.length(); l++)
                    {
                        if (n3.charAt(l) != '.')
                        {
                            hashSet.add(String.valueOf(n3.charAt(l)));
                        }
                    }
                    sum = hashSet.size() + sum;
                    hashSet.clear();
                }
                System.out.println(sum);
            }
        }
    }
}