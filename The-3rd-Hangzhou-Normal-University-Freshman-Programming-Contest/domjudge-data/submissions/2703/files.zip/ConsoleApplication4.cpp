﻿#include <stdio.h>
#include<string.h>
#include<stdlib.h>
int zhuan(int n){
	int x = 0;
	if (n == '1')
		x = 1;
	else if(n == 2)
		x = 2;
	else if (n == 3)
		x = 3;
	else if (n == 4)
		x = 4;
	else if (n == 5)
		x = 5;
	else if (n == 6)
		x = 6;
	else if (n == 7)
		x = 7;
	else if (n == 8)
		x = 8;
	else if (n == 9)
		x = 9;
	return x;
	}
int main() {
	char a[20];char b[20];char c[20];char d[20];
	scanf("%s", a); scanf("%s", b); scanf("%s", c); scanf("%s", d);
	int sum = 0; int x = 0;
	int len = strlen(a);
	for (int i = 0; i <len; i++) {
		sum = sum + zhuan(a[i]);
	}
	if (sum >= 16 || sum == 6) 
		x = x + 1;
	sum = 0; len = strlen(b);
	for (int i = 0; i <len; i++) {
		sum = sum + zhuan(b[i]);
	}
	if (sum >= 16 || sum == 6)
		x = x + 1;
	sum = 0; len = strlen(c);
	for (int i = 0; i <len; i++) {
		sum = sum + zhuan(c[i]);
	}
	if (sum >= 16 || sum == 6)
		x = x + 1;
	sum = 0; len = strlen(d);
	for (int i = 0; i <len; i++) {
		sum = sum + zhuan(d[i]);
	}
	if (sum >= 16 || sum == 6)
		x = x + 1;
	if (x == 1)
		printf("Oh dear!!");
	else if (x == 2)
		printf("BaoBao is good!!");
	else if (x == 3)
		printf("Bao Bao is a SupEr man///!");
	else if (x == 4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	else
		printf("Bao Bao is so Zhai......");
}