#include <stdio.h>
int main()
{
    int year,a,b,c,i,n,flag,count=0;
    
    scanf("%d",&n);
    while(n--)
    {scanf("%d%d",&year,&a);
    	b=year+a;
		if(b>9999)
		b=b-(b-9999);
    	if(b<year){
    		c=year;
    		year=b;
    		b=c;
		}
    	for(i=year;i<=b;i++){
    	    if(i%400==0)
            flag=1;
            else
            {
             if(i%4==0&&i%100!=0)
             flag=1;
             else
             flag=0;
            }
            if(flag==1)
            {
            count=count+1;
            }
            else
            {
            count=count+0;
            }
	 	}
    	printf("%d\n",count);
		count=0;	
	}
    return 0;
}
