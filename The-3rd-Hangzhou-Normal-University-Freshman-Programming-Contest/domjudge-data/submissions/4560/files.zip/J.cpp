#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int n,k,i,h,y,t,temp,j,sum;
	char a[10001]={},b[10001]={};
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		sum=0;h=0;
		for(i=1;i<=n;i++){
			scanf("%s",a);
			for(k=0;k<=strlen(a)-1;k++){
                 if(a[k]!='.'){
					 if(h==0)
						 b[h]=a[k],h++;
					 else{
						 for(j=0;j<=h-1;j++){
							 if(a[k]==b[j])
								 break;
							 if(j==h)
								 b[j]=a[k],h++;
						 }
					 }
					 //
				 }
			}
			sum+=h;
		}
		printf("%d\n",sum);
	}
	getchar();
	getchar();
	return 0;
}
//int cmp(const void*p,const void*q){
//return((struct kx*)q)->average -(struct kx*)p)->average)
//}