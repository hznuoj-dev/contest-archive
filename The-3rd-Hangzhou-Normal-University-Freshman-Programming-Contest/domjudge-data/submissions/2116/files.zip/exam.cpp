#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	char a[4];
	scanf("%s",a);
	printf(" __      _____\n|  | ___/ ____\\____\n|  |/ /\\   __\\/ ___\\\n|    <  |  | \\  \\___\n|__|_ \\ |__|  \\___  >\n     \\/           \\/");
}
