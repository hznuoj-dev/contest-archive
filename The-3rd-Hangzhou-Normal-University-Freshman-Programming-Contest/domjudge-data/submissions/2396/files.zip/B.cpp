
#include<bits/stdc++.h>
using namespace std;

int isLeapYear(int year){
    return (year%4==0&&year%100!=0)||year%400==0;
}

int main()
{
	int t;
	cin>>t;
	
	while(t--)
	{
		int num=0;
		int start,end;
		int y,a;
		cin>>y>>a;
		
		if(a > 0){
			for(int i=y;i<=y+a;i++)
			{
				if(i>=10000){
					i++;
					continue;
				}
				if(isLeapYear(i)) num++;
			}
		}
		else if(a < 0){
			for(int i=y+a;i<=y;i++)
			{
				if(i>=10000){
					i++;
					continue;
				}
				if(isLeapYear(i)) num++;
			}
		}
		cout<<num<<endl;
		
	}

	return 0;
}









