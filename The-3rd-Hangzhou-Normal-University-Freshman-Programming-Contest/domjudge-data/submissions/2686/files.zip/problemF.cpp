#include<stdio.h>
int main(){
	int i,j,n,k,m,count=0;
	int a[100],b[100];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++){
		scanf("%d",&b[i]);
	}
	for(j=1;j<=m;j++){
	   for(i=n-1;i>=0;i--){
	   	for(k=0;k<b[i];k++){
	   		if(j-a[i]<=0){
	   		count++;
	   	        }
		   }
	   }
	}
	printf("%d",count);
	
}
