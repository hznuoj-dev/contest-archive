#include<stdio.h>
int main(void){
	char ch;
	scanf("%c",&ch);
	printf("__ _____\n| | ___/ ____\\____\n| |/ /\\ __\\/ ___\\\n| < | | \\ \\___\n|__|_ \\ |__| \\___ >\n\\/ \\/");
	return 0;
}
