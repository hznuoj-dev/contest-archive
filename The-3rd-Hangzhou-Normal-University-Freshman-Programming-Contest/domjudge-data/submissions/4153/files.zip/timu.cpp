#include<bits/stdc++.h>
using namespace std;
int num[300]={0};
int main()
{
    int m,t,i,j,q,sum,flag;
	char n[1000005];
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
	   scanf("%d",&m);
	   sum=0;
	    for(q=1;q<=m;q++)
	    { 
		   scanf("%s",n);
		   for(j=0;j<=strlen(n)-1;j++)
		   {
		      if(n[j]!='.' && num[n[j]]==0)
		       {
			      num[n[j]]++;
			      sum++;
			   }
		   }
		  for(j=0;j<=300;j++)
	      {
		     if(num[j]==1) num[j]=0; 
		  }
		} 
	   printf("%d\n",sum);
	}
	return 0;
}
