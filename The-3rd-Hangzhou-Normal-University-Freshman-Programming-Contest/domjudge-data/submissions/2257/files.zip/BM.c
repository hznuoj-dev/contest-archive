#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(void) {
	int T,Y,A,B,x=0,t,i,j;
	scanf("%d",&T);
	while((T>=1)&&(T<=100)&&(T--)){
		scanf("%d %d",&Y,&A);
    B=Y+A;
    if(B>9999){
    	t=B-9999;
    	B=9999-t;
	}
	if(B<Y){
		j=Y;
		Y=B;
		B=j;
	}
	for(i=Y;i<=B;i++){
		if((i%400)==0||((i%4==0)&&(i%100!=0))){
		x=x+1;	
		}
		else
		x=x;
	}
	printf("%d\n",x);
	x=0;	
	}
	return 0;
}
