#include <bits/stdc++.h>
using namespace std;
typedef long long  ll;
const int MAXN=2e4+5;
ll a,b,c,d,l,mid,r,sum[200],n,m,t=0,k,x,w,v,y,ans,x2,y2;
int main()
{
    cin>>n;
    for(int i=1; i<=n; i++)
    {
        cin>>a>>b;
        if(a+b>9999)
        {
            l=a;
            r=9999-a-b+9999;
        }
        else
        {
            l=a;
            r=a+b;
        }
        l=min(l,r);
        r=max(l,r);
        for(int j=l; j<=r; j++)
        {
            if(j%4==0&&j%100!=0)
                sum[i]++;
            if(j%400==0)
                sum[i]++;
        }
    }
    for(int i=1;i<n;i++)
        cout<<sum[i]<<'\n';
        cout<<sum[n];
    return 0;
}

