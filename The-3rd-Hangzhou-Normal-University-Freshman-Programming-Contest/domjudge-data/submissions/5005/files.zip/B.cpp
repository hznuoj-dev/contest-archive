#include<iostream>
#include<algorithm>
#include<cmath>
#include<cstring>
using namespace std;
int k,n,m,x,y,i,T,j,t=0,sum,temp,s1,s2,s3,s4;
int a[5000],b[5000],c[5000],dp[100010];
char e[10];

int main(){
   cin>>e;
   cout<<" __      _____"<<'\n';
   cout<<"|  | ___/ ____\\____"<<'\n';
   cout<<"|  |/ /\\   __\\/ ___\\"<<'\n';
   cout<<"|    <  |  | \\  \\___"<<'\n';
   cout<<"|__|_ \\ |__|  \\___  >"<<'\n';
   cout<<"     \\/           \\/"<<'\n';
    return 0;
}
