#include <stdio.h>
int max(int x, int y){
	if(x>=y){
		return x;
	}
	else{
		return y;
	}
}
int main(){
	int t;
	scanf("%d", &t);
	while(t--){
		int m, n, k, p, cout=0, i;
		scanf("%d%d", &m, &n);
		if(m+n>9999){
			k=m+n-9999;
			p=9999-k;
		}
		else{
			p=m+n;
		}
		for(i=p+m-max(p, m);i<=max(p, m);i++){
			if((i%4==0&&i%100!=0)||(i%400==0)){
				cout++;
			}
		}
		printf("%d\n", cout);
	}
} 









































