#include<bits/stdc++.h>
using namespace std;
int leap(int min,int max){
	int cnt=0;
	for(int i=min;i<=max;i++){
		if(i%400==0||(i%4==0&&i%100!=0))cnt++;
	}
	return cnt;
}
int main(){
	int t,T;
	int min,max;
	int year,y;
		cin>>t;
	for(t=1;t<=T;t++){
		cin>>year>>y;
		min=year;
		max=year+y;
		if(min>max)
		{
			int t=min;
			min=max;
			max=t;
		}
		if(max>9999)max=9999*2-max; 
		cout<<leap(min,max)<<endl;
	}
	
	return 0;
}
