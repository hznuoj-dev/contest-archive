#include <iostream>
using namespace std;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int total_case;
    int total_processes, total_completed_processes;
    int counter;
    double percentage;

    cin >> total_case;
    while (total_case--) {
        cin >> total_processes >> total_completed_processes;
        if (total_completed_processes != 0) {
            percentage = 1.0 * total_completed_processes / total_processes;
        } else {
            percentage = 0;
        }

        cout << '[';
        for (counter = 0; counter < total_completed_processes; ++counter) {
            cout << '#';
        }
        for (counter = 0; counter < total_processes - total_completed_processes; ++counter) {
            cout << '-';
        }
        cout << "] " << (int)(100.0 * percentage) << "%\n";
    }

    return 0;
}