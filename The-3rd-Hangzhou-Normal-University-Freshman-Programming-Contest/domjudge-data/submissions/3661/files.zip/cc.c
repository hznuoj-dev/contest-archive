#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void) {
	int T;
	scanf("%d", &T);
	while (T--) {
		int n;
		int sum = 0;
		scanf("%d", &n);
		while (n--) {
			char cc[1000005];
			char fc[1000];
			scanf("%s", cc);
			int i, j, h = 0;
			for (i = 0; i < strlen(cc); i++) {
				if (cc[i] != '.') {
					int flag = 1;
					for (j = 0; j < h; j++) {
						if (fc[j] == cc[i]) {
							flag = 0;
							break;
						}
					}
					if (flag) {
						fc[h++] = cc[i];
					}
				}
			}
			sum += h;
		}
		printf("%d\n", sum);
	}
}