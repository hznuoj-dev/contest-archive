#include <iostream>
#include <cstdio>
#include <algorithm>
#include <cstring>
#include <string>
#include <queue>
#include <stack>
#include <set>
#include <map>
#include <cstdlib>
#include <vector>
#define INF 0x3f3f3f3f
#define fcin freopen("in.txt","r",stdin)
#define fcio ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
using namespace std;

int n;
string s;

int main()
{
	cin>>n;
	for(int i=0;i<n;i++) cin>>s;
	
	cout<<n*s.size()<<endl;
}
