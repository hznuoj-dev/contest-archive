#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e6;
const int INF=0x3f3f3f3f;
const ll MOD=998244353;
ll fac[N];
ll a[N];
ll fp(ll a, ll n){
	ll base=a;
	ll res=1;
	while(n){
		if(n&1){
			res=res*base%MOD;
		}
		base=base*base%MOD;
		n>>=1;
	}
	return res;
}
void init(){
	fac[0]=1;
	for(int i=1;i<=1e5;++i)
		fac[i]=fac[i-1]*i%MOD;
}
ll C(int n,int k){
	ll temp=fac[n-k]*fac[k]%MOD;
	ll ans=fac[n]*fp(temp,MOD-2)%MOD;
	return ans;
}
int main(){
	init();
	ll n; scanf("%lld",&n);
	ll maxx=0;
	for(int i=1;i<=n;++i){
		int num; scanf("%d",&num);
		a[num]++;
		if(maxx<num) maxx=num;
	}
	ll ans=1;
	for(ll i=2;i<=maxx;++i)
		ans=ans*C(a[i]+a[i-1]-1,a[i])%MOD;
	printf("%lld\n",ans);
	return 0;
}
