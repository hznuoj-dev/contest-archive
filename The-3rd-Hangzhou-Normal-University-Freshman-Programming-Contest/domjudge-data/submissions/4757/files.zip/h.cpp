#include <stdio.h>
int main (void){
	int t;
	scanf("%d",&t);
	while (t--){
		int m,n;
		scanf("%d %d",&m,&n);
		printf("[");
		for(int i=1;i<=n;i++){
			printf("#");
		}
		for(int i=1;i<=m-n;i++){
			printf("-");
		}
		printf("] ");
		printf("%d%%\n",n*100/m);
	}
	return 0;
}
