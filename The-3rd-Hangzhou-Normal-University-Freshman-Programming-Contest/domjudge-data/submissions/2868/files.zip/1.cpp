#include<stdio.h>
int main()
{
	int t, a, b, i;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d%d", &a, &b);
		printf("[");
		for (i = 0; i < b; i++)
			printf("#");
		for (i = 0; i < a - b; i++)
			printf("-");
		printf("] ");
		printf("%d%%\n", b * 100/a);
	}
	return 0;
}
