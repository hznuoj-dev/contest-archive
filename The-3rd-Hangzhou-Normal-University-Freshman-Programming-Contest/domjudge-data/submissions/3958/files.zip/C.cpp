#include<stdio.h>
int ans,x,a[100000];
void f(int x,int y);
int main(void){
	
	int n,i,s=1,y,p,b;
	scanf("%d",&n);
	ans=1;
	for(i=1;i<=n;i++){
		
		scanf("%lld",&x);
		a[x]++;
	}
	for(i=2;i<=10000;i++){
		
		x=a[i-1];
		y=a[i];
		if(a[i]==0) break;
		else f(x,y);
	}
	printf("%lld",ans);
}
void f(int x,int y){
	
	int i,t;
	long long s=1;
	t=y-1;
	y=x+y-1;
	if(y-t<t) t=y-x;
	for(i=y;i>=y-t;i--) s=s*i/(y-i+1)%998244353;
	ans=(ans*s)%998244353;
}
