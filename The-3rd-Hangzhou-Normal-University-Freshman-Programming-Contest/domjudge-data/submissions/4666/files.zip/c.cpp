#include<bits/stdc++.h>
using namespace std;
 int main(){
 	int repeat;
	 scanf("%d",&repeat);
	 while(repeat--){
	int repeat2,sum=0;
	char a[10000],ch;
	int b[10000],len;
	scanf("%d",&repeat2);
	while(repeat2--){
		scanf("%s",a);len=strlen(a); memset(b,0,sizeof(b));
        for(int i=0;i<len;i++){
            if(b[a[i]-' ']==0&&a[i]!='.')b[a[i]-' ']++;
        }
        for(int i=1;i<100;i++){
            if(b[i]!=0)sum++;
        }
		
	 } 	
 printf("%d\n",sum);
}	 return 0;
}
