#include <iostream>
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <set>
#include <map>
#include <queue>
#include <list>
using namespace std;
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int a,b;
		scanf("%d%d",&a,&b);
		if(a+b>=10000)
		{
			int t=a+b-9999;
			b=9999-t;
		}
		else b=a+b;
		int cnt=0;
		if(a>b)
		swap(a,b);
//		{
//			printf("a=%d b=%d\n",a,b);
//		}
		for(int i=a;i<=b;i++)
		{
			if(i%4==0&&i%100!=0||i%400==0)
			{
				cnt++;
			}
		}
		printf("%d\n",cnt);
	}
	return 0;
}
