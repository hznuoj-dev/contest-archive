#include <stdio.h>
int shuchu(int a,int b){
	int n=0,m=0;
	if(a+b>9999){
		n=a+(a+b-9999);
	}
	else{
		n=a+b;
	}
	if(a<=n){
		for(int i=a;i<=b;i++){
			if((i%4==0&&i%100!=0)||(i%100==0&&i%400==0)){
				 m++;
			}
		}
	}
	else{
		for(int i=n;i<=a;i++){
			if((i%4==0&&i%100!=0)||(i%100==0&&i%400==0)){
				m++; 
			}
		}
	}
	return m;
}
int main(){
	int n;
	scanf("%d",&n);
	int a[n],b[n];
	for(int i=0;i<n;i++){
		scanf("%d %d",&a[i],&b[i]);
		a[i]=shuchu(a[i],b[i]);
	}
	for(int i=0;i<n;i++){
		printf("%d\n",a[i]);
	}
} 
