#include<bits/stdc++.h>
using namespace std;
int qj(int l,int r)
{
	int ll=(l-1)/4-(l-1)/100+(l-1)/400, rr=r/4-r/100+r/400;
	return rr-ll;	
}
int main()
{
	int t; cin>>t;
	while(t--)
	{
		
		int n, m; cin>>n>>m;
		int l=n, r=n+m;
		if(l>=10000) l=19998-l;
		if(r>=10000) r=19998-r;
		if(l>r)
		{
			int t;
			t=l, l=r, r=t;
		}
		printf("%d\n",qj(l,r));
	}
	return 0;
}


