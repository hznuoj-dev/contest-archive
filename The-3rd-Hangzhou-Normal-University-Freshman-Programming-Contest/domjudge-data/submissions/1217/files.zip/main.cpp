//
//  main.cpp
//  c++_02
//
//  Created by 李尚鑫 on 2020/12/7.
//
#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

int main () {
    printf(" __      _____\n");
    printf("|  | ___/ ____\\____\n");
    printf("|  |/ /\\   __\\/ ___\\\n");
    printf("|    <  |  | \\  \\___\n");
    printf("|__|_ \\ |__|  \\___  >\n");
    printf("     \\/           \\/\n");
}
