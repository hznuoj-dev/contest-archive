#include<stdio.h>
#include<string.h>
#define max 1000000
char str[max+1],str1[max+1];
int main()
{
	int t,m,n,i,j,s,p,len,k,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		getchar();
		s=0;
		for(i=1;i<=n;i++){
		for(j=0;j<max;j++){
		 str1[j]='.';
	}
	scanf("%s",str);
	getchar();
	len=strlen(str);
	m=0;p=0;
	for(j=0;j<len;j++){
		if(str[j]!='.'){
			for(k=0;k<=m;k++){
				if(str[j]==str1[k])
				break;
			} 
			if(k>m){
				x=0;
				while(str1[x]!='.'){
					x=x+1;
				}
				str1[x]=str[j];
				p=p+1; 
			}
			m=x;
		}	
	}
	
	s=s+p;
	}
	printf("%d\n",s);
}
}
