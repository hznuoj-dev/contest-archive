#include<stdio.h>
#include<string.h>
int main()
{
	int t,n,i,j,a[1000];
	char str[1000000];
	scanf("%d",&t);
	while(t--)
	{
		int sum=0;
		scanf("%d",&n);
		getchar();
		while(n--)
		{
			gets(str);
			for(j=0;j<strlen(str);j++)
			{
				if(str[j]!='.')
				{
					a[str[j]]++;
				}
				
			}
			for(j=0;j<strlen(str);j++)
			{
			if(a[str[j]]!=0)
			sum++;
			a[str[j]]=0;	
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}


