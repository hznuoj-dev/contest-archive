#include <stdio.h>
long long int sight(long long int num);
int main(void) {
    long long int a,b,c,d,sum=0;
    scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
    if(sight(a)==1){
    	sum++;
	}
	if(sight(b)==1){
		sum++;
	}
	if(sight(c)==1){
		sum++; 
	}
	if(sight(d)==1){
		sum++;
	}
	switch(sum){
		default:printf("Bao Bao is so Zhai......");
		       break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
		       break;
		case 3:printf("Bao Bao is a Super man///!");
		       break;
		case 2:printf("BaoBao is good!!");
		       break;
		case 1:printf("Oh dear!!");
		       break;
	}
    return 0;

}
long long int sight(long long int num){
	long long int x=0,ret=0;
	if(num!=0){
		x+=num%10;
		num/=10;
	}
	if(x>=16||x==6){
		ret=1;
	}
	return ret;
}
