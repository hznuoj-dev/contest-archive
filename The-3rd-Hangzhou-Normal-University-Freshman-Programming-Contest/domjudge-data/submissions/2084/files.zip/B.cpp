#include <stdio.h>
int run(int a,int b){
	int sum=0;
	while(a<=b){
		if((a%4==0&&a%100!=0)||(a%400==0)){
			sum=sum+1;
		}
		a=a+1;
	}
	return sum;
}
int main(void){
	int T,Y,A,a,b,t,x;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&Y,&A);
		if(Y+A>9999){
			b=9999-(Y+A-9999);
			a=Y;
			if(a>b){
				t=b;b=a;a=t;
			}
		}
		else{
			if(Y<Y+A){
				a=Y;b=Y+A;
			}
			else
			{a=Y+A;b=Y;}
		}
		x=run(a,b);
		printf("%d\n",x);
	}
	return 0;
}
