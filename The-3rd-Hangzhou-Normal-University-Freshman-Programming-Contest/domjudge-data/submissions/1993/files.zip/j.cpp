#include<bits/stdc++.h>
using namespace std;
#define ll long long


int main(void){
	int n;
	cin>>n;
	while(n--){
		int q,count=0;
		cin>>q;
		for(int k=0;k<q;k++){
			map<char,int>m;
			string b;
			cin>>b;
			for(int k=0;k!=b.size();k++){
				if(b[k]!='.')
				m[b[k]]=1;
			}
			count+=m.size();
		}
		cout<<count<<endl;
	}
}
