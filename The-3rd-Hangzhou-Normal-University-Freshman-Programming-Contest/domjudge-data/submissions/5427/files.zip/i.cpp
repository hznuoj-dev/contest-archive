#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void){
	long long int a,b,c,d;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	long long int sum1=0,sum2=0,sum3=0,sum4=0;
	char time0[100]={ "Bao Bao is so Zhai......"};
	char time1[100]={"Oh dear!!"};
	char time2[100]={"BaoBao is good!!"};
	char time3[100]={"Bao Bao is a SupEr man///!"};
	char time4[100]={"Oh my God!!!!!!!!!!!!!!!!!!!!!"};
	while(a!=0){
		sum1 +=a%10;
        a/=10;
	}
	while(b!=0){
		sum2 +=b%10;
        b/=10;
	}
	while(c!=0){
		sum3 +=c%10;
        c/=10;
	}
	while(d!=0){
		sum4 +=d%10;
        d/=10;
	}
	int x,y,z,q,p;
	if(sum1 >=16||sum1==6){
		x=1;
	}else{
		x=0;
	}
	if(sum2>=16||sum2==6){
		y=1;
	}else{
		y=0;
	}
	if(sum3>=16||sum3==6){
		z=1;
	}else{
		z=0;
	}
    if(sum4>=16||sum4==6){
		q=1;
	}else{
		q=0;
	}
	p=x+y+z+q;
	if(p==0){
		printf("%s",time0);
	}else if(p==1){
		printf("%s",time1);
	}else if(p==2){
		printf("%s",time2);
	}else if(p==3){
		printf("%s",time3);
	}else if(p==4){
		printf("%s",time4);
	}
	return 0;
}
