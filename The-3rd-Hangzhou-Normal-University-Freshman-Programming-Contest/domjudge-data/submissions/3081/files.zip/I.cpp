#include <stdio.h>
int main()
{
	long long a,b,c,d;
	int A=0,B=0,C=0,D=0,sum=0;
	scanf("%lld%lld%lld%lld",&a,&b,&c,&d);
	do
	{
		A+=a%10;
		a/=10;
	}while(a>0);
	if(A==6||A>=16)
	{
		sum++;
	}
	do
	{
		D+=d%10;
		d/=10;
	}while(d>0);
	if(D==6||D>=16)
	{
		sum++;
	}
	do
	{
		B+=b%10;
		b/=10;
	}while(b>0);
	if(B==6||B>=16)
	{
		sum++;
	}
	do
	{
		C+=c%10;
		c/=10;
	}while(c>0);
	if(C==6||C>=16)
	{
		sum++;
	}
	if(sum==1)
	{
		printf("Oh dear!!\n");
	}
	if(sum==2)
	{
		printf("BaoBao is good!!\n");
	}
	if(sum==3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	if(sum==4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	if(sum==0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	return 0;
}
