#include <stdio.h>
int main(){
	int t,i;
	int m,n;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&m);
		for(i=1;i<=n;i++){
			if(i==1){
				printf("[");
			}
		    if(i<=m){
				printf("#");
			}
			if(i>m){
				printf("-");
			}
			if(i==n){
         	printf("] %d%%\n",m*100/n);
			}
		}
	}
	return 0;
}
