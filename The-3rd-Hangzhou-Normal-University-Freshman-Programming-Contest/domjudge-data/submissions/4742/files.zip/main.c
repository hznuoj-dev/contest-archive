#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
    long long a,b,c,d,sum1=0,sum2=0,sum3=0,sum4=0,n=0;
	scanf("%lld %lld %lld %lld",&a,&b,&c,&d);
	 while(a!=0){
	 	sum1=sum1+a%10;
	 	a=a/10;
	 	if (sum1>=16||sum1==6){
	 		n++;
	 		break;
		 }
	 }
       while(b!=0){
	 	sum2=sum2+b%10;
	 	b=b/10;
	 	if (sum2>=16||sum2==6){
	 		n++;
	 		break;
		 }
	 }
	 while(c!=0){
	 	sum3=sum3+c%10;
	 	c=c/10;
	 	if (sum3>=16||sum3==6){
	 		n++;
	 		break;
		 }
	 }
	 while(d!=0){
	 	sum4=sum4+d%10;
	 	d=d/10;
	 	if (sum4>=16||sum4==6){
	 		n++;
	 		break;
		 }
	 }
	 if (n==0)printf("Bao Bao is so Zhai......");
	 if (n==1)printf("Oh dear!!");
	 if (n==2)printf("BaoBao is good!!");
	 if (n==3)printf("Bao Bao is a SupEr man///!");
	 if (n==4)printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	return 0;
}
