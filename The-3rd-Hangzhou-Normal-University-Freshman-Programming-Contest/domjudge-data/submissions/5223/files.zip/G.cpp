#include<stdio.h>
int main(void)
{
	int t,n,m,o,i,j,k,a,b;
	scanf("%d",t);
	for(i=1;i<=t;i++)
	{
		scanf("%d %d",&n,&m);
		int num1[n],num2[n];
		for(j=1;j<=n;j++)
		num1[j]=j;
		for(j=1;j<=n;j++)
		num2[j]=j;
		for(k=1;k<=m;k++)
		{
			scanf("%d %d",&a,&b);
			if(num1[a]>num1[b])
			{
				o=num1[a];
				num1[a]=num1[b];
				num1[b]=o;
			}
		}
		for(j=1;j<=n;j++)
		{
			printf("%d",num2[num1[j]]);
			if(j!=n)
			printf(" ");
			else
			printf("\n");
		}
	}
}
