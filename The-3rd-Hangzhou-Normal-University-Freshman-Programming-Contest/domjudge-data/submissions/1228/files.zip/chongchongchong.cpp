#include<stdio.h>
int nianshu(int x,int y){
	int sum=0;
	for(int i=x;i<=y;i++){
		if(i!=0){
			if((i%4==0&&i%100!=0)||(i%400==0)) sum++;
		}
	}
	return sum;
}
int main(){
	int T,a,b;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&a,&b);
		b=a+b;
		if(b>9999) b=9999-(b-9999);
		if(b<0) b--;
		if(a>b) printf("%d\n",nianshu(b,a));
		else printf("%d\n",nianshu(a,b));
	}
	return 0;
} 
