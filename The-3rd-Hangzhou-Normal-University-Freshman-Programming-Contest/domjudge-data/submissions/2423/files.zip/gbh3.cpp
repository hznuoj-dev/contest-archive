#include<stdio.h>
	int main() {
		long long a, i, sum = 0, m;
		for (i = 0;i < 4;i++) {
			scanf("%lld", &a);
			m = 0;
			while (a > 0) {
				m = m + a % 10;
				a = a / 10;
			}
			if (m == 6 || m >= 16)
				sum++;
		}
		if (sum == 0)
			printf("Bao Bao is so Zhai......");
		else if (sum == 1)
			printf("Oh dear!!");
		else if (sum == 2)
			printf("BaoBao is good!!");
		else if (sum == 3)
			printf("Bao Bao is a SupEr man///!");
		else if (sum == 4)
			printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");
	}
