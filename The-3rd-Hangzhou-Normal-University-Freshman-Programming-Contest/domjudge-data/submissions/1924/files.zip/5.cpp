#include <stdio.h>
#include<string.h>
int main(){
int t1,f,i,j,n,t=0,k,q=0,v=0;
char s[100008],p[100008];
scanf("%d",&t1);
while (t1--){
	scanf("%d",&f);
	for(i=1;i<=f;i++){
		scanf("%s",s);
		n=strlen(s);
		for(j=0;j<n;j++){
			if(s[j]!='.'){
				for(k=0;k<=t-1;k++){
					if(p[k]==s[j]) q=1;
				}
				if (q==0){
				p[t]=s[j];
					t++;
					v++;
				}
				q=0;
			}
		}
		t=0;
	}
printf("%d\n",v);
	v=0;
}

 return 0;
}
