
import java.util.Arrays;
import java.util.Scanner;

public class Main
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		while (sc.hasNext())
		{
			String in=sc.next();
			String s="";String s2="";
			String s3="";
			s=" __      _____     ";
			 s2="|  | ___/ ____\\____";
			 s3="|  |/ /\\   __\\/ ___\\";
             String s4="|    <  |  | \\  \\___";
             String s5= "|__|_ \\ |__|  \\___  >";
             String s6="     \\/           \\/";
          
             System.out.println(s);
             System.out.println(s2);System.out.println(s3);
             System.out.println(s4);System.out.println(s5);
             System.out.println(s6);
		}

	}

}
