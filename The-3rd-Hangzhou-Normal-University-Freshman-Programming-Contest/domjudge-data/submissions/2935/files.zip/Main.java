import java.util.Scanner;

public class Main
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner((System.in));
        while (in.hasNext())
        {
            int n = in.nextInt();
            for (int i = 1; i <= n; i++)
            {
                int sum = 0;
                int n2 = in.nextInt();
                for (int k = 1; k <= n2; k++)
                {
                    String n3 = in.next();
                    char chElemDate = '.';
                    String n4 = deleteCharString0(String.valueOf(n3), chElemDate);
                    String n5 = removeRepeatChar(n4);
                    sum = sum + n5.length();
                }
                System.out.println(sum);
            }
        }
    }
    
    public static String removeRepeatChar(String str)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < str.length(); i++)
        {
            char charWord = str.charAt(i);
            int firstPosition = str.indexOf(charWord);
            int lastPosition = str.lastIndexOf(charWord);
            if (firstPosition == lastPosition || firstPosition == i)
            {
                sb.append(charWord);
            }
        }
        return sb.toString();
    }
    
    public static String deleteCharString0(String sourceString, char chElemData)
    {
        String deleteString = "";
        for (int i = 0; i < sourceString.length(); i++)
        {
            if (sourceString.charAt(i) != chElemData)
            {
                deleteString += sourceString.charAt(i);
            }
        }
        return deleteString;
    }
}