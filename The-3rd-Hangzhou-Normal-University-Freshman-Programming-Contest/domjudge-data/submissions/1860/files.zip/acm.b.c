#include<stdio.h>
int main() {
	int t,y,a,b,sy,f=0;
	int i;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&y,&a);
		if(y+a>9999){
			sy=y+a-9999;
			b=9999-sy;
		}
		else{
			b=y+a;
		}
			if(y<b){
				for(i=y;i<=b;i++){
					if((i%4==0)&&(i%100!=0)||(i%400==0)){
						f+=1;
					}
				}
			}
			else{
				for(i=b;i<=y;i++){
					if((i%4==0)&&(i%100!=0)||(i%400==0)){
						f+=1;
					}
				}
			}
		printf("%d\n",f);
		f=0;
	}
	return 0;
}
