#include<stdio.h>
#include<math.h>
#include<string.h>
#pragma warning(disable:4996)
int main() {
	int t, q, i, j, e[200] = { 0 }, s;
	char a[100001];
	scanf("%d", &t);
	while (t--) {
		s = 0;
		scanf("%d", &q);
		while (q--) {
			for (i = 0; i < 150; i++) {
				e[i] = 0;
			}
			scanf("%s", a);
			for (i = 0; a[i] != '\0'; i++) {
				if (a[i] != '.') {
					j = (int)a[i];
					e[j] = 1;
				}
			}
			for (i = 1; i < 150; i++) {
				if (e[i] == 1) {
					s++;
				}
			}
		}
		printf("%d\n", s);
	}
	return 0;
}