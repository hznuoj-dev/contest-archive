def main():
    T=int(input())
    while T>0:
        n,m=map(int,input().split())
        per=int((m/n+0.005)*100)
        print('[',end='')
        for i in range(m):
            print('#',end='')
        for i in range(n-m):
            print('-',end='')
        print('] ',end='')
        print(per,end='')
        print('%')
main()
