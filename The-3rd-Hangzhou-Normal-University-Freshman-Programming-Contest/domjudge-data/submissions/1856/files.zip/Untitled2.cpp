#include<stdio.h>
int main(){
	int T, Y, A;
	scanf("%d", &T);
	for(int i=0;i<T;++i){
		scanf("%d%d", &Y, &A);
		int y=Y+A, sum=0;
		if(y>9999){
			y=2*9999-y;
		}
		if(y<Y){
			int t=y;
			y=Y;
			Y=t;
		}
		for(int j=Y;j<=y;++j){
			if(j%400==0||(j%4==0&&j%100!=0)){
				sum++;
			}
		}
		printf("%d\n", sum);
	}
	return 0;
}
