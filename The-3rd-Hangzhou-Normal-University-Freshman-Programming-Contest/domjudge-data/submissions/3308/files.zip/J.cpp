#include<bits/stdc++.h>
using namespace std;
int asc[200];
int main(){
	int T;
	cin >> T;
	while(T--){
		int n;
		cin >> n;
		int sumn[n+1];
		for(int i=1;i<=n;i++){
			memset(asc,0,sizeof(asc));
			char ch[1000005];
			scanf("%s",ch);
			for(int j=0;j<strlen(ch);j++){
				if(ch[j]!='.')asc[ch[j]]++;
				if(asc[ch[j]]==1)sumn[i]++;
			}
		}
		int summ=0;
		for(int i=1;i<=n;i++)summ+=sumn[i];
		cout << summ << endl;
	}
return 0;
}
