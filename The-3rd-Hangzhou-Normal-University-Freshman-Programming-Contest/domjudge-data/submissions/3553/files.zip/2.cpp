#include<stdio.h> 
int main(){
	int a,b,c,d,x,t;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	int A=a;
	int B=b;
	int C=c;
	int D=d;
	int i,sum;
	for(i=10;i<A;i*=10){
		sum=0;
		t=a%i;
		sum+=t;
		a=a/i;	
	}
	if(t>=16||t==6)
	x++;
	for(i=10;i<B;i*=10){
			sum=0;
		t=b%i;
		sum+=t;
		b=b/i;	
	}
	if(t>=16||t==6)
	x++;
		for(i=10;i<C;i*=10){
				sum=0;
		t=c%i;
		sum+=t;
		c=c/i;	
	}
	if(t>=16||t==6)
	x++;
		for(i=10;i<D;i*=10){
				sum=0;
		t=d%i;
		sum+=t;
		d=d/i;	
	}
	if(t>=16||t==6)
	x++;
	if(x==0)
	printf("Bao Bao is so Zhai......\n");
	else if(x==1)
	printf("Oh dear!!\n");
	else if(x==2)
	printf("BaoBao is good!!\n");
	else if(x==3)
	printf("Bao Bao is a SupEr man///\n");
	else if(x==4)
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
return 0;	
}
