#include<stdio.h>
int main(){
	int a,i;
	float b,c,e;
	scanf("%d",&a);
	while(a--){
		scanf("%f%f",&b,&c);
		e=c/b*100;
		printf("[");
		for(i=0;i<c;i++){
			printf("#");
		}
		for(i=0;i<b-c;i++){
			printf("-");
		}
		
		printf("]");
			printf(" %.0lf%%\n",e);
	}
	return 0;
}
