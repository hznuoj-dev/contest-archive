#include <bits/stdc++.h>
using namespace std;
int a[118];
int main() {
	int t;
	cin>>t;
	for (int i=1;i<=t;i++) {
		int n,res=0;
		cin>>n;
		for (int j=1;j<=n;j++) {
			string s;
			int cnt=0;
			cin>>s;
			memset(a,0,sizeof(a));
			for (int k=0;k<s.length();k++) {
				if (s[k]=='.'||a[s[k]]) continue;
				else {
					a[s[k]]=1;
					cnt++;
				}
			}
			res+=cnt;
		}
		cout<<res<<endl;
	}
}
