#include<stdio.h>
#include<string.h>
char a[2][100000];
int main(){
	int T,cs,zs,zs1;
	long long l,i,j,s;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&cs);
		zs=0;
		while(cs--){
		zs1=0;
		s=0;
		scanf("%s",a[0]);
		l=strlen(a[0]);
		for(i=0;i<l;i++){
			if(a[0][i]!='.'&&zs1==0)
			{
				zs1+=1;
				a[1][s]=a[0][i];
				s++;
			}
			else if(a[0][i]!='.')
			{
				for(j=0;j<s;j++)
				{
					if(a[0][i]==a[1][j])
					break;
				}
				if(j>=s)
				{
				zs1+=1;
				a[1][s]==a[0][i];
				s++;
			    }
			}
		}
		zs+=zs1; 
		}
		printf("%d\n",zs);
	}
} 
