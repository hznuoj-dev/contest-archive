#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
     char a[100],b[100],c[100],d[100];
     int i,m=0,a1,b1,c1,d1;
     int aa=0,bb=0,cc=0,dd=0,j;
     for(j=0;j<4;j++){
	 aa=0;
	 scanf("%s",&a);
     a1=strlen(a);
     for(i=0;i<a1;i++){
     	aa=aa+(int)(a[i]-48);
	 }
	 if(aa>=16||aa==6)
	 m++;
}
if(m==0){
	printf("Bao Bao is so Zhai......\n");
}
else if(m==1){
	printf("Oh dear!!\n");
}
else if(m==2){
	printf("BaoBao is good!!\n");
}
else if(m==3){
	printf("Bao Bao is a SupEr man///!");
}
     else printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
     
	
}
