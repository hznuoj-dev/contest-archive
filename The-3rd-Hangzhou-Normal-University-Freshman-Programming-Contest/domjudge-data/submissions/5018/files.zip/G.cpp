#include<stdio.h>
int main(){
   int T,k,q,n,l,i,m,x,h,g,z,r,y;
   int a[100],b[100];
   int t[1000];
   scanf("%d",&T);
   while(T--){
   scanf("%d %d",&n,&m);
   k=m;
   for(i=1;i<=n;i++){
   	t[i]=i;
   } 
    while(m--){
   	scanf("%d %d",&a[m],&b[m]);
	    for(x=k;x>m;x--){
   	 	    if(b[x]==b[m])
   	 	    {
   	 	      if((a[x]>a[m]&&t[a[x]]<t[a[m]])||(a[x]<a[m]&&t[a[x]]>t[a[m]])){
   	 	      	h=t[a[x]];
   	 	      	t[a[x]]=t[a[m]];
   	 	      	t[a[m]]=h;
				}	
			}
			else if(a[x]==a[m])
			{
   	 	      if(b[x]>b[m]&&t[b[x]]<t[b[m]]||(b[x]<b[m]&&t[b[x]]>t[b[m]])){
   	 	      	h=t[b[x]];
   	 	      	t[b[x]]=t[b[m]];
   	 	      	t[b[m]]=h;
				}	
			}
		}
   	if((a[m]>b[m]&&t[a[m]]>t[b[m]])||(a[m]<b[m]&&t[a[m]]>t[b[m]]))
   	{
   	 q=t[a[m]];
   	 t[a[m]]=t[b[m]];
   	 t[b[m]]=q;
		for(x=k;x>m;x--){
   	 	    if(b[x]==b[m])
   	 	    {
   	 	      if(a[x]>a[m]&&t[a[x]]<t[a[m]]){
   	 	      	q=t[a[x]];
   	 	      	t[a[x]]=t[a[m]];
   	 	      	t[a[m]]=q;
				}	
			}
			else if(a[x]==a[m])
			{
   	 	      if(b[x]>b[m]&&t[b[x]]<t[b[m]]){
   	 	      	h=t[b[x]];
   	 	      	t[b[x]]=t[b[m]];
   	 	      	t[b[m]]=h;
				}	
			}
			else if(a[m]==b[x])
			{
				if(a[k-x]>a[m]&&t[a[k-x]]>t[a[m]])
				{
					g=t[a[k-x]];
					t[a[k-x]]=t[a[m]];
					t[a[m]]=g;
				}
			}
		}   
    }
    }
    for(z=1;z<k;z++)
    {
    	for(r=z+1;r<k;r++)
    	{
    		if(b[z]==b[r])
    		{
    			if((a[z]<a[r]&&t[a[z]]>t[a[r]])||(a[z]>a[r]&&t[a[z]]<t[a[r]]))
    			{
    				y=t[a[z]];
    				t[a[z]]=t[a[r]];
    				t[a[r]]=y;
				}
			}
		}
	}
    for(l=1;l<=n;l++){
    	printf("%d",t[l]);
    	if(l!=n)
    	printf(" ");
	}  
   }
}
