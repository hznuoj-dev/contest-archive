#include <stdio.h>
int main(void)
{
	int t,y,a,n=0,i=0,x=0,m=0;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&y,&a);
		n=y+a;
		if(n>9999)
		{
			n=n-9999;
			n=9999-n;
		}
		if(y>n)
		{
			m=n;
			n=y;
			y=m;
		}
		for(i=y;i<=n;++i)
		{
			if((i%4==0&&i%100!=0)||(i%400==0))
			{
				x++;
			}
		}
		printf("%d\n",x);
		x=0;
	}
	return 0;
}
