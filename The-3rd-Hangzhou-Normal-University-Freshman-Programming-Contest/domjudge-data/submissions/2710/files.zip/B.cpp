#include<bits/stdc++.h>
using namespace std;

int isLeapYear(int year){
    return (year%4==0&&year%100!=0)||year%400==0;
}
int main()
{
	int t;
	int y,a;
	int right,left;
	cin>>t;
	while(t--)
	{
		int num=0;
		cin>>y>>a;
		if(a>=0){
			left = y;
			right = y+a;
		}
		else {
			left = y+a;
			right = y;
		}
		if(right>9999) right=9999*2-right;
		
		if(left>right) swap(left,right);
		
		for(int i=left;i<=right;i++){
			if(isLeapYear(i)) num++;
		}		
		cout<<num<<endl;
		
	}

	return 0;
}









