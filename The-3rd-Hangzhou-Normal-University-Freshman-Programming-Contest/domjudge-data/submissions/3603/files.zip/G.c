#include<stdio.h>
int main(void){
	int T;
	scanf("%d",&T);
	while(T--){
	int n,m,x,y,t,i=0;
	scanf("%d %d",&n,&m);
	int sum[m][2];
	int s[n];
	for(x=0;x<m;x++){
		for(y=0;y<2;y++){
			scanf("%d",&sum[x][y]);
		}
	}
	for(x=0;x<m;x++){
		if(sum[x][1]==sum[x+1][1]){
			if(sum[x][0]>sum[x+1][0]){
				int t;
				t=sum[x][0];
				sum[x][0]=sum[x+1][0];
				sum[x+1][0]=t;
			}
		}
	}
	for(x=0;x<m;x++){
			printf("%d ",sum[x][0]);
	}
	printf("%d",sum[m-1][1]);
	
}
return 0;
}
