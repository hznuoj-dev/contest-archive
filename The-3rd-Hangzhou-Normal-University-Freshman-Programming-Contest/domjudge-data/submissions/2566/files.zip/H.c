#include <stdio.h>
#include <string.h>
#include <math.h>
int main(){
	int i,t,n,m,s;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		printf("[");
		for(i=0;i<m;i++){
			printf("#");
		}
		for(i=m;i<n;i++){
			printf("-");
		}
		printf("]");
		s=(m*100/n);
		printf(" %d",s);
		printf("%%\n");
	}
}
