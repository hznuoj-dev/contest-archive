#include <stdio.h>
#include <string.h>
int main(void){
	int T,n,l,sum,q,flag;
	char a[1000001],b[1000000];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		sum=0;q=0;
		while(n--){
			scanf("%s",&a);
			l=strlen(a);
			for(int i=0;i<l;i++){
				if(a[i]=='.')continue;
				else{
					if(q==0){b[0]=a[i];q=1;}
					flag=0;
					for(int j=0;j<q;j++){
						for(int x=0;x<q;x++){
							if(a[i]==b[x])flag=1;
						}
						if(flag==1)break;
						else
						 b[q]=a[i];
						 q=q+1;
					}
				}
			}
			sum=sum+q;
			q=0;
		}
		printf("%d\n",sum);
	}
	return 0;
}
