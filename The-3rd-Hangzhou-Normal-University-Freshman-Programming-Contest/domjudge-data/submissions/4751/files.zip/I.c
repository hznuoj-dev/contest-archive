#include<stdio.h>
int main()
{
	int a,b,c,d,i,s=0,g=0;
	scanf("%d %d %d %d",&a,&b,&c,&d);
	while(a>0)
	{
		s+=a%10;
		a/=10;
	}
	if(s>=16||s==6)
	{
		g+=1;
	}
	s=0;
	while(b>0)
	{
		s+=b%10;
		b/=10;
	}
	if(s>=16||s==6)
	{
		g+=1;
	}
	s=0;
	while(c>0)
	{
		s+=c%10;
		c/=10;
	}
	if(s>=16||s==6)
	{
		g+=1;
	}
	s=0;
	while(d>0)
	{
		s+=d%10;
		d/=10;
	}
	if(s>=16||s==6)
	{
		g+=1;
	}
	s=0;
	if(g==1)
	{
		printf("Oh dear!!\n");
	}
	if(g==2)
	{
		printf("BaoBao is good!!\n");
	}
	if(g==3)
	{
		printf("Bao Bao is a SupEr man///!\n");
	}
	if(g==4)
	{
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	}
	if(g==0)
	{
		printf("Bao Bao is so Zhai......\n");
	}
	return 0;
}
