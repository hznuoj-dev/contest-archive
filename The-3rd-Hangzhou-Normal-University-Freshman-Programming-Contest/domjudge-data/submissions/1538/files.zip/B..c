#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int t,a,b,n,i,c;
	scanf("%d",&t);
	while(t--){
		n=0;
		scanf("%d %d",&a,&b);
		if(a+b>9999&&b>0){
			b=9999-(a+b)%9999;
		}
		else if(a+b<=9999&&b>0)
		b=a+b;
		else if(b<0){
			c=b;
			b=a;
			a=b+c;
		}
		for(i=a;i<=b;i++){
			if((i%4==0&&i%100!=0)||i%400==0)
			n+=1;
		}
		printf("%d\n",n);
	} 
	return 0;
}
