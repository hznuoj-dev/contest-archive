#include<stdio.h>
#include<string.h>
#pragma warning(disable:4996)
int main()
{	
	int a,b,c,d,i,e;
	scanf("%d",&d);
	while(d--)
	{
		e=0;
		scanf("%d%d",&a,&b);
		c=a+b;
		if(c<a)
			{for(i=c;i<=a;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					e++;
			}
		}
		else if(c>9999)
		{
			for(i=a;i<=c;i++)
		{
			if((i%4==0&&i%100!=0)||i%400==0)
				e++;
		}
		}
		else
		{
			for(i=a;i<=c;i++)
			{
				if((i%4==0&&i%100!=0)||i%400==0)
					e++;
			}
		}
		printf("%d\n",e);
	}
	return 0;
}