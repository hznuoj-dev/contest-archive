#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 



int main(){
	int t,a,b,i;
	char c='%';
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		putchar('[');
		for(i=1;i<=b;i++) putchar('#');
		for(i=1;i<=(a-b);i++) putchar('-');
		putchar(']');
		printf(" %.0f%c\n",b*1.0/a*100,c);
	}
} 


