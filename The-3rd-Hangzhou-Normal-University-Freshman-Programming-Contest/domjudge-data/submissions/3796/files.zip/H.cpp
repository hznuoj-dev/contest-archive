#include"stdio.h"
int main(void){
	int k,i,a,b,T;
	char ch[100010];
	double c;
	scanf("%d",&T);
	while(T>0){
		scanf("%d%d",&a,&b);
		ch[0]='[';
		for(i=1;i<=b;i++){
			ch[i]='#';
		}
		for(i=b+1;i<=a;i++){
			ch[i]='-';
		}
		ch[i]=']';
		for(k=0;k<=i;k++){
			printf("%c",ch[k]);
		}
		c=b*100/a;
		printf(" %.0f%%",c);
		printf("\n");
		T--;
	}
	return 0;
}
