#include<bits/stdc++.h>
using namespace std;
int main()
{
    char str[100];
    scanf("%s",str);
        printf(" __      _____\n");
        printf("|  | ___/ ____\\____\n");
        printf("|  |/ /\\   __\\/ ___\\\n");
        printf("|    <  |  | \\  \\___\n");
        printf("|__|_ \\ |__|  \\___  >\n");
        printf("     \\/           \\/\n");

    return 0;
}
