//
// Created by Kyooma on 2020/12/13.
//
#include <bits/stdc++.h>
using namespace std;
map<char,int> a;
char k[100009];
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,cnt=0;
        scanf("%d",&n);
        getchar();
        for(int i=0;i<n;i++){
            a.clear();
            scanf("%s",k);
            int len=strlen(k);
            for(int i=0;i<len;i++){
                a[k[i]]++;
                if(k[i]!='.' && a[k[i]]==1) cnt++;
            }
        }
        printf("%d\n",cnt);
    }
}

