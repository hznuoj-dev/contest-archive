#include<stdio.h>
#include<string.h>
void RemoveDuplicate(char* str);
int main() {
	int T, n;
	char s[1000000];
	int sum;
	int i, j, L;
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &n);
		sum = 0;
		while (n--) {
			scanf("%s", &s);
			L = strlen(s);
			RemoveDuplicate(s);
			for (i = 0;i < strlen(s);i++){
				if (s[i] != '.')
					sum++;
			}
		}
		printf("%d\n", sum);
	}
	return 0;
}
void RemoveDuplicate(char* str)
{
	int i, j, k, len;

	len = strlen(str);
	for (i = k = 0; i < len; i++)
	{
		if (str[i])
		{
			str[k++] = str[i];
			for (j = i + 1; j < len; j++)
				if (str[j] == str[i])
					str[j] = '\0';
		}
	}
	str[k] = '\0';
}