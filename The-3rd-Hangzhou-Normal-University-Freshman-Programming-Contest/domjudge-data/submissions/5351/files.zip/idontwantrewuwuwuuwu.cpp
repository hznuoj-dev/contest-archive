#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int end[1000010]={0};
int c[1000010]={0};
int cmp(const void *p,const void *q)
{
	return *((int *)p)-*((int *)q);
}
int main()
{
	int n,m;
	int a[110]={0};
	int b[110]={0};
	scanf("%d %d",&n,&m);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);//�洢Ӳ�ҵ���� 
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&b[i]);//����ԭ�еĸ��� 
		if(m/a[i]<b[i])
		{
			b[i]=m/a[i];
		}
		//printf("%d ",b[i]);
	}
	int gs=0;
	int flag=1;
	int bz;
	for(int i=1;i<=n;i++)
	{
		flag=1;
		bz=gs;
		for(int j=1;j<=b[i];j++)
		{
			//printf("%d\n",bz);
			//printf("%d\n",c[bz]);
			for(int k=0;k<=bz;k++)
			{
				if(end[c[k]+a[i]*j]==0)
				{
					gs++;
					c[gs]=c[k]+a[i]*j;
					end[c[k]+a[i]*j]=1;
				}
			}	
		}
		qsort(c,gs,sizeof(int),cmp);
	}
	int count=0;
	for(int i=1;i<=m;i++)
	{
		if(end[i]>0)
		{
			count++;
			//printf("%d\n",i);
		}
	}
	printf("%d\n",count);
	return 0;
}


