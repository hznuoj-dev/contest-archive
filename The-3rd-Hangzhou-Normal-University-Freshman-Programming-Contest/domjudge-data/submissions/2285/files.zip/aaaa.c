#include<stdio.h>
#include<string.h>
#include<math.h>

int main()
{
	char a[19],b[19],c[19],d[19];
	scanf("%s %s %s %s",a,b,c,d);
	int lena,lenb,lenc,lend,s=0;
	lena=strlen(a);
	lenb=strlen(b);
	lenc=strlen(c);
	lend=strlen(d);
	int sa=0,sb=0,sc=0,sd=0;
	for(int i=0;i<lena;i++){
		sa+=a[i]-'0';
	}
	if (sa>=16 || sa==6){
		s++;
	}
	for(int i=0;i<lenb;i++){
		sb+=b[i]-'0';
	}
	if (sb>=16 || sb==6){
		s++;
	}
	for(int i=0;i<lenc;i++){
		sc+=c[i]-'0';
	}
	if (sc>=16 || sc==6){
		s++;
	}
	for(int i=0;i<lend;i++){
		sd+=d[i]-'0';
	}
	if (sd>=16 || sd==6){
		s++;
	}
	switch(s){
		case 1:printf("Oh dear!!");break;
		case 2:printf("BaoBao is good!!");break;
		case 3:printf("Bao Bao is a SupEr man///!");break;
		case 4:printf("Oh my God!!!!!!!!!!!!!!!!!!!!!");break;
		case 0:printf("Bao Bao is so Zhai......");break;
	}
}
