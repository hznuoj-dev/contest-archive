#include <stdio.h>
#include <string.h>
int main()
{
    int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,m;
		scanf("%d%d",&n,&m);
		double x=(double)m/(double)n*100;
		printf("[");
		for(int i=1;i<=m;++i)
		{
			printf("#");
		}
		for(int i=1;i<=n-m;++i)
		{
			printf("-");
		}
		printf("] %.f%%\n",x);
	 } 
	return 0;
 } 
