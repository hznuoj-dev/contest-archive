#include<stdio.h>
#include<math.h>
#include<string.h>
int main(void)
{
	int n;
	long long int m,a[102],b[102],k=1,s=0;
	scanf("%d%lld",&n,&m);
	for(int i=0;i<n;++i)
		scanf("%lld",&a[i]);
	for(int i=0;i<n;++i)
		scanf("%lld",&b[i]);
	while(k<=m)
	{
		long long int K=k;
		for(int j=n-1;j>=0;j=j-1)
		{
			if(K>=a[j])
			{
				if(K>=a[j]*b[j])
					K=K-a[j]*b[j];
				else
					K=K%a[j];
			}
			if(K==0){
				s++;
				break;	
			}
		}
		k++;
	}
	printf("%lld\n",s);
	return 0;
} 
