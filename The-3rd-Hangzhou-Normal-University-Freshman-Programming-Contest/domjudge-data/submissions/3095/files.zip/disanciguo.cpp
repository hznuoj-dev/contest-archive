#include<stdio.h>
int main ()
{
	int a[20]={0};
	int b[20]={0};
	int c[20]={0};
	int d[20]={0};
	int suma=0,sumb=0,sumc=0,sumd=0;
	long long A,B,C,D;
	scanf("%lld%lld%lld%lld",&A,&B,&C,&D);
	int regit=0 ;
	for (int i =1;A>0;i++){
		a[i]=A%10;
		A/=10;
		suma+=a[i];
	}
	for (int i =1;B>0;i++){
		b[i]=B%10;
		B/=10;
		sumb+=b[i];
	}
	for (int i =1;C>0;i++){
		c[i]=C%10;
		C/=10;
		sumc+=c[i];
	} 
	for (int i =1;D>0;i++){
		d[i]=D%10;
		D/=10;
		sumd+=d[i];
	}
 	if (suma>16||suma==6)
 	regit++;
	if(sumb>16||sumb==6)
	regit ++;
	if(sumc>16||sumc==6)
	regit ++;
	if(sumd>16||sumd==6)
	regit ++;
	if(regit ==0)
	printf("Bao Bao is so Zhai......");
	else if (regit == 1)
	printf("Oh dear!!");
	else if (regit ==2)
	printf("BaoBao is good!!");
	else if (regit ==3)
	printf("Bao Bao is a SupEr man///!");
	else 
	printf("Oh my God!!!!!!!!!!!!!!!!!!!!!") ;
	return 0;
}
