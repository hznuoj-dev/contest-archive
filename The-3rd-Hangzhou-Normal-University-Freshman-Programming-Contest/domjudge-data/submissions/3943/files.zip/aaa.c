#include <stdio.h>
//#pragma warning(disable:4996)
//#include <process.h>
int main(){
	long long int A,B,C,D,i,j,a,m=0,b,c,d,x=0;
	scanf("%lld %lld %lld %lld",&A,&B,&C,&D);
	for(i=1;;i++)
	{
		a=A%10;
	A=A/10;
		x+=a;
		if(A==0)
			break;
	}

	if(x==6||x>=16)
		m+=1;

			x=0;
		for(i=1;;i++)
	{
		b=B%10;
	B=B/10;
		x+=b;
		if(B==0)
			break;
	}
	if(x==6||x>=16)
		m+=1;

			x=0;
		for(i=1;;i++)
	{
		c=C%10;
	C=C/10;
		x+=c;
		if(C==0)
			break;
	}
	if(x==6||x>=16)
		m++;

	
			x=0;
		for(i=1;;i++)
	{
		d=D%10;
	D=D/10;
		x+=d;
		if(D==0)
			break;
	}
	if(x==6||x>=16)
		m++;

	if(m==0)
		printf("Bao Bao is so Zhai......\n");
	else if(m==1)
		printf("Oh dear!!\n");
		else if(m==2)
		printf("BaoBao is good!!\n");
	else if(m==3)
		printf("Bao Bao is a SupEr man///!\n");
			else if(m==4)
		printf("Oh my God!!!!!!!!!!!!!!!!!!!!!\n");
	//system ("pause");
return 0;
}
