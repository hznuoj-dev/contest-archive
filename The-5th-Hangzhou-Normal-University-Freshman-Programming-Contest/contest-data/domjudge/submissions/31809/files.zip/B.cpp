#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

typedef long long LL;

const int N = 200010;

int n;
LL a[N], b[N];

int main()
{
    cin >> n;
    for (int i = 0; i < n; i ++ ) cin >> a[i];
    for (int i = 0; i < n; i ++ ) cin >> b[i];
    sort(a, a + n);
    sort(b, b + n);

    LL cnt = b[0] - a[0];
    int flag = 1, res = 0;
    for (int i = 1; i < n; i ++ )
    {
        if (b[i] - a[i] != cnt)
        {
            flag = 0;
            break;
        }
    }
    if (flag == 1)
    {
        if (abs(b[0] - a[0]) > abs(b[0] + a[n - 1]))
        {
            res ++ ;
            cout << abs(b[0] + a[n - 1]) + res;
        }
        else cout << abs(b[0] - a[0]);
    }
    else if (flag == 0)
    {
        res ++ ;
        cnt = b[0] + a[n - 1];
        for (int i = 1; i < n; i ++ )
        {
            if (b[i] + a[n - i - 1] != cnt)
            {
                cout << -1;
                return 0;
            }
        }
        cout << abs(b[0] + a[n - 1]) + res;
    }
    return 0;
}