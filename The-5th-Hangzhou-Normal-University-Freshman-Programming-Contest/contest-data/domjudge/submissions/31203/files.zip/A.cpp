#include <bits/stdc++.h>
using namespace std;
#define fastio ios::sync_with_stdio(false);cin.tie(0); cout.tie(0)
typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e6 + 5;

ll read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){
        if(c=='-')f=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9'){
        x=(x<<3)+(x<<1)+(c^48);
        c=getchar();
    }
    return x;
}

bool cmp(pair<double,int>&a,pair<double,int>&b){
    return a.first>b.first;
}

vector<pair<double,int>>v;

signed main() {
    fastio;

    int m,k,a[6]={0},b[6]={0},x,p;
    double c,e=0,ma=0;
    m=read();
    k=read();
    for(int i=0;i<5;i++){
        a[i]=read();
    }
    for(int i=0;i<5;i++){
        b[i]=read();
        v.push_back(make_pair((double)b[i]/a[i],i));
    }
    sort(v.begin(),v.end(),cmp);
    for(int i=0;i<4;i++){
        p=a[i],e=b[i],ma=max(v[i].first,ma);
        for(int j=i+1;j<5;j++){
            p+=a[v[j].second];
            e+=b[v[j].second];
            x=p/m;
            ma=max(e/(p-x*k),ma);
        }
    }

    printf("%.2lf",ma);


}