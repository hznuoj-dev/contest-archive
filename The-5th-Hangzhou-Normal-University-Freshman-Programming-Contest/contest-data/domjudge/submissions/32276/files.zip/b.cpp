#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
ll a[maxn];
void solve(){
	ll n,m,b;
	cin>>n>>m>>b;
	ll nn=n;
	while(nn>0){
		nn-=m;
	}
	nn+=m;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	ll nowsum=0,ans=0;
	for(int i=1;i<=nn;i++){
		nowsum+=a[i];
	}
	for(int i=nn+1;i<=n;i++){
		//cout<<i<<"\n";
		if(nowsum>b){
			ans+=b;
			nowsum-=b;
		}
		else{
			ans+=nowsum;
			nowsum=0;
		}
		for(int j=i;j<=i+m-1;j++){
			nowsum+=a[j];
		}
		i=i+m-1;
	}
		if(nowsum>b){
			ans+=b;
			nowsum-=b;
		}
		else{
			ans+=nowsum;
			nowsum=0;
		}
		cout<<ans<<"\n";	
}
int main(){
	ios::sync_with_stdio(false);
	int T=1;
	//cin>>T;
	while(T--) solve();
}
/*
5 2 10
5 9 3 1 8

6 2 10
20 1 1 1 1 5
*/
