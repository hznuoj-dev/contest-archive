/**
 * HELLO WORLD
 * Author: ErodeesFleurs
**/

#include<bits/stdc++.h>

using namespace std;

#define quick ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug(a) cout<<#a<<"="<<a<<endl;
#define mm memset
#define rep(i,a,n) for (int i=a;i<n;i++)
#define per(i,a,n) for (int i=n-1;i>=a;i--)
#define llrep(i,a,n) for (ll i=a;i<n;i++)
#define llper(i,a,n) for (ll i=n-1;i>=a;i--)
#define pb push_back
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second
#define mod(x) ((x)%MOD)

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> PII;
typedef pair<ll,ll> PLL;

const int INF = 0x3f3f3f3f;
const ll L_INF=9223372036854775807;
const int MOD = 1e9+7;
const int NMAX = 500500;
const double eps = 1e-9;

ll gcd(ll a,ll b){return b==0?a:gcd(b,a%b);}
ll lcm(ll a,ll b){return a/gcd(a,b)*b;}
ll qmul(ll a,ll b){ll r=0;while(b){if(b&1)r=(r+a)%MOD;b>>=1;a=(a+a)%MOD;}return r;}
ll qpow(ll a,ll n){ll r=1;while(n){if(n&1)r=(r*a)%MOD;n>>=1;a=(a*a)%MOD;}return r;}
ll qpow(ll a,ll n,ll p){ll r=1;while(n){if(n&1)r=(r*a)%p;n>>=1;a=(a*a)%p;}return r;}
void exgcd(ll a,ll b,ll& d,ll& x,ll& y){if(!b) { d = a; x = 1; y = 0; }else{ exgcd(b, a%b, d, y, x); y -= x*(a/b); }}
ll inv(ll a, ll p){ll d,x,y;exgcd(a,p,d,x,y);return d == 1 ? (x+p)%p : -1;}

//CODE HERE//
ll n,m,k;
vector<ll>a(5);
vector<ll>b(5);

double ans=0;

void dfs(ll p,ll c,ll v){
	if(p>=5){
		if(c>=m)c-=k;
		ans=max(ans,1.0*v/c);
		return ;
	}
	rep(i,p+1,6){
		dfs(i,c+a[p],v+b[p]);
	}
}

void solve(){
	cin>>m>>k;
	rep(i,0,5)cin>>a[i];
	rep(i,0,5)cin>>b[i];
	rep(i,0,5){
		dfs(i,0,0);
	}
	printf("%.2lf",ans);
}

int main(){
    quick;
    int t=1;
//    cin>>t;
    while(t--)solve();
	return 0;
}
/*
5 3
1 2 4 4 2
2 2 1 2 4

*/
