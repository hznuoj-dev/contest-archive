#include <bits/stdc++.h>
#define maxn 200100
#define int long long
using namespace std;
map<pair<int,int>,int>e;
unordered_map<int,int>num;
void solve(){
	unordered_map<int,int>pos;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n,q,ans=0;  cin >> n;
	for(int i=1;i<n;++i){
		int u,v,w;
		cin >> u >> v >> w;
		e[{u,v}]=w;
		//e[{v,u}]=w;
	}
	for(auto u:e){
		ans=ans^u.second;
		num[u.first.first]++,num[u.first.second]++;
	}
	for(auto u:e){
		if(num[u.first.first]>=2&&num[u.first.second]>=2)  ans=ans^u.second;
	}
	cin >> q;
	while(q--){
		int x,y;
		cin >> x >> y;
		cout << ans << '\n';
	}
    return 0;
}