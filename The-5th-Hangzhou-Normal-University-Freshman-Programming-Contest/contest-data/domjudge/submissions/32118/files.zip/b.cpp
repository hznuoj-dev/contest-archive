#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
int a[maxn],num[maxn],b[maxn];
void solve(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b+1,b+1+n);
	if(n%2){
		int flag=b[(n+1)/2];
		int flagl=0,flagr=0;
		for(int j=1;j<=n;j++){
			if(flag>a[j]) flagl++;
			if(flag<a[j]) flagr++;
			if(flagr>flagl){
				cout<<0<<"\n";
				return;
			}
		}		
		if(flagl==flagr){
			cout<<1<<"\n";
			return;
		}
	}
	else{
		int midl=n/2,midr=n/2+1;
		if(b[midl]==b[midr]){
			int res=b[midl];
			int flagl=0,flagr=0;
			for(int j=1;j<=n;j++){
				if(res>a[j]) flagl++;
				if(res<a[j]) flagr++;
				if(flagr>flagl){
					cout<<0<<"\n";
					return;
				}
			}
			if(flagl==flagr){
				cout<<1<<"\n";
				return;
			}
		}
		else{
			if(b[midr]-b[midl]<=1){
				cout<<0<<"\n";
				return;
			}
			int res=b[midl]+1;
			int flagl=0,flagr=0;
			for(int j=1;j<=n;j++){
				if(res>a[j]) flagl++;
				if(res<a[j]) flagr++;
				if(flagr>flagl){
					cout<<0<<"\n";
					return;
				}
			}
			if(flagl==flagr){
				cout<<b[midr]-b[midl]-1<<"\n";
				return;
			}			
		}
	}
}
int main(){
	ios::sync_with_stdio(false);
	int T=1;
	//cin>>T;
	while(T--) solve();
}
/*
4
4 10 5 10
*/
