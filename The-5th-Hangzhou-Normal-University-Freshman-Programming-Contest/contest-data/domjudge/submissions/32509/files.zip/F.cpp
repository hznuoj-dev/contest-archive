#include <bits/stdc++.h>
#define int ll
using namespace std;
using ll = long long;
using ull = unsigned long long;
struct edge {
	int to;
	int v;
	edge(int _to, int _v):to(_to), v(_v) {}
};

vector<edge>e[200005];
int ans[200005];
int son[200005];

void init_ans(int i){
	for(auto x : e[i]){
		int n = son[x.to]+1;
//		cout<<x.v<<' '<<n<<'\n';
		if(n%2==1){
			ans[1] ^= x.v;
		}
		init_ans(x.to);
	}
}

int init_son(int i) {
	if(e[i].empty())return son[i] = 0;
	else {
		for(auto const &x:e[i]) {
			son[i] += init_son(x.to)+1;
		}
	}
	return son[i];
}

void dfs(int f, int s, int v){
	int add = son[f] - son[s] - 1;
	int del = son[s];
//	if(s==3)cout<<add<<' '<<del<<'\n';
	int n = abs(add-del);
	if(n%2==1)ans[s] = ans[f]^v;
	else ans[s] = ans[f];
	for(auto x:e[s]){
		dfs(s,x.to,x.v);
	}
}

void solve() {
	int n;
	cin>>n;
	for(int i = 1; i<=n-1; i++) {
		int u,v,w;
		cin>>u>>v>>w;
		if(u>v)swap(u,v);
		e[u].emplace_back(edge(v,w));
	}
	int q;
	cin>>q;
	init_son(1);
	init_ans(1);
//	cout<<ans[1]<<'\n';
//	for(int i = 1; i<=n; i++)cout<<son[i]<<'\n';
	for(auto x:e[1]){
		dfs(1,x.to,x.v);
	}
//	for(int i = 1;i<=n;i++) cout<<ans[i]<<'\n';
	for(int i = 1;i<=q;i++){
		int u,x;
		cin>>u>>x;
		int a = ans[u];
		if(n%2==0)cout<<a<<'\n';
		else cout<<(a^x^ans[1])<<'\n';
	}
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}

