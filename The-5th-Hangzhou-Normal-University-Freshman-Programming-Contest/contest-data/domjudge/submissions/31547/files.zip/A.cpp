#include<bits/stdc++.h>

using namespace std;

const int N = 200005;

int a[N];
int b[N];

int q[N],top;

bool com(int a,int b){
	return a<b;
}

void solve(){
	int n;
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i];
		b[i] = a[i];
	}
	sort(b+1,b+1+n,com);
	if(n%2){
		top = 0;
		int x = b[n/2+1];
		int flag = 0;
		for(int i=1;i<=n;++i){
			if(a[i]<x){
				top++;
			}else if(a[i] > x){
				if(top == 0){
					flag = 1;
					break;
				}else{
					top--;
				}
			}
		}
		if(top) flag = 1;
		if(flag == 1){
			cout<<"0";
			return ;
		}else{
			cout<<"1";
			return ;
		}
	}else{
		top = 0;
		int flag = 0;
		int x = b[n/2]+1;
		if(abs(b[n/2] - b[n/2+1]) == 1){
			cout<<"0";
			return ;
		}
		if(b[n/2] == b[n/2+1]){
			x = b[n/2];
//			cout<<"!!!";
		}
		for(int i=1;i<=n;++i){
			if(a[i]<x){
				top++;
			}else if(a[i] > x){
				if(top == 0){
					flag = 1;
					break;
				}
				top--;
			}
		}
		if(top) flag = 1;
		
		if(flag == 1){
			cout<<"0";
			return ;
		}else{
			if(b[n/2] == b[n/2+1]){
				cout<<"1";
				return ;
			}else{
				cout<<b[n/2+1]-b[n/2]-1;
				return ;
			}
		}
		
	}
}

int main(){
	cin.sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
