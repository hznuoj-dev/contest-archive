#include <bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
#define rep(a, b, c) for(int (a)=(b);(a)<=(c);(a)++)
#define per(a, b, c) for(int (a)=(b);(a)>=(c);(a)--)
#define mset(var, val) memset(var,val,sizeof(var))
#define ll long long
#define int ll
#define itn int
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pb push_back
#define endl "\n"
#define pii pair<int,int>
#define pll pair<ll,ll>
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 2e5 + 5;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-8;
const double pi = acos(-1.0);

int a[N],b[N],c[N];

void solve() {
    int n;
	cin>>n;
	rep(i,1,n){
		cin>>a[i];
		c[i]=-a[i];
	}
	rep(i,1,n){
		cin>>b[i];
	}
	sort(b+1,b+1+n);
	sort(a+1,a+1+n);
	sort(c+1,c+1+n);
	int x=a[1]-b[1];
	int xx=c[1]-b[1];
	int ans1=abs(x),ans2=abs(xx)+1;
	rep(i,1,n){
		if(a[i]-b[i]!=x){
			ans1=-1;
			break;
		}
	}
	rep(i,1,n){
		if(c[i]-b[i]!=xx){
			ans2=-1;
		}
	}
	if(ans1==-1 && ans2==-1){
		cout<<-1<<endl;
	}else if(ans1==-1 || ans2==-1){
		cout<<max(ans1,ans2)<<endl;
	}else{
		cout<<min(ans1,ans2)<<endl;
	}
}

/*
3
1 2 3
4 5 6
4
-1 0 1 2
1 0 -1 -2
1
-1000000000
1000000000
*/

signed main() {
    IOS;
    int t = 1;
    // cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
