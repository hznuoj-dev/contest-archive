#include <bits/stdc++.h> 

using i64 = long long;

struct node {
	double x, y;
};

bool cmp(node a, node b)
{
	return a.y / a.x > b.y / b.x;
}

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int m, k;
	std::vector<node> a(5);
	double maxn = 0.00, sum = 0, cnt = 0;
	
	std::cin >> m >> k;
	for (int i = 0; i < 5; ++i)
	std::cin >> a[i].x;
	for (int i = 0; i < 5; ++i)
	std::cin >> a[i].y;
	std::sort(a.begin(), a.end(), cmp);
	for (int i = 0; i < 5; ++i) {
		sum += a[i].y;
		cnt += a[i].x;
		if (cnt >= m)
		cnt -= k;
		if (sum / cnt > maxn)
		maxn = sum / cnt;
	}
	std::cout << std::setiosflags(std::ios::fixed) << std::setprecision(2) << maxn;
	
	return 0;
} 
