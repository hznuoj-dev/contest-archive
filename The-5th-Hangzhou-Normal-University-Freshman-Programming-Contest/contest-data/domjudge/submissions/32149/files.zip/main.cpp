#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;
const int P = 998244353;

void solve() {
    int n, k;
    std::cin >> n >> k;
    std::vector<int>a(n + 3);
    for(int i = 1;i <= n;i++) std::cin >> a[i];
    std::vector<bool>st(n + 3);
    if(n - k == 1){
        std::cout << "-1\n";
        return;
    }
    int num = 0;
    for(int i = 1;i <= n;i++) {
        if(i == a[i]) num++;
    }

    if(num < k) {
        int need = k - num;
        std::vector<int>b;
        for(int i = 1;i <= n;i++) {
            if(st[i]) continue;
            int start = i, ne = a[i], cnt = 1;
            if(ne != start) {
                st[ne] = true;
                cnt++;
                ne = a[ne];
            }
            if(cnt > 1)b.push_back(cnt);
        }
        std::sort(b.begin(), b.end());
        int ans = 0;
        for(auto v : b) {
            if(v <= need) {
                ans += v - 1;
                need -= v;
            } else {
                ans += need;
                need = 0;
            }
            if(!need)break;
        }
        std::cout << ans << '\n';
    } else {
        int need = num - k;
        int ans = (need + 1) >> 1;
        std::cout << ans << '\n';
    }
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    int T = 1;
//    std::cin >> T;
    while(T--) {
        solve();
    }
}