#include <bits/stdc++.h>
#define maxn 200100
using namespace std;
int a[maxn],b[maxn];
unordered_map<int,int>num;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n,l,r;  cin >> n;
	for(int i=1;i<=n;++i)  cin >> a[i],b[i]=a[i],num[a[i]]++;
	sort(b+1,b+n+1);
	if(n&1){
		l=r=b[(n+1)/2];
		if(num[l]%2==0)  {cout << 0 << '\n';return 0;}
	}
	else{
		l=b[n/2],r=b[n/2+1];
		if(l==r&&num[l]&1)  {cout << 0 << '\n';return 0;}
		else if(r==l+1)  {cout << 0 << '\n';return 0;}
		else if(l!=r)  r--,l++;
	}
	int tmp=0;
	for(int i=1;i<=n;++i){
		if(a[i]<l)  ++tmp;
		else if(a[i]>r) --tmp;
		if(tmp<0)  {cout << 0 << '\n';return 0;}
	}
	cout << r-l+1 << '\n';
    return 0;
}