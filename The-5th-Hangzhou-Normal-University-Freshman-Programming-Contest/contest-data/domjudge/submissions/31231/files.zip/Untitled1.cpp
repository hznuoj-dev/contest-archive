#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
const int N=2e5+5;
#define ll long long
#define ull unsigned long long
ll qpow(ll a,ll b,ll p)
{
	ll sum=1;
	while(b)
	{
		if(b&1)
		{
			sum=sum*a%p;
		}
		b>>=1;
		a=a*a%p;
	}
	return sum;
}
#define int ll
int a[N],b[N];
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
     int n;
     cin>>n;
    for(int i=1;i<=n;i++)
    cin>>a[i];
    for(int i=1;i<=n;i++)
    cin>>b[i];
    sort(a+1,a+1+n);
    sort(b+1,b+1+n);
    int flag=0;
    int tem=a[1]-b[1];
    for(int i=2;i<=n;i++)
    {
    	if(a[i]-b[i]!=tem)
    	break;
    	if(n==i)
    	flag=1;
	}
	tem=a[1]+b[1];
	for(int i=2;i<=n;i++)
	{
		if(a[i]+b[i]!=tem)
		break;
		if(n==i)
		flag=2;
	}
	if(flag==0)
	cout<<-1;
	else
	{
		if(flag==1)
		{
			cout<<abs(a[1]-b[1]);
		}
		else
		cout<<1+abs(abs(a[1])-abs(b[1]));
	}
}