#include<bits/stdc++.h>
using namespace std;
int main()
{
	std::ios::sync_with_stdio(false);
	int t,n,i,j,k;
	cin>>t;
	for(i=1;i<=t;i++)
	{
		cin>>n;
		if(n<=11)
		{
			cout<<"No Solution\n";
		}
		else
		{
			switch(n%7)
			{
				case 0:
					k=(n-14)/7;
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"1+6=";
					cout<<"1\n";
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"1+0=";
					cout<<"1\n";
					break;
				case 1:
					k=(n-15)/7;
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"9-7=";
					cout<<"7\n";
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"8-7=";
					cout<<"1\n";
					break;
				case 2:
					k=(n-16)/7;
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"7+7=";
					cout<<"9\n";
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"1+7=";
					cout<<"8\n";
					break;
				case 3:
					k=(n-17)/7;
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"3+1=";
					cout<<"6\n";
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"5+1=";
					cout<<"6\n";
					break;
				case 4:
					k=(n-18)/7;
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"11-3=";
					cout<<"9\n";
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"11-2=";
					cout<<"9\n";
					break;
				case 5:
					k=(n-12)/7;
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"3-1=";
					cout<<"1\n";
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"2-1=";
					cout<<"1\n";
					break;
				case 6:
					k=(n-13)/7;
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"1+1=";
					cout<<"3\n";
					for(j=1;j<=k;j++)
					{
						cout<<"1-1+";
					}
					cout<<"1+1=";
					cout<<"2\n";
					break;
			}
		}
	}	
	return 0;
}
