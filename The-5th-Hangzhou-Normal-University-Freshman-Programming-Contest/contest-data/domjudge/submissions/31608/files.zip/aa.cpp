#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int ll
const int N=2e5+7,mod=1e9+7;
int n,a[N],b[N];
void solve(){
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	int tr=1;
	for(int i=1;i<=n;i++){
		if(a[i]!=b[i]){
			tr=0;
			break;
		}
	}
	if(tr){
		cout<<"0\n";
		return;
	}
	reverse(a+1,a+1+n);
	for(int i=1;i<=n;i++)a[i]=-a[i];
	for(int i=1;i<=n;i++){
		if(b[i]-a[i]!=b[1]-a[1]){
			cout<<"-1\n";
			return;
		}
	}
	cout<<(abs(b[1]-a[1])+1)<<'\n';
}
signed main(){
	int t=1;
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cin>>t;
	while(t--)solve();
	return 0;
}
