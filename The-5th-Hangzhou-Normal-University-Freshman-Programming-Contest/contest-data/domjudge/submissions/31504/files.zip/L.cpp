#include<iostream>
#include<algorithm>
#include<cstring>

using namespace std;

const int N = 210;
typedef long long LL;

int k, m;
struct Mooncake
{
    int price;
    int com;

    bool operator < (const Mooncake &B)const
    {
        if(com != B.com) return com > B.com;
        return price < B.price;
    }

}a[10];

int main()
{
    cin >> m >> k;
    for(int i = 0; i < 5; i++)
        cin >> a[i].price;
    for(int i = 0; i < 5; i++)
        cin >> a[i].com;
    sort(a, a + 5);

    
    double p = 0, co = 0;
    double res = 0;

    for(int i = 0, flag = 0; i < 5; i++)
    {
        double co1 = co + a[i].com;
        double p1 = p + a[i].price;
        if(p1 >= m && !flag) 
        {
            p1 -= k;
            flag = 1;
        }
        if(res <= co1 / p1)
        {
            res = co1 / p1;
            p = p1, co = co1;
        }
    }
    printf("%.2lf", res);

    return 0;
}

