#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N],b[N],de[N];
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    bool st= false;
    int has_different=0;
    int delta=-2e9;
    for (int i=0;i<n;i++) cin >> a[i];
    for (int i=0;i<n;i++)
    {
        cin >> b[i];
        delta= max(delta,a[i]-b[i]);
        de[i]=a[i]-b[i];
        if(i>0 && de[i]!=de[i-1]) st= true;
    }
    if(!st) cout << -de[0];
    else cout << -1;
    return 0;
}
