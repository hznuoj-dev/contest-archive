#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[200001]={0},b[200001]={0},c[200001]={0},da[200001]={0},db[200001]={0},dc[200001]={0};
int main() {
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	bool fb=false,fc=false;
	int n;
	cin>>n;
	for(int i=1;i<=n;i++) 
		cin>>a[i];
	for(int i=1;i<=n;i++) 
		cin>>b[i],c[i]=-b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	for(int i=2;i<=n;i++) {
		bool f=false,f1=true,f2=true;
		da[i]=a[i]-a[i-1],db[i]=b[i]-b[i-1],dc[i]=c[i]-c[i-1];
		//cout<<a[i]<<' '<<b[i]<<' '<<da[i]<<' '<<db[i]<<'\n';//
		if(da[i]==db[i]&&!fb)f=true,f1=false;
		if(da[i]==dc[i]&&!fc)f=true,f2=false;
		if(f1&&da[i]+db[i]==0&&da[i]!=0)f=true,fb=true;
		if(f2&&da[i]+dc[i]==0&&da[i]!=0)f=true,fc=true;
		if(!f) {
			cout<<-1;
			return 0;
		}
	}
	ll cntb=0,cntc=1;
	if(fb)cntb+=(abs(a[1]+b[1])+1);
	else cntb+=abs(b[1]-a[1]);
	if(fc)cntc+=(abs(a[1]+c[1])+1);
	else cntc+=abs(c[1]-a[1]);
	cout<<min(cntb,cntc);
}