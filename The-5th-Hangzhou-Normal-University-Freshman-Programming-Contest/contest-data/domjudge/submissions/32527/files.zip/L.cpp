#include<cstdio>
#include<algorithm>
using namespace std;
typedef double dbl;
dbl ans;
int a[6],b[6],p[6],m,k;
inline const dbl calc(int *p,int n)
{
    int cost(0),value(0);
    for (int i(1);i<=k;i++)cost+=a[p[i]];
    if (cost>m)cost-=k;
    for (int i(1);i<=k;i++)value+=b[p[i]];
    return static_cast<dbl>(value)/cost;
}
int main()
{
    scanf("%d%d",&m,&k);
    for (int i(1);i<=5;i++)scanf("%d",&a[i]);
    for (int i(1);i<=5;i++)scanf("%d",&b[i]);
    for (int i(1);i<=5;i++)p[i]=i;
    for (int i(1);i<=5;i++)ans=max(ans,calc(p,i));
    while (next_permutation(p+1,p+5+1))
        for (int i(1);i<=5;i++)ans=max(ans,calc(p,i));
    printf("%.2lf\n",ans);
    return 0;
}