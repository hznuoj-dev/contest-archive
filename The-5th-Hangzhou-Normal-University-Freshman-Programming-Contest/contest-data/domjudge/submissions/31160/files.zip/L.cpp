#include <bits/stdc++.h>
#define endl '\n'
#define int long long
#define x first
#define y second

using namespace std;
typedef pair<int,int> PII;
int T;
int n, m;
double ans = 0;
string s;

struct mo{
    int p, g;
}a[2003];

void dfs(int i, int good, int p) {
    if(i == 5) {
        ans = max(ans, (double)good / (p - p / n * m));
        return;
    }

    dfs(i+1,good,p);
    dfs(i+1,good+a[i].g,p+a[i].p);
}

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0);

    cin >> n >> m;
    for(int i = 0 ; i < 5 ; i ++) cin >> a[i].p;
    for(int i = 0 ; i < 5 ; i ++) cin >> a[i].g;

    dfs(0,0,0);

    printf("%.2lf", ans);

}

