#include <bits/stdc++.h>
using namespace std;
const int M=200005;
int now,nest[M],head[M],to[M],w[M],n,a[M];
void add(int ui,int vi,int wi){
	nest[++now]=head[ui];
	head[ui]=now;
	to[now]=vi;
	w[now]=wi;
}
void dfs(int u,int fa,int yh){
	a[u]=yh;
	for(int i=head[u];i;i=nest[i]){
		int adj=to[i];
		if(adj==fa) continue;
		dfs(adj,u,yh^w[i]);
	}
}
int main(){
	cin>>n;
	for(int i=1;i<n;i++){
		int ui,vi,wi;
		scanf("%d%d%d",&ui,&vi,&wi);
		add(ui,vi,wi);
		add(vi,ui,wi);
	}
	dfs(1,0,0);
	long long ans=0;
	for(int i=1;i<=n;i++){
		ans^=(1ll*a[i]);
	}
	int t;
	cin>>t;
	while(t--){
		int u,s;
		scanf("%d%d",&u,&s);
		long long tmp=a[u]^s;
		if(n%2==0){
			printf("%lld\n",ans);
		}
		else{
			printf("%lld\n",ans^tmp);
		}
	}
	return 0;
}
