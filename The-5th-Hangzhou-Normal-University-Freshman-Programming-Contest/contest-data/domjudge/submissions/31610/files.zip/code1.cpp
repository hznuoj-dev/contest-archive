#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IO ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
const int N = 2e5 + 5;
int n, a[N], k[N];


signed main(){
    IO;
    cin >>n;
    for(int i = 1;i <= n;i++)
        cin >> a[i], k[i] = a[i];

    if(n & 1){
        cout << 0;
        return 0;
    }

    int p, ans;
    sort(a+1, a+1+n);
    if(a[n/2] == a[(n/2)+1]){
        p = a[n/2];
        int t = 0;
        for(int i = 1;i <= n;i++) if(a[i] == p) t++;
        if(t & 1){
            cout << 0;
            return 0;
        }
        ans = 1;
    }else if(a[n/2] + 1 == a[(n/2)+1]){
        cout << 0;
        return 0;
    }else   
        p = a[n/2] + 1, ans = a[(n/2)+1] - a[n/2] - 1;


    int left = 0, right = 0;
    for(int i = 1;i <= n;i++){
        if(k[i] < p) left++;
        else if(k[i] > p){
            if(++right > left){
                cout << 0;
                return 0;
            }
        }
    }

    
    cout << ans;

    return 0;
}