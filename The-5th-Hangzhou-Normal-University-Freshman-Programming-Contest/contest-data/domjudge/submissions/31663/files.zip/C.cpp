#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

int read() {
    int x = 0, f = 1; char c = getchar();
    while(c < '0' || c > '9') c == '-' ? f = -1: 0, c = getchar();
	while(c >= '0' && c <= '9') x = (x << 1) + (x << 3) + (c ^ '0'), c = getchar();
    return x * f;
}

int numCnt[] = {6, 2, 5, 5, 4, 5, 6, 3, 7, 6}; // 0-9
int TNum[] = {8, 7, -1, 9, -1, 6, 8, -1, -1, 8}; // ����һ��֮�� 

int L1[150], L2[150], R[150];
int LT1[150], LT2[150], RT[150];

int getCnt(int x) {
    if(x == 0) return numCnt[0];
    
    int r = 0;
    while(x) {
        r += numCnt[x % 10];
        x /= 10;
    }
    
    return r;
}

signed main() {
    
//    int stk[1000], top = 0;
    for(int i = 0; i <= 9; ++i) {
        for(int j = i; j <= 9; ++j) {
            if(i + j > 9) break;
            if(i == 2 && j == 2) continue;
            
            int s = (getCnt(i) + getCnt(j) + getCnt(i + j));
            
            if(!L1[s] || !L2[s]) {
                L1[s] = LT1[s] = i, L2[s] = LT2[s] = j, R[s] = RT[s] = i + j;
                if(TNum[L2[s]] != -1) LT2[s] = TNum[L2[s]];
                else if(TNum[L1[s]] != -1) LT1[s] = TNum[L1[s]];
                else RT[s] = TNum[RT[s]];
            }
        }
    }
//    for(int i = 9; i <= 17; ++i) {
//        cout << i << ' ' << L1[i] << '+' << L2[i] << '=' << R[i] << ' ' << LT1[i] << '-' << LT2[i] << '=' << RT[i] << ' ' << endl;
//    }
    
    int t = read();
    while(t--) {
        int n = read();
        if(n < 9 + 4) puts("No Solution");
        else {
            n -= 4;
            
            string s1, s2;
            int k = n / 9, d = n % 9;
            --k, d += 9;
            
            for(int i = 1; i <= k; ++i) s2 += (char)(L1[9] + '0');
            s2 += (char)(L1[d] + '0');
            s2 += '+';
            for(int i = 1; i <= k; ++i) s2 += (char)(L2[9] + '0');
            s2 += (char)(L2[d] + '0');
            s2 += '=';
            for(int i = 1; i <= k; ++i) s2 += (char)(R[9] + '0');
            s2 += (char)(R[d] + '0');
            
            for(int i = 1; i <= k; ++i) s1 += (char)(LT1[9] + '0');
            s1 += (char)(LT1[d] + '0');
            s1 += '-';
            for(int i = 1; i <= k; ++i) s1 += (char)(LT2[9] + '0');
            s1 += (char)(LT2[d] + '0');
            s1 += '=';
            for(int i = 1; i <= k; ++i) s1 += (char)(RT[9] + '0');
            s1 += (char)(RT[d] + '0');
            
            
            cout << s1 << endl << s2 << endl;
        }
    }
    return 0;
}

