#include<bits/stdc++.h>
#define rg register
#define il inline
typedef long long ll;
using namespace std;
ll mod = 1e9+7;
inline ll read() {
	ll ans = 0;
	char last = ' ', ch = getchar();
	while (ch < '0' || ch > '9') last = ch, ch = getchar();
	while (ch >= '0' && ch <= '9') ans = ans * 10 + ch - '0', ch = getchar();
	if (last == '-') return -ans;
	return ans;
}
il ll ksm(ll b,ll k){
	ll res=1;
	while(k){
		if(k&1) res=1ll*res*b%mod;
		b=1ll*b*b%mod;k>>=1;
	}
	return res;
}
int a[200020];
int b[200020];
int c[3000030];
int s[2000040];
int v[2000020];
int x[2000020];
int n;
bool ck(int k){
	stack<int>stk;
	for(int i=1;i<=n;i++){
		if(a[i]<k)stk.push(1);
		if(a[i]>k){
			if(!stk.empty()){
				stk.pop();
			}
			else return 0;
		}
	}
	return stk.empty();
}
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		c[a[i]]++;
		b[i]=a[i];
	}
	sort(b+1,b+n+1);
	if(n%2){
		puts("0");
		return 0;
	}
	else{
		for(int i=1;i<=2e5+5;i++){
			s[i]=s[i-1]+c[i];
		}
		ll ans=0;
		for(int i=1;i<=2e5+5;i++){
			int l=s[i-1];
			int r=n-s[i];
			if(l==r){
				if(!v[l])v[l]=1,x[l]=ck(i);
				ans+=x[l];
			}
		}
		if(ans)cout<<ans<<endl;
		else puts("0");
	}
}

