#include <bits/stdc++.h>
#define endl '\n'
#define int long long
#define x first
#define y second

using namespace std;
typedef pair<int,int> PII;
int T;
int n, m;
string s;
const int N = 2e5+10;
int a[N+10], tr[N+10];

int lowbit(int x) {
    return x & -x;
}

void add(int x, int c) {
    for(int i = x ; i <= N ; i += lowbit(i)) {
        tr[i] += c;
    }
}

int qry(int x) {
    int res = 0;
    for(int i = x; i ; i -= lowbit(i)) res += tr[i];
    return res;
}

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);

    cin >> n;
    for(int i = 1 ; i <= n ; i ++) cin >> a[i];
    for(int i = 1 ; i <= n ; i ++) add(a[i], 1);

    int l = -1, r = 0;
    for(int i = 1 ; i <= 200000 ; i ++) {
        int L = qry(i-1), R = n - qry(i);
        //cout << L << ' ' << R << endl;
        if(L != R) continue;
        if(l == -1) l = i;
        r = i;
    }
    bool ok = false;
    int x = 0, y = 0, k = l;
    for(int i = 1 ; i <= n ; i ++) {
        if(a[i] < k) x ++;
        if(a[i] > k) y ++;
        if(x < y) ok = true;
    }
    if(ok) cout << 0 << endl;
    else cout << r - l + 1 << endl;
}
