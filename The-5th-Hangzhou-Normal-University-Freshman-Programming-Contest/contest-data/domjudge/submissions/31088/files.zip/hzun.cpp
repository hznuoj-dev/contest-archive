# include<bits/stdc++.h>
# include<cstdio>
using namespace std;
# define ll long long
int main(){
	ll n,mind = 0,maxd = 200001;
	cin>>n;
	ll a[n];
	for(int i=0;i<n;i++){
		cin>>a[i];
		mind = min(mind,a[i]);
		maxd = max(maxd,a[i]);
	}
	ll  sum = 0;
	for(int i=mind;i<=maxd;i++){
		ll k=0;
		for(int j=0;j<n;j++){
			if(a[j]<i) k++;
			else if(a[j]>i) k--;
			if(k<0) break;
		}
		if(k==0) sum++;
	}
	cout<<sum;
	return 0;
}
