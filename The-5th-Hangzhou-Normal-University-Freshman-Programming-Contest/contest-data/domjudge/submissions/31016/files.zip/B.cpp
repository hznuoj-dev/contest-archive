#include<iostream>
#include<algorithm>
#include<cstring>
#include<map>

using namespace std;

const int N = 200010;
typedef long long LL;

map<int, int> mp;
int a[N], b[N];
int n;

int main()
{
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    for(int i = 0; i < n; i++)
        scanf("%d", &b[i]);

    sort(a, a + n), sort(b, b + n);

    for(int i = 0; i < n; i++)
        mp[b[i] - a[i]]++;

    if(mp.size() > 1) printf("-1\n");
    else printf("%d", abs(a[0] - b[0]));

    return 0;
}

