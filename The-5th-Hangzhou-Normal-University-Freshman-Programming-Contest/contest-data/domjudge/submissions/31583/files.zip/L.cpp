#include<bits/stdc++.h>
#define moder (long long)998244353
using namespace std;
long long binpow(long long a, long long b) {
  long long res = 1;
  while (b > 0) {
    if (b & 1) res = res * a % moder;
    a = a * a % moder;
    b >>= 1;
  }
  return res % moder;
}
long long C(long long x,long long y){
	if(y>x){
		return 0;
	}
	long long tim=1;
	for(int i=x;i>=x-y+1;i--){
		tim*=i;
		tim%=moder;
	}
	for(int i=1;i<=y;i++){
		tim*=binpow(i,moder-2);
		tim%=moder;
	}
	return tim%moder;
}
bool comp(long long x,long long y){
	return x<y;;
}
vector<int> who;
int m,k;
vector<int> a,b;
double ans=-1;
void dfs(int now){
	if(now==6){
		double sum1=0,sum2=0;
		for(int i=0;i<5;i++){
			sum1+=who[i]*b[i];
			sum2+=who[i]*a[i];
		}
		if(sum2>=m)	sum2-=k;
		ans=max(ans,sum1/sum2);
		return ;
	}
	for(int i=0;i<=1;i++){
		who.push_back(i);
		dfs(now+1);
		who.pop_back();
	}
}
inline void solve()
{
	cin>>m>>k;
	int num;
	for(int i=0;i<5;i++){
		cin>>num;
		a.push_back(num);
	}
	for(int i=0;i<5;i++){
		cin>>num;
		b.push_back(num);
	}
	dfs(1);
	printf("%.2f",ans);
}

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int tt;
	//cin>>tt;
	//while(tt--)
	solve();
}