#include<bits/stdc++.h>
#define rg register
#define il inline
typedef long long ll;
using namespace std;
ll mod = 1e9+7;
inline ll read() {
	ll ans = 0;
	char last = ' ', ch = getchar();
	while (ch < '0' || ch > '9') last = ch, ch = getchar();
	while (ch >= '0' && ch <= '9') ans = ans * 10 + ch - '0', ch = getchar();
	if (last == '-') return -ans;
	return ans;
}
il ll ksm(ll b,ll k){
	ll res=1;
	while(k){
		if(k&1) res=1ll*res*b%mod;
		b=1ll*b*b%mod;k>>=1;
	}
	return res;
}
int a[30];
int b[30];
int main(){
	int m,k;
	cin>>m>>k;
	int idx=1<<5;
	for(int i=1;i<=5;i++)cin>>a[i];
	for(int i=1;i<=5;i++)cin>>b[i];
	double ans=-1;
	while(--idx){
		double s=0;
		int v=0;
		int tt=idx;int i=1;
		while(tt){
			
			if(tt%2){
				s+=b[i];
				v+=a[i];
			}
			tt/=2;
			i++;
		}
		if(v>=m)v-=k;
		if(ans<s/v){

			ans=s/(v);
		}
//		ans=max(ans,);
	}
	printf("%.2lf",ans);
}

