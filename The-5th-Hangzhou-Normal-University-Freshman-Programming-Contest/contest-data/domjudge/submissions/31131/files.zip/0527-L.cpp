#include<bits/stdc++.h>
#define close std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
typedef long long ll;
const ll MAXN = 3e5+7;
const ll mod = 1e9+7;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
int a[6][2],b[6][2];
ll _power(ll a,int b){ ll ans=1,res=a;while(b){ if(b&1) ans=ans*res%mod;res=res*res%mod;b>>=1;} return ans%mod;}
void solve(){
	int m,k;cin>>m>>k;
	for(int i=1;i<=5;i++){
		cin>>a[i][1];
	}
	double ans=0.0;
	for(int i=1;i<=5;i++) cin>>b[i][1];
	for(int i=0;i<2;i++){
		for(int j=0;j<2;j++){
			for(int x=0;x<2;x++){
				for(int y=0;y<2;y++){
					for(int z=0;z<2;z++){
						int sum=0,tot=0;
						sum=a[1][i]+a[2][j]+a[3][x]+a[4][y]+a[5][z];
						tot=b[1][i]+b[2][j]+b[3][x]+b[4][y]+b[5][z];
						if(sum>=m) sum-=k;
						double tmp=tot*1.0/sum;
						ans=max(ans,tmp);	
					}
				}
			}
		}
	}
	printf("%.2f",ans);
}
signed main(){
	solve();
}
