#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;

int m, k;
int a[10], b[10];
int choose[10];

double best = 0;

void dfs(int i, int cost, int get){
    if (i == 4) {
                // for (int i = 0; i < 5; ++i) cout << choose[i];
                // cout << " " << cost << (cost>=m?"-3":"") << " " << get << endl;
                // if (cost) cout << " " << 1.*get/cost << endl;
        if (cost >= m) cost -= k;
        if (cost) best = max(1.*get/cost, best);
        return ;
    }

    choose[i+1] = 1;
    dfs(i+1, cost+a[i+1], get+b[i+1]);
    choose[i+1] = 0;
    dfs(i+1, cost, get);
}

void solve(){
    cin >> m >> k;

    for (int i = 0; i < 5; ++i) cin >> a[i];
    for (int i = 0; i < 5; ++i) cin >> b[i];

    dfs(-1, 0, 0);

    printf("%.2f", best);

    return ;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T = 1;
    // cin >> T;

    while (T--){
        solve();
    }

    return 0;
}
