#include<bits/stdc++.h>
#define int long long
using namespace std;
int n=5,m,kk,a[200006],b[200006],fz,fm,ans=-1;
signed main(){
	cin >> n;
	for (int i=1;i<=n;++i) cin >> a[i];
	for (int i=1;i<=n;++i) cin >> b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	bool f=true;
	for (int i=2;i<=n;++i) {
		if (b[i]-a[i]!=b[1]-a[1]) f=false;
	}
	if (f) {
		ans=abs(b[1]-a[1]);
	}
	for (int i=1;i<=n;++i) {
		a[i]=-a[i];
	}
	sort(a+1,a+1+n);
	f=true;
	for (int i=2;i<=n;++i) {
		if (b[i]-a[i]!=b[1]-a[1]) f=false;
	}
	if (f) {
		if (ans==-1) ans=abs(b[1]-a[1])+1;
		else ans=min(ans,abs(b[1]-a[1])+1);
	}
	cout << ans;
}
