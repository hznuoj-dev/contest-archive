#include <iostream>
#include <algorithm>
#include <cstring>
#include <map>
#include <vector>
#include <stack>

using namespace std;

int n, m;
long long b;
long long a[200005];
long long s[200005];

void solve()
{
    cin >> n >> m >> b;
    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i];
    }
    for (int i = 1; i <= n; ++i)
    {
        s[i] = s[i - 1] + a[i];
    }
    long long res = 0;
    long long out = 0;
    for (int i = n - m * ((n - 1) / m); i <= n; i += m)
    {
        if (b + out <= s[i])
        {
            out += b;
        }
        else
        {
            out = s[i];
        }
    }
    cout << out;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}