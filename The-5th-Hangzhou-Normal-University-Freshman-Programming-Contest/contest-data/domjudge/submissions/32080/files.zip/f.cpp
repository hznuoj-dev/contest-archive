#include<bits/stdc++.h>
using namespace std;
int main(){
	double a[5],b[5];
    double c[5];
    double d[31];
int m,k;
cin>>m>>k;
for(int i=0;i<5;i++)
cin>>a[i];
for(int i=0;i<5;i++)
cin>>b[i];
for(int i=0;i<5;i++)
c[i]=b[i]/a[i];
double xjb=0,sum=0;
sum=a[0];if(sum>=m) sum=sum-k; d[0]=b[0]/sum;
sum=a[1];if(sum>=m) sum=sum-k; d[1]=b[1]/sum;
sum=a[2];if(sum>=m) sum=sum-k; d[2]=b[2]/sum;
sum=a[3];if(sum>=m) sum=sum-k; d[3]=b[3]/sum;
sum=a[4];if(sum>=m) sum=sum-k; d[4]=b[4]/sum;
sum=a[0]+a[1];if(sum>=m) sum=sum-k; d[5]=(b[0]+b[1])/sum;
sum=a[0]+a[2];if(sum>=m) sum=sum-k; d[6]=(b[0]+b[2])/sum;
sum=a[0]+a[3];if(sum>=m) sum=sum-k; d[7]=(b[0]+b[3])/sum;
sum=a[0]+a[4];if(sum>=m) sum=sum-k; d[8]=(b[0]+b[4])/sum;
sum=a[1]+a[2];if(sum>=m) sum=sum-k; d[9]=(b[1]+b[2])/sum;
sum=a[1]+a[3];if(sum>=m) sum=sum-k; d[10]=(b[1]+b[3])/sum;
sum=a[1]+a[4];if(sum>=m) sum=sum-k; d[11]=(b[1]+b[4])/sum;
sum=a[2]+a[3];if(sum>=m) sum=sum-k; d[12]=(b[2]+b[3])/sum;
sum=a[2]+a[4];if(sum>=m) sum=sum-k; d[13]=(b[2]+b[4])/sum;
sum=a[3]+a[4];if(sum>=m) sum=sum-k; d[14]=(b[3]+b[4])/sum;
sum=a[0]+a[1]+a[2];if(sum>=m) sum=sum-k; d[15]=(b[0]+b[1]+b[2])/sum;
sum=a[0]+a[1]+a[3];if(sum>=m) sum=sum-k; d[16]=(b[0]+b[1]+b[3])/sum;
sum=a[0]+a[1]+a[4];if(sum>=m) sum=sum-k; d[17]=(b[0]+b[1]+b[4])/sum;
sum=a[0]+a[2]+a[3];if(sum>=m) sum=sum-k; d[18]=(b[0]+b[2]+b[3])/sum;
sum=a[0]+a[2]+a[4];if(sum>=m) sum=sum-k; d[19]=(b[0]+b[2]+b[4])/sum;
sum=a[0]+a[3]+a[4];if(sum>=m) sum=sum-k; d[20]=(b[0]+b[3]+b[4])/sum;
sum=a[1]+a[2]+a[3];if(sum>=m) sum=sum-k; d[21]=(b[1]+b[2]+b[3])/sum;
sum=a[1]+a[2]+a[4];if(sum>=m) sum=sum-k; d[22]=(b[1]+b[2]+b[4])/sum;
sum=a[1]+a[3]+a[4];if(sum>=m) sum=sum-k; d[23]=(b[1]+b[3]+b[4])/sum;
sum=a[2]+a[3]+a[4];if(sum>=m) sum=sum-k; d[24]=(b[2]+b[3]+b[4])/sum;
sum=a[0]+a[1]+a[2]+a[3];if(sum>=m) sum=sum-k; d[25]=(b[0]+b[1]+b[2]+b[3])/sum;
sum=a[0]+a[1]+a[2]+a[4];if(sum>=m) sum=sum-k; d[26]=(b[0]+b[1]+b[2]+b[4])/sum;
sum=a[0]+a[1]+a[3]+a[4];if(sum>=m) sum=sum-k; d[27]=(b[0]+b[1]+b[3]+b[4])/sum;
sum=a[0]+a[2]+a[3]+a[4];if(sum>=m) sum=sum-k; d[28]=(b[0]+b[2]+b[3]+b[4])/sum;
sum=a[1]+a[2]+a[3]+a[4];if(sum>=m) sum=sum-k; d[29]=(b[1]+b[2]+b[3]+b[4])/sum;
sum=a[0]+a[1]+a[2]+a[3]+a[4];if(sum>=m) sum=sum-k; d[30]=(b[0]+b[1]+b[2]+b[3]+b[4])/sum;
for(int i=0;i<=30;i++){
	if(d[i]>xjb)
	xjb=d[i];
}
printf("%.2lf",xjb);
	return 0;
} 
