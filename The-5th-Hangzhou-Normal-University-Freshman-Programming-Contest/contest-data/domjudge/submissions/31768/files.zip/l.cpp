#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
int main()
{
    double a[6], b[6], xjb[6] = {0}, max = xjb[1];
    double m ,k, x;
    double ma = 0, mb = 0 ,ma1 = 0, mb1= 0;
    cin >> m >> k;
    for(int i = 1; i <= 5; i++)
    {
        cin >> a[i];
    }
    for(int i = 1; i <= 5; i++)
    {
        cin >> b[i];
        xjb[i] = b[i] / a[i];
    }
    for(int i = 1; i <= 5; i++)
    {
        for(int j = i + 1; j <= 5; j++)
        {
            if(xjb[j] > xjb[i])
            {
                swap(xjb[i],xjb[j]);
                swap(a[i],a[j]);
                swap(b[i],b[j]);
            }
        }
    }
    for(int i = 1; i <= 5,ma < m; i++)
    {
        mb += b[i];
        ma += a[i];
        while(mb >= m)
        {
            ma1 = ma - a[i];
            mb1 = mb - b[i];
            break;
        }
    }
    ma -= k;
    x = mb / ma;
    double x1 = mb1 / ma1;
    if(x > x1)
        printf("%.2lf",x);
    else
        printf("%.2lf",x1);
    return 0;
}