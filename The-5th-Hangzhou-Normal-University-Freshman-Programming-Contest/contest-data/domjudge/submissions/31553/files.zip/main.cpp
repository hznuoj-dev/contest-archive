#include <bits/stdc++.h>
#define eps 1e-8
#define maxn 210
using namespace std;
struct node{
	int a,b;
}s[maxn];
bool cmp(node x,node y){
	return x.b*y.a-y.b*x.a>eps;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    double m,k;
	double ans=-1,sum=0,pri=0;
	cin >> m >> k;
	for(int i=1;i<=5;++i)  cin >> s[i].a;
	for(int i=1;i<=5;++i)  cin >> s[i].b;
	sort(s+1,s+6,cmp);
	for(int i=1;i<=5;++i){
		pri+=1.0*s[i].a;
		sum+=1.0*s[i].b;
		double tmp=pri;
		if(tmp-m>-eps)  tmp-=k;
		ans=max(ans,sum/tmp);
	}
	cout << fixed << setprecision(2) << ans << '\n';
    return 0;
}