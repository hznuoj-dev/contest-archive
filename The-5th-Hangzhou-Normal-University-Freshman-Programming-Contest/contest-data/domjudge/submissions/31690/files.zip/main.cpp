#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
const int N = 2 * 1e5 + 10;
int a[N], b[N], c[N];

int main()
{
    int n;
    cin >> n;
    int i, j, res = 0;
    for(i = 1; i <= n; i++)
    {
        cin >> a[i];
        b[a[i]] ++;
    }
    for(i = 1; i <= N - 10; i++)
    {
        c[i] = c[i - 1] + b[i];
    }
    j = 0;
    i = 0;
    //cout << a[1] << '=' << a[n] << endl;
    if (a[1] > a[n])
    {
        cout << 0 << endl;
        return 0; 
    }
    else if (a[1] == a[n])
    {
        while (a[1 + i] == a[1] && 1 + i <= n)
        {
            i++;
        }
        if (1 + i > n)
        {
            cout << "1" << endl;
            return 0;
        }
        while (a[n - j] == a[n] && n - j >= 0)
        {
            j++;
        }
        //cout << a[1 + i] << "===" << a[n - j] << endl;
        if (a[1 + i] >= a[n - j])
        {
            cout << 0 << endl;
            return 0;
        }
        int l = c[a[1] - 1], r = n - l - b[a[1]];
        //cout << l << "===" << r << endl;
        if (l == r)
        {
            cout << "1" << endl;
            return 0;
        }
        else
        {
            cout << "0" << endl;
            return 0;
        }
    }
    i = a[i + 1] + 1;
    j = a[n - j];
    //for(i = 1; i <= 10; i++) cout << c[i] << endl;
    for(; i < j; i++)
    {
        //cout << i << endl;
        int l = c[i - 1], r = n - c[i];
        if (l == r)
        {
            res++;
            
        }
    }
    i = 0;
    j = 0;
    while (a[1 + i] == a[1] && 1 + i <= n)
    {
        i++;
    }
    if (a[1 + i] < a[n] && c[a[1] - 1] == n - c[a[1]])
    {
        res++;
    }
    while (a[n - j] == a[n] && n - j >= 0)
    {
        j++;
    }
    if (a[1] < a[n - j] && c[a[n] - 1] == n - c[a[n]])
    {
        res++;
    }
    cout << res << endl;
    return 0;
}