#include<bits/stdc++.h>
#define ll long long
#define rr read()
using namespace std;
const int N=5e5+5;
ll a[N],b[N],s[N];
int ans1,ans2;
int read()
{
    char ch=getchar(); int x=0,g=0;
    while (ch<'0'||ch>'9') g|=ch=='-',ch=getchar();
    while (ch>='0'&&ch<='9') x=x*10+(ch^48),ch=getchar();
    return g? -x:x;
}

int main()
{
	int n=rr;
	for (int i=0;i<n;++i) a[i]=rr;
	for (int i=0;i<n;++i) b[i]=rr;
	
	sort(a,a+n);
	for (int i=0;i<n;++i) b[i]=-b[i];
	sort(b,b+n);
	for (int i=0;i<n;++i) s[i]=a[i]-b[i];
	bool f=1;
	for (int i=1;i<n;++i)
	if (s[i]!=s[i-1]){
		f=0; break;
	}
	if (f) ans1=1+abs(a[0]-b[0]);
	//return !printf("%lld\n",1+abs(a[0]-b[0]));
	
	for (int i=0;i<n;++i) b[i]=-b[i];
	sort(b,b+n);
	bool g=1;
	for (int i=0;i<n;++i) s[i]=a[i]-b[i];
	for (int i=1;i<n;++i)
	if (s[i]!=s[i-1]){
		g=0; break;
	}
	if (g) ans2=abs(a[0]-b[0]);
	if (f&&g) printf("%d\n",min(ans1,ans2));
	else if (f) printf("%d\n",ans1);
	else if (g) printf("%d\n",ans2);
	// return !printf("%lld\n",abs(a[0]-b[0]));
	else printf("-1\n");
	return 0;
}