#include<iostream>
#include<cmath>
using namespace std;

//B
const int N=2e5+7;
typedef long long ll;
ll a[N],b[N];

int main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++){
		cin>>b[i];
		b[i]-=a[i];
	}
	bool flag=true;
	for(int i=2;i<=n;i++){
		if(b[i]!=b[1]){
			flag=false;
			break;
		}
	}
	if(flag){
		cout<<(b[1]>=0?b[1]:-b[1])<<endl;
	}else{
		flag=true;
		b[1]+=2*a[1];
		for(int i=2;i<=n;i++){
			b[i]+=2*a[i];
			if(b[i]!=b[1]){
				flag=false;
				break;
			}
		}
		if(flag){
			cout<<(b[1]>=0?b[1]+1:-b[1]+1)<<endl;
		}else{
			cout<<-1<<endl;
		}
	}
}
