#include <iostream>
#include <bits/stdc++.h>
using namespace std;
#define int long long int
const int N = 1e6 + 10;
int a[N], n, b[N], c[N];

signed main()
{
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &a[i]);
	}
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &b[i]);
		c[i] = -b[i];
	}
	sort(a, a + n);
	sort(b, b + n);
	sort(c, c + n);
	int flag1 = 1, flag2 = 1;
	int ans = -1;
	int n1 = a[0] - b[0], n2 = a[0] - c[0];
	for (int i = 0; i < n; i++)
	{
		if (flag1 && a[i] - b[i] != n1)
		{
			flag1 = 0;
		}
		if (flag2 && a[i] - c[i] != n2)
		{
			flag2 = 0;
		}
	}
	if (flag1)
	{
		ans = abs(n1);
	}
	if (flag2)
	{
		ans = abs(n2) + 1;
	}
	if (flag1 && flag2)
	{
		ans = min(abs(n1), abs(n2) + 1);
	}
	cout << ans << endl;
	return 0;
}

