#include <bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
#define rep(a, b, c) for(int (a)=(b);(a)<=(c);(a)++)
#define per(a, b, c) for(int (a)=(b);(a)>=(c);(a)--)
#define mset(var, val) memset(var,val,sizeof(var))
#define ll long long
#define int ll
#define itn int
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pb push_back
#define endl "\n"
#define pii pair<int,int>
#define pll pair<ll,ll>
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 1e5 + 5;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-8;
const double pi = acos(-1.0);

int a[N],b[N];
int n;

bool check(int m){
	int t=0;
	rep(i,1,n){
		if(b[i]<m){
			t++;
		}else if(b[i]>m){
			t--;
		}
		if(t<0){
			return false;
		}
	}
	if(t!=0)
		return false;
	return true;
}

void solve() {
    cin>>n;
    rep(i,1,n){
    	cin>>a[i];
    	b[i]=a[i];
	}
	int f=a[1];
	int t=0;
	sort(a+1,a+1+n);
	if(n%2==1){
		t=a[(n+1)/2];
		int tt=0;
		rep(i,1,n){
			if(b[i]<t){
				tt++;
			}else if(b[i]>t){
				tt--;
			}
			if(tt<0){
				cout<<0<<endl;
				return;
			}
		}
		if(tt!=0){
			cout<<0<<endl;
		}else{
			cout<<1<<endl;
		}
		return;
	}else{
		int tl=a[n/2],tr=a[n/2+1];
		int l=tl,r=tr;
		int ans1=-1,ans2=-1;
		while(l<=r){
			int mid=(l+r)/2;
			if(check(mid)){
				r=mid-1;
				ans1=mid;
			}else{
				l=mid+1;
			}
		}
		l=tl,r=tr;
		while(l<=r){
			int mid=(l+r)/2;
			if(check(mid)){
				l=mid+1;
				ans2=mid;
			}else{
				r=mid-1;
			}
		}
		if(ans1==-1 || ans2==-1){
			cout<<0<<endl;
		}else{
			cout<<ans2-ans1+1<<endl;
		}
	}
}
/*
5
1 2 2 4 5
5
1 1 1 1 1
4
4 10 5 10
4
1 4 4 10
*/

signed main() {
    IOS;
    int t = 1;
    // cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
