#include <bits/stdc++.h>
using namespace std;
const int N = 200005;
int a[N], b[N], tdel[N], del[N];
int ta[N], tb[N];
int neg[N] = {};
bool cmp(int x, int y) {
	return abs(x) < abs(y);
}
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n, cost = 0, flag = 1, check = 1, neg = 0;
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for(int i = 1; i <= n; i++) {
		cin >> b[i];
	}
	sort(a + 1, a + 1 + n);
	sort(b + 1, b + 1 + n);
	for(int i = 1; i <= n; i++) {
		del[i] = b[i] - a[i];
	}
//	cout << "del: \n";
//	for(int i = 1; i <= n; i++) {
//		cout << del[i] << " ";
//	}
//	cout << "\ntdel: \n";
//	for(int i = 1; i <= n; i++) {
//		cout << tdel[i] << " ";
//	}
//	cout << "\n";
	sort(del + 1, del + 1 + n);
	for(int i = 2; i <= n; i++) {
		if(del[i - 1] != del[i]) {
			flag = 0;
			break;
		}
	}
	if(flag == 0) {
		for(int i = 1; i <= n; i++) {
			a[i] = -a[i];
		}
		neg = 1;
		sort(a + 1, a + n + 1);
		for(int i = 2; i <= n; i++) {
			if(b[i] - a[i] != b[i - 1] - a[i - 1]) {
				check = 0;
				break;
			}
		}
	}
	if(!flag && !check) {
		cout << "-1\n";
	} else {
		if(a[1] / abs(a[1]) != b[1] / abs(b[1]) || a[n] / abs(a[n]) != b[n] / abs(b[n])) {
			cost += abs(a[1] - b[1]);
			cout << cost + neg << "\n";
		} else {
			if(a[1] / abs(a[1]) == b[1] / abs(b[1])) {
				cost = abs(a[1] - b[1]);
				cout << cost << "\n";
			} else {
				cost = abs(a[1] + b[n]);
				cout << 1 + cost << "\n";
			}
		}
	}

	return 0;
}
/*

*/
