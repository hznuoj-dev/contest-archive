#include <iostream>
#include <algorithm>
#include <cstring>
#include <map>
#include <vector>
#include <stack>
#include <queue>
#include <cmath>

using namespace std;

int n, q;
long long k;
long long a[200005];
long long dp[200005];
long long ma[200005][30];
long long mi[200005][30];
long long s[200005];

void init(int n)
{
    for (int i = 1; i <= n; ++i)
    {
        ma[i][0] = a[i];
        mi[i][0] = a[i];
    }
    for (int j = 1; (1 << j) <= n; ++j)
    {
        for (int i = 1; i + (1 << j) <= n + 1; ++i)
        {
            ma[i][j] = max(ma[i][j - 1], ma[i + (1 << (j - 1))][j - 1]);
            mi[i][j] = min(mi[i][j - 1], mi[i + (1 << (j - 1))][j - 1]);
        }
    }
}

long long search(int l, int r)
{
    int k = log2(r - l + 1);
    long long t1 = min(mi[l][k], mi[r - (1 << k) + 1][k]);
    long long t2 = max(ma[l][k], ma[r - (1 << k) + 1][k]);
    return t2 - t1;
}

void solve()
{
    cin >> n >> k >> q;
    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i];
    }
    init(n);
    int l = 1, r = 1;
    for (r = 1; r <= n; ++r)
    {
        dp[r] = n;
        while (search(l, r) > k)
        {
            dp[l] = r - 1;
            ++l;
        }
    }

    for (int i = 1; i <= n; ++i)
    {
        s[i] = s[i - 1] + dp[i] - i + 1;
    }

    while (q--)
    {
        cin >> l >> r;
        long long res = 0;
        int k = lower_bound(dp + 1, dp + n + 1, r) - dp;
        if (k <= l)
        {
            long long x = (r - l + 1);
            res = (1 + x) * x / 2;
        }
        else
        {
            res = s[k - 1] - s[l - 1];
            long long x = (r - k + 1);
            res += (1 + x) * x / 2;
        }
        cout << res << endl;
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}