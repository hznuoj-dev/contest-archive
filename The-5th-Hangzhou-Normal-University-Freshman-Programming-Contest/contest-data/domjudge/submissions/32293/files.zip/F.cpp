#include<bits/stdc++.h>
#define rg register
#define il inline
typedef long long ll;
using namespace std;
ll mod = 1e9+7;
inline ll read() {
	ll ans = 0;
	char last = ' ', ch = getchar();
	while (ch < '0' || ch > '9') last = ch, ch = getchar();
	while (ch >= '0' && ch <= '9') ans = ans * 10 + ch - '0', ch = getchar();
	if (last == '-') return -ans;
	return ans;
}
il ll ksm(ll b,ll k){
	ll res=1;
	while(k){
		if(k&1) res=1ll*res*b%mod;
		b=1ll*b*b%mod;k>>=1;
	}
	return res;
}
int e[500040],ne[500040],h[500020],idx;
int w[500020];
void add(int a,int b,int c){
	e[idx]=b;
	ne[idx]=h[a];
	w[idx]=c;
	h[a]=idx++;
} 
int s;
int a[400040];
void dfs(int u, int x, int f) {
    s^=x, a[u]=x;
    for(int i=h[u];~i;i=ne[i]){
    	int j=e[i];
    	if(j==f)continue;
    	dfs(j,x^w[i],u);
	}
}
int main(){
	int n;
	cin>>n;
	memset(h,-1,sizeof h);
	for(int i=1;i<=n-1;i++){
		int a,b,c;
		cin>>a>>b>>c;
		add(a,b,c);
		add(b,a,c);
	}
	dfs(1,0,-1);
	int q;
	cin>>q;
	while(q--){
		int u;
		int x;
		cin>>u>>x;
		if(n%2){
			cout<<(s^x^a[u])<<endl;
		}
		else cout<<s<<endl;
	}
}

