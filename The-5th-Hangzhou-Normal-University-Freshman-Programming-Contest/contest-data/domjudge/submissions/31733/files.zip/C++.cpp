#include <bits/stdc++.h>
using namespace std;
struct node {
	double a;
	double b;
	double c;
}p[7];
bool cmp(node s, node l) {
	return s.a < l.a;
}
int main()
{
	int m, k, a[7], b[7];
	cin >> m >> k;
	for (int i = 1; i <= 5; i++) cin >> p[i].a;
	for (int i = 1; i <= 5; i++) cin >> p[i].b;
	for (int i = 1; i <= 5; i++){
		p[i].c = p[i].b * 1.0 / p[i].a * 1.0;
	}
	sort(p + 1, p + 6, cmp);
	double price = p[1].a, mm = p[1].b;
	double ans = price / mm;
	for (int i = 2; i <= 5; i++) {
        price += p[i].a;
        mm += p[i].b;
        if (price >= m) ans = max((mm) / (price - k), ans);
        else ans = max(ans, mm / price);
	}
	printf("%.2f", ans);
	return 0;
}