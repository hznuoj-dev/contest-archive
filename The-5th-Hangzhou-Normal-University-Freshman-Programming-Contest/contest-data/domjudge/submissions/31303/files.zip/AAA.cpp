#include<bits/stdc++.h>
#define lowbit(x) (x)&-(x)
#define int long long
using namespace std;
const int M=200005;
int a[M];
int t[M];
int n;
void updata(int p,int x){
	while(p<=M-1){
		t[p]+=x;
		p+=lowbit(p);
	}
	return ;
}
int query(int p){
	int res=0;
	while(p){
		res+=t[p];
		p-=lowbit(p);
	}
	return res;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	int r1=a[1];
	updata(a[1],1);
	for(int i=2;i<=n;i++){
		updata(a[i],1);
		int l=a[1],r=a[n],ans=INT_MAX;
		while(l<=r){
			int mid=(l+r)>>1;
			int t1=query(mid-1);
			int t2=query(mid);
			//cout<<mid<<' '<<t1<<' '<<t2<<'\n';
			if(t1>=i-t2)r=mid-1,ans=mid;
			else l=mid+1;
		}
//		cout<<ans<<'\n';
		r1=max(r1,ans);
	}
	int ans=r1-1;
	for(int i=a[n];i>=a[1];i--){
		int t1=query(i-1);
		int t2=query(i);
		if(t1==n-t2){
			ans=i;
			break;
		}
	}
//	cout<<ans;
	int k=max(0LL,ans-r1+1);
	cout<<k;
	return 0;
}
/*
4
4 10 5 10

4
1 4 4 10
*/
