#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

int read() {
    int x = 0, f = 1; char c = getchar();
    while(c < '0' || c > '9') c == '-' ? f = -1: 0, c = getchar();
	while(c >= '0' && c <= '9') x = (x << 1) + (x << 3) + (c ^ '0'), c = getchar();
    return x * f;
}

int qpow(int a, int k, int r = 1) {
	for(; k; k >>= 1, a = a * a)
		if(k & 1) r = r * a;
	return r;
}

int n, a[200050], b[200050], d1[200050], d2[200050];

int sol() {
    bool yes1 = true, yes2 = true;
    for(int i = 1; i <= n; ++i) {
        d1[i] = b[i] - a[i];
        d2[i] = b[i] + a[i];
        
        if(i > 1 && d1[i] != d1[i - 1]) yes1 = false;
        if(i > 1 && d2[i] != d2[i - 1]) yes2 = false;
    }
    
    int ans = -1;
    if(yes1) {
        int x = d1[1];
        if(ans == -1 || ans > x) ans = x;
    }
    if(yes2) {
        int x = d2[1] + 1;
        if(ans == -1 || ans > x) ans = x;
    }
    return ans;
}

signed main() {
    n = read();
    for(int i = 1; i <= n; ++i) a[i] = read();
    for(int i = 1; i <= n; ++i) b[i] = read();
    
    sort(a + 1, a + n + 1);
    sort(b + 1, b + n + 1);
    
    cout << sol() << endl;
    
    return 0;
}

