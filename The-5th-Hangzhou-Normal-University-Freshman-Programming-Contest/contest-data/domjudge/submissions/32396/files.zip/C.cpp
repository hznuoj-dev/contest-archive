#include<bits/stdc++.h>
#define mp make_pair
using namespace std;
bool comp(long long x,long long y){
	return x<y;;
}
const int maxn = 200005;
vector<pair<long long, long long> > g[maxn];
long long sz[maxn];
long long ans;
void dfs(int x,int fa){
	sz[x]=1;
	for(pair<long long,long long> v:g[x]){
		if(v.first==fa) continue;
		dfs(v.first,x);
		sz[x]+=sz[v.first];
		if(sz[v.first]&1) ans^=v.second;
	}
	
}
inline void solve()
{
	int n;
	cin>>n;
	if(n<12){
		cout<<"No Solution"<<'\n';
		return;
	}
	else{
		if((n-12)%4==0){
			int cnt = (n-12)/4;
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"3-";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"1=1\n";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"2-";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"1=1\n";
		}
		if((n-13)%4==0){
			int cnt = (n-12)/4;
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"1+1=";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"3\n";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"1+1=";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"2\n";
		}
		if((n-14)%4==0){
			int cnt = (n-14)/4;
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"3-1=";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"4\n";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"5-1=";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"4\n";
		}
		if((n-15)%4==0){
			int cnt = (n-15)/4;
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"+4=";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"3\n";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"+4=";
			for(int i=1;i<=cnt;i++){
				cout<<1;
			}
			cout<<"5\n";

		}
	}
}


int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int tt;
	cin>>tt;
	while(tt--)
	solve();
}
