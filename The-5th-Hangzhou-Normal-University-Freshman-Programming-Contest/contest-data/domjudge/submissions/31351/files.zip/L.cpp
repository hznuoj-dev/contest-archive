#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

int read() {
    int x = 0, f = 1; char c = getchar();
    while(c < '0' || c > '9') c == '-' ? f = -1: 0, c = getchar();
	while(c >= '0' && c <= '9') x = (x << 1) + (x << 3) + (c ^ '0'), c = getchar();
    return x * f;
}

int m, k, a[15], b[15];
double ans = 0;

void dfs(int i, int s, int e, int c) {
    if(i > 5) {
        if(c == 0) return ;
        int money = s >= m ? s - k : s;
        ans = max(ans, 1.0 * e / money);
        return ;
    }
    dfs(i + 1, s, e, c);
    dfs(i + 1, s + a[i], e + b[i], c + 1);
}

signed main() {
    m = read(), k = read();
    for(int i = 1; i <= 5; ++i) a[i] = read();
    for(int i = 1; i <= 5; ++i) b[i] = read();
    
    dfs(1, 0, 0, 0);
    printf("%.2lf\n", ans);
    
    return 0;
}

