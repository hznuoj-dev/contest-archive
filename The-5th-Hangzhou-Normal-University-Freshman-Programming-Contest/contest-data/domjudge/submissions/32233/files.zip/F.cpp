#include<bits/stdc++.h>
#define mp make_pair
using namespace std;
bool comp(long long x,long long y){
	return x<y;;
}
const int maxn = 200005;
vector<pair<long long, long long> > g[maxn];
long long sz[maxn];
long long ans;
void dfs(int x,int fa){
	sz[x]=1;
	for(pair<long long,long long> v:g[x]){
		if(v.first==fa) continue;
		dfs(v.first,x);
		sz[x]+=sz[v.first];
		if(sz[v.first]&1) ans^=v.second;
	}
	
}
inline void solve()
{
	int n;
	cin>>n;
	for(int i=0;i<n-1;i++){
		long long u,v,w;
		cin>>u>>v>>w;
		g[u].push_back(mp(v,w));
		g[v].push_back(mp(u,w));
	}
	queue<long long> q;
	vector<long long> sum(n+1);
	q.push(1);
	vector<int> vis(n+1);
	while(q.size()>0){
		int now = q.front();
		q.pop();
		vis[now]=1;
		for(auto i: g[now]){
			if(vis[i.first]==1)	continue;
			sum[i.first]=sum[now]^i.second;
			q.push(i.first);
		}
	}
	dfs(1,0);
	int qq;
	cin>>qq;
	for(int i=1;i<=qq;i++){
		int u,x;
		cin>>u>>x;
		long long val1= x^sum[u];
		if(n%2==0){
			cout<<ans<<'\n';
		}
		else{
			cout<<(ans^val1)<<'\n';
		}
	}
}


int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int tt;
	//cin>>tt;
	//while(tt--)
	solve();
}
