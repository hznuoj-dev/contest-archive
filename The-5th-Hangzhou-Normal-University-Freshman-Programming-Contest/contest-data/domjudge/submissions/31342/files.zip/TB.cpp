#include<bits/stdc++.h>
using namespace std;
long long a[200001],b[200001],c[200001];
int main()
{
	std::ios::sync_with_stdio(false);
	long long n,i,ans1=1e11,ans2=1e11;
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(i=1;i<=n;i++)
	{
		cin>>b[i];
	}
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	for(i=1;i<=n;i++)
	{
		c[i]=-b[n-i+1];
	}
	for(i=2;i<=n;i++)
	{
		if(b[i]-a[i]!=b[i-1]-a[i-1])
		{
			break;
		}
	}
	if(i==n+1)
	{
		ans1=abs(b[1]-a[1]);
	}
	for(i=2;i<=n;i++)
	{
		if(c[i]-a[i]!=c[i-1]-a[i-1])
		{
			break;
		}
	}
	if(i==n+1)
	{
		ans2=abs(c[1]-a[1])+1;
	}
	if(ans1!=1e11||ans2!=1e11)
	{
		cout<<min(ans1,ans2);
		return 0;
	}
	cout<<-1;
	return 0;
}
