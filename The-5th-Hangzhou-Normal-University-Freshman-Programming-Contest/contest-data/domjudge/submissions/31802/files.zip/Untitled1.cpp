#include<bits/stdc++.h>
#define int long long
#define endl '\n'
using namespace std;
int n,ans,q,m,t,b,fa[200005][20],fw[200005][20],a[200005],p[200005],z[200005];
signed main(){
	cin >> n >> m >> b;
	for (int i=1;i<=n;++i) cin >> a[i];
	for (int i=n,j=0;i>=1;--i,--j) {
		if (j==0) t+=b,j=m;
		q=min(t,a[i]);
		t-=q;
		ans+=q;
		//cout << "t=" << t << ",ans=" << ans << ",j=" << j << endl;
	}
	cout << ans;
	
}
