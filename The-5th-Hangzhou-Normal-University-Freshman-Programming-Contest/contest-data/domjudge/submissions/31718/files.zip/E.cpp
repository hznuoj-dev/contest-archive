#define _CRT_SECURE_NO_WARNINGS 1
#include<bits/stdc++.h>
#define ios  ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
typedef long long LL;
const LL MAXN = 2e5+10;
const int Inf = 0x7fffffff;
const LL INF = 0x3f3f3f3f3f3f3f3f;
const int MOD = 1e9+7;
using namespace std;
int father[MAXN];
int n,q;
int a[MAXN];
int h[MAXN];
int sum[MAXN];
int add(int a,int b)
{
	return ((a%MOD)+(b%MOD))%MOD;
}
int find(int x)
{
	if(father[x]!=x)
		father[x]=find(father[x]);
	return father[x];
}
void unionn(int a,int b)
{
	int fa,fb;
	fa=find(a);
	fb=find(b);
	father[fb]=fa;
	sum[fa]=add(sum[fa],sum[fb]);
}
bool pd(int a,int b)
{
	int fa=find(a);
	int fb=find(b);
	return fa==fb;
}
void couts()
{
	cout<<"a: ";
	for(int i=1;i<=n;++i)
		cout<<a[i]<<" ";
	cout<<"\n";
	cout<<"sum: ";
	for(int i=1;i<=n;++i)
		cout<<sum[i]<<" ";
	cout<<"\n";
	cout<<"happy: ";
	for(int i=1;i<=n;++i)
		cout<<h[i]<<" ";
	system("pause");
}
int main()
{
	ios;
	cin>>n>>q;
	for(int i=1;i<=n;++i)
	{
		cin>>a[i];
		father[i]=i;
		sum[i]=a[i]%MOD;	
	}
	for(int i=1;i<=n;++i)
	    h[i]=sum[i]%MOD;
	
	//couts();

	int c,u,v;
	for(int i=1;i<=q;++i)
	{
		cin>>c;
		if(c==1)
		{
			cin>>u>>v;
			//if(pd(u,v)==false)
		    unionn(u,v);
		}
		else if(c==2)
		{   
			int fu;
			cin>>u>>v;
			fu=find(u);
			int cnt=0;
			for(int j=1;j<=n;++j)
			{
				if(fu==find(j))
				{
					a[j]=add(a[j],v);
					++cnt;
					
				}
			}
            sum[fu]=add(sum[fu],((v%MOD)*(cnt%MOD))%MOD);
			//couts();
		
		}
		else if(c==3)
		{
			cin>>u;
			cout<<h[u]<<"\n";
		}
		int f;
		for(int j=1;j<=n;++j)
		{
			f=find(j);
			h[j]=add(h[j],sum[f]);
		}
		//couts();
	}
	//system("pause");
	return 0;
}