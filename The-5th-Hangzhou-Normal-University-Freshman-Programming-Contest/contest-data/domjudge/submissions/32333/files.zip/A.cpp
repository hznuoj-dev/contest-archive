#include<bits/stdc++.h>

#define star std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

#define endl "\n";

using namespace std;

typedef long long ll;

typedef unsigned long long ull;

const ll maxn = 2e5+7;

int n;
ll l=-1,r=-1,flag=0,leftt,rightt;
ll a[maxn];
int check(ll x){
	int cnt=0;
	for(int i=1;i<=n;i++){
		if(a[i]>x){
			cnt--;
		}else if(a[i]<x){
			cnt++;
		}
		if(cnt<0){
			return false;
		}
	}
	if(cnt==0){
		return true;
	}
	return false;
}
void solve(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a+1,a+1+n);
	if(n%2==1){
		if(check(a[(n+1)/2])){
			cout<<"1"<<endl;
		}else{
			cout<<"0"<<endl;
		}
	}else{
		l=a[(n+1)/2];
		r=a[(n+1)/2+1];
		if(l==r){
			if(check(l)){
				cout<<"1"<<endl;
			}else{
				cout<<"0"<<endl;
			}
		}else if(l+1==r){
			cout<<"0"<<endl;
		}else{
			if(check((l+r)/2)){
				cout<<r-l-1<<endl;
			}else{
				cout<<"0"<<endl;
			}
		}
	}
}
signed main()
{
star;
int _=1;
//cin>>_;
while(_--){
solve();
}
return 0;
}
//��дջ

