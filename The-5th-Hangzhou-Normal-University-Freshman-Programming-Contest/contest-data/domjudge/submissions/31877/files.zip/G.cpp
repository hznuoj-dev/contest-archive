#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

int read() {
    int x = 0, f = 1; char c = getchar();
    while(c < '0' || c > '9') c == '-' ? f = -1: 0, c = getchar();
	while(c >= '0' && c <= '9') x = (x << 1) + (x << 3) + (c ^ '0'), c = getchar();
    return x * f;
}

int qpow(int a, int k, int r = 1) {
	for(; k; k >>= 1, a = a * a)
		if(k & 1) r = r * a;
	return r;
}

int a[200050];
LL f[200050];

signed main() {
    int n = read(), m = read(), b = read();
    for(int i = 1; i <= n; ++i) a[i] = read();
    
    LL mx = 0, ans = 0, sum = 0;
    for(int i = 1; i <= n; ++i) {
        sum += a[i];
        if(i - m >= 1) mx = max(mx, f[i - m]);
        f[i] = min(mx + b, sum);
        ans = max(ans, f[i]);
    }
    cout << ans << endl;
    
    return 0;
}

