#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N],b[N];
int main(){
	int n;
	int num=0;
	cin>>n;
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++)
		cin>>b[i];
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	int flag=1;
	for(int i=2;i<=n;i++){
		if(a[i]-b[i]!=a[i-1]-b[i-1]){
			flag=0;
			break;
		}
	}	
	if(flag==0){
		cout<<"-1";
	}else{
		if(a[1]/abs(a[1])!=a[n]/abs(a[n])||b[1]/abs(b[1])!=b[n]/abs(b[n])){
			cout<<abs(a[1]-b[1]);
		}else{
			if(a[1]/abs(a[1])==b[1]/abs(b[1])){
				cout<<abs(a[1]-b[1]);
			}else{
				cout<<1+abs(a[1]+b[n]);
			}		
		}
	}
	return 0;
}
