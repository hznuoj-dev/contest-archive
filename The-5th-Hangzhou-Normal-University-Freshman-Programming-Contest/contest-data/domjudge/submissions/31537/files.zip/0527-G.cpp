#include<bits/stdc++.h>
#define close std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
typedef long long ll;
const ll MAXN = 3e5+7;
const ll mod = 1e9+7;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
#define int long long
int a[MAXN],pre[MAXN];
ll _power(ll a,int b){ ll ans=1,res=a;while(b){ if(b&1) ans=ans*res%mod;res=res*res%mod;b>>=1;} return ans%mod;}
void solve(){
int n,m,k;
cin>>n>>m>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		pre[i]=pre[i-1]+a[i];
	}
	int last=n%m;
	if(last==0) last+=m;
	int sum=0;
	for(int i=last;i<=n;i+=m){
		sum+=min(pre[i]-sum,k);
	}
	cout<<sum;
}
signed main(){
	solve();
}
