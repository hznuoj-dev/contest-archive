#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IO ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
const int N = 2e5 + 5;
int n,m, a[N], b[N], c[N];


signed main(){
    IO;

    int n;
    cin >> n;
    for(int i = 1;i <= n;i++)
    cin >> a[i];
    for(int i = 1;i <= n;i++)
    cin >> b[i], c[i] = -b[i];

    int ans = 0;

    sort(a+1, a+1+n);
    sort(b+1, b+1+n);
    sort(c+1, c+1+n);

    int d = a[1] - b[1];
    for(int i = 1;i <= n;i++)
        if(a[i] - b[i] != d){
            cout << -1;
            return 0;
        }


    if(abs(a[1] - b[1]) > abs(a[1] - c[1])){
        ans ++;
        d = abs(a[1] - c[1]);
    }else
        d = abs(a[1] - b[1]);

    cout << ans + d;



    return 0;
}