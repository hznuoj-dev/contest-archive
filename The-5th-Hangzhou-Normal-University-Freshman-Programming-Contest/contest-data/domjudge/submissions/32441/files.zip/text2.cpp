#include<bits/stdc++.h>
using namespace std;

struct yuebing {
	double costs;
	double judgements;
	double results;
} nums[10];
bool cmp (yuebing a, yuebing b) {
	if (a.results != b.results) {
		return a.results > b.results;
	} else {
		if (a.costs != b.costs) {
			return a.costs > b.costs;
		} else {
			return a.judgements > b.judgements;
		}
	}
}
signed main () {
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int m, k;
	cin >> m >> k;
	for (int i = 1; i <= 5; i++) {
		cin >> nums[i].costs;
	}
	for (int i = 1; i <= 5; i++) {
		cin >> nums[i].judgements;
	}
	for (int i = 1; i <= 5; i++) {
		nums[i].results = nums[i].judgements / nums[i].costs;
	}
	sort (nums + 1, nums + 1 + 5, cmp);
	double result = 0; 	// �����
	double result_money = 0;	// �ܻ���Ǯ��
	double result_judgement = 0;	//��������
	bool flag = false;
	for  (int i = 1; i <= 5; i++) {
		result_money = result_money + nums[i].costs;
		if ((result_money >= m) && (flag == false)) {
			flag = true;
			result_money = result_money - k;
		}
		result_judgement = result_judgement + nums[i].judgements;
		double temp_result = result_judgement / result_money;
		result = max (result, temp_result);
	}
	printf ("%.2f", result);
	return 0;
}
// 1	2	4		4		2
// 2	2	1		2		4
// 2	1	0.25	0.5		2
// 8 2
