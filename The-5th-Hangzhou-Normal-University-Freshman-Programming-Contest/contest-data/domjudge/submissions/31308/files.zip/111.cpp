#include<iostream>
using namespace std;
int n,ans,a[230000],res=0x3f;
int main()
{
	cin>>n;
	ans=0;
	int l=0,r=0x3f;
	for(int i=0;i<n;i++)cin>>a[i];
	if(a[0]>=a[n-1])
	{
		cout<<0;
		return 0;
	}
	for(int i=0;i<n-1;i++)
	{
		if(a[i]==a[i+1])
		{
			ans++;
			if(ans>1)
			{
				cout<<0;
				return 0;
			}
		}
	}
	int x=a[0],y=0;
	for(int i=1;i<n;i++)
	{
		if(a[i]>x&&a[i]>a[i+1])
		{
			if(i-y==1&&a[i]-x==1)
			{
				cout<<0;
				return 0;
			}
			l=max(l,x+1);
			r=min(r,a[i]-1);
			if(l>=r)
			{
				cout<<0;
				return 0;
			}
			x=a[i+1];
			y=i+1;
		}
	}
	if(ans==1)
	{
		cout<<1;
		return 0;
	}
	else 
	{
		cout<<r-l+1;
		return 0;
	}
	return 0;
}
