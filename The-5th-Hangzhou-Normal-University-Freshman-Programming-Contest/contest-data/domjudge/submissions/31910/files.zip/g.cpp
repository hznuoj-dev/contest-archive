#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N];
int main()
{
	int n,m,b;
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++) cin>>a[i];
	int sum=0;
	int ans=0;
	int t=0;
	for(int i=1;i<=n;i++)
	{
		t++;
		sum+=a[i];
		if(sum>=b&&t>=m)
		{
			t=0;
			ans+=b;
			sum-=b;
		}
		else if(t>=m&&sum<b&&i==n)
		{
			ans+=sum;
		}
		else if(i==1)
		{
			t=0;
			ans+=a[i];
			sum=0;
		}
	}
	cout<<ans<<endl;
	return 0;
}
