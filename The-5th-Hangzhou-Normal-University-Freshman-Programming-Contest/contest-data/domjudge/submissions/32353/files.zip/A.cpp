#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,a[200001],b[200001],cnt=0;
int main() {
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i],b[i]=a[i];
	sort(b+1,b+n+1);
	for(int i=1;i<=200000;i++) {
		int l=lower_bound(b+1,b+n+1,i)-b;
		l--;
		int r=lower_bound(b+1,b+n+1,i+1)-b;
		if(l+r==n+1) {
			int j=1;
			while(a[j]==i&&j<n)j++;
			if(a[j]>i)continue;
			j=n;
			while(a[j]==i&&j>1)j--;
			if(a[j]<i)continue;
			cnt++;
		}
	}
	cout<<cnt;
}