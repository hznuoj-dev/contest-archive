#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N=2e5+7,MOD=1e9+7,INF=0x3f3f3f3f,M=1e3+7;
ll n,k,q,a[N],len[N],lenl[N],res[M][M];
ll sz,tot,bl[N],L[N],R[N];

struct node{
	int l,r,minn,maxn;
}t[N*4];
void up(int id){
	if(t[id].l==t[id].r) return;
	t[id].minn=min(t[id*2].minn,t[id*2+1].minn);
	t[id].maxn=max(t[id*2].maxn,t[id*2+1].maxn);
}
void build(int id,int l,int r){
	t[id]={l,r,INF,0};
	if(l==r){
		t[id].minn=t[id].maxn=a[l];
		return;
	}
	build(id*2,l,(l+r)/2);
	build(id*2+1,(l+r)/2+1,r);
	up(id);
}
int getMinn(int id,int l,int r){
	if(t[id].l==l&&t[id].r==r) return t[id].minn;
	int mid=(t[id].l+t[id].r)/2;
	if(r<=mid) return getMinn(id*2,l,r);
	else if(l>mid) return getMinn(id*2+1,l,r);
	else return min(getMinn(id*2,l,mid),getMinn(id*2+1,mid+1,r));
}
int getMaxn(int id,int l,int r){
	if(t[id].l==l&&t[id].r==r) return t[id].maxn;
	int mid=(t[id].l+t[id].r)/2;
	if(r<=mid) return getMaxn(id*2,l,r);
	else if(l>mid) return getMaxn(id*2+1,l,r);
	else return max(getMaxn(id*2,l,mid),getMaxn(id*2+1,mid+1,r));
}

void solve(){
	cin>>n>>k>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	a[n+1]=2e9+7;
	build(1,1,n+1);
	for(int i=1;i<=n;i++){
		int l=i,r=n,res=n+1;
		while(l<=r){
			int mid=(l+r)/2;
			int maxn=getMaxn(1,i,mid),minn=getMinn(1,i,mid);
			if(maxn-minn>k){
				res=mid;
				r=mid-1;
			}else{
				l=mid+1;
			}
		}
		len[i]=res-i;
		
		l=1,r=i,res=0;
		while(l<=r){
			int mid=(l+r)/2;
			if(getMaxn(1,mid,i)-getMinn(1,mid,i)>k){
				res=mid;
				l=mid+1;
			}else{
				r=mid-1;
			}
		}
		lenl[i]=i-res;
//		len[i]=query(1,i+1,n+1,a[i])-i;
//		lenl[i]=i-query2(1,1,i-1,a[i]);
	}
	
	sz=sqrt(n);
	tot=(n+sz-1)/sz;
	for(int i=1;i<=n;i++){
		bl[i]=(i-1)/sz+1;
		if(L[bl[i]]==0) L[bl[i]]=i;
		R[bl[i]]=i;
	}
	
	for(int r=tot;r>=1;r--){
		for(int l=r;l>=1;l--){
			if(l<r) res[l][r]=res[l+1][r];
			for(int i=L[l];i<=R[l];i++){
				res[l][r]+=min(len[i],1ll*R[r]-i+1);
			}
		}
	}
	
	while(q--){
		int l,r;
		cin>>l>>r;
		ll ans=0;
		if(bl[l]==bl[r]){
			for(int i=l;i<=r;i++){
				ans+=min(1ll*r-i+1,len[i]);
			}
		}else{
			int bL=bl[l]+1,bR=bl[r]-1;
			if(bL<=bR) ans+=res[bL][bR];
			for(int i=l;i<L[bL];i++){
				ans+=min(1ll*r-i+1,len[i]);
			}
			for(int i=r;i>R[bR];i--){
				ans+=min(1ll*i-L[bL]+1,lenl[i]);
			}
		}
		cout<<ans<<'\n';
	}
}

int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc=1;
//	cin>>tc;
	while(tc--) solve();
	return 0;
}
/*
5 2 4
1 3 3 5 3
1 5
1 4
2 3
3 3

*/
