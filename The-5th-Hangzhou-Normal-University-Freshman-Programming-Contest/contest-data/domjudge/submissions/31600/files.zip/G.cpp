#include <bits/stdc++.h>
using namespace std;
#define int long long
const int inf=0x3f3f3f3f;

int a[200200];
int c[200200];

void solve() {
	int n,m,b,sum=0;
	cin>>n>>m>>b;
	for (int i=1; i<=n; ++i) {
		cin>>a[i];
		sum+=a[i];
		c[i]=a[i];
	}
	int t=ceil(n*1.0/m);
	for (int i=1; i<=n; ++i) c[i]+=c[i-1];
	int mod=n%m;
	if (mod==0) mod=m;
	int ans=b*t-b+c[mod];
	ans=min(b*t-b,sum-c[mod]);
	ans+=c[mod];
	cout<<ans<<'\n';
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);

	int tt=1;
//	cin>>tt;
	while (tt--) solve();

	return 0;
}
