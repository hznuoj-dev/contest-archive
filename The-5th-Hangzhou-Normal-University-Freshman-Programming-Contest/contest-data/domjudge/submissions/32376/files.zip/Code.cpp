#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 3e5+7,inf = 1e18+7;
typedef long long ll;

struct node{
	int u;
	int w;
};

vector<node>e[N];
int sz[N];
int n;

void dfs(int u,int fa){
	int size = 1;
	for (auto i : e[u]){
		if(i.u == fa) continue;
		dfs(i.u,u);
		size += sz[i.u];
	}
	sz[u] = size;
}

int val[N];

void dfs2(int u,int fa){
	for (auto i : e[u]){
		if (i.u == fa) continue;
		dfs2(i.u,u);
		if (sz[i.u] % 2){
			val[u] ^= i.w;
		}
		val[u] ^= val[i.u];
	}
}

void dfs3(int u,int fa){
	for (auto i : e[u]){
		if (i.u == fa) continue;
		int fa_sz = n - sz[i.u];
		int tmp = val[u] ^ val[i.u];
		if (sz[i.u] % 2){
			tmp ^= i.w;
		}
		val[i.u] = val[i.u] ^ tmp;
		if (fa_sz % 2){
			val[i.u] ^= i.w;
		}
		dfs3(i.u,u);
	}
}


void solve(){
	cin >> n;
	for (int i = 1; i < n; i++){
		int u,v,w;
		cin >> u >> v >> w;
		e[u].push_back({v,w});
		e[v].push_back({u,w});
	}
	dfs(1,-1);
	dfs2(1,-1);
	dfs3(1,-1);
	
	int q;
	cin >> q;
	while (q--){
		int u,x;
		cin >> u >> x;
		int ans = 0;
		if (n % 2) ans ^= x;
		ans ^= val[u];
		cout << ans << '\n';
	}
	
}

signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc = 1;
//	cin >> tc;
	while (tc--){
		solve();
	}
	return 0;
}
/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5

*/
