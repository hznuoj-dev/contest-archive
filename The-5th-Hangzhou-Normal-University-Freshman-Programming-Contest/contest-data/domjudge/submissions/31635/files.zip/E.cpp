#define _CRT_SECURE_NO_WARNINGS 1
#include<bits/stdc++.h>
#define ios  ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
typedef long long LL;
const LL MAXN = 2e5+10;
const int Inf = 0x7fffffff;
const LL INF = 0x3f3f3f3f3f3f3f3f;
const LL MOD = 1e9+7;
using namespace std;
int father[MAXN];
int n,q;
LL a[MAXN];
LL h[MAXN];
LL sum[MAXN];
LL add(LL a,LL b)
{
	return ((a%MOD)+(b%MOD))%MOD;
}
int find(int x)
{
	if(father[x]!=x)
		father[x]=find(father[x]);
	return father[x];
}
void unionn(int a,int b)
{
	int fa,fb;
	fa=find(a);
	fb=find(b);
	father[fb]=fa;
	sum[fa]=add(sum[fa],sum[fb]);
}
bool pd(int a,int b)
{
	int fa=find(a);
	int fb=find(b);
	return fa==fb;
}
void couts()
{
	cout<<"a: ";
	for(int i=1;i<=n;++i)
		cout<<a[i]<<" ";
	cout<<"\n";
	cout<<"sum: ";
	for(int i=1;i<=n;++i)
		cout<<sum[i]<<" ";
	cout<<"\n";
	cout<<"happy: ";
	for(int i=1;i<=n;++i)
		cout<<h[i]<<" ";
	system("pause");
}
int main()
{
	ios;
	cin>>n>>q;
	
	for(int i=1;i<=n;++i)
	{
		cin>>a[i];
		father[i]=i;
		sum[i]=a[i];
		h[i]=a[i];
	}
	int c,u,v;
	//couts();//
	for(int i=1;i<=q;++i)
	{
		//cout<<"Day "<<i<<": \n";//
		cin>>c;
		if(c==1)
		{
			cin>>u>>v;
			if(pd(u,v)==false)
			   unionn(u,v);
		}
		else if(c==2)
		{
			cin>>u>>v;
			int fu=find(u);
			for(int j=1;j<=n;++j)
			{
				if(fu==find(j))
				{
					a[j]=add(a[j],v);
					sum[fu]=add(sum[fu],v);
				}
			}
			//couts();//
		}
		else if(c==3)
		{
			cin>>u;
			h[u]=h[u]%MOD;
			cout<<h[u]<<"\n";
		}
		for(int j=1;j<=n;++j)
		{
			int f=find(j);
			h[j]=add(h[j],sum[f]);
		}
		//couts();//
	}
	//system("pause");
	return 0;
}