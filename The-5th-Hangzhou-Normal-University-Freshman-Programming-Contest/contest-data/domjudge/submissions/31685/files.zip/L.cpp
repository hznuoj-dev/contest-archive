#include<bits/stdc++.h>
using namespace std;
typedef struct total{
	int a;
	int b;
}t;
bool cmp(t x,t y)
{
	if(x.b == y.b)
	{
		return x.a<y.a;
	}
	else
	{
		return x.b>y.b;
	}
}
int main()
{
	int m,k;
	t c[5];
	cin>>m>>k;
	for(int i = 0; i < 5; i++)
	{
		cin>>c[i].a;
	}
	for(int i = 0; i < 5; i++)
	{
		cin>>c[i].b;
	}
	sort(c,c+5,cmp);
	float num1 = 0,num2 = 0,sum = 0,max = 0,flag =1;
	for(int i = 0; i < 5;i++)
	{
		if(c[i].b>=c[i].a)
		{
			num1+=c[i].b;
			num2+=c[i].a;
			if(num2>=m&&max == 0)
			{
				num2-=k;
				max = 1;
			}
		}
		else
		{
			sum = num1/num2;
			num1+=c[i].b;
			num2+=c[i].a;
			if(num2>=m&&max ==0)
			{
				num2-=k;
				max = 1;
				flag = 0;
			}
			if(sum<=num1/num2)
			{
				continue;
			}
			else
			{
				num1-=c[i].b;
				num2-=c[i].a;
				if(num2<m&&flag == 0)
				{
					max = 0;
					flag = 1;
					num2+=k;
				}
			}
		}
	}
	sum = num1/num2;
	printf("%.2f",sum);
	
}
