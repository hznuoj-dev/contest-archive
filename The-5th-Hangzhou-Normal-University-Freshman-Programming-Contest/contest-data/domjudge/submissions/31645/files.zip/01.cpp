#include<bits/stdc++.h>
using namespace std;
int main()
{
	int m, k;
	int a[10], b[10];
	cin >> m >> k;
	for (int i = 1;i <= 5;i++)
	{
		cin >> a[i];
	}
	for (int i = 1;i <= 5;i++)
	{
		cin >> b[i];
	}
	double c[10];
	for (int i = 1;i <= 5;i++)
	{
		c[i] = 1.0 * b[i] / a[i];
	}
	for (int i = 1;i <= 5;i++)
	{
		for (int j = i + 1;j <= 5;j++)
		{
			if (c[i] < c[j])
			{
				swap(a[i], a[j]);
				swap(b[i], b[j]);
				swap(c[i], c[j]);
			}
		}
	}
	int sum = 0, sum2 = 0;int i = 1;
	double max = c[1];
	while (sum < m)
	{
		sum += a[i];
		sum2 += b[i];
		i++;
		if (sum >= m)
		{
			sum -= k;
			if (max < 1.0 * sum2 / sum)
			{
				max = 1.0 * sum2 / sum;
			}
			break;
		}
	}
	printf("%.2f", max);
	return 0;
}

