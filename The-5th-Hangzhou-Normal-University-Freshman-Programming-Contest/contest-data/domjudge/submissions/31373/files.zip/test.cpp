#include<bits/stdc++.h>
using namespace std;
    long long int a[200001],b[200001];
void read(long long int n,long long int a[]){
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
}
int main(){
    long long int n;
    cin>>n;
    read(n,a);
    read(n,b);
    sort(a,a+n);
    sort(b,b+n);
    long long int c1,c2,c1ok,c2ok,c3;
    int i;
    c1=a[0]-b[0];
    c2=a[0]+b[0];
    for(i=0;i<n;i++){
        if(a[i]-b[i]!=c1)break;
    }
    if(i==n)c1ok=1;
    else c1ok=0;
    sort(b,b+n,0);
    for(i=0;i<n;i++){
        if(a[i]+b[i]!=c2)break;
    }
    if(i==n)c2ok=1;
    else c2ok=0;
    if(c1ok==0){
        if(c2ok==0)cout<<-1<<endl;
        else{
            c3=abs(c2)+1;
            cout<<c3<<endl;
        }
    }else{
        if(c2ok==0)cout<<abs(c1)<<endl;
        else{
            c3=abs(c2)+1;
            if(abs(c1)>c3)cout<<c3;
            else cout<<abs(c1)<<endl;
        }
    }
    return 0;
}