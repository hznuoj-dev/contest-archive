#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define dl <<"\n"
#define pub push_back
#define pob pop_back
#define pof pop_front
#define puf push_front
#define eps 1e-6
#define MAXX 1e5+1
#define IOS ios::sync_with_stdio(false), cin.tie(0), cout.tie(0)

//const ll INF = 0x3f3f3f3f3f3f3f3f;
const int inf = 0x3f3f3f3f, mod = 1000000007, rge1 = 1000100, rge2 = 10001;

//ll s[200001] = { 0 };

ll a[200001] = { 0 };
ll b[200001] = { 0 };
ll c[200001] = { 0 };

ll f1(ll n) {
    
    ll d = a[0] - b[0];

    for (ll i = 1; i < n; i++) {
        if (a[i] - b[i] != d) return -1;
    }

    return d;

}

ll f2(ll n) {

    ll d = a[0] - c[0];

    for (ll i = 1; i < n; i++) {
        if (a[i] - c[i] != d) return -1;
    }

    return d + 1;

}

void LolitaSama() {
    
    /*
    ll n = 0, k = 0;
    cin >> n >> k;

    ll c = 0;

    for (ll i = 1; i <= n; i++) {
        cin >> s[i];
        if (s[i] == i) c++;
    }

    if (n == k + 1) {
        cout << "-1" dl;
    }
    else {
        cout << (c + 1 - k) / 2 dl;
    }
    */

    ll n = 0;
    cin >> n;

    for (ll i = 0; i < n; i++) {
        cin >> a[i];
    }
    for (ll i = 0; i < n; i++) {
        cin >> b[i];
        c[i] = -b[i];
    }

    sort(a, a + n);
    sort(b, b + n);
    sort(c, c + n);

    ll r1 = f1(n);
    ll r2 = f2(n);

    if (r1 == -1) {

        if (r2 == -1) cout << "-1" dl;
        else cout << abs(r2) dl;
        
    }
    else {
        
        if (r2 == -1) cout << abs(r1) dl;
        else cout << min(abs(r1), abs(r2)) dl;
    
    }

}

int main() {

    //IOS;

    int T = 1;
    //cin >> T;


    while (T--) {

        LolitaSama();

    }

}
