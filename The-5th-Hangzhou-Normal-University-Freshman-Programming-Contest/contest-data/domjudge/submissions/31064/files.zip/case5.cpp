#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
const int N = 2e5+10;
int a[N];
int b[N];
int n;
int sum;
int main()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	for (int i = 1; i <= n; i++)
		cin >> b[i];
	sort(a + 1, a + n + 1);
	sort(b + 1, b + n + 1);
	if (abs(b[1] - a[1]) != abs(b[2] - a[2]))
	{
		cout << "-1";
		return 0;
	}
	if (abs(b[1] - a[1]) >abs( - b[1] - a[1]))
	{
		sum++;
		for (int i = 1; i <= n; i++)
		{
			a[i] *= -1;
		}
		sort(a + 1, a + n + 1);
	}
	cout << b[1] - a[1];
	
	return 0;
}