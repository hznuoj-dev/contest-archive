#include <bits/stdc++.h>

using namespace std;
using LL = long long;

constexpr int N = 2e5 + 5;

#define int long long

void solve()
{
    int n;
    
    cin >> n;
    
    vector<int>a(n), b(n);

    for(auto & x : a)cin >> x;
    for(auto & x : b)cin >> x;

    sort(b.begin(), b.end());

    if(n == 1){
        cout << min(abs(a[0] - b[0]), abs(-a[0]-b[0]) + 1) << endl;
        return;
    }

    int INF, res = 0x3f3f3f3f;

    sort(a.begin(), a.end());

    for(int i = 0; i < n; ++ i)
    {
        if(i == 0)INF = abs(a[i] - b[i]);
        else if(INF != abs(a[i] - b[i]))break;

        if(i == n - 1)res = abs(INF);
    }

    for(int i = 0; i < n; ++ i)a[i] = -a[i];

    sort(a.begin(), a.end());

    for(int i = 0; i < n; ++ i)
    {
        if(i == 0)INF = abs(a[i] - b[i]);
        else if(INF != abs(a[i] - b[i]))break;

        if(i == n - 1)res = min(abs(INF) + 1, res);
    }

    if(res == 0x3f3f3f3f)res = -1;
    
    cout << res << endl;
    
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // int T;
    // for (cin >> T; T -- ; )
        solve();

}