#include<bits/stdc++.h>
using namespace std;
#define ll long long
int a[200005],b[200005];
map<int,int>mp;
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	int l=a[0],r=a[n-1];
	sort(b,b+n);
	if(n%2){
		if(count(b,b+n,b[n/2])%2){
			cout<<1<<endl;
		}else{
			cout<<0<<endl;
		}
		return 0;
	}else{
		l=max(l,b[n/2-1]);
		r=min(r,b[n/2]);
		if(b[n/2]==b[n/2-1]){
			r++;
			l--;
		}
		if(r>l+1){
			cout<<r-l-1<<endl;
		}else{
			cout<<0<<endl;
		}
		return 0;
	}
	for(auto it=mp.begin();it!=mp.end();it++){
		
	}
	for(int i=0;i<n;i++){
		
	}
	return 0;
}