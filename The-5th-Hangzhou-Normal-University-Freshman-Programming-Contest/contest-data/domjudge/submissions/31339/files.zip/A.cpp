#include<bits/stdc++.h>
#define ll long long
#define PII pair<int,int>
//  #define int long long
using namespace std;
constexpr ll mod=1e9+7; 
const ll inf=0x3f3f3f3f;  
const ll INF=0x3f3f3f3f3f3f3f3f;  
const double eps=1e-10;  
const int N=2e5+10;
// struct node{
//     friend bool operator<(const node&a,const node&b){
//         return ;
//     }
// }
//priority_queue<ll,vector<ll>,greater<ll>>pq;
inline int read(){int x=0,f=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}return x*f;}
inline void write(int x){char F[200];int tmp=x>0?x:-x;if(x<0) putchar('-');int cnt=0;while(tmp>0){F[cnt++]=tmp%10+'0';tmp/=10;}while(cnt>0)putchar(F[--cnt]);}
inline int combination(int n,int k){int sum=0;if (n==k||k==0){return 1;}else{return combination(n-1,k)+combination(n-1,k-1);}}
int a[N],b[N];
void solve(){
    int n=read();
    for(int i=1;i<=n;i++){
        a[i]=read();
        b[i]=a[i];
    }
    sort(b+1,b+1+n);
    int l=1,r=200000,mid=-1;
    if(n%2){
        int cnt=0,pnt=0;
        for(int i=n/2+1;i>=1;i--){
            if(b[i]==b[n/2+1])cnt++;
        }
        for(int i=n/2+1;i<=n;i++){
            if(b[i]==b[n/2+1])pnt++;
        }
        if(cnt==pnt){
            l=b[n/2+1];
            r=b[n/2+1];
            mid=1;
        }else {
            mid=-1;
        }
    }else {
        if(b[n/2]==b[n/2+1]){
            int cnt=0,pnt=0;
            for(int i=n/2;i>=1;i--){
                if(b[i]==b[n/2])cnt++;
            }
            for(int i=n/2+1;i<=n;i++){
                if(b[i]==b[n/2])pnt++;
            }
            if(cnt==pnt){
                l=b[n/2];
                r=b[n/2];
                mid=1;
            }else {
                mid=-1;
            }
        }else {
            l=b[n/2]+1;
            r=b[n/2+1]-1;
            mid=1;
        }
    }
    // cout<<mid<<" "<<l<<" "<<r<<'\n';
    if(mid==-1||l>r){
        cout<<0<<'\n';
        return ;
    }
    int cnt=0;
    for(int i=1;i<=n;i++){
        if(a[i]<l)cnt++;
        if(a[i]>r)cnt--;
    // cout<<"cnt:"<<cnt<<'\n';

        if(cnt<0){
            cout<<0<<'\n';
            return ;
        }
    }
    if(cnt!=0){
        cout<<0<<'\n';
        return ;
    }else cout<<r-l+1<<'\n';
    //puts(ans>0?"YES":"NO");
    //puts(ans>0?"Yes":"No");
}

signed main(){
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    // cout.tie(0);
    int t=1;
  //  int t=read();
    while(t--){
        solve();
    }
}