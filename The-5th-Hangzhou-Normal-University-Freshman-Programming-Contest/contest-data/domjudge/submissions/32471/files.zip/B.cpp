#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e5+10;
struct Node{
	ll x;
}a[N], b[N];
bool cmp(Node m, Node n)
{
	return  m.x < n.x;
}
int main()
{
   int n;
   cin >> n;
   ll ansa1 = 0, ansa2 = 0;
   ll ansb1 = 0, ansb2 = 0;
   for(int i = 1; i <= n; ++i){
   	  cin >> a[i].x;
   	  if(a[i].x > 0)
   	     ansa1++;
   	  else
   	     ansa2++;
   }	
   for(int i = 1; i <= n; ++i){
   	  cin >> b[i].x;
   	  if(b[i].x > 0)
   	     ansb1++;
   	  else
   	     ansb2++;
   }
   sort(a+1, a+n+1, cmp);
   sort(b+1, b+n+1, cmp);
	  int flag1 = 1;
	  int num = 0;
	  int sum2 = 0;
	  for(int i = 1; i <= n; ++i){
	  	if(a[i].x != b[i].x && num == 0){
	  	   sum2 = b[i].x - a[i].x;
		   flag1 = 1;
		   num++;	
		}
		else if(a[i].x != b[i].x && num && b[i].x - a[i].x != sum2){
			flag1 = 0;
			break;
		}
	  }
	  if(flag1)
	     cout << abs(sum2) << endl;
	  else
	     cout << -1 << endl;
}
