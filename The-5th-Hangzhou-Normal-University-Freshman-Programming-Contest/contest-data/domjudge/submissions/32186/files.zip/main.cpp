//#include <iostream>
//using namespace std;
//const int N = 2e5 + 10;
//long long qpow(long long a , long long n , long long mod){
//    long long ans = 1;
//    while(n){
//        if(n & 1){
//            ans = ans * a % mod;
//        }
//        n >>= 1;
//        a = a * a % mod;
//    }
//    return ans;
//}
//int fa[N] , a[N] , sum[N] , b[N];
//int n , q;
//void Init(){
//    for(int i = 1 ; i <= n;i++) {
//        fa[i] = i;
//        sum[i] = 1;
//    }
//}
//int find(int x){
//    return fa[x] == x ? x : find(fa[x]);
//}
//int main() {
//    cin >> n >> q;
//    Init();
//    for(int i = 1 ; i <= n;i++){
//        cin >> b[i];
//        a[i] = b[i];
//    }
//    for(int i = 1 ; i <= q;i++){
//        int k , u , v;
//        cin >> k >> u;
//        if(k == 1){
//            cin >> v;
//            int fu = find(u);
//            int fv = find(v);
//            if(fu != fv) {
//                fa[fv] = fu;
//                sum[fu] += sum[fv];
//                a[fu] += a[fv];
//            }
//        }else if(k == 2){
//            cin >> v;
//            int fu = find(u);
//            a[fu] += v * sum[fu];
//        }else{
//            cout <<
//        }
//    }
//    return 0;
//}


//#include "iostream"
//#include "map"
//using namespace std;
//const int N = 2e5 + 10;
//int a[N] , sum = 0;
//int fa[N] , b[N];
//int n , k;
//map<int,int> map1;
//void Init(){
//    for(int i = 1 ; i <= n;i++) {
//        fa[i] = i;
//        b[i] = 1;
//    }
//}
//int find(int x){
//    return fa[x] == x ? x : find(fa[x]);
//}
//int main(){
//    cin >> n >> k;
//    for(int i = 1 ; i <= n;i++){
//        cin >> a[i];
//        if(a[i] == i) sum++;
//    }
//    if(k == n - 1) cout << -1;
//    else{
//        if(sum >= k){
//            if((sum - k) % 2 == 0){
//                cout << (sum - k) / 2;
//            }else{
//                cout << (sum - k) / 2 + 1;
//            }
//        }else{
//            Init();
//            for(int i = 1 ; i <= n;i++){
//                if(a[i] != i && fa[i] == i){
//                    int z = a[i];
//                    while(z != i){
//                        int fz = find(z);
//                        int fi = find(a[z]);
//                        if(fz != fi){
//                            fa[fi] = fz;
//                            b[fz] += b[fi];
//                        }
//                        z = a[z];
//                    }
//                    map1[b[z]]++;
//                }
//            }
//            int ans = 0;
//            k -= sum;
//            for(auto i : map1){
//                if(i.first == 1) continue;
//                if(k <= i.first * i.second){
//                    ans += (k / i.first) * (i.first - 1) + (k % i.first);
//                    if(k % 2 == 1 && i.first == 2) ans++;
//                    k = 0;
//                }else{
//                    ans += (i.first - 1) * i.second;
//                    k -= i.first * i.second;
//                }
//                if(k == 0)break;
//            }
//            cout << ans;
//        }
//    }
//}


#include "iostream"
#include "algorithm"
using namespace std;
const int N = 2e5 + 10;
long long a[N] , sum[N];
int main(){
    int n , m , b;
    cin >> n >> m >> b;
    for(int i = 1 ; i <= n;i++){
        cin >> a[i];
        sum[i] = sum[i - 1] + a[i];
    }
    long long ans = 0;
    for(int i = (n - 1) % m + 1 ; i <= n ;i += m){
        if(sum[i] - ans <= b) ans += (sum[i] - ans);
        else ans += b;
    }
    cout << ans;
}