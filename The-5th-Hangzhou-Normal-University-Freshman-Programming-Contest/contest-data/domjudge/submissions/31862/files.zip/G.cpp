#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=200005;
ll k[M];
int main()
{
	int n,m,b;
	ll sum=0,ans=0;
	scanf("%d%d%d",&n,&m,&b);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&k[i]);
	}
	for(int i=1;i<=n;i++)
	{
		sum+=k[i];
		if((n-i)%m==0)
		{
			if(sum<=b) ans+=sum,sum=0;
			else ans+=b,sum=sum-b;
		}
	}
	cout<<ans;
	return 0;
}