#include <bits/stdc++.h>

using namespace std;
using LL = long long;

constexpr int N = 2e5 + 10;

int d[N], s[N];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    cin >> n;
    vector<int> a(n);
    for (auto &x : a) cin >> x;

    int cnt = 0;
    for (int i = 0; i < n; ++ i)
    {
        int j = i + 1;
        while (j < n && a[j - 1] <= a[j]) ++ j;
        if (j - i & 1) d[a[i + j >> 1]] ++ , d[a[i + j >> 1] + 1] -- ;
        else 
        {
            int l = i + j - 1 >> 1, r = i + j >> 1;
            if (a[r] - a[l] > 1) d[a[l] + 1] ++ , d[a[r]] -- ;
            if (a[r] == a[l]) d[a[l]] ++ , d[a[l] + 1] -- ;
        }
        cnt ++ ;
        i = j - 1;
    }
    for (int i = 1; i < N; ++ i) s[i] = s[i - 1] + d[i];

    int ans = count(s, s + N, cnt);
    if (ans == 1)
    {
        int sum = 0, k;
        for (int i = 1; i < N; ++ i)
            if (s[i] == cnt) k = i;
        for (int i = 0; i < n; ++ i) sum += a[i] > k, sum -= a[i] < k;
        ans -= sum != 0;
    }
    cout << ans << "\n";
}