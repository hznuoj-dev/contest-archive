#include<bits/stdc++.h>
#define rg register
#define il inline
typedef long long ll;
using namespace std;
ll mod = 1e9+7;
inline ll read() {
	ll ans = 0;
	char last = ' ', ch = getchar();
	while (ch < '0' || ch > '9') last = ch, ch = getchar();
	while (ch >= '0' && ch <= '9') ans = ans * 10 + ch - '0', ch = getchar();
	if (last == '-') return -ans;
	return ans;
}
il ll ksm(ll b,ll k){
	ll res=1;
	while(k){
		if(k&1) res=1ll*res*b%mod;
		b=1ll*b*b%mod;k>>=1;
	}
	return res;
}
int a[200020];
ll s[2000020];
int dp[200020];
int v[200020];
int main(){
	int n,m,b;
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		s[i]=s[i-1]+a[i];
	}
	ll ans=0;
	for(int i=n;i>=1;i-=m){
		v[i]=1;
	}
	ll s=0;
	for(int i=1;i<=n;i++){
		s+=a[i];
		if(v[i]){
			if(s>b)ans+=b,s-=b;
			else ans+=s,s=0;
		}
	}
	cout<<ans<<endl;
}

