#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e5+10;
ll a[N],b[N],c[N],d[N];
int main()
{
    ll n,i;
    ll flag=0;
    cin >> n;
    for(i=0;i<n;i++)
    {
        cin >> a[i];
    }
    for(i=0;i<n;i++)
    {
        cin >> b[i];
    }
    sort(a,a+n);
    sort(b,b+n);
    for(i=1;i<n;i++)
    {
        c[i]=a[i]-a[i-1];
        d[i]=b[i]-b[i-1];
    }
    for(i=1;i<n;i++)
    {
        if(c[i]!=d[i])
        {
            flag=1;
            break;
        }
    }
    if(flag==1)
    {
        for(i=1;i<n;i++)
        {
            if(c[i]!=d[n-i])
            {
                flag=2;
                break;
            }
        }
    }
    if(flag==2)
    {
        cout << "-1" << endl;
    }
    else if(flag==1)
    {
        cout << a[0]+b[0]+1 << endl;
    }
    else if(flag==0)
    {
        if(a[0]>=b[0])
        {
            cout << a[0]-b[0] << endl;
        }
        else
        cout << b[0]-a[0] << endl;
    }
    return 0;
}