#include<bits/stdc++.h>
using namespace std;
typedef struct total{
	int a;
	int b;
}t;
bool cmp(t x,t y)
{
	if(x.b == y.b)
	{
		return x.a<y.a;
	}
	else
	{
		return x.b>y.b;
	}
}
int main()
{
	int m,k;
	t c[5];
	cin>>m>>k;
	for(int i = 0; i < 5; i++)
	{
		cin>>c[i].a;
	}
	for(int i = 0; i < 5; i++)
	{
		cin>>c[i].b;
	}
	sort(c,c+5,cmp);
	float num1 = 0,num2 = 0,sum = 0,max = 0;
	for(int i = 0; i < 5;i++)
	{
		if(c[i].b>=c[i].a)
		{
			num1+=c[i].b;
			num2+=c[i].a;
			max = i;
		}
		else if(num1>=num2)
		{
			continue;
		}
		else
		{
			if(c[i].b-c[i].a<=2)
			{
				num1+=c[i].b;
				num2+=c[i].a;
				max = i;
			}
		}
	}
	if(num2>=m)
	{
		num2-=k;
		sum = num1/num2;
	}
	else
	{
		sum = num1/num2;
		for(int i = max; i < 5;i++)
		{
			num1+=c[i].b;
			num2+=c[i].a;
			if(num2>=m)
			{
				num2-=k;
				break;
			}
		}
		if(sum<num1/num2)
		{
			sum = num1/num2;
		}
	}
	printf("%.2f",sum);
	
}
