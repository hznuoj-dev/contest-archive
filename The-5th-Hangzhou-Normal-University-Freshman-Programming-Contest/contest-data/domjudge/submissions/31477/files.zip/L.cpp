#include<bits/stdc++.h>
using namespace std;

void solve(){
	int m,k;
	cin>>m>>k;
	int a[6]={0},b[6]={0};
	double suma=0,sumb=0;
	int n=5;
	for(int i=1;i<=5;i++){
		cin>>a[i];
		suma+=a[i];
	}
		
	for(int j=1;j<=5;j++){
		cin>>b[j];
		sumb+=b[j];
	}
		
	double sum1=0,sum2=0,max=0;
	//5
	sum1=suma;
	sum2=sumb;
	if(sum1>=m)sum1-=k;
	if(max<sum2/sum1)max=sum2/sum1;
	//4
	sum1=sum2=0;
	for(int i=1;i<=n;i++){
		sum1=suma-a[i];
		sum2=sumb-b[i];
		if(sum1>=m)sum1-=k;
		if(max<sum2/sum1)max=sum2/sum1;	
	}
	//1
	for(int i=1;i<=n;i++){
		sum1=a[i];
		sum2=b[i];
		if(sum1>=m)sum1-=k;
		if(max<sum2/sum1)max=sum2/sum1;	
	}
	//2
	for(int i=1;i<=n;i++){
		sum1=a[i];
		sum2=b[i];
		for(int j=i+1;j<=n;j++){
			sum1+=a[j];
			sum2+=b[j];
			double t=sum1;
			if(t>=m)t-=k;
			if(max<sum2/t)max=sum2/t;	
			sum1-=a[j];
			sum2-=b[j];
		}
	}
	//3
	sum1=suma;
	sum2=sumb;
	for(int i=1;i<=n;i++){
		sum1=suma-a[i];
		sum2=sumb-b[i];
		for(int j=i+1;j<=n;j++){
			sum1-=a[j];
			sum2-=b[j];
			double t=sum1;
			if(t>=m)t-=k;
			if(max<sum2/t)max=sum2/t;
			sum1+=a[j];
			sum2+=b[j];
		}	
	}
	printf("%.2lf\n",max);
}

signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t;
	//cin>>t;
	t=1;
	while(t--){
		solve();
	}
	return 0;
}
