#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;

long long a[maxn];
int main(){
	int t,m,n;
	long long b;
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++)cin>>a[i];
	long long ans=0,p=0;
	t=n%m;
	if(t==0)t+=m;
	for(int i=1;i<=n;i++){
		p+=a[i];
		if(i==t){
			if(p>=b){
				ans+=b;
				p-=b;
			}else {
				ans+=p;
				p=0;
			}
			t+=m;
		}
		//cout<<ans<<endl;
	}
	cout<<ans;
}