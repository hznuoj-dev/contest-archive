#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int long long
const ll N=5e5+7;
const ll mod=1e9+7;
const ll inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
const double eps=1e-6;

int a[N];
int f[N];
void solve()
{
	int n,m,b,sum=0;
	cin>>n>>m>>b;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
//		sum+=a[i];
//		if(i==0) f[i]=a[i];
//		else f[i]=f[i-1]+a[i];
	}
	int p=(n-1)%m;
//	int num=f[p];
int ans=0;
	for(int i=0;i<n;i++)
	{
		sum+=a[i];
		if((i-p)%m==0)
		{
			if(sum<b){
				ans+=sum;
				sum=0;
			}
			else
			{
				ans+=b;
				sum-=b;
			}
		}
	}
	cout<<ans;
}
signed main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int _=1;
//	cin>>_;
	while(_--)
	{
		solve();
	}
	return 0;
}


