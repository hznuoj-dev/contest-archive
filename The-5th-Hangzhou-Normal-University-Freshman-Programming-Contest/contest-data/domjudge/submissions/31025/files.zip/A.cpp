#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

int read() {
    int x = 0, f = 1; char c = getchar();
    while(c < '0' || c > '9') c == '-' ? f = -1: 0, c = getchar();
	while(c >= '0' && c <= '9') x = (x << 1) + (x << 3) + (c ^ '0'), c = getchar();
    return x * f;
}

int qpow(int a, int k, int r = 1) {
	for(; k; k >>= 1, a = a * a)
		if(k & 1) r = r * a;
	return r;
}

int n, a[200050], b[200050], cnt[200050];
int flag[200050];

int sol(int k) {
    int sum = 0;
    for(int i = 1; i <= n; ++i) {
        if(a[i] < k) ++sum;
        else if(a[i] > k) --sum;
        if(sum < 0) return -1;
    }
    return sum == 0 ? 1 : -1;
}

signed main() {
    n = read();
    
    int mx = 0;
    for(int i = 1; i <= n; ++i) {
        a[i] = b[i] = read();
        ++cnt[a[i]];
    }
    sort(b + 1, b + n + 1);
    int ans = 0;
    for(int i = 1; i <= 200000; ++i) {
        cnt[i] += cnt[i - 1];
        if(cnt[i - 1] == n - cnt[i]) {
            int rk = lower_bound(b + 1, b + n + 1, i) - b;
            if(flag[rk] == 0) flag[rk] = sol(i);
            ans += (flag[rk] == 1);
        }
    }
    cout << ans << endl;
    return 0;
}

