#include<bits/stdc++.h>
using namespace std;
int main(){
	int t,n;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		if(n<12){
			puts("No Solution");
			continue;
		}
		if(n%2){
			n-=9;
			n/=2;
			if(n%2==0){
				vector<int>now;
				while(n){
					n-=2;
					now.push_back(1);
				}
				int sz=now.size();
				
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				putchar('-');
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				puts("=6");
				
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				putchar('-');
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				puts("=0");
			}else{
				n-=3;
				vector<int>now;
				now.push_back(7);
				while(n){
					n-=2;
					now.push_back(1);
				}
				int sz=now.size();
				
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				putchar('-');
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				puts("=6");
				
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				putchar('-');
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				puts("=0");
			}
		}else{
			n-=2;
			n/=2;
			if(n%2){
				n-=5;
				vector<int>now;
				now.push_back(2);
				while(n){
					n-=2;
					now.push_back(1);
				}
				
				int sz=now.size();
				printf("3");
				for(int i=1;i<sz;i++)printf("%d",now[i]);
				putchar('=');
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				puts("");
				
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				putchar('=');
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				puts("");
			}else{
				n-=6;
				vector<int>now;
				while(n){
					n-=2;
					now.push_back(1);
				}
				now.push_back(6);
				int sz=now.size();

				for(int i=0;i<sz-1;i++)printf("%d",now[i]);
				printf("0");
				putchar('=');
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				puts("");
				
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				putchar('=');
				for(int i=0;i<sz;i++)printf("%d",now[i]);
				puts("");
			}
		}
	}
}
