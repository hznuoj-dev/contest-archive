#include<cstdio>
template<class type>inline const void read(type &in)
{
    in=0;char ch(getchar());
    while (ch<48||ch>57)ch=getchar();
    while (ch>47&&ch<58)in=(in<<3)+(in<<1)+(ch&15),ch=getchar();
}
const int N(2e5+5);
int n,a[N];
inline const int check(const int &k)
{
    int sum(0);
    for (int i(1);i<=n;i++)
        if ((sum+=(a[i]<k?1:a[i]>k?-1:0))<0)
            return -1;
    return sum>0?1:0;
}
int main()
{
    read(n);
    for (int i(1);i<=n;i++)read(a[i]);
    int l(1),r(2e5);
    while (l<=r)
    {
        const int mid(l+r>>1);
        if (check(mid)==-1)l=mid+1;
        else r=mid-1;
    }
    int L(l),R(2e5);
    while (L<=R)
    {
        const int mid(L+R>>1);
        if (check(mid)>0)R=mid-1;
        else L=mid+1;
    }
    printf("%d\n",R-l+1);
    return 0;
}