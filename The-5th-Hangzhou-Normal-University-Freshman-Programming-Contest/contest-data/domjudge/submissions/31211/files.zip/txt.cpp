#include <iostream>
#include <cstring>
#include <queue>
#include <math.h>
#include <algorithm>

using namespace std;
const int N = 2E5 + 5;
using ll = long long;
ll a[N], b[N];
int main()
{

    ll i, j, k, n, l = 0, o, flag1 = 1, flag2 = 1, step1 = -1, step2 = -2, left, right, sum = 0;
    priority_queue<ll> Q1;
    cin >> n;
    if (n == 1)
        cout << 1 << endl;
    else
    {
        for (i = 1; i <= n; i++)
        {
            cin >> k;
            Q1.push(k);
        }
        while (!Q1.empty())
        {
            l++;
            a[l] = Q1.top();
            Q1.pop();
        }
        left = a[n / 2];
        right = a[n / 2 + 1];
        if (left == right)
        {
            for (i = 1; i <= n; i++)
            {
                if (left == a[i])
                    sum++;
            }
            if (sum % 2 == 0)
                cout << 1 << endl;
            else
                cout << 0 << endl;
        }
        else
            cout << left - right - 1 << endl;
    }

    return 0;
}