#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<char> s;
int n,a[200005],ans,maxn;
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i],maxn=max(maxn,a[i]);
    int k=a[1],l=0;
    while(1)
    {
        int t=1;
        for(int i=1;i<=n;i++)
        {
           if(k>a[i])s.push_back('(');
           else if(k<a[i]&&!s.empty())s.pop_back();
           else if(k<a[i]&&s.empty()){t=0;break;}
        }
        if(s.empty()&&t){l=k;break;}
        s.clear();
        k++;
        if(k==maxn+1)break;
    }
    s.clear();
    k=maxn;
    int r=maxn+1;
    while(1)
    {
        int t=1;
        for(int i=1;i<=n;i++)
        {
           if(k>a[i])s.push_back('(');
           else if(k<a[i]&&!s.empty())s.pop_back();
           else if(k<a[i]&&s.empty()){t=0;break;}
        }
        if(s.empty()&&t){r=k;break;}
        s.clear();
        k--;
        if(k==0)break;
    }
    if(l==r)cout<<1;
    else if(l==0)cout<<0;
    else cout<<r-l+1;
    return 0;
}