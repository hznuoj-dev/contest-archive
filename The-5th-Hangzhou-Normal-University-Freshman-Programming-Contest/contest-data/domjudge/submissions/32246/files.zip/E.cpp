#include<cstdio>
#include<algorithm>
using namespace std;
template<class type>inline const void read(type &in)
{
    in=0;char ch(getchar());
    while (ch<48||ch>57)ch=getchar();
    while (ch>47&&ch<58)in=(in<<3)+(in<<1)+(ch&15),ch=getchar();
}
const int N(4e5+5),mod(1e9+7);
int n,m,fa[N],add[N],rk[N],sz[N],st[N],sum[N],cnt;
inline const int Find(int x)
{
    return x==fa[x]?x:Find(fa[x]);
}
inline const void Union(int x,int y,int t)
{
    int fx(Find(x)),fy(Find(y));
    if (fx==fy)return;
    rk[fa[fx]=fa[fy]=++cnt]=max(rk[fx],rk[fy])+1;
    sum[cnt]=(sum[fx]+sum[fy])%mod;
    sz[cnt]=sz[fx]+sz[fy];
    (add[fx]+=1ll*(t-st[fx])*sum[fx]%mod)%=mod;
    (add[fy]+=1ll*(t-st[fy])*sum[fy]%mod)%=mod;
    st[cnt]=t;
}
inline const void Add(int x,int y,int t)
{
    const int fx(Find(x));
    (add[fx]+=1ll*sum[fx]*(t-st[fx])%mod)%=mod;
    (sum[fx]+=1ll*sz[fx]*y%mod)%=mod;
    st[fx]=t;
}
inline const int Get(int x,int t)
{
    return (add[x]+(x==fa[x]?1ll*sum[x]*(t-st[x])%mod:Get(fa[x],t)))%mod;
}
void check()
{
    for (int i(1);i<=n;i++)
    printf("%d:sum:%d add:%d st:%d sz:%d\n",i,sum[i],add[i],st[i],sz[i]);
}
int main()
{
    read(n);read(m);cnt=n;
    for (int i(1);i<=n;i++)read(sum[i]),sz[i]=1;
    for (int i(1);i<=n<<1;i++)fa[i]=i;
    for (int i(1),opt,x,y;i<=m;i++)
        switch (read(opt),read(x),opt)
        {
            case 1:read(y);Union(x,y,i);break;
            case 2:read(y);Add(x,y,i);break;
            case 3:printf("%d\n",Get(x,i));break;
        }
    return 0;
}