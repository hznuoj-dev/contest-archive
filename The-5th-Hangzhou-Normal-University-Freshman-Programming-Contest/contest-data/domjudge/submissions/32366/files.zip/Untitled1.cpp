#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn=2e5+7;
ll n,q,ans;
ll a[maxn],b[maxn];
map<pair<ll,ll>,ll >mp;
void solve(){
	cin>>n;
	for(int i=1;i<=n-1;i++){
		ll u,v,w;
		cin>>u>>v>>w;
		a[u]++;
		a[v]++;
		mp[{u,v}]=w;
		mp[{v,u}]=w;
		ans^=w;
	}
	ll cnt=0;
	for(int i=1;i<=n;i++){
		if(a[i]%2==0){
			b[++cnt]=i;
		}
	}
	for(int i=1;i<=cnt;i+=2){
		ans^=mp[{b[i],b[i+1]}];
	}
	cin>>q;
	while(q--){
		ll x,y;
		cin>>x>>y;
		cout<<ans<<endl;
	}
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
	return 0;
}