#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;
const int N = 1e4 + 3;
const int P = 1e9 + 7;

int e[N * 2], ne[N * 2], h[N], idx;
void add(int a, int b) {
    e[idx] = b, ne[idx] = h[a], h[a] = idx++;
}
int fa[N];
int deep[N];
std::vector<std::vector<int>>son;
std::vector<std::vector<int>>dep;
void dfs(int t, int f) {
    fa[t] = f;
    dep[deep[t]].push_back(t);
    for(int i = h[t];~i;i = ne[i]) {
        int j = e[i];
        if(j == f) continue;
        son[t].push_back(j);
        deep[j] = deep[t] + 1;
        dfs(j, t);
    }
}
std::vector<pii>road;
int getroad(int a, int b) {
    if(a > b) std::swap(a, b);
    for(int i = 0;i < road.size();i++) {
        if(road[i].first == a && road[i].second == b) {
            return i + 1;
        }
    }
    return -1;
}
void solve() {
    int n;
    std::cin >> n;
    memset(h, -1, sizeof h);
    idx = 0;
    std::vector<int>du(n + 3);
    son.clear();
    son.resize(n + 3);
    dep.clear();
    dep.resize(n + 3);
    road.clear();
    for(int i = 1;i < n;i++) {
        int u, v;
        std::cin >> u >> v;
        road.emplace_back(std::min(u, v), std::max(u, v));
        add(u, v);
        add(v, u);
    }
    dfs(1, 0);
    std::vector<bool>st(n + 3);
    for(int i = n;i >= 0;i--) {
        for(auto p : dep[i]) {
            if(st[p])continue;
            int f = fa[p];
            std::vector<int>s(son[f]);
            int start = -1;
            for(int j = 0;j < s.size();j++) {
                if(st[s[j]]) continue;
                if(start == -1) start = s[j];
                else {
                    std::cout << "? " << start << " " << s[j] << std::endl;
                    int hh;std::cin >> hh;
                    if(hh) {
                        std::cout << "? " << start << " " << f << std::endl;
                        std::cin >> hh;
                        if(hh) std::cout << "! " << getroad(start, f) << std::endl;
                        else std::cout << "! " << getroad(s[j], f) << std::endl;
                        return;
                    }
                    st[start] = true;
                    st[s[j]] = true;
                    start = -1;
                }
            }
            if(start != -1) {
                if(f == 1) {
                    std::cout << "! " << getroad(start, f) << std::endl;
                    return;
                }
                int ff = fa[f];
                std::cout << "? " << start << " " << ff << std::endl;
                int hh; std::cin >> hh;
                if(hh) {
                    std::cout << "? " << start << " " << f << std::endl;
                    std::cin >> hh;
                    if(hh) std::cout << "! " << getroad(start, f) << std::endl;
                    else std::cout << "! " << getroad(ff, f) << std::endl;
                    return;
                }
                st[start] = true;
                st[f] = true;
            }
        }
    }

}

int main() {
//    std::ios::sync_with_stdio(false);
//    std::cin.tie(nullptr);
//    std::cout.tie(nullptr);
    int T = 1;
    std::cin >> T;
    while(T--) {
        solve();
    }
}