#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
typedef long long ll;
ll a[2000000];
ll b[2000000];
bool cmp(ll a, ll b) {


	return a > b;

}
int main()
{
	ll n;
	cin >> n;
	for (ll i = 0; i < n; i++)
	{
		cin >> a[i];
	}
	for (ll i = 0; i < n; i++)
	{
		cin >> b[i];
	}
	sort(a, a + n, cmp);
	sort(b, b + n, cmp);
	double t = 0;
	t = a[0] - b[0];
	for (ll i = 1; i < n; i++)
	{

		if (a[i] - b[i] != t) { cout << -1; return 0; }


	}
	cout << abs(t);


	return 0;
}






