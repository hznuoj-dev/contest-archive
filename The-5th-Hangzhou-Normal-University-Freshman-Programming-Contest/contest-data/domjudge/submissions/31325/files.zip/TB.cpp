#include<bits/stdc++.h>
using namespace std;
int a[200001],b[200001],c[200001];
int main()
{
	std::ios::sync_with_stdio(false);
	int n,i;
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(i=1;i<=n;i++)
	{
		cin>>b[i];
	}
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	for(i=1;i<=n;i++)
	{
		c[i]=-b[n-i+1];
	}
	for(i=2;i<=n;i++)
	{
		if(b[i]-a[i]!=b[i-1]-a[i-1])
		{
			break;
		}
	}
	if(i==n+1)
	{
		cout<<abs(b[1]-a[1]);
		return 0;
	}
	for(i=2;i<=n;i++)
	{
		if(c[i]-a[i]!=c[i-1]-a[i-1])
		{
			break;
		}
	}
	if(i==n+1)
	{
		cout<<1+abs(c[1]-a[1]);
		return 0;
	}
	cout<<-1;
	return 0;
}
