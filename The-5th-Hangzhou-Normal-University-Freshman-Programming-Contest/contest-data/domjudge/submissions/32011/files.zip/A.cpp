#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define ll long long

using namespace std;

const int N = 2e5+5;
int n,a[N];
struct qu{
	int l,r;
}b[N],mer;

bool merge(qu &a,qu b){
	if(a.l>b.r||b.l>a.r){
		return false;
	}else{
		a.l = max(a.l,b.l);
		a.r = min(a.r,b.r);
		return true;
	}
}
int main(){
	IOS
	int cnt = 1;
	cin >> n;
	for(int i=1;i<=n;i++)cin >> a[i];
	b[cnt].l = 1;
	for(int i=2;i<=n;i++){
		if(a[i]>=a[i-1]){
			b[cnt].r = i;
		}else{
			b[++cnt].l = i; 
		}
	}
	int ans = 0,tl,tr,len;
	for(int i=1;i<=cnt;i++){
		tl = b[i].l;tr = b[i].r;
		if((tl-tr+1)%2){
			b[i].l = b[i].r = a[(tl+tr)/2];
		}else{
			b[i].l = a[(tl+tr)/2];
			b[i].r = a[(tl+tr)/2+1];
		}
	}
	mer.l = b[1].l;
	mer.r = b[1].r;
	bool f = true;
	for(int i=2;i<=cnt;i++){
		f = merge(mer,b[i]);
		if(!f){
			cout << 0 << endl;
			return 0;
		}
	}
	if(mer.r-mer.l==0)cout << 1 << endl;
	else cout << mer.r-mer.l-1 << endl;
	
	
	return 0;
} 
