#include<iostream>
#include<algorithm>
using namespace std;
int a[200010],b[200010];
int n;
int flag1,ans;
int main()
{
    cin >> n;
    for (int i = 1; i <= n ; i ++ ) cin >> a[i];
    for (int i = 1; i <= n ; i ++ ) cin >> b[i];
    sort(a + 1,a + n + 1),sort(b + 1,b + n + 1);
    //for (int i = 1; i <= n; i ++ ) cout << a[i] << " ";
    int x = a[1] - b[1],flag = 0;
    for (int i = 2; i <= n ; i ++ )
    {
        if (a[i] - b[i] != x) flag = 1;
    }
    int y = 0;
    for (int i = 1; i <= n; i ++ )
    {
        if (a[i] != a[1]) flag1 = 1;
        if (b[i] != b[1]) flag1 = 1;
    }
    if (flag1 == 0) ans = abs(min(a[1],b[1]) * 2); 
    if (flag == 1)
    {
    for (int i = 1; i <= n; i ++ )
    {
        a[i] = 0 - a[i];
    }
    sort(a + 1,a + n + 1);
    y = a[1] - b[1];
    for (int i = 2; i <= n ; i ++ )
    {
        if (a[i] - b[i] != y && flag != -1) 
        {
            cout << "-1" << endl;
            flag = -1;
        }
    } 
    }
    if (flag == 0 && ((a[1] == abs(a[1]) && b[1] == abs(b[1]) || a[1] != abs(a[1]) && b[1] != abs(b[1]) ))) cout << abs(x);
    if (flag == 0 && flag1 == 0 &&((a[1] != abs(a[1]) && b[1] == abs(b[1]) || a[1] == abs(a[1]) && b[1] != abs(b[1]) ))) cout << abs(x) - ans + 1;
    if (flag == 1) cout << abs(y) + 1;
    return 0;
}