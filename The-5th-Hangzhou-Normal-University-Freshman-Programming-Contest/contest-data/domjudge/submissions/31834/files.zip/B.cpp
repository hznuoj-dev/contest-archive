#include<stdio.h>
#include<stdlib.h>
#include<math.h>
int qsort_int(const void *a1, const void *a2)
{
	return *(int*)a1 - *(int*)a2;
}
void operate1(int a[], int n)
{
	for (int i = 1; i <= n; i++)
	{
		a[i] = -a[i];
	}
}

void operate2(int a[], int n)
{
	for (int i = 1; i <= n; i++)
	{
		a[i] = a[i] + 1;
	}
}

void operate3(int a[], int n)
{
	for (int i = 1; i <= n; i++)
	{
		a[i] = a[i] - 1;
	}
}
int main()
{
	int flag = 1;
	int a[200005], b[200005];
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
	}
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &b[i]);
	}
	qsort(a + 1, n, sizeof(int), qsort_int);
	qsort(b + 1, n, sizeof(int), qsort_int);
	
	for (int i = 2; i <= n; i++)
	{
		if (a[i] - b[i] != a[1] - b[1])
		flag = 0;
	}
	if (flag == 1)
	printf("%d\n", abs(a[1] - b[1]));
	else if (flag == 0)
	printf("-1\n");
}
