#include<iostream>
using namespace std;
double a[10],b[10];
int f[10];
int m,d;
int main()
{
    cin >> m >> d;
    for (int i = 1; i <= 5; i ++ ) cin >> a[i];
    for (int i = 1; i <= 5; i ++ ) cin >> b[i];
    double max1 = -1;
    for (int i = 1; i <= 5; i ++ )
    {
        double ans = a[i];
        if (ans >= m) ans = ans - d;
        max1 = max(max1,b[i]/ans);
    }
    for (int i = 1; i <= 5; i ++ )
    {
        for (int j = i + 1; j <= 5; j ++ )
        {
            double ans = a[i] + a[j];
            double ans1 = b[i] + b[j];
            if (ans >= m) ans = ans - d;
            max1 = max(max1,ans1/ans);
            //cout << i << j << endl;
        }
    }
    for (int i = 1; i <= 5; i ++ )
    {
        for (int j = i + 1; j <= 5; j ++ )
        {
           for (int k = j + 1; k <= 5; k ++)
           {
                double ans = a[i] + a[j] + a[k];
                double ans1 = b[i] + b[j] + b[k];
                if (ans >= m) ans = ans - d;
                max1 = max(max1,ans1/ans);
                //cout << i << j << k << endl;
           }
        }
    }
    for (int i = 1; i <= 5; i ++ )
    {
        for (int j = i + 1; j <= 5; j ++ )
        {
           for (int k = j + 1; k <= 5; k ++)
           {
                for (int n = k + 1;n <= 5 ;n ++ )
                {
                    //cout << i << j << k << n << endl;
                    double ans = a[i] + a[j] + a[k] + a[n];
                    double ans1 = b[i] + b[j] + b[k] + b[n];
                    if (ans >= m) ans = ans - d;
                    max1 = max(max1,ans1/ans);
                }
           }
        }
    }
    double ans = a[1] + a[2] + a[3] + a[4] + a[5];
    double ans1 = b[1] + b[2] + b[3] + b[4] + b[5]; 
    if (ans >= m) ans = ans - d;
    max1 = max(max1,ans1/ans);
    printf("%.2lf",max1);
    return 0;
}