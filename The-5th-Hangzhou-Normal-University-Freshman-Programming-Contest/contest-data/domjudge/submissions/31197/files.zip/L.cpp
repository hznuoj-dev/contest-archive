#include<bits/stdc++.h>
#define int long long
using namespace std;

int w[6], v[6]; // w�۸� v����ֵ ans = max{fi / (i>=m ? i-k:i);}
int f[1005];

signed main(){
	int m, k;
	cin >> m >> k;
	for(int i = 1; i <= 5; i++) cin >> w[i];
	for(int i = 1; i <= 5; i++) cin >> v[i];
	for(int i = 1; i <= 5; i++){
		for(int j = 1000; j >= w[i]; j--){
			f[j] = max(f[j], f[j - w[i]] + v[i]);
		}
	}
	double ans = -1.0;
	for(int i = 0; i <= 1000; i++){
		ans = max(ans, 1.0 * f[i] / (i >= m ? i-k:i));
	}
	cout << fixed << setprecision(2) << ans;
} 
