#include <bits/stdc++.h>
using namespace std;
const int N = 15;
struct Bis {
	int pri;
	int val;
	double pvp;//�Լ۱�
} a[N];

bool cmp(Bis x, Bis y) {
	return x.pvp > y.pvp;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int m, k, vis = 0;
	cin >> m >> k;
	double sumpri=0,sumval=0;
	for(int i = 1; i <= 5; i++) {
		cin >> a[i].pri;
		sumpri += a[i].pri;
	}
	for(int i = 1; i <= 5; i++) {
		cin >> a[i].val;
		sumval += a[i].val;
	}
	double maxn = 0.0;
//	for(int i = 1; i <= 5; i++) {
//		for(int j = i; j <= 5; j++) {
//			int tcost = 0, tval = 0, vis = 0;
//			for(int k = j + 1; k <= 5; k++) {
//				tcost += a[k].pri;
//				if(tcost >= m && !vis) {
//					tcost -= k;
//					vis = 1;
//				}
//				tval += a[k].val;
//				if(tval * 1.0 / tcost > maxn) {
//					maxn = tval * 1.0 / tcost;
//				}
//			}
//		}
//	}
	double sump,sumv;
	//5
	sump=sumpri;
	sumv=sumval;
	if(sump >= m) {
		sump -= k;
	}
	if(maxn < sumv * 1.0 / sump) {
		maxn = sumv * 1.0 / sump;
	}
	//1
	for(int i = 1; i <= 5; i++) {
		sump = a[i].pri;
		sumv = a[i].val;
		if(sump >= m) {
			sump -= k;
		}
		if(maxn < sumv * 1.0 / sump) {
			maxn = sumv * 1.0 / sump;
		}
	}
	//4
	for(int i = 1; i <= 5; i++) {
		sump = sumpri - a[i].pri;
		sumv = sumval - a[i].val;
		int tmp = sump;
		if(tmp >= m) {
			tmp -= k;
		}
		if(maxn < sumv * 1.0 / tmp) {
			maxn = sumv * 1.0 / tmp;
		}
	}
	//2
	for(int i = 1; i <= 5; i++) {
		sump = a[i].pri;
		sumv = a[i].val;
		for(int j = i + 1; j <= 5; j++) {
			sump += a[j].pri;
			sumv += a[j].val;
			int tmp = sump;
			if(tmp >= m) {
				tmp -= k;
			}
			if(maxn < sumv * 1.0 / tmp) {
				maxn = sumv * 1.0 / tmp;
			}
			sump = sump - a[j].pri;
			sumv = sumv - a[j].val;
		}
	}
	//3
	for(int i = 1; i <= 5; i++) {
		sump = sumpri - a[i].pri;
		sumv = sumval - a[i].val;
		for(int j = i + 1; j <= 5; j++) {
			sump = sump - a[j].pri;
			sumv = sumv - a[j].val;
			int tmp = sump;
			if(tmp >= m) {
				tmp -= k;
			}
			if(maxn < sumv * 1.0 / tmp) {
				maxn = sumv * 1.0 / tmp;
			}
			sump = sump + a[j].pri;
			sumv = sumv + a[j].val;
		}
		//sump = sumpri + a[i].pri;
		//sumv = sumval + a[i].val;
	}
	printf("%.2f", maxn);
	return 0;
}
