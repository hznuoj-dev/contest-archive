#include<bits/stdc++.h>
#define int long long
#define inf 0x3f3f3f3f

using namespace std;

void solve() {
	int n;
	cin >> n;
	vector<int> a(n + 1), b(n + 1), c(n + 1);

	int ans = -1;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for(int i = 1; i <= n; i++) {
		cin >> b[i];
	}
	sort(a.begin() + 1, a.end());
	sort(b.begin() + 1, b.end());
	
	int flag = 1;
	for(int i = 1; i <= n; i++){
		c[i] = b[i] - a[i];
		if(i > 1 && c[i] != c[i - 1]) flag = 0;
	}
	if(flag){
		ans = min(abs(b[1] - a[1]), abs(b[1] + a[1]) + 1);
	}

	cout << ans;
	return;
}
signed main() {
	ios::sync_with_stdio(0);

	int T = 1;
//	cin >> T;
	while(T--) {
		solve();
	}

	return 0;
}
