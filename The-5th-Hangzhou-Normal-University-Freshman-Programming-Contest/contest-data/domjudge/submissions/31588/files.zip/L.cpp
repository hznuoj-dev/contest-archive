#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int a[10], b[10];

int main()
{
	int m, c;
	cin >> m >> c;
	for (int i = 0; i < 5; i++)
	{
		cin >> a[i];
	}
	for (int i = 0; i < 5; i++)
	{
		cin >> b[i];
	}
	int sum = 0, sum2 = 0;
	double maxx = 0;
	for (int i = 0; i <= 1; i++)
	{
		for (int j = 0; j <= 1; j++)
		{
			for (int k = 0; k <= 1; k++)
			{
				for (int u = 0; u <= 1; u++)
				{
					for (int v = 0; v <= 1; v++)
					{
						sum = a[0] * i + a[1] * j + a[2] * k + a[3] * u + a[4] * v;
						sum2 = b[0] * i + b[1] * j + b[2] * k + b[3] * u + b[4] * v;
						if (sum >= m)
						{
							maxx = max(maxx, (double)sum2 / (double)(sum - c));
						}
						else
						{
							maxx = max(maxx, (double)sum2 / (double)(sum));
						}
					}
				}
			}
		}
	}
	printf("%.2lf", maxx);
	return 0;
}




//double dp[1005][1005];
//int m, k;
//double a[60], b[60];
//int sum = 0;
//
//int main()
//{
//	cin >> m >> k;
//	for (int i = 1; i <= 5; i++)
//	{
//		cin >> a[i];
//		sum += a[i];
//	}
//	for (int i = 1; i <= 5; i++)
//	{
//		cin >> b[i];
//	}
//	for (int i = 1; i <= 5; i++)
//	{
//		for (int j = 0; j <= 1000; j++)
//		{
//			dp[i][j] = dp[i - 1][j];
//			if (j >= a[i])
//			{
//				dp[i][j] = max(dp[i][j], dp[i - 1][j - a[i]] + b[i]);
//			}
//		}
//	}
//	double maxx = 0;
//	for (int i = 1; i <= 1000; i++)
//	{
//		if (i >= m)
//		{
//			maxx = max(maxx, dp[5][i] / (i - k));
//		}
//		else
//		{
//			maxx = max(maxx, dp[5][i] / i);
//		}
//	}
//	printf("%.2lf", maxx);
//	return 0;
//}


