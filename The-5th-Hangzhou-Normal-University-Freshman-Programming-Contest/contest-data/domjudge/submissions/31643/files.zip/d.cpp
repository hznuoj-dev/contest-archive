#include <bits/stdc++.h>
#define fp(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fb(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define go(u, i) for(int i = head[u]; i; i = e[i].nxt)
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
inline int rd() {
	register int x(0), f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline LL RD() {
	register LL x(0); register int f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline int int_rand(int l, int r){
	int res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
inline LL LL_rand(LL l, LL r){
	LL res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
const int maxn = 200010;
int n, k, m, a[maxn], f[maxn];
long long ans[maxn];
deque<int> q1, q2;
struct node{
	long long sum;
	int tg;
}t[maxn<<2];
struct query{int l, r, id;}q[maxn];
inline void pushdown(int d, int l, int md, int r){
	t[d<<1].sum += 1ll*(md-l+1)*t[d].tg, t[d<<1].tg += t[d].tg;
	t[d<<1|1].sum += 1ll*(r-md)*t[d].tg, t[d<<1|1].tg += t[d].tg;
	t[d].tg = 0;
}
void mdf(int d, int l, int r, int dl, int dr){
	if(dl <= l && r <= dr)return ++t[d].tg, t[d].sum += r-l+1, void();
	int md = l+r>>1;
	if(t[d].tg)pushdown(d, l, md, r);
	if(dl <= md)mdf(d<<1, l, md, dl, dr);
	if(dr > md)mdf(d<<1|1, md+1, r, dl, dr);
	t[d].sum = t[d<<1].sum+t[d<<1|1].sum;
}
long long qry(int d, int l, int r, int dl, int dr){
	if(dl <= l && r <= dr)return t[d].sum;
	int md = l+r>>1; long long ans = 0;
	if(t[d].tg)pushdown(d, l, md, r);
	if(dl <= md)ans = qry(d<<1, l, md, dl, dr);
	if(dr > md)ans += qry(d<<1|1, md+1, r, dl, dr);
	return ans;
}
int main(){
	n = rd(), k = rd(), m = rd();
	fp(i, 1, n)a[i] = rd();
	int now = 1;
	fp(i, 1, n){
		while(q1.size() && a[q1.back()] <= a[i])q1.pop_back();
		while(q2.size() && a[q2.back()] >= a[i])q2.pop_back();
		q1.push_back(i), q2.push_back(i);
		while(a[q1.front()]-a[q2.front()] > k){
			if(q1.front() < q2.front())now = q1.front()+1, q1.pop_front();
			else now = q2.front()+1, q2.pop_front();
		}
		f[i] = now;
	}
//	fp(i, 1, n)printf("%d ", f[i]);puts("");
	fp(i, 1, m)q[i].l = rd(), q[i].r = rd(), q[i].id = i;
	sort(q+1, q+1+m, [&](query &x, query &y){return x.r < y.r;}), now = 0;
	fp(i, 1, n){
		mdf(1, 1, n, f[i], i);
		while(now < m && q[now+1].r <= i)++now, ans[q[now].id] = qry(1, 1, n, q[now].l, q[now].r);
//		fp(i, 1, n)printf("%d ", qry(1, 1, n, i, i));puts("");
	}
	fp(i, 1, m)printf("%lld\n", ans[i]);
	return 0;
}
