#include<iostream>
using namespace std;
int main()
//{
//	long long a[50001], b[50001], c[50001];
//	int n;
//	cin >> n;
//	for (int i = 1; i <= n; i++)
//	{
//		cin >> a[i];
//	}
//	for (int i = 1; i <= n; i++)
//	{
//		cin >> b[i];
//		c[i] = -b[i];
//	}
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= n - i; j++)
//		{
//			if (a[j] > a[j + 1])
//			{
//				long long temp = a[j];
//				long long temp1 = a[j + 1];
//				a[j] = temp1;
//				a[j + 1] = temp;
//			}
//			if (b[j] > b[j + 1])
//			{
//				long long temp = b[j];
//				long long temp1 = b[j + 1];
//				b[j] = temp1;
//				c[j] = -temp1;
//				b[j + 1] = temp;
//				c[j + 1] = -temp;
//			}
//		}
//	}
//	int m = 0;
//	int t = 0;
//
//	for (int i = 1; i <= n; i++)
//	{
//		if (a[i] < 0)
//		{
//			m++;
//		}
//		if (b[i] < 0)
//		{
//			t++;
//		}
//	}
//	if (m != t && (n - m) != t)
//	{
//		cout << -1;
//		return 0;
//	}
//	for (int i = 1; i <= m; i++)
//	{
//		for (int j = 1; j <= m - i; j++)
//		{
//			long long temp = a[j];
//			a[j] = a[j + 1];
//			a[j + 1] = temp;
//		}
//	}
//	for (int i = 1; i <= t; i++)
//	{
//		for (int j = 1; j <= t - i; j++)
//		{
//			long long temp = b[j];
//			b[j] = b[j + 1];
//			b[j + 1] = temp;
//		}
//	}
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= n - i; j++)
//		{
//			if (c[j] > c[j + 1])
//			{
//				long long temp = c[j];
//				long long temp1 = c[j + 1];
//				c[j] = temp1;
//				c[j + 1] = temp;
//			}
//		}
//	}
//	for (int i = 1; i <= n - t; i++)
//	{
//		for (int j = 1; j <= n - t - i; j++)
//		{
//			if (c[j] < c[j + 1]) {
//				long long temp = c[j];
//				c[j] = c[j + 1];
//				c[j + 1] = temp;
//			}
//		}
//	}
//
//	long long x = a[1], y = b[1], z = c[1];
//	for (int i = 1; i <= n; i++)
//	{
//		long long x1 = a[i], y1 = b[i], z1 = c[i];
//		if (x1 - y1 != x - y)
//		{
//			if (x1 - z1 != x - z)
//			{
//				cout << -1;
//				return 0;
//
//			}
//		}
//	}
//
//	if (m = n - t)
//	{
//		cout << abs(x - z) + 1;
//		return 0;
//
//	}
//	if (m == t)
//	{
//		if (x * y >= 0)
//		{
//			cout << abs(x - y); return 0;
//		}
//		if (x * y < 0)
//		{
//			x = -x;
//			cout << abs(x - y) + 1; return 0;
//		}
//	}
//	return 0;
//}

{
	int m, k;
	double a[6], b[6], c[6];
	cin >> m >> k;
	for (int i = 1; i <=5; i++)
	{
		cin >> a[i];
	}
	for (int i = 1; i <= 5; i++)
	{
		cin >> b[i];
	}
	for (int i = 1; i <= 5; i++)
	{
		double x = a[i], y = b[i];
		c[i] = y / x;
	}
	for (int i = 1; i <= 5; i++)
	{
		for (int j = 1; j <= 5 - i; j++)
		{
			if (c[j] < c[j + 1])
			{
				double temp = c[j];
				c[j] = c[j + 1];
				c[j + 1] = temp;
				double temp1 = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp1;
				double temp2 = b[j];
				b[j] = b[j + 1];
				b[j + 1] = temp2;
			}
		}
	}
	double x = a[1], y = b[1], q = 0, w = 0;
	double max = y / x;
	for (int i = 1; i <= 5; i++)
	{
		double x1 = a[i], y1 = b[i];
		q = q + x1;//总价
		w = w + y1;//总评价
		if (q >= m)
		{
			if (w / (q - k) > max)
			{
				max = w / (q - k);
			}

		}
		else 
		{
			if (w / q > max)
			{
				max = w / (q - k);
			}
		}

	}
	printf("%.2lf", max);
	return 0;
}
