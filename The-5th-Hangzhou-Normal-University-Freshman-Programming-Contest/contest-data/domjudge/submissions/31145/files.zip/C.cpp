#include <bits/stdc++.h>

using i64 = long long;

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);

    int n;
    std::cin >> n;

    std::vector<int> a(n), b(n);
    for (int i = 0; i < n; i++)
        std::cin >> a[i];
    for (int i = 0; i < n; i++)
        std::cin >> b[i];

    std::sort(a.begin(), a.end());
    std::sort(b.begin(), b.end());

    std::vector<int> c(n), d(n);
    for (int i = 0; i < n; i++)
        c[i] = b[i] - a[i], d[i] = -a[i];
    std::sort(d.begin(), d.end());

    bool flag = false;
    for (int i = 0; i < n - 1; i++)
        if (c[i] != c[i + 1])
            flag = true;

    if (flag)
        std::cout << -1 << '\n';
    else
    {
        i64 res = 0;
        res = std::min(std::abs(b[0] - a[0]), std::abs(b[0] - d[0]) + 1);
        std::cout << res << '\n';
    }

    return 0;
}