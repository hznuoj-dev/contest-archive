#include <iostream>
#include <algorithm>
#include <string.h>
#include <math.h>

#define int long long
using namespace std;

const int N = 2e5 + 10;

int a[N] = {-1};

void solve()
{
    int n;
    int flag = 1;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    if (n == 1)
    {
        cout << 1 << endl;
        return;
    }
    int max, min;
    int pos1 = 1, pos2 = 1;
    for (int i = 1; i <= n; i++)
    {
        // cout << i << endl;
        if (a[i] <= a[i + 1])
        {
            pos2++;
            // cout << pos2 << endl;
        }
        else
        {
            if (pos1 == 1)
            {
                max = a[pos1];
                min = a[pos2];
            }
            if ((pos2 - pos1) % 2 == 0)
            {
                if (a[(pos2 / 2 + 1)] >= max && a[(pos2 / 2 + 1)] <= min)
                {
                    min = a[(pos2 / 2 + 1)];
                    max = a[(pos2 / 2 + 1)];
                }
                else
                {
                    cout << 0 << endl;
                    return;
                }
            }
            else
            {
                if (a[(pos2 - pos1 + 1) / 2 + pos1] <= min)
                    min = a[(pos2 - pos1 + 1) / 2 + pos1];
                else
                    flag = 0;
                if (a[(pos2 - pos1 + 1) / 2 + pos1 - 1] >= max)
                    max = a[(pos2 - pos1 + 1) / 2 + pos1 - 1];
                else
                    flag = 0;
                if (flag == 0)
                {
                    cout << 0 << endl;
                    return;
                }
            }
            if ((a[pos1] == max || a[pos2] == min) && pos1 != 1 && pos2 != 2 && max != min)
            {
                cout << 0 << endl;
                cout << pos1 << ' ' << pos2 << endl;
                return;
            }
            pos1 = i + 1;
            pos2 = pos1;
        }
    }
    //    cout << min << ' ' << max << endl;
    if (max == min)
        cout << 1 << endl;
    else
        cout << min - max - 1 << endl;
}

signed main()
{
    int t = 1;
    //	cin >> t;
    while (t--)
    {
        solve();
    }
    return 0;
}