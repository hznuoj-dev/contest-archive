#include <iostream>
#include <algorithm>
using namespace std;
int main(){
	long long k;
	int n, n1,  flag = 0;
	long  a[200000], b[200000];
	cin>>k;
	for (int i  = 0; i < k; i++)
		cin>>a[i];	
	for (int i = 0; i < k; i++)
		cin>>b[i];
	sort(a, a + k);
	sort(b, b + k);
	n = a[0] - b[0];
	for (int i = 0; i < k; i++)
		if (a[i] - b[i] != n){
		flag = 1;
	}
	for (int i = 0; i < k; i++ )
		a[i] = -a[k - i - 1];
	//sort(a, a + k - 1);
	flag = 2;
	n1 = b[0] - a[0]; 
	if (flag == 1)
		for (int i = 0; i < k; i++)
			if (b[i] - a[i] != n1)
				flag = 1;	
	if (flag == 2){
		if (n1 < 0)
			n1 = -n1;
		if (n < 0)
			n = -n; 
		cout<<min(n1 + 1, n);
		return 0;
	}
	if (flag == 0){
		if (n < 0)
			n = -n;
		cout<<n;
		return 0;
	}
	if (flag == 1){
		cout<<-1;
	}
}
