#include <bits/stdc++.h>
#define int ll
using namespace std;
using ll = long long;
using ull = unsigned long long;
int a[200010], b[200010];
int a1[200010];
void solve(){
	int n;
	cin>>n;
	for(int i = 1;i<=n;i++){
		cin>>a[i];
		a1[i] = -a[i];
	}
	for(int i = 1;i<=n;i++){
		cin>>b[i];
	}
	sort(a+1,a+n+1);
	sort(a1+1,a1+n+1);
	sort(b+1,b+n+1);
	bool flag1 = true, flag2 = true;
	int ans1 = abs(a[1]-b[1]), ans2 = 1 + abs(a1[1]-b[1]);
	for(int i = 1;i<=n;i++){
		if(ans1!=abs(a[i]-b[i])){
			flag1 = false;
		}
	}
	for(int i = 1;i<=n;i++){
		if(ans2!=1+abs(a1[i]-b[i])){
			flag2 = false;
		}
	}
	if(flag1&&flag2)cout<<min(ans1,ans2);
	else if(flag1)cout<<ans1;
	else if(flag2)cout<<ans2;
	else cout<<-1;
}

signed main(){
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}

