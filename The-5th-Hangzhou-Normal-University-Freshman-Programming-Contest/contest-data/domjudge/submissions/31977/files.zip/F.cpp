#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define fi first
#define se second
#define pii pair<int,int>
#define pb push_back
const int N = 2E5 + 10;


vector<pii> e[N];
void solve() {
	int n; cin >> n;
	for (int i = 1; i < n; i++) {
		int u, v, w; cin >> u >> v >> w;
		e[u].pb({v, w});
		e[v].pb({u, w});
	}
	
	vector<int> w(n + 1, 0), f(n + 1, 0);	
	w[1] = 0;
	f[1] = 0;
	function<void(int, int)> dfs = [&] (int x, int fa) {
		for (auto c : e[x]) {
			if (c.fi == fa) continue;
			f[c.fi] = f[x] ^ 1;
			w[c.fi] = w[x] ^ c.se;
			dfs(c.fi , x);
		}	
	};
	
	dfs(1, 0);
	ll ans = 0;
	for (int i = 1; i <= n; i++) {
		ans ^= w[i];
	}
//	cout << ans << endl;

	int q; cin >> q;
	while (q--) {
		int u, x; cin >> u >> x;
		if (n % 2 == 0) {
			cout << ans << endl;
			continue;
		}
		
//		vector<int> tmp(31, 0);
		ll tmp = ans;
		for (int i = 0; i < 31; i++) {
			if (w[i] & (1 << i) != x & (1 << i)) {
				tmp ^= (1 << i);
			}
		}
		cout << tmp << endl;
	}
	
}

/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5
*/
int main() {
	ios::sync_with_stdio(0); cout.tie(0); cin.tie(0);

	int T = 1;

	while(T--) solve();

	return 0;
}

