#include<bits/stdc++.h>
using namespace std; 
const int N = 2e5+5;
double a[N],b[N],c[N];
int main()
{
	vector<int>vec;
	int k,m; cin >> m >> k;
	for(int i = 1;i <= 5;i++) cin >> a[i];
	for(int i = 1;i <= 5;i++) cin >> b[i];
	double ans = 0;
	double q = 0,p = 0;
	for(int i = 1;i <= 5;i++)
	{
		p = a[i];
		q = b[i];
		if(p >= m) p -= k;
		ans = max(ans,q / p);
	} 
	for(int i = 1;i <= 5;i++)
	{
		for(int j = i + 1; j <= 5;j++)
		{
			p = a[i] + a[j];
			q = b[i] + b[j];
			if(p >= m) p -= k;
			ans = max(ans,q / p);
		}
	}
	for(int i = 1;i <= 5;i++)
	{
		for(int j = i + 1; j <= 5;j++)
		{
			for(int z = j + 1;z <= 5;z++)
			{
				p = a[i] + a[j] + a[z];
				q = b[i] + b[j] + b[z];
				//cout << p << " " << q << '\n';
				if(p >= m) p -= k;
				ans = max(ans,q / p);
			}
		}
	}
	
	for(int i = 1;i <= 5;i++)
	{
		for(int j = i + 1; j <= 5;j++)
		{
			for(int z = j + 1;z <= 5;z++)
			{
				for(int x = z + 1;x <= 5;x++)
				{
					p = a[i] + a[j] + a[z] + a[x];
					q = b[i] + b[j] + b[z] + b[x];
					if(p >= m) p -= k;
					ans = max(ans,q / p);
				}
			}
		}
	}
	p = 0;
	q = 0;
	for(int i = 1;i <= 5;i++)
	{
		p += a[i];
		q += b[i];
	}
	if(p >= m) p -= k;
	ans = max(ans,q / p);
	printf("%.2f\n",ans);
	
}
