
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
long long int a[N],b[N],de[N],de1[N],a1[N],b1[N];
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    for (int i=0;i<n;i++) cin >> a[i],a1[i]=a[i],a[i]=-a[i];
    for (int i=0;i<n;i++)
    {
        cin >> b[i];
        b1[i]=b[i];
        b[i]=-b[i];
    }
    int ans=0;
    sort(a1,a1+n);
    sort(b1,b1+n);
    sort(b,b+n);
    sort(a,a+n);
    bool st1= true,st= true;
    for (int i=0;i<n;i++)
    {
        de[i]=a[i]-b[i];
        de1[i]=a1[i]-b1[i];
        if(i>0 && de[i]!=de[i-1]) st= false;
        if(i>0 && de1[i]!=de1[i-1]) st1= false;
    }
    if(st && st1)
    {
        ans= min(abs(de[0]), abs(de1[0])+1);
    }else if(st)
    {
        ans= abs(de[0]);
    }else if(st1)
    {
        ans= abs(de1[0])+1;
    }else ans=-1;
    cout << ans;
    return 0;
}

/*
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
const int mod=1e9+7;
long long a[N],fa[N];
int p[N],cnt[N];
int find(int x)
{
    if(p[x]!=x)
    {
        p[x]= find(p[x]);
    }
    return p[x];
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n,q;
    cin >> n >> q;
    for (int i=1;i<=n;i++)
    {
        cin >> a[i];
        p[i]=i;
        fa[i]=a[i];
        cnt[i]=1;
    }
    while (q--)
    {
        int num;
        cin >> num;
        if(num==1)
        {
            int a,b;
            cin >> a >> b;
            a= find(a);
            b= find(b);
            p[a]=b;
            fa[b]+=fa[a];
            cnt[b]+=cnt[a];
        }else if(num==2)
        {
            int a,b;
            cin >> a >> b;
            a= find(a);
            fa[a]+=b*cnt[a];
        }else {
            int b;
            cin >> b;
            cout << a[b]%mod << endl;
        }
        for (int i=1;i<=n;i++)
        {
            int father= find(i);
            a[i]+=fa[father];
        }
    }
}
*/
/*
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    int min_num=1000000,max_num=-1;
    for (int i=1;i<=n;i++)
    {
        cin >> a[i];
        min_num= min(min_num,a[i]);
        max_num= max(max_num,a[i]);
    }
        int ans=0;
        for (int i=min_num;i<=max_num;i++)
        {
            stack<int> st;
            bool successful= true;
            for (int j=1;j<=n;j++)
            {
                if(a[j]>i)
                {
                    // )
                    if(st.empty())
                    {
                        successful= false;
                        goto a1;
                    } else{
                        st.pop();
                    }
                }else if(a[j]<i)
                {
                    // (
                    st.push(1);
                }
            }
            a1:
            if(!st.empty()) successful= false;
            if(successful)
            {
                ans++;
            }
        }
        cout << ans;
    return 0;
}
*/