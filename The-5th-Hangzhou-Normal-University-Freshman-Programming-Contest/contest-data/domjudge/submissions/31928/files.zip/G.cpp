#include <bits/stdc++.h>
#define int ll
using namespace std;
using ll = long long;
using ull = unsigned long long;
int a[200005];
void solve(){
	int n,m,b;
	int sum = 0;
	cin>>n>>m>>b;
	for(int i = 1;i<=n;i++){
		cin>>a[i];
		sum += a[i];
	}
	if(m>=n){
		cout<<min(sum,b)<<'\n';
		return;
	}
	int ans = 0;
	int size = 0;
	for(int i = 1;i<=n;i++){
		size+=a[i];
		if((n-i)%m==0){
			cout<<i<<'\n';
			ans += min(size,b);
			size = max(0ll,size-b);
		}
	}
	cout<<ans<<'\n';
}

signed main(){
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}

