#include<stdio.h>
#include<stdlib.h>

int n, j = 0;
long long int a[200001], b[200001];
int c, d;

int cmp(const void* e1, const void* e2)
{
	return *(long long int*)e1 - *(long long int*)e2;
}

int main()
{	
	scanf("%d", &n);
	
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &a[i]);
		b[i] = a[i];
	}
	
	qsort(b, n, sizeof(b[0]), cmp);
	
	if (n % 2 == 1)
	{
		int p = 0;
		c = b[n / 2];
		for (int i = 0; i < n; i++)
		{
			if (a[i] > c)
				p--;
			if (p == -1)
			{
				printf("0");
				return 0;
			}
			if (a[i] < c)
				p++;
		}
		if (p == 0)
			printf("1");
		else
		{
			printf("0");
			return 0;
		}	
	}
	else
	{
		c = b[n / 2 - 1];
		d = b[n / 2];
		if (c == d)
		{
			int p = 0;
			for (int i = 0; i < n; i++)
			{
				if (a[i] > c)
					p--;
				if (p == -1)
				{
					printf("0");
					return 0;
				}
				if (a[i] < c)
					p++;
			}
			if (p == 0)
			{
				printf("1");
				return 0;
			}
			else
			{
				printf("0");
				return 0;
			}
		}
		else
		{
			int p = 0;
			for (int i = 0; i < n; i++)
			{
				if (a[i] >= d)
					p--;
				if (p == -1)
				{
					printf("0");
					return 0;
				}
				if (a[i] <= c)
					p++;
			}
			if (p == 0)
			{
				printf("%d", d - c - 1);
				return 0;
			}
			else
			{
				printf("0");
				return 0;
			}
		}
	}
}