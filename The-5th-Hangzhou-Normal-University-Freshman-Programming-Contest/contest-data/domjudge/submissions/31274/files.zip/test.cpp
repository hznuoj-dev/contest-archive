#include<iostream>
using namespace std;
int m,k;
int a[6],b[6];
double ans=-1;
void dfs(int i,int temp1,int temp2){
    if(i==6){
        if(temp1!=0){
            if(temp1>=m)    temp1-=k;
            //cout<<(double)temp2/(double)temp1<<endl;
            ans=max((double)temp2/(double)temp1,ans);

        }
            return;
    }
    dfs(i+1,temp1+a[i],temp2+b[i]);
    dfs(i+1,temp1,temp2);
}
int main(){
    cin>>m>>k;
    for(int i=1;i<=5;i++)   cin>>a[i];
    for(int i=1;i<=5;i++)   cin>>b[i];
    dfs(1,0,0);
    printf("%.2lf",ans);
}