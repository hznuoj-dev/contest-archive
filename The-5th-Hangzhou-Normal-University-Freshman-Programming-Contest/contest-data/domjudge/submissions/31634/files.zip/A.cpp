#include<bits/stdc++.h>

#define star std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

#define endl "\n";

using namespace std;

typedef long long ll;

typedef unsigned long long ull;

const ll maxn = 2e5+7;

const ll mod =1e9+7;

const ll itf =0x3f3f3f3f;

const ll ITF =0x3f3f3f3f3f3f3f3f;

double pi = 3.1415926535898;

ll exgcd(ll a, ll b, ll &x, ll &y) // ��չŷ������㷨
{if (b == 0){x = 1, y = 0;return a;}ll ret = exgcd(b, a % b, y, x);y -= a / b * x;return ret;}

ll getInv(ll a, ll mod) // ��a��mod�µ���Ԫ����������Ԫ����-1
{ll x, y;ll d = exgcd(a, mod, x, y);return d == 1 ? (x % mod + mod) % mod : -1;}

ll gcd(ll x,ll y) // ��x��y�����Լ��
{ll k=0;if(x<y){k=x;x=y;y=k;};while(x%y!=0){k=x%y;x=y;y=k;}return y;}

ll qpow(ll a,ll b,ll m)
{long long sum=1;while(b){if(b&1){sum=sum*a%m;}a=a*a%m;b>>=1;}return sum;}

ll lowbit(ll x) // ȡһ�����������λ��һ���ߵ�0��ɵ��� ��1100ȡ100Ϊ4
{ return x&-x; }

ll C(ll nn, ll kk)//
{ll ansC = 1;for (ll i = nn; i > nn - kk; i--) ansC *= i;for (ll i = kk; i > 1; i--) ansC /= i;return ansC;}

ll CC(ll nn,ll kk)//
{ll CC[1010][1010]={0};for(ll i = 0; i <= nn; i++){CC[i][0] = 1;for(ll j = 1; j<=i; j++)CC[i][j] = CC[i-1][j-1] + CC[i-1][j];}return CC[nn][kk];}
////���ڻ������� Ĭ���Ǵ󶥶�
// priority_queue<int> a;
// //��ͬ�� priority_queue<int, vector<int>, less<int> > a;
//
//
// priority_queue<int, vector<int>, greater<int> > c; //��������С����
// priority_queue<string> b;
int n;
ll a[maxn];
int check(int x){
	int cnt=0;
	for(int i=1;i<=n;i++){
		if(a[i]>x){
			cnt--;
		}else if(a[i]<x){
			cnt++;
		}
		if(cnt<0){
			return false;
		}
	}
	if(cnt==0){
		return true;
	}else{
		return false;
	}
}
void solve(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a+1,a+1+n);
	int l=0,r=0;
	if(a[(n+1)/2]==a[(n+1)/2+1]){
		l=r=a[(n+1)/2+1];
	}else{
		l=1;
		for(int i=(n+1)/2;i>=2;i--){
			if(a[i]!=a[i-1]){
			l=i-1;	
			}
		}
		r=n;
		for(int i=(n+1)/+1;i<=n-1;i++){
			if(a[i]!=a[i+1]){
				r=i+1;
			}
		}
	}
//	cout<<a[(n+1)/2]<<endl;
	if(check(a[(n+1)/2])){
		cout<<r-l+1<<endl;
	}else{
		cout<<"0"<<endl;
	}
}
signed main()
{
star;
int _=1;
//cin>>_;
while(_--){
solve();
}
return 0;
}
//��дջ

