#include <bits/stdc++.h>
#define maxn 200100
#define int long long
using namespace std;
map<pair<int,int>,int>e;
unordered_map<int,int>num;
int ans=0,tmp=0,n;
void solve(){
	unordered_map<int,int>pos;
	int x,y,res;
	cin >> x >> y;
	res=y;
	pos[x]++;
	for(auto u:e){
		res=res^u.second;
		pos[u.first.first]++,pos[u.first.second]++;
		pos[u.first.first]%=2,pos[u.first.second]%=2;
	}
	for(auto u:e){
		if(pos[u.first.first]==0&&pos[u.first.second]==0){
			pos[u.first.first]++,pos[u.first.second]++;
			pos[u.first.first]%=2,pos[u.first.second]%=2;
			res=res^u.second;
		}
	}
	for(int i=1;i<=n;++i){
		if(pos[i]==0){
			while(1)  i=1;
		}
	}
	cout << res << '\n';
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int q;  cin >> n;
	for(int i=1;i<n;++i){
		int u,v,w;
		cin >> u >> v >> w;
		e[{u,v}]=w;
	}
	for(auto u:e){
		ans=ans^u.second;
		num[u.first.first]++,num[u.first.second]++;
		num[u.first.first]%=2,num[u.first.second]%=2;
	}
	for(auto u:e){
		if(num[u.first.first]==0&&num[u.first.second]==0){
			num[u.first.first]++,num[u.first.second]++;
			num[u.first.first]%=2,num[u.first.second]%=2;
			ans=ans^u.second;
		}
	}
	cin >> q;
	while(q--){
		if(n%2==0){
			int x,y;
			cin >> x >> y;
			for(int i=1;i<=n;++i){
				if(num[i]==0){
					while(1)  i=1;
				}
			}
			cout << ans << '\n';
		}
		else  solve();
	}
    return 0;
}