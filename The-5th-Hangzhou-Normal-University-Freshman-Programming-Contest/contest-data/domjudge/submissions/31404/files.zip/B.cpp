#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

typedef long long LL;

const int N = 200010;

int n;
LL a[N], b[N];

int main()
{
    cin >> n;
    for (int i = 0; i < n; i ++ ) cin >> a[i];
    for (int i = 0; i < n; i ++ ) cin >> b[i];
    sort(a, a + n);
    sort(b, b + n);

    int cnt = b[0] - a[0];
    int flag = 0;
    for (int i = 1; i < n; i ++ )
    {
        if (b[i] - a[i] != cnt )
        {
            flag = 1;
            break;
        }
    }
    int idx = 0;
    if (flag == 1)
    {
        for (int i = 0; i < n; i ++ )
        {
            a[i] = -a[i];
        }
        sort(a, a + n);
        cnt = b[0] - a[0];
        for (int i = 1; i < n; i ++ )
        {
            if (b[i] - a[i] == cnt)
            {
                idx = 1;
                break;
            }
        }
    }
    else if (flag == 0)
    {
        cout << abs(abs(b[0]) - abs(a[0]));
        return 0;
    }

    if (idx == 1) cout << -1;
    else if (idx == 0)
    {
        cout << abs(abs(b[0]) - abs(a[0]));
    }
}