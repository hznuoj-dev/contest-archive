//#include <iostream>
//using namespace std;
//const int N = 2e5 + 10;
//long long qpow(long long a , long long n , long long mod){
//    long long ans = 1;
//    while(n){
//        if(n & 1){
//            ans = ans * a % mod;
//        }
//        n >>= 1;
//        a = a * a % mod;
//    }
//    return ans;
//}
//int fa[N] , a[N] , sum[N] , b[N];
//int n , q;
//void Init(){
//    for(int i = 1 ; i <= n;i++) {
//        fa[i] = i;
//        sum[i] = 1;
//    }
//}
//int find(int x){
//    return fa[x] == x ? x : find(fa[x]);
//}
//int main() {
//    cin >> n >> q;
//    Init();
//    for(int i = 1 ; i <= n;i++){
//        cin >> b[i];
//        a[i] = b[i];
//    }
//    for(int i = 1 ; i <= q;i++){
//        int k , u , v;
//        cin >> k >> u;
//        if(k == 1){
//            cin >> v;
//            int fu = find(u);
//            int fv = find(v);
//            if(fu != fv) {
//                fa[fv] = fu;
//                sum[fu] += sum[fv];
//                a[fu] += a[fv];
//            }
//        }else if(k == 2){
//            cin >> v;
//            int fu = find(u);
//            a[fu] += v * sum[fu];
//        }else{
//            cout <<
//        }
//    }
//    return 0;
//}


#include "iostream"
using namespace std;
int main(){
    int a[6] , b[6];
    int n , q;
    cin >> n >> q;
    for(int i = 1 ; i <= 5 ;i++){
        cin >> a[i];
    }
    for(int i = 1 ; i <= 5;i++)cin >> b[i];
    double ans = 0;
    for(int i = 0 ;i < 2;i++){
        for(int j = 0 ; j < 2;j++){
            for(int k = 0 ; k < 2;k++){
                for(int l =0 ; l < 2;l++){
                    for(int m = 0 ; m < 2;m++){
                        int nm = (a[1] * i + a[2] * j + a[3] * k + a[4] * l + a[5] * m);
                        ans = max(ans , (b[1] * i + b[2] * j + b[3] * k + b[4] * l + b[5] * m) / (double)(nm - (nm >= n ? q : 0)));
                    }
                }
            }
        }
    }
    printf("%.2f" , ans);
}