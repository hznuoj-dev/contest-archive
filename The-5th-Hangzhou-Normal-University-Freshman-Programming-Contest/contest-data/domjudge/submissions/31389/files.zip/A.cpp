#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;

struct yb{
	double a,b;
	double c,d;
}q[6];
bool cmp(yb a,yb b){
	return a.c>b.c;
}
int main(){
	int m,k;
	cin>>m>>k;
	for(int i=1;i<=5;i++)cin>>q[i].a;
	for(int i=1;i<=5;i++)cin>>q[i].b;
	for(int i=1;i<=5;i++){
		q[i].c=q[i].b/q[i].a;
		if(q[i].a>=m)q[i].d=q[i].b/(q[i].a-k);
		else q[i].d=q[i].c;
	}
	sort(q+1,q+6,cmp);
	double maxn=0;
	for(int i=1;i<=5;i++)maxn=max(maxn,q[i].d);
	double a=0,b=0,c=0;
	for(int i=1;i<=5;i++){
		a+=q[i].a;
		b+=q[i].b;
		if(a>=m)break;
	}
	c=b/(a-k);
	maxn=max(maxn,c);
	printf("%.2llf",maxn);
}