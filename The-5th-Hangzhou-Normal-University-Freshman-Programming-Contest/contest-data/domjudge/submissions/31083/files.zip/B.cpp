#include<bits/stdc++.h>

using namespace std;
#define int long long 
const int N = 2e5 + 5;
int a[N], b[N];

void solve(){
	int n;
	cin >> n;
	for(int i = 1; i <= n; ++ i)cin >> a[i];
	for(int i = 1; i <= n; ++ i)cin >> b[i];
	sort(a + 1, a + 1 + n);
	sort(b + 1, b + 1 + n);
	int k = a[1] - b[1];
	int ans = INT_MAX;
	for(int i = 2; i <= n; ++ i)if(a[i] - b[i] != k)goto A;
	ans = abs(k);
	A:;
	for(int i = 1; i <= n / 2; ++ i)swap(b[i], b[n - i + 1]);
	for(int i = 1; i <= n; ++ i)b[i] = -b[i];
	k = a[1] - b[1];
	for(int i = 2; i <= n; ++ i)if(a[i] - b[i] != k){
		cout << -1;
		return;
	}
	ans = min(ans, abs(k) + 1);
	cout << ans;
}

signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	solve();
	return 0;
}
