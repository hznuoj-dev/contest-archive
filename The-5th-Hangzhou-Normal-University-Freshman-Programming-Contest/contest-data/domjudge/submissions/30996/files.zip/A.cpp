#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=1000005;
int k[M],f[M];
int main()
{
	int n,d,l=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&k[i]);
		f[i]=k[i];
	}
	sort(k+1,k+n+1);
	if(n%2==1) d=k[n/2+1];
	else d=(k[n/2]+k[n/2+1])/2;
	for(int i=1;i<=n;i++)
	{
		if(f[i]<d) l++;
		else if(f[i]>d) l--;
		if(l<0)
		{
			printf("0");
			return 0;
		}
	}
	if(l>0)
	{
		printf("0");
		return 0;
	}
	if(n%2==0)
	{
		if(k[n/2]==k[n/2+1])
		{
			printf("1");
		}
		else
		{
			printf("%d",k[n/2+1]-k[n/2]-1);
		}
		return 0;
	}
	else
	{
		printf("1");
		return 0;
	}
	return 0;
}