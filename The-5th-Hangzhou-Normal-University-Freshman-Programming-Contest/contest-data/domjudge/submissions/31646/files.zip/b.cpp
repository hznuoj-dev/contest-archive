#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
typedef long long LL;
typedef pair<int,int> PII;
vector<int> a,b;
vector<int> c;

void solve(){
    int n;
    cin>>n;
    a.resize(n);
    b.resize(n);
    for(int i=0;i<n;i++) cin>>a[i];
    for(int i=0;i<n;i++) cin>>b[i];
    sort(a.begin(),a.end());
    sort(b.begin(),b.end());
    c=a;
    for(int i=0;i<n;i++){
        c[i]=-c[i];
    }
    sort(c.begin(),c.end());
    int res1=abs(b[0]-a[0]),res2=1+abs(b[0]-c[0]);
    int f1=1,f2=1;
    for(int i=0;i<n;i++){
        if(abs(b[i]-a[i])!=res1){
            f1=1;
            break;
        }
    }
    for(int i=0;i<n;i++){
        if(abs(b[i]-c[i])+1!=res2){
            f2=1;
            break;
        }
    }
    int res=2e10;
    if(f1==1){
        res=min(res,res1);
    }
    if(f2==1){
        res=min(res,res2);
    }
    if(res==2e10){
        cout<<-1<<endl;
    }else{
        cout<<res<<endl;
    }
}

bool multi=false;

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T=1;
    if(multi) cin>>T;
    while(T--){
        solve();
    }

    return 0;
}
