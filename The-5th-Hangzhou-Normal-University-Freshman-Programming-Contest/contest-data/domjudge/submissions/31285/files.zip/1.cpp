#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N];
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;++i)scanf("%d",&a[i]);
	sort(a,a+n);
	if(a[n/2]!=a[n/2-1]&&n%2==0)cout<<a[n/2]-a[n/2-1]-1;
	else cout<<1;
	return 0;
}
