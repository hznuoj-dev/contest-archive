#include <iostream>
#include <algorithm>
#include <cstring>
#include <map>
#include <vector>
#include <stack>

using namespace std;

double n, m;
double a[200005];
double b[200005];

void solve()
{
    cin >> n >> m;
    for (int i = 0; i < 5; ++i)
    {
        cin >> a[i];
    }
    for (int i = 0; i < 5; ++i)
    {
        cin >> b[i];
    }
    double res = 0;
    for (int i = 1; i < 32; ++i)
    {
        int j = 0;
        int k = i;
        double jg = 0, jz = 0;
        while (k)
        {
            if (k % 2)
            {
                jg += a[j];
                jz += b[j];
            }
            k /= 2;
            ++j;
        }
        if (jg >= n)
        {
            jg -= m;
        }
        res = max(res, jz / jg);
    }
    printf("%.2lf", res);
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}