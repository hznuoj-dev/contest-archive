#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;

void solve() {
    int m, k;
    std::cin >> m >> k;
    std::vector<int>a(5), b(5);
    for(auto &v : a)std::cin >> v;
    for(auto &v : b)std::cin >> v;
    double ans = 0;
    for(int i = 1;i < 31;i++) {
        int numa = 0;
        int numb = 0;
        for(int j = 0;j < 5;j++) {
            if((i >> j) & 1) {
                numa += a[j];
                numb += b[j];
            }
        }
        if(numa >= m)numa -= k;
        ans =std::max(ans, (double)numb / numa);
    }
    printf("%.2lf\n", ans);
}

int main() {
    int T = 1;
    //std::cin >> T;
    while(T--) {
        solve();
    }
}