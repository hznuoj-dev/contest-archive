#include<bits/stdc++.h>
using namespace std;
int m,K;
int A[10],B[10];
int main(){
	scanf("%d %d",&m,&K);
	for(int i=0;i<5;i++){
		scanf("%d",&A[i]); 
	}
	for(int i=0;i<5;i++){
		scanf("%d",&B[i]);
	}
	double ans=0;
	for(int i=0;i<(1<<5);i++){
		int sum=0;
		int cost=0;
		for(int j=0;j<5;j++){
			if(i>>j&1){
				sum+=B[j];
				cost+=A[j];
			}
		}
		if(cost>=m)cost-=K;
		ans=max(ans,1.0*sum/cost);
	}
	printf("%.2f\n",ans);
	return 0;
}
