#include<bits/stdc++.h>
using namespace std;

const int N = 1e6;
int a[N], n;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	int n, m, b; 				cin >> n >> m >> b;
	for(int i = 1; i <= n; ++i) cin >> a[i];
	
	int st = (n + 1) % m + 1;
	
	int bin = 0, ans = 0;
	for(int i = st, j = 1; j <= n; ++j)
	{
		bin += a[j];
		
		if(st == j)
		{
			st = st + m;
			int del = min(b, bin);
			ans += del;
			bin -= del;
		}
	}
	
	cout << ans;
}

/*
vector<int> gp;

bool check(int num)
{
	int bin = 0;
	for(int i = 1; i <= n; ++i)
	{
		if(a[i] < num)
		{
			++bin;
		}
		else if(a[i] > num)
		{
			--bin;
		}
		
		if(bin < 0)
		{
			return false;
		}
	}
	
	if(bin == 0)
	{
		return true;
	}
	
	return false;
}

*/
