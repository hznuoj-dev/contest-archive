#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int m, k;
double f[N];
struct node
{
    int x, y;
    bool operator<(const node &t) const
    {
        if (x != t.x)
            return x > t.x;
        else
            return y < t.y;
    }
} a[N];

struct node1
{
    int x, y;
    bool operator<(const node1 &t) const
    {
        if (x != t.x)
            return x > t.x;
        else
            return y > t.y;
    }
} b[N];

void solve()
{
    cin >> m >> k;
    int n = 5;
    for (int i = 1; i <= n; ++i)
        cin >> a[i].y;
    for (int i = 1; i <= n; ++i)
        cin >> a[i].x;
    for (int i = 1; i <= n; ++i)
    {
        b[i].x = a[i].x;
        b[i].y = a[i].y;
    }
    sort(a + 1, a + n + 1);
    sort(b + 1, b + n + 1);
    // for (int i = 1; i <= n; ++i)
    //     cout << b[i].x << " " << b[i].y << endl;
    double ans = -INF;
    int sum1 = 0;
    int sum2 = 0;
    for (int i = 1; i <= n; ++i)
    {
        sum1 += a[i].x;
        sum2 += a[i].y;
        double t = 0;
        if (sum2 >= m)
        {
            t = (1.0 * sum1) / (sum2 - k);
        }
        else
        {
            t = (1.0 * sum1) / sum2;
        }
        if (t < ans)
        {
            sum1 -= a[i].x;
            sum2 -= a[i].y;
        }
        ans = max(ans, t);
    }
    sum1 = 0;
    sum2 = 0;
    for (int i = 1; i <= n; ++i)
    {
        sum1 += b[i].x;
        sum2 += b[i].y;
        double t = 0;
        if (sum2 >= m)
        {
            t = (1.0 * sum1) / (sum2 - k);
        }
        else
        {
            t = (1.0 * sum1) / sum2;
        }
        // if (t < ans)
        // {
        //     sum1 -= a[i].x;
        //     sum2 -= a[i].y;
        // }
        ans = max(ans, t);
    }
    cout << fixed << setprecision(2) << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}