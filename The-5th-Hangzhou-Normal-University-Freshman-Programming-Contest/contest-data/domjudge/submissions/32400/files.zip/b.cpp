#include<bits/stdc++.h>
using namespace std;
const int N =3e5+10;
int a[N],b[N];
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
	}
	sort(a,a+n);
	int cnt=0;
	int flag=0;
	if(a[0]<0)
	{
		flag=1;
	}
	for(int i=0;i<n;i++)
	{
		if(flag==1)
		{
			a[i]=-a[i];
		}
		if(a[i+1]-a[i]!=1)
		{
			cout<<-1;
			return 0;
		}
	}
	if(flag==1)
	cnt++;
	sort(b,b+n);
	for(int i=0;i<n;i++)
	{
		if(b[i+1]-b[i]!=1)
		{
			cout<<-1;
			return 0;
		}
	}
	int h;
	h=fabs(b[0]-a[0]);
	cout<<h+cnt;
	return 0;
}
