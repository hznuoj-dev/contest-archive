#include <bits/stdc++.h>

#define ll long long
const int N = 2e6 + 7;
void solve() {
	ll n, m, b;
	std::cin >> n >> m >> b;
	std::vector<ll> a(n + 1), sum(n + 1, 0ll);
	for (int i = 1; i <= n; i++) {
		std::cin >> a[i];
		sum[i] = sum[i - 1] + a[i];
	}
	ll ans = 0;
	int st = n % m;
	if (st == 0) st = m;
	int cur = 0;
	//std::cout << st << "\n";
	for (int i = 1; i <= n; i ++) {
		sum[i] = sum[i - 1] + a[i];
		if (i == st) {
			ans += std::min(b, sum[i]);
			sum[i] = std::max(0ll, sum[i] - b);
			st += m;
		}
	}
	std::cout << ans;
}

int main() {
	//std::ios::sync_with_stdio(0);
	//std::cin.tie(nullptr);
	
	solve();
}
