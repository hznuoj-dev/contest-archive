#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
int main()
{
    double a[10] = {0}, b[10] = {0}, xjb[10] = {0};
    double m ,k, x[10] = {0}, flag = 1 ,y = x[1];
    double ma = 0, mb = 0;
    cin >> m >> k;
    for(int i = 1; i <= 5; i++)
    {
        cin >> a[i];
    }
    for(int i = 1; i <= 5; i++)
    {
        cin >> b[i];
        xjb[i] = b[i] / a[i];
    }
    for(int i = 1; i <= 5; i++)
    {
        for(int j = i + 1; j <= 5; j++)
        {
            if(xjb[j] > xjb[i])
            {
                swap(xjb[i],xjb[j]);
                swap(a[i],a[j]);
                swap(b[i],b[j]);
            }
        }
    }
    for(int i = 1; i <= 5; i++)
    {
        mb += b[i];
        ma += a[i];
        if(ma >= m && flag == 1)
        {
            ma -= k;
            flag = 0;
        }
        x[i] = mb / ma;
        y = max(y,x[i]);
    }
    printf("%.2lf\n",y);
    return 0;
}