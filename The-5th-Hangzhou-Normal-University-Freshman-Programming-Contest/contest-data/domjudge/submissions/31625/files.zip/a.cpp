#include<bits/stdc++.h>
using namespace std;
const int N=3e5+10;
int a[N],c[N];
int main()
{
	int n,left=0,right=0,k=0,cnt=1;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		c[i]=a[i];
	}
	sort(a,a+n);
	k=a[1];
while(k<=a[n])
{
		for(int i=2;i<=n;i++)
		{
			if(a[i]<k)
			left++;
			else if(a[i]>k)
			right++;
		}
		if(left==right)
		{
			cnt++;
		}
		else
		k++;
}
cout<<cnt;
	return 0;
}
