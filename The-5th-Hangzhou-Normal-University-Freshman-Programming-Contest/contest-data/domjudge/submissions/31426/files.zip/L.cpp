#include <bits/stdc++.h>

double m, k;
double a[6], b[6];

void solve() {
	std::cin >> m >> k;	
	for (int i = 0; i < 5; i++) std::cin >> a[i];
	for (int i = 0; i < 5; i++) std::cin >> b[i];
	double ans = 0;
	for (int i = 0; i < (1 << 5); i++) {
		double res = 0, tmp = 0;
		for (int j = 0; j < 5; j++) {
			if (i & (1 << j)) {
				res += b[j];
				tmp += a[j];
				//if (tmp >= m) tmp -= k;
			}
		}
		//double cnt = tmp / m;
		//tmp -= cnt * k;
		if (tmp >= m) tmp -= k;
		if (tmp) ans = std::max(ans, res / tmp);
	}
	printf("%.2lf", ans);
}

int main() {
	solve();
}
