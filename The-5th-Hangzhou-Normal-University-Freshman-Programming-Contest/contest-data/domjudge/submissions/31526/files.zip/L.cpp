#include <bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int a[N],b[N],c[N];
int main()
{
	int m,k,cnt=0,h[10],num[10]={};
	cin>>m>>k;
    cout<<fixed<<setprecision(2);
    for(int i=0;i<5;i++)
    {
		cin>>a[i];
	}
	for(int i=0;i<5;i++)
	{
		cin>>b[i];
	}
	for(int i=0;i<5;i++)
	{
		h[i]=b[i]-a[i];
		if(h[i]>=0)
		{
			num[i]=i;
		}
	}
	int sum=0,manyizhi=0;
	for(int i=0;i<5;i++)
	{
		if(num[i]!=0)
		{
			sum+=a[i];
			manyizhi+=b[i];
			if(sum>m)
			{
				break;
			}
		}
	}
	double ans;
	ans=manyizhi*1.0/(sum-k);
	cout<<ans<<endl;
	return 0;
}
