#include<bits/stdc++.h>

using namespace std;

const int N = 200005;

#define ll long long

#define mod 998244353

ll qpow(ll a,ll b){
	ll res = 1;
	while(b){
		if(b&1){
			res *= a;
			res %= mod;
		}
		a = a*a;
		a %= mod;
		b>>=1;
	}
	return res;
}

ll dp[N];

void solve(){
	ll n;
	ll a,b,c;
	cin>>n>>a>>b>>c;
	ll sum = a+b+c - max(a,max(b,c));
	dp[0] = 0;
	dp[1] = 9*qpow(5,mod-2);
	for(ll i=2;i<=sum;++i){
		dp[i] = (dp[i-2] + 4*dp[i-1]%mod + 9)%mod * qpow(5,mod-2)%mod;
	}
	cout<<dp[sum];
	
}

int main(){
	cin.sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
