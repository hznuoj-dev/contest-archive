#include<bits/stdc++.h>

using namespace std;

#define int long long
#define ll long long
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pii pair<int,int>
#define pb push_back
//#define endl "\n"
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 2e5+7;
const int mod = 998244353;

struct node{
	int v,w;	
};
vector<node>e[N];
map<pii,int>mp1;

void dfs(int u,int ans,int fx,int fa){
	for(auto i:e[u]){
		if(i.v == fa) continue;
		if(e[i.v].size() == 1) continue;
		mp1[{fx,i.v}] = ans^i.w;
		mp1[{i.v,fx}] = ans^i.w;
		dfs(i.v,ans^i.w,fx,u);
	}
}

int ans[N];

void solve(){
	int n;
	cin >> n;
	int cnt = 0;
	for(int i=1;i<n;i++){
		int u,v,w;
		cin >> u >> v >> w;
		cnt ^= w;
		e[u].pb({v,w});
		e[v].pb({u,w});
	}
	int q;
	cin >> q;
	int m = 0;
	int idx = 0;
	for(int i=1;i<=n;i++){
		if(e[i].size() == 1) continue;
		idx = i;
		if(e[i].size()%2==0) ans[++m] = i;
	}
	dfs(idx,0,idx,-1);
	//dbg(cnt);
	for(int i=1;i<=m;i++){
		cnt ^= mp1[{idx,ans[i]}];
	}
	
	while(q--){
		int u,x;
		cin >> u >> x;
		if(e[u].size() == 1){
			for(auto v:e[u]){
				x ^= v.w;
				u = v.v;
			}
		}
		int w = cnt;
		if(m%2==1) w = x^mp1[{u,idx}];
//		for(int i=1;i<=m;i++){
//			int y = x^mp1[{u,idx}];
//			y ^= mp1[{idx,ans[i]}];
//			w^= y;
//		}
		cout << w << endl;
	}
}
/*
6
1 2 3
2 3 4
3 4 3
4 5 2
5 6 1
5

5
1 2 1
1 3 2
3 4 3
3 5 4
2

6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5
*/

signed main(){
	ios::sync_with_stdio(0);
    cin.tie(nullptr);cout.tie(nullptr);
	int T = 1;
    //cin >> T;
    while(T--) solve();

    return 0 ;
}

