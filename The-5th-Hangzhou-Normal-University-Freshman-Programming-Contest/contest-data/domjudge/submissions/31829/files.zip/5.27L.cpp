#include<bits/stdc++.h>
using namespace std;
const int N = 114514;
typedef long long ll;
double a[N],b[N],c[N],d[N];
double n,k,m;
double ans,temp;
int main(){
	cin>>m>>k;
	for(int i=1;i<=5;++i){
		cin>>a[i];
		c[i]=a[i];
	}
	c[31]=c[1]+c[2]+c[3]+c[4]+c[5];
	for(int j=1;j<=5;++j){
		cin>>b[j];
		d[j]=b[j];
	}
	c[6]=c[1]+c[2];
	c[7]=c[1]+c[3];
	c[8]=c[1]+c[4];
	c[9]=c[1]+c[5];
	c[10]=c[2]+c[3];
	c[11]=c[2]+c[4];
	c[12]=c[2]+c[5];
	c[13]=c[3]+c[4];
	c[14]=c[3]+c[5];
	c[15]=c[4]+c[5];
	c[16]=c[1]+c[2]+c[3];
	c[17]=c[1]+c[2]+c[4];
	c[18]=c[1]+c[2]+c[5];
	c[19]=c[1]+c[3]+c[4];
	c[20]=c[1]+c[3]+c[5];
	c[21]=c[1]+c[4]+c[5];
	c[22]=c[2]+c[3]+c[4];
	c[23]=c[2]+c[3]+c[5];
	c[24]=c[2]+c[4]+c[5];
	c[25]=c[3]+c[4]+c[5];
	c[26]=c[31]-c[1];
	c[27]=c[31]-c[2];
	c[28]=c[31]-c[3];
	c[29]=c[31]-c[4];
	c[30]=c[31]-c[5];
	d[6]=d[1]+d[2];
	d[7]=d[1]+d[3];
	d[8]=d[1]+d[4];
	d[9]=d[1]+d[5];
	d[10]=d[2]+d[3];
	d[11]=d[2]+d[4];
	d[12]=d[2]+d[5];
	d[13]=d[3]+d[4];
	d[14]=d[3]+d[5];
	d[15]=d[4]+d[5];
	d[16]=d[1]+d[2]+d[3];
	d[17]=d[1]+d[2]+d[4];
	d[18]=d[1]+d[2]+d[5];
	d[19]=d[1]+d[3]+d[4];
	d[20]=d[1]+d[3]+d[5];
	d[21]=d[1]+d[4]+d[5];
	d[22]=d[2]+d[3]+d[4];
	d[23]=d[2]+d[3]+d[5];
	d[24]=d[2]+d[4]+d[5];
	d[25]=d[3]+d[4]+d[5];
	d[26]=d[31]-d[1];
	d[27]=d[31]-d[2];
	d[28]=d[31]-d[3];
	d[29]=d[31]-d[4];
	d[30]=d[31]-d[5];
	
	for(int i=1;i<=25;++i){
		if(c[i]>=m){
			c[i]=c[i]-k;
		}
		temp=d[i]/c[i];
		ans=max(ans,temp);
	}
	cout<<fixed<<setprecision(2)<<ans<<endl;
	return 0;
	
}
