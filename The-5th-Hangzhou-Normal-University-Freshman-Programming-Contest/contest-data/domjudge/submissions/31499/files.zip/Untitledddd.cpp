#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
const int inf=0x3f3f3f3f;
const int N=1e6+10;
int a[N];
int b[N];
int c[N];
int d[N];


signed main()
{
	Acode;
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		c[i]=-a[i];
	}
	for(int i=1;i<=n;i++) 
	{
		cin>>b[i];
		d[i]=-b[i];
	}
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	sort(d+1,d+1+n);
	int flag=1;
	int w=0;
	if(n==1) flag=1;
	else 
	{
		w=a[1]-b[1];
		for(int i=2;i<=n;i++) 
	    {
		    if(a[i]-b[i]!=w) flag=0;
	    }
	}

	if(flag)
	{
		int t=abs(a[1]-b[1]);
		int tt=abs(a[1]-d[1])+1;
		int tt3=abs(b[1]-a[1]);
		int tt4=abs(b[1]-c[1])+1;
		cout<<min({t,tt,tt3,tt4});
	}
	else 
	{
		cout<<"-1";
	}
 
	return 0;
}

