#include <iostream>
#include <vector>
#include <bitset>
#include <map>
#include <queue>
#include <stack>
#include <algorithm>
#include <cmath>
#include <set>
#include <cstring>
#include <array>
#pragma GCC optimize(2)
#include <bits/stdc++.h>
#define rep(i,from,to) for(int i=from;i<to;i++)
#define ite(i,arr) for(auto &i:arr)
#define MID(l,r) int mid=(l+r)>>1
#define ALL(arr) arr.begin(),arr.end()
#define AXY(a,x,y) int x=a.first,y=a.second
#define vc vector
#define vi vector<int>
#define vll vector<long long>
#define pii pair<int,int>
#define endl '\n'
typedef long long ll;
typedef unsigned long long ull;
using namespace std;

namespace dbg {
#ifdef FTY
    template <typename T>
    void __print_var(string_view name, const T& x) { std::cerr << name << " = " << x; }
    template <typename T>
    void __print_var(string_view name, const vector<T>& x) {
        std::cerr << name << " = ";
        bool is_first = true;
        for (auto& ele : x) std::cerr << (is_first ? (is_first = false, "[") : ", ") << ele;
        std::cerr << "]";
    }
    template <typename T>
    void __print_var(string_view name, const set<T>& x) {
        std::cerr << name << " = ";
        bool is_first = true;
        for (auto& ele : x) std::cerr << (is_first ? (is_first = false, "{") : ", ") << ele;
        std::cerr << "}";
    }
    template <typename K, typename V>
    void __print_var(string_view name, const map<K, V>& x) {
        std::cerr << name << " = ";
        bool is_first = true;
        for (auto& [k, v] : x) std::cerr << (is_first ? (is_first = false, "{") : ", ") << "(" << k << ": " << v << ")";
        std::cerr << "}";
    }
    template <typename T>
    void __log(string_view name, const T& x) {
        __print_var(name, x); std::cerr << endl;
    }
#define LOG(args)\
    { std::cerr << "line " << __LINE__ << ": " << __func__ << "(): ";\
    __log(#args, ##args); }
#else
#define LOG(...)
#endif
}

const double eps = 1e-8;
const double PI = acos(-1);
struct Point {
    double x, y;
    Point() {
        x = 0, y = 0;
    }
    Point(double x, double y) {
        this->x = x;
        this->y = y;
    }
};
Point operator +(Point a, Point b) {
    return Point(a.x + b.x, a.y + b.y);
}
Point operator -(Point a, Point b) {
    return Point(a.x - b.x, a.y - b.y);
}
Point operator *(double a, Point b) {
    return Point(a * b.x, a * b.y);
}
Point operator *(Point b, double a) {
    return Point(a * b.x, a * b.y);
}
Point operator /(Point b, double a) {
    return Point(b.x / a, b.y / a);
}
double len(Point a) {
    return sqrt(a.x * a.x + a.y * a.y);
}
double dis(Point a, Point b) {
    return len(a - b);
}
bool operator ==(Point a, Point b) {
    return dis(a, b) <= eps;
}
bool operator !=(Point a, Point b) {
    return !(a == b);
}
double operator *(Point a, Point b) {
    return a.x * b.x + a.y * b.y;
}

double operator ^(Point a, Point b) {
    return a.x * b.y - a.y * b.x;
}

double getAngel(double b, double a, double c) {
    return acos((a * a + c * c - b * b) / (2 * a * c));
}
double getAngel(Point a, Point b) {
    return acos(a * b / len(a) / len(b));
}



const int mod = 998244353;



#define int ll
using namespace dbg;
template <class T>
T __gcd(T a, T b) {
    if (a < b) swap(a, b);
    return b ? __gcd(b, a % b) : a;
}
template <class T>
T __lcm(T a, T b) {
    T num = __gcd(a, b);
    return a / num * b;
}
inline int lowbit(int num) { return num & (-num); }
inline int qmi(int a, int b) {
    a %= mod;
    ll res = 1;
    while (b) {
        if (b & 1) res = (ll)res * a % mod;
        a = (ll)a * a % mod;
        b >>= 1;
    }
    return res;
}
int inv(int num) {
    return qmi(num, mod - 2);
}
const int N = 4e5;
ll fact[(int)N + 5];
ll inv_fact[(int)N + 5];
int prime[(int)N + 5];
int valid[(int)N + 5];
int pn = 0;
inline void getPrime() {
    rep(i, 2, N + 1) {
        if (!valid[i]) {
            valid[i] = i;
            prime[pn++] = i;
        }
        for (int j = 0; j < pn && i * prime[j] <= N; j++) {
            valid[i * prime[j]] = prime[j];
            if (i % prime[j] == 0) break;
        }
    }
}
inline void getFact() {
    fact[0] = fact[1] = 1;
    for (int i = 2; i <= N; i++) {
        fact[i] = i * fact[i - 1] % mod;
    }
}
inline void getInv() {
    inv_fact[N] = inv(fact[N]);
    for (int i = N - 1; i >= 0; i--) {
        inv_fact[i] = inv_fact[i + 1] * (i + 1) % mod;
    }
}
inline ll CC(int n, int m) {
    if (m<0 || m>n) {
        m = 0;
        return n / m;
    }//�����0��Ϊ�˺�debug  �˴�����RE ������
    ll res = fact[n] * inv_fact[m] % mod * inv_fact[n - m] % mod;
    return res;
}



signed main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int m, k;
    cin >> m >> k;
    int n = 5;
    vi arr(n), brr(n);
    ite(i, arr) cin >> i;
    ite(i, brr) cin >> i;
    double res = 0.0;
    for (int i = 1; i < (1 << 5); i++) {
        int sum = 0;
        int tot = 0;
        for (int j = 0; j < 5; j++) {
            if (((1 << j) & i) > 0) {
                sum += arr[j];
                tot += brr[j];
            }
        }
        if (sum >= m) sum -= k;
        res = max(tot / (double)sum, res);
   }
    printf("%.3lf\n", res);
    return 0;
}