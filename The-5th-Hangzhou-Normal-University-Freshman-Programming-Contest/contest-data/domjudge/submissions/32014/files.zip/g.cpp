#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
long long a[N],b[N];
int main(){
	long long n,m,b;
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	long long num=0,sum=0;
	for(int i=1;i<=n%m;i++){
		num+=a[i];
	}
	sum+=min(b,num);
	num-=min(b,num);
	for(int i=n%m+1;i<=n;i++){
		num+=a[i];
		if((i-n%m)%m==0){
			sum+=min(b,num);
			num-=min(b,num);	
		}
	}
	cout<<sum;
	return 0;
}
