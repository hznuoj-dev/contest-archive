/*
 * @Author: JSY
 * @Date: 2023-05-27 13:22:19
 * @Last Modified by: JSY
 * @Last Modified time: 2023-05-27 13:22:19
*/

#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int, int>
#define IOS ios::sync_with_stdio(0);cin.tie(0), cout.tie(0)
const int N = 200010;
int a[N];

signed main(){
    IOS;
    int n,m,b;
    cin >> n >> m >> b;
    for(int i=1;i<=n;i++){
        cin >> a[i];
    }
    int ans = 0,res = 0;
    for(int i=1;i<=n;i++){
        res += a[i];
        if((n-i) % m == 0){
            if(res >= b){
                ans += b;
                res -= b;
            }else{
                ans += res;
                res = 0;
            }
        }
    }
    cout << ans;
    return 0;
}