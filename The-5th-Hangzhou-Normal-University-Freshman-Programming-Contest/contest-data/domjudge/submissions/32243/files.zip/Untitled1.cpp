#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
const int N=2e5+5;
#define ll long long
#define ull unsigned long long
#define int ll
int a[N];
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int n,m,b;
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	ll sum=0;
	ll ans=0;
	if(m<=n-1)
	{
		ans+=a[1];
		if((n-1)%m==0)
		{
			for(int i=2;i<=n;i++)
			{
				sum+=a[i];
				if((i-1)%m==0)
				{
					ans+=min(b,sum);
					sum-=min(b,sum);
				}
			}
		}
		else
		{
			int tem=(n-1)/m*m-1;
				for(int i=2;i<=tem*m+1;i++)
			{
				sum+=a[i];
				if((i-1)%m==0)
				{
					ans+=min(b,sum);
					sum-=min(b,sum);
				}
			}
			for(int i=tem*m+1;i<=n;i++)
			{
				sum+=a[i];
				if(i==n)
				{
						ans+=min(b,sum);
				}
			}
		}
	}
	else
	{
		for(int i=1;i<=n;i++)
		{
			sum+=a[i];
		}
		ans=min(sum,b);
	}
	cout<<ans;
}