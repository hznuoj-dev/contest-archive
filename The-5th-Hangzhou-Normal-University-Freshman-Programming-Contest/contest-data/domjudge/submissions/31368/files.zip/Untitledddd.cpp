#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
const int inf=0x3f3f3f3f;
const int N=1e6+10;
int a[N];
int b[N];


signed main()
{
	Acode;
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(int i=1;i<=n;i++) cin>>b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	int flag=1;
	for(int i=1;i<=n-1;i++) 
	{
		if(a[i]-b[i]!=a[i+1]-b[i+1]) flag=0;
	}
	if(flag)
	{
		int t=abs(a[1]-b[1]);
		int t1=abs(a[1]+b[n]);
		cout<<min(t,t1)<<endl;
	}
	else 
	{
		cout<<"-1\n";
	}
 
	return 0;
}

