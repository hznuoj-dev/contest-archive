#include <bits/stdc++.h>
#define int long long
#define maxn 200100
using namespace std;
int a[maxn],s[maxn];
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n,m,b,ans=-1;
	cin >> n >> m >> b;
	for(int i=1;i<=n;++i)  cin >> a[i],s[i]=s[i-1]+a[i];
	for(int i=1;i<=m;++i){
		int sum=0;
		for(int j=i;j<=n;j+=m){
			sum+=min(s[j]-sum,b);
		}
		ans=max(ans,sum);
	}
	cout << ans << '\n';
    return 0;
}