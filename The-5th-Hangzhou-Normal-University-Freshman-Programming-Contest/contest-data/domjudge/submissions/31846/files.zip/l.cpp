#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long int m,k,i,j;
	long long int a[10],b[10],x=0,y=0;
	double c[10],t1,t2=-1,temp;
	scanf("%lld%lld",&m,&k);
	for(i=1;i<=5;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(i=1;i<=5;i++)
	{
		scanf("%lld",&b[i]);
		c[i]=b[i]*1.0/a[i];
		if(c[i]>t2)
		{
			t2=c[i];
		}
	}
	for(i=1;i<=4;i++)
	{
		for(j=1;j<=5-i;j++)
		{
			if(c[j]<c[j+1])
			{
				temp=c[j];
				c[j]=c[j+1];
				c[j+1]=temp;
				
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
				
				temp=b[j];
				b[j]=b[j+1];
				b[j+1]=temp;
			}
		}
	}
	for(i=1;i<=5;i++)
	{
		x=x+b[i];
		y=y+a[i];
		if(y>=m)
		{
			break;
		}
	}
	if(y>=m)
	{
		y=y-k;
	}
	t1=x*1.0/y;
	if(t2>t1)
	{
		printf("%.2f",t2);
	}
	else
	{
		printf("%.2f",t1);
	}
	return 0;
}
