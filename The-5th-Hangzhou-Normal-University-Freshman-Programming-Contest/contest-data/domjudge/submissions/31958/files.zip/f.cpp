#include <bits/stdc++.h>
using namespace std;
#define int long long

const int maxn = 200055;

struct node{
	int to,v;
};

vector<node>t[maxn];
int n,f[maxn],ys[maxn],a[maxn],sum;
map<pair<int,int>,int>mp;

void dfs(int u,int fa)
{
	for(auto i:t[u])
	{
		if(i.to==fa)continue;
		f[i.to]=u;
		ys[i.to]=ys[u]^i.v;
		dfs(i.to,u);
	}
}

signed main()
{
	ios::sync_with_stdio(false);cin.tie(0);
	cin>>n;
	for(int i=1;i<n;i++){
		int x,y,v;cin>>x>>y>>v;
		t[x].push_back({y,v});
		t[y].push_back({x,v});
		mp[make_pair(x,y)]=v;
		mp[make_pair(y,x)]=v;
	}
	dfs(1,0);
	for(int i=1;i<=n;i++)sum^=ys[i];
	int q;cin>>q;
	while(q--)
	{
		int u,x;
		cin>>u>>x;
		while(u!=1)
		{
			x^=mp[make_pair(u,f[u])];
			u=f[u];
		}
		if(n%2==0)cout<<sum<<'\n';
		else cout<<(x^sum)<<'\n';
	}
	return 0;
}
