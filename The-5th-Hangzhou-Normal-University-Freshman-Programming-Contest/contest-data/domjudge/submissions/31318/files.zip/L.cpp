#include <bits/stdc++.h>
using namespace std;
#define int long long
const int inf=0x3f3f3f3f;

int a[10],b[10];
int m,k;
double ans=-inf;

bool vis[10];
int price=0,judge=0;

void dfs(int depth) {
	if (price>=m) {
		ans=max(ans,judge*1.0/(price-k));
	} else {
		ans=max(ans,judge*1.0/price);
	}
	for (int i=1; i<=5; ++i) {
		if (vis[i]==false) {
			vis[i]=true;
			price+=a[i],judge+=b[i];
			dfs(depth+1);
			vis[i]=false;
			price-=a[i],judge-=b[i];
		}
	}
}

void solve() {
	cin>>m>>k;
	for (int i=1; i<=5; ++i) cin>>a[i];
	for (int i=1; i<=5; ++i) cin>>b[i];
	dfs(0);
	cout<<fixed<<setprecision(2)<<ans<<'\n';
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);

	int tt=1;
//	cin>>tt;
	while (tt--) solve();

	return 0;
}
