#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n;
	int a[N];
	int b,c1[N],c2[N];
void slove(){
	
	cin>>n;
	map<int,int>mp;
	for(int i=0;i<n;i++){
		cin>>a[i];
	//	cout<<a[i]<<endl;
		mp[a[i]]=1;
	}
	int k=1;int maxx=0,minn=0;
	int mm=0,nn=0;
	for(int i=0;i<n;i++){
		cin>>b;
		
		if(mp[b]!=1){
			k=0;
		//	cout<<000<<endl;
		}
		c1[i]=a[i]-b;
		c2[i]=-a[i]-b;
		if(i==0){
			maxx=c1[i];
			minn=c1[i];
			mm=c2[i];
			nn=c2[i];
		}
		else{
			maxx=max(maxx,c1[i]);
			minn=min(minn,c1[i]);
			mm=max(mm,c2[i]);
			nn=min(nn,c2[i]);
			}
	}
	if(k==1){
		cout<<"0";
		return;
	}
	if((maxx!=minn)&&(nn!=mm)){
		cout<<"-1";
		return;
	}
	if((abs(c1[0])>abs(c2[0]))&&(mm==nn)){
		cout<<abs(c2[0])+1;
		return;
	}
	else{
	//	cout<<c1[0]<<endl;;
		cout<<abs(c1[0]);
		return;
	}
	
	return;
}
int main(){
	int T=1;
//	cin>>T;
	while(T--){
		slove();
	}
	
	return 0;
} 
