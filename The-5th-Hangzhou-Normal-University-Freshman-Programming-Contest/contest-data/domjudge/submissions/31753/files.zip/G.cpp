#include <iostream>
#include <algorithm>
using namespace std;
const int N = 2e5 + 10;
using ll = long long;
int a[N];

int main()
{
    int n, m, b;
    scanf("%d %d %d", &n, &m, &b);
    for(int i = 1; i <= n; i++) scanf("%d", &a[i]);

    int s = (n - 1) % m + 1;
    // printf(":%d\n", s);
    ll sum = 0, ans = 0;
    int lastJ = 1;
    for(int i = s; i <= n; i += m) {
        while(lastJ <= i && lastJ <= n) {
            sum += a[lastJ++];
        }
        ll d = min(sum, (ll)b);
        sum -= d;
        ans += d;
        // printf(":%lld\n", d);
    }

    printf("%lld\n", ans);

    return 0;
}