#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
const int N=3e5+10;
double a1[N]={0};
double a2[N]={0};
void Sort(double *arr,int begin,int end){
    if(begin>end)
        return;
    int tmp = arr[begin];
    int i = begin;
    int j = end;
    while(i != j){
        while(arr[j]>=tmp&&j>i)
            j--;
        while(arr[i]<=tmp&&j>i)
            i++;
        if(j>i){
            int t=arr[i];
            arr[i]=arr[j];
            arr[j]=t;
        }
    }
    arr[begin] = arr[i];
    arr[i] = tmp;
    Sort(arr, begin, i-1);
    Sort(arr, i+1, end);
}

int main(){
   int n;
   cin>>n;
   for(int i=0;i<n;i++)
   cin>>a1[i];
   for(int i=0;i<n;i++)
   cin>>a2[i];
Sort(a1,0,n-1);
Sort(a2,0,n-1);
int flag=1;
for(int i=0;i<n;i++){
	if(a1[i]!=a2[i])
	flag=0;
} 
if(flag==1){
	cout<<'0';
	return 0;	 
}
flag=1;
	if(a1[n-1]<0&&a2[0]>0||a2[n-1]<0&&a1[0]>0){
		int k=a1[0]+a2[n-1];
		for(int i=1;i<n;i++){
		if(a1[i]+a2[n-1-i]!=k)
		flag=0;
		}
	}
else{
	for(int i=1;i<n;i++){
	int k=a1[0]-a2[0];
	if(a1[i]-a2[i]!=k)
	flag=0;
}
}
if(flag==0){
	cout<<"-1";
	return 0;
}
else{
	if(a1[n-1]<0&&a2[0]>0){
		int p=fabs(fabs(a1[0])-a2[n-1])+1;
		cout<<p;
		return 0;
	}
	else if(a2[n-1]<0&&a1[0]>0){
		int p=fabs(fabs(a2[0])-a1[n-1])+1;
		cout<<p;
		return 0;
	}
	else{
		int p=fabs(a1[0]-a2[0]);
		cout<<p;
	}
}
	return 0;
}















