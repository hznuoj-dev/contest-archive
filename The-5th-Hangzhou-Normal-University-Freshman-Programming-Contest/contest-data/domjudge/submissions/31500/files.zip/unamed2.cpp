#include<bits/stdc++.h>
using namespace std;
#define int long long

int a[200010], b[200010];

void run() {
	string s;
	int n, res, p, cal;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		b[i] = a[i];
	}
	sort(b + 1, b + 1 + n);
	p = n / 2;
	if (n % 2 == 1) {
		res = 1;
		cal = b[p + 1];
	} else {
		if (abs(b[p] - b[p + 1]) < 2) {
			if (b[p] == b[p + 1]) {
				res = 1;
				cal = b[p];
			} else {
				cout << "0\n";
				return;
			}
		} else {
			res = abs(b[p] - b[p + 1]) - 1;
			cal = b[p] + 1;
		}
	}
	for (int i = 1; i <= n; i++) {
		if (a[i] > cal) {
			s += ')';
		} else if (a[i] < cal) {
			s += '(';
		}
	}
	int cur = 0;
	for (int i = 0; i < s.length(); i++) {
		if (s[i] == '(') {
			cur++;
		} else {
			cur--;
		}
		if (cur < 0) {
			cout << "0\n";
			return;
		}
	}
	cout << res << "\n";
	return;
}

signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int T = 1;
//	cin >> T;
	while (T--) {
		run();
	}
	return 0;
}
