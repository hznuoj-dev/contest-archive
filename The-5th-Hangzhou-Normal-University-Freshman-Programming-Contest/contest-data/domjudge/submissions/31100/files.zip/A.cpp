        #include<iostream>
        #include<algorithm>
        #include<queue>
        #include<cmath>
        #include<map>
        #include<iomanip>
        #include<stack>
        #define shojig ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
        using namespace std;
        typedef long long ll;
        int a[1000000];
		int main()
        {
            int n,maxx=0,minn=200001,ans=0;
            cin>>n;
            for(int i=1;i<=n;i++)
			{
				cin>>a[i];
				maxx=max(a[i],maxx);
				minn=min(a[i],minn);
			}
            for(int i=minn+1;i<=maxx-1;i++){
            	int sum=0;
            	for(int j=1;j<=n;j++){
            		if(a[j]<i)sum++;
            		else if(a[j]>i)sum--;
				}
				if(sum==0)ans++;
			}
			cout<<ans;
        } 
