#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
const int N = 1e5 + 10;
typedef long long ll;
bool v[10];
int a[10], b[10];
int m, k;
double ans = 0;

void dfs(int now, int nowx, int n, int cosum, int wsum) {
    if(now == n) {
        if(cosum >= m) cosum -= k;
        if(cosum * 1. / wsum > ans) ans = cosum * 1. / wsum;
        return;
    }
    if(now > n) return;
    if(nowx >= 5) return;
    dfs(now + 1, nowx + 1, n, cosum + a[nowx], wsum + b[nowx]);
    dfs(now, nowx + 1, n, cosum, wsum);
}

void solve() {
	cin >> m >> k;
    for(int i = 0; i < 5; i++) cin >> a[i];
    for(int i = 0; i < 5; i++) cin >> b[i];
	dfs(0, 0, 1, 0, 0);
    dfs(0, 0, 2, 0, 0);
    dfs(0, 0, 3, 0, 0);
    dfs(0, 0, 4, 0, 0);
    dfs(0, 0, 5, 0, 0);
    cout << fixed << setprecision(2);
    cout << ans << "\n";
}
int main()
{
	IOS
	int T = 1;
	// cin >> T;
	while(T--) solve();
	return 0;
}