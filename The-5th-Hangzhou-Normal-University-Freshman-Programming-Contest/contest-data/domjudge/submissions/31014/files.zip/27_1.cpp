#include<iostream>
#include<algorithm>
using namespace std;
int a[100010],b[100010];
int n;
int main()
{
    cin >> n;
    for (int i = 1; i <= n ; i ++ ) cin >> a[i];
    for (int i = 1; i <= n ; i ++ ) cin >> b[i];
    sort(a + 1,a + n + 1),sort(b + 1,b + n + 1);
    int x = a[1] - b[1],flag = 0;
    for (int i = 2; i <= n ; i ++ )
    {
        if (a[i] - b[i] != x) 
        {
            cout << "-1";
            flag = 1;
        }
    }
    if (flag == 0 ) cout << abs(x);
    return 0;
}