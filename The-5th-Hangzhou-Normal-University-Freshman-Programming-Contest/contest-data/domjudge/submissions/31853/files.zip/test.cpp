#include<bits/stdc++.h>
using namespace std;
int a[200010],b[200010];
int c[200010],d[200010];
int main() {
    int n;
    cin >> n;
    bool flag1=1,flag2=1;;
    int ans=1e9;
    for(int i=0;i<n;i++)scanf("%d",&a[i]),c[i]=-a[i];
    for(int i=0;i<n;i++)scanf("%d",&b[i]),d[i]=b[i];
    sort(a,a+n);sort(b,b+n);
     sort(c,c+n);sort(d,d+n);
    int x=0;
    for(int i=0;i<n;i++)
    {
    	if(i==0)x=a[i]-b[i];
    	else
    	{
    		if((a[i]-b[i])!=x)
    		{
    			flag1=0;break;
			}
		}
	}
	x=abs(x);
	int y=0;
	
    for(int i=0;i<n;i++)
    {
    	if(i==0)y=c[i]-d[i];
    	else
    	{
    		if((c[i]-d[i])!=y)
    		{
    			flag2=0;break;
			}
		}
	}
	y=abs(y)+1;
	if(flag1&&flag2)
	{
		cout<<min(x,y);
	}
	else if(flag1)
		cout<<x;
		else if(flag2)
		cout<<y;
		else
		cout<<-1;
	return 0;
}
