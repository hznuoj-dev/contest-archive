#include<bits/stdc++.h>
using namespace std;

int numsa[200000+10];
int numsb[200000+10];
int numsc[200000+10];
signed main () {
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> numsa[i];
		numsc[i] = -numsa[i];
	}
	for (int i = 1; i <= n; i++) {
		cin >> numsb[i];
	}
	sort (numsa + 1, numsa + n + 1);
	sort (numsb + 1, numsb + n + 1);
	sort (numsc + 1, numsc + n + 1);
	int cnta = numsa[1] - numsb[1];
	bool flaga = false;
	for (int i = 2; i <= n; i++) {
		if (cnta != numsa[i] - numsb[i]) {
			flaga = true;
			break;
		}
	}
	int cntb = numsc[1] - numsb[1];
	bool flagb = false;
	for (int i = 2; i <= n; i++) {
		if (cntb != numsc[i] - numsb[i]) {
			flagb = true;
			break;
		}
	}
	if ((flaga == true) && (flagb == true)) {
		cout << "-1";
	} else if ((flaga == true) && (flagb == false)) {
		cout << abs(cntb) + 1;
	} else if ((flaga == false) && (flagb == true)) {
		cout << abs(cnta);
	} else {
		cout << min(abs(cnta), abs(cntb) + 1);
	}
	return 0;
}
