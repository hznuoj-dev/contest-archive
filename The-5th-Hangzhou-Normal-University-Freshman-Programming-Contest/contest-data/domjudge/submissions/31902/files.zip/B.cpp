#include<bits/stdc++.h>

#define star std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

#define endl "\n";

using namespace std;

typedef long long ll;


const ll maxn = 2e5+50;
ll n,a[maxn],b[maxn];
void solve(){
	cin>>n;
	for(ll i=1;i<=n;i++){
		cin>>a[i];
	}
	for(ll i=1;i<=n;i++){
		cin>>b[i];
	}
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	int flag=0;
	for(ll i=1;i<=n-1;i++){
		if(a[i+1]-a[i]!=b[i+1]-b[i]){
			flag=1;
			break;
		}
	}
	if(flag==1){
		for(ll i=1;i<=n-1;i++){
			if(a[i+1]-a[i]!=b[n-i+1]-b[n-i]){
				cout<<"-1"<<endl;
				return;
			}
		}
	}
	if(flag==0){
		cout<<abs(a[n]-b[n])<<endl;
	}else{
		cout<<a[n]+b[1]+1<<endl;
	} 
//	cout<<min(abs(a[n]-b[n]),abs(a[n]+b[1])+1)<<endl;
	return;
}
signed main()
{
star;
int _=1;
//cin>>_;
while(_--){
solve();
}
return 0;
}
//��дջ

