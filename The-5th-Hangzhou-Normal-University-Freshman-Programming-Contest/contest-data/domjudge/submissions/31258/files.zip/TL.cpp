#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,k,i,j,l;
	double price,value,maxn=0,a[6],b[6];
	cin>>n>>k;
	for(i=1;i<=5;i++)
	{
		cin>>a[i];
	}
	for(i=1;i<=5;i++)
	{
		cin>>b[i];
	}
	for(i=0;i<=31;i++)
	{
		price=0;value=0;
		for(j=1,l=1;j<=16;j<<=1,l++)
		{
			if(j&i)
			{
				price+=a[l];
				value+=b[l];
			}
		}
		if(price>=n)
		{
			price-=k;
		}
		maxn=max(maxn,price/value);
	}
	printf("%.2lf",maxn);
	return 0;
}
