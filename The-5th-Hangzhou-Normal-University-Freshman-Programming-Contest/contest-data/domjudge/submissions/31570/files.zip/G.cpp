#include <bits/stdc++.h>
#define endl '\n'
#define int long long
#define x first
#define y second

using namespace std;
typedef pair<int,int> PII;
int T;
int n, m, k, u;
string s;

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);

    cin >> n >> m >> k;
    if(n % 2 == 0) u = 1;
    vector<int> a(n);
    for(int i = 0 ; i < n ; i ++) cin >> a[i];
    int x = 0, f = 0;
    for(int i = 0 ; i < n ; i ++) {
        x += a[i];
        if(i % 2 == u) {
            int z = min(x, k);
            f += z;
            x -= z;
        }
    }

    cout << f << endl;
}

