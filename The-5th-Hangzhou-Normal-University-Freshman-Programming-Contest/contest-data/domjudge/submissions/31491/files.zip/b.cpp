#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
ll a[maxn],b[maxn];
void solve(){
	ll n,ans=-1;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	sort(b+1,b+1+n);
	ll flag=1,res=b[1]-a[1];
	for(int i=2;i<=n;i++){
		if(b[i]-a[i]!=res){
			flag=0;
			break;
		}
	}
	if(flag) ans=abs(res);
	for(int i=1;i<=n;i++){
		a[i]=-a[i];
	}
	sort(a+1,a+1+n);
	flag=1;
	res=b[1]-a[1];
	for(int i=2;i<=n;i++){
		if(b[i]-a[i]!=res){
			flag=0;
			break;
		}
	}
	ans=min(ans,abs(res)+1);
	cout<<ans<<"\n";
	
}
int main(){
	ios::sync_with_stdio(false);
	int T=1;
	//cin>>T;
	while(T--) solve();
}
