#include<bits/stdc++.h>

using namespace std;

const int N = 200005;

#define ll long long

ll a[N];
int vis[N];

void solve(){
	ll n,m,b;
	cin>>n>>m>>b;
	for(int i=1;i<=n;++i){
		cin>>a[i];
	}
	for(int i=n;i>=1;i-=m){
		vis[i] = 1;
	}
	
	ll now = 0;
	ll ans = 0;
	for(int i=1;i<=n;++i){
		now += a[i];
		if(vis[i]){
			ll to = min(now,b);
			now -= to;
			ans += to;
		}
	}
	
	cout<<ans;
}

int main(){
	cin.sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
