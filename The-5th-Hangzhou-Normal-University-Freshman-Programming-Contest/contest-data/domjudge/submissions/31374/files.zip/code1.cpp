#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IO ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
const int N = 2e5 + 5;
int n,m, k;
double a[10], b[10], sa = 0, sb = 0;


signed main(){
    IO;
    cin >> m >> k;
    for(int i = 1;i <= 5;i++)
        cin >> a[i], sa += a[i];

    for(int i = 1;i <= 5;i++)
        cin >> b[i], sb += b[i];

    double ans = b[1] / a[1];
    for(int i = 1;i <= 5;i++){
        double v = a[i];
        if(v >= m) v -= k;
        ans = max(ans, b[i]/v);
    }

    for(int i = 1;i <= 5;i++)
        for(int j = 1;j <= 5;j++) if(i != j){
            double v = a[i] + a[j];
            double bb = b[i] + b[j];
            if(v >= m) v -= k;
            ans = max(ans, bb / v);
        }

    for(int i = 1;i <= 5;i++)
        for(int j = 1;j <= 5;j++) if(i != j){
            double v = sa - a[i] - a[j];
            double bb = sb - b[i] - b[j];
            if(v >= m) v -= k;
            ans = max(ans, bb / v);
        }

    for(int i = 1;i <= 5;i++){
        double v = sa - a[i];
        double bb = sb - b[i];
        if(v >= m) v-= k;
        ans = max(ans, bb/v);
    } 

    if(sa >= m) sa -= k;
    ans = max(ans, sb / sa);

    printf("%.2lf", ans);

    return 0;
}