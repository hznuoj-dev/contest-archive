        #include<iostream>
        #include<algorithm>
        #include<queue>
        #include<cmath>
        #include<map>
        #include<iomanip>
        #include<stack>
        #define shojig ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
        using namespace std;
        typedef long long ll;
        int a[2000000],b[2000000];
		int main()
        {
           	int n;
           	cin>>n;
           	for(int i=1;i<=n;i++){
           		cin>>a[i];
           		b[i]=a[i];
			}
			sort(b+1,b+n+1);
			int l,r;
			if(n%2){
				l=b[n/2+1];
				r=l;
			}
			else {
				l=b[n/2];
				r=b[n/2+1];
			}
			l=max(a[1],l);
			r=min(a[n],r);
			if(l==r)cout<<"1";
			else if(l>r)cout<<"0";
			else cout<<r-l-1;
           	
		}
		 
