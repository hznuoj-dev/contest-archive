#include <bits/stdc++.h>
using namespace std;
int main()
{
	int m, k, a[7], b[7];
	cin >> m >> k;
	for (int i = 1; i <= 5; i++) cin >> a[i];
	for (int i = 1; i <= 5; i++) cin >> b[i];
	/*for (int i = 1; i <= 5; i++){
		p[i].c = p[i].b * 1.0 / p[i].a * 1.0;
	}
	sort(p + 1, p + 6, cmp);
    for (int i = 1; i <= 5; i++){
        cout << p[i].a << ' ' << p[i].b <<  endl;
	}
	double price = p[1].a, mm = p[1].b;
	double ans = price / mm;
	for (int i = 2; i <= 5; i++) {
        price += p[i].a;
        mm += p[i].b;
        if (price >= m) ans = max((mm) / (price - k), ans);
        else ans = max(ans, mm / price);
	}
	printf("%.2f", ans);*/
    double price = 0, mm = 0, ans = 0;
    for (int i = 1; i <= 5; i ++){
        mm = b[i];
        price = a[i];
        if (a[i] >= m){
            ans = max(b[i] / (a[i] - k),ans);
        } else ans = max(b[i] / a[i],ans);
    }
    for (int i = 1; i <= 5; i ++){
        for (int j = i; i <= 5; i ++)
        {
            if (i == j) continue;
            price = a[i] + a[j];
            mm = b[i] + b[j];
            if (price >= m) ans = max(mm / (price - k),ans);
            else ans = max(mm / price,ans);
        }
    }
    double totp = 0, totm = 0;
    for (int i = 1; i <= 5; i ++){
        totp += a[i];
        totm += b[i];
    }
    for (int i = 1; i <= 5; i ++){
        for (int j = i; j <= 5; j ++){
            if (i == j) continue;
            price = totp -a[i] - a[j];
            mm = totm - b[i] - b[j];
            if (price >= m) ans = max(mm / (price - k),ans);
            else ans = max(mm / price,ans);
            //cout << mm << ' ' << price << ' ' << ans <<  ' ' << i << ' ' << j <<endl;
        }
    }
    for (int i = 1; i <= 5; i ++){
            price = totp -a[i];
            mm = totm - b[i];
            if (price >= m) ans = max(mm / (price - k),ans);
            else ans = max(mm / price,ans);
        
    }
    if (totp >= m) ans = max((totm) / (totp - k), ans);
    else ans = max(totm / totp,ans);
    printf("%.2f", ans);
	return 0;
}