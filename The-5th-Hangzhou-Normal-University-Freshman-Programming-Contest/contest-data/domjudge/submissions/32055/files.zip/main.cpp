#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define dl <<"\n"
#define pub push_back
#define pob pop_back
#define pof pop_front
#define puf push_front
#define eps 1e-6
#define MAXX 1e5+1
#define IOS ios::sync_with_stdio(false), cin.tie(0), cout.tie(0)

//const ll INF = 0x3f3f3f3f3f3f3f3f;
const int inf = 0x3f3f3f3f, mod = 1000000007, rge1 = 1000100, rge2 = 10001;

//ll s[200001] = { 0 };

/*
double m = 0, k = 0;
double d = 0;

struct GOOD {
    double p;//price
    double c;//comment
    double r;//rate
};

GOOD g[5];

bool mc(GOOD x, GOOD y) {

    if (x.r != y.r) {

        if (x.r > y.r) {
            d += x.p;
        }
        else {
            d += y.p;
        }

        return x.r > y.r;
    }
    else {

        if (x.p >= (m - d)) {

            if (y.p < (m - d)) {
                d += x.p;
                return true;
            }
            else {

                if (x.p < y.p) {
                    d += x.p;
                }
                else {
                    d += y.p;
                }

                return x.p < y.p;
            }

        }
        else {

            if (y.p >= (m - d)) {
                d += y.p;
                return false;
            }
            else {

                if (x.p > y.p) {
                    d += x.p;
                }
                else {
                    d += y.p;
                }

                return x.p > y.p;
            }

        }
    
    }

}
*/

double price[6] = { 0 }, comment[6] = { 0 }, rate[40] = { 0 };

void LolitaSama() {

    /*
    L

    ll n = 0, k = 0;
    cin >> n >> k;

    ll c = 0;

    for (ll i = 1; i <= n; i++) {
        cin >> s[i];
        if (s[i] == i) c++;
    }

    if (n == k + 1) {
        cout << "-1" dl;
    }
    else {
        cout << (c + 1 - k) / 2 dl;
    }
    */

    /*
    cin >> m >> k;

    for (int i = 0; i < 5; i++) {
        cin >> g[i].p;
    }
    for (int i = 0; i < 5; i++) {
        cin >> g[i].c;
        g[i].r = g[i].c / g[i].p;
    }

    sort(g, g + 5, mc);

    double sump = 0;
    double sumc = 0;
    double rem = g[0].r;

    for (int i = 0; i < 5;i++) {
    
        sump += g[i].p;
        sumc += g[i].c;
        if (sump >= m) {
            cout << fixed << setprecision(2) << max((sumc) / (sump - k), rem) dl;
            return;
        }

    }

    cout << fixed << setprecision(2) << rem dl;
    */

    /*
    ll n = 0;
    cin >> n;

    if (n % 2 != 0) {
        cout << "0" dl;
        return;
    }
    
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    
    int cnt = 0;

    for (int i = a[0]; i <= a[n - 1]; i++) {
        
        int op = 0;

        for (int j = 0; j < n; j++) {
            if (a[j] < i) op--;
            else if (a[j] > i) op++;
        }

        if (op == 0) {
            cnt++;
        }

    }

    cout << cnt dl;
    */

    int m, k;
    cin >> m >> k;

    for (int i = 1; i <= 5; i++) {
        cin >> price[i];
    }

    for (int i = 1; i <= 5; i++) {
        cin >> comment[i];
    }

    double sump = 0, sums = 0;

    //1
    sump = price[1], sums = comment[1];
    if (sump >= m) sump -= k;
    rate[1] = sums / sump;
    //2
    sump = price[2], sums = comment[2];
    if (sump >= m) sump -= k;
    rate[2] = sums / sump;
    //3
    sump = price[3], sums = comment[3];
    if (sump >= m) sump -= k;
    rate[3] = sums / sump;
    //4
    sump = price[4], sums = comment[4];
    if (sump >= m) sump -= k;
    rate[4] = sums / sump;
    //5
    sump = price[5], sums = comment[5];
    if (sump >= m) sump -= k;
    rate[5] = sums / sump;

    //1 2
    sump = price[1] + price[2], sums = comment[1] + comment[2];
    if (sump >= m) sump -= k;
    rate[6] = sums / sump;
    //1 3
    sump = price[1] + price[3], sums = comment[1] + comment[3];
    if (sump >= m) sump -= k;
    rate[7] = sums / sump;
    //1 4
    sump = price[1] + price[4], sums = comment[1] + comment[4];
    if (sump >= m) sump -= k;
    rate[8] = sums / sump;
    //1 5
    sump = price[1] + price[5], sums = comment[1] + comment[5];
    if (sump >= m) sump -= k;
    rate[9] = sums / sump;
    //2 3
    sump = price[2] + price[3], sums = comment[2] + comment[3];
    if (sump >= m) sump -= k;
    rate[10] = sums / sump;
    //2 4
    sump = price[2] + price[4], sums = comment[2] + comment[4];
    if (sump >= m) sump -= k;
    rate[11] = sums / sump;
    //2 5
    sump = price[2] + price[5], sums = comment[2] + comment[5];
    if (sump >= m) sump -= k;
    rate[12] = sums / sump;
    //3 4
    sump = price[3] + price[4], sums = comment[3] + comment[4];
    if (sump >= m) sump -= k;
    rate[13] = sums / sump;
    //3 5
    sump = price[3] + price[5], sums = comment[3] + comment[5];
    if (sump >= m) sump -= k;
    rate[14] = sums / sump;
    //4 5
    sump = price[4] + price[5], sums = comment[4] + comment[5];
    if (sump >= m) sump -= k;
    rate[15] = sums / sump;

    //1 2 3
    sump = price[1] + price[2] + price[3], sums = comment[1] + comment[2] + comment[3];
    if (sump >= m) sump -= k;
    rate[16] = sums / sump;
    //1 2 4
    sump = price[1] + price[2] + price[4], sums = comment[1] + comment[2] + comment[4];
    if (sump >= m) sump -= k;
    rate[17] = sums / sump;
    //1 2 5
    sump = price[1] + price[2] + price[5], sums = comment[1] + comment[2] + comment[5];
    if (sump >= m) sump -= k;
    rate[18] = sums / sump;
    //1 3 4
    sump = price[1] + price[3] + price[4], sums = comment[1] + comment[3] + comment[4];
    if (sump >= m) sump -= k;
    rate[19] = sums / sump;
    //1 3 5
    sump = price[1] + price[3] + price[5], sums = comment[1] + comment[3] + comment[5];
    if (sump >= m) sump -= k;
    rate[20] = sums / sump;
    //1 4 5
    sump = price[1] + price[4] + price[5], sums = comment[1] + comment[4] + comment[5];
    if (sump >= m) sump -= k;
    rate[21] = sums / sump;
    //2 3 4
    sump = price[2] + price[3] + price[4], sums = comment[2] + comment[3] + comment[4];
    if (sump >= m) sump -= k;
    rate[22] = sums / sump;
    //2 3 5
    sump = price[2] + price[3] + price[5], sums = comment[2] + comment[3] + comment[5];
    if (sump >= m) sump -= k;
    rate[23] = sums / sump;
    //2 4 5
    sump = price[2] + price[4] + price[5], sums = comment[2] + comment[4] + comment[5];
    if (sump >= m) sump -= k;
    rate[24] = sums / sump;
    //3 4 5
    sump = price[3] + price[4] + price[5], sums = comment[3] + comment[4] + comment[5];
    if (sump >= m) sump -= k;
    rate[25] = sums / sump;

    //1 2 3 4
    sump = price[1] + price[2] + price[3] + price[4], sums = comment[1] + comment[2] + comment[3] + comment[4];
    if (sump >= m) sump -= k;
    rate[26] = sums / sump;
    //1 2 3 5
    sump = price[1] + price[2] + price[3] + price[5], sums = comment[1] + comment[2] + comment[3] + comment[5];
    if (sump >= m) sump -= k;
    rate[27] = sums / sump;
    //1 2 4 5
    sump = price[1] + price[2] + price[4] + price[5], sums = comment[1] + comment[2] + comment[4] + comment[5];
    if (sump >= m) sump -= k;
    rate[28] = sums / sump;
    //1 3 4 5
    sump = price[1] + price[3] + price[4] + price[5], sums = comment[1] + comment[3] + comment[4] + comment[5];
    if (sump >= m) sump -= k;
    rate[29] = sums / sump;
    //2 3 4 5
    sump = price[2] + price[3] + price[4] + price[5], sums = comment[2] + comment[3] + comment[4] + comment[5];
    if (sump >= m) sump -= k;
    rate[30] = sums / sump;

    //1 2 3 4 5
    sump = price[1] + price[2] + price[3] + price[4] + price[5], sums = comment[1] + comment[2] + comment[3] + comment[4] + comment[5];
    if (sump >= m) sump -= k;
    rate[31] = sums / sump;
    
    sort(rate + 1, rate + 32);

    printf("%.2lf\n", rate[31]);

}

int main() {

    //IOS;

    int T = 1;
    //cin >> T;


    while (T--) {

        LolitaSama();

    }

}
