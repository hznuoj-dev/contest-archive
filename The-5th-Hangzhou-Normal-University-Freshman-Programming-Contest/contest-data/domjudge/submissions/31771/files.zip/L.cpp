#include<bits/stdc++.h>
using namespace std;
typedef struct total{
	int a;
	int b;
}t;
bool cmp(t x,t y)
{
	if(x.b == y.b)
	{
		return x.a<y.a;
	}
	else
	{
		return x.b>y.b;
	}
}
int main()
{
	int m,k;
	t c[5];
	cin>>m>>k;
	for(int i = 0; i < 5; i++)
	{
		cin>>c[i].a;
	}
	for(int i = 0; i < 5; i++)
	{
		cin>>c[i].b;
	}
	sort(c,c+5,cmp);
	float num1 = 0,num2 = 0,sum = 0,max = 0,flag =1;
	for(int i = 0; i < 5;i++)
	{
		num1+=c[i].b;
		num2+=c[i].a;
		if(num2>=m&&flag == 1)
		{
			num2-=k;
			flag = 0;
		}
		sum = num1/num2;
		if(sum>=max)
		{
			max = sum;
		}
	}
	printf("%.2f",max);
	
}
