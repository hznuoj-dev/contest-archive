        #include<iostream>
        #include<algorithm>
        #include<queue>
        #include<cmath>
        #include<map>
        #include<iomanip>
        #include<stack>
        #define shojig ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
        using namespace std;
        typedef long long ll;
        int a[2000000],b[2000000],a1[2000000],b1[2000000],c[2000000],c1[2000000];
		int main()
        {
           	int n,mina,minb;
           	cin>>n;
           	for(int i=1;i<=n;i++){
           		cin>>a[i];
           		b[i]=-1*a[i];
			}
			sort(a+1,a+n+1);
			sort(b+1,b+n+1);
			for(int i=1;i<=n;i++)cin>>c[i];
			sort(c+1,c+n+1);
			int f1=1,f2=1;
			for(int i=1;i<n;i++){
				if((a[i+1]-a[i])!=(c[i+1]-c[i]))f1=0;
				if((b[i+1]-b[i])!=(c[i+1]-c[i]))f2=0;
			}
			if(f1==0&&f2==0)cout<<"-1";
			else{
				mina=abs(a[1]-c[1]);
				minb=abs(b[1]-c[1])+1;
				if(f1==1&&f2==0){
					cout<<mina;
				}
				if(f2==1&&f1==0){
					cout<<minb;
				}
				if(f1==1&&f2==1){
					cout<<min(mina,minb);
				}
				
			}
           	
		}
		 
