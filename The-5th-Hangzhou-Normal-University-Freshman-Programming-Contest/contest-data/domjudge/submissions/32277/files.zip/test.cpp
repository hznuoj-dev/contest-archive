#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=2e5+10;
long long n,a[maxn];
bool check(int k){
    int cnt1=0,cnt2=0;
    for(int i=1;i<=n;i++){
        if(a[i]>k)  cnt1++;
        if(a[i]<k)  cnt2++;
    }
    if(cnt1==cnt2)  return true;
    else    return false;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n;
    for(int i=1;i<=n;i++)   cin>>a[i];
    int cnt=0;
    sort(a+1,a+1+n);
    int num1=a[n/2];
    int num2=a[n/2+1];
    for(int i=num1;i<=num2;i++){
        if(check(i))    cnt++;
    }
    cout<<cnt;
}