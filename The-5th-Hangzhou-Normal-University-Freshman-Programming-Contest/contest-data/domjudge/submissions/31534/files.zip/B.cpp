#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
    ll a;
    ll b;
    double m;
}p[6];
bool cmp(Node a, Node b)
{
    if(a.m != b.m)
       return a.m > b.m;
    else if(a.a != b.a)
       return a.a > b.a;
}
int main()
{
    ll m, k;
    cin >> m >> k;
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].a;
    }
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].b;
        p[i].m = (double)p[i].b / (double)p[i].a;
    }
    sort(p+1, p+5+1, cmp);
    double maxx = 0;
    int flag = 0;
    ll sum = 0;
    ll ans = 0;
    int i = 0;
    for(i = 1; i <= 5; ++i){
        sum += p[i].a;
        ans += p[i].b;
        if(sum >= m && flag == 0){
            flag = 1;
            sum -= k;
        }
        double temp = (double)ans / (double)sum;
        maxx = max(temp, maxx);
    }
    printf("%.2lf\n", maxx);
    return 0;
}