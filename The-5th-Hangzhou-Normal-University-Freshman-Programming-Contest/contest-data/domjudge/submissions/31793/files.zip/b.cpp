#include<stdio.h>
#include<stdlib.h>

int cmp(const void* e1, const void* e2)
{
	return *(long long int*)e1 - *(long long int*)e2;
}

int main()
{
	int n, ah = 0, bh = 1, p;
	long long int a[20001], b[200001];
	scanf("%d", &n);
	
	for (int i = 0; i < n; i++)
		scanf("%lld", &a[i]);
	for (int i = 0; i < n; i++)
		scanf("%lld", &b[i]);
		
	qsort(a, n, sizeof(a[0]), cmp);
	qsort(b, n, sizeof(a[0]), cmp);
	
	p = a[0] - b[0];
	for (int i = 1; i < n; i++)
	{
		if (p != a[i] - b[i])
		{
			ah = -1;
			break;
		}
	}
	if (ah == 0)
		ah = abs(p);
	
	for (int i = 0; i < n; i++)
	{
		b[i] = -b[i];
	}
	qsort(b, n, sizeof(a[0]), cmp);
	p = a[0] - b[0];
	for (int i = 1; i < n; i++)
	{
		if (p != a[i] - b[i])
		{
			bh = -1;
			break;
		}
	}
	if (bh == 1)
		bh = abs(p) + 1;
	
	if (ah != -1 && bh != -1)
	{
		if (ah < bh)
			printf("%d", ah);
		else
			printf("%d", bh);
	}
	else if (ah == -1 && bh == -1)
	{
		printf("-1");
	}
	else if (ah != -1 && bh == -1)
	{
		printf("%d", ah);
	}
	else if (ah == -1 && bh != -1)
	{
		printf("%d", bh);
	}
}