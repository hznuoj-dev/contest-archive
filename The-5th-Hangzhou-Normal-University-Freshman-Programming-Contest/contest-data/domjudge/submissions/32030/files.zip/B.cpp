#include <bits/stdc++.h>

int n;

int count(std::vector<int>&a, std::vector<int>&b, std::vector<int>&c, std::vector<int>&d, int cnt) {
	int dec = a[0] - b[0];
	//std::cout << dec << "\n";
	bool ok = 1;
	
	for (int i = 1; i < n; i++) {
		int tmp = a[i] - b[i];
		if (tmp != dec) {
			ok = 0;
			break;
		}
	}
	
	if (!ok) return (int)2e9 + 7;
	else {
		int ans = abs(dec);
		//std::cout << ans << "\n";
		ans += cnt;
		return ans;
	}
}

void solve() {
	std::cin >> n;
	
	std::vector<int> a(n), b(n), c(n), d(n), aa(n), bb(n), cc(n), dd(n);
	
	for (int i = 0; i < n; i++) {
		std::cin >> a[i];
		c[i] = a[i];
		cc[i] = -a[i];
	}
	
	for (int i = 0; i < n; i++) {
		std::cin >> b[i];
		d[i] = b[i];
		dd[i] = -b[i];
	}
	
	std::sort(a.begin(), a.end());
	std::sort(b.begin(), b.end());
	
	for (int i = 0; i < n; i++) aa[i] = -a[i];
	for (int i = 0; i < n; i++) bb[i] = -b[i];
	
	std::sort(aa.begin(), aa.end());
	std::sort(bb.begin(), bb.end());
	
	//for (auto it : aa) std::cout << it << " ";
	//std::cout << "\n";
	
	int ans = (int)2e9 + 7;
	ans = std::min({count(a, b, c, d, 0), count(aa, b, cc, d, 1), count(a, bb, c, dd, 1), count(aa, bb, cc, dd, 2)});
	if (ans == (int)2e9 + 7) std::cout << -1;
	else {
		std::cout << ans;
	}
}

int main() {
	solve();
}
