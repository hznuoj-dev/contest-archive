#include <bits/stdc++.h>
#define endl '\n'
#define int long long
#define x first
#define y second

using namespace std;
typedef pair<int,int> PII;
int T;
int n, m;
string s;

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);

    cin >> n;
    vector<int> a(n),b(n),c(n);
    for(int i = 0 ; i < n ; i ++) {cin >> a[i]; c[i] = - a[i];}
    for(int i = 0 ; i < n ; i ++) cin >> b[i];
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    sort(c.begin(), c.end());

    set<int> s,t;
    for(int i = 0 ; i < n ; i ++) s.insert(abs(a[i] - b[i]));
    for(int i = 0 ; i < n ; i ++) t.insert(abs(c[i] - b[i]));

    bool ok = false;
    int ans = 9e18;
    if(s.size() == 1) {
        ok = true;
        ans = min(ans, *s.begin());
    }

    if(t.size() == 1) {
        ok = true;
        ans = min(ans, *t.begin()+1);
    }

    if(!ok) cout << -1 << endl;
    else cout << ans << endl;
}

