#define _CRT_SECURE_NO_WARNINGS 1
#include<bits/stdc++.h>
#define ios  ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
typedef long long LL;
const LL MAXN = 1e5+10;
const int Inf = 0x7fffffff;
const LL INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
int m,k;
int a[10];
int b[10];
double ans=0.0;
bool in[6];
void dfs(int now)
{
	if(now>5)
	{
		int aa=0,bb=0;
		double cnt=0.0;
		for(int i=1;i<=5;++i)
		{
			if(in[i]==1)
			{
			  aa+=a[i];
			  bb+=b[i];
			}
		}
		if(aa>=m)
			aa-=k;
		cnt=(double)bb/(double)aa;
		if(cnt>ans)
			ans=cnt;
		return;
	}
	for(int i=0;i<=1;++i)
	{
		in[now]=i;
		dfs(now+1);
	}
}
int main()
{
	//ios;
	scanf("%d%d",&m,&k);
	for(int i=1;i<=5;++i)
		scanf("%d",&a[i]);
	for(int i=1;i<=5;++i)
		scanf("%d",&b[i]);
	dfs(1);
	printf("%.2f",ans);
	//system("pause");
	return 0;
}