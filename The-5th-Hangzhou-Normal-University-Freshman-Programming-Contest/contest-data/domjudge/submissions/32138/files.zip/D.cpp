#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
using ll = long long;
const int N = 2e5 + 10, INF = 2e9 + 10;
ll bits[N];
int n, k, q;
inline int lowbit(int x) {
    return x & (-x);
}
void add(int x, int v) {
    while(x <= n) {
        bits[x] += v;
        x += lowbit(x);
    }
}
ll query(int x) {
    ll ret = 0;
    while(x) {
        ret += bits[x];
        x -= lowbit(x);
    }
    return ret;
}

int rPos[N], a[N];
map<int, int> mp;
int main()
{
    scanf("%d %d %d", &n, &k, &q);
    for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
    mp[INF] = n + 1;
    mp[-INF + 1] = n + 1;
    mp[-INF] = n + 1;
    for(int i = n; i >= 1; i--) {
        mp[a[i]] = i;
        auto it1 = mp.upper_bound(a[i] + k), it2 = mp.lower_bound(a[i] - k);
        it2 = prev(it2);
        rPos[i] = min(it1->second, it2->second) - i - 1;
        add(i, rPos[i] + 1);
    }

    int l, r;
    for(int i = 0; i < q; i++) {
        scanf("%d %d", &l, &r);
        int lh = l, rh = r, pos = r;
        while(lh <= rh) {
            int mid = (lh + rh) / 2;
            if(rPos[mid] + mid >= r) {
                pos = mid;
                rh = mid - 1;
            } else {
                lh = mid + 1;
            }
        }

        long long ans = 0;
        int num = r - pos + 1;
        r = pos - 1;
        ans += num * 1ll * (num + 1) / 2;
        if(r >= l)  ans += query(r) - query(l-1);
        printf("%lld\n", ans);
    }

    return 0;
}