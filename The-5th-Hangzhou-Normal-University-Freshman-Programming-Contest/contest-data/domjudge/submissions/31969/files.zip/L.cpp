#include<bits/stdc++.h>
using namespace std;
struct node{
	int a;
	int b;
	double v;
}num[10];
void slove(){
	int m,k;
	cin>>m>>k;
//	int a[10],b[10];
	for(int i=1;i<=5;i++){
		cin>>num[i].a;
	} 
	for(int i=1;i<=5;i++){
		cin>>num[i].b;
		num[i].v=(double)num[i].b/(double)num[i].a;
	}
	double ans=0;
	double P=0,Q=0;
	
	//��һ��������� 
	for(int i=1;i<=5;i++){double p;
		if(num[i].a>m)  p=num[i].a-k;
		else p=num[i].a;
		double vv=(double)num[i].b/p;
		if(vv>ans) ans=vv;
		P+=num[i].a;
		Q+=num[i].b;
	}
	if(P>=m) P-=k; 
	double V=Q/P;
	if(V>ans) ans=V;
//	cout<<V<<endl;
	for(int i=1;i<=5;i++){
		for(int j=i+1;j<=5;j++){
			double p=num[i].a+num[j].a;
			if(p>=m) p-=k;
			double q=num[i].b+num[j].b;
			double vv=q/p;
			if(vv>ans) ans=vv;
			
		}
	}
	for(int i=1;i<=5;i++){
		for(int j=i+1;j<=5;j++){
			for(int kk=j+1;kk<=5;kk++){
				double p=num[i].a+num[j].a+num[kk].a;
				if(p>=m) p-=k;
			
			double q=num[i].b+num[j].b+num[kk].b;
			double vv=q/p;
			if(vv>ans) ans=vv;//cout<<vv<<endl;
			}
		}
	}
	for(int i=1;i<=5;i++){
		double p=0;
		double q=0;
		for(int j=1;j<=5;j++){
			if(j!=i) {
				p+=num[j].a;
				q+=num[j].b;
			}
		}
		if(p>=m) p-=k;
		double vv=q/p;
			if(vv>ans) ans=vv;
	}

	printf("%.2lf",ans); 
}
int main(){
	int T=1;
//	cin>>T;
	while(T--){
		slove();
	}
	
	return 0;
} 
