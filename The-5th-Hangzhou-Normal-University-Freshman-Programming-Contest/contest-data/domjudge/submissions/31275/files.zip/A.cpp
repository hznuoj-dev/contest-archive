#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
typedef unsigned long long ull;
const int N=2e5+10;
const int mod=1e9+7;

int n,a[N];

int check(int x)
{
	int res=0;
	
	for(int i=1;i<=n;i++)
	{
		if(a[i]<x)
			res++;
		else if(a[i]>x)
			res--;
		if(res<0)
			return 0;
	}
	
	if(res==0)
		return 2;
	else
		return 1;
}

void run()
{
	int l,r,mid,ans=0,ll=mod,rr=0,x;

	cin >> n;
	for(int i=1;i<=n;i++)
		cin >> a[i];

	l=1;r=200000;
	while(l<=r)
	{
		mid=l+r>>1;
		x=check(mid);
		if(x==2)
		{
			r=mid-1;
			ll=mid;
		}
		else if(x==1)
			r=mid-1;
		else
			l=mid+1;
	}
	
	l=1;r=200000;
	while(l<=r)
	{
		mid=l+r>>1;
		x=check(mid);
		if(x==2)
		{
			l=mid+1;
			rr=mid;
		}
		else if(x==1)
			r=mid-1;
		else
			l=mid+1;
	}
	
//	cout << '#' << ll << ' ' << rr << endl;
	cout << max(0LL,rr-ll+1);
}

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

