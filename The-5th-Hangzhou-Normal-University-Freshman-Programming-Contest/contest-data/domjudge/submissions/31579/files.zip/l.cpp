#include<bits/stdc++.h>

using namespace std;

#define int long long
#define ll long long
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pii pair<int,int>
#define pb push_back
//#define endl "\n"
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 3e5+7;
const int mod = 998244353;

int a[N],b[N];
int m,k;
double res;
void dfs(string s,int ans1,int ans2){
	//dbg(s,ans1,ans2,res);
	if(ans1 != 0&&ans2!=0){
		if(ans1 >=m) res = max(1.0*ans2/(ans1-k),res);
		else res = max(1.0*ans2/(ans1),res);
	}
	for(int i=1;i<=5;i++){
		string c = to_string(i);
		if(s.find(c) == -1){
			dfs(s+c,ans1+a[i],ans2+b[i]);
		}
	}
}

void solve(){
	cin >> m >> k;
	for(int i=1;i<=5;i++) cin >> a[i];
	for(int i=1;i<=5;i++) cin >> b[i];
	dfs("",0,0);	
	printf("%.2f",res);
	
}
/*
5 3
1 2 4 4 2
2 2 1 2 4
*/

signed main(){
//	ios::sync_with_stdio(0);
//    cin.tie(nullptr);cout.tie(nullptr);
	int T = 1;
    //cin >> T;
    while(T--) solve();

    return 0 ;
}

