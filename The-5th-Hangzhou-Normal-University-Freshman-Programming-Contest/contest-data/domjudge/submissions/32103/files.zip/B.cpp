#include <bits/stdc++.h>
using namespace std;
#define fastio ios::sync_with_stdio(false);cin.tie(0); cout.tie(0)
typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e6 + 5;

ll a[200001],b[200001];

signed main(){
    fastio;
    int n,h=0;
    ll su1=0,su2=0,su3,c,d,j=1,k=1;
    cin>>n;
    for(int i=0;i<n;i++)cin>>a[i],su1+=a[i];
    sort(a,a+n);
    for(int i=0;i<n;i++)cin>>b[i],su2+=b[i];
    sort(b,b+n);
    c=a[0]-b[0];d=a[0]+b[n-1];
    for(int i=1;i<n;i++){
        if(a[i]-b[i]!=c){
            j=0;break;
        }
    }
    for(int i=1;i<n;i++){
        if(a[i]+b[n-i-1]!=d){
            k=0;break;
        }
    }
    if(j==0&&k==0){
        printf("-1");
    }
    else if(j==0&&k==1){
        printf("%lld",abs(c)+1);
    }
    else {
        if(abs(d)<abs(c)){
            d=abs(d);
            d++;
        }
        else d=abs(d);
        printf("%lld",d);
    }

}