#include<bits/stdc++.h>
using namespace std;
int n;
const int maxn = 2e5 + 9;
int a[maxn],cnt[maxn],tmp[maxn];
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin >> n;
	for(int i = 1;i <= n;i ++){
		cin >> a[i];
		cnt[a[i]]++;
	}
	memcpy(tmp,a,sizeof(tmp));
	sort(a + 1,a + 1 + n);
	if(n % 2){
		if(cnt[a[n/2 + 1]] % 2){
			cout << 1 << '\n';
		}
	}else{
		if(a[n/2] != a[n/2 + 1]){
			int l = a[n/2] + 1,r = a[n/2 + 1];
			int rec = r;
			int left = 0,right = 0,mid = (l + r) / 2;
			memcpy(a,tmp,sizeof(a));
			while(l < r){
				bool f = 0;
				left = 0,right = 0;
				mid = (l + r) / 2;
				for(int i = 1;i <= n;i ++){
					if(a[i] < mid) ++ left;
					if(a[i] > mid) ++ right;
					if(right > left){
						l = mid + 1;
						f = 1;
						break;
					}
				}
				if(f) continue;
				r = mid;
			}
			cout << rec - r << '\n';
		}else{
			if(cnt[a[n/2]] % 2 == 0) cout << 1 << '\n';
			else cout << 0 << '\n';
		}
	}
	return 0;
}

