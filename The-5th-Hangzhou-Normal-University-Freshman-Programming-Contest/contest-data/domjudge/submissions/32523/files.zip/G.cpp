#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IO ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
const int N = 2e5 + 5;
int n, a[N], m, b, d[N][2], s[N];


signed main(){
    IO;
    cin >>n >> m >> b;
    for(int i = 1;i <= n;i++)
        cin >> a[i], s[i] = s[i-1] + a[i];

    for(int i = 1;i <= m;i++){
        d[i][1] = min(b, s[i]);
        d[i][0] = d[i-1][1];
        // cout << d[i][1] << ' ' << d[i][0] << '\n';
    }

    for(int i = m + 1;i <= n;i++){
        d[i][1] = (d[i-m][1]+min(b, s[i]-d[i-m][1]));
        d[i][0] = (d[i-1][1]+min(b, s[i]-d[i-1][1]));
        // cout << d[i][1] << ' ' << d[i][0] << '\n';
    }

    cout << d[n][1];


    return 0;
}