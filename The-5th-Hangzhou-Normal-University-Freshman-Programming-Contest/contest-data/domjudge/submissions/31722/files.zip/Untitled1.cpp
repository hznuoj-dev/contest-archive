#include<bits/stdc++.h>
#define int long long
#define endl '\n'
using namespace std;
int n,l,q,m,t,et,fa[200005][20],fw[200005][20],a[200005],p[200005],z[200005];
struct edge{
	int v,w;
	edge(){
		
	}
	edge(int _v,int _w):v(_v),w(_w){
		
	}
};
vector <edge> g[200005];
void dfs(int u) {
	for (int i=1;i<20;++i) {
		fa[u][i]=fa[fa[u][i-1]][i-1];
		fw[u][i]=fw[u][i-1] xor fw[fa[u][i-1]][i-1];
	}
	z[u]++;
	for (edge e:g[u]) {
		int v=e.v,w=e.w;
		if (v==fa[u][0]) continue;
		fa[v][0]=u;fw[v][0]=w;
		dfs(v);
		z[u]+=z[v];
		if (z[v]&1) p[u]=p[u] xor w;
		p[u] =p[u] xor p[v];
	}
}
int back(int u,int x) {
	for (int i=19;i>=0;--i) {
		if (fa[u][i]) {
			x=fw[u][i] xor x;
			u=fa[u][i];
		}
	}
	return x;
}
signed main(){
	cin >> n;
	for (int i=1;i<n;++i) {
		int u,v,w;
		cin >> u >> v >> w;
		g[u].push_back(edge(v,w));
		g[v].push_back(edge(u,w)); 
	}
	dfs(1);
	cin >> q;
	while (q--) {
		int u,x;
		cin >> u >> x;
		if (z[1]&1) a[1]=back(u,x);
		cout << (a[1] xor p[1]) << endl;
	}
	
}
