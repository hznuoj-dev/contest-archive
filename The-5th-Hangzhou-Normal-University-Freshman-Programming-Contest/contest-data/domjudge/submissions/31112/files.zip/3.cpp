#include<bits/stdc++.h>
using namespace std; 
const int N = 2e5+5;
int a[N],b[N],c[N];
int main()
{
	int n; cin >> n;
	bool f = 1;
	for(int i = 1;i <= n;i++) cin >> a[i];
	for(int i = 1;i <= n;i++)
	{
		cin >> b[i];
		c[i] = -b[i];
	}
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	int p = 1;
	
	for(int i = 2;i <= n;i++)
	{
		if(a[i] - b[i] != a[i - 1] - b[i - 1] )
		{
			p = 0;
			break;
		}
	}
	
	for(int i = 2;i <= n;i++)
	{
		if(a[i] - c[i] != a[i - 1] - c[i - 1] )
		{
			f = 0;
			break;
		}
	}
	if(!f && !p)
	{
		puts("-1");
		return 0;
	}else if(f && p)
	{
		cout << min(abs(a[1] - c[1]) + 1,abs(a[1] - b[1])) << '\n';
		return 0;
	}else if(f)
	{
		cout << abs(a[1] - c[1]) + 1 << '\n';
		return 0;
	}else if(p)
	{
		cout << abs(a[1] - b[1]) << '\n';
		return 0;
	}
}
