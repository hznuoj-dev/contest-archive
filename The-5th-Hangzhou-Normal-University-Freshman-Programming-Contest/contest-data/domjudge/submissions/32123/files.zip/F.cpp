#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
typedef unsigned long long ull;
const int N=2e5+10;
const int mod=1e9+7;

struct node{
	int v,w;
};
vector<node> e[N];
int a[N],son[N],k;

int dfs(int x,int fa)
{
	for(auto it:e[x])
		if((it.v)!=fa)
		{
			a[it.v]=a[x]^it.w;
			son[x]+=dfs(it.v,x);
		}
	return son[x]+1;
}

void dfs2(int x,int fa)
{
	int v;
	for(auto it:e[x])
	{
		v=it.v;
		if(v==fa)
			continue;
		if(son[v]%2==0)
			k^=(it.w);
		dfs2(v,x);
	}
}

void run()
{
	int n,q,u,v,w,x,r,ans=0;
	
	cin >> n;
	for(int i=1;i<n;i++)
	{
		cin >> u >> v >> w;
		e[u].push_back({v,w});
		e[v].push_back({u,w});
	}
	
	dfs(1,0);
	dfs2(1,0);
//	cout << "k=" << k << endl;
	cin >> q;
	while(q--)
	{
		cin >> u >> x;
		if(u!=1)
			r=x^a[u];
//		cout << "r=" << r << endl;
		if(n%2==0)
			cout << k;
		else
			cout << (r^k);
		cout << endl;
	}
}

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

