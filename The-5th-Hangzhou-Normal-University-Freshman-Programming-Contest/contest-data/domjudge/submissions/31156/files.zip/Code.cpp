#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 2e5+7,inf = 1e18+7;
typedef long long ll;

int a[N],b[N],d[N];

void solve(){
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
	}
	for (int i = 1; i <= n; i++){
		cin >> b[i];
	}
	sort(a + 1,a + 1 + n);
	sort(b + 1,b + 1 + n);
	int val1 = inf,ans = inf;
	for (int i = 1; i <= n; i++){
		if (i == 1){
			val1 = b[i] - a[i];
		}else{
			int tmp = b[i] - a[i];
			if (tmp != val1){
				val1 = inf;
				break;
			}
		}
	}
	for (int i = 1; i <= n; i++){
		a[i] = -a[i];
	}
	sort(a + 1,a + 1 + n);
	int val2 = inf;
	bool f = true;
	for (int i = 1; i <= n; i++){
		if (i == 1){
			val2 = b[i] - a[i];
		}else{
			int tmp = b[i] - a[i];
			if (tmp != val2){
				f = false;
				val2 = inf;
				break;
			}
		}
	}
	if (f) val2++;
	if (val1 < 0) val1 = -val1;
	if (val2 < 0) val2 = -val2;
	ans = min(val1,val2);
	if (ans == inf){
		ans = -1;
	}
	cout << ans << '\n';	
}

signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc = 1;
//	cin >> tc;
	while (tc--){
		solve();
	}
	return 0;
}
