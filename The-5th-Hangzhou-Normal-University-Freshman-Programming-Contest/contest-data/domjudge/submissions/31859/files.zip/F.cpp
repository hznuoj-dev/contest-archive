#include<bits/stdc++.h>

using namespace std;

const int N = 200005;

#define ll long long

vector<pair<ll,ll> > e[N];

ll son[N];
ll dp[N];
ll f[N],fw[N];

void dfs(int now,int fa){
	f[now] = fa;
	son[now] = 1;
	for(int i=0;i<e[now].size();++i){
		int to = e[now][i].first;
		ll w = e[now][i].second;
		if(to == fa){
			continue;
		}
		fw[to] = w;
		dfs(to,now);
		son[now] += son[to];
		dp[now] ^= dp[to];
		if(son[to]%2){
			dp[now] ^= w;
		}
	}
}

ll n;
void solve(){
	cin>>n;
	ll u,v,w;
	for(int i=1;i<n;++i){
		cin>>u>>v>>w;
		e[u].push_back(make_pair(v,w));
		e[v].push_back(make_pair(u,w));
	}
	
	dfs(1,0);
	
	int q;
	cin>>q;
	for(int i=1;i<=q;++i){
		cin>>u>>w;
		ll ans = 0;
		if(n%2) ans ^= w;
		ans ^= dp[1];
		if(f[u] != 0){
//			ll nowfa = dp[f[u]] ^ dp[u];
//			ans ^= nowfa;
			if((n-son[u])%2){
				ans ^= fw[u];
			}
		}
		cout<<ans<<'\n';
	}

}

/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5
*/

int main(){
	cin.sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
