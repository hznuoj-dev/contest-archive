#include <iostream>
#include <bits/stdc++.h>
using namespace std;
#define int long long int
const int N = 1e6 + 10;
int a[N], n, b[N];

signed main()
{
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &a[i]);
	}
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &b[i]);
	}
	sort(a, a + n);
	sort(b, b + n);
	int flag1 = 1, flag2 = 1;
	int ans = -1;
	int a1 = a[0] - b[0], b1 = a[0] + b[0];
	for (int i = 0; i < n; i++)
	{
		if (flag1 && a[i] - b[i] != a1)
		{
			flag1 = 0;
		}
		else if (flag2 && a[i] + b[i] != b1)
		{
			flag2 = 0;
		}
	}
	if (flag1)
	{
		ans = abs(a1);
	}
	if (flag2)
	{
		ans = abs(b1) + 1;
	}
	if (flag1 && flag2)
	{
		ans = min(abs(a1), abs(b1) + 1);
	}
	cout << ans << endl;
	return 0;
}

