#include <bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
#define rep(a, b, c) for(int (a)=(b);(a)<=(c);(a)++)
#define per(a, b, c) for(int (a)=(b);(a)>=(c);(a)--)
#define mset(var, val) memset(var,val,sizeof(var))
#define ll long long
#define int ll
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pb push_back
#define endl "\n"
#define pii pair<int,int>
#define pll pair<ll,ll>
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 2e5 + 5;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-8;
const double pi = acos(-1.0);

vector<pii>G[N];

int vis[N],d[N];

void dfs(int u,int w){
	if(vis[u]){
		return;
	}
	vis[u]=1;
	for(int i=0;i<G[u].size();i++){
		int to=G[u][i].fi;
		int tw=G[u][i].se;
		if(!vis[to]){
			d[to]=w^tw;
			dfs(to,w^tw);
		}
	}
}

void solve() {
    int n;
    cin>>n;
    rep(i,1,n-1){
    	int u,v,w;
    	cin>>u>>v>>w;
    	G[u].pb({v,w});
    	G[v].pb({u,w});
//    	d[u]++,d[v]++;
	}
	dfs(1,0);
	int all=0;
	rep(i,2,n){
		all^=d[i];
	}
	int q;
	cin>>q;
	while(q--){
		int u,x,ans=0;
		cin>>u>>x;
		if(n&1){
			ans=x;
			ans^=d[u];
		}
		ans^=all;
		cout<<ans<<endl;
	}
}
/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5
*/

signed main() {
    IOS;
    int t = 1;
    // cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
