#include <bits/stdc++.h>
#define fp(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fb(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define go(u, i) for(int i = head[u]; i; i = e[i].nxt)
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
inline int rd() {
	register int x(0), f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline LL RD() {
	register LL x(0); register int f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline int int_rand(int l, int r){
	int res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
inline LL LL_rand(LL l, LL r){
	LL res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
const int maxn = 200010, inf = INT_MAX-10;
int n, a[maxn], b[maxn], ans;
inline int slv(){
	int dt = a[1]-b[1];
	fp(i, 2, n)if(a[i]-b[i] != dt)return inf;
	return abs(dt);
}
int main(){
//	freopen("a.in", "r", stdin);
//	freopen("a.out", "w", stdout);
	n = rd();
	fp(i, 1, n)a[i] = rd();
	fp(i, 1, n)b[i] = rd();
	sort(a+1, a+1+n), sort(b+1, b+1+n);
	ans = slv(), reverse(a+1, a+1+n);
	fp(i, 1, n)a[i] = -a[i];
	ans = min(ans, slv()+1);
	printf("%d\n", ans == inf ? -1 : ans);
	return 0;
}
