#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
typedef long long ll;
ll a[N];
int main()
{
	ll n,m,b;
	cin>>n>>m>>b;
	for(ll i=1;i<=n;i++) cin>>a[i];
	ll sum=0;
	ll ans=0;
	ll t=0;
	for(ll i=1;i<=n;i++)
	{
		t++;
		sum+=a[i];
		if(sum>=b&&t>=m)
		{
			t=0;
			ans+=b;
			sum-=b;
		}
		else if(t>=m&&i==n)
		{
			ans+=sum;
		}
		else if(i==1)
		{
			if(a[i]>=b)
			{
				t=0;
				ans+=b;
				sum-=b;
			}
			else
			{
				t=0;
				ans+=a[i];
				sum=0;
			}
		}
	}
	cout<<ans<<endl;
	return 0;
}
