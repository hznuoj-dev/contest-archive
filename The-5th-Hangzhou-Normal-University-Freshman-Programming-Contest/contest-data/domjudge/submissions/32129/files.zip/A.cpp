#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;

long long a[maxn],b[maxn];
int main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b+1,b+n+1);
	if(n%2){
		cout<<1;
	}
	else {
		int l=b[n/2],r=b[n/2+1];
		if (l==r)cout<<1;
		else {
			cout<<r-l-1;
		}
	}
}