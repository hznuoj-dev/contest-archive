#include<bits/stdc++.h>
using namespace std;
int a[200005];
int main(){
	int n;
	scanf("%d",&n);
	int l=0,r=0;
	int ansl=0,ansr=200005;
	for(int i=0;i<n;i++)scanf("%d",&a[i]);
	a[n]=-1;
	for(int i=0;i<=n;i++){
		
		if(i!=0){
			if(a[i]>=a[i-1]){
				r++;
			}else{
				if((r-l+1)%2){
					int temp=a[(l+r)/2];
					if(temp>ansr||temp<ansl){
						puts("0");
						return 0;
					}
					ansr=temp+1,ansl=temp-1;
				}else{
					int t1=a[(l+r)/2],t2=a[(l+r)/2+1];
					
					if(t1>ansr||t2<ansl){
						puts("0");
						return 0;
					}
					if(t1==t2){
						ansl=t1-1,ansr=t1+1;
					}
					else {
						
						ansl=max(ansl,t1);
						ansr=min(ansr,t2);
					}
				}
				
				l=i,r=i;
				
			}
		}
		
	}
	printf("%d\n",ansr-ansl-1);
}
