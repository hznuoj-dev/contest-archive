#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=1000005;
int kt1[M],kt2[M],r1[M],r2[M];
int main()
{
	bool flag1=true,flag2=true;
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&kt1[i]);
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%d",&kt2[i]);
	}
	sort(kt1+1,kt1+n+1);
	sort(kt2+1,kt2+n+1);
	for(int i=2;i<=n;i++)
	{
		r1[i]=kt1[i]-kt1[i-1];
		r2[i]=kt2[i]-kt2[i-1];
	}
	for(int i=2;i<=n;i++)
	{
		if(r1[i]!=r2[i])
		{
			flag1=false;
		}
		if(r1[i]+r2[i]!=0)
		{
			flag2=false;
		}
	}
	if(!flag1&&!flag2)
	{
		printf("-1");
		return 0;
	}
	if(flag1&&flag2)
	{
		printf("%d",min(abs(kt2[1]-kt1[1]),abs(kt2[1]+kt1[1])+1));
	}
	else if(flag1)
	{
		printf("%d",abs(kt2[1]-kt1[1]));
	}
	else
	{
		printf("%d",abs(kt2[1]+kt1[1])+1);
	}
	return 0;
}