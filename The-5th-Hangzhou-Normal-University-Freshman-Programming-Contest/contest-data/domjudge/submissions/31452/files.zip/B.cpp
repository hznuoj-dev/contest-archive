#include<bits/stdc++.h>
#define ll long long
#define PII pair<int,int>
//  #define int long long
using namespace std;
constexpr ll mod=1e9+7; 
const ll inf=0x3f3f3f3f;  
const ll INF=0x3f3f3f3f3f3f3f3f;  
const double eps=1e-10;  
const int N=2e5+10;
// struct node{
//     friend bool operator<(const node&a,const node&b){
//         return ;
//     }
// }
//priority_queue<ll,vector<ll>,greater<ll>>pq;
inline int read(){int x=0,f=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}return x*f;}
inline void write(int x){char F[200];int tmp=x>0?x:-x;if(x<0) putchar('-');int cnt=0;while(tmp>0){F[cnt++]=tmp%10+'0';tmp/=10;}while(cnt>0)putchar(F[--cnt]);}
inline int combination(int n,int k){int sum=0;if (n==k||k==0){return 1;}else{return combination(n-1,k)+combination(n-1,k-1);}}
int a[N],b[N],c[N],d[N],e[N];
bool cmp(int a,int b){
    if(a>b)return true;
    else return false;
}
void solve(){
    int n=read(),ans=inf;
    for(int i=1;i<=n;i++){
        a[i]=read();
    }
    for(int i=1;i<=n;i++){
        b[i]=read();
        c[i]=b[i];
    }
    sort(a+1,a+1+n);
    sort(b+1,b+1+n);
    sort(c+1,c+1+n,cmp);
    for(int i=1;i<=n;i++){
        d[i]=b[i]-a[i];
        e[i]=b[i]-a[i];
    }
    sort(d+1,d+1+n);
    sort(e+1,e+1+n);
    if(d[1]==d[n])ans=min(ans,abs(d[1]));
    if(e[1]==e[n])ans=min(ans,abs(e[1]));
    for(int i=1;i<=n;i++){
        a[i]=0-a[i];
    }
    sort(a+1,a+1+n);
    for(int i=1;i<=n;i++){
        d[i]=b[i]-a[i];
        e[i]=b[i]-a[i];
    }
    sort(d+1,d+1+n);
    sort(e+1,e+1+n);
    if(d[1]==d[n])ans=min(ans,abs(d[1])+1);
    if(e[1]==e[n])ans=min(ans,abs(e[1])+1);
    if(ans!=inf)cout<<ans<<'\n';
    else cout<<-1<<'\n';
    //puts(ans>0?"YES":"NO");
    //puts(ans>0?"Yes":"No");
}

signed main(){
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    // cout.tie(0);
    int t=1;
  //  int t=read();
    while(t--){
        solve();
    }
}