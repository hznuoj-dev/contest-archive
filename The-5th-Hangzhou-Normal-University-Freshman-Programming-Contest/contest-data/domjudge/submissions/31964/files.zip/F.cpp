#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=2000005;
struct node{
	int v,w,lst;
}t[M];
int head[M],tot=0,wt[M],ft[M],ans=0;
void add(int u,int v,int w){
	t[++tot].v=v;
	t[tot].lst=head[u];
	t[tot].w=w;
	head[u]=tot;
}
bool dfs(int u,int f){
	int v;
	for(int i=head[u];i;i=t[i].lst)
	{
		v=t[i].v;
		if(v==f) continue;
		if(dfs(v,u)) ft[u]++,ans=(ans^t[i].w);
	}
	if(ft[u]%2==0) return true;
	else return false;
}
void dfs2(int u,int f){
	int v;
	for(int i=head[u];i;i=t[i].lst)
	{
		v=t[i].v;
		if(v==f) continue;
		wt[v]=(wt[u]^t[i].w);
		dfs2(u,f);
	}
	return ;
}
int main()
{
	int n,m,b,u,v,w,q,ts,id;
	scanf("%d",&n);
	for(int i=1;i<=n-1;i++)
	{
		scanf("%d%d%d",&u,&v,&w);
		add(u,v,w);
		add(v,u,w);
	}
	scanf("%d",&q);
	bool flag=false;
	if(dfs(1,0)) flag=true;
	if(!flag)
	{
		for(int i=1;i<=q;i++)
		{
			scanf("%d%d",&id,&ts);
			printf("%d\n",ans);
		}
		return 0;
	}
	else
	{
		dfs2(1,0);
		for(int i=1;i<=q;i++)
		{
			scanf("%d%d",&id,&ts);
			printf("%d\n",ans^wt[id]^ts);
		}
	}
	return 0;
}