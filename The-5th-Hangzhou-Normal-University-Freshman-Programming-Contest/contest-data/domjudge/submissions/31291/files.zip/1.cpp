#include<bits/stdc++.h>
using namespace std;
const int N=4e5+5;
int n,a[N],b[N],ans;
bool judge(int x)
{
	int sum=0;
	for(int i=1;i<=n;++i)
	{
		if(a[i]<x)sum++;
		else if(a[i]>x)sum--;
		if(sum<0)return 0;
	}
	if(sum)return 0;
	return 1;
}
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]),b[i]=a[i];
	sort(b+1,b+n+1);
	int k=b[(n+1)/2];
	if(judge(k))ans=1;
	if(judge(k-1))
	{
		for(int i=(n+1)/2;i;--i)
		{
			if(b[i]!=k)
			{
				ans+=k-b[i]-1;
				break;
			}
		}
	}
	if(judge(k+1))
	{
		for(int i=(n+1)/2;i<=n;++i)
		{
			if(b[i]!=k)
			{
				ans+=b[i]-k-1;
				break;
			}
		}
	}
	printf("%d\n",ans);
	return 0;
}
