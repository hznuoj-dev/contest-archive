#include <bits/stdc++.h>
#define maxn 200100
#define int long long
using namespace std;
map<pair<int,int>,int>e;
vector<int>edge[maxn];
unordered_map<int,int>num,pos;
unordered_map<int,bool>vis,vis_;
int ans=0,tmp=0,n,ans1=0;
int check(int x,int y){
	vis[x]=true;
	int res=0;
	for(auto u:edge[x]){
		if(u==y)  return res=res^e[{x,y}];
		else if(vis[u])  continue;
		else res=res^e[{x,u}]^check(u,y);
	}
	return res;
}
void clean1(){
	queue<int>ppp;
	for(int i=1;i<=n;++i){
		if(num[i]==0)  ppp.push(i);
	}
	while(ppp.size()){
		int x=ppp.front();
		ppp.pop();
		int y=ppp.front();
		ppp.pop();
		ans=ans^check(x,y);
	}
}
int check1(int x,int y){
	vis_[x]=true;
	int res=0;
	for(auto u:edge[x]){
		if(u==y)  return res=res^e[{x,y}];
		else if(vis_[u])  continue;
		else res=res^e[{x,u}]^check1(u,y);
	}
	return res;
}
void clean2(){
	queue<int>ppp;
	for(int i=1;i<=n;++i){
		if(pos[i]==0)  ppp.push(i);
	}
	while(ppp.size()){
		int x=ppp.front();
		ppp.pop();
		int y=ppp.front();
		ppp.pop();
		ans1=ans1^check1(x,y);
	}
}
void solve(){
	pos.clear();
	int x,y;
	cin >> x >> y;
	ans1=y;
	pos[x]++;
	for(auto u:e){
		ans1=ans1^u.second;
		pos[u.first.first]++,pos[u.first.second]++;
		pos[u.first.first]%=2,pos[u.first.second]%=2;
	}
	for(auto u:e){
		if(pos[u.first.first]==0&&pos[u.first.second]==0){
			pos[u.first.first]++,pos[u.first.second]++;
			pos[u.first.first]%=2,pos[u.first.second]%=2;
			ans1=ans1^u.second;
		}
	}
	clean2();
	cout << ans1 << '\n';
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int q;  cin >> n;
	for(int i=1;i<n;++i){
		int u,v,w;
		cin >> u >> v >> w;
		edge[u].push_back(v);
		edge[v].push_back(u);
		e[{u,v}]=w;
		e[{v,u}]=w;
	}
	for(auto u:e){
		if(num[u.first.first]==0&&num[u.first.second]==0){
			ans=ans^u.second;
			num[u.first.first]++,num[u.first.second]++;
			num[u.first.first]%=2,num[u.first.second]%=2;
		}
	}
	if(n%2==0)  clean1();
	cin >> q;
	while(q--){
		if(n%2==0){
			int x,y;
			cin >> x >> y;
			cout << ans << '\n';
		}
		else  solve();
	}
    return 0;
}