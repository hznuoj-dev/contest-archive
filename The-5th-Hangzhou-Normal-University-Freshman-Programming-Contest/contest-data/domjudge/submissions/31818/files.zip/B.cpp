#include<cstdio>
#include<algorithm>
using namespace std;
template<class type>inline const void read(type &in)
{
    in=0;char ch(getchar());bool f(0);
    while (ch<48||ch>57)f|=ch=='-',ch=getchar();
    while (ch>47&&ch<58)in=(in<<3)+(in<<1)+(ch&15),ch=getchar();
    if (f)in=-in;
}
const int N(2e5+5);
int n,a[N],b[N],ans;
int main()
{
    read(n);
    for (int i(1);i<=n;i++)read(a[i]);
    for (int i(1);i<=n;i++)read(b[i]);
    sort(a+1,a+n+1);sort(b+1,b+n+1);
    bool flag1(0),flag2(0);
    for (int i(2);i<=n;i++)
        if (b[i]-a[i]!=b[i-1]-a[i-1])
            {flag1=1;break;}
    if (!flag1)ans=abs(b[1]-a[1]);
    for (int i(1);i<=n;i++)a[i]*=-1;
    sort(a+1,a+n+1);
    for (int i(2);i<=n;i++)
        if (b[i]-a[i]!=b[i-1]-a[i-1])
            {flag2=1;break;}
    if (flag1&&flag2)return puts("-1"),0;
    if (!flag2)ans=min(ans,abs(b[1]-a[1])+1);
    printf("%d\n",ans);
    return 0;
}