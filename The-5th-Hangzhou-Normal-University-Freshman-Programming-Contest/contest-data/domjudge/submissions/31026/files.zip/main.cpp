
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
const int N=2e5+10;
const int inf=1<<30;
int a[N],n,b[N];
int cal(int* c){
    int i;
    rep(i,1,n-1)if(c[i+1]-c[i]!=b[i+1]-b[i])return inf;
    return abs(c[1]-b[1]);
}
int main(){
    scanf("%d",&n);int i;
    rep(i,1,n)scanf("%d",&a[i]);
    rep(i,1,n)scanf("%d",&b[i]);sort(b+1,b+1+n);
    sort(a+1,a+1+n);
    int ans=cal(a);
    reverse(a+1,a+1+n);
    ans=min(ans,cal(a));
    if(ans<inf)printf("%d",ans);else printf("-1");
}