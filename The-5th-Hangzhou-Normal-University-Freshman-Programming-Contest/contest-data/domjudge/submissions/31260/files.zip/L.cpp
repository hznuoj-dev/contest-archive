#include <iostream>
#include <algorithm>

using namespace std;

const int N = 6;

int a[N], b[N];
int m, k;

int main()
{
    cin >> m >> k;
    double maxx = 0;
    double c;
    for (int i = 0; i < 5; i ++ ) cin >> a[i];
    for (int i = 0; i < 5; i ++ ) cin >> b[i];
    for (int i = 0; i < 5; i ++ )
    {
        if (a[i] >= m)
        {
            c = b[i] / (a[i] - k);
        }
        else c = b[i] / a[i];
        maxx = max(maxx, c);
    }
    for (int i = 0; i < 5; i ++ )
    {
        for (int j = i + 1; j < 5; j ++ )
        {
            if (a[i] + a[j] >= m)
            {
                c = (b[i] + b[j]) / (a[i] + a[j] - k);
            }
            else c = (b[i] + b[j]) / (a[i] + a[j]);
            maxx = max(maxx, c);
        }
    }
    for (int i = 0; i < 5; i ++ )
    {
        for (int j = i + 1; j < 5; j ++ )
        {
            for (int z = j + 1; z < 5; z ++ )
            {
                if (a[i] + a[j] + a[z] >= m)
                    c = (b[i] + b[j] + b[z]) / (a[i] + a[j] + a[z] - k);
                else c = (b[i] + b[j] + b[z]) / (a[i] + a[j] + a[z]);
                maxx = max(maxx, c);
            }
        }
    }
    double suma = 0, sumb = 0;
    for (int i = 0; i < 5; i ++ )
    {
        for (int j = 0; j < 5; j ++ )
        {
            if (j != i)
            {
                suma += a[j];
                sumb += b[j];
            }
        }
        if (suma >= m) suma -= k;
        c = sumb / suma;
        maxx = max(maxx, c);
    }
    suma = 0, sumb = 0;
    for (int i = 0; i < 5; i ++ )
    {
        suma += a[i];
        sumb += b[i];
    }
    if (suma >= m) suma -= k;
    c = sumb / suma;
    maxx = max(maxx, c);
    printf("%.2lf", maxx);
    return 0;
}