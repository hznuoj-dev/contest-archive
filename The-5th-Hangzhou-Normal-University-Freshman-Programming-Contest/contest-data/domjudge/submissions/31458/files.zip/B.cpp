#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=200005;
ll ans1,ans2,k1[M],k2[M],k3[M];
int n;
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&k1[i]);
		k3[i]=-k1[i];
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&k2[i]);
	}
	sort(k1+1,k1+n+1);
	sort(k3+1,k3+n+1);
	sort(k2+1,k2+n+1);
	ans1=abs(k2[1]-k1[1]);
	for(int i=1;i<=n-1;i++)
	{
		if(k2[i]-k1[i]!=k2[i+1]-k1[i+1])
		{
			ans1=-1;
			break;
		}
	}
	ans2=abs(k3[1]-k1[1])+1;
	for(int i=1;i<=n-1;i++)
	{
		if(k3[i]-k1[i]!=k3[i+1]-k1[i+1])
		{
			ans2=-1;
			break;
		}
	}
	if(ans1==-1&&ans2==-1) printf("-1");
	else if(ans1==-1) cout<<ans2;
	else if(ans2==-1) cout<<ans1;
	else cout<<min(ans1,ans2);
	return 0;
}