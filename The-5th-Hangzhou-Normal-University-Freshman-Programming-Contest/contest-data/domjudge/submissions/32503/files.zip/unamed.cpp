#include<bits/stdc++.h>
using namespace std;
#define int long long

int q[200010];

void run() {
	int n, m, b;
	cin >> n >> m >> b;
	int res = 0;
	int cur = 0;
	for (int i = 0; i < n; i++) {
		cin >> q[i];
		cur += q[i];
		if (i % m == 0 && i + m < n) {
			res += min(b, cur);
			cur = max(cur - b, 0ll);
		}
	}
	res += min(b, cur);
	cout << res << '\n';
	return;
}

signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int T = 1;
//	cin >> T;
	while (T--) {
		run();
	}
	return 0;
}
