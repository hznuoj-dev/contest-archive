#include<iostream>
using namespace std;
#include<algorithm>
#include<string>
#include<math.h>
#include<vector>
typedef long long ll;
int main()
{
	ll n, sum1 = 0, sum2 = 0, count = 0, flag = 0, sum;
	std::cin >> n;
	std::vector<ll>a(n), b(n);
	for (int i = 0; i < n; i++)
	{
		std::cin >> a[i];
		sum1 += a[i];
	}
	std::sort(a.begin(), a.end());
	for (int i = 0; i < n; i++)
	{
		std::cin >> b[i];
		sum2 += b[i];
	}
	std::sort(b.begin(), b.end());
	sum = b[0] - a[0];
	for (int i = 1; i < n ; i++)
	{
		if ((b[i] - a[i]) != sum)
		{
			flag = 1;
			break;
		}
	}
	if (flag == 1)
	{
		std::cout << -1 << endl;
	}
	else
	{
		if (a[0] * b[0] <= 0)
		{
			count = abs(abs(sum1) - abs(sum2)) / n + 1;
		}
		else
			count = abs(abs(sum1) - abs(sum2)) / n;
		std::cout << count << endl;
	}
}
