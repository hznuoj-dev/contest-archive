
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
const int N=2e5+10;
#define LL long long
int n,m,cnt;
LL b,a[N],s[N],f[N];
vector<LL>t[N];
int main(){
    scanf("%d%d%lld",&n,&m,&b);int i,j;
    rep(i,1,n)scanf("%lld",&a[i]);rep(i,1,n)s[i]=s[i-1]+a[i];
    LL mx=0;
    rep(i,1,n){
        f[i]=min(s[i],b);
        for(auto v:t[i]){
            mx=max(mx,v);--cnt;
        }
        LL tmp=0;
        if(cnt)tmp=s[i];
        tmp=max(tmp,mx);
        f[i]=max(f[i],tmp);
        if(i-m+1>=1){
            int l,r,res=-1;l=i+1;r=n;
            while(l<=r){
                int mid=l+r>>1;
                if(f[i-m+1]+b<=s[mid])res=mid,r=mid-1;else l=mid+1;
            }
            ++cnt;
            if(res>0){
                t[res].push_back(f[i-m+1]+b);
            }
        }
    }
    LL ans=0;
    rep(i,1,n)ans=max(ans,f[i]);
    printf("%lld",ans);
}