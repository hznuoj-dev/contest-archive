#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5,mod=1e9+7;
vector<int>g[maxn];
bool vis[maxn];
int cnt[maxn];
int d[maxn];
int du[maxn];
int qmi(int a,int b){
	int res=1;
	while(b){
		if(b&1)res=res*a%mod;
		b>>=1;
		a=a*a%mod;
	}
	return res;
}
priority_queue<pair<int,int>>q;
void bfs(){
	while(!q.empty()){
		int u=q.top().second;
		q.pop();
		if(vis[u])continue;
		vis[u]=1;
		//cout<<u<<' '<<d[u]<<'\n';
		for(auto v:g[u]){
			if(d[v]<d[u]+1){
				d[v]=d[u]+1;
				q.push({d[v],v});
			}
		}
	}
	return ;
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int n,m,k;cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		int u,v;cin>>u>>v;
		g[u].push_back(v);
		du[v]++;
	}//������������ֵ����С��
	for(int i=1;i<=n;i++){
		if(du[i]==0){
			q.push({0,i});
		}
	}
	bfs();
	for(int i=1;i<=n;i++)cnt[d[i]]++;
	for(int i=1;i<=n;i++)cnt[i]+=cnt[i-1];
	int ans=0;
	for(int i=1;i<=n;i++){
		ans+=cnt[d[i]-1];
		ans%=mod;
	}
//	for(int i=1;i<=n;i++)cout<<d[i]<<' ';
//	cout<<'\n';
	ans=qmi(ans,k);
	cout<<ans;
	return 0;
}
/*
3 3 3
1 3
3 2
1 2

3 8 0
2 3
2 1
2 3
3 1
2 1
2 1
2 3
3 1

4 7 2
1 2
1 4
2 3
1 4
1 3
1 2
4 3

3 3 3
1 2
2 3
1 2
*/
