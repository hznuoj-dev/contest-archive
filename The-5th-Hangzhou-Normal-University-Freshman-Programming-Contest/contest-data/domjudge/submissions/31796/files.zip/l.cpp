#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int m,k;
struct node
{
	double a;
	double b;
}seg[222];
int main()
{
	scanf("%d %d",&m,&k);
	for(int i=1;i<=5;i++) scanf("%lf",&seg[i].a);
	for(int i=1;i<=5;i++) scanf("%lf",&seg[i].b);
	double max=0,x;
	for(int i=1;i<=5;i++) 
	{
		if(seg[i].a>=m) x=(double)seg[i].b/(seg[i].a-k)*1.0;
	    else x=(double)seg[i].b/seg[i].a*1.0;
	    if(x>max) max=x;
    }//5
    double bb=seg[1].b+seg[2].b+seg[3].b+seg[4].b+seg[5].b;
    double aa=seg[1].a+seg[2].a+seg[3].a+seg[4].a+seg[5].a;
    if(aa>=m)//1
    {
    	if((bb/(aa-k))>max) max=bb/(aa-k);
	}
	else 
	{
		if((bb/aa)>max) max=bb/aa;
	}
    for(int i=1;i<=5;i++)//5
    {
    	if((aa-seg[i].a)>=m)
    	{
    		if((bb-seg[i].b)/(aa-seg[i].a-k)>max) max=(bb-seg[i].b)/(aa-seg[i].a-k);
		}
		else 
		{
			if((bb-seg[i].b)/(aa-seg[i].a)>max) max=(bb-seg[i].b)/(aa-seg[i].a);
		}
	}
	for(int i=1;i<5;i++)
	{
		for(int j=i+1;j<=5;j++)
		{
			if((aa-seg[i].a-seg[j].a)>=m)
	    	{
	    		if((bb-seg[i].b-seg[j].b)/(aa-seg[i].a-k-seg[j].a)>max) max=(bb-seg[i].b-seg[j].b)/(aa-seg[i].a-k-seg[j].a);
			}
			else 
			{
				if((bb-seg[i].b-seg[j].b)/(aa-seg[i].a-seg[j].a)>max) max=(bb-seg[i].b-seg[j].b)/(aa-seg[i].a-seg[j].a);
			}
		}
	}
	for(int i=1;i<5;i++)
	{
		for(int j=i+1;j<=5;j++)
		{
			if((seg[i].a+seg[j].a)>=m)
	    	{
	    		if((seg[i].b+seg[j].b)/(seg[i].a-k+seg[j].a)>max) max=(seg[i].b+seg[j].b)/(seg[i].a-k+seg[j].a);
			}
			else 
			{
				if((seg[i].b+seg[j].b)/(seg[i].a+seg[j].a)>max) max=(seg[i].b+seg[j].b)/(seg[i].a+seg[j].a);
			}
		}
	}
	printf("%.2f\n",max);
	return 0;
}
