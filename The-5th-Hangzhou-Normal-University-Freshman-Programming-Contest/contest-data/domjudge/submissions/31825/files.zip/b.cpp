#include<bits/stdc++.h>
using namespace std;
int main(){
	double a[5],b[5];
    double c[5];
int m,k;
double sum=0;
int qd=0;
cin>>m>>k;
for(int i=0;i<5;i++)
cin>>a[i];
for(int i=0;i<5;i++)
cin>>b[i];
for(int i=0;i<5;i++)
c[i]=b[i]/a[i];
double xjb=0;
double s=0;
 for(int i=0;i<5;i++){
 	double max=0;
 	int n=0;
 	for(int j=0;j<5;j++){  	 
	  		if(c[j]>max){
	  			max=c[j];
				  n=a[j]; 
			  }
		 
		 if(c[j]==max){
		 	if(a[j]>n)
		 	max=c[j];
		 	n=a[j];
		 }
	 }
	 for(int j=0;j<5;j++){
	 	if(c[j]==max&&n==a[j]){
	 		qd+=b[j];
	 		sum+=a[j];
	 		c[j]=-1;
		 }
	 }
	 if(sum>=m)
	 s=qd/(sum-k);
	 else
	 s=qd/sum; 
	 if(s>xjb)
	 xjb=s;
 }
 printf("%.2lf",xjb);
	return 0;
} 
