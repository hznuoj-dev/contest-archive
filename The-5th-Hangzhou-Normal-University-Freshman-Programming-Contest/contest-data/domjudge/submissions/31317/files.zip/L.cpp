#include <bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
#define rep(a, b, c) for(int (a)=(b);(a)<=(c);(a)++)
#define per(a, b, c) for(int (a)=(b);(a)>=(c);(a)--)
#define mset(var, val) memset(var,val,sizeof(var))
#define ll long long
#define int ll
#define itn int
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pb push_back
#define endl "\n"
#define pii pair<int,int>
#define pll pair<ll,ll>
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 2e5 + 5;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-8;
const double pi = acos(-1.0);

int a[10],b[10];

void solve() {
    int m,k;
	cin>>m>>k;
	rep(i,1,5){
		cin>>a[i];
	}
	rep(i,1,5){
		cin>>b[i];
	}
	double ans=0;
	rep(i,1,31){
		int up=0,down=0;
		rep(j,0,4){
			if(i&(1<<j)){
				up+=b[j+1],down+=a[j+1];
			}
		}
		down-=down/m*k;
//		if(down>=m){
//			down-=k;
//		}
		ans=max(ans,up*1.0/down);
	}
	printf("%.2f\n",ans);
}

/*
5 3
1 2 4 4 2
2 2 1 2 4
*/

signed main() {
    IOS;
    int t = 1;
    // cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
