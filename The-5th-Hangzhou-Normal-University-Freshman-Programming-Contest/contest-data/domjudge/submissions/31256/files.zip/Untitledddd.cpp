#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
//#define int long long 
const int inf=0x3f3f3f3f;
const int N=1e6+10;
int a[N],b[N];
	int n;
bool check(int x)
{
	stack<int>st;
	for(int i=1;i<=n;i++) 
	{
		if(a[i]<x) st.push('(');
		else if(a[i]>x) 
		{
			if(st.size()) st.pop();
			else 
			{
				return false;
			}
		}	
 	}
 	if(st.size()==0) return true;
 	else return false;
}

int main()
{
	Acode;
	cin>>n;
	int ans=0;
	for(int i=1;i<=n;i++) 
	{
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b+1,b+1+n); 
	int l=b[n/2];
	int r=b[(n/2)+1];
	for(int i=l;i<=r;i++)
	{
		if(check(i))
		{
			ans++;
			//cout<<i<<endl;
		}
		
	}
	cout<<ans<<endl;	
	
	
	return 0;
}

