#include<iostream>
#include<algorithm>
using namespace std;
#define int long long
const int N = 2e5 + 5;
int n, m, b, a[N], sum[N], ans;
signed main()
{
	cin >> n >> m >> b;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		sum[i] = sum[i - 1] + a[i];
	}
	int c = 0, t = -m;
	for (int i = 1; i <= n; i++)
	{
		c += a[i];
		if (i - t >= m)
		{
			if (c >= b)
				c -= b, ans += b, t = i;
			else if ((sum[i + m] - sum[i]) >= b)
				ans += c, c = 0, t = i;
			else if (i == n)
				ans += c, c = 0, t = n;
		}
	}
	cout << ans << endl;
	return 0;
}
