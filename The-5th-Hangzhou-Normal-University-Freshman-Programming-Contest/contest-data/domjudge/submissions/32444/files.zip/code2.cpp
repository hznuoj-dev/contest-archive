#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IO ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
typedef pair<int,int> pii;
const int N = 2e5 + 5;
int n, q, par[N][25], dep[N], val[N][25], ans = 0;
bool ct[N];
vector<pii>vec[N];

void predfs(int u,int fa){
    dep[u] = dep[fa] + 1;
    par[u][0] = fa;
    for(int i = 1;i < 25;i++){
        par[u][i] = par[par[u][i-1]][i-1];
        val[u][i] = val[u][i-1] ^ val[par[u][i-1]][i-1];
    }
    for(auto way : vec[u]) if(way.first != fa){
        val[way.first][0] = way.second;
        predfs(way.first, u);
    }
}

void dfs(int u,int fa, int w){
    for(auto way : vec[u]) if(way.first != fa){
        dfs(way.first, u, way.second);
    }
    if(u == 1) return;
    // cout << u << ' ' << w;
    ans ^= w;
    ct[u] = !ct[u];
    ct[fa] = !ct[fa];
    if(!ct[u]){
        // cout << ' ' << w;
        ans ^= w;
        ct[u] = !ct[u];
        ct[fa] = !ct[fa];
    }
    // cout << '\n';
}

signed main(){
    IO;
    cin >> n;
    for(int i = 1, u,v,w;i < n;i++){
        cin >> u >> v >> w;
        vec[u].push_back({v,w});
        vec[v].push_back({u,w});
    }

    predfs(1, 0);
    dfs(1,0, 0);

    int f = 0;
    if(!ct[1]) f = 1;

    int u,x;
    cin >> q;
    // cout << "____________\n";
    while(q--){
        cin >> u >> x;
        if(f) cout << (ans ^ val[u][24] ^ x) << '\n';
        else cout << ans << '\n';
    }
    // cout << ans << ' ' << f;

    return 0;
}