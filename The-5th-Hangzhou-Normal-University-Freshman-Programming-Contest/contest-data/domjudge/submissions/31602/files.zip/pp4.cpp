#define _CRT_SECURE_NO_WARNINGS 1
#include<iostream>
#include<algorithm>
using namespace std;
const int N = 210;
int m, k;
int a[N];
int b[N];
int sum1;
int pus1;
int cot;
double val;
int main()
{
    cin >> m >> k;
    for (int i = 1; i <= 5; i++)
    {
      cin >> a[i];
    }
    for (int i = 1; i <= 5; i++)
        cin >> b[i];
    for (int i = 1; i <= 5; i++)
    {
        int sum = a[i];
        int pul = b[i];
        if (sum >= m)sum -= k;
        if (pul * 1.0 / sum > val)val = pul * 1.0 / sum;
    }
    for (int i = 1; i <= 5; i++)
    {
        for (int j = i+1; j <= 5; j++)
        {
            int sum = a[i]+a[j];
            int pul = b[i]+b[j];
            if (sum >= m)sum -= k;
            if (pul * 1.0 / sum > val)val = pul * 1.0 / sum;
        }
    }
    for (int i = 1; i <= 5; i++)
    {
        for (int j = i+1; j <= 5; j++)
        {
            for (int t = j + 1; t <= 5; t++)
            {
                int sum = a[i] + a[j]+a[t];
                int pul =b[i] + b[j] + b[t] ;
                if (sum >= m)sum -= k;
                if (pul * 1.0 /sum > val)val = pul * 1.0 / sum;
           }
        }
    }
    for (int i = 1; i <= 5; i++)
    {
        for (int j = i + 1; j <= 5; j++)
        {
            for (int t = j + 1; t <= 5; t++)
            {
                for (int w = t + 1; w <= 5; w++)
                {
                    int sum = a[i] + a[j] + a[t]+a[w];
                    int pul = b[i] + b[j] + b[t]+b[w];
                    if (sum >= m)sum -= k;
                    if (pul * 1.0 / sum > val)val = pul * 1.0 / sum;
                }
            }
        }
    }
    int sum = a[1] + a[2] + a[3] + a[4]+a[5];
    int pul = b[1] + b[2] + b[3] + b[4]+b[5];
    if (sum >= m)sum -= k;
    if (pul * 1.0 / sum > val)val = pul * 1.0 / sum;
    printf("%.2lf", val);
    return 0;
}