#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define ll long long

using namespace std;

const int N = 2e5+5;
ll n,m,b,a[N],dp[N];

int main(){
	IOS
	cin >> n >> m >> b;;
	for(int i=1;i<=n;i++){
		cin >> a[i];
		a[i] = a[i]+a[i-1];
	}
	for(int i=1;i<=m;i++){
		if(a[i]>b)dp[i] = b;
		else dp[i] = a[i];
	}
	for(int i=m+1;i<=n;i++){
		ll t1 = a[i],t2 = a[i]-dp[i-m];
		if(t1>b)t1 = b;
		if(t2>b)t2 = b;
		dp[i] = max(t1,t2+dp[i-m]);
	}
	ll ans;
	for(int i=1;i<=n;i++){
		ans = max(ans, dp[i]);
	}
	cout << ans << endl;
	
	
	
	return 0;
} 
