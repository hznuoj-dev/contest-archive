#define _CRT_SECURE_NO_WARNINGS 1
#include<bits/stdc++.h>
#define ios  ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
typedef long long LL;
const LL MAXN = 2e5+10;
const int Inf = 0x7fffffff;
const LL INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
int n;
int a[MAXN];
int b[MAXN];
int c[MAXN];
string sa,sb,sc;
int ans=0;
bool pd()
{
	for(int i=2;i<=n;++i)
	{
		if(c[i]!=c[1])
			return false;
	}
	if(sa==sb)
	  return true;
	if(sc==sb)
	{
	  ++ans;
	  return true;
	}
	return false;
}
int main()
{
	ios;
	cin>>n;
	
	for(int i=1;i<=n;++i)
	{
		cin>>a[i];
		if(a[i]>=0)
		{
			sa.push_back('1');
			sc.push_back('0');
		}
		else
		{
			sa.push_back('0');
			sc.push_back('1');
		}
	}
	for(int i=1;i<=n;++i)
	{
		cin>>b[i];
		if(b[i]>=0)
			sb.push_back('1');
		else
			sa.push_back('0');
	}
	for(int i=1;i<=n;++i)
		c[i]=abs(abs(b[i])-abs(a[i]));
	if(pd())
	{
		ans+=c[1];
		cout<<ans;
	}
	else
		cout<<-1;
	//system("pause");
	return 0;
}