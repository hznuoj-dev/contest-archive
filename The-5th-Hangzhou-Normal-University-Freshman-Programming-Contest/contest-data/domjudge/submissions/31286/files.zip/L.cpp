#include<bits/stdc++.h>

using namespace std;
#define int long long 
const int N = 6;
int a[N], b[N];
int m, k;

int cal(int p){
	if(p >= m)return p - k;
	else return p;
}

void solve(){
	cin >> m >> k;
	int suma = 0, sumb = 0;
	for(int i = 1; i <= 5; ++ i)cin >> a[i], suma+=a[i];
	for(int i = 1; i <= 5; ++ i)cin >> b[i], sumb+=b[i];
	double ans = 0;
	for(int i = 1; i <= 5; ++ i){
		ans = max(ans, b[i] * 1.0 / cal(a[i]));//1
		ans = max(ans, (sumb - b[i]) * 1.0 / cal(suma - a[i]));//4
	}
	for(int i = 1; i <= 5; ++ i){
		for(int j = i + 1; j <= 5; ++ j){
			ans = max(ans, (b[i] + b[j]) * 1.0 / cal(a[i] + a[j]));//2
			ans = max(ans, (sumb - b[i] - b[j]) * 1.0 / cal(suma - a[i] - a[j]));//3
		}
	}
	ans = max(ans, sumb * 1.0 / cal(suma));
	printf("%.2lf", ans);
	
}

signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	solve();
	return 0;
}
