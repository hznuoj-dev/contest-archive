#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
typedef unsigned long long ull;
const int N=2e5+10;
const int mod=1e12+7;

int a[N],b[N],c[N],d[N];

void run()
{
	int n,k,ans1,ans2,ans;
	
	cin >> n;
	for(int i=1;i<=n;i++)
	{
		cin >> a[i];
		c[i]=a[i];
		d[i]=-a[i];
	}
	for(int i=1;i<=n;i++)
		cin >> b[i];
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	sort(d+1,d+1+n);
	
	ans1=0;
	for(int i=1;i<=n;i++)
		if(i==1)
			k=b[i]-c[i];
		else if(k!=b[i]-c[i])
		{
			ans1=mod;
			break;
		}
	if(ans1!=mod)
		ans1=abs(k);
		
	ans2=0;
	for(int i=1;i<=n;i++)
		if(i==1)
			k=b[i]-d[i];
		else if(k!=b[i]-d[i])
		{
			ans2=mod;
			break;
		}
	if(ans2!=mod)
		ans2=abs(k)+1;
	
//	cout << "#" << ans1 << ' ' << ans2 << endl;
	ans=min(ans1,ans2);
	if(ans==mod)
		cout << -1;
	else
		cout << ans;
}

/*
3
1 2 3
-4 -5 -6
*/

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

