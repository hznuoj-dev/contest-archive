#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn = 2e5 + 9;
ll s[maxn],a[maxn];
ll d[maxn][2];
int n,m;
ll b;
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin >> n >> m >> b;
	for(int i = 1;i <= n;i ++) cin >> a[i];
	for(int i = 1;i <= n;i ++){
		s[i] = s[i - 1] + a[i];
	}
	ll res;
	for(int i = 1;i <= n;i ++){
		d[i][0] = max(d[i - 1][0],d[i - 1][1]);
		res = s[i] - d[max(i - m,0)][0];
		d[i][1] = min(res,b) + d[max(i - m,0)][0];
		res = s[i] - d[max(i - m,0)][1];
		d[i][1] = max(d[i][1],min(res,b) + d[max(i - m,0)][1]);
	}
	cout << max(d[n][1],d[n][0]) << '\n';
	return 0;
}

