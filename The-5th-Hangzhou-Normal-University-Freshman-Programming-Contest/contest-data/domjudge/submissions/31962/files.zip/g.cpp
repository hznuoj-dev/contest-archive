#include<bits/stdc++.h>

using namespace std;

#define int long long
#define ll long long
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pii pair<int,int>
#define pb push_back
//#define endl "\n"
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 2e5+7;
const int mod = 998244353;
int a[N],c[N];

void solve(){
	int n,m,b;
	cin >> n >> m >> b;
	for(int i=1;i<=n;i++) cin >> a[i],c[i] = c[i-1] + a[i];
	int cnt = 0;
	int pos = n;
	int ans = 0;
	for(int i=n;i>=1;i--){
		if(i == pos){
			if(ans) c[i] -= ans;
			cnt += min(b,max(0ll,c[i]));
			ans += min(b,max(0ll,c[i]));
			pos -= m;
		}
		ans = max(0ll,ans-a[i]);
	}
	cout << cnt << endl;
}
/*
6 2 10
20 1 1 1 1 5
5 2 10
5 9 3 1 8
*/

signed main(){
	ios::sync_with_stdio(0);
    cin.tie(nullptr);cout.tie(nullptr);
	int T = 1;
    //cin >> T;
    while(T--) solve();

    return 0 ;
}

