#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

vector<int> e[10050];
map<pair<int, int>, int> mp;
int rest[10050], stk[10050];

bool qry(int u, int v) {
    cout << "? " << u << ' ' << v << endl;
    int r; cin >> r;
    return r == 1;
}

void ensure(int x) {
    cout << "! " << x << endl;
}

bool dfs(int x, int fa) {
    rest[x] = 0;
    for(int y : e[x]) {
        if(y == fa) continue;
        if(dfs(y, x)) return true;
    }
    
    int top = 0;
    for(int y : e[x]) {
        if(y == fa) continue;
        if(rest[y]) {
            if(qry(x, rest[y])) {
                if(qry(x, y)) ensure(mp[{x, y}]);
                else ensure(mp[{y, rest[y]}]);
                return true;
            }
        }
        else stk[++top] = y;
    }
    
    for(int i = 1; i + 1 <= top; i += 2) {
        if(qry(stk[i], stk[i + 1])) {
            if(qry(x, stk[i])) ensure(mp[{x, stk[i]}]);
            else ensure(mp[{x, stk[i] + 1}]);
            return true;
        }
    }
    
    if(top & 1) rest[x] = stk[top];
    
    return false;
}

signed main() {
    int t; cin >> t;
    while(t--) {
        int n; cin >> n;
        for(int i = 1, u, v; i < n; ++i) {
            cin >> u >> v;
            e[u].push_back(v), e[v].push_back(u);
            mp[{u, v}] = mp[{v, u}] = i;
        }
        if(!dfs(1, 0)) ensure(mp[{1, rest[1]}]);
        
        mp.clear();
        for(int i = 1; i <= n; ++i) e[i].clear();
    }
    
    return 0;
}

/*

12
1 2
1 3
1 4
2 12
3 5
3 6
4 7
5 8
5 9
5 10
10 11
*/

