#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 2e5+10;
int a[N];
int b[N];
struct s
{
    int a,b;
}p[N];
int cmp(s x, s y)
{
    return x.b<y.b;
}
int di(int n)
{
    int dis=abs(b[1]-a[1]);
    int flag=1;
    for(int i=2;i<=n;i++)
    {
        // cout<<p[i].a<<' '<<p[i].b<<'\n';
        if(abs(b[i]-a[i])!=dis) return -1;
    }
    return dis;
}
signed main()
{
    int n;
    cin >> n;
    for(int i=1;i<=n;i++) cin >> a[i];
    for(int i=1;i<=n;i++)
    {
        p[i].a=a[i];
        cin >> b[i];
        p[i].b=b[i];
    }
    sort(p+1,p+1+n,cmp);
    for(int i=1;i<=n;i++)
    {
        a[i]=p[i].a;
        b[i]=p[i].b;
    }
    int res=1e18;
    if(di(n)>0) res=min(res,di(n));
    for(int i=1;i<=n;i++) a[i]=-a[i];
    if(di(n)>0) res=min(res,di(n)+1);
    for(int i=1;i<=n;i++) a[i]=-a[i];
    sort(a+1,a+n+1);
    if(di(n)>0) res=min(res,di(n)+1);
    for(int i=1;i<=n;i++) a[i]=-a[i];
    sort(a+1,a+n+1);
    if(di(n)>0) res=min(res,di(n)+1);
    if(res==1e18) cout<<-1<<'\n';
    else cout<<res<<'\n';
    return 0;
}