#include<bits/stdc++.h>
#define moder (long long)998244353
using namespace std;
long long binpow(long long a, long long b) {
  long long res = 1;
  while (b > 0) {
    if (b & 1) res = res * a % moder;
    a = a * a % moder;
    b >>= 1;
  }
  return res % moder;
}
long long C(long long x,long long y){
	if(y>x){
		return 0;
	}
	long long tim=1;
	for(int i=x;i>=x-y+1;i--){
		tim*=i;
		tim%=moder;
	}
	for(int i=1;i<=y;i++){
		tim*=binpow(i,moder-2);
		tim%=moder;
	}
	return tim%moder;
}
bool comp(long long x,long long y){
	return x<y;;
}
vector<int> a,b;
	int n;
int check (int k){
	stack<int> s;
	while(s.size()>0)	s.pop();
	for(int i=0;i<n;i++){
		if(b[i]<k){
			s.push(1);
		}
		if(b[i]>k){
			if(s.size()==0)	return 0;
			else s.pop();
		}
	}
	if(s.size()!=0)	return 0;
	return 1;
}
inline void solve()
{
	cin>>n;

	for(int i=0;i<n;i++){
		int num;
		cin>>num;
		a.push_back(num);
	}
	b=a;
	sort(a.begin(),a.end(),comp);
	if(n%2!=0){
		if(check(a[n/2])==1){
			cout<<1;
		}
		else{
			cout<<0;
		}
	}
	else{
		int ans=0;
		int l=1,r=0;
		if(check(a[n/2-1]+1)==1&&check(a[n/2]-1)==1){
			l=a[n/2-1]+1;
			r=a[n/2]-1;
		}
		if(check(a[n/2-1])==1)
			l=a[n/2-1];
		if(check(a[n/2])==1)
			r=a[n/2];
		ans = r-l+1;
		cout<<ans;
	}
}

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int tt;
	//cin>>tt;
	//while(tt--)
	solve();
}
