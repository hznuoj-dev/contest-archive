#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=200005;
double ans=0;
ll a[M],b[M],m,k;
void dfs(int id,ll sum,ll my){
	if(id==6)
	{
		if(my==0) return ;
		ans=max(ans,1.0*sum/(my-my/m*k));
		return ;
	}
	dfs(id+1,sum,my);
	sum+=b[id];
	my+=a[id];
	dfs(id+1,sum,my);
}
int main()
{
	scanf("%lld%lld",&m,&k);
	for(int i=1;i<=5;i++)
	{
		scanf("%lld%lld",&a[i],&b[i]);
	}
	dfs(1,0,0);
	printf("%.2lf",ans);
	return 0;
}