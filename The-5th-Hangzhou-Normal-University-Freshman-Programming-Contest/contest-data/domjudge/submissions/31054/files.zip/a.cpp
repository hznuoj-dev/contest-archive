#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N=2e5+7;
int n,a[N];

int check(int k){
	int cnt=0;
	for(int i=1;i<=n;i++){
		if(a[i]<k) cnt++;
		else if(a[i]>k) cnt--;
		if(cnt<0) return -1;
	}
	if(cnt>0) return 1;
	else if(cnt==0) return 0;
}

void solve(){
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	int l=1,r=2e5,ll=1e9+7,rr=1;
	
	while(l<=r){
		int mid=(l+r)/2;
		int res=check(mid);
		if(res==0){
			ll=mid;
			r=mid-1;
		}else if(res<0){
			l=mid+1;
		}else if(res>0){
			r=mid-1;
		}
	}
	
	l=1,r=2e5;
	while(l<=r){
		int mid=(l+r)/2;
		int res=check(mid);
		if(res==0){
			rr=mid;
			l=mid+1;
		}else if(res<0){
			l=mid+1;
		}else if(res>0){
			r=mid-1;
		}
	}
	cout<<max(0,rr-ll+1);
}

int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc=1;
//	cin>>tc;
	while(tc--) solve();
	return 0;
}
/*
4
4 10 5 10

4
1 4 4 10

*/
