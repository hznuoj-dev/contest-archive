#include<bits/stdc++.h>
using namespace std; 
const int N = 2e5+5;
double a[N],b[N],c[N];
int main()
{
	int k,m; cin >> m >> k;
	for(int i = 1;i <= 5;i++)
	{
		cin >> a[i];
		while(a[i] > m) a[i] -= k;
	}
		
	double q = 0,p = 0;
	for(int i = 1;i <= 5;i++)
	{
		cin >> b[i];
		if(b[i] >= a[i]) q += b[i],p += a[i];
	}
	while(p >= m) p -= k;
	printf("%.2f\n",q / p);
	
}
