#include <bits/stdc++.h>
using namespace std;
const int N=205;
int p[N],w[N],dp[40005];
//#define int long long
int main() {
	std::ios::sync_with_stdio(false);
    std::cin.tie(0);std::cout.tie(0);
	int m,k;
	double ans=0;
	cin>>m>>k;
	for(int i=1;i<=5;i++) cin>>p[i];
	for(int i=1;i<=5;i++) cin>>w[i];
	int v=0,sum=0;
	for(int t1=0;t1<2;t1++){
		for(int t2=0;t2<2;t2++){
			for(int t3=0;t3<2;t3++){
				for(int t4=0;t4<2;t4++){
					for(int t5=0;t5<2;t5++){
		if(t1) v+=p[1],sum+=w[1];
		if(t2) v+=p[2],sum+=w[2];
		if(t3) v+=p[3],sum+=w[3];
		if(t4) v+=p[4],sum+=w[4];
		if(t5) v+=p[5],sum+=w[5];
		if(v>=m) v-=k;
		//cout<<v<<" "<<sum<<" "<<1.0*sum/v<<endl;
		ans=max(ans,1.0*sum/v);
		v=0,sum=0;
	}
	}	
	}	
	}
	}
	// for(int i=1;i<(1<<5);i++){
		// int a=i,sum=0,v=0;
		// for(int j=0;j<5;j++){
			// if((a>>j)&1) v+=p[j],sum+=w[j];
			// //cout<<v<<" "<<sum<<endl;
		// }
		// if(v>=m) v-=k;
		// ans=max(ans,1.0*sum/v);
		// //cout<<i<<" "<<v<<" "<<sum<<" "<<1.0*sum/v<<endl;
	// }
	printf("%.2f",ans);
  return 0;
}