#include <bits/stdc++.h>
using namespace std;
#define int long long
double dp[205][205];
signed main()
{
	//ios::sync_with_stdio(false);cin.tie(0);
	int n,m;cin>>n>>m;
	int a[n+5]={};
	int b[n+5]={};
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	for(int i=1;i<=n;i++)
	{
		for(int j=200;j>=0;j--)
		{
			if((j-a[i])>=0)
			{
				if(j>m)
				{
					if((dp[i][j-a[i]]+b[i])*1.0/(j-m)>dp[i][j])dp[i][j]=dp[i][j-a[i]]+b[i];
				}
				else 
				{
					if((dp[i][j-a[i]]+b[i])*1.0/j>dp[i][j])dp[i][j]=dp[i][j-a[i]]+b[i];
				}
			}
		}
	}
	double ans=0;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=200;j++)
		{
			if(j>m)ans=max(ans,dp[i][j]/(j-m));
			else ans=max(ans,dp[i][j]*1.0/j);
		}
	}
	printf("%.2f",ans);
	return 0;
}
