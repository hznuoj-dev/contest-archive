#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5;
vector<pair<int,int>>g[maxn];
int t[maxn<<1],idx,st[maxn],ed[maxn],val[maxn];
int deep[maxn],f[maxn][25];
void dfs(int now,int father){
	st[now]=++idx;
	deep[now]=deep[father]+1;
	f[now][0]=father;
	for(int i=1;(1LL<<i)<=deep[now];i++)f[now][i]=f[f[now][i-1]][i-1];
	for(auto x:g[now]){
		int v=x.first;
		int w=x.second;
		if(v!=father){
			val[v]=w;
			dfs(v,now);
		}
	}
	ed[now]=++idx;
	return ;
}
int lca(int a,int b){
	if(deep[a]<deep[b])swap(a,b);
	for(int i=20;i>=0;i--){
		if(deep[a]-(1LL<<i)>=deep[b])a=f[a][i];
	}
	if(a==b)return a;
	for(int i=20;i>=0;i--){
		if(f[a][i]!=f[b][i]){
			a=f[a][i];
			b=f[b][i];
		}
	}
	return f[a][0];
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int n;cin>>n;
	for(int i=1;i<=n-1;i++){
		int u,v,w;cin>>u>>v>>w;
		g[u].push_back({v,w});
		g[v].push_back({u,w});
	}
	dfs(1,0);
	for(int i=1;i<=n;i++){
		t[st[i]]=val[i];
		t[ed[i]]=val[i];
	}
//	for(int i=1;i<=n;i++)cout<<val[i]<<' ';
//	cout<<'\n';
	for(int i=1;i<=2*n;i++){
		t[i]^=t[i-1];
	}
	int ans=0;
	for(int i=1;i<=n;i++){//���˸��ڵ� 
		ans^=t[st[i]];
//		cout<<i<<' '<<t[st[i]]<<'\n';
	}
//	cout<<ans<<'\n';
	int q;cin>>q;
	while(q--){
		int u,x;cin>>u>>x;
		if(n%2==0)cout<<ans<<'\n';
		else{
			int d=t[st[u]];
			int k=x^d;
			ans^=k;
			cout<<ans<<'\n';
		}
	}
	return 0;
}
/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5
*/
