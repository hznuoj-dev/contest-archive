#include <bits/stdc++.h>
using namespace std;
#define int long long
double dp[1005][1005];
signed main()
{
	//ios::sync_with_stdio(false);cin.tie(0);
	int n,m;cin>>n>>m;
	int a[6]={};
	int b[6]={};
	for(int i=1;i<=5;i++)cin>>a[i];
	for(int i=1;i<=5;i++)cin>>b[i];
	dp[0][0]=1;
	for(int i=1;i<=5;i++)
	{
		for(int j=1000;j>=0;j--)
		{
			if((j-a[i])>=0)
			{
				for(int k=1000;k>=0;k--)
				{
					if(j>=n)
					{
						if(dp[j-a[i]][k-b[i]])dp[j][k]=k*1.0/(j-m);
					}
					else 
					{
						if(dp[j-a[i]][k-b[i]])dp[j][k]=k*1.0/j;
					}
				}
			}
		}
	}
	double ans=0;
	for(int i=1;i<=1000;i++)
	{
		for(int j=1;j<=1000;j++)ans=max(ans,dp[i][j]);
	}
	printf("%.2f",ans);
	return 0;
}
