#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t;
	//cin >> t;
	t = 1;
	while (t--)
	{
		int n;
		cin>>n;
		int minn=1e15;
		vector<int>a(n),b(n);
		for(int i=0;i<n;i++)
		{
			cin>>a[i];
		}
		vector<int>sub(n);
		for(int i=0;i<n;i++)
		{
			cin>>b[i];
			sub[i]=b[i]-a[i];
		}
		for(int i=1;i<sub.size();i++)
		{
			if(sub[i]!=sub[i-1])
			break;
			if(i==sub.size()-1)
			minn=abs(sub[0]);
		}
		for(int i=0;i<b.size();i++)
		{
			b[i]=-b[i];
			sub[i]=b[i]-a[i];
		}
		for(int i=1;i<sub.size();i++)
		{
			if(sub[i]!=sub[i-1])
			break;
			if(i==sub.size()-1)
			minn=min(minn,1+abs(sub[0]));
		}
		if(minn!=1e15)
		cout<<minn<<endl;
		else
		cout<<-1<<endl;
	}
	return 0;
}