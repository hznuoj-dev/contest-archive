#include<bits/stdc++.h>

#define fu(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fd(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define PRN(X) cout << #X << "=" << X << endl
#define PR(X) cout << #X << "=" << X << " "
using namespace std;

const int N = 2e5 + 5;

int read(){
	int f = 1, x = 0; char ch = getchar();
	while(ch > '9' || ch < '0'){ 	if(ch == '-')f = -1; ch = getchar(); }
	while(ch <= '9' && ch >= '0'){ x = (x << 1) + (x << 3) + (ch ^ 48);  ch = getchar(); }
	return x * f;
}
int n, a[N], b[N];
int deal(int *x, int *y){
	map<int,int> mp;
	fu(i, 1, n) mp[x[i] - y[i]]++;
	if(mp.size() > 1) return -1;
	else return abs(mp.begin()->first);
}
void solve(){
	n = read();
	fu(i, 1, n) a[i] = read();
	fu(i, 1, n) b[i] = read();
	sort(a + 1, a + 1 + n);
	sort(b + 1, b + 1 + n);
	int ans1 = deal(a, b);
	fu(i, 1, n) b[i] = -b[i];
	sort(b + 1, b + 1 + n);
	int ans2 = deal(a, b);
	if(ans1 == -1 && ans2 == -1) printf("-1\n");
	else if(ans1 == -1) cout << ans2 + 1 << endl;
	else if(ans2 == -1) cout << ans1 << endl;
	else cout << min(ans1, ans2 + 1) << endl;
}
int main(){
	int t = 1;
	while(t--){
		solve();
	}
}


