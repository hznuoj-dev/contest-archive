#include <bits/stdc++.h>

using namespace std;
using LL = long long;

constexpr int N = 2e5 + 5;

#define int long long

int n, m, b, cnt, sum;

int a[N], c[N];

bool flag = 1;

void solve()
{
    cin >> n >> m >> b; 

    for(int i = 1; i <= n; ++ i){
        cin >> a[i];
        // c[i] += a[i] + c[i - 1];
    }

    if((n - 1) % m){
        flag = 1;
    }

    cnt = (n - 1) / m + 1;

    for(int i = 1; i <= n; ++ i)
    {
        c[i] = a[i] + c[i - 1];

        if((i - 1) % m == 0 && cnt > 1){
            if(b < c[i]){
                c[i] -= b;
                sum += b;
            }else{
                sum += c[i];
                c[i] = 0;
            }
            cnt --;
        }

        if(cnt == 1)
        {
            if(i == n)
            {
                if(b < c[i]){
                c[i] -= b;
                sum += b;
                }else{
                    sum += c[i];
                    c[i] = 0;
                }
                cnt --;
                break;
            }
        }
    }

    cout << sum << endl;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // ?int T;
    // f?or (cin >> T; T -- ; )
        solve();

}