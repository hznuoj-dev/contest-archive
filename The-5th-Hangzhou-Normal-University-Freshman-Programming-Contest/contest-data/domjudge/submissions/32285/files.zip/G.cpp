#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll dp[400010];
ll s[400010];
int a[400010];
inline int read() {
	int x = 0, f = 1;
	char c = getchar();
	while (c > '9' || c < '0') {
		if (c == '-') f = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		x = x * 10 + c - '0';
		c = getchar();
	}
	return x * f;
}
int main () {
	int n = read(), m = read(), k = read();
	for (int i = 1; i <= n; i++) a[i] = read();
	ll ans = 0, maxn = 0;
	for (int i = 1; i <= n; i++) {
		s[i] = s[i - 1] + a[i];
		if (i < m + 1) dp[i] = s[i] >= k ? k : s[i];
		else {
			 maxn = max(maxn, dp[i - m]);
			dp[i] = min(maxn + k, s[i]);
			ans = max(ans, dp[i]);
		}
	}
	printf("%lld", ans);
}
