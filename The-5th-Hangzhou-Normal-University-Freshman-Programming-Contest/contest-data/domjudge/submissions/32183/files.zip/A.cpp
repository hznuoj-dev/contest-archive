#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
vector<char> s;
int n,a[200005],ans,maxn;
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i],maxn=max(maxn,a[i]);
    int k=a[1];
    while(1)
    {
        int t=1;
        for(int i=1;i<=n;i++)
        {
           if(k>a[i])s.push_back('(');
           else if(k<a[i]&&!s.empty())s.pop_back();
           else if(k<a[i]&&s.empty()){t=0;break;}
        }
        if(s.empty()&&t)ans++;
        k++;
        if(k==maxn+1)break;
    }
    cout<<ans;
    return 0;
}