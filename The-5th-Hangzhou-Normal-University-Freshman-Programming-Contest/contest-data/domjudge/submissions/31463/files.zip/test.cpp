#include <iostream>
#include <algorithm>

using namespace std;
typedef long long ll;
const int N = 2e5 + 5;
ll a[N],b[N],c[N],d[N],e[N];

int main(){

    int n;
    cin >> n;

    for(int i = 1;i <= n;i++){
        cin >> a[i];
    }
    for(int i = 1;i <= n;i++){
        cin >> b[i];
        c[i] = - b[i];
    }

    sort(a + 1, a + n + 1);
    sort(b + 1, b + n + 1);
    sort(c + 1, c + n + 1);

    int flag1 = 1, flag2 = 1;

    for(int i = 1;i <= n;i++){
        d[i] = a[i] - b[i];
        e[i] = a[i] - c[i];

        if(i > 1) {
            if(d[i] != d[i-1]) flag1 = 0;
            if(e[i] != e[i-1]) flag2 = 0;
        }
    }

    if(flag1 && !flag2) {
        cout << abs(d[1]) << "\n";
    }
    else if(flag2 && !flag1){
        cout << abs(e[1]) + 1 << "\n";
    }
    else if(flag1 && flag2){
        cout << min(abs(d[1]),abs(e[1]) + 1) << "\n";
    }
    else cout << "-1" << "\n";

}