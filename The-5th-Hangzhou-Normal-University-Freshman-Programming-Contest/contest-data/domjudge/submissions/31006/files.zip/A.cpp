#include<bits/stdc++.h>

#define fu(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fd(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define PRN(X) cout << #X << "=" << X << endl
#define PR(X) cout << #X << "=" << X << " "
using namespace std;

const int N = 2e5 + 5;

int read(){
	int f = 1, x = 0; char ch = getchar();
	while(ch > '9' || ch < '0'){ 	if(ch == '-')f = -1; ch = getchar(); }
	while(ch <= '9' && ch >= '0'){ x = (x << 1) + (x << 3) + (ch ^ 48);  ch = getchar(); }
	return x * f;
}
int a[N], cnt[N], sum[N], vis[N], res[N];int n;
bool check(int val){
	stack<int> stk;
	fu(i, 1, n) {
		if(a[i] < val) stk.push(i);
		else if(a[i] > val){
			if(!stk.empty())stk.pop();
			else return false;
		}
	}
	return stk.empty();
}
void solve(){
	n = read();
	int ans = 0;
	fu(i, 1, n) a[i] = read();
	fu(i, 1, n) cnt[a[i]]++;
	fu(i, 1, N - 5) {
		int L = sum[i - 1];
		sum[i] = sum[i - 1] + cnt[i];
		int R = n - sum[i];
		if(L == R) {
			if(!vis[L]) vis[L] = 1, res[L] = check(i);
			ans += res[L];
		}
	}
	cout << ans << endl;
}
int main(){
	int t = 1;
	while(t--){
		solve();
	}
}


