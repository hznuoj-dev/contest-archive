#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll maxn = 2e5 + 10;
const ll minn = 1e9 + 7;
const double eps = 1e-6;
const int INFTY = (1<<21);

int gcd(int a, int b) {return b ? gcd(b, a % b) : a;}
int lcm(int a, int b) {return a * b / gcd(a, b);}

ll n;
ll a[maxn];
set<ll>S1,S2;
vector<int>V1,V2;

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	std::cin>>n;
    for(int i=1;i<=n;i++)
	{
		std::cin>>a[i];
	}
    for(int i=1;i<=n;i++)
	{
		if(i%2==1)
		{
			V1.push_back(a[i]);
		}
		else 
		{
			V2.push_back(a[i]);
		}
	}
	ll num=0;
	sort(V1.begin(),V1.end());
    sort(V2.begin(),V2.end());
    int f=0;
    if(V1[V1.size()-1]==V2[0])
    {
        std::cout<<"1"<<endl;
        f=1;
    }
    else 
    {
        for(ll i=V1[V1.size()-1]+1;i<=V2[0]-1;i++)
        {
            num++;
            f=1;
        }
        std::cout<<num<<endl;
    }
    if(f==0)
    {
        cout<<"-1"<<endl;
    }
	return 0;
}