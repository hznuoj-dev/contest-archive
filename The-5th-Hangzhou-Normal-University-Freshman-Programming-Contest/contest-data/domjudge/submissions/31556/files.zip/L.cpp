#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
bool vis[10];
int m,k;
double ans = 0;
double a[10],b[10];
void dfs(int pos, double sum_a,double sum_b){
	sum_a += a[pos];
	sum_b += b[pos];
    if(sum_a>=m){
		ans = max(ans,sum_b/(sum_a-k));
	}
	else ans = max(ans,sum_b/sum_a);
	for(int i = 1;i<=5;i++){
		if(!vis[i]){
			vis[i] = true;
			dfs(i,sum_a,sum_b);
			vis[i] = false;
		}
	}
}
void solve(){
	cin>>m>>k;
	for(int i = 1;i<=5;i++){
		cin>>a[i];
	}
	for(int i = 1;i<=5;i++){
		cin>>b[i];
	}
	cout<<fixed<<setprecision(2);
	for(int i = 1;i<=5;i++){
		vis[i] = true;
		dfs(i,0,0);
		vis[i] = false;
	}
	cout<<ans<<'\n';
}

signed main(){
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}

