#include<bits/stdc++.h>
using namespace std;
struct node{
	int a;
	int b;
	int v;
}num[10];
bool cmp(node x,node y){
	if(x.v!=y.v)
	return x.v>y.v;
	else return x.a>y.a;
}
void slove(){
	int m,k;
	cin>>m>>k;
	int a[10],b[10];
	for(int i=1;i<=5;i++){
		cin>>num[i].a;
	} 
	for(int i=1;i<=5;i++){
		cin>>num[i].b;
		num[i].v=num[i].b/num[i].a;
	}
	sort(num+1,num+6,cmp);
	double ans=0,p=0,anss=0;
	for(int i=1;i<=5;i++){
		ans+=num[i].a;
		p+=num[i].b;
		
		if(ans>=m){ 
		ans-=k;
	}
	
	
	double vv=(double)p/(double)ans;
		if(vv>anss) anss=(double)p/(double)ans;
	}
	printf("%.2lf",anss); 
}
int main(){
	int T=1;
//	cin>>T;
	while(T--){
		slove();
	}
	
	return 0;
} 
