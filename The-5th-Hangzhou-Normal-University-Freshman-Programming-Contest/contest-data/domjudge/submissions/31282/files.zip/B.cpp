#include<iostream>
#include<algorithm>
using namespace std; 
const int N = 200005; 
int a[N],b[N]; 
int n; 

bool check()
{
	for(int i = 2;i<=n;++i){
		if(a[i]-a[i-1]!=b[i]-b[i-1])
		return false; 
	}
	return true; 
}
int main(){
	cin>>n; 
	for(int i =1;i<=n;++i){
		cin>>a[i]; 
	}
	for(int j =1;j<=n;++j){
		cin>>b[j]; 
	}
	sort(a+1,a+n+1); 
	sort(b+1,b+n+1); 
	int ans = 0; 
	if(!check()){
		for(int i = 1;i<=n;++i)
		b[i]=-b[i]; 
		sort(b+1,b+n+1); 
		ans = 1; 
		if(!check()){
			cout<<-1;
			return 0; 
		} 
	}
	ans += abs(a[1]-b[1]);
	cout<<ans; 
	return 0;  
}
