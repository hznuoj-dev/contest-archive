#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int a[N];

bool check(int mid)
{
    int cnt0 = 0, cnt1 = 0;
    for (int i = 1; i <= n; ++i)
    {
        if (a[i] < mid)
            cnt0++;
        else if (a[i] > mid)
            cnt1++;
        if (cnt1 > cnt0)
            return false;
    }
    if (cnt1 != cnt0)
        return false;
    return true;
}

bool check1(int mid)
{
    int cnt0 = 0, cnt1 = 0;
    for (int i = 1; i <= n; ++i)
    {
        if (a[i] < mid)
            cnt0++;
        else if (a[i] > mid)
            cnt1++;
        if (cnt1 > cnt0)
            return false;
    }
    return true;
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    int l = 1, r = 1e9;
    while (l <= r)
    {
        int mid = l + r >> 1;
        if (check1(mid))
            r = mid - 1;
        else
            l = mid + 1;
    }
    // cout << l << endl;
    int ans1 = l;

    // cout << check(3) << endl;
    l = ans1, r = 1e9;
    while (l <= r)
    {
        int mid = l + r >> 1;
        if (check(mid))
            l = mid + 1;
        else
            r = mid - 1;
    }
    // cout << r << endl;
    int ans2 = r;
    cout << ans2 - ans1 + 1 << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}