﻿#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=2e5+9;
int a[N],n,m,k,lg[N],val[N],sum[N];
int mn[19][N],mx[19][N];

inline int ask(int l,int r)
{
    int len=lg[r-l+1];
    int Mn=min(mn[len][l],mn[len][r-(1<<len)+1]);
    int Mx=max(mx[len][l],mx[len][r-(1<<len)+1]);
    return Mx-Mn;
}

signed main()
{
    scanf("%lld%lld%lld",&n,&k,&m);
    lg[0]=-1;
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&a[i]);
        mn[0][i]=mx[0][i]=a[i];
        lg[i]=lg[i>>1]+1;
    }
    for(int i=1;i<=18;i++)
        for(int l=1;l+(1<<i)-1<=n;l++)
            mn[i][l]=min(mn[i-1][l],mn[i-1][l+(1<<i-1)]),
            mx[i][l]=max(mx[i-1][l],mx[i-1][l+(1<<i-1)]);
    for(int i=1;i<=n;i++)
    {
        int l=i,r=n;
        while(l<r)
        {
            int mid=(l+r+1)>>1;
            if(ask(i,mid)<=k) l=mid;
            else r=mid-1;
        }
        val[i]=l;
    }
    for(int i=1;i<=n;i++) sum[i]=sum[i-1]+(val[i]-i+1);
    while(m--)
    {
        int L,R,l,r,ans;
        scanf("%lld%lld",&L,&R);
        l=L-1,r=R;
        while(l<r)
        {
            int mid=(l+r+1)>>1;
            if(val[mid]<=R) l=mid;
            else r=mid-1;
        }
        ans=(sum[l]-sum[L-1]);
        ans+=(R*(R-l)-(l+R-1)*(R-l)/2);
        printf("%lld\n",ans);
    }
    return 0;
}