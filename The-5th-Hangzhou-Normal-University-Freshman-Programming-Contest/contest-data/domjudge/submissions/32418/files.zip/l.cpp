#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
struct node {
	int pj,jg;
	double xjb;
} a[6];
bool cmp(node a,node b) {
	if(a.xjb==b.xjb) {
		return a.jg>b.jg;
	} else {
		return a.xjb>b.xjb;
	}
}
int main() {
	int m,k;
	cin>>m>>k;
	for(int i=1; i<=5; i++)
		cin>>a[i].jg;
	for(int i=1; i<=5; i++)
		cin>>a[i].pj;
	for(int i=1; i<=5; i++)
		a[i].xjb=a[i].pj*1.0/a[i].jg;
	sort(a+1,a+6,cmp);
	double maxn=0;
	for(int i=1;i<=5;i++){
		for(int j=1;j<=5;j++){
			int zj=0,zp=0;
			int num=0;
			while(num+j<=i){
				zj+=a[num+j].jg;
				zp+=a[num+j].pj;
				num++;
			}
			if(zj>=m) zj-=k;
			maxn=max(maxn,zp*1.0/zj);
		}
	}
	printf("%.2f\n",maxn);
	return 0;
}
