/*
 * @Author: JSY
 * @Date: 2023-05-27 11:58:53
 * @Last Modified by: JSY
 * @Last Modified time: 2023-05-27 11:58:53
*/

#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define PII pair<int, int>
#define IOS ios::sync_with_stdio(0);cin.tie(0), cout.tie(0)
const int N = 200010;
int n;
int a[N];
int b[N];

bool check(int x){
    int res = 0;
    for(int i=1;i<=n;i++){
        if(a[i] == x) continue;
        if(a[i] < x) res ++;
        if(a[i] > x) res --;
        if(res < 0) return false;
    }
    if(res != 0) return false;
    else return true;
}

signed main(){
    IOS;
    cin >> n;
    for(int i=1;i<=n;i++){
        cin >> a[i];
        b[i] = a[i];
    }
    int ans = 0 , id = -1;
    sort(b+1,b+n+1);
    if(n % 2 == 0){
        int l = n/2 , r = n/2+1;
        if(b[l] == b[r]){
            ans = 1;
            id = b[l];
        }else if(b[r] == b[l]+1){
            ans = 0;
            id = -1;
        }else{
            ans = b[r] - b[l] - 1;
            id = b[l] + 1;
        }
    }else{
        int l = n/2+1;
        ans = 1;
        id = b[l];
    }
    if(id != -1){
        if(check(id)) cout << ans;
        else cout << 0;
    }
    return 0;
}