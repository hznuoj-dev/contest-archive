#include<bits/stdc++.h>
using namespace std;
const int N = 250;
int a[N],b[N];
double ans;
int main()
{
	int m, k;
    cin >> m >> k;
    for (int i = 1; i <= 5; i++)
    {
      cin >> a[i];
    }
    for (int i = 1; i <= 5; i++)
        cin >> b[i];
    for (int i = 1; i <= 5; i++)
    {
        int sum = a[i];
        int manyizhi = b[i];
        if (sum >= m)sum -= k;
        if (manyizhi * 1.0 / sum > ans)
		ans = manyizhi * 1.0 / sum;
    }
    for (int i = 1; i <= 5; i++)
    {
        for (int j = i+1; j <= 5; j++)
        {
            int sum = a[i]+a[j];
            int manyizhi = b[i]+b[j];
            if (sum >= m)sum -= k;
            if (manyizhi * 1.0 / sum > ans)
			ans = manyizhi * 1.0 / sum;
        }
    }
    for (int i = 1; i <= 5; i++)
    {
        for (int j = i+1; j <= 5; j++)
        {
            for (int t = j + 1; t <= 5; t++)
            {
                int sum = a[i] + a[j]+a[t];
                int manyizhi =b[i] + b[j] + b[t] ;
                if (sum >= m)sum -= k;
                if (manyizhi * 1.0 /sum > ans)
				ans = manyizhi * 1.0 / sum;
           }
        }
    }
    for (int i = 1; i <= 5; i++)
    {
        for (int j = i + 1; j <= 5; j++)
        {
            for (int t = j + 1; t <= 5; t++)
            {
                for (int w = t + 1; w <= 5; w++)
                {
                    int sum = a[i] + a[j] + a[t]+a[w];
                    int manyizhi = b[i] + b[j] + b[t]+b[w];
                    if (sum >= m)sum -= k;
                    if (manyizhi * 1.0 / sum > ans)
					ans = manyizhi * 1.0 / sum;
                }
            }
        }
    }
    int sum,manyizhi;
    for(int i=1;i<=5;i++)
    {
		sum+=a[i];
		manyizhi+=b[i];
	}
    if (sum >= m)sum -= k;
    if (manyizhi * 1.0 / sum > ans)
	ans = manyizhi * 1.0 / sum;
    printf("%.2lf",ans);
    return 0;
}
