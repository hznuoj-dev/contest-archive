#include<bits/stdc++.h>
using namespace std;
int main()
{
	int sum,n,temp,i,j,flag,flag2,cha2[20000],cha[20000],a[20000],b[20000];
	cin>>n;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(i=1;i<=n;i++)
	{
		cin>>b[i];
	}
	
	for(i=1;i<n;i++)
	{
		for(j=1;j<=n-i;j++)
		{
			if(abs(a[j])>abs(a[j+1]))
			{
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
			if(abs(b[j])>abs(b[j+1]))
			{
				temp=b[j];
				b[j]=b[j+1];
				b[j+1]=temp;
			}
		}
	}
	for(i=1;i<=n;i++)
	{
		cha[i]=a[i]-b[i];
	}
	for(i=1;i<=n;i++)
	{
		cha2[i]=(-1)*a[i]-b[i];
	}
	flag=1;
	flag2=1;
	for(i=1;i<n;i++)
	{
		if(cha[i]!=cha[i+1])
		{
			flag=0;
		}
	}
	if(flag==1)
	{
		sum=cha[1];
		if(sum<0)
		{
			sum=(-1)*sum;
		}
	}
	
	
	for(i=1;i<n;i++)
	{
		if(cha2[i]!=cha2[i+1])
		{
			flag2=0;
		}
	}
	if(flag2==1)
	{
		sum=cha2[1];
		if(sum<0)
		{
			sum=(-1)*sum;
		}
		sum++;
	}
	
	if(flag==0&&flag2==0)
	{
		sum=-1;
	}
	
	cout<<sum<<endl;
	return 0;
}
