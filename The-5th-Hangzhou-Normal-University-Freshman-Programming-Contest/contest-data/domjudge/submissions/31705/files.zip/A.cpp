#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
vector<pair<int,int> >q;
int a[200005];
int ans[200010];
void play(int l, int r) {
	if((r-l+1)%2==0) {
		int mid = (l+r)/2;
		if(a[mid]==a[mid+1]) {
			int cnt = 0;
			for(int i = l; i<=r; i++) {
				if(a[i]==a[mid])cnt++;
			}
			if(cnt%2==0){
				ans[a[mid]]++;
				ans[a[mid]+1]--;
			}
		}
		else{
			ans[a[mid]+1]++;
			ans[a[mid+1]]--;
		}
	} else {
		int mid = (l+r)/2;
		int cnt = 0;
		for(int i = l; i<=r; i++) {
			if(a[i]==a[mid])cnt++;
		}
		if(cnt%2==1){
			ans[a[mid]]++;
			ans[a[mid]+1]--;
		}
	}
}
void solve() {
	int n;
	cin>>n;
	for(int i = 1; i<=n; i++) {
		cin>>a[i];
	}
	int l = 1;
	for(int i = 2; i<=n; i++) {
		if(a[i]<a[i-1]) {
			q.push_back({l,i-1});
			l = i;
		}
	}
	q.push_back({l,n});
	for(auto x:q) {
//		cout<<x.first<<' '<<x.second<<'\n';
		play(x.first,x.second);
	}
	int answer = 0;
	for(int i = 1;i<=200005;i++){
		ans[i] += ans[i-1];
//		cout<<ans[i]<<'\n';
		if(ans[i]==q.size())answer++;
	}
	cout<<answer;
}

signed main() {
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}
