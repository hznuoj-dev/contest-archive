#include<bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);

const int N = 2e5+10;
const int M = 1e9+7;
const int INF = 0x3f3f3f3f;

int gcd(int a,int b){
	return (b==0)?a:gcd(b,a%b);
}

int lcm(int a,int b){
	return a*b/gcd(a,b);
}

int a[N],b[N];

void solve(){
	int n;
	cin>>n;
	
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	
	bool ok=1,flag=1;
	int ans,res;
	for(int i=1;i<n;i++){
		if(a[i]-b[i]!=a[i+1]-b[i+1]){
			ok=0;
		}
	}
	
	if(ok){
		res=abs(a[1]-b[1]);
	}
	
//	if(!ok){
		for(int i=1;i<=n;i++){
			a[i]=-a[i];
		}
		
		for(int i=1;i<n;i++){
			if(a[i]-b[i]!=a[i+1]-b[i+1]){
				flag=0;
			}
		}
		
		if(flag){
			ans=abs(a[1]-b[1]);
		}
	//}
	
	if(!ok && !flag){
		cout<<"-1"<<endl;
		return ;
	}
	
	if(ok && flag){
		cout<<min(ans,res)<<endl;
		return ;
	}
	
	if(ok && !flag){
		cout<<res<<endl;
		return ;
	}
	
	if(flag && !ok){
		cout<<ans<<endl;
		return ;
	}
}

signed main(){
	IOS;
	
	int t;
	t=1;
	//cin>>t;
	
	while(t--){
		solve();
	}
	
	return 0;
}
