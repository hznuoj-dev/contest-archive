#include<iostream>
#include<cstring>
#include<string>
#include<algorithm>
#include<queue>
#include<utility>
#include<cmath>
#include<stack>
#include<set>
#include<map>
#define int long long
using namespace std;
const int N=1e6+50;
const int M=1e6;
const int inf=0x3f3f3f3f;
const int mod=1e9+7;
int n,p,a[N],b[N],c[N];
void solve(){
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i],c[i]=-b[i];
	
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	
	for(int i=1;i<=n;i++)b[i]-=a[i],c[i]-=a[i];
	bool flag1=true,flag2=true;
	int x=b[1],y=c[1];
	for(int i=2;i<=n;i++){
		if(b[i]!=x)flag1=false;
		if(c[i]!=y)flag2=false;
	}
	if(flag1&&flag2)cout<<min(abs(x),abs(y));
	else if(flag1)cout<<abs(x);
	else if(flag2)cout<<abs(y);
	else cout<<-1;
}
signed main(){
	int T=1;
//	cin>>T;
	while(T--)solve();
}

