#include<bits/stdc++.h>
using namespace std;
int a[9],b[9];
int main(){
	int k,m,s1=0,s2=0;
	double maxi=0;
	cin>>m>>k;
	for(int i=1;i<=5;i++){
		cin>>a[i];
	}
	for(int i=1;i<=5;i++){
		cin>>b[i];
	}
	for(int c=0;c<2;c++){
		for(int d=0;d<2;d++){
			for(int e=0;e<2;e++){
				for(int f=0;f<2;f++){
					for(int g=0;g<2;g++){
						if(c) s1+=a[1],s2+=b[1];
						if(d) s1+=a[2],s2+=b[2];
						if(e) s1+=a[3],s2+=b[3];
						if(f) s1+=a[4],s2+=b[4];
						if(g) s1+=a[5],s2+=b[5];
						if(s1>=m) s1-=k;
						maxi=max(maxi,s1*1.0/s2);
						s1=0,s2=0;
					}
				}
			}
		}
	}
	printf("%.2f",maxi);
	return 0;
} 
