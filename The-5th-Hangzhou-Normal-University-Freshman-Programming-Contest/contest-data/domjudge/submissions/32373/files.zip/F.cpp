#define _CRT_SECURE_NO_WARNINGS 1
#include<bits/stdc++.h>
#define ios  ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
typedef long long LL;
const LL MAXN = 2e5+10;
const int Inf = 0x7fffffff;
const LL INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
struct Edge{
	int last,to,w;
}edge[MAXN];
int menu[MAXN];
bool visited[MAXN];
int va[MAXN];
int n,q;
void build(int s,int t,int w,int p)
{
	edge[p].to=t;
	edge[p].w=w;
	edge[p].last=menu[s];
	menu[s]=p;
}
void Works(int x)
{
	queue<int> que;
	que.push(x);
	while(!que.empty())
	{
		
		int now;
		now=que.front();
		visited[now]=true;
		//cout<<"now ��"<<now<<":\n";
		que.pop();
		for(int i=menu[now];i!=-1;i=edge[i].last)
		{
			int t=edge[i].to;
			int w=edge[i].w;
			if(visited[t]==false)
			{
				va[t]=(w^va[now]);
				//for(int j=1;j<=n;++j)
				//	cout<<va[j]<<" ";
				//system("pause");
				que.push(t);
			}
		}
	}
	int ans=va[1];
	for(int i=2;i<=n;++i)
		ans=ans^va[i];
	cout<<ans<<"\n";
	return;
}
int main()
{
	ios;
	int a,b,c;
	cin>>n;
	for(int i=1;i<=n;++i)
		menu[i]=-1;
	int u,v,w;
	for(int i=1;i<n;++i)
	{
		cin>>u>>v>>w;
		build(u,v,w,i);
		build(v,u,w,i+n);
	}
	cin>>q;
	for(int i=1;i<=q;++i)
	{
		cin>>u>>v;
		for(int j=1;j<=n;++j)
		{
			va[j]=-1;
			visited[j]=false;
		}
		va[u]=v;
		Works(u);
	}
	//system("pause");
	return 0;
}