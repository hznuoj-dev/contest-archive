        #include<iostream>
        #include<algorithm>
        #include<queue>
        #include<cmath>
        #include<map>
        #include<iomanip>
        #include<stack>
        #define shojig ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
        using namespace std;
        typedef long long ll;
        int a[2000000],b[2000000],a1[2000000],b1[2000000];
		int main()
        {
           	int n,x;
           	cin>>n;
           	for(int i=1;i<=n;i++)cin>>a[i];
           	sort(a+1,a+n+1);
			for(int i=n;i>=2;i--)a1[i]=a[i]-a[i-1]; 
        	for(int i=1;i<=n;i++)cin>>b[i];
        	sort(b+1,b+n+1);
			for(int i=n;i>=2;i--){
				b1[i]=b[i]-b[i-1];
				if(b1[i]!=a1[i]){
					cout<<"-1";
					return 0;
				}
			}
			cout<<min(abs(a[1]-b[1]),abs(-1*a[1]-b[n])+1); 
		}
		 
