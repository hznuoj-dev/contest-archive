#include<iostream>
#include<vector>
using namespace std; 
const int N = 2e5+5; 
const int P = 1e9+7; 
int f[N], a[N], h[N], siz[N], up[N]; 
vector<int> g[N]; 
int n,q; 

int find(int x){
	while(x!=f[x])
		x=f[x]=f[f[x]]; 
	return x; 
}

int merge(int u,int v){
	int x = find(u), y = find(v); 
	f[x] = y; 
	siz[y] += siz[x]; 
	a[y] = (a[y] + a[x])%P; 
	for(int i = 0;i<g[x].size();++i){
		g[y].push_back(g[x][i]); 
	}
}

void update(int u, int t){
	int x = find(u); 
	int tmp = t-up[x]; 
	int k = a[x]*tmp%P; 
	for(int i = 0;i<g[x].size();++i){
		h[g[x][i]] = (h[g[x][i]]+k)%P; 
	}
	up[x]=t; 
}

int main(){
	cin>>n>>q; 
	for(int i = 1;i<=n;++i){
	f[i]=i; 
	siz[i]=1; 
	g[i].push_back(i); 	
	cin>>a[i]; 
	}
	for(int i = 1;i<=q;++i){
		int t, u, v; 
		cin>>t; 
		switch(t){
			case 1:
				cin>>u>>v; 
				update(u,i); 
				update(v,i); 
				merge(u,v);  
				break; 
			case 2:
				cin>>u>>v; 
				update(u,i); 
				a[find(u)]=(a[find(u)]+v*siz[find(u)]%P)%P;
				break; 
			case 3:
				cin>>u; 
				update(u,i); 
				cout<<h[u]<<endl; 
				break; 
		}
	}
}
