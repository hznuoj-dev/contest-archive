#include<bits/stdc++.h>
#define rg register
#define il inline
typedef long long ll;
using namespace std;
#define int ll
ll mod = 1e9+7;
inline ll read() {
	ll ans = 0;
	char last = ' ', ch = getchar();
	while (ch < '0' || ch > '9') last = ch, ch = getchar();
	while (ch >= '0' && ch <= '9') ans = ans * 10 + ch - '0', ch = getchar();
	if (last == '-') return -ans;
	return ans;
}
il ll ksm(ll b,ll k){
	ll res=1;
	while(k){
		if(k&1) res=1ll*res*b%mod;
		b=1ll*b*b%mod;k>>=1;
	}
	return res;
}
int e[800040],ne[800040],h[800020],idx;
int chu[400040];
int ru[400040];
int w[400040];
ll c[400040];
ll s[4000040];
void add(int a,int b){
	e[idx]=b;
	ne[idx]=h[a];
	h[a]=idx++;
} 
map<pair<int,int>,int>mp;
signed main(){
	memset(h,-1,sizeof h);
	int n,m,k;
	n=read();
	m=read();
	k=read();
	for(int i=1;i<=m;i++){
		int a,b;
		a=read();
		b=read();
		ru[b]++;
		chu[a]++;
		add(a,b);
	}
	queue<int>q;
	for(int i=1;i<=n;i++){
		if(ru[i]==0)q.push(i),w[i]=1;
	}
	ll ans=0;
	while(!q.empty()){
		int tt=q.front();
		q.pop();
		for(int i=h[tt];~i;i=ne[i]){
			int j=e[i];
			w[j]=max(w[j],w[tt]+1);
			ru[j]--;
			if(!ru[j])q.push(j);
			
		}
	}
	for(int i=1;i<=n;i++){
		c[w[i]]++;
	}
	for(int i=1;i<=2e5+10;i++){
		s[i]=s[i-1]+c[i];
	}
	for(int i=1;i<=n;i++){
		ans+=s[w[i]-1];
		ans%=mod;
	}
	cout<<ksm(ans,k)%mod<<endl;
}

