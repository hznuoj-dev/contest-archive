#include <bits/stdc++.h>
using namespace std;
const int N = 200005;
int a[N], b[N], del[N];
int ta[N], tb[N];
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n, cost = 0, flag = 1;
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
		ta[i] = abs(a[i]);
	}
	for(int i = 1; i <= n; i++) {
		cin >> b[i];
		tb[i] = abs(b[i]);
	}
	sort(ta + 1, ta + 1 + n);
	sort(tb + 1, tb + 1 + n);
	for(int i = 1; i <= n; i++) {
		del[i] = tb[i] - ta[i];
	}
	sort(del + 1, del + 1 + n);
	for(int i = 2; i <= n; i++) {
		if(del[i - 1] != del[i]) {
			flag = 0;
			break;
		}
	}
	if(!flag) {
		cout << "-1\n";
	} else {
		cost += del[1];
		int nea = 0, neb = 0;
		for(int i = 1; i <= n; i++) {
			if((a[i] < 0 && b[i] > 0) || (a[i] > 0 && b[i] < 0)) {
				cost++;
			}
		}
		cout << cost << "\n";
	}
	return 0;
}
/*
4
1 3 4 2
-1 -2 -3 -4
*/
