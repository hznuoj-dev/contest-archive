#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 3e5+7,inf = 1e18+7;
typedef long long ll;

int a[10],b[10];

void solve(){
	int m,k;
	cin >> m >> k;
	for (int i = 1; i <= 5; i++){
		cin >> a[i];
	}
	for (int i = 1; i <= 5; i++){
		cin >> b[i];
	}
	double ans = -1;
	for (int i = 1; i < (1ll << 5); i++){
		int tot = 0,cost = 0;
		for (int j = 1; j <= 5; j++){
			if ((i >> (j - 1)) & 1){
				tot += b[j];
				cost += a[j];
				
			}
		}
		if (cost >= m) cost -= k;
		double tmp = (tot * 1.0) / cost;
		ans = max(ans,tmp);		
	}
	printf("%.2lf\n",ans);

	
}

signed main(){
//	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc = 1;
//	cin >> tc;
	while (tc--){
		solve();
	}
	return 0;
}
/*
5 3
1 2 4 4 2
2 2 1 2 4

*/
