#include <iostream>
#include <algorithm>

using namespace std;

const int N = 1010;

int n, m,k;
int a[N], b[N];
double maxi=0,res;
int main()
{
	cin >> m >> k;
	
	for (int i = 1; i <= 5; i ++ ) cin >> a[i];
	for (int i = 1; i <= 5; i ++ ) cin >> b[i];
	
	for (int i = 1; i <= 5; i ++ )
	{
		if(a[i]>=m)
		{
			res=b[i]*1.0/(a[i]-k);
		}
		else 
			res=b[i]*1.0/(a[i]);
		maxi=max(maxi,res);
	}
	for(int i=1;i<=4;i++)
	{
		for(int j=i+1;j<=5;j++)
		{
			int q=a[i]+a[j];
			int w=b[i]+b[j];
			if(q>=m)
			{
				res=w*1.0/(q-k);
			}
			else 
				res=w*1.0/(q);
			maxi=max(maxi,res);
		}
	}
	for(int i=1;i<=3;i++)
	{
		for(int s=i+1;s<=4;s++)
		{
		   for(int j=s+1;j<=5;j++)
		  {
		 	  int q=a[i]+a[j]+a[s];
			  int w=b[i]+b[j]+b[s];
			  if(q>=m)
			  {
			     	res=w*1.0/(q-k);
			  }
			  else 
			     	res=w*1.0/(q);
			maxi=max(maxi,res);
		}
		}
	}
	for(int i=1;i<=2;i++)
	{
		for(int s=i+1;s<=3;s++)
		{
			for(int j=s+1;j<=4;j++)
			{
				for(int t=j+1;t<=5;t++)
				{
					
				int q=a[i]+a[j]+a[s]+a[t];
				int w=b[i]+b[j]+b[s]+b[t];
				if(q>=m)
				{
					res=w*1.0/(q-k);
				}
				else 
					res=w*1.0/(q);
				maxi=max(maxi,res);
				}
			}
		}
	}
	int q,w;
	
for(int i=1;i<=5;i++)
{
	q+=a[i];
	w+=b[i];
}
if(q>=m)
{
	res=w*1.0/(q-k);
}
else 
	res=w*1.0/(q);
maxi=max(maxi,res);

	printf("%.2lf",maxi);
	return 0;
}
