﻿#include<bits/stdc++.h>
using namespace std;
const int N=2e5+9;
#define ll long long
int a[N],b[N],n,m,k;
int ans,tmp;
double res;
int main()
{
    cin>>m>>k;n=5;
    for(int i=0;i<n;i++) cin>>a[i],ans+=a[i];
    for(int i=0;i<n;i++) cin>>b[i],tmp+=b[i];
    for(int S=1;S<(1<<5);S++)
    {
        ans=tmp=0;
        for(int i=0;i<5;i++)
            if(S&(1<<i))
            {
                ans+=a[i];
                tmp+=b[i];
            }
        if(ans>=m) ans-=k;
        res=max(res,(double)(1.0*tmp/ans));
    }
    printf("%.2lf",res);
    return 0;
}