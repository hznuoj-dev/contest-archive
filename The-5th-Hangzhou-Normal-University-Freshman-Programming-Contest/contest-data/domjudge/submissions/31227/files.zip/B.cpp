#include<bits/stdc++.h>
using namespace std;

const int N = 1e6;
int a[N], b[N], c[N], d[N];

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	int n; cin >> n;
	for(int i = 1; i <= n; ++i) { cin >> a[i]; d[i] = -a[i]; } 
	for(int i = 1; i <= n; ++i) cin >> b[i]; 
	
	sort(a + 1, a + 1 + n); 
	sort(d + 1, d + 1 + n);
	sort(b + 1, b + 1 + n);
	
	int f1 = 1, f2 = 1; 
	c[0] = a[1] - b[1]; 
	d[0] = d[1] - b[1];
	for(int i = 1; i <= n; ++i) 
	{
		if(f1)
		{
			c[i] = a[i] - b[i];
			if(c[i] != c[i - 1])
				f1 = 0;
		}
		if(f2)
		{
			d[i] = d[i] - b[i];
			if(d[i] != d[i - 1])
				f2 = 0;
		}
	}
	
	if(f1)
	{
		if(f2)
		{
			cout << min((abs(d[n]) + 1), abs(c[n]));
		}
		else
		{
			cout << abs(c[n]);
		}
	}
	else
	{
		cout << "-1";
	}
}
