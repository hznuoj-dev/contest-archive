#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

int main() {
    int m, k, i, j;
    int a[5], b[5];
    int c[32], d[32];
    double t, res;
    cin >> m >> k;
    for (i = 0; i < 5; i++) {
        cin >> a[i];
    }
    for (i = 0; i < 5; i++) {
        cin >> b[i];
    }
    for (i = 0; i < 32; i++) {
        c[i] = 0;
        d[i] = 0;
    }
    for (i = 1; i < 32; i++) {
        for (j = 0; j < 5; j++) {
            if ((i >> j) & 1) {
                c[i] += a[j];
                d[i] += b[j];
            }
        }
    }
    res = 0;
    for (i = 1; i < 32; i++) {
        if (c[i] >= m) 
            t = d[i] * 1.0 / (c[i] - k);
        else
            t = d[i] * 1.0 / c[i];
        if (t > res)
            res = t;
    }
    printf("%.2f\n", res);
    return 0;
}