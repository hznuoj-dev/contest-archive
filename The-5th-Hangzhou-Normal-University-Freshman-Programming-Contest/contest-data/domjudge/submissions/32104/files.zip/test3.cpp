#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t;
	//cin >> t;
	t = 1;
	while (t--)
	{
		int n;
		cin >> n;
		vector<int>k(n), s(n);
		for (int i = 0;i < n;i++)
		{
			cin >> k[i];
		}
		s = k;
		sort(s.begin(), s.end());
		int ans, l, r;
		if (s.size() == 1)
		{
			cout << 1 << endl;
			return 0;
		}
		if (s.size() % 2)
		{
			l = s[(s.size() + 1) / 2];
			r = l;
			
		}
		else
		{
			l = s[s.size() / 2 - 1];
			r = s[s.size() / 2];
			if (l != r)r--, l++;
		}
		if (l==r&&(n - count(s.begin(), s.end(), r)) % 2)
		{
			cout << 0 << endl;
			return 0;
		}
		int cnt = 0;
		for (int i = 0;i < k.size();i++)
		{
			if (k[i] < l)cnt++;
			else if (k[i] > r)cnt--;
			if (cnt < 0)
			{
				cout << 0 << endl;
				return 0;
			}
		}
		cout << r - l + 1 << endl;
	}
	return 0;
}