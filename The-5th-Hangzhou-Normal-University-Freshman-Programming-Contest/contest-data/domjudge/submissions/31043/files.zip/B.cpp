#include <bits/stdc++.h>
#define endl '\n'
#define int long long
#define x first
#define y second

using namespace std;
typedef pair<int,int> PII;
int T;
int n, m;
string s;

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);

    cin >> n;
    vector<int> a(n),b(n);
    for(int i = 0 ; i < n ; i ++) cin >> a[i];
    for(int i = 0 ; i < n ; i ++) cin >> b[i];
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());

    set<int> s,t;
    for(int i = 0 ; i < n - 1 ; i ++) s.insert(a[i+1] - a[i]);
    for(int i = 0 ; i < n - 1 ; i ++) t.insert(b[i+1] - b[i]);

    if(s != t || s.size() > 1) {
        cout << -1 << endl;
        return 0;
    }

    int ans1 = abs(b[n-1]-a[n-1]), ans2 = 1 + abs(-a[0]-b[n-1]);

    cout << min(ans1, ans2) << endl;
}

