#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int m,k;
double a[6],b[6],ans;
int main()
{
    cin>>m>>k;
    for(int i=1;i<=5;i++)cin>>a[i];
    for(int i=1;i<=5;i++)cin>>b[i];
    for(int i=1;i<=5;i++)
    {
        double x=a[i];
        if(x>=m)x-=k;
        ans=max(ans,x/b[i]);
    }
    double sum=0,sum1=0;
    for(int i=1;i<=5;i++)
    { 
        sum+=a[i];
        sum1+=b[i];
    }
    if(sum>=m)sum-=k;
    ans=max(ans,sum/sum1);
    for(int i=1;i<=5;i++)
    { 
        double x=sum-a[i];
        if(x>=m)x-=k;
        ans=max(ans,x/sum1-b[i]);
    }
    for(int i=1;i<=5;i++)
    {
        for(int j=1;j<=5;j++)
        {
            if(j==i)continue;
            double x=a[i]+a[j],y=b[i]+b[j];
            if(x>=m)x-=k;
            ans=max(ans,x/y);
            double x1=sum-x,y1=sum1-y;
            if(x1>=m)x1-=k;
            ans=max(ans,x1/y1);
        }
    }
    printf("%.2lf",ans);
    return 0;
}
