#include <iostream>
#include <bits/stdc++.h>
using namespace std;
int m, k;

struct bin
{
	int price, remark;
	double x;
} b[10];

bool cmp(bin a, bin c)
{
	return a.x > c.x;
}

int main()
{
	cin >> m >> k;
	for (int i = 0; i < 5; i++)
	{
		cin >> b[i].price;
	}
	for (int i = 0; i < 5; i++)
	{
		cin >> b[i].remark;
	}
	for (int i = 0; i < 5; i++)
	{
		b[i].x = (double)b[i].remark / (double)b[i].price;
	}
	sort(b, b + 5, cmp);
	double maxx = 0;
	double sum = 0, sum2 = 0;
	for (int i = 0; i < 5; i++)
	{
		sum += b[i].price;
		sum2 += b[i].remark;
		if (sum >= m)
		{
			sum -= k;
		}
		maxx = max(sum2 / sum, maxx);
	}
	printf("%.2lf", maxx);
	return 0;
}

