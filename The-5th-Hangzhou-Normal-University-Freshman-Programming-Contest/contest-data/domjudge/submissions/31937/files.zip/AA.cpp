#include<bits/stdc++.h>
#define ll long long
#define rr read()
using namespace std;
const int N=5e5+5;
ll a[N],b[N],s[N];
int n;
int read()
{
    char ch=getchar(); int x=0,g=0;
    while (ch<'0'||ch>'9') g|=ch=='-',ch=getchar();
    while (ch>='0'&&ch<='9') x=x*10+(ch^48),ch=getchar();
    return g? -x:x;
}
bool check(int k)
{
	int top=0;
	for (int i=0;i<n;++i)
	if (a[i]<k) ++top;
	else if (a[i]>k){
		if (!top) return 0;
		else --top;
	}
	if (top) return 0;
	return 1;
}

int main()
{
	n=rr;
	for (int i=0;i<n;++i) //,A=max(A,a[i]),B=min(B,a[i]);
	{
		a[i]=rr;
	}
	if (n&1){
		for (int i=0;i<n;++i) b[i]=a[i];
		sort(b,b+n);
		if (check(b[n/2])) printf("1\n");
		else printf("0\n");
	}
	else{
		int l=0,r=1e9;
		for (int i=0;i<n;++i)
		if (i&1)
		{
			r=a[i]<r? a[i]:r;
			//r=min(r,a[i]);
		}
		else{
			l=l>a[i]? l:a[i];
			//l=max(l,a[i]);
		}
		if (l>r) printf("0\n");
		else if (l==r) printf("1\n");
		else printf("%d\n",r-l-1);
	}
	
	
	return 0;
}