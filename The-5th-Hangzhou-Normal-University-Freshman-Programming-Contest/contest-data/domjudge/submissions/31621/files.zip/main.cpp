/*
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
long long int a[N],b[N],de[N],de1[N];
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    bool st= false;
    int has_different=0;
    for (int i=0;i<n;i++) cin >> a[i];
    for (int i=0;i<n;i++)
    {
        cin >> b[i];
        de[i]=a[i]-b[i];
        de1[i]=(a[i]*-1)-b[i];
        if(i>0 && de[i]!=de[i-1]) st= true;
    }
    bool st1= false;
    if(st)
    {
        for (int i=0;i<n;i++)
        {
            if(i>0 && de1[i]!=de1[i-1]) st1= true;
        }
    }
    if(!st) cout << abs(de[0]);
    else if(st && !st1) cout << abs(de1[0])+1;
    else cout << -1;
    return 0;
}
*/
/*
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
const int mod=1e9+7;
long long a[N],fa[N];
int p[N],cnt[N];
int find(int x)
{
    if(p[x]!=x)
    {
        p[x]= find(p[x]);
    }
    return p[x];
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n,q;
    cin >> n >> q;
    for (int i=1;i<=n;i++)
    {
        cin >> a[i];
        p[i]=i;
        fa[i]=a[i];
        cnt[i]=1;
    }
    while (q--)
    {
        int num;
        cin >> num;
        if(num==1)
        {
            int a,b;
            cin >> a >> b;
            a= find(a);
            b= find(b);
            p[a]=b;
            fa[b]+=fa[a];
            cnt[b]+=cnt[a];
        }else if(num==2)
        {
            int a,b;
            cin >> a >> b;
            a= find(a);
            fa[a]+=b*cnt[a];
        }else {
            int b;
            cin >> b;
            cout << a[b]%mod << endl;
        }
        for (int i=1;i<=n;i++)
        {
            int father= find(i);
            a[i]+=fa[father];
        }
    }
}
*/
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=210;
int a[N];
int b[N];
int main(){
//    ios::sync_with_stdio(false);
//    cin.tie(0);
//    cout.tie(0);
    int m,k;
    cin >> m >> k;
    for (int i=0;i<5;i++) cin >> a[i];
    for (int i=0;i<5;i++) cin >> b[i];
    double res=0;
    for(int size=1;size<=5;size++)
    {
        if(size==1)
        {
            for (int i=0;i<5;i++)
            {
                double jiage=a[i];
                if(jiage>=m) jiage-=k;
                double pingjia=b[i];
                res= max(res,pingjia/jiage);
            }
        }else if(size==2)
        {
            for (int i=0;i<5;i++)
            {
                for (int j=0;j<5;j++)
                {
                    if(i==j) continue;
                    double jiage=a[i]+a[j];
                    if(jiage>=m) jiage-=k;
                    double pingjia=b[i]+b[j];
                    res= max(res,pingjia/jiage);
                }
            }
        }else if(size==3)
        {
            for (int i=0;i<5;i++)
            {
                for (int j=0;j<5;j++)
                {
                    for (int o=0;o<5;o++)
                    {
                        if(i==j || i==o || j==o) continue;
                        double jiage=a[i]+a[j]+a[o];
                        if(jiage>=m) jiage-=k;
                        double pingjia=b[i]+b[j]+b[o];
                        res= max(res,pingjia/jiage);
                    }
                }
            }
        }else if(size==4)
        {
            for (int i=0;i<5;i++)
            {
                double jiage=0,pingjia=0;
                for (int j=0;j<5;j++)
                {
                    if(j==i)continue;
                    jiage+=a[j];
                    pingjia+=b[j];
                }
                if(jiage>=m) jiage-=k;
                res= max(res,pingjia/jiage);
            }
        } else{
            double jiage=0,pingjia=0;
            for (int j=0;j<5;j++)
            {
                jiage+=a[j];
                pingjia+=b[j];
            }
            if(jiage>=m) jiage-=k;
            res= max(res,pingjia/jiage);
        }
    }
    printf("%.2f",res);
}