#include <bits/stdc++.h>
using namespace std;
const int N = 200005;
int a[N], ans = 0, stat[N];
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n, m, b;
	cin >> n >> m >> b;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
//	int flag = 0;
//	int index = n;
//	ans = min(b, a[n]);
//	stat[n] = a[n] - min(b, a[n]);
//	for(int i = n - 1; i >= 1; i--) {
//		stat[i] = stat[i + 1] + a[i];
//		if(index - m >= i && stat[i] >= b) {
//			ans += min(b, stat[i]);
//			stat[i] -= b;
//			index = i;
//		} else if(i == 1 && stat[i] < b) {
//			ans += stat[i];
//			stat[i] -= stat[i];
//		}
//	}
	long long sum = 0, res = 0;
	double x=ceil(n/m);
	for(int i = 1; i <= n; i++) {
		res += a[i];
		if(i>n-(x-1)*b&&(int)(i-(n-(x-1)*b))%m==0){
			if(res > b) {
				sum+=b;
				res-=b;
			}else{
				sum+=res;
				res=0;
			}
		}
	}
	cout << sum << "\n";
	return 0;
}
