#include<bits/stdc++.h>
#define int long long
using namespace std;
int n=5,m,k,a[200006],b[200006],fz,fm,ans,x,y;
map <int,int> mp;
signed main(){
	cin >> n;
	for (int i=1;i<=n;++i) {
		cin >> a[i];
		b[i]=a[i];
		mp[a[i]]++;
	}
	for (auto i:mp) {
		b[++m]=i.first;
	}
	x+=mp[b[1]];
	y+=mp[b[m]];
	for (int i=1,j=m;i<j;) {
		//cout << "i=" << i << ",j=" << j << ",x=" << x << ",y=" << y << endl;
		if (x==y) {
			if (i+1==j) {
				fz++;
				k=b[i]+1;
				ans+=b[j]-b[i]-1;
			}
			else if (i+1==j-1) {
				fz++;
				k=b[i+1];
				ans+=1;
			}
		}
		if (x>y) y+=mp[b[j]],j--;
		else     x+=mp[b[i]],i++;
	}
	if (ans) {
		//cout << "k=" << k << endl;
		for (int i=1;i<=n;++i) {
			if (a[i]<k) fm++;
			else if (a[i]>k) fm--;
			if (fm<0) ans=0;
		}
		if (fm) ans=0;
	}
	assert(fz<=1);
	cout << ans;
}
