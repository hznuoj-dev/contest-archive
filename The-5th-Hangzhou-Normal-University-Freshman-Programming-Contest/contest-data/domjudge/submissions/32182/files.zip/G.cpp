#include<bits/stdc++.h>

#define star std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

#define endl "\n";

using namespace std;

typedef long long ll;

typedef unsigned long long ull;

const ll maxn = 2e5+7;

const ll mod =1e9+7;

const ll itf =0x3f3f3f3f;

const ll ITF =0x3f3f3f3f3f3f3f3f;

double pi = 3.1415926535898;

int n,m,b;
ll a[maxn],dp[maxn],sum[maxn];
ll minn(ll x,ll y){
	if(x>y){
		return y;
	}else{
		return x;
	}
}
void solve(){
	cin>>n>>m>>b;
	dp[0]=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum[i]=sum[i-1]+a[i];
	}
//	cout<<sum[0]<<endl;
	for(int i=1;i<=n;i++){
		ll k=minn(b,sum[i]-dp[max(0,i-m)]);
		dp[i]=dp[max(0,i-m)]+k;
	}
	cout<<dp[n]<<endl;
//	for(int i=1;i<=n;i++){
//		for(int j=1;j<=2;j++){
//			dp[i][j]=max()
//		}
//	}
}
signed main()
{
star;
int _=1;
//cin>>_;
while(_--){
solve();
}
return 0;
}
//��дջ

