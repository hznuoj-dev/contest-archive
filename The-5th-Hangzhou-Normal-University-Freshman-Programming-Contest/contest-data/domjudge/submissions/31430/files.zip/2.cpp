#include<bits/stdc++.h>
using namespace std;
int  m,k,a[10],w[10];
double  ans;
void  dfs(int  s,double  c,double  p)
{
	if(s==6)
	{
	  if(c>=m)  c-=k;
	  if(c)  ans=max(ans,(double)(p/c));
	  return; 
	}
	
	dfs(s+1,c,p);
	dfs(s+1,c+a[s],p+w[s]);
}
int main()
{
	cin>>m>>k;
	
	for(int  i=1;i<=5;i++)
	cin>>a[i];
	
	for(int  i=1;i<=5;i++)
	cin>>w[i];
	
	dfs(1,0,0);
	
	printf("%.2lf",ans);
	return  0;
} 
