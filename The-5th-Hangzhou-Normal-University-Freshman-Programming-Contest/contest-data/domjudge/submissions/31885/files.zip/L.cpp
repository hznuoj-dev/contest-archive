#include<iostream>
#include<vector>
using namespace std;
int s[5]={1,2,4,8,16};
int main(){
	int m,k;
	cin>>m>>k;
	int price[5];
	int value[5];
	for(int i=0;i<5;i++){
		cin>>price[i];
	}
	for(int i=0;i<5;i++){
		cin>>value[i];
	}
	double most=0;
	for(int i=0;i<(1<<5);i++){
		int cost=0;
		int think=0;
		for(int j=0;j<5;j++){
			if(i&s[j]){
				cost+=price[j];
				think+=value[j];
			}
		}
		if(cost>=m){
			cost-=k;
		}
		double tmp = think*1.0/cost;
		most  = max(most,tmp);
	}
	char final[100];
	sprintf(final,"%.2lf",most);
	cout<<final;
	return 0;
}
