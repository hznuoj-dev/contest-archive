#include <iostream>
#include <algorithm>
#include <string.h>
#include <math.h>

#define int long long
using namespace std;

const int N = 2e5 + 10;

int a[N], b[N];

void solve()
{
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	for (int i = 1; i <= n; i++)
		cin >> b[i];
	if (n == 1)
	{
		if(a[1]*b[1]<0)
			cout << abs(abs(a[1]) - abs(b[1])) + 1 << endl;
		else
			cout << abs(a[1] - b[1]) << endl;
		return;
	}
	sort(a + 1, a + n + 1);
	sort(b + 1, b + n + 1);
	int flag = 1;
	int num = a[1] - b[1];
	for (int i = 2; i <= n; i++)
	{
		if (num != a[i] - b[i])
		{
			flag = 0;
			break;
		}
	}
	if (flag == 1)
		cout << abs(num) << endl;
	else
		cout << -1 << endl;
}

signed main()
{
	int t = 1;
	//	cin >> t;
	while (t--)
	{
		solve();
	}
	return 0;
}