#include <bits/stdc++.h>
#define maxn 200100
using namespace std;
int a[maxn],b[maxn];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int n,ans=0,ans1=1;  cin >> n;
	for(int i=1;i<=n;++i)  cin >> a[i];
	for(int i=1;i<=n;++i)  cin >> b[i];
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	for(int i=1;i<=n;++i){
		if(b[i]==a[i]){
			while(b[i]==a[i]&&i+1<=n)  ++i;
		}
		else if(b[i]>a[i]){
			ans=b[i]-a[i];
			while(b[i]>a[i]&&i+1<=n){
				if(ans!=b[i]-a[i])  break;
				++i;
			}
		}
		else if(b[i]<a[i]){
			ans=a[i]-b[i];
			while(b[i]<a[i]&&i+1<=n){
				if(ans!=a[i]-b[i])  break;
				++i;
			}
		}
		if(i!=n)  {ans=-1;break;}
	}
	for(int i=1;i<=n;++i)  b[i]=-b[i];
	sort(b+1,b+n+1);
	for(int i=1;i<=n;++i){
		if(b[i]==a[i]){
			while(b[i]==a[i]&&i+1<=n)  ++i;
		}
		else if(b[i]>a[i]){
			ans1=b[i]-a[i];
			while(b[i]>a[i]&&i+1<=n){
				if(ans1!=b[i]-a[i])  break;
				++i;
			}
		}
		else if(b[i]<a[i]){
			ans1=a[i]-b[i];
			while(b[i]<a[i]&&i+1<=n){
				if(ans1!=a[i]-b[i])  break;
				++i;
			}
		}
		if(i!=n)  {ans1=-1;break;}
	}
	if(ans==-1&&ans1==-1)  cout << -1 << '\n';
	else if(ans!=-1&&ans1!=-1)  cout << min(ans,ans1+1) << '\n';
	else cout << max(ans,ans1+1) << '\n';
    return 0;
}