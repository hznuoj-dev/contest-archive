#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

typedef long long LL;

const int N = 200010;

int n;
LL a[N], b[N];

int main()
{
    cin >> n;
    for (int i = 0; i < n; i ++ ) cin >> a[i];
    for (int i = 0; i < n; i ++ ) cin >> b[i];
    sort(a, a + n);
    sort(b, b + n);

    LL cnt = b[0] - a[0];
    int flag1 = 0, flag2 = 0;
    for (int i = 1; i < n; i ++ )
    {
        if (b[i] - a[i] != cnt)
        {
            flag1 = 1;
            break;
        }
    }
    if (flag1 == 0)
    {
        if (b[0] - a[0] > b[n - 1] + a[0])
        {
            cout << abs(b[n - 1] + a[0]) + 1;
        }
        else cout << abs(b[0] - a[0]);
    }
    else if (flag1 == 1)
    {
        for (int i = 0; i < n; i ++ ) a[i] = -a[i];
        sort(a, a + n);
        cnt = b[0] - a[0];
        for (int i = 1; i < n; i ++ )
        {
            if (b[i] - a[i] != cnt)
            {
                flag2 = 1;
                break;
            }
        }
        if (flag2 == 1)
        {
            cout << -1;
        }
        else if (flag2 == 0)
        {
            cout << abs(b[0] - a[0]) + 1;
        }
    }
    return 0;
}