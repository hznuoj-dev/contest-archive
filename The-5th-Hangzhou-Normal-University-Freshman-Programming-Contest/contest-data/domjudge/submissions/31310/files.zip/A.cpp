#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;

struct yb{
	double a,b;
	double c;
}q[6];
bool cmp(yb a,yb b){
	return a.c>b.c;
}
int main(){
	int m,k;
	cin>>m>>k;
	for(int i=1;i<=5;i++)cin>>q[i].a;
	for(int i=1;i<=5;i++)cin>>q[i].b;
	for(int i=1;i<=5;i++){
		if(q[i].a<m)
		q[i].c=q[i].b/q[i].a;
		else q[i].c=q[i].b/(q[i].a-k);
	}
	sort(q+1,q+6,cmp);
	double minn=q[1].c;
	double a=0,b=0,c=0;
	for(int i=1;i<=5;i++){
		a+=q[i].a;
		b+=q[i].b;
		if(a>=m)break;
	}
	c=b/(a-k);
	minn=max(minn,c);
	printf("%.2llf",minn);
}