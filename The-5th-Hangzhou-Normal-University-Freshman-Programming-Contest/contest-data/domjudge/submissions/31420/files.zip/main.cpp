
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
const int N=2e5+10;
#define LL long long
int n,a[N],mx[N][20],mn[N][20],lg[N],k,to[N],q;
LL ans[N];
int delta(int l,int r){
    int k=lg[r-l+1];
    return max(mx[l][k],mx[r-(1<<k)+1][k])-min(mn[l][k],mn[r-(1<<k)+1][k]);
}
LL seg[N<<2],tag[N<<2],sum[N<<2];
void pushup(int rt){
    seg[rt]=seg[rt<<1]+seg[rt<<1|1];
    sum[rt]=sum[rt<<1]+sum[rt<<1|1];
}
void pushdown(int rt){
    if(tag[rt]){
        sum[rt<<1]+=seg[rt<<1]*tag[rt];sum[rt<<1|1]+=seg[rt<<1|1]*tag[rt];
        tag[rt<<1]+=tag[rt];tag[rt<<1|1]+=tag[rt];tag[rt]=0;
    }
}

void modify(int rt,int l,int r,int k,int d){
    if(l==r){
        if(d)seg[rt]=1,sum[rt]=1;
        else seg[rt]=sum[rt]=0;
        return;
    }
    int mid=l+r>>1;pushdown(rt);
    if(mid>=k)modify(rt<<1,l,mid,k,d);
    else modify(rt<<1|1,mid+1,r,k,d);
}
void mdy(int rt,int l,int r,int ql,int qr,LL d){
    if(ql<=l && r<=qr){
        tag[rt]+=d;sum[rt]+=d*seg[rt];return;
    }
    pushdown(rt);int mid=l+r>>1;
    if(mid>=ql)mdy(rt<<1,l,mid,ql,qr,d);
    if(mid+1<=qr)mdy(rt<<1|1,mid+1,r,ql,qr,d);pushup(rt);
}
LL query(int rt,int l,int r,int ql,int qr){
    if(ql<=l && r<=qr)return sum[rt];
    int mid=l+r>>1;
    LL res=0;pushdown(rt);
    if(mid>=ql)res+=query(rt<<1,l,mid,ql,qr);
    if(mid+1<=qr)res+=query(rt<<1|1,mid+1,r,ql,qr);
    pushup(rt);return res;
}
vector<pr<int,int> >t[N];
vector<int>but[N];
struct bit{
    LL c[N];
    int lowbit(int x){return x&-x;}
    LL qry(int x){
        LL res=0;while(x){res+=c[x];x-=lowbit(x);}return res;
    }
    void cng(int x,LL d){
        while(x<=n){c[x]+=d;x+=lowbit(x);}
    }
    LL sig(int l,int r){
        if(l==1)return qry(r);return qry(r)-qry(l-1);
    }
}tr1,tr2,tr3;


int main(){//freopen("in.txt","r",stdin);
    scanf("%d%d%d",&n,&k,&q);int i,j;
    rep(i,1,n)scanf("%d",&a[i]),mx[i][0]=mn[i][0]=a[i];
    rep(i,2,n)lg[i]=lg[i>>1]+1;
    rep(j,1,19)for(i=1;i+(1<<j)-1<=n;++i)mn[i][j]=min(mn[i][j-1],mn[i+(1<<j-1)][j-1]),mx[i][j]=max(mx[i][j-1],mx[i+(1<<j-1)][j-1]);
    rep(i,1,n){
        int l=i,r=n,res;
        while(l<=r){
            int mid=l+r>>1;
            if(delta(i,mid)<=k)res=mid,l=mid+1;else r=mid-1;
        }
        to[i]=res;
        but[res].push_back(i);
    }
    rep(i,1,q){
        int x,y;scanf("%d%d",&x,&y);
        t[y].push_back(mkp(i,x));
    }
    rep(i,1,n){
        tr1.cng(i,1);tr2.cng(i,i-1);
        for(auto v:t[i]){
            ans[v.fi]=tr1.sig(v.se,i)*(LL)i-tr2.sig(v.se,i)+tr3.sig(v.se,i);
        }
        for(auto v:but[i]){
            tr1.cng(v,-1);tr2.cng(v,1-v);
            tr3.cng(v,to[v]-v+1);
        }
    }
    rep(i,1,q)printf("%lld\n",ans[i]);
}