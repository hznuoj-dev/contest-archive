#include<bits/stdc++.h>
#define ll long long
#define PII pair<int,int>
#define int long long
using namespace std;
constexpr ll mod=1e9+7; 
const ll inf=0x3f3f3f3f;  
const ll INF=0x3f3f3f3f3f3f3f3f;  
const double eps=1e-10;  
const int N=5e5+10;
// struct node{
//     friend bool operator<(const node&a,const node&b){
//         return ;
//     }
// }
//priority_queue<ll,vector<ll>,greater<ll>>pq;
inline int read(){int x=0,f=1;char ch=getchar();while(ch<'0'||ch>'9'){if(ch=='-')f=-1;ch=getchar();}while(ch>='0'&&ch<='9'){x=(x<<1)+(x<<3)+(ch^48);ch=getchar();}return x*f;}
inline void write(int x){char F[200];int tmp=x>0?x:-x;if(x<0) putchar('-');int cnt=0;while(tmp>0){F[cnt++]=tmp%10+'0';tmp/=10;}while(cnt>0)putchar(F[--cnt]);}
inline int combination(int n,int k){int sum=0;if (n==k||k==0){return 1;}else{return combination(n-1,k)+combination(n-1,k-1);}}
int h[N],e[N],ne[N],idx,w[N],p[N];
map<PII,int>mp;
bool st[N/2];
void add(int a,int b,int we){
    e[idx]=b,ne[idx]=h[a],w[idx]=we,h[a]=idx++;
}
void dfs(int u,int val){
    st[u]=true;
    for(int i=h[u];i!=-1;i=ne[i]){
        int j=e[i],we=w[i];
        if(!st[j])p[j]=we^val,dfs(j,p[j]);
    }
}
void solve(){
    int n=read(),temp=0;
    idx=0;
    memset(h,-1,sizeof h);
    for(int i=1;i<n;i++){
        int x=read(),y=read(),we=read();
        add(x,y,we);
        add(y,x,we);
        temp^=we;
    }
    int q=read();
    while(q--){
        int root=read(),val=read(),ans=temp^val;
        cout<<ans<<'\n';
    }
    //puts(ans>0?"YES":"NO");
    //puts(ans>0?"Yes":"No");
}

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int t=1;
  //  int t=read();
    while(t--){
        solve();
    }
}