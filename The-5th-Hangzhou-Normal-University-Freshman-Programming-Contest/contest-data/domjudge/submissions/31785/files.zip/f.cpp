#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N=2e5+7,MOD=1e9+7;
int n,q,d[N];
struct edge{
	int to,w;
};
vector<edge> e[N];

void dfs(int now,int last){
	for(auto x:e[now]){
		if(x.to==last) continue;
		d[x.to]=d[now]^x.w;
		dfs(x.to,now);
	}
}

void solve(){
	cin>>n;
	int x=0,cnt=0;
	for(int i=1;i<n;i++){
		int u,v,w;
		cin>>u>>v>>w;
		x^=w;
		e[u].push_back({v,w});
		e[v].push_back({u,w});
	}
	dfs(1,0);
	
	for(int i=1;i<=n;i++){
		if(e[i].size()%2==0){
			x^=d[i];
			cnt++;
		}
	}
	
	cin>>q;
	while(q--){
		int u,val;
		cin>>u>>val;
		if(cnt%2==0){
			cout<<x<<'\n';
		}else{
			cout<<(x^d[u]^val)<<'\n';
		}
	}
}

int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc=1;
//	cin>>tc;
	while(tc--) solve();
	return 0;
}
/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5

*/
