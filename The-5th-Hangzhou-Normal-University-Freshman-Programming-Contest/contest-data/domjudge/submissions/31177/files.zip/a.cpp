#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N=2e5+7;
int n,a[N],b[N];

void solve(){
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=n;i++) cin>>b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	ll ans=1e18;
	
	bool flag=true;
	for(int i=1;i<=n;i++){
		if(b[i]-a[i]!=b[1]-a[1]){
			flag=false;
			break;
		}
	}
	if(flag) ans=min(ans,abs(1ll*b[1]-a[1]));
	
	for(int i=1;i<=n;i++) a[i]=-a[i];
	sort(a+1,a+1+n);
	flag=true;
	for(int i=1;i<=n;i++){
		if(b[i]-a[i]!=b[1]-a[1]){
			flag=false;
			break;
		}
	}
	if(flag) ans=min(ans,1+abs(1ll*b[1]-a[1]));
	
	if(ans==1e18) ans=-1;
	cout<<ans<<'\n';
}

int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc=1;
//	cin>>tc;
	while(tc--) solve();
	return 0;
}
/*
3
1 2 3
4 5 6

*/
