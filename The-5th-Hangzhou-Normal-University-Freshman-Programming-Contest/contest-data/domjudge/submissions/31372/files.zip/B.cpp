#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
    int a;
    int b;
    double m;
}p[6];
bool cmp(Node a, Node b)
{
    return a.m > b.m;
}
int main()
{
    int m, k;
    int a[6] = {0};
    int b[6] = {0};
    cin >> m >> k;
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].a;
    }
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].b;
        p[i].m = (double)p[i].b / (double)p[i].a;
    }
    sort(p+1, p+5+1, cmp);
    double maxx = 0;
    int sum = 0;
    int ans = 0;
    int i = 0;
    for(i = 1; i <= 5; ++i){
         if(p[i].m >= 1.0){
            sum += p[i].a;
            ans += p[i].b;
         }
         else
            break;
    }
    if(sum >= m)
      sum -= k;
    maxx = (double)ans / (double)sum;
    if(sum < m){
        int flag = 0;
        for(int j = i; j <= 5; ++j){
             sum += p[j].a;
             ans += p[j].b;
             if(sum >= m){
                flag = 1;
                break;
             }
        }
        if(flag == 1){
            sum -= k;
            maxx = max(maxx, (double)ans / (double)sum);
            printf("%.2lf\n", maxx);
        }else{
            printf("%.2lf\n", maxx);
        }
        return 0;
    }
    printf("%.2lf\n", maxx);
    return 0;
}