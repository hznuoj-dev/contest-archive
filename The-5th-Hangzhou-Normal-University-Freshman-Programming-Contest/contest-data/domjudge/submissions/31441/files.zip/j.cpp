#include <bits/stdc++.h>
#define fp(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fb(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define go(u, i) for(int i = head[u]; i; i = e[i].nxt)
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
inline int rd() {
	register int x(0), f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline LL RD() {
	register LL x(0); register int f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline int int_rand(int l, int r){
	int res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
inline LL LL_rand(LL l, LL r){
	LL res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
const int maxn = 200010, maxm = 800010, mod = 1e9+7;
int n, m, K, f[maxn], t[maxn], deg[maxn];
queue<int> q;
struct edge{int to, nxt;}e[maxm];
int head[maxn], k;
inline void add(int u, int v){e[++k] = (edge){v, head[u]}, head[u] = k;}
inline int fpow(int a, int b, int ans = 1){
	for(; b; b >>= 1, a = 1ll*a*a%mod)if(b&1)ans = 1ll*ans*a%mod;
	return ans;
}
int main(){
	n = rd(), m = rd(), K = rd();
	fp(i, 1, m){
		int u = rd(), v = rd();
		add(u, v), ++deg[v];
	}
	fp(i, 1, n)if(!deg[i])q.push(i);
	while(q.size()){
		int u = q.front(); q.pop();
		go(u, i){
			f[e[i].to] = max(f[e[i].to], f[u]+1);
			if(!(--deg[e[i].to]))q.push(e[i].to);
		}
	}
	fp(i, 1, n)++t[f[i]];
	int sum = 0, ans = 0;
	fb(i, n, 0)ans = (ans + 1ll*sum*t[i])%mod, sum = (sum+t[i])%mod;
	ans = fpow(ans, K);
	printf("%d\n", ans);
	return 0;
}
