/**
 * HELLO WORLD
 * Author: ErodeesFleurs
**/

#include<bits/stdc++.h>

using namespace std;

#define quick ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug(a) cout<<#a<<"="<<a<<endl;
#define mm memset
#define rep(i,a,n) for (int i=a;i<n;i++)
#define per(i,a,n) for (int i=n-1;i>=a;i--)
#define llrep(i,a,n) for (ll i=a;i<n;i++)
#define llper(i,a,n) for (ll i=n-1;i>=a;i--)
#define pb push_back
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second
#define mod(x) ((x)%MOD)

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> PII;
typedef pair<ll,ll> PLL;

const int INF = 0x3f3f3f3f;
const ll L_INF=9223372036854775807;
const int MOD = 1e9+7;
const int NMAX = 500500;
const double eps = 1e-9;

ll gcd(ll a,ll b){return b==0?a:gcd(b,a%b);}
ll lcm(ll a,ll b){return a/gcd(a,b)*b;}
ll qmul(ll a,ll b){ll r=0;while(b){if(b&1)r=(r+a)%MOD;b>>=1;a=(a+a)%MOD;}return r;}
ll qpow(ll a,ll n){ll r=1;while(n){if(n&1)r=(r*a)%MOD;n>>=1;a=(a*a)%MOD;}return r;}
ll qpow(ll a,ll n,ll p){ll r=1;while(n){if(n&1)r=(r*a)%p;n>>=1;a=(a*a)%p;}return r;}
void exgcd(ll a,ll b,ll& d,ll& x,ll& y){if(!b) { d = a; x = 1; y = 0; }else{ exgcd(b, a%b, d, y, x); y -= x*(a/b); }}
ll inv(ll a, ll p){ll d,x,y;exgcd(a,p,d,x,y);return d == 1 ? (x+p)%p : -1;}

//CODE HERE//
ll n,m;
vector<ll>a;

bool check(ll x){
	stack<ll>s;
	rep(i,0,n){
		if(a[i]<x){
			s.push(1);
		}
		else if(a[i]>x){
			if(s.size()&&s.top()==1){
				s.pop();
				continue;
			}
			s.push(0);
		}
	}
	if(s.size())return 0;
	else return 1;
}

void solve(){
	cin>>n;
	a.resize(n);
	rep(i,0,n)cin>>a[i];
	vector<ll>b=a;
	sort(all(a));
	ll l=0,r=0;
	if(a.size()%2==0){
		l=a[a.size()/2-1];
		r=a[a.size()/2];
		if(r-l==1){
			cout<<0<<endl;
			return ;
		}
		else if(r-l!=0){
			l++,r--;
		}
	}
	else l=r=a[a.size()/2];
	ll ans=0;
	stack<ll>s;
//	cout<<l<<" "<<r<<endl;
	rep(i,0,n){
		if(b[i]<l){
			s.push(1);
		}
		else if(b[i]>r){
			if(s.size()&&s.top()==1){
				s.pop();
				continue;
			}
			s.push(0);
		}
	}
	if(s.size()) cout<<0<<endl;
	else cout<<r-l+1<<endl;
}

int main(){
    quick;
    int t=1;
//    cin>>t;
    while(t--)solve();
	return 0;
}
/*
4
4 10 5 10

4
1 4 4 10
*/
