#include<bits/stdc++.h>
#define ll long long
#define rr read()
using namespace std;
const int N=5e5+5;
ll a[N],b[N],s[N];
int n,L,R,A,B=1e7;
int read()
{
    char ch=getchar(); int x=0,g=0;
    while (ch<'0'||ch>'9') g|=ch=='-',ch=getchar();
    while (ch>='0'&&ch<='9') x=x*10+(ch^48),ch=getchar();
    return g? -x:x;
}
bool check(int k)
{
	int top=0;
	for (int i=0;i<n;++i)
	if (a[i]<k) ++top;
	else if (a[i]>k){
		if (!top) return 0;
		else --top;
	}
//	if (top) return 0;
	return 1;
}
bool check2(int k)
{
	int top=0;
	for (int i=0;i<n;++i)
	if (a[i]<k) ++top;
	else if (a[i]>k){
		if (!top) return 0;
		else --top;
	}
	if (top) return 0;
	return 1;
}
int main()
{
	n=rr;
	for (int i=0;i<n;++i) a[i]=rr;//,A=max(A,a[i]),B=min(B,a[i]);
	int l1=1,r1=2e5;
	while (r1-l1>1)
	{
		int mid=(l1+r1)/2;
		if (check(mid)) r1=mid;
		else l1=mid;
	}
	if (check(l1-1)) L=l1-1;
	else if (check(l1)) L=l1;
	else if ((check(r1)))L=r1;
//	printf("L=%d\n",L);
	int l2=1,r2=2e5;
	while (r2-l2>1)
	{
	//	printf("%d %d\n",l2,r2);
		int mid=(l2+r2)/2;
		if (check2(mid)) l2=mid;
		else r2=mid;
	}
	if (check(r2+1)) R=r2+1;
	else if (check2(r2)) R=r2;
	else R=l2;
	//printf("R=%d\n",R);
	if (L>R) printf("0\n");
	else printf("%d\n",R-L+1);
	return 0;
}