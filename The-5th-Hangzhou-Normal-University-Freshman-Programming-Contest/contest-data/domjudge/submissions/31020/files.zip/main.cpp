#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;

void solve() {
    int n;
    std::cin >> n;
    std::vector<int>a(n);
    for(auto &v : a) std::cin >> v;
    std::vector<int>b(a);
    std::sort(b.begin(), b.end());
    int p = n / 2;
    if(n & 1 || b[p] == b[p - 1]) {
        int k = b[p];
        int num = 0;
        for(auto v : a) {
            if(v < k) num++;
            if(v > k) num--;
            if(num < 0){
                std::cout << "0\n";
                return;
            }
        }
        if(num != 0) std::cout << "0\n";
        else std::cout << "1\n";
    } else {
        int k = b[p] - 1;
        int num = 0;
        for(auto v : a) {
            if(v < k) num++;
            if(v > k) num--;
            if(num < 0){
                std::cout << "0\n";
                return;
            }
        }
        if(num != 0) std::cout << "0\n";
        else std::cout << b[p] - b[p - 1] - 1 << '\n';
    }
}

int main() {
    int T = 1;
    //std::cin >> T;
    while(T--) {
        solve();
    }
}