#include<iostream>
#include<algorithm>
using namespace std; 
const int N = 200005; 
long long a[N],b[N]; 
int n; 

bool check()
{
	for(int i = 2;i<=n;++i){
		if(a[i]-a[i-1]!=b[i]-b[i-1])
		return false; 
	}
	return true; 
}
int main(){
	cin>>n; 
	for(int i =1;i<=n;++i){
		cin>>a[i]; 
	}
	for(int j =1;j<=n;++j){
		cin>>b[j]; 
	}
	sort(a+1,a+n+1); 
	sort(b+1,b+n+1); 
	long long ans = 3e9; 
	bool f = false; 
	if(check()){
		ans = abs(a[1]-b[1]); 
		f = true; 
	}
	for(int i = 1;i<=n;++i)
	b[i]=-b[i]; 
	sort(b+1,b+n+1); 
	if(!check() && !f){
		cout<<-1;
		return 0; 
	} 
	else{
		ans = min(ans, 1+abs(a[1]-b[1]));
	}
	cout<<ans; 
	return 0;  
}
