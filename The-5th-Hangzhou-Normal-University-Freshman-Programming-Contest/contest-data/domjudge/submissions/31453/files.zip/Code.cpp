#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 3e5+7,inf = 1e18+7;
typedef long long ll;

int a[N];
stack<int>p;
void solve(){
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
	}
	int l = 0,r = inf;
	for (int i = 1; i <= n; i++){
		if (p.empty()){
			p.push(a[i]);
		}else{
			if (!p.empty() && p.top() <= a[i]){
				int L = p.top();
				p.pop();
				int R = a[i];
				l = max(l,L);
				r = min(r,R);				
			}else{
				p.push(a[i]);				
			}			
		}
	}
	int ans = 0;
	if (p.empty()){
		if (l == r){
			ans = 1;
		}else if (l < r){
			ans = r - l - 1;
		}
	}
	cout << ans << '\n';
	
}

signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc = 1;
//	cin >> tc;
	while (tc--){
		solve();
	}
	return 0;
}
