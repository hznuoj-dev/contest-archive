#include<bits/stdc++.h>
using namespace std;
void solve(){
	int n;
	cin>>n;
	long long a[n+1],b1[n+1],b2[n+1],c1[n+1],c2[n+1];
	for(int i=1;i<=n;i++)
		cin>>a[i];
	for(int i=1;i<=n;i++){
		cin>>b1[i];
		b2[i]=-b1[i];
	}
		
	sort(a+1,a+n+1);
	sort(b1+1,b1+n+1);
	sort(b2+1,b2+n+1);
	set<long long>s1,s2;
	for(int i=1;i<=n;i++){
		c1[i]=fabs(b1[i]-a[i]);
		c2[i]=fabs(b2[i]-a[i]);
		s1.insert(c1[i]);
		s2.insert(c2[i]);
	}
	if(s1.size()>1&&s2.size()>1){
		cout<<-1<<endl;
	}else if(s1.size()>1&&s2.size()==1){
		cout<<c2[1]+1<<endl;
	}else if(s2.size()>1&&s1.size()==1){
		cout<<c1[1]<<endl;
	}else{
		cout<<min(c1[1],c2[1]+1)<<endl;
	}
}
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t;
	//cin>>t;
	t=1;
	while(t--){
		solve();
	}
	return 0;
}
