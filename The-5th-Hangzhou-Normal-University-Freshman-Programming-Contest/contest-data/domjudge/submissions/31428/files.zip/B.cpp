#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
    int a;
    int b;
    double m;
}p[6];
bool cmp(Node a, Node b)
{
    return a.m > b.m;
}
int main()
{
    int m, k;
    cin >> m >> k;
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].a;
    }
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].b;
        p[i].m = (double)p[i].b / (double)p[i].a;
    }
    sort(p+1, p+5+1, cmp);
    double maxx = 0;
    int sum = 0;
    int ans = 0;
    int i = 0;
    for(i = 1; i <= 5; ++i){
         if(p[i].m >= 1.0){
            sum += p[i].a;
            ans += p[i].b;
         }
         else
            break;
    }
    int flag = 0;
    if(sum >= m){
      sum -= k;
      flag = 1;
    }
    maxx = (double)ans / (double)sum;
        for(int j = i; j <= 5; ++j){
             sum += p[j].a;
             ans += p[j].b;
             if(sum >= m && flag == 0){
                flag = 1;
                sum -= k;
                //double tmp = (double)ans / (double)sum;
                //maxx = max(maxx, tmp;)
             }
             double temp = (double)ans / (double)sum;
             maxx = max(temp, maxx);
        }
    printf("%.2lf\n", maxx);
    return 0;
}