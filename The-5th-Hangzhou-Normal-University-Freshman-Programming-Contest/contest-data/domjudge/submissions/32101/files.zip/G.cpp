#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int long long
const ll N=5e5+7;
const ll mod=1e9+7;
const ll inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
const double eps=1e-6;

vector<pair<int,int> > adj[N];
int wigh[N],f=0;
void dfs(int x,int fath)
{
	for(int i=0;i<adj[x].size();i++)
	{
		if(adj[x][i].first!=fath)
		{
			wigh[adj[x][i].first]=adj[x][i].second^wigh[x];
			f^=wigh[adj[x][i].first];
			dfs(adj[x][i].first,x);
		}
	
	}
}
void solve()
{
	int n;
	cin>>n;
	for(int i=1;i<n;i++)
	{
		int u,v,w;
		cin>>u>>v>>w;
		adj[u].push_back({v,w});
		adj[v].push_back({u,w});
	}
	dfs(1,0);
	int q;
	cin>>q;
	for(int i=0;i<q;i++)
	{
		int u,x;
		cin>>u>>x;
		if(n%2==0) cout<<f<<"\n";
		else cout<<(f^(x^wigh[u]))<<"\n";
	}
}
signed main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int _=1;
//	cin>>_;
	while(_--)
	{
		solve();
	}
	return 0;
}


