#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
    ll a;
    ll b;
    double m;
}p[6];
bool cmp(Node l, Node r)
{
    return l.m > r.m;
}
int main()
{
    ll m, k;
    ll sum = 0;
    ll ans = 0;
    cin >> m >> k;
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].a;
        sum += p[i].a;
    }
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].b;
        p[i].m = (double)p[i].b / (double)p[i].a;
        ans += p[i].b;
    }
    sort(p+1, p+5+1, cmp);
    double maxx = 0;
    if(sum >= m)
      sum -= k;
    double temp;
    temp = (double)ans / (double)sum;
    maxx = max(p[1].m, temp);
    sum = 0;
    ans = 0;
    for(int i = 1; i <= 4; ++i){
        sum = p[i].a;
        ans = p[i].b;
        for(int j = i + 1; j <= 5; ++j){
             sum += p[j].a;
             ans += p[j].b;
             if(sum >= m)
               sum -= k;
             double tmp = (double)ans / (double)sum;
             maxx = max(maxx, tmp);
             sum = p[i].a;
             ans -= p[j].b;
        }
    }
    //3
    for(int i = 1; i <= 3; ++i){
        sum = p[i].a;
        ans = p[i].b;
        for(int j = i + 1; j <= 4; ++j){
            sum += p[j].a;
            ans += p[j].b;
             for(int l = j + 1; l <= 5; ++l){
                 sum += p[l].a;
                 ans += p[l].b;
                 if(sum >= m)
                    sum -= k;
                double tmp = (double)ans / (double)sum;
                maxx = max(maxx, tmp);
                sum = p[i].a + p[j].a;
                ans -= p[l].b;
             }
             sum = p[i].a;
             ans -= p[j].b;
        }
    }
    //4
    for(int i = 1; i <= 2; ++i){
        sum = p[i].a;
        ans = p[i].b;
        for(int j = i + 1; j <= 3; ++j){
            sum += p[j].a;
            ans += p[j].b;
            for(int l = j + 1; l <= 4; ++l){
                sum += p[l].a;
                ans += p[l].b;
                for(int r = l + 1; r <= 5; ++r){
                    sum += p[r].a;
                    ans += p[r].b;
                    if(sum >= m)
                      sum -= k;
                    double tmp = (double)ans / (double)sum;
                    maxx = max(maxx, tmp);
                    sum = p[i].a + p[j].a + p[l].a;
                    ans -= p[r].b;
                }
                 sum = p[i].a + p[j].a;
                 ans -= p[l].b;
            }
             sum = p[i].a;
             ans -= p[j].b;
        }
    }
    printf("%.2lf\n", maxx);
    return 0;
}
