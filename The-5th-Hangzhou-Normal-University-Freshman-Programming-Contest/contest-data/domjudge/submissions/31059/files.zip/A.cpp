#include <bits/stdc++.h>

using namespace std;

const int N = 1e6 + 10;

int n;
int a[N];
int b[N];
int sum[N];
int num = 0;

int main()
{
    int max = 0;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        cin >> a[i];
        b[a[i]]++;
        if (a[i] > max)
            max = a[i];
    }

    sort(a, a + n);

    sum[0] = b[0];
    for (int i = 1; i <= max; i++)
    {
        sum[i] = sum[i - 1] + b[i];
    }

    for (int i = 0; i <= max; i++)
    {
        if (sum[i - 1] == sum[max] - sum[i])
            num++;
    }
    cout << num << endl;
    return 0;
}