#include<bits/stdc++.h>
using namespace std;
const int N=1e6+5;
int n,a[N],b[N],ans;
bool flag;
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]);
	for(int i=1;i<=n;++i)scanf("%d",&b[i]);
	sort(a+1,a+n+1);sort(b+1,b+n+1);
	flag=1;
	for(int i=2;i<=n;++i)
	{
		if(b[i]-b[i-1]!=a[i]-a[i-1])
		{
			flag=0;
			break;
		}
	}
	if(!flag)
	{
		puts("-1");
		return 0;
	}
	ans=abs(a[1]-b[1]);
	ans=min(ans,abs(-a[n]-b[1])+1);
	printf("%d\n",ans);
	return 0;
}
