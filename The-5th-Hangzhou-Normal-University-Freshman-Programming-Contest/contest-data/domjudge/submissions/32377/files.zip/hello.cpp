// #include <bits/stdc++.h>
// #define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
// #define debug(x) cerr << #x << '=' << x << endl
// #define all(x) (x).begin(), (x).end()
// #define int long long
// #define mpk make_pair
// #define endl '\n'
// using namespace std;
// typedef unsigned long long ULL;
// typedef long long ll;
// typedef pair<int, int> pii;
// typedef pair<ll, ll> pll;
// const int inf = 0x3f3f3f3f;
// const ll INF = 0x3f3f3f3f3f3f3f3f;
// const int mod = 1e9 + 7;
// const double eps = 1e-9;
// const int N = 5e5 + 10, M = 4e5 + 10;

// int n, q;
// vector<pii> g[N];
// // vector<pii> qry[N];
// // int ans[N];
// int ans;
// int a[N];

// void dfs(int u, int par)
// {
//     for (auto [v, w] : g[u])
//     {
//         if (v == par)
//             continue;
//         a[v] = a[u] ^ w;
//         ans ^= a[v];
//         dfs(v, u);
//     }
// }

// void solve()
// {
//     cin >> n;
//     for (int i = 1; i < n; ++i)
//     {
//         int u, v, w;
//         cin >> u >> v >> w;
//         g[u].push_back({v, w});
//         g[v].push_back({u, w});
//     }
//     cin >> q;
//     while (q--)
//     {
//         int u, x;
//         cin >> u >> x;
//         a[u] = x;
//         ans = a[u];
//         dfs(u, -1);
//         cout << ans << endl;
//     }
// }
// signed main(void)
// {
//     Zeoy;
//     int T = 1;
//     // cin >> T;
//     while (T--)
//     {
//         solve();
//     }
//     return 0;
// }
#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n, m, k;
int a[N];

void solve()
{
    cin >> n >> m >> k;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    int ans = 0;
    int sum = 0;
    int pre = -1;
    int p = 0;
    // for (int i = 1; i * m + 1 <= n; ++i)
    // {
    //     p = i;
    // }
    // p = p * m + 1;
    for (int i = 1; i <= n; ++i)
    {
        sum += a[i];
        if ((pre == -1 || i - pre == m) && i + m < n)
        {
            if (sum >= k)
            {
                ans += k;
                sum -= k;
            }
            else
            {
                ans += sum;
                sum = 0;
            }
            pre = i;
        }
        else if (i + m >= n && i - pre >= m && sum >= k)
        {
            ans += k;
            sum -= k;
            pre = i;
        }
        else if (i == n && i - pre >= m)
        {
            if (sum)
            {
                ans += sum;
                sum = 0;
            }
        }
    }
    cout << ans << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}