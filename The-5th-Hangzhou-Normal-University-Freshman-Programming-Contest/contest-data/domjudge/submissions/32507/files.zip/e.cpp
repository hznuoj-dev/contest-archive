/*
 * @Author: JSY
 * @Date: 2023-05-27 13:32:17
 * @Last Modified by: JSY
 * @Last Modified time: 2023-05-27 13:32:17
*/

#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int, int>
#define IOS ios::sync_with_stdio(0);cin.tie(0), cout.tie(0)
const int N = 200010 , mod = 1e9+7;
int a[N];
int h[N];
int p[N];
int siz[N];
int ku[N];

int find(int x){
    if(x != p[x]) p[x] = find(p[x]);
    return p[x];
}

signed main(){
    IOS;
    int n,q;
    cin >> n >> q;
    for(int i=1;i<=n;i++){
        cin >> a[i];
        p[i] = i;
        h[i] = a[i];
        siz[i] = 1;
    } 
    while(q--){
        int pos,x,y;
        cin >> pos;
        for(int i=1;i<=n;i++){
            ku[i] += h[find(i)];
        }
        if(pos == 1){
            cin >> x >> y;
            int px = find(x) , py = find(y);
            p[px] = py;
            h[py] = (h[py] + h[px]) % mod;
            siz[py] += siz[px];
        }else if(pos == 2){
            cin >> x >> y;
            int px = find(x);
            h[px] = (h[px] + siz[px]*y) % mod;
        }else{
            cin >> x;
            cout << ku[x] << '\n';
        }
    }
    return 0;
}