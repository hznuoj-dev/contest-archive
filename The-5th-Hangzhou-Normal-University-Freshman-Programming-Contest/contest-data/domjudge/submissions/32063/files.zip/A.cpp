#include<bits/stdc++.h>
using namespace std;
const int N = 2e5 + 10;
int n;
int a[N] , b[N];
int res , k;
bool flag;
int maxn , minn;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin >> n;
	for(int i = 1 ; i <= n ; i ++)cin >> a[i];
	int pos = 1;
	maxn = 1e9;
	for(int i = 2 ; i <= n ; i ++)
	{
		if(a[i] >= a[i - 1] && i != n)
		{
			continue;
		}
		else
		{
			if(i == n)i ++;
			if((i + pos) % 2 == 0)
			{
				int l = (i - 1 + pos) / 2 , r = (i - 1 + pos) / 2 + 1;
				if(a[l] == a[r])
				{
					int shaobin = a[l];
					if(a[l] < minn || a[l]  > maxn)
					{
						flag = true;
						break;
					}
					for(; r <= i - 1 ; r ++ , l --)
					{
						if(a[l] == shaobin && a[r] == shaobin)
						{
							continue;
						}
						else if(a[l]  == shaobin && a[r]  != shaobin)
						{
							flag = true;
							break;
						}
						else if(a[l]  != shaobin && a[r] == shaobin)
						{
							flag = true;
							break;
						}
					}
					if(flag)
					{
						break;
					}
					else
					{
						minn = shaobin , maxn = shaobin;
						pos = i;
					}
				}
				else
				{
					if(a[r] - a[l] > 1 && (a[l] + 1 >= minn || a[r] - 1 <= maxn))
					{
						minn = max(minn , a[l] + 1) , maxn = min(maxn , a[r] - 1);
						pos = i;
					}
					else
					{
						flag = true;
						break;
					}
				} 
			}
			else
			{
				int mid = (pos + i - 1) / 2;
				int shaobin = a[mid];
				if(a[mid] < minn || a[mid]  > maxn)
					{
						flag = true;
						break;
					}
				for(int l = mid - 1 , r = mid + 1 ; r <= i - 1 ; r ++ , l --)
				{
					if(a[l] == shaobin && a[r] == shaobin)
					{
						continue;
					}
					else if(a[l]  == shaobin && a[r]  != shaobin)
					{
						flag = true;
						break;
					}
					else if(a[l]  != shaobin && a[r] == shaobin)
					{
						flag = true;
						break;
					}
				}
				if(flag)
				{
					break;
				}
				else
				{
					minn = shaobin , maxn = shaobin;
					pos = i;
				}
			}
		}
	}
	if(flag)
	{
		cout << 0 << '\n';
	}else
	{
		cout << maxn - minn + 1 << '\n';
	}
	return 0;
}