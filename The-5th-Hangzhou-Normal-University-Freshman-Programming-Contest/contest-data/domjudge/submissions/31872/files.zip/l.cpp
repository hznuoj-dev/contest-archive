#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
struct node{
	int pj,jg;
	double xjb;
}a[6];
bool cmp(node a,node b){
	if(a.xjb==b.xjb){
		return a.jg<b.jg;
	}else{
		return a.xjb>b.xjb;
	}
}
int main(){
	int m,k;
	cin>>m>>k;
	for(int i=1;i<=5;i++)
		cin>>a[i].jg;
	for(int i=1;i<6;i++)	
		cin>>a[i].pj;
	for(int i=1;i<=5;i++)	
		a[i].xjb=a[i].pj*1.0/a[i].jg;
	sort(a+1,a+6,cmp);
	int zj=0,zp=0,num=1;
	while(zj<m&&num<=5){
		zj+=a[num].jg;
		zp+=a[num].pj;
		num++;
	}
	if(zj>=m) zj-=k;
	printf("%.2f",max(a[1].xjb,zp*1.0/zj));
	return 0;
}
