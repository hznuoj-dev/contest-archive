#include <bits/stdc++.h>
#define eps 1e-8
#define maxn 210
using namespace std;
struct node{
	double a,b;
}s[maxn];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    double m,k;
	cin >> m >> k;
	double ans=-1;
	for(int i=1;i<=5;++i)  cin >> s[i].a;
	for(int i=1;i<=5;++i)  cin >> s[i].b;
	for(int i=1;i<(1<<5);++i){
		double sum=0,pri=0;
		for(int j=0;j<5;++j){
			if((i>>j)&1)  pri+=s[j+1].a,sum+=s[j+1].b;
		}
		if(pri-m>-eps)  pri-=k;
		ans=max(ans,sum/pri);  
	}
	cout << fixed << setprecision(2) << ans << '\n';
    return 0;
}