#include <bits/stdc++.h>
using namespace std;
const int M=200005;
long long a[M],b[M],n;
long long c[M],d[M],e[M];
long long ans1=1<<30,ans2=1<<30;
bool cmp(long long q,long long w){
	return q<w;
}
long long Labs(long long x){
	if(x<0) return -x;
	return x;
}
long long Lmin(long long x,long long y){
	if(x<y) return x;
	return y;
}
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%lld",&b[i]);
	}
	sort(a+1,a+1+n,cmp);
	sort(b+1,b+1+n,cmp);
	for(int i=1;i<n;i++){
		c[i]=a[i+1]-a[i];
		d[i]=b[i+1]-b[i];
	}
	n--;
	bool flag=true;
	for(int i=1;i<=n;i++){
		if(c[i]!=d[i]){
			flag=false;
			break;
		}
	}
	if(flag){
		ans1=Labs(a[1]-b[1]);
	}
	for(int i=1;i<=n;i++){
		int j=n-i+1;
		e[j]=c[i];
	}
	flag=true;
	for(int i=1;i<=n;i++){
		if(e[i]!=d[i]){
			flag=false;
			break;
		}
	}
	if(flag){
		ans2=Labs(a[1]+b[1+n])+1;
	}
	long long ans=Lmin(ans1,ans2);
	if(ans==1<<30) puts("-1");
	else printf("%lld",ans);
	return 0;
}
