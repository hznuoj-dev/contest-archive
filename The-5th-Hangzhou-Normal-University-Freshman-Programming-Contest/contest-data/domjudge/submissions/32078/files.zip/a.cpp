#include <bits/stdc++.h>
using namespace std;
#define int long long
int n;
int a[200005]={};
bool check(int x)
{
	stack<char>c;
	for(int i=1;i<=n;i++)
	{
		if(a[i]<x)c.push('(');
		else if(a[i]>x)
		{
			if(c.empty())return false;
			else c.pop();
		}
	}
	if(c.size())return true;
	return true;
}
bool check1(int x)
{
	stack<char>c;
	for(int i=1;i<=n;i++)
	{
		if(a[i]<x)c.push('(');
		else if(a[i]>x)
		{
			if(c.empty())return false;
			else c.pop();
		}
	}
	if(c.size())return true;
	return false;
}
signed main()
{
	ios::sync_with_stdio(false);cin.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	int l=1,r=200005;
	while(l<=r)
	{
		int mid=(l+r)>>1;
		if(check(mid))r=mid-1;
		else l=mid+1;
	}
	int ans=l;
	l=1,r=200005;
	while(l<=r)
	{
		int mid=(l+r)>>1;
		if(check1(mid))r=mid-1;
		else l=mid+1;
	}
	int res=r;
	cout<<res-ans+1<<'\n';
	return 0;
}
