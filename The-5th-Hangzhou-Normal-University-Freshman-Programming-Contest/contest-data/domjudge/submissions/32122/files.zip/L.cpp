#include <iostream>
using namespace std;

struct info{
	int price = 0, value = 0;
}a[6];
int m, k;
double e[32];
int sum[32], pj[32];

int main(){
	cin >> m >> k;
	for (int i = 1; i <= 5; i++)
		cin >> a[i].price;
	for (int i = 1; i <= 5; i++)
		cin >> a[i].value;

	double ans = 0;
	for (int i = 0; i <= 31; i++){
		int n = i;
		for (int j = 1; j <= 5 && n > 0; j++){
			if (n % 2 == 1){
				sum[i] += a[j].price;
				pj[i] += a[j].value;
			}
			n /= 2;
		}
		if (sum[i] >= m){
			e[i] = (pj[i] * 1.0) / (sum[i] - k);
		}
		else e[i] = (pj[i] * 1.0) / sum[i];
		ans = max(e[i], ans);
	}
	printf("%.2lf\n", ans);
	return 0;
}