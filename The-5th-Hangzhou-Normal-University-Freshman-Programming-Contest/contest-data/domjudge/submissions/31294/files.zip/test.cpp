#include <map>
#include <set>
#include <array>
#include <cmath>
#include <queue>
#include <stack>
#include <tuple>
#include <cctype>
#include <cstdio>
#include <string>
#include <vector>
#include <cassert>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <algorithm>
#include <functional>
#include <unordered_map>
using namespace std;

#define db double
#define il inline
#define fir first
#define sec second
#define eps (1e-10)
#define pb push_back
#define ll long long
#define mkp make_pair
#define eb emplace_back
#define pii pair<int, int>
#define lowbit(a) (a & (-a))
#define SZ(a) ((int)a.size())
#define ull unsigned long long
#define all(a) a.begin(), a.end()
#define split cout << "=========\n";
#define GG { cout << "NO\n"; return; }
#define pll pair<long long, long long>
#define equals(a, b) (fabs((a) - (b)) < eps)

constexpr int ON = 0;
constexpr int CW = -1;
constexpr int CCW = 1;
constexpr int BACK = 2;
constexpr int FRONT = -2;
const db pi = acos(-1.000);
constexpr int maxn = 3e5 + 50;
constexpr int INF = 0x3f3f3f3f;
constexpr ll LINF =  0x3f3f3f3f3f3f3f3f;
constexpr ll mod = 998244353; /* 1e9 + 7 */
constexpr int dir[8][2] = {-1, 0, -1, 1, 0, 1, 1, 1, 1, 0, 1, -1, 0, -1, -1, -1};


void solve(int cas) {
    int n; cin >> n;
    if (n == 1) {
        cout << "1\n";
        return ;
    }
    vector<int> a(n);
    for (int i = 0; i < n; ++i) cin >> a[i];
    int x = *max_element(all(a));
    vector<int> cnt(x + 1, 0);
    vector<int> b = a;
    sort(all(b));
    b.erase(unique(all(b)));
    for (int i = 0; i < n; ++i) {
        cnt[a[i]]++;
    }
    int sum = 0;
    int k = - 1;
    int l = -1, r = -1;
    for (int i = 0; i < SZ(b); ++i) {
        if (sum == n - cnt[b[i]] - sum)
            k = b[i];
        sum += cnt[b[i]];
    }
    sum = 0;
    for (int i = 0; i < SZ(b) - 1; ++i) {
        sum += cnt[b[i]];
        if (b[i + 1] - b[i] > 1) {
            if (sum == n - sum) {
                l = b[i] + 1;
                r = b[i + 1] - 1;
            }
        }
    }
    if (k < 0 && l < 0 && r < 0) {
        cout << "0\n";
        return ;
    }
    if (k != -1) {
        int now = 0;
        for (int i = 0; i < n; ++i) {
            if (a[i] < k) now++;
            else if (a[i] > k) now--;
            if (now < 0) {
                cout << "-1\n";
                return ;
            }
        }
        cout << "1\n";
    } else {
        int now = 0;
        for (int i = 0; i < n; ++i) {
            if (a[i] < l) now++;
            else if (a[i] > r) now--;
            if (now < 0) {
                cout << "-1\n";
                return ;
            }
        }
        cout << r - l + 1 << '\n';
    }
}


signed main() {
    // cout << fixed << setprecision(10);
    ios::sync_with_stdio(false); cin.tie(nullptr);
    // int T; cin>>T; while (T--)
    solve(1);
    return 0;
}
