#include <iostream>
#include <algorithm>

using namespace std;

const int N = 200010;

int n;
int a[N], b[N];

int main()
{
    cin >> n;
    for (int i = 0; i < n; i ++ )
    {
        cin >> a[i];
        b[i] = a[i];
    }
    sort(b, b + n);

    int idx1, idx2;
    int flag = 1;
    if (n % 2 != 0)
    {
        idx1 = b[n / 2];
        int c = 0, d = 0;
        for (int i = 0; i < n; i ++ )
        {
            if (a[i] < idx1) c ++ ;
            if (a[i] > idx1) d ++ ;
            if (c < d)
            {
                flag = 0;
                break;
            }
        }
        if (c != d) flag = 0;
        if (flag == 0) cout << 0;
        else cout << 1;
    }
    else if (n % 2 == 0)
    {
        int flag1 = 1, flag2 = 1;
        idx1 = b[n / 2 - 1];
        idx2 = b[n / 2];
        int c = 0, d = 0;
        for (int i = 0; i < n; i ++ )
        {
            if (a[i] < idx1) c ++ ;
            if (a[i] > idx1) d ++ ;
            if (c < d)
            {
                flag1 = 0;
                break;
            }
        }
        if (c != d) flag1 = 0;
        c = 0, d = 0;
        if (idx1 != idx2)
            for (int i = 0; i < n; i ++ )
            {
                if (a[i] < idx2) c ++ ;
                if (a[i] > idx2) d ++ ;
                if (c < d)
                {
                    flag2 = 0;
                    break;
                }
            }
        if (c != d) flag2 = 0;
        int res = idx2 - idx1 + 1;
        if (flag1 == 0) res -- ;
        if (flag2 == 0) res -- ;
        cout << res;
    }
    return 0;
}