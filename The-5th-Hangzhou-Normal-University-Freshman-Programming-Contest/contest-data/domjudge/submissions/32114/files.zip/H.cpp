#include<bits/stdc++.h>

using namespace std;
#define int long long 
const int N = 10;
int a[N], p[N], vis[N];

void solve(){
	int n, k;
	cin >> n >> k;
	for(int i = 1; i <= n; ++ i)cin >> a[i];
	if(k == n - 1){
		cout << -1 << '\n';
		return;
	}
	int sum = 0;
	for(int i = 1; i <= n; ++ i)if(a[i] == i) ++sum, vis[i] = 1;
	if(sum > k){
		cout << (sum - k + 1) / 2;
		return;
	}
	int ans = 0;
	for(int i = 1; i <= n; ++ i){
		if(vis[i] or a[i] == i)continue;
		int k = i, sum = 0;
		while(1){
			vis[i] = 1;
			if(k == i)break;
			++sum;
			k = a[i];
		}
		p[sum]++;
	}
	for(int i = 1; i <= n; ++ i){
		while(p[i]){
			if(k >= i)k-=i,ans += i - 1;
			else goto A;
		}
	}
	A:;
	cout << ans + k;
}

signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	int t = 1;
	//cin >> t;
	while(t--)solve();
	return 0;
}
