#include <bits/stdc++.h>
#define fp(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fb(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define go(u, i) for(int i = head[u]; i; i = e[i].nxt)
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
inline int rd() {
	register int x(0), f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline LL RD() {
	register LL x(0); register int f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline int int_rand(int l, int r){
	int res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
inline LL LL_rand(LL l, LL r){
	LL res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
const int maxn = 200010, inf = 0x3f3f3f3f;
int n, mx, a[maxn], t[maxn], s[maxn];
inline bool chk(int x){
	fp(i, 1, n){
		if(a[i] < x)s[i] = s[i-1]+1;
		else if(a[i] == x)s[i] = s[i-1];
		else s[i] = s[i-1]-1;
	}
	fp(i, 1, n)if(s[i] < 0)return 0;
	if(s[n] > 0)return 0;
	return 1;
}
int main(){
	n = rd();
	fp(i, 1, n)a[i] = rd(), mx = max(mx, a[i]), ++t[a[i]];
	fp(i, 1, mx)t[i] += t[i-1];
	int res = 0, res2 = 0;
	fp(i, 1, mx)if(t[i]-t[i-1] && t[i-1] == t[mx]-t[i])res = i;
	fp(i, 1, n)if(t[a[i]] == t[mx]-t[a[i]])res2 = a[i];
	if(!res && !res2)return puts("0"), 0;
	else if(res)printf("%d\n", chk(res) ? 1 : 0);
	else{
		if(!chk(res2+1))puts("0");
		else{
			int nxt = inf;
			fp(i, 1, n)if(a[i] > res2 && a[i] < nxt)nxt = a[i];
			printf("%d\n", nxt-res2-1);
		}
	}
	return 0;
}
