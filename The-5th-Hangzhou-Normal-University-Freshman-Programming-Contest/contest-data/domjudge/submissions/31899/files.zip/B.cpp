#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,a[200005],b[200005],ans;
bool cmp(int a,int b)
{
    return a>b;
}
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=1;i<=n;i++)cin>>b[i];
    sort(a+1,a+n+1);
    sort(b+1,b+n+1);
    int p=1;
    for(int i=2;i<=n;i++)
    {
        if(b[i]-a[i]!=b[i-1]-a[i-1])p=0;break;
    }
    if(p)ans=abs(b[1]-a[1]);
    sort(a+1,a+n+1,cmp);
    int t=1;
    for(int i=2;i<=n;i++)
    {
        if(b[i]+a[i]!=b[i-1]+a[i-1])t=0;break;
    }
    if(t&&!p)cout<<abs(b[1]+a[1])+1;
    else if(t&&p)cout<<min(ans,abs(b[1]+a[1])+1);
    else if(!t&&p)cout<<ans;
    else cout<<-1;
    return 0;
}
