#include<iostream>
using namespace std;
int n,ans,a[200000],res=99999999;
int main()
{
	cin>>n;
	ans=0;
	for(int i=0;i<n;i++)cin>>a[i];
	if(a[0]>=a[n-1])
	{
		cout<<0;
		return 0;
	}
	for(int i=0;i<n-1;i++)
	{
		if(a[i]==a[i+1])
		{
			ans++;
			if(ans>1)
			{
				cout<<0;
				return 0;
			}
		}
	}
	int x=a[0];
	for(int i=1;i<n;i++)
	{
		if(a[i]>x&&a[i]>a[i+1])
		{
			res=min(res,a[i]-x-1);
			x=a[i+1];
		}
	}
	if(ans==1)
	{
		cout<<1;
		return 0;
	}
	else 
	{
		cout<<res;
		return 0;
	}
	return 0;
}
