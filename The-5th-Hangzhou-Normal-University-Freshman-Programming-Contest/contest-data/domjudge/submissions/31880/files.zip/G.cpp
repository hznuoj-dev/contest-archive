#include<bits/stdc++.h>
using namespace std;
int a[200005];
long long f[200005];
long long pre[200005];
int main(){
	int n,m,b;
	scanf("%d%d%d",&n,&m,&b);
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		pre[i]=pre[i-1]+a[i];
	}
	long long ans=0;
	for(int i=1;i<=m;i++){
		f[i]=min((long long)b,pre[i]);
		ans=max(f[i],ans);
	//	printf("%lld#",f[i]);
	}
	for(int i=m+1;i<=n;i++){
		f[i]=max(f[i],f[i-m]+min((long long)b,pre[i]-f[i-m]));
	//	printf("%lld#",f[i]);
		ans=max(f[i],ans);
	}
	printf("%lld\n",ans);

}
