/*
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
const int mod=1e9+7;
long long a[N],fa[N];
int p[N],cnt[N];
int find(int x)
{
    if(p[x]!=x)
    {
        p[x]= find(p[x]);
    }
    return p[x];
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n,q;
    cin >> n >> q;
    for (int i=1;i<=n;i++)
    {
        cin >> a[i];
        p[i]=i;
        fa[i]=a[i];
        cnt[i]=1;
    }
    while (q--)
    {
        int num;
        cin >> num;
        if(num==1)
        {
            int a,b;
            cin >> a >> b;
            a= find(a);
            b= find(b);
            p[a]=b;
            fa[b]+=fa[a];
            cnt[b]+=cnt[a];
        }else if(num==2)
        {
            int a,b;
            cin >> a >> b;
            a= find(a);
            fa[a]+=b*cnt[a];
        }else {
            int b;
            cin >> b;
            cout << a[b]%mod << endl;
        }
        for (int i=1;i<=n;i++)
        {
            int father= find(i);
            a[i]+=fa[father];
        }
    }
}
*/
/*
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n;
    cin >> n;
    int min_num=1000000,max_num=-1;
    for (int i=1;i<=n;i++)
    {
        cin >> a[i];
        min_num= min(min_num,a[i]);
        max_num= max(max_num,a[i]);
    }
        int ans=0;
        for (int i=min_num;i<=max_num;i++)
        {
            stack<int> st;
            bool successful= true;
            for (int j=1;j<=n;j++)
            {
                if(a[j]>i)
                {
                    // )
                    if(st.empty())
                    {
                        successful= false;
                        goto a1;
                    } else{
                        st.pop();
                    }
                }else if(a[j]<i)
                {
                    // (
                    st.push(1);
                }
            }
            a1:
            if(!st.empty()) successful= false;
            if(successful)
            {
                ans++;
            }
        }
        cout << ans;
    return 0;
}
*/
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
long long int a[N];
long long int now[N];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n,m,b;
    cin >> n>> m >>b;
    for (int i=1;i<=n;i++)
    {
        cin >> a[i];
        if(i==1) now[1]=a[1];
        else now[i]=now[i-1]+a[i];
    }
    long long int ans=0;
    for (int i=(n-1)%m+1;i<=n;i+=m)
    {
        if(now[i]-ans<=b) ans += (now[i]-ans);
        else ans += b;
    }
    cout << ans;
    return 0;
}
