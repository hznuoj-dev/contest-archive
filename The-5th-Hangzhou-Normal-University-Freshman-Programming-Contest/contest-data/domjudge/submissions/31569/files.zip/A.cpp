#include<bits/stdc++.h>
using namespace std;

const int N = 1e6;
int a[N];
int n;
vector<int> s;

void deal(int num)
{
	for(int i = 1; i <= n; ++i)
	{
		if(a[i] < num)
		{
			s.push_back(1);
		}
		else if(a[i] > num)
		{
			s.push_back(2);
		}
	}
}

bool check()
{
	int bin = 0;
	
	for(int i = s.size() - 1; i >= 0; --i)
	{
		if(s[i] == 2)
		{
			++bin;
		}
		else
		{
			--bin;
		}
		
		if(bin < 0)
		{
			return false;
		}
	}
	
	if(bin == 0)
	{
		return true;
	}
	
	return false;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	int mi = 1e9, ma = -1;
	cin >> n;
	for(int i = 1; i <= n; ++i) 
	{
		cin >> a[i];
		if(mi > a[i]) mi = a[i];
		if(ma < a[i]) ma = a[i];
	}
	 
	int l = 2, r = 0;
	for(int i = mi; i <= ma; ++i)
	{	
		s.clear();
		
		deal(i);
		
		if(check())
		{
			l = i;
			break;
		}
	}
	for(int i = ma; i >= mi; --i)
	{
		s.clear();
		
		deal(i);
		
		if(check())
		{
			r = i;
			break;
		}
		
		if(i - l + 1 == -1)
		break;
	}
	
	cout << max(r - l + 1, 0);
}

/*
4
4 4 4 5

*/
