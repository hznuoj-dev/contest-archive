#include <bits/stdc++.h>
#define int long long
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

int read() {
    int x = 0, f = 1; char c = getchar();
    while(c < '0' || c > '9') c == '-' ? f = -1: 0, c = getchar();
	while(c >= '0' && c <= '9') x = (x << 1) + (x << 3) + (c ^ '0'), c = getchar();
    return x * f;
}

int qpow(int a, int k, int r = 1) {
	for(; k; k >>= 1, a = a * a)
		if(k & 1) r = r * a;
	return r;
}

int n, k, q, a[200050], R[200050];
int stmx[25][200050], stmn[25][200050];
int id[200050], ql[200050], qr[200050];
LL ans[200050], b[200050], c[200050];
vector<int> eq[200050];

LL qry(LL b[], int i, LL r = 0) {
    for(; i; i -= (i & -i)) r += b[i];
    return r;
}

void add(LL b[], int i, LL v) {
    for(; i <= n; i += (i & -i)) b[i] += v;
}

int getMax(int l, int r) {
    int k = log2(r - l + 1);
    return max(stmx[k][l], stmx[k][r - (1 << k) + 1]);
}

int getMin(int l, int r) {
    int k = log2(r - l + 1);
    return min(stmn[k][l], stmn[k][r - (1 << k) + 1]);
}

bool chk(int l, int r, int k) {
    return getMax(l, r) - getMin(l, r) <= k;
}

void ins(int i) {
    for(int x : eq[i]) {
        LL z = qry(b, x) - qry(b, x - 1);
        add(b, x, -z + i);
        add(c, x, 1);
    }
}

signed main() {
    memset(stmx, 0, sizeof stmx);
    memset(stmn, 0x3f, sizeof stmn);
    
    n = read(), k = read(), q = read();
    for(int i = 1; i <= n; ++i) a[i] = stmx[0][i] = stmn[0][i] = read();
    
    for(int k = 1; k <= 20; ++k) {
        for(int i = 1; i + (1 << k) - 1 <= n; ++i) {
            stmx[k][i] = max(stmx[k - 1][i], stmx[k - 1][i + (1 << k - 1)]);
            stmn[k][i] = min(stmn[k - 1][i], stmn[k - 1][i + (1 << k - 1)]);
        }
    }
    
    for(int i = 1; i <= n; ++i) {
        int l = i, r = n;
        while(l < r) {
            int mid = l + r + 1 >> 1;
            if(chk(i, mid, k)) l = mid;
            else r = mid - 1;
        }
        eq[l].push_back(i);
    }
    
    for(int i = 1; i <= q; ++i)
        a[i] = i, id[i] = i, ql[i] = read(), qr[i] = read();
    
    sort(a + 1, a + q + 1, [](int x, int y) -> bool {
        return qr[x] == qr[y] ? ql[x] < ql[y] : qr[x] < qr[y];
    });
    
    int r = 0;
    for(int p = 1; p <= q; ++p) {
        int i = a[p];
        while(r < qr[i]) ins(++r);
        LL x = qry(b, qr[i]) - qry(b, ql[i] - 1);
        LL y = (qr[i] - ql[i] + 1 - qry(c, qr[i]) + qry(c, ql[i] - 1)) * r;
        
//        cout << ql[i] << ' ' << qr[i] << ' ' << x << ' ' << y << endl;
        
        ans[id[i]] = x + y - 1ll * (ql[i] + qr[i]) * (qr[i] - ql[i] + 1) / 2 + (qr[i] - ql[i] + 1);
    }
    
    for(int i = 1; i <= q; ++i) printf("%lld\n", ans[i]);
    return 0;
}

