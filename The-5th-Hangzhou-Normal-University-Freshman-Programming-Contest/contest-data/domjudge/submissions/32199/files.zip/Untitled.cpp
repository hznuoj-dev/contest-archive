#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long 
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const int inf=0x3f3f3f3f;
const int N=2e6+10;
int n;
vector<pair<int,int>>g[N];
int ans[N];
int sz[N];
void dfs(int u,int par)
{
	sz[u]=ans[u];
	for(auto it:g[u])
	{
		int v=it.first;
		int w=it.second;
		ans[v]=(w^ans[u]);
		if(v==par)  continue;
		dfs(v,u);
		sz[u]=(sz[u]^sz[v]);
	}
}


signed main()
{
	Acode;
	cin>>n;
	for(int i=1;i<=n-1;i++) 
	{
		int u,v,w;
		cin>>u>>v>>w;
		g[u].push_back({v,w});
		g[v].push_back({u,w});
	}
	
	int q;
	cin>>q;
	while(q--)
	{
		int u,x;
		cin>>u>>x;
		ans[u]=x;
		dfs(u,0);
//		for(int i=1;i<=n;i++) 
//		{
//			cout<<ans[i]<<" ";
//		}
        cout<<sz[u]<<endl;
	}
	
	
	return 0;
}