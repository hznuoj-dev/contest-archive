#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
    ll a;
    ll b;
}p[6];
int main()
{
    ll m, k;
    ll sum = 0;
    ll ans = 0;
    cin >> m >> k;
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].a;
        sum += p[i].a;
    }
    for(int i = 1; i <= 5; ++i){
        cin >> p[i].b;
        ans += p[i].b;
    }
    double maxx = 0;
    if(sum >= m)
      sum -= k;
    double temp;
    temp = (double)ans / (double)sum;
    maxx = max(maxx, temp);
    sum = 0;
    ans = 0;
    //1
    for(int i = 1; i <= 5; ++i){
    	sum = p[i].a;
    	ans = p[i].b;
    	int flag = 0;
    	if(sum >= m){
    		flag = 1;
    		sum -= k;
		}
		double tmp = (double) ans / (double) sum;
		maxx = max(maxx, tmp);
		if(flag == 1)
		   sum += k;
		sum -= p[i].a;
		ans -= p[i].b;
	}
    //2
    for(int i = 1; i <= 4; ++i){
        sum = p[i].a;
        ans = p[i].b;
        int flag = 0;
        for(int j = i + 1; j <= 5; ++j){
             sum += p[j].a;
             ans += p[j].b;
             if(sum >= m){ 
               sum -= k;
               flag = 1; 
            } 
             double tmp = (double)ans / (double)sum;
             maxx = max(maxx, tmp);
             if(flag == 1)
               sum += k, flag = 0;
             sum -= p[j].a;
             ans -= p[j].b;
        }
    }
    //3
    for(int i = 1; i <= 3; ++i){
        sum = p[i].a;
        ans = p[i].b;
        for(int j = i + 1; j <= 4; ++j){
            sum += p[j].a;
            ans += p[j].b;
            int flag = 1;
             for(int l = j + 1; l <= 5; ++l){
                 sum += p[l].a;
                 ans += p[l].b;
                 if(sum >= m)
                    sum -= k, flag = 1;
                double tmp = (double)ans / (double)sum;
                maxx = max(maxx, tmp);
                if(flag)
                  sum += k, flag = 0;
                sum -= p[l].a;
                ans -= p[l].b;
             }
             sum -= p[j].a;
             ans -= p[j].b;
        }
    }
    //4
    for(int i = 1; i <= 2; ++i){
        sum = p[i].a;
        ans = p[i].b;
        for(int j = i + 1; j <= 3; ++j){
            sum += p[j].a;
            ans += p[j].b;
            for(int l = j + 1; l <= 4; ++l){
                sum += p[l].a;
                ans += p[l].b;
                int flag = 0;
                for(int r = l + 1; r <= 5; ++r){
                    sum += p[r].a;
                    ans += p[r].b;
                    if(sum >= m)
                      sum -= k, flag = 1;
                    double tmp = (double)ans / (double)sum;
                    maxx = max(maxx, tmp);
                    if(flag)
                      sum += k, flag = 0;
                    sum -= p[r].a;
                    ans -= p[r].b;
                }
                 sum -= p[l].a;
                 ans -= p[l].b;
            }
             sum -= p[j].a;
             ans -= p[j].b;
        }
    }
    printf("%.2lf\n", maxx);
    return 0;
}
