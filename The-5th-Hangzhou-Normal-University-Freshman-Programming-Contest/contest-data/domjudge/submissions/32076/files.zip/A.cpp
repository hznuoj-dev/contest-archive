#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
vector<pair<int,int> >q;
int a[200005];
const int INF = 0x3f3f3f3f;
//int ans[200010];
//void play(int l, int r) {
//	if((r-l+1)%2==0) {
//		int mid = (l+r)/2;
//		if(a[mid]==a[mid+1]) {
//			int cnt = 0;
//			for(int i = l; i<=r; i++) {
//				if(a[i]==a[mid])cnt++;
//			}
//			if(cnt%2==0) {
//				ans[a[mid]]++;
//				ans[a[mid]+1]--;
//			}
//		} else {
//			ans[a[mid]+1]++;
//			ans[a[mid+1]]--;
//		}
//	} else {
//		int mid = (l+r)/2;
//		int cnt = 0;
//		for(int i = l; i<=r; i++) {
//			if(a[i]==a[mid])cnt++;
//		}
//		if(cnt%2==1) {
//			ans[a[mid]]++;
//			ans[a[mid]+1]--;
//		}
//	}
//}
int minn = INF, maxn = -INF;
int upper[200005], lower[200005];
int ans = 0;
int n;
bool check(int x){
	stack<int>s;
	for(int i = 1;i<=n;i++){
		if(a[i]<x){
			s.push(1);
		}
		else if(a[i]>x){
			if(s.empty()) return false;
			else s.pop();
		}
	}
	if(!s.empty())return false;
	return true;
}

void solve() {
	cin>>n;
	for(int i = 1; i<=n; i++) {
		cin>>a[i];
		minn = min(minn,a[i]);
		maxn = max(maxn,a[i]);
	}
	for(int i = 1;i<=n;i++){
		upper[minn]++;
		upper[a[i]]--;
		lower[a[i]+1]++;
	}
	for(int i = minn;i<=maxn;i++){
		upper[i] += upper[i-1];
		lower[i] += lower[i-1];
		if(upper[i]==lower[i]){
			if(check(i))ans++;
		}
	}
	cout<<ans<<'\n';
}

signed main() {
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}
