#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn=2e5+7;
ll n,m,b;
ll a[maxn],sum[maxn];
void solve(){
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum[i]=sum[i-1]+a[i];
	}
	ll ans=0;
		for(int i=1;i<=n;i+=m){
			if(sum[i]-ans>=b){
				ans+=b;
			}else{
				ans+=sum[i]-ans;
			}
		}
	ll ans2=0;
		for(int i=2;i<=n;i+=m){
			if(sum[i]-ans2>=b){
				ans2+=b;
			}else{
				ans2+=sum[i]-ans2;
			}
		}
	ll ans3=0;
	ll st=n-n/m*m;
	if(st<=0)st+=m;
	for(int i=st;i<=n;i+=m){
		if(sum[i]-ans3>=b){
				ans3+=b;
			}else{
				ans3+=sum[i]-ans3;
			}
	}
	cout<<max(max(ans,ans2),ans3);
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
	return 0;
}