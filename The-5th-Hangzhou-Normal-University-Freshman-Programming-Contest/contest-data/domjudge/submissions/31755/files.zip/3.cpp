#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll maxn = 2e5 + 10;
const ll minn = 1e9 + 7;
const double eps = 1e-6;
const int INFTY = (1<<21);

int gcd(int a, int b) {return b ? gcd(b, a % b) : a;}
int lcm(int a, int b) {return a * b / gcd(a, b);}

ll n;
ll a[maxn],b[maxn];

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cin>>n;
    for(ll i=1;i<=n;i++)
    {
        std::cin>>a[i];
    }
    for(ll i=1;i<=n;i++)
    {
        std::cin>>b[i];
    }
    sort(a+1,a+1+n);
    sort(b+1,b+1+n);
    ll num=abs(a[1]-b[1]);
    int f=0;
    for(ll i=2;i<=n;i++)
    {
        if(abs(a[i]-b[i])!=num)
        {
            f=1;
            break;
        }
    }
    if(f==0)
    {
        std::cout<<num<<endl;
    }
    else 
    {
        std::cout<<"-1"<<endl;
    }
    return 0;
}