#include<bits/stdc++.h>
#define int long long
using namespace std;
map<pair<int,int>,bool> vis;
const int mod = 1e9 + 7;
int n,m,k,cnt;
int qpow(int a,int b,int p){
	int res = 1;
	while(b){
		if(b & 1){
			res = res * a % p;
		}
		a  = a * a % p;
		b >>= 1;
	}
	return res;
}
signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin >> n >> m >> k;
	int u,v;
	pair<int,int> x;
	for(int i = 1;i <= m;i ++){
		cin >> u >> v;
		x = make_pair(u,v);
		if(vis[x] == 0){
			cnt ++;
			vis[x] = 1;
		}
	}
//	cout << "?? " << cnt << " " << k << '\n';
	cout << qpow(cnt,k,mod) << '\n';
	return 0;
}

