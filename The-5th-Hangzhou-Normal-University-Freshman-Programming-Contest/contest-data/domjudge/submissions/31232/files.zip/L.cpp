#include<bits/stdc++.h>

#define fu(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fd(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define PRN(X) cout << #X << "=" << X << endl
#define PR(X) cout << #X << "=" << X << " "
using namespace std;

const int N = 2e5 + 5;

int read(){
	int f = 1, x = 0; char ch = getchar();
	while(ch > '9' || ch < '0'){ 	if(ch == '-')f = -1; ch = getchar(); }
	while(ch <= '9' && ch >= '0'){ x = (x << 1) + (x << 3) + (ch ^ 48);  ch = getchar(); }
	return x * f;
}
int a[10], b[10];
void solve(){
	int m = read(), k = read();
	fu(i, 1, 5) a[i] = read();
	fu(i, 1, 5) b[i] = read();
	double ans = 0;
	fu(st, 1, (1 << 5) - 1) {
		double suma = 0, sumb = 0;
		fu(j, 1, 5) {
			if(st & (1 << (j - 1))){
			if(st == 18) PR(j);suma += a[j], sumb += b[j];}
		}
		if(st == 19) PR(suma), PRN(sumb);
		if(suma >= m) suma -= k;
		ans = max(sumb / suma, ans); 
	}
	printf("%.2lf", ans);
}
int main(){
	int t = 1;
	while(t--){
		solve();
	}
}


