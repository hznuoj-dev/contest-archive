#include<bits/stdc++.h>
#define close std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
typedef long long ll;
const ll MAXN = 3e5+7;
const ll mod = 1e9+7;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
#define int long long
int a[MAXN],b[MAXN],c[MAXN];
ll _power(ll a,int b){ ll ans=1,res=a;while(b){ if(b&1) ans=ans*res%mod;res=res*res%mod;b>>=1;} return ans%mod;}
void solve(){
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		c[i]=-1*a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	sort(a+1,a+1+n);
	sort(c+1,c+1+n);
	sort(b+1,b+1+n);
	int ans=inf;
	int flag=1,tmp=0;
	for(int i=1;i<=n;i++){
		if(i==1) tmp=a[i]-b[i];
		else{
			if(a[i]-b[i]!=tmp) flag=0;
		}
	}
	if(flag){
		ans=min(ans,abs(tmp));
	}
     flag=1,tmp=0;
	for(int i=1;i<=n;i++){
		if(i==1) tmp=c[i]-b[i];
		else{
			if(c[i]-b[i]!=tmp) flag=0;
		}
	}
	if(flag){
		ans=min(ans,abs(tmp)+1);
	}
	if(ans!=inf)
	cout<<ans;
	else cout<<"-1";
}
signed main(){
	solve();
}
