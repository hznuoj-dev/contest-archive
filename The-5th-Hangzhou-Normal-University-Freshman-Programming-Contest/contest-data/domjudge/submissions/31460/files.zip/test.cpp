#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=2e5+10;
long long n,a[maxn],b[maxn],ans=0;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n;
    for(int i=1;i<=n;i++)   cin>>a[i];
    for(int i=1;i<=n;i++)   cin>>b[i];
    sort(a+1,a+1+n);
    sort(b+1,b+1+n);
    long long res1=a[1]-b[1];
    bool f=true,f2=true;
    for(int i=2;i<=n;i++){
        if(a[i]-b[i]!=res1){
            f=false;
            break;
        }
    }
    for(int i=1;i<=n;i++)   a[i]=-a[i];
    sort(a+1,a+1+n);
    long long res2=a[1]-b[1];
        for(int i=2;i<=n;i++){
            if(a[i]-b[i]!=res2){
                f2=false;
                break;
            }
        }
    if(f==false&&f2==false)     cout<<"-1";
    else if(f==true&&f2==true){
        ans=abs(res1);
        if(ans>abs(res2)){
            ans=abs(res2)+1;
        }
        cout<<ans;
    }
    else if(f==false&&f2==true){
        ans++;
        ans=ans+abs(res2);
        cout<<ans;
    }
    else if(f==true&&f2==false){
        ans=abs(res1);
        cout<<ans;
    }
}