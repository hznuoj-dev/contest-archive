#include<bits/stdc++.h>

#define fu(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fd(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define PRN(X) cout << #X << "=" << X << endl
#define PR(X) cout << #X << "=" << X << " "
using namespace std;
const int N = 2e5 + 5;
int head[N], ecnt;
struct Edge {
	int v, w, nxt;
}e[N << 1];
void init_edge() {
	memset(head, -1, sizeof head);
	ecnt = 1;
}
void add_edge(int u, int v, int w = 0) {//����һ���ߣ�
	ecnt++;
	e[ecnt].v = v, e[ecnt].w = w;
	e[ecnt].nxt = head[u];
	head[u] = ecnt;
}

int read() {
	int f = 1, x = 0; char ch = getchar();
	while (ch > '9' || ch < '0') { if (ch == '-')f = -1; ch = getchar(); }
	while (ch <= '9' && ch >= '0') { x = (x << 1) + (x << 3) + (ch ^ 48);  ch = getchar(); }
	return x * f;
}
int w[N], a[N], vis[N];
void dfs(int u, int& len, int last, int rt) {
	vis[u] = 1;len++;
	for (int i = head[u]; i != -1; i = e[i].nxt) {
		if ( (last ^ 1)== i) continue;
		int v = e[i].v;
		if (v != rt)dfs(v, len, i, rt);
		break;
	}
}
void solve() {
	init_edge();
	int n = read(), k = n - read();
	fu(i, 1, n) {
		a[i] = read();
		if (a[i] != i) {
			int u = i, v = a[i];
			add_edge(u, v);
			add_edge(v, u);
		};
	}
	if(k == 1) {
		puts("-1");
		return ;
	}
	int sum = 0;
	vector<int> L;
	fu(i, 1, n){
		int len = 0;
		if(a[i] != i && !vis[i]) dfs(i, len, 0, i);
		if(len > 1)L.push_back(len), sum += len;
	}
//	for(auto l:L)PR(l);
//	puts("");
	if(k >= sum) {
		int num = k - sum;
		PR(k);
		cout << (num + 1) / 2 << endl;
		return;
	}
	sort(L.begin(), L.end());
	int need = sum - k;
	int ans = 0;
	
//	for(auto l:L)PR(l);
//	puts("");
	fu(i, 0, L.size() - 1) {
		if(need >= L[i]) ans += L[i] - 1, need -= L[i];
		else {
			if(L[i] == need + 1) {
				L[i] -= (need - 1);
				need -= (need - 1);
				ans += (need - 1);
				if(L.back() == 2) ans += 2;
				else ans += 1;
			}
			else ans += need;
			break;
		}
	}
	cout << ans << endl;
}
int main(){
	int t = 1;
	while(t--){
		solve();
	}
}
/*
5 2
5 4 3 2 1


*/

