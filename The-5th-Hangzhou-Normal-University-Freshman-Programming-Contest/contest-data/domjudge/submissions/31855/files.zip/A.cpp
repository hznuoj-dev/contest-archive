        #include<iostream>
        #include<algorithm>
        #include<queue>
        #include<cmath>
        #include<map>
        #include<iomanip>
        #include<stack>
        #define shojig ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
        using namespace std;
        typedef long long ll;
        int a[2000000],a1[2000000];
		int main()
        {
        	int n,ans=0;
        	cin>>n;
           	for(int i=1;i<=n;i++)
           	{
           		cin>>a[i];
				a1[i]=a[i];
			}
			sort(a1+1,a1+n+1);
			int l,r;
			if(n%2){
				l=a1[n/2+1];
				r=l;
			}
			else {
				l=a1[n/2];
				r=a1[n/2+1];
			}
			l=max(a[1],l);
			r=min(a[n],r);
			for(int i=l;i<=r;i++){
				int sum=0;
				for(int j=1;j<=n;j++){
					if(a[j]<i)sum++;
					if(a[j]>i)sum--;
					if(sum<0){
						break;
					}
				}
				if(sum==0)ans++;
			}
			cout<<ans;
		}
		 
