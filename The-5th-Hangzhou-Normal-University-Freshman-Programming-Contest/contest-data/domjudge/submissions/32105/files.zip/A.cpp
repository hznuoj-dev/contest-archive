#include <iostream>
//#include <bits/stdc++.h>
#include <stack>
using namespace std;
const int N = 1e6 + 10;
int a[N], n, k;
int maxx = 0, minn = 1e9;
int numl, numr;

bool judge(int mid)
{
	stack<char> st;
	char ch;
	for (int i = 1; i <= n; i++)
	{
		if (a[i] == mid)
		{
			continue;
		}
		else if (a[i] < mid)
		{
			ch = '(';
			numl++;
		}
		else if (a[i] > mid)
		{
			ch = ')';
			numr++;
		}
		if (st.size() == 0)
		{
			st.push(ch);
		}
		else if (st.size() && st.top() == '(' && ch == '(')
		{
			st.push(ch);
		}
		else if (st.size() && st.top() == '(' && ch == ')')
		{
			st.pop();
		}
		else if (st.size() && st.top() == ')')
		{
			st.push(ch);
		}

	}
	if (st.size())
	{
		return false;
	}
	else
	{
		return true;
	}
}

int main()
{
	cin >> n;
	int flag = 0;
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
	}
	int ll = 0, rr = 0;
	int l = 1, r = 2e5;

	while (l < r)
	{
		numl = 0, numr = 0;
		int mid = l + r >> 1;
		if (judge(mid))
		{
			flag = 1;
			r = mid - 1;
		}
		else if (numl >= numr && !judge(mid))
		{
			r = mid - 1;
		}
		else if (numr > numl && !judge(mid))
		{
			l = mid + 1;
		}
	}
	ll = l;
	l = 1, r = 2e5;
	while (l < r)
	{
		numl = 0, numr = 0;
		int mid = l + r + 1 >> 1;
		if (judge(mid))
		{
			flag = 1;
			l = mid + 1;
		}
		else if (numl >= numr && !judge(mid))
		{
			r = mid - 1;
		}
		else if (numr > numl && !judge(mid))
		{
			l = mid + 1;
		}

	}
	rr = r;
	if (flag == 1)
	{
		cout << rr - ll << endl;
	}
	else
	{
		cout << 0 << endl;
	}

	return 0;
}