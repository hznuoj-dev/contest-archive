#include<bits/stdc++.h>
#define int long long
#define inf 0x3f3f3f3f

using namespace std;
const int N = 2e5 + 5;
int a[N], b[N], c[N], d[N];

void solve() {
	int n;
	cin >> n;
	int ans = -1;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for(int i = 1; i <= n; i++) {
		cin >> b[i];
	}
	sort(a + 1, a + n + 1);
	sort(b + 1, b + n + 1);

	int flag1 = 1, flag2 = 1;
	for(int i = 1; i <= n; i++) {
		c[i] = b[i] - a[i];
		d[i] = a[i] + b[n - i + 1];
		if(i > 1 && c[i] != c[i - 1]) {
			flag1 = 0;
		}
		if(i > 1 && d[i] != d[i - 1]){
			flag2 = 0;
		}
	}
//	for(int i = 1; i <= n; i++){
//		cout << d[i] << " \n"[i == n];
//	}
	if(flag1){
		ans = abs(c[1]);
	}
	if(flag2){
		if(ans == -1) ans = abs(d[1]) + 1;
		else ans = min(ans, abs(d[1]) + 1);
	}
//	cout << flag1 << " " << flag2 << endl;

	cout << ans << endl;
	return;
}
/*
2
0 1
2 3

3 
2 3 3
0 0 1
*/
signed main() {
	ios::sync_with_stdio(0);

	int T = 1;
//	cin >> T;
	while(T--) {
		solve();
	}

	return 0;
}
