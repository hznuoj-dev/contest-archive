#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,a[200005],b[200005],ans;
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=1;i<=n;i++)cin>>b[i];
    sort(a+1,a+n+1);
    sort(b+1,b+n+1);
    int t=0,p=0;
    for(int i=1;i<=n;i++)
    {
        if(a[i]>0&&b[i]<0||a[i]<0&&b[i]>0||a[i]==0&&b[i]==0)t++;
        if(!a[i]&&!b[i])p++;
    }
    if(t==p||t==n||t==0)
    {
        if(t==n&&t!=p)ans++;
        int x=a[1]-b[1],q=1;
        for(int i=2;i<=n;i++)
        {
            if(a[i]-b[i]!=x){q=0;cout<<-1;break;}
        }
        if(q){ans+=abs(x);cout<<ans;}
    }
    else cout<<-1;
    return 0;
}