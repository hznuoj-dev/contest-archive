#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define fi first
#define se second
#define pii pair<int,int>
#define pb push_back
const int N = 2E5 + 10;

void solve() {
	int n, m, b; cin >> n >> m >> b;
	
	vector<int> a(n + 1);
	vector<ll> pre(n + 1);
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		pre[i] = pre[i - 1] + a[i];
	}
	
	ll ans = 0;
	for (int i = n % m; i <= n; i += m) {
		if (pre[i] - ans >= b) {
			ans += b;
		} else {
			ans += pre[i] - ans;
		}
	}
	cout << ans << endl;



}
/*
5 2 10
5 9 3 1 8

6 2 10
20 1 1 1 1 5
*/

int main() {
	ios::sync_with_stdio(0); cout.tie(0); cin.tie(0);

	int T = 1;

	while(T--) solve();

	return 0;
}

