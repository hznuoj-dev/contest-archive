#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int ll
typedef pair<int,int>pii;
const int N=2e5+7,mod=1e9+7;
int n,u,v,w,a[N][40],ans[40],q;
vector<pii>e[N];
void dfs(int u,int last,int w){
	for(pii x:e[u]){
		if(x.first!=last){
			a[x.first][w]=a[u][w]^(x.second&(1<<w));
			dfs(x.first,u,w);
		}
	}
}
void solve(){
	cin>>n;
	for(int i=1;i<n;i++){
		cin>>u>>v>>w;
		e[u].push_back({v,w});
		e[v].push_back({u,w});
	}
	for(int i=0;i<31;i++)a[1][i]=1<<i;
	for(int i=0;i<31;i++)dfs(1,-1,i);
	for(int i=0;i<31;i++){
		for(int j=1;j<=n;j++){
			ans[i]^=a[j][i];
		}
	}
	cin>>q;
	while(q--){
		int u,x;
		cin>>u>>x;
		int sum=0;
		for(int i=0;i<31;i++){
			if((x&(1<<i))==a[u][i]){
				sum+=ans[i];
			}else{
				sum+=((n-(a[u][i]>0))&1)*ans[i];
			}
		}
		cout<<sum<<'\n';
	}
	
}
signed main(){
	int t=1;
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cin>>t;
	while(t--)solve();
	return 0;
}
