#include<stdio.h>

int m, n, k, j = 0;
long long int b, a[200001], c[200001], h = 0;

int main()
{
	scanf("%d %d %lld", &n, &m, &b);
	
	for (int i = 0; i < n; i++)
		scanf("%lld", &a[i]);
		
	if (n % m == 0)
	{
		for (int i = 0; i < n; i += m)
		{
			for (int y = i; y < i + m; y++)
			{
				c[j] += a[y];
			}
			j++;
		}
		for (int i = 0; i < j - 1; i++)
		{
			if (c[i] > b)
			{
				c[i + 1] += c[i] - b;
				h += b;
			}
			else
				h += c[i]; 
		}
		if (c[j - 1] <= b)
			h += c[j - 1];
		else
			h += b;
		printf("%lld", h);		
	}
	else
	{
		for (int i = n - 1; i >= 0; i -= m)
		{
			for (int y = i; y > i - m && y >= 0; y--)
			{
				c[j] += a[y];
			}
			j++;
		}
		for (int i = j - 1; i > 0; i--)
		{
			if (c[i] > b)
			{
				c[i - 1] += c[i] - b;
				h += b;
			}
			else
				h += c[i]; 
		}
		if (c[0] <= b)
			h += c[0];
		else
			h += b;
		printf("%lld", h);
	}
}