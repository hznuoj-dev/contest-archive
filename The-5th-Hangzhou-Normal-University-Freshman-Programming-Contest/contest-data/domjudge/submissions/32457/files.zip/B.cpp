#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,a[200001],b[200001];
ll s;
priority_queue<ll,vector<ll>,greater<ll>>q;
int main() {
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	s=b[1]-a[1];
	for(int i=1;i<=n;i++) {
		if(b[i]!=s+a[i]) 
			break;
		if(i==n)q.push(abs(s));
	}
	sort(a+1,a+1+n,greater<ll>());
	s=b[1]-a[1];
	for(int i=1;i<=n;i++) {
		if(b[i]!=s+a[i]) 
			break;
		if(i==n)q.push(abs(s));
	}
	for(int i=1;i<=n;i++)a[i]*=-1;
	s=b[1]-a[1];
	for(int i=1;i<=n;i++) {
		if(b[i]!=s+a[i]) 
			break;
		if(i==n)q.push(abs(s));
	}
	sort(a+1,a+1+n,greater<ll>());
	s=b[1]-a[1];
	for(int i=1;i<=n;i++) {
		if(b[i]!=s+a[i]) 
			break;
		if(i==n)q.push(abs(s));
	}
	if(q.size())cout<<q.top();
	else cout<<-1;
}