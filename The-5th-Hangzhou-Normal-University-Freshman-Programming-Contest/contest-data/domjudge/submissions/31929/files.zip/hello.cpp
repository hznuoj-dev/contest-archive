#include <bits/stdc++.h>
#define Zeoy std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define debug(x) cerr << #x << '=' << x << endl
#define all(x) (x).begin(), (x).end()
#define int long long
#define mpk make_pair
#define endl '\n'
using namespace std;
typedef unsigned long long ULL;
typedef long long ll;
typedef pair<int, int> pii;
typedef pair<ll, ll> pll;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-9;
const int N = 2e5 + 10, M = 4e5 + 10;

int n;
int a[N];
int b[N];

void solve()
{
    cin >> n;
    bool ok = false;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    for (int i = 1; i <= n; ++i)
        cin >> b[i];
    int ans = INF;
    sort(a + 1, a + n + 1);
    sort(b + 1, b + n + 1);

    bool flag = true;
    int d = abs(a[1] - b[1]);
    for (int i = 2; i <= n; ++i)
    {
        if (abs(a[i] - b[i]) != d)
        {
            flag = false;
            break;
        }
    }
    if (flag)
    {
        ok = true;
        ans = min(ans, d);
    }

    for (int i = 1; i <= n; ++i)
        a[i] = -a[i];
    sort(a + 1, a + n + 1);
    d = abs(a[1] - b[1]);
    flag = true;
    for (int i = 2; i <= n; ++i)
    {
        if (abs(a[i] - b[i]) != d)
        {
            flag = false;
            break;
        }
    }
    if (flag)
    {
        ok = true;
        ans = min(ans, d + 1);
    }

    for (int i = 1; i <= n; ++i)
        a[i] = -a[i];
    for (int i = 1; i <= n; ++i)
        b[i] = -b[i];
    sort(a + 1, a + n + 1);
    sort(b + 1, b + n + 1);
    d = abs(a[1] - b[1]);
    flag = true;
    for (int i = 2; i <= n; ++i)
    {
        if (abs(a[i] - b[i]) != d)
        {
            flag = false;
            break;
        }
    }
    if (flag)
    {
        ok = true;
        ans = min(ans, d + 1);
    }

    for (int i = 1; i <= n; ++i)
        a[i] = -a[i];
    // for (int i = 1; i <= n; ++i)
    //     b[i] = -b[i];
    sort(a + 1, a + n + 1);
    sort(b + 1, b + n + 1);
    d = abs(a[1] - b[1]);
    flag = true;
    for (int i = 2; i <= n; ++i)
    {
        if (abs(a[i] - b[i]) != d)
        {
            flag = false;
            break;
        }
    }
    if (flag)
    {
        ok = true;
        ans = min(ans, d + 2);
    }
    if (ok)
        cout << ans << endl;
    else
        cout << -1 << endl;
}
signed main(void)
{
    Zeoy;
    int T = 1;
    // cin >> T;
    while (T--)
    {
        solve();
    }
    return 0;
}