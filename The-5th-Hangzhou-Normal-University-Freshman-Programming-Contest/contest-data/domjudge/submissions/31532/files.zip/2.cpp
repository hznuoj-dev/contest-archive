#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
const int N=2e5+10;
const long long NN=1e16;
long long a[N],b[N];
int main(void){
	long long n,ans=1e17;
	cin>>n;
	for(long long i=1;i<=n;i++){
		cin>>a[i];
	}
	for(long long i=1;i<=n;i++){
		cin>>b[i];
	}
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	for(long long i=1;i<n;i++){
		if(abs(a[i]-b[i])!=abs(a[i+1]-b[i+1])){
			ans=-1;
			break;
		}
	}
	long long fl=1;
	for(long long i=1;i<=n;i++){
		if(a[i]==-b[i]){
			continue;
		} else {
			fl=0;
			break;
		}
	}
	if(fl){
		ans=1;
	}
	if(ans>NN){
		long long x=0,y=1;
		long long fx=1,fy=1;
		for(long long i=1;i<n;i++){
			if(a[i]-b[i]!=a[i+1]-b[i+1]){
				fx=0;
				break;
			}
		}
		if(fx){
			x+=abs(a[1]-b[1]);
			ans=x;
		}
		for(long long i=1;i<n;i++){
			if(-a[i]-b[i]!=-a[i+1]-b[i+1]){
				fy=0;
				break;
			}
		}
		if(fy){
			y+=abs(-a[1]-b[1]);
			ans=y;
		}
		if(fx&&fy){
			ans=min(x,y);
		}
	}
	if(ans>NN){
		ans=-1;
	}
	cout<<ans;	
	return 0;
}