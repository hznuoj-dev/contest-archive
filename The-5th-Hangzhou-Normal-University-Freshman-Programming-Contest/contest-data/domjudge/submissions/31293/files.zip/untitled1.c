#include <stdio.h>
#include <math.h>
typedef long long ll;
#define MAX 20002

void quick_sort(ll num[], int low, int high )
{
	int i,j,temp;
	int tmp;
	
	i = low;
	j = high;
	tmp = num[low];   //任命为中间分界线，左边比他小，右边比他大,通常第一个元素是基准数
	
	if(i > j)  //如果下标i大于下标j，函数结束运行
	{
		return;
	}
	
	while(i != j)
	{
		while(num[j] >= tmp && j > i)   
		{
			j--;
		}
		
		while(num[i] <= tmp && j > i)
		{
			i++;
		}
		
		if(j > i)
		{
			temp = num[j];
			num[j] = num[i];
			num[i] = temp;
		}
	}
	
	num[low] = num[i];
	num[i] = tmp;
	
	quick_sort(num,low,i-1);
	quick_sort(num,i+1,high);
}

int main (){
	int n, i;
	ll a[MAX], b[MAX];
	scanf("%d", &n);
	for (i = 1; i <= n; i++)
	{
		scanf("%lld", &a[i]);
	}
	for (i = 1; i <= n; i++)
	{
		scanf("%lld", &b[i]);
	}
	quick_sort(a, 1, n);
	quick_sort(b, 1, n);
	ll tmp = a[1] - b[1];
	for (i = 2; i <= n; i++)
	{
		if (a[i] - b[i] != tmp)
		{
			printf("-1");
			return 0;
		}
	}
	if (a[1] * b[1] > 0)
	{
		printf("%lld", abs(tmp));
	}
	else if (a[1] * b[1] == 0)
	{
		printf("%lld", abs(tmp));
	}
	else if (a[1] * b[1] < 0)
	{
		printf("%lld", abs(abs(a[1]) - abs(b[1])) + 1);
	}
	return 0;
}
