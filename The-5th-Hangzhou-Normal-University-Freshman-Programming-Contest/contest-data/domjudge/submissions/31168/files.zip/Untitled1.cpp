#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
const int N=2e5+5;
#define ll long long
#define ull unsigned long long
ll qpow(ll a,ll b,ll p)
{
	ll sum=1;
	while(b)
	{
		if(b&1)
		{
			sum=sum*a%p;
		}
		b>>=1;
		a=a*a%p;
	}
	return sum;
}
signed main()
{

int m,k;
cin>>m>>k;
 int price[6];
 int pin[6];
 for(int i=1;i<=5;i++)
 cin>>price[i];
 for(int i=1;i<=5;i++)
 cin>>pin[i];
 double ans=-1;
 for(int i=1;i<=5;i++)
 {
 	int tem=price[i];
 	if(tem>=m)
 	tem-=k;
 	ans=max(ans,pin[i]*1.0/tem);
 }
 for(int i=1;i<=5;i++)
 {
 	for(int j=1;j<=5;j++)
 	{
 		if(i!=j){
 		 int tem=price[i]+price[j];
 	     if(tem>=m)
 	     tem-=k;
 			ans=max(ans,(pin[i]+pin[j])*1.0/tem);
		 }
	 }
 }
  for(int i=1;i<=5;i++)
 {
 	for(int j=1;j<=5;j++)
 	{
 	   for(int a=1;a<=5;a++)
 	   {
 	   	if(i!=j&&j!=a&&i!=a)
 	   	{
 	   		 int tem=price[i]+price[j]+price[a];
 	     if(tem>=m)
 	     tem-=k;
 			ans=max(ans,(pin[i]+pin[j]+pin[a])*1.0/tem);
		 }
			}
		}
	 }
	for(int i=1;i<=5;i++)
 {
 	for(int j=1;j<=5;j++)
 	{
 	   for(int a=1;a<=5;a++)
 	   {
 	   	for(int b=1;b<=5;b++)
 	   {	
		if(i!=j&&j!=a&&i!=a&&i!=b&&j!=b&&a!=b)
 	   	{
 	   		 int tem=price[i]+price[j]+price[a]+price[b];
 	     if(tem>=m)
 	     tem-=k;
 			ans=max(ans,(pin[i]+pin[j]+pin[a]+pin[b])*1.0/tem);
		 }
		}
			}
		}
	 }
	 for(int i=1;i<=5;i++)
 {
 	for(int j=1;j<=5;j++)
 	{
 	   for(int a=1;a<=5;a++)
 	   {
 	   	for(int b=1;b<=5;b++)
 	   {	
 	   for(int o=1;o<=5;o++)
 	   {
 	   	if(i!=j&&j!=a&&i!=a&&i!=b&&j!=b&&a!=b&&o!=i&&o!=j&&o!=a&&o!=b)
 	   	{
 	   		 int tem=price[i]+price[j]+price[a]+price[b]+price[o];
 	     if(tem>=m)
 	     tem-=k;
 			ans=max(ans,(pin[i]+pin[j]+pin[a]+pin[b]+pin[o])*1.0/tem);
		 }
		}
		}
			}
		}
	 }
 printf("%.2f",ans);
	
}