#include<bits/stdc++.h>
using namespace std;
int  n,u,v,k,tot,to[1000000],nxt[1000000],w[1000000],h[1000000],sz[1000000],ans[1000000],q;
void  add(int  u,int  v,int  k)
{
	to[++tot]=v;
	w[tot]=k;
	nxt[tot]=h[u];
	h[u]=tot;
}
void  dfs(int  s,int  f)
{
	sz[s]=1;
	
	for(int  i=h[s];i;i=nxt[i])
	if(to[i]!=f)
	{
		dfs(to[i],s);
		sz[s]+=sz[to[i]];
	    if(sz[to[i]]%2)  ans[1]=ans[1]^w[i];
	}
	
}
void  dp(int  s,int  f)
{
	int  k=0;
	for(int  i=h[s];i;i=nxt[i])
	if(to[i]!=f)
	{
		k=sz[to[i]];
		ans[to[i]]=ans[s];
		if(k%2)  ans[to[i]]^=w[i];
		if((n-k)%2)  ans[to[i]]^=w[i];
		sz[s]=n-k;
		sz[to[i]]=n;
		dp(to[i],s);
		sz[s]=n;
		sz[to[i]]=k;
	}
}
int main()
{
	cin>>n;
	
	for(int  i=1;i<n;i++)
	cin>>u>>v>>k,add(u,v,k),add(v,u,k);
	
	dfs(1,1);
	
	dp(1,1);
	
	cin>>q;
	for(int  i=1;i<=q;i++)
	{
	  cin>>u>>v;
	  if(n%2)  cout<<(ans[u]^v)<<'\n';
	  else  cout<<ans[u]<<'\n';
	}
	return  0;
} 
