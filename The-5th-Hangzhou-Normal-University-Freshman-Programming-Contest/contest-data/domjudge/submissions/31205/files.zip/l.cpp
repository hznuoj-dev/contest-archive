#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int cmp(double&a,double&b){
	return a>b;
}
//L
int main(){
	int m,k;
	int a[6],b[6];
	cin>>m>>k;
	for(int i=0;i<=4;i++)cin>>a[i];
	for(int i=0;i<=4;i++)cin>>b[i];
	int num=1;
	vector<double>v;
	while(num<32){
		int hap=0,pri=0;
		for(int i=0;i<=4;i++){
			if(num&(1<<i)){
				hap+=b[i];
				pri+=a[i];
			}
		}
		if(pri>=m)pri-=k;
		v.push_back(hap/(double)pri);
		num++;
	}
	sort(v.begin(),v.end(),cmp);
	printf("%.2f",v[0]);
}
