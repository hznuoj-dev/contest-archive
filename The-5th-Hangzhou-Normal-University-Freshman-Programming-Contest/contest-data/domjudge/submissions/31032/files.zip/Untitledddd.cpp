#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
//#define int long long 
const int inf=0x3f3f3f3f;
const int N=1e5+10;
int a[N];
int b[N];
int m,k;
double ans=0;

void dfs(int step,int sum,int sum1)
{
	if(step>=6) 
	{
		int w=0;
		if(sum>=m)
		w=sum-k;
		else 
		w=sum;
//		int x=sum/m;
//		int t=x*k;
//		double w=sum-t;
		ans=max(ans,sum1*1.0/w);
		return;
	}
	dfs(step+1,sum+a[step],sum1+b[step]);
	dfs(step+1,sum,sum1);
}


int main()
{
    //Acode;
    cin>>m>>k;
    for(int i=1;i<=5;i++)
    {
    	cin>>a[i];
	}
	for(int i=1;i<=5;i++) 
	{
		cin>>b[i];
	}
	dfs(1,0,0);
    printf("%.2f\n",ans);
	
	
	return 0;
}