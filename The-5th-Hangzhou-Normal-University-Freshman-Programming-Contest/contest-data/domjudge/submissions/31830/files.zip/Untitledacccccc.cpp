#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
const int inf=0x3f3f3f3f;
const int N=1e6+10;
int a[N];
int dp[N];
int s[N];
signed main()
{
	Acode ;
	int n,m,b;
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		s[i]=s[i-1]+a[i];
	} 
	
	for(int i=1;i<=n;i++)
	{
		dp[i]=dp[i-1];
		dp[i]=max(dp[i],dp[i-m]+min(s[i]-s[i-m]+abs(s[i-m]-dp[i-m]),b));
	
	}
	cout<<dp[n]<<endl;
	return 0;
}