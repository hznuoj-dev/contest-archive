#include <iostream>
using namespace std;

void print(int x, int cnt) {
    for(int i = 0; i < cnt; i++)    printf("%d", x);
}

void solve()
{
    int n;
    scanf("%d", &n);
    if(n < 12)  {
        printf("-1\n");
        return;
    }

    int rem = n % 4, fac = (n - 12) / 4;
    if(rem == 0) {
        print(1, fac);
        printf("5-1=");
        print(1, fac);
        printf("1\n");

        print(1, fac);
        printf("2-1=");
        print(1, fac);
        printf("1\n");
    } else if(rem == 1) {
        print(1, fac);
        printf("1+1=");
        print(1, fac);
        printf("5\n");

        print(1, fac);
        printf("1+1=");
        print(1, fac);
        printf("2\n");
    } else if(rem == 2) {
        print(1, fac);
        printf("9=");
        print(1, fac);
        printf("6\n");

        print(1, fac);
        printf("6=");
        print(1, fac);
        printf("6\n");
    } else {
        print(1, fac);
        printf("3-1=");
        print(1, fac);
        printf("3\n");

        print(1, fac);
        printf("3-1=");
        print(1, fac);
        printf("2\n");
    }
}

int main()
{
    int T;
    scanf("%d", &T);
    while(T--)  solve();
    return 0;
}