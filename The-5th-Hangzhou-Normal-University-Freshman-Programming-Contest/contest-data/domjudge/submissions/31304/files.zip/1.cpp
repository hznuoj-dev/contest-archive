#include<bits/stdc++.h>
using namespace std;
int  n,a[1000000],b[1000000],ans,p,q;
int main()
{
	cin>>n;
	
	for(int  i=1;i<=n;i++)
	cin>>a[i];
	
	sort(a+1,a+1+n);
	
	for(int  i=1;i<=n;i++)
	cin>>b[i];
	
	sort(b+1,b+1+n);
	
	for(int  i=1;i<n;i++)
	{
	  if(a[i]-b[i]!=a[i+1]-b[i+1])  p=1;
	  if(a[i]-b[n+1-i]!=a[i+1]-b[n-i])  q=1;
	}
	
	if(!p&&!q)  ans=min(abs(a[n]-b[n]),abs(a[1]+b[n])+1),cout<<ans;
	else  if(!p)  ans=abs(a[n]-b[n]),cout<<ans;
	else  if(!q)  ans=abs(a[1]+b[n]+1),cout<<ans;
	else  cout<<"-1\n";
	return 0;
} 
