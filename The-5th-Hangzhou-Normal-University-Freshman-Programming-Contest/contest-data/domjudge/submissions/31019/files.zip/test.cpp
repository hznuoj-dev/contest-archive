#include<bits/stdc++.h>
using namespace std;
    long long int a[200001],b[200001];
void read(long long int n,long long int a[]){
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
}
int main(){
    long long int n;
    cin>>n;
    read(n,a);
    read(n,b);
    sort(a,a+n);
    sort(b,b+n);
    long long int c1,c2;
    c1=a[0]-b[0];
    c2=a[0]+b[0];
    for(int i=0;i<n;i++){
        if((a[i]-b[i]!=c1)){
            cout<<-1<<endl;
            return 0;
        }
    }
    if(abs(c1)>abs(c2)+1)cout<<abs(c2)+1<<endl;
    else cout<<abs(c1)<<endl;
    return 0;
}