/**
 * HELLO WORLD
 * Author: ErodeesFleurs
**/

#include<bits/stdc++.h>

using namespace std;

#define quick ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug(a) cout<<#a<<"="<<a<<endl;
#define mm memset
#define rep(i,a,n) for (int i=a;i<n;i++)
#define per(i,a,n) for (int i=n-1;i>=a;i--)
#define llrep(i,a,n) for (ll i=a;i<n;i++)
#define llper(i,a,n) for (ll i=n-1;i>=a;i--)
#define pb push_back
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second
#define mod(x) ((x)%MOD)

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> PII;
typedef pair<ll,ll> PLL;

const int INF = 0x3f3f3f3f;
const ll L_INF=9223372036854775807;
const int MOD = 1e9+7;
const int NMAX = 500500;
const double eps = 1e-9;

ll gcd(ll a,ll b){return b==0?a:gcd(b,a%b);}
ll lcm(ll a,ll b){return a/gcd(a,b)*b;}
ll qmul(ll a,ll b){ll r=0;while(b){if(b&1)r=(r+a)%MOD;b>>=1;a=(a+a)%MOD;}return r;}
ll qpow(ll a,ll n){ll r=1;while(n){if(n&1)r=(r*a)%MOD;n>>=1;a=(a*a)%MOD;}return r;}
ll qpow(ll a,ll n,ll p){ll r=1;while(n){if(n&1)r=(r*a)%p;n>>=1;a=(a*a)%p;}return r;}
void exgcd(ll a,ll b,ll& d,ll& x,ll& y){if(!b) { d = a; x = 1; y = 0; }else{ exgcd(b, a%b, d, y, x); y -= x*(a/b); }}
ll inv(ll a, ll p){ll d,x,y;exgcd(a,p,d,x,y);return d == 1 ? (x+p)%p : -1;}

//CODE HERE//
ll n,m;


void solve(){
	cin>>n;
	vector<ll>a(n),b(n);
	rep(i,0,n)cin>>a[i];
	rep(i,0,n)cin>>b[i];
	sort(all(a));
	sort(all(b));
	bool flag1=0;
	rep(i,1,n){
		if(a[i]-b[i]!=a[i-1]-b[i-1]){
			flag1=1;
			break;
		}
	}
	ll ans1=L_INF;
	if(!flag1){
		ans1=abs(a[0]-b[0]);
	}
	bool flag2=0;
	rep(i,0,n)a[i]=-a[i];
	sort(all(a));
	rep(i,1,n){
		if(a[i]-b[i]!=a[i-1]-b[i-1]){
			flag2=1;
			break;
		}
	}
	ll ans2=L_INF;
	if(!flag1){
		ans2=abs(a[0]-b[0]);
	}	
//	cout<<ans1<<" "<<ans2<<endl;
	if(flag1&&flag2){
		cout<<-1<<endl;
	}
	else cout<<min(ans1,ans2)<<endl;
}

int main(){
    quick;
    int t=1;
//    cin>>t;
    while(t--)solve();
	return 0;
}
/*
3
1 2 3
4 5 6

*/
