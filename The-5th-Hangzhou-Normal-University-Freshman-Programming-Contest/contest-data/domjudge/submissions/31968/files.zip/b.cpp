#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
int a[maxn],num[maxn],b[maxn];
void solve(){
	int n;
	cin>>n;
	int res1,res2;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		num[a[i]]++;
		b[i]=a[i];
	}
	res1=a[1];
	res2=a[n];
	sort(a+1,a+1+n);
	if(num[a[1]]==n){
		cout<<1<<"\n";
		return;
	}
	if(n%2==0){
		int midl=n/2,midr=n/2+1;
		if(a[midl]==a[midr]){
			int resl=0,resr=0;
			for(int i=1;i<=n;i++){
				if(a[midl]>b[i]) resl++;
				if(a[midl]<b[i]) resr++;
				if(resr>resl){
					cout<<0<<"\n";
					return;
				}
			}
			cout<<1<<"\n";
			return;
		}
		else{
			int ans=0;
			for(int i=a[midl]+1;i<=a[midr]-1;i++){
				int resl=0,resr=0,flagf=1;
				//cout<<i<<"?\n";
				for(int j=1;j<=n;j++){
					if(i>b[j]) resl++;
					if(i<b[j]) resr++;
					if(resr>resl){
						//cout<<resr<<" "<<resl<<"!!\n";
						flagf=0;
						break;
					}
				}
				if(flagf) ans++;
			}
			cout<<ans<<"\n";
			return;
		}
	}
	else{
		int mid=(n+1)/2;
		int flag1=lower_bound(a+1,a+1+n,a[mid])-a;
		int flag2=upper_bound(a+1,a+1+n,a[mid])-a-1;
		int flag=flag2-flag1+1;
		if(flag%2){
			int resl=0,resr=0;
			for(int i=1;i<=n;i++){
				if(a[mid]>b[i]) resl++;
				if(a[mid]<b[i]) resr++;
				if(resr>resl){
					cout<<0<<"\n";
					return;
				}
			}
			cout<<1<<"\n";
		} 
		else{
			cout<<0<<"\n";
		}
		return;
	}
}
int main(){
	ios::sync_with_stdio(false);
	int T=1;
	//cin>>T;
	while(T--) solve();
}

/*
4
4 10 5 10

*/
