#include <iostream>
#include <algorithm>
#include <cstring>
#include <cmath>
using namespace std;
int main()
{
    int n,sum = 0, flag = 0, m;
    int a[200005] = {0}, b[200005] = {0};
    m = a[1];
    cin >> n;
    for(int i = 1; i <= n; i++)
    {
        cin >> a[i];
        //b[i] = a[i];
        m = max(m,a[i]);
        if(a[i] == a[i-1])
            flag = 1;
    }
    if(flag == 1)
    {
        cout << "1" << endl;
        return 0;
    }
    sort(b+1,b+n+1);
    int mid = b[n/2];
    for(int j = mid; j < m; j++)
    {
        flag = 0;
        for(int i = 1; i <= n;)
        {
            if(a[i] < j && a[i+1] >= j)
            {
                if(a[i] < j && a[i+1] >j)
                {
                    flag = 1;
                    i = i + 2;
                    while(i >= n)
                        break;
                }
                else
                {
                    if(a[i+2] > j)
                    {
                        flag = 1;
                        i += 3;
                        while(i >= n)
                        break;
                    }
                }
            }
            else
            {
                flag = 0;
                break;
            }
        }
        if(flag == 1)
            sum ++;
    }
    cout << sum;
}