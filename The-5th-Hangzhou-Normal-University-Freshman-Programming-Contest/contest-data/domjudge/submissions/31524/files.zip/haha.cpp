#include<bits/stdc++.h>
using namespace std;
int m , k;
double a[10] , b[10];
bool st[10];
double res;

void dfs(int u , int pri , double pj)
{
	res = max(res , pj / (double)(pri - (pri / m) * k));
	for(int i = 1 ; i <= 5 ; i ++)
	{
		if(!st[i])
		{
			st[i] = true;
			dfs(i + 1 , pri + a[i] , pj + b[i]);
			st[i] = false;
		}
	}
	return;
}

int main()
{
	scanf("%d%d" , &m , &k);
	double pj , pri;
	for(int i = 1 ; i <= 5 ; i ++)scanf("%lf" , &a[i]);
	for(int i = 1 ; i <= 5 ; i ++)scanf("%lf" , &b[i]);
	dfs(1 , 0 , 0);
	printf("%.2lf" , res);
	return 0;
}
