#include <bits/stdc++.h>
#define ll long long

void solve() {
	int n, q, k;
	std::cin >> n >> k >> q;
	std::set<ll> s;
	std::map<ll, int> mp;
	
	std::vector<ll> a(n + 2, 0ll), cnt(n + 2, 0ll), snt(n + 2, 0ll), sum(n + 2, 0ll);
	
	for (int i = 1; i <= n; i++) {
		std::cin >> a[i];
	}
	
	int l = 1, r = 1;
	ll mini = a[l], maxi = a[r];
	
	mp[a[l]]++;
	s.insert(a[l]);
	
	while (r <= n - 1) {
		r++;
		mp[a[r]]++;
		s.insert(a[r]);
		auto it = s.upper_bound(maxi);
		if (it != s.end()) maxi = (*it);
		mini = (*s.begin());
		if (maxi - mini <= k) {
			continue;
		}	
		else {
			while(l <= n && maxi - mini > k) {
				cnt[l] = r - 1;
				snt[l] = r - l;
				mp[a[l]]--;
				if (mp[a[l]] == 0) s.erase(a[l]);
				auto it = s.upper_bound(maxi);
				if (it != s.end()) maxi = (*it);
				mini = (*s.begin());
				l++;
			}
		}
	}
	
	for (int i = l; i <= n; i++) {
		cnt[i] = n;
		snt[i] = n - i + 1;
	}
	
	/*for (int i = 1; i <= n; i++) {
		std::cout << cnt[i] << " \n"[i == n];
	}*/
	for (int i = n; i >= 1; i--) {
		sum[i] = sum[i + 1] + snt[i];
	}
	
	while (q--) {
		ll l, r;
		std::cin >> l >> r;
		ll pos = std::upper_bound(cnt.begin() + l, cnt.begin() + r + 1, r) - cnt.begin();
		//std::cout << "pos = " << pos << "\n";
		int tmp = 0;
		tmp = sum[l] - sum[pos] + (r - pos + 1) * r - (pos + r) * (r - pos + 1) / 2 + r - pos + 1; 
		std::cout << tmp << "\n";
	}
}

int main() {
	solve();
}
