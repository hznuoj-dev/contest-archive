#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
typedef long long LL;
typedef pair<int,int> PII;

void solve(){
    int n;
    cin>>n;
    vector<int> a(n);
    for(int i=0;i<n;i++) cin>>a[i];
    int l=0,r=n-1;
    if(n%2==1){
        cout<<0<<endl;
        return;
    }
    int minv=0,maxv=2e5+10;
    while(l<r){
        int n1=min(a[l],a[r]),n2=max(a[l],a[r]);
        minv=max(minv,n1);
        maxv=min(maxv,n2);
        l++,r--;
    }
    if(minv==maxv){
        cout<<1<<endl;
        return;
    }else{
        cout<<maxv-minv-1<<endl;
        return;
    }
}

bool multi=false;

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T=1;
    if(multi) cin>>T;
    while(T--){
        solve();
    }

    return 0;
}