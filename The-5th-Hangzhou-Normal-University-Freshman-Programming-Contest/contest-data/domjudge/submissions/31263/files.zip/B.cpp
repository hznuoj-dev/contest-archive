#include <iostream>
#include <algorithm>

using namespace std;
const int N = 2e5 + 10;
int a[N], b[N], n;
int step = 0;

int main(){
    cin >> n;
    for (int i = 1; i <= n; i++)
        scanf("%d", &a[i]);
    for (int i = 1; i <= n; i++)
        scanf("%d", &b[i]);
    sort(a + 1, a + 1 + n);
    sort(b + 1, b + 1 + n);
    
    int flag = 1; 
    for (int i = 2; i <= n; i++){
        if ((b[i-1] - a[i-1]) != (b[i] - a[i])){ 
            flag = 0;
            break;
        }
    }
    if (flag == 0) cout << -1 << endl;
    else {
        int ans = 0;
        ans = min(abs(a[1] - b[1]), abs(a[1] + b[n]));
        cout << ans << endl;
    }
    return 0;
}