
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
const int N=2e5+10;
int a[N],n,b[N];
bool ck(int x){
    int s=0,i;
    rep(i,1,n){
        if(a[i]<x)++s;
        if(a[i]>x)--s;
        if(s<0)return 0;
    }
    return s==0;
}
int main(){
    scanf("%d",&n);int i;
    rep(i,1,n)scanf("%d",&a[i]);
    rep(i,1,n)b[i]=a[i];
    sort(b+1,b+1+n);
    if(n&1){
        if(ck(b[n/2+1]))printf("1");else printf("0");
    }else{
        if(b[n/2]==b[n/2+1]){
            if(ck(b[n/2]))printf("1");else printf("0");
        }else if(b[n/2+1]-1==b[n/2])printf("0");
        else{
            if(ck(b[n/2+1]-1))printf("%d",b[n/2+1]-b[n/2]-1);else printf("0");
        }
    }
}