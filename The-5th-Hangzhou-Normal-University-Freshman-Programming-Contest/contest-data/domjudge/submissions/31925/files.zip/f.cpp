#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N=2e5+7,MOD=1e9+7;
int n,m,k,w[N],cnt[N];
ll a[N];
vector<int> e[N];

ll qpow(ll x,ll y){
	ll res=1;
	while(y>0){
		if(y&1) res=res*x%MOD;
		x=x*x%MOD;
		y>>=1;
	}
	return res;
}

void solve(){
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		int u,v;
		cin>>u>>v;
		e[u].push_back(v);
		cnt[v]++;
	}
	queue<int> q;
	for(int i=1;i<=n;i++) if(cnt[i]==0) q.push(i);
	while(!q.empty()){
		int now=q.front();
		q.pop();
		for(auto to:e[now]){
			w[to]=max(w[to],w[now]+1);
			cnt[to]--;
			if(cnt[to]==0) q.push(to);
		}
	}
	for(int i=1;i<=n;i++) a[w[i]]++;
	for(int i=1;i<N;i++) a[i]+=a[i-1];
	ll sum=0;
	for(int i=0;i<N;i++){
		sum=(sum+(a[i]-a[i-1])*(a[N-1]-a[i])%MOD)%MOD;
	}
	cout<<qpow(sum,k)<<'\n';
}

int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc=1;
//	cin>>tc;
	while(tc--) solve();
	return 0;
}
/*
3 3 3
1 2
2 3
1 2

4 7 2
1 2
1 4
2 3
1 4
1 3
1 2
4 3

3 8 0
2 3
2 1
2 3
3 1
2 1
2 1
2 3
3 1

3 3 3
1 3
3 2
1 2

*/
