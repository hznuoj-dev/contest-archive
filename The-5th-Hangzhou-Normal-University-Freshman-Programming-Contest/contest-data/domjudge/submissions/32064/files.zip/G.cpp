#include <iostream>
#include <algorithm>
#include <cmath>
#include <iomanip>
using namespace std;
const int N=2e5+10;
int a[N];
int main(void){
	long long n,m,b;
	cin>>n>>m>>b;
	long long sum=0;
	for(long long i=1;i<=n;i++){
		cin>>a[i];
		sum+=a[i];
	}
	if((n+1)%m==0){
		long long ans=0,ts=0;
		for(long long i=1;i<=n;i++){
			ts+=a[i];
			if((i+1)%m==0){
				if(ts<b){
					ans+=ts;
					ts=0;
				} else {
					ans+=b;
					ts-=b;
				}
			}
		}
		cout<<ans;
	} else {
		long long ans=0,ts=0,tn=n-1;
		while(tn>m){
			tn-=m;
		}
		for(long long i=1;i<=tn;i++){
			ts+=a[i];
		}
		for(long long i=tn+1,j=1;i<=n;i++,j++){
			ts+=a[i];
			if(j%m==1){
				if(ts<b){
					ans+=ts;
					ts=0;
				} else {
					ans+=b;
					ts-=b;
				}
			}
		}
		cout<<ans;
	}
	return 0;
}	