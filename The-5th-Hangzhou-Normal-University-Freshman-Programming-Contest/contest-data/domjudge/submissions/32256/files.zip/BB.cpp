#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n;
	long long a[N];
	long long b[N],c1[N],c2[N];
void slove(){
	
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		cin>>b[i];
	}
	sort(a,a+n);
	sort(b,b+n);
	int maxx=0,minn=0;
	int mm=0,nn=0;
	for(int i=0;i<n;i++){
		c1[i]=a[i]-b[i];
		if(i==0){
			maxx=c1[i];
			minn=c1[i];
		}
		else{
			if(maxx>=c1[i]) maxx=c1[i];
			if(minn<=c1[i]) minn=c1[i];
			}
	}
	
	for(int i=0;i<n;i++){
		b[i]=-b[i];
	}
	
	sort(b,b+n);
	for(int i=0;i<n;i++){
		c2[i]=a[i]-b[i];
		if(i==0){
			mm=c2[i];
			nn=c2[i];
		}
		else{
			if(mm>=c2[i]) mm=c2[i];
			if(nn<=c2[i]) nn=c2[i];
		}
	}
	
	if((maxx!=minn)&&(nn!=mm)){
		cout<<"-1";
		return;
	}
	if((abs(c1[0])>abs(c2[0]))&&(mm==nn)){
		cout<<abs(c2[0])+1;
		return;
	}
	else{
	//	cout<<c1[0]<<endl;;
		cout<<abs(c1[0]);
		return;
	}
	
	return;
}
int main(){
	int T=1;
//	cin>>T;
	while(T--){
		slove();
	}
	
	return 0;
} 
