#include<iostream>
#include<algorithm>
#include<cstring>
#include<map>

using namespace std;

const int N = 200010;
typedef long long LL;

map<int, int> mp, mpc;
int a[N], b[N], c[N];
int n;

int main()
{
    scanf("%d", &n);
    for(int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    for(int i = 0; i < n; i++)
    {
        scanf("%d", &b[i]);
        c[i] = -b[i];
    }

    sort(a, a + n), sort(b, b + n), sort(c, c + n);

    for(int i = 0; i < n; i++)
    {
        mp[b[i] - a[i]]++;
        mpc[c[i] - a[i]]++;
    }

    if(mp.size() > 1 && mpc.size() > 1) printf("-1\n");
    else printf("%d", min(abs(a[0] - b[0]), abs(a[0] - c[0]) + 1));

    return 0;
}

