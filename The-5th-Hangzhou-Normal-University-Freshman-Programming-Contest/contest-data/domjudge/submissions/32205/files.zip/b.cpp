#include<iostream>
#include<cmath>
#include<algorithm>
using namespace std;

//B
const int N=2e5+7;
typedef long long ll;
ll a[N],b[N],temp[N];
	int n;
	
ll op(ll *p){
	ll minn=2e9;
	for(int i=1;i<=n;i++){
		minn=min(minn,p[i]);
	}
	for(int i=1;i<=n;i++)p[i]-=minn;
	sort(p+1,p+1+n);
	return -minn;
}

ll re(ll* p){
	for(int i=1;i<=n;i++){
		p[i]=-p[i];
	}
	return op(p);
}

ll count(ll a,ll b){
	return a>b?a-b:b-a;
}

int main(){
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++){
		cin>>b[i];
		temp[i]=b[i];
	}
	ll disa=op(a);
	ll disb=op(temp);
	ll ans=2e9;
	bool flag=true;
	for(int i=1;i<=n;i++){
		if(a[i]!=temp[i])flag=false;
	}
	if(flag){
		ans=min(ans,count(disa,disb));
	}
	flag=true;
	disb=re(b);
	for(int i=1;i<=n;i++){
		if(a[i]!=b[i])flag=false;
	}
	if(flag){
		ans=min(ans,count(disa,disb)+1);
	}
	if(ans==2e9){
		cout<<-1;
	}else{
		cout<<ans;
	}
}


/*

3
1 1 2
2 2 1

0 0 1
0 1 1


3
1 2 3
4 5 6


3
-1 -2 -3
4 5 6

0 -1 -2
0 1 2

4
0 0 0 0
-1 -1 -1 -1


1
1000000000
-1000000000

1
100000000
-1

*/
