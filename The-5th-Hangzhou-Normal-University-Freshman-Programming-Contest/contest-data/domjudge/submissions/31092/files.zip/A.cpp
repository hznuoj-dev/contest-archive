#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;

int a[maxn],b[maxn];
int main(){
	int n,minn=-1,k=1;
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	int l=a[1]-b[1];
	for(int i=2;i<=n&&k;i++){
		if(a[i]-b[i]!=l)k--;
	}
	if(k){
		if(l<0)l=-l;
		minn=l;
	}
	k=1;
	for(int i=1;i<=n;i++)b[i]=-b[i];
	sort(b+1,b+1+n);
	l=a[1]-b[1];
	for(int i=2;i<=n&&k;i++){
		if(a[i]-b[i]!=l)k--;
	}
	if(k){
		if(l<0)l=-l;
		if(minn!=-1)minn=min(minn,l);
		else minn=l;
	}
	cout<<minn;
}