#include<bits/stdc++.h>

#define fu(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fd(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define PRN(X) cout << #X << "=" << X << endl
#define PR(X) cout << #X << "=" << X << " "
using namespace std;

const int N = 2e5 + 5;

int read(){
	int f = 1, x = 0; char ch = getchar();
	while(ch > '9' || ch < '0'){ 	if(ch == '-')f = -1; ch = getchar(); }
	while(ch <= '9' && ch >= '0'){ x = (x << 1) + (x << 3) + (ch ^ 48);  ch = getchar(); }
	return x * f;
}
vector<int> G[N], W[N];
int n, sz[N], f[N];
void dfs1(int u, int fa){
	sz[u] = 1;
	fu(i, 0, G[u].size() - 1){
		int v = G[u][i], w = W[u][i];
		if(v == fa) continue;
		dfs1(v, u);
		sz[u] += sz[v];
		if(sz[v] & 1) f[1] ^= w;
	}
}
void dfs2(int u, int fa){
	fu(i, 0, G[u].size() - 1) {
		int v = G[u][i], w = W[u][i];
		if(v == fa) continue;
		//if(v == 4) PR(sz[v]), PRN(n - sz[v]);
		if((n - sz[v]) % 2 != sz[v] % 2) f[v] = f[u] ^ w;
		else f[v] = f[u];
		dfs2(v, u);
	}
}
void solve(){
	
	n = read();
	fu(i, 1, n - 1) {
		int u = read(), v = read(), w = read();
		G[u].push_back(v);
		G[v].push_back(u);
		W[u].push_back(w);
		W[v].push_back(w);
	}
	dfs1(1, 0);
	dfs2(1, 0);
	//fu(i, 1, n) PR(f[i]);
	int q = read();
	fu(i, 1, q){
		int u = read(), w = read();
		if(n & 1) printf("%d\n", f[u] ^ w);
		else printf("%d\n", f[u]);
	}
}
int main(){
	
	solve();
}


