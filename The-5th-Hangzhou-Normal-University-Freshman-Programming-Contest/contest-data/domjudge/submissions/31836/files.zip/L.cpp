#include <bits/stdc++.h>
using namespace std;
const int N = 15;
struct Bis{
	int pri;
	int val;
	double pvp;//�Լ۱� 
}a[N];

bool cmp(Bis x, Bis y) {
	return x.pvp > y.pvp;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int m, k, vis = 0;
	cin >> m >> k;
	for(int i = 1; i <= 5; i++) {
		cin >> a[i].pri;
	}
	for(int i = 1; i <= 5; i++) {
		cin >> a[i].val;
	}
	for(int i = 1; i <= 5; i++) {
		a[i].pvp = (a[i].val * 1.0 / a[i].pri);
	}
	sort(a + 1, a + 1 + 5, cmp);
	double maxn = 0.0;
	int tcost = 0, tval = 0;
	for(int i = 1; i <= 5; i++) {
		tcost += a[i].pri;
		if(tcost % m == 0) {
			tcost -= k;
		}
		tval += a[i].val;
		if(tval * 1.0 / tcost > maxn) {
			maxn = tval * 1.0 / tcost;
		}
	}
	for(int i = 1; i <= 5; i++) {
		int tmp = a[i].pri;
		if(a[i].pri >= m) {
			tmp = a[i].pri - k;
		}
		if(a[i].val * 1.0 / tmp > maxn) {
			maxn = a[i].val * 1.0 / tmp;
		}
	}
	printf("%.2f", maxn);
	return 0;
}
