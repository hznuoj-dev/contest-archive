#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;
const long long mod = 1e9 + 7;

int n,fa[maxn],h[maxn];
long long a[maxn],b[maxn],t[maxn];
int find(int x){
	return fa[x]==x ? fa[x]: fa[x]=find(fa[x]);
}
void merge(int a,int b){
	int faa=find(a);
	int fbb=find(b);
	if(faa!=fbb){
		if(h[faa]<h[fbb]){
			t[fbb]+=t[faa];
			fa[faa]=fbb;
		}
		else {
			t[faa]+=t[fbb];
			fa[fbb]=faa;
			if(h[faa]==h[fbb])h[faa]++;
		}
	}	
}
void init(){
	for(int i=1;i<=n;i++){
		fa[i]=i;
		h[i]=0;
		t[i]=a[i];
	}
} 
void c1(){
	int u,v;
	cin>>u>>v;
	merge(u,v);
}
void c2(){
	int u,v;
	cin>>u>>v;
	int f=find(u);
	for(int i=1;i<=n;i++){
		if(find(i)==f){
			a[i]+=v;
			t[f]+=v;
		}
	}
}
void c3(){
	int u;
	cin>>u;
	cout<<b[u]%mod<<endl;
}
void xf(){
	for(int i=1;i<=n;i++){
		b[i]+=t[find(i)];
	}
//	for(int i=1;i<=n;i++)cout<<b[i]<<" ";
//	cout<<endl;
//	for(int i=1;i<=n;i++)cout<<t[find(i)]<<" ";
//	cout<<endl;
}
int main(){
	int q;
	cin>>n>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	init();
	xf();
	for(int i=1;i<=q;i++){
		int c;
		cin>>c;
		if(c==1)c1();
		else if(c==2)c2();
		else if(c==3)c3();
		xf();
	}
}