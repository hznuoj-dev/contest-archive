#include<bits/stdc++.h>
using namespace std;
int a[200005],b[200005];
int main(){
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
		scanf("%d",&a[i]);
	for(int i=0;i<n;i++)
		scanf("%d",&b[i]);
	sort(a,a+n);
	sort(b,b+n);
	int d=-1,d2=-1;
	int f1=1,f2=1;
	for(int i=0;i<n;i++){
		if(d==-1){
			d=abs(a[i]-b[i]);
			d2=abs(a[i]-(-b[n-i-1]));
		}else{
			if(abs(a[i]-b[i])!=d){
				f1=0;
			}
			if(abs(a[i]-(-b[n-i-1]))!=d2){
				f2=0;
			}
		}
	}
	long long ans=(long long)1e10;
	if(f1){
		ans=min((long long)d,ans);
	}
	if(f2){
		ans=min(1+(long long)d2,ans);
		//printf("%d\n",1+d2); 
	}
	if(ans==(long long)1e10)puts("-1");
	else printf("%lld\n",ans);
}
