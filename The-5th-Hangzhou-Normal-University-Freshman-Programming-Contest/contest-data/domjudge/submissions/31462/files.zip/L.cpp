#include <iostream>
#include <algorithm>
using namespace std;
const int N = 5;
int a[N], b[N];

int m, k;
int main()
{
    double ans = 0;
    scanf("%d %d", &m, &k);
    for(int i = 0; i < N; i++)  scanf("%d", &a[i]);
    for(int i = 0; i < N; i++)  scanf("%d", &b[i]);
    for(int i = 1; i < (1<<5); i++) {
        int sumA = 0, sumB = 0;
        for(int j = 0; j < N; j++) {
            if((1<<j) & i)  {
                sumA += a[j];
                sumB += b[j];
            }
        }
        ans = max(ans, sumA * 1.0 / sumB);
    }
    printf("%.02lf\n", ans);

    return 0;
}