#include<stdio.h>
int main()
{
	int n, k, a[200001];
	scanf("%d %d", &n, &k);
	for (int i = 1; i < n; i++)
		scanf("%d", &a[i]);
	if (n == k + 1)
	{
		printf("-1");
		return 0;
	}
	printf("%d", (n - k + 1) / 2);
}