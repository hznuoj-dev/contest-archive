#include <iostream>
#include <algorithm>

using namespace std;
const int N = 2e5 + 10;
int a[N], n;

int main(){
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
        scanf("%d", &a[i]);
    sort(a + 1, a + 1 + n);
    int mid = (1 + n) / 2;
    int ans = 0;
    if (n % 2 == 0){
        ans = a[mid + 1] - a[mid] - 1;
        if (ans < 0) ans = 1;
    }
    else ans = a[mid];

    cout << ans << endl;
    return 0;
    
}