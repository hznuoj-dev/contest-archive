#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>
#include <cstring>
#define endl "\n"
using namespace std;
typedef pair<int, int> PII;
typedef long long ll;

int n;
vector<int> a, b;
int k;
int va;

bool cmp(int a, int b)
{
    return abs(a) < abs(b) || abs(a) == abs(b) && a < b;
}

int main()
{
    cin >> n;
    for(int i = 0;i < n;i++)
    {
        int tt;
        cin >> tt;
        a.push_back(tt);
    }
    for(int i = 0;i < n;i++)
    {
        int tt;
        cin >> tt;
        b.push_back(tt);
    }
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    if(a[0] - b[0] == a[1] - b[1])
    {
        bool judge = 0;
        for(int i = 1;i < n - 1;i++)
        {
            if(a[i] - a[i + 1] != a[i - 1] - a[i] || b[i] - b[i + 1] != b[i - 1] - b[i])
            {
                judge = 1;
                break;
            }
        }
        if(abs(a[0] - b[0]) > abs(a[n - 1] + b[0]) + 1 && judge)
        {
            k = abs(a[n - 1] + b[0]) + 1;
            reverse(a.begin(), a.end());
            for(int i = 0;i < n;i++)
            {
                a[i] = -a[i];
            }
            
            va = a[0] - b[0];
        }
        else
        {
            k = abs(a[0] - b[0]);
            va = a[0] - b[0];
        }
    }
    else
    {
        reverse(a.begin(), a.end());
        for(int i = 0;i < n;i++)
        {
            a[i] = -a[i];
        }
        k = 1;
        if(a[0] - b[0] == a[1] - b[1])
        {
            k += abs(a[0] - b[0]);
            va = a[0] - b[0];
        }
    }
    for(int i = 0;i < n;i++)
    {
        if(a[i] - b[i] != va)
        {
            cout << -1;
            return 0;
        }
    }
    cout << k;
    return 0;
}
