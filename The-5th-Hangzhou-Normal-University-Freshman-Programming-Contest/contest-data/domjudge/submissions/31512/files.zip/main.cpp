#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;



void solve() {
    int n, k, q;
    std::cin >> n >> k >> q;
    std::vector<int>a(n + 2);
    std::multiset<int>s;
    for(int i = 1;i <= n;i++) std::cin >> a[i];
    std::vector<int>R(n + 2), sumR(n + 2);
    int l, r = 0;
    for(int i = 1;i <= n;i++) {
        while(r < n) {
            r++;
            s.insert(a[r]);
            int mn = *s.begin();
            int mx = *s.rbegin();
            if(mx - mn > k) {
                s.erase(s.find(a[r]));
                r--;
                break;
            }
        }
        R[i] = r;
        sumR[i] = R[i] - i + 1 + sumR[i - 1];
        s.erase(s.find(a[i]));
    }
    R[n + 1] = n + 1;
    while(q--) {
        std::cin >> l >> r;
        int p = std::upper_bound(R.begin(), R.end(), r) - R.begin();
        p--;
        if(p < l)p = l - 1;
        if(p > n) p = n;
        ll ans = sumR[p] - sumR[l - 1];
        ans += (1 + r - p) * (r - p) / 2;
        std::cout << ans << '\n';
    }
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    int T = 1;
    //std::cin >> T;
    while(T--) {
        solve();
    }
}