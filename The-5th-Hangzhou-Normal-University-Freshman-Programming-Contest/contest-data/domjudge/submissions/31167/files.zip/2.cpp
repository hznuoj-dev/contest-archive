#include<bits/stdc++.h>
using namespace std;
const int N=10;
int m,k,suma,sumb;
double ans;
struct node
{
	int a,b;
	double p;
}A[N];
bool cmp(node x,node y)
{
	return x.p>y.p;
}
int main()
{
	scanf("%d%d",&m,&k);
	for(int i=1;i<=5;++i)scanf("%d",&A[i].a);
	for(int i=1;i<=5;++i)scanf("%d",&A[i].b),A[i].p=((double)A[i].b)/A[i].a;
	sort(A+1,A+6,cmp);
	for(int i=1;i<=5;++i)
	{
		suma+=A[i].a,sumb+=A[i].b;
		if(suma<m)ans=max(ans,((double)sumb)/suma);
		else ans=max(ans,((double)sumb)/(suma-k));
	}
	printf("%.2lf\n",ans);
	return 0;
}
