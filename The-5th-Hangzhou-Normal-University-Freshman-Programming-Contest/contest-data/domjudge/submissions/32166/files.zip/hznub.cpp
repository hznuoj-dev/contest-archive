#include <bits/stdc++.h>

using namespace std;
using LL = long long;

constexpr int N = 2e5 + 5;

int a[N], c[N], b[N], n, cnt1, cnt2;

bool flag1, flag2;

void solve()
{
    cin >> n;

    for(int i = 1; i <= n; ++ i)cin >> a[i];

    for(int i = 1; i <= n; ++ i){
        cin >> b[i];
        c[i] = -a[i];
    }

    sort(b + 1, b + 1 + n);
    sort(c + 1, c + 1 + n);

    flag1 = 1, flag2 = 1;

    cnt1 = 0, cnt2 = 0;

    cnt1 = abs(a[1] - b[1]);
    cnt2 = abs(c[1] - b[1]);

    for(int i = 1; i <= n; ++ i)
    {
        if(abs(a[i] - b[i]) != cnt1)flag1 = 0;
        if(abs(c[i] - b[i]) != cnt2)flag2 = 0;
    }

    if(flag1 && !flag2){
        cout << cnt1 << endl;
    }else if(!flag1 && flag2){
        cout << cnt2 + 1 << endl;
    }else if(flag1 && flag2){
        cout << min(cnt1, cnt2 + 1) << endl;
    }else cout << -1 << endl;
    
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // int T;
    // for (cin >> T; T -- ; )
        solve();

}