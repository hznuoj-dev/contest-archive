#include <iostream>
#include <algorithm>
#include <cstring>
#include <map>
#include <vector>
#include <stack>

using namespace std;

int n, m;
vector<pair<int, int>> mp[200005];
int f[200005];
int oxr[200005];

void dfs(int i, int k)
{
    for (auto x : mp[i])
    {
        int v = x.first;
        long long w = x.second;
        if (!f[v])
        {
            f[v] = 1;
            oxr[v] = k ^ w;
            dfs(v, oxr[v]);
        }
    }
}

void solve()
{
    cin >> n;
    int u, v, x;
    for (int i = 0; i < n - 1; ++i)
    {
        cin >> u >> v >> x;
        mp[u].push_back({v, x});
        mp[v].push_back({u, x});
    }
    f[1] = 1;
    dfs(1, 0);
    int res = 0;
    for (int i = 2; i <= n; ++i)
    {
        res ^= oxr[i];
    }
    int q;
    cin >> q;
    while (q--)
    {
        cin >> u >> v;
        if (n % 2)
        {
            int ans = res ^ oxr[u] ^ v;
            cout << ans << endl;
        }
        else
        {
            cout << res << endl;
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}