#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const int N = 2e5 + 10, mod = 1e9 + 7;
#define endl "\n"
typedef pair <int, int> PII;
struct node{
    int x, y;
}r[N];
int a[N];
bool cmp1(node a, node b){
    return a.x > b.x;
}
bool cmp2(int a, int b){
    return a > b;
}
void solve(){
    priority_queue <int, vector <int>, greater <int>> pq;
    int num;
    cin >> num;
    for (int i = 1; i <= num; i ++)cin >> a[i];
    // if (num % 2){
    //     cout << 1 << endl;
    //     return;
    // }
    pq.push(a[1]);
    for (int i = 2; i <= num; i ++){
        if (pq.size() && a[i] >= pq.top()){
            pq.pop();
        }
        else if (pq.empty() || a[i] < pq.top())pq.push(a[i]);
    }
    if (num % 2){
        if (pq.size() == 1)cout << 1 << endl;
        else cout << 0 << endl;
        return;
    }
    else{
        if (pq.size())cout << 0 << endl;
        else{
            sort(a + 1, a + num + 1);
            int ans;
            if (a[num / 2] == a[num / 2 + 1])ans = 1;
            else ans = (a[num / 2 + 1] - a[num / 2] - 1);
            cout << ans << endl;
        }
    }
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int q;
    //cin >> q;
    q = 1;
    while (q --){
        solve();
    }
    return 0;
}