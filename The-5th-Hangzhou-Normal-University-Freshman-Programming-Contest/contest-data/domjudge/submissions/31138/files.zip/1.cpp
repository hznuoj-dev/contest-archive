#include<bits/stdc++.h>
using namespace std;
long long int a[300000],b[300000],c[300000];
int main()
{
	long long int n;
	long long int i;
	scanf("%lld",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(i=1;i<=n;i++)
	{
		scanf("%lld",&b[i]);
	}
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	for(i=1;i<=n;i++)
	{
		c[i]=a[i]-b[i];
	}
	for(i=1;i<n;i++)
	{
		if(c[i]!=c[i+1])
		{
			break;
		}
	}
	if(i>=n)
	{
		if(c[1]<0)
		{
			c[1]=-c[1];
		}
		printf("%lld",c[1]);
	}
	else
	{
		printf("-1");
	}
	return 0;
}
