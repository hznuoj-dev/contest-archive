#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n, m, b;
	int sum = 0, ans = 0;
	cin >> n >> m >> b;
	int a[n];
	
	int count;
	if(n%m==0)
	{
		count = n/m;
	}
	else
	{
		count = n/m+1;
	}
	
	int start = n-(count-1)*m-1;
	for(int i=0; i<=start; i++)
	{
		cin >> a[i];
		sum += a[i];
	}
	if(sum >= b)
	{
		ans += b;
		sum -= b;
	}
	else
	{
		ans += sum;
		sum = 0;
	}
	if(count>1)
	{
		for(int i=0; i<count-1; i++)
		{
			for(int j=1; j<=m; j++)
			{
				cin >> a[start+i*m+j];
				sum += a[start+i*m+j];
			}
			if(sum >= b)
			{
				ans += b;
				sum -= b;
			}
			else
			{
				ans += sum;
				sum = 0;
			}
		}		
	}
	cout << ans << endl;
	return 0;
}
