#include <iostream>
#include <algorithm>

using namespace std;
const int N = 2e5 + 10;

int a[N], b[N];
//int c[N];

int main (void)
{
	cin.tie(0);
	ios::sync_with_stdio(false);
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) cin >> a[i];
	for (int i = 0; i < n; i++) {
		cin >> b[i];
		//c[i] = -b[i];
	} 
	sort(a, a + n);
	sort(b, b + n);
	//sort(c, c + n);
	int ans1 = 0, ans2 = 0, f = 0;
	ans1 = abs(a[0] - b[0]);
	ans2 = abs(a[0] + b[n - 1]) + 1;
	for (int i = 1; i < n; i++)
	{
		if (ans1 != abs(a[i] - b[i]))
		{
			f = 1;
			break;
		}
	}
	for (int i = 1; i < n; i++)
	{
		if (ans2 != abs(a[i] + b[n - i - 1]) + 1)
		{
			if (f == 1)
			{
				cout << -1 << endl;
				return 0;
			}
			else
			{
				f = 2;
				break;
			}
		}
	}
	if (f == 2)
	{
		cout << ans1 << endl;
	}
	else if (f == 1)
	{
		cout << ans2 << endl;
	}
	else
	{
		cout << min(ans1, ans2) << endl;
	}
	
	
	
	return 0;
}
