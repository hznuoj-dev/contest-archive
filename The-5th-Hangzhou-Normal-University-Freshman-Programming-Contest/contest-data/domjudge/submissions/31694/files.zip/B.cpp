#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll ans = 100000000000000, maxn1 = -ans, maxn2 = -ans, min1 = ans;
ll a[200010], b[200010];
int main () {
	int n;
	cin >> n;
	map<ll, int> mp;
	int f1 = 1, f2 = 1;
	for (int i = 1; i <= n; i++) cin >> a[i], maxn1 = max(maxn1, a[i]), min1 = min(min1, a[i]);
	for (int i = 1; i <= n; i++) cin >> b[i], maxn2 = max(maxn2, b[i]);
	ll ans1 = abs(maxn1 - maxn2), d = maxn2 - maxn1;
//	cout << d << endl;
	for (int i = 1; i <= n; i++) mp[a[i] + d] ++;
	for (int i = 1; i <= n; i++) {
		if (!mp.count(b[i]) || mp[b[i]] <= 0) {
			f1 = 0;
			break;
		}
		mp[b[i]]--;
	}
	mp.clear();
	ll ans2;
	ans2 = abs(maxn2 + min1) + 1, d = maxn2 + min1;
	//cout << d << endl;
	for (int i = 1; i <= n; i++) mp[-a[i] + d] ++;
	for (int i = 1; i <= n; i++) {
		if (!mp.count(b[i]) || mp[b[i]] <= 0) {
			f2 = 0;
			break;
		}
		mp[b[i]]--;
	}
	if (f1) ans = min(ans, ans1);
	if (f2) ans = min(ans, ans2);
	if (!f1 && !f2) cout << "-1";
	else cout << ans;
	
}
