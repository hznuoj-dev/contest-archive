#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n;
	long long a[N];
	long long b[N],c1[N],c2[N];
void slove(){
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		cin>>b[i];
	}
	sort(a,a+n);
	sort(b,b+n);
	int C1,C2,f1=1,f2=1;
	for(int i=0;i<n;i++){
		c1[i]=a[i]-b[i];
		if(i==0) C1=c1[i];
		else{
			if(c1[i]!=C1){
				f1=0;
				break;
			}
		}
	}
	
	for(int i=0;i<n;i++){
		b[i]=-b[i];
	}
	
	sort(b,b+n);
	for(int i=0;i<n;i++){
		c2[i]=a[i]-b[i];
		if(i==0){
			C2=c2[i];
		}
		else{
			if(c2[i]!=C2){
				f2=0;
				break;
			}
		}
	}
	
	if(f1==0&&f2==0){
		cout<<"-1";
		return;
	}
	if(C1<0) C1=-C1;
	if(C2<0) C2=-C2;
	if(C1>C2){
		if(f2==1){
			cout<<C2+1;
		return;
		}
		else{
			cout<<C1;
			return;
		}
	}
	else{
		if(f1==1){
			cout<<C1;
			return;
		}
		else{
			cout<<C2+1;
			return;
		}
	}
	
	return;
}
int main(){
	int T=1;
//	cin>>T;
	while(T--){
		slove();
	}
	
	return 0;
} 
