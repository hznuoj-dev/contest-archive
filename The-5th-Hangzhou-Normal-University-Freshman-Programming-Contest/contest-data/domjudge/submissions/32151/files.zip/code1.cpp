#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IO ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
const int N = 2e5 + 5;
int n, a[N], m, b, d[N][2], s[N][2];


signed main(){
    IO;
    cin >>n >> m >> b;
    for(int i = 1;i <= n;i++)
        cin >> a[i];

    s[1][0] = a[1];
    s[1][1] = max(0ll, a[1] - b);
    d[1][1] = min(b, a[1]);

    int sum = a[1];
    for(int i = 2;i <= m;i++){
        sum += a[i];
        s[i][0] = s[i-1][1] + a[i];
        s[i][1] = sum - min(b, sum);
        // d[i][1] = min(b, sum);
        // d[i][0] = d[i-1][1];
    }

    for(int i = m+1;i <= n;i++){
        sum += a[i];
        s[i][0] = min(s[i-1][1],s[i-1][0]) + a[i];
        s[i][1] = s[i-1][0] + a[i];
        s[i][1] -= min(b, s[i][1]);
        // d[i][1] = max(d[i-m][1],d[i-m][0])
    }

    // for(int i = 1;i <= n;i++){
    //     cout << s[i][0] << ' ' << s[i][1] << '\n';
    // }

    cout << sum - min(s[n][1], s[n][0]);

    return 0;
}