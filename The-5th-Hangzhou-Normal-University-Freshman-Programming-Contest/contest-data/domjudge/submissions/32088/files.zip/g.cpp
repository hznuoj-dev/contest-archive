#include <bits/stdc++.h>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
using namespace std;
const int N = 1e5 + 10;
typedef long long ll;

void solve()
{
    ll n, m, b;
    cin >> n >> m >> b;
    vector<ll> a(n), s(n);
    for(int i = 0; i < n; i++) {
        cin >> a[i];
        if(i == 0) s[i] = a[i];
        else s[i] = s[i - 1] + a[i];
    }
    vector<ll> dp(n);
    for(int i = 0; i < n; i++) {
        if(i < m) dp[i] = min(s[i], b);
        else {
            dp[i] = min(dp[i - m] + b, s[i]);
        }
    }
    cout << dp[n - 1] << "\n";
}

int main()
{
    IOS
    int T = 1;
    // cin >> T;
    while(T--)
    {
        solve();
    }
    return 0;
}