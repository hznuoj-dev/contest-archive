#include <map>
#include <numeric>
#include <set>
#include <array>
#include <cmath>
#include <queue>
#include <stack>
#include <tuple>
#include <cctype>
#include <cstdio>
#include <string>
#include <vector>
#include <cassert>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <algorithm>
#include <functional>
#include <unordered_map>
using namespace std;

#define db double
#define il inline
#define fir first
#define sec second
#define eps (1e-10)
#define pb push_back
#define ll long long
#define mkp make_pair
#define eb emplace_back
#define pii pair<int, int>
#define lowbit(a) (a & (-a))
#define SZ(a) ((int)a.size())
#define ull unsigned long long
#define all(a) a.begin(), a.end()
#define split cout << "=========\n";
#define GG { cout << "NO\n"; return; }
#define pll pair<long long, long long>
#define equals(a, b) (fabs((a) - (b)) < eps)

constexpr int ON = 0;
constexpr int CW = -1;
constexpr int CCW = 1;
constexpr int BACK = 2;
constexpr int FRONT = -2;
const db pi = acos(-1.000);
constexpr int maxn = 3e5 + 50;
constexpr int INF = 0x3f3f3f3f;
constexpr ll LINF =  0x3f3f3f3f3f3f3f3f;
constexpr ll mod = 998244353; /* 1e9 + 7 */
constexpr int dir[8][2] = {-1, 0, -1, 1, 0, 1, 1, 1, 1, 0, 1, -1, 0, -1, -1, -1};


int n, k, q;
int a[maxn];
int st_min[20][maxn], st_max[20][maxn];

int lg[maxn];

void build_st() {
    for (int i = 2; i <= n; ++i)
        lg[i] = lg[i >> 1] + 1;
    for (int i = 1; i <= n; ++i)
        st_min[0][i] = st_max[0][i] = a[i];
    for (int j = 1; j <= 18; ++j)
        for (int i = 1; i + (1 << j) - 1 <= n; ++i)
            st_min[j][i] = min(st_min[j - 1][i], st_min[j - 1][i + (1 << (j - 1))]),
            st_max[j][i] = max(st_max[j - 1][i], st_max[j - 1][i + (1 << (j - 1))]);
}

int query_min(int l, int r) {
    int k = lg[r - l + 1];
    return min(st_min[k][l], st_min[k][r - (1 << k) + 1]);
}

int query_max(int l, int r) {
    int k = lg[r - l + 1];
    return max(st_min[k][l], st_max[k][r - (1 << k) + 1]);
}


ll sum[maxn << 2], lazy[maxn << 2];
void push_up(int p) {
    sum[p] = sum[p << 1] + sum[p << 1 | 1];
}
void push_down(int p, int l, int r) {
    if (lazy[p]) {
        int mid = (l + r) >> 1;
        sum[p << 1] += lazy[p] * (mid - l + 1);
        sum[p << 1 | 1] += lazy[p] * (r - mid);
        lazy[p << 1] += lazy[p];
        lazy[p << 1 | 1] += lazy[p];
        lazy[p] = 0;
    }
}
void update(int p, int l, int r, int ql, int qr, ll val) {
    if (ql <= l && r <= qr) {
        sum[p] += val * (r - l + 1);
        lazy[p] += val;
        return ;
    }
    push_down(p, l, r);
    int mid = (l + r) >> 1;
    if (ql <= mid) update(p << 1, l, mid, ql, qr, val);
    if (mid < qr) update(p << 1 | 1, mid + 1, r, ql, qr, val);
    push_up(p);
}
ll query(int p, int l, int r, int ql, int qr) {
    if (ql <= l && r <= qr) return sum[p];
    push_down(p, l, r);
    int mid = (l + r) >> 1;
    ll ans = 0;
    if (ql <= mid) ans += query(p << 1, l, mid, ql, qr);
    if (mid < qr) ans += query(p << 1 | 1, mid + 1, r, ql, qr);
    return ans;
}

pii tag[maxn];

struct Q {
    int id;
    int l, r;
    bool operator<(const Q t) const {
        return l < t.l;
    }
} qr[maxn];

ll ans[maxn];

void solve(int cas) {
    cin >> n >> k >> q;
    for (int i = 1; i <= n; ++i)
        cin >> a[i];
    build_st();
    for (int i = 1; i <= n; ++i) {
        int l = i, r = n;
        int L = i, R = i;
        while (l <= r) {
            int mid = (l + r) >> 1;
            if (query_max(i, mid) - query_min(i, mid) <= k) {
                R = mid;
                l = mid + 1;
            } else r = mid - 1;
        }
        tag[i] = {L, R};
        update(1, 1, n, L, R, 1);
    }
    for (int i = 1; i <= q; ++i) {
        cin >> qr[i].l >> qr[i].r;
        qr[i].id = i;
    }
    sort(qr + 1, qr + 1 + q);
    int j = 1;
    for (int i = 1; i <= n; ++i) {
        while (j <= q && qr[j].l <= i) {
            ans[qr[j].id] = query(1, 1, n, qr[j].l, qr[j].r);
            j++;
        }
        update(1, 1, n, tag[i].fir, tag[i].sec, -1);
    }
    for (int i = 1; i <= q; ++i)
        cout << ans[i] << '\n';
}


signed main() {
    // cout << fixed << setprecision(2);
    ios::sync_with_stdio(false); cin.tie(nullptr);
    // int T; cin>>T; while (T--)
    solve(1);
    return 0;
}
