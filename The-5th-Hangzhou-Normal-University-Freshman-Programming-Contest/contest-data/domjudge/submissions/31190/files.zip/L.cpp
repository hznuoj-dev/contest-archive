#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define fi first
#define se second
#define pii pair<int,int>
#define pb push_back
const int N = 200 + 10;

struct node {
	double a, b; 
}t[N];
void solve() {
	int m, k; cin >> m >> k;
	
	for (int i = 1; i <= 5; i++) cin >> t[i].a;
	for (int i = 1; i <= 5; i++) cin >> t[i].b;

	double ans = 0;
	int p[6];
	for (int i = 1 ; i <= 5; i++) p[i] = i;
//	cout << t[p[5]].a << ' ' << t[p[5]].b << endl;
	do {
		int prea = 0;
		double preb = 0;
		for (int i = 1; i <= 5; i++) {
			prea += t[p[i]].a;
			preb += t[p[i]].b;
			ans = max(ans, preb / (prea - (prea / m ? k : 0)));
//			cout << i << ' ' << p[i] << ' ' << preb / (prea - prea / m * k) << endl;
		}
	}while (next_permutation(p + 1, p + 6));
	
	
	printf("%.2f", ans);
	
	
}

/*
5 3 
1 2 4 4 2
2 2 1 2 4

*/
int main() {
	ios::sync_with_stdio(0); cout.tie(0); cin.tie(0);

	int T = 1;

	while(T--) solve();

	return 0;
}

