#include<bits/stdc++.h>
#define int long long
using namespace std;
int n=5,m,kk,a[6],b[6],fz,fm;
double ans=0;
void dfs(int k) {
	if (k==n+1) {
		if (!fm||!fz) return;
		bool ok=false;
		if (fm>=m) {
			ok=true;
			fm-=kk;
		}
		//cout << "fz=" << fz << ",fm=" << fm << endl;
		if (ans==0) ans=1.0*fz/fm;
		else ans=max(ans,1.0*fz/fm);
		if (ok) fm+=kk;
		return;
	}
	dfs(k+1);
	fz+=b[k];
	fm+=a[k];
	dfs(k+1);
	fz-=b[k];
	fm-=a[k];
	
}
signed main(){
	cin >> m >> kk;
	for (int i=1;i<=n;++i) cin >> a[i];
	for (int i=1;i<=n;++i) cin >> b[i];
	dfs(1);
	printf("%.2lf",ans);
}
