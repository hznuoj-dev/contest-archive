#include <bits/stdc++.h> 

using i64 = long long;

struct node {
	double x, y;
};

bool cmp(node a, node b)
{
	return a.y / a.x > b.y / b.x;
}

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int n, sum = 0, cnt = 1;
	std::vector<i64> a, b, c;
	std::map<i64, i64> mpa, mpc;
	
	std::cin >> n;
	a = std::vector<i64>(n);
	b = std::vector<i64>(n);
	c = std::vector<i64>(n);
	for (int i = 0; i < n; ++i) {
		std::cin >> a[i];
		mpa[a[i]] = 1;
		c[i] = -a[i];
		mpc[c[i]] = 1;
	}
	for (int i = 0; i < n; ++i)
		std::cin >> b[i];
	std::sort(a.begin(), a.end());
	std::sort(b.begin(), b.end());
	std::sort(c.begin(), c.end());
	int x = b[0] - a[0], y = b[0] - c[0];
	bool flag1 = false, flag2 = false;
	for (int i = 1; i < n; ++i) {
		if (b[i] - a[i] != x)
		flag1 = true;
		if (b[i] - c[i] != y)
		flag2 = true;
	}
	if (!flag1)
	std::cout << sum + abs(x);
	else if (!flag2)
	std::cout << cnt + abs(y);
	else {
		flag1 = flag2 = false;
		for (int i = 0; i < n; ++i) {
			if (!mpa[b[i]])
			flag1 = true;
			if (!mpc[b[i]])
			flag2 = true;
		}
		if (!flag1)
		std::cout << sum;
		else if (!flag2)
		std::cout << cnt;
		else
		std::cout << -1;
	}
	
	return 0;
} 
