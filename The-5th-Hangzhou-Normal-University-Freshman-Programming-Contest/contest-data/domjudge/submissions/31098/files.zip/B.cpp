#include <bits/stdc++.h>
using namespace std;
#define int long long
const int inf=0x3f3f3f3f;
int a[200200],b[200200],c[200200];
void solve() {
	int n;
	cin>>n;
	for (int i=1; i<=n; ++i) cin>>a[i];
	for (int i=1; i<=n; ++i) cin>>b[i],c[i]=-b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	int dif1=a[1]-b[1];
	bool flag1=true;
	for (int i=1; i<=n; ++i) {
		if (a[i]-b[i]!=dif1) {
			flag1=false;
			break;
		}
	}
	int dif2=a[1]-c[1];
	bool flag2=true;
	for (int i=1; i<=n; ++i) {
		if (a[i]-c[i]!=dif2) {
			flag2=false;
			break;
		}
	}
	if (flag1&&flag2) {
		cout<<min(abs(dif1),abs(dif2)+1)<<'\n';
	} else if (flag1) {
		cout<<abs(dif1)<<'\n';
	} else if (flag2) {
		cout<<abs(dif2)+1<<'\n';
	} else {
		cout<<"-1\n";
	}
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);

	int tt=1;
//	cin>>tt;
	while (tt--) solve();

	return 0;
}
