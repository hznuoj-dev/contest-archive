/**
 * HELLO WORLD
 * Author: ErodeesFleurs
**/

#include<bits/stdc++.h>

using namespace std;

#define quick ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
#define debug(a) cout<<#a<<"="<<a<<endl;
#define mm memset
#define rep(i,a,n) for (int i=a;i<n;i++)
#define per(i,a,n) for (int i=n-1;i>=a;i--)
#define llrep(i,a,n) for (ll i=a;i<n;i++)
#define llper(i,a,n) for (ll i=n-1;i>=a;i--)
#define pb push_back
#define all(x) (x).begin(),(x).end()
#define fi first
#define se second
#define mod(x) ((x)%MOD)

typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> PII;
typedef pair<ll,ll> PLL;

const int INF = 0x3f3f3f3f;
const ll L_INF=9223372036854775807;
const int MOD = 1e9+7;
const int NMAX = 500500;
const double eps = 1e-9;

ll gcd(ll a,ll b){return b==0?a:gcd(b,a%b);}
ll lcm(ll a,ll b){return a/gcd(a,b)*b;}
ll qmul(ll a,ll b){ll r=0;while(b){if(b&1)r=(r+a)%MOD;b>>=1;a=(a+a)%MOD;}return r;}
ll qpow(ll a,ll n){ll r=1;while(n){if(n&1)r=(r*a)%MOD;n>>=1;a=(a*a)%MOD;}return r;}
ll qpow(ll a,ll n,ll p){ll r=1;while(n){if(n&1)r=(r*a)%p;n>>=1;a=(a*a)%p;}return r;}
void exgcd(ll a,ll b,ll& d,ll& x,ll& y){if(!b) { d = a; x = 1; y = 0; }else{ exgcd(b, a%b, d, y, x); y -= x*(a/b); }}
ll inv(ll a, ll p){ll d,x,y;exgcd(a,p,d,x,y);return d == 1 ? (x+p)%p : -1;}

//CODE HERE//
ll n,m,k;
ll base=0;

struct node{
	ll v,po;
};

vector<node>mp[(ll)2e5+10];
vector<ll>siz(2e5+10);
vector<ll>po(2e5+10);

ll dfs(ll x,ll fa){
	siz[x]=1;
	rep(i,0,mp[x].size()){
		if(mp[x][i].v==fa)continue;
		po[mp[x][i].v]=po[x]^mp[x][i].po;
		siz[x]+=dfs(mp[x][i].v,x);
		if(siz[mp[x][i].v]%2==1)base^=mp[x][i].po;
	}
	return siz[x];
}

void solve(){
	cin>>n;
	rep(i,0,n-1){
		ll u,v,x;cin>>u>>v>>x;
		mp[u].pb({v,x});
		mp[v].pb({u,x});
	}
	dfs(1,0);
	ll q;cin>>q;
//	rep(i,0,n+1)cout<<po[i]<<" ";cout<<endl;
	while(q--){
		ll u,x;cin>>u>>x;
		ll ori=po[u]^x;
		if(n%2==0)cout<<base<<endl;
		else cout<<(base^ori)<<endl;
	}
}

int main(){
    quick;
    int t=1;
//    cin>>t;
    while(t--)solve();
	return 0;
}
/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5

*/
