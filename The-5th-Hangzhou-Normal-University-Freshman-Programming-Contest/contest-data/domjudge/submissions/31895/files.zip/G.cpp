#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
int a[200005];
void solve(){
	int n,m,b;
	cin>>n>>m>>b;
	for(int i = 1;i<=n;i++){
		cin>>a[i];
	}
	int ans = 0;
	int size = 0;
	for(int i = 1;i<=n;i++){
		size+=a[i];
		if((n-i)%m==0){
//			cout<<i<<'\n';
			ans += min(size,b);
			size = max(0,size-b);
		}
	}
	cout<<ans<<'\n';
}

signed main(){
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}

