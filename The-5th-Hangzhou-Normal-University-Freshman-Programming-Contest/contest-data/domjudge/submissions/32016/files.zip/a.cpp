#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
int a[maxn],num[maxn],b[maxn];
void solve(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b+1,b+1+n);
	int midl=n/2,midr=n/2+1;
	int ans=0;
	for(int i=b[midl];i<=b[midr];i++){
		int flag=1,flagl=0,flagr=0;
		for(int j=1;j<=n;j++){
			if(i>a[j]) flagl++;
			if(i<a[j]) flagr++;
			if(flagr>flagl){
				flag=0;
				break;
			}
		}
		if(flag &&flagl==flagr) ans++;
		//cout<<i<<" "<<ans<<"?\n";
	}
	cout<<ans<<"\n";
}
int main(){
	ios::sync_with_stdio(false);
	int T=1;
	//cin>>T;
	while(T--) solve();
}
