#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=2e5+10;
long long n,a[maxn],m,b,pre[maxn],ans,res[maxn],t;
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n>>m>>b;
    for(int i=1;i<=n;i++)   cin>>a[i];
    for(int i=1;i<=n;i++)   pre[i]=pre[i-1]+a[i];
    int pos=(n-1)%m+1;
    t=1;
    res[t]=pre[pos]-pre[0];
    for(int i=pos+m;i<=n;i++){
        if((i-pos)%m==0){
            //cout<<i<<endl;
            res[++t]=pre[i]-pre[i-m];
        }    
    }

    // for(int i=1+m;i<=n;i++){
    //     if((i-1)%m==0){
    //         res[++pos]=pre[i]-pre[i-m];
    //         tmp=i;
    //     }  
    // }
    // if(tmp!=n){
    //     res[pos]+=pre[n]-pre[tmp];
        
    // }
    //for(int i=1;i<=t;i++)   cout<<res[i]<<" ";
    for(int i=1;i<=t;i++){
        if(res[i]>b){
            ans+=b;
            res[i]-=b;
            res[i+1]+=res[i];
        }
        else    ans+=res[i];
    }
    cout<<ans;
}