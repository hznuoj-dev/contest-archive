#include<iostream>
#include<vector>
#include<algorithm>
#include<cmath>
using namespace std;
int main(){
	int n;
	cin>>n;
	int countall=1e9,countother=1e9;
	vector<int> all(n),final(n);
	for(int i=0;i<n;i++){
		cin>>all[i];
	}
	for(int i=0;i<n;i++){
		cin>>final[i];
	}
	sort(all.begin(),all.end());
	sort(final.begin(),final.end());
	vector<int> otherall= all;
	int flagall=1;
	int sign=all[0]-final[0];
	for(int i=1;i<n;i++){
		if(all[i]-final[i]!=sign){
			flagall=0;
			break;
		}
	}
	if(flagall){
		countall = abs(sign); 
	}
	for(int i=0;i<n;i++){
		otherall[i] = -otherall[i];
	}
	sort(otherall.begin(),otherall.end());
	int flagother=1;
	int signother=otherall[0]-final[0];
	for(int i=1;i<n;i++){
		if(otherall[i]-final[i]!=signother){
			flagother=0;
			break;
		}
	}
	if(flagother){
		countother = abs(signother)+1;
	}
	int result;
	if(flagall==0&&countother==0){
		result=-1;
	}
	else{
		result = min(countother,countall);
	}
	cout<<result;
	return 0;
}
