#include<bits/stdc++.h>

using namespace std;
#define int long long 
const int N = 2e5 + 5;
int a[N], p[N], n;

bool check(int x){
	int k = 0;
	for(int i = 1; i <= n; ++ i){
		if(a[i] < x)++k;
		if(a[i] > x)--k;
		if(k < 0)return false;
	}
	if(k == 0)return true;
	else return false;
}

void solve(){
	cin >> n;
	for(int i = 1; i <= n; ++ i)cin >> a[i], p[a[i]] ++;
	int ans = 0, k = 0;
	for(int i = 2; i < 2e5; ++ i){
		k += p[i - 1];
		if(k != n - k - p[i])continue;
		if(check(i))++ ans;
	}
	cout << ans ;
	
}

signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	solve();
	return 0;
}
