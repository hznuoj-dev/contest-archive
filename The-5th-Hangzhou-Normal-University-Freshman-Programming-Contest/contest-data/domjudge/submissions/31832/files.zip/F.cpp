#include <iostream>
#include <vector>
using namespace std;
const int N = 2e5 + 10;
struct edge {
    int to, w;
};
vector<edge> edges[N];

int sz[N], tmpAns[N];

void init(int u, int fa, int w) {
    sz[u] = 1;
    tmpAns[1] ^= w;
    for(edge &e: edges[u])  if(e.to != fa) {
        init(e.to, u, w ^ e.w);
        sz[u] += sz[e.to];
    }
}

int n;
void dfs(int u, int fa, int tw) {
    tmpAns[u] = tw;
    for(edge &e: edges[u])  if(e.to != fa) {
        int tmpw = tw ^ (sz[e.to] & 1? e.w: 0) ^ ((n - sz[e.to]) & 1? e.w: 0);
        dfs(e.to, u, tmpw);
    }
}

int main()
{
    int u, v, w;
    scanf("%d", &n);
    for(int i = 1; i < n; i++) {
        scanf("%d %d %d", &u, &v, &w);
        edges[u].push_back({v, w});
        edges[v].push_back({u, w});
    }

    init(1, 1, 0);
    dfs(1, 1, tmpAns[1]);
    int q;
    scanf("%d", &q);
    int x, a;
    for(int i = 0; i < q; i++) {
        scanf("%d %d", &x, &a);
        // printf(":%d\n", tmpAns[x]);
        printf("%d\n", tmpAns[x] ^ (n & 1? a: 0));
    }

    return 0;
}