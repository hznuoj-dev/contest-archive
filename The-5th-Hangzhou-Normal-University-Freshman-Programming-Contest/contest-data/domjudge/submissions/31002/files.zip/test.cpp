#include<bits/stdc++.h>
using namespace std;
    long long int a[200001],b[200001];
void read(long long int n,long long int a[]){
    for(int i=0;i<n;i++){
        cin>>a[i];
    }
}
int main(){
    long long int n;
    cin>>n;
    read(n,a);
    read(n,b);
    sort(a,a+n);
    sort(b,b+n);
    long long int c;
    c=a[0]-b[0];
    for(int i=0;i<n;i++){
        if((a[i]-b[i]!=c)){
            cout<<-1<<endl;
            return 0;
        }
    }
    cout<<abs(c)<<endl;
    return 0;
}