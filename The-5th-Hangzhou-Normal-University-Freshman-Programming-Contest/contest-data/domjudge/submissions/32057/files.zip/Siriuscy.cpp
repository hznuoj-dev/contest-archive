#include<bits/stdc++.h>
using namespace std;
#define N 6
int a[N] = {};
int b[N] = {};
int n, m;
double js(int suml, int power)
{
	double x;
	x = (1.0 * power) / (1.0 * (suml - suml / n * m));
	return x;
}
int main()
{
	scanf("%d%d", &n, &m);
	for (int i = 1; i <= 5; i++)
		scanf("%d", &a[i]);
	for (int i = 1; i <= 5; i++)
		scanf("%d", &b[i]);
	double minl = 0;
	for (int i = 1; i <= 5; i++)
	{
		double x;
		x = 1.0 * b[i] / (1.0 * (a[i] - a[i] / n * m));
		if (x > minl) minl = x;
	}
	int suml, power;
	double t;
	suml = a[1] + a[2];
	power = b[1] + b[2];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[3];
	power = b[1] + b[3];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[4];
	power = b[1] + b[4];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[5];
	power = b[1] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[2] + a[3];
	power = b[2] + b[3];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[2] + a[4];
	power = b[2] + b[4];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[2] + a[5];
	power = b[2] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[3] + a[4];
	power = b[3] + b[4];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[3] + a[5];
	power = b[3] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[4] + a[5];
	power = b[4] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[2] + a[3];
	power = b[1] + b[2] + b[3];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[2] + a[4];
	power = b[1] + b[2] + b[4];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[2] + a[5];
	power = b[1] + b[2] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[3] + a[4];
	power = b[1] + b[3] + b[4];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[3] + a[5];
	power = b[1] + b[3] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[4] + a[5];
	power = b[1] + b[4] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[2] + a[3] + a[4];
	power = b[2] + b[3] + b[4];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[2] + a[3] + a[5];
	power = b[2] + b[3] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[2] + a[4] + a[5];
	power = b[2] + b[4] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[3] + a[4] + a[5];
	power = b[3] + b[4] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[2] + a[3] + a[4];
	power = b[1] + b[2] + b[3] + b[4];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[2] + a[3] + a[5];
	power = b[1] + b[2] + b[3] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[2] + a[4] + a[5];
	power = b[1] + b[2] + b[4] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[3] + a[4] + a[5];
	power = b[1] + b[3] + b[4] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[2] + a[3] + a[4] + a[5];
	power = b[2] + b[3] + b[4] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	suml = a[1] + a[2] + a[3] + a[4] + a[5];
	power = b[1] + b[2] + b[3] + b[4] + b[5];
	t = js(suml, power);
	if (t > minl) minl = t;
	
	cout << fixed << setprecision(2) << minl;

	return 0;
}
