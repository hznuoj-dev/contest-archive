#include<iostream>
#include<cstdio>
#include<string>
#include<algorithm>
using namespace std;
typedef long long ll;

ll m, k;
struct cs
{
	int a, b;
	double c;
	int aa, bb;
};
cs c[8];
bool cmp(cs a, cs b)
{
	return a.c > b.c;
}
int main()
{
	cin >> m >> k;
	for (int i = 1; i <= 5; i++)
	{
	
		cin >> c[i].a;
	}

	for (int i = 1; i <= 5; i++)
	{
		cin >> c[i].b;
		c[i].c = 1.0 * c[i].b / c[i].a;
	}
	sort(c + 1, c + 6,cmp);
	double suma=0, sumb = 0;
	double t = 0;
	for (int i = 1; i <= 5; i++)
	{
		

		suma += c[i].a;
		sumb += c[i].b;
		double sumaa = suma;
		if (suma >= m) sumaa -= (sumaa/m*k);
		double s = 0;
		s = 1.0*sumb / sumaa;
		if (s > t) t = s;

	}
	printf("%.2lf", t);

	return 0;

}