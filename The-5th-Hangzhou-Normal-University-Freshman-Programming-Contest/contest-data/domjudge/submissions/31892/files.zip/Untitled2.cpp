#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[2000005],b[2000005];
int main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	int l,r;
	sort(b+1,b+1+n);
	if(n%2){
		l=b[(n+1)/2];
		r=l;
	}else{
		
		l=b[n/2];
		r=b[n/2+1];
		if(l!=r){
			l++;
			r--;
		}
	}
	if(l>r){
		cout<<0<<endl;
		return 0;
	}
	int u=0,f=0;
	for(int i=1;i<=n;i++){
		if(a[i]<l){
			u++;
		}else if(a[i]>r){
			u--;
		}
		if(u<0){
			f++;
			break;
		}
	}
	if(f||u){
		cout<<0<<endl;
	}else{
		cout<<r-l+1<<endl;
	}
	/*if(n%2&&count(b,b+n,b[n/2])%2==0){
		cout<<0<<endl;
	}else if(n%2&&count(b,b+n,b[n/2])%2==0){
		int k=b[n/2],f=0,u=0;
		for(int i=1;i<=n;i++){
			if(a[i]>k){
				u++;
			}else if(a[i]<k){
				u--;
			}
			if(u<0)f++;
		}
		if(f)cout<<0<<endl;
		else cout<<1<<endl;
	}else{
		if(b[n/2]==b[n/2-1]){
			if(count(b,b+n,b[n/2])%2){
				cout<<0<<endl;
			}else{
				int w=count(b,b+n,b[n/2])/2;
				int f=0;
				for(int i=0;i<w;i++){
					if(b[n/2-1-i]!=b[n/2+i]){
						f++;
						break;
					}
				}
				if(f){
					cout<<0<<endl;
				}else{
					int k=b[n/2],g=0;
					for(int i=1;i<=n;i++){
						if(a[i]>k){
							u++;
						}else if(a[i]<k){
							u--;
						}
						if(u<0)g++,break;
					}
					if(g)cout<<0<<endl;
					else cout<<1<<endl;
				}
			}
		}else if(b[n/2]-b[n/2-1]==1){
			cout<<0<<endl;
		}else{
			int k=b[n/2]-1,f=0,u=0;
			for(int i=1;i<=n;i++){
				if(a[i]>k){
					u++;
				}else if(a[i]<k){
					u--;
				}
				if(u<0)f++;
			}
			if(f)cout<<0<<endl;
			else cout<<b[n/2]-b[n/2-1]-1<<endl;
		}
	}*/
	return 0;
}