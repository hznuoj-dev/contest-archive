#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
typedef long long LL;
typedef pair<int,int> PII;
vector<int> a,b;
vector<int> c;

void solve(){
    int n;
    cin>>n;
    a.resize(n);
    b.resize(n);
    for(int i=0;i<n;i++) cin>>a[i];
    for(int i=0;i<n;i++) cin>>b[i];
    sort(a.begin(),a.end());
    sort(b.begin(),b.end());
    c=a;
    for(int i=0;i<n;i++){
        c[i]=-c[i];
    }
    sort(c.begin(),c.end());
    int res1=abs(b[0]-a[0]),res2=1+abs(b[0]-c[0]);
    for(int i=0;i<n;i++){
        if(abs(b[i]-a[i])!=res1){
            cout<<-1<<endl;
            return;
        }
    }
    for(int i=0;i<n;i++){
        if(abs(b[i]-c[i])+1!=res2){
            cout<<-1<<endl;
            return;
        }
    }
    cout<<min(res1,res2)<<endl;
}

bool multi=false;

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T=1;
    if(multi) cin>>T;
    while(T--){
        solve();
    }

    return 0;
}
