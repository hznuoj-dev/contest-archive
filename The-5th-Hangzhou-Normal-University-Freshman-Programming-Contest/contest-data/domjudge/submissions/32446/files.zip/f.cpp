#include<bits/stdc++.h>

#define star std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

#define endl "\n";

using namespace std;

typedef long long ll;

typedef unsigned long long ull;

const ll maxn = 2e5+7;

const ll mod =1e9+7;

const ll itf =0x3f3f3f3f;

const ll ITF =0x3f3f3f3f3f3f3f3f;

double pi = 3.1415926535898;


int n,m;
int x[maxn];
void solve(){
	int n;
	cin>>n;
	int sum;
	for(int i=1;i<=n-1;i++){
		int a,b,c;  cin>>a>>b>>c;
		x[a]++;
		x[b]++;
		sum^=c;
	}
//	cout<<(1^2^3^4^5);
//	cout<<sum<<endl;
	int q;  cin>>q;
	while(q--){
		int u,v;  cin>>u>>v;
//		cout<<
	}
//	cout<<(5^5^5^5^1^2^3^4^5)<<endl;
//	cin>>n;
//	int ans,x,y;
//	cin>>x>>y>>ans;
//	for(int i=2;i<=n-1;i++){
//		int a,b,c;
//		cin>>a>>b>>c;
//		ans^=c;
//	}
//	int q;
//	cin>>q;
//	while(q--){
//		int k,k2;  cin>>k>>k2;
//		cout<<ans<<endl;
//	}
}
signed main()
{
star;
int _=1;
//cin>>_;
while(_--){
solve();
}
return 0;
}
//��дջ

