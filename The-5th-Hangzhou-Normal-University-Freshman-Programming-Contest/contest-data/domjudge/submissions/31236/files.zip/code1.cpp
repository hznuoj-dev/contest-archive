#include<bits/stdc++.h>
using namespace std;
#define int long long
#define IO ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
const int N = 2e5 + 5;
int n,m, a[N], b[N], c[N];


signed main(){
    IO;

    int n;
    cin >> n;
    for(int i = 1;i <= n;i++)
    cin >> a[i];
    for(int i = 1;i <= n;i++)
    cin >> b[i], c[i] = -b[i];

    int ans = 0;

    sort(a+1, a+1+n);
    sort(b+1, b+1+n);
    sort(c+1, c+1+n);

    int d1 = a[1] - b[1], d2 = a[1] - c[1], f1 = 1, f2 = 1;
    for(int i = 1;i <= n;i++)
        if(a[i] - b[i] != d1){
            f1 = 0;
            break;
        }


    for(int i = 1;i <= n;i++)
        if(a[i] - c[i] != d2){
            f2 = 0;
            break;
        }

    int f = 0;
    if(f1 && f2){
        if(abs(a[1] - b[1]) > abs(a[1] - c[1]))
            f = 1;
    }else if(f2)
        f = 1;
    
    if(!f1 && !f2){
        cout << -1;
        return 0;
    }


    if(f){
        ans = 1 + abs(a[1] - c[1]);
    }else
        ans = abs(a[1] - b[1]);

    cout << ans;



    return 0;
}