#include <iostream>
#include <algorithm>
#include <string.h>
#include <math.h>

#define int long long
using namespace std;

const int N = 3e5 + 10;

int a[N]={0}, b[N]={0},c[N]={0};

void solve()
{
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	for (int i = 1; i <= n; i++){
		cin >> b[i];
		c[i] = -b[i];
	}
	if (n == 1)
	{
		if(a[1]*b[1]<0)
			cout << abs(abs(a[1]) - abs(b[1])) + 1 << endl;
		else
			cout << abs(a[1] - b[1]) << endl;
		return;
	}
	sort(a + 1, a + n + 1);
	sort(b + 1, b + n + 1);
	sort(c + 1, c + n + 1);
	int flag1 = 1,flag2=1;
	int num1 = a[1] - b[1], num2 = a[1] - c[1];
	for (int i = 2; i <= n; i++)
	{
		if (num1 != a[i] - b[i])
			flag1 = 0;
		if(num2 != a[i]-c[i])
			flag2 = 0;
		if(flag1==0&&flag2==0){
			break;
		}
	}
	if (flag1 == 1){
		cout << abs(num1) << endl;
		return;
	}
	else if(flag2==1){
		cout << abs(num2)+1 << endl;
		return;
	}
	else
		cout << -1 << endl;
}

signed main()
{
	int t = 1;
	//	cin >> t;
	while (t--)
	{
		solve();
	}
	return 0;
}