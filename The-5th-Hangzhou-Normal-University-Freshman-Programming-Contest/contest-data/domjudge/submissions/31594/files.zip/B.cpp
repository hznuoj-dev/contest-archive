#include <bits/stdc++.h>
using namespace std;
#define fastio ios::sync_with_stdio(false);cin.tie(0); cout.tie(0)
typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e6 + 5;

signed main(){
    fastio;
    int n,h=0;
    ll su1=0,su2=0,su3,c=0,a,b;
    cin>>n;
    for(int i=0;i<n;i++)cin>>a,su1+=a;
    for(int i=0;i<n;i++)cin>>b,su2+=b;
    if(su1>0&&su2<0&&min(su1,-su2)*2>n)h=1;
    else if(su1<0&&su2>0&&min(su2,-su1)*2>n)h=1;
    if(h==1){
        su3=abs(su1+su2);
        c=1;
    }
    else {
        su3=abs(su1-su2);
    }
    if(su3%n!=0){
        printf("-1");
        system("pause");
        return 0;
    }
    else {
        printf("%lld",(su3/n+c));
        system("pause");
        return 0;
    }
}