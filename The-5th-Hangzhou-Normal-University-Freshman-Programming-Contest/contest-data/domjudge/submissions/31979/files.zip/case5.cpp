#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;
typedef long long ll;
const int N = 2e5+10;
ll a[N];
ll b[N];
int n;
ll sum;
int main()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	for (int i = 1; i <= n; i++)
		cin >> b[i];
	sort(a + 1, a + n + 1);
	sort(b + 1, b + n + 1);
	long long k = abs(a[1] - b[1]);
	bool as = true;
	for (int i = 2; i <= n; i++)
	{
		if (abs(b[i] - a[i]) != k)
		{
			as = false;
			break;
		}
	}
	if (!as)
	{
		if (abs(a[1] + b[1]) < abs(a[1] - b[1]))
		{
			sum++;
			for (int i = 1; i <= n; i++)
			{
				a[i] *= -1;
			}
			sort(a + 1, a + n + 1);
			k = abs(a[1] - b[1]);
			for (int i = 2; i <= n; i++)
			{
				if (abs(b[i] - a[i]) != k)
				{
					cout << "-1";
					return 0;
				}
			}
		}
		else
		{
			cout << "-1";
			return 0;
		}
	}
	if (abs(b[1] - a[1]) >abs( b[1] + a[1]))
	{
		sum++;
		for (int i = 1; i <= n; i++)
		{
			a[i] *= -1;
		}
		sort(a + 1, a + n + 1);
	}
	sum += abs(b[1] - a[1]);
	cout << sum;
	return 0;
}