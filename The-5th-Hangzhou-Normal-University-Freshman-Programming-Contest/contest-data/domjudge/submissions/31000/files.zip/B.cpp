#include <iostream>
#include <algorithm>

using namespace std;

const int N = 200010;
int a[N], b[N];

int main()
{
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    for (int i = 0; i < n; i++)
        scanf("%d", &b[i]);
    sort(a, a + n);
    sort(b, b + n);
    int x = a[0] - b[0];
    int flag = 1;
    for (int i = 1; i < n; i++)
    {
        if (a[i] - b[i] != x)
            flag = 0;
    }
    if (flag == 0)
        puts("-1");
    else
    {
        int res = min(abs(a[0] - b[0]), abs(a[0] + b[0]));
        printf("%d\n", res);
    }
    return 0;
}