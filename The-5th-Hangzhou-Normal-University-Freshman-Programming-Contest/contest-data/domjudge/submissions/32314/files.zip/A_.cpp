#include <bits/stdc++.h>
using namespace std;

int main(){
    int n;cin>>n;
    vector<int> a(n+1),b(n+1);
    
    for(int i=1;i<=n;i++){
        int x;cin>>x;
        a[i] = b[i] = x;
    }

    sort(b.begin()+1,b.end());
    
    if(n&1){
        int k = b[n/2+1] , l = 0 , r = 0;
        for(int i=1;i<=n;i++){
            if(a[i] < k) l++;
            if(a[i] > k) r++;
            if(r > l) {
                cout << 0 << "\n";
                return 0;
            }
        }
        if(l==r) cout << 1 << "\n";
        else cout << 0 << "\n";
    }else{
        int k1 = b[(n+1)/2] , k2 = b[(n+2)/2];
        int l = 0 , r = 0;
        if(k1 == k2){
            for(int i=1;i<=n;i++){
                if(a[i] < k1) l++;
                if(a[i] > k1) r++;
                if(r > l) {
                    cout << 0 << "\n";
                    return 0;
                }
            }
            if(l==r) cout << 1 << "\n";
            else cout << 0 << "\n";
        }else{
            int res = k2 - k1 - 1;
            int l = 0 , r = 0;
            for(int i=1;i<=n;i++){
                if(a[i] < k1) l++;
                if(a[i] > k1) r++;
                if(r > l) break;
            }
            if(l==r)res++;
            l = 0 , r = 0;
            for(int i=1;i<=n;i++){
                if(a[i] < k2) l++;
                if(a[i] > k2) r++;
                if(r > l) break;
            }
            if(l==r)res++;
            cout << res << "\n";
        }
    }
    return 0;
}
