#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int long long
const ll N=5e5+7;
const ll mod=1e9+7;
const ll inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
const double eps=1e-6;

int a[N];
void solve()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++)
    {
    	cin>>a[i];
	}
	sort(a,a+n);
	if(n%2!=0)
	{
		int num=0;
		int k=a[n/2];
		for(int i=0;i<n;i++)
		{
			if(a[i]>k) num--;
			else if(a[i]<k) num++;
			if(num<0)
			{
				cout<<"0";
				return;
			}
		}	
		if(num==0)cout<<"1";
		else cout<<"0";
	 } 
	else 
	{
		int r=a[n/2];
		int l=a[n/2-1];
		int k=(l+r)>>1;
		if(k==l&&k!=r) cout<<"0";
		else 
		{
			int num=0;
			for(int i=0;i<n;i++)
			{
				if(a[i]>k) num--;
				else if(a[i]<k) num++;
				if(num<0)
				{
					cout<<"0";
					return;
				}
			}	
			if(num==0&&l==r)cout<<"1";
			else if(num==0) cout<<r-l-1;
			else cout<<"0";	
		}
	}
}
signed main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int _=1;
//	cin>>_;
	while(_--)
	{
		solve();
	}
	return 0;
}

