#include<cstdio>
#include<algorithm>
using namespace std;
struct node
{
	float a;
	float b;
	float c;
};
node w[20];
int cmp(node w1,node w2)
{
	return w1.c>w2.c;
}
int main()
{
	int n,k,i;
	scanf("%d%d",&n,&k);
	for(i=1;i<=5;i++)
	scanf("%f",&w[i].a);
	for(i=1;i<=5;i++)
	{
		scanf("%f",&w[i].b);	
		w[i].c=w[i].b/w[i].a;
	}	
	sort(w+1,w+5+1,cmp);
	if(w[1].a>n)
	{
		printf("%.2f",w[1].b/(w[1].a-k));return 0;
	}
	int sum1=0,bk=0,sum2=0;
	for(i=1;i<=5;i++)
	{
		sum1+=(int)w[i].a;sum2+=(int)w[i].b;//printf("%d %d\n",sum1,sum2);
		if(sum1>=n)
		{
			bk=1;break;
		}
	}
	if(bk==0)printf("%.2f",w[1].c);
	else
	if((float)(sum2/(sum1-k))>w[1].c)printf("%.2f",(float)(sum2/(sum1-k)));
	else printf("%.2f",w[1].c);
	return 0;
} 
