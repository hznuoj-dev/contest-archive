#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 2e5 + 5;
int a[N], f[N], s[N];
int n, m, b;

signed main(){
	cin >> n >> m >> b;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
		s[i] = s[i - 1] + a[i];
	}
//	f[1] = min(b, s[1]);
	for(int i = 1; i <= n; i++){
		if(i <= m){
			f[i] = min(s[i], b);
			continue;
		}
		for(int j = m; j <= i; j++){
			f[i] = max(f[i], f[i - j] + min(s[i] - f[i - j], b));
		}
	}
	cout << f[n];
	return 0;
}

/*
5 2 10
5 9 3 1 8

6 2 10
20 1 1 1 1 5
*/
