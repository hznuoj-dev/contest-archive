#include <bits/stdc++.h>

using namespace std;

const int N = 2e5 + 10;

struct node
{
    int c;
    int a;
    int b;
} st[N];

int m, k;

int main()
{
    cin >> m >> k;

    for (int i = 0; i < 5; i++)
    {
        cin >> st[i].a;
    }

    for (int i = 0; i < 5; i++)
    {
        cin >> st[i].b;
    }

    for (int i = 0; i < 5; i++)
    {
        st[i].c = st[i].b - st[i].a;
    }

    for (int i = 0; i < 5; i++)
    {
        int t = i;
        for (int j = i + 1; j < 5; j++)
        {
            if (st[t].c < st[j].c)
                t = j;
        }
        if (t != i)
        {
            swap(st[t].c, st[i].c);
            swap(st[t].a, st[i].a);
            swap(st[t].b, st[i].b);
        }
    }

    for (int i = 0; i < 5; i++)
    {
        int j;
        for (j = i + 1; j < 5; j++)
        {
            if (st[j].c != st[i].c)
                break;
        }
        for (int k = i; k < j;k++){
            int t=k;
            for (int l = k + 1; l < j;l++){
                if(st[t].a<st[l].a)
                    t = l;
            }
            if(t!=k){
                swap(st[t].c, st[k].c);
                swap(st[t].a, st[k].a);
                swap(st[t].b, st[k].b);
            }
        }
    }

    /*for (int i = 0; i < 5; i++)
    {
        cout << "sta=" << st[i].a << endl;
        cout << "stb=" << st[i].b << endl;
        cout << "stc=" << st[i].c << endl;
    }*/

    int sum1 = 0;
    int sum2 = 0;
    double res = -1e9;
    for (int i = 0; i < 5; i++)
    {
        double t;
        sum1 += st[i].a;
        sum2 += st[i].b;
        if (sum1 >= m)
        {
            t = 1.0 * sum2 / (sum1 - k);
        }
        else
        {
            t = 1.0 * sum2 / sum1;
        }
        // printf("%.2llf ", t);
        // cout << "res=" << res << endl;
        res = max(res, t);
    }
    printf("%.2llf", res);
    return 0;
}