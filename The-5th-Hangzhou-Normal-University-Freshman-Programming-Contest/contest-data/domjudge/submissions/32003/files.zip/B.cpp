#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main(){
	int n;
	cin>>n;
	vector<int> all(n),final(n);
	for(int i=0;i<n;i++){
		cin>>all[i];
	}
	for(int i=0;i<n;i++){
		cin>>final[i];
	}
	sort(all.begin(),all.end());
	sort(final.begin(),final.end());
	int flag=1;
	int sign=all[0]-final[0];
	for(int i=1;i<n;i++){
		if(all[i]-final[i]!=sign){
			flag=0;
			break;
		}
	}
	if(flag==1){
		cout<<abs(sign);
		return 0;
	}
	else{
		reverse(all.begin(),all.end());
		for(int i=0;i<n;i++){
			all[i] = -all[i];
		}
		int di =1;
		int si =all[0]-final[0];
		for(int i=1;i<n;i++){
			if(all[i]-final[i]!=si){
				di=0;
				break;
			}
		}
		if(di==1){
			cout<<abs(si)+1;
			return 0;
		}
		else
		{
			cout<<-1;
			return 0;
		}
	}
	return 0;
}
