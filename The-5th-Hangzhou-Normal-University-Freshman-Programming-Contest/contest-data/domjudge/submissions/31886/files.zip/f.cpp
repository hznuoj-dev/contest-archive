/*
 * @Author: JSY
 * @Date: 2023-05-27 14:04:04
 * @Last Modified by: JSY
 * @Last Modified time: 2023-05-27 14:04:04
*/

#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int, int>
#define IOS ios::sync_with_stdio(0);cin.tie(0), cout.tie(0)
const int N = 200010;
int n;
vector<PII> v[N];
int yi[N];
int ans = 0;

void dfs(int x,int fa){
    ans = ans ^ yi[x];
    for(int i=0;i<v[x].size();i++){
        int t = v[x][i].first ,w = v[x][i].second;
        if(t == fa) continue;
        yi[t] = w ^ yi[x];
        dfs(t,x);
    }
    return ;
}

signed main(){
    IOS;
    cin >> n;
    for(int i=1;i<n;i++){
        int a,b,w;
        cin >> a >> b >> w;
        v[a].push_back({b,w});
        v[b].push_back({a,w});
    }
    yi[1] = 0;
    dfs(1,0);
    int q;
    cin >> q;
    while(q--){
        int y,shu;
        cin >> y >> shu;
        if(n % 2 == 0) cout << ans << '\n';
        else{
            int x = yi[y] ^ shu ^ ans;
            cout << x << '\n';
        }
    }
    return 0;
}