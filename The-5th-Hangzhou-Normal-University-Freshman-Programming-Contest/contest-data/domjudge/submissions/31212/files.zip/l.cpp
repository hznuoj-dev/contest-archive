/*
 * @Author: JSY
 * @Date: 2023-05-27 12:22:32
 * @Last Modified by: JSY
 * @Last Modified time: 2023-05-27 12:22:32
*/

#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define PII pair<int, int>
#define IOS ios::sync_with_stdio(0);cin.tie(0), cout.tie(0)
const int N = 10010;
int a[N],b[N];

signed main(){
    //IOS;
    int m,p;
    cin >> m >> p;
    for(int i=1;i<=5;i++) cin >> a[i];
    for(int i=1;i<=5;i++) cin >> b[i];
    double ans = 0.0;
    //1
    for(int i=1;i<=5;i++){
        int c = a[i];
        if(c >= m) c -= p;
        double res = (double)b[i] / (double)c;
        ans = max(ans , res);
    }
    //2;
    for(int i=1;i<=4;i++){
        for(int j=i+1;j<=5;j++){
            int c = a[i] + a[j];
            int w = b[i] + b[j];
            if(c >= m) c -= p;
            double res = (double)w / (double)c;
            ans = max(ans , res);
            
        }
    }
    //3;
    for(int i=1;i<=3;i++){
        for(int j=i+1;j<=4;j++){
            for(int k=j+1;k<=5;k++){
                int c = a[i] + a[j] + a[k];
                int w = b[i] + b[j] + b[k];
                if(c >= m) c -= p;
                double res = (double)w / (double)c;
                ans = max(ans , res);
                //cout << "---" << ans << '\n';
            }
        }
    }
    //4
    for(int i=1;i<=2;i++){
        for(int j=i+1;j<=3;j++){
            for(int k=j+1;k<=4;k++){
                for(int u=k+1;u<=5;u++){
                    int c = a[i] + a[j] + a[k] + a[u];
                    int w = b[i] + b[j] + b[k] + b[u];
                    if(c >= m) c -= p;
                    double res = (double)w / (double)c;
                    ans = max(ans , res);
                }
            }
        }
    }
    // 5
    int c = a[1] + a[2] + a[3] + a[4] + a[5];
    int w = b[1] + b[2] + b[3] + b[4] + b[5];
    if(c >= m) c -= p;
    double res = (double)w / (double)c;
    ans = max(ans , res);
    printf("%.2f",ans);
    //cout << ans;
    return 0;
}