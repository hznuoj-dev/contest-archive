#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn=2e5+7;
ll n;
ll a[maxn],b[maxn];
void solve(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	ll ans1=a[1]-b[1],ans2=a[1]+b[1];
	int flag1=0,flag2=0;
	for(int i=2;i<=n;i++){
		if(a[i]-b[i]!=ans1){
			flag1=1;
			break;	
		}
	}
	for(int i=2;i<=n;i++){
		if(a[i]+b[i]!=ans2){
			flag2=1;
			break;
		}
	}
	int flag3=0,flag4=0;
	for(int i=1;i<=n;i++){
		a[i]=(-a[i]);
	}
	sort(a+1,a+1+n);
	ll ans3=a[1]-b[1],ans4=a[1]+b[1];
	for(int i=2;i<=n;i++){
		if(a[i]-b[i]!=ans3){
			flag3=1;
			break;	
		}
	}
	for(int i=2;i<=n;i++){
		if(a[i]+b[i]!=ans4){
			flag4=1;
			break;
		}
	}
	if(flag1&&flag2&&flag3&&flag4)cout<<-1;
	else{
		ll x=-1;
		if(flag1==0)x=abs(ans1);
		if(flag2==0){
			if(x==-1)x=abs(ans2)+1;
			else x=min(x,abs(ans2)+1);
		}
		if(flag3==0){
			if(x==-1)x=abs(ans3)+1;
			else x=min(x,abs(ans3)+1);
		}
		if(flag4==0){
			if(x==-1)x=abs(ans4)+2;
			else x=min(x,abs(ans4)+2);
		}
		cout<<x;
	}
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
	return 0;
}