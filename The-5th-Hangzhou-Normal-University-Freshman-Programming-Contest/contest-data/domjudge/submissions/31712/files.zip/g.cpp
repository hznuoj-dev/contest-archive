#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
typedef long long LL;
typedef pair<int,int> PII;

const int N=2e5+10;

int n,m,b;
int a[N];
bool st[N];

void solve(){
    cin>>n>>m>>b;
    for(int i=1;i<=n;i++) cin>>a[i];
    for(int i=n;i>=1;i-=m){
        st[i]=true;
    }
    int cur=0;
    int res=0;
    for(int i=1;i<=n;i++){
        cur+=a[i];
        if(st[i]){
            int t=min(cur,b);
            cur-=t;
            res+=t;
        }
    }
    cout<<res<<endl;
}

bool multi=false;

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T=1;
    if(multi) cin>>T;
    while(T--){
        solve();
    }

    return 0;
}