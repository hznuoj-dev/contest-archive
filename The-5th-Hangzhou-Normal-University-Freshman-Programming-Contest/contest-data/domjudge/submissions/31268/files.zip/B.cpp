#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int long long
const ll N=5e5+7;
const ll mod=1e9+7;
const ll inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
const double eps=1e-6;

int a[N];
int a1[N];
int b[N];
void solve()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		a1[i]=-a[i];
	}
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
	}
	sort(a,a+n);
	sort(b,b+n);
	sort(a1,a1+n);
	int g=0;
	int ans=INF;
	for(int i=0;i<n;i++)
	{
		if(a[i]-b[i]!=a[0]-b[0]) 
		{
			g=1;
			break;
		}
	}
	if(g==0) ans=min(abs(a[0]-b[0]),ans);
	g=0;
	for(int i=0;i<n;i++)
	{
		if(a1[i]-b[i]!=a1[0]-b[0]) 
		{
			g=1;
			break;
		}
	}
	if(g==0) ans=min(abs(a1[0]-b[0]+1),ans);
	if(ans==INF) cout<<"-1";
	else cout<<ans;
}
signed main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int _=1;
//	cin>>_;
	while(_--)
	{
		solve();
	}
	return 0;
}


