#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>
#include <cstring>
#define endl "\n"
using namespace std;
typedef pair<int, int> PII;
typedef long long ll;

int m, k;
int a[5], b[5];
int n, p[5];
bool v[5];
double rat;

void dfs(int u)
{
    if(u == n)
    {
        int pr = 0, xi = 0;
        for(int i = 0;i < n;i++)
        {
            xi += b[p[i]];
            pr += a[p[i]];
        }
        if(pr >= m)
        pr -= k;
        rat = max(rat, xi * 1.0 / pr);

    }
    else
    {
        for(int i = (u == 0 ? 0 : p[u - 1] + 1);i < 5;i++)
        {
            p[u] = i;
            dfs(u + 1);
        }
    }
}


int main()
{
    cin >> m >> k;
    for(int i = 0;i < 5;i++)
    {
        cin >> a[i];
    }
    for(int i = 0;i < 5;i++)
    {
        cin >> b[i];
    }
    for(int i = 1;i <= 5;i++)
    {
        n = i;
        dfs(0);
    }
    printf("%.2f", rat);
    return 0;
}
