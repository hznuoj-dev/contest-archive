#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
struct node {
	int t;
	int num;
};
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int T;
	//cin >> T;
	T = 1;
	while (T--)
	{
		int n, m, b, ans = 0,temp;
		cin >> n >> m >> b;
		vector<int>s;
		for (int i = 0;i < n;i++)
		{
			cin >> temp;
			s.push_back(temp);
			if(i)s[i]+=s[i-1];
		}
		int st=n-1;
		while(st-m>=0)st-=m;
		for(int i=st;i<n;i+=m)
		{
			s[i]-=ans;
			if(s[i]>b)ans+=b;
			else ans+=s[i];
		}
		cout<<ans<<endl;
	}
	return 0;
}