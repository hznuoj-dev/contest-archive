#include<bits/stdc++.h>
using namespace std;

void solve() {
	int n,m;// ��ʱ�� n ,���m
	long long b;
	cin>>n>>m>>b;
	int a[n+1];
	long long S[n+1]= {0};
	for(int i=1; i<=n; i++) {
		cin>>a[i];
		S[i]=S[i-1]+a[i];
	}
	long long que=0;//�����е�����
	long long sum=0;
	int x=ceil(1.0*n/m);//������ x
	//int time=1-m;//��һ�η��е�ʱ��
	int start=n-(x-1)*m;

	for(int i=1; i<=n; i++) {
		que+=a[i];
		if(i>=start) {
			if((i-start)%m==0) {
				if(que>b) {
					sum=sum+b;
					que=que-b;
				} else {
					sum=sum+que;
					que=0;
				}
			}
		}

	}
	cout<<sum<<endl;
}

signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int t;
	//cin>>t;
	t=1;
	while(t--) {
		solve();
	}
	return 0;
}
