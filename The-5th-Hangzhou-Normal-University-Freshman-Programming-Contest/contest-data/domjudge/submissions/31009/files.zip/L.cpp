#include<bits/stdc++.h>
using namespace std;

int a[100], b[100];

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	int m, k; cin >> m >> k;
	for(int i = 1; i <= 5; ++i)
	{
		cin >> a[i];
	}
	for(int i = 1; i <= 5; ++i)
	{
		cin >> b[i];
	}
	
	vector<int> flag, bin;
	for(int i = 1; i <= 5; ++i)
	{
		flag.push_back(i);
	}
	bin = flag;
	
	double ans = 0, tb = 0, ta = 0;
	do
	{
		for(int i = 1; i <= 5; ++i)
		{
			ta = 0, tb = 0;
			for(int j = 1; j <= i; ++j)
			{
				tb += b[flag[j - 1]];
				ta += a[flag[j - 1]];
			}
			if(ta >= m) ta = ta - k;
			ans = max(ans, tb / ta);
		}
		
		next_permutation(flag.begin(), flag.end());
	}while(flag != bin);
	
	printf("%.2lf", ans);
}
