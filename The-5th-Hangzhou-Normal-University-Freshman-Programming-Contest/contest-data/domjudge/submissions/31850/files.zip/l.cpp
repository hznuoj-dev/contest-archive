#include<iostream>
#include<algorithm>
#include<iomanip>
using namespace std;
double d[5];
struct node
{
	int a;
	int b;
	double c;
}x[10];

bool cmp(node x1,node x2)
{
	if(x1.c!=x2.c)
	{
		return x1.c>x2.c;
	}
	else
	{
		return x1.a<x2.a;
	}
}

int main()
{
	int m,k;
	cin >> m >> k;
	for(int i=1;i<=5;i++)
	{
		cin >> x[i].a;
	}
	for(int i=1;i<=5;i++)
	{
		cin >> x[i].b;
	}
	for(int i=1;i<=5;i++)
	{
		x[i].c=x[i].b*1.0/x[i].a;
	}
	sort(x+1,x+6,cmp);
	int p,q;
	for(int i=1;i<=5;i++)
	{
		p=0,q=0;
		for(int j=1;j<=i;j++)
		{
			p+=x[j].a;
			q+=x[j].b;
			int x=min(1,p/m);
			p-=x*k;
			d[i-1]=q*1.0/p;
		}
	}
	double max=0;
	for(int i=0;i<=4;i++)
	{
		if(d[i]>max) max=d[i];
	}
	cout << fixed << setprecision(2) << max << endl;
	return 0;
}
