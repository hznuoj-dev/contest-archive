#include<bits/stdc++.h>
using namespace std;
int m , k;
double a[10] , b[10];
bool st[10];
double res;

void dfs(int u , int pri , double pj)
{
	if(u == 6)
	{
		res = max(res , pj / (double)(pri - (pri / m) * k));
	}
	for(int i = u ; i <= 5 ; i ++)
	{
		if(!st[i])
		{
			st[i] = true;
			dfs(u + 1 , pri + a[i] , pj + b[i]);
			st[i] = false;
		}else
		{
			dfs(u + 1 , pri , pj);
		}
	}
	return;
}

int main()
{
	scanf("%d%d" , &m , &k);
	for(int i = 1 ; i <= 5 ; i ++)scanf("%lf" , &a[i]);
	for(int i = 1 ; i <= 5 ; i ++)scanf("%lf" , &b[i]);
	dfs(1 , 0 , 0);
	printf("%.2lf" , res);
	return 0;
}
