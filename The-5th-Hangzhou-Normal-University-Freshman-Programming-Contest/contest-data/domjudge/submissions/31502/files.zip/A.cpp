#include<iostream>
#include<vector>
using namespace std;
int main(){
	int n;
	cin>>n;
	vector<int> all(n);
	for(int i=0;i<n;i++){
		cin>>all[i];
	}
	int left=1,right=1e9;
	for(int i=0;i<=n/2;i++){
		int newleft,newright;
		newleft = all[i];
		newright = all[n-1-i];
		if(newleft>newright){
			swap(newleft,newright);
		}
		left = max(left,newleft);
		right = min(right,newright);
	}
	if(left==right){
		cout<<1;
		return 0;
	}
	else{
		cout<<right-left-1;
		return 0;
	}
	return 0;
}
