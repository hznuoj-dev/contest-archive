#include <bits/stdc++.h>
using namespace std;

int main()
{
	double a[6];
	double b[6];
	double m,k;
	cin >> m >> k;
	for(int i = 1; i <= 5; i++)
	{
		cin >> a[i];
	}
	for(int i = 1; i <= 5; i++)
	{
		cin >> b[i];
	}
	double max = 0;
	for(int i = 1; i <= 5; i++)
	{
		double w = m/a[i];
		double j = 1;
		double max2 = 1.0 * b[i]*(w+1) / (1.0*((w+1)*a[i] - k));
		while(1)
		{
			double max1 = 1.0 * b[i]*(w+1+j) / (1.0*((w+1+j)*a[i] - k));
			if(max1 >= max2)
			{
				max2 = max1;
				j++;
			}
			else
			{
				break;
			}
		}
		if(max2 >= max)
		{
			max = max2;
		}
	}
	printf("%.2f",max);
	
	return 0;
}
