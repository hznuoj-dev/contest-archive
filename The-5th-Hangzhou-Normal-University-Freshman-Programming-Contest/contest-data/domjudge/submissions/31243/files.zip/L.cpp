#include<bits/stdc++.h>
#define int long long
using namespace std;

int w[6], v[6]; // w�۸� v����ֵ ans = max{fi / (i>=m ? i-k:i);}
int f[1005];

signed main(){
	int m, k;
	cin >> m >> k;
	int n = 5;
	for(int i = 1; i <= n; i++){
		cin >> w[i];
	}
	for(int i = 1; i <= n; i++){
		cin >> v[i];
	}
	double ans = -1.0;
	for(int i = 0; i < (1 << n); i++){
		double sum = 0.0;
		int price = 0;
		for(int j = 0; j < 5; j++){
			if((i>>j)&1){
				sum += v[j + 1];
				price += w[j + 1];
			}
		}
		if(price >= m) price -= k;
		ans = max(ans, sum / price);
	}
	cout << fixed << setprecision(2) << ans << endl;
	return 0;
} 
/*
5 3
1 2 4 4 2
2 2 1 2 4
*/
