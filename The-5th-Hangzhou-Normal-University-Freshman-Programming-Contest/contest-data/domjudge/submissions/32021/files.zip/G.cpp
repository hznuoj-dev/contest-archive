#include <bits/stdc++.h>
using namespace std;
const int M=200005;
int n,m;
long long b,a[M],s[M],f[M][3];
long long lmin(long long x,long long y){
	if(x<y) return x;
	return y;
}
long long lmax(long long x,long long y){
	if(x>y) return x;
	return y;
}
int main(){
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++){
		scanf("%lld",&a[i]);
		s[i]=s[i-1]+a[i];
	}
	for(int i=1;i<=n;i++){
		f[i][0]=lmax(f[i-1][0],f[i-1][1]);
		if(i<=m){
			f[i][1]=lmin(b,s[i]);
		}
		else{
			f[i][1]=f[i-m][1]+lmin(b,s[i]-f[i-m][1]);
			f[i][1]=lmax(f[i][1],f[i-m][0]+lmin(b,s[i]-f[i-m][0]));
		}
	}
	printf("%lld\n",lmax(f[n][0],f[n][1]));
	return 0;
}
