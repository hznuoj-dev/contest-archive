#include<bits/stdc++.h>
using namespace std;
const int N=1e6;
int a[N],b[N],s[N];



int main()
{
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&b[i]);
	}sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	int k=a[1]-b[1];
	for(int i=1;i<=n;i++){
		if(a[i]-b[i]!=k)
		{cout<<-1;return 0;}
	}cout<<abs(k);
		
	
}
