#include<stdio.h>
#include<stdlib.h>
int cmp(const void*a,const void*b){
	return *(long long int*)a-*(long long int*)b;
}
int main(){
	long long int f1=0,f2=0,n,a[200005]={0},b[200005]={0},max1=0,max2=0;
	scanf("%lld",&n);
	for(int i=0;i<n;i++){
		scanf("%lld",&a[i]);
	}
	for(int i=0;i<n;i++){
		scanf("%lld",&b[i]);
	}
	qsort(a,n,sizeof(long long int),cmp);
	qsort(b,n,sizeof(long long int),cmp);
	max1=a[0]-b[0];
	f1=1;
	for(int i=1;i<n;i++){
		if(max1!=a[i]-b[i]){
			f1=0;
			break;
		}
	}
	f2=1;
	max2=a[0]+b[n-1];
	for(int i=1;i<n;i++){
		if(max1!=a[i]+b[n-1-i]){
			f2=0;
			break;
		}
	}
	if(max1<0){
		max1=-max1;
	}
	if(max2<0){
		max2=-max2;
	}
	if(f1==0&&f2==0){
		printf("-1\n");
	}
	else if(f1==1&&f2==1){
		if(max1<max2){
			printf("%lld\n",max1);
		}
		else{
			printf("%lld\n",max2);
		}
	}
	else if(f1==1){
		printf("%lld\n",max1);
	}
	else{
		printf("%lld\n",max2);
	}
	return 0;
}
