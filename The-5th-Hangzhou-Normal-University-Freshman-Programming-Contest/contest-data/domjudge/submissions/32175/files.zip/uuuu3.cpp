#include<iostream>
using namespace std;
#include<algorithm>
#include<string>
#include<vector>
#include<iomanip>
typedef long long ll;
int main()
{
	int m, k, flag = 0, t;
	std::cin >> m >> k;
	double a[5], b[5], c[5], x = 0, y = 0, d[5], max = 0;
	for (int i = 0; i < 5; i++)
	{
		std::cin >> a[i];
	}
	for (int i = 0; i < 5; i++)
	{
		std::cin >> b[i];
	}
	for (int i = 0; i < 5; i++)
	{
		for (int j = 0; j < 5; j++)
		{
			if (max < b[j] / a[j])
			{
				max = b[j] / a[j];
				t = j;
			}
		}
		x += b[t];
		y += a[t];
		if (y >= m)
		{
			y = y - k;
		}
		d[i] = x / y;
		b[t] = 0;
		max = 0;
	}
	std::sort(d, d + 5, greater<double>());
	/*for (int i = 0; i < 5; i++)
	{
		std::cout << d[i] << endl;
	}*/
	printf("%.2lf", d[0]);
}
