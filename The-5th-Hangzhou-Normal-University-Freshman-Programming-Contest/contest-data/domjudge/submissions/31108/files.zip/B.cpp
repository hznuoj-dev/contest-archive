#include <iostream>
#include <algorithm>

using namespace std;

const int N = 200010;
int a[N], b[N];

bool cmp(int x, int y)
{
    return x > y;
}

int main()
{
    int n;
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
        scanf("%d", &a[i]);
    for (int i = 0; i < n; i++)
        scanf("%d", &b[i]);
    sort(a, a + n);
    sort(b, b + n);
    int res = 2e9 + 1;
    int x = a[0] - b[0];
    int flag = 1;
    for (int i = 1; i < n; i++)
    {
        if (a[i] - b[i] != x)
            flag = 0;
    }
    if (flag == 1)
    {
        res = min(abs(a[0] - b[0]), res);
    }
    sort(a, a + n, cmp);
    flag = 1;
    x = a[0] + b[0];
    for (int i = 1; i < n; i++)
    {
        if (a[i] + b[i] != x)
            flag = 0;
    }
    if (flag == 1)
    {
        res = min(res, abs(a[0] + b[0]) + 1);
    }
    if (res < 2e9 + 1)
        printf("%d\n", res);
    else
        puts("-1");
    return 0;
}