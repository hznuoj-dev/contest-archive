#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

// typedef long long LL;

const int N = 200010;

int n;
int a[N], b[N];

int main()
{
    cin >> n;
    for (int i = 0; i < n; i ++ ) cin >> a[i];
    for (int i = 0; i < n; i ++ ) cin >> b[i];
    sort(a, a + n);
    sort(b, b + n);

    int cnt = b[0] - a[0];
    int res = 1e9 + 1;
    int flag1 = 1, flag2 = 1; // ��¼��������Ƿ����

    // a����ת
    for (int i = 1; i < n; i ++ )
    {
        if (b[i] - a[i] != cnt)
        {
            flag1 = 0;
            break;
        }
    }
    if (flag1 == 1) res = min(res, abs(cnt));

    // a��ת
    for (int i = 0; i < n; i ++ ) a[i] = -a[i];
    sort(a, a + n);
    cnt = b[0] - a[0];
    for (int i = 1; i < n; i ++ )
    {
        if (b[i] - a[i] != cnt)
        {
            flag2 = 0;
            break;
        }
    }
    if (flag2 == 1) res = min(res, abs(cnt) + 1);

    if (flag1 == 0 && flag2 == 0) cout << -1; // ���������������
    else cout << res;

    return 0;
}