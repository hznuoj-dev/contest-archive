#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[200005],b[200005];
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		cin>>b[i];
	}
	sort(a,a+n);
	sort(b,b+n);
	int f=0;
	for(int i=1;i<n;i++){
		if(a[i]-b[i]!=a[0]-b[0]){
			f++;
			break;
		}
	}
	int ans;
	if(f){
		cout<<"-1"<<endl;
	}else{
		if(abs(a[0]-b[0])<=abs(a[0]+b[0])){
			ans=abs(a[0]-b[0]);
		}else{
			ans=abs(a[0]+b[0]);
		}
		cout<<ans<<endl;
	}
	return 0;
}