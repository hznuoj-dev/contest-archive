#include<bits/stdc++.h>
using namespace std;
#define ll long long
double a[6][2];
double b[35][2]; 
map<int,int>mp;
int main(){
	int m,k;
	scanf("%d %d",&m,&k);
	int n=5;
	for(int i=1;i<=n;i++){
		scanf("%lf",&a[i][0]);
	}
	for(int i=1;i<=n;i++){
		scanf("%lf",&a[i][1]);
	}
	double max=0;
	for(int i=0;i<(1<<5);i++){
		for(int j=1;j<6;j++){
			if((1<<(j-1))&i){
				b[i][0]+=a[j][0];
				b[i][1]+=a[j][1];
			}
		}
		if(b[i][0]>=m){
			b[i][0]-=k;
		}
		if(max<b[i][1]/b[i][0]){
			max=b[i][1]/b[i][0];
		}
	}
	printf("%.2f\n",max);
	return 0;
}