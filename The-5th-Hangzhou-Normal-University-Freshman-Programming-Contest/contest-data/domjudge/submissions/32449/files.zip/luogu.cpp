#include <bits/stdc++.h> 

using i64 = long long;

struct node {
	double x, y;
};

bool cmp(node a, node b)
{
	return a.y / a.x > b.y / b.x;
}

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	i64 n, m, b, sum = 0, cnt = 0, tol = 0, p, t;
	std::vector<i64> a;
	
	std::cin >> n >> m >> b;
	a = std::vector<i64>(n);
	for (int i = 0; i < n; ++i)
		std::cin >> a[i];
	sum += a[0];
	for (int i = 1; i < n; ++i) {
		cnt++;
		tol += a[i];
		if (cnt == m) {
			cnt = 0;
			t = tol;
			if (tol >= b) {
				sum += b;
				tol -= b;
			}
			else {
				sum += tol;
				tol = 0;
			}
			p = i;
		}
	}
	if (p < n - 1 && t < b) {
		sum -= t;
		for (int i = p + 1; i < n; ++i)
		t += a[i];
		if (t >= b)
		sum += b;
		else
		sum += t;
	}
	std::cout << sum;
	
	return 0;
} 
