#include <iostream>
#include <algorithm>

using namespace std;

const int N = 1010;

int n, m,k;
int v[N], w[N];
int f[N];
double maxi=0;
int main()
{
	cin >> n >> k;
	
	for (int i = 1; i <= n; i ++ )
	{
	  cin >> v[i];
	  m+=v[i];
	}
	for (int i = 1; i <= n; i ++ ) cin >> w[i];
	
	for (int i = 1; i <= n; i ++ )
		for (int j = m; j >= v[i]; j -- )
			f[j] = max(f[j], f[j - v[i]] + w[i]);
	
	for(int i=1;i<=m;i++)
	{
		double ans;
		if(i>=n)
		{
			ans=f[i]*1.0/(i-k);
		}
		else
			ans=f[i]*1.0/i;
		maxi=max(maxi,ans);
	}
	printf("%.2lf",maxi);
	return 0;
}
