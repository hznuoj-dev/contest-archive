#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	int n, n1, m, m1, num = 0;
	long a[300000];
	cin>>n;
	for (int i = 0; i <n ;i++){
		cin>>a[i];
	}
	sort(a, a + n);
	if (n % 2 == 0){
		n1 = a[n / 2];
		m = a[n / 2 - 1];
		if (n1 == m){
			for (int i  = n / 2; a[i] != n1; i++)
				num++;
			for (int i = n/2 - 1; a[i] != n1; i--)
				num++;
			if (num % 2 == 0)
				cout<<1;
			else 
				cout<<0;
			return 0;
		}
		else if (n1 != m){
			cout<<n1 - m - 1;
		}
	}
	else if (n % 2 != 0){
		n1 = a[n / 2 - 1];
		m = a[n / 2 + 1];
		m1 = a[n / 2];
		if (n1 == m && n1 == m1 && m1 == m){
			for (int i  = n / 2; a[i] != n1; i--)
				num++;
			for (int i = n/2 + 1; a[i] != n1; i++)
				num++;
			if (num % 2 != 0)
				cout<<1;
			else 
				cout<<0;
			return 0;	
		}
		else
		cout<<m - n1 - 1;
	}
}
