#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=2e5+5;
int a[maxn];
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int n,m,b;cin>>n>>m>>b;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)a[i]+=a[i-1];
	int ans=0;
	int s=n%m;
	for(int i=s;i<=n;i+=m){
		ans+=min(b,a[i]-ans);
	}
	cout<<ans;
	return 0;
}
/*
5 2 10
5 9 3 1 8

6 2 10
20 1 1 1 1 5
*/
