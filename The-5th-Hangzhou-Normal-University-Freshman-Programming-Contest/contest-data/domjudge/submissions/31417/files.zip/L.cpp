#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int long long
const ll N=5e5+7;
const ll mod=1e9+7;
const ll inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
const double eps=1e-6;

int ans[5]={0};
double a[5],b[5];
void solve()
{
	int m,k;
    cin>>m>>k;
    for(int i=0;i<5;i++)
    {
    	cin>>a[i];
	}
	for(int i=0;i<5;i++)
	{
		cin>>b[i];
	}
	double f=-1;
    for(int i=4;i>=0;i--)
    {
    	ans[i]=1;
    	int ans1[5];
    	for(int p=0;p<5;p++)
    	{
    		ans1[p]=ans[p];
//    		cout<<ans1[p]<<" aaaaaaaaaaa ";
		}
    	
    	do{
//    	for(int p=0;p<5;p++)
//    	{
//    		cout<<ans1[p]<<" ";
//		}
//		cout<<"\n";
    		double pj=0.0,jg=0.0;
    		for(int j=0;j<5;j++)
    		{
    			if(ans1[j]==1)
    			{
    				jg+=a[j];
    				pj+=b[j];
				}
			}
			if(jg>=m) f=max(pj/(jg-1.0*k),f);
			else f=max(pj/jg,f);
		}while(next_permutation(ans1,ans1+5));
	}
	cout<<fixed<<setprecision(2)<<f;
}
signed main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int _=1;
//	cin>>_;
	while(_--)
	{
		solve();
	}
	return 0;
}


