#include <iostream>
#include <queue>
#include <vector>
using namespace std;
const int N = 2e5 + 10, mod = 1e9 + 7;
vector<int> edges[N];
int deg[N], cnt[N];

int qpower(int a, int b) {
    int ret = 1;
    while(b) {
        if(b & 1)   ret = ret * 1ll * a % mod;
        a = a * 1ll * a % mod;
        b >>= 1;
    }
    return ret;
}

int main()
{
    int n, m, k;
    scanf("%d %d %d", &n, &m, &k);
    int u, v;
    for(int i = 0; i < m; i++) {
        scanf("%d %d", &u, &v);
        edges[u].push_back(v);
        deg[v]++;
    }

    queue<int> q;
    int c = 0;
    for(int i = 1; i <= n; i++) if(deg[i] == 0)     q.push(i);
    while(!q.empty()) {
        int len = q.size();
        cnt[c++] = len;
        while(len--) {
            int u = q.front();
            q.pop();
            for(int nxt: edges[u])  {
                deg[nxt]--;
                if(deg[nxt] == 0)   q.push(nxt);
            }
        }
    }

    int sum = n;
    long long t = 0;
    for(int i = 0 ; i < c; i++) {
        sum -= cnt[i];
        t += sum * 1ll * cnt[i];
    }
    // printf("%lld\n", t);
    printf("%d", qpower(t % mod, k));

    return 0;
}