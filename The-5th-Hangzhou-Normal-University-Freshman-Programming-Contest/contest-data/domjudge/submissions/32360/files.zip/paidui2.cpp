#include<bits/stdc++.h>
using namespace std;
int main()
{
	int t,n,m,b,a[10000],sum,i,maxt,left,sum2;
	cin>>n>>m>>b;
	sum=0;
	sum2=0;
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
		sum+=a[i];
	}
	maxt=(n+m)/(m+1);
		for(t=1;t<=n;t+=m)
	   {
	   	if(sum<=0)
	   	{
	   		break;
		}
	   	left=0;
	  	if(t==1)
	  	{
	  		if(a[t]<=b)
		   {
		 	sum2+=a[t];
		 	sum-=a[t];
		 	a[t]=0;
		   }
		    else
		   {
		 	sum2+=b;
		 	a[t]-=b;
		 	sum-=b;
		   }
		}
		else if(t+m>n)
		{
			for(i=1;i<=n;i++)
			{
				left+=a[i];
			}
			if(left<=b)
			{
				
				a[t]=0;
				sum2+=left;
				sum-=left;
			}
			else if(left>b)
			{
				a[t]=left-b;
				sum2+=b;
				sum-=b;
			}
		}
		else
		{
			for(i=1;i<=t;i++)
			{
				left+=a[i];
			}
			if(left<=b)
			{
				for(i=1;i<=t;i++)
				{
					a[i]=0;
				}
				a[t]=0;
				sum2+=left;
				sum-=left;
			}
			else if(left>b)
			{
				for(i=1;i<t;i++)
				{
					a[i]=0;
				}
				a[t]=left-b;
				sum2+=b;
				sum-=b;
			}
		} 
		 
	  }
	cout<<sum2<<endl;
	
	return 0;
}
