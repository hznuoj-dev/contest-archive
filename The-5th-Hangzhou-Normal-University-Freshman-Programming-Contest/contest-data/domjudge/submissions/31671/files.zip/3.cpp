#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll maxn = 1e5 + 10;
const ll minn = 1e9 + 7;
const double eps = 1e-6;
const int INFTY = (1<<21);

int gcd(int a, int b) {return b ? gcd(b, a % b) : a;}
int lcm(int a, int b) {return a * b / gcd(a, b);}

int m,k,a[maxn],b[maxn];

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cin>>m>>k;
    for(int i=1;i<=5;i++)
    {
        std::cin>>a[i];
    }
    for(int i=1;i<=5;i++)
    {
        std::cin>>b[i];
    }
    double min_num=0;
    for(int num1=0;num1<=1;num1++)
    {
        for(int num2=0;num2<=1;num2++)
        {
            for(int num3=0;num3<=1;num3++)
            {
                for(int num4=0;num4<=1;num4++)
                {
                    for(int num5=0;num5<=1;num5++)
                    {
                        double chushu = (b[1]*num1+b[2]*num2+b[3]*num3+b[4]*num4+b[5]*num5);
                        double beichu = (a[1]*num1+a[2]*num2+a[3]*num3+a[4]*num4+a[5]*num5);
                        if(beichu>=m)
                        {
                            beichu=beichu-k;
                        }
                        if(beichu)
                        {
                            min_num=max(min_num,chushu/beichu);
                        }
                    }
                }
            }
        }
    }
    printf("%.2lf\n",min_num);
    return 0;
}