﻿#include<bits/stdc++.h>
using namespace std;
const int N=2e5+9;
int a[N],f[N],g[N],n,m,siz[N];
int ver[N<<1],nxt[N<<1],w[N<<1],tot,h[N];

inline int mul(int x,int y){return (y&1?x:0);}

inline void add(int x,int y,int z)
{
    ver[++tot]=y,nxt[tot]=h[x],h[x]=tot,w[tot]=z;
}

void dfs(int u,int fa)
{
    siz[u]=1;
    for(int i=h[u];i;i=nxt[i])
    {
        int v=ver[i];
        if(v==fa) continue;
        dfs(v,u);
        f[1]^=mul(w[i],siz[v]);
        siz[u]+=siz[v];
    }
}

void dp(int u,int fa)
{
    for(int i=h[u];i;i=nxt[i])
    {
        int v=ver[i];
        if(v==fa) continue;
        g[v]=g[u]^(mul(w[i],n-siz[v]))^(mul(w[i],siz[v]));
        dp(v,u);
    }
}

int main()
{
    scanf("%d",&n);
    for(int i=1;i<n;i++)
    {
        int x,y,z;
        scanf("%d%d%d",&x,&y,&z);
        add(x,y,z),add(y,x,z);
    }
    dfs(1,0);
    // printf("%d\n",f[1]);
    g[1]=f[1];
    dp(1,0);
    scanf("%d",&m);
    while(m--)
    {
        int u,x;
        scanf("%d%d",&u,&x);
        printf("%d\n",g[u]^(n&1?x:0));
    }
    return 0;
}