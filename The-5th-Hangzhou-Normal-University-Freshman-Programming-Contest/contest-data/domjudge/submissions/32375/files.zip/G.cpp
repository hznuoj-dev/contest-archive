#include <iostream>

using namespace std;

typedef long long LL;

const int N = 200010;

int n, m;
LL b;
LL a[N], sum[N];

int main()
{
    cin >> n >> m >> b;
    for (int i = 0; i < n; i ++ ) cin >> a[i];
    sum[0] = a[0];
    for (int i = 1; i < n; i ++ ) sum[i] = a[i] + sum[i - 1];

    int cnt = 1; // ���д���
    LL num = 0; // ��������
    int k = m + 1, flag = 0;
    for (int i = 0; i < n; i ++ )
    {
        if ((n - 1) % m == 0 && flag == 0)
        {
            num += a[0];
            cnt ++ ;
            flag = 1;
        }
        else if (k > m && sum[i] >= b + num)
        {
            num += b;
            cnt ++ ;
            k = 1;
        }
        else if (k > m && (i == n - 1) || (i == n - 1 - m))
        {
            if (sum[i] - num <= b) num += sum[i] - num;
            else num += b;
            cnt ++ ;
            k = 1;
        }
        k ++ ;
    }
    cout << num;
}