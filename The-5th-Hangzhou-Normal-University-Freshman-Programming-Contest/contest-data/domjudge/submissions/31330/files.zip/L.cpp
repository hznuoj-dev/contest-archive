#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define ll long long

using namespace std;

const int N = 5;
int m,k,a[N],b[N];
double ans = 0.0,temp;

void solve() {
	int t,temp;
	for(int i=0; i<5; i++) {
		if(a[i]>=m)t = a[i]-k;
		else t = a[i];
		ans = max(ans,b[i]*1.0/t);
	}
	for(int i=0; i<4; i++) {
		for(int j=i+1; j<5; j++) {
			t = a[i]+a[j];
			temp = b[i]+b[j];
			if(t>=m)t-=k;
			ans = max(ans,temp*1.0/t);
		}
	}
	for(int i=0; i<3; i++) {
		for(int j=i+1; j<4; j++) {
			for(int q=j+1; q<5; q++) {
				t = a[i]+a[j]+a[q];
				temp = b[i]+b[j]+b[q];
				if(t>=m)t-=k;
				ans = max(ans,temp*1.0/t);
			}
		}
	}
	for(int i=0; i<2; i++) {
		for(int j=i+1; j<3; j++) {
			for(int q=j+1; q<4; q++) {
				for(int p=k+1; p<5; p++) {
					t = a[i]+a[j]+a[q]+a[p];
					temp = b[i]+b[j]+b[q]+b[p];
					if(t>=m)t-=k;
					ans = max(ans,temp*1.0/t);
				}
			}
		}
	}
	t = a[0]+a[1]+a[2]+a[3]+a[4];
	temp = b[0]+b[1]+b[2]+b[3]+b[4];
	if(t>=m)t-=k;
	ans = max(ans,temp*1.0/t);
	printf("%.2lf\n",ans);

}
int main() {
//	IOS
	cin >> m >> k;
	for(int i=0; i<5; i++)cin >> a[i];
	for(int i=0; i<5; i++)cin >> b[i];

	solve();



	return 0;
}
