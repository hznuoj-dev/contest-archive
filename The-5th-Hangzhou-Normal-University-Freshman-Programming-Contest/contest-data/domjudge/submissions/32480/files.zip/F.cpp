#include<cstdio>
template<class type>inline const void read(type &in)
{
    in=0;char ch(getchar());
    while (ch<48||ch>57)ch=getchar();
    while (ch>47&&ch<58)in=(in<<3)+(in<<1)+(ch&15),ch=getchar();
}
const int N(2e5+5);
struct edge
{
    int to,w,next;
    inline edge(const int &to=0,const int &w=0,const int &next=0):to(to),w(w),next(next){}
}e[N<<1];
int head[N],n,m,edc,a[N],sum[N],dep[N],dis[N],Sum,Ans;
inline const void addEdge(const int &u,const int &v,const int &w)
{
    e[++edc]=edge(v,w,head[u]);head[u]=edc;
}
inline const void dfs(int p,int fa)
{
    for (int i(head[p]);i;i=e[i].next)
    {
        const int son(e[i].to);
        if (son==fa)continue;
        a[son]=e[i].w;
        dep[son]=dep[p]+1;
        dis[son]=dis[p]^e[i].w;
        dfs(son,p);
        sum[p]^=sum[son];
    }
    //sum[p]^=a[p];
    Sum^=dis[p];
}
inline const int makeRoot(int x)
{
    return Sum^(n&1?dis[x]:0);
}
void force(int x,int fa)
{
    for (int i=head[x];i;i=e[i].next)
    {
        int son=e[i].to;
        if (son==fa)continue;
        a[son]=a[x]^e[i].w;
        force(son,x);
    }
    Ans^=a[x];
}
int main()
{
    read(n);
    for (int i(1),u,v,w;i<n;i++)read(u),read(v),read(w),addEdge(u,v,w),addEdge(v,u,w);
    dfs(dep[1]=1,0);
    //printf("%d\n",Sum);
    read(m);
    for (int u,v;m--;)
        read(u),read(v),
      //  a[u]=v,force(u,Ans=0),printf("::%d\n",Ans),
        printf("%d\n",(n&1?v:0)^makeRoot(u));
    return 0;
}
/*
7
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
6 7 9
6
1 2
3 5
2 8
4 10
5 1
7 3
*/