﻿#include<bits/stdc++.h>
using namespace std;
const int N=2e5+9;
int a[N],n,maxn,b[N];

inline bool check(int x)
{
    int tmp1=0,tmp2=0;
    for(int i=1;i<=n;i++)
    {
        if(b[i]<x) tmp1++;
        else if(b[i]>x) tmp2++;
        if(tmp2>tmp1) return false;
    }
    return tmp1==tmp2;
}

int main()
{
    cin>>n;
    for(int i=1;i<=n;i++) cin>>a[i],maxn=max(maxn,a[i]),b[i]=a[i];
    if(n&1)
    {
        sort(a+1,a+1+n);
        puts(check(a[n/2+1])?"1":"0");
        return 0;
    }
    sort(a+1,a+1+n);
    int l=a[n/2],r=a[n/2+1],ans=0;
    if(r-l>1)
    {
        if(check(l+1)) ans+=r-l-1;
    }
    ans+=check(l);
    if(r!=l) ans+=check(r);
    printf("%d",ans);
    return 0;
}