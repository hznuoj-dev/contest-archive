#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,a[200005],b[200005],ans,ans1;
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=1;i<=n;i++)cin>>b[i];
    sort(a+1,a+n+1);
    sort(b+1,b+n+1);
    int t=1;
    for(int i=2;i<=n;i++)
    {
        if(b[i]-a[i]!=b[i-1]-a[i-1])t=0;break;
    }
    if(t)ans=abs(b[1]-a[1]);
    for(int i=1;i<=n;i++)
    {
        a[i]*=-1;
    }
    sort(a+1,a+n+1);
    int p=1;
    for(int i=2;i<=n;i++)
    {
        if(b[i]-a[i]!=b[i-1]-a[i-1])p=0;break;
    }
    if(p)ans1=abs(b[1]-a[1]);
    if(t&&p)cout<<min(ans,ans1);
    else if(t&&!p)cout<<ans;
    else if(!t&&p)cout<<ans1;
    else cout<<-1;
    return 0;
}
