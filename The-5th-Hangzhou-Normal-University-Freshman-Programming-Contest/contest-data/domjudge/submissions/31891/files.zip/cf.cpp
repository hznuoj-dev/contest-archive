#include <bits/stdc++.h>
using namespace std;
const int N=205;
int p[N],w[N],dp[40005];
//#define int long long
int main() {
	std::ios::sync_with_stdio(false);
    std::cin.tie(0);std::cout.tie(0);
	int m,k;
	double ans=0;
	cin>>m>>k;
	for(int i=0;i<5;i++) cin>>p[i];
	for(int i=0;i<5;i++) cin>>w[i];
	for(int i=1;i<(1<<5);i++){
		int a=i,sum=0,v=0;
		for(int j=0;j<5;j++){
			if(a>>j&1) v+=p[5-j-1],sum+=w[5-j-1];
		}
		ans=max(ans,1.0*v/sum);
	}
	printf("%.2f",ans);
  return 0;
}