#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define fi first
#define se second
#define pii pair<int,int>
#define pb push_back
const int N = 2E5 + 10;

void solve() {
	int n; cin >> n;
	
	vector<int> a(n + 1), b(n + 1);
	for (int i = 1; i <= n; i++) cin >> a[i];
	for (int i = 1; i <= n; i++) cin >> b[i];
	
	int f1 = 0;
	for (int i = 1; i <= n; i++) {
		if (a[i] < 0) {
			a[i] *= -1;
			f1 = 1;
		}
	}
	int f2 = 0;
	for (int i = 1; i <= n; i++) {
		if (b[i] < 0) {
			f2 = 1;
			b[i] *= -1;
		}
	}

	sort(a.begin() + 1, a.end());
	sort(b.begin() + 1, b.end());
	
	int ans = 0;
	for (int i = 1; i <= n; i++) {
		ans = max(abs(a[i] - b[i]), ans);
	}
	
	cout << ans << endl;
	
	
}


int main() {
	ios::sync_with_stdio(0); cout.tie(0); cin.tie(0);

	int T = 1;

	while(T--) solve();

	return 0;
}

