
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
const int N=8e5+10;
#define LL long long
const LL md=1000000007;
LL fpw(LL x,LL y){
    LL res=1;
    while(y){
        if(y&1)res=res*x%md;
        x=x*x%md;y>>=1;
    }return res;
}
vector<int>G[N];
int n,m,f[N];
LL k;
void dfs(int u){
    if(f[u])return;
    for(auto v:G[u]){
        dfs(v);f[u]=max(f[u],f[v]+1);
    }
}
int main(){
    scanf("%d%d%lld",&n,&m,&k);
    int i,j;
    rep(i,1,m){
        int x,y;scanf("%d%d",&x,&y);
        G[y].push_back(x);
    }
    rep(i,1,n)dfs(i);
    sort(f+1,f+1+n);
    LL cnt=0;
    rep(i,1,n){
        j=i;while(j+1<=n && f[j+1]==f[i])++j;
        cnt+=(LL)(i-1)*(LL)(j-i+1);
        i=j;
    }
    printf("%lld",fpw(cnt,k));
}