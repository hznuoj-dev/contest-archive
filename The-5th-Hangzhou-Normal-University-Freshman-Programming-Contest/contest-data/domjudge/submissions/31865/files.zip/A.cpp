#include <iostream>
#include <map>
#include <vector>

using namespace std;

const int N = 200010;
int n;
int a[N];
map<int, int> mp;
vector<int> pp;

bool check_1(int x)
{
    int cnt = 0;
    for (int i = 0; i < n; i++)
    {
        if (a[i] < x)
            cnt++;
        if (a[i] > x)
            cnt--;
        if (cnt < 0)
            return false;
    }
    return true;
}

int main()
{
    scanf("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf("%d", &a[i]);
        mp[a[i]]++;
    }
    for (int i = 1; i <= 2e5; i++)
    {
        if ((n - mp[i]) % 2 == 0 && mp[i - 1] == (n - mp[i]) / 2)
            pp.push_back(i);
        mp[i] = mp[i - 1] + mp[i];
    }
    if (pp.size() == 0)
    {
        printf("%d", 0);
        return 0;
    }
    int l = 0, r = pp.size();
    while (l < r)
    {
        int mid = (l + r) / 2;
        if (check_1(pp[mid]))
            r = mid;
        else
            l = mid + 1;
    }
    int l2 = 0, r2 = pp.size();
    while (l2 < r2)
    {
        int mid = (l2 + r2 + 1) / 2;
        if (check_1(pp[mid]))
            l2 = mid;
        else
            r2 = mid - 1;
    }
    printf("%d", l2 - l + 1);
    return 0;
}
