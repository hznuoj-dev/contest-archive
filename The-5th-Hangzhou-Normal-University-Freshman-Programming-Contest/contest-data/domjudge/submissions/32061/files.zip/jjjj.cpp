#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn = 1e5 + 10;
int m,k,a[maxn],b[maxn];

int main()
{
	cin>>m>>k;
	for(int i=1;i<=5;i++){
		cin>>a[i];
	}
	for(int i=1;i<=5;i++){
		cin>>b[i];
	}
	double s=0;
	for(int i=0;i<=1;i++){
		for(int ii=0;ii<=1;ii++){
			for(int iii=0;iii<=1;iii++){
				for(int iiii=0;iiii<=1;iiii++){
					for(int iiiii=0;iiiii<=1;iiiii++){
						double x = (b[1]*i+b[2]*ii+b[3]*iii+b[4]*iiii+b[5]*iiiii);
						double y = (a[1]*i+a[2]*ii+a[3]*iii+a[4]*iiii+a[5]*iiiii);
						if(y>=m){
							y=y-k;
						}
						if(y){
							s=max(s,x/y);
						}
					}
				}
			}
		}
	}
	printf("%.2lf\n",s);
	return 0;
}

