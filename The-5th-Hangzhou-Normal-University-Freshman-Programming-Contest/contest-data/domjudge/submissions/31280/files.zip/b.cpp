/*
 * @Author: JSY
 * @Date: 2023-05-27 12:20:29
 * @Last Modified by: JSY
 * @Last Modified time: 2023-05-27 12:20:29
*/

#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int, int>
#define IOS ios::sync_with_stdio(0);cin.tie(0), cout.tie(0)
const int N = 200010;
int a[N] , b[N];

signed main(){
    IOS;
    int n;
    cin >> n;
    for(int i=1;i<=n;i++){
        cin >> a[i];
    }
    for(int i=1;i<=n;i++){
        cin >> b[i];
    }
    sort(a+1,a+n+1);
    sort(b+1,b+n+1);
    int ans1 = -1;
    int res = a[1] - b[1];
    for(int i=2;i<=n;i++){
        if(a[i] - b[i] == res) ans1 = abs(res);
        else{
            ans1 = -1;
            break;
        }
    }
    for(int i=1;i<=n;i++) a[i] = -a[i];
    sort(a+1,a+n+1);
    int ans2 = -1;
    res = a[1] - b[1];
    for(int i=2;i<=n;i++){
        if(a[i] - b[i] == res) ans2 = abs(res) + 1;
        else{
            ans2 = -1;
            break;
        }
    }
    if(ans1 == -1 && ans2 == -1) cout << -1;
    else if(ans1 != -1 && ans2 != -1) cout << min(ans1 , ans2);
    else if(ans1 != -1) cout << ans1;
    else if(ans2 != -1) cout << ans2;
    return 0;
}