#include<bits/stdc++.h>

using namespace std;

#define int long long
#define ll long long
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pii pair<int,int>
#define pb push_back
//#define endl "\n"
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 3e5+7;
const int mod = 998244353;

int a[N],b[N],c[N],a1[N],a2[N];
int n;

void solve(){
	cin >> n;
	int mx1 = 0,mx2 = 0;
	for(int i=1;i<=n;i++) cin >> a[i],mx1 = max(abs(a[i]),mx1);
	for(int i=1;i<=n;i++) cin >> b[i],mx2 = max(abs(b[i]),mx2);
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	for(int i=1;i<=n;i++) c[i] = a[i] - b[i];
	sort(c+1,c+1+n);
	if(c[1] == c[n]){
		cout << abs(c[1]) << endl;
		return ;
	}
	//map<int,int>mp11,mp12,mp2;
	int cnt = mx1-mx2;
	for(int i=1;i<=n;i++){
		a1[i] = -1*a[i]+cnt;
		a2[i] = -1*a[i]-cnt;
	}
	sort(a1+1,a1+1+n);
	sort(a2+1,a2+1+n);
	int f = 1;
	for(int i=1;i<=n;i++){
		if(b[i] != a1[i]){
			f = 0;
			break;
		}
	}
	if(f){
		cout << abs(cnt) +1 << endl;
		return ;
	}
	f = 1;
	for(int i=1;i<=n;i++){
		if(b[i] != a2[i]){
			f = 0;
			break;
		}
	}
	if(f){
		cout << abs(cnt) +1 << endl;
		return ;
	}
	cout << -1 << endl;
}
/*
*/

signed main(){
	ios::sync_with_stdio(0);
    cin.tie(nullptr);cout.tie(nullptr);
	int T = 1;
    //cin >> T;
    while(T--) solve();

    return 0 ;
}

