#include<bits/stdc++.h>
#define to first
#define val second
#define int long long
using namespace std;
const int maxn = 2e5 + 9;
bool vis[maxn];
vector< pair<int,int> > g[maxn];
int cal[maxn],d[maxn];
int ans;
void dfs(int x) {
//	cout << "??? " << x << " " << g[x].size() << '\n';
	for(int i = 0; i < g[x].size(); i ++) {
		int y = g[x][i].to,z = g[x][i].val;
		if(vis[y]) continue;
//		cout << "work\n";
		vis[y] = 1;
		cal[y] = cal[x]^z;
		ans ^= cal[y];
		dfs(y);
	}
}
int n,p;
signed main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int u,v,w;
	cin >> n;
	for(int i = 1; i < n; i ++) {
		cin >> u >> v >> w;
		g[u].push_back(make_pair(v,w));
		g[v].push_back(make_pair(u,w));
		d[u]++;
		d[v]++;
	}
	for(int i = 1; i <= n; i ++) {
		if(d[i] == 1) {
//			cout << "??\n";
			p = i;
			vis[i] = 1;
			dfs(i);
			break;
		}
	}
//	cout << ans << '\n';
//	for(int i = 1;i <= n;i ++){
//		cout << cal[i] << ' ';
//	}
	int q,res;
//	cout << "? " << p << '\n';
	cin >> q;
	while(q --) {
		cin >> u >> w;
		if(u != p) {
			res = ans^((n % 2)*(w^cal[u]));
		} else {
			res = ans^((n % 2)*w);
		}
		cout << res << '\n';
	}
	return 0;
}

