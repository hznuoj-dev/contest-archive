// #include<bits/stdc++.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <string.h>
#include <string>
#include <math.h>

#define int long long

using namespace std;
const int N = 1e6 + 10;

int player[N] = {0};

void solve()
{
    int n, m, b, time, other;
    cin >> n >> m >> b;
    time = n / m;
    other = n % m + m - 1;
    int rest = 0;
    if (other >= m)
    {
        other -= m;
        time++;
    }
//    cout << time << ' ' << other << endl;
//    return;
    int num = 0, res = 0;
    for (int i = 1; i <= n; i++)
    {
        cin >> player[i];
    }
    for (int i = 1; i <= n; i++)
    {
        num += player[i];
        if (rest == 0)
        {
            if (num >= b)
            {
                res += b;
                num -= b;
                rest = m;
            }
            else if (other == 0)
            {
                res += num;
                num = 0;
                rest = m;
            }
            else if (other > 0 && num < b)
            {
                other--;
            }
        }
        if (rest != 0)
        {
            rest--;
        }
    }

    cout << res << endl;
}
signed main()
{
    int t;
    t = 1;
    //    cin>>t;
    while (t--)
    {
        solve();
    }
    return 0;
}
