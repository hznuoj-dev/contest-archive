#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define fi first
#define se second
#define pii pair<int,int>
#define pb push_back
const int N = 2E5 + 10;

void solve() {
	int n; cin >> n;
	
	vector<int> a(n + 1);
	for (int i = 1; i <= n; i++) cin >> a[i];
	
	if (a[1] > a[n]) {
		cout << "0\n";
	} else {
		sort(a.begin() + 1, a.end());
		
		if (n % 2) {
			int k = a[(n + 1) / 2];
			int cnt = 0;
			for (int i = 1; i <= n; i++) {
				if (a[i] == k) cnt++;
			}
			if (cnt % 2) {
				cout << 0 << endl;
			}else cout << 1 << endl;
		}else {
			int l = a[n / 2];
			int r = a[n / 2 + 1];
			
			if (l == r) {
				int cnt = 0;
				for (int i = 1; i <= n; i++) {
					if (a[i] == l) cnt++;
				}
				if (cnt % 2) {
					cout << 0 << endl;
				}else cout << 1 << endl;
			}else {
				cout << r - l - 1 << endl;
			}
		}
	}
}

/*
4
4 10 5 10
4 
1 4 4 10

4
1 4 5 10

*/
int main() {
	ios::sync_with_stdio(0); cout.tie(0); cin.tie(0);

	int T = 1;

	while(T--) solve();

	return 0;
}

