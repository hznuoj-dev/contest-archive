#include <bits/stdc++.h>

using namespace std;

void a(){
    int n;
    cin >> n;
    vector<int> vc(n);
    vector<int> arr(n);
    for (int i = 0; i < n; ++i) {
        cin >> vc[i];
        arr[i] = vc[i];
    }
    if(n % 2){

    }
    else{
        std::sort(vc.begin(), vc.end());
        int m2 = vc[n/2], m1 = vc[n/2 - 1];
        if(m1 < arr[0]) m1 = arr[0]; if(arr[n-1] < m2) m2 = arr[n-1];
        for (int i = m1; i < m2; ++i) {

        }

    }
}

void l(){
    double m, k;
    cin >> m >> k;  // 满m减k

    vector<double> value_yb(5);
    for (int i = 0; i < 5; ++i) {
        cin >> value_yb[i];
    }

    vector<double> value_real(5);
    for (int i = 0; i < 5; ++i) {
        cin >> value_real[i];
    }

    vector<double> real_yb(5);
    for (int i = 0; i < 5; ++i) {
        double v_yb = value_yb[i] >= m? value_yb[i] - k : value_yb[i];
        real_yb[i] = value_real[i] / v_yb;
    }

    std::sort(real_yb.begin(), real_yb.end());

    double most_one = real_yb[4];

    double most_mk = 0;

    value_real.push_back(0);
    value_yb.push_back(0);

    int a[5];
    for (a[0] = 0; a[0] <= 5; ++a[0]) {
        for (a[1] = 1; a[1] <= 5; ++a[1]) {
            for (a[2] = 2; a[2] <= 5; ++a[2]) {
                for (a[3] = 3; a[3] <= 5; ++a[3]) {
                    for (a[4] = 4; a[4] <= 5; ++a[4]) {

                        bool f = false;
                        for (int i = 0; i < 4; ++i) {
                            for (int j = i+1; j < 5; ++j) {
                                if(a[i] == a[j] && a[i] != 5)
                                    f = true;
                            }
                        }

                        if(f) continue;



                        double all_real = value_real[a[0]] + value_real[a[1]] + value_real[a[2]] + value_real[a[3]] + value_real[a[4]];
                        double all_yb = value_yb [a[0]] + value_yb [a[1]] + value_yb [a[2]] + value_yb [a[3]] + value_yb [a[4]];
                        if(all_yb >= m) all_yb -= k;

                        if(most_mk < all_real / all_yb) {
                            most_mk = all_real / all_yb;
//                            cout << most_mk << "\n";
//                            printf("%d        %d        %d        %d        %d\n", a[0], a[1], a[2], a[3], a[4]);
//                            printf("%lf %lf %lf %lf %lf\n", value_real[a[0]], value_real[a[1]], value_real[a[2]], value_real[a[3]], value_real[a[4]]);
//                            printf("%lf %lf %lf %lf %lf\n\n", value_yb[a[0]], value_yb[a[1]], value_yb[a[2]], value_yb[a[3]], value_yb[a[4]]);
                        }
                    }
                }
            }
        }
    }

    printf("%.2lf", most_mk > most_one ? most_mk : most_one);

}

int main() {
    l();
}
