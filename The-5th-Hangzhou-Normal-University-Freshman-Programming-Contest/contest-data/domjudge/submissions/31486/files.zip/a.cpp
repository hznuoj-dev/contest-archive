#include<iostream>
using namespace std;
long long a[200020];

int main()
{
	long long n;
	cin >> n;
	for(int i=1;i<=n;i++)
	{
		cin >> a[i];
	}
	long long zx=0,min=0,max=1e9;
	bool flag=0;
	for(int i=1;i<=n;i++)
	{
		if(a[i]<a[i+1]&&a[i+1]<a[i+2])
		{
			if(zx==0)
			{
				zx=a[i+1];
			}
			else
			{
				if(zx!=a[i+1])
				{
					cout << 0 << endl;
				    flag=1;
				    break;
				}
			}
			i+=2;
		}
		else if(a[i]<a[i+1]&&a[i+1]==a[i+2])
		{
			if(zx==0)
			{
				zx=a[i+1];
			}
			else
			{
				if(zx!=a[i+1])
				{
					cout << 0 << endl;
				    flag=1;
				    break;
				}
			}
			while(a[i]<=a[i+1])
			{
				i++;
			}
		}
		else if(a[i]<a[i+1]&&a[i+1]>a[i+2])
		{
			if(a[i]>min)
			{
				min=a[i];
			}
			if(a[i+1]<max)
			{
				max=a[i+1];
			}
			i++;
		}
		else if(a[i]>a[i+1])
		{
			cout << 0 << endl;
			flag=1;
			break;
		}
	}
	if(flag==0)
	{
		if(zx==0)
		{
			cout << max-min-1 << endl;
		}
		else
		{
			if(zx<=min||zx>=max)
			{
				cout << 0 << endl;
			}
			else
			{
				cout << 1 << endl;
			}
		}
	}
	return 0;
}
