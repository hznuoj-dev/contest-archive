#include <iostream>
#include <algorithm>
#include <cstring>
#include <map>
#include <vector>
#include <stack>

using namespace std;

int n;
int a[200005];
int b[200005];

bool func(int x)
{
    stack<int> st;
    for (int i = 1; i <= n; ++i)
    {
        if (b[i] < x)
        {
            st.push(0);
        }
        else if (b[i] > x)
        {
            if (st.empty())
            {
                return false;
            }
            st.pop();
        }
    }
    if (st.empty())
    {
        return true;
    }
    return false;
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i];
        b[i] = a[i];
    }
    sort(a + 1, a + n + 1);
    int l, r;
    if (n % 2)
    {
        l = r = a[n / 2 + 1];
    }
    else
    {
        l = a[n / 2];
        r = a[n / 2 + 1];
    }
    int res = 0;
    if (l == r)
    {
        if (func(l))
        {
            res = 1;
        }
    }
    else
    {
        if (func(l + 1))
        {
            res = r - l - 1;
        }
    }
    cout << res;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}