#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e5+10;
struct Node{
	ll x;
}a[N], b[N];
bool cmp(Node m, Node n)
{
	return  abs(m.x) < abs(n.x);
}
int main()
{
   int n;
   cin >> n;
   ll ansa1 = 0, ansa2 = 0;
   ll ansb1 = 0, ansb2 = 0;
   for(int i = 1; i <= n; ++i){
   	  cin >> a[i].x;
   	  if(a[i].x > 0)
   	     ansa1++;
   	  else
   	     ansa2++;
   }	
   for(int i = 1; i <= n; ++i){
   	  cin >> b[i].x;
   }
   //-4 -3 1 2->-2 -1 3 4
   //-2 -1 3 4
   //-1 -2 -3 -4
   //1 0 -1 -2
   sort(a+1, a+n+1, cmp);
   sort(b+1, b+n+1, cmp);
	  int flag1 = 1;
	  int num = 0;
	  int sum2 = 0;
	  for(int i = 1; i <= n; ++i){
	  	if(a[i].x != b[i].x && num == 0){
	  	   sum2 = b[i].x - a[i].x;
		   num++;	
		}
		else if(a[i].x != b[i].x && num && b[i].x - a[i].x != sum2){
			flag1 = 0;
			break;
		}
	  }
	  int sum1 = 0;
	  num = 0;
	  int flag = 1;
	  for(int i = 1; i <= n; ++i){
	  	 if(num == 0){
	  	   	sum1 = -a[i].x - b[i].x;
	  	   	num++;
		 }
		 else{
		 	if(-a[i].x - b[i].x != sum1){
		 		 flag = 0;
		 		 break;
			 }
		 }
	  }
	  if(!flag1 && !flag){
	  	 cout << -1 << endl;
	  }else{
	     int ans = min(abs(sum2), abs(sum1) + 1);
	     cout << ans << endl;
	  }
}
