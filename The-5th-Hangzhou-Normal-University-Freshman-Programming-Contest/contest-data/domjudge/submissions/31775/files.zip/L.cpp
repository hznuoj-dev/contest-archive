#include<bits/stdc++.h>
#include <set>
using namespace std;
int main()
{
	int m, k;
	cin >> m >> k;
	int a[5], b[5];
	for(int i=0; i<5; i++)
	{
		cin >> a[i];
	}
	for(int i=0; i<5; i++)
	{
		cin >> b[i];
	}
	
	int c[5][2] = {0, 1, 0, 1, 0, 1, 0, 1, 0, 1};
	multiset<double> x;
	double money, ping, etilletas;
	for(int i=0; i<2; i++)
		for(int j=0; j<2; j++)
			for(int p=0; p<2; p++)
				for(int q=0; q<2; q++)
					for(int r=0; r<2; r++)
					{
						ping = b[0]*c[0][i] + b[1]*c[1][j] + b[2]*c[2][p] + b[3]*c[3][q] + b[4]*c[4][r];
						if(ping == 0)
						{
							continue;
						}
						money = a[0]*c[0][i] + a[1]*c[1][j] + a[2]*c[2][p] + a[3]*c[3][q] + a[4]*c[4][r];
						if(money>=m)
						{
							money -= k;
						}
						etilletas = ping/money;
						x.insert(etilletas);
					}
	multiset<double>::iterator it = x.end();
	it--;
	printf("%.2f\n", *it);
	return 0;
}
