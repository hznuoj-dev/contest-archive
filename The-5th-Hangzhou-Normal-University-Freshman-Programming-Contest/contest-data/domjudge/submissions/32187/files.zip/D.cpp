#include <iostream>
#include <algorithm>
#include <map>
#include <vector>
using namespace std;
using ll = long long;
const int N = 2e5 + 10, INF = 2e9 + 10;
ll bits[N];
int n, k, q;
inline int lowbit(int x) {
    return x & (-x);
}
void add(int x, int v) {
    while(x <= n) {
        bits[x] += v;
        x += lowbit(x);
    }
}
ll query(int x) {
    ll ret = 0;
    while(x) {
        ret += bits[x];
        x -= lowbit(x);
    }
    return ret;
}

int rPos[N], a[N];

struct node {
    int id, val;
};
int main()
{
    scanf("%d %d %d", &n, &k, &q);
    for(int i = 1; i <= n; i++) scanf("%d", &a[i]);
    
    vector<node> asc, des;
    asc.push_back({n+1, INF});
    des.push_back({n+1, -INF});
    for(int i = n; i >= 1; i--) {
        rPos[i] = INF;
        while(asc.back().val < a[i])    asc.pop_back();
        asc.push_back({i, a[i]});
        while(des.back().val > a[i])    des.pop_back();
        des.push_back({i, a[i]});
        int lh = 0, rh = asc.size() - 1, pos;
        while(lh <= rh) {
            int mid = (lh + rh) / 2;
            if(asc[mid].val > a[i] + k) {
                pos = asc[mid].id;
                lh = mid + 1;
            } else {
                rh = mid - 1;
            }
        }
        rPos[i] = min(rPos[i], pos - i - 1);
        lh = 0, rh = des.size() - 1;
        while(lh <= rh) {
            int mid = (lh + rh) / 2;
            if(des[mid].val < a[i] - k) {
                pos = des[mid].id;
                lh = mid + 1;
            } else {
                rh = mid - 1;
            }
        }
        rPos[i] = min(rPos[i], pos - i - 1);
        add(i, rPos[i] + 1);
    }

    // for(int i = 1; i <= n; i++) printf(":%d\n", rPos[i]);
    int l, r;
    for(int i = 0; i < q; i++) {
        scanf("%d %d", &l, &r);
        int lh = l, rh = r, pos = r;
        while(lh <= rh) {
            int mid = (lh + rh) / 2;
            if(rPos[mid] + mid >= r) {
                pos = mid;
                rh = mid - 1;
            } else {
                lh = mid + 1;
            }
        }

        long long ans = 0;
        int num = r - pos + 1;
        r = pos - 1;
        ans += num * 1ll * (num + 1) / 2;
        if(r >= l)  ans += query(r) - query(l-1);
        printf("%lld\n", ans);
    }

    return 0;
}