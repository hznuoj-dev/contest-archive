/*
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
const int mod=1e9+7;
long long a[N],fa[N];
int p[N],cnt[N];
int find(int x)
{
    if(p[x]!=x)
    {
        p[x]= find(p[x]);
    }
    return p[x];
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    int n,q;
    cin >> n >> q;
    for (int i=1;i<=n;i++)
    {
        cin >> a[i];
        p[i]=i;
        fa[i]=a[i];
        cnt[i]=1;
    }
    while (q--)
    {
        int num;
        cin >> num;
        if(num==1)
        {
            int a,b;
            cin >> a >> b;
            a= find(a);
            b= find(b);
            p[a]=b;
            fa[b]+=fa[a];
            cnt[b]+=cnt[a];
        }else if(num==2)
        {
            int a,b;
            cin >> a >> b;
            a= find(a);
            fa[a]+=b*cnt[a];
        }else {
            int b;
            cin >> b;
            cout << a[b]%mod << endl;
        }
        for (int i=1;i<=n;i++)
        {
            int father= find(i);
            a[i]+=fa[father];
        }
    }
}
*/

#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N];
int n;
map<int,int> mp;
bool f(int x)
{
    stack<int> st;
    for (int i=1;i<=n;i++)
    {
        if(a[i]<x) st.push(a[i]);
        else if(a[i]>x){
            if(st.empty()) return false;
            st.pop();
        }
    }
    if(st.empty()) return true;
    else return false;
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin >> n;
    for (int i=1;i<=n;i++) cin >> a[i],mp[a[i]]++;
    int sum=0,ans=0,last=0;
    for (auto x:mp)
    {
        if(n-x.second-sum==sum)
        {
            if(f(x.first)) ans++;
        }else if(n-sum-x.second==sum+x.second && f(x.first+1))
        {
            last=x.first+1;
        }else if(n-sum==sum && last!=0 && f(x.first-1))
        {
            ans += x.first-last;
        }
        sum += x.second;
    }
    cout << ans;
    return 0;
}

/*
#include <iostream>
#include <bits/stdc++.h>
using namespace std;
const int N=2e5+10;
long long int a[N];
long long int now[N];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    return 0;
}
*/
