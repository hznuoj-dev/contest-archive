#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main()
{
	ios::sync_with_stdio(false);cin.tie(0);
	int n;cin>>n;
	int a[n+5]={},b[n+5]={},c[n+5]={};
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)cin>>b[i];
	for(int i=1;i<=n;i++)c[i]=-a[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	int ans=LLONG_MAX;
	int mi=-1;
	int flag=0;
	for(int i=1;i<=n;i++)
	{
		if(mi==-1)mi=abs(a[i]-b[i]);
		else if(abs(a[i]-b[i])!=mi)
		{
			flag=1;
			break;
		}
	}
	if(!flag)ans=min(ans,mi);
	mi=-1;
	flag=0;
	for(int i=1;i<=n;i++)
	{
		if(mi==-1)mi=abs(c[i]-b[i]);
		else if(abs(c[i]-b[i])!=mi)
		{
			flag=1;
			break;
		}
	}
	if(!flag)ans=min(ans,mi+1);
	if(ans==LLONG_MAX)cout<<"-1";
	else cout<<ans;
	return 0;
}
