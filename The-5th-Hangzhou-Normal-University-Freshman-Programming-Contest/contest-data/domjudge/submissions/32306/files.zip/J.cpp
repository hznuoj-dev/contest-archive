#include <bits/stdc++.h>
#define int long long
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

int read() {
    int x = 0, f = 1; char c = getchar();
    while(c < '0' || c > '9') c == '-' ? f = -1: 0, c = getchar();
	while(c >= '0' && c <= '9') x = (x << 1) + (x << 3) + (c ^ '0'), c = getchar();
    return x * f;
}

const int MOD = 1e9 + 7;
int w[200050], d[200050];
vector<int> e[200050];

int qpow(int a, int k, int r = 1) {
	for(; k; k >>= 1, a = 1ll * a * a % MOD)
		if(k & 1) r = 1ll * r * a % MOD;
	return r;
}

signed main() {
    int n = read(), m = read(), k = read();
    for(int i = 1; i <= m; ++i) {
        int u = read(), v = read();
        e[u].push_back(v);
        ++d[v];
    }
    
    queue<int> q;
    for(int i = 1; i <= n; ++i)
        if(!d[i]) q.push(i), w[i] = 1;
    
    while(!q.empty()) {
        int x = q.front(); q.pop();
        for(int y : e[x]) {
            w[y] = max(w[y], w[x] + 1);
            --d[y];
            if(!d[y]) q.push(y);
        }
    }
    
    int ans = 0;
    sort(w + 1, w + n + 1);
    for(int i = 1; i <= n; ++i)
        ans += lower_bound(w + 1, w + n + 1, w[i]) - w - 1;
    
    cout << qpow(ans, k) << endl;
    return 0;
}

