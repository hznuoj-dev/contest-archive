#include <bits/stdc++.h>
using namespace std;
const int N = 200005;
int a[N], ans = 0, stat[N];
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n, m, b;
	cin >> n >> m >> b;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	int flag = 0;
	int index = 1;
	ans = min(b, a[1]);
	stat[1] = a[1] - min(b, a[1]);
	for(int i = 2; i <= n; i++) {
		stat[i] = stat[i - 1] + a[i];
		if(index + m <= i && stat[i] >= b) {
			ans += min(b, stat[i]);
			if(stat[i] >= b) {
				stat[i] -= b;
			}
			index = i;
		} else if(i == n) {
			ans += stat[i];
			stat[i] -= stat[i];
		}
	}
//	for(int i = 1; i <= n; i++) {
//		cout << stat[i] << " ";
//	}
	cout << ans << "\n";
	return 0;
}
