#include <bits/stdc++.h>
using namespace std;
#define int long long
const int inf=0x3f3f3f3f;

int a[200200];
int b[200200];

void solve(){
	int n;
	cin>>n;
	for (int i=1;i<=n;++i) cin>>a[i];
	if (n%2==1) {
		cout<<"0\n";
		return;
	}
	
	int l=1,r=n;
	while (a[l]==a[r]&&l<r) ++l,--r;
	if (a[l]>a[r]){
		cout<<"0\n";
		return;
	}
	
	int ptr=0;
	for (int i=l;i<=r;++i){
		b[++ptr]=a[i];
	}
	
	
	
	sort(b+1,b+1+ptr);
	
//	for (int i=1;i<=ptr;++i) cout<<b[i]<<' ';
//	cout<<'\n';
	
	int ans=b[ptr/2+1]-b[ptr/2];
//	cout<<ans<<'\n';
	if (ans==0) ans=1;
	else if (ans>=1) --ans;
	cout<<ans<<'\n';
}
//    4
//    4 10 5 10

//	  4
//    1 4 4 10
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	
	int tt=1;
//	cin>>tt;
	while (tt--) solve();
	
	return 0;
}
