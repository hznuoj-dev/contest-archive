#include <iostream>
#include <bits/stdc++.h>
using namespace std;
#define int long long int
const int N = 1e6 + 10;
int n, m, b, op, rest, a[N], sum, ans;

signed main()
{
	cin >> n >> m >> b;
	op = (n - 1) / m;
	op++;
	rest = (n - 1) % m;
	int cd = 0;
	for (int i = 0; i < n; i++)
	{
		int x = 0;
		scanf("%lld", &x);
		sum += x;
		if (cd == 0)
		{
			if (rest && sum < b)
			{
				rest--;
				continue;
			}
			else if (rest != 0 && op && sum >= b)
			{
				sum -= b;
				ans += b;
				op--;
				cd = m;
			}
			else if (rest == 0 && op)
			{
				if (sum >= b)
				{
					sum -= b;
					ans += b;
				}
				else
				{
					ans += sum;
					sum = 0;
				}
				op--;
				cd = m;
			}

			else if (i == n - 1 && op)
			{
				if (sum >= b)
				{
					ans += b;
				}
				else
				{
					ans += sum;
				}
				cd = m;
			}
		}
		cd--;
	}
	cout << ans << endl;

	return 0;
}

