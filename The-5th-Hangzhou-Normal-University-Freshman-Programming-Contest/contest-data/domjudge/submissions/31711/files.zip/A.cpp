#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;

struct yb{
	double a,b;
	double c;
}q[6];
bool cmp(yb a,yb b){
	if(a.c!=b.c)return a.c>b.c;
	else return a.a<b.a;
}
int main(){
	int m,k;
	cin>>m>>k;
	for(int i=1;i<=5;i++)cin>>q[i].a;
	for(int i=1;i<=5;i++)cin>>q[i].b;
	for(int i=1;i<=5;i++){
		q[i].c=q[i].b/q[i].a;
	}
	sort(q+1,q+6,cmp);
	double maxn=0;
	for(int i=1;i<32;i++){
		int n=i,j=1,a=0,b=0;
		while(n>0){
			if(n%2){
				a+=q[j].a;
				b+=q[j].b;
			}
			j++;
			n>>=1;
		}
		if(a>=m)a-=k;
		double c=(double)b/(double)a;
		cout<<c<<endl;
		maxn=max(maxn,c);
	}
	printf("%.2llf",maxn);
}