#include <bits/stdc++.h>
using namespace std;
using i64 = long long;
 
int main() {
	cin.tie(0), cout.tie(0);
	ios::sync_with_stdio(false);
	
	int m, k;
	cin >> m >> k;
	vector<double> a(6), b(6);
	for (int i = 1; i <= 5; ++i) {
		cin >> a[i];
	} 
	for (int i = 1; i <= 5; ++i) {
		cin >> b[i];
	}
	
	double ans = -1;
	for (int i = 1; i < 32; ++i) {
		double bb = 0, aa = 0;
		for (int x = i, j = 1; x; x >>= 1, j += 1) {
			if (x & 1) {
				bb += b[j];
				aa += a[j];
			}
		}
		if (aa >= m) {
			aa -= k;
		}
		ans = max(ans, bb / aa);
	}
	
	cout << setprecision(2) << fixed << ans << '\n';
	return 0;
} 
