#include<bits/stdc++.h>
using namespace std;
int a[200005],b[200005];
int pos[200005];
int main(){
	int n;
	scanf("%d",&n);
	int maxn=0;
	int minn=(int)2e5+5;
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		b[i]=a[i];
	}
	sort(b,b+n);
	int mid;
	mid=b[n/2-1];
//	printf("%d\n",mid);
	stack<int>s;
	for(int i=0;i<n;i++){
		if(n%2&&a[i]==mid||b[n/2]==mid&&a[i]==mid)continue;
		if(s.empty()){
			if(a[i]>mid){
				puts("0");
				return 0;
			}
			s.push(a[i]);
		}
		else{
			if(a[i]>mid)s.pop();
			else s.push(a[i]);
		}
	}
	if(!s.empty()){
		puts("0");
		return 0;
	}
	if(n%2){
		puts("1");
	}else{
		if(b[n/2]==(mid))puts("1");
		else printf("%d\n",b[n/2]-mid-1);
	}
}
