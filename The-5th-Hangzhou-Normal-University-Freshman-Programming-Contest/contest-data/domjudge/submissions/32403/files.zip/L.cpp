#include <bits/stdc++.h>
using namespace std;
#define fastio ios::sync_with_stdio(false);cin.tie(0); cout.tie(0)
typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e6 + 5;

ll read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){
        if(c=='-')f=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9'){
        x=(x<<3)+(x<<1)+(c^48);
        c=getchar();
    }
    return x;
}

ll a[200005];

signed main() {
    fastio;
    ll n=read(),q,h,s=0;

    for(int i=0;i<n;i++){
        a[i]=read();
    }
    q=a[0],h=a[n-1];
    sort(a,a+n);
    if(n%2==1){
        s=a[n/2];
        if(s<q||s>h){
            printf("0");
        }
        else {
            ll z=0,y=0;
            for(int i =0;i<n/2;i++){
                if(a[n/2-i]==s)z++;
                if(a[n/2+i]==s)y++;
                if(z!=y)break;
                if(a[n/2-i]!=s)break;
            }
            if(z!=y)printf("0");
            else {
                printf("%lld",a[n/2+y]-a[n/2-y]-1);
            }
        }
    }
    else {
        q=max(q,a[n/2-1]);
        h=min(a[n/2],h);
        if(q>h){
            printf("0");
        }
        else if(q==h){
            ll z=1,y=1;
            for(int i=1;i<n/2;i++){
                if(a[n/2-1-i]==q)z++;
                if(a[n/2+i]==q)y++;
                if(z!=y)break;
                if(a[n/2+i]!=q)break;
            }
            if(z!=y)printf("0");
            else if(z==n/2)printf("1");
            else printf("%lld",a[n/2+z]-a[n/2-1-z]-1);
        }
        else printf("%lld",h-q-1);
    }
    system("pause");
}