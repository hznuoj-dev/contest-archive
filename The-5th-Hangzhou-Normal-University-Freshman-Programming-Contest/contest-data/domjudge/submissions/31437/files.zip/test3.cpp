#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
int cmp(int a,int b)
{
	return a>b;
}
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t;
	//cin >> t;
	t = 1;
	while (t--)
	{
		int n;
		cin>>n;
		int minn=1e15;
		vector<int>a(n),b(n);
		for(int i=0;i<n;i++)
		{
			cin>>a[i];
		}
		vector<int>sub(n);
		for(int i=0;i<n;i++)
		{
			cin>>b[i];
		}
		sort(a.begin(),a.end());
		sort(b.begin(),b.end());
		for(int i=0;i<n;i++)
		sub[i]=b[i]-a[i];
		if(n==1)
		{
			cout<<min(abs(a[0]-b[0]),abs(a[0]+b[0])+1);
			return 0;
		}
		for(int i=1;i<sub.size();i++)
		{
			if(sub[i]!=sub[i-1])
			break;
			if(i==sub.size()-1)
			minn=abs(sub[0]);
		}
		sort(b.begin(),b.end(),cmp);
		for(int i=0;i<b.size();i++)
		{
			b[i]=-b[i];
			sub[i]=b[i]-a[i];
		}
		for(int i=1;i<sub.size();i++)
		{
			if(sub[i]!=sub[i-1])
			break;
			if(i==sub.size()-1)
			minn=min(minn,1+abs(sub[0]));
		}
		if(minn!=1e15)
		cout<<minn<<endl;
		else
		cout<<-1<<endl;
	}
	return 0;
}