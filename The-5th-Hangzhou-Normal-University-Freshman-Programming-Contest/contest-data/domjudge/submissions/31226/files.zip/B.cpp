#include<bits/stdc++.h>
using namespace std;
const int maxn = 2e5 + 9;
int a[maxn],b[maxn];
int n;
int main() {
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	cin >> n;
	for(int i = 1; i <= n; i ++) {
		cin >> a[i];
	}
	for(int i = 1; i <= n; i ++) {
		cin >> b[i];
	}
	sort(a + 1,a + 1 + n);
	sort(b + 1,b + 1 + n);
	int i = 2;
	int ans1 = -1,ans2 = -1;
	while(a[i] - b[i] == a[i - 1] - b[i - 1] && i <= n) ++i;
	if(i == n + 1) {
		ans1 = abs(a[1] - b[1]) ;
	}
	for(int j = 1; j <= n; j ++) a[j] = -a[j];
	sort(a + 1,a + 1 + n);
	i = 2;
	while(a[i] - b[i] == a[i - 1] - b[i - 1] && i <= n) ++i;
	if(i == n + 1) {
		ans2 = abs(a[1] - b[1]) + 1 ;
	}
	if(ans1 != -1 && ans2 != -1) cout << min(ans1,ans2) << '\n';
	else if(ans1 == -1 && ans2 == -1) cout << -1 << '\n';
	else cout << max(ans1,ans2) << '\n';
	return 0;
}

