#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 3e5+7,inf = 1e18+7;
typedef long long ll;

int a[N],pre[N];

void solve(){
	int n,m,b;
	cin >> n >> m >> b;
	for (int i = 1; i <= n; i++){
		cin >>a[i];
		pre[i] = pre[i - 1] + a[i];
	}
	int ans = 0;
	for (int i = 1; i <= m; i++){
		int sum = 0;
		for (int j = i; j <= n; j += m){
			int tmp = pre[j] - sum;
			if (tmp >= b){
				sum += b;
			}else{
				sum += tmp;
			}
		}
		ans = max(ans,sum);
	}
	cout << ans << '\n';
}

signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc = 1;
//	cin >> tc;
	while (tc--){
		solve();
	}
	return 0;
}
/*
5 3
1 2 4 4 2
2 2 1 2 4

*/
