#include <bits/stdc++.h> 

using i64 = long long;

struct node {
	double x, y;
};

bool cmp(node a, node b)
{
	return a.y / a.x > b.y / b.x;
}

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int m, k;
	std::vector<node> a(5);
	std::string str[32] = {"00000", "00001", "00010", "00011", "00100", "00101", "00110", "00111", "01000", "01001", "01010", "01011", "01100", "01101", "01110", "01111", "10000", "10001", "10010", "10011", "10100", "10101", "10110", "10111", "11000", "11001", "11010", "11011", "11100", "11101", "11110", "11111"};
	double maxn = 0.00;
	int sum = 0, cnt = 0, t;
	
	//std::cout << str[31];
	std::cin >> m >> k;
	for (int i = 0; i < 5; ++i)
	std::cin >> a[i].x;
	for (int i = 0; i < 5; ++i)
	std::cin >> a[i].y;
	for (int i = 1; i < 32; ++i) {
		sum = cnt = 0;
		for (int j = 0; j < 5; ++j) {
			if (str[i][j] == '1') {
				sum += a[j].y;
				cnt += a[j].x;
			}
		}
		if (cnt >= m)
		t = k;
		else
		t = 0;
	//	std::cout << sum << ' ' << cnt << ' ' << t << ' ' << 1.0 * sum / (cnt - t) << ' ' << maxn << '\n';
		if (1.0 * sum / (cnt - t) > maxn)
		maxn = sum / (cnt - t);
	}
	std::cout << std::fixed << std::setprecision(2) << maxn;
	
	return 0;
} 
