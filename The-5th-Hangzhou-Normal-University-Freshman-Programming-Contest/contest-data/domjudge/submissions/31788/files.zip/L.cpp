#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int m,k;
double a[6],b[6],ans;
int main()
{
    cin>>m>>k;
    for(int i=1;i<=5;i++)cin>>a[i];
    for(int i=1;i<=5;i++)cin>>b[i];
    for(int i=1;i<=5;i++)
    {
        double x=a[i];
        if(x>=m)x-=k;
        ans=max(ans,b[i]/x);
    }
    double sum=0,sum1=0;
    for(int i=1;i<=5;i++)
    { 
        sum+=a[i];
        sum1+=b[i];
    }
    int t=0;
    if(sum>=m)t=1,sum-=k;
    ans=max(ans,sum1/sum);
    if(t)sum+=k;
    for(int i=1;i<=5;i++)
    { 
        double x=sum-a[i];
        if(x>=m)x-=k;
        ans=max(ans,sum1-b[i]/x);
    }
    for(int i=1;i<=5;i++)
    {
        for(int j=1;j<=5;j++)
        {
            if(j==i)continue;
            double x=a[i]+a[j],y=b[i]+b[j];
            if(x>=m)x-=k;
            ans=max(ans,y/x);
            double x1=sum-a[i]-a[j],y1=sum1-y;
            if(x1>=m)x1-=k;
            ans=max(ans,y1/x1);
        }
    }
    printf("%.2lf",ans);
    return 0;
}
