#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define fi first
#define se second
#define pii pair<int,int>
#define pb push_back
const int N = 2E5 + 10;

void solve() {
	int n; cin >> n;
	
	vector<ll> a(n + 1), b(n + 1);
	for (int i = 1; i <= n; i++) cin >> a[i];
	for (int i = 1; i <= n; i++) cin >> b[i];
	
	sort(a.begin() + 1, a.end());
	sort(b.begin() + 1, b.end());
	
	ll tmp = a[1] - b[1];
	int f = 1;
	for (int i = 2; i <= n; i++) {
		if (a[i] - b[i] != tmp) {
			f = 0;
			break;
		}
	}

	for (int i = 1; i <= n; i++) {
		a[i] *= -1;
	}
	sort(a.begin() + 1, a.end());
	
	ll tmp1 = a[1] - b[1];
	int f1 = 1;
	for (int i = 2; i <= n; i++) {
		if (a[i] - b[i] != tmp1) {
			f1 = 0;
			break;
		}
	}
	if (f && f1) {
		cout << min(abs(tmp), abs(tmp1) + 1) << endl;
	}else if (f) {
		cout << abs(tmp) << endl;
	}else if (f1) {
		cout << abs(tmp1) + 1 << endl;
	}else cout << "-1\n";
	
}
/*
1 2 3 4
-3 -2 -1 0


*/

int main() {
	ios::sync_with_stdio(0); cout.tie(0); cin.tie(0);

	int T = 1;

	while(T--) solve();

	return 0;
}

