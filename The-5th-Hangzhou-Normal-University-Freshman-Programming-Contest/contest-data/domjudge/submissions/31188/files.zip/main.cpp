#include <iostream>
#include <algorithm>
#include <queue>
#include <cstring>
#define endl "\n"
using namespace std;
typedef pair<int, int> PII;
typedef long long ll;

const int N = 2e5 + 10;
int n, k;
int a[N], b[N];
int cnt[N];
int main()
{
    cin >> n;
    for(int i = 0;i < n;i++)
    {
        cin >> a[i];
        cnt[a[i]]++;
    }
    memcpy(b, a, sizeof(a));
    sort(a, a + n);
    if(n % 2)
    {
        if(cnt[a[n / 2]] % 2)
        {
            k = 1;
            int bb = 0;
            for(int i = 0;i < n;i++)
            {
                if(b[i] == a[n / 2])
                continue;
                if(b[i] < a[n / 2])
                {
                    bb++;
                }
                else
                {
                    bb--;
                }
                if(bb < 0)
                break;
            }
            if(bb < 0)
            k = 0;
        }
        else
        {
            k = 0; 
        }
    }
    else
    {
        if(a[n / 2 - 1] != a[n / 2])
        {
            int bb = 0;
            k = a[n / 2] - a[n / 2 - 1] - 1;
            for(int i = 0;i < n;i++)
            {
                if(b[i] < a[n / 2])
                {
                    bb++;
                }
                else
                {
                    bb--;
                }
                if(bb < 0)
                break;
            }
            if(bb < 0)
            {
                k = 0;
            }
        }
        else if(cnt[a[n / 2]] % 2 == 0)
        {
            if(a[n / 2] == a[0] || a[n / 2] == a[n - 1])
            {
                if(a[n - 1] == a[0])
                {
                    k = 1;
                }
                else
                {
                    k = 0;
                }
            }
            else
            {
                k = 1;
                int bb = 0;
                for(int i = 0;i < n;i++)
                {
                    if(b[i] == a[n / 2])
                    continue;
                    if(b[i] < a[n / 2])
                    {
                        bb++;
                    }
                    else
                    {
                        bb--;
                    }
                    if(bb < 0)
                    {
                        k = 0;
                        break;
                    }
                }
            }
        }
        else
        {
            k = 0;
        }
    }
    cout << k;
    return 0;
}