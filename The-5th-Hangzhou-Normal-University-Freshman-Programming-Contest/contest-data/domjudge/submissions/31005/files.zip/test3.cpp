#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int t;
	//cin >> t;
	t = 1;
	while (t--)
	{
		int n;
		cin >> n;
		vector<int>s(n);
		for (int i = 0;i < n;i++)
		{
			cin >> s[i];
		}
		sort(s.begin(), s.end());
		int ans, l, r;
		if (s.size() == 1)
		{
			cout << 1 << endl;
			return 0;
		}
		if (s.size() % 2)
		{
			l = s[(s.size() + 1) / 2];
			r = l;
		}
		else
		{
			l = s[s.size() / 2 - 1];
			r = s[s.size() / 2];
			if (l != r)r--, l++;
		}
		cout << r - l + 1 << endl;
	}
	return 0;
}