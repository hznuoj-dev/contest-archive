#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
const int N = 2 * 1e5 + 100;
int a[N], b[N], c[N];
bool cmp(int a, int b)
{
    return a > b;
}
int main()
{
    int n;
    cin >> n;
    int i, j, k, l = 0, res = 0x3f3f3f3f;
    for(i = 0; i < n; i++)
        cin >> a[i];
    for(i = 0; i < n; i++)
    {
        cin >> b[i];
        c[i] = b[i];
    }
    sort(a, a + n);
    sort(b, b + n);
    sort(c, c + n, cmp);
    i = 1;
    while(i < n)
    {
        if (abs(a[i] - a[i - 1]) != abs(b[i] - b[i - 1]))
        {
            l++;
            break;
        }
        i++;
    }
    if (i == n)
        res = abs(a[0] - b[0]);

    i = 1;
    while(i < n)
    {
        if (abs(a[i] - a[i - 1]) != abs(c[i] - c[i - 1]))
        {
            l++;
            break;
        }
        i++;
    }
    if (i == n)
        res = min(res, abs(a[0] + c[0]) + 1);
    if (l == 2)
    {
        cout << -1 << endl;
        return 0;
    }
    cout << res << endl;

}