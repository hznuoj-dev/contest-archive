#include <bits/stdc++.h>
#define ll long long
using namespace std;
int a[200010], b[200010];
int n;
bool check(ll k) {
	int cnt1 = 0, cnt2 = 0;
	for (int i = 1; i <= n; i++) {
		if (a[i] < k) cnt1++;
		else if (a[i] > k) cnt2++;
		if (cnt1 < cnt2) return false; 
	}
	if (cnt1 == cnt2) return true;
	else return false;
}
map<ll, ll> mp;
int main () {
	cin >> n;
	for (int i = 1; i <= n; i++) cin >> a[i], b[i] = a[i], mp[a[i]]++;
	sort(b + 1, b + n + 1);
	if (n % 2) {
		ll k = b[n / 2 + 1];
		if (check(k)) cout << 1;
		else cout << 0;
		return 0;
	}
	if (b[n / 2 + 1] == b[n / 2]) {
		if (mp[b[n / 2]] % 2) {
			cout << 0;
		} 
		else if (check(b[n / 2])) cout << 1;
		else cout << 0;
		return 0;
	}
//	ll ans = 0;
	if (b[n / 2 + 1] - b[n / 2] - 1 <= 0) cout << 0;
	else {
		ll k = b[n / 2] + 1;
		if (check(k)) {
			//cout << "!!!!!!!!!!";
			cout << (b[n / 2 + 1] - b[n / 2] - 1);
			//cout << ans;
		}
		else cout << 0;
	}
}
