#include <bits/stdc++.h>

using namespace std;
using LL = long long;

int a[10], b[10];

int m, k;

int sum1, sum2, sum3;

double res, ans;

double sol1(int a1, int b1)
{
    sum1 = a1;
    sum2 = b1;

    if(sum1 >= m)sum1 -= k;

    return double(sum2) / double(sum1);
}

double sol2(int a1, int b1, int a2, int b2)
{
    sum1 = a1 + a2;
    sum2 = b1 + b2;

    if(sum1 >= m)sum1 -= k;

    double ans = double(sum2) / double(sum1);

    return ans;
}

double sol3(int a1, int b1, int a2, int b2,int a3, int b3)
{
    sum1 = a1 + a2 + a3;
    sum2 = b1 + b2 + b3;

    // cout << ":" <<  sum1 << endl;

    if(sum1 >= m)sum1 -= k;

    // cout << "=" << sum1 << endl;

    double ans = double(sum2) / double(sum1);

    return ans;
}

double sol4(int a1, int b1, int a2, int b2,int a3, int b3, int a4, int b4)
{
    sum1 = a1 + a2 + a3 + a4;
    sum2 = b1 + b2 + b3 + b4;

    if(sum1 >= m)sum1 -= k;

    double ans = double(sum2) / double(sum1);

    return ans;
}

double sol5(int a1, int b1, int a2, int b2,int a3, int b3, int a4, int b4, int a5, int b5)
{
    sum1 = a1 + a2 + a3 + a4 + a5;
    sum2 = b1 + b2 + b3 + b4 + b5;

    if(sum1 >= m)sum1 -= k;

    double ans = double(sum2) / double(sum1);

    return ans;
}

void solve()
{
    cin >> m >> k;

    for(int i = 1; i <= 5; ++ i)cin >> a[i];

    for(int i = 1; i <= 5; ++ i)cin >> b[i];

    res = 0;

    for(int i = 1; i <= 5; ++ i)
    {
        if(res < sol1(a[i], b[i]))res = sol1(a[i], b[i]);
    }

    for(int i = 1; i <= 5; ++ i)
    {
        for(int j = 1; j <= 5; ++ j)
        {
            if(i == j)continue;

            double ans = sol2(a[i], b[i], a[j], b[j]);

            if(ans > res)res = ans;
        }
    }

    for(int i = 1; i <= 5; ++ i)
    {
        for(int j = 1; j <= 5; ++ j)
        {
            if(i == j)continue;

            for(int k = 1; k <= 5; ++ k)
            {
                if(k == i || k == j)continue;

                double ans = sol3(a[i], b[i], a[j], b[j], a[k], b[k]);

                if(ans > res)res = ans;
            }
        }
    }

    for(int i = 1; i <= 5; ++ i)
    {
        for(int j = 1; j <= 5; ++ j)
        {
            if(i == j)continue;

            for(int k = 1; k <= 5; ++ k)
            {
                if(k == i || k == j)continue;

                for(int g = 1; g <= 5; ++ g)
                {
                    if(g == i || g == j || g == k)continue;

                    double ans = sol4(a[i], b[i], a[j], b[j], a[k], b[k], a[g], b[g]);

                    if(ans > res)res = ans;
                }
            }
        }
    }

    double ans = sol5(a[1], b[1], a[2], b[2], a[3], b[3], a[4], b[4], a[5], b[5]);

    if(res < ans)res = ans;

    printf("%.2lf\n", res);
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // int T;
    // for (cin >> T; T -- ; )
        solve();

}