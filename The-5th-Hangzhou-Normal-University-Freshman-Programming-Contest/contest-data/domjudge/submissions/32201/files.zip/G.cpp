#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll dp[200010];
ll s[200010];
int a[200010];
int main () {
	int n, m, k;
	cin >> n >> m >> k;
	vector<ll> v;
	for (int i = 1; i <= n; i++) cin >> a[i];
	for (int i = 1; i <= n; i++) {
		s[i] = s[i - 1] + a[i];
		if (i < m + 1) dp[i] = s[i] >= k ? k : s[i];
		if (i >= m + 1) v.push_back(-dp[i - m]);
		if (i >= m + 1) {
			sort(v.begin(), v.end());
			//for (int i = 0; i < v.size(); i++) cout << v[i] << " ";
			//cout << endl;
			int num;
			if (k - s[i] < v[0]) num = 0; 
			else num = lower_bound(v.begin(), v.end(), k - s[i]) - v.begin() - 1;
			dp[i] = -v[num] + k;
			//cout << dp[i] << endl;
			dp[i] = min(dp[i], s[i]);
			//cout << num << endl;
		}
	}
	ll ans = 0;
	for (int i = 1; i <= n; i++) ans = max(ans, dp[i]);
	cout << ans;
}
