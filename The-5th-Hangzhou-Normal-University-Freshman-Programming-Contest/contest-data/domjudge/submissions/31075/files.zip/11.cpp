#include<bits/stdc++.h>
using namespace std;
int n;
int a[203000],b[202000],c[202000],max1,max2,flag1,flag2;
int main()
{
	cin>>n;
	for(int i=0;i<n;i++)cin>>a[i];
	for(int i=0;i<n;i++)
	{
		cin>>b[i];
		c[i]=-1*b[i];
		
	}
	sort(a,a+n);
	sort(b,b+n);
	sort(c,c+n);
	for(int i=0;i<n;i++)
	{
		if(i==0)
		{
			max1=a[i]-c[i];
			max2=a[i]-b[i];
		}
		else
		{
			if(a[i]-c[i]!=max1)
			{
				flag1=1;
			}
			if(a[i]-b[i]!=max2)
			{
				flag2=1;
			}
		}
	}
	if(flag1==0&&flag2==0)
	{
		cout<<min(abs(max2),abs(max1));
	}
	else if(flag1==1&&flag2==0)
	{
		cout<<abs(max2);
	}
	else if(flag1==0&&flag2==1)
	{
		cout<<abs(max1);
	}
	else if(flag1==1&&flag2==1)
	{
		cout<<-1;
	}
	return 0;
}
