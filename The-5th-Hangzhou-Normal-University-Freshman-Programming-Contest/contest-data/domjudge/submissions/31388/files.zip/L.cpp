#include<bits/stdc++.h>

using namespace std;

const int N = 200005;

#define ll long long

#define mod 998244353

ll a[N];
ll b[N];

int vis[N];
double ans;

ll m,k;

void find(){
	ll sum1 = 0;
	ll sum2 = 0;
	for(int i=1;i<=5;++i){
		if(vis[i]){
			sum1 += b[i];
			sum2 += a[i];
		}
	}
	
	if(sum2 == 0) return ;
	if(sum2 >= m) sum2 -= k;
	
	double now = sum1*1.0 / sum2;
	ans = max(ans,now);
}

void dfs(int x){
	if(x == 5){
		find();
		return ;
	}
	vis[x+1] = 1;
	dfs(x+1);
	vis[x+1] = 0;
	dfs(x+1);
}

void solve(){
	cin>>m>>k;
	for(int i=1;i<=5;++i){
		cin>>a[i];
	}
	for(int i=1;i<=5;++i){
		cin>>b[i];
	}
	
	vis[1] = 1;
	dfs(1);
	vis[1] = 0;
	dfs(1);
	
	printf("%.2lf",ans);
}

int main(){
	cin.sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
