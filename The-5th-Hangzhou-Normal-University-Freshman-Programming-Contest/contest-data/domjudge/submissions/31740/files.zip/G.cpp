#include<bits/stdc++.h>
#define int long long
#define fu(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fd(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define PRN(X) cout << #X << "=" << X << endl
#define PR(X) cout << #X << "=" << X << " "
using namespace std;

const int N = 2e5 + 5;

int read(){
	int f = 1, x = 0; char ch = getchar();
	while(ch > '9' || ch < '0'){ 	if(ch == '-')f = -1; ch = getchar(); }
	while(ch <= '9' && ch >= '0'){ x = (x << 1) + (x << 3) + (ch ^ 48);  ch = getchar(); }
	return x * f;
}
int f[N], g[N], a[N], sum[N];
void solve(){
	int n = read(), m = read(), b = read();
	fu(i, 1, n) {
		a[i] = read();
		sum[i] = sum[i - 1] + a[i];
	}
	fu(i, 1, n) {
		if(b > sum[i] - g[max(0ll, i - m)]) f[i] = sum[i];
		else f[i] = g[max(0ll, i - m)] + b;
		g[i] = max(f[i], g[i - 1]);
	}
	cout << f[n] << endl;
}
signed main(){
	int t = 1;
	while(t--){
		solve();
	}
}


