#include <bits/stdc++.h>
using namespace std;
int m,k;
double ans=-1;
int bit[10],a[10],b[10];
int main(){
	cin>>m>>k;
	for(int i=1;i<=5;i++){
		scanf("%d",&a[i]);
	}
	for(int j=1;j<=5;j++){
		scanf("%d",&b[j]);
	}
	for(int i=1;i<=31;i++){
		int x=i,len=0;
		for(int j=1;j<=5;j++) bit[j]=0;
		while(x){
			bit[++len]=x%2;
			x/=2;
		}
		int sum1,sum2;
		sum1=sum2=0;
		for(int j=1;j<=5;j++){
			if(bit[j]) sum1+=b[j],sum2+=a[j];
		}
		if(sum2>=m) sum2-=k;
		double tmp=(1.0*sum1)/(1.0*sum2);
		if(tmp-ans>=0.001) ans=tmp;
	}
	printf("%.2lf",ans);
	return 0;
}
