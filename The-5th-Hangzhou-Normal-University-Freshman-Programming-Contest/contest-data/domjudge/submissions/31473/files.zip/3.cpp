#include <bits/stdc++.h>

const int N = 2*1e5 + 10;

using namespace std;

int main()
{
	int n;
	int a[N];
	int b[N];
	int c,d;
	int f,g;
	cin >> n;
	for(int i = 0 ; i < n; i ++)
	{
		cin >> a[i];
	}
	for(int i = 0 ; i < n; i ++)
	{
		cin >> b[i];
	}	
	sort(a,a+n);
	sort(b,b+n);
	int t = 0;
	if(a[0] >= b[0])
	{
		for(int i = 0; i < n-1; i ++)
		{
			c = a[i] - b[i];
			d = a[i+1] - b[i+1];
			f = c;
			if(c != d)
			{
				t = 1;
				break;
			}
		}
		if(t==0)
		{
			if(-a[0] >= b[n-1])
			{
				for(int i = 0; i < n-1; i ++)
				{
					c = -a[i] - b[n-1-i];
					d = -a[i+1] - b[n-2-i];
					g = c;
					if(c != d)
					{
						t = 1;
						break;
					}
				}					
			}
			else
			{
				for(int i = 0; i < n-1; i ++)
				{
					c = a[n-1-i] + b[i];
					d = a[n-2-i] + b[i+1];
					g = c;
					if(c != d)
					{
						t = 1;
						break;
					}
				}					
			}						
		}
		if(t == 0)
		{
			if (f >= g + 1)
			{
				cout << g + 1;
			}
			else
			{
				cout << f;
			}
		}
	}
	else
	{
		for(int i = 0; i < n-1; i ++)
		{
			c = -a[i] + b[i];
			d = -a[i+1] + b[i+1];
			f = c;
			if(c != d)
			{
				t = 1;
				break;
			}
		}
		if(t==0)
		{
			if(a[n-1] <= -b[0])
			{
				for(int i = 0; i < n-1; i ++)
				{
					c = -a[n-1-i] - b[i];
					d = -a[n-2-i] - b[i+1];
					g = c;
					if(c != d)
					{
						t = 1;
						break;
					}
				}					
			}
			else
			{
				for(int i = 0; i < n-1; i ++)
				{
					c = a[i] + b[n-1-i];
					d = a[i+1] + b[n-2-i];
					g = c;
					if(c != d)
					{
						t = 1;
						break;
					}
				}					
			}						
		}
		if(t == 0)
		{
			if (f >= g + 1)
			{
				cout << g + 1;
			}
			else
			{
				cout << f;
			}
		}			
	}
	
	if(t == 1)
	{
		cout << "-1";
	}
	return 0;
}
