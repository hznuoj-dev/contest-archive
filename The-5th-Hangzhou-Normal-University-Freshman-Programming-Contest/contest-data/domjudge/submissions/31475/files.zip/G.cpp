#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
typedef unsigned long long ull;
const int N=2e5+10;
const int mod=1e9+7;

int a[N];

void run()
{
	int n,m,b,ans,sum,st;
	
	cin >> n >> m >> b;
	for(int i=1;i<=n;i++)
		cin >> a[i];
	ans=sum=0;
	st=n;
	while(st-m>0)
		st-=m;
	
	for(int i=1;i<=n;i++)
	{
		sum+=a[i];
		if(i==st)
		{
			st+=m;
			ans+=min(sum,b);
			sum=max(sum-b,0LL);
		}
	}
	cout << ans;
}

signed main()
{
    int T=1;

    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

