#include <iostream>
#include <cstring>
#include <queue>
#include <math.h>
#include <algorithm>

using namespace std;
const int N = 2E5 + 5;
using ll = long long;
ll a[N], b[N];
int main()
{

    ll i, j, k, n, l = 0, o, flag1 = 1, flag2 = 1, step1 = -1, step2 = -2, left, right, sum = 0;
    priority_queue<ll> Q1;
    cin >> n;
    for (i = 1; i <= n; i++)
        cin >> a[i];
    if (n == 1 || n == 3)
        cout << 1 << endl;
    else
    {
        for (i = 1; i <= n; i++)
            Q1.push(a[i]);
        while (!Q1.empty())
        {
            l++;
            b[i] = Q1.top();
            Q1.pop();
        }
        if (n % 2 == 0)
        {
            left = b[n / 2];
            right = b[n / 2 + 1];
            if (left != right)
                cout << left - right - 1 << endl;
            else
            {
                for (i = 1; i <= n; i++)
                {
                    if (left == b[i])
                        sum++;
                }
                if (sum % 2 == 0)
                    cout << 1 << endl;
                else
                    cout << 0 << endl;
            }
        }
        else
        {
           left = b[n/2+1];
                for (i = 1; i <= n; i++)
                {
                    if (left == b[i])
                        sum++;
                }
                if (sum % 2 == 0)
                    cout << 0 << endl;
                else
                    cout << 1 << endl;
             
        }
    }

    return 0;
}