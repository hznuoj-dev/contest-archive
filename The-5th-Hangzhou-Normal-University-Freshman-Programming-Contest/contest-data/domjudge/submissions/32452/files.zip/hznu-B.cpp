#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 2e5+5;
ll a[N],b[N],c[N],d[N];
int main()
{
    ll n,i;
    ll flag1=0,flag2=0;
    cin >> n;
    for(i=0;i<n;i++)
    {
        cin >> a[i];
    }
    for(i=0;i<n;i++)
    {
        cin >> b[i];
    }
    sort(a,a+n);
    sort(b,b+n);
    for(i=1;i<n;i++)
    {
        c[i]=a[i]-a[i-1];
        d[i]=b[i]-b[i-1];
    }
    for(i=1;i<n;i++)
    {
        if(c[i]!=d[i])
        {
            flag1=1;
            break;
        }
    }
    for(i=1;i<n;i++)
    {
        if(c[i]!=d[n-i])
        {
            flag2=1;
            break;
        }
    }
    if(flag1==1&&flag2==1)
    {
        cout << "-1" << endl;
    }
    else if(flag1==1&&flag2==0)
    {
        cout << abs(a[0]+b[n-1])+1 << endl;
    }
    else if(flag1==0&&flag2==1)
    {
        if(a[0]>=b[0])
        cout << a[0]-b[0] <<endl;
        else
        cout << b[0]-a[0] <<endl;
    }
    else if(flag1==0&&flag2==0)
    {
        ll x=abs(a[0]+b[n-1])+1;
        ll y=abs(a[0]-b[0]);
        x=(x<y)?x:y;
        cout << x << endl;
    }
    return 0;
}