#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
bool cmp(int a, int b) {
	return abs(a) < abs(b);
}
int n, a[200010], b[200010];
int main()
{
	
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 1; i <= n; i++) cin >> b[i];
	sort(a + 1, a + n, cmp);
	sort(b + 1, b + n, cmp);
	bool f1 = true;
	bool f2 = true;
	for (int i = 1; i < n; i++) {
		if (a[i] - a[i + 1] != b[i] - b[i + 1]) {
			f1 = false;
		}
		if (a[i] - a[i + 1] != b[i + 1] - b[i]) {
			f2 = false;
		}
	}
	if (f1) cout << abs(a[1] - b[1]) << endl;
	else if (f2) cout << 1 + abs(-a[1] - b[1]) << endl;
	else cout << -1 << endl;
	return 0;
}
// 
//3 -1 2 -3
// 1 -2 3
// 3 ȫ��
// 1 3 4
// 4 6 7
//3 ȫ��
// -1 -2 -3
// -4 -5 -6