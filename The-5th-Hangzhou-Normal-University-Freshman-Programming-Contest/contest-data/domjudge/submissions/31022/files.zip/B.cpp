﻿#include<bits/stdc++.h>
using namespace std;
const int N=2e5+9;
#define ll long long
int a[N],b[N],n;
ll ans,tmp;
int main()
{
    cin>>n;
    for(int i=1;i<=n;i++) cin>>a[i];
    for(int i=1;i<=n;i++) cin>>b[i];
    sort(a+1,a+1+n);
    sort(b+1,b+1+n);
    ans=a[1]-b[1];
    for(int i=2;i<=n;i++) 
    {
        if(a[i]-b[i]!=ans)
        {
            ans=1e16;
            break;
        }
    }
    for(int i=1;i<=n;i++) a[i]=-a[i];
    tmp=a[1]-b[1];
    for(int i=2;i<=n;i++) 
    {
        if(a[i]-b[i]!=tmp)
        {
            tmp=1e16;
            break;
        }
    }
    if(tmp==1e16&&ans==1e16) puts("-1");
    else printf("%lld\n",min(abs(tmp)+1,abs(ans)));
    return 0;
}