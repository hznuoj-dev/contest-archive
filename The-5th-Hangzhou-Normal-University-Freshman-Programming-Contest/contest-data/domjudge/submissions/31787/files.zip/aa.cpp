#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int ll
const int N=2e5+7,mod=1e9+7;
int n,m,b,a[N],dp[N],q[N];
void solve(){
	cin>>n>>m>>b;
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)q[i]=q[i-1]+a[i];
	for(int i=1;i<=n;i++){
		if(i-m>=0)dp[i]=max(dp[i-1],dp[i-m]+min(q[i]-dp[i-m],b));
		else dp[i]=min(q[i],b);
	}
	cout<<dp[n];
}
signed main(){
	int t=1;
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cin>>t;
	while(t--)solve();
	return 0;
}
