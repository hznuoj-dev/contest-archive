#include <iostream>
#include <algorithm>
using namespace std;

int main()
{
    double a[5], b[5];
    int m, k1;
    double mc = 0;
    double c = 0;
    double sa = 0;
    double sb = 0;
    cin >> m >> k1;
    for (int i = 0; i < 5; i++)
    {
        cin >> a[i];
    }
    for (int i = 0; i < 5; i++)
    {
        cin >> b[i];
    }
    for (int i = 0; i < 5; i++)
    {
        if (a[i] >= m)
        {
            c = b[i] / (a[i] - k1);
        }
        else
        {
            c = b[i] / a[i];
        }
        if (c > mc)
        {
            mc = c;
        }
    }
    for (int i = 0; i < 5 - 1; i++)
    {
        for (int j = i + 1; j < 5; j++)
        {
            sa = a[i] + a[j];
            sb = b[i] + b[j];
            if (sa >= m)
            {
                c = sb / (sa - k1);
            }
            else
            {
                c = sb / sa;
            }
            if (c > mc)
            {
                mc = c;
            }
        }
    }
    for (int i = 0; i < 5 - 2; i++)
    {
        for (int j = i + 1; j < 5 - 1; j++)
        {
            for (int k = j + 1; k < 5; k++)
            {
                sa = a[i] + a[j] + a[k];
                sb = b[i] + b[j] + b[k];
                if (sa >= m)
                {
                    c = sb / (sa - k1);
                }
                else
                {
                    c = sb / sa;
                }
                if (c > mc)
                {
                    mc = c;
                }
            }
        }
    }
    for (int i = 0; i < 5 - 3; i++)
    {
        for (int j = i + 1; j < 5 - 2; j++)
        {
            for (int k = j + 1; k < 5 - 1; k++)
            {
                for (int z = k + 1; z < 5; z++)
                {
                    sa = a[i] + a[j] + a[k] + a[z];
                    sb = b[i] + b[j] + b[k] + b[z];
                    if (sa >= m)
                    {
                        c = sb / (sa - k1);
                    }
                    else
                    {
                        c = sb / sa;
                    }
                    if (c > mc)
                    {
                        mc = c;
                    }
                }
            }
        }
    }
    sa = a[0] + a[1] + a[2] + a[3] + a[4] + a[5];
    sb = b[0] + b[1] + b[2] + b[3] + b[4] + b[5];
    if (sa >= m)
    {
        c = sb / (sa - k1);
    }
    else
    {
        c = sb / sa;
    }
    if (c > mc)
    {
        mc = c;
    }
    printf("%.2f", mc);
    return 0;
}