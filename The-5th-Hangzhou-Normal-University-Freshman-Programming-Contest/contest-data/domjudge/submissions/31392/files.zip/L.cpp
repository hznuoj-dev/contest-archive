#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int dp[55555]={0},a[404],b[404];
int s=0;
double son,mother,ans;
int main() {
	int m,k;
	scanf("%d%d",&m,&k);
	for(int i=1;i<=5;i++)scanf("%d",a+i),s+=a[i];
	for(int i=1;i<=5;i++) {
		scanf("%d",b+i);
		for(int j=s;j>=a[i];j--)dp[j]=max(dp[j],dp[j-a[i]]+b[i]);
	}
	for(int j=1;j<=s;j++) {
		mother=j-j/m*k,son=dp[j];
		ans=max(ans,son/mother);
	}
	printf("%.2f",ans);
}