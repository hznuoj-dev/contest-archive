#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N=2e5+7,MOD=1e9+7;
ll n,m,b,dp[N];

void solve(){
	cin>>n>>m>>b;
	ll sum=0;
	for(int i=1;i<=n;i++){
		ll a;
		cin>>a;
		sum+=a;
		dp[i]=dp[i-1];
		if(i<=m) dp[i]=max(dp[i],min(sum,b));
		else dp[i]=max(dp[i],dp[i-m]+min(sum-dp[i-m],b));
	}
	cout<<dp[n]<<'\n';
}

int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc=1;
//	cin>>tc;
	while(tc--) solve();
	return 0;
}
/*
5 2 10
5 9 3 1 8

6 2 10
20 1 1 1 1 5

*/
