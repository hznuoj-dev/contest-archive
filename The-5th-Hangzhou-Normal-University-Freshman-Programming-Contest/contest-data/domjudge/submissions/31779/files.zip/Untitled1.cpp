#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
#define ll long long 
#define ull undigned long long
#define int ll
const int N=2e5+10;
int a[N];
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
    int n;
    cin>>n;
    map<int,int>mp;
    int num=0;
    int jilu=-1;
    for(int i=1;i<=n;i++)
    {
    	cin>>a[i];
    	mp[a[i]]++;
	}
	int flag=0;
    for(auto[x,y]:mp)
    {
    	num+=y;
        if(n%2==0)
        {
        	if(num==n/2)
        	{
        		jilu=x;
        		flag=1;
        		break;
			}
			else if(num>n/2)
			{
				jilu=x;
				flag=2;
				break;
			}
		}
		else
		{
			if(num>n/2)
			{
				jilu=x;
				flag=3;
					break;
			}
		}
	}
	if(flag==1)
	{
		for(auto p=mp.begin();p!=mp.end();p++)
		{
			if((*p).first==jilu)
			{
				if(p!=--mp.end())
				cout<<((*(++p)).first)-(*(--p)).first-1;
				else
				cout<<0;
			}
		}
	}
	if(flag==2)
	{
		cout<<1;
	}
	if(flag==3)
	{
		cout<<1;
	}
}