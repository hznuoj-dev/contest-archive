#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll ans = 0;
const int N = 200010, M = 400010;
int head[N], ne[M], ver[M], w[M], tot;
ll res[N];
void add(int x, int y, int z) {
	ver[++tot] = y, w[tot] = z, ne[tot] = head[x], head[x] = tot;
}
void dfs(int x, int fa, ll num) {
	for (int i = head[x]; i; i = ne[i]) {
		int y = ver[i];
		if (y == fa) continue;
		res[y] = w[i] xor num;
		ans ^= res[y];
		dfs(y, x, res[y]);
	}
}
int main () {
	int n;
	cin >> n;
	int pos, q;
	for (int i = 1; i < n; i++) {
		int x, y, z;
		cin >> x >> y >> z;
		add(x, y, z), add(y, x, z);
		pos = x;
	}
	dfs(pos, 0, 0);
	res[pos] = 0;
	cin >> q;
	while (q--) {
		int x, y;
		cin >> x >> y;
		if (n % 2 == 0) cout << ans << endl;
		else cout << (ans ^ res[x] ^ y) << endl;
	}
}
