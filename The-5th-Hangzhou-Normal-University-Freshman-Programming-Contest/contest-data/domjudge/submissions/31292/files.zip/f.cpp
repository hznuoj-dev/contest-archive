#include <bits/stdc++.h>
#define fp(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fb(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define go(u, i) for(int i = head[u]; i; i = e[i].nxt)
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
inline int rd() {
	register int x(0), f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline LL RD() {
	register LL x(0); register int f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline int int_rand(int l, int r){
	int res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
inline LL LL_rand(LL l, LL r){
	LL res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
const int maxn = 200010;
int n, m, f[maxn], g[maxn], siz[maxn];
struct edge{int to, w, nxt;}e[maxn<<1];
int head[maxn], k;
inline void add(int u, int v, int w){e[++k] = {v, w, head[u]}, head[u] = k;}
void dfs(int u, int pre){
	siz[u] = 1;
	go(u, i)if(e[i].to != pre){
		dfs(e[i].to, u), siz[u] += siz[e[i].to];
		if(siz[e[i].to]&1)f[u] ^= e[i].w^f[e[i].to];
		else f[u] ^= f[e[i].to];
	}
}
void dfs2(int u, int pre){
	go(u, i)if(e[i].to != pre){
		int res = siz[e[i].to]&1 ? g[u]^e[i].w^f[e[i].to] : g[u]^f[e[i].to];
		if(n-siz[e[i].to]&1)g[e[i].to] = f[e[i].to]^res^e[i].w;
		else g[e[i].to] = f[e[i].to]^res;
		dfs2(e[i].to, u);
	}
}
int main(){
//	freopen("a.in", "r", stdin);
//	freopen("a.out", "w", stdout);
	n = rd();
	fp(i, 2, n){
		int u = rd(), v = rd(), w = rd();
		add(u, v, w), add(v, u, w);
	}
	dfs(1, 0), g[1] = f[1], dfs2(1, 0), m = rd();
	while(m--){
		int u = rd(), v = rd();
		printf("%d\n", n&1 ? g[u]^v : g[u]);
	}
	return 0;
}
