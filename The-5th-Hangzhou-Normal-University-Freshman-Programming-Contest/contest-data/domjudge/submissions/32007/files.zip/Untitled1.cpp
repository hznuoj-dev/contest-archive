#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=2e5+10;
int n,a[maxn];
int main(){
	cin>>n;
	for(int i=1;i<=n;i++)	
		cin>>a[i];
	sort(a+1,a+1+n);
	int num1=a[n/2];
	int num2=a[n/2+1];
	int ans=0;
	if(num1==num2)	ans=1;
	else 	ans=abs(num1-num2)-1;
	cout<<ans;	
}