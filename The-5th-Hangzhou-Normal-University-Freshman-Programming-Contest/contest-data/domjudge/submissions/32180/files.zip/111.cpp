#include<iostream>
using namespace std;
int main()
{
    int n;
    int numa = 0, numb = 0, numc = 0;
    cin >> n;
    long long a[200001], b[200001], c[200001];
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    for (int i = 1; i <= n; i++)
    {
        cin >> b[i];
        long long x = b[i];
        c[i] = -x;
    }
    for (int i = 1; i <= n; i++)//确定小于零个数
    {
        if (a[i] < 0)
            numa++;
        if (b[i] < 0)
            numb++;
        if (c[i] < 0)
            numc++;
    }
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n - i; j++)
        {
            if (a[j] > a[j + 1])
            {
                long long temp1 = a[j];
                a[j] = a[j + 1];
                a[j + 1] = temp1;
            }
            if (b[j] > b[j + 1])
            {
                long long temp2 = b[j];
                b[j] = b[j + 1];
                b[j + 1] = temp2;
            }
            if (c[j] > c[j + 1])
            {
                long long temp3 = c[j];
                c[j] = c[j + 1];
                c[j + 1] = temp3;
            }
        }
    }
    if (numa > 0)
        for (int i = 1; i <= numa; i++)
        {
            for (int j = 1; j <= numa - i; j++)
            {
                if (a[j] < a[j + 1])
                {
                    long long temp1 = a[j];
                    a[j] = a[j + 1];
                    a[j + 1] = temp1;
                }
            }
        }
    if (numb > 0)
        for (int i = 1; i <= numb; i++)
        {
            for (int j = 1; j <= numb - i; j++)
            {
                if (b[j] < b[j + 1])
                {
                    long long temp1 = b[j];
                    b[j] = b[j + 1];
                    b[j + 1] = temp1;
                }
            }
        }
    if (numc > 0)
        for (int i = 1; i <= numc; i++)
        {
            for (int j = 1; j <= numc - i; j++)
            {
                if (c[j] < c[j + 1])
                {
                    long long temp1 = c[j];
                    c[j] = c[j + 1];
                    c[j + 1] = temp1;
                }
            }
        }
    int a1 = a[1], b1 = b[1], c1 = c[1];
    for (int i = 1; i <= n; i++)
    {
        int a2 = a[i], b2 = b[i], c2 = c[i];
        if (a1 - b1 != a2 - b2 && a1 - c1 != a2 - c2)
        {
            cout << -1;
            return 0;
        }
    }
    if (numb == numc)
    {
        cout << min(abs(a1 - b1), abs(a1 - c1) + 1);

    }
    else
    {
        if (numa == numb)
        {
            cout << abs(a1 - b1);
        }
        if (numa == numc)
        {
            cout << abs(a1 - c1) + 1;
        }
    }
    return 0;
}

