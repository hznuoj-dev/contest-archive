#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll maxn = 2e5 + 10;
const ll minn = 1e9 + 7;
const double eps = 1e-6;
const int INFTY = (1<<21);

int gcd(int a, int b) {return b ? gcd(b, a % b) : a;}
int lcm(int a, int b) {return a * b / gcd(a, b);}

ll n;
ll a[maxn],b[maxn],c[maxn],d[maxn];

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cin>>n;
    for(ll i=1;i<=n;i++)
    {
        std::cin>>a[i];
        c[i]=-a[i];
    }
    for(ll i=1;i<=n;i++)
    {
        std::cin>>b[i];
        d[i]=-b[i];
    }
    sort(a+1,a+1+n);
    sort(b+1,b+1+n);
    sort(c+1,c+1+n);
    sort(d+1,d+1+n);
    int f1=0,f2=0,f3=0,f4=0,ans=0;
    ll num=-1;
    for(ll i=2;i<=n;i++)
    {
        if(a[i]-b[i]!=a[1]-b[1])
        {
            f1=1;
            break;
        }
    }
    if(f1!=1)
    {
        num=abs(a[1]-b[1]);
    }
    for(ll i=2;i<=n;i++)
    {
        if(a[i]-d[i]!=a[1]-d[1])
        {
            f2=1;
            break;
        }
    }
    if(f2!=1)
    {
        if(num!=-1)
        {
            num=min(num,abs(a[1]-d[1])+1);
        }
        else 
        {
            num=abs(a[1]-d[1])+1;
        }
    }
    for(ll i=2;i<=n;i++)
    {
        if(c[i]-d[i]!=c[1]-d[1])
        {
            f3=1;
            break;
        }
    }
    if(f3!=1)
    {
        if(num!=-1)
        {
            num=min(num,abs(c[1]-d[1])+2);
        }
        else 
        {
            num=abs(c[1]-d[1])+2;
        }
    }
    for(ll i=2;i<=n;i++)
    {
        if(c[i]-b[i]!=c[1]-b[1])
        {
            f4=1;
            break;
        }
    }
    if(f4!=1)
    {
        if(num!=-1)
        {
            num=min(num,abs(c[1]-b[1])+1);
        }
        else 
        {
            num=abs(c[1]-b[1])+1;
        }
    }
    if(num!=-1)
    {
        std::cout<<num<<endl;
    }
    else 
    {
        std::cout<<"-1"<<endl;
    }
    return 0;
}