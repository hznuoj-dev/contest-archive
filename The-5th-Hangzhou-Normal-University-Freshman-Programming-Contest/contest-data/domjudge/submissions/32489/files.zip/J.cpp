#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int long long
#define fu(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fd(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define PRN(X) cout << #X << "=" << X << endl
#define PR(X) cout << #X << "=" << X << " "

const int N = 2e5 + 5;

int read(){
	int f = 1, x = 0; char ch = getchar();
	while(ch > '9' || ch < '0'){ 	if(ch == '-')f = -1; ch = getchar(); }
	while(ch <= '9' && ch >= '0'){ x = (x << 1) + (x << 3) + (ch ^ 48);  ch = getchar(); }
	return x * f;
}

ll fast_power(ll a, ll b, ll p) {
	ll ans = 1;
	a %= p;
	while (b) {
		if (b & 1)ans = (ans * a) % p;
		a = (a * a) % p;
		b >>= 1;
	}
	return ans;
}
const int P = 1e9 + 7;
vector<int> G[N];
int deg[N], f[N], cnt[N];
void solve(){
	int n = read(), m = read(), k = read();
	
	fu(i, 1, m) {
		int u = read(), v = read();
		G[u].push_back(v);
		++ deg[v];
	}

	queue<int> que;	
	fu(i, 1, n) if(!deg[i]) que.push(i);
	
	while(!que.empty()) {
		int u = que.front(); que.pop();
		
		for(auto v: G[u]) {
			f[v] = max(f[v], f[u] + 1);
			--deg[v];
			if(!deg[v]) que.push(v);
		}
	}
	fu(i, 1, n) cnt[f[i]] += 1;
	int sum = 0, ans = 0;
	fd(i, n, 0) ans = (ans + sum * cnt[i]) % P, sum += cnt[i], sum %= P;
	ans = fast_power(ans, k, P);
	printf("%lld\n", ans);
}

signed main(){
	int t = 1;
	while(t--){
		solve();
	}
}


