#include<stdio.h>
int main()
{
	int m, k, i, price = 0, etill = 0;
	double xjb;
	scanf("%d %d", &m, &k);
	int a[5], b[5];
	for (i = 1; i <= 5; i++) {
		scanf("%d", &a[i]);
	}
	for (i = 1; i <= 5; i++) {
		scanf("%d", &b[i]);
	}
	
	for (i = 1; i <= 5; i++) {
		if (b[i] / a[i] >= 1) {
			price += a[i];
			etill += b[i];
		}
	}
	if (price >= m) {
		price -= k;
	}
	xjb = etill / price;
	printf("%.2lf", xjb);
	return 0;
}
