#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
double a[maxn],b[maxn],m,k,ans=0.0;
void dfs(int pos,double sum1,double sum2){
	if(pos>5) return;
	//printf("%d %f %f\n",pos,sum1,sum2);
	if(sum1>=m){
		double res=sum2/(sum1-k);
		ans=max(ans,res);
	}
	else{
		double res=sum2/sum1;
		ans=max(ans,res);
	}
	dfs(pos+1,sum1+a[pos+1],sum2+b[pos+1]);
	dfs(pos+1,sum1,sum2);
}
void solve(){
	scanf("%lf%lf",&m,&k);
	for(int i=1;i<=5;i++) scanf("%lf",&a[i]);
	for(int i=1;i<=5;i++) scanf("%lf",&b[i]);
	dfs(0,0,0);
	printf("%.2f\n",ans);
}
int main(){
	ios::sync_with_stdio(false);
	int T=1;
	//cin>>T;
	while(T--) solve();
}

/*

5 3
1 2 4 4 2
2 2 1 2 4

*/
