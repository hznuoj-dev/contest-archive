#include <bits/stdc++.h>
using namespace std;
#define fastio ios::sync_with_stdio(false);cin.tie(0); cout.tie(0)
typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e6 + 5;

ll read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){
        if(c=='-')f=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9'){
        x=(x<<3)+(x<<1)+(c^48);
        c=getchar();
    }
    return x;
}

ll a[200001],b[200001];

signed main(){
    fastio;
    int n,h=0;
    ll su1=0,su2=0,su3,c=0;
    n=read();
    for(int i=0;i<n;i++)cin>>a[i],su1+=a[i];
    for(int i=0;i<n;i++)cin>>b[i],su2+=b[i];
    if(su1>0&&su2<0||su1<0&&su2>0){h=1;};
    if(h==1){
        su3=abs(su1+su2);
        c=1;
    }
    else {
        su3=abs(su1-su2);
    }
    if(su3%n!=0){
        printf("-1");
        system("pause");
        return 0;
    }
    else {
        printf("%lld",(su3/n+c));
        system("pause");
        return 0;
    }
}