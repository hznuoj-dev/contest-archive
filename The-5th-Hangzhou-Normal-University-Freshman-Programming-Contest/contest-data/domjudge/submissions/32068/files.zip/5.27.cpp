#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
const int N = 2 * 1e5 + 100;
int a[N], b[N];
int main()
{
    int n;
    cin >> n;
    int i, j, k, l, res = 0;
    for(i = 0; i < n; i++)
        cin >> a[i];
    for(i = 0; i < n; i++)
        cin >> b[i];
    sort(a, a + n);
    sort(b, b + n);
    // for(i = 0; i < n; i++)
    //     cout << a[i] << endl;
    // for(i = 0; i < n; i++)
    //     cout << b[i] << endl;
    //cout << abs(a[0] + b[n - 1]) << endl;
    if (abs(a[0] - b[0]) < abs(a[0] + b[n - 1]) + 1)
    {
        //cout << 1 << endl;
        res = abs(a[0] - b[0]);
        k = abs(a[0] - b[0]);
        i = 1;
        while(i < n)
        {
            if (abs(a[i] - a[i - 1]) != abs(b[i] - b[i - 1]))
            {
                cout << -1 << endl;
                return 0;
            }
            i++;
        }
        cout << res << endl;
    }
    else
    {
        res = abs(a[0] + b[n - 1]) + 1;
        k = abs(a[0] + b[n - 1]);
        i = 1;
        while(i < n)
        {
            //cout << a[i] << '-' << a[i - 1] << "==" << b[i] << '-' << b[i - 1] << endl;
            if (abs(a[i] - a[i - 1]) != abs(b[i] - b[i - 1]))
            {
                cout << -1 << endl;
                return 0;
            }
            i++;
        }
        cout << res << endl;
    }

}