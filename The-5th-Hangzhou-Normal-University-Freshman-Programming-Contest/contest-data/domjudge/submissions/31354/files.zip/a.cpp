#include<iostream>
using namespace std;
#include<algorithm>

//A
const int N=2e5+7;
int buk[N];
int a[N];
int n;

//����������Ӧ������������һ�� 

bool check(int k){
	int num=0;
	for(int i=1;i<=n;i++){
		if(a[i]>k)num--;
		else if(a[i]<k)num++;
		if(num<0)return false;
	}
	if(num>0)return false;
	return true;
}

int cmp(int&a,int&b){return a<b;}

int main(){
	
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		buk[i]=a[i];
	}
	sort(buk+1,buk+1+n,cmp);
//	for(int i=1;i<N;i++)buk[i]+=buk[i-1];
	int k,num;
	if(n&1){
		k=buk[n/2+1];
		num=1;
	}else{
		int l=buk[n/2],r=buk[n/2+1];
		if(l==r){
			k=buk[n/2];
			num=1;
		}else if(l+1==r){
			num=1;
			if(check(l))num++;
			if(check(r))num++;
			cout<<num<<endl;
			return 0;
		}else if(l+1<r){
			k=l+1;
			num=r-l-1;
		}
	}
	if(check(k))cout<<num<<endl;
	else cout<<0<<endl;
}













