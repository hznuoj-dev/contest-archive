#include<bits/stdc++.h>
using namespace std;
const int M=2e5+5;
const long long inf=1e18;
int A[M],B[M],n;
int d[M];
long long solve(){
	sort(A+1,A+1+n);
	sort(B+1,B+1+n);
	long long res=0;
	d[0]=A[1]-B[1]; 
	for(int i=1;i<=n;i++){
		d[i]=A[i]-B[i];
		if(d[i]!=d[0])return inf;
		//res+=abs(d[i]);
	}
	return abs(d[0]);
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&A[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&B[i]);
	}
	long long ans=inf;
	ans=min(ans,solve());
	for(int i=1;i<=n;i++)A[i]=-A[i];
	ans=min(ans,solve()+1);
	if(ans>=inf)printf("-1\n");
	else printf("%lld\n",ans);
	return 0;
}
