#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main() {
	ll x,s=0,k;
	ll n,m,b;
	cin>>n>>m>>b;
	if(n%2) {
		ll s1=0,s2=0;
		ll l1=0,l2=0;
		for(int i=1;i<=n;i++) {
			cin>>x;
			l1+=x,l2+=x;
			if(i%2) {
				k=min(l1,b);
				l1-=k,s1+=k;
			} else {
				k=min(l2,b);
				l2-=k,s2+=k;
			}
		}
		s=max(s1,s2);
	} else {
		ll l=0;
		for(int i=1;i<=n;i++) {
			cin>>x;
			l+=x;
			if(i%2==0) {
				k=min(l,b);
				l-=k,s+=k;
			}
		}
	}
	cout<<s;
}