#include <iostream>
#include <algorithm>
#include <cmath>
#include <iomanip>
using namespace std;
int main(void){
	double ans=-1;
	int m,k;
	double a[10],b[10];
	cin>>m>>k;
	double sn=0,ss=0;
	for(int i=1;i<=5;i++){
		cin>>a[i];
		sn+=a[i];
	}
	for(int i=1;i<=5;i++){
		cin>>b[i];
		ss+=b[i];
	}
	for(int i=1;i<=5;i++){
		double temp=b[i]/a[i];
		if(a[i]>=m){
			temp=b[i]/(a[i]-k);
		}
		ans=max(ans,temp);
	}
	for(int i=1;i<5;i++){
		for(int j=i+1;j<=5;j++){
			double n=a[i]+a[j],s=b[i]+b[j];
			if(n>=m){
				n-=k;
			}
			ans=max(ans,s/n);
		}
	}
	for(int i=1;i<4;i++){
		for(int j=i+1;j<5;j++){
			for(int o=j+1;o<=5;o++){
				double n=a[i]+a[j]+a[o],s=b[i]+b[j]+b[o];
				if(n>=m){
					n-=k;
				}
				ans=max(ans,s/n);
			}
		}
	}
	for(int i=1;i<=5;i++){
		double n=sn-a[i],s=ss-b[i];
		if(n>=m){
			n-=k;
		}
		ans=max(ans,s/n);
	}
	if(sn>=m){
		sn-=k;
	}
	ans=max(ans,ss/sn);
	cout<<fixed<<setprecision(2)<<ans;
	return 0;
}