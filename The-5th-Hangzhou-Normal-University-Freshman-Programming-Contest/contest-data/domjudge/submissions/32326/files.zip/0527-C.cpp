#include<bits/stdc++.h>
#define close std::ios::sync_with_stido(flase),cin.tie(0),cout.tie(0);
using namespace std;
typedef long long ll;
const ll MAXN = 3e5+7;
void solve(){
	int n;cin>>n;
	//1 7 5  （2 3 5
	int cnt5=0;
	if(n<=10||n==11){
		cout<<"No Solution\n";
	}
	else if(n%2==0){//a=a
		n-=2;
		n/=2;
		if(n%5==1){
			cnt5=n/5;
			cnt5--;
			for(int i=0;i<cnt5;i++) cout<<5;
			cout<<"9=";
			for(int i=0;i<cnt5;i++) cout<<5;
			cout<<"0\n";
			for(int i=0;i<cnt5;i++) cout<<5;
			cout<<"9=";
			for(int i=0;i<cnt5;i++) cout<<5;
			cout<<"9\n";
		}
		else if(n%5==2){
			cnt5=n/5;
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"1=";
			for(int i=0;i<cnt5-1;i++) cout<<5;cout<<"31\n";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"1=";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"1\n";
		}
		else if(n%5==3){
			cnt5=n/5;
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"7=";
			for(int i=0;i<cnt5-1;i++) cout<<5;cout<<"37\n";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"7=";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"7\n";
		}
		else if(n%5==4){
			cnt5=n/5;
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"4=";
			for(int i=0;i<cnt5-1;i++) cout<<5;cout<<"34\n";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"4=";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"4\n";
		}
		else if(n%5==0){
			cnt5=n/5;
			for(int i=0;i<cnt5;i++) cout<<"17";
			cout<<"=";
			for(int i=0;i<cnt5-1;i++) cout<<"17";
		     cout<<"71";
			cout<<"\n";
			for(int i=0;i<cnt5;i++) cout<<"17";
			cout<<"=";
			for(int i=0;i<cnt5;i++) cout<<"17";
			cout<<"\n";
		}
	}
	else{//a-a=0
		n-=9;
		n/=2;
		if(n%5==0){
			cnt5=n/5;
			for(int i=0;i<cnt5;i++) cout<<"17";
			cout<<"-";
			for(int i=0;i<cnt5;i++) cout<<"17";
			cout<<"=9\n";
			for(int i=0;i<cnt5;i++) cout<<"17";
			cout<<"-";
			for(int i=0;i<cnt5;i++) cout<<"17";
			cout<<"=0\n";
		}
		else if(n%5==1){
			cnt5=n/5;
			cnt5--;
			for(int i=0;i<cnt5;i++) cout<<5;
			cout<<"9-";
			for(int i=0;i<cnt5;i++) cout<<5;
			cout<<"9=9\n";
			for(int i=0;i<cnt5;i++) cout<<5;
			cout<<"9-";
			for(int i=0;i<cnt5;i++) cout<<5;
			cout<<"9=0\n";
		}
		else if(n%5==2){
			cnt5=n/5;
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"1-";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"1=9\n";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"1-";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"1=0\n";
		}
		else if(n%5==3){
			cnt5=n/5;
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"7-";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"7=9\n";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"7-";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"7=0\n";
		}
		else if(n%5==4){
			cnt5=n/5;
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"4-";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"4=9\n";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"4-";
			for(int i=0;i<cnt5;i++) cout<<5;cout<<"4=0\n";
		}
	}
}
signed main(){
	int t;cin>>t;
	while(t--)
	solve();
}