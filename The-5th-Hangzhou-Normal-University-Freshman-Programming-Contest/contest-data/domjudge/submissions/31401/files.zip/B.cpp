#include <bits/stdc++.h>
using namespace std;
const int N = 200005;
int a[N], b[N], del[N];
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n, cost = 0, flag = 1;
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for(int i = 1; i <= n; i++) {
		cin >> b[i];
	}
	sort(a + 1, a + 1 + n);
	sort(b + 1, b + 1 + n);
	for(int i = 1; i <= n; i++) {
		if(a[i] < 0 && b[i] > 0) {
			a[i] = abs(a[i]);
			cost++;
		} else if(a[i] > 0 && b[i] < 0) {
			b[i] = abs(b[i]);
			cost++;
		}
	}
	for(int i = 1; i <= n; i++) {
		del[i] = b[i] - a[i];
	}
	for(int i = 2; i <= n; i++) {
		if(del[i - 1] != del[i]) {
			flag = 0;
			break;
		}
	}
	if(!flag) {
		cout << "-1\n";
	} else {
		cost += del[1];
		cout << cost << "\n";
	}
	return 0;
}
