#include<bits/stdc++.h>
using namespace std;

int numsa[200000+10];
int numsb[200000+10];
signed main () {
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> numsa[i];
	}
	for (int i = 1; i <= n; i++) {
		cin >> numsb[i];
	}
	sort (numsa + 1, numsa + n + 1);
	sort (numsb + 1, numsb + n + 1);
	int flag = numsa[1] - numsb[1];
	for (int i = 2; i <= n; i++) {
		if (flag != numsa[i] - numsb[i]) {
			cout << "-1";
			return 0;
		}
	}
	cout << abs(flag);
	return 0;
}
// 1 2 3 4
// 1 2 4 5
// 4 10 5 10
// 1 4 4 10
// min = 1
// max = 10
