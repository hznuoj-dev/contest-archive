#include <iostream>
#include <algorithm>
#include <iomanip>
#include <cmath>
using namespace std;
const int N=2e5+10;
typedef long long ll;
const ll NN=1e16;
ll a[N],b[N];
int cmp(int x,int y){
	return x>y;
}
int main(void){
	int n;
	ll ans=1e17;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		cin>>b[i];
	}
	sort(b+1,b+1+n);
	sort(a+1,a+1+n,cmp);
	int f=1;
	for(int i=1;i<=n;i++){
		if(a[i]!=-b[i]){
			f=0;
			break;
		}
	}
	sort(a+1,a+1+n);
	if(f==0){
		f=1;
		for(int i=1;i<=n;i++){
			if(a[i]!=-b[i]){
				f=0;
				break;
			}
		}
	}
	if(f){
		ans=1;
	}
	if(ans>NN){
		ll fx=1,fy=1;
		for(int i=1;i<n;i++){
			if(a[i]-b[i]!=a[i+1]-b[i+1]){
				fx=0;
				break;
			}
		}
		for(int i=1;i<n;i++){
			if(-a[i]-b[i]!=-a[i+1]-b[i+1]){
				fy=0;
				break;
			}
		}
		if(fx&&fy){
			ans=min(abs(a[1]-b[1]),abs(-a[1]-b[1]));
		} else if(fx==1&&fy==0){
			ans=abs(a[1]-b[1]);
		} else if(fx==0&&fy==1){
			ans=abs(-a[1]-b[1]);
		} else {
			ans=-1;
		}
	}
	if(ans==1){
		int fl=1;
		for(int i=1;i<=n;i++){
			if(a[i]!=b[i]){
				fl=0;
				break;
			}
		}
		if(fl){
			ans=0;
		}
	}
	cout<<ans;
	return 0;
}