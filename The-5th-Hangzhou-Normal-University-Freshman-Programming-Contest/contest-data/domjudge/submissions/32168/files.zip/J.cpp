﻿#include<bits/stdc++.h>
using namespace std;
const int N=2e5+9,mod=1e9+7;
#define PII pair<int,int>
int n,m,k,fac[N],inv[N];
int ver[N<<2],nxt[N<<2],h[N],tot;
int Q[N],in[N],a[N],hh=0,tt=-1;
map<PII,int> Map;
bool vis[N];

inline void add(int x,int y)
{
    ver[++tot]=y,nxt[tot]=h[x],h[x]=tot;
}

inline void Init()
{
    fac[1]=inv[1]=inv[0]=fac[0]=1;
    for(int i=1;i<=n;i++) fac[i]=1ll*fac[i-1]*i%mod;
    for(int i=2;i<=n;i++) inv[i]=1ll*(mod-mod/i)*inv[mod%i]%mod;
    for(int i=2;i<=n;i++) inv[i]=1ll*inv[i]*inv[i-1]%mod;
}

inline int C(int n,int m){return 1ll*fac[n]*inv[m]%mod*inv[n-m]%mod;}

inline int poww(int x,int k)
{
    int res=1;
    while(k)
    {
        if(k&1) res=1ll*x*res%mod;
        x=1ll*x*x%mod;
        k>>=1;
    }
    return res;
}

inline void topo()
{
    memset(vis,0,sizeof vis);
    hh=0,tt=-1;
    for(int i=1;i<=n;i++)
        if(!in[i]) Q[++tt]=i,vis[i]=true;
    while(hh<=tt)
    {
        int u=Q[hh++];
        for(int i=h[u];i;i=nxt[i])
        {
            int v=ver[i];
            in[v]--;
            a[v]=max(a[v],a[u]+1);
            if(!in[v]) 
                Q[++tt]=v,vis[v]=true;
        }
    }
}

int main()
{
    scanf("%d%d%d",&n,&m,&k);
    Init();
    for(int i=1;i<=m;i++)
    {
        int x,y;
        scanf("%d%d",&x,&y);
        if(Map[{x,y}]) continue;
        Map[{x,y}]=1;
        add(x,y);
        in[y]++;
    }
    topo();
    sort(a+1,a+1+n);
    int ans=0;
    for(int i=2;i<=n;i++)
    {
        int p=lower_bound(a+1,a+1+n,a[i])-a-1;
        ans=(ans+p)%mod;
    }
    printf("%d",poww(ans,k));
    return 0;
}