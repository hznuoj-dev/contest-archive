#include<bits/stdc++.h>
using namespace std;
int a[200005],b[200005];
void slove(){
	int n;
	cin>>n;
	
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b+1,b+n+1);
	
	
	if(n%2==1){
		int k=b[n/2+1],v=0;
		for(int i=1;i<=n;i++){
			if(a[i]<k) v++;
			else if(a[i]>k) v--;
			if(v<0){
				cout<<0<<endl;
				return;
			}
		}
		if(v==0) cout<<1<<endl;
		else cout<<0<<endl;
	}
	else{
		if(b[n/2]==b[n/2+1]){
			int k=b[n/2+1],v=0;
		for(int i=1;i<=n;i++){
			if(a[i]<k) v++;
			else if(a[i]>k) v--;
			if(v<0){
				cout<<0<<endl;
				return;
			}
		}
		if(v==0) cout<<1<<endl;
		else cout<<0<<endl;
		}
		else{
			int minn=b[n/2]+1;
			int maxx=b[n/2+1]-1;
			int v=0,ans=0,f=0,op=0;
			for(int i=1;i<=n;i++){
				if(a[i]<minn){
					v++;
				}
				else if(a[i]>maxx){
					v--;
				}
				if(v<0){
					cout<<0<<endl;
					return;
				}
			}
			if(v==0){
				ans=maxx-minn+1;
				for(int i=1;i<=n;i++){
					if(a[i]<minn-1) f++;
					else if(a[i]>maxx+1) f--;
					if(f<0){
						op=1;
					}
				}
				if(op==0&&f==0) ans+=2;
				cout<<ans<<endl;;
			}
			else cout<<0<<endl;
		}
	}
	return;
}
int main(){
	int T=1;
//	cin>>T;
	while(T--){
		slove();
	}
	
	return 0;
} 
