#include <bits/stdc++.h>
using namespace std;
const int N=200005;
int a[N],b[N];
//#define int long long
int main() {
	std::ios::sync_with_stdio(false);
    std::cin.tie(0);std::cout.tie(0);
	int n;
	cin>>n;
	for(int i=0;i<n;i++) cin>>a[i];
	for(int i=0;i<n;i++) cin>>b[i];
	sort(a,a+n);
	sort(b,b+n);
	int c1=a[0]-b[0],c2=a[0]+b[n-1],f1=0,f2=0;
	for(int i=1;i<n;i++){
		if(c1!=a[i]-b[i]){
			f1=1;break;
		}
	}
	for(int i=1;i<n;i++){
		if(c2!=a[i]+b[n-i-1]){
			f2=1;break;
		}
	}
	if(f1&&f2){
		cout<<-1;
	}
	else{
		if(!f1&&!f2){
			cout<<min(abs(a[0]+b[n-1])+1,abs(c1));
		}
		else if(!f1) cout<<abs(c1);
		else cout<<abs(a[0]+b[n-1])+1;
	}
  return 0;
}