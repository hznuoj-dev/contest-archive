#include<bits/stdc++.h>
#define rg register
#define il inline
typedef long long ll;
using namespace std;
ll mod = 1e9+7;
inline ll read() {
	ll ans = 0;
	char last = ' ', ch = getchar();
	while (ch < '0' || ch > '9') last = ch, ch = getchar();
	while (ch >= '0' && ch <= '9') ans = ans * 10 + ch - '0', ch = getchar();
	if (last == '-') return -ans;
	return ans;
}
il ll ksm(ll b,ll k){
	ll res=1;
	while(k){
		if(k&1) res=1ll*res*b%mod;
		b=1ll*b*b%mod;k>>=1;
	}
	return res;
}
int e[800040],ne[800040],h[800020],idx;
int chu[400040];
int ru[400040];
void add(int a,int b){
	e[idx]=b;
	ne[idx]=h[a];
	h[a]=idx++;
} 
map<pair<int,int>,int>mp;
int main(){
	memset(h,-1,sizeof h);
	int n,m,k;
	n=read();
	m=read();
	k=read();
	for(int i=1;i<=m;i++){
		int a,b;
		a=read();
		b=read();
		ru[b]++;
		chu[a]++;
		add(a,b);
	}
	queue<int>q;
	for(int i=1;i<=n;i++){
		if(ru[i]==0)q.push(i);
	}
	ll ans=0;
	while(!q.empty()){
		int tt=q.front();
		q.pop();
		for(int i=h[tt];~i;i=ne[i]){
			
			int j=e[i];
			if(!mp[{tt,j}])mp[{tt,j}]=1,ans++;
			ru[j]--;
			if(!ru[j])q.push(j);
			
		}
	}
	cout<<ksm(ans,k)<<endl;
}

