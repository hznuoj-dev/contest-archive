#include <iostream>
#include <algorithm>
#include <map>
using namespace std;
const int N = 2e5 + 10;
int a[N], b[N];
map<int, int> mp;
int n;

bool check(int x) {
    int sum = 0;
    for(int i = 1; i <= n; i++) {
        if(a[i] < x)    sum++;
        else if(a[i] > x)    sum--;
        if(sum < 0) return false;
    }
    return true;
}

int main()
{
    
    scanf("%d", &n);
    for(int i = 1; i <= n; i++) {
        scanf("%d", &a[i]);
        b[i] = a[i];
        mp[a[i]]++;
    }
    sort(b + 1, b + n + 1);
    int p = (n + 1) / 2, mid = b[p];
    // printf(":%d\n", mid);
    if(n & 1) {
        if(mp[mid] % 2 == 0 || !check(mid))    {
            printf("0");
        } else {
            printf("1");
        }
        return 0;
    } else {
        if(p + 1 <= n && b[p+1] > mid + 1) {
            if(check(mid + 1))  {
                printf("%d", b[p+1] - mid - 1);
            } else {
                printf("0");
            }
        } else {
            if(check(mid))  printf("1");
            else    printf("0");
        }
    }

    return 0;
}