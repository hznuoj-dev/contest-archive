#include <iostream>
#include <algorithm>
#include <cstring>
using namespace std;
int a[6], b[6], c[6], v[6];
int n, k;
double res = 0;
void dfs(int m)
{
    if (m == 0)
    {
        
        double cnt = 0, sum = 0;
        for(int i = 1; i <= 5; i++)
        {
            if (v[i] == 1)
                sum += a[i];
        }
        for(int i = 1; i <= 5; i++)
        {
            if (v[i] == 1)
                cnt += b[i];
        }
        if (sum >= n)
            sum -= k;
        res = max(res, cnt / (sum * 1.0));
        //cout << cnt << "==" << sum << endl;
        return;
    }
    for(int i = 1; i <= 5; i++)
    {
        if (v[i] == 1)
            continue;
        v[i] = 1;
        dfs(m - 1);
        v[i] = 0;
    }
}
int main()
{
    
    cin >> n >> k;
    int i, j, k, l;
    for(i = 1; i <= 5; i++) cin >> a[i];
    for(i = 1; i <= 5; i++) cin >> b[i];
    for(i = 1; i <= 5; i++)
    {
        memset(v, 0, sizeof(v));
        dfs(i);
    }
    printf("%.2lf\n", res);
    return 0;
}