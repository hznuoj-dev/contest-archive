#include <bits/stdc++.h>
#define ll long long
using namespace std;
ll dp[200010];
ll s[200010];
int a[200010];
inline int read() {
	int x = 0, f = 1;
	char c = getchar();
	while (c > '9' || c < '0') {
		if (c == '-') f = -1;
		c = getchar();
	}
	while (c >= '0' && c <= '9') {
		x = x * 10 + c - '0';
		c = getchar();
	}
	return x * f;
}
int main () {
	int n = read(), m = read(), k = read();
	vector<ll> v;
	for (int i = 1; i <= n; i++) a[i] = read();
	ll ans = 0;
	for (int i = 1; i <= n; i++) {
		s[i] = s[i - 1] + a[i];
		if (i < m + 1) dp[i] = s[i] >= k ? k : s[i];
		if (i >= m + 1) v.push_back(-dp[i - m]);
		if (i >= m + 1) {
			sort(v.begin(), v.end());
			int num;
			if (k - s[i] < v[0]) num = 0; 
			else num = lower_bound(v.begin(), v.end(), k - s[i]) - v.begin() - 1;
			dp[i] = -v[num] + k;
			dp[i] = min(dp[i], s[i]);
			ans = max(ans, dp[i]);
		}
	}
	printf("%lld", ans);
}
