#include<bits/stdc++.h>
using namespace std; 
const int N = 2e5+5;
int a[N],b[N],c[N];
int main()
{
	int n; cin >> n;
	vector<int>vec;
	int x,y;
	for(int i = 1;i <= n;i++) cin >> a[i];
	sort(a + 1, a + 1 + n);
	if(n % 2 == 0)
	{
		int maxx = a[n / 2],minn = a[n / 2 + 1];
		if(maxx != minn)
		{
			cout << minn - maxx - 1 << '\n';
		}else
		{
			int cntl = n / 2,cntr = n / 2 + 1;
			while(a[cntl] == a[n / 2]) cntl--;
			while(a[cntr] == a[n / 2]) cntr++;
			cntr = n - cntr + 1;
			if(cntl == cntr) puts("1");
			else puts("0");
		}
	}else
	{
		int mid = a[n / 2 + 1];
		int cntl = n / 2 + 1, cntr = n / 2 + 1;
		while(a[cntl] == a[n / 2 + 1]) cntl--;
		while(a[cntr] == a[n / 2 + 1]) cntr++;
		cntr = n - cntr + 1;
		if(cntl == cntr) puts("1");
		else puts("0");
	}
} 
