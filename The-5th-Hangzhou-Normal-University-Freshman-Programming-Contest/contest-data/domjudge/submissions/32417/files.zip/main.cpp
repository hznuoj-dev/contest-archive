#include <bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef long double ld;

#define dl <<"\n"
#define pub push_back
#define pob pop_back
#define pof pop_front
#define puf push_front
#define eps 1e-6
#define MAXX 1e5+1
#define IOS ios::sync_with_stdio(false), cin.tie(0), cout.tie(0)

//const ll INF = 0x3f3f3f3f3f3f3f3f;
const int inf = 0x3f3f3f3f, mod = 1000000007, rge1 = 1000100, rge2 = 10001;

//ll s[200001] = { 0 };

/*
double m = 0, k = 0;
double d = 0;

struct GOOD {
    double p;//price
    double c;//comment
    double r;//rate
};

GOOD g[5];

bool mc(GOOD x, GOOD y) {

    if (x.r != y.r) {

        if (x.r > y.r) {
            d += x.p;
        }
        else {
            d += y.p;
        }

        return x.r > y.r;
    }
    else {

        if (x.p >= (m - d)) {

            if (y.p < (m - d)) {
                d += x.p;
                return true;
            }
            else {

                if (x.p < y.p) {
                    d += x.p;
                }
                else {
                    d += y.p;
                }

                return x.p < y.p;
            }

        }
        else {

            if (y.p >= (m - d)) {
                d += y.p;
                return false;
            }
            else {

                if (x.p > y.p) {
                    d += x.p;
                }
                else {
                    d += y.p;
                }

                return x.p > y.p;
            }

        }
    
    }

}
*/

/*
ll p[200001][3] = { 0 };
ll Rank[200001] = { 0 };

void init(ll n) {
    for (ll i = 1; i <= n; ++i) {
        p[i][0] = i;
        p[i][2] = 0;
        cin >> p[i][1];
        p[i][1] %= 1000000007;
        Rank[i] = 1;
    }
}

ll Find(ll x) {
    return x == p[x][0] ? x : (p[x][0] = Find(p[x][0]));
}

void merge() {

    ll u = 0, v = 0;
    cin >> u >> v;

    ll x = Find(u), y = Find(v);

    if (Rank[x] <= Rank[y]) {
        p[x][0] = y;
    }
    else {
        p[y][0] = x;
    }

    if (Rank[x] == Rank[y] && x != y) {
        Rank[y]++;
    }

}

void up(ll n) {

    ll u = 0, v = 0;
    cin >> u >> v;

    ll dad = Find(u);

    for (ll i = 1; i <= n; i++) {
        if (dad == Find(i)) {
            p[i][1] += v;
        }
    }

}

ll sum[200001] = { 0 };

void everyeve(ll n) {

    for (ll i = 1; i <= n; i++) {
        sum[i] = 0;
    }

    for (ll i = 1; i <= n; i++) {
        
        ll dad = Find(i);
        sum[dad] += p[i][1];
        sum[dad] %= 1000000007;

    }

    for (ll i = 1; i <= n; i++) {

        ll dad = Find(i);

        p[i][2] += sum[dad];
        p[i][2] %= 1000000007;

    }

}

void ask() {
    ll u = 0;
    cin >> u;
    cout << p[u][2] dl;
}*/

ll a[200001] = { 0 };
ll b[200001] = { 0 };

void LolitaSama() {

    ll n = 0;
    cin >> n;

    if (n % 2 != 0) {
        cout << "0" dl;
        return;
    }

    for (int i = 0; i < n; i++) {
        cin >> a[i];
        b[i] = a[i];
    }

    sort(b, b + n);

    int cnt = 0;

    for (int i = b[n / 2 - 1]; i <= b[n / 2]; i++) {

        int op = 0;

        for (int j = 0; j < n; j++) {
            if (a[j] < i) op--;
            else if (a[j] > i) op++;
            if (op > 0) {
                op = -1;
                break;
            }
        }

        if (op == 0) {
            cnt++;
        }

    }

    cout << cnt dl;



    /*
    ll n = 0, q = 0;
    cin >> n >> q;

    init(n);

    int op = 0;

    while (q--) {

        everyeve(n);

        cin >> op;
        switch (op) {
        case 1:
            merge();
            //everyeve(n);
            break;
        case 2:
            up(n);
            //everyeve(n);
            break;
        case 3:
            ask();
            break;
        }

        //everyeve(n);
    }
    */

    /*
    L

    ll n = 0, k = 0;
    cin >> n >> k;

    ll c = 0;

    for (ll i = 1; i <= n; i++) {
        cin >> s[i];
        if (s[i] == i) c++;
    }

    if (n == k + 1) {
        cout << "-1" dl;
    }
    else {
        cout << (c + 1 - k) / 2 dl;
    }
    */

    /*
    cin >> m >> k;

    for (int i = 0; i < 5; i++) {
        cin >> g[i].p;
    }
    for (int i = 0; i < 5; i++) {
        cin >> g[i].c;
        g[i].r = g[i].c / g[i].p;
    }

    sort(g, g + 5, mc);

    double sump = 0;
    double sumc = 0;
    double rem = g[0].r;

    for (int i = 0; i < 5;i++) {

        sump += g[i].p;
        sumc += g[i].c;
        if (sump >= m) {
            cout << fixed << setprecision(2) << max((sumc) / (sump - k), rem) dl;
            return;
        }

    }

    cout << fixed << setprecision(2) << rem dl;
    */

    /*
    ll n = 0;
    cin >> n;

    if (n % 2 != 0) {
        cout << "0" dl;
        return;
    }

    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }

    int cnt = 0;

    for (int i = a[0]; i <= a[n - 1]; i++) {

        int op = 0;

        for (int j = 0; j < n; j++) {
            if (a[j] < i) op--;
            else if (a[j] > i) op++;
        }

        if (op == 0) {
            cnt++;
        }

    }

    cout << cnt dl;
    */

}

int main() {

    //IOS;

    int T = 1;
    //cin >> T;


    while (T--) {

        LolitaSama();

    }

}
