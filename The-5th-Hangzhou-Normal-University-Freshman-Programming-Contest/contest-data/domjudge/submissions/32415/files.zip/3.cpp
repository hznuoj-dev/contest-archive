#include<bits/stdc++.h>
using namespace std; 
const int N = 2e5+5;
typedef long long LL;
typedef pair<int,int> PII;
int n, a, b, c;
int h[N],e[2 * N],ne[2 * N],idx;
LL w[N], p[N], res = 0;
bool vt[N];

struct Node{
	int u, v;
	LL w;
} edg[N];

void add(int a, int b, int c) {
	e[idx] = b,w[idx] = c,ne[idx] = h[a],h[a] = idx++;
}

LL fig(LL a, LL k){
	int g[35],d[35],cnt = 0,dc = 0;
	memset(g, 0, sizeof g);
	while(a)g[++cnt] = a % 2, a /= 2;
	while(k)d[++dc] = k % 2, k /= 2;
	for(int i = 1; i <= dc; ++i)if(d[i])g[i] = abs(g[i] - 1);
	LL res = 0;
//	for(int i = 1; i <= max(cnt, dc); ++i)cout<<g[i];cout<<"\n";
	for(int i = 1; i <= max(cnt, dc); ++i)res += g[i]*pow(2, i - 1);
	return res;
}

void cc(int u){
	res ^= p[u];
//	cout<<u<<" "<<p[u]<<"\n";
	for(int i = h[u]; i != -1; i = ne[i]){
		LL t = e[i];
		if(vt[t])continue;
		vt[t] = true;
//		cout<<p[u]<<" "<<w[i]<<"\n";
		LL now = fig(p[u], w[i]);
//		cout<<now<<"\n";
		p[t] = now;
		cc(t);
	}
}

int main()
{
//	cout<<fig(0, 5)<<"\n";
	scanf("%d",&n);
	memset(h, -1, sizeof h);
	for(int i = 1; i < n; ++i)scanf("%d%d%d",&a,&b,&c),add(a,b,c),add(b,a,c);
//	for(int i = 1; i <= n; ++i){
//		cout<<i<<"---";
//		for(int j = h[i]; ~j; j = ne[j]){
//			int t = e[j];
//			cout<<t<<" ";
//		}
//		cout<<"\n";
//	}
//	cout<<ne[5]<<"\n";
	int tt;
	scanf("%d",&tt);
	while(tt--){
		res = 0;
		for(int i = 0;i <= n;i++)vt[i] = 0;
		for(int i = 0;i <= n;i++)p[i] = 0;
		int u, cnt;
		scanf("%d%d",&u,&cnt);
		p[u] = cnt;
		vt[u] = true;
		cc(u);
		printf("%lld\n",res);
	}
} 
