#include<bits/stdc++.h>

using namespace std;

#define int long long
#define ll long long
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pii pair<int,int>
#define pb push_back
//#define endl "\n"
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 3e5+7;
const int mod = 998244353;

int a[N],b[N],c[N],c1[N],a2[N];
int n;

void solve(){
	cin >> n;
	int mx1 = 0,mx2 = 0,f1 = 0,f2 = 0;
	for(int i=1;i<=n;i++) cin >> a[i],mx1 = max(abs(a[i]),mx1);
	for(int i=1;i<=n;i++) cin >> b[i],mx2 = max(abs(b[i]),mx2);
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	for(int i=1;i<=n;i++) c[i] = a[i] - b[i];
	sort(c+1,c+1+n);
	if(c[1] == c[n]){
		f1 = 1;
	}
	for(int i=1;i<=n;i++) a[i] *=-1;
	sort(a+1,a+1+n);
	for(int i=1;i<=n;i++) c1[i] = a[i] - b[i];
	sort(c1+1,c1+1+n);
	if(c1[1] == c1[n]) f2 = 1;
	if(f1&&f2) cout << min(abs(c[1]),abs(c1[1])+1);
	else if(f1) cout << abs(c[1]);
	else if(f2) cout << abs(c1[1])+1;
	else cout << -1;
}
/*
*/

signed main(){
	ios::sync_with_stdio(0);
    cin.tie(nullptr);cout.tie(nullptr);
	int T = 1;
    //cin >> T;
    while(T--) solve();

    return 0 ;
}

