#include <iostream>
#include <algorithm>

using namespace std;
const int N = 210;

int v[6], w[6];
int m, kk;
double ans = 0;

void moonk(int k, int f, double ww, double vv)
{
	if (k == 1)
	{
		if (f)
		{
			if (ww + w[k] >= m)
				ww -= kk;
			ans = max(ans, (vv + v[k]) / (ww + w[k]));		
		}
		else
		{
			if (ww == 0) return;
			ans = max(ans, vv / ww);
		}
		return;
	}
	moonk(k - 1, 1, f * w[k] + ww, f * v[k] + vv);
	moonk(k - 1, 0, f * w[k] + ww, f * v[k] + vv);
}

int main (void)
{
	cin >> m >> kk;
	
	for (int i = 1; i <= 5; i++) cin >> w[i];
	for (int i = 1; i <= 5; i++) cin >> v[i];

	moonk(5, 1, 0, 0);
	moonk(5, 0, 0, 0);
	printf("%.2lf", ans);
	
	return 0;
}
