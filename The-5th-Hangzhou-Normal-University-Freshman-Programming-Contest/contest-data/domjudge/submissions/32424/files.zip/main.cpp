
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
const int N=1010;
vector<pr<int,int> >G[N];
int n,ans,ft[N];
int ask(int u,int v){
    printf("? %d %d\n",u,v);
    fflush(stdout);
    int res;scanf("%d",&res);return res;
}
bool flg;
void dfs0(int u,int fa){
    ft[u]=fa;
    for(auto v:G[u])if(v.fi!=fa){
        dfs0(v.fi,u);
    }
}
void dfs(int u,int fa){
    vector<pr<int,int> >sset;
    int i;
    for(auto v:G[u])if(v.fi!=ft[u])sset.push_back(v);
    int sz=sset.size();
    for(i=0;i<=sz-1;i+=2){
        if(i+1<=sz-1){
            if(ask(sset[i].fi,sset[i+1].fi)){
                if(ask(sset[i].fi,u)){
                    ans=sset[i].se;
                }else ans=sset[i+1].se;
                flg=1;return;
            }dfs(sset[i].fi,sset[i].fi);if(flg)return;
            dfs(sset[i+1].fi,sset[i+1].fi);if(flg)return;
        }

    }
    if(sz>0 && (sz-1)%2==0){
        dfs(sset[sz-1].fi,fa);
    }else{
        if(u!=fa && ask(fa,u)){
            vector<int>tmp;
            int v=u;tmp.push_back(v);
            while(v!=fa){
                tmp.push_back(ft[v]);v=ft[v];
            }
            int l=1,r=(int)tmp.size()-1,res;
            while(l<=r){
                int mid=l+r>>1;
                if(ask(tmp[0],tmp[mid]))res=mid,r=mid-1;else l=mid+1;
            }
            for(auto vv:G[tmp[res]])if(vv.fi==tmp[res-1])ans=vv.se;
            flg=1;return;
        }
    }
}
int main(){
    int T,i,j;scanf("%d",&T);
    while(T--){
        scanf("%d",&n);
        rep(i,1,n-1){
            int x,y;scanf("%d%d",&x,&y);
            G[x].push_back(mkp(y,i));
            G[y].push_back(mkp(x,i));
        }
        flg=0;
        dfs0(1,0);
        dfs(1,1);
        printf("! %d\n",ans);fflush(stdout);
    }
}