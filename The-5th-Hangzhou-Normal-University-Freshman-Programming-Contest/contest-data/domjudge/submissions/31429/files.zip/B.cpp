#include<bits/stdc++.h>
#define moder (long long)998244353
using namespace std;
long long binpow(long long a, long long b) {
  long long res = 1;
  while (b > 0) {
    if (b & 1) res = res * a % moder;
    a = a * a % moder;
    b >>= 1;
  }
  return res % moder;
}
long long C(long long x,long long y){
	if(y>x){
		return 0;
	}
	long long tim=1;
	for(int i=x;i>=x-y+1;i--){
		tim*=i;
		tim%=moder;
	}
	for(int i=1;i<=y;i++){
		tim*=binpow(i,moder-2);
		tim%=moder;
	}
	return tim%moder;
}
bool comp(long long x,long long y){
	return x<y;;
}
inline void solve()
{
	int n;
	cin>>n;
	vector<long long> a(n),b(n);
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		cin>>b[i];
	}
	sort(a.begin(),a.end(),comp);

	sort(b.begin(),b.end(),comp);
	vector<long long > c,d;
	long long ans1=0;// no rev
	c=a,d=b;
	for(int  i=0;i<n;i++){
		a[i]-=c[0];
		b[i]-=d[0];
		if(a[i]!=b[i]){
			cout<<-1<<'\n';
			return ;
		}
	}
	ans1 = abs(c[0]-d[0]);
	long long ans2=1;
	b=d;
	for(int i=0;i<n;i++){
		b[i]*=-1;
	}
	sort(b.begin(),b.end(),comp);
	ans2+=abs(b[0]-c[0]);
	cout<<min(ans1,ans2)<<'\n';;
}

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	int tt;
	//cin>>tt;
	//while(tt--)
	solve();
}