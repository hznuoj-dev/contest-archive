#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int m,k,a[222],b[222];
struct node
{
	int a;
	int b;
	double x;
}seg[222];
bool cmp(node h,node hh)
{
	return h.x>hh.x;
}
int main()
{
	scanf("%d %d",&m,&k);
	for(int i=1;i<=5;i++) scanf("%d",&seg[i].a);
	for(int i=1;i<=5;i++) scanf("%d",&seg[i].b);
	for(int i=1;i<=5;i++) seg[i].x=seg[i].b/seg[i].a;
	sort(seg+1,seg+6,cmp);
	double max=0;
	int aa=0,bb=0;
	for(int i=1;i<=5;i++)
	{
		aa+=seg[i].a;
		bb+=seg[i].b;
		if(aa>=m) if(bb/(aa-k)>max) max=bb/(aa-k);
		else  if(bb/aa>max) max=bb/aa;
	}
	printf("%.2lf\n",max);
	return 0;
}
