#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N=2e5+7;
int m,k;
double a[7],b[7];

void solve(){
	cin>>m>>k;
	for(int i=0;i<5;i++) cin>>a[i];
	for(int i=0;i<5;i++) cin>>b[i];
	double ans=-1e9;
	for(int i=1;i<(1<<5);i++){
		double x=0,y=0;
		for(int j=0;j<5;j++){
			if(i&(1<<j)){
				x+=a[j];
				y+=b[j];
			}
		}
		if(x>=m) x-=k;
		ans=max(ans,y/x);
	}
	printf("%.2lf\n",ans);
}

int main(){
//	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc=1;
//	cin>>tc;
	while(tc--) solve();
	return 0;
}
/*
5 3
1 2 4 4 2
2 2 1 2 4

*/
