#include <bits/stdc++.h>
#define int long long

using namespace std;



void pr_vc(vector<int>& vc){
    for (int i : vc) {
        cout << i << " " ;
    }
    cout << "\n";
}

void b(){
    int n;
    cin >> n;
    vector<int> a(n);
    vector<int> vc(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    for (int i = 0; i < n; ++i) {
        cin >> vc[i];
    }

    std::sort(a.begin(), a.end());
    std::sort(vc.begin(), vc.end());

    int point = 0;
    int det[2];
    det[0] = a[0] - vc[0];
    det[1] = a[0] - (-vc[n-1]);
    if(abs(det[0]) > abs(det[1]) + 1){
        det[0] = det[1];
        for (int i = 0; i < n; ++i) {
            vc[i] = -vc[i];
        }
        //pr_vec(vc);
//        for (int i = 0; i < n / 2; ++i) {
//            swap(vc[i], vc[n-1-i]);
//        }
        std::sort(vc.begin(), vc.end());
        //pr_vec(vc);

        point = 1;
    }
    for (int i = 0; i < n; ++i) {
        vc[i] += det[0];
    }
    //pr_vec(vc);

    bool f = true;
    for (int i = 0; i < n; ++i) {
        if(a[i] != vc[i]){
            f = false;
            break;
        }
    }

    if(f){
        cout << abs(det[0]) + point;
    }
    else{
        cout << -1;
    }
}

signed main() {
    int n = 1;
    //cin >> n;
    while (n--){
        b();
    }
}
