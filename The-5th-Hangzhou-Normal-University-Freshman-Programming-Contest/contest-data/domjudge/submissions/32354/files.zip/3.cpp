#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define N 400010
#define inf 1000000000000ll

int m,k;
int a[10],b[10];

signed main() {
    cin>>m>>k;
    for(int i=1;i<=5;++i) cin>>a[i];
    for(int i=1;i<=5;++i) cin>>b[i];
    double ans=0;
    for(int now=1;now<=31;++now){
        int cost=0,val=0;
        for(int i=1;i<=5;++i) if(now&(1<<(i-1))){
            cost+=a[i];
            val+=b[i];
        }
        if(cost>=m) cost-=k;
        ans=max(1.0*val/cost,ans);
    }
    printf("%.2lf",ans);
}