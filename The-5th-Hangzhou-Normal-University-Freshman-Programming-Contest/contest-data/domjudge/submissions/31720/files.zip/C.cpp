#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=200005;
ll ans1,ans2,k1[M],k2[M],k3[M];
int n,d,l;
string s1,s2,s3;
void rep(int x){
	s1="";
	s2="";
	s3="";
	d=x%9;
	if(d>=4) l=x/9-1;
	else l=x/9-2;
	for(int i=1;i<=l;i++)
	{
		s1+='1';
		s2+='1';
		s3+='2';
	}
	if(d==0)
	{
		s1+='3';s2+='2';s3+='4';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
		s1[s1.length()-1]='2';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
	else if(d==1) 
	{
		s1+='7';s2+='8';s3+='9';
		cout<<s1<<"-"<<s2<<"="<<s3<<endl;
		s1[s1.length()-1]='1';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
	else if(d==2)
	{
		s1+='5';s2+='3';s3+='6';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
		s1[s1.length()-1]='3';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
	else if(d==3)
	{
		s1+='5';s2+='5';s3+='8';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
		s1[s1.length()-1]='3';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
	else if(d==4)
	{
		s1+='7';s2+='1';s3+='2';
		cout<<s1<<"-"<<s2<<"="<<s3<<endl;
		s1[s1.length()-1]='1';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
	else if(d==5)
	{
		s1+='7';s2+='0';s3+='1';
		cout<<s1<<"-"<<s2<<"="<<s3<<endl;
		s1[s1.length()-1]='1';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
	else if(d==6)
	{
		s1+='1';s2+='5';s3+='4';
		cout<<s1<<"-"<<s2<<"="<<s3<<endl;
		s2[s2.length()-1]='3';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
	else if(d==7)
	{
		s1+='7';s2+='2';s3+='3';
		cout<<s1<<"-"<<s2<<"="<<s3<<endl;
		s1[s1.length()-1]='1';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
	else if(d==8)
	{
		s1+='7';s2+='5';s3+='6';
		cout<<s1<<"-"<<s2<<"="<<s3<<endl;
		s1[s1.length()-1]='1';
		cout<<s1<<"+"<<s2<<"="<<s3<<endl;
	}
}
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		if(n<13)
		{
			printf("No Solution\n");
			continue;
		}
		rep(n);
	}
	return 0;
}