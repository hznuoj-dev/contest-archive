#include <bits/stdc++.h>
#define int long long

using namespace std;

void a(){
    int n;
    cin >> n;
    vector<int> vc(n);
    vector<int> arr(n);
    for (int i = 0; i < n; ++i) {
        cin >> vc[i];
        arr[i] = vc[i];
    }
    if(n % 2){

    }
    else{
        std::sort(vc.begin(), vc.end());
        int m2 = vc[n/2], m1 = vc[n/2 - 1];
        if(m1 < arr[0]) m1 = arr[0]; if(arr[n-1] < m2) m2 = arr[n-1];
        for (int i = m1; i < m2; ++i) {

        }

    }
}

void pr_vec(vector<int>& vc){
    for (int i : vc) {
        cout << i << " " ;
    }
    cout << "\n";
}
void b(){
    int n;
    cin >> n;
    vector<int> a(n);
    vector<int> vc(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    for (int i = 0; i < n; ++i) {
        cin >> vc[i];
    }

    std::sort(a.begin(), a.end());
    std::sort(vc.begin(), vc.end());

    int point = 0;
    int det[2];
    det[0] = a[0] - vc[0];
    det[1] = a[0] - (-vc[n-1]);
    if(abs(det[0]) > abs(det[1])){
        det[0] = det[1];
        for (int i = 0; i < n; ++i) {
            vc[i] = -vc[i];
        }
        pr_vec(vc);
        for (int i = 0; i < n / 2; ++i) {
            swap(vc[i], vc[n-1-i]);
        }
        pr_vec(vc);

        point = 1;
    }
    for (int i = 0; i < n; ++i) {
        vc[i] += det[0];
    }
    pr_vec(vc);

    bool f = true;
    for (int i = 0; i < n; ++i) {
        if(a[i] != vc[i]){
            f = false;
        }
    }

    if(f){
        cout << abs(det[0]) + point;
    }
    else{
        cout << -1;
    }



//
//    int cnt_a = a[0];
//    for (int i = 0; i < n-1; ++i) {
//        if(a[i] * a[i+1] < 0){
//            cnt_a = i;
//            break;
//        }
//    }
//
//
//    int cnt_vc = vc[0];
//    for (int i = 0; i < n-1; ++i) {
//        if(vc[i] * vc[i+1] < 0){
//            cnt_vc = i;
//            break;
//        }
//    }
//
//    int point = 0;
//    int det[2];
//    det[0] = cnt_a - cnt_vc;
//    det[1] = cnt_a - (n-1 - cnt_vc - 1);
//    if(abs(det[0]) > abs(det[1])){
//        //反转
//        for (int i = 0; i < n; ++i) {
//            vc[i] = -vc[i];
//        }
//        for (int i = 0; i <= n / 2; ++i) {
//            swap(vc[i], vc[n-1]);
//        }
//        det[0] = det[1];
//        point = 1;
//    }
//    for (int i = 0; i < n; ++i) {
//        vc[i] += det[0];
//    }
//
//


}

signed main() {
    b();
}
