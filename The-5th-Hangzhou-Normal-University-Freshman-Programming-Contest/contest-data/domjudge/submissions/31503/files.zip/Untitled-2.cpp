//#include<bits/stdc++.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <string.h>
#include <string>
#include <math.h>

#define int long long

using namespace std;
const int N = 1e6 + 10;
float money[N];
float value[N];
float xjb[N];
void solve()
{
    float m, k;
    cin >> m >> k;
    for (int i = 1; i <= 5; i++)
    {
        cin >> money[i];
    }
    for (int i = 1; i <= 5; i++)
    {
        cin >> value[i];
    }
    for (int i = 1; i <= 5;i++){
        xjb[i] = value[i] / money[i];
    }
    float t;
    for (int i = 1; i <= 5;i++){
        for (int j = 1; j <= 5-i+1;j++){
            if(xjb[j]<xjb[j+1]){
                t = xjb[j];
                xjb[j] = xjb[j + 1];
                xjb[j + 1] = t;

                t = money[j];
                money[j] = money[j + 1];
                money[j + 1] = t;

                t = value[j];
                value[j] = value[j + 1];
                value[j + 1] = t;
            }
        }
    }
//    for (int i = 1; i <= 5; i++)
//    {
//        cout << xjb[i] << ' ' << value[i] << ' ' << money[i] /<< endl;
//    }
    float max=0;
    int num = 0;
    float res;
    while(num<=5){
        num++;
        float mm = 0, vv = 0;
        for (int i = 1; i <= num;i++){
            mm += money[i];
            vv += value[i];
        }
        if(mm>=m)
            mm -= k;
        res = vv / mm;
        if(res>max)
            max = res;
    }
    printf("%0.2f\n", max);
}
signed main()
{
    int t;
    t = 1;
    //    cin>>t;
    while (t--)
    {
        solve();
    }
    return 0;
}

