#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

long long int n;
long long int a[200000], b[200000];

bool cmp(int x1, int x2)
{
    return x1 > x2;
}

int main()
{
    cin >> n;
    for (long long int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    for (long long int i = 0; i < n; i++)
    {
        cin >> b[i];
    }
    int t1 = 1;
    sort(a, a + n, cmp);
    sort(b, b + n);
    for (long long int i = 0; i < n; i++)
    {
        if (a[i] == -b[i])
        {
            continue;
        }
        else
        {
            t1 = 0;
            break;
        }
    }
    if (t1 == 1)
    {
        cout << 1;
    }
    else
    {
        sort(a, a + n);
        int t2 = 1;
        int v = b[0] - a[0];
        for (long long int i = 0; i < n; i++)
        {
            if (a[i] + v == b[i])
            {
                continue;
            }
            else
            {
                t2 = 0;
                break;
            }
        }
        if (t2 == 1)
        {
            cout << abs(v);
        }
        else
        {
            int t3 = 1;
            sort(a, a + n, cmp);
            v = -b[0] - a[0];
            for (long long int i = 0; i < n; i++)
            {
                if (a[i] + v == -b[i])
                {
                    continue;
                }
                else
                {
                    t3 = 0;
                    break;
                }
            }
            if (t3 == 1)
            {
                cout << abs(v) + 1;
            }
            else
            {
                cout << "-1";
            }
        }
    }
}

/*
3
-5 1 3
1 3 9
*/