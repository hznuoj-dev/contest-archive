#include<cstdio>
#include<iostream>
#include<cmath>
using namespace std;
const int N=3e5+10;
double a1[N]={0};
double a2[N]={0};
int main(){
   int n;
   cin>>n;
   for(int i=0;i<n;i++)
   cin>>a1[i];
   for(int i=0;i<n;i++)
   cin>>a2[i];
    for (int i=0;i<n-1;i++){
        for (int j=0;j<n-i-1;j++){
            if (a1[j]>a1[j+1]){
            int temp = a1[j];
                a1[j] = a1[j+1];
                a1[j+1] = temp;
                        }
            if (a2[j]>a2[j+1]){
            int temp = a2[j];
                a2[j] = a2[j+1];
                a2[j+1] = temp;
                 }
         }
}
int flag=1;
for(int i=0;i<n;i++){
	if(a1[i]!=a2[i])
	flag=0;
} 
if(flag==1){
	cout<<'0';
	return 0;	 
}
flag=1;
for(int i=1;i<n;i++){
	int k=a1[0]-a2[0];
	if(a1[i]-a2[i]!=k)
	flag=0;
}
if(flag==0){
	cout<<"-1";
	return 0;
}
else{
	if(a1[0]<0&&a1[n-1]<0&&a2[0]>0&&a2[n-1]>0){
		int p=fabs(fabs(a1[0])-a2[n-1])+1;
		cout<<p;
		return 0;
	}
	else if(a2[0]<0&&a2[n-1]<0&&a1[0]>0&&a1[n-1]>0){
		int p=fabs(fabs(a2[0])-a1[n-1])+1;
		cout<<p;
		return 0;
	}
	else{
		int p=fabs(a1[0]-a2[0]);
		cout<<p;
	}
	
}
	




	return 0;
}















