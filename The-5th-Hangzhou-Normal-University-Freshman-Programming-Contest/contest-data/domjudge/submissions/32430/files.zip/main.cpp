//#include <iostream>
//using namespace std;
//const int N = 2e5 + 10;
//long long qpow(long long a , long long n , long long mod){
//    long long ans = 1;
//    while(n){
//        if(n & 1){
//            ans = ans * a % mod;
//        }
//        n >>= 1;
//        a = a * a % mod;
//    }
//    return ans;
//}
//int fa[N] , a[N] , sum[N] , b[N];
//int n , q;
//void Init(){
//    for(int i = 1 ; i <= n;i++) {
//        fa[i] = i;
//        sum[i] = 1;
//    }
//}
//int find(int x){
//    return fa[x] == x ? x : find(fa[x]);
//}
//int main() {
//    cin >> n >> q;
//    Init();
//    for(int i = 1 ; i <= n;i++){
//        cin >> b[i];
//        a[i] = b[i];
//    }
//    for(int i = 1 ; i <= q;i++){
//        int k , u , v;
//        cin >> k >> u;
//        if(k == 1){
//            cin >> v;
//            int fu = find(u);
//            int fv = find(v);
//            if(fu != fv) {
//                fa[fv] = fu;
//                sum[fu] += sum[fv];
//                a[fu] += a[fv];
//            }
//        }else if(k == 2){
//            cin >> v;
//            int fu = find(u);
//            a[fu] += v * sum[fu];
//        }else{
//            cout <<
//        }
//    }
//    return 0;
//}

//#include "iostream"
//#include "vector"
//#include "map"
//using namespace std;
//const int N = 2e5 + 10;
//vector<pair<int,int>> vec[N];
//map<int,int> map1;
//int dfs(int u , int fa ,int x){
//    int ans = x;
//    for(auto&[v , w] : vec[u]){
//        if(v == fa) continue;
//        ans ^= dfs(v , u , x ^ w);
//    }
//    return ans;
//}
//int main(){
//    ios::sync_with_stdio(false);
//    cin.tie(0);
//    cout.tie(0);
//    int n , q;
//    cin >> n;
//    for(int i = 1 ; i <= n - 1;i++){
//        int u , v , w;
//        cin >> u >> v >> w;
//        vec[u].push_back({v , w});
//        vec[v].push_back({u , w});
//    }
//    cin >> q;
//    while(q--){
//        int u , x;
//        cin >> u >> x;
//        cout << dfs(u , u , x) << endl;
//    }
//}

#include "iostream"
#include "map"
#include "stack"
using namespace std;
const int N = 2e5 + 10;
int a[N], n;
map<int,int> map1;
bool check(int num){
    stack<int> s;
    for(int i = 1 ; i <= n;i++){
        if(a[i] < num){
            s.push(a[i]);
        }else if(a[i] > num){
            s.pop();
        }
    }
    if(s.empty()) return true;
    else return false;
}
int main(){
    cin >> n;
    for(int i = 1 ; i <= n;i++) {
        cin >> a[i];
        map1[a[i]]++;
    }
    int sum = 0 , ans = 0;
    int last = 0;
    for(auto i : map1){
        if(n - i.second - sum == sum) {
            if(check(i.first)) ans += 1;
        }
        else if(n - sum - i.second == sum + i.second && check(i.first + 1)) {
            last = i.first + 1;
        }
        else if(n - sum == sum && last != 0 && check(i.first - 1)) {
            ans += i.first - last;
        }
        sum += i.second;
    }
    cout << ans;
}