#include<bits/stdc++.h>
using namespace std;
int a[6],w[6];
int main(){
	int m,k;
	scanf("%d%d",&m,&k);
	for(int i=0;i<5;i++){
		scanf("%d",&a[i]);
	}
	for(int i=0;i<5;i++){
		scanf("%d",&w[i]);
	}
	int n=(1<<5);
	double ans=0;
	for(int i=0;i<n;i++){
		int nowcost=0;
		int nowval=0;
		int x=i,tp=0;
		while(x){
			if(x&1){
				nowcost+=a[tp];
				nowval+=w[tp];
			}
			tp++;
			x>>=1;
		}
		if(nowcost>=m)nowcost-=k;
		ans=max(ans,(double)nowval/nowcost);
	}
	printf("%.2f\n",ans);
}
