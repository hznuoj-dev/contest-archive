#include<bits/stdc++.h>
using namespace std;
int  k,maxn,minn,n,m,q,a[1000000],f[1000000],g[1000000],l,r,len1,len2,dp[1000000],ff[1000000],gg[1000000],ll,rr,mid;
int main()
{
	cin>>n>>m>>q;
	
	for(int  i=1;i<=n;i++)
	{
	  cin>>a[i];
	  if(len1==0)  {len1++,f[1]=a[i];ff[1]=i;}
	  else  if(a[i]<f[len1])
	  {
	  	len1++;
	  	f[len1]=a[i];
	  	ff[len1]=i;
	  }
	  else  if(a[i]>f[len1])
	  {
	  	l=lower_bound(f,f+1+len1,a[i],greater<int>())-f;
	  	
	  	if(f[l]!=a[i])  
	  	{
	  	  len1=l+1;
	  	  f[len1]=a[i];
	  	  ff[len1]=l+1;
		}
		else  len1=l;
	  }
	  
	  if(len2==0)  {len2++,g[1]=a[i];gg[1]=i;}
	  else  if(a[i]>g[len2])
	  {
	  	len2++;
	  	g[len2]=a[i];
	  	gg[len2]=i;
	  }
	  else  if(a[i]<g[len2])
	  {
	  	r=lower_bound(g+1,g+1+len2,a[i])-g;
	  	
	  	if(f[r]!=a[i])  
	  	{
	  	  len2=r;
	  	  g[len2]=a[i];
	  	  gg[len2]=i;
		}
		else  len2=r;
	  }
	  
	  if(i!=1)
	  {
	  	ll=1;rr=i-1;
	  	
	  	while(ll<rr)
	  	{
	  	  mid=ll+rr>>1;
	  	  
	  	  k=upper_bound(ff+1,ff+1+len1,mid)-ff;
	  	  maxn=f[k-1];
	  	  
	  	  k=upper_bound(gg+1,gg+1+len2,mid)-gg;
	  	  minn=g[k-1];
	  	  
	  	  if(maxn-minn<=m)  rr=mid;
	  	  else  ll=mid+1;
		}
		
		dp[i]=dp[i-1]+i+1-ll;
	  }
	  else  dp[1]=1;
	}
	
	for(int  i=1;i<=q;i++)
	{
	  cin>>l>>r;
	  
	  if(l==r)  cout<<"1\n";
	  else  if(l==1)  cout<<dp[r]<<'\n';
	  else  cout<<dp[r]-dp[l]<<'\n'; 
	}
	return  0;
}
