#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 200010, M = 800010;
const ll mod = (ll)(1e9 + 7);
int head[N], ne[M], ver[M], in[N], d[N], cnt[N], tot;
ll mp[N], sum[N];
void add(int x, int y) {
	ver[++tot] = y, ne[tot] = head[x], head[x] = tot;
}
ll qp(ll a, ll k, ll p, ll r = 1) {
    for (; k; k >>= 1, a = a * a % p)
        if (k & 1) r = r * a % p;
    return r;
}
void dfs(int x) {
	for (int i = head[x]; i; i = ne[i]) {
		int y = ver[i];
		d[y] = max(d[y], d[x] + 1);
		cnt[y]++;
		if (in[y] == cnt[y]) dfs(y);
	}
} 
int main () {
	int n, m, k;
	cin >> n >> m >> k;
	for (int i = 1; i <= m; i++) {
		int x, y;
		cin >> x >> y;
		add(x, y);
		in[y]++;
	}
	for (int i = 1; i <= n; i++) {
		if (!in[i]) d[i] = 1, dfs(i);
 	}
 	set<int> s;
 	ll maxn = 0;
 	for (int i = 1; i <= n; i++) {
 		s.insert(d[i]);
 		mp[d[i]]++;
 		maxn = max(maxn, (ll)d[i]);
	} 
	//for (int i = 1; i <= n; i++) cout << d[i] << " ";
	//cout << endl;
	ll res = 0ll;
	sum[maxn + 1] = 0;
	for (int i = maxn; i >= 1; i--) sum[i] = sum[i + 1] + mp[i];
	for (int i = 1; i < maxn; i++) res = (res + mp[i] * sum[i + 1] % mod) % mod;
	ll ans = qp(res, k, mod);
	cout << ans;
	return 0;
}
