﻿#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<string>
#include<cstring>
#include<cstdio>
#include<algorithm>
#include<map>
#include<vector>
#include<malloc.h>
#include<numeric>
#include<cmath>
#include<math.h>
#include<iomanip>
#include<queue>
#include<set>
#include<bitset>
#include<stack>
#include<fstream>
#include<stdexcept>
using namespace std;
typedef long long ll;
typedef pair<int, int>PII;
#define lowbit(x) x&(-x)​
int m,k, a[10], b[10];
double ans = 0;
void dfs(int u,int price,int x)
{
	if (u == 5)return;
	dfs(u + 1,price,x);
	price += b[u];
	if (price >= m)price -= k;
	x += a[u];
	ans = max(ans, x * 1.0 / price);
	dfs(u + 1, price, x);
	
}
int main()
{
	cin >> m >> k;
	for (int i = 0; i < 5; i++)cin >> a[i];
	for (int i = 0; i < 5; i++)cin >> b[i];
	dfs(0, 0, 0);
	printf("%.2lf", ans);
	
}








