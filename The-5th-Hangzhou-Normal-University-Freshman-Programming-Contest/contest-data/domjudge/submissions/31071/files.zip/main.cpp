#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;

void solve() {
    int n;
    std::cin >> n;
    std::vector<int>a(n), b(n);
    for(auto &v : a) std::cin >> v;
    for(auto &v : b) std::cin >> v;
    std::sort(a.begin(), a.end());
    std::sort(b.begin(), b.end());
    ll d = a[0] - b[0];
    int f = 1;
    for(int i = 0;i < n;i++) {
        if(d != a[i] - b[i]) {
            f = 0;
            break;
        }
    }
    if(f == 1) {
        std::cout << std::abs(d) << '\n';
        return;
    }
    for(auto &v : b) v = -v;
    std::sort(b.begin(), b.end());
    d = a[0] - b[0];
    f = 1;
    for(int i = 0;i < n;i++) {
        if(d != a[i] - b[i]) {
            f = 0;
            break;
        }
    }
    if(f == 1) std::cout << std::abs(d) + 1 << '\n';
    else std::cout << "-1\n";
}

int main() {
    int T = 1;
    //std::cin >> T;
    while(T--) {
        solve();
    }
}