#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const int N = 1e5 + 10, mod = 1e9 + 7;
#define endl "\n"
typedef pair <int, int> PII;
int n, k;
struct node{
    int x, y;
}r[N];
double a[N], b[N], ans, c[N], d[N];
bool cmp1(node a, node b){
    return a.x > b.x;
}
bool cmp2(int a, int b){
    return a > b;
}
void solve(){
    int num;
    cin >> num;
    for (int i = 1; i <= num; i ++)cin >> a[i], c[i] = -a[i];
    for (int i = 1; i <= num; i ++)cin >> b[i], d[i] = b[i];
    sort(a + 1, a + num + 1);
    sort(b + 1, b + num + 1);
    for (int i = 2; i <= num; i ++){
        if (abs(a[i] - a[i - 1]) != abs(b[i] - b[i - 1])){
            cout << -1 << endl;
            return;
        }
    }
    ans = abs(a[1] - b[1]);
    sort(c + 1, c + num + 1);
    sort(d + 1, d + num + 1);
    ans = min(ans, abs(c[1] - d[1]) + 1);
    cout << ans << endl;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int q;
    //cin >> q;
    q = 1;
    while (q --){
        solve();
    }
    return 0;
}