#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[2000005];
int main(){
	ll n,m,b;
	cin>>n>>m>>b;
	ll k=0;
	int j=n-n/m*m;
	if(j==0)j+=m;
	ll x=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		x+=a[i];
		if((i-j)%m==0){
			k+=min(b,x);
			x-=min(b,x);
		}
	}
	cout<<k<<endl;
	return 0;
}