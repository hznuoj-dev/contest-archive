#include <bits/stdc++.h>
#define endl '\n'
//#define int long long
using namespace std;
typedef unsigned long long ull;
const int N=2e5+10;
const int mod=1e9+7;

int m,k;
double a[14],b[14],ans=0;

void dfs(int x,double price,double eva)
{
	int p=price;
	if(p>=m)
		p-=k;
	if(x!=0)
		ans=max(ans,eva/p);
	
	for(int i=x+1;i<=5;i++)
		dfs(i,price+a[i],eva+b[i]);	
}

void run()
{
	scanf("%d%d",&m,&k);
	for(int i=1;i<=5;i++)
		scanf("%lf",&a[i]);
	for(int i=1;i<=5;i++)
		scanf("%lf",&b[i]);
		
	for(int i=1;i<=5;i++)
		dfs(0,0,0);
	printf("%.2f",ans);
}

signed main()
{
    int T=1;

//    ios::sync_with_stdio(false),cin.tie(nullptr),cout.tie(nullptr);
    //cin >> T;
    while(T--)
        run();

    return 0;
}

