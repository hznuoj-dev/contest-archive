﻿#include<bits/stdc++.h>
using namespace std;
int n;
const string s1[7]={"7-1=1+1","6-7=7","2+4=7","4-3=2","7-4=1+4","3=2","7-1=2"};
const string s2[7]={"1+1=1+1","6+1=7","3+4=7","4-2=2","7-4=7-4","2=2","1+1=2"};
int main()
{
    int T;
    scanf("%d",&T);
    while(T--)
    {
        scanf("%d",&n);
        // if(n==8){puts("-1=-");continue;}
        // if(n==10){puts("+1=-7\n-7=-7");continue;}
        if(n<12){puts("No Solution");continue;}
        int cnt=n/7;n%=7;
        // printf("%d\n",n);
        if(n>=5) cnt--;
        else cnt-=2;
        cout<<s1[n];
        for(int i=1;i<=cnt;i++) printf("+1-1");
        puts("");
        cout<<s2[n];
        for(int i=1;i<=cnt;i++) printf("+1-1");
        puts("");
    }
    return 0;
}