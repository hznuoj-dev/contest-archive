#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
#define int ll
#define endl '\n'
#define pii pair<int, int>
#define pll pair<ll, ll>
#define jql std::ios::sync_with_stdio(false), std::cin.tie(0), std::cout.tie(0)
#define all(a) a.begin(), a.end()
#define gcd __gcd
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int N = 2e5 + 10;
double eps = 1e-7;
int a[N], b[N];
void solve()
{
    int n;
    cin >> n;
    for (int i = 0; i < n; i++)
        cin >> a[i];
    for (int i = 0; i < n; i++)
        cin >> b[i];
    sort(a, a + n);
    sort(b, b + n);
    int k = a[0] - b[0];
    int flag = 1;
    for (int i = 1; i < n; i++)
    {
        if (a[i] - b[i] != k)
        {
            flag = 0;
            break;
        }
    }
    if (!flag)
    {
        cout << -1 << endl;
        return;
    }
    cout << abs(k) << endl;
}
signed main()
{
    jql;
    int _ = 1;
    // cin >> _;
    while (_--)
        solve();
    return 0;
}