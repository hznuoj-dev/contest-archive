#include <iostream>

using namespace std;

int a[10], b[10];
int m, k;
double res = 0;

void dfs(int x, int jg, int jz)
{
    if (x == 5)
    {
        if (jg > 0)
        {
            if (jg >= m)
                jg = jg - k;
            if (res < jz * 1.0 / jg)
                res = jz * 1.0 / jg;
        }
        return;
    }
    dfs(x + 1, jg + a[x], jz + b[x]);
    dfs(x + 1, jg, jz);
}

int main()
{
    scanf("%d%d", &m, &k);
    for (int i = 0; i < 5; i++)
        scanf("%d", &a[i]);
    for (int i = 0; i < 5; i++)
        scanf("%d", &b[i]);
    dfs(0, 0, 0);
    printf("%.2f", res);
    return 0;
}