
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
#define D double
D a[10],b[10],m,k;
D cal(int s){
    D cst=0,val=0;
    int i;
    rep(i,0,4)if(s&(1<<i)){
        cst+=a[i];val+=b[i];
    }
    if(cst>=m)cst-=k;
    return val/cst;
}
int main(){
    cin>>m>>k;
    int i;
    rep(i,0,4)cin>>a[i];
    rep(i,0,4)cin>>b[i];
    D ans=0;
    rep(i,1,(1<<5)-1)ans=max(ans,cal(i));
    printf("%.2lf",ans);
}