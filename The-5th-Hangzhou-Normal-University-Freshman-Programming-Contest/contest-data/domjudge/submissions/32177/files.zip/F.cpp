#include<bits/stdc++.h>
using namespace std;
int deg[200005];
struct edge{
	int v,next,w;
}e[400005];
int eid,h[200005];
void addEdge(int u,int v,int w){
	e[eid]={v,h[u],w};
	h[u]=eid++;
}
int sz[200005];
int sum[200005];
int ans=0;
void dfs(int u,int fa){
	for(int i=h[u];~i;i=e[i].next){
		int v=e[i].v,w=e[i].w;
		if(v==fa)continue;
		sum[v]=sum[u]^w;
		ans^=sum[v];
		dfs(v,u);
		
	}
}
int main(){
	int n;
	memset(h,-1,sizeof(h));
	scanf("%d",&n);
	for(int i=0;i<n-1;i++){
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		addEdge(u,v,w);
		addEdge(v,u,w);
	}	
	dfs(1,0);
	int q;
	scanf("%d",&q);
	while(q--){
		int u,x;
		scanf("%d%d",&u,&x);
		if(n%2==0)printf("%d\n",ans);
		else printf("%d\n",ans^x);
	}
}
