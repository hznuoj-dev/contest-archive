#include <bits/stdc++.h>

#define ll long long
const int N = 2e6 + 7;
ll dp[N][2];
void solve() {
	int n, m, b;
	std::cin >> n >> m >> b;
	std::vector<ll> a(n + 1);
	ll sum = 0;
	for (int i = 1; i <= n; i++) {
		std::cin >> a[i];
		sum += a[i];
	}
	dp[1][0] = a[1];
	dp[1][1] = std::max(a[1] - b, 0ll);
	
	for (int i = 2; i <= n; i++) {
		dp[i][0] = std::min(dp[i - 1][0], dp[i - 1][1]) + a[i];
		dp[i][1] = std::max(dp[std::max(1, (int)i - m + 1)][0] + a[i] - b, 0ll);
	}
	
	/*for (int i = 1; i <= n; i++) {
		for (int j = 0; j <= 1; j++) {
			printf("dp[%lld][%lld] = %lld\n", i, j, dp[i][j]);
		}
	}*/
	
	std::cout << std::max(0ll, sum - std::min(dp[n][0], dp[n][1]));
}

int main() {
	//std::ios::sync_with_stdio(0);
	//std::cin.tie(nullptr);
	
	solve();
}
