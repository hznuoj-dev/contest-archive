#include <bits/stdc++.h>
#define endl '\n'
#define int long long
#define x first
#define y second

using namespace std;
typedef pair<int,int> PII;
int T;
int n, m, qi;
string s;

signed main()
{
    ios::sync_with_stdio(0);
    cin.tie(0),cout.tie(0);

    cin >> n;
    vector<vector<PII>> g(n+1);
    vector<int> st(n+1, 0), l(n+1,0);
    int ans = 0;
    for(int i = 0 ; i < n - 1 ; i ++) {
        int a, b, c; cin >> a >> b >> c;
        g[a].push_back({b, c});
        g[b].push_back({a, c});
    }
    queue<int> q;
    q.push(1);
    while(q.size()) {
        auto u = q.front();
        q.pop();

        for(auto [i,j] : g[u]) {
            if(st[i]) continue;
            l[i] = l[u] ^ j;
            q.push(i);
            st[i] = true;
        }
    }

    for(int i = 1 ; i <= n ; i ++) ans ^= l[i];

    map<int,int> mp;

    cin >> qi;
    while(qi --) {
        int a, b; cin >> a >> b;
        int res = ans;
        if(n & 1) res = res ^ b ^ l[a];
        cout << res << endl;
    }
}
/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5
*/

