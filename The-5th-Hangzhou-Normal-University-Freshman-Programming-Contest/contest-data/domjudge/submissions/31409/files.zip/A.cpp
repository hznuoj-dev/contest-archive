#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
int a[200005];
bool flag[200005];
set<int>ans[200005];
int cot = 0;
int max_deep = 0;
int d = -1;
map<int,int>m;
void play(int start, int end, int deep) {
	if(start>=end) return;
	max_deep = max(max_deep,deep);
	for(int i = start+1; i<=end; i++) {
		if(a[i]<a[i-1]) {
			flag[deep]=true;
			break;
		}
	}
	int mid = (start+end)/2;
	play(start,mid,deep+1),play(mid+1,end,deep+1);
}
void find(int start, int end, int deep){
	if(deep<d){
		int mid = (start+end)/2;
		find(start,mid,deep+1);
		find(mid+1,end,deep+1);
	}
	else{
		cot++;
		if((end-start+1)%2==1){
			int mid = (start+end)/2;
			int cnt = 0;
			for(int i = start;i<=end;i++){
                if(a[i]==a[mid])cnt++;
			}
			if(cnt%2==1)ans[cot].insert(a[mid]);
		}
		else{
			int mid = (start+end)/2;
			for(int i = a[mid]+1;i<a[mid+1];i++){
				ans[cot].insert(i);
			}
			if(a[mid]==a[mid+1]){
				int cnt = 0;
				for(int i = start;i<=end;i++){
                    if(a[i]==a[mid])cnt++;
				}
				if(cnt%2==0)ans[cot].insert(a[mid]);
			}
		}
	}
}
void solve() {
	int n;
	cin>>n;
	for(int i = 1; i<=n; i++) {
		cin>>a[i];
	}
	play(1,n,1);
	for(int i = 1;i<=max_deep;i++){
		if(!flag[i]){
			d = i;
			break;
		}
	}
	if(d==-1)cout<<0<<'\n';
	else{
		find(1,n,1);
		for(int i = 1;i<=cot;i++){
			for(auto const &x:ans[i]){
				m[x]++;
			}
		}
		int  c = 0;
		for(auto x:m){
			if(x.second==cot){
				c++;
//				cout<<x.first<<'\n';
			}
		}
		cout<<c<<'\n';
	}
}

signed main() {
	int T = 1;
//	cin>>T;
	while(T--)solve();
	return 0;
}
