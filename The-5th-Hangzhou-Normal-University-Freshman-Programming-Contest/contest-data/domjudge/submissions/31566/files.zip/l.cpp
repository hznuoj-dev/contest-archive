#include<bits/stdc++.h>
using namespace std;
int main()
{
	long long int m,k,i;
	long long int a[10],b[10],x=0,y=0;
	double c[10];
	scanf("%lld%lld",&m,&k);
	for(i=1;i<=5;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(i=1;i<=5;i++)
	{
		scanf("%lld",&b[i]);
		c[i]=b[i]*1.0/a[i];
	}
	for(i=1;i<=5;i++)
	{
		if(c[i]>=1)
		{
			x=x+b[i];
			y=y+a[i];
		}
	}
	if(y>=m)
	{
		y=y-k;
	}
	printf("%.2f",x*1.0/y);
	return 0;
}
