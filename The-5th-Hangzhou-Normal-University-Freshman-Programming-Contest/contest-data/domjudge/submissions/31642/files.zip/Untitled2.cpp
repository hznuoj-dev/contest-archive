#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a1[2000005],b[2000005],a2[2000005];
int main(){
#define int long long
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a1[i];
		a2[i]=-a1[i];
	}
	for(int i=0;i<n;i++){
		cin>>b[i];
	}
	sort(a1,a1+n);
	sort(a2,a2+n);
	sort(b,b+n);
	int f=0,g=0;
	for(int i=1;i<n;i++){
		if(a1[i]-b[i]!=a1[0]-b[0]){
			f++;
		}		
		if(a2[i]-b[i]!=a2[0]-b[0]){
			g++;	
		}
		if(f&&g)break;
	}
	int ans=-1;
	//cout<<f<<" "<<g<<endl;
	if(f&&g){
		cout<<"-1"<<endl;
		return 0;
	}
	if(f&&g==0){
		ans=abs(a2[0]-b[0])+1;
	}else if(g&&f==0){
		ans=abs(a1[0]-b[0]);
	}else{
		if(abs(a1[0]-b[0])<=abs(a2[0]-b[0])+1){
			ans=abs(a1[0]-b[0]);
		}else{
			ans=abs(a2[0]-b[0])+1;
		}
	//	cout<<abs(a1[0]-b[0])<<" "<<abs(a2[0]-b[0])<<endl;
	}
	cout<<ans<<endl;
	return 0;
}