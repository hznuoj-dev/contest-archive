#include<bits/stdc++.h>

using namespace std;
#define int long long 
using PII = pair<int, int>;
const int N = 2e5 + 5;
vector<PII>v[N];
int dis[N], vis[N];

void dfs(int x, int k){
	if(vis[x])return;
	vis[x] = 1;
	dis[x] = k;
	if(v[x].empty())return;
	for(auto i : v[x]){
		dfs(i.first, k ^ i.second);
	}
}

void solve(){
	int n;
	cin >> n;
	int x, y, z;
	int ans = 0;
	for(int i = 1; i < n; ++ i){
		cin >> x >> y >> z;
		v[x].push_back({y, z});
		v[y].push_back({x, z});
	}
	int q;cin >> q;
	dis[1] = 0;
	dfs(1, 0);
	for(int i = 1; i <= n; ++ i)ans ^= dis[i];
	while(q--){
		int x, val;
		cin >> x >> val;
		int kk = 0;
		if(n % 2 != 1)kk = ans;
		else kk =  ans ^ dis[x] ^ val;
		cout << kk << '\n';
	}
}

signed main(){
	ios::sync_with_stdio(0),cin.tie(0);
	int t = 1;
	//cin >> t;
	while(t--)solve();
	return 0;
}

/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5

*/
