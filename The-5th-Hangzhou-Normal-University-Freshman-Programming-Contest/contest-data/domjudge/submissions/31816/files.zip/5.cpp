#include<bits/stdc++.h>
using namespace std;
long long  n,m,k,a[1000000],p,num,ans;
int main()
{
	cin>>n>>m>>k;
	
	for(int  i=1;i<=n;i++)
	cin>>a[i];
	
	p=n;
	while(p>m)  p-=m;
	
	for(int  i=1;i<=n;i++)
	{
	  num+=a[i];
	  if(i==p)
	  {
	  	p+=m;
	  	if(num<=k)  ans+=num,num=0;
		else  num-=k,ans+=k; 
	  }
	}
	
	cout<<ans;
	return  0;
}
