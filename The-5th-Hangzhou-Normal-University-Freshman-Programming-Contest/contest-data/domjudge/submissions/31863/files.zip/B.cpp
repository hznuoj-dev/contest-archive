#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll n,a[200001],b[200001],ans=-1;
int main() {
	scanf("%lld",&n);
	for(ll i=1;i<=n;i++)scanf("%lld",a+i);
	for(ll i=1;i<=n;i++)scanf("%lld",b+i);
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	ll d1=b[1]-a[1],d2=b[1]+a[1];
	ll c1=abs(d1),c2=abs(d2)+1;
	for(ll i=1;i<=n;i++) {
		if(b[i]-a[i]!=d1)c1=-1;
		if(b[i]+a[i]!=d2)c2=-1;
	}
	if(c1!=-1&&c2!=-1)ans=min(c1,c2);
	else if(c1!=-1)ans=c1;
	else ans=c2;
	printf("%lld",ans);
}