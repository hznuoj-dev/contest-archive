#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
struct node {
	int t;
	int num;
};
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0), cout.tie(0);
	int T;
	//cin >> T;
	T = 1;
	while (T--)
	{
		int n, m, b, ans = 0;
		cin >> n >> m >> b;
		vector<int>s;
		for (int i = 0;i < n;i++)
		{
			int temp;
			cin >> temp;
			s.push_back(temp);
		}
		queue<node>q;
		int sum = 0;
		int sec = 0;
		int cnt;
		if(n%2)
		cnt = m-1;
		else
		cnt=m-2;
		for (int i = 0;i < n;i++)
		{
			cnt++;
			node temp;
			temp.num = s[i];
			temp.t = sec;
			sum += temp.num;
			q.push(temp);
			int p = b;
			if (cnt == m)
			{
				while (p && q.size())
				{
					if (q.front().num > p)
					{
						q.front().num -= p;
						sum -= p;
						ans += p;
						break;
					}
					else
					{
						p -= q.front().num;
						ans += q.front().num;
						sum -= q.front().num;
						q.pop();
					}
				}
				cnt = 0;
			}
			sec++;
			if (q.size() && sec - q.front().t == n)
				q.pop(), sum -= q.front().num;
		}
		cout << ans << endl;
	}
	return 0;
}