// #include<bits/stdc++.h>
#include <iostream>
#include <algorithm>
#include <set>
#include <map>
#include <stack>
#include <queue>
#include <string.h>
#include <string>
#include <math.h>

#define int long long

using namespace std;
const int N = 1e6 + 10;
float money[N];
float value[N];
int mj[6]={0};
void solve()
{
    float m, k;
    cin >> m >> k;
    for (int i = 1; i <= 5; i++)
    {
        cin >> money[i];
    }
    for (int i = 1; i <= 5; i++)
    {
        cin >> value[i];
    }
    float max=0;
    while(1){
        int time = 0;
        mj[1]++;
        if(mj[1]==2){
            int pos = 1;
            while(mj[pos]==2){
                mj[pos] = 0;
                mj[pos + 1]++;
                pos++;
            }
        }
//        for (int i = 1; i <= 5; i++)
//            cout << mj[i];
//        cout << endl;
        float mm=0, vv=0, res=0;
        for (int i = 1; i <= 5;i++){
            if(mj[i]==1){
                mm += money[i];
                vv += value[i];
                time++;
            }
        }
        if (mm >= m)
            mm -= k;
        res = vv / mm;
        if (res > max)
            max = res;
        if(time==5) break;
    }
    printf("%0.2f\n", max);
}
signed main()
{
    int t;
    t = 1;
    //    cin>>t;
    while (t--)
    {
        solve();
    }
    return 0;
}
