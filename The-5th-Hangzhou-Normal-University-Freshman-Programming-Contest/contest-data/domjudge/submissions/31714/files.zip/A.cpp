# include<stdio.h>
int max(int a[], int n)
{ 
    int max = 0;
	for (int i = 1; i <= n; i++)
	{
		if (a[i] >= max)
		max = a[i];
	}
	return max;
}

int min(int a[], int n)
{ 
    int min = 100000;
	for (int i = 1; i <= n; i++)
	{
		if (a[i] <= min)
		min = a[i];
	}
	return min;
}

int main()
{
	int n;
	scanf("%d", &n);
	int flag1 = 0;
	int flag2 = 0;
	int flag = 1;
	int a[200005];
	for (int i = 1; i <= n; i++)
	{
		scanf("%d", &a[i]);
	}
	int k, p, q;
	int count = 0, countk = 0;
	int temp1 = 0, temp2 = 0;
	p = max(a, n);
	q = min(a, n);
	for (int k = q; k <= p; k++)
	{
		for (int i = 2; i <= n; i++)
		{
			if (a[i] != a[1])
			flag = 0;
		}
		if (flag == 1)
		{
			countk = 1;
			break;
		}
		for (int i = 1; i <= n; i++)
		{
			if (a[i] < k)
			{
			flag1++;
			temp1 = 1;
			temp2 = 0;
		    }
			if (a[i] > k)
			{
			flag2++;
			temp1 = 0;
			temp2 = 1;
		    }
			if (flag1 == 1 && flag2 == 1 && temp1 == 0 && temp2 == 1)
			{
				count = 1;
				flag1 = 0;
				flag2 = 0;
			}
			else if (flag1 > 1 || flag2 > 1)
			{
				flag1 = flag2 = 0;
				count = 0;
				break;
			}
		}
		if (count > 0)
		countk++;
	}
	printf("%d\n", countk);
}
