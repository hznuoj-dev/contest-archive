#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int ll
const int N=2e5+7,mod=1e9+7;
int m,k,a[N],b[N];
void solve(){
	scanf("%d%d",&m,&k);
	for(int i=1;i<=5;i++)scanf("%d",&a[i]);
	for(int i=1;i<=5;i++)scanf("%d",&b[i]);
	double ans=0;
	for(int x=1;x<(1<<5);x++){
		int sum1=0,sum2=0;
		for(int i=0;i<5;i++){
			if(x&(1<<i)){
				sum1+=a[i+1];
				sum2+=b[i+1];
			}
		}
		if(sum1>=m)sum1-=k;
//		sum1=sum1-int(sum1/m)*k;
		ans=max(ans,sum2*1.0/sum1);
	}
	printf("%.2f",ans);
}
signed main(){
	int t=1;
//	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cin>>t;
	while(t--)solve();
	return 0;
}
