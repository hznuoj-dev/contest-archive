#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=200005;
ll kt1[M],kt2[M],r1[M],r2[M];
bool cmp(ll x,ll y){
	return x>y;
}
int main()
{
	bool flag1=true,flag2=true;
	ll n,INf=2e9+10,ans=INf;
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&kt1[i]);
	}
	for(int i=1;i<=n;i++)
	{
		scanf("%lld",&kt2[i]);
	}
	sort(kt1+1,kt1+n+1);
	sort(kt2+1,kt2+n+1);
	for(int i=2;i<=n;i++)
	{
		r1[i]=kt1[i]-kt1[i-1];
		r2[i]=kt2[i]-kt2[i-1];
	}
	for(int i=2;i<=n;i++)
	{
		if(r1[i]!=r2[i])
		{
			flag1=false;
		}
		if(r1[i]+r2[i]!=0)
		{
			flag2=false;
		}
	}
	if(flag1&&flag2)
	{
		ans=min(abs(kt2[1]-kt1[1]),abs(kt2[1]+kt1[1])+1);
	}
	else if(flag1)
	{
		ans=abs(kt2[1]-kt1[1]);
	}
	else
	{
		ans=(abs(kt2[1]+kt1[1])+1);
	}
	flag1=flag2=true;
	sort(kt1+1,kt1+n+1,cmp);
	for(int i=2;i<=n;i++)
	{
		r1[i]=kt1[i]-kt1[i-1];
	}
	for(int i=2;i<=n;i++)
	{
		if(r1[i]!=r2[i])
		{
			flag1=false;
		}
		if(r1[i]+r2[i]!=0)
		{
			flag2=false;
		}
	}
	if(flag1&&flag2)
	{
		ans=min(ans,min(abs(kt2[1]-kt1[1]),abs(kt2[1]+kt1[1])+1));
	}
	else if(flag1)
	{
		ans=min(ans,abs(kt2[1]-kt1[1]));
	}
	else
	{
		ans=min(abs(kt2[1]+kt1[1])+1,ans);
	}
	if(ans==INf)
	{
		printf("-1");
	}
	else
	{
		printf("%lld",ans);
	}
	return 0;
}