#include<bits/stdc++.h>
#define int long long
using namespace std;
const int maxn=10;
double a[10],b[10];
int m,k;
double ans;
signed main(){
	ios::sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	cin>>m>>k;
//	cout<<m<<' '<<k<<'\n';
	double sum1=0,sum2=0;
	for(int i=1;i<=5;i++)cin>>a[i],sum1+=a[i];
	for(int j=1;j<=5;j++)cin>>b[j],sum2+=b[j];
	for(int i=1;i<=5;i++){
		double d=a[i];
		if(d>=m)d-=k;
		ans=max(ans,b[i]/d);
		d=sum1-a[i];
		double s1=sum2-b[i];
		if(d>=m)d-=k;
		ans=max(ans,s1/d);
//		cout<<ans<<'\n';
	}
	for(int i=1;i<=5;i++){
		for(int j=i+1;j<=5;j++){
			double d=a[i]+a[j];
			double s1=b[i]+b[j];
			if(d>=m)d-=k;
			ans=max(ans,s1/d);
			d=sum1-a[i]-a[j];
			s1=sum2-b[i]-b[j];
			if(d>=m)d-=k;
			ans=max(ans,s1/d);
//			cout<<ans<<'\n';
		}
	}
	for(int i=1;i<=5;i++){
		for(int j=i+1;j<=5;j++){
			for(int kk=j+1;kk<=5;kk++){
				double d=a[i]+a[j]+a[kk];
				double s1=b[i]+b[j]+b[kk];
//				cout<<d<<' '<<s1<<' '<<ans<<'\n';
				if(d>=m)d=d-k;
				ans=max(ans,s1/d);
//				cout<<d<<' '<<s1<<' '<<ans<<'\n';
//				cout<<"--------\n";
			}
			
		}
	}
	cout<<fixed<<setprecision(2)<<ans;
	return 0;
}
/*
5 3
1 2 4 4 2
2 2 1 2 4
*/
