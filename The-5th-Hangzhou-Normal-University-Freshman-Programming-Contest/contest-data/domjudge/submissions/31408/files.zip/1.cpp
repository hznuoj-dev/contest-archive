#define _CRT_SECURE_NO_WARNINGS 1
#include<iostream>
#include<algorithm>
using namespace std;
int m, k, c[6];
double s, v, ans, a[6], b[6];
void dfs(int x, int y)
{
	if (x == 3)
	{
		double s1 = 0, v1 = 0, s2, v2;
		for (int i = 1; i <= 2; i++)
		{
			s1 += a[c[i]];
			v1 += b[c[i]];
		}
		s2 = s - s1;
		v2 = v - v1;
		if (s1 >= m)
			s1 -= k;
		ans = max(ans, v1 / s1);
		if (s2 >= m)
			s2 -= k;
		ans = max(ans, v2 / s2);
		return;
	}
	for (int i = y + 1; i <= 5; i++)
	{
		c[x] = i;
		dfs(x + 1, i);
	}
}
int main()
{
	cin >> m >> k;
	for (int i = 1; i <= 5; i++)
		cin >> a[i], s += a[i];
	for (int i = 1; i <= 5; i++)
		cin >> b[i], v += b[i];
	if (s >= m)
		ans = v / (s - k);
	else
		ans = v / s;
	dfs(1, 0);
	for (int i = 1; i <= 5; i++)
	{
		if (a[i] >= m)
			ans = max(ans, (b[i] / (a[i] - k)));
		else
			ans = max(ans, (b[i] / a[i]));
	}
	printf("%.2lf", ans);
	return 0;
}
