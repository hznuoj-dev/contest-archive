#include <iostream>
using namespace std;
int a[6];
int b[6];
int main(){
	int m, k;
	cin >> m >> k;
	double xing = 0;
	for (int i = 1; i <= 5; i++){
		cin >> a[i];
	}
	for (int i = 1; i <= 5; i++){
		cin >> b[i];
	}
	int money;
	int ping;
	money = a[1] + a[2] + a[3] + a[4] + a[5];
	ping = b[1] + b[2] + b[3] + b[4] + b[5];
	if (money >= m){
		money -= k;
	}
	if (xing < ping * 1.0 / money){
		xing = ping * 1.0 / money;
	}
	for (int i = 1; i <= 5; i++){
		money = a[i];
		ping = b[i];
		if (money >= m){
			money -= k;
		}
		double b1 = ping * 1.0 / money;
		if (xing < b1){
			xing = b1;
		}
	}
	for (int i = 1; i <= 4; i++){
		for (int j = i + 1; j <= 5; j++){
			money = a[i] + a[j];
			ping = b[i] + b[j];
			if (money > m){
				money -= k;
			}
			double b1 = ping * 1.0 / money;
			if (xing < b1){
				xing = b1;
			}
		}
	}
	for (int i = 1; i <= 3; i++){
		for (int j = i + 1; j <= 4; j++){
			for (int k1 = j + 1; k1 <= 5; k1++){
				money = a[i] + a[j] + a[k1];
				ping = b[i] + b[j] + b[k1];
				if (money >= m){
					money -= k;
				}
				double b1 = ping * 1.0 / money;
				if (xing < b1){
					xing = b1;
				}
			}
		}
	}
	for (int i = 1; i <= 2; i++){
		for (int j = i + 1; j <= 3; j++){
			for (int k1 = j + 1; k1 <= 4; k1++){
				for (int l = k1 + 1; l <= 5; l++){
					money = a[i] + a[j] + a[k1] + a[l];
					ping = b[i] + b[j] + b[k1] + b[l];
					if (money >= m){
						money -= k;
					}
					double b1 = ping * 1.0 / money;
					if (xing < b1){
						xing = b1;
					}
				}
			}
		}
	}
	printf("%.2lf", xing);
	return 0;
}
