#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn=2e5+7;
ll n;
ll a[maxn],b[maxn];
void solve(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b+1,b+1+n);
	if(n%2){
		ll ans=b[n/2+1];
			stack<char>st;
			for(int i=1;i<=n;i++){
				if(a[i]<ans){
					st.push('(');
				}else if(a[i]>ans){
					if(!st.empty()&&st.top()=='('){
						st.pop();
					}else{
						st.push(')');
					}
				}
			}
			if(st.empty())cout<<1;
			else cout<<0;
	}else{
		if(b[n/2+1]==b[n/2]){
			ll ans=b[n/2];
			stack<char>st;
			for(int i=1;i<=n;i++){
				if(a[i]<ans){
					st.push('(');
				}else if(a[i]>ans){
					if(!st.empty()&&st.top()=='('){
						st.pop();
					}else{
						st.push(')');
					}
				}
			}
			if(st.empty())cout<<1;
			else cout<<0;
		}else{
			ll ans=b[n/2]+1;
			stack<char>st;
			for(int i=1;i<=n;i++){
				if(a[i]<ans){
					st.push('(');
				}else if(a[i]>ans){
					if(!st.empty()&&st.top()=='('){
						st.pop();
					}else{
						st.push(')');
					}
				}
			}
			if(st.empty())cout<<b[n/2+1]-b[n/2]-1;
			else cout<<0;
		}
	}
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
	return 0;
}