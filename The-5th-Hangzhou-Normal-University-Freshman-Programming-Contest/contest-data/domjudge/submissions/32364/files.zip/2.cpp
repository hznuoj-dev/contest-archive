#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define N 200010

int n;
int a[N], mx = N * 2, mn = 0;

signed main() {
    cin >> n;
    for (int i = 1; i <= n; ++i) cin >> a[i];
    a[n + 1] = 0;
    for (int i = 1, last = 0, st = 1; i <= n + 1; ++i) {
        if (a[i] >= last) {
            last = a[i];
        } else {
            int l = (st + i - 1) / 2;
            int r = l + 1;
            if (a[l] != a[r]) {
                if ((i - st) % 2 != 0) {
                    mx = min(mx, a[l]);
                    mn = max(mn, a[l]);
                } else {
                    mx = min(mx, a[r] - 1);
                    mn = max(mn, a[l] + 1);
                }
            } else {
                int tmp = a[l];
                while (l >= st && a[l] == tmp) l--;
                while (r < i && a[r] == tmp) r++;
                if ((l - st + 1) == (i - r)) {
                    mx = min(mx, tmp);
                    mn = max(mn, tmp);
                } else {
                    cout << 0;
                    return 0;
                }
            }
            last = a[i];
            st = i;
        }
    }
    cout << max(0, mx - mn + 1);
}