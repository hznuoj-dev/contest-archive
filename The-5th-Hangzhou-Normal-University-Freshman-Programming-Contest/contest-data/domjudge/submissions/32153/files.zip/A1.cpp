#include <bits/stdc++.h>
using namespace std;
#define int long long
const int inf=0x3f3f3f3f;

int a[200200];
int b[200200];
int n;

bool check(int x) {
	stack<char> stk;
	for (int i=1; i<=n; ++i) {
		if (a[i]<x)
			stk.push('(');
		else if (a[i]>x) {
			if (!stk.empty()&&stk.top()=='(') {
				stk.pop();
			} else {
				return false;
			}
		}
	}
	if (stk.empty()) {
		return true;
	} else {
		return false;
	}
}

void solve() {
	cin>>n;
	int maxn=-inf,minn=inf;
	for (int i=1; i<=n; ++i) {
		cin>>a[i];
		maxn=max(maxn,a[i]);
		minn=min(minn,a[i]); 
	}

	int l=1,r=maxn;

	while (!check(l)) {
		++l;
		if (l>r) {
			cout<<"0\n";
			return;
		}
	}
	while (!check(r)) {
		--r;
		if (l>r) {
			cout<<"0\n";
			return;
		}
	}
	cout<<r-l+1<<'\n';

}
//    ((()())())
//    4
//    4 10 5 10

//	  4
//    1 4 4 10
signed main() {
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);

	int tt=1;
//	cin>>tt;
	while (tt--) solve();

	return 0;
}
