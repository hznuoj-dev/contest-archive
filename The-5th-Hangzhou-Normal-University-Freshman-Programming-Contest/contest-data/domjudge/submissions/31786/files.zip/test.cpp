#include<iostream>
#include<algorithm>
using namespace std;
const int maxn=2e5+10;
long long n,a[maxn],m,b,pre[maxn],ans,res[maxn];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin>>n>>m>>b;
    for(int i=1;i<=n;i++)   cin>>a[i];
    for(int i=1;i<=n;i++)   pre[i]=pre[i-1]+a[i];
    res[1]=a[1];
    int pos=1;
    int tmp=1;
    for(int i=1+m;i<=n;i++){
        if((i-1)%m==0){
            res[++pos]=pre[i]-pre[i-m];
            tmp=i;
        }  
    }
    if(tmp!=n){
        res[pos]+=pre[n]-pre[tmp];
        
    }
    for(int i=1;i<=pos;i++){
        if(res[i]>b){
            ans+=b;
            res[i]-=b;
            res[i+1]+=res[i];
        }
        else    ans+=res[i];
    }
    cout<<ans;
}