#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const int N = 2e5 + 10, mod = 1e9 + 7;
#define endl "\n"
typedef pair <int, int> PII;
struct node{
    int x, y;
}r[N];
int a[N];
bool cmp1(node a, node b){
    return a.x > b.x;
}
bool cmp2(int a, int b){
    return a > b;
}
void solve(){
    priority_queue <int, vector <int>, greater <int>> pq;
    int num, ans = 0;
    cin >> num;
    for (int i = 1; i <= num; i ++)cin >> a[i];
    pq.push(a[1]);
    int minn = a[1];
    for (int i = 2; i <= num; i ++){
        if (pq.size() && a[i] >= pq.top()){
            pq.pop();
        }
        else if (pq.empty() || a[i] < pq.top())pq.push(a[i]);
    }
    sort(a + 1, a + num + 1);
    if (num % 2){
        if (num == 1){
            cout << 1 << endl;
            return;
        }
        if (pq.size() == 1){
            int k = max(minn, a[num / 2]);
            ans = a[num / 2 + 2] - k - 1;
            if (ans <= 0)ans = 0;
            else ans = 1;
            cout << ans << endl;
        }
        else cout << 0 << endl;
        return;
    }
    else{
        if (pq.size())cout << 0 << endl;
        else{
            int k = max(minn, a[num / 2]);
            if (k == a[num / 2 + 1])ans = 1;
            else ans = a[num / 2 + 1] - k - 1;
            if (ans <= 0)ans = 0;
            cout << ans << endl;
        }
    }
}
signed main(){
    //ios::sync_with_stdio(false);
    //cin.tie(0);cout.tie(0);
    int q;
    cin >> q;
    //q = 1;
    while (q --){
        solve();
    }
    return 0;
}