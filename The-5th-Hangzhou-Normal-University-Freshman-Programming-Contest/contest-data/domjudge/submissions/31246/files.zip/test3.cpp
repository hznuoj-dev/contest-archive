#include<bits/stdc++.h>
using namespace std;
#define int long long
#define endl '\n'
vector<pair<int, int>>s(5);
int vis[5];
int m, k;
double maxx = 0;
void dfs(int v, int pr, int step)
{
	if (step == 5)
	{
		int v1=v, pr1=pr;
		if (pr1 >= m)
			pr1 -= k;
		maxx = max(maxx, (double)((double)v1 / (double)pr1));
		return;
	}
	else
	{
		vis[step] = 1;
		dfs(v + s[step].second, pr + s[step].first, step + 1);
		vis[step] = 0;
		dfs(v, pr, step + 1);
	}
}
signed main()
{
	// ios::sync_with_stdio(false);
	// cin.tie(0), cout.tie(0);
	int t;
	//cin >> t;
	t = 1;
	while (t--)
	{
		cin >> m >> k;
		for (int i = 0;i < 5;i++)
		{
			cin >> s[i].first;
		}
		for (int i = 0;i < 5;i++)
		{
			cin >> s[i].second;
		}
		dfs(0, 0, 0);
		printf("%.2lf", maxx);
	}
	return 0;
}