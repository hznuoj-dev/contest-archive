#include <bits/stdc++.h>

using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr)
#define rep(a, b, c) for(int (a)=(b);(a)<=(c);(a)++)
#define per(a, b, c) for(int (a)=(b);(a)>=(c);(a)--)
#define mset(var, val) memset(var,val,sizeof(var))
#define ll long long
#define int ll
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pb push_back
#define endl "\n"
#define pii pair<int,int>
#define pll pair<ll,ll>
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 2e5 + 5;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const int mod = 1e9 + 7;
const double eps = 1e-8;
const double pi = acos(-1.0);

int a[N];

pii dp[N];

void solve() {
    int n,m,b,pre=0;
    cin>>n>>m>>b;
    rep(i,1,n){
    	cin>>a[i];
	}
	rep(i,1,m){
		dp[i].se=pre+a[i];
		if(dp[i].se>=b){
			dp[i].fi=b,dp[i].se-=b;
		}else{
			dp[i].fi=dp[i].se,dp[i].se=0;
		}
		if(dp[i].fi<dp[i-1].fi){
			dp[i].fi=dp[i-1].fi,dp[i].se=dp[i-1].se+a[i];
		}
		pre+=a[i];
	}
	rep(i,m+1,n){
		dp[i].se=pre+a[i]-dp[i-m].fi;
		if(dp[i].se>=b){
			dp[i].fi=dp[i-m].fi+b,dp[i].se-=b;
		}else{
			dp[i].fi=dp[i-m].fi+dp[i].se,dp[i].se=0;
		}
		if(dp[i].fi<dp[i-1].fi){
			dp[i].fi=dp[i-1].fi,dp[i].se=dp[i-1].se+a[i];
		}
		pre+=a[i];
	}
	cout<<dp[n].fi<<endl;
}
/*
5 2 10
5 9 3 1 8
6 2 10
20 1 1 1 1 5
*/

signed main() {
    IOS;
    int t = 1;
    // cin >> t;
    while (t--) {
        solve();
    }
    return 0;
}
