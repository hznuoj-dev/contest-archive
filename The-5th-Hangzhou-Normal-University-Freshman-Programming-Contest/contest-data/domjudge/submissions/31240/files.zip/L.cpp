#include<iostream>
#include<string>
#include<algorithm>
#include<cstring>
#include<map>
#include<vector>
#include<cmath>
#include<iomanip>
#define ll long long
#define IOS ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
#define rep(a,b,c) for (int a = b; a <= c; a++)
#define drep(a,b,c) for (int a = b; a >= c; a--)
using namespace std;
int m,k,a[10],v[10],f[10];
double ans;
void dfs(int x,double y,double z){
    if (x==6){
        if (y>=m) y=y-k;
        ans=max(ans,z/y);
        return;
    }
    rep(i,1,5){
        if (!f[i]){
            f[i]=1;
            dfs(x+1,y+a[i],z+v[i]);
            f[i]=0;
            dfs(x+1,y,z);
        }
    }
}
int main(){
    cin>>m>>k;
    rep(i,1,5){
        cin>>a[i];
    }
    rep(i,1,5){
        cin>>v[i];
    }
    dfs(1,0,0);
    cout<<setiosflags(ios::fixed)<<setprecision(2)<<ans<<endl;
}