#include <bits/stdc++.h>
#define ll long long
using namespace std;
double ans = 0.0;
ll a[10], b[10];
int m, k;
void dfs(int pos, ll ans1, ll ans2) {
	if (pos > 5) {
		if (ans1 >= m) ans1 -= k;
		ans1 = max(ans1, 0ll);
		if (!ans1) return;
		double res = (double)ans2 / ans1;
		ans = max(res, ans);
		return;
	}
	//cout << "?" << endl;
	dfs(pos + 1, ans1 + a[pos], ans2 + b[pos]);
	dfs(pos + 1, ans1, ans2);
	return;
}
int main () {
	cin >> m >> k;
	for (int i = 1; i <= 5; i++) cin >> a[i];
	for (int i = 1; i <= 5; i++) cin >> b[i];
	//cout << b[4];
	dfs(1, 0, 0);
	printf("%.2lf", ans);
	
}
