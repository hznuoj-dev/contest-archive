
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
const int N=1010;
vector<pr<int,int> >G[N];
int n,ans;
int ask(int u,int v){
    printf("? %d %d\n",u,v);
    fflush(stdout);
    int res;scanf("%d",&res);return res;
}
bool flg;
void dfs(int u,int fa){
    vector<pr<int,int> >sset;
    int i;
    for(auto v:G[u])if(v.fi!=fa)sset.push_back(v);
    int sz=sset.size();
    for(i=0;i<=sz-1;i+=2){
        if(i+1<=sz-1){
            if(ask(sset[i].fi,sset[i+1].fi)){
                if(ask(sset[i].fi,u)){
                    ans=sset[i].se;
                }else ans=sset[i+1].se;
                flg=1;return;
            }
        }else{
            if(ask(sset[i].fi,u)){
                flg=1;ans=sset[i].se;
                return;
            }
        }
    }
    for(auto v:sset){
        dfs(v.fi,u);if(flg)return;
    }
}
int main(){
    int T,i,j;scanf("%d",&T);
    while(T--){
        scanf("%d",&n);
        rep(i,1,n-1){
            int x,y;scanf("%d%d",&x,&y);
            G[x].push_back(mkp(y,i));
            G[y].push_back(mkp(x,i));
        }
        flg=0;
        dfs(1,0);
        printf("! %d\n",ans);fflush(stdout);
    }
}