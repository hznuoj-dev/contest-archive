#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int n,a[200001],b[200001];
int main() {
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i],b[i]=a[i];
	sort(b+1,b+1+n);
	int cnt=0,k=b[n/2+1];
	if(n%2==0)k=k+b[n/2]>>1;
	for(int i=1;i<=n;i++) {
		if(a[i]<k)cnt++;
		else if(a[i]>k)cnt--;
		if(cnt<0) {
			printf("0");
			return 0;
		}
	}
	if(cnt!=0) {
		printf("0");
		return 0;
	}
	for(ll i=1;i<=200000;i++) {
		ll l=lower_bound(b+1,b+n+1,i)-b;
		l--;
		ll r=lower_bound(b+1,b+n+1,i+1)-b;
		if(l+r==n+1)cnt++;
	}
	cout<<cnt;
}