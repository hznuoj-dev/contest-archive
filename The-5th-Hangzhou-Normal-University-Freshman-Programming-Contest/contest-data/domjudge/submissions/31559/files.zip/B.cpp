#include<bits/stdc++.h>
#include <set>
using namespace std;
int main()
{
	int n;
	cin >> n;
	multiset<int> a, b;
	int x;
	for(int i=0; i<n; i++)
	{
		cin >> x;
		a.insert(x);
	}
	for(int i=0; i<n; i++)
	{
		cin >> x;
		b.insert(x);
	}
	
	multiset<int>::iterator c = a.begin(), d = b.begin();
	int judg[2]={0,0};
	int p,q;
	for(int i=1; i<n; i++)
	{
		p = *c;
		p-=*(++c);
		q = *d;
		q-=*(++d);
		if(p!= q)
		{
			judg[0]++;
			break;
		}
	}
	multiset<int>::iterator e = a.begin(), f = b.end();
	f--;
	for(int i=1; i<n; i++)
	{
		p = *e;
		p-=*(++e);
		q = -*f;
		q+=*(--f);
		if(p != q)
		{
			judg[1]++;
			break;
		}
	}
//	cout << judg[0] << endl;
//	cout << judg[1] << endl;
	if(judg[0]==1&&judg[1]==1)
	{
		cout << -1 << endl;
	}
	int zheng, fan, temp;
	multiset<int>::iterator it = a.begin(), id = b.begin(), ir = b.end();
	ir --;
	if(judg[0]!=1&&judg[1]!=1)
	{
		zheng = abs(*it - *id);
		fan = abs(*it - (-(*ir))) + 1;
		if(zheng>fan)
		{
			cout << fan << endl;
		}
		else
		{
			cout << zheng << endl;
		}
	}
	if(judg[0]==1&&judg[1]!=1)
	{
		fan = abs(*it - (-(*ir))) + 1;
		cout << fan << endl;
	}
	if(judg[0]==1&&judg[1]!=1)
	{
		zheng = abs(*it - *id);
		cout << zheng << endl;
	}	
	return 0;
}
