#include<bits/stdc++.h>
using namespace std;
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
const int N = 1e5 + 10;
typedef long long ll;
void solve() {
	int n;
	cin >> n;
	vector<int> a(n), b(n);
	for(int i = 0; i < n; i++) cin >> a[i];
	for(int i = 0; i < n; i++) cin >> b[i];
	sort(a.begin(), a.end());
	sort(b.begin(), b.end());
	bool f1 = true, f2 = true;
	for(int i = 1; i < n; i++) {
		if(a[i] - b[i] != a[i - 1] - b[i - 1]) {
			f1 = false;
		}
		if(a[i] + b[n - 1 - i] != a[i - 1] + b[n - i]) {
			f2 = false;
		}
	}
	if(!f1 && !f2) cout << -1 << "\n";
	else {
		ll ans = 0;
		if(f1 && !f2) {
			ans += abs(a[0] - b[0]);
		}
		else if(!f1 && f2) {
			ans += abs(a[0] + b[n - 1]) + 1;
		}
		else if(abs(a[0] + b[n - 1]) >= abs(a[0] - b[0])) ans += abs(a[0] - b[0]);
		else ans += abs(a[0] + b[n - 1]) + 1;
		cout << ans << "\n";
	}
}
int main()
{
	IOS
	int T = 1;
	// cin >> T;
	while(T--) solve();
	return 0;
}