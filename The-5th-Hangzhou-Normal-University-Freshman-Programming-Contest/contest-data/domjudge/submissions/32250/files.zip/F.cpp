#include<bits/stdc++.h>
#define int long long 
using namespace std;

const int N = 2e5 + 5;
int yh[N];
int vis[N];
struct edge {
	int v, w;
};
vector<edge> g[N];

void solve() {
	int n;
	cin >> n;
	for(int i = 1; i < n; i++) {
		int u, v, w;
		cin >> u >> v >> w;
		g[u].push_back({v, w});
		g[v].push_back({u, w});
	}
	
	for(int i = 1; i <= n; i++) {
		vis[i] = 1;
		for(auto ed : g[i]) {
			if(vis[ed.v]) continue;
			yh[ed.v] = yh[i] ^ ed.w;
		}
	}
	int k = 0;
	for(int i = 1; i <= n; i++) k ^= yh[i];
//	cout << k << endl;
	int q;
	cin >> q;
	while(q--){
		int u, x;
		cin >> u >> x;
		if(u != 1){
			x ^= yh[u];
		}
		int ans = k;
		if(n % 2) ans ^= x;
		cout << ans << endl;
	}
	
}
signed main() {
	ios::sync_with_stdio(0);

	int test = 1;
//	cin >> test;
	while(test--) {
		solve();
	}

	return 0;
}
/*
6
1 2 1
1 3 2
3 4 3
3 5 4
3 6 5
2
1 2
3 5
*/
