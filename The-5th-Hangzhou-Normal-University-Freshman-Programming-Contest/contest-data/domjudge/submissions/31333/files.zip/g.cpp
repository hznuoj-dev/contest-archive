#include <bits/stdc++.h>
#define fp(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fb(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define go(u, i) for(int i = head[u]; i; i = e[i].nxt)
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
inline int rd() {
	register int x(0), f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline LL RD() {
	register LL x(0); register int f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline int int_rand(int l, int r){
	int res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
inline LL LL_rand(LL l, LL r){
	LL res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
const int maxn = 200010;
int n, m, k, a[maxn];
int main(){
	n = rd(), m = rd(), k = rd();
	fp(i, 1, n)a[i] = rd();
	long long sum = 0, ans = 0;
	fp(i, 1, n){
		sum += a[i];
		if(i%m == n%m)ans += min((LL)k, sum), sum = max(0ll, sum-k);
	}
	printf("%lld\n", ans);
	return 0;
}
