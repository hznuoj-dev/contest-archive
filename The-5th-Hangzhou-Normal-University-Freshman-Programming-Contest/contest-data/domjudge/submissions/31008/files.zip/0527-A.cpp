#include<bits/stdc++.h>
#define close std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
typedef long long ll;
const ll MAXN = 3e5+7;
const ll mod = 1e9+7;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
#define int long long
ll _power(ll a,int b){ ll ans=1,res=a;while(b){ if(b&1) ans=ans*res%mod;res=res*res%mod;b>>=1;} return ans%mod;}
void solve(){
	int n;cin>>n;
	map<int,int> sz;
	for(int i=1;i<=n;i++){
		int  a;cin>>a;
		sz[a]++;
	}
	int start=0,end=0;
	int sum=0;
	for(auto it:sz){
		sum+=it.second;
			if(start==0&&sum*2==n){
				start=it.first;
			}
			else if(start!=0&&end==0) end=it.first;
			
			if(start==0&&(sum-it.second)*2==(n-it.second)){
				start=it.first;
				end=start;
			}
	}
	if(start==0) cout<<"0\n";
	else if(start==end) cout<<"1\n";
	else cout<<end-start-1<<"\n";
}
signed main(){
	solve();
}