#include<bits/stdc++.h>

using namespace std;

#define int long long
#define endl '\n'
#define IOS ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);

const int N = 10;
const int M = 1e9+7;
const int INF = 0x3f3f3f3f;

int gcd(int a,int b){
	return (b==0)?a:gcd(b,a%b);
}

int lcm(int a,int b){
	return a*b/gcd(a,b);
}

struct node{
	int a,b,c;
}s[N];

bool cmp(node a,node b){
	return a.c>b.c;
}

void solve(){
	int m,k;
	cin>>m>>k;
	
	int n=5;
	
	for(int i=1;i<=n;i++){
		cin>>s[i].a;
	}
	
	for(int i=1;i<=n;i++){
		cin>>s[i].b;
		s[i].c=s[i].b-s[i].a;
	}
	
	sort(s+1,s+1+n,cmp);
	
	int ans=-INF,cnt1=0,cnt2=0;
	bool ok=1;
	for(int i=1;i<=n;i++){
		cnt1+=s[i].a;
		cnt2+=s[i].b;
		
		if(cnt1>=m && ok){
			cnt1-=k;
			ok=0;
		}
		
		ans=max(ans,cnt2/cnt1);
	}
	
	printf("%.2lf\n",(double)ans);
}

signed main(){
	IOS;
	
	int t;
	t=1;
	//cin>>t;
	
	while(t--){
		solve();
	}
	
	return 0;
}
