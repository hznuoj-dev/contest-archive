#include<iostream>
#include<cmath>
using namespace std;

//B
const int N=2e5+7;
typedef long long ll;
ll a[N],b[N];
ll dir[N],cg[N];

int main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++)cin>>b[i];
	for(int i=1;i<=n;i++){
		dir[i]=a[i]-b[i];
		cg[i]=a[i]+b[i];
	}
	bool flagdir=true,flagcg=true;
	for(int i=1;i<=n;i++){
		if(dir[i]!=dir[1])flagdir=false;
		if(cg[i]!=cg[1])flagcg=false;
	}
		if(dir[1]<0)dir[1]=-dir[1];
		if(cg[1]<0)cg[1]=-cg[1];
	if(flagdir&&flagcg){
		cout<<min(dir[1],cg[1]+1);
	}else if(flagdir){
		cout<<dir[1];
	}else if(flagcg){
		cout<<cg[1]+1;
	}else{
		cout<<-1;
	}
}


/*

3
1 1 2
2 2 1

3
1 2 3
4 5 6

3
-1 -2 -3
4 5 6

4
1 1 1 1
-1 -1 -1 -1


1
1000000000
-1000000000

1
100000000
-1

*/
