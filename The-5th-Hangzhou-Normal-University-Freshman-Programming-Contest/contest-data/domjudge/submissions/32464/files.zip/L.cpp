#include <bits/stdc++.h>
using namespace std;
#define fastio ios::sync_with_stdio(false);cin.tie(0); cout.tie(0)
typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e6 + 5;

ll read(){
    int x=0,f=1;
    char c=getchar();
    while(c<'0'||c>'9'){
        if(c=='-')f=-1;
        c=getchar();
    }
    while(c>='0'&&c<='9'){
        x=(x<<3)+(x<<1)+(c^48);
        c=getchar();
    }
    return x;
}

ll a[200005];

signed main() {
    fastio;
    ll n=read(),q,h,k=0;
    for(int i=0;i<n;i++){
        a[i]=read();
    }
    q=a[0],h=a[n-1];
    for(int i=q;i<=h;i++){
        ll flag=0,c=1;
        for(int j=0;j<n;j++){
            if(a[j]<i){
                flag++;
            }
            else if(a[j]>i){
                flag--;
            }
            if(flag<0){
                c=0;
                break;
            }
        }
        if(flag==0&&c==1)k++;
    }
    printf("%lld",k);
    system("pause");
}