#define _CRT_SECURE_NO_WARNINGS 1
#include<bits/stdc++.h>
#define ios  ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
typedef long long LL;
const LL MAXN = 2e5+10;
const int Inf = 0x7fffffff;
const LL INF = 0x3f3f3f3f3f3f3f3f;
using namespace std;
int n;
int a[MAXN];
int b[MAXN];
bool pd(int k)
{
	stack<bool> sta;
	for(int i=1;i<=n;++i)
	{
		if(a[i]<k)
			sta.push(false);
		if(a[i]>k)
		{
			if(sta.empty()==true)
				sta.push(true);
			else
			{
				if(sta.top()==false)
					sta.pop();
				else
					return false;
			}
		}
	}
	if(sta.empty()==true)
		return true;
	else
		return false;
}
int works()
{
	int ans=0;
	int m=n/2;
	map<int,int> maps;
	for(int i=1;i<=n;++i)
		b[i]=a[i];
	sort(b+1,b+n+1);
	for(int i=1;i<=n;++i)
	{
		if(pd(a[i])==true && maps[a[i]]==0)
		{
			ans++;
			maps[a[i]]++;
		}
	}
	if(b[m+1]-b[m]>=2)
	{
		if(pd(b[m]+1)==true && pd(b[m+1]-1)==true)
			ans+=(b[m+1]-b[m]-1);
	}
	return ans;
}
int main()
{
	ios;
	cin>>n;
	for(int i=1;i<=n;++i)
		cin>>a[i];
	cout<<works();
	//system("pause");
	return 0;
}