#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int long long
const ll N=5e5+7;
const ll mod=1e9+7;
const ll inf=0x3f3f3f3f;
const ll INF=0x3f3f3f3f3f3f3f3f;
const double eps=1e-6;
struct node
{
	int a,b;
	
}moon[10];
bool cmp(node aa,node bb)
{
	if(aa.b!=bb.b)return aa.b>bb.b;
	else return aa.a< bb.a;
}
void solve()
{
    int m,k;
    cin>>m>>k;
    for(int i=0;i<5;i++)
    {
    	cin>>moon[i].a;
	}
	for(int i=0;i<5;i++)
	{
		cin>>moon[i].b;
	}
	sort(moon,moon+5,cmp);
	double ans=-1;
	double pj=0.0,jg=0.0;
	for(int i=0;i<5;i++)
	{
		pj+=(double)moon[i].b;
		jg+=(double)moon[i].a;
		if(jg>=m) ans=max(pj/(jg-1.0*k),ans);
		else ans=max(pj/jg,ans);
	}
	cout<<fixed<<setprecision(2)<<ans;
}
signed main()
{
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int _=1;
//	cin>>_;
	while(_--)
	{
		solve();
	}
	return 0;
}

