﻿#include<bits/stdc++.h>
using namespace std;
const int N=2e5+9;
#define ll long long
int a[N],n,m,b;
int main()
{
    cin>>n>>m>>b;
    for(int i=1;i<=n;i++) cin>>a[i];
    ll now=0,pre=-100,ans=0;
    int cnt=(n+m-1)/m;
    for(int i=1;i<=n;i++)
    {
        now+=a[i];
        if(n-i+1<=(cnt-1)*m+1)
        {
            ans+=min(now,1ll*b);
            now=max(0ll,now-b);
            pre=i;
            for(int j=i+1;j<=n;j++)
            {
                now+=a[j];
                if(j-pre==m)
                {
                    pre=j;
                    ans+=min(now,1ll*b);
                    now=max(0ll,now-b);
                }
            }
            break;
        }
        if(now<b||i-pre<m) continue;
        ans+=b;now-=b;
        pre=i;
        cnt--;
    }
    printf("%lld",ans);
    return 0;
}