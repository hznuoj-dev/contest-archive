#include<iostream>
#include<algorithm>
using namespace std;
#define int long long
const int N = 2e5 + 5;
int n, m, b, a[N], sum[N], ans;
signed main()
{
	cin >> n >> m >> b;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		sum[i] = sum[i - 1] + a[i];
	}
	int c = 0, t = -m;
	for (int i = 1; i <= n - n / m * m; i++)
	{
		c += a[i];
		if (i - t >= m)
		{
			if (c >= b)
			{
				c -= b;
				ans += b;
				t = i;
			}
		}
	}
	if (!ans)
	{
		ans = c;
		t = n - n / m * m;
		c = 0;
	}
	for (int i = n - n / m * m+1; i <= n; i++)
	{
		c += a[i];
		if (i - t >= m)
		{
			if (c >= b)
			{
				c -= b, ans += b;
				if (i >= m && sum[i] - sum[i - m] >= b && i-m>=t+m)
				{
					c += b;
					ans += c - (sum[i] - sum[i - m]);
					c = c - (c - (sum[i] - sum[i - m])) - b;
				}
				t = i;
			}
			else if (i == n)
				ans += c, c = 0, t = n;
		}
	}
	cout << ans << endl;
	return 0;
}
