#include <bits/stdc++.h>
using namespace std;
#define int long long
signed main()
{
	ios::sync_with_stdio(false);cin.tie(0);
	int n,m,b;cin>>n>>m>>b;
	int a[n+5]={};
	int sum[n+5]={};
	for(int i=1;i<=n;i++)cin>>a[i];
	for(int i=1;i<=n;i++)sum[i]=sum[i-1]+a[i];
	int num=0;
	int mx=0;
	for(int i=1;i<=m;i++)
	{
		int ans=0;
		num=0;
		for(int j=i;j<=n;j+=m)
		{
			int pre=max(j-m,(int)0);
			num+=sum[j]-sum[pre];
			ans+=min(num,b);
			num-=b;
			if(num<0)num=0;
		}
		mx=max(mx,ans);
	}
	cout<<mx;
	return 0;
}
