#include<bits/stdc++.h>
using namespace std;
int main()
{
    int a[6],b[6],c[6];
    int m,k,i,wor,pay,i1,i2,i3;
    cin >> m >> k;
    for(i=0;i<5;i++) cin >> a[i];
    for(i=0;i<5;i++) cin >> b[i];
    double res,js;
    for(i=0;i<5;i++)
    {
        pay=a[i];
        wor=b[i];
        if(pay>=m)
        pay-=k;
        if(i==0)
        {res=wor*1.0/pay;}
        else
        {
            js=wor*1.0/pay;
            if(js>res)
            res=js;
        }
    }
    for(i=0;i<4;i++)
    {
        for(i1=i+1;i1<5;i1++)
        {
            pay=a[i]+a[i1];
            wor=b[i]+b[i1];
            if(pay>=m)
            pay-=k;
            js=wor*1.0/pay;
            if(js>res)
            res=js;
        }
    }
    for(i=0;i<3;i++)
    {
        for(i1=i+1;i1<4;i1++)
        {
            for(i2=i1+1;i2<5;i2++)
            {
                pay=a[i]+a[i1]+a[i2];
                wor=b[i]+b[i1]+b[i2];
                if(pay>=m)
                pay-=k;
                js=wor*1.0/pay;
                if(js>res)
                res=js;
            }
        }
    }
    for(i=0;i<2;i++)
    {
        for(i1=i+1;i1<3;i1++)
        {
            for(i2=i1+1;i2<4;i2++)
            {
                for(i3=i2+1;i3<5;i3++)
                {
                    pay=a[i]+a[i1]+a[i2]+a[i3];
                    wor=b[i]+b[i1]+b[i2]+a[i3];
                    if(pay>=m)
                    pay-=k;
                    js=wor*1.0/pay;
                    if(js>res)
                    res=js;
                }
            }
        }
    }
    pay=a[0]+a[1]+a[2]+a[3]+a[4];
    wor=b[0]+b[1]+b[2]+b[3]+b[4];
    if(pay>=m)
    pay-=k;
    js=wor*1.0/pay;
    if(js>res)
    res=js;
    printf("%.2lf",res);
    return 0;
}