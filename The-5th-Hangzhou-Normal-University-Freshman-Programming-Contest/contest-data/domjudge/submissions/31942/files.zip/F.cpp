#include <bits/stdc++.h>
using namespace std;

typedef long long LL;
typedef unsigned long long ULL;
//typedef __int128 LLL;

int read() {
    int x = 0, f = 1; char c = getchar();
    while(c < '0' || c > '9') c == '-' ? f = -1: 0, c = getchar();
	while(c >= '0' && c <= '9') x = (x << 1) + (x << 3) + (c ^ '0'), c = getchar();
    return x * f;
}

vector<pair<int, int>> e[200050];
int sum, a[200050];

void add(int u, int v, int w) {
    e[u].push_back({v, w});
}

void dfs(int u, int x, int fa) {
    sum ^= x, a[u] = x;
    for(auto p : e[u]) {
        int v = p.first, w = p.second;
        if(v == fa) continue;
        dfs(v, x ^ w, u);
    }
}

signed main() {
    int n = read();
    for(int i = 1; i <= n - 1; ++i) {
        int u = read(), v = read(), w = read();
        add(u, v, w), add(v, u, w);
    }
    dfs(1, 0, 0);
    
    int q = read();
    while(q--) {
        int u = read(), x = read();
        if(n & 1) printf("%d\n", sum ^ x ^ a[u]);
        else printf("%d\n", sum);
    }
    
    return 0;
}

