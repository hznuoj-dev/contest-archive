#include<bits/stdc++.h>
using namespace std;
#define int long long

int a[200010], b[200010], d1[200010], d2[200010];

void run() {
	int n;
	int jud1 = 1, jud2 = 1;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> a[i];
	}
	sort(a, a + n);
	for (int i = 0; i < n; i++) {
		cin >> b[i];
	}
	sort(b, b + n);
	for (int i = 0; i < n; i++) {
		d1[i] = a[i] - b[i];
		d2[i] = a[i] + b[n - i - 1];
	}
	for (int i = 1; i < n; i++) {
		if (d1[i] != d1[i - 1]) {
			jud1 = 0;
			break;
		}
	}
	for (int i = 1; i < n; i++) {
		if (d2[i] != d2[i - 1]) {
			jud2 = 0;
			break;
		}
	}
	if (!jud1 && !jud2) {
		cout << "-1\n";
	} else if (jud1 && jud2) {
		cout << min(abs(d1[0]), abs(d2[0]) + 1) << "\n";
	} else if (jud1) {
		cout << abs(d1[0]) << "\n";
	} else {
		cout << abs(d2[0]) + 1 << "\n";
	}
	return;
}

signed main() {
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int T = 1;
//	cin >> T;
	while (T--) {
		run();
	}
	return 0;
}
