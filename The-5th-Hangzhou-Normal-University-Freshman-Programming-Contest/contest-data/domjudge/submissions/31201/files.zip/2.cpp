#include<bits/stdc++.h>
using namespace std;
const int N=10;
int m,k;
double ans;
struct node
{
	int a,b;
	double p;
}A[N];
void dfs(int id,int suma,int sumb)
{
	if(id==6)
	{
		if(suma==0)return;
		if(suma>=m)ans=max(ans,((double)sumb)/(suma-k));
		else ans=max(ans,((double)sumb)/suma);
		return;
	}
	dfs(id+1,suma+A[id].a,sumb+A[id].b);
	dfs(id+1,suma,sumb);
}
int main()
{
	scanf("%d%d",&m,&k);
	for(int i=1;i<=5;++i)scanf("%d",&A[i].a);
	for(int i=1;i<=5;++i)scanf("%d",&A[i].b),A[i].p=((double)A[i].b)/A[i].a;
	dfs(1,0,0);
	printf("%.2lf\n",ans);
	return 0;
}
