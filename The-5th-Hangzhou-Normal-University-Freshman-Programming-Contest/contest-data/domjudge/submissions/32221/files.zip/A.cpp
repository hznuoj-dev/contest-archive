#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define fi first
#define se second
#define pii pair<int,int>
#define pb push_back
const int N = 2E5 + 10;

void solve() {
	int n; cin >> n;
	
	vector<int> a(n + 1);
	for (int i = 1; i <= n; i++) cin >> a[i];
	
	if (a[1] == a[n]) {
		queue<int> q;
		for (int i = 1; i <= n; i++) {
			if (a[i] < a[1]) {
				q.push(i);
			}else if (a[i] > a[1]){
				if (q.size() == 0) {
					cout << "0\n";
					return;
				}
				q.pop();
			}
		}
		if (q.size() != 0) {
			cout << "0\n";
		}else {
			cout << 1 << endl;
		} 
	}else {
		int l = a[1] + 1, r = a[n] - 1;
		for (int i = 2; i < n; i++) {
			if (a[i] <= a[i + 1]) {
				l = max(l, a[i]);
				r = min(r, a[i + 1]);
			}
		}
		queue<int> q;
		int f = 1;
		for (int i = 1; i <= n; i++) {
			if (a[i] < l) {
				q.push(i);
			}else if (a[i] > l){
				if (q.size() == 0) {
					f = 0;
					break;
				}
				q.pop();
			}
		}
		if (!f || q.size()) l++;
 		while (q.size()) q.pop();
		
		f = 1;
		for (int i = 1; i <= n; i++) {
			if (a[i] < r) {
				q.push(i);
			}else if (a[i] > r){
				if (q.size() == 0) {
					f = 0;
					break;
				}
				q.pop();
			}
		}		
		if (!f || q.size()) r--;
		cout << max(0, r - l + 1) << endl;
	}
	
	
	
}

/*
4
4 10 5 10
4 
1 4 4 10

4
1 4 5 10

*/
int main() {
	ios::sync_with_stdio(0); cout.tie(0); cin.tie(0);

	int T = 1;

	while(T--) solve();

	return 0;
}

