#include<bits/stdc++.h>
using namespace std;

const int N = 1e6;
int a[N], n;
vector<int> s;

bool check(int num)
{
	int bin = 0;
	for(int i = 1; i <= n; ++i)
	{
		if(a[i] < num)
		{
			++bin;
		}
		else if(a[i] > num)
		{
			--bin;
		}
		
		if(bin < 0)
		{
			return false;
		}
	}
	
	if(bin == 0)
	{
		return true;
	}
	
	return false;
}

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	int mi = 1e9, ma = -1;
	cin >> n;
	for(int i = 1; i <= n; ++i) 
	{
		cin >> a[i];
		if(mi >= a[i] - 1) mi = a[i];
		if(ma <= a[i] + 1) ma = a[i];
	}
	
	if(mi + 1 == ma)
	{
		cout << "0";
		return 0;
	}
	
	int l = 100, r = -100;
	
	for(int i = mi; i <= ma; ++i)
	{
		if(check(i))
		{
			l = i;
			break;
		}
	}
	for(int i = ma; i >= mi; --i)
	{
		if(check(i))
		{
			r = i;
			break;
		}
	}
	
	cout << max(r - l + 1, 0);
}

/*
4
4 4 4 5

*/
