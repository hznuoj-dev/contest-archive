#include <bits/stdc++.h>
using namespace std;
const int N = 15;
struct Bis{
	int pri;
	int val;
}a[N];

bool cmp(Bis x, Bis y) {
	if(x.val == y.val) {
		return x.pri > y.pri;
	}
	return x.val < y.val;
}

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int m, k;
	cin >> m >> k;
	for(int i = 1; i <= 5; i++) {
		cin >> a[i].pri;
	}
	for(int i = 1; i <= 5; i++) {
		cin >> a[i].val;
	}
	sort(a + 1, a + 1 + 5, cmp);
	double maxn = 0.0, maxs = 0.0;
	int cost = 0, tval = 0;
	for(int i = 5; i >= 1; i--) {
		int scost = a[i].pri, sval = a[i].val;
		cost += a[i].pri;
		if(cost % m == 0) {
			cost -= k;
		}
		tval += a[i].val;
		if(tval * 1.0 / cost > maxn) {
			maxn = tval * 1.0 / cost;
		}
		if(sval * 1.0 / scost > maxs) {
			maxs = tval * 1.0 / cost;
		}
	}
	if(maxs > maxn) {
		maxn = maxs;
	}
	printf("%.2f", maxn);
	return 0;
}
