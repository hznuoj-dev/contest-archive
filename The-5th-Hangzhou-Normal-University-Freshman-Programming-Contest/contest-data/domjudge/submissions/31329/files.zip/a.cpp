#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
int a[maxn],num[maxn];
void solve(){
	int n;
	cin>>n;
	int res1,res2;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		num[a[i]]++;
	}
	res1=a[1];
	res2=a[n];
	sort(a+1,a+1+n);
	if(num[a[1]]==n){
		cout<<1<<"\n";
		return;
	}
	int ans=0;
	if(n%2==0){
		int midl=n/2,midr=n/2+1;
		if(a[midl]==a[midr]){
			int flag1=lower_bound(a+1,a+1+n,a[midl])-a-1;
			int flag2=upper_bound(a+1,a+1+n,a[midl])-a;
			flag2=n-flag2+1;
			//cout<<flag1<<" "<<flag2<<"?\n";
			if(flag1==flag2){
				if(a[midl]>res1 || a[midl]<res2){
					cout<<0<<"\n";
					return;
				}
				cout<<1<<"\n";
				return;
			}
			else{
				cout<<0<<"\n";
				return;
			}
		}
		else{
			cout<<a[midr]-a[midl]-1<<"\n";
			return;
		}
	}
	else{
		int mid=(n+1)/2;
		if(a[mid]>res1 || a[mid]<res2){
			cout<<0<<"\n";
			return;
		}
		int flag1=lower_bound(a+1,a+1+n,a[mid])-a;
		int flag2=upper_bound(a+1,a+1+n,a[mid])-a-1;
		int flag=flag2-flag1+1;
		if(flag%2){
			cout<<1<<"\n";
		} 
		else{
			cout<<0<<"\n";
		}
		return;
	}
}
int main(){
	ios::sync_with_stdio(false);
	int T=1;
	//cin>>T;
	while(T--) solve();
}
