#include <iostream>
#include <algorithm>
#include <cmath>

using namespace std;

typedef long long LL;

const int N = 200010;

int n;
LL a[N], b[N];

int main()
{
    cin >> n;
    for (int i = 0; i < n; i ++ ) cin >> a[i];
    for (int i = 0; i < n; i ++ ) cin >> b[i];
    sort(a, a + n);
    sort(b, b + n);

    LL cnt = b[0] - a[0], res = 0x3f3f3f; // ab�Ĳ�
    bool pd = true; // �жϵ�һ��
    int flag = 1; // �жϵڶ���
    for (int i = 1; i < n; i ++ )
    {
        if (b[i] - a[i] != cnt)
        {
            pd = false;
            break;
        }
    }
    if (pd == true) res = min(res, abs(b[0] - a[0]));
    // elseif (flag == 0)
    // {
        cnt = b[0] + a[n - 1];
        for (int i = 1; i < n; i ++ )
        {
            if (b[i] + a[n - i - 1] != cnt)
            {
                flag = 0;
                break;
            }
        }
        if (flag == 1) res = min(res, abs(cnt) + 1);
        if (pd == false && flag == 0) cout << -1;
        else
        {
           cout << res;
        } 
    // }
    return 0;
}