#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    int n;
    cin >> n;
    int a[n+1] = {0};
    int ans = 0;
    set<int> st;
    for(int i = 1; i <= n; ++i){
        cin >> a[i];
        st.insert(a[i]);
    }
    sort(a+1, a+n+1);
    if(st.size() == 1){
        cout << 0 << endl;
        return 0;
    }
    if(n % 2 == 0){
        if(a[n/2+1] == a[n/2]){
            int l = n / 2, r = n / 2 + 1;
            while(a[l] == a[r]){
                l--;
                r++;
                if(l < 2)
                  break;
            }
            if(a[l] != a[r] && a[l] != a[n / 2] && a[r] != a[n / 2 + 1])
               cout << 1 << endl;
            else
               cout << 0 << endl;
        }
        else
            cout << a[n/2+1] - a[n/2]  - 1 << endl;
    }else{
       int l = n / 2, r = n / 2 + 2;
            while(a[l] == a[r]){
                 l--;
                 r++;
                 if(l <= 1)
                    break;
            }
            if(a[l] != a[r] && a[l] != a[n / 2 + 1] && a[r] != a[n / 2 + 1])
               cout << 1 << endl;
            else
               cout << 0 << endl;
    }
    return 0;
}