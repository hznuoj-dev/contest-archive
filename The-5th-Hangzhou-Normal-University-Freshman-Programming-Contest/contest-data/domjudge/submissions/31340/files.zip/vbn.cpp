# include<bits/stdc++.h>
# include<cstdio>
using namespace std;
#define ll long long 
int qfjj(ll a[],ll b[],ll n){
	int k = -b[n-1]-a[0];
	int p=1;
	for(int i=1;i<=n-1;i++){
		if(-b[n-1-i]-a[i]!=k){
			p=0;
			break;
		}
	}
	return p;
}
int jj(ll a[],ll b[],ll n){
	int k = a[0]-b[0];
	int p=1;
	for(int i=1;i<=n-1;i++){
		if(a[i]-b[i]!=k){
			p=0;
			break;
		}
	}
	return p;
}
int main(){
	ll n,mind = 0;
	int p=0,q=0;
	cin>>n;
	ll a[n],b[n];
	for(int i=0;i<n;i++) cin>>a[i];
	for(int i=0;i<n;i++) cin>>b[i];
	if(qfjj(a,b,n)){
		p=1;
		mind = 1+abs(-b[n-1]-a[0]);
	}
	if(jj(a,b,n)){
		q=1;
		mind=min(mind,abs(a[0]-b[0]));
	}
	if(p||q) cout<<mind;
	else cout<<-1;
	return 0;
}
