#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define fi first
#define se second
#define pii pair<int,int>
#define pb push_back
const int N = 2E5 + 10;

void solve() {
	int n; cin >> n;
	
	vector<int> a(n + 1);
	for (int i = 1; i <= n; i++) cin >> a[i];

	int l, r;
	for (int i = 1; i <= n; i++) {
		int p = 1;
		while (1) {
			if (i + p * 2 - 1 > n) break;
			int f = 1;
			for (int j = 1; j <= p; j++) {
				if (a[i + j - 1] >= a[i + p * 2 - j]) {
					if (j == p && a[i + j - 1] == a[i + p * 2 - j]) continue;
					f = 0;
					break;
				} 
			}
			if (!f) break;
			p++;
		}
		p--;
		if (p == 0) {
			cout << 0 << endl;
			return;
		}
		l = max(l, a[i + p - 1]);
		r = min(r, a[i + p]);
		i += p * 2 - 1;
//		cout << i << ' ' << l << ' ' << r << ' ' << p << endl;
	}
	
	if (l == r) {
		cout << 1 << endl;
	}else 
		cout << max(0, r - l - 1);
	
	
	
}

/*
4
4 10 5 10
4 
1 4 4 10

4
1 4 5 10

*/
int main() {
	ios::sync_with_stdio(0); cout.tie(0); cin.tie(0);

	int T = 1;

	while(T--) solve();

	return 0;
}

