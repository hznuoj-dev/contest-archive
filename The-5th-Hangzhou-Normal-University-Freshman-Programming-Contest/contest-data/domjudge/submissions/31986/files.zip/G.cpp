#include <iostream>
#include <algorithm>
#include <cmath>
#include <iomanip>
using namespace std;
const int N=2e5+10;
int a[N];
int main(void){
	int n,m,b;
	cin>>n>>m>>b;
	int sum=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum+=a[i];
	}
	if((n+1)%m==0){
		int ans=0,ts=0;
		for(int i=1;i<=n;i++){
			ts+=a[i];
			if((i+1)%m==0){
				if(ts<b){
					ans+=ts;
					ts=0;
				} else {
					ans+=b;
					ts-=b;
				}
			}
		}
		cout<<ans;
	} else {
		int ans=1;
		ans+=(n-1)/m;
		cout<<min(ans*b,sum);
	}
	return 0;
}	