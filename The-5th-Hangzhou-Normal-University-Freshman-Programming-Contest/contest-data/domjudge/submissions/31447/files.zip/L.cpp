#include<bits/stdc++.h>
#define ll long long
#define rr read()
using namespace std;
const int N=5e5+5;
int a[N],b[N],s[N];
int n,k,m;
double ans;
int read()
{
    char ch=getchar(); int x=0,g=0;
    while (ch<'0'||ch>'9') g|=ch=='-',ch=getchar();
    while (ch>='0'&&ch<='9') x=x*10+(ch^48),ch=getchar();
    return g? -x:x;
}

void dfs(int dep,int A,int B)
{
//	printf("dep=%d %d %d\n",dep,A,B);
	if (dep==6){
		if (!A) return;
		double val;
		if (A>=m) val=(double)B/(A-k);
		else val=(double)B/A;
	//	printf("%d %d %lf\n",A,B,val);
		ans=val>ans? val:ans;
		return;
	}
	dfs(dep+1,A+a[dep],B+b[dep]);
	dfs(dep+1,A,B);
}
int main()
{
	m=rr, k=rr;
	for (int i=1;i<=5;++i)
	{
		a[i]=rr;
	}
	for (int i=1;i<=5;++i)
	{
		b[i]=rr;
	}
	dfs(1,0,0);
	printf("%.2lf",ans);
	return 0;
}