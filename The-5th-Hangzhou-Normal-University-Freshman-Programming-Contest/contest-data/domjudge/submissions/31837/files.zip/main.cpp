#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;
const int N = 2e5 + 3;
const int P = 1e9 + 7;

int e[N * 2], ne[N * 2], w[N * 2], h[N], idx;
void add(int a, int b, int c) {
    e[idx] = b, ne[idx] = h[a], w[idx] = c, h[a] = idx++;
}
int res[N];

void dfs(int t, int f) {
    for(int i = h[t];~i;i = ne[i]) {
        int j = e[i];
        if(j == f) continue;
        res[j] = res[t] ^ w[i];
        dfs(j, t);
    }
}
void solve() {
    int n;
    std::cin >> n;
    memset(h, -1, sizeof h);
    for(int i = 1;i < n;i++) {
        int u, v, c;
        std::cin >> u >> v >> c;
        add(u, v, c);
        add(v, u ,c);
    }
    dfs(1, 0);
//    std::vector<ll>pow2(40, 1);
//    for(int i = 1;i < 40;i++) pow2[i] = pow2[i - 1] * 2;
//    std::vector<ll>num(40);
//    for(int i = 0;i < 40;i++) {
//        for(int j = 1;j <= n;j++) {
//            if((res[j] >> i) & 1) {
//                num[i]++;
//            }
//        }
//    }
    ll tot = 0;
    for(int i = 1;i <= n;i++) tot ^= res[i];
    int q;
    std::cin >> q;
    while(q--) {
        int u, x;
        std::cin >> u >> x;
        if(n & 1) std::cout << (tot ^ x) << '\n';
        else std::cout << tot << '\n';
//        int bh = res[u] ^ x;
//        for(int i = 0;i < 40;i++) {
//            if((bh >> i) & 1) {
//                ans += (n - num[i]) * pow2[i];
//            } else {
//                ans += num[i] * pow2[i];
//            }
//        }
    }
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    int T = 1;
    //std::cin >> T;
    while(T--) {
        solve();
    }
}