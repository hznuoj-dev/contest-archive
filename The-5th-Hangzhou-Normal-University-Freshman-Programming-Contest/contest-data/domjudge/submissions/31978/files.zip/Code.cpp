#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 3e5+7,inf = 1e18+7;
typedef long long ll;

int a[N],b[N];
int n;

bool check(string s){
	stack<char>p;
	int k = s.size();
	for (int i = 0; i < k; i++){
		if (s[i] == '('){
			p.push(s[i]);
		}else{
			if (p.empty()){
				return false;
			}else{
				p.pop();
			}
		}
	}
	if (!p.empty()) return false;
	return true;
}

bool check(int x){
	string s = "";
	for (int i = 1; i <= n; i++){
		if (b[i] < x){
			s += '(';
		}else if (b[i] > x){
			s += ')';
		}
	}
	return check(s);
}

void solve(){
	cin >> n;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
		b[i] = a[i];
	}
	if (n % 2){
		cout << 0 << '\n';
		return;
	}
	sort(a + 1,a + 1 + n);
	int l = a[n / 2],r = a[n / 2 + 1];
	bool f1 = false,f2 = false,f3 = false;
	if (l == r){
		f1 = check(l);
		if (f1){
			cout << 1 << '\n';
			return;
		}else{
			cout << 0 << '\n';
		}
	}else{
		f1 = check(l);
		f2 = check(l + 1);
		f3 = check(r);
		int ans = 0;
		if (f2){
			ans += r - l - 1;			
		}
		if (f1) ans++;
		if (f3) ans++;
		cout << ans << '\n';
	}
	

	
}

signed main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc = 1;
//	cin >> tc;
	while (tc--){
		solve();
	}
	return 0;
}
