#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define ll long long

using namespace std;

const int N = 2e5+5;
ll n,a[N],b[N];

void judge(){
	bool f1,f2;
	f1 = f2 = true;
	ll temp = a[0]-b[0];
	for(int i=1;i<n;i++){
		if(a[i]-b[i]!=temp){
			f1 = false;
			break;
		}
	}
	temp = a[0]+b[n-1];
	for(int i=1;i<n;i++){
		if(a[i]+b[n-i-1]!=temp){
			f2 = false;
			break;
		}
	}
	if(f1&&f2){
		cout << min(labs(a[0]-b[0]),labs(a[0]+b[n-1])+1) << endl;
	}else if(f1){
		cout << labs(a[0]-b[0]) << endl;
	}else if(f2){
		cout << labs(a[0]+b[n-1])+1 << endl;
	}else {
		cout << -1 << endl;
	}
	
}
int main(){
	IOS
	cin >> n;
	for(int i=0;i<n;i++)cin >> a[i];
	for(int i=0;i<n;i++)cin >> b[i];
	sort(a,a+n);
	sort(b,b+n);	
	judge();
	
	
	
	
	return 0;
} 
