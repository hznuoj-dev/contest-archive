#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N = 2e5+10;
double a[10];
double b[10];
struct s
{
    double a,b;
}p[10];
signed main()
{
    double m,k;
    double xjb=-1;
    double sum1,sum2;
    cin >> m >> k;
    for(int i=0;i<5;i++)
    {
        cin >> a[i];
        sum1+=a[i];
    }
    for(int i=0;i<5;i++)
    {
        p[i].a=a[i];
        cin >> b[i];
        sum2+=b[i];
        p[i].b=b[i];
        if(p[i].a>=m) xjb=max(xjb,p[i].b/(p[i].a-k));
        else xjb=max(xjb,p[i].b/p[i].a);
    }
    // printf("%.2lf\n",xjb);
    if(sum1>=m) xjb=max(xjb,sum2/(sum1-k));
    else xjb=max(xjb,sum2/sum1);
    // printf("%.2lf\n",xjb);
    for(int i=0;i<5;i++)
    {
        if(sum1-a[i]>=m) xjb=max(xjb,(sum2-p[i].b)/(sum1-a[i]-k));
        else xjb=max(xjb,(sum2-p[i].b)/(sum1-a[i]));
    }
    // printf("%.2lf\n",xjb);
    for(int i=0;i<5;i++)
    {
        for(int j=i+1;j<5;j++)
        {
            if(sum1-a[i]-a[j]>=m) xjb=max(xjb,(sum2-p[i].b-p[j].b)/(sum1-a[i]-a[j]-k));
            else xjb=max(xjb,(sum2-p[i].b-p[j].b)/(sum1-a[i]-a[j]));
        }
    }
    // printf("%.2lf\n",xjb);
    for(int i=0;i<5;i++)
    {
        for(int j=i+1;j<5;j++)
        {
            if(a[i]+a[j]>=m) xjb=max(xjb,(a[i]+a[j])/(a[i]+a[j]-k));
            else xjb=max(xjb,(a[i]+a[j])/(a[i]+a[j]));
        }
    }
    printf("%.2lf\n",xjb);
    return 0;
}