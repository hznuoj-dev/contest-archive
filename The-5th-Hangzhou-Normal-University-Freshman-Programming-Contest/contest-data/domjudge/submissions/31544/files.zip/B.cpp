#include<bits/stdc++.h>
#define rg register
#define il inline
typedef long long ll;
using namespace std;
ll mod = 1e9+7;
inline ll read() {
	ll ans = 0;
	char last = ' ', ch = getchar();
	while (ch < '0' || ch > '9') last = ch, ch = getchar();
	while (ch >= '0' && ch <= '9') ans = ans * 10 + ch - '0', ch = getchar();
	if (last == '-') return -ans;
	return ans;
}
il ll ksm(ll b,ll k){
	ll res=1;
	while(k){
		if(k&1) res=1ll*res*b%mod;
		b=1ll*b*b%mod;k>>=1;
	}
	return res;
}
int a[500050];
int b[500050];
int c[500050];
int n;
int solve(int *a,int *b){
	for(int i=1;i<=n-1;i++){
		if(a[i]-a[i+1]!=b[i]-b[i+1])return 0x3f3f3f3f;
	}
	return abs(a[1]-b[1]);
}
bool cmp(int a,int b){
	return a>b;
}
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	} 
	for(int i=1;i<=n;i++){
		cin>>b[i];
		c[i]=-b[i];
	}
	int ans=0x3f3f3f3f;
	ans=min(ans,solve(a,b));
	sort(a+1,a+n+1);
	sort(b+1,b+n+1);
	ans=min(ans,solve(a,b)+1);
	sort(b+1,b+n+1,cmp);
	ans=min(ans,solve(a,b)+1);
	ans=min(ans,solve(a,c)+1);
	sort(c+1,c+n+1);
	ans=min(ans,solve(a,c)+2);
	sort(c+1,c+n+1,cmp);
	ans=min(ans,solve(a,c)+2);	
	if(ans>=0x3f3f3f3f)puts("-1");
	else cout<<ans<<endl;
}

