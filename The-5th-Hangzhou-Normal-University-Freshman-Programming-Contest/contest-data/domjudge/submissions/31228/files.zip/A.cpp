#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int main()
{
    int n;
    cin >> n;
    int a[n+1] = {0};
    int ans = 0;
    map<int, int> mp;
    set<int> st;
    for(int i = 1; i <= n; ++i){
        cin >> a[i];
        ans++;
        mp[a[i]]++;
        st.insert(a[i]);
    }
    int minx = 200008;
    sort(a+1, a+n+1);
    if(st.size() == 1){
        cout << 0 << endl;
        return 0;
    }
    //4 4 4 6 6 10 10 10
    //6
    if(n % 2 == 0){
        if(a[n/2+1] == a[n/2]){
            if(a[n/2-1] == a[n/2] || a[n/2+2] == a[n/2+1])
               cout << 0 << endl;
            else
               cout << 1 << endl;
        }
        else
            cout << a[n/2+1] - a[n/2]  - 1 << endl;
    }else{
        //1 4 4 4 4 9 10
        //1 2 4 4 4 4 10 10 10
       if(a[n/2+2] != a[n/2])
          cout << min(a[n/2+2] - a[n/2] - 1, 0)<< endl;
       else if(a[n/2+2] == a[n/2]){
             if(a[n/2+1] == a[n/2-1] || a[n/2+3] == a[n/2+1])
                  cout << 0 << endl;
             else
                 cout << 1 << endl;
       }
    }
    return 0;
}