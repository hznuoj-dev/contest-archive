#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll maxn = 2e5 + 10;
const ll minn = 1e9 + 7;
const double eps = 1e-6;
const int INFTY = (1<<21);

int gcd(int a, int b) {return b ? gcd(b, a % b) : a;}
int lcm(int a, int b) {return a * b / gcd(a, b);}

ll n,m,b;
ll a[maxn];

int main()
{
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cin>>n>>m>>b;
    for(ll i=1;i<=n;i++)
    {
        std::cin>>a[i];
    }
    ll num=0;//此时的人数
    ll Num=0;//放行的总人数
    ll time=m;
    ll ans=1;
    if(n==((n-1)/m)*m+1)
    {
        for(ll i=1;i<=((n-1)/m)*m+1;i++)
        {
            num=num+a[i];
            if(time==m)
            {
                ans=1;
            }
            if(ans==1)
            {
                Num=Num+min(num,b);
                ans=0;
                num=num-min(num,b);
                time=1;
            }
            else if(ans==0)
            {
                time++;
            }
        }
    }
    else 
    {
        ll zhongzhi=0;
        if(1)
        {
            for(ll i=1;i<=((n-1)/m)*m+1-1;i++)
            {
            num=num+a[i];
            if(time==m)
            {
                ans=1;
            }
            if(ans==1)
            {
                Num=Num+min(num,b);
                ans=0;
                num=num-min(num,b);
                time=1;
            }
            else if(ans==0)
            {
                time++;
            }
            }
            for(ll i=((n-1)/m)*m+1;i<=n;i++)
            {
            num=num+a[i];
            }
            Num=Num+min(num,b);
            zhongzhi=Num;
            Num=0;
            num=0;
            time=1;
            ans=1;
        }
        if(2)
        {
            for(ll i=1;i<=n;i++)
            {
                num=num+a[i];
                if(time==m)
                {
                    ans=1;
                }
                if(num>=b&&ans==1)
                {
                    Num=Num+min(num,b);
                    num=num-min(num,b);
                    ans=0;
                    time=1;
                }
                if(ans==0)
                {
                    time++;
                }
            }
        }
        Num=max(Num,zhongzhi);
    }
    std::cout<<Num<<endl;
    return 0;
}