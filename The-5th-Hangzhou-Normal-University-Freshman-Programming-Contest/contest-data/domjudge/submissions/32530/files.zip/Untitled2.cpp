#include<bits/stdc++.h>
using namespace std;
#define ll long long
int a[2000005],fa[2000005];
int find(int x){
	if(x==fa[x])return x;
	return fa[x]=find(fa[x]);
}
void m(int x,int y){
	int fx=find(x);
	int fy=find(y);
	fa[fx]=fy;
}
map<int,int>mp,mp1;
//vector<pair<int,int> >v;
int main(){
	int n,k;
	cin>>n>>k;
	int f=0;
	for(int i=1;i<=n;i++){
		fa[i]=i;
	}
	for(int i=1;i<=n;i++){
		cin>>a[i];
		
		if(a[i]==i){
			f++;
		}else{
			m(a[i],i);
		}
	}
	
	if(k==n-1){
		cout<<-1<<endl;
		return 0;
	}
	if(f>=k){
		if(f!=n)cout<<f-k<<endl;
		else if(f==n){
			if(k==n){
				cout<<0<<endl;
			}else
			cout<<f-k-1<<endl;
		}
	}else{
		int ans=0;
		for(int i=1;i<=n;i++)find(i);
		for(int i=1;i<=n;i++){
			if(find(i)!=i){
				mp[find(i)]++;
			}
		}
		int w=k-f;
		for(auto it=mp.begin();it!=mp.end();it++){
			mp1[it->second+1]++;
		}
		for(auto it=mp1.begin();it!=mp1.end();it++){
			if(w-((it->first)*(it->second))>=0){
				w-=((it->first)*(it->second));
				ans+=((it->first-1)*(it->second));
			}else {
				int temp=w/(it->first);
				w-=temp*(it->first);
				ans+=temp*(it->first-1);
				if(mp1.upper_bound(w+1)!=mp1.end()){
					ans+=w;
					w-=w;
				}else{
					ans+=w+1;
					w-=w;
				}
			}
			if(!w)break;
		}
		cout<<ans<<endl;
	}
	return 0;
}
/*
10 7
2 3 4 5 6 7 8 9 10 1
1 2 3 5 4 8 7 6 10 9
*/