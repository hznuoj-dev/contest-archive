#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[200001]={0},b[200001]={0},c[200001]={0},da[200001]={0},db[200001]={0},dc[200001]={0};
int main() {
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int fb1=0,fb2=0,fc1=0,fc2=0;
	int n;
	cin>>n;
	for(int i=1;i<=n;i++) 
		cin>>a[i];
	for(int i=1;i<=n;i++) 
		cin>>b[i],c[i]=-b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	for(int i=2;i<=n;i++) {
		da[i]=a[i]-a[i-1],db[i]=b[i]-b[i-1],dc[i]=c[i]-c[i-1];
		//cout<<a[i]<<' '<<b[i]<<' '<<da[i]<<' '<<db[i]<<'\n';//
		if(da[i]==db[i])fb1++;
		if(da[i]==dc[i])fc1++;
		if(da[i]+db[i]==0)fb2++;
		if(da[i]+dc[i]==0)fc2++;
	}
	ll cntb1=0,cntc1=1,cntb2=0,cntc2=1;
	priority_queue<ll,vector<ll>,greater<ll> >ans;
	if(fb1==n-1)cntb1+=abs(b[1]-a[1]),ans.push(cntb1);
	if(fb2==n-1)cntb2+=abs(b[1]+a[1]),ans.push(cntb2);
	if(fc1==n-1)cntc1+=abs(c[1]-a[1]),ans.push(cntc1);
	if(fc2==n-1)cntc2+=abs(c[1]+a[1]),ans.push(cntc2);
	if(ans.empty())cout<<-1;
	else cout<<ans.top();
}