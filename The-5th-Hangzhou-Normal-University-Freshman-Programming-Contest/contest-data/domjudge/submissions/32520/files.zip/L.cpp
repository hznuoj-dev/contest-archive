#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
struct y {
	double a,b;
}e[404];
bool cmp(y i1,y i2) {
	if(i1.b/i1.a!=i2.b/i2.a)return i1.b/i1.a>i2.b/i2.a;
	return i1.a>i2.a;
}
double ans=0;
int main() {
	int m,k;
	scanf("%d%d",&m,&k);
	for(int i=1;i<=5;i++)scanf("%lf",&e[i].a);
	for(int i=1;i<=5;i++)scanf("%lf",&e[i].b);
	sort(e+1,e+6,cmp);
	double son=0,mother=0;
	double mm;
	for(int i=1;i<=5;i++) {
		son+=e[i].b,mother+=e[i].a;
		//d=min(mother/m,1);
		mm=mother;
		int d=(int)mother/m;
		mm-=d*k;
		ans=max(ans,son/mm);
	}
	printf("%.2f",ans);
}