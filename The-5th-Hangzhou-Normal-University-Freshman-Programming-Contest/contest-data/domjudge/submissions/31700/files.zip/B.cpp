#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;
int main(){
	int n;
	cin>>n;
	int count=0;
	vector<int> all(n),final(n);
	for(int i=0;i<n;i++){
		cin>>all[i];
	}
	for(int i=0;i<n;i++){
		cin>>final[i];
	}
	sort(all.begin(),all.end());
	sort(final.begin(),final.end());
	int flag=1;
	int sign=all[0]-final[0];
	for(int i=1;i<n;i++){
		if(all[i]-final[i]!=sign){
			flag=0;
			break;
		}
	}
	if(flag==0){
		count++;
		reverse(all.begin(),all.end());
		for(int i=0;i<n;i++){
			all[i]=-all[i];
		}
		flag=1;
		sign=all[0]-final[0];
		for(int i=1;i<n;i++){
			if(all[i]-final[i]!=sign){
				flag=0;
				break;
			}
		}
	}
	if(flag){
		count += abs(sign);
		cout<<count;
	}
	else{
		cout<<-1;
	}
	return 0;
}
