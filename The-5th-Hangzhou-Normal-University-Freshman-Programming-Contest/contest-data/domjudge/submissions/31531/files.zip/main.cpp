
#include <bits/stdc++.h>
using namespace std;
#define rep(i,j,k) for(i=j;i<=k;++i)
#define dow(i,j,k) for(i=j;i>=k;--i)
#define pr pair
#define mkp make_pair
#define fi first
#define se second
const int N=5e5+10;
vector<pr<int,int> >G[N];
int n,q,ans[N],d[N],sum=0;
vector<pr<int,int> >ask[N];
void dfs0(int u,int fa){
    for(auto v:G[u])if(v.fi!=fa){
        d[v.fi]=d[u]^v.se;
        dfs0(v.fi,u);
    }
}
void dfs(int u,int fa){
    for(auto v:ask[u]){
        if(n&1)ans[v.se]=v.fi^sum;else ans[v.se]=sum;
    }
    for(auto v:G[u])if(v.fi!=fa){
        if(n&1)sum^=v.se;
        dfs(v.fi,u);
    }
}
int main(){
    scanf("%d",&n);int i;
    rep(i,2,n){
        int x,y,w;scanf("%d%d%d",&x,&y,&w);
        G[x].push_back(mkp(y,w));G[y].push_back(mkp(x,w));
    }
    scanf("%d",&q);
    rep(i,1,q){
        int u,x;scanf("%d%d",&u,&x);ask[u].push_back(mkp(x,i));
    }
    dfs0(1,0);
    rep(i,1,n)sum^=d[i];
    dfs(1,0);
    rep(i,1,q)printf("%d\n",ans[i]);
}