/*
 * @Author: JSY
 * @Date: 2023-05-27 14:58:04
 * @Last Modified by: JSY
 * @Last Modified time: 2023-05-27 14:58:04
*/

#include<bits/stdc++.h>
using namespace std;
#define int long long
#define PII pair<int, int>
#define IOS ios::sync_with_stdio(0);cin.tie(0), cout.tie(0)
const int N = 1000010 , mod = 1e9+7;
int n,m,k;
vector<int> v[N];
int ru[N];
int d[N];
int jie[N];
int sum[N];

void dfs(int x){
    for(int i=0;i<v[x].size();i++){
        int t = v[x][i];
        if(d[t] < d[x] + 1){
            d[t] = d[x] + 1;
            dfs(t);
        }
    }
    return ;
}

int qmi(int a,int k){
    int res = 1;
    while(k){
        if(k & 1) res = res * a % mod;
        k >>= 1;
        a = a % mod * a % mod;
    }
    return res;
}

signed main(){
    IOS;
    cin >> n >> m >> k;
    while(m--){
        int a,b;
        cin >> a >> b;
        v[a].push_back(b);
        ru[b] ++;
    }
    int root = 0;
    for(int i=1;i<=n;i++){
        if(ru[i] == 0){
            root = i;
            break;
        }
    }
    d[root] = 1;
    dfs(root);
    int ma = 0;
    for(int i=1;i<=n;i++){
        jie[d[i]] = (jie[d[i]] + 1) % mod;
        ma = max(ma , d[i]);
    }
    for(int i=ma-1;i>=1;i--){
        sum[i] = (sum[i+1] + jie[i+1]) % mod;
    }
    int ans = 0;
    for(int i=1;i<ma;i++){
        ans = (ans + jie[i] * sum[i] % mod) % mod;
    }
    int res = qmi(ans,k);
    cout << res;
    return 0;
}