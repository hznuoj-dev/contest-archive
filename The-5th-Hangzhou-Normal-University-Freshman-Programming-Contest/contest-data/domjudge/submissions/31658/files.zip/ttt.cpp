#include <iostream>
#include <string>
#include <cstring>
#include <queue>
#include <math.h>
#include <algorithm>
using ll = long long;
using namespace std;
const int N = 2E5 + 5;
ll a[N], b[N];
int main()
{

    ll i, j, k, n, l, o, flag1 = 1, flag2 = 1, step1 = -1, step2 = -1;
    priority_queue<ll> Q1, Q2, Q3, Q4;
    cin >> n;
    for (i = 1; i <= n; i++)
    {
        cin >> a[i];
    }
    for (i = 1; i <= n; i++)
        cin >> b[i];
    for (i = 1; i <= n; i++)
        Q1.push(a[i]);
    for (i = 1; i <= n; i++)
        Q2.push(b[i]);
    l = abs(Q1.top() - Q2.top());
    while (!Q1.empty())
    {
        if (abs(Q1.top() - Q2.top()) != l)
        {
            flag1 = 0;
            break;
        }
        Q1.pop();
        Q2.pop();
    }
    if (flag1 == 1)
        step1 = l;

    for (i = 1; i <= n; i++)
        Q3.push(-a[i]);
    for (i = 1; i <= n; i++)
        Q4.push(b[i]);

    l = abs(Q3.top() - Q4.top());
    while (!Q3.empty())
    {
        if (abs(Q3.top() - Q4.top()) != l)
        {
            flag2 = 0;
            break;
        }
        Q3.pop();
        Q4.pop();
    }
    if (flag2 == 1)
        step2 = l + 1;

    if (step2 == -1 && step1 == -1)
        cout << -1 << endl;
    else if (step2 != -1 && step1 != -1)
    {
        cout << min(step2, step1) << endl;
    }
    else if (step2 == -1 && step1 != -1)
        cout << step1 << endl;
    else if (step2 != -1 && step1 == -1)
        cout << step2 << endl;
    return 0;
}