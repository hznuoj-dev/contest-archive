#include<bits/stdc++.h>
using namespace std;
const int N=1e6+5;
const int INF=0x7fffffff;
int n,a[N],b[N],ans1=INF,ans2=INF;
bool flag;
int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i)scanf("%d",&a[i]);
	for(int i=1;i<=n;++i)scanf("%d",&b[i]);
	sort(a+1,a+n+1);sort(b+1,b+n+1);
	flag=1;
	for(int i=2;i<=n;++i)
	{
		if(b[i]-b[i-1]!=a[i]-a[i-1])
		{
			flag=0;
			break;
		}
	}
	if(flag)ans1=abs(a[1]-b[1]);
	for(int i=1;i<=n;++i)a[i]=-a[i];
	sort(a+1,a+n+1);
	flag=1;
	for(int i=2;i<=n;++i)
	{
		if(b[i]-b[i-1]!=a[i]-a[i-1])
		{
			flag=0;
			break;
		}
	}
	if(flag)ans2=abs(a[1]-b[1])+1;
	if(ans1==ans2&&ans1==INF)puts("-1");
	else printf("%d\n",min(ans1,ans2)); 
	return 0;
}
