#include <bits/stdc++.h>

using namespace std;
using LL = long long;

constexpr int N = 2e5 + 5;

#define int long long

#define zero 0

int n, m, b, cnt, sum;

int a[N], c[N], x;

int f[N][2];

void solve()
{
    cin >> n >> m >> b; 

    for(int i = 1; i <= n; ++ i)
    {
        cin >> x;
        a[i] = a[i - 1] + x;
    }

    for(int i = 1; i <= n; ++ i)
    {
        // f[i][0] = f[i - 1][0];
        f[i][1] = max((long long)zero, f[max(i - m, (long long)zero)][1] + min(b, a[i] - f[max(i - m, (long long)zero)][1]));
    }

    cout << f[n][1] << endl;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    // ?int T;
    // f?or (cin >> T; T -- ; )
        solve();

}