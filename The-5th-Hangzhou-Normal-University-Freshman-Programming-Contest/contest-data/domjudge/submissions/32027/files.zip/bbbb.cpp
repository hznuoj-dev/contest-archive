#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn = 2e5 + 10;
ll n;
ll a[maxn],b[maxn],c[maxn],d[maxn];
int main()
{
	cin>>n;
	for(ll i=1;i<=n;i++){
		cin>>a[i];
		c[i]=-a[i];
	}
	for(ll i=1;i<=n;i++){
		cin>>b[i];
		d[i]=-b[i];
	}
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	sort(d+1,d+1+n);
	int f1=0,f2=0,f3=0,f4=0,ans=0;
	ll nn=-1;
	for(ll i=2;i<=n;i++){
		if(a[i]-b[i]!=a[1]-b[1]){
			f1=1;
			break;
		}
	}
	if(f1!=1){
		nn=abs(a[1]-b[1]);
	}
	for(ll i=2;i<=n;i++){
		if(a[i]-d[i]!=a[1]-d[1]){
			f2=1;
			break;
		}
	}
	if(f2!=1){
		if(nn!=-1){
			nn=min(nn,abs(a[1]-d[1])+1);
		}
		else {
			nn=abs(a[1]-d[1])+1;
		}
	}
	for(ll i=2;i<=n;i++){
		if(c[i]-d[i]!=c[1]-d[1]){
			f3=1;
			break;
		}
	}
	if(f3!=1){
		if(nn!=-1)	{
			nn=min(nn,abs(c[1]-d[1])+2);
		}
		else {
			nn=abs(c[1]-d[1])+2;
		}
	}
	for(ll i=2;i<=n;i++){
		if(c[i]-b[i]!=c[1]-b[1]){
			f4=1;
			break;
		}
	}
	if(f4!=1){
		if(nn!=-1){
			nn=min(nn,abs(c[1]-b[1])+1);
		}
		else {
			nn=abs(c[1]-b[1])+1;
		}
	}
	if(nn!=-1){
		cout<<nn<<endl;
	}
	else {
		cout<<"-1"<<endl;
	}
	return 0;
}
