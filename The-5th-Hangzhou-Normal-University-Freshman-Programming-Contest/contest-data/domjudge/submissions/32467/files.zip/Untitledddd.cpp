#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
//#define int long long 
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
const int inf=0x3f3f3f3f;
const int N=2e6+10;
int n;
vector<pair<int,int>>g[N];
int ans[N];
int sz[N];
int dif[N];
set<int>st;
int bb[N];
void dfs(int u,int par)
{
	sz[u]=ans[u];
	dif[u]=1;
	for(auto it:g[u])
	{
		int v=it.first;
		int w=it.second;
		ans[v]=(w^ans[u]);
		if(v==par)  continue;
		dfs(v,u);
		sz[u]=(sz[u]^sz[v]);
		dif[u]+=dif[v];
	}
	
}


int main()
{
	Acode;
	cin>>n;
	int cnt=0;
	for(int i=1;i<=n-1;i++) 
	{
		int u,v,w;
		cin>>u>>v>>w;
		bb[u]++;
		bb[v]++;
		cnt=(cnt^w);
		g[u].push_back({v,w});
		g[v].push_back({u,w});
	}
	for(int i=1;i<=n;i++) 
	{
		if(bb[i]%2==0) st.insert(i);
	}
	int q;
	cin>>q;
	int lei=0;
	for(int i=1;i<=n;i++) 
	{
		if(st.count(i)==0) 
		{
			dfs(i,0);
			lei=sz[i];
		}
	}
	while(q--)
	{
		int u,x;
		cin>>u>>x;
		if(st.count(u)==0) 
		{
			cout<<lei<<endl;
			continue;
		}
		ans[u]=x;
		dfs(u,0);
//		for(int i=1;i<=n;i++) 
//		{
//			cout<<ans[i]<<" ";
//		}
		cout<<sz[u]<<endl;
	}
	return 0;	
}





//5
//1 2 1
//2 3 2
//2 4 3
//1 5 4