#include<bits/stdc++.h>
#define close std::ios::sync_with_stido(flase),cin.tie(0),cout.tie(0);
using namespace std;
typedef long long ll;
const ll MAXN = 3e5+7;
#define int long long
int sum[MAXN],ans[MAXN],tmp=0;int n;
vector<pair<int,int> > adj[MAXN];
void dfs_sum(int u,int fa){
	sum[u]=1;
	for(auto it:adj[u]){
		int v=it.first;
		if(v==fa) continue;
		dfs_sum(v,u);
		sum[u]+=sum[v];
	}
}
void dfs_up(int u,int fa){
	for(auto it:adj[u]){
		int v=it.first,w=it.second;
		if(v==fa) continue;
		int ss=sum[v];
		if(ss%2==1) tmp^=w;
		dfs_up(v,u);
	}
}
void dfs_down(int u,int fa){
	
	for(auto it:adj[u]){
		int temp=ans[u];
		int v=it.first,w=it.second;
		if(v==fa) continue;
		int ss=sum[v];
		if(ss%2==1){
			temp^=w;
		}
		if((n-ss)%2==1) temp^=w;
		ans[v]=temp;
		dfs_down(v,u);
	}
}
void solve(){
	cin>>n;
	for(int i=1;i<n;i++){
		int u,v,w;cin>>u>>v>>w;
		adj[u].push_back({v,w});
		adj[v].push_back({u,w});
	}
	int q;cin>>q;
	dfs_sum(1,-1);
	dfs_up(1,-1);
	ans[1]=tmp;
	dfs_down(1,-1);
	while(q--){
		int u,w;cin>>u>>w;
		if(n%2==1)
		cout<<(ans[u]^w)<<"\n";
		else cout<<tmp<<"\n";
	}
	
}
signed main(){
	solve();
}