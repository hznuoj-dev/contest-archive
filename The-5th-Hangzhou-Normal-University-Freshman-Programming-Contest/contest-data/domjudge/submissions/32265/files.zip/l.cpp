#include<iostream>
#include<iomanip>
using namespace std;
double max1;
int a[10],b[10];
int p,q,m,k,cnt,sum,sum1;

void dfs(int x)
{
	if(x==1)
	{
		for(int i=1;i<=5;i++)
		{
			p=a[i];
			q=b[i];
			if(p>=m) p=p-k;
			if(p!=0&&q*1.0/p>max1) max1=q*1.0/p;
		}
		dfs(x+1);
	}
	if(x==2)
	{
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=5&&j!=i;j++)
			{
				p=a[i]+a[j],q=b[i]+b[j];
				if(p>=m) p=p-k;
				if(p!=0&&q*1.0/p>max1) max1=q*1.0/p;
			}
		}
		dfs(x+1);
	}
	if(x==3)
	{
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=5&&j!=i;j++)
			{
				for(int z=1;z<=5&&z!=j&&z!=i;z++)
				{
					p=a[i]+a[z]+a[j],q=b[i]+b[z]+b[j];
					if(p>=m) p=p-k;
				    if(p!=0&&q*1.0/p>max1) max1=q*1.0/p;
				}
			}
		}
		dfs(x+1);
	}
	if(x==4)
	{
		for(int i=1;i<=5;i++)
		{
			p=sum-a[i];
			q=sum1-b[i];
			if(p>=m) p=p-k;
			if(p!=0&&q*1.0/p>max1) max1=q*1.0/p;
		}
		dfs(x+1);
	}
	if(x==5)
	{
		p=sum,q=sum1;
		if(p>=m) p=p-k;
		if(p!=0&&q*1.0/p>max1) max1=q*1.0/p;
		dfs(x+1);
	}
	if(x==6) return;
}


int main()
{
	cin >> m >> k;
	for(int i=1;i<=5;i++)
	{
		cin >> a[i];
		sum+=a[i];
	}
	for(int i=1;i<=5;i++)
	{
		cin >> b[i];
		sum1+=b[i];
	}
	dfs(1);
	cout << fixed << setprecision(2) << max1 << endl;
	return 0;
}
