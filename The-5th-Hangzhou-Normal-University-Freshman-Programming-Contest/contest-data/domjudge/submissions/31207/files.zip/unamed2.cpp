#include<bits/stdc++.h>
using namespace std;
#define int long long

const int maxn = (1 << 5) - 1;

double dp[maxn];
int a[maxn], b[maxn];

void run() {
	int m, k;
	cin >> m >> k;
	for (int i = 0; i < 5; i++) {
		cin >> a[i];
	}
	for (int i = 0; i < 5; i++) {
		cin >> b[i];
	}
	int cal, res;
	for (int i = 1; i <= maxn; i++) {
		cal = 0;
		res = 0;
		for (int j = 0; j < 5; j++) {
			if ((1 << j)&i) {
				cal += b[j];
				res += a[j];
			}
		}
		res -= ((res / m) * k);
		dp[i] = max(dp[i - 1], 1.0 * cal / res);
	}
	printf("%.2lf\n", dp[maxn]);
	return;
}

signed main() {
//	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int T = 1;
//	cin >> T;
	while (T--) {
		run();
	}
	return 0;
}
