#include <iostream>
#include <algorithm>
#include <queue>
#include <vector>
#include <cstring>
#define endl "\n"
using namespace std;
typedef pair<int, int> PII;
typedef long long ll;

int n;
vector<int> a, b;
int k;
int va;

int main()
{
    cin >> n;
    for(int i = 0;i < n;i++)
    {
        int tt;
        cin >> tt;
        a.push_back(tt);
    }
    for(int i = 0;i < n;i++)
    {
        int tt;
        cin >> tt;
        b.push_back(tt);
    }
    sort(a.begin(), a.end());
    sort(b.begin(), b.end());
    if(a[0] - b[0] == a[1] - b[1])
    {
        if(abs(a[0] - b[0]) > abs(a[n - 1] + b[0]) + 1)
        {
            k = abs(a[n - 1] + b[0]) + 1;
            reverse(a.begin(), a.end());
            for(int i = 0;i < n;i++)
            {
                a[i] = -a[i];
            }
            
            va = a[0] - b[0];
        }
        else
        {
            k = abs(a[0] - b[0]);
            va = a[0] - b[0];
        }
    }
    else
    {
        cout << -1;
        return 0;
    }
    for(int i = 0;i < n;i++)
    {
        if(a[i] - b[i] != va)
        {
            cout << -1;
            return 0;
        }
    }
    cout << k;
    return 0;
}
