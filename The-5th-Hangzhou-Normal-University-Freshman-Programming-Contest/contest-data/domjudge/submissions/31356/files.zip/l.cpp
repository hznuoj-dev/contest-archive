#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long
typedef long long LL;
typedef pair<int,int> PII;

const int N=210,M=40010;

int m,k;
int a[N],b[N];
int dp[N][M];

void solve(){
    cin>>m>>k;
    for(int i=1;i<=5;i++){
        cin>>a[i];
    }
    for(int i=1;i<=5;i++){
        cin>>b[i];
    }
    double res=0;
    for(int i=1;i<=(1<<6-1);i++){
        int v=0,w=0;
        for(int j=0;j<5;j++){
            if(i>>j&1){
                v+=a[j+1];
                w+=b[j+1];
            } 
        }
        res=max(res,1.*w/(v-(v>=m)*k));
    }
    cout<<fixed<<setprecision(2)<<res<<endl;
}

bool multi=false;

signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);

    int T=1;
    if(multi) cin>>T;
    while(T--){
        solve();
    }

    return 0;
}