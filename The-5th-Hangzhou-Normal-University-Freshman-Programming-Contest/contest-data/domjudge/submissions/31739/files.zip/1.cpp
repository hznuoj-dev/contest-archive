#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;

long long int n;
long long int a[200000], b[200000];

bool cmp(int x1, int x2)
{
    return x1 > x2;
}

int main()
{
    cin >> n;
    for (long long int i = 0; i < n; i++)
    {
        cin >> a[i];
    }
    for (long long int i = 0; i < n; i++)
    {
        cin >> b[i];
    }
    int t1 = 1;
    sort(a, a + n, cmp);
    sort(b, b + n);
    int v1 = b[0] + a[0];
    int c1 = -1;
    for (long long int i = 0; i < n; i++)
    {
        if (v1 - a[i] == b[i])
        {
            continue;
        }
        else
        {
            t1 = 0;
            break;
        }
    }
    if (t1 == 1)
    {
        c1 = abs(v1) + 1;
    }
    sort(a, a + n);
    int t2 = 1;
    int v2 = b[0] - a[0];
    int c2 = -1;
    for (long long int i = 0; i < n; i++)
    {
        if (a[i] + v2 == b[i])
        {
            continue;
        }
        else
        {
            t2 = 0;
            break;
        }
    }
    if (t2 == 1)
    {
        c2 = abs(v2);
    }
    if (t1 == 0 && t2 == 0)
    {
        cout << "-1";
    }
    else if (t2 == 0 && t1 == 1)
    {
        cout << c1;
    }
    else if (t1 == 0 && t2 == 1)
    {
        cout << c2;
    }
    else
    {
        if (c1 < c2)
        {
            cout << c1;
        }
        else
        {
            cout << c2;
        }
    }
}
