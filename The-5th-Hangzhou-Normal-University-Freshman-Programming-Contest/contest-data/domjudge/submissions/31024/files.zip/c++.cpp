#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const int N = 1e5 + 10, mod = 1e9 + 7;
#define endl "\n"
typedef pair <int, int> PII;
int n, k;
struct node{
    int x, y;
}r[N];
double a[N], b[N], ans;
bool vis[10];
bool cmp1(node a, node b){
    return a.x > b.x;
}
bool cmp2(int a, int b){
    return a > b;
}
void dfs(double sum, double cnt){
    if (cnt > 0){
        if (sum >= n)ans = max(ans, cnt / (sum - k));
        else ans = max(ans, cnt / sum);
    }
    for (int i = 1; i <= 5; i ++){
        if (!vis[i]){
            vis[i] = 1;
            dfs(sum + a[i], cnt + b[i]);
            vis[i] = 0;
        }
    }
}
void solve(){
    cin >> n >> k;
    for (int i = 1; i <= 5; i ++)cin >> a[i];
    for (int i = 1; i <= 5; i ++)cin >> b[i];
    dfs(0, 0);
    cout << fixed << setprecision(2) << ans << endl;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int q;
    //cin >> q;
    q = 1;
    while (q --){
        solve();
    }
    return 0;
}