#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int n,a[N],b[N];
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=n;i++) cin>>b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	int fg=1,fg1=1;
	int ch=a[1]-b[1];
	for(int i=2;i<=n;i++)
	{
		if(a[i]-b[i]!=ch)
		{
			fg=0;
			break;
		}
	}
	for(int i=1;i<=n;i++) a[i]=-a[i];
	int min;
	if(fg) min=abs(ch);
	sort(a+1,a+1+n);
	int ch1=a[1]-b[1];
	//for(int i=1;i<=n;i++) cout<<a[i]<<" ";
	//cout<<endl;
	//for(int i=1;i<=n;i++) cout<<b[i]<<" ";
	for(int i=2;i<=n;i++)
	{
		if(a[i]-b[i]!=ch1)
		{
			fg1=0;
			break;
		}
	}
	//cout<<fg<<fg1<<endl;
	if(fg==0&&fg1==0) cout<<-1<<endl;
	else
	{
		if(fg==1&&fg1==0) cout<<min<<endl;
		else if(fg==0&&fg1==1) cout<<abs(a[1]-b[1])+1<<endl;
		else
		{
			if(min>abs(a[1]-b[1])+1) cout<<abs(a[1]-b[1])+1<<endl;
			else cout<<min<<endl;
		}
	}
	return 0;
}
