#include <iostream>
#include <algorithm>

using namespace std;
struct info{
    int a, b;
    double e;
}c[6];

int dp[6][6];
int m, k;

bool cmp(info x, info y){
    return x.e > y.e;
}

int main(){
    cin >> m >> k;
    for (int i = 1; i <= 5; i++)
        cin >> c[i].a;
    for (int i = 1; i <= 5; i++){
        cin >> c[i].b;
        c[i].e = c[i].b * 1.0 / c[i].a;
    }
        
    sort(c + 1, c + 1 + 5, cmp);
    
    double e[6] = {0};
    int sum[6] = {0};
    int pj[6] = {0};
    for (int i = 1; i <= 5; i++){
        double temp;
        if (sum[i - 1] + c[i].a >= m){
            temp = (pj[i-1] + c[i].b) * 1.0 / (sum[i - 1] + c[i].a - k);
        }
        else {
            temp = (pj[i-1] + c[i].b) * 1.0 / (sum[i - 1] + c[i].a);
        }
        if (temp >= e[i-1]){
            e[i] = temp;
            sum[i] = sum[i-1] + c[i].a;
            pj[i] = pj[i-1] + c[i].b;
        }
        else {
            e[i] = e[i-1];
            sum[i] = sum[i-1];
            pj[i] = pj[i-1];
        }
    }
    printf("%.2lf\n", e[5]);
    return 0;
}