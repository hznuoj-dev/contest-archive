#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f
#define INF 0x3f3f3f3f3f3f3f3f
#define ll long long 
#define ull undigned long long
#define int ll
const int N=2e5+5;
int a[N],b[N];
signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0),cout.tie(0);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	cin>>a[i];
	for(int j=1;j<=n;j++)
	cin>>b[j];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	int flag=0;
	int flag1=0;
	int tem=a[1]-b[1];
	for(int i=2;i<=n;i++)
	{
		if(a[i]-b[i]!=tem)
		{
			flag++;
			break;
		}
	}
	tem=a[1]+b[n];
	for(int i=2;i<=n;i++)
	{
		if(a[i]+b[n-i+1]!=tem)
		{
			flag1++;
			break;
		}
	}
	if(flag==0&&flag1==0)
	{
		cout<<min(abs(a[1]-b[1]),1+abs(a[1]+b[n]));
	}
	else if(flag==0&&flag1!=0)
	{
		cout<<abs(a[1]-b[1]);
	}
	else if(flag!=0&&flag1==0)
	{
		cout<<1+abs(a[1]+b[n]);
	}
	else
	cout<<-1;
	
}