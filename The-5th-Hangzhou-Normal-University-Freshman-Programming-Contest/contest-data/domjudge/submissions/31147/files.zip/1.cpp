#include<iostream>
using namespace std;
int main()
{
	long long a[50001], b[50001];
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
	}
	for (int i = 1; i <= n; i++)
	{
		cin >> b[i];
	}
	for (int i = 1; i <= n; i++)
	{
		for (int j = 1; j <= n - i; j++)
		{
			if (a[j] > a[j + 1])
			{
				long long temp = a[j];
				long long temp1 = a[j + 1];
				a[j] = temp1;
				a[j + 1] = temp;
			}
			if (b[j] > b[j + 1])
			{
				long long temp = b[j];
				long long temp1 = b[j + 1];
				b[j] = temp1;
				b[j + 1] = temp;
			}
		}
	}
	long long x = a[1], y = b[1];
	for (int i = 2; i <= n; i++)
	{
		long long x1 = a[i], y1 = b[i];
		if ((x1 / y1) != x / y)
		{
			cout << -1;
			return 0;
		}
	}
	if (x * y >= 0)
	{
		cout << abs(x - y);
	}
	if (x * y < 0)
	{
		x = -x;
		cout << abs(x - y) + 1;
	}
	return 0;
}
//{
//	int m, k;
//	float a[6], b[6], c[6];
//	cin >> m >> k;
//	for (int i = 1; i < +5; i++)
//	{
//		cin >> a[i];
//	}
//	for (int i = 1; i <= 5; i++)
//	{
//		cin >> b[i];
//	}
//	for (int i = 1; i <= 5; i++)
//	{
//		float x = a[i], y = b[i];
//		c[i] = x / y;
//	}
//	for (int i = 1; i <= 5; i++)
//	{
//		for (int j = 1; i <= 5 - i; j++)
//		{
//			if (c[j] < c[j + 1])
//			{
//				float temp = c[j];
//				c[j] = c[j + 1];
//				c[j + 1] = temp;
//				float temp = a[j];
//				a[j] = a[j + 1];
//				a[j + 1] = temp; 
//				float temp = b[j];
//				b[j] = b[j + 1];
//				b[j + 1] = temp;
//			}
//		}
//	}
//	int sum = 0;
//	for (int i = 1; i <= 5; i++)
//	{
//		int x = a[i];
//		sum = sum + x;
//		if (sum >= m)
//		{
//			printf()
//		}
//	}
//}