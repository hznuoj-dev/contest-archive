#include<bits/stdc++.h>
using namespace std;
void slove(){
	int n,m,b,a[200005],st=1;
	cin>>n>>m>>b;
	long long sum=0,ans=0;
	if((n-1)%m==0){
		st=1;
	}
	else{
		st=(n-1)%m+1;
	}
	int id=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum+=a[i];
		if(i==st+id*m){
		     id++;
			 if(sum>=b){
			 ans+=b;
			 sum-=b;
			 }
			 else{
			 	 ans+=sum;
			 	 sum=0;
			 }
		}
		
	}
	cout<<ans;
	return;
}
int main(){
	int T=1;
//	cin>>T;
	while(T--){
		slove();
	}
	
	return 0;
} 
