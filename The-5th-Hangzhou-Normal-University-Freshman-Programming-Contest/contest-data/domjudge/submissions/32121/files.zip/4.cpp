#include <bits/stdc++.h>
using namespace std;

int main()
{
	int a[6];
	int b[6];
	int m,k;
	cin >> m >> k;
	for(int i = 1; i <= 5; i++)
	{
		cin >> a[i];
	}
	for(int i = 1; i <= 5; i++)
	{
		cin >> b[i];
	}
	double max = 0;
	double max1;
	int x,y;
	if(a[1] >= m)
	{
		x = a[1] - k;
		y = b[1];
	}
	else
	{
		x = a[1];
		y = b[1];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}
	
	if(a[2] >= m)
	{
		x = a[2] - k;
		y = b[2];
	}
	else
	{
		x = a[2];
		y = b[2];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}
	
	if(a[3] >= m)
	{
		x = a[3] - k;
		y = b[3];
	}
	else
	{
		x = a[3];
		y = b[3];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	if(a[4] >= m)
	{
		x = a[4] - k;
		y = b[4];
	}
	else
	{
		x = a[4];
		y = b[4];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
	if(a[5] >= m)
	{
		x = a[5] - k;
		y = b[5];
	}
	else
	{
		x = a[5];
		y = b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	if(a[1] + a[2] >= m)
	{
		x = a[1] + a[2]- k;
		y = b[1] + b[2];
	}
	else
	{
		x = a[1] + a[2];
		y = b[1] + b[2];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	
	if(a[1] + a[3] >= m)
	{
		x = a[1] + a[3]- k;
		y = b[1] + b[3];
	}
	else
	{
		x = a[1] + a[3];
		y = b[1] + b[3];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
		
	if(a[1] + a[4] >= m)
	{
		x = a[1] + a[4]- k;
		y = b[1] + b[4];
	}
	else
	{
		x = a[1] + a[4];
		y = b[1] + b[4];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
		
	
	if(a[1] + a[5] >= m)
	{
		x = a[1] + a[5]- k;
		y = b[1] + b[5];
	}
	else
	{
		x = a[1] + a[5];
		y = b[1] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
		
	
	if(a[3] + a[2] >= m)
	{
		x = a[3] + a[2]- k;
		y = b[3] + b[2];
	}
	else
	{
		x = a[3] + a[2];
		y = b[3] + b[2];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
		
	
	if(a[4] + a[2] >= m)
	{
		x = a[4] + a[2]- k;
		y = b[4] + b[2];
	}
	else
	{
		x = a[4] + a[2];
		y = b[4] + b[2];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
		
	if(a[5] + a[2] >= m)
	{
		x = a[5] + a[2]- k;
		y = b[5] + b[2];
	}
	else
	{
		x = a[5] + a[2];
		y = b[5] + b[2];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	if(a[4] + a[3] >= m)
	{
		x = a[4] + a[3]- k;
		y = b[4] + b[3];
	}
	else
	{
		x = a[4] + a[3];
		y = b[4] + b[3];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	if(a[4] + a[5] >= m)
	{
		x = a[4] + a[5]- k;
		y = b[4] + b[5];
	}
	else
	{
		x = a[4] + a[5];
		y = b[4] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	if(a[5] + a[3] >= m)
	{
		x = a[5] + a[3]- k;
		y = b[5] + b[3];
	}
	else
	{
		x = a[5] + a[3];
		y = b[5] + b[3];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	
	
	
	
	
	if(a[1] + a[2] + a[3]>= m)
	{
		x = a[1] + a[2] + a[3]- k;
		y = b[1] + b[2] + b[3];
	}
	else
	{
		x = a[1] + a[2] + a[3];
		y = b[1] + b[2] + b[3];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	
	
	
	
	
	if(a[1] + a[2] + a[4]>= m)
	{
		x = a[1] + a[2] + a[4]- k;
		y = b[1] + b[2] + b[4];
	}
	else
	{
		x = a[1] + a[2] + a[4];
		y = b[1] + b[2] + b[4];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
	
	
	
	
	
	
	if(a[1] + a[2] + a[5]>= m)
	{
		x = a[1] + a[2] + a[5]- k;
		y = b[1] + b[2] + b[5];
	}
	else
	{
		x = a[1] + a[2] + a[5];
		y = b[1] + b[2] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
	
	
	
	
	
	
	
	
	
	if(a[1] + a[3] + a[4]>= m)
	{
		x = a[1] + a[3] + a[4]- k;
		y = b[1] + b[3] + b[4];
	}
	else
	{
		x = a[1] + a[3] + a[4];
		y = b[1] + b[3] + b[4];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
	
	if(a[1] + a[3] + a[5]>= m)
	{
		x = a[1] + a[3] + a[5]- k;
		y = b[1] + b[3] + b[5];
	}
	else
	{
		x = a[1] + a[3] + a[5];
		y = b[1] + b[3] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}					


	if(a[1] + a[4] + a[5]>= m)
	{
		x = a[1] + a[4] + a[5]- k;
		y = b[1] + b[4] + b[5];
	}
	else
	{
		x = a[1] + a[4] + a[5];
		y = b[1] + b[4] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
	
	
	
	
	
	if(a[1] + a[2] + a[3]>= m)
	{
		x = a[1] + a[2] + a[3]- k;
		y = b[1] + b[2] + b[3];
	}
	else
	{
		x = a[1] + a[2] + a[3];
		y = b[1] + b[2] + b[3];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
	
	if(a[2] + a[4] + a[5]>= m)
	{
		x = a[2] + a[4] + a[5]- k;
		y = b[2] + b[4] + b[5];
	}
	else
	{
		x = a[2] + a[4] + a[5];
		y = b[2] + b[4] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
	
	if(a[3] + a[4] + a[5]>= m)
	{
		x = a[3] + a[4] + a[5]- k;
		y = b[3] + b[4] + b[5];
	}
	else
	{
		x = a[3] + a[4] + a[5];
		y = b[3] + b[4] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
	if(a[2] + a[3] + a[4]>= m)
	{
		x = a[2] + a[3] + a[4]- k;
		y = b[2] + b[3] + b[4];
	}
	else
	{
		x = a[2] + a[3] + a[4];
		y = b[2] + b[3] + b[4];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}			
	
	if(a [1] + a[2] + a[3] + a[4] + a[5]>= m)
	{
		x =a[1] + a[2] + a[3] + a[4] + a[5]- k;
		y = b[1] + b[2] + b[3] + b[4] + b[5];
	}
	else
	{
		x =a[1] + a[2] + a[3] + a[4] + a[5];
		y = b[1] + b[2] + b[3] + b[4] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}			
	
	if( a[2] + a[3] + a[4] + a[5]>= m)
	{
		x =a[2] + a[3] + a[4] + a[5]- k;
		y =  b[2] + b[3] + b[4] + b[5];
	}
	else
	{
		x =a[2] + a[3] + a[4] + a[5];
		y =  b[2] + b[3] + b[4] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	
	if(a[1] + a[3] + a[4] + a[5]>= m)
	{
		x =a[1]  + a[3] + a[4] + a[5]- k;
		y = b[1] + b[3] + b[4] + b[5];
	}
	else
	{
		x =a[1]  + a[3] + a[4] + a[5];
		y = b[1] + b[3] + b[4] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}		
	if(a[1] + a[2] + a[4] + a[5]>= m)
	{
		x =a[1] + a[2] + a[4] + a[5]- k;
		y = b[1] + b[2]  + b[4] + b[5];
	}
	else
	{
		x =a[1] + a[2] + a[4] + a[5];
		y = b[1] + b[2]  + b[4] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	


	if(a[1] + a[2] + a[3] + a[5]>= m)
	{
		x =a[1] + a[2] + a[3] + a[5]- k;
		y = b[1] + b[2] + b[3] + b[5];
	}
	else
	{
		x =a[1] + a[2] + a[3] + a[5]- k;
		y = b[1] + b[2] + b[3] + b[5];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	

	
	if(a[1] + a[2] + a[3] + a[4]>= m)
	{
		x =a[1] + a[2] + a[3] + a[4]- k;
		y = b[1] + b[2] + b[3] + b[4];
	}
	else
	{
		x =a[1] + a[2] + a[3] + a[4];
		y = b[1] + b[2] + b[3] + b[4];		
	}
	max1 = 1.0*y/x;
	if(max1 >= max)
	{
		max = max1;
	}	
	
				
	printf("%.2f",max);				
	return 0;
}
