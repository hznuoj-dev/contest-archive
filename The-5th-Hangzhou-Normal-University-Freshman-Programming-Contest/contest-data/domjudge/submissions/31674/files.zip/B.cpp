#include <bits/stdc++.h>
using namespace std;
#define fastio ios::sync_with_stdio(false);cin.tie(0); cout.tie(0)
typedef long long ll;
typedef pair<int, int> pii;
const int N = 1e6 + 5;

ll a[200001],b[200001];

signed main(){
    fastio;
    int n,h=0;
    ll su1=0,su2=0,su3,c;
    cin>>n;
    for(int i=0;i<n;i++)cin>>a[i],su1+=a[i];
    sort(a,a+n);
    for(int i=0;i<n;i++)cin>>b[i],su2+=b[i];
    sort(b,b+n);
    c=a[0]-b[0];
    for(int i=1;i<n;i++){
        if(a[i]-b[i]!=c){
            printf("-1");
            return 0;
        }
    }
    if(su1>0&&su2<0&&min(su1,-su2)*2>n)h=1;
    else if(su1<0&&su2>0&&min(su2,-su1)*2>n)h=1;
    if(h==1){
        su3=abs(su1+su2);
    }
    else {
        su3=abs(su1-su2);
    }
    printf("%lld",(su3/n+h));
    system("pause");
}