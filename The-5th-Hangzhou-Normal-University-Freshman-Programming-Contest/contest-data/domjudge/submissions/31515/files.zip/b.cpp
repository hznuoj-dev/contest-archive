#include<iostream>
#include<cmath>
using namespace std;

//B
const int N=2e5+7;
typedef long long ll;
ll a[N],b[N];

int main(){
	int n;
	cin>>n;
	bool allAreSame=true;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(a[i]!=a[1])allAreSame=false;
	}
	for(int i=1;i<=n;i++)cin>>b[i];
	for(int i=n;i>=1;i--){
		b[i]-=b[i-1];
		a[i]-=a[i-1];
	}
	bool flag=true;
	ll k=1;
	if(a[2]*b[2]<0)k=-1;
	for(int i=2;i<=n;i++){
		if(a[i]*k!=b[i]){
			flag=false;
			break;
		}
	}
	if(flag){
		ll step=0;
		if(allAreSame){
			if(a[1]*b[1]<0){
				step++;
				a[1]*=-1;
			}
		}else{
			if(k<0){
				step++;
				a[1]*=-1;
			}
		}
		step+=max(a[1],b[1])-min(a[1],b[1]);
		cout<<step<<endl;
	}else{
		cout<<-1<<endl;
	}
}


/*
3
1 2 3
4 5 6

3
-1 -2 -3
4 5 6

4
1 1 1 1
-1 -1 -1 -1

*/
