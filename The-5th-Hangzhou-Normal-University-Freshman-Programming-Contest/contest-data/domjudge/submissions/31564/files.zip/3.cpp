#include<bits/stdc++.h>
using namespace std;
int  n,a[1000000],t[1000000],l,r,p,k;
int main()
{
	cin>>n;
	
	for(int  i=1;i<=n;i++)
	cin>>a[i],t[i]=a[i];
	
	sort(t+1,t+1+n);
	
	if(t[(n+1)/2]!=t[n/2+1])
	{
		k=t[n/2+1]-t[(n+1)/2];
		
		if(k==1)  {cout<<"0\n";return  0;}
		else  k=t[n/2+1]-1;
		
		for(int i=1;i<=n;i++)
		{
		  if(a[i]<k)  l++;
		  if(a[i]>k)  r++;
		  if(l<r)  p=1;
		}
		
		if(p)  cout<<"0\n";
		else  cout<<t[n/2+1]-t[(n+1)/2]-1;
	}
	
	else
	{
		k=t[n/2+1];
		for(int  i=1;i<=n;i++)
		{
			if(a[i]<k)  l++;
			if(a[i]>k)  r++;
			if(l<r)  p=1;
		}
		
		if(p)  cout<<"0\n";
		else  cout<<"1\n";
	}
	return 0;
}
