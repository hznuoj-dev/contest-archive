#include<bits/stdc++.h>
#define close std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
typedef long long ll;
const ll MAXN = 3e5+7;
const ll mod = 1e9+7;
const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
#define int long long
int a[MAXN],b[MAXN];
map<int,int> sz;
stack<char> sta;
void solve(){
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
		sz[a[i]]++;
	}
	sort(b+1,b+1+n);
	if(n%2==1){
		int tmp=(b[(n+1)/2]);
		for(int i=1;i<=n;i++){
			if(a[i]<tmp){
				sta.push('(');
			}
			else if(a[i]>tmp){
				if(sta.size()&&sta.top()=='(') sta.pop();
				else sta.push(')');
			}
		}
		if(sta.size()) cout<<"0";
		else cout<<"1";
	}
	else{
		int start=b[n/2],end=b[n/2+1],tmp;
		if(end-start<2) tmp=start;
		else tmp=start+1;
		for(int i=1;i<=n;i++){
			if(a[i]<tmp){
				sta.push('(');
			}
			else if(a[i]>tmp){
				if(sta.size()&&sta.top()=='(') sta.pop();
				else sta.push(')');
			}
		}
		if(sta.size()) cout<<"0";
		else if(start==end)cout<<"1";
		else cout<<end-start-1;
	} 
}
signed main(){
	solve();
}