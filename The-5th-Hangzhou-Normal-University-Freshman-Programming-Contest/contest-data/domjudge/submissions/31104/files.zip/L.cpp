#include<bits/stdc++.h>
using namespace std;
int a[10],b[10];
int m,k;
int val,sat;
double ans;
void dfs(int p,int val,int sat){
	if(val != 0){
		if(val >= m){
			ans = max(ans,(double)sat/(val - k));
		}else ans = max(ans,(double)sat/val);
	}
	if(p > 5) return;
	dfs(p + 1,val + a[p],sat + b[p]);
	dfs(p + 1,val,sat);
}
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin >> m >> k;
	for(int i = 1;i <= 5;i ++){
		cin >> a[i];
	}
	for(int i = 1;i <= 5;i ++){
		cin >> b[i]; 
	}
	dfs(1,0,0);
	printf("%.2lf\n",ans);
	return 0;
}

