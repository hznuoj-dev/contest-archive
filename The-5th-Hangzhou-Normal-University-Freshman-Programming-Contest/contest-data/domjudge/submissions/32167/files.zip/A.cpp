#include<bits/stdc++.h>
using namespace std;
const int maxn=1e6+10;


long long a[maxn],b[maxn];
int n;
int jc(long long x){
	int k=0;
	for(int i=1;i<=n&&k>=0;i++){
		if(a[i]<x)k++;
		else if(a[i]>x)k--;
	}
	if(k==0)return 1;
	else return 0;
}
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b+1,b+n+1);
	if(n%2){
		if(jc(b[n/2+1]))cout<<1;
		else cout<<0;
	}
	else {
		int l=b[n/2],r=b[n/2+1];
		if (l==r){
			if(jc(b[n/2+1]))cout<<1;
			else cout<<0;
		}
		else {
			int ans=0;
			for(long long i=l+1;i<r;i++){
				if(jc(i))ans++;
			}
			cout<<ans;
		}
	}
}