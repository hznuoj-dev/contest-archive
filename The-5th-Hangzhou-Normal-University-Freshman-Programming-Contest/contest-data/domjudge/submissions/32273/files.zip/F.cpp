#include<bits/stdc++.h>
using namespace std;
int deg[200005];
struct edge{
	int v,next,w;
}e[400005];
int eid,h[200005];
void addEdge(int u,int v,int w){
	e[eid]={v,h[u],w};
	h[u]=eid++;
}
int sz[200005];
int sum[200005];
bool deleted[400005];
int ans=0;
void dfs(int u,int fa){
	for(int i=h[u];~i;i=e[i].next){
		int v=e[i].v,w=e[i].w;
		if(v==fa||deleted[i])continue;
		sum[v]=sum[u]^w;
		ans^=sum[v];
		dfs(v,u);
		
	}
}
int sum2[200005];
void dfs2(int u,int fa){
	for(int i=h[u];~i;i=e[i].next){
		int v=e[i].v,w=e[i].w;
		if(v==fa)continue;
		sum2[v]=sum2[u]^w;
		dfs(v,u);
		
	}
}
int main(){
	int n;
	memset(h,-1,sizeof(h));
	scanf("%d",&n);
	for(int i=0;i<n-1;i++){
		int u,v,w;
		scanf("%d%d%d",&u,&v,&w);
		deg[u]++,deg[v]++;
		addEdge(u,v,w);
		addEdge(v,u,w);
	}	

	if(n%2==0){
		dfs(1,0);
		int q;
		scanf("%d",&q);
		while(q--){
			int u,x;
			scanf("%d%d",&u,&x);
			printf("%d\n",ans);
		}
	}else{
		for(int i=1;i<=n;i++){
			if(deg[i]==1){
				dfs2(i,0);
				deleted[h[i]]=1;
				if(i==1)dfs(2,0);
				else dfs(1,0);
				break;
			}
			
		}
		int q;
		scanf("%d",&q);
		while(q--){
			int u,x;
			scanf("%d%d",&u,&x);
			printf("%d\n",ans^x^sum2[x]);
		} 
		
	}
}
