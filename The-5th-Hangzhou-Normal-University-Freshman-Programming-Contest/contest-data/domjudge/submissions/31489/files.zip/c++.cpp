#include<bits/stdc++.h>
using namespace std;
using ll = long long;
const int N = 1e6 + 10, mod = 1e9 + 7;
#define endl "\n"
#define int long long
typedef pair <int, int> PII;
struct node{
    int x, y;
}r[N];
ll a[N], dp[N], s[N];
bool cmp1(node a, node b){
    return a.x > b.x;
}
bool cmp2(int a, int b){
    return a > b;
}
void solve(){
    int n, m;
    ll b;
    cin >> n >> m >> b;
    for (int i = 1; i <= n; i ++){
        cin >> a[i];
        s[i] = s[i - 1] + a[i];
    }
    for (int i = 1; i <= m; i ++){
        dp[i] = min(s[i], b);
        //cout << dp[i] << " \n"[i == m];
    }
    for (int i = m + 1; i <= n; i ++){
        dp[i] = min(dp[i - m] + b, dp[i - m] + s[i] - dp[i - m]);
    }
    ll maxx = 0;
    for (int i = 1; i <= n; i ++){
        maxx = max(dp[i], maxx);
        //cout << dp[i] << " \n"[i == n];
    }
    cout << maxx << endl;
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int q;
    //cin >> q;
    q = 1;
    while (q --){
        solve();
    }
    return 0;
}