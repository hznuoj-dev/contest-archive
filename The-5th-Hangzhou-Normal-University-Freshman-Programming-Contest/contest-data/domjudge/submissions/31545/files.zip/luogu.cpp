#include <bits/stdc++.h> 

using i64 = long long;

struct node {
	double x, y;
};

bool cmp(node a, node b)
{
	return a.y / a.x > b.y / b.x;
}

int main()
{
	std::ios::sync_with_stdio(false);
	std::cin.tie(nullptr);
	
	int m, k;
	std::vector<node> a(5);
	double maxn = 0.00;
	int sum = 0, cnt = 0, t;
	
	std::cin >> m >> k;
	for (int i = 0; i < 5; ++i)
	std::cin >> a[i].x;
	for (int i = 0; i < 5; ++i)
	std::cin >> a[i].y;
	std::sort(a.begin(), a.end(), cmp);
	for (int i = 0; i < 5; ++i) {
		sum += a[i].y;
		cnt += a[i].x;
		if (cnt >= m)
		t = k;
		else
		t = 0;
	//	std::cout << sum << ' ' << cnt << ' ' << t << ' ' << 1.0 * sum / (cnt - t) << ' ' << maxn << '\n';
		if (1.0 * sum / (cnt - t) > maxn)
		maxn = sum / (cnt - t);
	}
	std::cout << std::fixed << std::setprecision(2) << maxn;
	
	return 0;
} 
