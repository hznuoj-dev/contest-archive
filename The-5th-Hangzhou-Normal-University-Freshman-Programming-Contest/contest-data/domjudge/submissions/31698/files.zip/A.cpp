#include <bits/stdc++.h>
using namespace std;
const int M=200005;
int a[M];
int b[M];
int num[M];
int n,m,mx=-1;
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		b[i]=a[i];
		num[a[i]]++;
	}
	sort(b+1,b+1+n);
	if(n%2){
		int tmp=b[n/2+1];
		int l,r;
		l=r=0;
		bool flag=true;
		for(int i=1;i<=n;i++){
			if(b[i]<tmp) l++;
			if(b[i]>tmp) r++;
			if(r>l){
				flag=false;
				break;
			}
		}
		if(l!=r) flag=false;
		if(flag){
			puts("1");
			return 0;
		}
		else{
			puts("0");
			return 0;
		}
	}
	else{
		int tmp1,tmp2;
		tmp1=b[n/2];
		tmp2=b[n/2+1];
		if(tmp1!=tmp2){
			int tmp=tmp1+1;
			int l,r;
			l=r=0;
			bool flag=true;
			for(int i=1;i<=n;i++){
				if(b[i]<tmp) l++;
				if(b[i]>tmp) r++;
				if(r>l){
					flag=false;
					break;
				}
			}
			if(l!=r) flag=false;
			if(flag){
				printf("%d\n",tmp2-1-tmp1);
				return 0;
			}
			else{
				puts("0");
				return 0;
			}
		}
		else{
			int tmp=tmp1;
			bool flag=true;
			int l=0,r=0;
			for(int i=1;i<=n;i++){
				if(b[i]<tmp) l++;
				if(b[i]>tmp) r++;
				if(r>l){
					flag=false;
					break;
				}
			}
			if(l!=r) flag=false;
			if(flag){
				puts("1");
				return 0;
			}
			else{
				puts("0");
				return 0;
			}
		}
	}
	return 0;
}
