#include<bits/stdc++.h>

using namespace std;

#define int long long
#define ll long long
#define fi first
#define se second
#define no "NO\n"
#define yes "YES\n"
#define pii pair<int,int>
#define pb push_back
//#define endl "\n"
#define dbg(x...) do{cout<<#x<<" -> ";err(x);}while (0)

void err() { cout << '\n'; }

template<class T, class... Ts>
void err(T arg, Ts... args) {
    cout << arg << ' ';
    err(args...);
}

const int N = 3e5+7;
const int mod = 998244353;

int n;
int a[N],b[N];


void solve(){
	cin >> n;
	for(int i=1;i<=n;i++) cin >> a[i],b[i] = a[i];
	sort(b+1,b+1+n);
	if(n%2==1) {
		int k = b[n/2+1];
		int f = 0;
		for(int i=1;i<=n;i++){
			if(a[i]<k) f++;
			else if(a[i]>k){
				if(f == 0){
					f = 1;
					break;
				}
				f--;
			} 
		}
		if(f) cout << 0 << endl;
		else cout << 1 << endl;
	}else{
		if(b[n/2] == b[n/2+1]){
			int k = b[n/2+1];
			int f = 0;
			for(int i=1;i<=n;i++){
				if(a[i]<k) f++;
				else if(a[i]>k){
					if(f == 0){
						f = 1;
						break;
					}
					f--;
				}
			}
			if(f) cout << 0 << endl;
			else cout << 1 << endl;
		}else if(b[n/2+1] - b[n/2] == 1) cout << 0 << endl;
		else{
			int k = b[n/2]+1;
			int f = 0;
			for(int i=1;i<=n;i++){
				if(a[i]<k) f++;
				else if(a[i]>k){
					if(f == 0){
						f = 1;
						break;
					}
					f--;
				}
			}
			if(f) cout << 0 << endl;
			else cout << b[n/2+1] - b[n/2] - 1 << endl;
		}
	}
}
/*
*/

signed main(){
	ios::sync_with_stdio(0);
    cin.tie(nullptr);cout.tie(nullptr);
	int T = 1;
    //cin >> T;
    while(T--) solve();

    return 0 ;
}

