#include<bits/stdc++.h>
using namespace std;
int main() {
    int n, m, b;
    cin >> n >> m >> b;
    vector<int> queue(n);
    for (int i = 0; i < n; i++) {
        cin >> queue[i];
    }
    int maxPeople = 0;
    int timeElapsed = 0;
    for (int i = 0; i < n; i++) {
        int release = min(queue[i], b);
        maxPeople += release;
        queue[i] -= release;
        timeElapsed++;
        if (timeElapsed == m) {
            timeElapsed = 0;
        } else {
            int remainingTime = m - timeElapsed;
            int remainingCapacity = min(queue[i], b);
            if (remainingCapacity > 0) {
                int additionalRelease = min(remainingCapacity, remainingTime * b);
                maxPeople += additionalRelease;
                queue[i] -= additionalRelease;
            }
            timeElapsed = 0;
        }
    }
    cout << maxPeople << endl;
    return 0;
}

