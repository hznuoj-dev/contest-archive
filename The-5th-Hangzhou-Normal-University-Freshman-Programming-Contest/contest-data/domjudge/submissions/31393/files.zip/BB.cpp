#include<bits/stdc++.h>
using namespace std;
const int N=2e5+5;
int n;
	int a[N];
	int b[N],c1[N],c2[N];
void slove(){
	
	cin>>n;
	map<int,int>mp,mp1;
	for(int i=0;i<n;i++){
		cin>>a[i];
	//	cout<<a[i]<<endl;
		mp[a[i]]++;
	}
	int k=1;
	for(int i=0;i<n;i++){
		cin>>b[i];mp1[b[i]]++;
	}
	for(int i=0;i<n;i++){
		if(mp[a[i]]!=mp1[a[i]]){
			k=0;
		}
	}
	if(k==1){
		cout<<"0";
		return;
	}
	sort(a,a+n);
	sort(b,b+n);
	int maxx=0,minn=0;
	int mm=0,nn=0;
	for(int i=0;i<n;i++){
		c1[i]=a[i]-b[i];
		if(i==0){
			maxx=c1[i];
			minn=c1[i];
		}
		else{
			maxx=max(maxx,c1[i]);
			minn=min(minn,c1[i]);
			}
	}
	for(int i=0;i<n;i++){
		b[i]=-b[i];
	}
	sort(b,b+n);
	for(int i=0;i<n;i++){
		c2[i]=a[i]-b[i];
		if(i==0){
			mm=c2[i];
			nn=c2[i];
		}
		else{
			mm=max(mm,c2[i]);
			nn=min(nn,c2[i]);
		}
	}
	
	if((maxx!=minn)&&(nn!=mm)){
		cout<<"-1";
		return;
	}
	if((abs(c1[0])>abs(c2[0]))&&(mm==nn)){
		cout<<abs(c2[0])+1;
		return;
	}
	else{
	//	cout<<c1[0]<<endl;;
		cout<<abs(c1[0]);
		return;
	}
	
	return;
}
int main(){
	int T=1;
//	cin>>T;
	while(T--){
		slove();
	}
	
	return 0;
} 
