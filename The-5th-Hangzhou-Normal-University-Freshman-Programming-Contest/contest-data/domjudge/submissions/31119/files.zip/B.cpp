#include <bits/stdc++.h>
using namespace std;
const int M=200005;
int a[M],b[M],n;
int c[M],d[M],e[M];
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=1;i<=n;i++){
		scanf("%d",&b[i]);
	}
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	for(int i=1;i<n;i++){
		c[i]=a[i+1]-a[i];
		d[i]=b[i+1]-b[i];
	}
	n--;
	bool flag=true;
	for(int i=1;i<=n;i++){
		if(c[i]!=d[i]){
			flag=false;
			break;
		}
	}
	if(flag){
		printf("%d",abs(a[1]-b[1]));
		return 0;
	}
	for(int i=1;i<=n;i++){
		int j=n-i+1;
		e[j]=c[i];
	}
	flag=true;
	for(int i=1;i<=n;i++){
		if(e[i]!=d[i]){
			flag=false;
			break;
		}
	}
	if(flag){
		printf("%d",1+abs(a[1]+b[1+n]));
		return 0;
	}
	puts("-1");
	return 0;
}
