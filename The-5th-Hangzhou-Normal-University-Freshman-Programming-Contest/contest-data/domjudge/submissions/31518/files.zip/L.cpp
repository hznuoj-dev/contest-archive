#include <iostream>
#include <bits/stdc++.h>
using namespace std;
double dp[1005][1005];
int m, k;
int a[60], b[60];
int sum = 0;

int main()
{
	cin >> m >> k;
	for (int i = 1; i <= 5; i++)
	{
		cin >> a[i];
		sum += a[i];
	}
	for (int i = 1; i <= 5; i++)
	{
		cin >> b[i];
	}
	for (int i = 1; i <= 5; i++)
	{
		for (int j = 0; j <= 1000; j++)
		{
			dp[i][j] = dp[i - 1][j];
			if (j >= a[i])
			{
				dp[i][j] = max(dp[i][j], dp[i - 1][j - a[i]] + b[i]);
			}
		}
	}
	double maxx = 0;
	for (int i = 1; i <= 1000; i++)
	{
		if (i >= m)
		{
			maxx = max(maxx, dp[5][i] / (i - k));
		}
		else
		{
			maxx = max(maxx, dp[5][i] / i);
		}
	}
	printf("%.2lf", maxx);
	return 0;
}


