#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10,M=1e9+7;
typedef pair<int,int>pii;
int n,k;
struct caozuo{
    int a,b;
}r[N];
long long int a[N],b[N],c[N],d[N],ans;
bool cmp1(caozuo a,caozuo b){
    return a.a>b.a;
}
bool cmp2(int a,int b){
    return a>b;
}
int main(){
    cin.tie(0);cout.tie(0);
    int q=1;
    while(q--){
        int x;
        bool p=0,q=0;
        cin>>x;
        for(int i=1;i<=x;i++){
            cin>>a[i],c[i]=-a[i];
        }
        for(int i=1;i<=x;i++){
            cin>>b[i],d[i]=-b[i];
        }
        sort(a+1,a+x+1);
        sort(b+1,b+x+1);
        for(int i=2;i<x;i++){
            if(abs(a[i]-a[i-1])!=abs(b[i]-b[i-1])){
                p=1;
                break;
            }
        }
        if(!p)ans=abs(a[1]-b[1]);
        sort(c+1,c+x+1);
        sort(d+1,d+x+1);
        for(int i=2;i<=x;i++){
            if(abs(c[i]-c[i-1])!=abs(d[i]-d[i-1])){
                q=1;
                break;
            }
        }
        if(p&&q)ans=-1;
        else if(p)ans=abs(c[1]-d[1])+1;
        else if(!p&&!q)ans=min(ans,abs(c[1]-d[1]+1));
        cout<<ans<<endl;
    }
    return 0;
}