#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;
const int P = 1e9 + 7;

ll qmi(ll a, int b, int m = P){
    ll res = 1;
    a %= m;
    while(b){
        if(b & 1) res = res * a % m;
        a = a * a % m;
        b >>= 1;
    }
    return res;
}

void solve() {
    int n, m, k;
    std::cin >> n >> m >> k;
    std::vector<int>deep(n + 3);
    std::vector<int>du(n + 3);
    std::vector<std::vector<int>>g(n + 3);
    for(int i = 1;i <= m;i++) {
        int u, v;
        std::cin >> u >> v;
        g[u].push_back(v);
        du[v]++;
    }
    std::queue<pii>q;
    for(int i = 1;i <= n;i++) {
        if(du[i] == 0) {
            q.emplace(i, 0);
        }
    }
    std::vector<int>num(n + 3);
    while(!q.empty()) {
        auto [t, d] = q.front();
        q.pop();
        num[d]++;
        for(auto e : g[t]) {
            du[e]--;
            if(du[e] == 0) {
                q.emplace(e, d + 1);
            }
        }
    }
    ll sum = 0;
    ll ans = 0;
    for(int i = n;i >= 0;i--) {
        ans = (ans + num[i] * sum) % P;
        sum += num[i];
    }
    std::cout << qmi(ans, k) << '\n';
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    int T = 1;
    //std::cin >> T;
    while(T--) {
        solve();
    }
}