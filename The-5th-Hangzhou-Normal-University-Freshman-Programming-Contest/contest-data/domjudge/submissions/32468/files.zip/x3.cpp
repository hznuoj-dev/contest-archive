#include <bits/stdc++.h>
#define maxn 200100
#define int long long
using namespace std;
map<pair<int,int>,int>e;
unordered_map<int,int>num;
int ans=0,tmp=0,n;
void solve(){
	unordered_map<int,int>pos;
	int x,y,res,cnt;
	cin >> x >> y;
	res=y;
	pos[x]++;
	do{
		cnt=0;
		for(auto u:e){
			if(pos[u.first.first]==0){
				res=res^u.second;
				pos[u.first.first]++,pos[u.first.second]++;
				pos[u.first.first]%=2,pos[u.first.second]%=2;
			}
		}
		for(int i=1;i<=n;++i)  if(pos[i]==0)  cnt++;
	}while(cnt);
	cout << res << '\n';
}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0);cout.tie(0);
    int q,cnt;  cin >> n;
	for(int i=1;i<n;++i){
		int u,v,w;
		cin >> u >> v >> w;
		e[{u,v}]=w;
		e[{v,u}]=w;
	}
	do{
		cnt=0;
		for(auto u:e){
			if(num[u.first.first]==0){
				ans=ans^u.second;
				num[u.first.first]++,num[u.first.second]++;
				num[u.first.first]%=2,num[u.first.second]%=2;
			}
		}
		for(int i=1;i<=n;++i)  if(num[i]==0)  cnt++;
	}while(cnt);
	cin >> q;
	while(q--){
		if(n%2==0){
			int x,y;
			cin >> x >> y;
			cout << ans << '\n';
		}
		else  solve();
	}
    return 0;
}