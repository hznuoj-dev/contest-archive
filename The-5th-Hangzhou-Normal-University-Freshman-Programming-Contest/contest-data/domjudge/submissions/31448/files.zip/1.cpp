#include<iostream>
#include<algorithm>
using namespace std;
const int N = 2e5 + 5;
int a[N], b[N], c[N], n;
int main()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	for (int i = 1; i <= n; i++)
		cin >> b[i];
	sort(a + 1, a + 1 + n);
	sort(b + 1, b + 1 + n);
	int g = 1, h = 1, ans1 = a[1] - b[1];
	for (int i = 2; i <= n; i++)
	{
		if (a[i] - b[i] != ans1)
		{
			g = 0;
			break;
		}
	}
	for (int i = 1; i <= n; i++)
		a[i] = -a[i];
	sort(a + 1, a + 1 + n);
	int ans2 = a[1] - b[1];
	for (int i = 2; i <= n; i++)
	{
		if (a[i] - b[i] != ans2)
		{
			h = 0;
			break;
		}
	}
	ans1=abs(ans1);
	ans2=abs(ans2)+1; 
	if (g && h)
		cout << min(ans1, ans2) << endl;
	else if (g)
		cout << ans1 << endl;
	else if (h)
		cout << ans2 << endl;
	else
		cout << "-1" << endl;
	return 0;
}
