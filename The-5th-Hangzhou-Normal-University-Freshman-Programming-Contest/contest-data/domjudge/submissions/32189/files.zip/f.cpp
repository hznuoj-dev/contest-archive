#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N=2e5+7,MOD=1e9+7,INF=0x3f3f3f3f,M=1e3+7;
ll n,k,q,a[N],len[N],lenl[N],res[M][M];
int sz,tot,bl[N],L[N],R[N];

struct node{
	int l,r,minn,maxn;
}t[N*4];
void up(int id){
	if(t[id].l==t[id].r) return;
	t[id].minn=min(t[id*2].minn,t[id*2+1].minn);
	t[id].maxn=max(t[id*2].maxn,t[id*2+1].maxn);
}
void build(int id,int l,int r){
	t[id]={l,r,INF,0};
	if(l==r){
		t[id].minn=t[id].maxn=a[l];
		return;
	}
	build(id*2,l,(l+r)/2);
	build(id*2+1,(l+r)/2+1,r);
	up(id);
}
int query(int id,int l,int r,int val){
	int difNow=max(abs(t[id].minn-val),abs(t[id].maxn-val));
	if(difNow<=k) return n+1;
	
	if(t[id].l==l&&t[id].r==r){
		if(t[id].l==t[id].r) return t[id].l;
		int difL=max(abs(t[id*2].minn-val),abs(t[id*2].maxn-val));
		if(difL>k) return query(id*2,t[id*2].l,t[id*2].r,val);
		else return query(id*2+1,t[id*2+1].l,t[id*2+1].r,val);
	}
	int mid=(t[id].l+t[id].r)/2;
	if(r<=mid) return query(id*2,l,r,val);
	else if(l>mid) return query(id*2+1,l,r,val);
	else return min(query(id*2,l,mid,val),query(id*2+1,mid+1,r,val));
}
int query2(int id,int l,int r,int val){
	int difNow=max(abs(t[id].minn-val),abs(t[id].maxn-val));
	if(difNow<=k) return 0;
	
	if(t[id].l==l&&t[id].r==r){
		if(t[id].l==t[id].r) return t[id].l;
		int difR=max(abs(t[id*2+1].minn-val),abs(t[id*2+1].maxn-val));
		if(difR>k) return query2(id*2+1,t[id*2+1].l,t[id*2+1].r,val);
		else return query2(id*2,t[id*2].l,t[id*2].r,val);
	}
	int mid=(t[id].l+t[id].r)/2;
	if(r<=mid) return query2(id*2,l,r,val);
	else if(l>mid) return query2(id*2+1,l,r,val);
	else return max(query2(id*2,l,mid,val),query2(id*2+1,mid+1,r,val));
}

void solve(){
	cin>>n>>k>>q;
	for(int i=1;i<=n;i++) cin>>a[i];
	a[n+1]=2e9+7;
	build(1,1,n+1);
	for(int i=1;i<=n;i++){
		len[i]=query(1,i+1,n+1,a[i])-i;
		lenl[i]=i-query2(1,1,i-1,a[i]);
	}
	
	sz=sqrt(n);
	tot=(n+sz-1)/sz;
	for(int i=1;i<=n;i++){
		bl[i]=(i-1)/sz+1;
		if(L[bl[i]]==0) L[bl[i]]=i;
		R[bl[i]]=i;
	}
	
	for(int r=tot;r>=1;r--){
		for(int l=r;l>=1;l--){
			if(l<r) res[l][r]=res[l+1][r];
			for(int i=L[l];i<=R[l];i++){
				res[l][r]+=min(len[i],1ll*R[r]-i+1);
			}
		}
	}
	
	while(q--){
		int l,r;
		cin>>l>>r;
		ll ans=0;
		if(bl[l]==bl[r]){
			for(int i=l;i<=r;i++){
				ans+=min(1ll*r-i+1,len[i]);
			}
		}else{
			int bL=bl[l]+1,bR=bl[r]-1;
			if(bL<=bR) ans+=res[bL][bR];
			for(int i=l;i<L[bL];i++){
				ans+=min(1ll*r-i+1,len[i]);
			}
			for(int i=r;i>R[bR];i--){
				ans+=min(1ll*i-L[bL]+1,lenl[i]);
			}	
		}
		cout<<ans<<'\n';
	}
}

int main(){
	ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
	int tc=1;
//	cin>>tc;
	while(tc--) solve();
	return 0;
}
/*
5 2 4
1 3 3 5 3
1 5
1 4
2 3
3 3

*/
