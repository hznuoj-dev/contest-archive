#include <bits/stdc++.h>
using namespace std;
const int N = 200005;
int a[N], b[N], tdel[N], del[N];
int ta[N], tb[N];
int neg[N] = {};
bool cmp(int x, int y) {
	return abs(x) < abs(y);
}
int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n, cost = 0, flag = 1;
	cin >> n;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
		ta[i] = abs(a[i]);
	}
	for(int i = 1; i <= n; i++) {
		cin >> b[i];
		tb[i] = abs(b[i]);
	}
	sort(ta + 1, ta + 1 + n);
	sort(tb + 1, tb + 1 + n);
	sort(a + 1, a + 1 + n);
	sort(b + 1, b + 1 + n);
	for(int i = 1; i <= n; i++) {
		tdel[i] = tb[i] - ta[i];
		del[i] = b[i] - a[i];
	}
//	cout << "del: \n";
//	for(int i = 1; i <= n; i++) {
//		cout << del[i] << " ";
//	}
//	cout << "\ntdel: \n";
//	for(int i = 1; i <= n; i++) {
//		cout << tdel[i] << " ";
//	}
//	cout << "\n";
	sort(del + 1, del + 1 + n);
	sort(tdel + 1, tdel + 1 + n);
	for(int i = 2; i <= n; i++) {
		if(tdel[i - 1] != tdel[i]) {
			flag = 0;
			break;
		}
		if(del[i - 1] != del[i]) {
			flag = 0;
			break;
		}
	}
	if(!flag) {
		cout << "-1\n";
	} else {
		cost += abs(del[1]);
		if(n != 1) {
			for(int i = 1; i <= n; i++) {
				if((a[i] < 0 && b[i] > 0) || (a[i] > 0 && b[i] < 0)) {
					neg[i]++;
				}
			}
			sort(neg + 1, neg + n + 1);
			for(int i = 2; i <= n; i++) {
				if(neg[i - 1] != neg[i]) {
					flag = 0;
					break;
				}
			}
		}
		if(!flag) {
			cout << "-1\n";
		} else {
			cost += neg[1];
			cout << cost << "\n";
		}
	}
	return 0;
}
/*
1
-3
2

3
4 5 6
-7 -8 -9

6
1 -3 4 2 8 9
2 -4 5 3 9 10
*/
