#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int a[N],b[N];
int main() {
	int n;
	cin>>n;
	for(int i=1; i<=n; i++){
		cin>>a[i];
		b[i]=a[i];
	}
	sort(b+1,b+n+1);
	if(a[1]>a[n]){
		int num1=0,num2=0,num=0;
		for(int i=1;i<=n;i++){
			if(a[i]<a[1]){
				num1++;
			}else if(a[i]>a[1]){
				num2++;
			}
		}
		if(num1==num2) num++;
		num1=0;num2=0;
		for(int i=1;i<=n;i++){
			if(a[i]<a[n]){
				num1++;
			}else if(a[i]>a[n]){
				num2++;
			}
		}
		if(num1==num2) num++;
		cout<<num;
	}else if(b[n/2+1]==b[(n+1)/2]){
		if(b[n/2+1]<a[1]||b[n/2+1]>a[n]){
			cout<<"0";
		}else{
			int num1=0,num2=0;
			for(int i=1;i<=n;i++){
				if(a[i]<b[n/2+1]){
					num1++;
				}else if(a[i]>b[n/2+1]){
					num2++;
				}
			}
			if(num1==num2)
				cout<<"1";
			else
				cout<<"0";	
		}
	}else{
		cout<<min(a[n],b[n/2+1])-max(a[1],b[(n+1)/2])-1;
	}
	return 0;
}
