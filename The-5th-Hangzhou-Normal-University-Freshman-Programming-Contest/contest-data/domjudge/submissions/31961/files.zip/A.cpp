        #include<iostream>
        #include<algorithm>
        #include<queue>
        #include<cmath>
        #include<map>
        #include<iomanip>
        #include<stack>
        #define shojig ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
        using namespace std;
        typedef long long ll;
        ll a[2000000]={0},dp[2000000]={0};
		int main()
        {
        	ll n,m,b;
        	cin>>n>>m>>b;
        	for(int i=1;i<=n;i++){
        		cin>>a[i];
        		a[i]=a[i]+a[i-1];
			}
			for(int i=1;i<=n;i++)
			{
				if(i>=m+1){
					if(a[i]-dp[i-m]>=b)
					dp[i]=max(dp[i-1],dp[i-m]+b);
					else dp[i]=max(dp[i-1],a[i]);
				}
				else dp[i]=min(b,a[i]);
			}
			cout<<dp[n];
		}
		 
