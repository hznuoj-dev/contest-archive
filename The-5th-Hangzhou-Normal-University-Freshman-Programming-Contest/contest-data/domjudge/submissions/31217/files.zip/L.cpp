#include <iostream>

using namespace std;

const int N = 10;
int a[N], b[N];
int m, k;
int vv = 0, ww = 0;
double res = 0;
// v 价格
void dfs(int x, int v, int w)
{
    if (x == 5)
    {
        if (v != 0)
        {
            if (v >= m)
                v = v - k;
            res = max(res, w * 1.0 / v);
        }
        return;
    }
    dfs(x + 1, v, w);
    dfs(x + 1, v + a[x], w + b[x]);
}

int main()
{
    scanf("%d%d", &m, &k);
    for (int i = 0; i < 5; i++)
        scanf("%d", &a[i]);
    for (int i = 0; i < 5; i++)
        scanf("%d", &b[i]);
    dfs(0, 0, 0);
    printf("%.2f", res);
    return 0;
}