#include <bits/stdc++.h>
#define fp(i, a, b) for(int i = (a), ed = (b); i <= ed; ++i)
#define fb(i, a, b) for(int i = (a), ed = (b); i >= ed; --i)
#define go(u, i) for(int i = head[u]; i; i = e[i].nxt)
using namespace std;
typedef long long LL;
typedef pair<int, int> pii;
inline int rd() {
	register int x(0), f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline LL RD() {
	register LL x(0); register int f(1); register char c(getchar());
	while (c < '0' || '9' < c) { if (c == '-')f = -1; c = getchar(); }
	while ('0' <= c && c <= '9')x = x*10 + c-'0', c = getchar();
	return x*f;
}
inline int int_rand(int l, int r){
	int res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
inline LL LL_rand(LL l, LL r){
	LL res = 1.0l*rand()/RAND_MAX*(r-l+1);
	if(res == r-l+1)res = r-l;
	return l+res;
}
const int maxn = 1010;
int T, n, stk[maxn], tp, id[maxn][maxn];
struct edge{int to, nxt;}e[maxn<<1];
int head[maxn], k;
inline void add(int u, int v){e[++k] = (edge){v, head[u]}, head[u] = k;}
bool dfs(int u, int pre, int des){
	stk[++tp] = u;
	if(u == des)return 1;
	go(u, i)if(e[i].to != pre && dfs(e[i].to, u, des))return 1;
	return --tp, 0;
}
int main(){
	T = rd();
	while(T--){
		n = rd(), memset(head, 0, sizeof head), k = 0;
		fp(i, 2, n){
			int u = rd(), v = rd();
			add(u, v), add(v, u), id[u][v] = id[v][u] = i-1;
		}
		int u, v;
		while(1){
			u = int_rand(1, n), v = int_rand(1, n);
			printf("? %d %d\n", u, v), fflush(stdout);
			int res = rd();
			if(res)break;
		}
		tp = 0, dfs(u, 0, v);
		int l = 2, r = tp, res = 0;
		while(l <= r){
			int md = l+r>>1;
			printf("? %d %d\n", stk[l-1], stk[md]), fflush(stdout);
			if(rd())res = md, r = md-1;
			else l = md+1;
		}
		printf("! %d\n", id[stk[res]][stk[res-1]]), fflush(stdout);
	}
	return 0;
}
