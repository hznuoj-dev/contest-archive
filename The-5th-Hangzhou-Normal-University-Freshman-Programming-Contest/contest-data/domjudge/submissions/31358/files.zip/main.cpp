#include <iostream>
#include <algorithm>
#include <cstring>
#include <map>
#include <vector>
#include <stack>

using namespace std;

int n, m;
long long a[200005];
long long b[200005];
long long da[200005];
long long db[200005];
long long c[200005];
long long dc[200005];

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; ++i)
    {
        cin >> a[i];
        c[i] = -a[i];
    }
    for (int i = 1; i <= n; ++i)
    {
        cin >> b[i];
    }
    sort(a + 1, a + n + 1);
    sort(b + 1, b + n + 1);
    sort(c + 1, c + n + 1);
    int flag = 0;
    for (int i = 1; i <= n; ++i)
    {
        if (a[i] != b[i])
        {
            flag = 1;
            break;
        }
    }
    if (!flag)
    {
        cout << 0 << endl;
        return;
    }
    for (int i = 1; i <= n; ++i)
    {
        da[i] = a[i] - a[i - 1];
        db[i] = b[i] - b[i - 1];
        dc[i] = c[i] - c[i - 1];
    }
    flag = 0;
    for (int i = 2; i <= n; ++i)
    {
        if (da[i] != db[i])
        {
            flag = 1;
            break;
        }
    }
    long long res = -1;
    if (!flag)
    {
        res = abs(a[1] - b[1]);
    }
    flag = 0;
    for (int i = 2; i <= n; ++i)
    {
        if (dc[i] != db[i])
        {
            flag = 1;
            break;
        }
    }
    if (!flag)
    {
        if (res == -1)
        {
            res = abs(c[1] - b[1]) + 1;
        }
        else
        {
            res = min(res, abs(c[1] - b[1]) + 1);
        }
    }
    cout << res;
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    int t = 1;
    // cin >> t;
    while (t--)
    {
        solve();
    }
}