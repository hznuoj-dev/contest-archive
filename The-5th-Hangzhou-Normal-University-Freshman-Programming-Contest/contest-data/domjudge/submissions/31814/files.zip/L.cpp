#include <iostream>
#include <cstdio>
#include <cmath>
using namespace std;

int dp[1000];

int main() {
    int m, k, i, j;
    int a[5], b[5];
    double maxn, t;
    int x;
    cin >> m >> k;
    for (i = 0; i < 5; i++) {
        cin >> a[i];
    }
    for (i = 0; i < 5; i++) {
        cin >> b[i];
    }
    for (i = 0; i < 1000; i++)
        dp[i] = 0;
    for (i = 0; i < 5; i++) {
        for (j = 0; j < 1000; j++) {
            if (j > a[i]) {
                dp[j] = max(dp[j], dp[j - a[i]] + b[i]);
            }
        }
    }
    maxn = 0;
    for (i = 0; i < m; i++) {
        t = dp[i] * 1.0 / i;
        if (t > maxn) 
            maxn = t;
    }
    for (; i < 1000; i++) {
        t = dp[i] * 1.0 / (i - k);
        if (t > maxn) 
            maxn = t;
    }
    printf("%.2f", maxn);
    return 0;
}