#include<bits/stdc++.h>
using namespace std;

const int N = 1e6;
int a[N], n;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	
	int n, m, b; 				cin >> n >> m >> b;
	for(int i = 1; i <= n; ++i) cin >> a[i];
	
	
	int x = 0;
	for(int st = 1; st <= m; ++st)
	{
		int bin = 0, ans = 0;
		for(int i = st, j = 1; j <= n; ++j)
		{
			bin += a[j];
		
			if(i == j)
			{
				i = i + m;
				int del = min(b, bin);
				ans += del;
				bin -= del;
			}
		}
		x = max(x, ans);
	}
	
	cout << x;
}
