#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;

int num0[200010];
int num[200010];

void solve(){
    int n;
    cin >> n;

    for (int i = 0; i < n; ++i){
        cin >> num[i];
        num0[i] = num[i];
    }
    sort(num, num+n);

    int l, r;
    if (n&1 == 1){
        l = r = num[n/2];
    }
    else{
        if (num[n/2-1] == num[n/2]){
            l = r = num[n/2];
        }
        else {
            l = num[n/2-1] + 1;
            r = num[n/2] - 1;
        }
    }

    int last = 0;
    for (int i = 0; i < n; ++i){
        if (num0[i] < l){
            last += 1;
        }
        else if (num0[i] > r){
            last -= 1;
            if (last < 0) break;
        }
    }

    if (last) cout << 0 << endl;
    else {
        if (l == r) cout << 1 << endl;
        else cout << r-l+1 << endl;
    }

    return ;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T = 1;
    // cin >> T;

    while (T--){
        solve();
    }

    return 0;
}
