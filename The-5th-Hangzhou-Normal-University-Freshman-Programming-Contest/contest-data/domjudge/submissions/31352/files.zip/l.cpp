#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
struct node{
	int pj,jg;
	double xjb;
}a[6];
bool cmp(node a,node b){
	return a.xjb>b.xjb;
}
int main(){
	int m,k;
	cin>>m>>k;
	for(int i=1;i<=5;i++)
		cin>>a[i].jg;
	for(int i=1;i<6;i++)	
		cin>>a[i].pj;
	for(int i=1;i<=5;i++)	
		a[i].xjb=a[i].pj*1.0/a[i].jg;
	sort(a+1,a+6,cmp);
	int zj=0,zp=0,jian=0;
	double maxn=0;
	for(int i=1;i<=5;i++){
		zj+=a[i].jg;
		zp+=a[i].pj;
		if(zj-jian*m>=m){
			zj-=k;
			jian++;
		}
		maxn=max(maxn,zp*1.0/zj);
	}	
	printf("%.2f",maxn);
	return 0;
}
