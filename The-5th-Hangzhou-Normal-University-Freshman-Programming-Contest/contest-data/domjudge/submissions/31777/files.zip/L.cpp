#include<iostream>
#include<stdio.h>
using namespace std; 
float a[10],b[10]; 
float m,k; 
float dfs(int p, float cost, float cnt){
	float ans = 0; 
	if(cost)
		ans = cnt/cost; 
	if(cost >= m)
		ans = cnt/(cost-k); 
	for(int i = p+1;i<=5;++i)
		ans = max(ans, dfs(i,cost+a[i],cnt+b[i])); 
	return ans; 
}

int main(){
	cin>>m>>k; 
	for(int i = 1;i<=5;++i)
	cin>>a[i]; 
	for(int i = 1;i<=5;++i)
	cin>>b[i]; 
	printf("%.2f",dfs(0,0,0)); 
}
