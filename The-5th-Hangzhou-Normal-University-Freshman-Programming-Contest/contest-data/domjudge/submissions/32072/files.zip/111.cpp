#include<iostream>
using namespace std;
int main()
//{
//	long long a[50001], b[50001], c[50001];
//	int n;
//	cin >> n;
//	for (int i = 1; i <= n; i++)
//	{
//		cin >> a[i];
//	}
//	for (int i = 1; i <= n; i++)
//	{
//		cin >> b[i];
//		c[i] = -b[i];
//	}
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= n - i; j++)
//		{
//			if (a[j] > a[j + 1])
//			{
//				long long temp = a[j];
//				long long temp1 = a[j + 1];
//				a[j] = temp1;
//				a[j + 1] = temp;
//			}
//			if (b[j] > b[j + 1])
//			{
//				long long temp = b[j];
//				long long temp1 = b[j + 1];
//				b[j] = temp1;
//				c[j] = -temp1;
//				b[j + 1] = temp;
//				c[j + 1] = -temp;
//			}
//		}
//	}
//	int m = 0;
//	int t = 0;
//
//	for (int i = 1; i <= n; i++)
//	{
//		if (a[i] < 0)
//		{
//			m++;
//		}
//		if (b[i] < 0)
//		{
//			t++;
//		}
//	}
//	if (m != t && (n - m) != t)
//	{
//		cout << -1;
//		return 0;
//	}
//	for (int i = 1; i <= m; i++)
//	{
//		for (int j = 1; j <= m - i; j++)
//		{
//			long long temp = a[j];
//			a[j] = a[j + 1];
//			a[j + 1] = temp;
//		}
//	}
//	for (int i = 1; i <= t; i++)
//	{
//		for (int j = 1; j <= t - i; j++)
//		{
//			long long temp = b[j];
//			b[j] = b[j + 1];
//			b[j + 1] = temp;
//		}
//	}
//	for (int i = 1; i <= n; i++)
//	{
//		for (int j = 1; j <= n - i; j++)
//		{
//			if (c[j] > c[j + 1])
//			{
//				long long temp = c[j];
//				long long temp1 = c[j + 1];
//				c[j] = temp1;
//				c[j + 1] = temp;
//			}
//		}
//	}
//	for (int i = 1; i <= n - t; i++)
//	{
//		for (int j = 1; j <= n - t - i; j++)
//		{
//			if (c[j] < c[j + 1]) {
//				long long temp = c[j];
//				c[j] = c[j + 1];
//				c[j + 1] = temp;
//			}
//		}
//	}
//
//	long long x = a[1], y = b[1], z = c[1];
//	for (int i = 1; i <= n; i++)
//	{
//		long long x1 = a[i], y1 = b[i], z1 = c[i];
//		if (x1 - y1 != x - y)
//		{
//			if (x1 - z1 != x - z)
//			{
//				cout << -1;
//				return 0;
//
//			}
//		}
//	}
//
//	if (m = n - t)
//	{
//		cout << abs(x - z) + 1;
//		return 0;
//
//	}
//	if (m == t)
//	{
//		if (x * y >= 0)
//		{
//			cout << abs(x - y); return 0;
//		}
//		if (x * y < 0)
//		{
//			x = -x;
//			cout << abs(x - y) + 1; return 0;
//		}
//	}
//	return 0;
//}
{
	int m, k;
	cin >> m >> k;
	double a[3][6];
	for (int i = 1; i <= 2; i++)
	{
		for (int j = 1; j <= 5; j++)
		{
			cin >> a[i][j];
		}
	}
	double x1 = a[1][1], y1 = a[2][1];
	double max = y1 / x1;

	for (int i = 1; i <= 5; i++)
	{
		double x = a[1][i], y = a[2][i];
		if (a[1][i] >= m)
		{
			if (max < y / (x - k))
				max = y / (x - k);
		}
		else
		{
			if (max < y / x)
				max = y / x;
		}
	}

	int j = 2;
	for (int i = 1; i <= 4; i++)
	{
		for (j = i + 1; j <= 5; j++)
		{
			double x = a[1][i], y = a[2][i];
			double x2 = a[1][j], y2 = a[2][j];
			if (x + x2 >= m)
			{
				if (max < (y + y2) / (x + x2 - k))
					max = (y + y2) / (x + x2 - k);
			}
			else
			{
				if (max < (y + y2) / (x + x2))
					max = (y + y2) / (x + x2);
			}
		}
	}

	int j1 = 2, l = 3;
	for (int i = 1; i <= 3; i++)
	{
		for (j1 = i + 1; j1 <= 4; j1++)
		{
			for (l = j1 + 1; l <= 5; l++)
			{
				double x = a[1][i], y = a[2][i];
				double x2 = a[1][j1], y2 = a[2][j1];
				double x3 = a[1][l], y3 = a[2][l];
				if (x + x2 + x3 >= m)
				{
					if (max < (y + y2 + y3) / (x + x2 + x3 - k))
					{
						max = (y + y2 + y3) / (x + x2 + x3 - k);
					}
				}
				else
					if (max < (y + y2 + y3) / (x + x2 + x3))
						max = (y + y2 + y3) / (x + x2 + x3);
			}
		}
	}

	double num = 0, num1 = 0;
	for (int i = 1; i <= 5; i++)
	{
		for (int j2 = 2; j2 != i && j <= 5; j2++)
		{
			double t = a[1][j2], u = a[2][j2];
			num = num + t;
			num1 = num1 + u;
		}
		if (num >= m)
		{
			if (max < num1 / (num - k))
				max = num1 / (num - k);

		}
		else
			if (max < num1 / num)
				max = num1 / num;
	}

	int h1 = 0, h2 = 0;
	for (int i = 1; i <= 5; i++)
	{
		double t = a[1][i], u = a[2][i];
		h1 = h1 + t;
		h2 = h2 + u;
	}
	if (h1 >= m)
	{
		if (max < h2 / (h1 - k))
		{
			max = h2 / (h1 - k);
		}
	}
	else
	{
		if (max < h2 / h1)
			max = h2 / h1;
	}
	printf("%.2lf", max);
	return 0;
}
