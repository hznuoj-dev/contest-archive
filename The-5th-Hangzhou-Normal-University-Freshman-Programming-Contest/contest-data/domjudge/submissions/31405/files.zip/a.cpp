#include<iostream>
using namespace std;
#include<algorithm>

//A
const int N=2e5+7;
int buk[N];
int a[N];
int n;

//����������Ӧ������������һ�� 

bool check(int k){
	int num=0;
	for(int i=1;i<=n;i++){
		if(a[i]>k)num--;
		else if(a[i]<k)num++;
		if(num<0)return false;
	}
	if(num>0)return false;
	return true;
}

int cmp(int&a,int&b){return a<b;}

int main(){
	
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		buk[i]=a[i];
	}
	sort(buk+1,buk+1+n,cmp);
//	for(int i=1;i<=n;i++)cout<<buk[i]<<" ";
//	cout<<endl;

	int k,num=0;
	if(n%2==1){
		k=buk[n/2+1];
		if(check(k))num++;
		cout<<num<<endl;
	}else{
		int l=buk[n/2],r=buk[n/2+1];
		if(l==r){
			k=buk[n/2];
			if(check(k))num++;
			cout<<num<<endl;
		}else if(l+1==r){
			cout<<0<<endl;
		}else if(l+1<r){
			k=l+1;
			if(check(k))num=r-l-1;
			cout<<num<<endl;
		}
	}
}













