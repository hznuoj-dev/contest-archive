#include <iostream>
#include <algorithm>
#include <cmath>
using namespace std;
const int N = 2 * 1e5 + 10;
int a[N], b[N];
int main()
{
    int n;
    cin >> n;
    int i, j, k, l, res = 0;
    for(i = 0; i < n; i++)
        cin >> a[i];
    for(i = 0; i < n; i++)
        cin >> b[i];
    sort(a, a + n);
    sort(b, b + n);
    //cout << abs(a[0] + b[n - 1]) << endl;
    if (abs(a[0] - b[0]) < abs(a[0] + b[n - 1]) + 1)
    {
        res = abs(a[0] - b[0]);
        k = abs(a[0] - b[0]);
        i = 0;
        while(i < n)
        {
            if (abs(a[i] - b[i]) != k)
            {
                cout << -1 << endl;
                return 0;
            }
            i++;
        }
        cout << res << endl;
    }
    else
    {
        res = abs(a[0] + b[n - 1]) + 1;
        k = abs(a[0] + b[n - 1]);
        i = 0;
        while(i < n)
        {
            if (abs(a[i] + b[n - 1 - i]) != k)
            {
                cout << -1 << endl;
                return 0;
            }
            i++;
        }
        cout << res << endl;
    }

}