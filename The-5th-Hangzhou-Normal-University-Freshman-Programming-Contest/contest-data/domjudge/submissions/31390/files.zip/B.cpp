#include <iostream>
#include <algorithm>
using namespace std;

int a[200005];
int b[200005];
int c[200005];

int main() {
    int n, res1 = -1, res2 = -1, i, res;
    cin >> n;
    for (i = 0; i < n; i++) {
        cin >> a[i];
        b[i] = a[i] * -1;
    }
    for (i = 0; i < n; i++) {
        cin >> c[i];
    }
    sort(a, a + n);
    sort(b, b + n);
    sort(c, c + n);
    res = c[0] - a[0];
    for (i = 1; i < n; i++) {
        if (c[i] - a[i] != res)
            break;
    }
    if (i == n) {
        if (res < 0)
            res *= -1;
        res1 = res;
    }
    res = c[0] - b[0];
    for (i = 1; i < n; i++) {
        if (c[i] - b[i] != res)
            break;
    }
    if (i == n) {
        if (res < 0)
            res *= -1;
        res2 = res + 1;
    }
    if (res1 != -1 && res2 != -1) {
        if (res1 < res2) {
            cout << res1 << endl;
        } else {
            cout << res2 << endl;
        }
    } else if (res1 != -1) {
        cout << res1;
    } else if (res2 != -1) {
        cout << res2;
    } else {
        cout << -1 << endl;
    }
    return 0;
}