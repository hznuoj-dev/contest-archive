#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N=2e6+5;
ll n,m,b,a[N],sum,ans;
bool flag[N];
int main()
{
	scanf("%lld%lld%lld",&n,&m,&b);
	for(int i=n;i>=1;i-=m)flag[i]=1;
	for(int i=1;i<=n;++i)
	{
		scanf("%lld",&a[i]);
		sum+=a[i];
		if(flag[i])
		{
			if(sum<b)ans+=sum,sum=0;
			else ans+=b,sum-=b;
		}
	}
	printf("%lld\n",ans);
	return 0;
}
