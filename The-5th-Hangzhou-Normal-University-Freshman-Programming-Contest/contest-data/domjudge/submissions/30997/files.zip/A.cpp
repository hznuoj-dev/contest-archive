#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;

int num[200010];

void solve(){
    int n;
    cin >>  n;

    for (int i = 0; i < n; ++i){
        cin >> num[i];
    }
    sort(num, num+n);

    if (n&1 == 1) cout << 1 << endl;
    else if (num[n/2] == num[n/2-1]) cout << 1 << endl;
    else cout << num[n/2] - num[n/2-1] -1 << endl;

    return ;
}

signed main()
{
    ios::sync_with_stdio(false);
    cin.tie(NULL);

    int T = 1;
    // cin >> T;

    while (T--){
        solve();
    }

    return 0;
}
