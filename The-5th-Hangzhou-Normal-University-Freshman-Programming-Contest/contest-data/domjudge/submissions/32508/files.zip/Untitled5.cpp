#include <bits/stdc++.h>

const int N = 2e5 + 7;
std::vector<int> v[N], w[N];

void solve() {
	int n;
	std::cin >> n;
	std::vector<int> du(n + 1, 0ll);
	std::vector<int> ww(n + 1, 0ll);	
	for (int i = 1; i <= n - 1; i++) {
		int ui, vi, wi;
		std::cin >> ui >> vi >> wi;
		du[ui]++;
		du[vi]++;
		ww[ui] = wi, ww[vi] = wi;
	}
	int ans = 0;
	for (int i = 1; i <= n; i++) {
		if (du[i] == 1) {
			ans ^= ww[i];
		}
	}
	int q;
	std::cin >> q;
	while (q--) {
		int l, r;
		std::cin >> l >> r;
		std::cout << ans << "\n";
	}
	
}

int main() {
	solve();
}
