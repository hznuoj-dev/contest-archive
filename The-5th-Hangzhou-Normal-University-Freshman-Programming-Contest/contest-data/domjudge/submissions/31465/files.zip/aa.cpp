#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
//#define int ll
const int N=2e5+7,mod=1e9+7;
int n,a[N],cnt[N];
int check(int m){
	int cnt1=0,cnt2=0;
	for(int i=1;i<=n;i++){
		if(a[i]<m)cnt1++;
		if(a[i]>m)cnt2++;
		if(cnt2>cnt1)return 0;
	}
	if(cnt1!=cnt2)return 0;
	return 1;
}
void solve(){
	cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i],cnt[a[i]]++;
	for(int i=1;i<N;i++)cnt[i]+=cnt[i-1];
	int le=0,re=N-1,l=1,r=N-1;
	while(l<=r){
		int mid=l+r>>1;
		if(cnt[mid-1]>=cnt[N-1]-cnt[mid]){
			le=mid;
			r=mid-1;
		}else{
			l=mid+1;
		}
	}
	l=1,r=N-1;
	while(l<=r){
		int mid=l+r>>1;
		if(cnt[mid-1]>cnt[N-1]-cnt[mid]){
			re=mid;
			r=mid-1;
		}else if(cnt[mid-1]==cnt[N-1]-cnt[mid]){
			re=mid;
			l=mid+1;
		}else{
			l=mid+1;
		}
	}
	int ans=0;
	if(le>re){
		cout<<"-1\n";
	}else if(le==re){
		cout<<check(le)<<'\n';
	}else if(le+1==re){
		if(check(le))ans++;
		if(check(re))ans++;
		cout<<ans<<'\n';
	}else{
		if(check(le))ans++;
		if(check(re))ans++;
		ans+=check(le+1)*(re-le-1);
		cout<<ans<<'\n';
	}
}
signed main(){
	int t=1;
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cin>>t;
	while(t--)solve();
	return 0;
}
