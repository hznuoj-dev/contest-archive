#include <iostream>
#include <cstdio>
using namespace std;

int a[200005];

int main() {
    int n, kmin = 1, kmax = 200000;
    int i, j, k, res;
    scanf("%d", &n);
    for (i = 0; i < n; i++) {
        scanf("%d", &a[i]);
    }
    i = 0;
    j = 0;
    while (i < n) {
        for (k = i + 1; k < n; k++) {
            if (a[k] < a[k - 1])
                break;
        }
        if ((k - j) & 1) {
            if (kmin < a[(k + j) / 2])
                kmin = a[(k + j) / 2];
            if (kmax > a[(k + j) / 2]) 
                kmax = a[(k + j) / 2];
        } else {
            if (kmin < a[(k + j) / 2 - 1])
                kmin = a[(k + j) / 2 - 1];
            if (kmax > a[(k + j) / 2])
                kmax = a[(k + j) / 2];
        }
        j = k;
        i = k;
    }
    if (kmin < kmax) {
        printf("%d\n", kmax - kmin - 1);
    } else if (kmin == kmax) {
        printf("1\n");
    } else {
        printf("0\n");
    }
    return 0;
}