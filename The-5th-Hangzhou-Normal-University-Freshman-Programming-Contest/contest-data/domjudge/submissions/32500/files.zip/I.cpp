#include <iostream>
#include <unordered_set>
#include <vector>
using namespace std;
const int N = 1e3 + 10;
unordered_set<int> edges[N];
int mark[N], flag, f[N], dep[N], G[N][N];

void init(int u, int fa) {
    dep[u] = dep[fa] + 1;
    f[u] = fa;
    edges[u].erase(fa);
    for(int nxt: edges[u])  init(nxt, u);
}

vector<int> path1, path2;

void findPath(int u, int v) {
    path1.clear();
    path2.clear();
    path1.push_back(u);
    path2.push_back(v);
    while(u != v) {
        if(dep[u] >= dep[v])    {
            u = f[u];
            path1.push_back(u);
        } else {
            v = f[v];
            path2.push_back(v);
        }
    }

    for(int i = path2.size() - 2; i >= 0; i--)  path1.push_back(path2[i]);
}

void find(int u, int v) {
    findPath(u, v);
    int lh = 0, rh = path1.size() - 1, x;
    while(lh + 1 < rh) {
        int mid = (lh + rh) / 2;
        printf("? %d %d\n", path1[mid], path1[rh]);
        fflush(stdout);
        scanf("%d", &x);
        if(x == 1) {
            lh = mid;
        } else {
            rh = mid;
        }
    }
    printf("! %d\n", G[path1[lh]][path1[lh+1]]);
    fflush(stdout);
}

void dfs(int u, int fa) {
    // printf("::%d\n", u);
    if(flag)    return;
    vector<int> v;
    for(int nxt: edges[u]) {
        dfs(nxt, u);
        v.push_back(nxt);
    }
    // printf(":%d\n", v.size());
    int x;
    for(int i = 1; i < v.size(); i += 2) {    
        if(flag)    return;
        printf("? %d %d\n", mark[v[i-1]], mark[v[i]]);
        fflush(stdout);
        scanf("%d", &x);
        if(x)   {
            find(mark[v[i-1]], mark[v[i]]);
            flag = 1;
            return;
        }
        edges[u].erase(v[i-1]);
        edges[u].erase(v[i]);
    }
    if(edges[u].empty())    mark[u] = u;
    else                    mark[u] = mark[v.back()];
    if(u == 1)  find(1, mark[1]); 
}

void solve()
{
    int n;
    scanf("%d", &n);
    int u, v;
    for(int i = 1; i <= n; i++) edges[i].clear();
    for(int i = 1; i < n; i++) {
        scanf("%d %d", &u, &v);
        edges[u].insert(v);
        edges[v].insert(u);
        G[u][v] = G[v][u] = i;
    }

    init(1, 0);
    flag = 0;
    dfs(1, 1);
}


int main()
{
    int T;
    scanf("%d", &T);
    while(T--)  solve();

    return 0;
}