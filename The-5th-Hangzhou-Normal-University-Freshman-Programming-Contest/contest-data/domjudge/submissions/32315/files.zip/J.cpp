#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int M=2000005,mod=1e9+7;
ll ans;
struct node{
	int v,lst;
}t[M];
int head[M],tot;
void add(int u,int v){
	t[++tot].v=v;
	t[tot].lst=head[u];
	head[u]=tot;
}
map<ll,bool>mp;
ll qpow(ll a,ll b,ll p){
	ll res=1;
	while(b)
	{
		if(b&1) res=(res*a)%p;
		a=(a*a)%p;
		b>>=1;
	}
	return res;
}
ll w[M],st[M],r[M];
queue<ll>q;
int main()
{
	ll bs=1e5+7,n,u,v,m,l,k,mx=0,sum=0;
	scanf("%lld%lld%lld",&n,&m,&k);
	for(int i=1;i<=m;i++)
	{
		scanf("%lld%lld",&u,&v);
		l=u*bs+v;
		if(mp[l]) continue;
		mp[l]=true;
		add(u,v);
		r[v]++;
	}
	for(int i=1;i<=n;i++)
	{
		if(r[i]==0) q.push(i);
	}
	while(!q.empty())
	{
		u=q.front();
		q.pop();
		for(int i=head[u];i;i=t[i].lst)
		{
			v=t[i].v;
			w[v]=max(w[v],w[u]+1);
			r[v]--;
			if(r[v]==0) q.push(v);
		}
	}
	for(int i=1;i<=n;i++)
	{
		st[w[i]]++;
		mx=max(w[i],mx);
	}
	for(int i=mx;i>=0;i--) ans=(ans+sum*st[i]),sum+=st[i];
	printf("%lld",qpow(ans,k,mod));
	return 0;
}