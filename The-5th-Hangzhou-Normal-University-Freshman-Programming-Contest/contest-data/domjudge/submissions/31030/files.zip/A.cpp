        #include<iostream>
        #include<algorithm>
        #include<queue>
        #include<cmath>
        #include<map>
        #include<iomanip>
        #include<stack>
        #define shojig ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
        using namespace std;
        typedef long long ll;
        double max(double a,double b){
        	if(a>=b)return a;
        	return b;
		}
        int main()
        {
            double m,k,a[6],b[6],maxx=0;
            cin>>m>>k;
            for(int i=1;i<=5;i++)cin>>a[i];
            for(int i=1;i<=5;i++){
            	cin>>b[i];
            	if(a[i]>=m) maxx=max(b[i]/(a[i]-k),maxx);
				else maxx=max((b[i]/a[i]),maxx);
			}
			for(int i=1;i<=5;i++)
			{
				for(int j=i+1;j<=5;j++)
				{
					if(a[i]+a[j]>=m)maxx=max((b[i]+b[j])/(a[i]+a[j]-k),maxx);
					else maxx=max((b[i]+b[j])/(a[i]+a[j]),maxx);
				}
			}
			for(int i=1;i<=5;i++)
			{
				for(int j=i+1;j<=5;j++)
				{
					for(int p=j+1;p<=5;p++){
						if(a[i]+a[j]+a[p]>=m)maxx=max((b[i]+b[j]+b[p])/(a[i]+a[j]+a[p]-k),maxx);
						else maxx=max((b[i]+b[j]+b[p])/(a[i]+a[j]+a[p]),maxx);
					}
				}
			}
			for(int i=1;i<=5;i++)
			{
				for(int j=i+1;j<=5;j++)
				{
					for(int p=j+1;p<=5;p++){
						for(int l=p+1;l<=5;l++){
							if(a[i]+a[j]+a[p]+a[l]>=m)maxx=max((b[i]+b[j]+b[p]+b[l])/(a[i]+a[j]+a[p]+a[l]-k),maxx);
							else maxx=max((b[i]+b[j]+b[p]+b[l])/(a[i]+a[j]+a[p]+a[l]),maxx);
						}
					}
				}
			}
			if(a[1]+a[2]+a[3]+a[4]+a[5]>=m){
				maxx=max((b[1]+b[2]+b[3]+b[4]+b[5])/(a[1]+a[2]+a[3]+a[4]+a[5]-k),maxx);
			}
			else maxx=max((b[1]+b[2]+b[3]+b[4]+b[5])/(a[1]+a[2]+a[3]+a[4]+a[5]),maxx);
			cout<<fixed<<setprecision(2)<<maxx;
        } 
