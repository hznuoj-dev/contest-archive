#include<bits/stdc++.h>

using namespace std;
#define ll long long
#define endl '\n'
#define N 200010
#define inf 0x3f3f3f3f3f3f3f3f
#define int ll
int n;
int a[N],b[N];
signed main(){
    cin>>n;
    for(int i=1;i<=n;++i)cin>>a[i];
    for(int i=1;i<=n;++i)cin>>b[i];
    sort(a+1,a+1+n);
    sort(b+1,b+1+n);
    int del1=inf,fl1=0;
    int del2=inf,fl2=0;
    for(int i=1;i<=n;++i){
        int tmp1=a[i]-b[i];
        int tmp2=a[i]+b[i];
        if(del1==inf) del1=tmp1;
        else {
            if(tmp1!=del1) fl1=1;
            else del1=tmp1;
        }
        if(del2==inf) del2=tmp2;
        else{
            if(tmp2!=del2) fl2=1;
            else del2=tmp2;
        }
        if(fl1&&fl2){
            cout<<-1;
            return 0;
        }
    }
    int res=inf;
    del2=abs(del2)+1;
    if(!fl1) res=min(res,abs(del1));
    if(!fl2) res=min(res,abs(del2));
    cout<<res;
}