#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define int long long 
#define Acode ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
#define int long long 
const int inf=0x3f3f3f3f;
const int N=1e6+10;

int a[N],b[N];
int c[N],d[N];


signed main()
{
	Acode ;
	int n;
	cin>>n;
	for(int i=1;i<=n;i++) 
	{
		cin>>a[i];
		c[i]=-a[i];
	}
	
	for(int i=1;i<=n;i++) 
	{
		cin>>b[i];
		d[i]=-b[i];
	}
	
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	sort(d+1,d+1+n);
	
	int flag=1;
	for(int i=1;i<=n-1;i++) 
	{
		if(a[i]-b[i]!=a[i+1]-b[i+1]) flag=0;
	}
	
	if(flag==1) 
	{
		int t=abs(a[1]-b[1]);
		int tt=abs(a[1]-d[1])+1;
		cout<<min(t,tt);
	}
	else 
	{
		cout<<"-1";
	}
	
	
	
	return 0;
}