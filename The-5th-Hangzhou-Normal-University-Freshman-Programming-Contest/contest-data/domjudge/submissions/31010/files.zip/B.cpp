#include<bits/stdc++.h>

using namespace std;

const int N = 200005;

int a[N];
int b[N];
int c[N];

void solve(){
	int n;
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i];
	}
	
	for(int i=1;i<=n;++i){
		cin>>b[i];
		c[i] = -b[i];
	}
	
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	sort(c+1,c+1+n);
	
	int x = a[1] - b[1];
	int ans = INT_MAX;
	int flag = 0;
	for(int i=2;i<=n;++i){
		int now = a[i]-b[i];
		if(now != x){
			flag = 1;
			break;
		}
	}
	
	int y = a[1] - c[1];
	int tag = 0;
	for(int i=2;i<=n;++i){
		int now = a[i] - c[i];
		if(now != y){
			tag = 1;
			break;
		}
	}

	if(tag == 0 && flag == 0){
		cout<<min(abs(x),abs(y)+1);
	}else if(tag == 0){
		cout<<abs(y)+1;
	}else if(flag == 0){
		cout<<abs(x);
	}else{
		cout<<"-1";
	}
	
}

int main(){
	cin.sync_with_stdio(false);
	cin.tie(0);cout.tie(0);
	int t = 1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}
