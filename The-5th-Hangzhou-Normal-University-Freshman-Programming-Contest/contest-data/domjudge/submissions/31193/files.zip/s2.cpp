#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
typedef long long ll;
bool cmp(ll a, ll b)
{
	return a < b;
}
ll n;
ll a[200010];
ll b[200010];
int main()
{
	ll t3 = 0;
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		b[i] = a[i];
	}
	sort(a + 1, a + 1 + n, cmp);
	ll k;
	k = a[n / 2];
	

	for (; k <= a[n]; k++)
	{
		ll t1 = 0, t2 = 0;
		for (ll j = 1; j <= n; j++)
		{
			if (b[j] < k)
			{
				t1++;
			}
			else if (b[j] > k)
			{
				t2++;
			}
		}
		if (t1 == t2)   t3++;

	}
	
	cout << t3;
	return 0;
}