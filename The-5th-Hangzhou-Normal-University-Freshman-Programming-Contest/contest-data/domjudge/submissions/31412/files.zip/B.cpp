#include<bits/stdc++.h>
#define int long long
#define inf 0x3f3f3f3f

using namespace std;
const int N = 2e5 + 5;
int a[N], b[N], c[N];

void solve() {
	int n;
	cin >> n;
	int ans = -1;
	for(int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for(int i = 1; i <= n; i++) {
		cin >> b[i];
	}
	sort(a + 1, a + n + 1);
	sort(b + 1, b + n + 1);

	int flag = 1;
	for(int i = 1; i <= n; i++) {
		c[i] = b[i] - a[i];
		if(i > 1 && c[i] != c[i - 1]) {
			flag = 0;
			break;
		}
	}
	if(flag) {
		ans = abs(b[1] - a[1]);
	} else {
		flag = 1;
		for(int i = 1; i <= n; i++) {
			b[i] = -b[i];
		}
		sort(b + 1, b + n + 1);
		for(int i = 1; i <= n; i++) {
			c[i] = b[i] - a[i];
			if(i > 1 && c[i] != c[i - 1]) {
				flag = 0;
				break;
			}
		}
		if(flag) {
			ans = abs(b[1] - a[1]) + 1;
		}
	}

	cout << ans << endl;
	return;
}
/*
2
0 1
2 3
*/
signed main() {
	ios::sync_with_stdio(0);

	int T = 1;
//	cin >> T;
	while(T--) {
		solve();
	}

	return 0;
}
