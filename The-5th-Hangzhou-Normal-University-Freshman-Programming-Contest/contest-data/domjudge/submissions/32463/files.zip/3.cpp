#include<bits/stdc++.h>
using namespace std; 
const int N = 2e5+5;
typedef long long LL;
int n, a, b, c;
int h[N],e[N],ne[N],idx;
LL w[N], p[N], res = 0;
bool vt[N];

void add(int a, int b, int c) {
	e[idx] = b,w[idx] = c,ne[idx] = h[a],h[a] = idx++;
}

LL fig(LL a, LL k){
	int g[35],d[35],cnt = 0,dc = 0;
	memset(g, 0, sizeof g);
	while(a)g[++cnt] = a % 2, a /= 2;
	while(k)d[++dc] = k % 2, k /= 2;
	for(int i = 1; i <= dc; ++i)if(d[i])g[i] = abs(g[i] - 1);
	LL res = 0;
//	for(int i = 1; i <= max(cnt, dc); ++i)cout<<g[i];cout<<"\n";
	for(int i = 1; i <= max(cnt, dc); ++i)res += g[i]*pow(2, i - 1);
	return res;
}

void cc(int r){
	res ^= p[r];
	queue<int> qe;
	qe.push(r);
	
	while(qe.size()){
		int u = qe.front();qe.pop();
		for(int i = h[u]; i != -1; i = ne[i]){
			LL t = e[i];
			if(vt[t])continue;
			vt[t] = true;
	//		cout<<p[u]<<" "<<w[i]<<"\n";
			LL now = fig(p[u], w[i]);
	//		cout<<now<<"\n";
			p[t] = now;
			res ^= p[t];
			qe.push(t);
		}
	}
}
inline int read()
{
    int x=0,f=1;
    char ch=getchar();
    while(ch<'0'||ch>'9'){
        if(ch=='-')
            f=-1;
        ch=getchar();
    }
    while(ch>='0'&&ch<='9'){
        x=(x<<1)+(x<<3)+(ch^48);
        ch=getchar();
    }
    return x*f;
}
int main()
{
//	cout<<fig(0, 5)<<"\n";
	ios::sync_with_stdio(false);
	n = read();
	for(int i = 1;i<= n;i++) h[i] = -1;
	for(int i = 1; i < n; ++i)a = read(),b=read(),c=read(),add(a,b,c),add(b,a,c);
	int tt;
	tt = read();
	while(tt--){
		res = 0;
		for(int i = 0;i <= n;i++)vt[i] = 0;
		for(int i = 0;i <= n;i++)p[i] = 0;
		int u, cnt;
		u = read();
		cnt = read();
		p[u] = cnt;
		vt[u] = true;
		cc(u);
		printf("%lld\n",res);
	}
} 
