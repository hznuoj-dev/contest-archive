#include<iostream>
#include<algorithm>
#include<iomanip>
using namespace std;
double d[5];
struct node
{
	int a;
	int b;
	double c;
}x[10];

bool cmp(node x1,node x2)
{
	if(x1.c!=x2.c)
	{
		return x1.c>x2.c;
	}
	else
	{
		return 0;
	}
}

int main()
{
	int m,k;
	cin >> m >> k;
	for(int i=1;i<=5;i++)
	{
		cin >> x[i].a;
	}
	for(int i=1;i<=5;i++)
	{
		cin >> x[i].b;
	}
	for(int i=1;i<=5;i++)
	{
		x[i].c=x[i].b*1.0/x[i].a;
	}
	sort(x+1,x+6,cmp);
	bool flag=1;
	int p=x[1].b;
	int q=x[1].a;
	if(q>=m&&flag==1) q-=k,flag=0;
	d[0]=p*1.0/q;
	p=p+x[2].b;
	q=q+x[2].a;
	if(q>=m&&flag==1) q-=k,flag=0;
	d[1]=p*1.0/q;
	p=p+x[3].b;
	q=q+x[3].a;
	if(q>=m&&flag==1) q-=k,flag=0;
	d[2]=p*1.0/q;
	p=p+x[4].b;
	q=q+x[4].a;
	if(q>=m&&flag==1) q-=k,flag=0;
	d[3]=p*1.0/q;
	p=p+x[5].b;
	q=q+x[5].a;
	if(q>=m&&flag==1) q-=k,flag=0;
	d[4]=p*1.0/q;
	double max=0;
	for(int i=0;i<=4;i++)
	{
		if(d[i]>max) max=d[i];
	}
	cout << fixed << setprecision(2) << max << endl;
	return 0;
}
