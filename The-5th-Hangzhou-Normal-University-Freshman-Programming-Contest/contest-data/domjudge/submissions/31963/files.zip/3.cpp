#include<bits/stdc++.h>
using namespace std; 
const int N = 2e5+5;
typedef long long LL;
LL n, m, b;
LL a[N];

int main()
{
	cin>>n>>m>>b;
	for(int i = 1; i <= n; ++i)cin>>a[i];
	int st = n % m;
	if(!st)st = m;
	LL res = 0, sum = 0;
	LL cnt = 0;
	for(int i = 1; i <= n; ++i){
		sum += a[i];
		if(i >= st && cnt % m == 0)res += min(sum, b),sum -= min(sum, b);
		if(i >= st)cnt++;
	}
	cout<<res<<"\n";
} 
