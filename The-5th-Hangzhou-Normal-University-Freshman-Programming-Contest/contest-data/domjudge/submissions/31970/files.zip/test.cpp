#include <iostream>
#include <algorithm>

using namespace std;
typedef long long ll;
const int N = 205;

int pri[10],sat[10];

double a[50];

int main(){

    int m, k;
    cin >> m >> k;

    for(int i = 1;i <= 5;i++){
        cin >> pri[i];
    }
    
    for(int i = 1;i <= 5;i++){
        cin >> sat[i];
    }

    double ans = 0;

    //1
    int sump = pri[1],sums = sat[1];
    if(sump >= m) sump -= k;
    a[1] = sums * 1.0 / sump;
    //1 2
    sump = pri[1] + pri[2],sums = sat[1] + sat[2];
    if(sump >= m) sump -= k;
    a[2] = sums * 1.0 / sump;
    //1 3
    sump = pri[1] + pri[3],sums = sat[1] + sat[3];
    if(sump >= m) sump -= k;
    a[3] = sums * 1.0 / sump;
    //1 4
    sump = pri[1] + pri[4],sums = sat[1] + sat[4];
    if(sump >= m) sump -= k;
    a[4] = sums * 1.0 / sump;
    //1 5
    sump = pri[1] + pri[5],sums = sat[1] + sat[5];
    if(sump >= m) sump -= k;
    a[5] = sums * 1.0 / sump;
    //1 2 3
    sump = pri[1] + pri[2] + pri[3],sums = sat[1] + sat[2] + sat[3];
    if(sump >= m) sump -= k;
    a[6] = sums * 1.0 / sump;
    //1 2 4
    sump = pri[1] + pri[2] + pri[4],sums = sat[1] + sat[2] + sat[4];
    if(sump >= m) sump -= k;
    a[7] = sums * 1.0 / sump;
    //1 2 5
    sump = pri[1] + pri[2] + pri[5],sums = sat[1] + sat[2] + sat[5];
    if(sump >= m) sump -= k;
    a[8] = sums * 1.0 / sump;
    //1 3 4
    sump = pri[1] + pri[3] + pri[4],sums = sat[1] + sat[3] + sat[4];
    if(sump >= m) sump -= k;
    a[9] = sums * 1.0 / sump;
    //1 3 5
    sump = pri[1] + pri[3] + pri[5],sums = sat[1] + sat[3] + sat[5];
    if(sump >= m) sump -= k;
    a[10] = sums * 1.0 / sump;
    //1 4 5
    sump = pri[1] + pri[5] + pri[4],sums = sat[1] + sat[5] + sat[4];
    if(sump >= m) sump -= k;
    a[11] = sums * 1.0 / sump;
    //1 2 3 4
    sump = pri[1] + pri[2] + pri[3] + pri[4],sums = sat[1] + sat[2] + sat[3] + sat[4];
    if(sump >= m) sump -= k;
    a[12] = sums * 1.0 / sump;
    //1 2 3 5
    sump = pri[1] + pri[2] + pri[3] + pri[5],sums = sat[1] + sat[2] + sat[3] + sat[5];
    if(sump >= m) sump -= k;
    a[13] = sums * 1.0 / sump;
    //1 2 4 5
    sump = pri[1] + pri[2] + pri[4] + pri[5],sums = sat[1] + sat[2] + sat[4] + sat[5];
    if(sump >= m) sump -= k;
    a[14] = sums * 1.0 / sump;
    //1 3 4 5
    sump = pri[1] + pri[3] + pri[4] + pri[5],sums = sat[1] + sat[3] + sat[4] + sat[5];
    if(sump >= m) sump -= k;
    a[15] = sums * 1.0 / sump;
    //1 2 3 4 5
    sump = pri[1] + pri[2] + pri[3] + pri[4] + pri[5],sums = sat[1] + sat[2] + sat[3] + sat[4] + sat[5];
    if(sump >= m) sump -= k;
    a[16] = sums * 1.0 / sump;
    //2 3
    sump = pri[2] + pri[3],sums = sat[2] + sat[3];
    if(sump >= m) sump -= k;
    a[17] = sums * 1.0 / sump;
    //2 4
    sump = pri[2] + pri[4],sums = sat[2] + sat[4];
    if(sump >= m) sump -= k;
    a[18] = sums * 1.0 / sump;
    //2 5
    sump = pri[2] + pri[5],sums = sat[2] + sat[5];
    if(sump >= m) sump -= k;
    a[19] = sums * 1.0 / sump;
    //2 3 4
    sump = pri[2] + pri[3] + pri[4],sums = sat[2] + sat[3] + sat[4];
    if(sump >= m) sump -= k;
    a[20] = sums * 1.0 / sump;
    //2 3 5
    sump = pri[2] + pri[3] + pri[5],sums = sat[2] + sat[3] + sat[5];
    if(sump >= m) sump -= k;
    a[21] = sums * 1.0 / sump;
    //2 4 5
    sump = pri[2] + pri[4] + pri[5],sums = sat[2] + sat[4] + sat[5];
    if(sump >= m) sump -= k;
    a[22] = sums * 1.0 / sump;
    //2 3 4 5
    sump = pri[2] + pri[3] + pri[4] + pri[5],sums = sat[2] + sat[3] + sat[4] + sat[5];
    if(sump >= m) sump -= k;
    a[23] = sums * 1.0 / sump;
    //3 4
    sump = pri[3] + pri[4],sums = sat[3] + sat[4];
    if(sump >= m) sump -= k;
    a[24] = sums * 1.0 / sump;
    //3 5
    sump = pri[3] + pri[5],sums = sat[3] + sat[5];
    if(sump >= m) sump -= k;
    a[25] = sums * 1.0 / sump;
    //3 4 5
    sump = pri[3] + pri[4] + pri[5],sums = sat[3] + sat[4] + sat[5];
    if(sump >= m) sump -= k;
    a[26] = sums * 1.0 / sump;
    //4 5
    sump = pri[4] + pri[5],sums = sat[4] + sat[5];
    if(sump >= m) sump -= k;
    a[27] = sums * 1.0 / sump;
    //2
    sump = pri[2],sums = sat[2];
    if(sump >= m) sump -= k;
    a[28] = sums * 1.0 / sump;
    //3
    sump = pri[3],sums = sat[3];
    if(sump >= m) sump -= k;
    a[29] = sums * 1.0 / sump;
    //4
    sump = pri[4],sums = sat[4];
    if(sump >= m) sump -= k;
    a[30] = sums * 1.0 / sump;
    //5
    sump = pri[5],sums = sat[5];
    if(sump >= m) sump -= k;
    a[31] = sums * 1.0 / sump;

    sort(a + 1, a + 32);

    ans = a[31];
    printf("%.2lf\n", ans);

    return 0;
}