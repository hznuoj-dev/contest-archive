#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10;
int n,a[N],b[N];
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<=n;i++) cin>>b[i];
	sort(a+1,a+1+n);
	sort(b+1,b+1+n);
	int fg=1;
	int ch=a[1]-b[1];
	for(int i=2;i<=n;i++)
	{
		if(a[i]-b[i]!=ch)
		{
			fg=0;
			break;
		}
	}
	if(fg==0) cout<<-1<<endl;
	else
	{
		if(abs(a[1]-b[1])<abs(-a[n]-b[1])+1) cout<<abs(a[1]-b[1])<<endl;
		else cout<<abs(-a[n]-b[1])+1<<endl;
	}
	return 0;
}
