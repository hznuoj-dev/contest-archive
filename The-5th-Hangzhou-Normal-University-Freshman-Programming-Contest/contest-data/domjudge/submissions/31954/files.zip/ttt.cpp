#include <iostream>
#include <string>
#include <cstring>
#include <queue>
#include <math.h>
#include <algorithm>
using ll = long long;
using namespace std;
const int N = 2E5 + 5;
double a[6], b[6];
int n, k;
double DFS(int pos, double suma, double sumb)
{
    double maxx = 0;
        if (a[pos] + suma >= n)
           maxx =  (sumb + b[pos]) / (a[pos] + suma - k);
        else
           maxx =  (sumb + b[pos]) / (a[pos] + suma);

    int i, j;
    
    for (i = pos + 1; i <= 5; i++)
            maxx =  max(maxx, DFS(i, suma + a[pos], sumb + b[pos]));
    
    
    return maxx;
}
int main()
{

    ll i, j, l;
    double maxx = 0, ass;

    cin >> n >> k;
    for (i = 1; i <= 5; i++)
        cin >> a[i];
    for (i = 1; i <= 5; i++)
        cin >> b[i];
    for (i = 1; i <= 5; i++)
    {
        ass = DFS(i, 0, 0);
        maxx = max(maxx,ass);
    }
    printf("%.2lf", maxx);
    return 0;
}