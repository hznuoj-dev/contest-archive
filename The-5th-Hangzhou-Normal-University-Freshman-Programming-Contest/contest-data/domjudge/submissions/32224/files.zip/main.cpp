#include <bits/stdc++.h>
#define int long long

using namespace std;



void pr_vc(vector<int>& vc){
    for (int i : vc) {
        cout << i << " " ;
    }
    cout << "\n";
}

void b(){
    int n;
    cin >> n;
    vector<int> a(n);
    vector<int> vc_up(n);
    vector<int> vc_down(n);
    for (int i = 0; i < n; ++i) {
        cin >> a[i];
    }
    for (int i = 0; i < n; ++i) {
        cin >> vc_up[i];
        vc_down[i] = -vc_up[i];
    }

    std::sort(a.begin(), a.end());
    std::sort(vc_up.begin(), vc_up.end());
    std::sort(vc_down.begin(), vc_down.end());


    int det[2];
    det[0] = a[0] - vc_up[0];
    det[1] = a[0] - vc_down[0];

    int res[2];

    for (int i = 0; i < n; ++i) {
        vc_up[i] += det[0];
        vc_down[i] += det[1];
    }
    bool f[2] = {true, true};
    for (int i = 0; i < n; ++i) {
        if(a[i] != vc_up[i]){
            f[0] = false;
            break;
        }
        if(a[i] != vc_down[i]){
            f[1] = false;
            break;
        }
    }

    int point[2] = {0, 1};

    for (int i = 0; i < 2; ++i) {
        if(f[i]){
            res[i] = abs(det[i]) + point[i];
        }
        else{
            res[i] = INT64_MAX;
        }
    }

    if(res[0] == res[1] && res[1] == INT64_MAX){
        cout << -1;
    }
    else{
        cout << (res[0] < res[1] ? res[0] : res[1]);
    }

}

signed main() {
    int n = 1;
    //cin >> n;
    while (n--){
        b();
    }
}
