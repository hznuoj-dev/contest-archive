#include<bits/stdc++.h>
using namespace std;
const int N=1e6+5;
int n,q,head[N],cnt,dep[N],sum;
struct edge
{
	int nxt,v,dis;
}e[N<<1];
void add(int u,int v,int w)
{
	e[++cnt].nxt=head[u];
	head[u]=cnt;
	e[cnt].v=v;
	e[cnt].dis=w;
}
void dfs(int u,int fa)
{
	for(int i=head[u];i;i=e[i].nxt)
	{
		int v=e[i].v;
		if(v==fa)continue;
		dep[v]=dep[u]^e[i].dis;
		dfs(v,u);
	}
}
int main()
{
	scanf("%d",&n);
	for(int i=1;i<n;++i)
	{
		int x,y,z;
		scanf("%d%d%d",&x,&y,&z);
		add(x,y,z);add(y,x,z);
	}
	dfs(1,0);
	for(int i=1;i<=n;++i)sum^=dep[i];
	scanf("%d",&q);
	while(q--)
	{
		int u,x;
		scanf("%d%d",&u,&x);
		x^=dep[u];
		if(n&1)printf("%d\n",x^sum);
		else printf("%d\n",sum);
	}
	return 0;
}
