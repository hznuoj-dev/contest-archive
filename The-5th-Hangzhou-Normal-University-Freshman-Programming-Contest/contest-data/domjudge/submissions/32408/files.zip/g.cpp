#include<iostream>
#include<algorithm>
using namespace std;

//G
const int N=2e5+7;
typedef long long ll;
ll n,a[N],dis,maxn;

int cmp(ll&a,ll&b){return a>b;}

void dfs(int i,int now,int time){
	
}

int main(){
	cin>>n>>dis>>maxn;
	ll time=1;
	ll now=0;
	ll ans=0;
	for(ll i=1;i<=n;i++)cin>>a[i];
	for(ll i=1;i<=n;i++){
		now+=a[i];
		if(i>=time){
			if(maxn<=now){
				ans+=maxn;
				now-=maxn;
				time=i+dis;
			}else if(i==n||i==1){
				ans+=now;
				now=0;
				time=i+dis;
			}
		}
	}
	cout<<ans<<endl;
}

/*
5 2 10
5 9 3 1 8

6 2 10
20 1 1 1 1 5

*/
