#include<stdio.h>
int main()
{
	int m, k, j = 0;
	int a[5], b[5];
	double h[32], z;
	scanf("%d %d", &m, &k);
	for (int i = 0; i < 5; i++)
		scanf("%d", &a[i]);
	for (int i = 0; i < 5; i++)
		scanf("%d", &b[i]);
		
	for (int i = 0; i < 5; i++)
	{
		h[j] = b[i] * 1.00 / (a[i] - (a[i] / m) * k);
		j++;
	}
	
	for (int i = 0; i < 4; i++)
	{
		for (int p = i + 1; p < 5; p++)
		{
			h[j] = (b[i] + b[p]) * 1.00 / (a[i] + a[p] - (a[i] + a[p]) / m * k);
			j++;
		}
	}
	
	for (int i = 0; i < 3; i++)
	{
		for (int p = i + 1; p < 4; p++)
		{
			for (int y = p + 1; y < 5; y++)
			{
				h[j] = (b[i] + b[p] + b[y]) * 1.00 / (a[i] + a[p] + a[y] - (a[i] + a[p] + a[y]) / m * k);
				j++;
			}
		}
	}
	
	for (int i = 0; i < 2; i++)
	{
		for (int p = i + 1; p < 3; p++)
		{
			for (int y = p + 1; y < 4; y++)
			{
				for (int q = y + 1; q < 5; q++)
				{
					h[j] = (b[i] + b[p] + b[y] + b[q]) * 1.00 / (a[i] + a[p] + a[y] + a[q] - (a[i] + a[p] + a[y] + a[q]) / m * k);
					j++;
				}
			}
		}
	}
	
	h[j] = (b[0] + b[1] + b[2] + b[3] + b[4]) * 1.00 / (a[0] + a[1] + a[2] + a[3] + a[4] - (a[0] + a[2] + a[1] + a[3] + a[4]) / m * k);
	z = h[0];
	for (int i = 1; i < j; i++)
	{
		if (z < h[i])
		z = h[i];
	}
	printf("%.2lf", z);
}