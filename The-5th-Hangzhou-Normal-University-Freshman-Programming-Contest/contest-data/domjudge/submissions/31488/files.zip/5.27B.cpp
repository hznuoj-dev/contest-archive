#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N = 214514;
int n;
ll a[N],b[N];
ll ans,ans2,res;
int main(){
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>a[i];
	}
	sort(a,a+n);
	for(int i=0;i<n;++i){
		cin>>b[i];
	}
	sort(b,b+n);
	for(int i=0;i<n-1;++i){
		ans=a[i]-b[i];
		ans2=a[i+1]-b[i+1];
		if(ans==ans2){
			res=abs(ans);
		}
		else{
			res=-1;
			break;
		}
	}
	cout<<res<<endl;
	return 0;
}
