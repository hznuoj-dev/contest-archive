#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define int ll
typedef pair<int,int>pii;
const int N=2e5+7,mod=1e9+7;
int n,m,k,u,v,d[N],cnt[N],q[N],vis[N];
vector<int>e[N];
stack<int>s;
void dfs(int u){
	vis[u]=1;
	for(int x:e[u])if(!vis[x])dfs(x);
	s.push(u);
}
int fpow(int a,int n){
	int ans=1;
	while(n){
		if(n&1)ans=ans*a%mod;
		a=a*a%mod;
		n>>=1;
	}
	return ans;
}
set<int>ss[N];
void solve(){
	cin>>n>>m>>k;
	for(int i=1;i<=m;i++){
		cin>>u>>v;
		ss[u].insert(v);
	}
	for(int u=1;u<=n;u++){
		for(int v:ss[u]){
			e[u].push_back(v);
		}
	}
	for(int i=1;i<=n;i++)d[i]=1,dfs(i);
	while(!s.empty()){
		int now=s.top();
		for(int x:e[now])d[x]=max(d[x],d[now]+1);
		s.pop();
	}
	for(int i=1;i<=n;i++)cnt[d[i]]++;
	for(int i=1;i<=n;i++)q[i]=(q[i-1]+cnt[i])%mod;
	int sum=0;
	for(int i=1;i<=n;i++)sum=(sum+q[d[i]-1])%mod;
	cout<<fpow(sum,k);
}
signed main(){
	int t=1;
	ios::sync_with_stdio(0),cin.tie(0),cout.tie(0);
//	cin>>t;
	while(t--)solve();
	return 0;
}
