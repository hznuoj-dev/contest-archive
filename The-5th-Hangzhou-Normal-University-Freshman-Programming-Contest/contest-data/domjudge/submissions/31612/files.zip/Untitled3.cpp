#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll maxn=2e5+7;
ll m,k;
double y=0;
struct node{
	ll a,b;
}x[10];
bool cmp(node a,node b){
	return a.b*b.a>b.b*a.a;
}
void dfs(int st,ll he,ll money){
	if(money>=m){
		y=max(y,he*1.0/(money-k));
		return;
	}
	if(st>5)return;
	dfs(st+1,he+x[st].b,money+x[st].a);
	dfs(st+1,he,money);
	return;
}
void solve(){
	cin>>m>>k;
	for(int i=1;i<=5;i++){
		cin>>x[i].a;	
	}
	for(int i=1;i<=5;i++){
		cin>>x[i].b;	
	}
	sort(x+1,x+1+5,cmp);	
	double ans=0;
	if(x[1].a<m)ans=x[1].b*1.0/x[1].a;
	else ans=x[1].b*1.0/(x[1].a-k);
	ll he=0,money=0;
	dfs(1,he,money);
	printf("%.2f",max(y,ans));
}
int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
	return 0;
}