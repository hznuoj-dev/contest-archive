#include<bits/stdc++.h>
using namespace std;
int m,k;
struct node{
	int jia,ping;
	float bi;
}n[20];
bool cmp(node a,node b){
	return a.bi<b.bi;
}

int main(){
	cin>>m>>k;
	for(int i=1;i<=5;i++){
		cin>>n[i].jia;
	}
	for(int i=1;i<=5;i++){
		cin>>n[i].ping;
		n[i].bi=n[i].ping*1.0/n[i].jia;
	}
	sort(n+1,n+6,cmp);
	int jia=0,ping=0;
	float maxx=0;

	for(int i=5;i>=1;i--){
		jia+=n[i].jia;
		ping+=n[i].ping;
		//cout<<jia-(jia/m*k)<<" "<<ping<<endl;
		if(maxx<ping*1.0/(jia-(jia/m*k))){
			maxx=ping*1.0/(jia-(jia/m*k));
		}
	}
	printf("%.2f",maxx);
}
