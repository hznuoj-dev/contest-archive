#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[200001]={0},b[200001]={0};
int n;
int nb=1;
int main() {
	scanf("%d",&n);
	for(int i=1;i<=n;i++) 
		scanf("%d",a+i),b[i]=a[i];
	sort(a+1,a+n+1);
	if(a[n]==a[1]) {
		printf("1");
		return 0;
	}
	if(n%2)printf("1");
	else if(a[n/2+1]==a[n/2])printf("1");
	else  {
		int k1=a[n/2],k2=a[n/2+1];
		int l=lower_bound(a+1,a+n+1,k1)-a;
		int r=lower_bound(a+1,a+n+1,k2+1)-a;
		r--;
		if(l+r==n+1)printf("%d",k2-k1+1);
		else printf("%d",k2-k1-1);
	}
	/*if(n%2) {
		int k=a[n/2+1];
		int l=lower_bound(a+1,a+n+1,k)-a;
		int r=lower_bound(a+1,a+n+1,k+1)-a;
		r--;
		string s="";
				for(int i=1;i<=n;i++) {
					if(b[i]<k)s+='(';
					else s+=')';
					if(s.size()&&s[0]==')') {
						printf("0");
						return 0;
					}
				}
				if(s[s.size()-1]=='(') {
					printf("0");
					return 0;
				}
		if(l+r==n+1)cout<<1;
		else cout<<0;
	} else {
		if(a[n/2]!=a[n/2+1]) {
			int k1=a[n/2],k2=a[n/2+1];
			int l=lower_bound(a+1,a+n+1,k1)-a;
			int r=lower_bound(a+1,a+n+1,k2+1)-a;
			r--;
			//cout<<l<<' '<<r<<'\n';//
			if(l+r==n+1) {
				string s="";
				for(int i=1;i<=n;i++) {
					if(b[i]<k1)s+='(';
					else s+=')';
					if(s.size()&&s[0]==')') {
						printf("0");
						return 0;
					}
				}
				if(s[s.size()-1]=='(') {
					printf("0");
					return 0;
				}
				cout<<(k2-k1+1);
			}
			else {
				string s="";
				for(int i=1;i<=n;i++) {
					if(b[i]<k1+1)s+='(';
					else s+=')';
					if(s.size()&&s[0]==')') {
						printf("0");
						return 0;
					}
				}
				if(s[s.size()-1]=='(') {
					printf("0");
					return 0;
				}
				cout<<(k2-k1-1);
			}
		} else {
			int k=a[n/2+1];
			int l=lower_bound(a+1,a+n+1,k)-a;
			int r=lower_bound(a+1,a+n+1,k+1)-a;
			r--;
			string s="";
				for(int i=1;i<=n;i++) {
					if(b[i]<k)s+='(';
					else s+=')';
					if(s.size()&&s[0]==')') {
						printf("0");
						return 0;
					}
				}
				if(s[s.size()-1]=='(') {
					printf("0");
					return 0;
				}
			if(l+r==n+1)cout<<1;
			else cout<<0;
		}
	}*/
}