#include <bits/stdc++.h>
using ll = long long;
using pii = std::pair<ll, ll>;

void solve() {
    ll n, m, k;
    std::cin >> n >> m >> k;
    std::vector<ll>a(n + 3), dp(n + 3), mx_dp(n + 3);
    for(int i = 1;i <= n;i++) std::cin >> a[i];
    ll tot = 0;
    for(int i = 1;i <= n;i++) {
        tot += a[i];
        if(i > m)dp[i] = mx_dp[i - m] + std::min(k, tot - mx_dp[i - m]);
        else dp[i] = std::min(k, tot);
        mx_dp[i] = std::max(dp[i], mx_dp[i - 1]);
    }
    std::cout << dp[n] << '\n';
}

int main() {
    std::ios::sync_with_stdio(false);
    std::cin.tie(nullptr);
    std::cout.tie(nullptr);
    int T = 1;
    //std::cin >> T;
    while(T--) {
        solve();
    }
}