#include<bits/stdc++.h>
#define int long long
using namespace std;

const int N = 2e5 + 5;
int a[N], f[N], s[N];
int n, m, b;
priority_queue<int> q;

signed main(){
	ios::sync_with_stdio(0);
	
	cin >> n >> m >> b;
	for(int i = 1; i <= n; i++){
		cin >> a[i];
		s[i] = s[i - 1] + a[i];
	}
//	f[1] = min(b, s[1]);
	for(int i = 1; i <= n; i++){
		if(i <= m){
			f[i] = min(s[i], b);
			if(i < m) q.push(f[i]);
			continue;
		}
		f[i] = min(s[i] - q.top(), b) + q.top();
		q.push(f[i - 1]);
//		for(int j = m; j <= i; j++){
//			f[i] = max(f[i], f[i - j] + min(s[i] - f[i - j], b));
//		}
	}
//	for(int i = 1; i <= n; i++){
//		cout << f[i] << " \n"[i == n];
//	}
	int ans = -1;
	for(int i = 1; i <= n; i++){
		ans = max(ans, f[i]);
	}
	cout << ans << endl;
	return 0;
}

/*
5 2 10
5 9 3 1 8

6 2 10
20 1 1 1 1 5
*/
