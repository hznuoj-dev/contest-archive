#include<stdio.h>
struct
{
	int like;
	char name[20];
}music[100000], swap;
int main()
{
	int n, i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d%s", &music[i].like, &music[i].name);
	}
	int k;
	scanf("%d", &k);
	for (i = 0; i < n - 1; i++)
	{
		for (j = i; j < n; j++)
		{
			if (music[i].like < music[j].like)
			{
				swap = music[i];
				music[i] = music[j];
				music[j] = swap;
			}
		}
	}
	printf("%s\n", music[k].name);
	return 0;
}