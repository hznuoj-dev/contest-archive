#include<stdio.h>
int main(void){
	int n,m,i,j,flag0=0,flag1=0,flag2=0,temp=0,result=0;
	scanf("%d%d",&n,&m);
	int kind[n],power[n];
	for(i=0;i<n;i++){
		scanf("%d",&kind[i]);
		if(kind[i]==1){
			power[i]=0;
			flag1++;
		}
		else if(kind[i]==2){
			power[i]=0;
			flag2++;
		}
		else{
			scanf("%d",&power[i]);
			flag0++;
		}		
	}
	if(flag2>0&&(flag0>0||flag1>0)){
			result=1;
	}
	else if(flag1>0){
		for(j=0;j<n;j++){
			if(kind[j]==0){
				temp+=power[j];
			}
		}
		if(temp>=2500||(temp>2100&&m==1)){
			result=1;
		}
	}
	if(result){
		printf("haoye");
	}
	else{
		printf("QAQ");
	}
	return 0;
}
