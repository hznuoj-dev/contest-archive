//B
#include<stdio.h>
int main()
{
	int T,n,a[5000],i,j,sum,num;
	scanf("%d",&T);
	while(T--)
	{
		num=0;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
		    scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++)
		{
		    sum=0;
			for(j=i;j<n;j++)
			{
				sum+=a[j];
				if(sum==7777)
				{	
					num+=1;	
						
				}			
				
			}
		}
		printf("%d\n",num);
		
	}
	
	return 0;
 } 
 
 
 
 
 
 
