#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main (){
	int m,n,i,j;
	scanf("%d %d",&n,&m);
	int a[n+1][m+1];
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	int min,k,jm;
	min=fabs(a[0][0]-a[1][0]);
	for(i=0;i<n-1;i++){
		for(jm=0;jm<m;jm++){
			for(k=i+1;k<n;k++){
				for(j=0;j<m;j++){
					if(a[i][jm]==a[k][j]){
						min=0;
						break;
						break;
						break;
						break;
					}
					if(fabs(a[i][jm]-a[k][j])<min){
						min =fabs(a[i][jm]-a[k][j]);
					}
				}
			}
		}
	}
	printf("%d",min);
	return 0;
} 
