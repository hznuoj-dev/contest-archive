#include<stdio.h>
char name[100011][17]={0};
int a[100011]={0};
main()
{
	int n,k,max=0,i,q;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		scanf("%s",name[i]);
	}
	scanf("%d",&k);
	k++;
	while(k--)
	{
		max=0;
		for(q=1;q<=n;q++)
		{
			if(a[max]<a[q])max=q;
		}
		a[max]=0;
	}
	printf("%s",name[max]);
}