/*B*/
#include<stdio.h>
#define MAX 100000
int main(void)
{
	int t, n, i, j, k, l, cnt;
	char str[MAX];
	scanf("%d", &t);
	for(i=1;i<=t;i++){
		scanf("%d", &n);
		cnt=0;
		for(j=0;j<n;j++){/*������ĸ*/
			scanf("%c , &str[j]");
		}
		for(k=0;k<n;k++){
			for(l=k+1;l<n;l++){
				if(str[k]==str[l]){
					cnt++;
					str[l]=' ';
				}
			}
		}
		if(cnt){
			printf("%d\n", 1);
		}else{
			if(n%2){
			    printf("%d\n", 2*cnt+1);
		    }else{
			    printf("%d\n", 2*cnt);
		    }
		}
	}
	return 0;
}
