#include<stdio.h>
#include <string.h>
long long int num[100000] = { 0 };
char ch[100000][16] = { '\0' };
int main(void) 
{
    long long int n, t, s, k, temp = 0;
    char tran[16] = { '\0' };
    scanf_s("%lld", &n);
    t = n;
    s = n;
    while (t--)
    {
        for (int i = 0; i < n; i++)
        {
            scanf_s("%lld", &num[i]);
            scanf_s("%s", ch[i], 17);
        }
        while (s--)
        {
            for (int i = 0; i < n - 1; i++)
            {
                if (num[i] < num[i + 1])
                {
                    temp = num[i];
                    num[i] = num[i + 1];
                    num[i + 1] = temp;
                    strcpy_s(tran, ch[i][16], 16);
                    strcpy_s(ch[i][16], ch[i + 1][16], 16);
                    strcpy_s(ch[i + 1][16], tran, 16);
                }
            }
        }
        scanf_s("%lld", &k);
        printf("%s", ch[k]);
    }
}