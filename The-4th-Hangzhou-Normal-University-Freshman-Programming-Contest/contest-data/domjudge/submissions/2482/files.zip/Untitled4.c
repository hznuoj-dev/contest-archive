#include<stdio.h>
struct person{
	long long xihuan;
	char ge[100];
}stu[100000];
int comp(const void*p,const void*q){
	return (*(int*)p-*(int*)q);
}
int main(){
	int n,k;
	scanf("%d",&n);
	int i=0;
	while(i<n){
		scanf("%lld%s",&stu[i].xihuan,&stu[i].ge);
		getchar();
		i++;
	}
	struct person max;
	i=0;
	while(i<n-1){
		int j=0;
		while(j<n-i-1){
			if(stu[j].xihuan<stu[j+1].xihuan){
				max=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=max;
			}
			j++;
		}
		i++;
	}
	scanf("%d",&k);
	printf("%s",&stu[k].ge); 
	return 0;
}
