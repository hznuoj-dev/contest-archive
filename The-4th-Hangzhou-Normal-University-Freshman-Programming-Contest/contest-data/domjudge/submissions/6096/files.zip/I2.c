
#include<stdio.h>
#include<process.h>
struct Song
{
	long long w;
	char s[100];
}a[10000],t;
int main()
{
	int n;
	int k;
	
	int i,j;
	int m;

	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&a[i].w,a[i].s);
	}

	for(i=0;i<n-1;i++)
	{
		m=i;
		for(j=i+1;j<n;j++)
		{
			if(a[j].w>a[m].w)
			{
				m=j;
			}
		}
		if(m!=i)
		{
			t=a[i];
			a[i]=a[m];
			a[m]=t;
		}
	}

	scanf("%d",&k);
	printf("%s\n",a[k].s);

	system("pause");
	return 0;
}