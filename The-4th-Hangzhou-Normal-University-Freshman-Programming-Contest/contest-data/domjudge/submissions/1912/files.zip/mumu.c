#define _CRT_SECURE_NO_WARNINGS

#include<math.h>
#include<string.h>
#include<stdio.h>
int main()
{
    int n;
    scanf("%d", &n);
    while (n--)
        printf("Welcome to HZNU\n");
        

    return 0;
}