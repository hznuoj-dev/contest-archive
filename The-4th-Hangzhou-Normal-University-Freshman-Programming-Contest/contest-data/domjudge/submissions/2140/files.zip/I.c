#include <stdio.h>
void bubbleSort(int list[], int n);
int main(void){
	int i,n,k;
	scanf("%d",&n);
	int w[n],c[n];
	char str[n][16];
	for(i=0;i<n;i++)
	{
		scanf("%d%s",&w[i],str[i]);
		c[i]=w[i];
	}
		scanf("%d",&k);
	bubbleSort(w,n);
	for(i=0;i<n;i++)
	{
		if(w[k]==c[i])
		printf("%s\n",str[i]);
	}
	return 0;
}
void bubbleSort(int list[], int n) {
    int pass,i,t,exchange;
    for(pass=1;pass<n;++pass){
    	exchange = 0;
        for(i=0;i<n-pass;++i){
            if(list[i]<list[i+1]){
                t=list[i];
                list[i]=list[i+1];
                list[i+1]=t;
                exchange=1;
            }
        }
        if(exchange==0)
	    break;
    }
}
