/*F*/
#define MAX 100
#include<stdio.h>
int main(void)
{
	int t, n, k, i, j, temp, l, flag, p, q;
	int a[MAX][MAX], b[MAX][MAX], c[MAX][MAX];
	scanf("%d", &t);
	for(k=1;k<=t;k++){
		scanf("%d", &n);
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d", &a[i][j]);
			}
		}
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d", b[i][j]);
			}
		}
		for(l=1;l<=4;l++){
			flag=1;
			for(i=0;i<n;i++){
				if(flag==0) break;
				for(j=0;j<n;j++){
					if(a[i][j]!=b[i][j]){
						flag=0;
					}
				}
			}
			if(flag){
			    printf("%d", 1);
			    break;
			}
			for(p=0;p<n;p++){
		for(q=0;q<n;q++){
			c[q][n-p-1]=a[p][q];
		}
	}
	for(p=0;p<n;p++){
		for(q=0;q<n;q++){
			a[p][q]=c[p][q];
		}
	}
	if(flag==0){
			printf("%d", -1);
		}
		}		
	}
	return 0;
}

