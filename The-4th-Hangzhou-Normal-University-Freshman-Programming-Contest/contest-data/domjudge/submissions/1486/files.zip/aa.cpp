#include <iostream>
#include <vector>
#include <map>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin.tie(0);
	int q;
	cin>>q;
	while(q--){
		int n;
		cin>>n;
		map<char,int> mp;
		while(n--){
			char cur;
			cin>>cur;
			if(mp.count(cur)) mp[cur]++;
			else mp[cur]=1;
		}
		int k=0;
		int result=0;
		for(auto i=mp.begin();i!=mp.end();i++){
			if(i->second%2) k=1;
			result+=(i->second/2)*2;
		}
		cout<<result+k<<endl;
	}
	
	return 0;
}
