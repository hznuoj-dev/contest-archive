#include<bits/stdc++.h>
using namespace std;
int like[100010]; 
bool cmp(int a,int b){
	return a>b;
}
int main(){
	int n,a;
	string s;
	scanf("%d",&n);
	map<int,string> m;
	for(int i=1;i<=n;i++){
		cin>>like[i]>>s;
		m[like[i]]=s;
	}
	sort(like+1,like+1+n,cmp);
	scanf("%d",&a);
	cout<<m[like[a+1]]<<'\n';
	return 0;
}
