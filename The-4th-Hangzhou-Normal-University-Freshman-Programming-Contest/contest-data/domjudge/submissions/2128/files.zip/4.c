#include <stdio.h>

int main(void){
	char a[1000];
	int t,i,j,n,len,flag=0;
	char k;
	scanf("%d",&t);
	while(t--){
		flag=0;
		len=0;
		scanf("%d",&n);
		getchar();
		for(i=0;i<150;i++){
			a[i]=0;
		}
		for(i=0;i<n-1;i++){
			scanf("%c ",&k);
			a[k]++;
		}
		scanf("%c",&k);
		a[k]++;
		for(i=32;i<150;i++){
			if(a[i]%2==0){
				len=len+a[i];
			}else if(a[i]/2!=0){
				len=len+a[i]-1;
			}
			if(a[i]%2==1)flag=1;
		}
		len=len+flag;
		printf("%d\n",len);
	}

	return 0;
} 
