#include <stdio.h>
#include <stdlib.h>
struct song{
 int love;
 char name[16];
};
int cmp(const void *p,const void *q)
{
 struct song *pp = (struct song*)p;
 struct song *pq = (struct song*)q;
	int b = pq->love;
	int a = pp->love;
 return b-a;
}
int main()
{
 int i,q,n;
 scanf("%d",&n);
 struct song a[n];
 for(i=0;i<n;++i)
 {
  scanf("%d %s",&a[i].love,a[i].name);
 }
 qsort(a,n,sizeof(struct song),cmp);
  scanf("%d",&q);
 printf("%s",a[q].name);
 return 0;
}
