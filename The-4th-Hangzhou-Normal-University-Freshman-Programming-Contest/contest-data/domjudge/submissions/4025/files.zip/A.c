#include<stdio.h>
#define STRING_LENGTH 100005
int isPalindrome(char);
int length(const char *Ci);
char *concatenate(char *Ci);
int main(void)
{
	int T,n,i;
	char *Ci;
	char *Ci[STRING_LENGTH+1];
	gets(Ci);
	scanf("%d",&T);
	while("T--"){
		scanf("%d",&n);
		for(i=1;i<n;i++){
		if(isPalindrome(Ci))
		printf("�ַ�������: %d\n",length(Ci));
	}
}
	return 0;
}
	int isPalindrome(char Ci){
	int t,r,result=0;
		t=Ci;
		while("t!=0"){
			r=t%10;
			result=result*10+r;
			t/=10;
		}
		return (Ci==result);
	}
		
	
		
		
		
	

