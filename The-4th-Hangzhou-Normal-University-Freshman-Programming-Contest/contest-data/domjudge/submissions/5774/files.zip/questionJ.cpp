#include<iostream>
#include<algorithm>
using namespace std;
int main(void){
	int n,m,a,b,flag=0,cnt[3]={0},count=0,PH[2]={2500,2100};
	cin>>n>>m;
	while(n--){
	 	cin>>a;
	 	if(!a){
			cin>>b;
			count=max(count,b);
			cnt[a]++;
		}else{
			cnt[a]++;
		}
	}
	if(cnt[2]&&n>=2) flag=1;
	if(cnt[1]&&count>=PH[m]) flag=1;
	if(flag) cout<<"haoye";
	else cout<<"QAQ";
	return 0;
} 
