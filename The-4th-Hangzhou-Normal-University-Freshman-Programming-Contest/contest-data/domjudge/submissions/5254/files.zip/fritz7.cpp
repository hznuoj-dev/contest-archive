#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<cmath>
#include<cctype>
using namespace std;
struct hh {
	int zl;
	int gj;
};
struct hh gsk[101];
int main(){
int n,m,i,j;
cin>>n>>m;
int num;
int one=0,two=0,zero=0;int maxn=0;
 for(i=0;i<n;i++){
 	cin>>gsk[i].zl;
 	
 	if(gsk[i].zl==1){
 		one++;
	 }
	 else if(gsk[i].zl==2){
	 	two++;
	 }
	 else if(gsk[i].zl==0){
	 	
	zero++; 
 	cin>>gsk[i].gj;
 	if(gsk[i].gj>maxn){
 		maxn=gsk[i].gj;
	 }
 }
}
int hf=0;
if(two>=1&&n>=2){
	hf=1;
}
else if(one>=1&&zero>=1){
	if(m==0){
		if(maxn>=2500){
			hf=1;
		}
	}
	else{
		if(maxn>1200){
			hf=1;
		}
	}
}
if(hf==1)cout<<"haoye"<<endl;
else cout<<"QAQ"<<endl;
}
