#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int aa[100100]={0};
int main(){
	int t=0,i=0,n=0,h=0,g=0;
	int x=0,y=0;
	scanf("%d",&t);
	while(t--){
		g=0,h=0;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&aa[i]);
		}
		for(x=0;x<n;x++){
			for(y=x;y<n;y++){
				g=g+aa[y];
				if(g==7777){
					g=0;
					h++;
					break;
				}
				if(g>7777){
					g=0;
					break;
				}
			}
		}
		printf("%d\n",h);
	}
	return 0;
}
