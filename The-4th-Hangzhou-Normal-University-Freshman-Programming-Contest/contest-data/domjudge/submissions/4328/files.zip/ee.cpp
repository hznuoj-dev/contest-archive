#include<stdio.h>
#include<stdlib.h>
struct song{
	int a;
	char b[16];
};
int comp(const void *p,const void *q){
	return ((struct song *)q)->a-((struct song *)p)->a;
}
int main(){
	struct song x[100000];
	int n,k,i;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&x[i].a,x[i].b);
	}
	scanf("%d",&k);
	qsort(x,n,sizeof(struct song),comp);
	printf("%s\n",x[k].b);
	return 0;
}
