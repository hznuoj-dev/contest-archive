#include<stdio.h>
#include<stdlib.h>
#include<stdio.h> 
typedef struct{
	long long cishu;
	char name[20];
}sing;
int cmp(const void*a,const void*b){
	return ((sing *)b)->cishu - ((sing *)a)->cishu;
}
int main(void){
	sing s1[10000];
	int n,i,k;
	char ch=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%lld %s",&s1[i].cishu,s1[i].name);
	}
	scanf("%d",&k);
	qsort(s1,n,sizeof(sing),cmp);
			printf("%s",s1[k].name);
	return 0;
} 

