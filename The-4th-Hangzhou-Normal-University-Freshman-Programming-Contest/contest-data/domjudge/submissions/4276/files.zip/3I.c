#include <stdio.h>

struct song {
	int w;
	char name[16];
};

int comp(const void *p, const void *q) {
	return ((struct song *)q)->w - ((struct song *)p)->w;
}

int main() {
	int n, k, i, j;
	scanf("%d", &n);
	struct song a[n];
	for (i = 0; i < n; ++i) {
		getchar();
		scanf("%d %s", &a[i].w, a[i].name );
	}
	scanf("%d", &k);
	qsort(a, n, sizeof(struct song), comp);
	printf("%s", a[k].name);
	return 0;
}