#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n;int a,b;
	scanf("%d",&n);
	while(n--)
{
	scanf("%d%d",&a,&b);
	if(b==0)printf("no\n");
	else printf("yes\n");
}
	return 0;
}
