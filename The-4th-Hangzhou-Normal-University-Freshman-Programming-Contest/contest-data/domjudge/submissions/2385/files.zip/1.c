#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
char str[1010][50];
int main (){
	int t=0,i=1,j=0,h=0,n=0,x=0,y=0;
	char c;
	scanf("%d",&t);
	while(t--){
		i=1,h=0;
		while(scanf("%s",str[i])!=EOF){
			n=strlen(str[i]);
			if(str[i][n-1]=='.'||str[i][n-1]=='?'||str[i][n-1]=='!'){
				break;
			}
			i++;
		}
		c=str[i][n-1];
		str[i][n-1]='\0';
		if(i%2==0){
			for(x=1;x<=i/2;x++){
				if(h==1){
					printf(" ");
				}
				printf("%s %s",str[x],str[i-x+1]);
				h=1;
			}
			printf("%c\n",c);
		} else if(i%2==1){
			for(x=1;x<=i/2;x++){
				if(h==1){
					printf(" ");
				}
				printf("%s %s",str[x],str[i+1-x]);
				h=1;
			}
			printf(" %s",str[i/2+1]);
			printf("%c\n",c);
		}
	}
	return 0;
}
