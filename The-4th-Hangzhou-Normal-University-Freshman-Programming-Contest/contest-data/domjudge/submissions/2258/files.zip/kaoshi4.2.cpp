#include<stdio.h>
#include<stdlib.h>
#define nb 10^5
struct stf{
	long long int cd;
	char mz[16];
}; 
int comp(const void*p,const void*q){
	return ((struct stf*)q)->cd-((struct stf*)p)->cd;
}
int main(void){
	struct stf stfkk[nb];
	int i;
	long long int k,n;
	scanf("%lld",&n);
	for(i=0;i<n;i++){
		scanf("%lld%s",&stfkk[i].cd,stfkk[i].mz);
	}
	scanf("%lld",&k);
	qsort(stfkk,n,sizeof(struct stf),comp);
	printf("%s",stfkk[k].mz);
	return  0;
}
