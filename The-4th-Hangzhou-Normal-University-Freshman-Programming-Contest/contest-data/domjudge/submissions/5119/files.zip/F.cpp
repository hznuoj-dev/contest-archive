#include<stdio.h>
int main() {
	int T;
	int N;
	int a[20][20];
	int b[20][20];
	int a1[20][20];
	scanf("%d",&T);
	for(int i=1; i<=T; i++) {
		int p=-1;
		scanf("%d",&N);
		for(int x=0; x<N; x++) {
			for(int y=0; y<N; y++) {
				scanf("%d",&a[x][y]);
			}
		}
		for(int k=0; k<N; k++) {
			for(int l=0; l<N; l++) {
				scanf("%d",&b[k][l]);
			}
		}
		for(int i=1; i<=3; i++) {
		    	int sum=0;
			for(int q=0; q<N; q++) {
				for(int w=0; w<N; w++) {
					a1[q][w]=a[w][N-q-1];
					if(a1[q][w]==b[q][w]) {
						sum=sum+1;
					}
				}
			}
			if(sum==N*N){
			    p=i;
				break;	
			}
			else{
				for(int x=0;x<N;x++){
					for(int y=0;y<N;y++){
						a[x][y]=a1[x][y];
					}
				}
			}
		}
		if(p==3){
			p=1;
		}
		printf("%d\n",p);
	}
    return 0;
}
