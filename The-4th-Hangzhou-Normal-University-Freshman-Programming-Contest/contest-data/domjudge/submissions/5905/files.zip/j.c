#include<stdio.h>
#include<string.h>
int main(){
	int n,i,m,k[11],ATK=2500,DEF=2100,a[11],flag=0,c=0,b=0;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&k[i]);
			if(m==0&&k[i]>=ATK)
				c=1;
			else if(m==1&&k[i]>DEF)
				c=1;
		}
			if(a[i]==1)
				b=1;
			if(a[i]==2&&n>=2)
				flag=1;

	}
	if(c==1&&b==1||flag==1)
		printf("haoye\n");
	else
		printf("QAQ\n");
	return 0;
}