#include<bits/stdc++.h>
using namespace std;
int main()
{  int i,j,k,n,m,l;
   cin>>n;
   for (i=1;i<=n;i++)
    cout<<"Welcome to HZNU"<<"\n";
  
   

 
} 
