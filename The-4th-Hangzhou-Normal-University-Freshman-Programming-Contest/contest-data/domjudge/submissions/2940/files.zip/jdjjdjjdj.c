#include<stdio.h>
#include<math.h>
#include<string.h>
int main() {
	int T, i, n, t, k , pass, j, len, exchange;
	char bq[100][100], m[100];
	int sb[1000];
		scanf("%d", &t);
		for (i = 0; i <= t - 1; i++) {
			scanf("%lld", &sb[i]);
			scanf("%s", bq[i]);
		}
		for (i = 0; i < t - 1; i++) {
			for (j = 0; j < t - 1 - i; j++) {
				if (sb[j] < sb[j + 1]) {
					strcpy(m, bq[j]);
					strcpy(bq[j], bq[j + 1]);
					strcpy(bq[j + 1], m);
					k = sb[j];
					sb[j] = sb[j + 1];
					sb[j + 1] = k;
				}
			}
		}
		scanf("%d", &k);
		printf("%s", bq[k]);
		}
	


/*#include<stdio.h>
#include<string.h>

struct numeber {
	long long love;
	char name[100]
};
int main() {
	int n, sb[100], k, i;
	char p[1000];
	struct number get[1000];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%lld%s", &get.love[i], get.name[i]);
	}
	for (i = 0; i < n - i; i++) {
		for (int j = 0; j < n - i - 1; j++) {
			if (get.love[j] < get.love[j + 1]) {
				long long	temp = get.love[j];
				get.love[j] = get.love[j + 1];
				get.love[j + 1] = temp;
				strcpy(p, get.name[j]);
				strcpy(get.name[j], get.name[j + 1]);
				strcpy(get.name[j + 1], p);
			}
		}
	}
	scanf("%d", &k);
	printf("%s", get.name[k + 1]);

}
*/