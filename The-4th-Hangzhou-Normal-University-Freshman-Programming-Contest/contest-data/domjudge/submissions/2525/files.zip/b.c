#include<stdio.h>
int main(){
	int t, n, i, j, s, m;
	int f[100000];
	scanf("%d", &t);
	while(t--){
		m=0;
		scanf("%d", &n);
		for(i=0;i<n;i++){
			scanf("%d", &f[i]);
		}
		for(i=0;i<n;i++){
			for(j=i+1;j<n;j++){
				f[i]+=f[j];
				if(f[i]==7777){
					m+=1;
					break;
				}
			}
		}
		printf("%d\n", m);
	}
	
}
