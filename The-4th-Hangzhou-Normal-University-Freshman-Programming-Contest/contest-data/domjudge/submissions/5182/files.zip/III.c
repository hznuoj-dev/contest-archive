#include <stdio.h>
#include <stdlib.h>
#define size 100008 
struct STU{
	int num;
	char ss[20];
};
int cmp(const void* a,const void* b){
	struct STU *p=(struct STU *)a, *q=(struct STU *)b;
	return (q->num) - (p->num );
}
struct STU a[size];
int main(int argc, char *argv[]) {
	int T,i,m;
	
	scanf("%d",&T);
	for(i=0;i<T;i++){
		scanf("%d %s",&a[i].num ,a[i].ss );
	} 
	qsort(a,T,sizeof(struct STU),cmp);
	scanf("%d",&m);
	printf("%s\n",a[m].ss );
	return 0;
}
