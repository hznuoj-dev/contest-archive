#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int f(int x);
int main(){
	int t, n, i, j, r, s=0, q=0;
	scanf("%d%d", &n, &t);
	r=f(t);
	while(n--){
		scanf("%d", &i);
		if(i==0){
			scanf("%d", &j);
			if(j>=r&&s==0){
				s=2;
			}
		}
		else if(i==1&&(s==2||s==1)){
			s=3;
		}
		else if(i==2&&q>=1&&s==0){
			s=3;
			q=0;
		} 	
		q+=1;
		if(s==2||s==1){
			s-=1;
		} 
		if(s==3){
			printf("haoye\n");
			break;
		}
	}
	if(s!=3){
		printf("QAQ\n");
	}
}
int f(int x){
	if(x==1){
		return 2100;
	}
	if(x==0){
		return 2500;
	}
}
