#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		char arr[100000];
		scanf("%d",&n);
		int i=0;
		while(i<n){
			scanf("%c",&arr[i]);
			i++;
		}
		i=0;
		while(i<n){
			printf("%c ",&arr[i]);
			i++;
		}
		i=0;
		int brr[52];
		while(i<n){
			if(arr[i]=='a'){brr[0]++;}
			if(arr[i]=='b'){brr[1]++;}
			if(arr[i]=='c'){brr[2]++;}
			if(arr[i]=='d'){brr[3]++;}
			if(arr[i]=='e'){brr[51]++;}
			if(arr[i]=='f'){brr[4]++;}
			if(arr[i]=='g'){brr[5]++;}
			if(arr[i]=='h'){brr[6]++;}
			if(arr[i]=='i'){brr[7]++;}
			if(arr[i]=='j'){brr[8]++;}
			if(arr[i]=='k'){brr[9]++;}
			if(arr[i]=='l'){brr[10]++;}
			if(arr[i]=='m'){brr[11]++;}
			if(arr[i]=='n'){brr[12]++;}
			if(arr[i]=='o'){brr[13]++;}
			if(arr[i]=='p'){brr[14]++;}
			if(arr[i]=='q'){brr[15]++;}
			if(arr[i]=='r'){brr[16]++;}
			if(arr[i]=='s'){brr[17]++;}
			if(arr[i]=='t'){brr[18]++;}
			if(arr[i]=='u'){brr[19]++;}
			if(arr[i]=='v'){brr[20]++;}
			if(arr[i]=='w'){brr[21]++;}
			if(arr[i]=='x'){brr[22]++;}
			if(arr[i]=='y'){brr[23]++;}
			if(arr[i]=='z'){brr[24]++;}
			if(arr[i]=='A'){brr[25]++;}
			if(arr[i]=='B'){brr[26]++;}
			if(arr[i]=='C'){brr[27]++;}
			if(arr[i]=='D'){brr[28]++;}
			if(arr[i]=='E'){brr[29]++;}
			if(arr[i]=='F'){brr[30]++;}
			if(arr[i]=='G'){brr[31]++;}
			if(arr[i]=='H'){brr[32]++;}
			if(arr[i]=='I'){brr[33]++;}
			if(arr[i]=='J'){brr[34]++;}
			if(arr[i]=='K'){brr[35]++;}
			if(arr[i]=='L'){brr[36]++;}
			if(arr[i]=='M'){brr[37]++;}
			if(arr[i]=='N'){brr[38]++;}
			if(arr[i]=='O'){brr[39]++;}
			if(arr[i]=='P'){brr[40]++;}
			if(arr[i]=='Q'){brr[41]++;}
			if(arr[i]=='R'){brr[42]++;}
			if(arr[i]=='S'){brr[43]++;}
			if(arr[i]=='T'){brr[44]++;}
			if(arr[i]=='U'){brr[45]++;}
			if(arr[i]=='V'){brr[46]++;}
			if(arr[i]=='W'){brr[47]++;}
			if(arr[i]=='X'){brr[48]++;}
			if(arr[i]=='Y'){brr[49]++;}
			if(arr[i]=='Z'){brr[50]++;}
			i++;
		}
		i=0;
		int cnt=0;
		while(i<52){
			if(brr[i]%2==1){
				cnt++;
			}
			i++;
		}
		printf("%d\n",n-cnt+1);
	}
	return 0;
}
