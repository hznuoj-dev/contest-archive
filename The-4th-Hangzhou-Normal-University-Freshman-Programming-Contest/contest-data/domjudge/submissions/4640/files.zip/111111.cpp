#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<map>
#include<iomanip>
#include<ctime>
using namespace std;
string a[1010];
int main()
{
	int t;
	cin >> t;
	while (t--)
	{
		char x;
		int n = 0;
		for (int i = 0;; i++)
		{
			n++;
			cin >> a[i];
			int l = a[i].length();
			if (a[i][l-1] == '.' || a[i][l-1] == '!' || a[i][l-1] == '?')
			{
				x = a[i][l-1];
				break;
			}
		}
		for (int i = 0, j = n - 1; i < j; i++,j--)
		{
			if (j == n - 1)
			{
				cout << a[i];
				cout << ' ';
				int l = a[j].length();
				for (int d = 0; d < l-1; d++)
				{
					cout << a[j][d];
				}
			}
			else
			{
				cout << ' ';
				cout << a[i];
				cout << ' ';
				cout << a[j];
			}
			
		}
		if (n % 2 != 0)
		{
			if (n == 1)
			{
				int l = a[0].length();
				for (int d = 0; d < l-1; d++)
				{
					cout << a[0][d];
				}
			}
			else
				cout<<' '<< a[(n - 1) / 2];
		}
		cout << x << endl;
	}
}