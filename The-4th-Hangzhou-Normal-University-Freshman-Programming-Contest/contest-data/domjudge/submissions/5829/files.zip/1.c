#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int main(void)
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		char a[1000][31]; 
		char b[31];
		int i=0;
		while(1)
		{
			scanf("%s",a[i]);
			getchar();
			if((a[i][strlen(a[i])-1]=='?')||(a[i][strlen(a[i])-1]=='!')||(a[i][strlen(a[i])-1]=='.')) break;
			i++;
		}
		char c=a[i][strlen(a[i])-1];
		int j;
		for(j=0;j<(strlen(a[i])-1);j++)
		{
			b[j]=a[i][j];
		}
		b[j]='\0';
		strcpy(a[i],b);
		int n=i;//�ַ�cuan����-1
		int count=1;
		for(i=0;i<n/2;i++)
		{
			printf("%s %s ",a[i],a[n-i]);
		}
		if(n%2==0) printf("%s",a[n/2]);
		else
		{
			printf("%s %s",a[n/2],a[n/2+1]);
		}
		printf("%c\n",c);
	}
	return 0;
} 
