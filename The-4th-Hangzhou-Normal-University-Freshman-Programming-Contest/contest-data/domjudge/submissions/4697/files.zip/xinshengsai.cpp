#include <stdio.h>
int maxii(int a,int b){
	if(a>b) return a;
	else return b;
}
int main()
{
	int t;
	scanf("%d\n",&t);
	int a[52];
	
	while(t--)
	{
		for(int i=0;i<52;i++) a[i]=0;
		int n;
		scanf("%d\n",&n);
		int num=2*n-1;
		char str[num];
		int sum=0;
		for(int i=0;i<=2*n-2;i++) 
		    scanf("%c",&str[i]);
		for(int i=0;i<n;i++)
		{
			if(str[2*i]>='A'&&str[2*i]<='Z') 
			    a[str[2*i]-'A']+=1;
			else a[str[2*i]-'a'+26]+=1;
			
		}
		int max=0;
		int ff=0;
		int max_i;
		for(int i=0;i<52;i++)
		{
		    if(a[i]%2==1&&a[i]>max)
			{    
			    max=a[i];
				max_i=i;
			}
		}
		for(int i=0;i<52;i++)
		{
			if(a[i]%2==0)
			    sum+=a[i];
		}
		for(int i=0;i<52;i++)
		{
			if(a[i]%2==1&&i!=max_i)
			{
				sum+=a[i]/2*2;
			}
		}

		    printf("%d\n",sum+max);

	}
	
	return 0;
}
