#include<stdio.h>
int main(){
	int n,t,m,i,j,b,a=1;
	scanf("%d",&n);
	while(n--){
		scanf("%d %d",&t,&m);
		for(i=0;;i++){
			j=i*m%t;
			if(j==0){
				printf("yes\n");
				a=0;
				break;
			}
		}
		if(a){
			printf("no\n");
		}
	}
	return 0;
}
