#include <iostream>
using namespace std;
char bb[10][3][4]={{" _ ",
			           "| |",
				       "|_|"},
	                 {"   ",
			          "  |",
				      "  |"},
				     {" _ ",
			          " _|",
				      "|_ "},
				     {" _ ",
			          " _|",
				      " _|"},
				     {"   ",
			          "|_|",
				      "  |"},
				     {" _ ",
			          "|_ ",
				      " _|"},
				     {" _ ",
			          "|_ ",
				      "|_|"},
				     {" _ ",
			          "  |",
				      "  |"},
				     {" _ ",
			          "|_|",
				      "|_|"},
				     {" _ ",
			          "|_|",
				      " _|"}
					 };
/*
 _  _  _  _  _  _ 
 _| _| _| _| _| _|
|_ |_ |_ |_ |_ |_ 
 _  _  _  _  _  _ 
 _| _| _| _| _| _|
|_  _||_ |_ |_ |_ 

*/
/*
    _  _  _  _  _ 
  ||_| _|  | _||_ 
  | _||_   | _| _|
    _  _  _  _    
  ||_| _||_  _||_|
  ||_||_ |_| _|  |
*/
int f(char a[3][3])
{
	
	for(int i=0;i<10;++i)
	{
		int flag=0;
		for(int j=0;j<3;++j)
		{
			for(int k=0;k<3;++k)
			{
				if (a[j][k]!=bb[i][j][k])
				{
					flag=1;
					break;
				}
			}
			if (flag==1)
			{
				break;
			}
		}
		if (flag==0)
		{
			return i;
		}
	} 
	return -1;
}
int main()
{	
    char a[4][19],b[4][19],t[3][3];
	int i,j,k,c[6],d[6];
    for(i=0;i<3;++i)
    {
   		 cin.getline(a[i],19);
	}
    for(i=0;i<3;++i)
    {
   		 cin.getline(b[i],19);
	}  
	for(k=0;k<6;++k)
	{
		for(i=0;i<3;++i)
		{
			for(j=0;j<3;++j)
			{
				t[i][j]=a[i][k*3+j];
			}
		}
		c[k] = f(t);		 
	}
	for(k=0;k<6;++k)
	{
		for(i=0;i<3;++i)
		{
			for(j=0;j<3;++j)
			{
				t[i][j]=b[i][k*3+j];
			}
		}
		d[k] = f(t);
	}
/*	for(k=0;k<6;++k)
	{
		cout<<c[k]<<" ";
	}
	cout << endl;
	for(k=0;k<6;++k)
	{
		cout<<d[k]<<" ";
	}
	cout << endl;*/
 	int cc=(c[0]*10+c[1])*3600+(c[2]*10+c[3])*60+c[4]*10+c[5];
 	int dd=(d[0]*10+d[1])*3600+(d[2]*10+d[3])*60+d[4]*10+d[5];
 	int tt=dd-cc;
 	if (cc==dd)
 	{
 		cout<<"gang gang hao"<<endl;
	}
	else if (cc<dd)
	{
		cout<<"late"<<endl;
	}
	else
	{
		cout<<"early"<<endl;
		tt = cc - dd;
	}	
	int hour=tt/3600;
	int fen=tt%3600/60;
	int miao=tt%60;
	int hour1 = hour/10,hour2 = hour%10;
	int fen1=fen/10,fen2=fen%10;
	int miao1=miao/10,miao2=miao%10;
	cout<<bb[hour1][0];
	cout<<bb[hour2][0];
	cout<<bb[fen1][0];
	cout<<bb[fen2][0];
	cout<<bb[miao1][0];
	cout<<bb[miao2][0];
	cout<<endl;
	cout<<bb[hour1][1];
	cout<<bb[hour2][1];
	cout<<bb[fen1][1];
	cout<<bb[fen2][1];
	cout<<bb[miao1][1];
	cout<<bb[miao2][1];
	cout<<endl;
	cout<<bb[hour1][2];
	cout<<bb[hour2][2];
	cout<<bb[fen1][2];
	cout<<bb[fen2][2];
	cout<<bb[miao1][2];
	cout<<bb[miao2][2];
	cout<<endl;
}
