#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
typedef struct song{
 int love;
 char name[30]; 
}song;
int cmp(const void *p, const void *q){
 song xx = *(song *)p ;
 song yy = *(song *)q ;
 return yy.love-xx.love ;
}
int main (){
 int n,i,k;
 scanf("%d",&n);
 struct song a[n+1];
 for(i=0;i<n;i++){
  scanf("%d %s",&a[i].love,a[i].name);
 }
 scanf("%d",&k);
 qsort(a,n,sizeof(song),cmp);
 printf("%s",a[k].name);
 return 0;
} 
