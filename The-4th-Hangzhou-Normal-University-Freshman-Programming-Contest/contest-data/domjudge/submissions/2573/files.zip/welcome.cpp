#include<stdio.h>
#include<string.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		char a[1000][30];
		scanf("%s",a[i])
	}

}
