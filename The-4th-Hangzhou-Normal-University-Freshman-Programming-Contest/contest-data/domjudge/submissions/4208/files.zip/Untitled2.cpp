#include<stdio.h>
int main(void){
	int T,n,i,j,t,k,max;
	scanf("%d",&T);
	while(T>0){
		scanf("%d",&n);
		char a[n+1],b[n+1];
		int c[n+1];
		for(i=0;i<n;i++){
			scanf(" %c",&a[i]); 
		}
		b[0]=a[0];
		c[0]=1;
		t=1;
		for(i=1;i<n;i++){
			k=1;
			for(j=0;j<t&&k==1;j++){
				if(a[i]==b[j]){
					c[j]+=1;
					k=0;
				}
			}
			if(k==1){
				b[t]=a[i];
				c[t]=1;
				t+=1;
			}
		}
		k=1;
		max=0;
		for(i=0;i<t;i++){
			if(c[i]%2==0){
				max+=c[i];
			}
			else if(k==1){
				k=0;
				max+=c[i];
			}
			else
			max+=c[i]-1;
		}
		printf("%d",max);
		if(T!=1)
		printf("\n");
		T-=1;
	}
	return 0;
} 

