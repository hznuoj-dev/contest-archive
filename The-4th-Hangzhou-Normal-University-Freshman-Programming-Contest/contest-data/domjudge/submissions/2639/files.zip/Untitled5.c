#include<stdio.h>
#include<stdlib.h>
struct song{
	char name[20];
	int level;
}s[100010];
int comp(const void *p,const void *q){
	return -((struct song *)p)->level+((struct song *)q)->level;
}
int main()
{
	int t;
	int m;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		scanf("%d %s",&s[i].level,s[i].name);
	}
	scanf("%d",&m);
	qsort(s,t,sizeof(struct song),comp);
	printf("%s",s[m].name);
	return 0;
}
