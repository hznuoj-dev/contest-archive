#include<stdio.h>
#include<stdlib.h>
struct sing{
	long long w;
	char s[16];
};
int comp(const void *p, const void *q){
	return((struct sing *)q)->w - ((struct sing *)p)->w;
}
int main(void){
	struct sing a[100000];
	long long n,i,k;
	scanf("%lld",&n);
	for(i=0;i<n;i++){
		scanf("%lld %s",&a[i].w,a[i].s);
	}
	scanf("%lld",&k);
	qsort(a,n,sizeof(struct sing),comp);

			printf("%s",a[i].s);
	
	return 0;
}
















