#include<stdio.h>

int main()
{
	int N;
	char c;
	char a[1010][35];
	scanf("%d",&N);
	int i=0,j=0;
	while(N--)
	{
		i=j=0;
		for(int h=0;h<1010;h++)
		{
			for(int g=0;g<35;g++)
			{
				a[h][g]='\0';
			}

		}
		c=getchar();
		while(c!='.'&&c!=','&&c!='?')
		{
			if(c==' ')
			{
				i++;
				j=0;
			}
			else
			{
				a[i][j]=c;
				j++;
			}
			c=getchar();
		}
		if((i+1)%2==0)
		{
			for(int p=0;p<=i/2;p++)
			{
				if(p==0)
				{
					printf("%s",a[p]);
				}
				else
				{
					printf(" %s",a[p]);
				}
				printf(" %s",a[i-p]);
			}
		}
		else
		{
			for(int p=0;p<=(i-1)/2;p++)
			{
				if(p==0)
				{
					printf("%s",a[p]);
				}
				else
				{
					printf(" %s",a[p]);
				}
				printf(" %s",a[i-p]);
			}
			printf(" %s",a[i/2]);		
		}

		printf("%c",c);
		printf("\n");
		getchar();

	}
}
