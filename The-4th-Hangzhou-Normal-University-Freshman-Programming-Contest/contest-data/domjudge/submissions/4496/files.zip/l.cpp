#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
const int maxn=30;
int a[maxn][maxn];
int b[maxn][maxn];
int main(){
	int T;
	cin>>T;
	while(T--){
		int n;
		cin>>n;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				cin>>a[i][j];
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				cin>>b[i][j];
			}
		}	
		int flag=1;		
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(a[i][j]!=b[i][j]){
					flag=0;
					break;
				}
			}
			if(flag==0) break; 
		}
		if(flag==1){
			cout<<"0"<<endl;
			continue;
		} 
		flag=1;			
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(a[i][j]!=b[n-j+1][i]){
					flag=0;
					break;
				}
			}
			if(flag==0) break; 
		}
		if(flag==1){
			cout<<"1"<<endl;
			continue;
		} 
		flag=1;	
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(a[i][j]!=b[j][n-i+1]){
					flag=0;
					break;
				}
			}
			if(flag==0) break; 
		}
		if(flag==1){
			cout<<"1"<<endl;
			continue;
		} 
		flag=1;	
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(a[i][j]!=b[n-i+1][n-j+1]){
					flag=0;
					break;
				}
			}
			if(flag==0) break; 
		}
		if(flag==1){
			cout<<"2"<<endl;
			continue;
		} 
		cout<<"-1"<<endl;
	}
	return 0;
}
 
