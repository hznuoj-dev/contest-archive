#include<bits/stdc++.h>
using namespace std;

int n;

int main(){
	cin>>n;
	for(int i=0;i<n;i++)cout<<"Welcome to HZNU"<<'\n';
	
	
	
	
	
	return 0;
} 
