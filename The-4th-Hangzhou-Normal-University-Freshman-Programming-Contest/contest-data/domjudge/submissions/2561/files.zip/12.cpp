#include<stdio.h>
#include<stdlib.h>
#define ARRAY_SIZE 100000
struct loy
{
	char name [40];
	int num;
} ;
int cmp(const void *p,const void *q)
{
	struct loy*pp=(struct loy*)(p);
	struct loy*pq=(struct loy*)(q);
	int a=pp->num;
	int b=pq->num;
	return b-a;
}
int main(void)
{
   struct loy loyArray[ARRAY_SIZE];
   long long int t,n,i;
    scanf("%lld",&n);
    for(i=0;i<n;++i)
    { 
    scanf("%lld %s",&loyArray[i].num,loyArray[i].name);
     }
     
	 qsort (loyArray,n,sizeof(struct loy),cmp);
	 scanf("%lld",&t); 
	printf("%s\n",loyArray[t].name);
   return 0;
}
