#include<stdio.h>
int main()
{
	int n,t;
	int i,j,k,f;
	char a[100010];
	scanf("%d",&t);
	while(t--)
	{
		k=0;
		f=0;
		scanf("%d",&n);
		getchar();
		for(i=0;i<n;i++)
		{
			scanf("%c",&a[i]);
			getchar();
		}
		for(i=0;i<n;i++)
		{
			for(j=i;j<n;j++)
			{
				if(i!=j&&a[i]==a[j]&&a[i]!=' ')
				{
					k+=2;
					a[i]=' ';
					a[j]=' ';
					break;
				}
			}
		}
		for(i=0;i<n;i++)
		{
			if(a[i]!=' ')
			{
				k++;
				break;
			}
		}
		printf("%d\n",k);
	}
	return 0;
}
