#include <iostream>
using namespace std;
int n,t;
int a[100100];
int main ()
{
	cin >> n; 
	for (int i = 1; i <= n; i++)
		{
			cin >> t; 
			int sum=0,l=1,p=0;;
			for (int j = 1; j <= t; j++)
			{
				cin >> a[j];
				sum+=a[j];
				while  (sum > 7777)
					{
						sum=sum-a[l];
						l++;
					}
				if (sum == 7777) p++;
			}
			cout << p;
		}
}
