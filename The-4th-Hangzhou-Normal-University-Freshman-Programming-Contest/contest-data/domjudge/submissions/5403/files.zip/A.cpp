#include<stdio.h>

int main()
{
	int x,b,sum,max=0,i,j,num=0;
	int g[200000]={0};
	char a[200000],o;
	scanf("%d",&x);
	while(x--)
	{
		sum=0;
		max=0;
		num=0;
		scanf("%d",&b);
		for( i=1;i<=b;i++)
		{
			scanf("%c",&o);
			if((o>='a'&&o<='z')||(o>='A'&&o<='Z'))
			{
				for( j=1;j<=b;j++)
				{
				if(g[j]==0)
				{
					a[j]=o;
					g[j]++;
					num++;
					break;
				}
				else if(a[j]==o)
				{
					g[j]++;
					break;
				}
					
				}
			}
			else
				i--;
		}
			
		for(i=1;i<=num;i++)
		{
			if(g[i]%2==0)
			{
				sum+=g[i];
			}
			else
			{
				if(g[i]>max&&max!=0)
				{
					sum=sum+max-1;
					max=g[i];
				}
				else if(g[i]>max&&max==0)
				{
					max=g[i];
				}
				
			}
		}
		sum+=max;
		if(x>=1)
		printf("%d\n",sum);
		else
		printf("%d",sum);
		for(i=1;i<=num;i++)
		{
			g[i]=0;
		}
	}
	
	return 0;
}
