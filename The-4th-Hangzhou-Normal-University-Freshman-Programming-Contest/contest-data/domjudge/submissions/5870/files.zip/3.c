#include<stdio.h>
struct zu{
	long long w;
	char s[17];
}song[100001],ti;
int main(void){
	long long n,k,i,x,y,max;
	scanf("%lld",&n);
	for(i=1;i<=n;i++){
		scanf("%lld%s",&song[i].w,song[i].s);
	}
	for(x=1;x<n;x++){
		max=x;
		for(y=x;y<=n;y++){
			if(song[max].w<song[y].w){
				max=y;
		}if(max!=x){
			
		ti=song[max];
			song[max]=song[x];
			song[x]=ti;}}
		
	}
	scanf("%lld",&k);
	printf("%s",song[k+1].s);
	 
	return 0;
}
