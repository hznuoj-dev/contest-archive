
#include<stdio.h>
int main()
{
	int n,m,i,ac,flag=0,j;//ac�ǹ����� 
	int type[15];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%d",&type[i]);
		getchar();
		if(type[i]==0)
		{
			scanf("%d",&ac); 
		} 
	}
	if(n==0||n==1) printf("QAQ");
    else
    {
    	for(i=0;i<n;i++)
    	{
    		if(type[i]==2)
    		{
    			flag=1;
    			break;
			}
			if(type[i]==0)
			{
			 for(j=0;j<n;j++)
			 {
			 	if(type[j]==1)
			 	{
			 		if(m==0&&ac>=2500)
			 		{
			 			flag=1;
			 			break;
					 }
					 if(m==1&&ac>2100)
					 {
					 	flag=1;
					 	break;
					 }
					 
				}
			 }
			 if(flag==1) break;
			}
		}
		if(flag==1) printf("haoye\n");
		else printf("QAQ\n");
	}
	return 0;
 } 

