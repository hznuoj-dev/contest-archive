#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<map>
#include<iomanip>
#include<ctime>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int a[21][21],b[21][21];
		int n;
		cin>>n; 
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				cin>>a[i][j];
			}
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				cin>>b[i][j];
			}
		}
		
		
		int flag=1;
		for(int i=0,p1=0;i<n;i++,p1++)
		{
			for(int j=0,p2=0;j<n;j++,p2++)
			{
				if(b[i][j]!=a[p1][p2])
				{
					flag=0;
				}
			}
		}
		if(flag)
		{
			cout<<0<<endl;
			continue;
		}
		
		flag=1;
		for(int i=0,p1=n-1;i<n;i++,p1--)
		{
			for(int j=0,p2=0;j<n;j++,p2++)
			{
				if(b[i][j]!=a[p2][p1])
				{
					flag=0;
				}
			}
		}
		if(flag)
		{
			cout<<1<<endl;
			continue;
		}
		
		
		flag=1;
		for(int i=0,p1=0;i<n;i++,p1++)
		{
			for(int j=0,p2=n-1;j<n;j++,p2--)
			{
				if(b[i][j]!=a[p2][p1])
				{
					flag=0;
				}
			}
		}
		if(flag)
		{
			cout<<1<<endl;
			continue;
		}
		
		
		flag=1;
		for(int i=0,p1=n-1;i<n;i++,p1--)
		{
			for(int j=0,p2=n-1;j<n;j++,p2--)
			{
				if(b[i][j]!=a[p1][p2])
				{
					flag=0;
				}
			}
		}
		if(flag)
		{
			cout<<2<<endl;
			continue;
		}
		cout<<-1<<endl;
	}
}
