#include<stdio.h>
#include<string.h>
struct ge{
	long long int a;
	char x[999];
}m[1000000];
int comp(const void*p,const void*q){
	return((struct ge*)q)->a -((struct ge*)p)->a ;
	
}

int main(void){
	 long long int n;
	scanf("%lld",&n);
	int i,j;
	for(i=0;i<n;i++){
		scanf("%lld %s",&m[i].a ,m[i].x );
	}
	struct ge q;
	qsort(m,n,sizeof(struct ge),comp);
	long long int k;
	scanf("%lld",&k);
	printf("%s\n",m[k].x );
	return 0;
}

