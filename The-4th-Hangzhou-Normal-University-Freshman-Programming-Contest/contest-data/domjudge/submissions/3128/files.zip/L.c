#include <stdio.h>
#include <string.h>
#include <math.h>
int main ()
{
    int t,n,i,j,k;
    scanf("%d",&t);
    for(i=1;i<=t;i++)
    {
        scanf("%d %d",&n,&k);
        int a[n];
        a[0]=1;
        for(j=1;j<n;j++)
            a[j]=0;
        int b=0;
        if(k==0)
            printf("no\n");
        else
        {
            while(1)
        {
            b=(b+k)%n;
            if(a[b]==1)
                break;
            a[b]++;
        }
        if(b==0)
            printf("yes\n");
        else
            printf("no\n");
        }

    }

}
