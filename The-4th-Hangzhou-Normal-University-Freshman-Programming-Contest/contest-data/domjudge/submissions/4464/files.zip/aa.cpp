#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#define pzc 666
using namespace std;
int a[25][25],b[25][25];
int main()
{
	int t,i,j,k,n;
	cin>>t;
	while(t--)
	{
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		cin>>n;
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				scanf("%d",&a[i][j]);
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				scanf("%d",&b[i][j]);
		k=1;
		for(i=1;i<=n&&k;i++)
			for(j=1;j<=n;j++)
				if(a[i][j]!=b[i][j])
					k=0;
		if(k==1)
		{
			cout<<"0"<<endl; continue;
		}
		k=1;
		for(i=1;i<=n;i++)
			for(j=1;j<=n&&k;j++)
				if(a[i][j]!=b[j][i])
					k=0;
		if(k==1)
		{
			cout<<"1"<<endl; continue;
		}
		
		k=1;
		for(i=1;i<=n;i++)
			for(j=1;j<=n&&k;j++)
				if(a[i][j]!=b[n-j+1][n-i+1])
					k=0;
		if(k==1)
		{
			cout<<"1"<<endl; continue;
		}
		
		k=1;
		for(i=1;i<=n;i++)
			for(j=1;j<=n&&k;j++)
				if(a[i][j]!=b[n-i+1][n-j+1])
					k=0;
		if(k==1)
		{
			cout<<"2"<<endl; continue;
		}
		else cout<<"-1"<<endl;
	}
}
