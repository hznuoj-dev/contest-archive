#include<stdio.h>
int main()
{
	double T,a,b;
	scanf("%lf",&T);
	while(T--){
		scanf("%lf%lf",&a,&b);
		if(b!=0)
		printf("yes\n");
		else
		printf("no\n");
	}
	return 0;
}

