#include<stdio.h>
#include<string.h>
int main(){
	long long int m,n,i=0,a[100000],j,k,t;
	char str1[100],str[1000][1000];
	scanf("%lld",&n);
	while(n--){
		scanf("%lld %s",&a[i],str[i]);
		i++;
	}
	scanf("%lld",&m);
	for(j=0;j<i;j++){
		for(k=0;k<i-j;k++){
			if(a[k]<a[k+1]){
				t=a[k];
				a[k]=a[k+1];
				a[k+1]=t;
				strcpy(str1,str[k]);
				strcpy(str[k],str[k+1]);
				strcpy(str[k+1],str1);
			}
		}
	}
	printf("%s",str[m]);
}
