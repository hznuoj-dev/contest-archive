#include<bits/stdc++.h>
using namespace std;
const int N=2e5;
int a[24][24],b[24][24];
int c[24][24];
int n;
void change(){
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			c[j][i]=a[i][j];
	for(int i=1;i<=n;i++)reverse(c[i]+1,c[i]+1+n);
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
		a[i][j]=c[i][j];
}
bool com(){
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			if(a[i][j]!=b[i][j])return 0;
	return 1;
}
void solve(){
	cin>>n;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			cin>>a[i][j];
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			cin>>b[i][j];
	int ans=0;
	if(com()){
		cout<<0<<'\n';
		return;
	}
	change();
	if(com()){
		cout<<1<<'\n';
		return;
	}
	change();
	if(com()){
		cout<<2<<'\n';
		return;
	}
	change();
	if(com()){
		cout<<1<<'\n';
		return;
	}
	cout<<-1<<'\n';
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
