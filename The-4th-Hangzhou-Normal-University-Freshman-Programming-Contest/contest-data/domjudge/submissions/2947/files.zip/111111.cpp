#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<map>
#include<iomanip>
#include<ctime>
using namespace std;
class gs
{
public:
	int name;
	int atk;
};
gs a[20];
int main()
{
	int flag = 0;
	int n, m;
	cin >> n >> m;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i].name;
		if (a[i].name == 0)
		{
			cin >> a[i].atk;
		}
	}
	if (n < 2)
	{
		flag = 0;
	}
	else
	{
		for (int i = 0; i < n; i++)
		{
			if (a[i].name == 2)
			{
				flag = 1;
			}
			else if (a[i].name == 1)
			{
				for (int j = 0; j < i; j++)
				{
					if (m == 0)
					{
						if (a[j].atk >= 2500)
						{
							flag = 1;
						}
					}
					else if (m == 1)
					{
						if (a[j].atk >= 2100)
						{
							flag = 1;
						}
					}
				}
			}
		}
	}
	if (flag)
	{
		cout << "haoye";
	}
	else
	{
		cout << "QAQ";
	}
}