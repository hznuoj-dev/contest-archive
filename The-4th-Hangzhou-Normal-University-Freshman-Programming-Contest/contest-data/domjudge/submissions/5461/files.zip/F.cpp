#include <bits/stdc++.h>
using namespace std;
map <int,int> m;

int main(){
	int i,n,x,z,h=0,y;
	cin>>n>>z;
	for (i=0;i<n;++i){
		cin>>x;
		if (x==2 && n>1 ) {
			h=1;
			break;
		} else if (x==0){
			cin>>y;
			if (y>m[0]) m[0]=y;
		}else {
			m[1]=1;
		}
	}
	if (m[1]== 1 && h ==0 ){
		if (z==1) {
			if (m[0]>2100) h=1;
		}else {
			if (m[0]>=2500) h=1;
		}
	}
	if (h==1) cout<<"haoye";
	else cout<<"QAQ";
	return 0;
}
