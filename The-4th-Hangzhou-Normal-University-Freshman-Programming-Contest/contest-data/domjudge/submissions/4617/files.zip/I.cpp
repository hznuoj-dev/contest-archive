#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct song {
	int a;
	char b[20];
};
struct song m[100000];

int inc(const void *c, const void *f) {
	return (*(song *)c).a > (*(song *)f).a ? 1 : -1;
}

int main () {
	int x, d, max, weizhi, i;
	weizhi = 0;
	scanf("%d", &x);
	for (i = 0; i < x; i++) {
		scanf("%d", &m[i].a);
		scanf("%s", m[i].b);
	}
	scanf("%d", &d);
	qsort(m, i, sizeof(song), inc);
	printf("%s", m[i - d - 1].b);
}