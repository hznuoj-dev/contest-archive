#include<stdio.h>
#include<stdlib.h>
struct chang
{
	long long int w;
	char s[100];
};
int comp(const void* p, const void* q);
int main()
{
	struct chang c[1000];
	int n,i;
	scanf("%d", &n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s", &c[i].w, c[i].s,strlen(c[i].s));
	}
	qsort(c, n, sizeof(struct chang), comp);
	int k;
	scanf("%d", &k);
	printf("%s", c[k].s);
}
int comp(const void* p, const void* q)
{
	return -(((struct chang*)p)->w - ((struct chang*)q)->w);
}