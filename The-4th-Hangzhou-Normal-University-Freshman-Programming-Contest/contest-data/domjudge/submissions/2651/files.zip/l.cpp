#include<bits/stdc++.h>
using namespace std;
int t,n,x;

int main(){
	cin >>t;
	while(t--){
		cin >>n >>x;
		int i;
		for(i=0;i<x;i++){
			if(i*n%x==0)break;
		}
		if(i!=x)cout << "yes\n";
		else cout << "no\n"; 
	}
	
return 0;
} 
/*1 1 1 1 1 1 1 /1 1 1 1 1 1
  0     0     0     0*/
