#include <iostream>
using namespace std;
int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		int a[100]={0};
		int n,i,k=0;
		char b;
		cin>>n;
		for(i=0;i<n;++i)
		{
			cin>>b;
			if ((int)b>=65&&(int)b<=90)
			{
				a[(int)b-65]=a[(int)b-65]+1;
			}
			if ((int)b>=97&&(int)b<=122)
			{
				a[(int)b-71]=a[(int)b-71]+1;
			}
		}
		for(i=0;i<52;++i)
		{
			k=k+a[i]/2*2;
		}
		for(i=0;i<52;++i)
		{
			if (a[i]%2==1)
			{
				k=k+1;
				break;
			}
		}
		cout<<k<<endl;
	}
}
