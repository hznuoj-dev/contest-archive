#include<bits/stdc++.h>

using namespace std;

int q[1000005],top;

int n,m;

int ans = INT_MAX;

bool com(int a,int b){
	return a<b;
}

int main()
{
	int x;
	int l=INT_MAX,r=-1;
	scanf("%d%d",&n,&m);
	int a[n+1][m+1]={};
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			scanf("%d",&x);
			a[i][j] = x;
		}
	}

	for(int i=1;i<=n;++i){
		sort(a[i]+1,a[i]+1+n,com);
	}
	
	int now,last;
	for(int i=1;i<=m;++i){
		now = 1;last = a[1][i];top = 0;
		q[++top] = a[1][i];
		while(now < n){
			int to = lower_bound(a[now+1]+1,a[now+1]+1+m,last)-a[now+1];
			if(to == m+1){
				to--;
			}
			if(abs(a[now+1][to]-last)>abs(a[now+1][to+1]-last)) to++;
			q[++top] = a[now+1][to];
			last = q[top];
			now++;
		}
		int sum  = 0;
		for(int i=1;i<top;++i){
			sum += abs(q[i+1]-q[i]);
		}
		ans = min(ans,sum);
		/*for(int i=1;i<=top;++i){
			cout<<q[i]<<endl;
		}*/
	}
	
	
	printf("%d",ans);
	
	return 0;
}
