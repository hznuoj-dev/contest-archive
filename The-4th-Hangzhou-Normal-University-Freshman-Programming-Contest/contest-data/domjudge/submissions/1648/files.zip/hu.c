#include<stdio.h>
int main()
{
	int i, n;
	scanf("%d", &n);
	for (i = 1; i <= n; i++)
	{
		printf("Welcome to HZNU\n");
	}
	return 0;
}