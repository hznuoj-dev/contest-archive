#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int a[6000];
int main()
{
    int t;
    int sum;
    int flag=0;
    int i,j;
    int n;
    scanf("%d",&t);
    while(t--){
    	scanf("%d",&n);
    	for(i=0;i<n;i++){
    		scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			sum=a[i];
			if(sum==7777){
					flag++;
					continue;
			}
			for(j=i+1;j<n;j++){
				sum+=a[j];
                if(sum==7777){
					flag++;
					break;
			    }
		    	
			}
		}
		printf("%d\n",flag);
	}
	return 0;
}
