#define _CRT_SECURE_NO_WARNINGS
#include<process.h>

#include<stdio.h>
#define size 10
int main()
{
	int n,m;
	int i=0,k;
	int sum=0,flag=0;
	int a[size]={0};
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]==0)
		{
			scanf("%d",&k);
			sum=sum+k;
			if(sum>=2500)
				flag=1;
			continue;
		}
		if(a[i]==1)
		{
			if(flag==1)
			{
				printf("haoye\n");
				break;
			}
			continue;
		}
		if(a[i]==2)
		{
			if(flag==0)
			{
				printf("QAQ\n");
				break;
			}
			i++;
			continue;
		}
	}
	if(flag==0)
			printf("QAQ\n");
	if(flag==1)
			printf("haoye\n");
	system("pause");
	return 0;
}



/*
//��һ�а���һ������ n(1 �� n �� 105)�������� n �׸衣

//������ n �У��� i �а���һ�������� wi(1 �� wi �� 109) 
//��һ���ַ��� si(1 �� |si| �� 15)�������� i �׸��ϲ���̶Ⱥ͸�����

#include<stdio.h>
#define size 100000
int main()
{
	int n,m;
	int a[size];
	char *b[size];
	int i,j,k,t;
	char *p;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&a[i],&b[i]);
	}
	for(i=0;i<n-1;i++)
	{
		k=i;
		for(j=i+1;j<n;j++)
		{
			if(a[j]<a[k])
				k=j;
		}
		if(k!=i)
		{
			t=a[i];
			a[i]=a[k];
			a[k]=t;
			p=b[i];
			b[i]=b[k];
			b[k]=p;
		}
	}
	scanf("%d",&m);
	printf("%s\n",a[m]);
	system("pause");
	return 0;
}
*/


/*
#include<stdio.h>
#define size 100000
struct king
{
	int count;
	char song[20];
}a[size];
int main()
{
	int n,m;
	int i,j,k;
	struct king t;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&a[i].count,a[i].song);
	}
	for(i=0;i<n-1;i++)
	{
		k=i;
		for(j=i+1;j<n;j++)
		{
			if(a[j].count>a[k].count)
				k=j;
		}
		if(k!=i)
		{
			t=a[i];
			a[i]=a[k];
			a[k]=t;
		}
	}
	scanf("%d",&m);
	printf("%s\n",a[m].song);
	system("pause");
	return 0;
}
*/


/*
#include<stdio.h>
int main()
{
	int T,m,n;
	int i,y;
	int flag;
	scanf("%d",&T);
	while(T--)
	{
		flag=0;
		scanf("%d %d",&m,&n);
		if(n==0)
		{
			printf("no\n");
			continue;
		}
		if(n==1)
		{
			printf("yes\n");
			continue;
		}
		for(y=0,i=0;y<100000;i++)
		{
			if((y+n*i)%m==0)
			{
				flag=1;
				break;
			}
		}
		if(flag==1)
			printf("yes\n");
		else
			printf("no\n");
	}
	system("pause");
	return 0;
}
*/





/*	K
#include<stdio.h>
int main()
{
	int i;
	int n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		printf("Welcome to HZNU\n");
	return 0;
}
*/
