#include <iostream>
using namespace std;
int n,x,y;
int main ()
{
	cin >> n; 
	for (int i = 1; i <= n; i++)
	{
		cin >> x >> y;
		if (y == 0) cout << "no" << '\n';
		else	cout << "yes" << '\n';
	}
}
