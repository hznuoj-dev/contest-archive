#include<stdio.h>
int main()
{
	int T;
	int n,x;
    scanf("%d%d",&n,&x);
    if(n%x==0)
   {
	printf("Yes\n");
   }
	else
	{
		printf("No\n");
	}
	return 0;
}

