#include<stdio.h>
#include<string.h>
int main() 
{
	int j,p=0,x,lenb,c[100]={0},sum=0,i,t;
	char b[10001],a[100];
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		sum=0;
		p=0;
		scanf("%d",&x);
		getchar();
		gets(b);
     lenb=strlen(b);
     for(i=0;i<100;++i)
     {
     	c[i]=0;
     	a[i]='\0';
	 }
     for(i=0;i<lenb;++i)
     {
     	for(j=0;j<p+1;++j)
     	{
     		if(b[i]!=a[j]&&b[i]!=' ')
     		{
     		   a[j]=b[i];
     		   c[j]=c[j]+1;
     		   p++;
				break;	
			}
			if(b[i]==a[j])
			{
				c[j] =c[j]+1;
				if(c[j]>=2)
				{
					c[j]=c[j]-2;
					sum=sum+2;
				}
				break;
			}
			
		}
	 }
	 printf("%d\n",sum+1);
	}
     
	  
}


