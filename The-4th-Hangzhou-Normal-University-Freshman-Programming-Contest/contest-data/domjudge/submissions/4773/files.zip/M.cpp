#include <cstdio>
#include <algorithm>
#include <set>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <climits>
#include <stack>
#include <map>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include<time.h>
#define tententen tql666
#define PI acos(-1) 
typedef long long int ll; 	 
using namespace std;
	int main(){
		int n, t,s,k,i,j,x,y,l;
	    cin >> t;
	    while(t--){
		    map<int, string>mp;
		    string bd;
		    k=1;
		    string str;
		    while(cin>>str){
		        l=str.length();
		        bd=str.substr(l-1);
				if(bd!="."&&bd!="!"&&bd!="?"){
			    	mp[k] = str;
			    	++k;
				}else{
				    mp[k]=str.substr(0,l-1);
					break;	
				}
			}
			/*if(k%2==0){
			    x=k-1;
			    y=k;
			}else{
				y=k-1;
			    x=k;
			}*/
			int x=0;
			int y=k+1;	
			for ( i = 1; i <= k; ++i) {
				if(i%2==1){
					if(i==k){
						x++;
						cout << mp[x];
					}else{
						x++;
						cout << mp[x] <<" ";}
				}else{
					if(i==k){
						y--;
						cout << mp[y];
					}else{
						y--;
						cout << mp[y] <<" ";}
				}
			}
			cout <<bd<< endl;
	    }
    return 0;
}