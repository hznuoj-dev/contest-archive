#include<bits/stdc++.h>
using namespace std;
const int N=2e5;
struct node{
	string s;
	int w;
}a[N];
bool cmp(node a,node b){
	return a.w>b.w;
}
void solve(){
	int n;cin>>n;
	for(int i=1;i<=n;i++)cin>>a[i].w>>a[i].s;
	sort(a+1,a+n+1,cmp);
	int k;cin>>k;
	cout<<a[k+1].s;
}
int main(){
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
}
