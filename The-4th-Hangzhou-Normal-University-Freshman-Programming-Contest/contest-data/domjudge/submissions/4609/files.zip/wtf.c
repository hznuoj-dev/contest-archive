﻿#include<stdio.h>
#include<math.h>
#include<string.h>
int main() {
	int i, t, k, n, x, j;
	char bq[100][100], m[100];
	long long sb[100];
	scanf("%d", &t);
	for (i = 0; i < t; i++) {
		scanf("%d%d", &n, &x);
		if (x != 0) {
			printf("yes\n");
		}
		else
			printf("no\n");
	}
}


