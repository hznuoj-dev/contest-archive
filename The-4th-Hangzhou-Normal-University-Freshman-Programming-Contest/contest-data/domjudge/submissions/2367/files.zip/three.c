#include<stdio.h>
int main() {
    int t, n, x;
    scanf("%d", &t);
    while (t--) {
        scanf("%d %d", &n,&x);
        if (x == 0) {
            printf("no\n");
        }
        else {
            printf("yes\n");
        }
    }
}
