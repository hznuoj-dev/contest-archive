#include<bits/stdc++.h>
using namespace std;
const int N=100010;

struct node {
	int i;
	char name[20];
};
node ge[N];
int n;
int k;
int cmp(node first,node second) {
	return first.i>second.i;
}

int main(){
	cin >> n;
	for(int i=1;i<=n;i++){
		cin >> ge[i].i >> ge[i].name;
	}
	cin >> k;
	sort(ge+1,ge+n+1,cmp);
	cout  << ge[k+1].name;

return 0;
}

