#include<stdio.h>
#include<string.h>
int main()
{
    int T, gshu, i, j, shn = 1, changdu, biaozhi, jihao = 0;
    char nb;
    scanf("%d", &T);
    while (T--) {
        struct cnm {
            int cishu = 0;
            char name;
        }; struct cnm djl[1000];
        changdu = 0;
        biaozhi = 0;
        scanf("%d", &gshu);
        scanf(" ");
        scanf("%c", &djl[1].name);
        djl[1].cishu = 1;
        shn = 1;
        scanf(" ");
        for (i = 0; i < gshu; i++) {
            if (i == gshu - 1) {
                scanf(" ");
            }
            scanf("%c", &nb);
            jihao = 0;
            for (j = 1; j <= shn; j++) {
                if (nb == djl[j].name) {
                    djl[j].cishu++;
                    break;
                }
                if (j == shn && nb != djl[j].name) {
                    djl[shn + 1].name = nb;
                    djl[shn + 1].cishu++;
                    jihao = 1;
                }
            }
            if (jihao == 1) {
                shn++;
                jihao = 0;
            }
        }
        for (j = 0; j < shn; j++) {
            if (djl[j].cishu > 1) {
                changdu += djl[j].cishu / 2;
            }
            if (djl[j].cishu % 2 != 0) {
                biaozhi = 1;
            }
        }
        changdu *= 2;
        if (biaozhi == 1) {
            changdu++;
        }
        printf("%d\n", changdu);
    }
    return 0;
}