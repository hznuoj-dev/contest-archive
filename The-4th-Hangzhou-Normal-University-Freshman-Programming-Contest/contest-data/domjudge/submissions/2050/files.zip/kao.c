#include<stdio.h>
int main(void)
{
	int t, i;
	long long int n, x; 
	scanf("%d", &t);
	while (t--)
	{
		scanf("%lld%lld", &n, &x);
			
			if (x== 0)
			{
				printf("no\n");
			}
			else 
			{
				printf("yes\n");
			}
	}
	return 0;
}