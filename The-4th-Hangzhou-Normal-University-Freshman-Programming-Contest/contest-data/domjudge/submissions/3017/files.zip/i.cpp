#include<stdio.h>
#include<string.h>
struct son
{
	int xi;
	char name[16];

};
int main()
{
	struct son ge[100001];
	struct son t;
	int n,k;
	int i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &ge[i].xi);
		gets(ge[i].name);
		
	}
	scanf("%d", &k);
	for (j = 0; j < n - 1; j++)
	{
		for (i = 0; i < n - j - 1; i++)
		{
			if (ge[i].xi < ge[i + 1].xi)
			{
				t = ge[i];
				ge[i] = ge[i + 1];
				ge[i + 1] = t;
			}
		}
	}
	printf("%s\n", ge[k].name);
	return 0;
}

