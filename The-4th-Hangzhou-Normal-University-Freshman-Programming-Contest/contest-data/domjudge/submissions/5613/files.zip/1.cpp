#include<stdio.h>
#include<string.h>
int main(){
	int n;
	scanf("%d",&n);
int a[100010];
	for(n;n>0;n--){
		int x;
			int q = 0;
		scanf("%d",&x);
		for(int i =0;i<x;i++){
		
		scanf("%d",&a[i]);
	    q +=a[i];
	}
	if(q<7777)
	printf("0");
	else{
	
		
		
		int r = 0;
		for(int i =0;i<x;i++){
			int sum = 0;
			{    int temp = i;
				while(sum<7777){
					sum +=a[temp];
					temp++;
					
					if(sum==7777){
					r++;
					}
				}
			}
		}
		printf("%d",r);

	}
			if(n!=1)
		printf("\n");
}
}
