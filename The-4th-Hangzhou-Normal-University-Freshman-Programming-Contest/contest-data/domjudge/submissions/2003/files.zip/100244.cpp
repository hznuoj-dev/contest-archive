#include <iostream>
#include <cstring>
using namespace std;
int main()
{
	int n;
	cin>>n;
	int b[10001];
	char c[10001][16];
	int i;
	for(i=0;i<n;++i)
	{
		cin>>b[i]>>c[i];
		
	}
	int g;
	cin>>g;
	int index,temp,k,j;
	char temp1[16];
	for(i=0;i<n-1;++i)
	{
		index=i;
		for(k=i;k<n;++k)
		{
			if (b[index]<b[k])
			{
				index=k;
			}
		}
		temp=b[index];
		b[index]=b[i];
		b[i]=temp;
		strcpy(temp1,c[index]);
		strcpy(c[index],c[i]);
		strcpy(c[i],temp1);
	}
	cout<<c[g]<<endl;
}
