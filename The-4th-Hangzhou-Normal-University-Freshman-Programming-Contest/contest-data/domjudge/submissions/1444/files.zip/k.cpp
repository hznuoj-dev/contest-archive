#include<bits/stdc++.h>
using namespace std;
int a[100010];
int main()
{
	int N;
	cin>>N;
	while(N--)
	{
		cout<<"Welcome to HZNU"<<'\n';
		
	}
}
