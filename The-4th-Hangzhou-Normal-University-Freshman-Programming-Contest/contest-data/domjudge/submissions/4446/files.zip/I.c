#include<stdio.h>
#include<string.h>
int main()
{
	
	
	int n,i,k,wi[10000],f;
	char si[10000][16],d[16];
	int j,o;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&wi[i],si[i]);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++)
	{
		o=i;
		for(j=i+1;j<n;j++)
		{
			if(wi[o]<wi[j])
			{
				o=j;
			}
		}
		if(o!=i)
		{
			f=wi[o];
			wi[o]=wi[i];
			wi[i]=f;
			strcpy(d,si[o]);
			strcpy(si[o],si[i]);
			strcpy(si[i],d);
		}
	}
	printf("%s",si[k]);
	return 0;
}



/*5
12 iuguiuhi
13 gfnuu
11 dsfjglil
15 ijdoof
18 dnguiu
4
*/
