#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	
	long T,n,strs[60]={0};
	
	scanf("%d",&T);
	while(T--){
		char str[60];
		char *p;
		p=str;
		scanf("%d",&n);
		int t=1;
		char str1;
		scanf("%c",&str1);
		*p=str1;
		for(int i=1;i<n;i++){
			scanf("%c",&str1);
			
			for(int j=0;j<t;j++){
				if(str1-str[j]==0){
					strs[j]++;	
					break;
				}
				else if(j==t-1){
					*(p+t)=str1;
					strs[t]++;
					t++;
				}
			}
		}
		long max=0;
		int a[60]={0},x;
		for(int i=1;i<=t;i++){
			for(int j=0;j<t;j++){
				if(max<strs[j]&&a[j]==0){
					max=strs[j];
					x=j;
				}
			}
			a[x]=i;
			max=0;
		}
		int sum=0;
		int y=100,min=60;
		for(int i=0;i<t;i++){
			if(min>a[i]&&strs[i]%2==1){
				min=a[i];
				y=i;
			}
		}
		
		if(y==100)
			printf("1\n");
		else{
			sum+=strs[y];
			for(int i=0;i<t;i++){
				if(strs[i]%2==0)
					sum+=strs[i];
			}
			printf("%d\n",sum);
		}
		free(p);
	}
}
