#include<stdio.h>
#include <stdlib.h>
#include <stdio.h>
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,i,j,s=0;
		scanf("%d\n",&n);
		char p[n];
		getchar();
		for(i=1;i<=n;i++){
			scanf("%c",&p[i]);
		}
		if(n%2==0){
			for(i=1;i<=n/2;i++){
				for(j=n/2+1;j<=n;j++){
					if(p[i]==p[j]){
						s++;
					}
				}
			}
			printf("%d\n",s+1);
		}
		else{
			for(i=1;i<=n/2;i++){
				for(j=n/2;j<=n;j++){
					if(p[i]==p[j]){
						s++;
					}
				}
			}
			printf("%d\n",s+1);
		}
	} 
return 0;
}

