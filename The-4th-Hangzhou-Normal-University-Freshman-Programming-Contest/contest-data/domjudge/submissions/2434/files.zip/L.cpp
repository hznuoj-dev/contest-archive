#include<stdio.h>
int main()
{
	int t;
	scanf("%d", &t);
	while (t--)
	{
		int a[10000], i,n,x;
		scanf("%d %d", &n,&x);
		for (i = 0; i < n; i++)
		{
			i = i + x;
		}
		if (a[i] == a[i + x]&&x!=0&&n%x==0)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}