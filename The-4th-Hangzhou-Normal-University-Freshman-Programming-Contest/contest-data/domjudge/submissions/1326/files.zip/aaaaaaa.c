#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int a[100005]={0};
int main(){
	int t,sum=0,len,i,n;
	char ch;
	scanf("%d",&t);
	while(t--)
	{
		len=0;
		sum=0;
		for(i=64;i<=97+40;i++)
		a[i]=0;
		scanf("%d",&n);
		getchar();
		while(n--)
		{
			scanf("%c",&ch);
			len++;
			getchar();
			a[ch]++;
		}
		for(i=65;i<=97+40;i++)
		{
			if(a[i]>=2)
			{
				sum+=a[i]/2;
			}
		}
		if(sum<len)
		printf("%d\n",sum*2+1);
		else
		printf("%d\n",sum*2);
	}
	return 0;
}
