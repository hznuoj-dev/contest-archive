#include<stdio.h>
int main() {
	int t;
	long long n,x;
	scanf("%d",&t);
	while(t>0){
		scanf("%lld%lld",&n,&x);
		if(x==0)
		printf("no\n");
		if(x!=0)
		printf("yes\n");
		t--;
	} 
	return 0;
}
