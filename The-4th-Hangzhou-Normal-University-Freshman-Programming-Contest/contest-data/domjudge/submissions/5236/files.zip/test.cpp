#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define ll long long
#define N 100050 
#define res register int 
using namespace std;
int n,m,p,q,t,total,maxx;
int a[N];
char c;
bool allow;
int main()
{
//	freopen("1.in","r",stdin);
	 scanf("%d",&t);
	 while(t>0)
	 {
	 	allow=false;
	 	for(res i=1;i<=52;i++) 
	 	a[i]=0;
	 	scanf("%d",&n);
	 	scanf("%c",&c);
	 	for(res i=1;i<=n;i++)
	 	{
	 		scanf("%c",&c);
	 		if((c>='A') and (c<='Z')) a[int(c)-int('A')+1]++;
	 		if((c>='a') and (c<='z')) a[int(c)-int('a')+1+26]++;
	 		scanf("%c",&c);
		}
		total=0;
		total=0;
		for(res i=1;i<=52;i++)   
		{
			if(a[i]%2==0) total+=a[i];
			if((a[i]%2!=0)) 
			{
				total+=a[i]/2*2;
				if(allow==false)
				{
					total+=1;
					allow=true;
				}
			}
		}
		printf("%d\n",total);
		t--;
	 }
}
