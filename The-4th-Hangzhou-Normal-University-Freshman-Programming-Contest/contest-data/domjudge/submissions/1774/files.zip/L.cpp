#include<stdio.h>
int main()
{
	int t,n,x,p=0;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&x);
		if(x==0)
			p=0;
		else 
		{
			for(int i=0;i<n;i++)
			{
				for(int j=0;j<n/x;j++)
				{
					if((i+x*j)==(n-1))
					{
						p=1;
						break;
					}
					else
						p=0;
				}
			}
		}
		if(p)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0; 
}
