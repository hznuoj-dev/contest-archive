#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,x;
		scanf("%d %d",&n,&x);
		if(x==0)
			printf("no\n");
		else if((x*n)%x==0)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}
