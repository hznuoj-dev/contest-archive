#include<stdio.h>
int main()
{
	int t,n,i,o,j,p,q;
	
	char a[100000],b[502];
	scanf("%d",&t);
	while(t--)
	{
		q=0;
		
		p=0;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			
			scanf("%s",&a[i]);
		
		}
		for(i=0;i<n;i++)
		printf("%c\n",a[i]);
		for(i=0;i<n-1;i++)
		{
			o=0;
			if(a[i]=='1')
				continue;
			for(j=i+1;j<n;j++)
			{
				
				if(a[i]==a[j]&&((a[i]>64&&a[i]<91)||(a[i]>96&&a[i]<123)))
				{
				o++;
				a[j]='1';
				}
				
			}
			if((o+1)%2==0)
			    p=p+o+1;
			else
			{
				p=p+o;
				q=1;
			}
			
		}
		
	if(q==0)
		printf("%d\n",p);
	else
		printf("%d\n",p+1);
	}
	return 0;
}

