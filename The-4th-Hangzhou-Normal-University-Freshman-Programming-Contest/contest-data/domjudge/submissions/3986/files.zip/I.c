#include<stdio.h>
int n,i,k,pass,x,pm[100000],t;
	long long a[100000];
	char s[100000][16];
int main(void){
	scanf("%d",&n);
	for(x=0;x<n;x++){
			pm[x]=x;
			a[x]=0;
	}
	for(i=0;i<n;i++){
		scanf("%lld",&a[i]);
		scanf(" %s",s[i]);
	}
	scanf("%d",&k);
	for(pass=1;pass<=k+2&&pass<n;pass++){
			for(x=n-1;x>=pass;x--){
				if(a[pm[x]]>a[pm[x-1]]){
					t=pm[x];
					pm[x]=pm[x-1];
					pm[x-1]=t;
				}
			}
		}
		printf("%s\n",s[pm[k]]);
}