#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdbool.h>
	int n,m,x,y,i;
	int a[2];
	bool b[5];
int main(void)
{
	scanf("%d%d",&n,&m);
	a[0]=2500;
	a[1]=2101;
	for(i=0;i<=n;i++)
	{
		scanf("%d",&x);
		if(x==1)
		b[1]=true;
		else if(x==2)
		b[2]=true;
		else
		{
		scanf("%d",&y);
		if (y >= a[m]) 
		b[0]=true;
        }
    }
        if (b[1]&&b[0]) 
        printf("haoye");
        else if (b[2]&&n>1)
		printf("haoye");
        else printf("QAQ");
        return 0;
	}
