#include<stdio.h>
#include<string.h>
int main(void){
	int t,n,i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int a[n],count=0,sum=0;
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		int s=0;
		for(i=0;i<n;i++){
			sum+=a[i];
			if(sum==7777){
				++count;
				sum=0;
				s=s+1;
				i=s-1;
			}
		}
		printf("%d\n",count);
		memset(a,0,sizeof(a));
	}
	return 0;
}

