#include<bits/stdc++.h>
using namespace std;
int n,m;
int x,a,k;
int zt[3];// 1 ����ɱ 2 ���Գ��� 0 ������ɱ�� 
int main(){
	cin >> n >> m;
	if(m==0)k=2101;
	else k=2500;
	
	for(int i=1;i<=n;i++){
		cin >> x;
		a=0;
		if(x==2&&n>1)zt[0]=1;
		if(x==0)cin >>a;
		if(a>=k)zt[1]=1;
		if(x==1)zt[2]=1;
	} 
	if(zt[0]||(zt[1]&&zt[2]))cout << "haoye";
	else cout << "QAQ"; 


return 0;
}

