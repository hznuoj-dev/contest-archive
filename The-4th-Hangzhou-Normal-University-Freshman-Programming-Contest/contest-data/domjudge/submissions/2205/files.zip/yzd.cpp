#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
struct Point {
    long long wi;
    string si;
};
int cmp (const void *p,const void *q){
    return (*(Point *)p).wi-(*(Point *)q).wi;
}
Point aa[100001];
int main () {
    cnm;
    int n;
    cin >> n;
    for (int i = 0 ; i<n ; i++){
        cin >> aa[i].wi >> aa[i].si;
    }
    qsort(aa,n,sizeof(Point),cmp);
    /*for (int i = 0 ; i<n ; i++){
        cout << aa[i].si<<endl;
    }*/
    int k;
    cin >> k;
    cout << aa[n-k-1].si;
    
    return 0;
}