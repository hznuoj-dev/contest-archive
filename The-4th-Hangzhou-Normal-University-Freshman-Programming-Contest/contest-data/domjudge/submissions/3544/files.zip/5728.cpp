#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int cap(const void *p,const void *q)
{
	return *(int *)q-*(int *)p;
}
struct ge{
	int w;
	char s[20];
}stiff[10010];
int main()
{
    int n,i,k;
    scanf("%d",&n);
    for(i=0;i<n;++i)
    {
    	scanf("%d %s",&stiff[i].w,stiff[i].s);
	}
	qsort(stiff,n,sizeof(struct ge),cap);
	scanf("%d",&k);
	printf("%s\n",stiff[k].s);
    return 0;
} 
