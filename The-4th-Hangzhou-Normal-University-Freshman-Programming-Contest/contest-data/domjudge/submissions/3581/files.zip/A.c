#include<stdio.h>
int main(){
	int T,n,num;
	char a[100001]; 
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		num=n+1;
		for(int i=0;i<n;i++){
			scanf("%s",&a[i]);
		}
		for(int i=0;i<n;i++){
			if(a[i]<=89){
				num--;
			}
		}
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				if(a[i]==a[j]){
					num--;
				}
			}
		}
		printf("%d\n",num);
	}         
}
