#include<stdio.h>
int main(void)
{
	int n,m,b=1,c=1;//c=1��ʾ���޴�� ��c=0��ʾ���� ,b=0��ʾ���� 
	scanf("%d %d",&n,&m);
	int s[n],k[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d",&s[i]);
		if(s[i]==0)
		{
			scanf("%d",&k[i]);
		}
	}
 		int t=n;
 		for(int i=0;i<n;i++)
		{
			if(s[i] == 2 && n>1)
			{
				b=0;
				goto out;
			}
		} 
		
		for(int i=0;i<n;i++)
		{
			if(m==0)
			{
				if(s[i] == 0 && k[i] >= 2500)
				{
					c=0;
					t--;
				}
			}else
			{
				if(s[i] == 0 && k[i]>=2100)
				{
					c=0;
					t--;
				}
			}
			
			
			
			if(c == 0)
			{
				for(int j=0;j<n;j++)
				{
					if(s[j] == 1)
					{
							b=0;
					 	goto out;
					} 
						 
				}
			}
			
		}
	out:
		if(b==0)
			printf("haoye\n");
		else
			printf("QAQ\n");
			
	return 0;
}
	


