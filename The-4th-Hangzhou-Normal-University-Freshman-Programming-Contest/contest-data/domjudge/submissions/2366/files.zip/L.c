#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
int main()
{
	int T;
	long long m, n;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%lld%lld", &n, &m);
		if (m!=0)
		{
			printf("yes\n");
		}
		else
		{
			printf("no\n");
		}
	}
	return 0;
}