#include<stdio.h>
#include<string.h>
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int n,x;
		scanf("%d",&n);
		getchar();
		char a[100666];
		int i;
		for(i=1;i<=n;i++){
			scanf("%c",&a[i]);
			getchar();
		}
		int j;
		int count[100666];
		int k=1;
		for(i=1;i<=n-1;i++){
			count[k]=0;
			int flag=0; 
			for(j=i+1;j<=n;j++){
				if(a[i]==a[j] && a[i]!='.'){
					count[k]+=2;
					a[j]='.';
					flag=1;
				}
			}
			if(flag==1){
				k++;
			}
		}
		
		//k=k-1;
		int sum=0;
		for(i=1;i<=k;i++){
			sum+=count[i]/2*2;
		}
		printf("%d\n",sum+1);
	}
	return 0;
} 
