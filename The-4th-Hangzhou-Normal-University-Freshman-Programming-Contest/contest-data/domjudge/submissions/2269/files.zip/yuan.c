#include<stdio.h>
int main()
{
	int t,n,x,i,m=1,k=1;
	while (scanf("%d", &t) != EOF)
	{
		
		for (i = 0; i < t; i++)
		{
			scanf("%d%d", &n,&x);
			if (n != 0 && x != 0)
				printf("yes\n");
			else if (n != 0 && x == 0)
				printf("no\n");
		}
	}
	return 0;
}




