#include<stdio.h>
int main()
{
	int a,i;
	scanf("%d",&a);
	for(i=0;i<a;i++)
	{
		printf("Welcome to HZNU\n");
	}
	return 0;
 } 
