#include<stdio.h>
int main(void)
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		printf("Welcome to HZNU\n");
	}
	return 0;
}
