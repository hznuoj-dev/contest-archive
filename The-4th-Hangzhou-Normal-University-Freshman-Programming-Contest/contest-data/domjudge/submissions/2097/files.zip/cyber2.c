#include<stdio.h>
char a[100005];
int main(){
int n,i,t,j,ret,sum,max;
scanf("%d",&t);
while(t--)
{sum=0;
ret=1;
max=0;
scanf("%d",&n);
getchar();
	for(i=0;i<n;i++)
	{
	if(i==0)
	scanf("%c",&a[i]);
	else
	scanf(" %c",&a[i]);
	getchar();
	}
	for(i=0;i<n;i++)
	{ret=1;
	if(a[i]=='9')
	continue; 
		for(j=0;j<n;j++)
		{
			if(a[i]==a[j]&&a[i]!='9'&&a[j]!='9'&&j!=i)
			{
				ret++;
				a[j]='9';
				}
		}
			a[i]='9';
			if(ret%2==0)
			sum+=ret;
			else{
				if(max<ret)
			max=ret;}
	}
	sum+=max;
	printf("%d\n",sum);
 } 
return 0;
} 
