#include<stdio.h>
#include<stdlib.h>
int main() {
	int n,m,a,atk,flag=0,i,t=0;
	int x[100];
	scanf("%d%d",&n,&m);
	if(m==0) {
		a=2500;
	} else a=2100;
	if(n==1) {
		flag=0;
	} for(i=0;i<n;i++) {
			scanf("%d",&x[i]);
			if(x[i]==0) {
				scanf("%d",&atk);
				if(m==0&&atk>=a) {
					t=1;
				}
				else if(m==1&&atk>a){
					t=1;
				}
			}
			if(n>=2&&x[i]==2) {
				flag=1;
			}
		}
	for(i=0; i<n; i++) {
		if(flag==1) {
			break;
		}
		if(x[i]==1&&t==1) {
			flag=1;
			break;
		}
	}
	if(flag==1) {
		printf("haoye");
	} else printf("QAQ");
}


