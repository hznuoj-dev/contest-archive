#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		printf("Welcome to HZN\n");
	}
	return 0;
}
