#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q)
{
	return(*(char*)p-*(char*)q);
}
char a[200002]={0};
char b[100002]={0};
int main()
{
	int t,n,i,j,c,s;
	char e;
	scanf("%d",&t);
	while(t--)
	{
		c=0;
		s=0;
		scanf("%d",&n);
		getchar();
		scanf("%[^\n]",a);
		for(j=0,i=0;i<strlen(a);i+=2,j++)
		{
			b[j]=a[i];
		}
		//qsort(b,n,sizeof(char),comp);
		for(j=0;j<n-1;j++)
		{
			for(i=j;i<n-1;i++)
			{
				if(b[j]==b[i]&&b[j]!='!')
				{
					c++;
					b[i]='!';
				}

			}
			s+=(c/2)*2;
			c=0;
		}
		if(s!=n)
		printf("%d\n",s+1);
		else
		printf("%d\n",s);
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
	}
	return 0;
}
