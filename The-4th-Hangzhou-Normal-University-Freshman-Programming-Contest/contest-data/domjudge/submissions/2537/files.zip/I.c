#include<stdio.h>
#include<stdlib.h>
typedef struct{
	int cishu;
	char name[20]
}sing;
int cmp(const void*a,const void*b){
	sing *p=(sing*)a,*q=(sing*)b;
	if(p->cishu>q->cishu)
	return 1;
	else if(p->cishu<q->cishu)
	return -1;
	else return 0;
}
int main(void){
	sing s1[10000];
	int n,i,k;
	char ch=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&s1[i].cishu,s1[i].name);
	}
	scanf("%d",&k);
	qsort(s1,n,sizeof(sing),cmp);
			printf("%s",s1[0].name);
	return 0;
} 

