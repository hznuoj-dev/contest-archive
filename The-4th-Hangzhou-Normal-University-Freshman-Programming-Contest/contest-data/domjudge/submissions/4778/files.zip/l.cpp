#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
int x[20];
int y[20];
int main(){
	int n,m;
	cin>>n>>m;
	int flag=1;
	for(int i=0;i<n;i++){
		cin>>x[i];
		if(x[i]==0) cin>>y[i];
	}
	for(int i=0;i<n;i++){
		if(x[i]==2&&n>=2) flag=0;
	}
	for(int i=0;i<n;i++){
		if(x[i]==0&&m==0&&y[i]>=2500){
			for(int i=0;i<n;i++){
				if(x[i]==1){
					flag=0;
					break;
				}
			}
		}
		if(x[i]==0&&m==1&&y[i]>2100){
			for(int i=0;i<n;i++){
				if(x[i]==1){
					flag=0;
					break;
				}
			}
		}
	} 
	if(flag==0) cout<<"haoye"<<endl;
	else cout<<"QAQ"<<endl;
	return 0;
}
 
