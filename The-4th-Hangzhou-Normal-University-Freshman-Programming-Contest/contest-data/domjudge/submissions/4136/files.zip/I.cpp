#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
int main (){
	int n,i,k,b[100000],t,s,j;
	char a[100000][16],p[16];
	scanf("%d",&n);
	for(i=0;i<n;++i){
		scanf("%d %s",&b[i],a[i]);
	}
	for(i=0;i<n-1;++i){
		s=i;
		for(j=i+1;j<n;++j){
			if(b[s]<b[j]){
				s=j;
			}
		}
		if(s!=i){
			t=b[s];
			b[s]=b[i];
			b[i]=t;
			strcpy(p,a[s]);
			strcpy(a[s],a[i]);
			strcpy(a[i],p);
		}
	}
	scanf("%d",&k);
	printf("%s",a[k]);
} 
