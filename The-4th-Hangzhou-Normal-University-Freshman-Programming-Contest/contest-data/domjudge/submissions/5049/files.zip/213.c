#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q)
{
	return(*(int*)p-*(int*)q);
}
char a[200009]={0};
char b[100005]={0};
int main()
{
	int t,n,i,j,c,s;
	char e;
	scanf("%d",&t);
	while(t--)
	{
		c=1;
		s=0;
		scanf("%d",&n);
		getchar();
		scanf("%[^\n]",a);
		for(j=0,i=0;i<strlen(a);i+=2,j++)
		{
			b[j]=a[i];
		}
		//qsort(b,n,sizeof(char),comp);
		for(j=0;j<n-1;j++)
			for(i=0;i<n-j-1;i++)
				if(b[i]>b[i+1])
				{e=b[i];b[i]=b[i+1];b[i+1]=e;}
		for(i=0;i<n;i++)
		{
			if(b[i]==b[i+1])
				c++;
			else
			{
				s+=(c/2)*2;
				c=1;
			}
		}
		if(s!=n)
		printf("%d\n",s+1);
		else
			printf("%d\n",s);
	}
	return 0;
}
