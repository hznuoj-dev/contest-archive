#include<stdio.h>
char ans[10050];
int main(){
	int T,n,i,j;
	char temp;
	int count[52];
	int ans1,flag;
	scanf("%d",&T);
	while(T--){
		for(i=0;i<53;i++){
			count[i]=0;
		
		}
		
		scanf("%d",&n);
		getchar();
		while(n--){
			scanf("%c",&temp);
			getchar();
		
			if(temp<='Z'){count[temp-'A']++;}
			else {count[26+temp-'a']++;}
		}
		ans1=0;
		flag=0;
			for(i=0;i<52;i++){
				if(count[i]%2==0)ans1=ans1+count[i];else flag=1;		
			}
			ans1=ans1+flag;
		printf("%d\n",ans1);
	}
}
