#include<bits/stdc++.h>
using namespace std;
const int N=2e5;
string s[N];
int cnt;
void solve(){
	cnt=0;
	string a;
	while(cin>>a){
		s[++cnt]=a;
	}
	char ch=s[cnt][s[cnt].size()-1];
	s[cnt][s[cnt].size()-1]-=ch;
	int l=1,r=cnt;
	vector<string>ans;
	while(l<=r){
		ans.push_back(s[l]);
		ans.push_back(s[r]);
		l++,r--;
	}
	for(int i=0;i<cnt-1;i++)
		cout<<ans[i]<<' ';
	cout<<ans[cnt-1]<<ch<<'\n';
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
