#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define N 20
#define M 9999

struct song{
	int like;
	char name[N];
};
int comp(const void *p,const void *q){
	return ((struct song *)p)->like-((struct song *)q)->like;
}
int main(){
	struct song s[M];
	struct song most;
	int n;
	scanf("%d",&n);
	int i;
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].like,s[i].name);
	}
	int k;
	scanf("%d",&k);
	if(k==0){
		for(i=0;i<n;i++){
		printf("%s",s[i].name);
		}
	}
	else{
		qsort(s,n,sizeof(struct song),comp);
		for(i=0;i<n-k;i++){
			printf("%s\n",s[i].name);
		}
	}
	return 0;
}
