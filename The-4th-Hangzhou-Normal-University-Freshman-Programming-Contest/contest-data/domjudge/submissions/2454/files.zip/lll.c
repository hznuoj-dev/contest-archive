#include<stdio.h>
int main(void){
	int t;
	scanf("%d",&t);
	while(t--)
	{
	int n,x,s,flag=0;
	scanf("%d %d",&n,&x);
	int i;
	i=x;
	while(i--){
	if(i*x/n==0){
		printf("yes\n");
		flag=1;
		break;
	}	
	}
	if(flag==0){
		printf("no");
	}
	}
		
return 0;	
}
