#include <stdio.h>
int main(){
	printf("Welcome to HZNU\n");
	return 0; 
} 
