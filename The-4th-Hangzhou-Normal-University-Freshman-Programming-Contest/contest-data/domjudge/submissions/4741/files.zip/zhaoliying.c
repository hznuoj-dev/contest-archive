#include<stdio.h>
struct Song
{
	int num;
	char name[20];
}son[100001],temp;
int main()
{
	int n, i, j, k;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d %s", &son[i].num, son[i].name);
	}
	scanf("%d", &k);
	for (j = 0; j < n; j++)
	{
		for (i = 0; i < n - j; i++)
		{
			
			if (son[i+1].num >son[i].num)
			{
				
				temp = son[i + 1];
				son[i + 1] = son[i];
				son[i] = temp;   	
			}
		}
	}
	printf("%s\n", son[k].name);
	return 0;
}
