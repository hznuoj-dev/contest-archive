#include <stdio.h>
int main()
{
	int m,n;
	int i,j;
	scanf("%d %d",&m,&n);
	int a[m*n];
	for(i=0;i<m*n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<m*n-1;++i)
	{
		for(j=0;j<m*n-1-i;++j)
		{
			if(a[j] < a[j+1])
			{
				int t = a[j];
				a[j] = a[j+1];
				a[j+1] = t;
			}
		}
	}
	/*for(i=0;i<m*n;i++)
	{
		printf("%d ",a[i]);
	}*/
	int min = a[0] - a[1];
	for(i=0;i<m*n-1;++i)
	{
		if(a[i]-a[i+1] < min)
			min = a[i] - a[i+1];
	}
	printf("%d",min);
	
		
	
	
	
	return 0;
}
