#include <stdio.h>
#include <string.h>
int w[1000]={0};
void qk();
int main()
{
	int i,t;
	scanf("%d",&t);
	getchar();
	int n,m,countd=0,countf=0;;
	char ch;
	while(t--)
	{
		countd=0,countf=0;
		scanf("%d",&n);
		getchar();
		for(i=0;i<n;i++)
		{
			scanf("%c",&ch);
			getchar();
			m=ch;
			//printf("%d ",m);
			w[m]++;
		}
		//printf("\n");
		for(i=0;i<200;i++)
		{
			if(w[i]!=0)
			{
				if(w[i]%2!=0&&w[i]>=3)
					++countf;
				else if(w[i]==1)
					++countf;
				else if(w[i]%2==0&&w[i]!=0)
					countd+=w[i];		
			}
		}
		//printf("%d %d\n",countf,countd);
		if(countf>1&&countd!=0)
			countd+=2;
		else if(countf>1&&countd==0)
			countd+=1;	
		else if(countf==1)
			countd+=1;
		else if(countf==0)
			countd+=0;	
		printf("%d\n",countd);
		qk();
		//memset(w,0,sizeof(w));	
	}
	return 0;
} 
void qk()
{
	int i;
	for(i=0;i<1000;i++)
		w[i]=0;
}
