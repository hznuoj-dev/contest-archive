#include<stdio.h>
int main() {
	int n, m,i,j;
	int temp,t;
	int x[10], k[10] = {0,0,0,0,0,0,0,0,0,0};
	int a=0, b=0,c=0;
	scanf("%d%d", &n, &m);
	for (i = 0; i < n;i++) {
		scanf("%d", &x[i]);
		if (x[i] == 0) {
			scanf("%d", &t);
			k[i] = t;
		}
	}
	for (i= 0; i < n; i++) {
		for (j = n - 1; j > i; j--) {
			if (x[j] <= x[j - 1]) {
				temp = x[j];
				x[j] = x[j-1];
				x[j - 1] = temp;
				temp = k[j];
				k[j] = k[j - 1];
				k[j - 1] = temp;
			}
		}
	}
	for (i = 0; i < n; i++) {
		if (x[i] == 0) a++;
		if (x[i] == 1) b++;
		if (x[i] == 2) c++;
	}
	for (i = 0; i < a; i++) {
		for (j = a-1; j >i; j--) {
			if (k[j] > k[j - 1]) {
				temp = k[j];
				k[j] = k[j - 1];
				k[j - 1] = temp;
			}
		}
	}
	for (i = 0; i < n; i++) {
		if(n==1||n==0||a==0){
			printf("QAQ");
			break;
		}
		else if (c != 0 && n >= 2) {
			if (m == 0) {
				if (k[i] >= 2500) {
					printf("haoye");
					break;
				}
				else {
					printf("QAQ");
					break;
				}
			}
			if (m == 1) {
				if (k[i] > 2100) {
					printf("haoye");
					break;
				}
				else {
					printf("QAQ");
					break;
				}
			}
		}
		else if (m == 0) {
			if (b == 0) {
				printf("QAQ");
				break;
			}
			else if (x[i] == 0 && k[i] >= 2500 && b != 0) {
				printf("haoye");
				break;
			}
			else if(x[i] == 0 && k[i] <2500) {
				printf("QAQ");
				break;
			}
		}
		else if (m == 1) {
				if (b == 0) {
					printf("QAQ");
					break;
				}
				else if (x[i] == 0 && k[i] > 2100 && b != 0) {
					printf("haoye");
					break;
				}
				else if (x[i] == 0 && k[i] <= 2100 ) {
					printf("QAQ");
					break;
				}
		}
	}
	return 0;
}





