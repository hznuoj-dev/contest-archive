#include<stdio.h> 
int main(void){
	long long int n,i,sum,t,mark[130],temp;
	scanf("%lld",&t);
	while(t--){
		scanf("%lld",&n);
		char str[n];
		sum=0;
		for(i=0;i<130;i++){
			mark[i]=0;
		}
		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&str[i]);
			temp=str[i];
			mark[temp]++;
		}
		for(i=0;i<130;i++){
			sum+=mark[i]/2;
		}
		printf("%lld\n",sum*2+1);
	} 
	return 0;
}
