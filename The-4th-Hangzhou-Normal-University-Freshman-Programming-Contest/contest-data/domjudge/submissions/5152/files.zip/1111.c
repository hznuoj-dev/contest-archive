#include<stdio.h>
struct song
{
	int favor;
	char name[50];
}stu[100001],temp;
void paixu(struct song stu[],int n)
{
	int i,j,k;
	for(i=0;i<n-1;i++)
	{
		k=i;
		for(j=i+1;j<n;j++)
			if(stu[j].favor>stu[k].favor) k=j;
		if(k!=i)
		{
			temp=stu[i];
			stu[i]=stu[k];
			stu[k]=temp;
		}
	}
}
int main()
{
	struct song *p1,*p2;
	int n,i,k;
	scanf("%d",&n);
	p1=stu;
	for(;p1<stu+n;p1++)
	{
		scanf("%d %s",&(*p1).favor,(*p1).name);
	}
	scanf("%d",&k);
	p2=&stu[k];
	paixu(stu,n);
	printf("%s",(*p2).name);
	return 0;
}

