#include<stdio.h>
#include<stdlib.h>
#define ARRAY_SIZE 100000
struct loy
{
	char name [20];
	long long int num;
} ;
long  long int cmp(const void *p,const void *q)
{
	struct loy*pp=(struct loy*)(p);
	struct loy*pq=(struct loy*)(q);
	long long int a=pp->num;
	long long int b=pq->num;
	return b-a;
}
int main(void)
{
   struct loy loyArray[ARRAY_SIZE];
   long long int n,i;
    scanf("%lld",&n);
    for(i=0;i<n;++i)
    { 
    scanf("%lld %s",&loyArray[i].num,loyArray[i].name);
    }
    qsort (loyArray,n,sizeof(struct loy),cmp);
    long long int t;
	scanf("%lld",&t);
	printf("%s\n",loyArray[t].name);
   return 0;
}
