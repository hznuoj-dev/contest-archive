/*#include<stdio.h>
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int Y,A,x;
		int n=0;
		int m=0;
		int c=0;
		int d=0;
		scanf("%d %d",&Y,&A);
		if(A>0){
			if(Y+A<10000){
		for(int i=Y;i<=Y+A;i++){
			if(i%4==0&&i%100!=0||i%400==0)
		     n++;
	}
		printf("%d\n",n);
	}
	else{
		if(19998-(Y+A)>Y){
		for(int i=Y;i<=(9999-(Y+A-9999));i++){
		if(i%4==0&&i%100!=0||i%400==0)
		     c++;
	}
	printf("%d\n",c);
}
        if(19998-(Y+A)<=Y){
		for(int i=19998-(Y+A);i<=Y;i++){
		if(i%4==0&&i%100!=0||i%400==0)
		     d++;
	}
	printf("%d\n",d);
}
}
}
	if(A<=0){
		for(int i=Y+A;i<=Y;i++){
			if(i%4==0&&i%100!=0||i%400==0)
			m++;
		}
		printf("%d\n",m);
	}
	}

return 0;	
		
	}*/
/*#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int a[100];
	double sum=0.0;
	int max=a[0];
	int min=a[0];
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		sum+=a[i];
		if(a[i]>max){
			max=a[i];
		}
		if(a[i]<min){
			min=a[i];
		}
	}
	printf("%d %d %.1f",max,min,sum/n);
	return 0;
}	*/
/*#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	while(n--){
		printf("Welcome to HZNU\n");
	}
	return 0;
}*/
/*#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,x;
		scanf("%d %d",&n,&x);
		
			if(x!=0){
				printf("yes\n");
			}
			else
			printf("no\n");
		
	}
	return 0;
}*/
#include<stdio.h>
#include<string.h>
int main(){
	int n;
	scanf("%d",&n);
	long long int  w[1000];
    char s[100][15];
	char c;
	for(int i=1;i<=n;i++){
		scanf("%lld",&w[i]);
		scanf("%s",s[i]);
	}
	int t;
	int k;
	scanf("%d",&k);
	for(int j=1;j<n;j++){
		for(int i=1;i<n-1-j;i++){
			if(w[i]>w[i+1]){
				t=w[i];
				strcpy(c,s+i);
				w[i]=w[i+1];
				strcpy(s+i,s+i+1);
				w[i+1]=t;
				strcpy(s+1+i,c);			
				}
		}
	}
	printf("%s",s[k+1]);
	return 0;
}*/

/*��һ�а���һ�������� T(1 �� T �� 10)�������� T �����ݡ�
����ÿһ������:
��һ��Ϊ n����ʾ�� n(1 �� n �� 105
) ��������
�ڶ����� n ������ ai(1 �� ai �� 5000)��*/
/*#include<stdio.h>
int main(){
	int T;
	scanf("%d",T);
	while(T--){
		int n;
		scanf("%d",&n);
		int a[i];
		for(int i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		
	}
}*/	
/*#include<stdio.h>
int main(){
	int n,m,k;
	int flag=0;
	scanf("%d %d",&n,&m);
	int x[100];
	for(int i=1;i<=n;i++){
		scanf("%d",&x[i]);
		if(x[i]==0)
		scanf("%d",&k);
	}
	for(int i=n;i>=0;i--){
	for(int j=1;j<=n;j++){
	    if(n>=2&&m==0&&x[i]==0&&k>=2500&&x[j]==1){
		flag=1;
		break;
		break;
		}
		}
		}
	for(int i=n;i>=0;i--){
	for(int j=1;j<=n;j++){	
	    if(n>=2&&m==1&&x[i]==0&&k>=2100&&x[j]==1){
		flag=1;
		break;
		break;
		}
	}
}
for(int i=n;i>=0;i--){
for(int j=1;j<=n;j++){
	if(m==0&&x[i]==2&&n>1){
		if(x[j]==0&&k<2500){
			flag=1;
		}
	}
		if(m==1&&x[i]==2&&n>1){
		if(x[j]==0&&k<=2100){
			flag=1;
		}
	}
		if(x[j]!=0)
		flag=1;
		break;
		break;
	    }
		}
	if(flag==0){
	    printf("QAQ\n");
	}
	else
	printf("haoye\n");

return 0;
}*/


	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	



	
