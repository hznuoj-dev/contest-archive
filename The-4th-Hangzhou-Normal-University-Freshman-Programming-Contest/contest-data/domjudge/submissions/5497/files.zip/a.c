#include<stdio.h>

struct zf
{
	char s1;
	int b;
};
int main()
{
	struct zf z[100000];
	int t,k,i,n,sum,h;
	h=0;
	
	scanf("%d",&t);

	while (t--)
	{
		i=0;
		scanf("%d",&k);
		getchar();
		while (i<k)
		{
			z[i].s1=getchar();
			getchar();
			z[i].b=1;
			i++;
		}
		for (i = 0; i < k; i++)
		{
			for ( n = 0; n < k; n++)
			{
				
				if (n<i&&z[i].s1==z[n].s1)
				{
					break;
				}
				if (z[i].s1==z[n].s1&&n>i)
				{
				
					z[i].b=z[i].b+1;
					z[n].b=0;
				}
			}
		}
		sum=0;
		h=0;
		for (i= 0;i < k; i++)
		{
			if (z[i].b>=2)
			{
				sum=sum+z[i].b/2;
			}
			if (z[i].b==1&&h==0)
			{
				sum=sum+1;
				h=h+1;
			}
			if (z[i].b>=2&&z[i].b%2==1&&h==0)
			{
				sum=sum+1;
				h=h+1;
			}
		}
		if(h==0)
		printf("%d\n",sum*2);
		if(h==1)
		printf("%d\n",(sum-1)*2+1);
	}

	return 0;
}
