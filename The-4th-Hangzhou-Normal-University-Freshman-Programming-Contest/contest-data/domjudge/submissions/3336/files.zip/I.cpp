#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
typedef struct
{
	char s[16];
	long long int w;
}like;
int main()
{
	like a[10000];
	int n,k;
	scanf("%d",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%lld%s",&a[i].w,a[i].s);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(a[0]),comp);
	printf("%s",a[k+1].s);
	return 0;
}
int comp(const void *p,const void *q)
{
	like a=*(like*)p;
	like b=*(like*)q;
	return b.w-a.w;
}
