#include <stdio.h>
#include <string.h>
#include <iostream>
using namespace std;
char w[2000][200];
char s[31000];
char ss[200];
int main()
{
	int i,t,j,k;
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		j=0,k=0;
		cin.getline(s,30010);
		//puts(s);
		char ch='\0';
		int len=strlen(s);
		ch=s[len-1];
		s[len-1]='\0';
		len=strlen(s);
		for(i=0;i<=len;i++)
		{
			if(s[i]!=' '&&s[i]!='\0')
			{
				ss[j++]=s[i];
			} 
			if(s[i]==' '||s[i]=='\0')
			{
				strcpy(w[k++],ss);
				memset(ss,'\0',sizeof(ss));
				j=0;
			}
		}
		if(k%2==0)
		{
			for(i=0,j=k-1;i<=k/2-1&&j>=k/2;i++,j--)
			{
				printf("%s",w[i]);
				printf(" ");
				printf("%s",w[j]);
				if(j!=k/2)
					printf(" ");
			}
			printf("%c",ch);
			printf("\n");
		}
		else 
		{
			for(i=0,j=k-1;i<=k/2||j>k/2;i++,j--)
			{
				if(i==k/2)
				{
					printf("%s",w[i]);
					break;
				}
				printf("%s",w[i]);
				printf(" ");
				if(j>k/2)
				{
					printf("%s",w[j]);
					printf(" ");
				}
			}
			printf("%c",ch);
			printf("\n");
		}
		memset(w,'\0',sizeof(w));
	}
	return 0;
} 

