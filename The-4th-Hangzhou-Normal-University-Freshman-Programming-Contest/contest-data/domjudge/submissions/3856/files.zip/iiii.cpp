#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
struct ge{
	long long xi;
	char name[20];
};
struct ge a[100010]={
{10000000000,"min"}	};
int main(){
	int n,k,maxx,minn;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld%s",&a[i].xi,a[i].name);
	}
	scanf("%d",&k);
//	a[100001]={0,"min"};	
	if(k<n/2){
	for(int s=1;s<=k+1;s++){
		maxx=1;
		for(int i=1;i<=n;i++){
			if(a[i].xi>a[maxx].xi) maxx=i;
		}
		if(s!=k+1){
			a[maxx].xi=0;
		}else if(s==k+1) break;
	}
	printf("%s",a[maxx].name);
	}else{
	for(int s=1;s<=k+1;s++){
		minn=0;
		for(int i=1;i<=n;i++){
			if(a[i].xi<a[minn].xi&&a[i].xi!=0) minn=i;
		}
		if(s!=k+1){
			a[minn].xi=0;
		}else if(s==k+1) break;
	}
	printf("%s",a[minn].name);	
	}
//	for(int i=1;i<n;i++){
//		for(int j=i+1;j<=n;j++){
//			if(a[j].xi>a[i].xi) {
//			struct ge temp;	
//			temp=a[j];
//			a[j]=a[i];
//			a[i]=temp;
//			}
//		}
//	}
	return 0;
}
