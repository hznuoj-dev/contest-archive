#include<stdio.h>
#include<string.h>
struct song {
	long long love;
	char s[101];
};
int main (){
	int k,n,i,j;
	struct song a[1001],e;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d%s",&a[i].love,a[i].s);
	}
	for(i=1;i<n;i++){
		for(j=1;j<n;j++){
		if(a[j].love<a[j+1].love){
			e=a[j];
			a[j]=a[j+1];
			a[j+1]=e;
		}
	 }
	}
	scanf("%d",&k);
	printf("%s",a[k+1].s);
}