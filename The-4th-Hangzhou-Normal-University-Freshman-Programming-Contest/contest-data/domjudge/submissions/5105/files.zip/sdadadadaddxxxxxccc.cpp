#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int w[105];
int s[105];
int main(void) {
	int T, n, m, i, j, cnt1 = 0, flag, cnt2 = 0, cnt3 = 0;
	scanf("%d%d", &n, &m);
	if (m == 0) {
		for (i = 1; i <= n; ++i) {
			scanf("%d", &w[i]);
			if (w[i] == 0) {
				scanf("%d", &s[i]);
			}
		}
		for (i = 1; i <= n; ++i) {
			if (w[i] == 0 && s[i] >= 2500) {
				cnt1++;
			}
			if (w[i] == 1) {
				cnt2++;
			}
			if (w[i] == 2) {
				cnt3++;
			}
		}
		if (cnt1 >= 1 && cnt2 >= 1) {
			printf("haoye\n");
		} else if (cnt3 == 1 && (cnt1 != 0 || cnt2 != 0)) {
			printf("haoye\n");
		} else if (cnt3 > 1) {
			printf("haoye\n");
		} else {
			printf("QAQ\n");
		}


	} else {

		for (i = 1; i <= n; ++i) {
			scanf("%d", &w[i]);
			if (w[i] == 0) {
				scanf("%d", &s[i]);
			}
		}
		for (i = 1; i <= n; ++i) {
			if (w[i] == 0 && s[i] > 2100) {
				cnt1++;
			}
			if (w[i] == 1) {
				cnt2++;
			}
			if (w[i] == 2) {
				cnt3++;
			}
		}
		if (cnt1 >= 1 && cnt2 >= 1) {
			printf("haoye\n");
		} else if (cnt3 == 1 && (cnt1 != 0 || cnt2 != 0)) {
			printf("haoye\n");
		} else if (cnt3 > 1) {
			printf("haoye\n");
		} else {
			printf("QAQ\n");
		}

	}


}

