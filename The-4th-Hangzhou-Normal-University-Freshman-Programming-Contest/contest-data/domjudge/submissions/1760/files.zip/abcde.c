#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
int main(void){
	int x,i,n;
	char ch[10001];
	
	scanf("%d",&n);
	while(n--){
		scanf("%d",&x);
		getchar();
		int s[10001]={0};
		int sum=0;
		int flag=1;
		for(i=1;i<=x;++i){
			scanf("%s",&ch[i]);
			s[(int)(ch[i])]++;
			if(s[(int)(ch[i])]%2==0) sum++;
		}
		for(i=64;i<=130;++i){
			if(s[i]%2==1) flag=0;
		}
		if(!flag)
		printf("%d\n",sum*2+1);
		else printf("%d\n",sum*2);
	}
	return 0;
} 
