#include<bits/stdc++.h>
using namespace std;
string s;
int a[100010];
int main()
{
	map<int,string> mp;
	int n,k,i=0;
	int N;
	cin>>N;
	int tmp=N;
	while(N--)
	{
		cin>>n>>s;
		a[i]=n;
		mp[n]=s;
		i++;
	}
	cin>>k;
	sort(a,a+tmp);
	cout<<mp[a[tmp-k-1]];
}
