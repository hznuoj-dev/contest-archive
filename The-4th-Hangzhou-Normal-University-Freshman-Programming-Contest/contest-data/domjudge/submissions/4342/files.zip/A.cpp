#include <stdio.h>
char a[100000];
int main(void){
	int T,i,j,n,k=0;
	char ch;
	scanf("%d",&T);
	while(T){
		T--;
		scanf("%d",&n);
		scanf("\n");
		for(i=0;i<n;i++){
			scanf("%c",&ch);
			if(ch==' '){
				scanf("%c",&ch);
				a[i]=ch;
			}else if(ch=='\n'){
				break;
			}else{
				a[i]=ch;
			}
		}
		for(i=0;i<n-1;i++){
			for(j=i+1;j<n;j++){
				if(a[i]==a[j]){
					k+=2;	
			}
			}
		}
		k++;
		printf("%d\n",k);
		k=0;
	}
	return 0;
	}

