#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main (){
	int n,m,i,j,k;
	int a[10];
	int atk[10];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0) {
			scanf("%d",&atk[i]);
		}
	}
	if(m==0){
		int f=0;
		for(i=0;i<n;i++){
			if(a[i]==0&&atk[i]>=2500){
				for(j=0;j<n;j++){
					if(a[j]==1){
						printf("haoye");
						f=1;
					}
					if(a[j]==2&&n>2){
						printf("haoye");
						f=1;
					}
				}
			}
		}
		if(f==0){
			printf("QAQ");
		}
	}
	if(m==1){
		int f=0;
		for(i=0;i<n;i++){
			if(a[i]==0&&atk[i]>2100){
				for(j=0;j<n;j++){
					if(a[j]==1){
						printf("haoye");
						f=1;
					}
					if(a[j]==2&&n>2){
						printf("haoye");
						f=1;
					}
				}
			}
		}
		if(f==0){
			printf("QAQ");
		}
	}
	return 0;
} 
