#include<stdio.h>
#include<string.h>
int main(){
	int n;
	int w[10001],t;
	char s[10001][100],s1[100];
	int k;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%d",&w[i]);
		getchar();
		scanf("%s",s[i]);                           
	}
	scanf("%d",&k);
	k=k+1;
	for (int i=n;i>1;i--){
		for (int j=n;j>n-i+1;j--){
			if(w[j]>w[j-1]){
				t=w[j];
				w[j]=w[j-1];
				w[j-1]=t;
				strncpy(s1,s[j],15);
				strncpy(s[j],s[j-1],15);
				strncpy(s[j-1],s1,15);
			}                            
		}
	}
	printf("%s",s[k]);
	return 0;
}
