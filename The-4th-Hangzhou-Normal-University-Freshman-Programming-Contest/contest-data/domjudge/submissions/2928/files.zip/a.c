#include <stdio.h>
int main(void) {
	int t,n,i,a[5000],j,k;
	int num,sum;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		num=0;
		scanf("%d",&n);
		for(j=0;j<n;j++){
			scanf("%d",&a[j]);
		}
		for(j=0;j<n;j++){
			sum=a[j];
			for(k=j+1;k<=n;k++){
				if(sum<7777){
					sum+=a[k];
				}
				else if(sum>7777){
					sum-=a[k-1];
					sum+=a[k];
					continue;
				}
				else if(sum==7777){
					num++;
					break;
				}
			}
		}
		printf("%d\n",num);
	}
	return 0;
}

