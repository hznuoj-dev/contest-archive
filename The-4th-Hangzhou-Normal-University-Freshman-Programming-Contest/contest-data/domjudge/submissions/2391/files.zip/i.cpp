#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<algorithm>
#define MogeKo qwq

using namespace std;

const int maxn = 1e5+10;

struct node {
	int w;
	char s[20];
} a[maxn];

bool cmp(node A,node B) {
	return A.w > B.w;
}

int n,k;

int main() {
	scanf("%d",&n);
	for(int i = 1; i <= n; i++) {
		scanf("%d",&a[i].w);
		scanf("%s",a[i].s);
	}
	sort(a+1,a+n+1,cmp);
	scanf("%d",&k);
	printf("%s",a[k+1].s);
	return 0;
}

