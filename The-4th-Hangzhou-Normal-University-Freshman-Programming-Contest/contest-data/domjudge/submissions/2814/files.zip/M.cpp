#include <stdio.h>
#include <string.h>

int main() {
	int n, x, i, c, y;
	char a[1000][32];
	char b;
	scanf("%d", &n);
	while (n--) {
		for (i = 0; i < 1000; i++) {
			scanf("%s", a[i]);
			x = strlen(a[i]);
			if (a[i][x - 1] == '.' || a[i][x - 1] == '!' || a[i][x - 1] == '?') {
				b = a[i][x - 1];
				a[i][x - 1] = a[i][x];
				a[i][x] = ' ';
				goto zhe;
			}
		}
zhe:
		if ((i + 1) % 2 == 0) {
			c = (i + 1) / 2;
			for (x = c; x > 0; x--) {
				printf("%s ", a[c - x]);
				if (x == 1) {
					printf("%s", a[c + x - 1]);
					printf("%c\n", b);
				} else
					printf("%s ", a[c + x - 1 ]);
			}
		}

		if ((i + 1) % 2 != 0) {
			c = i / 2;
			for (x = c; x > 0; x--) {
				printf("%s ", a[c - x]);
				printf("%s ", a[c + x]);
			}
			printf("%s%c\n", a[c], b);
		}
	}
}