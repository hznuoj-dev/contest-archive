#include <stdio.h>
int main(void)
{
	int b[200]={0};
	int t, n,i,s,sum,flag;
	char ch;
	scanf("%d",&t);
	while(t--)
	{
		sum=0;flag=0;
		scanf("%d",&n);
		for(i=1;i<=n;i++){
			scanf(" %c",&ch);
			s = ch;
			b[s]++;
		}
		for(i=0;i<=200;i++){
			if(b[i]!=0){
				sum+=b[i]/2;
				if(b[i]%2==1) flag=1;
			}
		}
		if(flag)
		printf("%d\n",sum+1);
		else printf("%d\n",sum);
	}
	return 0;
}
