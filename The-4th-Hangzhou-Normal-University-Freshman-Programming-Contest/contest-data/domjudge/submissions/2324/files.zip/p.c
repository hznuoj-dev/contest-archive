#include <stdio.h>
char na[100004][20];
long long int pp[100004];
int rank[100004];
int rank1[100004];
int main()
{
	int a,b,c,d,e,f;
	scanf("%d",&a);
	for(b=1;b<=a;b++)
	{
		scanf("%d %s",&pp[b],na[b]);
	}
	for(c=1;c<=a;c++)
	{
		for(d=1;d<=a;d++)
		{
			if(pp[c]<pp[d])
				rank[c]=rank[c]+1;
		}
		rank1[rank[c]]=c;
	}
	scanf("%d",&e);
	printf("%s\n",na[rank1[e]]);
	return 0;
}