#include <stdio.h>
#include <stdlib.h>

/* run this program using the console pauser or add your own getch, system("pause") or input loop */

int main(int argc, char *argv[]) {
	int T,a,b;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&a,&b);
		if(b!=0){
			printf("yes\n");
		}
		else{
			printf("no\n");
		}
	} 
	return 0;
}
