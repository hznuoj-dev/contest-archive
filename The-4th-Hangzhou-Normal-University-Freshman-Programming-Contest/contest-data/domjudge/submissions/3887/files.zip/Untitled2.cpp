#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int t,n,atk,now,yes=0;
	scanf("%d%d",&t,&now);
	while(t--){
		scanf("%d",&n);
		if(n==0){
			scanf("%d",&atk);
			if(now==0&&atk>=2500)now=-1;
			else if(now==1&&atk>2100)now=-1;
		}
		else if(n==1){
			if(now==-1){
				yes=1;
			}
		}
		else{
			if(now!=-1&&t>0){
				yes=1;
			}
			else t--;
		}
	}
	if(yes==1)printf("haoye");
	else printf("QAQ");
}

