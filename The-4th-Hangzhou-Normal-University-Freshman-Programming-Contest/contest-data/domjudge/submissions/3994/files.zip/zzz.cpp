#include<bits/stdc++.h>
using namespace std;

string word[1005],word1[1005];
int main(){
	int t;
	string fuhao;
	cin>>t;
	while(t--){
		int i=1;
		while(1){
			cin>>word[i];
			if(word[i][word[i].size()-1]=='.'||word[i][word[i].size()-1]=='!'||word[i][word[i].size()-1]=='?'){
				fuhao=word[i][word[i].size()-1];
				word[i][word[i].size()-1]='\0';
				break;
			}
			i++;
		}
		int l=1,r=i;
		for(int j=0;j<i;j++){
			if(j%2==0){
				word1[j]=word[l];
				l++;
			}else{
				word1[j]=word[r];
				r--;
			}
		}
		word1[i]=fuhao;
		for(int j=0;j<i-1;j++){
			if(j==1){
				cout<<word1[j];
			}else{
				cout<<word1[j]<<' ';
			}
		}
		cout<<word1[i-1]<<word1[i]<<'\n';
	}
} 
