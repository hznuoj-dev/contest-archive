#include <stdio.h>
int main()
{
	int T,n,x,o,q,f,t;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d%d",&n,&x);
		o=q=f=t=0;
		if(x==0)
		printf("no\n");
		else
		while(1)
		{
			o=o+x;
			while(o>n)
			{
				o=o-n-1;
				if(o==0)
				{
					f=1;
					break;
				}
				t++;
			}
			if(t==30)
			{
				printf("no\n");
				break;
			}
			if(f==1)
			{
				printf("yes\n");
				break;
			}
		}
	}
}
