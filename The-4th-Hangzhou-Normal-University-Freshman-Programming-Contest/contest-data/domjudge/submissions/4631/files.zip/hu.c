#include <stdio.h>
#include <string.h>
#pragma warning(disable:4996)
int main() {
    int n,x[10],m,i; 
    char a[100][100]; 
    scanf("%d", &n);
    for ( i = 0; i < n; i++)
    {
        scanf("%d", &x[i]);

        scanf("%s", a[i]);
    }
    scanf("%d", &m);
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (x[j] > x[i])
            {
                char s[100];
                strcpy(s, a[i]);
                strcpy(a[i], a[j]);
                strcpy(a[j], s);
            }
        }
    }
    printf("%s", a[m]);
}
