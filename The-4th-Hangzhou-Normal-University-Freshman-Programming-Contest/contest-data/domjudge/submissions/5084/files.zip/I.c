
#include<stdio.h>

int main()
{
	struct Song
	{
		int love;
		char name[50];
	}song[10010],t;
	int n;
	int k;
	int i,j;
	int m;

	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&song[i].love,song[i].name);
	}

	for(i=0;i<n-1;i++)
	{
		m=i;
		for(j=i+1;j<n;j++)
		{
			if(song[j].love>song[m].love)
			{
				m=j;
			}
		}
		if(m!=i)
		{
			t=song[i];
			song[i]=song[m];
			song[m]=t;
		}
	}

	scanf("%d",&k);
	printf("%s\n",song[k].name);

	return 0;
}