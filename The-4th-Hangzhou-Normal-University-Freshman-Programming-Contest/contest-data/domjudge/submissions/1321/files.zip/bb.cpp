#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#define pzc 666
using namespace std;
int main()
{
	int t,n,i,j,k,a,b,c;
	char ch,s;
	cin>>n;
	while(n--)
		cout<<"Welcome to HZNU"<<endl;
}
