#include<bits/stdc++.h>
#define wtn tql
using namespace std;

int main(void){
	int t;cin>>t;
	while(t--){
		map<int,int>a;
		int n;cin>>n;
		for(int i=0;i<n;i++){
		char input[1];
			cin>>input;
			a[input[0]-'A']++;
			
		}
		map<int,int>::iterator p;
		p=a.begin();
		int js=0;int sum=0;
		while(p!=a.end()){
			if(p->second%2==0)sum+=p->second;
			else {
				js=1;
				sum+=p->second-1;
			}
			p++;
		}
		sum+=js;
		cout<<sum<<endl;
	}
return 0;
}

