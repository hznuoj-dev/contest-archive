#include<stdio.h>
#include<string.h>
#define atk 2500
#define def 2100
int main()
{
    int n,m,i,j,a[11],k[11]={0},flag=0,x=0;
    scanf("%d%d",&n,&m);
    for(i=0;i<n;++i)
    {
    	scanf("%d",&a[i]);
    	if(a[i]==0)
    	{
    		scanf("%d",&k[i]);
		}
	}
	for(i=0;i<n;++i)
	{
		if(m==0)
		{
			if(k[i]>=atk)
			{
				for(j=0;j<n;++j)
				{
					if(a[j]==1)
					{
						flag=1;
						break;
					}
				}
				if(flag)
				break;
			}
		}
		if(m==1)
		{
			if(k[i]>def)
			{
				for(j=0;j<n;++j)
				{
					if(a[j]==1)
					{
						flag=1;
						break;
					}
				}if(flag)
				break;
			}
		}
		
	}
	for(i=0;i<n;++i)
	{
		if(a[i]==2)
		{
			if(n>1)
			{
				flag=1;
				break;
			}if(flag)
				break;
		}
	}
	
	if(flag==1)
	printf("haoye\n");
	else
	printf("QAQ\n");
    return 0;
} 
