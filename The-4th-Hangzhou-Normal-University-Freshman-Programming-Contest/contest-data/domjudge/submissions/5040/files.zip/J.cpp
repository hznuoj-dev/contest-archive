/*J*/
#include<stdio.h>
struct card{
	int x;
	int k;
};
int main(void)
{
	int m, n, i, j, flag1, flag2;
	struct card a[20];
	scanf("%d%d", &n, &m);
	for(i=0;i<n;i++){
		scanf("%d%d", &a[i].x, &a[i].k);
	}
	flag1=flag2=0;
	if(n<=1){
		printf("QAQ");
	}else{
		if(m){
			for(i=0;i<n;i++){
				if(a[i].x==0&&a[i].k>2100){
					flag1=1;
				}
				if(a[i].x>0){
					flag2=1;
				}
			}
		}else{
			for(i=0;i<n;i++){
				if(a[i].x==0&&a[i].k>=2500){
					flag1=1;
				}
				if(a[i].x>0){
					flag2=1;
				}
			}
		}
	}
	if(flag1*flag2){
		printf("haoye");
	}else{
		printf("QAQ");
	}
	return 0;
}
