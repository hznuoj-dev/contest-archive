#include<stdio.h>
#include<string.h>
int main()
{
	int t;
	scanf("%d", &t);
	getchar();
	while (t--)
	{
		char a[30010];
		int len, i, j = 0, k, f = 1;
		scanf("%[^\n]", a);
		getchar();
		len = strlen(a);
		k = len - 1;
		int num = 0;
		for (i = 0; i < len; i++)
		{
			if (a[i]==' ')
			{
				num++;
			}
		}
		num++;
		while (num--)
		{
			if (f == 1)
			{
				for (i = j; a[i] != ' ' && a[i] != '.' && a[i] != "、" && a[i] != '!'; i++)
				{
					printf("%c", a[i]);
				}
				printf("%c",a[i]);
				j = i + 1;
				f = -f;
			}
			else
			{
				for (i = k;; i--)
				{
					if (a[i] == ' ')
					{
						break;
					}
					k = i - 2;
				}
				for (i++; a[i] != ' ' && a[i] != '.' && a[i] != "、" && a[i] != '!'; i++)
				{
					printf("%c", a[i]);
				}
				printf(" ");
				f = -f;
			}
		}
		printf("\b%c\n", a[len - 1]);
	}
	return 0;
}