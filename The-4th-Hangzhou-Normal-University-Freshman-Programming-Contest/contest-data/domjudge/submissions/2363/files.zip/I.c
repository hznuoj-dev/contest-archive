#include <stdio.h>
struct song{
	int w;
	char s[15];
};
struct song a[100000];
struct song temp;
int main(){
	int n,k,i,j;
	scanf("%d",&n);
	 for(i=0;i<n;++i){
	 	scanf("%d %s",&a[i].w,a[i].s);
	 }
	 scanf("%d",&k);
	 for(j=1;j<n;++j){
	 	for(i=0;i<n-j;++i){
	 		if(a[i].w<a[i+1].w){
	 			temp=a[i+1];
	 			a[i+1]=a[i];
	 			a[i]=temp;
			 }
		 }
	 }
	 printf("%s",a[k].s);
	 return 0;
} 
