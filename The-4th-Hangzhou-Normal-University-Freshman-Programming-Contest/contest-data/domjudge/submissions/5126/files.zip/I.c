#include<stdio.h>

int main()
{
	int n, m;
	int t[10000];
	char ch[100][100];
	scanf("%d", &n);
	getchar();

	for (int i = 0; i < n; i++)
	{

		scanf("%d", &t[i]);
		
		scanf("%s",ch[i]);

	}

	scanf("%d", &m);
	for (int j = 0; j < n; j++)
	{
		if (t[j] < m)
		{

			printf("%s\n", ch[j]);

		}
	}
	return 0;
}