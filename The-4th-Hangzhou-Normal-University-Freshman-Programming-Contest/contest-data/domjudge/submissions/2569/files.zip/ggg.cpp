#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
struct array
{
	int dasiki;
	char s[16];
};
int cmp( const void *a , const void *b ) 
{ 
struct array *c = (array *)a; 
struct array *d = (array *)b; 
return d->dasiki - c->dasiki; 
} 
int main()
{
	int T,n,sum=0,i,k;
	array a[100001];
	scanf("%d",&n);
	getchar();
	for(i=1;i<=n;i++)
	{
		scanf("%d %s",&a[i].dasiki,a[i].s);
	 } 
	 qsort(a,n+1,sizeof(100),cmp);
	 scanf("%d",&k);
	 printf("%s",a[n-k].s);
 } 
