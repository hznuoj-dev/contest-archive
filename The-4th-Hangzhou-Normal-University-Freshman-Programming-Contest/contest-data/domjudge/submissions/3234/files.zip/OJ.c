#include <stdio.h>
#include <string.h>

struct high {
	long long a;
	char name[16];
};

int main() {
	struct high song[100];
	struct high p;
	int n, k, i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%lld %s", &song[i].a, &song[i].name);
	}
	scanf("%d", &k);
	for (i = 0; i < n; i++) {
		for (j = 0; j < n - 1 - i; j++) {
			if (song[j].a < song[j + 1].a) {
				p = song[j + 1];
				song[j + 1] = song[j];
				song[j] = p;
			}
		}
	}
	printf ("%s", song[k].name);
}