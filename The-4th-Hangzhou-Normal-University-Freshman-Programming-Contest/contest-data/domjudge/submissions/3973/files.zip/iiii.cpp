#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
struct ge{
	long long xi;
	char name[20];
};
struct ge a[100010]={
{10000000000,"min"}	};
int main(){
	int n,k;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%lld%s",&a[i].xi,a[i].name);
	}
	scanf("%d",&k);
//	a[100001]={0,"min"};	

	if(k<n/2){
		int m;
	for(int s=1;s<=k+1;s++){
		m=1;
		for(int i=1;i<=n;i++){
			if(a[i].xi>a[m].xi&&a[i].xi!=0) m=i;
		}
		if(s!=k+1){
			a[m].xi=0;
		}else if(s==k+1) break;
	}
	printf("%s",a[m].name);
	}else{
		int mm;
	for(int s=1;s<=n-k;s++){
		mm=0;
		for(int i=1;i<=n;i++){
			if(a[i].xi<a[mm].xi&&a[i].xi!=0) mm=i;
		}
		if(s!=k+1){
			a[mm].xi=0;
		}else if(s==k+1) break;
	}
	printf("%s",a[mm].name);	
	}
//	for(int i=1;i<n;i++){
//		for(int j=i+1;j<=n;j++){
//			if(a[j].xi>a[i].xi) {
//			struct ge temp;	
//			temp=a[j];
//			a[j]=a[i];
//			a[i]=temp;
//			}
//		}
//	}
	return 0;
}
