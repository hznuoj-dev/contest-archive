#include <stdio.h>
int main(void)
{
	int n,m,i,x;
	int count=0;
	int count1=0;
	int count2=0;
	int card[11];
	int atk[11]={0};
	scanf("%d%d",&n,&m);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&card[i]);
		if(card[i]==0)
		scanf("%d",&atk[i]);
		if(card[i]==2)
		count=1;
		if(card[i]==1)
		count1=1;
	}
	if(n<2)
	printf("QAQ");
	else
	{
	    if(count==1)
	    {
	    	printf("haoye");
		}
		if(count==0)
		{
			if(count1==0)
			{
				printf("QAQ");
			}
			if(count1==1)
			{
				if(m==0)
				{
					for(i=1;i<=n;i++)
					{
						if(atk[i]>=2500)
						{
							count2=1;
							break;
						}
					}
					if(count2==1)
					{
						printf("haoye");
					}
					else
					printf("QAQ");
				}
				if(m==1)
				{
					for(i=1;i<=n;i++)
					{
						if(atk[i]>2100)
						{
							count2=1;
							break;
						}
					}
					if(count2==1)
					{
						printf("haoye");
					}
					else
					printf("QAQ");
				}
			}
		}
    }
	return 0;
}

