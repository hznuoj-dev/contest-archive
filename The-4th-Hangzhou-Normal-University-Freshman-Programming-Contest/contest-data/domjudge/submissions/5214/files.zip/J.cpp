#include<stdio.h>
int main()
{
	int n, m, x, k, t = 0, f = 0, p = 0;
	scanf("%d %d", &n, &m);
	while (n--)
	{
		scanf("%d", &x);
		if (x == 2)
		{
			if (n >= 2)
			{
				t = 1;
			}
		}
		else if (x == 0)
		{
			scanf("%d", &k);
			if (m == 0&&k>=2500)
			{
				f = 1;
			}
			else if (m == 1 && k >= 2100)
			{
				f = 1;
			}
		}
		else if (x == 1)
		{
			p = 1;
		}
	}
	if (t == 1)
	{
		printf("haoye");
	}
	else if (f == 1 && p == 1)
	{
		printf("haoye");
	}
	else
	{
		printf("QAQ");
	}
	return 0;
}
