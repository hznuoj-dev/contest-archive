#include <stdio.h>
int main()
{
	int T,ch[64]={0},n,i,s,sum;
	char a[2];
	scanf("%d",&T);
	while(T--)
	{
		sum=1;
		scanf("%d",&n);
		while(n--)
		{
			scanf("%s",a);
			s=(int)(a[0])-65;
			ch[s]++;
		}
		for(i=0;i<64;i++)
		{
			sum=sum+2*(ch[i]/2);
		}
		printf("%d\n",sum);
	}
 } 
