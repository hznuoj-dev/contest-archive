#include <stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,x;
		scanf("%d %d",&n,&x);
		int i;
		if(x==1)printf("yes\n");
		else if(x==0)printf("no\n");
		else{
			int temp=0;
			int flag=0;
			for(i=0;i<1000000;i++){
				temp+=x;
				if(temp>=n)temp = temp-n;
				if(temp==0){
					printf("yes\n");
					flag=1;
					break;
				}
			}
			if(flag==0)printf("no\n");
		}
	}
}
