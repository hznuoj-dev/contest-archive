#include<bits/stdc++.h>
using namespace std;

int main(){
	int t,n,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&x);
		if(x==0||n<=2)
			printf("no\n");
		if(x!=0&&n>2)
			printf("yes\n");
	}
	return 0;
} 
