#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;

int main()
{
	int n,m;
	cin>>n>>m;
	int z=0;
	if(m==0)
		z=2500;
	else 
		z=2100;
	int j=0,k=0,l=0;
	for(int i=0;i<n;i++)
	{
		int x;
		cin>>x;
		if(x==0)
		{	cin>>x;
			if(x>=z&&m==0)
				j=1;
			else if(x>z&&m==1)
				j=1;
		}
		if(x==1)
			k=1;
		if(x==2)
			l=1;
	}
	
		if(l==1&&n>1)
		{
			cout<<"haoye"<<endl;
			
		}
		else if(j==1&&k==1)
			cout<<"haoye"<<endl;
		else
			cout<<"QAQ"<<endl;

	
}
