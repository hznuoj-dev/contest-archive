#include<stdio.h>
int main(){
	int t,a,b;
	scanf("%d",&t);
	for(int z=0;z<t;z++){
		scanf("%d%d",&a,&b);
		if(b==0){
			printf("no\n");
			continue;
		}
		if((a-1)*2%b==0){
			printf("yes\n");
		}
		else{
			printf("no\n");
		}
	}
	return 0;
}
