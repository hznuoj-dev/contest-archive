#include<stdio.h>
#include<stdlib.h>
int main(){
	int t;
	int n, x;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d%d", &n, &x);
		if (x == 0)printf("no\n");
		else if (n % x == 0)printf("yes\n");
		else printf("no\n");

	}
}