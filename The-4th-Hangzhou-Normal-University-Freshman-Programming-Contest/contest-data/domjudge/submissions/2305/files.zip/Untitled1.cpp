#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct yoo{
	int num;
	char a[1000];
};
int cmp(const void *p,const void *q)
{
	struct yoo *pp=(struct yoo *)(p);
	struct yoo *pq=(struct yoo *)(q);
	int a=pp->num;
	int b=pq->num;
	return a-b;
}
int main()
{
	struct yoo b[101];
	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d%s",&b[i].num,b[i].a);
	qsort(b,n,sizeof(struct yoo),cmp);
	scanf("%d",&k);
	for(i=0;i<n-k;i++)
	printf("%s",b[i].a);
}
