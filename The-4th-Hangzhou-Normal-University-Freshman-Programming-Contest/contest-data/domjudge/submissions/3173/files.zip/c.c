#include<stdio.h>
int main()
{
	int n,m,b;
	scanf("%d", &n);
	while (n--)
	{
		scanf("%d %d", &m,&b);
		if(b==0)
			printf("no\n");
		else {
			if (m % b == 0)
				printf("yes\n");
			else printf("no\n");
		}
	}

	return 0;
}