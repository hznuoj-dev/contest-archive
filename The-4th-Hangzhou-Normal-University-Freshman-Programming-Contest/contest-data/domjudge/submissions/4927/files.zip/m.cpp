#include <stdio.h>

int main() {
	int n, i, j, t, dst, z, k, r;
	int a[21][21], b[21][21];
	int tmp[21][21];
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &n);
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				scanf("%d", &a[i][j]);
		}
		for (int i = 0; i < n; i++) {
			for (int j = 0; j < n; j++)
				scanf("%d", &b[i][j]);
		}
		r = 0;
		for (k = 0; k <= 3; k++) {
			z = 0;
			for (i = 0; i <= n - 1; i++) {
				for (j = 0; j <= n - 1; j++) {
					if (a[i][j] != b[i][j]) {
						z = 1;
					}
				}
			}
			if (z == 0) {
				printf("%d\n", k);
				r = 1;
				break;
			}
			if (z == 1) {
				dst = n - 1;
				for (int i = 0; i < n; i++, dst--)
					for (int j = 0; j < n; j++)
						tmp[j][dst] = a[i][j];
				for (int i = 0; i < n; i++)
					for (int j = 0; j < n; j++)
						a[i][j] = tmp[i][j];
			}
		}
		if (r == 0)
			printf("-1\n");
	}
	return 0;
}

