#include<bits/stdc++.h>
using namespace std; 
struct dd{
	int love;
	char s[20];
}song[100005];

bool cmp(dd p,dd q)
{
	return p.love>q.love;
}

int main()
{
	int i,n,k;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
		scanf("%d %s",&song[i].love,song[i].s);
	cin>>k;
	sort(song+1,song+1+n,cmp);
	cout<<song[k+1].s<<endl;
	return 0;
}
