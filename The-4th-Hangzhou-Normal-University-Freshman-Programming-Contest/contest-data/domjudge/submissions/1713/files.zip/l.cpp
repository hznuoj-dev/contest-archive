#include<stdio.h>
int main ()
{
	int t,i,j;
	scanf("%d",&t);
	while(t--)
		{
			scanf("%d%d",&i,&j);
    		if(j!=0)
		  {
			printf("yes\n");
		  }
		  else
		  {
		  	printf("yes\n");
		  }
		}
		
	
 } 
