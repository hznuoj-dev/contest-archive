#include <stdio.h>
#include <stdlib.h>
struct song{
	int w;
	char s[15];
};
int comp(const void *p,const void *q){
	return ((struct song*)q)->w-((struct song*)p)->w;
}
struct song a[100000];
struct song temp;
int main(){
	int n,k,i,j;
	scanf("%d\n",&n);
	 for(i=0;i<n;++i){
	 	scanf("%d %s",&a[i].w,a[i].s);
	 }
	 qsort(a,n,sizeof(struct song),comp);
	 scanf("%d",&k);
	 printf("%s\n",a[k].s);
	 return 0;
} 
