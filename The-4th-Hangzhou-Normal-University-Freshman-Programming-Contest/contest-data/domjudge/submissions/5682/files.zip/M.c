#include <stdio.h>
#include <string.h>
int main()
{
	int T;
	char ch[1010][31],bd;
	scanf("%d",&T);
		int i=1,j,f=0;
		while(~scanf("%s",ch[i]))
		{
			if(ch[i][strlen(ch[i])-1]<65)
			{
				f=1;
				bd=ch[i][strlen(ch[i])-1];
				ch[i][strlen(ch[i])-1]='\0';
			}
			if(f==1)
			{
				f=0;
				for(j=1;j<=i/2;j++)
				{
					printf("%s %s",ch[j],ch[i-j+1]);
					if(j!=i/2)
					printf(" ");
				}
				if(i%2!=0)
				printf(" %s",ch[i/2+1]);
				printf("%c\n",bd);
				T--;
				if(T==0)break;
				i=0;
			}
			i++;
		}
}
