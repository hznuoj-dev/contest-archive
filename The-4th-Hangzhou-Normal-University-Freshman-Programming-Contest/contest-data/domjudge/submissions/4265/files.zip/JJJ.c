#include<stdio.h>
struct t{
	int n;
	int ak;
};
int main(){
      int n,m;
      scanf("%d %d",&n,&m);
      struct t ta[n];
      int i;
      for(i=0;i<n;i++){
      	scanf("%d",&ta[i].n);
      	if(ta[i].n==0)
      	scanf("%d",&ta[i].ak); 
	  }
	  int flag1=0;int flag2=0;
	  for(i=0;i<n;i++){
	  	if(ta[i].n==0){
	  		if(m==0){
	  		if(ta[i].ak>=2500){
			  
			  flag1++;
			  break;}}
	  		if(m==1){
			  
	  		if(ta[i].ak>2100){
			  
			  flag1++;
			  break;}
			  }
		  }
	  }
	  for( i=0;i<n;i++){
	  	if(ta[i].n==1){
	  	flag1++;
	  	break;
	  }}
	  
	
	  
	 for(i=0;i<n;i++){
	 	if(ta[i].n==2){
	 		flag2++;
	 		break;
		 }
	 }
	
	 for(i=0;i<n;i++){
	 	if(ta[i].n!=2){
	 		flag2++;
	 		break;
		 }
	 }
	
	 if(flag1==2 || flag2==2)printf("haoye");
	 else printf("QAQ");
} 



