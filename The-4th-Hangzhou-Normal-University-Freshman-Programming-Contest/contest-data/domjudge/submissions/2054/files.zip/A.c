#include<stdio.h>
#include <string.h>
int expandAround(char * str, int left, int right)
{
    while(str[left] == str[right]  && left >= 0 && right < strlen(str))
    {
        left--;
        right++;
    }
    return right - left - 1;
}
 
int max(int a, int b)
{
    if(a > b)
        return a;
    return b;
}
int main(void)
{
	int T,n,i;
	char str[1000];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		int m,j;
		for(i=0;i<n;i++){
			scanf("%c ",&str[i]);
		m = 0;
        for(j= 0; j< strlen(str); j++)
        {
            int len1 = expandAround(str, j, j);  
            int len2 = expandAround(str, j, j + 1);
            int len = max(len1, len2);
            m = max(m, len);
        }
		}
		printf("%d\n", m);
	}
	return 0;
 } 
