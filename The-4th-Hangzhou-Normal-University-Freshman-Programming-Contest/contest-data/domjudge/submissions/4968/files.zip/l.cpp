#include<stdio.h>
void cnm(int, int);
int main()
{
    int T, gs, qw;
    scanf("%d", &T);
    while (T--) {
        scanf("%d %d", &gs, &qw);
        cnm(gs, qw);
    }
    return 0;
}
void cnm(int x, int y) {
    int i, all = 0, biaozhi = 0;
    if (y == 0) {
        biaozhi = 1;
    }
    if (y != 0) {
        for (i = 0; i < 2000; i++) {
            all += y;
            if (all >= x) {
                all -= x;
            }
            if (all == 0) {
                biaozhi = 2;
                printf("yes\n");
                break;
            }
        }
    }
    if (biaozhi != 2) {
        printf("no\n");
    }

}
