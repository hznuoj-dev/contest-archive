//
#include<stdio.h>
#include<math.h>
char a[10 ^ 5];
int main(void){
	int T;
	scanf("%d", &T);
	
	while (T--) {
		int n, k =0;
		scanf("%d", &n);
		getchar();
		for (int i = 0; i < n; i++) {
			scanf(" %c", &a[i]);
		}
		if (n != 1) {
			for (int j = 0; j <sqrt(n); j++) {
				for (int i = j +1; i < n; i++) {
					if (a[j] == a[i]) {
						if (j == 0) {
							k += 1;
							break;
						}
						if (j > 0) {
							for (int o = 0; o < j; o++) {
								if (a[i] != a[o])
									k += 1;
							}
							break;
						}
					}
				}
			}
			if (n % 2 != 0) {
				if (k == 0)
					printf("1\n");
				else
					printf("%d\n", k * 2 + 1);
			}
			if (n % 2 == 0) {
				if (k == 0)
					printf("1\n");
				else
					printf("%d\n", k * 2);
			}
		}
		if (n == 1) 
			printf("1\n");
	}
	return 0;
}