#include<bits/stdc++.h>
using namespace std;

int a[30][30],f[4];
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				scanf("%d",&a[i][j]);
			}
		}
		int p;
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				scanf("%d",&p);
				if(p!=a[i][j])f[0]=1;
				if(p!=a[j][n-1-i])f[1]=1;
				if(p!=a[n-1-i][n-1-j])f[2]=1;
				if(p!=a[n-1-j][i])f[3]=1;
			}
		}
		int ans=-1;
		if(f[0]==0)ans=0;
		else if(f[1]==0||f[3]==0)ans=1;
		else if(f[2]==0)ans=2;
		printf("%d\n",ans);
		f[0]=0,f[1]=0,f[2]=0,f[3]=0,ans=-1;
		
	}	
}
