#include<bits/stdc++.h>
#define wtn tql
using namespace std;
int main(void){
int n;cin>>n;
while(n--)cout<<"Welcome to HZNU"<<endl;
return 0;
}

