#include <stdio.h>

int main () {
	int m, n, j[10], k[10];
	int x = 0, y = 0, z = 0;
	scanf("%d %d", &m, &n);
	int i;
	for (i = 0; i < 10; i++) {
		j[i] = 0;
		k[i] = 0;
	}
	for (i = 0; i < m; i++) {
		scanf("%d", &j[i]);
		if (j[i] == 1)
			y = 1;
		if (j[i] == 2)
			z = 1;
		if (j[i] == 0) {
			scanf("%d", &k[i]);
			if (k[i] >= 2500 && n == 0)
				x = 1;
			if (k[i] > 2100 && n == 1)
				x = 1;
		}
	}
	if (x == 1 && y == 1)
		printf("haoye");
	else if (z == 1 && m >= 2)
		printf("haoye");
	else
		printf("QAQ");

}