#include <iostream>
#include <vector>
#include <map>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin.tie(0);
	int q;
	cin>>q;
	while(q--){
		int n,x;
		cin>>n>>x;

		if(x) cout<<"yes\n";
		else cout<<"no\n";
	}
	
	return 0;
}
