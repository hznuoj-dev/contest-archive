#include<stdio.h>
int main(){
    int t;
    int a[5001],n,s,q;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		q=0;
		for (int i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for (int i=0;i<n;i++){
			s=0;
			for (int j=i;j<n;j++){
				s+=a[j];
				if (s==7777){
					q++;
				}
				
			}
		}
		printf("%d\n",q);
	} 
	
	
} 
