#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int a[100005]={0};
int main(){
	int t,n,i;
	scanf("%d",&n);
	while(n--)
	printf("Welcome to HZNU\n"); 
	return 0;
}
