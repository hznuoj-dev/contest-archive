#include<stdio.h>
int main() {
	int n;
	scanf("%d", &n);
	struct songs {
		long w;
		char s[16];
	};
	struct songs song[10001];
	for (int i = 0; i < n; i++) {
		scanf("%ld", &song[i].w);
		getchar();
		scanf("%s",song[i].s);
	}
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			struct songs swap;
			if (song[i].w < song[j].w) {

			}
			else {
				swap = song[i];
				song[i] = song[j];
				song[j] = swap;
			}
		}
	}
	int k;
	scanf("%d", &k);
	printf("%s\n", song[k].s);
	return 0;
}