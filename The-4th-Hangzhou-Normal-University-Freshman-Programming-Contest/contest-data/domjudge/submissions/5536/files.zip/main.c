//
//  main.c
//  I.cpp
//
//  Created by 陶艾嘉 on 2021/12/12.
//

#include <stdio.h>
#include<stdlib.h>
#define ARRAY_SIZE 100000
struct stff{
    char name[16];
    int num;
};
int comp(const void*p,const void*q){
    return((struct stff*)q)->num-((struct stff*)p)->num;
}
int main(){
    struct stff a[ARRAY_SIZE];
    int i,n,k=0;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%d %s\n",&a[i].num,a[i].name);
    }
    scanf("%d",&k);
    qsort(a,n,sizeof(struct stff),comp);
    printf("%s\n",a[k].name);
    return 0;
}
