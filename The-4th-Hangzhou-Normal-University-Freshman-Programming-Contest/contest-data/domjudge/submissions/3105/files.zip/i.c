#include <stdio.h>
#include <stdio.h>
struct music
{
	int w;
	char s[20];
	int num;
}sing [200000];
int main()
{
	int n,i,j,k,t;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&sing[i].w,sing[i].s);
		sing[i].num=i+1;
	}
	scanf("%d",&k);
	for(i=0;i<n-1;i++)
	{
		for(j=i+1;j<n;j++)
		{
			if(sing[i].w<sing[j].w)
			{
				t=sing[j].num,sing[j].num=sing[i].num,sing[i].num=t;
			}
		}
	}
	for(i=0;i<n;i++)
	{
		if(sing[i].num==k+1)
		{
			printf("%s",sing[i].s);
			break;
		}
	}
	return 0;
}
