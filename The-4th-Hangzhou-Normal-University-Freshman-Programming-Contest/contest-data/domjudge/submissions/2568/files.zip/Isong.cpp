#include <stdio.h>
struct num{
	int no;
	char name[16]; 
};
int main()
{
	struct num a[10001],t;
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%d %s",&a[i].no,&a[i].name);
	}
	scanf("%d",&k);
	for(i=0;i<n-1;++i)
	{
		for(j=0;j<n-i-1;++j)
		{
			if(a[j].no<a[j+1].no)
			{
				t = a[j];
				a[j] = a[j+1];
				a[j+1] = t;
			} 
		}
	}
	printf("%s",a[k].name);
	return 0;
} 
