#include<bits/stdc++.h>
using namespace std;
string wrus[1001],omg[1001];
int main () {
	int t,c,n,jud;
	char ch;
	cin>>t;
	getchar();
	for(int i = 1; i <= t; i++) {
		for(int j = 1; j <= n; j++) {
			wrus[j] = "";
		}
		n = 1;
		c = 1;
		while(1) {
			ch = getchar();
			if(ch=='.'||ch=='!'||ch=='?') {
				break;
			}
			if(ch==' ') {
				n++;
			} else {
				wrus[n]+=ch;
			}
		}
		for(int j = 1; j <= n; j+=2) {
			omg[j] = wrus[c];
			c++;
		}
		if(n%2==0) {
			for(int j = n; j >= 2; j-=2) {
				omg[j] = wrus[c];
				c++;
			}
		} else {
			for(int j = n - 1; j >= 2; j-=2) {
				omg[j] = wrus[c];
				c++;
			}
		}
		cout<<omg[1];
		for(int j = 2; j <= n; j++) {
			cout<<" "<<omg[j];
		}
		cout<<ch<<"\n";
		getchar();
	}
	return 0;
}
