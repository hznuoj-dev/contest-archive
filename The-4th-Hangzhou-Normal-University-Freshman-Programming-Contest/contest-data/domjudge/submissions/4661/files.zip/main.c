#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
struct song{
    long long int w[20];
    char name[20];
};which[100010];
int main(){
    int t,i,j,k,ccc;
    scanf("%d",&t);
    for(i=0;i<t;i++){
        scanf("%lld%s",which[i].w,which[i].name);
    }
    scanf("%d",&ccc);
    
    qsort(&a[0].w,t,sizeof(struct song),comp);
    
    printf("%s\n",which[ccc].name);
    
    return 0;
}
int comp(const void *p,const void *q){
    return (*(int *)q-*(int *)p);
}
