#include<stdio.h>
int main(){
  printf("This is an easy problem.\n");
  printf("a b c d e f!") ;
  return 0;
}
