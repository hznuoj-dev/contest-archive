#include<stdio.h>
#include<stdlib.h>
int main(){
	int t;int n,m,x,c=0,gg=0;int a[11][2];
	scanf("%d %d",&n,&m);
	for(t=0;t<n;t++){
		a[t][0]=3; 
	}
	for(t=0;t<n;t++){ 
		scanf("%d",&a[t][0]);
		if(a[t][0]==0)
		  scanf("%d",&a[t][1]);
	}
	for(t=0;t<n;t++){
		if(a[t][0]==2&&n>=2)
		  c=1;
	}
	if(c==1){
		printf("haoye");
	    return 0;
	}
	for(t=0;t<n;t++){
		if(a[t][0]==1)
		  c=1;
	}
	if(c==0){
		printf("QAQ");
	    return 0;
	}
	switch(m){
		case 0:m=2500;break;
		case 1:m=2101;break;
	}
	for(t=0;t<n;t++){
		if(a[t][1]>=m)
		  gg=1;
	}
	if(gg==1)
	  printf("haoye");
	else
	  printf("QAQ");
	return 0;
}
