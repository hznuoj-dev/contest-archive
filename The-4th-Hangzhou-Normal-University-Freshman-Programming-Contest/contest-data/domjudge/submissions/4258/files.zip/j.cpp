#include<bits/stdc++.h>
using namespace std;
int n,m,k,gong,g;
int a[3];
int main(){
	cin>>n>>m;
	for(int i=1;i<=n;i++){
		cin>>k;
		if(k==0){
			cin>>g;
			if(g>a[0])a[0]=g;
		}
		else a[k]++;						
	}
	
	if(m==0){
		if(a[2]!=0){
			if(n>=2)
			cout<<"haoye";
			else cout<<"QAQ";	
		}
		else if(a[0]>=2500&&a[1]!=0){
			cout<<"haoye";
		}
		else cout<<"QAQ";		
	}
	else{
		if(a[2]!=0){
			if(n>=2)
			cout<<"haoye";
			else cout<<"QAQ";	
		}
		else if(a[0]>2100&&a[1]!=0){
			cout<<"haoye";
		}
		else cout<<"QAQ";	
	}	
	return 0;
}
