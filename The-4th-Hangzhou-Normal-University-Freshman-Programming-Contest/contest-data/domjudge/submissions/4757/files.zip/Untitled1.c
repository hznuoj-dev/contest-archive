#include <stdio.h>
#include <string.h>
void swap(int *x,int *y){
	int t=*x;
	*x=*y;
	*y=t;
}
int a[10000];
char name[10000][17];
int main(void){
	char d[17];
	int k, n, i, j, max;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i],name[i]);
	}
	scanf("%d",&k);
	for(i=0;i<k+1;i++){
		max=i;
		for(j=i+1;j<n;j++){
			if(a[j]>a[max])
				max=j;
		}
		if(max!=i){
			swap(&a[i],&a[max]);
			strcpy(d,name[i]);
			strcpy(name[i],name[max]);
			strcpy(name[max],d);
		}
	} 
	printf("%s\n",name[k]);
}

