#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 

int main()
{
	int t,a,b;
	scanf("%d",&t);
	while(t--)
	{
		int flag=0;
		scanf("%d %d",&a,&b);
		if(b==0)
		{
			flag=0;
		}
		else if(b<=a-1)
		{
			flag=1;
		}
		if(flag==1)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}
