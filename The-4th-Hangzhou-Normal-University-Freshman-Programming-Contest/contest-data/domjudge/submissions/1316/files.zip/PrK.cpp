#include<bits/stdc++.h>
using namespace std;

int main (){
	int a;
	cin>>a;
	for(int i = 1; i <= a;i++){
		cout<<"Welcome to HZNU\n";
	}
	return 0;
}
