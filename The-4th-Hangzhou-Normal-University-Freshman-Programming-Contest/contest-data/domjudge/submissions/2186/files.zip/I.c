#include<stdio.h>
#include<string.h>
typedef struct
{
	int favour;
	char name[16];
}songs;

int main()
{
	int n;
	scanf("%d", &n);
	songs ary[1000];
		getchar();
	
		int i;
		for (i = 0; i < n; i++)
		{
			scanf("%d %s", &ary[i].favour, ary[i].name);
			getchar();
		}
		int j, l;
		for (j = 0; j < n - 1; j++)
		{
			for (l = j + 1; l < n; l++)
			{
				if (ary[j].favour < ary[l].favour)
				{
					int temp;
					temp = ary[j].favour;
					ary[j].favour = ary[l].favour;
					ary[l].favour = temp;

					char TEMP[16];
					strcpy(TEMP, ary[j].name);
					strcpy(ary[j].name, ary[l].name);
					strcpy(ary[l].name, TEMP);
				}
			}
		}
		int k;
		scanf("%d", &k);
		getchar();
		printf("%s\n", ary[k].name);
	
	return 0;
}