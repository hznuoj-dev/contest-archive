#include <stdio.h>
int main(void) {
	int n,m,flag1=0,x,atk,flag2=0,i;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&x);
		if(x==0){
			scanf("%d",&atk);
			if(m==0){
				if(atk>=2500)
					flag1=1;
			}
			else if(m==1){
				if(atk>2500)
					flag1=1;
			}
		}
		else if(x==1){
			if(flag1==1){
				flag2=1;
				break;
			}
			else break;
		}
		else if(x==2){
			if(n>=2){
				flag2=1;
				break;
			}
			else break;
		}
	}
	if(flag2==1){
		printf("haoye\n");
	}
	else printf("QAQ\n");
	return 0;
}

