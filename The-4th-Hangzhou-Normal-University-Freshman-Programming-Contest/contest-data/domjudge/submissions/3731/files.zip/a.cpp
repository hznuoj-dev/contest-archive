#include<cstdio>
int a[52];
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
	int	n;
		scanf("%d\n",&n);
		for(int i = 1;i<2*n;i++){
			char c;
			int p;
			scanf("%c",&c);
			if(c<='z'&&c>='a')
			{p = c-'a';
				a[p]++;
			}
			else if(c<='Z'&&c>='A'){
				p=c-'A'+26;
				a[p]++;
			}
		}
		int sum=0;
		for(int i=0;i<56;i++){
			sum+=a[i]/2;
			a[i]=0;
		}
		if(2*sum < n)printf("%d\n",sum*2+1);
		else printf("%d\n",sum*2);
	}
}
