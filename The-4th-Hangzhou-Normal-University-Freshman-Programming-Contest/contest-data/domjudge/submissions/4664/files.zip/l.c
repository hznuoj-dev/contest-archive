//l
#include<stdio.h>
int main(){
	int flag;
	long long t,n,x,count,num,turn;
	scanf("%lld",&t);
	while(t--){
		scanf("%lld %lld",&n,&x);
		flag=0;
		if(x==0){
			printf("no\n");
		}
		else{
			count=0;
			turn=0; 
			num=1000000000;
			while(num--){
				count=count+x;
				if(count>n-1){count=count-n;turn=1;}
				if(count==0){flag=1;break;}
				if(count==x&&turn==1){break;}
			//�ص���һ�� ���ߵ����յ� 
			}
			
			if(flag==1)printf("yes\n"); else printf("no\n");
		}
	}
} 
