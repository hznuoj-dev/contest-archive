#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int T,n,sum=0,k=0,i;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		int a[n];
		for(i=0;i<n;i++){
			scanf("%c",&a[i]);
		}
		while(sum==7777){
			for(i=0;i<n;i++){
			sum+=a[i];
			k++;
			}
		};
		printf("%d",k);
	}
	return 0;
}
