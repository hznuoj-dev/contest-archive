#include <bits/stdc++.h>
using namespace std;
struct ji{
	char first[3];
	char second[3];
	char third[3];
}a[6],b[6];
int sz(ji a){
	int s;
	if (a.first[1]=='_'){
		if (a.second[1]=='_'){
			if(a.second[0]== '|'){
				if(a.second[2 =='|']){
					if (a.third[1]=='_') s=8;
					else s=9;
				} else {
					if (a.second[0]=='|') s=6;
					else s=5;
				}
			}else {
				if (a.third[0]=='|') s=2;
			else s=3;
			}
		}else {
			if (a.second[0] == '|') s=0;
			else s=7;
		}
	}else {
		if (a.second[0]=='|') s=4;
		else s=1;
	}
	return s;
}
int main(){
	int s1,s2,i,j,as[6],bs[6],shi[3],dian[3];
	static int ca,cha[6];
	for (i=0;i<3;++i){
		for (j=0;j<6;++j){
			if (i==0) scanf("%s",a[j].first);
			if (i==1) scanf("%s",a[j].second);
			if (i==2) scanf("%s",a[j].third);
		}
	}
	for (i=0;i<3;++i){
		for (j=0;j<6;++j){
			if (i==0) scanf("%s",b[j].first);
			if (i==1) scanf("%s",b[j].second);
			if (i==2) scanf("%s",b[j].third);
		}
	}
	for (i=0;i<6;++i){
		as[i]=sz(a[i]);
		bs[i]=sz(b[i]);
		if (i%2==1){
			shi[i/2]=as[i]+as[i-1];
			dian[i/2]=bs[i]+bs[i-1];
		} 
	}
	s1=shi[0]*3600+shi[1]*60+shi[2];
	s2=dian[0]*3600+dian[1]*60+dian[2];
	if (s1>s2){
		cout<<"early"<<'\n';
		ca=s1-s2;
	}
	else if (s1<s2){
		cout<<"late"<<'\n';
		ca=s2-s1;
	}
	else cout<<"gang gang hao"<<'\n';
	cha[0]=(ca/3600)/10;
	cha[1]=(ca/3600)%10;
	cha[2]=((ca%3600) / 60)/10;
	cha[3]=((ca/3600) / 60)%10;
	cha[4]=(ca%60)/10;
	cha[5]=(ca%60)%10;
	for (i=0;i<3;++i){
		for (j=0;j<6;++j){
			if (i==0){
				if (cha[j]== 1 &&cha[j]==4) cout<<"   ";
				else cout<<" _ ";
			}else if (i==1){
				switch(cha[j]){
					case 0: cout<<"| |";break;
					case 1: cout<<"  |";break;			
					case 2: cout<<" _|";break;
					case 3: cout<<" _|";break;
					case 4: cout<<"|_|";break;
					case 5: cout<<"|_ ";break;
					case 6: cout<<"|_ ";break;
					case 7: cout<<"  |";break;
					case 8: cout<<"|_|";break;
					default:cout<<"|_|";break;
				}
			}else {
				switch(cha[j]){
					case 0: cout<<"|_|";break;
					case 1: cout<<"  |";break;			
					case 2: cout<<"|_ ";break;
					case 3: cout<<" _|";break;
					case 4: cout<<"  |";break;
					case 5: cout<<" _|";break;
					case 6: cout<<"|_|";break;
					case 7: cout<<"  |";break;
					case 8: cout<<"|_|";break;
					default:cout<<"  |";break;
				}
			}
		}
		cout<<'/n';
	}
	return 0;
} 
