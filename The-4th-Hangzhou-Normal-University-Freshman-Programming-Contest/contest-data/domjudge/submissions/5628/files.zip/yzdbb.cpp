#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
int a[100001];
int main () {
    cnm;
    int t;
    cin >> t; 
    while (t--){
    	int sum=0,ans=0;
    	int n;
    	cin >> n;
    	for (int i = 0 ; i<n ; i++)
    	 cin >> a[i];
        for (int i = 0 ; i<n ; i++){
        	sum+=a[i];
        	if (sum==7777) {
        		ans++;
        		sum=0;
			}
		}
		sum=0;
		for (int i = n-1 ; i>=0 ; i--){
			sum+=a[i];
			if (sum==7777) {
        		ans++;
        		sum=0;
			}
		}
		cout << ans <<endl;
	}
    return 0;
}
