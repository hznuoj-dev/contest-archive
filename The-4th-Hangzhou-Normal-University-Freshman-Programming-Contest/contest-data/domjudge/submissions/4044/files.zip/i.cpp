#include<stdio.h>
#include<stdlib.h>
struct song{
	int a[100000000];
	char b[16];
};
int comp(const void *p,const void *q){
	return ((struct song *)q)->a-((struct song *)p)->a;
}
int main(){
	struct song x[100000];
	int n,al,i;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%s %s",x[i].a,x[i].b);
	}
	scanf("%d",&al);
	qsort(x,n,sizeof(struct song),comp);
	for(i=al;i<n;i++){
		printf("%s\n",x[i].b);
	}
	return 0;
}
