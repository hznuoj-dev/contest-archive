#include<stdio.h>
#include<stdlib.h>
struct stu{
		long long int x;
		char a[20];
	};
	struct stu opp[100008],t;
int comp(const void *p,const void *q)
{
	return ((struct stu *)q)->x - ((struct stu *)p)->x;
}
int main()	
{	
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&opp[i].x,opp[i].a);
 }
	scanf("%d",&k);
	qsort(opp,n,sizeof(struct stu),comp);
	printf("%s\n",opp[k].a);
	return 0;
}
//#include<stdio.h>
//int main()
//{
//	int n,m,i,ac,flag=0,j;//ac�ǹ����� 
//	int type[15];
//	scanf("%d %d",&n,&m);
//	for(i=0;i<n;i++)
//	{
//		scanf("%d",&type[i]);
//		if(type[i]==0)
//		{
//			scanf("%d",&ac);
//		} 
//	}
//	if(n==0||n==1) printf("QAQ");
//    else
//    {
//    	for(i=0;i<n;i++)
//    	{
//    		if(type[i]==2)
//    		{
//    			flag=1;
//    			break;
//			}
//			if(type[i]==0)
//			{
//			 for(j=0;j<n;j++)
//			 {
//			 	if(type[j]==1)
//			 	{
//			 		if(m==0&&ac>=2500)
//			 		{
//			 			flag=1;
//			 			break;
//					 }
//					 if(m==1&&ac>2100)
//					 {
//					 	flag==1;
//					 	break;
//					 }
//					 
//				}
//			 }
//			 if(flag==1) break;
//			}
//		}
//		if(flag==1) printf("haoye\n");
//		else printf("QAQ\n");
//	}
//	return 0;
// } 

