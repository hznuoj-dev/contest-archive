#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct Stu{
	char name[20];
	long long int num;
};
int cmp(const void *p,const void *q)
{
	struct Stu *pp=(struct Stu *)(p);
	struct Stu *pq=(struct Stu *)(q);
	long long int a=pp->num;
	long long int b=pq->num;
	return b-a; 
}
int main()
{
	struct Stu a[10010];
	long long int t,i=0,n,sum;
	scanf("%lld",&t);
	sum=t;
	while(t--)
	{
		 
			scanf("%lld%s",&a[i].num,a[i].name);
			i++;
		
		
	}
	
	qsort(a,sum,sizeof(struct Stu),cmp);
	scanf("%lld",&n);
	printf("%s\n",a[n].name); 
}
