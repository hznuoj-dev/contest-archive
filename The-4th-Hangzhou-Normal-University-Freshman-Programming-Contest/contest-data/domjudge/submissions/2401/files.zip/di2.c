#include<stdio.h>
#include<stdlib.h>
struct xxx{
	long int a;
	char y[16];
};
int comp(const void *p,const void *q){
	return ((struct xxx *)q)->a - ((struct xxx *)p)->a;
}
int main(void)
{
	int a,b,c,n,m;
	scanf("%d",&a);
	struct xxx x[a];
	for(b=0;b<a;b++)
	{
		scanf("%d%s",&x[b].a ,&x[b].y );
	}
	scanf("%d",&n);
	qsort(x,a,sizeof(struct xxx),comp);
	printf("%s",x[n].y );
	return 0;
	
	
}

