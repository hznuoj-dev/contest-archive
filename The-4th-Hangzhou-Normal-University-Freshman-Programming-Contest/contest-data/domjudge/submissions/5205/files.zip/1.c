#include<stdio.h>
#include<string.h>
int main(){
	int T;
	scanf("%d",&T);
	getchar();
	while(T--){
		int i=1;
		char s[1666][66];
		char t;
		while(scanf("%s",s[i]),t=(getchar())!='\n'){
			i++;
		}
		int len;
		int j;
		len=strlen(s[i]);
		//printf("%d\n",len);
//		for(j=1;j<=i;j++){
//			printf("%s ",s[j]);
//		}
		int c;
		int g;
		for(c=1;c<=(i/2);c++){
			printf("%s ",s[c]);
			if(i-c+1==i){
				for(g=0;g<len-1;g++){
					printf("%c",s[i+c-1][g]);
				}
				printf(" ");
			}
			else{
				printf("%s ",s[i-c+1]);
			}
			
		}
		
		if(i%2!=0){
			printf("%s",s[(i+1)/2]);
			printf("%c\n",s[i][len-1]);
		}
		else{
			printf("%c\n",s[i][len-1]);
		}
	}
	return 0;
} 
