#include<stdio.h>

int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m,i;
		scanf("%d%d",&n,&m);
		if(n>=m&&m!=0) printf("yes\n");
		if(m==0) printf("no\n");
		if(n<m&&m!=0){
			if(m%n==0) printf("yes\n");
			for(i=n-1;i>0;i--){
				if(m%i==0){
					printf("no\n");
					break;
				}
			}
		}
	} 
	return 0;
}

