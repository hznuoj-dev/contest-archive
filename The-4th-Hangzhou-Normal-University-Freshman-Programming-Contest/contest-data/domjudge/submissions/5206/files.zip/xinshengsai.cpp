#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int compare(const void* a,const void* b){
	int* pa = (int*)a;
	int* pb = (int*)b;
	int num1 = *pa;
	int num2 = *pb;
	return num2 - num1;
}
struct student{
	int n;
	char str[20];
};
int main()
{
	int n;
	scanf("%d",&n);
	struct student a[n];
	int pp[n];
	for(int i=0;i<n;i++){
		scanf("%d %s",&a[i].n,a[i].str);
	}
	int k;
	scanf("%d",&k);
	for(int i=0;i<n;i++) pp[i]=a[i].n;
	qsort(pp,n,sizeof(int),compare);
	
	for(int i=0;i<n;i++)
	{
		if(a[i].n==pp[k])
		{
			printf("%s\n",a[i].str);
			break;
		}
	}

	return 0;
}
