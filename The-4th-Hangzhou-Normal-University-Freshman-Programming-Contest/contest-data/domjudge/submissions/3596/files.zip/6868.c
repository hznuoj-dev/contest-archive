#include<stdio.h>
#include<string.h>
#include<math.h>
typedef struct song{
	int love;
	char name[16];
}song;
	int cmp(const void *p, const void *q){
 song xx = *(song *)p ;
 song yy = *(song *)q ;
 return yy.love-xx.love ;
}
int main(){
	int i,n,k,j,t,m,flag;;
	char n1[16];
	scanf("%d",&n);
	song a[n+1];
	for(i=0;i<n;i++){
		scanf("%d",&a[i].love);
		scanf("%s",a[i].name );
}
	scanf("%d",&k);
	qsort(a,n,sizeof(song),cmp);
	printf("%s",a[k].name );
	
	return 0;
} 
