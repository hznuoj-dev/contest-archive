#include <stdio.h>
int num[10], k[1001];

int main() {
	int n, m, i, j, p = 0;
	scanf("%d %d", &n, &m);
	for (i = 0; i < n; ++i) {
		scanf("%d", &num[i]);
		if (num[i] == 0)
			scanf(" %d", &k[i]);
	}


	for (i = 0; i < n; ++i) {
		if (num[i] == 2 && n > 1)
			p = 1;

		if (num[i] == 0) {
			if (m == 0 && k[i] >= 2500) {
				for (j = 0; j < n; ++j) {
					if (num[j] == 1)
						p = 1;

				}
			}
			if (m == 1 && k[i] > 2100) {
				for (j = 0; j < n; ++j) {
					if (num[j] == 1)
						p = 1;



				}

			}
		}

	}
	if (p == 0)
		printf("QAQ");
	if (p == 1)
		printf("haoye");
}
