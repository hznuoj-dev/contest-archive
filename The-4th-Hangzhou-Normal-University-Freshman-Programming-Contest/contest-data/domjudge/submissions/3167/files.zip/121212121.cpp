#include<stdio.h>
int main()
{
	long long int t,n,i,num[200]={0};
	char   s[100000];
	scanf("%lld",&t);
	while(t--)
	{
		long long int sum=0;
	scanf("%lld",&n);	
	for(i=0;i<n;i++)
    {	scanf("%s",&s[i]);	
		num[int(s[i])]++; 
	}	
	long long int max=0;
    for(i=0;i<200;i++)
    {
      if(num[i]%2!=0&&num[i]>max)	
      {
		 max=num[i];
	  }	
	}
	sum+=max;
	 for(i=0;i<200;i++)
    {
      if(num[i]%2==0)	
      {
		 sum+=num[i];
	  }	
	}
	printf("%lld\n",sum);
	}
	return 0;
 } 
