#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
int main(void){
	int x,i,j;
	scanf("%d",&x);
	for(i=1;i<=x;++i){
		printf("Welcome to HZNU\n");
	}
	
	
	
	
	
	
	
	
	return 0;
} 
