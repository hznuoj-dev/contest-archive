#include<stdio.h>
#include<string.h>
char b[20000][15];
int main(){
	int n,k,p;
	char x[2][15];
	scanf("%d",&n);
	int a[n+10];
	for(int z=0;z<n;z++){
		strcpy(x[0],x[1]);
		getchar();
		scanf("%d %s",&a[z],b[z]);
	}
	getchar();
	scanf("%d",&k);
	for(int z=0;z<n-1;z++){
		for(int j=0;j<n-1;j++){
			if(a[j]<a[j+1]){
				p=a[j];
				a[j]=a[j+1];
				a[j+1]=p;
				strcpy(x[0],b[j]);strcpy(b[j],b[j+1]);strcpy(b[j+1],x[0]);
			}
		}
	}
	printf("%s",b[k]);
	return 0;
}
