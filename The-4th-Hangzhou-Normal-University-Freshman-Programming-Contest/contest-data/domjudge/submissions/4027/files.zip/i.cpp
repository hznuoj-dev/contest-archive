#include<stdio.h>
#include<stdlib.h>
struct a{
	long long int w;
	char s[18];
};
int comp(const void *p,const void *q){
	return ((struct a*)p)->w-((struct a*)q)->w;
}

int main(){
	int n,k;
	scanf("%d",&n);
	struct a a1[10005];
	for(int i=0;i<n;i++){
		scanf("%lld %s",&a1[i].w,a1[i].s);
	}
	scanf("%d",&k);
	qsort(a1,n,sizeof(struct a),comp);
	
		printf("%s",a1[n-k-1].s);
	
}