#include<stdio.h>
int main(){
	int n,t,i,w,q,sum;
	int a[100000];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		w=0;
		q=0;
		sum=0;
		for(i=0;i<n;i++){
			sum+=a[i];
			if(sum==7777){
				w++;
				q++;
				i=w-1;
				sum=0;
			}
		}
		printf("%d",q);
	}
	return 0;
}
