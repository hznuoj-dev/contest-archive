#include<stdio.h>
int main(void){
	int n,i,t;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&i);
		if(i==0)
		printf("no");
		else
		printf("yes");
	}
	return 0;
} 
