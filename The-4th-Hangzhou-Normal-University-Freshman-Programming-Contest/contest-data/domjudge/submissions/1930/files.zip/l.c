#include<stdio.h>
int main() {
	int T,n,x;
	scanf("%d", &T);
	while (T--) {
		scanf("%d%d", &n, &x);
		if (x > 0) {
			printf("yes\n");
		else {
			printf('no\n')
		}
		}
	}
	return 0;
}
