#include<stdio.h>
int main(void){
	int t,n,x,sum,m;
	scanf("%d",&t);
	while(t--){
		sum=0;
		scanf("%d %d",&n,&x);
		if(x==0) printf("no\n");
		else   printf("yes\n");
		
	}
	return 0;
} 
