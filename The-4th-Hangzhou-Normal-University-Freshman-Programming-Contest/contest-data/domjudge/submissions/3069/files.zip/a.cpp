#include<bits/stdc++.h>
using namespace std;
map<char,int> mp;
int main()
{

	char c;
	int N;
	int tmp;
	int cnt=0;
	cin>>N;
	int n;
	while(N--)
	{
		cin>>n;
		tmp=n;
		while(n--)
		{
			cin>>c;
			mp[c]++;
			if(mp[c]%2==0)
			{
				mp[c]-=2;
				cnt+=2;
				tmp=tmp-2;
			}
		}
		if(tmp==0)
		{
			cout<<cnt<<'\n';
		}
		else
		{
			cout<<cnt+1<<'\n';			
		}

	}
	
}
