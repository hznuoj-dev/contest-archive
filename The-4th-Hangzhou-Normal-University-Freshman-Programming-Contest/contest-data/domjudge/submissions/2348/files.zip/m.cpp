#include<stdio.h>
int main(){
	int t,i;
	long long int n,x,s=0;
	scanf("%d",&t);
	getchar();
	for(i=0;i<t;i++){
		scanf("%lld %lld",&n,&x);
		getchar();
		if(x==0){
			printf("no\n");
		}
		else{
			printf("yes\n");
		}
}
	return 0;
}

