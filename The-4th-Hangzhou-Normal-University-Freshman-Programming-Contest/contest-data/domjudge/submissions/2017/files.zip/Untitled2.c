#include<stdio.h>
#include<stdlib.h>
int main()
{
	int n,x,t,i,k=1,ans;
	scanf("%d",&t);
	while(t--)
	{
 	    scanf("%d%d",&n,&x);
 	    x%=n;
 	    ans=0;
 	    if(x==0)
 	    {
 	    	ans=0;
		}
 	    else
		 {
		 	for(i=0;i<n*n;i++)
 	        {
 	    	k=(k+x)%n;
 	    	if(k==1)
 	    	{
 	    		ans=1;
 	    		break;
			}
		    }
		 }
		if(ans==0)
		    printf("no\n");
		else
		    printf("yes\n");
    }
} 
 
