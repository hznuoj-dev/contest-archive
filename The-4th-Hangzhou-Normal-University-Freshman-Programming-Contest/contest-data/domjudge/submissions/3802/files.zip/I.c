#include<stdio.h>
#include<stdlib.h>
struct ge{
	int love;
	char name[20];
}m;
int compare(const void*p,const void*q){
	m *c=(m*)p,*d=(m*)q;
	return d->love-c->love;
}
int main(){
	int n,k,i,j;
	scanf("%d",&n);
	struct ge a[n];
	struct ge t;
	for(i=1;i<=n;i++)scanf("%d%s",&a[i].love,a[i].name);
	scanf("%d",&k);
	qsort(ge,n,sizeof(m),compare);
	printf("%s",ge[k].name);
	return 0;
}
