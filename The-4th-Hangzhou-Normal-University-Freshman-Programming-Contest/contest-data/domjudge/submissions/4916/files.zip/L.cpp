#include<iostream>
#include<string>
#include<algorithm>
#include<map>
using namespace std;
int main() {
	int n;
	cin >> n;
	map<int, string>m;
	while (n--) {
		int a;
		string b;
		cin >> a >> b;
		m.insert({ a,b });
	}
	int k;
	cin >> k;
	auto it = m.end();
	for (int i = 0; i < k; i++) {
		it--;
	}
	it--;
	cout << it->second << endl;
}