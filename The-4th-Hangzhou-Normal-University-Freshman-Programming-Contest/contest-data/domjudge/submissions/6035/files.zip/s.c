#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int a[100010];
int sum(int *a,int n){
	int i,co=0,j,s=0,k;
	if(n){
		for(k=0;k<n;k++){
	     for(i=0;i<n-k;i++){
		  co=0;
		  for(j=0;j<=i;j++){
			co=co+*(a+k+j);
		  }
		  if(co==7777)s++;
	    }
	   }

	return s;
}
}
int cmp(const void *a,const void *b){
	int *p=(int *)a;
	int *q=(int *)b;
	return *p-*q;
}
int main(){
	int t,n,i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		
	}
	
	printf("%d",sum(a,n));
	qsort(a,n,sizeof(a[0]),cmp);
}
}