#include <stdio.h>
int main (){
	int T,n,flag[100001],s=0;
	char a[100001];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		getchar();
		s=0;
		for(int i=1;i<=n;++i){
			scanf("%c",&a[i]);
			getchar();
			flag[i]=0;
		}
		for(int i=1;i<n;++i){
			flag[i]=1;
			for(int j=i+1;j<=n;++j){
				if(flag[j]==0&&(a[j]==a[i])){
					flag[j]=1;
					s+=2;
					break;
				}
			}
		}
		if(s==n){
			printf("%d\n",s);
		}
		else{
			printf("%d\n",s+1);
		}
	}
} 
