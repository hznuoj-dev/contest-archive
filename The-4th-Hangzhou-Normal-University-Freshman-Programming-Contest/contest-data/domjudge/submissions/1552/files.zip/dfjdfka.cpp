#include<bits/stdc++.h>
using namespace std;
void solve(){
	int n, ans=0;
	cin>>n;
	map<char,int>mp;
	for(int i=0;i<n;i++){
		char ch;cin>>ch;
		mp[ch]++;
	}
	for(auto x:a){
		if(x.second%2==0)ans+=x.second;
		else ans+=x.second-1;
	}
	if(ans!=n)ans++;
	cout<<ans<<'\n';
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
