#include <stdio.h>

struct song{
	int number;
	char a[16];
};
int main(void){
	struct song array[100001];
	struct song temp;
	int n,i,pass,exchange,k;
	scanf("%d",&n);
	for(i=0;i<n;++i){
		scanf("%d %s",&array[i].number,array[i].a);
	}
	scanf("%d",&k);
	for(pass=1;pass<n;++pass){
		exchange=0;
		for(i=0;i<n-pass;++i){
			if(array[i].number<array[i+1].number){
				temp=array[i];
				array[i]=array[i+1];
				array[i+1]=temp;
				exchange=1;
			}
		}
		if(exchange==0)
			break;
	}
		printf("%s",array[k].a);
	return 0;
}
