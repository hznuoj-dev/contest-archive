#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct Stu{
	char name[22];
	int num;
};
int cmp(const void *p,const void *q)
{
	struct Stu *pp=(struct Stu *)(p);
	struct Stu *pq=(struct Stu *)(q);
	int a=pp->num;
	int b=pq->num;
	return b-a; 
}
int main()
{
	struct Stu a[14001];
	int t,i,n,sum;
	scanf("%d",&t);
	sum=t;
	while(t--)
	{
		 
			scanf("%d%s",&a[i].num,a[i].name);
			i++; 
		
		
	}
	
	qsort(a,sum,sizeof(struct Stu),cmp);
	scanf("%d",&n);
	printf("%s",a[n].name); 
}
