#include<stdio.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
int cmp(const void *p,const void *q)
{
	int *a = (int*)p;
	int *b = (int*)q;
	return *a-*b;
}
int main()
{
	int T,n,i,j,k;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		int a[n],cnt=0,sum;
		for(i=0;i<n;++i)
		{
			scanf("%d",&a[i]);
		}
		qsort(a,n,sizeof(int),cmp);
		for(i=0;i<n;++i)
		{	
		 	sum=0;
		 	for(j=i;j<n;++j)
		 	{
		 		if(sum + a[j] == 7777)
		 		{
		 			cnt++;
				}
				else if(sum + a[j] < 7777)
				{
					sum+= a[j]; 
				}
				
			}
		}
		printf("%d\n",cnt);
		cnt = 0;
	}
}
