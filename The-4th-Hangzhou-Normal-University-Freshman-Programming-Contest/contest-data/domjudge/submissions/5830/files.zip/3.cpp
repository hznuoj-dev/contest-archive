#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		long int n,a[100000],sum=0,time=0;
		scanf("%ld",&n);
		for(int i=0;i<n;i++){
			scanf("%ld",&a[i]);
		}
		for(int i=0;i<n;i++){
			sum=a[i];
			for(int j=i+1;j<n;j++){
				sum=sum+a[j];
			    if(sum==7777){
				    time++;
				    break;
			    }
			}
		}
		printf("%ld\n",time);
	}
	return 0;
}
