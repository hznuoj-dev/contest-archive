#include<stdio.h>
#include<conio.h>
int main(void){
	int n;
	scanf("%d",&n);
	while(n--)
		printf("Welcome to HZNU\n");
	getch();
	return 0;
}