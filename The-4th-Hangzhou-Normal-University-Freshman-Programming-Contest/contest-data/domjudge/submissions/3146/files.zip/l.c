#include <stdio.h>
#include <string.h>

struct number {
	long long int w;
	char s[16];

};

int main() {
	int n, i, j;
	scanf("%d", &n);
	struct number a[100];
	for (i = 0; i < n; i++) {
		scanf("%lld%s", &a[i].w, a[i].s);
	}
	for (i = 0; i < n - 1; i++) {
		for (j = 0; j < n - i - 1; j++) {
			if (a[j].w < a[j + 1].w) {
				char change[21];
				int m = a[j + 1].w;
				a[j + 1].w = a[j].w;
				a[j].w = m;
				strcpy(change, a[j + 1].s);
				strcpy(a[j + 1].s, a[j].s) ;
				strcpy(a[j].s, change);
			}
		}
	}
	int k;
	scanf("%d", &k);
	printf("%s\n", a[k].s);
}

