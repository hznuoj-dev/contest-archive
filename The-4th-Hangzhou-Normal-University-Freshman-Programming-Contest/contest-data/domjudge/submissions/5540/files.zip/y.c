#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct song {
	long long love;
	char s[20];
};
int com(const void*a,const void *b){
	return ((struct song*)b)->love - ((struct song *)a)->love;
}
struct song a[100001],e;
int main (){
int n;
int i,j;
int len;
char s[1001][101],c;
int k;
scanf("%d",&n);
getchar();
while(n--){
	i=0;
	while(scanf("%s",s[i])){
		len=strlen(s[i]);
		if(s[i][len-1]=='.'||s[i][len-1]=='!'||s[i][len-1]=='?'){
			c=s[i][len-1];
			s[i][len-1]='\0';
			break;
		}
		i++;

	}
	k=i;
	if(k%2==0){
	for(i=0;i<=k/2;i++){
		if(i==k/2){
			printf("%s%c\n",s[i],c);
		}
		else
		printf("%s %s ",s[i],s[k-i]);
	}
	}
	else{
		for(i=0;i<=k/2;i++){
		printf("%s %s",s[i],s[k-i]);
		if(i!=k/2)
			printf(" ");
	    }
		printf("%c\n",c);
	}
}
}