#include<stdio.h>
#include<math.h>
int main()
{
	int cnt,t,n,i,b,a;
	scanf("%d",&t);
	while(t--)
	{
		a=0;
		cnt=0;
		scanf("%d",&n);
		while(n--)
		{
			scanf("%d",&b);
			a^=b;
			if(a==a)
			{
				cnt++;
			}
		}
		printf("%d",1+2*cnt);
	}
	return 0;
}
