#include <bits/stdc++.h>
using namespace std;

struct node
{
	int p;
	string s;
}a[100001];

bool op(node a,node b)
{
	return a.p<b.p;
}


int main()
{
	int n;
	int i,j,k,num; 
	int t1;
	string t2;
	
	cin >> n;
	for(i=1;i<=n;i++)
		cin >> a[i].p >> a[i].s;
	cin >> num;
	sort(a+1,a+n,op);
	
	cout << a[n-num].s;
	return 0;
}
