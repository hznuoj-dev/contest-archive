#include<bits/stdc++.h>
using namespace std;
const int b=1e5+10;
char ch,s[b];
static int a[b];
int main(void){
	int t,n,ans;
	int sin1,sin2,dou;
	dou=0;
	ans=0;
	scanf("%d",&t);
	
	for(int i=1;i<=t;i++){
		scanf("%d",&n);
		getchar();
		int j=1;sin1=sin2=0;dou=0;
		while (j<=n){
			int k=1;
			scanf("%c",&ch);
			getchar();
			s[j]=ch;
			while (k<j){
				if (s[j]==s[k]){
					a[k]++;
					n--;j--;
					break;
				}
				k++;
			}
			if (k==j) a[j]++;
			j++;		
		}
		for (int h=1;h<=n;h++){
			if (a[h]%2==0) dou++;
			else if (a[h]>1) sin1++;
			else sin2++;
		}
		ans=dou+sin1+1;
		printf("%d\n",ans);
	}
	return 0;
}

