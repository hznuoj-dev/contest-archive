#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
struct zi{
	int xu;
	char ci[40];
}a[1010];
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int t=0,tt=1,max=0;
		char s;
		getchar();
		s=getchar();
	while(s!='.'&&s!='!'&&s!='?'){
//		a[tt].ci[t]=s;
		if(s==' ') {
			if(t>max) max=t;
			t=0;
			tt++;
		}else{
			a[tt].ci[t]=s;
			t++;
		}
		s=getchar();
	}
	if(tt%2==0){
		for(int j=1;j<=tt/2;j++){
		printf("%s ",a[j].ci);
		if(j!=tt/2) printf("%s ",a[tt-j+1].ci);
		else printf("%s",a[tt-j+1].ci);
    	}
	}else{
		for(int j=1;j<=tt/2;j++){
		printf("%s ",a[j].ci);
		printf("%s ",a[tt-j+1].ci);
	    }
	    printf("%s",a[tt/2+1].ci);
	}
	printf("%c\n",s);
//	for(int j=1;j<=t;j++){
//		printf("%s",a[j].ci);
//	}
for(int k=1;k<=tt;k++){
	for(int kk=0;kk<=30;kk++){
		a[k].ci[kk]='\0';
	}
}
	}
	return 0;
}
