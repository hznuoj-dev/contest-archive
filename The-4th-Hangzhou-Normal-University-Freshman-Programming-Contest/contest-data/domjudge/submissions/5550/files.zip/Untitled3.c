#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int cmp(const void *p,const void *q)
{
	return *(char *)q-*(char *)p;
}
int main()
{
	int T,n,i,sum,max1,max2;
	char a[500000];
	scanf("%d",&T);
	while(T--)
	{
		sum=1,max1=0,max2=0;
		scanf("%d",&n);
		getchar();
		gets(a);
		qsort(a,2*n-1,sizeof(char),cmp);
		for(i=1;i<strlen(a);i++)
		{
			if(a[i-1]!=' ')
			{
				if(a[i]==a[i-1])
					sum++;
				else
				{
					if(sum%2==0)
						max1+=sum;
					else if(sum%2==1)
					{
						if(sum>max2)
						max2=sum;
					}
					sum=1;	
				}
			}
		}
		printf("%d\n",max1+max2);
	}
	return 0;	
} 
