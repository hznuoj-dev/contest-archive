#include "stdio.h"
int main(void)
{
	int n;
	scanf("%d",&n);
	while(n--)
	{
		if(n!=0)
		printf("Welcome to HZNU\n");
		else
		printf("Welcome to HZNU");
	}
	return 0;
}
