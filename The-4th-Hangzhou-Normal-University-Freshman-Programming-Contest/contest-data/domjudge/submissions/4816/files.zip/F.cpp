#include <bits/stdc++.h>
using namespace std;
int a[21][21],b[21][21];

int main(){
	int t,i,n,j,k,s;
	int x,y,z;
	cin>>t;
	for (i=0;i<t;++i){
		cin>>n;
		x=y=z=1;
		s=0;
		for (j=1;j<=n;++j){
			for (k=1;k<=n;++k){
				cin>>a[j][k];
			}
		}
		for (j=1;j<=n;++j){
			for (k=1;k<=n;++k){
				cin>>b[j][k];
				if (b[j][k] !=a[n-j+1][n-k+1] ) y=0;
				if (b[j][k] !=a[n-k+1][j]) x=0;
				if (b[j][k] !=a[k][n-j+1]) z=0;
			}
		}
		if (y==1) s=2;
		if (x==1 || z==1) s=1;
		if (s==0) cout<<"-1";
		else cout<<s<<'\n';
	}
	return 0;
}
