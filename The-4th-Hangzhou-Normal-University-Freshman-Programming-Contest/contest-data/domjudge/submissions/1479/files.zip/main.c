//
//  main.c
//  欢迎来到杭师大
//
//  Created by 徐文哲 on 2021/12/12.
//

#include <stdio.h>

int main(int argc, const char * argv[]) {
    int n,i;
    scanf("%d",&n);
    for (i=0; i<n; i++) {
        printf("Welcome to HZNU\n");
    }
    
    return 0;
}
