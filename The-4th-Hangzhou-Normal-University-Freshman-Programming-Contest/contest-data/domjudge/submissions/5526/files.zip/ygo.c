#include<stdio.h>
int main()
{
	int n, m;
	int x, k;
	int flag1 = 0;
	int flag2 = 0;
	int flag3 = 0;
	scanf("%d %d", &n, &m);
	int sp = n;
	while (n--)
	{
		scanf("%d", &x);
		if (x == 0)
		{
			scanf("%d", &k);
			if (m == 0 && k >= 2500)
			{
				sp = sp - 1;
				flag1 = 1;
			}
			else if (m == 1 && k >= 2100)
			{
				sp = sp - 1;
				flag1 = 1;
			}
		}
		else if (x == 1)
			flag2 = 1;
		else if (x == 2 && flag1 == 0 && sp != 1)
		{
			printf("haoye");
			flag3 = 1;
			break;
		}
		if (flag2 == 1 && flag1 == 1)
		{
			printf("haoye");
			flag3 = 1;
			break;
		}
	}
	if (flag3 == 0)
		printf("QAQ");
}