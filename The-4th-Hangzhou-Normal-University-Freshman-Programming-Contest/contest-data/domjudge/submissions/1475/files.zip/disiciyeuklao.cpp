#include<stdio.h>
#include<string.h>
int main() {
	int n,i;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		printf("Welcome to HZNU\n");
	}
}
