#include<stdio.h>
#include<string.h>
int main(){
	int t,n,a[100000];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int i,j,k=0;
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			int sum=0;
			for(j=i;j<n;j++){
				sum=sum+a[j];
				if(sum==7777){
					k++;
				}
			}
		}
		printf("%d\n",k);
	}
}
