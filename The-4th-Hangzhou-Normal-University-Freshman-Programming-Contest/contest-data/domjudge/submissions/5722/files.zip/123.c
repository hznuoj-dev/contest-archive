//
//#include<stdio.h>
//int main()
//{
//	int n,m;
//	scanf("%d %d",&n,&m);//n�����ƣ�m��Ӣ�۱�����ʽ 
//    int i;
//    int a[20];
//    int k;
//    int attach=0;
//    
//    for(i=0;i<n;i++)
//    {
//		scanf("%d",&a[i]);
//		if(a[i]==0)
//		{
//			scanf("%d",&k);
//			attach=k+attach;
//			//k��ʾ������ 
//		}
//		
//	}
//	if(m==0)
//	{
//		if(attach>=2500)
//		printf("haoye\n");
//		else 
//		printf("QAQ\n");
//	} 
//	else if(m==1)
//	{
//		if(attach>2100)
//		printf("haoye\n");
//		else 
//		printf("QAQ\n");
//	}
//	return 0;
//}
//#include<stdio.h>
//#include<string.h>
//int main()
//{
//	int t;
//	scanf("%d",&t);
//	while(t--)
//	{
//	  char a[60000];
//	  scanf("%[^\n]",a[60000]);
//	  char *p;
//	  strtok(a," ");
//	  while(p) 
//	  {
//	  	
//	  }
//
//	}
//}
//#include<stdio.h>
//int main()
//{
//	int t;
//	scanf("%d",&t);
//	while(t--)
//	{
//		int n,x;
//		scanf("%d %d",&n,&x);
//		if(n%x==0)
//		printf("yes\n");
//		else if(n*2%x==0)
//		printf("yes\n");
//		else 
//	}
//}
//#include<stdio.h>
//#include<stdlib.h>
//struct acm
//{
//	int a;
//	int b;
//};
//struct nb
//{
//	int c;
//	char d;
//	int e;
//};
//int main()
//{
//	int n;
//	int give=0;
//	struct acm math[3000];
//	struct nb die[3000];
//	scanf("%d",&n);//n��ʾ�м�����Ʒ 
//    int i;
//    for(i=0;i<n;i++)
//    {
//		scanf("%d %d",&math[i].a,&math[i].b);
//	}
//	int q;
//	int j=0;
//	int x=0,y=0;
//	scanf("%d",&q);
//	for(i=0;i<q;i++)
//	{
//		scanf("%d %c %d",&die[i].c,&die[i].d,&die[i].e);
//		if(c==1&&d=="X")
//		{
//		x=die[i].e;
//		}
//		if(c==1&&d=="Y")
//		{
//		y=die[i].e;
//		}
//		if(c==2&&d=="X")
//		{
//			
//		}
//	}
//
//}   
//#include<stdio.h>
//int main()
//{
//	int n,m;
//	scanf("%d %d",&n,&m);
//	int a[20][1000000];
//	int i,j;
//	for(i=0;i<n;i++)
//	{
//		for(j=0;j<m;j++)
//		{
//			scanf("%d",&a[i][j]); 
//		}
//	}
//	int ans[100000];
//	int g=0;
//	int p=0,q=0;
//	for(j=0;i<m;j++)
//	{
//		for(i=0;i<n-1;i++)
//		{
//			p=a[i][j];
//			q=a[i+1][j];
//			ans[g]=abs(p-q);
//			p
//		} 
//	}
//}
//#include<stdio.h>
//int main()
//{
//	int t;
//	scanf("%d",&t);
//	while(t--)
//	{
//		int n;
//	     int i,j;
//	     int  flag=0;
//	     for(i=0;i<n;i++)
//	     for(j=0;j<n;j++)
//		{
//			int a[30][30];
//			scanf("%d",&a[i][j]);
//		}
//	
//		for(i=0;i<n;i++)
//		for(j=0;j<n;j++)
//		{
//			int b[30][2];
//			scanf("%d",&b[i][j]);
//		}
//		for(i=0;i<n;i++)
//		for(j=0;j<n;j++)
//		{
//			if(a[i][j]==b[i][j])
//			flag++; 
//		}
//		if(flag==4)
//		printf("0\n");
//		else
//		{
//			for(i=1;i<=4;i++)
//			{
//				int t;
//				
//			}
//		}
//	}
//	
//}
#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,m;
		scanf("%d %d",&n,&m);
		if(m!=0)
		printf("yes\n");
		else
		printf("no\n");
		
	}
	return 0;
}
