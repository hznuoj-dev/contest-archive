# include <stdio.h>

int main(void)
{
	int t;
	long int n, x, a = 0, flag = 0;

	scanf("%d", &t);

	for(t; t>0; t--)
	{
		scanf("%ld %ld", &n, &x);
	

		
		if(x == 0)
		{
			printf("no\n");
		
			continue;
		}
		a = 0;
		flag = 0;
		a = a + x;

		while(a != 0)
		{

			if(n % x == 0)
			{
				printf("yes\n");
				break;
			}


			if(a+x <= n-1)
				a = a + x;

			if(a+x > n-1)
			{
				a = x-(n-1-a)-1;
			
				if(flag == 0)
				{
					flag = a;
					continue;
				}
				if(flag == a)
				{
					printf("no\n");
					break;
				}
			}
			if(a == 0)
				printf("yes\n");
		

		}
	}

	return 0;
}