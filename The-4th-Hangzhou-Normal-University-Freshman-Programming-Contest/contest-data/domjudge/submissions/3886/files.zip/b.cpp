#include<bits/stdc++.h>
#define wtn tql
using namespace std;
int a[100010];
int main(void){
int t;cin>>t;
while(t--){
	int n;cin>>n;
	for(int i=0;i<n;i++)cin>>a[i];
	//sort(a,a+n);
	int re=0;
	for(int i=0;i<n;i++){
		int sum=a[i];		
		for(int u=i+1;u<n;u++){
			sum+=a[u];
			if(sum==7777)re++;
			if(sum>=7777)break;
		}
	}
	cout<<re<<endl;
}
return 0;
}

