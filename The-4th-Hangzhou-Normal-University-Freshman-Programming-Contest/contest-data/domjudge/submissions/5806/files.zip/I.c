#include<stdio.h>
int main()
{
	int n, m;
	long long t[10000],temp;
	char ch[100][100];
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{

		scanf("%lld", &t[i]);

		scanf("%s", ch[i]);

	}
	for (int j = 0; j < n - 1; j++)
	{
		for (int i= 0; i < n - 1 - j; i++)
		{
			if (t[i] > t[i + 1])
			{
				temp = t[i];
				t[i] = t[i + 1];
				t[i + 1] = temp;
			}
		}
	}
	scanf("%d", &m);
	
	for (int j = 0; j < n - m; j++)
	{

		printf("%s\n", ch[j]);

	}

	return 0;
}
