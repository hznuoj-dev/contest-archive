#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		scanf("%d",&n);
		int a[n],i;
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		int j,cnt=0,m=n;
		for(j=0;j<n;j++){
			for(i=j+1;i<n;i++){
				if(a[j]==a[i])
				cnt=1;
			}
			if(cnt==0)
			m--;
		}
		if((n-m)==1)
		printf("%d\n",n);
		else
		printf("%d\n",m);
	}
	return 0;
} 
