#include<stdio.h>
int main(void){
	int n,m,x[10],k[10],a=0,b=0,c=0,d=0,e=0,i,j=0;
	scanf("%d %d",&n,&m);
    if(n>1){
		for(i=0;i<n;i++){
		scanf("%d",&x[i]);
		if(x[i]==0){
			a++;
			scanf("%d",k[j]);
		j++;
		} 
		if(x[i]==1) b++;
		if(x[i]==2) c++;
	}}
	else if(n==0) printf("QAQ\n");
	else if(n==1){
		scanf("%d",&x[0]);
		if(x[0]==0) scanf("%d",&k[0]);
		printf("QAQ\n");
	} 
	if(c>=1&&(a>=1||b>=1)) printf("haoye\n");
	else if(c==0&&b==0||(c==1&&a==0&&b==0)||(c==0&&b==0)) printf("QAQ\n");
	else if(c==0&&b!=0&&a!=0){
		if(m==0){
			for(j=0;j<a;j++){
				if(k[j]>=2100){
					d=1;
					printf("haoye\n");
				} 
				else continue;
			}
			if(d==0) printf("QAQ\n");
		}
		else if(m==1){
			for(j=0;j<a;j++){
				if(k[j]>=2500){
					e=1;
					printf("haoye\n");
				} 
				else continue;
			}
			if(e==0) printf("QAQ\n");
		}
	}
return 0;
}	
