#include<stdio.h>
#include<string.h>
main()
{
	int t,n;
	int a[1000][1]={0};
	int sum,i,j,x=0;
	char ch;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		x=n;
		while(n--)
		{
			getchar();
			scanf("%c",&ch);
			a[ch][0]++;
		}
		sum=0;
		for(i=0;i<1000;i++)
		{
			if(a[i][0]%2==1)
			{
				sum=1;
				break;
			}
		}
		for(i=0;i<1000;i++)
		{
			if(a[i][0]>=2)
			{
				j=a[i][0]/2;
				sum=sum+2*j;
			}
		}
		if(sum==0)
			sum=1;
		printf("%d\n",sum);
		memset(a,0,sizeof(a));
	}
}