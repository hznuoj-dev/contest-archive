#include<stdio.h>
#include<string.h>
int main()
{
	long long n,i,num[200]={0};
	char   s[100000];
	long long int t;
	scanf("%lld",&t);
	while(t--)
	{
	scanf("%lld",&n);
	for(i=0;i<n;i++)
    {	scanf("%s",&s[i]);	
		num[int(s[i])]++; 
	}
	long long int max=0,sum=0;
    for(i=0;i<200;i++)
    {
      if(num[i]%2!=0&&num[i]>max)	
      {
		 max=num[i];
	  }	
	}
	sum+=max;
	 for(i=0;i<200;i++)
    {
      if(num[i]%2==0)	
      {
		 sum+=num[i];
	  }	
	}
	printf("%lld\n",sum);
	for(i=0;i<200;i++)
	{
		num[i]=0;
	}
	}
	return 0;
 } 
