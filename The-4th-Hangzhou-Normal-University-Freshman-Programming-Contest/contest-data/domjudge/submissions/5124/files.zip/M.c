#define _CRT_SECURE_NO_WARNINGS
//#include<stdio.h>
//#define length 10000
//int main()
//{
//	long long ch[11][length + 1];
//	int out[length + 1];
//	int n; int i, k;
//	long long m;
//	scanf("%d%lld", &n, &m);
//	for ( i = 0; i < n; i++)
//	{
//		for ( k = 0; k < m; k++)
//		{
//			scanf("%lld", &ch[i][k]);
//		}
//	}
//	for ( i = 0; i < n; i++)
//	{
//
//	}
//	return 0;
////}
//#include<stdio.h>
//#define length 1000000
//int main(void)
//{
//	long long n, m, T[length + 1];
//	long long num[length+1];
//	char name[length + 1][20];
//	scanf("%lld", &n);
//	for (int i = 0; i < n; i++)
//	{
//		scanf("%lld", &num[i]);
//		scanf("%s", name[i]);
//	}
//	scanf("%lld", &m);
//	printf("%s", name[n - m - 1]);
//	return 0;
// analyze:stacksize <1000000>
//Mjiaohui
#include<stdio.h>
#include<string.h>
int main()
{
	int T;
	scanf("%d", &T);
	char word[100][30];
	char sign[1][1];
	while (T--)
	{
		int i = 0; int x; int k;
		do
		{
			scanf("%s", word[i]);
			i++;
		} while (getchar() != '\n');

		x = strlen(word[i-1]);
		
	
	
		printf("%s ", word[0]);
		for ( k = 0; k < x-1; k++)
		{
			printf("%c", word[i - 1][k]);
		}
		
		for ( k = 2; k <= i/2; k++)
		{
			printf(" %s", word[k-1]);
			printf(" %s", word[i - k]);
		}
		if (i%2!=0)
		{
			printf(" %s", word[i / 2 ]);
		}
		printf("%s\n", &word[i-1][x-1]);
	}
	return 0;
}

