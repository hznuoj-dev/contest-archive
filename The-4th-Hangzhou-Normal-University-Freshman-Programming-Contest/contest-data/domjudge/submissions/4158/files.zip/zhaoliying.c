#include<stdio.h>
struct Song
{
	int num;
	char name[20];
}son[100001];
int main()
{
	int n, i, max, k1, k2, k;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d %s", &son[i].num, son[i].name);
	}
	scanf("%d", &k);
	max = son[0].num;
	k1 = 0;
	for (i = 1; i < n; i++)
	{
		if (son[i].num > max)
		{
			max = son[i].num;
			k2 = i;
			son[i] = son[k1];
			son[k1] = son[k2];
		}
	}
	printf("%s\n", son[k].name);
	return 0;
}

