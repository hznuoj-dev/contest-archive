#include <iostream>
#include <cstring>
using namespace std;
int b[100001];
char c[100001][16];
void qsort(int l,int r)
{
	int i,j,mid,p;
	i=l;
	j=r;
	mid=b[(l+r)/2];
	char temp1[16];
	do
	{
		while (b[i]<mid)
			++i;
		while (b[j]>mid)
			--j;
		if (i<=j)
		{
			p=b[i];
			b[i]=b[j];
			b[j]=p;
			strcpy(temp1,c[i]);
			strcpy(c[i],c[j]);
			strcpy(c[j],temp1);
			i++;
			j--;
		}
	}while (i<=j);
	if (l<j)
		qsort(l,j); 
	if (i<r)
		qsort(i,r);
}
int main()
{
	int n;
	cin>>n;
	int i;
	for(i=0;i<n;++i)
	{
		cin>>b[i]>>c[i];	
	}
	int g;
	cin>>g;
	qsort(0,n-1);
	for(i=0;i<n;++i)
	{
		cout<<b[i]<<" ";	
	}
	cout<<endl;
	cout<<c[n-g-1]<<endl;
}
