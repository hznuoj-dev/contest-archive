
#include <stdio.h>
#include <string.h>
#pragma warning
int main() {
    int n; int  l[10]; char c[100][100]; int m;
    scanf_s("%d", &n);
    if (n < 1 || n >100000)
        return 0;
    for (int i = 0; i < n; i++)
    {
        scanf_s("%d", &l[i]);
        if (l[i] < 1 || l[i]>1000000000)
            return 0;
        getchar();
        gets(c[i]);
        if (strlen(c[i]) < 1 || strlen(c[i]) > 15)
            return 0;
    }
    scanf_s("%d", &m);
    if (m<0 || m>n)
        return 0;
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (l[j] > l[i])
            {
                char s[100];
                strcpy(s, c[i]);
                strcpy(c[i], c[j]);
                strcpy(c[j], s);
            }
        }
    }
    printf("%s", c[m]);
}