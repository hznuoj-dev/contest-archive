#include<stdio.h>
#include<stdlib.h>

int main()
{
	int n1[257]={0},c=0;
	char x;
	int a,b,t,d;
		scanf("%d",&t);
	while(t--)
	{
		for(a=0;a<257;a++)
			n1[a]=0;
		c=0;
		d=0;
		scanf("%d",&b);
		for(a=0;a<b;a++)
		{
			scanf(" %c",&x);
			n1[x]++;
		}
		for(a='a'+0;a<='z'+0;a++)
		{
			
			d+=n1[a];
			if(n1[a]%2==0)
			{
				c+=n1[a];
			}
			else c+=n1[a]-1;
		}
		for(a='A'+0;a<='Z'+0;a++)
		{
			
			d+=n1[a];
			if(n1[a]%2==0)
			{
				c+=n1[a];
			}
			else c+=n1[a]-1;
		}
		if(d!=c)
		{
			c++;
		}
		printf("%d\n",c);
	}

	return 0;
}