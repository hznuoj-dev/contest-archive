#include<stdio.h>
int main (){

long long T;
long long a,b; 
scanf("%lld",&T);
while(T--)
{
	scanf("%lld %lld",&a, &b);
		 if(b == 0)
	{
		printf("no\n");
	}
	
   else	if(2 * (a - 1) % b == 0){
		printf("yes\n");
		
	}
     else 
	{
		printf("no\n");
	}
}

}
