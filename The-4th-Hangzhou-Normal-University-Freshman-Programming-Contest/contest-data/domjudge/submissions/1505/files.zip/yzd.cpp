#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
int a[100001];
int main () {
    cnm;
    int t;
    cin >> t;
   while (t--){
       int n,x;
       cin >> n >> x;
       if (x==0) 
       {cout << "no" << endl;}
       else {cout << "yes" << endl;}
   }
    return 0;
}