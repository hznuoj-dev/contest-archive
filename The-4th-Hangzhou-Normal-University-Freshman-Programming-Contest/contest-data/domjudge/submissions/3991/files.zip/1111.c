#include <stdio.h>
#include <stdlib.h>

typedef struct song {
	long int num;
	char name[50];
} Song;

int compare(const void *a, const void *b) {
	Song *p = (Song *)a;
	Song *q = (Song *)b;
	return q->num - p->num;
}

int main() {
	int n, k;
	scanf("%d", &n);
	Song song[10010];
	for (int i = 0; i < n; i++) {
		scanf("%ld %s", &song[i].num, song[i].name);
	}
	qsort(song, n, sizeof(song[0]), compare);
	scanf("%d", &k);

	for (int i = k; i < n; i++) {
		printf("%s", song[i].name);
	}
	return 0;
}