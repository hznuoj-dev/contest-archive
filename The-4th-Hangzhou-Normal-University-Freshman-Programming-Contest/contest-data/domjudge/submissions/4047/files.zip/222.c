#include <stdio.h>
#include <stdlib.h>


struct stu{
	int m;
	char s[16];
};
int cmp(const void *p,const void *q)
{
	struct stu *pp = (struct stu*)p;
	struct stu *pq = (struct stu*)q;
	int a = pp->m;
	int b = pq->m;
	return b-a;
}
int main()
{
	int i;
	int k;
	int n;
	scanf("%d",&n);
	struct stu a[n];
	for(i=0;i<n;++i)
	{
		scanf("%d %s",&a[i].m,a[i].s);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(struct stu),cmp);
	printf("%s",a[k].s);
	
	
	return 0;
}
