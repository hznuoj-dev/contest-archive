#include<stdio.h>
int main(){
  int T;
  char str[1001][31];
  char b;
  scanf("%d",&T);
  getchar();
  while(T--){
	  int i;
	  for(i=1;;i++){
		 for(int q=0;;q++){
	      scanf("%c",&b);
	        if(b=='.'||b=='!'||b=='?'||b==' '){
			str[i][q]='\0';
			break;
	   }
			else{
		  str[i][q]=b;	
		}
		  }
		 if(b!=' '){
		 break;
		 }
	 }
	  getchar();
	  if(i==1){
	  printf("%s%c\n",str[1],b);
	  }
	  else{
	  printf("%s %s",str[1],str[i]);
	  if(i%2==0){
	  for(int j=2;j<=i/2;j++){
	    printf(" %s %s",str[j],str[i-j+1]); 
	   }
	  printf("%c\n",b);
	  }
	  else{
	  for(int j=2;j<=i/2;j++){
	    printf(" %s %s",str[j],str[i-j+1]); 
	   }
	  printf(" %s%c\n",str[i/2+1],b);
	  }
	 }
  }
}