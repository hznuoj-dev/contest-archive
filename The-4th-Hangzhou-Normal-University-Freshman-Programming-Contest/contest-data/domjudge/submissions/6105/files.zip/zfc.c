#include<stdio.h>
#include<string.h>
#include<stdlib.h>
typedef struct {
	int number;
	char name[30];
}student;
 student stu[100005];
int comp(const void* a,const void* b)
{
	student *p=(student*)a; student *q=(student*)b;
	return q->number-p->number;
}
int main()
{
 int n,t,i,x,j,k;
 scanf("%d",&n); 
 getchar();  
 for(i=0;i<n;i++)
 scanf("%d %s",&stu[i].number,stu[i].name);
 qsort(stu,n,sizeof(stu[0]),comp);
 scanf("%d",&k);
 printf("%s\n",stu[k].name);
	return 0;
}
