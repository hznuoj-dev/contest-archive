#include<bits/stdc++.h>

using namespace std;

int main(){
	int n,m,p,a[20],f[3];
	scanf("%d%d",&n,&m);
	if(m==0)p=2500;
	else p=2100;
	int t=0;
	while(n--){
		int h;
		scanf("%d",&h);
		if(h==0){
			scanf("%d",&a[t]);
			if(a[t]>=p)f[0]=1;
			t++;
		}
		else f[h]=1;
	}
	if(t==0){
		if(f[2]==1&&f[1]==1)printf("haoye");
		else printf("QAQ");
	}
	else {
		if(f[2]==1)printf("haoye");
		else if(f[1]==1&&f[0]==1)printf("haoye");
		else printf("QAQ");
	}			
}
