#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <sstream>
#include<bits/stdc++.h>
#define ll long long
#define INF 1e6
#define MAXZ 100050 
#define pancake std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
using namespace std;
ll qm (ll base , ll power , ll m){
    ll result = (ll) 1 % m;
    ll t = (ll) base;
    while (power){
        if(power & 1){
            result = result * t % m ;
        }
            t = t * t % m;
            power >>= 1 ;
    }
    return result;
}
typedef struct stu{
       ll a;
       string b;
}stu;
bool cmp (stu x , stu y){
        return x.a > y.a;
}
int num[100050];
ll bef[100050];
int main(){
    pancake;
    ll t;
    cin >> t;
    while(t --){
        ll n;
        cin >> n;
        int sum = 0;
        int left = 0;
        for(int i = 0  ; i < n  ; i ++){
           cin >> num[i];

           if(i == 0) bef[i] = num[i];
           else bef[i] = num[i] + bef[i - 1];

           if(bef[i] == 7777) sum ++;
           else if (bef[i] > 7777){
               for(int j = left ; j < i ; j ++){
                   if(bef[i] - bef[j] == 7777) sum ++;
                   else if(bef[i] - bef[j] < 7777){
                       left = j;
                       break;
                   }
               }
           }
        }
        cout << sum << endl;
    }
    return 0;
}