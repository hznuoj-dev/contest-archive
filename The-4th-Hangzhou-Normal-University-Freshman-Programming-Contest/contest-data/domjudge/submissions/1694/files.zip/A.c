#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(void)
{
	int i,j,n,T;
	char c[100100],ch;
	scanf("%d",&T);
	while(T--){
		int max_len=0,cnt=0,odd_max=-1;
		int times[100100]={0};
		scanf("%d",&n);
		getchar();
		scanf("%c",&ch);
		c[cnt]=ch;
		times[cnt]=1;
		cnt++;
		for(i=1;i<n;i++){
			scanf(" %c",&ch);
			for(j=0;j<cnt;j++){
				if(c[j]==ch){
					break;
				}
			}
			if(j==cnt){
				c[cnt]=ch;
				times[cnt]++;
				cnt++;
			}else{//���� 
				times[j]++;
			}
		}
		for(i=0;i<cnt;i++){
			if(times[i]%2==0){
				max_len+=times[i]; 
			}else if(odd_max<times[i]){
				odd_max=times[i];
			}
		}
		if(odd_max>0){
			max_len+=odd_max;
		}
		printf("%d\n",max_len);
	}
	return 0;
}
