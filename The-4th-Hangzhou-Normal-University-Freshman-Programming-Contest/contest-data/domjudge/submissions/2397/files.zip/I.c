#include <stdio.h>

int main(void) {
	int n,x,i,j;
	scanf("%d",&n);
	struct{
		int a;
		char b[16];
		}st[n+1];
	for(i=0;i<n;i++){
		scanf("%d%s",&st[i].a,st[i].b);
	}
	scanf("%d",&x);
	for(i=1;i<n;i++)
		for(j=0;j<n-i;j++)
			if(st[j].a<st[j+1].a){
				st[n]=st[j];
				st[j]=st[j+1];
				st[j+1]=st[n];
			}
		printf("%s",st[x].b);	
	return 0;
}

