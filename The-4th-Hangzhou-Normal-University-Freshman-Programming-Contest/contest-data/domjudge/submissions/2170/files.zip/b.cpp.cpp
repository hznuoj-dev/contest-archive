#include<stdio.h>
int main()
{
	int sum,sum2,i,j,t,n,a[100009];
	scanf("%d",&t);
	while(t--)
	{
		printf("Welcome to HZNU\n");
	} 
	return 0;
}
