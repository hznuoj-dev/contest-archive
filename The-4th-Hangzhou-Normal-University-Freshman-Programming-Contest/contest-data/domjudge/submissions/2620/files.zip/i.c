#include<stdio.h>
#include<stdlib.h>
struct song{
	int w;
	char name[8];
};
int comp(const void*p,const void *q){
	return((struct song *)q)->w-((struct song *)p)->w;
}
int main(){
	struct song A[20];
	int n;
	scanf("%d",&n);
	int i,k;
	for(i=0;i<n;i++){
		scanf("%d%s",&A[i].w,A[i].name);
	}
	scanf("%d",&k);
	qsort(A,n,sizeof(struct song),comp);
	printf("%s",A[k].name);
	return 0;
}
	
