#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		long long int n;
		long long int a[10000];
		int sum=0,time=0;
		scanf("%lld",&n);
		for(int i=0;i<n;i++){
			scanf("%lld",&a[i]);
		}
		
		for(int i=0;i<n;i++){
			sum=a[i];
			for(int j=i+1;j<n;j++){
				sum=sum+a[j];
			    if(sum==7777){
				    time++;
				    break;
			    }
			}
		}
		printf("%lld\n",time);
	}
	return 0;
}
