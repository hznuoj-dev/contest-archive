#include<stdio.h>
#include<string.h>
#include<stdlib.h>


int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int N;
		scanf("%d",&N);
		int fang1[N][N];
		int fang2[N][N];
		int i,j;
		for(i=0;i<N;i++)
			for(j=0;j<N;j++)
				scanf("%d",&fang1[i][j]);	
		for(i=0;i<N;i++)
			for(j=0;j<N;j++)
				scanf("%d",&fang2[i][j]);
		int flag=0,zhuan=0;
		for(j=0;j<3&&flag!=N;j++)
		{
				for(i=0;i<N;i++)
				{
					if(zhuan==0)
					{
						if(fang1[N-1][i]==fang2[0][i])
						flag++;
					}
					if(zhuan==1)
					{
						if(fang1[N-i-1][N-1]==fang2[0][i])
							flag++;
					}
					if(zhuan==2)
					{
						if(fang1[0][N-i-1]==fang2[0][i])
							flag++;
					}
				
				}
				
		}
		if(j==3) printf("-1\n");
		else printf("%d\n",j);
	}
	return 0;
}
