#include <bits/stdc++.h>
using namespace std; 
string s1,s2,s3,s4,s5,s6;
int t3,h3,f3,m3;
int pd (string st, string sm, string se)
{
	if (st=="   "&&sm=="  |"&&se=="  |") return 1;
	if (st==" _ "&&sm==" _|"&&se=="|_ ") return 2;
	if (st==" _ "&&sm==" _|"&&se==" _|") return 3;
	if (st=="   "&&sm=="|_|"&&se=="  |") return 4;
	if (st==" _ "&&sm=="|_ "&&se==" _|") return 5;
	if (st==" _ "&&sm=="|_ "&&se=="|_|") return 6;
	if (st==" _ "&&sm=="  |"&&se=="  |") return 7;
	if (st==" _ "&&sm=="|_|"&&se=="|_|") return 8;
	if (st==" _ "&&sm=="|_|"&&se==" _|") return 9;
	if (st==" _ "&&sm=="| |"&&se=="|_|") return 0;
	
}

void pr3(int x)
{
	if (x==1) printf("  |");
	if (x==2) printf("|_ ");
	if (x==3) printf(" _|");
	if (x==4) printf("  |");
	if (x==5) printf(" _|");
	if (x==6) printf("|_|");
	if (x==7) printf("  |");
	if (x==8) printf("|_|");
	if (x==9) printf(" _|");
	if (x==0) printf("|_|");
}
void pr1(int x)
{
	if (x==1) printf("   ");
	if (x==2) printf(" _ ");
	if (x==3) printf(" _ ");
	if (x==4) printf("   ");
	if (x==5) printf(" _ ");
	if (x==6) printf(" _ ");
	if (x==7) printf(" _ ");
	if (x==8) printf(" _ ");
	if (x==9) printf(" _ ");
	if (x==0) printf(" _ ");
}
void pr2(int x)
{
	if (x==1) printf("  |");
	if (x==2) printf(" _|");
	if (x==3) printf(" _|");
	if (x==4) printf("|_|");
	if (x==5) printf("|_ ");
	if (x==6) printf("|_ ");
	if (x==7) printf("  |");
	if (x==8) printf("|_|");
	if (x==9) printf("|_|");
	if (x==0) printf("| |");
}

int main()
{
	int h1,h2,f1,f2,m1,m2,t1,t2;
	getline(cin,s1);
	getline(cin,s2);
	getline(cin,s3);
	getline(cin,s4);
	getline(cin,s5);
	getline(cin,s6);
	h1=pd(s1.substr(0,3),s2.substr(0,3),s3.substr(0,3))*10+pd(s1.substr(3,3),s2.substr(3,3),s3.substr(3,3));
	f1=pd(s1.substr(6,3),s2.substr(6,3),s3.substr(6,3))*10+pd(s1.substr(9,3),s2.substr(9,3),s3.substr(9,3));
	m1=pd(s1.substr(12,3),s2.substr(12,3),s3.substr(12,3))*10+pd(s1.substr(15,3),s2.substr(15,3),s3.substr(15,3));
	
	h2=pd(s4.substr(0,3),s5.substr(0,3),s6.substr(0,3))*10+pd(s4.substr(3,3),s5.substr(3,3),s6.substr(3,3));
	f2=pd(s4.substr(6,3),s5.substr(6,3),s6.substr(6,3))*10+pd(s4.substr(9,3),s5.substr(9,3),s6.substr(9,3));
	m2=pd(s4.substr(12,3),s5.substr(12,3),s6.substr(12,3))*10+pd(s4.substr(15,3),s5.substr(15,3),s6.substr(15,3));	
//cout << h1 << f1 << m1 << endl;
//	cout << h2 << f2 << m2 << endl;
	t1=h1*60*60+f1*60+m1;
	t2=h2*60*60+f2*60+m2;
	if (t1>t2) printf("early\n");
	if (t1<t2) printf("late\n");
	if (t1==t2) 
	{
		printf("gang gang hao\n");
		printf(" _  _  _  _  _  _ \n");
		printf("| || || || || || |\n");
		printf("|_||_||_||_||_||_|\n");
		return 0;
	}
	t3=abs(t1-t2);
	h3=t3/60/60;
	f3=(t3-h3*60*60)/60;
	m3=(t3-h3*60*60-f3*60);
	//cout << h3 << f3 << m3 << endl;
	pr1(h3/10);pr1(h3%10);
	pr1(f3/10);pr1(f3%10);
	pr1(m3/10);pr1(m3%10); printf("\n");
	
	pr2(h3/10);pr2(h3%10);
	pr2(f3/10);pr2(f3%10);
	pr2(m3/10);pr2(m3%10); printf("\n");
	
	pr3(h3/10);pr3(h3%10);
	pr3(f3/10);pr3(f3%10);
	pr3(m3/10);pr3(m3%10); printf("\n");
/*	pr2();
	pr3();*/
/*	cout << endl;
	cout << s1 << endl;
	cout << s2 << endl;
	cout << s3 << endl;
	cout << s4 << endl;
	cout << s5 << endl;
	cout << s6 << endl;*/
}
