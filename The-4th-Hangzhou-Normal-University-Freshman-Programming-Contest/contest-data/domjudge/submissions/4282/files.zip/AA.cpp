#include <bits/stdc++.h>
using namespace std;

int a[52];

int main()
{
	int t,n,i,j;
	int m,ans;
	char c;
	
	cin >> t;
	while(t--)
	{
		for(i=0;i<=51;i++)
			a[i]=0;
		
		cin >> n;
		for(i=1;i<=n;i++)
		{
			cin >> c;
			if(c>='A' && c<='Z')	a[c-'A']++;
			else if(c>='a' && c<='z')	a[c-'a'+26]++;
		}
		ans=0;m=0;
		for(i=0;i<=51;i++)
		{
			if(a[i]%2==0 && a[i]!=0)	ans+=a[i];
			else m=max(m,a[i]);
		}
		ans+=m;
		cout << ans << '\n';
	}
	
	return 0;
}
