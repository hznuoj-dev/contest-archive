#include<stdio.h>
main()
{
	int T;
	long long n,x;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%lld", &n);
		scanf("%lld", &x);
		if (x == 0)
			printf("no\n");
		else
			printf("yes\n");
	}

}
