#include<bits/stdc++.h>
using namespace std;
int a[21][21],b[21][21];
int c[21][21];
int main()
{
	int tmp;
	int size;
	cin>>tmp;
	while(tmp--)
	{
		for(int i=0;i<21;i++)
		{
			for(int j=0;j<21;j++)
			{
				a[i][j]=0;
				b[i][j]=0;
				c[i][j]=0;
			}
		}
		int flag=1;
		cin>>size;
		for(int i=1;i<=size;i++)
		{
			for(int j=1;j<=size;j++)
			{
				cin>>a[i][j];
			}
		}
		for(int i=1;i<=size;i++)
		{
			for(int j=1;j<=size;j++)
			{
				cin>>b[i][j];
			}
		}
		for(int tt=1;tt<=4;tt++)
		{
			flag=1;
			for(int i=1;i<=size;i++)
			{
				for(int j=1;j<=size;j++)
				{
					c[i][j]=a[size-j+1][i];
				}
			}
			for(int i=1;i<=size;i++)
			{
				for(int j=1;j<=size;j++)
				{
					a[i][j]=c[i][j];
				}
			}			
			for(int i=1;i<=size;i++)
			{
				for(int j=1;j<=size;j++)
				{
					if(c[i][j]!=b[i][j])
					{
						flag=0;
					}
				}
			}
			if(flag==1)
			{
				cout<<min(tt,4-tt)<<'\n';
				break;
			}
		}
		if(flag==0)
		{
			cout<<-1<<'\n';				
		}
	
	}		
}
