#include <stdio.h>
int main()
{
	long long int t,n,m;
	scanf("%lld",&t);
	while(t--)
	{
	 scanf("%lld %lld",&n,&m);
	 if(m==0)
	 {
	 	printf("no\n");
	 }
	 else
	 {
	 	printf("yes\n");
	 }
	}
	return 0;
 } 
