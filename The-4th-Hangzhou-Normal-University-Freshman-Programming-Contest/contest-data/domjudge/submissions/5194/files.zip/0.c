#include<stdio.h>
int main(){
	int t, c=0;
	long n, x, i;
	scanf("%d",&t);
	while(t--){
		scanf("%ld %ld",&n,&x);
		if(x==0){
			printf("NO\n");
		}
		else if(x!=0){
		    for(i=1;i<10^6;i++){
			    if(i*n%x==0){
		      		c=c+1;
		    		break;
	    		}
	    	}
	    	if(c==0){
	    		printf("NO\n");
	    	}
    		else if(c==1){
	    		printf("YES\n");
	    	}
	    	c=0;
			}
	}
	return 0;
}
