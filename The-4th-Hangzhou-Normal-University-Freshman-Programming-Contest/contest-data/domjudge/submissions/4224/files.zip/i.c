#include <stdio.h>
#include <string.h>
struct number {
	long long int w;
	char s[16];
};
int main() {
	int n, i, j;
	scanf("%d", &n);
	struct number a[100000];
	for (i = 1; i <=n; i++) {
		scanf("%lld%s", &a[i].w, a[i].s);
	}
	for (i = 1; i <= n ; i++) {
		for (j = n; j >= i ; j--) {
			if (a[j].w < a[j + 1].w) {
				char change[21];
				strcpy(change, a[j + 1].s);
				strcpy(a[j + 1].s, a[j].s);
				strcpy(a[j].s, change);
			}
		}
	}
	int k;
	scanf("%d", &k);
	printf("%s\n", a[k].s);
}