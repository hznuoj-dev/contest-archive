#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int main(){
	int t,n,i,j,sum;
	int s1[20][20],s2[20][20],s3[20][20],s4[20][20],s5[20][20];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		sum=0;
		memset(s1,0,sizeof(s1));
		memset(s2,0,sizeof(s2));
		memset(s3,0,sizeof(s3));
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&s1[i][j]);
				s3[n-1-j][i]=s1[i][j];
				s4[j][n-1-i]=s1[i][j];
				s5[n-1-i][n-1-j]=s1[i][j];
			}
		}
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&s2[i][j]);
			}
		}
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(s2[i][j]!=s1[i][j]){
					break;
				}
			}
		}
		if(i==n&&j==n)printf("0\n");
		else{
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(s2[i][j]!=s3[i][j]){
					break;
				}
			}
		}
		if(i==n&&j==n)printf("1\n");
		else{
			for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(s2[i][j]!=s4[i][j]){
					break;
				}
			}
		}
		if(i==n&&j==n)printf("1\n");
		else{
		 for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(s2[i][j]!=s5[i][j]){
					break;
				}
			}
		}
		 if(i==n&&j==n)printf("2\n");
		 else printf("-1\n");
		}
		}
		}

	}


}