#include<stdio.h>
#include<strlib.h>
struct song{
	char name[21];
	long long int num;
};
int comp(const void *p,const void *q){
	struct song *min=(struct song *)(p);
	struct song *max=(struct song *)(q);
	return max->num-min->num;
}
int main(void){
	struct song ch[100000];
	int n,i;
	int T;
	scanf("%d",&n); 
	for(i=0;i<n;++i){
		scanf("%lld%s",&ch[i].num,ch[i].name);
	}
	qsort(ch,n,sizeof(struct song),comp);
	scanf("%d",&T);
	printf ("%s\n",ch[T].name);
	return 0;
}
