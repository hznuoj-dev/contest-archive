#include<stdio.h>
int main() {
	int n, a, b;
	scanf("%d", &n);
	while (n--) {
		scanf("%d %d", &a, &b);
		if (b != 0) {
			printf("yes");
		}
		else {
			printf("no");
		}
	}
	return 0;
}