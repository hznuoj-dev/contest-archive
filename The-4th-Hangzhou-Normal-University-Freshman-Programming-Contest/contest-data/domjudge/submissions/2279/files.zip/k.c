#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);3
	while(n--){
		printf("Welcome to HZNU\n");
	}
	return 0;
} 
