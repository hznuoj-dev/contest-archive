#include<stdio.h>
struct student
{
	long long int xiai;
	char b[10000];
}a[10000];
int main()
{
	struct student temp;
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&a[i].xiai,a[i].b);
	}
	scanf("%d",&k);
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(a[j].xiai<a[j+1].xiai)
			{
				temp=a[j+1];
				a[j+1]=a[j];
				a[j]=temp;
			}
		}
	}
	printf("%s\n",a[k].b);
	return 0;
}