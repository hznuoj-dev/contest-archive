#include <bits/stdc++.h>
using namespace std;
struct ge{
	int ai;
	char name[16];
} di[100010],b[100010];
void zhao(int l,int r){
	int i;
	if (l==r) return;
	int mid=(l+r)/2;
	zhao(l,mid);
	zhao(mid+1,r);
	int p=l ,q=mid+1;
	for (i=l;i<=r;i++){
		if (p==mid+1) b[i]=di[q++];
		else if (q==r+1) b[i]=di[p++];
		else if (di[p].ai<di[q].ai){
			b[i]=di[q++];
		} else b[i]=di[p++];		
	}
	for (i=l;i<=r;i++) di[i]=b[i];
}
int main(){
	int n,t,i,z;
	cin>>n;
	for (i=0;i<n;++i){
		scanf("%d %s",&di[i].ai,di[i].name);
	}
	cin>>t;
	zhao(0, n);
	cout<<di[t].name;
	return 0;
} 
