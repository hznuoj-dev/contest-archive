#include<stdio.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
int cmp(const void *p,const void *q)
{
	int *a = (int*)p;
	int *b = (int*)q;
	return *a-*b;
}
int main()
{
	int T,n,i,j,k;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		int a[n],cnt=0,sum;
		for(i=0;i<n;++i)
		{
			scanf("%d",&a[i]);
		}
		qsort(a,n,sizeof(int),cmp);
		for(i=0;i<n;++i)
		{	
		 	sum=7777;
		 	sum -= a[i];
			int pos = i+1;
		 	for(j=i+1;j<n&&pos<n;++j)
		 	{	
		 		if(sum>0)
		 		{
		 			for(k=j+1;k<n;++k)
					{
						if(a[k]==sum)cnt++;
					} 
		 			sum -= a[j];
				}
				else if(sum<=0) sum += a[j];
				if(j==n-1)
				{
					j = pos;
					pos++; 
					sum = 7777-a[i];
				}
			}
		}
		printf("%d\n",cnt);
		cnt = 0;
	}
}
