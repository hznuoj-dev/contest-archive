#include <stdio.h>
#include <string.h>
int main(void){
	char a[1000][31];
	char k;
	int i=0,n=0,len,t;
	scanf("%d",&t);
	while(t--){
		n=0;
		while(1){
			scanf("%s",a[n]);
			len=strlen(a[n]);
			if(a[n][len-1]>='a'&&a[n][len-1]<='z'||a[n][len-1]>='A'&&a[n][len-1]<='z'){
			}else{
				k=a[n][len-1];
				a[n][len-1]='\0';
				break;
			}
			n++;
		}
		n++;
		if(n%2==1){
			for(i=0;i<n/2;i++){
				printf("%s ",a[i]);
				printf("%s ",a[n-i-1]);
			}
			printf("%s",a[i]);
			printf("%c\n",k);
		}else{
			for(i=0;i<n/2-1;i++){
				printf("%s ",a[i]);
				printf("%s ",a[n-i-1]);
			}
				printf("%s ",a[i]);
				printf("%s",a[n-i-1]);
				printf("%c\n",k);
		}
	}
	return 0;
}
