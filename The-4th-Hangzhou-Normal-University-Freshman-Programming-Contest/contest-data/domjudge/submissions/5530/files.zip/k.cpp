#include <stdio.h>
int main(){
int n,m,a[100],k,b=0,c=0,d=0;
scanf("%d%d",&n,&m);
for(int i=0;i<n;i++){
	scanf("%d",&a[i]);
	if(a[i]==0)
	scanf("%d",&k);
}
if(n==0||n==1){
	printf("QAQ\n");
}
else{
if(m==1){
	for(int i=0;i<n;i++){
		if(a[i]==0)
		b=1;
			if(a[i]==1)
				c=1;
		if(a[i]==2)
			d=1;			
	}
	if(d==1&&m>1)
		printf("haoye\n");
	else if((b==1&&k>2100)&&(c==1)){
		printf("haoye\n");
	}
	else{
	printf("QAQ\n");
	}
	
}
if(m==0){
	for(int i=0;i<n;i++){
			if(a[i]==0)
			b=1;
				if(a[i]==1)
					c=1;
			if(a[i]==2)
				d=1;			
		}
		if(d==1&&k>1)
			printf("haoye\n");
		else if((b==1&&k>=2500)&&(c==1)){
			printf("haoye\n");
		}
		else{
		printf("QAQ\n");
		}
		
	}	
}

	return 0;
}
