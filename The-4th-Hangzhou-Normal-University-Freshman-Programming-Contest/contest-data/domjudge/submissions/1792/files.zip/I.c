#include <stdio.h>
struct song{
	int w;
	char s[15];
};
int main(){
	int n,k,i,j;
	struct song a[200];
	struct song temp;
	scanf("%d",&n);
	 for(i=0;i<n;++i){
	 	scanf("%d %s",&a[i].w,a[i].s);
	 }
	 scanf("%d",&k);
	 for(j=1;j<n;++j){
	 	for(i=0;i<n-j;++i){
	 		if(a[i].w<a[i+1].w){
	 			temp=a[i+1];
	 			a[i+1]=a[i];
	 			a[i]=temp;
			 }
		 }
	 }
	 printf("%s",a[k].s);
	 return 0;
} 
