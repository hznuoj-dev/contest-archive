#include<stdio.h>
struct song{
	long long c;
	char a[15];
};
int main(void){
	int i,j,n,k;
	scanf("%d",&n);
	struct song num[n],item;
	for(i=0;i<n;i++){
		scanf("%lld%s",&num[i].c,num[i].a);
	}
	for(j=1;j<n;j++){
		for(i=0;i<n-j;i++){
			if(num[i].c<num[i+1].c){
				item=num[i];
				num[i]=num[i+1];
				num[i+1]=item;
			}
		}
	}
	scanf("%d",&k);
	printf("%s",num[k].a);
	return 0;
}

