#include<stdio.h>
struct pp{
	long long int wi;
	char si[16];
};
int main(void){
	long long int n,i,j,k;
	struct pp a[1000],tt;
	scanf("%lld",&n);
	for(i=0;i<n;i++){
		scanf("%lld%s",&a[i].wi ,a[i].si );
	}
	scanf("%lld",&k);
	for(i=0;i<n;i++){
		for(j=n-1;j>i;j--){
			if(a[j-1].wi <a[j].wi ){
				tt=a[j-1];
				a[j-1]=a[j];
				a[j]=tt;
			}
		}
	}
	printf("%s\n",a[k].si );
	return 0;
} 
