#include <stdio.h>
int main(){
 int t,n,i,j,k,s,left;
 int a[10000];
 scanf("%d",&t);
 while(t--){
  k=0;
  scanf("%d",&n);
  for(i=0;i<n;i++){
   scanf("%d",&a[i]);
  }
  s=a[0];
  left=0;
  for(i=1;i<n;i++){
   s+=a[i];
   if(s==7777){
    k++;
    s-=a[left];
    left++; 
   }
 if(s>7777){
    s-=a[left];
    left++;
    if(s==7777){
    k++;
  }
   }
  }
 printf("%d\n",k);
 }
 return 0;
}
