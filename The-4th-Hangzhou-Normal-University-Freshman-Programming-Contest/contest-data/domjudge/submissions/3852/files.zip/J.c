#include<stdio.h>
int main(void)
{
	int n,m,x[10],i,k;
	scanf("%d %d",&n,&m);
    for(i=0;i<n;i++){
		scanf("%d",&x[i]);
	}
	for(i=0;i<n;i++){
		if(x[i]==0) scanf("%d",&k); 
	}
	

	if(n>=2){
	    for(i=0;i<n;i++){
	    	int h=0;
		    if(x[i]==2){
			    printf("haoye");
			    break;
			}
		    else if(m==0&&x[i]==0&&k>=2500){
		        for(i=0;i<n;i++){
		    	    if(x[i]==1)   h=h+1;
			    }
			    if(h>=1){
				    printf("haoye");
				    break;
				}
                else{
                	printf("QAQ");
				    break;
				}
            }
	        else if(m==1&&x[i]==0&&k>=2100){
	            for(i=0;i<n;i++){
		    	    if(x[i]==1)   h=h+1;
			    }
			    if(h>=1){
				    printf("haoye");
				    break;
				}
                else{
                	printf("QAQ");
				    break;
				}
            }
        }
    }
    else printf("QAQ");
	return 0;
}
