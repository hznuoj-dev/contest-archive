#include <stdio.h>

int main(void) {
	int n, m;
	int k, flag = 0;
	scanf("%d %d", &n, &m);
	int x[n], r[n];
	for (int i = 0; i < n; i++) {
		scanf("%d", &x[i]);
		if (x[i] == 0) {
			scanf("%d", &k);
			if (m == 0)
				r[i] = k - 2500;
			else
				r[i] = k - 2100;
		} else if (x[i] == 1)
			flag = 1;
		else
			flag = 2;
	}


	if (n >= 2) {
		for (int i = 0; i < n; i++) {

			if ((r [i] >= 0 && flag == 1) || flag == 2) {
				printf("haoye\n");
				break;
			} else
				printf("QAQ\n");
		}
	} else
		printf("QAQ\n");

	return 0;
}