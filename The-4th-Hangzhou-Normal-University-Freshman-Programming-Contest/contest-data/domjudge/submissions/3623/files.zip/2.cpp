 #include<bits/stdc++.h>
using namespace std;
int x[26],d[26];
int main(){
	int a,b,sum,n,j,k;
	char ch;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",&a);
		sum=0;
		int flag=0;
		for(j=0;j<=25;j++){
			x[j]=0;
			d[j]=0;
		}
		for(j=0;j<a;j++){
			cin>>ch;
			if(ch>='a' &&ch<='z') x[ch-'a']++;
			else if(ch>='A' &&ch<='Z') d[ch-'A']++;
		}
		for(j=0;j<=25;j++){
			sum=sum+(x[j])/2*2+(d[j])/2*2;
			if(x[j]%2==1||d[j]%2==1) flag=1; 
		}
		if(flag==1) sum++;
		printf("%d\n",sum);
	}
} 
