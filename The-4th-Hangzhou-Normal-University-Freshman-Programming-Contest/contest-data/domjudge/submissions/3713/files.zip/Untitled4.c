#include<stdio.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
struct stu{
	int fav;
	char name[16];
}ge[100001];
int cmp(const void*p,const void*q)
{
	struct stu *pp = (struct stu*)(p); 
	struct stu *pq = (struct stu*)(q); 
	int a = pp->fav;
	int b = pq->fav;
	return a>b?-1:1;
}
int main()
{
	int i,k,n;
	scanf("%d",&n);
	for(i=0;i<n;++i)
		scanf("%d %s",&ge[i].fav,ge[i].name);
	scanf("%d",&k);
	qsort(ge,n,sizeof(struct stu),cmp);
	printf("%s",ge[k].name);
}
