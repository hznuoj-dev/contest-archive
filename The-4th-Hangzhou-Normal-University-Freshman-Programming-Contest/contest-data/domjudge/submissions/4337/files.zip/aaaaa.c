#include <stdio.h>
int main(void){
	int n,m,x[10],k,flag,z;
	int i,d;
	scanf("%d%d",&n,&m);
	if(n==1) printf("QAQ");
	else{
		flag=0;
		d=0;
		for(i=0;i<n;i++){
			scanf("%d",&x[i]);
			if(x[i]==0){
				scanf("%d",&k);
				if(m==0){
					if(k>=2500) flag+=1; 
				}
				else{
					if(k>=2100) flag+=1;
				}
			}
			else if(x[i]==1) d=d+1;
			else if(x[i]==2) z=1;
		}
		if((d>0&&flag>0)||z==1) printf("haoye");
		else printf("QAQ");
	}
	return 0;
}

















