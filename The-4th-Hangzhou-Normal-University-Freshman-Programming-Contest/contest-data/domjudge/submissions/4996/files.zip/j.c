#include<stdio.h>
#include<string.h>
int main(){
	int n,i,m,k[11],ATK=2500,DEF=2100,a[11],flag=0;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0)
			scanf("%d",&k[i]);
	}
	for(i=0;i<n;i++){
		if(a[i]==2){
			i=i+1;
			if(flag==0&&i<n-1){
			printf("haoye\n");
			break;
		}
		}

		if(a[i]==0){
			if(m==0&&k[i]>=ATK)
				flag=1;
			else if(m==1&&k[i]>DEF)
				flag=1;
		}
		if(a[i]==1&&flag==1){
			printf("haoye\n");
			break;
		}
		
	}
	if(i==n)
		printf("QAQ\n");
	return 0;
}