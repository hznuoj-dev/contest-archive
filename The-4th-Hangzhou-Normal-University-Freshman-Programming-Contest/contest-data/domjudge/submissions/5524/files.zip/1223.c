#include"stdio.h"
int main(void){
int n1[21][21],n2[21][21];
int a,b,c,d,e,t,z1=0,y1=0,z2=0;
scanf("%d",&t);
while(t--){
scanf("%d",&e);
z1=0;y1=0;z2=0;
for(a=0;a<e;a++)
for(b=0;b<e;b++)
scanf("%d",&n1[a][b]);
for(a=0;a<e;a++)
for(b=0;b<e;b++){
scanf("%d",&n2[a][b]);
if(n2[a][b]==n1[e-b-1][a]) z1++;
if(n2[a][b]==n1[b][e-a-1]) y1++;
if(n2[a][b]==n1[e-a-1][e-b-1]) z2++;}
if(z1==e*e||y1==e*e) printf("1\n");
else if(z2==e*e) printf("2\n");
else printf("-1\n");}
return 0;}