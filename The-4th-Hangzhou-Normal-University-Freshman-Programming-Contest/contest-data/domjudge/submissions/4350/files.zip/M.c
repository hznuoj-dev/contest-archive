#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 
#include<ctype.h> 
char s[1005][35],k[35];
int main()
{
	int t,i,j,k;
	scanf("%d",&t);
	while(t--)
	{
		i=0;
		while(1)
		{
			scanf("%s",s[i]);
			int len=strlen(s[i]);
			if(s[i][len-1]=='.'||s[i][len-1]=='?'||s[i][len-1]=='!')
				break;
			i++;
		}
		printf("%s ",s[0]);
		for(j=0;j<strlen(s[i])-1;j++)
			printf("%c",s[i][j]);
		printf(" ");
		printf("%s ",s[1]);
		printf("%s ",s[i-1]);
		for(j=2;j<=i-2;j++)
		{
			if(j<i-2)
				printf("%s ",s[j]);
			else
				printf("%s",s[j]);
		}
		printf("%c",s[i][strlen(s[i])-1]);
		printf("\n");
	}
	return 0;
}
