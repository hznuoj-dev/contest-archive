#include<stdio.h>
int main() {
	int t = 0;
	int i = 0;
	int j = 0;
	int n = 0;
	int sum = 0;
	int ans = 0;
	int a[10000];
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &n);
		for (i = 0; i < n; i++) {
			scanf("%d", &a[i]);
		}
		for (i = 0; i < n; i++) {
			for (j = i; j < n; j++) {
				sum = sum+ a[j];
				if (sum == 7777) {
					ans++;
				}
			}
			sum = 0;
		}
		printf("%d", ans);
	}
}