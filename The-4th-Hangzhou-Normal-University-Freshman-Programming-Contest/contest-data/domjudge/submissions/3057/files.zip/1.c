#include <string.h>
#include <stdio.h>
#include <math.h>

char ch[1000][18];
int main() {
	int t;
	long long int a[10005];
	scanf("%d", &t);
	for (int i = 0;i < t;i++) {
		scanf("%lld", &a[i]);
		scanf("%s", ch[i]);
	}
	long long int n;
	char s[20];
	for (int pass = 1;pass < t;pass++) {
		for (int i = 0;i < t - pass;i++) {
			if (a[i] < a[i + 1]) {
				n = a[i];
				a[i] = a[i + 1];
				a[i + 1] = n;
				strcpy(s, ch[i]);
				strcpy(ch[i], ch[i + 1]);
				strcpy(ch[i + 1], s);
			}
		}
	}
	int m;
	scanf("%d", &m);
	printf("%s", ch[m]);
	printf("\n");
}









