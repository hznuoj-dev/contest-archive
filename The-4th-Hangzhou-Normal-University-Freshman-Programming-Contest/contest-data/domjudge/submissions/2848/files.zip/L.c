#include<stdio.h>
main(){
	int n,x,t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&x);
		if(x!=0)
			printf("yes\n");
		else
			printf("no\n");
	}

}

