#include<stdio.h>
#include<string.h>

int main(void){
	int t,i,j,n;
	scanf("%d",&t);
	while(t--){
		char ch;
		int a[200]={0};
		scanf("%d",&n);
		
		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&ch);
			a[ch]++;
		}
		int flag=0,sum=0;
		for(i=65;i<=92;i++){
			if(a[i]%2==0){
				sum+=a[i];
			}
			if(a[i]%2==1&&a[i]>1){
				sum+=a[i]-1;
				flag=1;
			}
			if(a[i]==1) flag=1;
		}
		for(i=97;i<=124;i++){
			if(a[i]%2==0){
				sum+=a[i];
			}
			if(a[i]%2==1&&a[i]>1){
				sum+=a[i]-1;
				flag=1;
			}
			if(a[i]==1) flag=1;
		}
		if(flag==1) sum+=1;
		printf("%d\n",sum);
	}
	return 0;
}

