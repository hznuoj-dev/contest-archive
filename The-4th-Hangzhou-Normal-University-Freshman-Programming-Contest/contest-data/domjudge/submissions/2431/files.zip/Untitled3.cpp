#include<stdio.h>
int main(void){
	int n;
	scanf("%d",&n);
	while(n>0){
		printf("Welcome to HZNU\n");
		n-=1;
	}
	return 0;
}
