#include<stdio.h>
#include<string.h>
long long shu,a[100001],huan,b[100001];
	char str[100001][16];
int main()
{
	int t,i,j,k;
	
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		scanf("%lld %s",&shu,str[i]);
		a[i]=shu;
		b[i]=shu;
	}
	scanf("%d",&k);
	for(i=1;i<=t;i++)
	{
		for(j=1;j<=t-i;j++)
		{
			if(a[j]<a[j+1])
			{
				huan=a[j];
				a[j]=a[j+1];
				a[j+1]=huan;
			}
		}
	}
	for(i=1;i<=t;i++)
	{
		if(a[k+1]==b[i])
		{
			printf("%s\n",str[i]);
			break;
		}
	}
	return 0;
}
