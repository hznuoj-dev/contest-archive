#include<stdio.h>
struct zyh
{
	long long int w;
	char qq[16];
}zz[100001];
int main()
{
   struct zyh t;
   int n,i,j,x;
   scanf("%d",&n);
   for(i=0;i<n;i++)
   {
   	scanf("%lld %s",&zz[i].w,zz[i].qq);
   }
   scanf("%d",&x);
   for(i=0;i<n-1;i++)
   {
   	for(j=0;j<n-1-i;j++)
   	{
   		if(zz[j].w>zz[j+1].w)
   		{
   			t=zz[j];
   			zz[j]=zz[j+1];
   			zz[j+1]=t;
		}
	}
   }
   for(i=0;i<n-x;i++)
    printf("%s\n",zz[i].qq);
   return 0;
}
