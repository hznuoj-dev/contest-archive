#include <stdio.h>
#include <string.h>

int main() {
	int t, i, j, n, x, k;
	scanf("%d", &t);
	while (n--) {
		scanf("%d%d", &n, &x);
		if (x != 0)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}