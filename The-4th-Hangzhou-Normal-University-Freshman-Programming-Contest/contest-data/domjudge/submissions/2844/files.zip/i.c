#include<stdio.h>
int main(){
	long int t,n,x,i,s=0,a[10]={0};
	scanf("%ld",&t);
	while(t--){
		scanf("%ld%ld",&n,&x);
		while(1){
			s=s+x;
			if(s<10){
				a[s]=a[s]+1;
				if(a[s]==2||x==0){
					printf("no\n");
					s=0;
					break;
				}
			}
			if(s>=n)
				s=s%n;
			if(s==0){
				printf("yes\n");
				break;
			}
			
		}
		for(i=1;i<10;i++)
				a[i]=0;
	}
	return 0;
}
