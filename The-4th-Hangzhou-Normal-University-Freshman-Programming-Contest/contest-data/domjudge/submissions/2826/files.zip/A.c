
#include<stdio.h>

int main()
{
	int T;
	int n;
	char c[10000];
	int num[200]={0};
	int i,j,m;
	int sum;

	scanf("%d",&T);
	for(j=0;j<T;j++)
	{
		sum=1;
		scanf("%d",&n);

		for(i=0;i<n;i++)
		{
			scanf("%c",&c[i]);
			num[c[i]]+=1;
		}

		for(i=90;i<125;i++)
		{
			if(num[i]>=2)
			{
				sum+=num[i]/2*2;
			}
			num[i]=0;
		}

		printf("%d\n",sum);
	}
	
	return 0;
}

