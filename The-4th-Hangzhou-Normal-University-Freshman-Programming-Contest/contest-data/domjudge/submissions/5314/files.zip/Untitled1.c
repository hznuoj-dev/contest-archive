#include <stdio.h>
int main() {
    int n,m,i,x[12],k;
    int f=0;
    scanf("%d %d",&n,&m);
    for(i=0;i<n;i++){
    	scanf("%d",&x[i]);
    	if(x[i]==0){
    		scanf("%d",&k);
			}
		}
		for(i=0;i<n;i++){
			if(x[i]==0){
    		if(m==0&&k>=2500){
    			if(x[i+1]==1){
    				f=1;
    				break;
				}
			}
			else if(m==1&&k>2100){
				if(x[i+1]==1){
    				f=1;
    				break;
				}
			}
		}
			else if(x[i]==2&&n>=2){
				f=1;
				break;
			}
	}
	if(f==1)
	printf("haoye\n");
	else
	printf("QAQ\n");
	return 0; 
}

