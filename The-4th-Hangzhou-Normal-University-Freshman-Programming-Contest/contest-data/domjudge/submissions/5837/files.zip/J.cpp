#include<stdio.h>
int main(){
	int n,m,x[10],bird=1,niao,k;
	scanf("%d%d",&n,&m);
	if(m==1)
		niao=2100;
	else
		niao=2500;
	for(int i=0;i<n;i++){
		scanf("%d",&x[i]);
		if(x[i]==0)
			scanf("%d",&k);
		if(x[i]==2){
			if(n-i-1>0)
				bird=0;
		}
		if(x[i]==1&&x[i-1]==0){
			if(k>niao)
				bird=0;
		}
	}
	if(bird==0)
		printf("haoye");
	else
		printf("QAQ");
	return 0;
}