#include<stdio.h>
main()
{
	int t,n;
	int a[150][1]={0};
	int sum=0,i,j,x;
	char ch;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		x=n;
		while(n--)
		{
			getchar();
			scanf("%c",&ch);
			a[ch][0]++;
		}
		for(i=0;i<150;i++)
		{
			if(a[i][0]==1)
			{
				sum=1;
				break;
			}
		}
		for(i=0;i<150;i++)
		{
			if(a[i][0]>=2)
			{
				j=a[i][0]/2;
				sum=sum+2*j;
				a[i][0]=0;
			}
			else if(a[i][0]==1)
				a[i][0]=0;
		}
		if(x%2==0 && sum==0)
			sum=1;
		printf("%d\n",sum);
	}
}