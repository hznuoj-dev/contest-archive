#include<bits/stdc++.h>
using namespace std;
int a[100005];
map<int,string>k;
int n,m,q;
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>m;
		a[i]=m;
		cin>>k[m];	
	}
	cin>>q;
	sort(a+1,a+1+n);
	cout<<k[a[n-q]];
	return 0;
}
