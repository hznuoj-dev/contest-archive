#include<stdio.h>

int main() {
	int n, t, i,p = 0, l, x;
	char c;
	int a[55] = { 0 };
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &n);
		n = 2 * n;
		l = 0;
		p = 0;
		for (int i = 0; i < 52; i++) 
		a[i] = 0;
		while (n--) {
			scanf("%c", &c);
			if (c != '\n' && c != ' ') {
				x = c - 65;
				if (x > 25) {
					x -= 6;
				}
				a[x]=a[x]+1;
			}
		}
		for (i = 0; i < 52; i++) {
			if (a[i] % 2 == 1) {
				l += a[i] - 1;
				p++;
			}
			else {
				l += a[i];
			}
		}
		if (p > 0) {
			l++;
		}
		printf("%d\n", l);
	}
}