//
//  main.c
//  L.cpp
//
//  Created by 陶艾嘉 on 2021/12/12.
//

#include <stdio.h>
int main(void){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,x,s,k;
        scanf("%d %d",&n,&x);
        do{
            k=n%x;
            s=n+k;
            n=s;
        }while(k!=0);
        if(k==0){
            printf("yes\n");
    }
    else
        printf("no\n");
    }
}
