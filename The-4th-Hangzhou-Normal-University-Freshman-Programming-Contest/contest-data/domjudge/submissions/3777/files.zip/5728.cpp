#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct ge{
	int w;
	char s[20];
}stiff[100100];
int cap(const void *p,const void *q)
{
	struct ge *pp=(struct ge*)(p);
	struct ge *pq=(struct ge*)(q);
	int a = pp->w;
	int b = pq->w;
	return b-a;
}

int main()
{
    int n,i,k;
    scanf("%d",&n);
    for(i=0;i<n;++i)
    {
    	scanf("%d%s",&stiff[i].w,stiff[i].s);
	}
	qsort(stiff,n,sizeof(struct ge),cap);
	scanf("%d",&k);
	printf("%s\n",stiff[k].s);
    return 0;
} 
