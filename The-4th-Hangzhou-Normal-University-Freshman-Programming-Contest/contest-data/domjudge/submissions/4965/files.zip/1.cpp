#include <stdio.h>
struct jg{
	int a;
	char name[16];
}; 
int main(void){
	struct jg g[100000],t;
	int k, n, i, j, max;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&g[i].a,g[i].name);
	}
	scanf("%d",&k);
	for(i=0;i<k+1;i++){
		max=i;
		for(j=i+1;j<n;j++){
			if(g[j].a>g[max].a)
				max=j;
		}
		if(max!=i){
			t=g[i];
			g[i]=g[max];
			g[max]=t;
		}
	}
	printf("%s\n",g[k].name);
}
