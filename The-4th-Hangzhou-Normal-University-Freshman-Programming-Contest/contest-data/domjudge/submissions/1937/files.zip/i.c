#include<stdio.h>
#include<stdlib.h>
struct g{
	long long int a;
	char b[100];
};
int comp(const void *p, const void *q)
{
	return ((struct g *)q)->a - ((struct g *)p)->a;
}
int main(){
	long long int n;
	long long int t;
	struct g gg[1000];
	scanf("%lld", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%lld%s", &gg[i].a, gg[i].b);
	}
	qsort(gg, n, sizeof(struct g), comp);
	scanf("%lld", &t);
	printf("%s", gg[t].b);
}