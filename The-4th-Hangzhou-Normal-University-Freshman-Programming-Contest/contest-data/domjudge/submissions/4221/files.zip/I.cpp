#include<stdio.h>
#include<stdlib.h>
struct ge{
	 int w;
	char s[16];
};
int comp(const void *p, const void *q){
		return ((struct ge *)q)->w-((struct ge *)p)->w;
	}
int main(){
	struct ge g[10000];
	int n,k,i;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&g[i].w,g[i].s);
	}
	scanf("%d",&k);
	qsort(g,n,sizeof(struct ge),comp);
	printf("%s\n",g[k].s);
}

	
