#include<stdio.h>
#include<stdlib.h>
#define ARRAY_SIZE 10000
struct song{
	int time;
	char name[16];
};
int comp(const void*p,const void*q){
	return((struct song*)q)->time-((struct song*)p)->time;
}
int main(void){
	struct song songArray[ARRAY_SIZE];
	int i,n;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&songArray[i].time,songArray[i].name);
	}
	int k;
	scanf("%d",&k);
	qsort(songArray,n,sizeof(struct song),comp);
    printf("%s",songArray[k].name);
	return 0;
}
