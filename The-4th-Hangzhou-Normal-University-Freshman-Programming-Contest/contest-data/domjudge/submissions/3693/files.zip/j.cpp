#include<bits/stdc++.h>
using namespace std;
int v0=0,v1=0,v2=0;
int main()
{
	int n,m;
	cin>>n>>m;
	int h=m==0?2500:2100;
	for(int i=0;i<n;i++)
	{
		int now;
		cin>>now;
		if(now==0)
		{
			int x;
			cin>>x;
			if(x>=h)	v0++;
		}
		else if(now==1)
		{
			v1++;
		}
		else
		{
			v2++;
		}
	}
	if(v0&&v1)
	{
		cout<<"haoye"<<endl;
	}
	else if(v2&&v1||v2&&v0)
	{
		cout<<"haoye"<<endl;
	}
	else
	{
		cout<<"QAQ"<<endl;
	}
	
	return 0;
}
