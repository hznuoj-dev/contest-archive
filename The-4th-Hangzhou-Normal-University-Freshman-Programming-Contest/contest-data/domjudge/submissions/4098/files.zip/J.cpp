#include<bits/stdc++.h>
using namespace std;
int monst=0;
int main()
{ int n=0,m=0,k=0,l=0,i=0,j=0,bury=0,black=0,ph=0,flag=0;
  cin>>n>>flag;
  if (flag==1) flag=2100; else flag=2500;
  for (i=1;i<=n;i++)
   { cin>>m; 
     if (m==0) 
	 { cin>>monst;
	   if (monst>=flag) ph=1;
     }
     if (m==1) bury=1;
	 if (m==2) black=1; 
   }
  if (black==1 && n>=2) { cout<<"haoye"; return 0;}
  if (ph==1 && bury==1) { cout<<"haoye"; return 0;}
  cout<<"QAQ"; return 0;
  
}
