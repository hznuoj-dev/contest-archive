#include<iostream>
#include<algorithm>
using namespace std;
int a[26];int A[26];
void fenjian(char ch){
	if(ch>='a'&&ch<='z'){
		a[ch-'a']++;
	}else{
		A[ch-'A']++;
	}
}
int main(void){
	int n,m;cin>>n;char ch;
	while(n--){
		cin>>m;
		while(m--){
			cin>>ch;
			fenjian(ch);
		}
		int flag=0,sum=0;
		for(int i=0;i<26;i++){
		sum=sum+a[i]/2+A[i]/2;
			if(a[i]%2==1||A[i]%2==1)
				flag=1;
		a[i]=0;A[i]=0;
		}
		cout<<sum*2+flag<<endl;
	}
} 
