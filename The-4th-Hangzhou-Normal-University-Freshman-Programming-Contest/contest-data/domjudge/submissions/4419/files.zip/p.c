#include <stdio.h>
int s[53]={0};
int main(){
	int a,b,c,d,e,g;
	char f,h;
	scanf("%d",&a);
	while(a>0)
	{
		d=0;
		e=0;
		for(c=1;c<=52;c++)
		scanf("%d",&b);
		for(c=1;c<=b;c++)
		{
			scanf("%c",&f);
			if(f<='Z')
			s[f-'A'+1]=s[f-'A'+1]+1;
			else if(f<='z')
			s[f-'a'+1+26]=s[f-'a'+1+26]+1;
			g=getchar();
		}
		for(c=1;c<=52;c++)
		{
			if(s[c]%2==0)
				d=d+s[c];
			else if(s[c]%2==1&&s[c]>e)
				e=s[c];
		}
		g=d+e;
		printf("%d\n",g);
		a=a-1;
		
	}
	return 0;
}