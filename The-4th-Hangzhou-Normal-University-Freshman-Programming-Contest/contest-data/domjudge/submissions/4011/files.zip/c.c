#include<stdio.h>
int ai[100000];
char ge[100000][15];
main()
{
	int n,a,i=0,j,k;
	int pai=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&ai[i],&ge[i]);
	}
	scanf("%d",&k);
	printf("%s\n",ge[n-k-1]);
}