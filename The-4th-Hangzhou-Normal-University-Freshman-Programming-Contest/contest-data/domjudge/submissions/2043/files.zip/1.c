#include<stdio.h>
#include<string.h>
int main(void){
	int t,i,n,sum,x,y;
	char s[100000],c;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		i=0;
		getchar();
		s[0]=getchar();
		s[1]='\0';
		n-=1;
		sum=0;
		while(n--){
			c=getchar();
			getchar();
			if(i<0){
				i=0;
				s[i]=c;
			}
			else{
			for(x=0;x<=i;x++){
				if(s[x]==c){
					for(y=x;y<i;y++)
						s[y]=s[y+1];
					x=i;
					i-=1;
					sum+=1;
				}
			}
			if(x!=i+2){
				s[i+1]=c;
				i+=1;
				s[i+1]='\0';
			}
			}
		}
		if(i==1&&sum==0)
			printf("2\n");
		else if(i==0&&sum==0)
			printf("1\n");
		else if(s[0]=='\0')
			printf("%d\n",sum*2);
		else
			printf("%d\n",sum*2+1);
	}
return 0;
}