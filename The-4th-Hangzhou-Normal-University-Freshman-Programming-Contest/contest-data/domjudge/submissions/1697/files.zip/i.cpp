#include<bits/stdc++.h>
#define wtn tql
using namespace std;
struct dg{
	int w;
	char name[20];
}a[100010];
int cmp(dg x,dg y){
	return x.w>y.w;
}
int main(void){
	int n;cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i].w>>a[i].name;
	}
	sort(a,a+n,cmp);
	int k;cin>>k;
	cout<<a[k].name<<endl;
return 0;
}

