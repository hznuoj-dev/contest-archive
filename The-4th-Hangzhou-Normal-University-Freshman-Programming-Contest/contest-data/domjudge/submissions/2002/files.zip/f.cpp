#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#define MogeKo qwq

using namespace std;

int t,n,a[30][30],b[30][30];
bool flag;

int main() {
	scanf("%d",&t);
	while(t--) {
		scanf("%d",&n);
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= n; j++)
				scanf("%d",&a[i][j]);
		for(int i = 1; i <= n; i++)
			for(int j = 1; j <= n; j++)
				scanf("%d",&b[i][j]);

		flag = true;
		for(int i = 1; i <= n && flag; i++)
			for(int j = 1; j <= n && flag; j++)
				if(a[i][j] != b[i][j]) {
					flag = false;
					break;
				}
		if(flag) {
			printf("0\n");
			continue;
		}

		flag = true;
		for(int i = 1; i <= n && flag; i++)
			for(int j = 1; j <= n && flag; j++)
				if(a[n-j+1][i] != b[i][j]) {
					flag = false;
					break;
				}
		if(flag) {
			printf("1\n");
			continue;
		}

		flag = true;
		for(int i = 1; i <= n && flag; i++)
			for(int j = 1; j <= n && flag; j++)
				if(a[j][n-i+1] != b[i][j]) {
					flag = false;
					break;
				}
		if(flag) {
			printf("1\n");
			continue;
		}

		flag = true;
		for(int i = 1; i <= n && flag; i++)
			for(int j = 1; j <= n && flag; j++)
				if(a[n-i+1][n-j+1] != b[i][j]) {
					flag = false;
					break;
				}
		if(flag) {
			printf("2\n");
			continue;
		}
		
		printf("-1\n");

	}
	return 0;
}

