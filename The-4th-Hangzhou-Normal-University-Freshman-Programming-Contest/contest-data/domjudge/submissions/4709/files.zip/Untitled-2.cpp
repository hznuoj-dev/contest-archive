#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <sstream>
#include<bits/stdc++.h>
#define ll long long
#define INF 1e6
#define MAXZ 100050 
#define pancake std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
using namespace std;
ll qm (ll base , ll power , ll m){
    ll result = (ll) 1 % m;
    ll t = (ll) base;
    while (power){
        if(power & 1){
            result = result * t % m ;
        }
            t = t * t % m;
            power >>= 1 ;
    }
    return result;
}
typedef struct stu{
       ll a;
       string b;
}stu;
bool cmp (stu x , stu y){
        return x.a > y.a;
}
int main(){
    ll t;
    cin >> t;
    while(t --){
        string word[1050];
        int i = 0;
        while(cin >> word[i] && word[i][word[i].length() - 1] != '.' && word[i][word[i].length() - 1] != '!' && word[i][word[i].length() - 1] != '?'){
              i ++;
        }
        int left = 1 , right = i - 1;
        cout << word[0] << ' ';
        for(int j = 0 ; j < word[i].length() - 1 ; j ++){
            cout << word[i][j];
        }
        while(left <= right){
            cout << ' ';
            if(left == right) cout << word[left];
            else cout << word[left] << ' ' << word[right];
            left ++;
            right --;
        }
        cout << word[i][word[i].length() - 1] << endl;
    }
    return 0;
}