#include<stdio.h>
struct music{
	int l;
	char name[16];
}a;
int comp(const *p,const *q){
	//*p->struct a[101].m;*q->struct a[101].m;
	//int *q=(int*)b;
	 return ((struct music *)q)->l - ((struct music *)p) ->l;
	//return *q-*p; 
}
int main(){
	int n,i,j,k;
	scanf("%d",&n);
	struct music a[n];
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i].l,a[i].name);
		
	}
	qsort(a,n,sizeof(struct music),comp);
	scanf("%d",&k);
	printf("%s",a[k].name);
	return 0;
}

