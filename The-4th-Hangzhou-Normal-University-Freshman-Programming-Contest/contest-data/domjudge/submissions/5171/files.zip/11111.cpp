#include<bits/stdc++.h>
#include<iosfwd>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<string>
#include<vector>
#include<stack>
#include<bitset>
#include<cstdlib>
#include<cmath>
#include<set>
#include<list>
#include<deque>
#include<map>
#include<queue>  
#define endl '\n'; 
using namespace std;
typedef long double ld;
typedef long long ll;
const double eps = 1e-6;
const ll INF = 1e6+10;
#define ywh666 ios_base::sync_with_stdio(0);cin.tie(0);
bool is_prime(ll a){
    if(a < 0) return false;
    if(a == 0 || a == 1 ) return false;
    if(a == 2 || a == 3) return true;
    for(ll i = 2 ; i <= sqrt(a) ; ++i){
        if(a % i == 0) return false;
    }
    return true;
}
const ll  mod = 1e9+7;
ll qpow(ll x , ll n ){
    ll ans = 1;
    while(n > 0){
        if(n & 1 == 1){
            ans = ans * x  % mod ;
        }
        x = x * x % mod;
        n >>= 1;
    }
    return ans % mod;
}
int main(){
    ll  n,m;
    cin >> n >> m;
    vector< vector <ll> > a(n);
    for( ll i = 0 ; i < n ; i ++){
        for(ll j = 0 ; j < m ; j ++){
            ll x ;
            cin >> x;
            a[i].push_back(x);
        }
        sort(a[i].begin(),a[i].end());
    }
    ll sum = 1e15 ;
    for(ll i = 0 ; i < m ; i ++){
        ll cnt = a[0][i];
        ll ans = 0 ;
        for(ll j = 1 ; j < n ; j ++){
            ll cc = lower_bound(a[j].begin(),a[j].end(),cnt) - a[j].begin();
            ans = ans + cc;
        }
        sum = min(sum,ans);
    }
    cout << sum << endl;

    return 0 ;
}