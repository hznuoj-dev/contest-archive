#include<stdio.h>
struct a{
	int b;
}x[10000];
int main(void){
	int n,m,flag=0;
	int f=0;
		scanf("%d %d",&n,&m);
	int i,j,atk;
		for(i=0;i<n;i++){
		scanf("%d",&x[i].b );
	if(x[i].b==0){
		scanf("%d",&atk);
		flag=1;
	}
	if(x[i].b==2&&n>=2){
		printf("haoye\n");
		f=1;}
	}
	if(flag==1&&f==0){
		for(i=0;i<n;i++){
			if(x[i].b ==1){
			printf("haoye\n");
			f=1;
			}
		}
		
	}else if(f==0)
	printf("QAQ\n");
	return 0;
}

