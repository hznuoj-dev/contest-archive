#include <stdio.h>

int main(void) {
	int n,x,i,j;
	scanf("%d",&n);
	struct{
		int a;
		char b[16];
		}st[n+1];
	for(i=0;i<n;i++){
		scanf("%d%s",&st[i].a,st[i].b);
	}
	scanf("%d",&x);
	for(i=0;i<n;i++){
		for(j=i;j<n;j++)
			if(st[j].a>st[i].a){
				st[n]=st[j];
				st[j]=st[i];
				st[i]=st[n];
			}
			if(i==x)
			break;
		}
		printf("%s",st[x].b);	
	return 0;
}

