#include<stdio.h>
int main()
{
	int t;
	scanf("%d", &t);
	while (t--)
	{
		int b[123] = { 0 };
		int c[123] = { 0 };
		int n, i, sum = 0, f = 0;
		char a;
		scanf("%d", &n);
		for (i = 0; i < 2 * n; i++)
		{
			scanf("%c", &a);
			if (i % 2 == 0)
				b[(int)a]++;
		}
		for (i = 0; i < 123; i++)
		{
			if (b[i] % 2 == 0)
			{
				sum += b[i];
			}
			else
			{
				f = 1;
				sum += b[i] - 1;
			}
		}
		if (f)
			sum++;
		printf("%d\n", sum);
	}
	return 0;
}