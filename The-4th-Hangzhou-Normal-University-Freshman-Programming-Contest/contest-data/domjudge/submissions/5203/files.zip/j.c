#include<stdio.h>
int main(){
	int t, n, i, j, r, s=0, q=0, k;
	scanf("%d%d", &n, &t);
	if(t==1) r=2100, k=1;
	if(t==0) r=2500, k=0;
	while(n--){
		scanf("%d", &i);
		if(i==0){
			scanf("%d", &j);
			if((j>=r&&s==0&&k==0)||(j>r&&s==0&&k==1)) s=2;
		}
		else if(i==1&&(s==2||s==1)) s=3;
		else if(i==2&&q>=1&&s==0){
			s=3;
			q=0;
		} 	
		q+=1;
		if(s==2||s==1) s-=1;
		if(s==3){
			printf("haoye\n");
			break;
		}
	}
	if(s!=3) printf("QAQ\n");
}
