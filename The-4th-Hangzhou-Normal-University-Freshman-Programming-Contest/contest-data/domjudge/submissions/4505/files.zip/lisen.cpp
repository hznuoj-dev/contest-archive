#include<bits/stdc++.h>
#include<algorithm>
using namespace std;

struct jk{
	int w;
	char s[20];
	bool operator < (const jk & ano)const{
		return w < ano.w;
	}
	bool operator > (const jk & ano)const{
		return w > ano.w;
	}
	
};
const int b=1e5+10;
vector <jk> a(b),p;
static int n;
int main(void){
	int t,k;
	char s1[16];
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%d%s",&a(i).w,a(i).s);
	}
	sort(a.begin(),a.end())
	scanf("%d",&k);
	printf("%s",a(k+1).s);
	return 0;
}


