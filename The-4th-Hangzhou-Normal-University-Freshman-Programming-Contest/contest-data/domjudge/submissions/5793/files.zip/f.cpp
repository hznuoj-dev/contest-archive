#include<bits/stdc++.h>
using namespace std;
int a[20][20],b[20][20];
int main(){
	int t;
	int n;
	cin>>t;
	for(int i=0;i<t;i++){
		cin>>n;
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				cin>>a[j][k];
			}
		}
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				cin>>b[j][k];
			}
		}
		int flag=-1,flag0=1,flag1=1,flag2=1,flag3=1;
			for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(a[j][k]!=b[j][k]){
					flag0=0;
					break;
				}
				if(flag0==0)break;
			}
		}
		if(flag0==1)flag=3;
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(a[j][k]!=b[n-j-1][n-k-1]){
					flag1=0;
					break;
				}
				if(flag1==0)break;
			}
		}
		if(flag1==1)flag=2;
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(a[j][k]!=b[k][n-j-1]){
					flag2=0;
					break;
				}
				if(flag2==0)break;
			}
		}
		if(flag2==1)flag=1;
		for(int j=0;j<n;j++){
			if(flag==1)break;
			for(int k=0;k<n;k++){
				if(b[j][k]!=a[k][n-j-1]){
					flag3=0;
					break;
				}
				if(flag3==0)break;
			}
		}
		if(flag3==1)flag=1;
		cout<<flag<<'\n';		
	}
	return 0;
}
