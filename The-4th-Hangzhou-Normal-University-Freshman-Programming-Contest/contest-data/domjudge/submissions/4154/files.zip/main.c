#include<stdio.h>
int main()
{
    int n,m,card,sum=0,dam,use=0;
    scanf("%d%d",&n,&m);
    int t;
    t=m==0?2500:2100;
    for (int i=0; i<n; i++) {
        scanf("%d",&card);
        if (card==0) {
            scanf("%d",&dam);
            sum+=dam;
        }
        else if (card==1&&sum>=t){
            printf("haoye");
            use++;
            break;
        }
        else if(card==2&&sum<t&&i<n-1){
            printf("haoye");
            use++;
            break;
        }
    }
    if (use==0) {
        printf("QAQ");
    }
 return 0;
 }
