#include<stdio.h>
#include<string.h>
int main(){
	int n;
	scanf("%d",&n);
char str[100000];
char s; 

	for(n;n>0;n--){
		int a[123] ={0};
		int sum = 0;
int x;
scanf("%d",&x);
getchar(); 
for(int i = 0;i<x;i++){
	scanf("%c",&s);
	getchar();
	a[s]++;
}
int flag = 0;
for(int i =64;i<=122;i++){
	
	if(a[i]%2==0&&a[i]!=0){
		sum +=a[i];
	}
	else if(a[i]>1&&a[i]%2==1)
	{
		sum+=a[i]-1;
		flag = 1;
	}
	else if(a[i]==1)
	flag =1;
}
if(flag)
sum++;
printf("%d\n",sum);

	}
}
