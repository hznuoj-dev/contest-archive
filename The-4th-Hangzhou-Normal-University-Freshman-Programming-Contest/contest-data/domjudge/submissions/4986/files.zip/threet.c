#include<stdio.h>
int main(){
	int t,n;
	scanf("%d",&t);
	while(t--){
		int k=0;
		scanf("%d",&n);
		int a[n];
		int i,j,sum;
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			sum=0;
			for(j=0;j<=i;j++){
				sum=sum+a[j];
				if(sum==7777){
					k++;
					break;
				}
				else if(sum>7777){
					break;
				}
			}
		}
		printf("%d\n",k);
	}
}
