#include <stdio.h>
int main(){
	int n,m,i,j,h;
	int x,k,flag=0;
	int cnt=0;
	scanf("%d%d",&n,&m);
	while(n--){
		if(n==1)	cnt==0;
		scanf("%d",&x);
		if(n==2&&x==0&&x==2)	cnt=0;
		if(x==0){
			i++;
		}
		if(x==1){
			j++;
		}
		if(x==2){
			h++;
		}
		if(x==0)	scanf("%d",&k);
		if(m==0){
			if(k>=2500)	flag++;
		}else if(m==0){
			if(k>=2100)	flag++;
		}
		if(flag&&x==1){
			cnt++;
		}
		if(flag&&x==2){
			cnt++;
		}
	}
	if(cnt)	printf("haoye");
	else	printf("QAQ");
	return 0;
}
