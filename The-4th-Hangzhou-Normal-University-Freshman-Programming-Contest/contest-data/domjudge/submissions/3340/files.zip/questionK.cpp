#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
struct gequ{
	int chendu;
	string geming;
}haoge[100010];
bool cmp(gequ a,gequ b){
	if(a.chendu>b.chendu){
		swap(a.geming,b.geming);
		return 1;
	}else{
		return 0;
	}
}
int main(void){
	int n,a;string b;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a>>b;
		haoge[i].chendu=a;
		haoge[i].geming=b;
	}
	sort(haoge+1,haoge+n+1,cmp);
	int m;cin>>m;
	cout<<haoge[m+1].geming;
} 
