#include<stdio.h>
int main() {
    int t, n, x;
    scanf("%d", &t);
    while (t--) {
        printf("Welcome to HZNU\n");
    }
}
