#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#define pzc 666
using namespace std;
int a[1000010];
int main()
{
	long long x,y;
	int t,n,i,j,k,b,c,l,f,d;	
	char ch;
	cin>>t;
	while(t--)
	{
		cin>>n>>x;
		if(x==0) cout<<"no"<<endl;
		else cout<<"yes"<<endl;
	}
}
