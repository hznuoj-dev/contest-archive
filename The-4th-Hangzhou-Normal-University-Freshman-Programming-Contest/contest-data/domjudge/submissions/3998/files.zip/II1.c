#include<stdio.h>
#include<stdlib.h>
struct song{
	int c;
	char a[15];
};
int comp(const void *p,const void *q){
	return ((struct song *)q)->c-((struct song *)p)->c;
}
int main(void){
	int i,j,n,k;
	scanf("%d",&n);
	struct song num[n],item;
	for(i=0;i<n;i++){
		scanf("%d%s",&num[i].c,num[i].a);
	}
	qsort(num,n,sizeof(struct song),comp);	
	scanf("%d",&k);
	printf("%s",num[k].a);
	return 0;
}


