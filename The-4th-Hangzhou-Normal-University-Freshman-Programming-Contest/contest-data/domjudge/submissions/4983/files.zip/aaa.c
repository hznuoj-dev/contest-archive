/*********************************************************************
    ������:
    ����: 2021-12-12 15:15
    ˵��:
*********************************************************************/
#include <stdio.h>

int sum[256];

int main() {
	int t, i, j, k, n, nn, nn2, num[10] = {0};
	char a;
	scanf("%d", &t);
	getchar();
	for (i = 0; i < t; i++) {
		k = 0;
		for (j = 0; j < 256; j++) {
			sum[j] = 0;
		}
		nn = nn2 = 0;
		scanf("%d", &n);
		getchar();
		while (n--) {
			a = getchar();
			getchar();
			sum[a]++;
		}
		for (j = 0; j < 256; j++) {
			if (sum[j] % 2) {
				nn2 += sum[j] - 1 ;
				k++;
			} else if (sum[j])
				nn += sum[j];
		}
		if (k) {
			num[i] = nn + nn2 + 1;
		} else
			num[i] = nn;
	}
	for (i = 0; i < t; i++) {
		printf("%d\n", num[i]);
	}
	return 0;
}
