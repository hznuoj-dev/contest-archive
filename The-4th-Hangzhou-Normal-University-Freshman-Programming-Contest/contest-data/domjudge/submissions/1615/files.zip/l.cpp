#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
const int maxn=100010;
int a[maxn];
int main(){
	int T;
	cin>>T;
	while(T--){
		int n,x;
		cin>>n>>x;
		if(x==0) cout<<"no"<<endl;
		else cout<<"yes"<<endl;
	}
	return 0;
}
 
