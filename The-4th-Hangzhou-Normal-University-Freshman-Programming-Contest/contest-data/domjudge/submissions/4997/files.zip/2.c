#include <stdio.h>
int main(void){
	int t,n,i,c,d,j;
	int a[1000];
	scanf("%d",&t);
	while(t--){
		c=0;
		d=0;
		j=0;
		scanf("%d",&n);
		for(i=0;i<n;++i){
			scanf("%d",&a[i]);
		}
		for(i=j;i<n;++i){
			d+=a[i];
			if(d==7777){
				c++;
				d=0;
				++j;
				i=j;
				
			}
			if(d>7777){
				d=0;
				++j;
				i=j;
			}
		}
		printf("%d\n",c);
	}
	return 0;
} 
