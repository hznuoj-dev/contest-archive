#include<stdio.h>
int a[10], k[1001];
int main()
{
	int n, m, i, j, flag = 0;
	scanf("%d %d", &n, &m);
	for (i = 0; i < n; ++i)
	{
		scanf("%d", &a[i]);
		if (a[i] == 0)
			scanf(" %d", &k[i]);
	}


	for (i = 0; i < n; ++i)
	{
		if (a[i] == 2 && n > 1)
			flag = 1;

		if (a[i] == 0)
		{
			if (m == 0 && k[i] >= 2500)
			{
				for (j = 0; j < n; ++j)
				{
					if (a[j] == 1)
						flag = 1;

				}
			}
			if (m == 1 && k[i] > 2100)
			{
				for (j = 0; j < n; ++j)
				{
					if (a[j] == 1)
						flag = 1;



				}

			}
		}

	}
	if (flag == 0)
		printf("QAQ");
	if (flag == 1)
		printf("haoye");
}