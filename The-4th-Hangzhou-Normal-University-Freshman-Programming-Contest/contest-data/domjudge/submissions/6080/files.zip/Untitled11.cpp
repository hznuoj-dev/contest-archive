#include <stdio.h>

int main(void){
	int n,kind,judge=0,judge1=0,judge2=0;
	scanf("%d %d",&n,&kind);
	if (n<=1) {
    	judge=0;
    } 
    else{

    	for (int i=1; i<=n; i++){
	    	int k,atc=0;
	    	scanf("%d",&k);
	    	if (k==0){
	    		scanf("%d",&atc);
			if (kind==1&&atc>2100) judge1=1;
			else if (kind==0&&atc>=2500) judge1=1;
		}
		else if (k==1){
			judge2=1;
		}
		else if (k==2){
			judge=1;
			break;
		}
		if (judge1==1&&judge2==1){
			judge=1;
			break;
		}
	}
}
	if (judge==1) printf("haoye\n");
	else if (judge==0) printf("QAQ\n");
	
	return 0;
} 
