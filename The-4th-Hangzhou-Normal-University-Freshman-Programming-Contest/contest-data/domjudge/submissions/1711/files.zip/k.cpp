#include <stdio.h>
int main(){
long long t,n,x,a[100000];
scanf("%lld",&t);
while(t--){
	scanf("%lld%lld",&n,&x);
if(x==0){
	printf("no");
}
else{
	printf("yes");
}	
	printf("\n");
	
}
	return 0;
}
