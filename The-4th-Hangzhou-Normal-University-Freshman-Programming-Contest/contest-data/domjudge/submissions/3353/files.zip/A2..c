#include<stdio.h>

int main()
{
	int T;
	int n;
	char c[20000];
	int num[200]={0};
	int i,j,m;
	int sum;
	int f;

	scanf("%d",&T);
	for(j=0;j<T;j++)
	{
		sum=0;
		f=0;
		scanf("%d",&n);
	
		getchar();
		for(i=0;i<n;i++)
		{
			scanf("%c",&c[i]);
			getchar();
			num[c[i]]+=1;
		}

		for(i=90;i<125;i++)
		{
			if(num[i]>=1)
			{
				if(num[i]%2==0)
				{
					f=f;
				}
				else
				{
					f+=1;
				}
				if(num[i]>=2)
				{
					sum+=num[i]/2*2;
				}
			}
			num[i]=0;
		}
		if(f!=0)
		{
			sum+=1;
		}
		
		printf("%d\n",sum);
	}

	return 0;
}

