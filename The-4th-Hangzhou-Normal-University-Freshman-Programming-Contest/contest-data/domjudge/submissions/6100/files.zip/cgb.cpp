#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct Stu{
	long long num;
	char name[21];
};
int cmp(const void *p,const void *q)
{
	struct Stu *pp =(struct Stu *)(p);
	struct Stu *pq =(struct Stu *)(q);
	int a= pp->num;
	int b= pq->num;
	return a-b;
}
int main()
{
	struct Stu a[11000];
	long long t,i,k,n;

		scanf("%lld",&n);
		for(i=0;i<n;++i)
		{
			scanf("%lld%s",&a[i].num,a[i].name);
		}
		qsort(a,n,sizeof(struct Stu),cmp);
        scanf("%lld",&k);
		printf("%s\n",a[k].name);


	return 0;
}
