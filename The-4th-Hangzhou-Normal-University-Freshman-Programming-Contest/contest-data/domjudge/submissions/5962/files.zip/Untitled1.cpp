#include<stdio.h>
#include<stdlib.h>
int main(void)
{
 	int i,j,a,b,n,c[20],xue,sum,flag;
 	char ch[10010];
 	scanf("%d",&n);
  	while(n--)
 	{
	 	getchar();
		gets(ch);
 		flag=0,sum=0;
		scanf("%d",&a);
		if(a%2!=0)
		{
			sum+=1;
		}
 		
		for(i=0;i<a;++i)
 		{
 			for(j=i+1;j<a;j++)
 			{
 				if(ch[i]==ch[j])
 				{
 					sum+=2;
				}
			}
		}
		if(sum<2*a&&a%2==0)
		{
			sum+=1;
		}
		printf("%d\n",sum);
	}
	
	return 0;
} 
