#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int T,n,a[100];
	char b;
	scanf("%d", &T);
	while (T--)
	{
		memset(a, 0, 240);
		int sum = 0;
		scanf("%d", &n);
		getchar();
		for (int i = 0; i <n; i++)
		{
			scanf("%c", &b);
			a[int(b) - 65] = a[int(b) - 65] + 1;
			getchar();
		}
		for (int i = 0; i < 60; i++)
		{
			sum=sum+(a[i] / 2)*2;
		}
		if (sum < n) {
			sum += 1;
		}
		printf("%d\n", sum);
	}
	return 0;
}
