#include <bits/stdc++.h>
using namespace std;
map<char,int> m;
int main(){
	int i,j,s,n,t;
	cin>>n;
	for (i=0;i<n;++i){
		cin>>t;
		s=0;
		for (j=0;j<t;++j){
			char ch;
			cin>>ch;
			m[ch]++;
			if(m[ch]%2==0){
				s=s+2;
			}
			if (j<t-1)ch=getchar();
		}
		if (s<t) s++;
		cout<<s<<'\n';
		m.clear();
	}
	return 0;
} 
