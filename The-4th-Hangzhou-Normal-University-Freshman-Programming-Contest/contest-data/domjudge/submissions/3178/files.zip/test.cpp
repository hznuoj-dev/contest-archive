#include<stdio.h>

int main(){
	
	int t,i,j;
	long long int n,x;
	scanf("%d",&t);
	
	
	while(t--){
		scanf("%lld %lld",&n,&x);
		i=0;
		int flag[n+1]={0};
		while(i>=0){
			if(x>n){
				printf("no\n");
				break;
			}else{
			
				if (flag[i])  {
				printf("no\n");
				break;
				}
			
				flag[i]=1;
			
				if(i>n-1){
				i=i%(n-1)-1;
					if(i==0){
					printf("yes\n");
					break;
					}
				}
				
			}
		i+=x;
		}
		
	}

	
	
	return 0;
}
