#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int T,i,j,num;
	char a[1001][31],temp;
	scanf("%d",&T);
	while(T--)
	{
		getchar();
		for(i=0;i<1001;i++)
		{
			scanf("%s",a[i]);
			if(a[i][strlen(a[i])-1]=='.'||a[i][strlen(a[i])-1]=='!'||a[i][strlen(a[i])-1]=='?')
			{
				temp=a[i][strlen(a[i])-1];
				a[i][strlen(a[i])-1]='\0';
				num=i;
				break;
			}
		}
		if((num+1)%2==0)
		{
		for(i=0;i<=num/2;i++)
		{
			printf("%s ",a[i]);
			printf("%s ",a[num-i]);
		}
		printf("%c\n",temp);
	}
		if(num%2==0)
		{
			for(i=0;i<=num/2-1;i++)
			{
				printf("%s ",a[i]);
				printf("%s ",a[num-i]);
			}
			printf("%s",a[num/2]);
			printf("%c\n",temp);
		}
}
 } 
