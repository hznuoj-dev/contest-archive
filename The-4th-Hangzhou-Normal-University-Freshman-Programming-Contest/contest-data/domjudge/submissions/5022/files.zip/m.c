#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int main(){
	int i,j,n,T,str,end;
	char x[1001][50];
	scanf("%d",&T);
	while(T--){
		i=0;
		do{
			scanf("%s",&x[i]);
			n=strlen(x[i]);
			i+=1;
		}while(x[i-1][n-1]!='.'&&x[i-1][n-1]!='!'&&x[i-1][n-1]!='?');
		if(i==1)
			printf("%s\n",x[0]);
		else if(i==2){
			printf("%s %s\n",x[0],x[1]);
		} 
		else{
		n=strlen(x[i-1]);
		printf("%s ",x[0]);
		for(j=0;j<n-1;j++){
			printf("%c",x[i-1][j]);
		}
		printf(" ");
		str=1,end=i-2;
		for(j=2;j<i;j++){
			if(j%2==0){
				printf("%s",x[str]);
				str+=1;
			}
			else{
				printf("%s",x[end]);
				end-=1;
			}
			if(j<i-1)
				printf (" ");
		}
		printf("%c\n",x[i-1][n-1]);	
	}
	}
}
