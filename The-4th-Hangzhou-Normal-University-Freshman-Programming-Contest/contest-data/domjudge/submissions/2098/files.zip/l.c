#include <stdio.h>
#include <math.h>
#include <string.h>
int pi=10000;
int main(){ 
    int n,i,t,x;
    char a[pi];
    scanf("%d",&t);
    while(t--){
    	scanf("%d %d",&n,&x);
    	if(x==0){
    		printf("no\n");
		}else if(x==1){
			printf("yes\n");
		}else if((n*x)%x==0){
			printf("yes\n");
		}
	}
	return 0;
}


