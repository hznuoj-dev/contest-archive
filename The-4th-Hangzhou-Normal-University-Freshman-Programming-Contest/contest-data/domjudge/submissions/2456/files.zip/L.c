#include<stdio.h>
int main()
{
	int t;
	scanf("%d", &t);
	while (t--)
	{
		long long int n, x;
		scanf("%lld %lld", &n, &x);
		if (x == 0)
			printf("no\n");
		else
			printf("yes\n");
	}
}
