# include <stdio.h>
# include <stdlib.h>
struct Stu
{
	char name [21];
	long long int num;
};
int cmp(const void *p,const void *q)
{
	struct Stu *pp = (struct Stu *)(p);
	struct Stu *pq = (struct Stu *)(q);
	int a = pp -> num;
	int b = pq -> num;
	return b - a;
}
int main ()
{
	struct Stu a [50];
	int n,i,T;
		scanf ("%d" , &n);	
		for (i=0;i<n;++i)
		{
			scanf ("%lld %s" , &a[i].num , a[i].name);
		}
		qsort (a,n,sizeof(struct Stu),cmp);
		scanf("%d",&T);
		printf ("%s\n" , a[T].name);
	return 0;
}
