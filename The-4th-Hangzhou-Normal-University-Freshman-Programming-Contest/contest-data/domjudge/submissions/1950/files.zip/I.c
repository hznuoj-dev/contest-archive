#include <stdio.h>
#include <stdlib.h>
struct song{
	int x;
	char ch[20];
};
int comp(const void*a,const void*b){
	return ((struct song *)b)->x-((struct song*)a)->x;
}
	struct song a[100000];
int main(){
	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d%s",&a[i].x,a[i].ch);
	}
	qsort(a,n,sizeof(struct song),comp);
	scanf("%d",&k);
	printf("%s\n",a[k].ch);
return 0;
}

