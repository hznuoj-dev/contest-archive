#include<bits/stdc++.h>
using namespace std;
const int N=2e5;
bool ok1=0,ok2=0,ok3=0;
void solve(){
	int n,m,k;cin>>n>>m;
	int a,b;
	for(int i=1;i<=n;i++){
		cin>>a;
		if(a==0){
			cin>>b;
			if(m==0 && b>=2500)ok1=true;
			if(m==1 && b>=2100)ok1=true;
		}
		if(a==1)ok2=true;
		if(a==2)ok3=true;
	}
	if(ok3==1&&n>=2)cout<<"haoye";
	else if(ok1==1&&ok2==1)cout<<"haoye";
	else cout<<"QAQ";
}
int main(){
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
}
