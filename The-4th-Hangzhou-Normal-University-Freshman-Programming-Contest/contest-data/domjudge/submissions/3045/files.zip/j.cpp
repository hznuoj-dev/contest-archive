#include<bits/stdc++.h>
#define wtn tql
using namespace std;
int main(void){
	int n,m;cin>>n>>m;
	int a[2]={0};//a[0]Ϊ1�ƣ�1Ϊ2�ƣ����� 
	vector<int>b(0);//������ 
	int hmgj=0;//���𹥻� 
	for(int i=0;i<n;i++){
		int input;cin>>input;
		if(input>0)a[input-1]++;
		else {
			int in;
			cin>>in;
			b.push_back(in); 
			if(m==0&&in>=2500)hmgj=1;
			else if(m==1&&in>=2100)hmgj=1;
		}
	}
	if(a[0]>=1&&hmgj==1)cout<<"haoye"<<endl;
	else if(a[1]>=1&&b.size()+a[0]>0)cout<<"haoye"<<endl;
	else cout<<"QAQ"<<endl;
return 0;
}

