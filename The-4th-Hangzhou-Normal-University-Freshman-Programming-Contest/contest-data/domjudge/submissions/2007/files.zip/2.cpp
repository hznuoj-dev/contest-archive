#include<stdio.h>
int main(void){
	int T,n,i,j,k,m,a[100000],b;
	scanf("%d",&T);
	while(T--){
		b=0;
		scanf("%d",&n);
		for(k=0;k<n;++k)
			scanf("%d",&a[k]);
		for(i=0;i<n;++i){
			m=0;
			for(j=i;j<n;++j){
				m+=a[j];
				if(m==7777){
					b++;
					break;
				}
			}
		}
		printf("%d\n",b);
	}
	return 0;
}