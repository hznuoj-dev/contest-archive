#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int a[6000];
int main()
{
    int t;
    int sum;
    int flag=0;
    int i,j;
    int n;
    scanf("%d",&t);
    while(t--){
    	scanf("%d",&n);
    	for(i=0;i<n;i++){
    		scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			sum=a[i];
			if(sum==7777){
					flag++;
					continue;
			}
			for(j=i+1;j<n;j++){
				sum+=a[j];
                if(sum==7777&&a[j+1]!=0&&j+1<n){
					flag++;
					break;
			    }
			    else if(sum==7777&&a[j+1]==0&&j+1<n){
					flag+=2;
					j++;
			    }
			    else if(sum==7777&&j==n-1){
					flag++;
					j++;
			    }
			    else if(sum>7777){
				    break;
				}
		    	
			}
		}
		printf("%d\n",flag);
	}
	return 0;
}
/*#include<stdio.h>
#include<stdlib.h>
struct cao{
	int love;
	char name[20];
}a[100005],temp;
int cmp(const void *p,const void *q){
	return (int *)(((struct cao*)q)->love-((struct cao*)p)->love);
}
int main()
{
	int n;
	int k;
	int i,j;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i].love,&a[i].name);
	}
	scanf("%d",&k);
    qsort(a,n,n*sizeof(struct cao),cmp);
    printf("%s\n",a[0].name);
    printf("%s\n",a[1].name);
    printf("%s\n",a[2].name);
	printf("%s",a[k].name);
	return 0;
}*/
/*#include<stdio.h>
int main()
{
	int t;
	int n,k;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&k);
		
	}
	return 0;
}*/

