#include <iostream>
#include <string.h>
using namespace std;
int n,k,x,y;
int main (){
	cin >> n >> k; 
	int f1=0,f2=0,f3=0;
	for (int i = 1; i <= n; i++)
		{
			cin >> x;
			if (x == 0)	{
				cin >> y;
				if (k == 0) 
				{
					if (y >= 2500) f1=1;
				}
				else if (k == 1) {
					if (y > 2100) f1=1;
				}
			}
			else if (x == 1) {
				f2=1;
			}
			else if (x == 2){
				f3=1;
			}
		}
	if (f2 == 1 && f1 == 1) cout << "haoye" << '\n';
	else if (f3 == 1 && n >= 2) cout << "haoye" << '\n';
	else cout << "QAQ" << '\n'; 
}
