#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	for(int i=0;i<a;++i)
	{
		printf("Welcome to HZNU\n");
	}
}
