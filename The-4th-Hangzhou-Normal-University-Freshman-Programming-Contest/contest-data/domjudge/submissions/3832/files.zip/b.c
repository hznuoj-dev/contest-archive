#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int l[100002]={0};
struct
{
	int ai;
	char name[20];	
}ge[100002];
main()
{
	int n,a,i=0,j,k;
	char s[20];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&a,&s);
		ge[i].ai=a;
		strcpy(ge[i].name,s);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n;j++)
		{
			if(ge[i].ai>ge[j].ai)
				l[i]++;
		}
		if(l[i]==n-k-1)
		{
			printf("%s\n",ge[i].name);
			break;
		}
	}
}