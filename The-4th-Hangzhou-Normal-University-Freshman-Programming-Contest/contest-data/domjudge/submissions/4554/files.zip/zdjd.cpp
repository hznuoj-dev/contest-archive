#include<stdio.h>
int main(){
	int i,t,m,n;
  scanf("%d",&t);
  for (i=1;i<=t;i++){
  	scanf("%d%d",&m,&n);
  	if (n==0) printf("no");
  	 else printf("yes");
  	if (i!=t) printf("\n");
  }
  return 0;
}
