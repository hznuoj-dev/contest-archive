#include<stdio.h>
int main(){
	int n,m,g,s1=0,s0=0,s2=0;
		int x[11];
		int ge=0;
		scanf("%d %d",&n,&m);
		int j=0;
	for(int i=0;i<n;i++){
		scanf("%d",&x[i]);
		if(x[i]==0){
			scanf("%d",&g);
			ge+=g;
			s0++;
		}
		if(x[i]==1){
			s1++;
		}
		if(x[i]==2){
			s2++;
		}
	}
	
		if((s0>0&&ge>=2500&&s1>0)||(s2>0&& n>1)){
			printf("haoye");
		}
		else
			printf("QAQ");

}