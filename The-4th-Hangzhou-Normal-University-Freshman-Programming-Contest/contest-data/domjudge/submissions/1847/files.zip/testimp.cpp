#include<stdio.h>
int main (){

long long T;
long long a,b; 
scanf("%lld",&T);
while(T--)
{
	scanf("%lld %lld",&a, &b);
		 if(b == 0)
	{
		printf("no");
	}
	
   else	if(2 * (a - 1) % b == 0){
		printf("yes");
		
	}
     else 
	{
		printf("no");
	}
}

}
