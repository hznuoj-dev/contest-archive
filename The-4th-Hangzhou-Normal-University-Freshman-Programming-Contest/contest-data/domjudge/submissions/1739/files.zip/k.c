#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int main(){
	int T,i,x,a[100],sum1,sum2;
	char c;
	scanf("%d",&T);
	for(i=0;i<T;i++){
		printf("Welcome to HZNU\n");
	}
}
