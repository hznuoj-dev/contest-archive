#include<stdio.h>
#include<stdlib.h>
struct stu{
	char s[16];
	int w;
};
int main(void){
	struct stu stua[10000];
	struct stu t;
	int n,i,k,j,b;
	scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d%s",&stua[i].w,stua[i].s);
		}
		scanf("%d",&b);
	for(i=0;i<n-1;i++){
		k=i;
		for(j=i+1;j<n;j++)
		if(stua[j].w>stua[k].w)
		k=j;
		t=stua[k];stua[k]=stua[i];stua[i]=t;
	}
			printf("%s",stua[b].s);
	return 0;

} 
