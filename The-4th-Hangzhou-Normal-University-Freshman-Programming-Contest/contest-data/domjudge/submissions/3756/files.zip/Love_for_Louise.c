# include <stdio.h>

int main(void)
{
	int t;
	long int n, x, a=0, flag=0;

	scanf("%d", &t);

	for(t; t>0; t--)
	{
		a = 0;
		scanf("%d %d", &n, &x);
	
		a = a + x;

		if(x == 0)
		{
			printf("no\n");

			continue;
		}

		while(a != 0)
		{
			if(a+x <= n-1)
				a = a + x;
			else if(a+ x > n-1)
			{
				a = x-(n-1-a)-1;

				flag++;

				if(flag > 1000000)
				{
					printf("no\n");
			
					break;
				}
			}

			if(a == 0)
			{
				printf("yes\n");

				break;
			}
		}
	}
	return 0;
}