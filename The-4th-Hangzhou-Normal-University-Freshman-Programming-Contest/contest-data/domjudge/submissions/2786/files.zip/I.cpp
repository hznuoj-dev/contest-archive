#include <stdio.h>
int main(void){
	int n,i,j,m,a[10000],b[10000];
	char s[10000][16],ch;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d ",&a[i]);
		for(j=0;ch=getchar(),ch!='\n';j++){
			if(ch!='\n')
			s[i][j]=ch;
		}
		b[i]=j;
	}
	scanf("%d",&m);
	for(i=0;i<n;i++){
		if(m==a[i]){
			for(j=0;j<=b[i];j++){
				printf("%c",s[i][j]);
			}
		}
	}
	return 0;
	}

