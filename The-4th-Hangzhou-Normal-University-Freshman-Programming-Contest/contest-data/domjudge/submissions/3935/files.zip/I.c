#include<stdio.h>
typedef struct{
	int le;
	char name[20];
}st;
st get[100000];
int comp(const void*p,const void*q){
	return ((st*)q)->le-((st*)p)->le;
}
int main(){
	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&get[i].le,get[i].name);
	}
	scanf("%d",&k);
	qsort(get,n,sizeof(st),comp);
	printf("%s",get[k].name);
	return 0;
}
