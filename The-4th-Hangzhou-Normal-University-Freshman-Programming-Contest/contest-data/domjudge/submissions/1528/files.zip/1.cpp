#include<bits/stdc++.h>
using namespace std;

int main(){
	int a;
	scanf("%d",&a);
	for(int i=1;i<=a;i++){
		printf("Welcome to HZNU");
		if(i!=a) printf("\n");
	}
	return 0;
}
