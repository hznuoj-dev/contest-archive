#include<stdio.h>
main()
{
	int n,m;
	int i,ka,a,x;
	int flag=0,f1=0,f2=0;
	scanf("%d %d",&n,&m);
	x=n;
	for(i=1;i<=n;i++)
	{
		scanf("%d",&ka);
		if(ka==0)
		{
			scanf("%d",&a);
			if(m==0)
			{
				if(a>=2500)
				{
					f1=1;
					x--;
				}
			}
			else
			{
				if(a>2100)
				{
					f1=1;
					x--;
				}
			}
		}
		else if(ka==2 && x-1>0)
		{
			flag=1;
		}
		else if(ka==1)
			f2=1;
	}
	if((f1==1 && f2==1) || flag==1)
		printf("haoye\n");
	else
		printf("QAQ\n");
}