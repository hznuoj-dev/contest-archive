#include<stdio.h>
int main(){
	long int t,n,x,s=0,a=0;
	scanf("%ld",&t);
	while(t--){
		scanf("%ld%ld",&n,&x);
		while(1){
			s=s+x;
			if(s==x){
				a=a+1;
				if(a==2||x==0){
					printf("no\n");
					break;
				}
			}
			if(n%x==0){
				printf("yes");
				break;
			}
			if(s>=n)
				s=s%n;
			if(s==0){
				printf("yes\n");
				break;
			}
		}
		s=0;
		a=0;
	}
	return 0;
}
