#include<stdio.h>
#include<string.h>
int main()
{
	int T;
	scanf("%d", &T);
	while (T--)
	{
		int n;
		char ch[100000],
			 ch1[100000];
		scanf("%d", &n);
		getchar();
		gets(ch);
		int x, y = 0;
		for (x = 0; x < strlen(ch); x++)
		{
			if (ch[x] != ' ')
			{
				ch1[y] = ch[x];
				y++;
			}
		}
		int i, j;
		for (i = 0; i < 2 * n - 1; i++)
		{
			for (j = i + 1; j < n; j++)
			{
				char temp;
				if (ch1[i] > ch1[j])
				{
					temp = ch1[i];
					ch1[i] = ch1[j];
					ch1[j] = temp;
				}
			}
		}
		int num = 0;
		int k = 0;
		while (k < n - 1)
		{
			if (ch1[k] == ch1[k + 1])
			{
				num += 2;
				k += 2;
				continue;
			}
			else
			{
				k++;
			}
		}
		if (n % 2 == 0)
		{
			if (n == 2)
			{
				if (num == 0)
				{
					printf("1\n");
				}
				else
				{
					printf("%d\n", num);
				}
			}
			else
			{
				if (num == 0)
				{
					printf("1\n");
				}
				else
				{
					printf("%d\n", num + 1);
				}
			}
		}
		else
		{
			if (n == 1)
			{
				printf("1\n");
			}
			else
			{
				if (num != 0)
				{
					printf("%d\n", num + 1);
				}
				else
				{
					printf("1\n");
				}
			}
		}
	}
	return 0;
}