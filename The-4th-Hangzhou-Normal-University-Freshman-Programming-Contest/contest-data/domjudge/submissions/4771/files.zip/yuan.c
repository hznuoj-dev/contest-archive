#include<stdio.h>//���⿪����������������������˿˿˿IIIIII
#pragma warning(disable:4996)
struct words
{
	int time;
	char sign;

}word[111111];
int main()
{
	int T;
	scanf("%d", &T);
	while (T--)
	{
		int n, i, j, u = 1;
		char w;
		scanf("%d", &n);
		getchar();
		scanf("%c", &word[0].sign);
		getchar();
		word[0].time = 1;
		for (i = 1; i < n; i++)
		{
			scanf("%c", &w);
			getchar();
			for (j = 0; j <= u; j++)
			{
				if (w == word[j].sign)
				{
					word[j].time++;
					break;
				}
			}
			if (j == u + 1)
			{
				word[u].sign = w;
				word[u].time = 1;
				u++;
			}
		}

		i = 0;
		int sum = 0, f = 0;
		while (word[i].sign)
		{
			if (word[i].time % 2 == 0)
				sum += word[i].time;
			else
			{
				if (word[i].time >= 3)
					sum += word[i].time - 1;
				else if(f!=1)
				{
					sum += word[i].time;
					f = 1;
				}
			}
			i++;
		}
		printf("%d\n", sum);
		memset(word, 0, sizeof(word));
	}
	return 0;
}
