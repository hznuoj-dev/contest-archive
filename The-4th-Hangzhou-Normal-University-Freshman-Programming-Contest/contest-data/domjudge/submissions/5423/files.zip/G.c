#include<stdio.h>
#include<string.h>
int time(char *ch[3],int b){
	int i,j,k=0;
	char str[3][3];
	for(i=0;i<3;i++){
		for(j=b;j<b+3;j++){
			str[i][k++]=ch[i][j];
		}
		str[i][k]='\0';
	}
	if(strcmp(str[0]," _ ")==0&&strcmp(str[1],"| |")==0&&strcmp(str[2],"|_|")==0) return 0;
	if(strcmp(str[0],"   ")==0&&strcmp(str[1],"  |")==0&&strcmp(str[2],"  |")==0) return 1;
	if(strcmp(str[0]," _ ")==0&&strcmp(str[1]," _|")==0&&strcmp(str[2],"|_ ")==0) return 2;
	if(strcmp(str[0]," _ ")==0&&strcmp(str[1]," _|")==0&&strcmp(str[2]," _|")==0) return 3;
	if(strcmp(str[0],"   ")==0&&strcmp(str[1],"|_|")==0&&strcmp(str[2],"  |")==0) return 4;
	if(strcmp(str[0]," _ ")==0&&strcmp(str[1],"|_ ")==0&&strcmp(str[2]," _|")==0) return 5;
	if(strcmp(str[0]," _ ")==0&&strcmp(str[1],"|_ ")==0&&strcmp(str[2],"|_|")==0) return 6;
	if(strcmp(str[0]," _ ")==0&&strcmp(str[1],"  |")==0&&strcmp(str[2],"  |")==0) return 7;
	if(strcmp(str[0]," _ ")==0&&strcmp(str[1],"|_|")==0&&strcmp(str[2],"|_|")==0) return 8;
	if(strcmp(str[0]," _ ")==0&&strcmp(str[1],"|_|")==0&&strcmp(str[2]," _|")==0) return 9;
}
void number(int x,char *ch[3]){
	if(x==0){
		strcpy(ch[0]," _ ");
		strcpy(ch[1],"| |");
		strcpy(ch[2],"|_|");
	}
	if(x==1){
		strcpy(ch[0],"   ");
		strcpy(ch[1],"  |");
		strcpy(ch[2],"  |");
	}
	if(x==2){
		strcpy(ch[0]," _ ");
		strcpy(ch[1]," _|");
		strcpy(ch[2],"|_|");
	}
	if(x==3){
		strcpy(ch[0]," _ ");
		strcpy(ch[1],"| |");
		strcpy(ch[2],"|_ ");
	}
	if(x==4){
		strcpy(ch[0],"   ");
		strcpy(ch[1],"|_|");
		strcpy(ch[2],"  |");
	}
	if(x==5){
		strcpy(ch[0]," _ ");
		strcpy(ch[1],"|_ ");
		strcpy(ch[2]," _|");
	}
	if(x==6){
		strcpy(ch[0]," _ ");
		strcpy(ch[1],"|_ ");
		strcpy(ch[2],"|_|");
	}
	if(x==7){
		strcpy(ch[0]," _ ");
		strcpy(ch[1],"  |");
		strcpy(ch[2],"  |");
	}
	if(x==8){
		strcpy(ch[0]," _ ");
		strcpy(ch[1],"|_|");
		strcpy(ch[2],"|_|");
	}
	if(x==9){
		strcpy(ch[0]," _ ");
		strcpy(ch[1],"|_|");
		strcpy(ch[2]," _|");
	}
	}
int main(void){
	char m[3][18];
	char n[3][18];
	char p[3][18]={'\0'};
	int a1=0,b1=0,c1=0,a2=0,b2=0,c2=0,i,j,a,b,c;
	for(i=0;i<3;i++){
		for(j=0;j<18;j++){
			scanf("%c",&m[i][j]);
		}
	}
	for(i=0;i<3;i++){
		for(j=0;j<18;j++){
			scanf("%c",&n[i][j]);
		}
	}
	a1=time(m,0)*10+time(m,3);
	b1=time(m,6)*10+time(m,9);
	c1=time(m,12)*10+time(m,15);
	a2=time(n,0)*10+time(n,3);
	b2=time(n,6)*10+time(n,9);
	c2=time(n,12)*10+time(n,15);
	if(a1==a2&&b1==b2&&c1==c2){
		printf("gang gang hao\n");
	}
	else{
		if(a1<a2||(a1==a2&&b1<b2)||(a1==a2&&b1==b2&&c1<c2)){
			printf("late\n");
			a=a2-a1;
			b=b2-b1;
			c=c2-c1;
		}
		 else if(a1>a2||(a1==a2&&b1>b2)||(a1==a2&&b1==b2&&c1>c2)){
			printf("early\n");
			a=a1-a2;
			b=b1-b2;
			c=c1-c2;
		}
		int a10,a20,b10,b20,c10,c20;
		char str1[3][3],str2[3][3],str3[3][3],str4[3][3],str5[3][3],str6[3][3];
		a10=a/10;
		a20=a%10;
		b10=b/10;
		b20=b%10;
		c10=c/10;
		c20=c%10;
		number(a10,str1);
		number(a20,str2);
		number(b10,str3);
		number(b20,str4);
		number(c10,str5);
		number(c20,str6);
		for(i=0;i<3;i++){
			printf("%s%s%s%s%s%s\n",str1[i],str2[i],str3[i],str4[i],str5[i],str6[i]);
		}
	}
	return 0;
}

