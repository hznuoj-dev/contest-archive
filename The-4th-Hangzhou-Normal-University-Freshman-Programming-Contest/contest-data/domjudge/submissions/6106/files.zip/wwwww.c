#include<stdio.h>
#include<string.h>
int main()
{
	int i,pp,j,t,k,pan;
	char str[1001][31];
	scanf("%d",&t);
	while(t--)
	{
		pan=0;
		for(i=0;i<=30001;i++)
		{
			scanf("%s",str[i]);
			k=strlen(str[i]);
			pp=i;
			for(j=0;j<k;j++)
			{
				if(str[i][j]=='.'||str[i][j]=='!'||str[i][j]=='?')
				pan=1;
	
			}
			if(pan==1)
			break;
		}
		if(pp==0)
		printf("%s\n",str[0]);
		else if(pp!=0)
		{
		printf("%s\n",str[0]);
		for(j=0;j<k-1;j++)
		{
			printf("%c",str[i][j]);
		}
		printf(" ");
	
		
		for(i=1;i<=pp/2;i++)
		{
			
			if(pp%2==0&&i==pp/2)
			    printf("%s",str[i]);
			    else
			     printf("%s ",str[i]);
				
				if(pp%2==0&&i==pp/2)
				break;
				else if(pp%2!=0&&i==pp/2)
				printf("%s",str[pp-i]);
				else
				printf("%s ",str[pp-i]);
			
				
			
		}
		if(pp!=1)
		printf("%c",str[pp][k-1]);
		printf("\n");
	}
	}
	return 0;
}
