#include<stdio.h>
int main()
{
	int n, i, j;
	scanf("%d", &n);
	while (n > 0)
	{
		scanf("%d %d", &i, &j);
		if (j != 0)
			printf("yes");
		else
			printf("no");
		if (n != 1)
			printf("\n");
		n--;
	}
}