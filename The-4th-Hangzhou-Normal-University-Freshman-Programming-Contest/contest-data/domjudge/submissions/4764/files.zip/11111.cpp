#include<bits/stdc++.h>
#include<iosfwd>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<string>
#include<vector>
#include<stack>
#include<bitset>
#include<cstdlib>
#include<cmath>
#include<set>
#include<list>
#include<deque>
#include<map>
#include<queue>  
#define endl '\n'; 
using namespace std;
typedef long double ld;
typedef long long ll;
const double eps = 1e-6;
const ll INF = 2e5+100;
#define ywh666 ios_base::sync_with_stdio(0);cin.tie(0);
bool is_prime(ll a){
    if(a < 0) return false;
    if(a == 0 || a == 1 ) return false;
    if(a == 2 || a == 3) return true;
    for(ll i = 2 ; i <= sqrt(a) ; ++i){
        if(a % i == 0) return false;
    }
    return true;
}
const ll  mod = 1e9+7;
ll qpow(ll x , ll n ){
    ll ans = 1;
    while(n > 0){
        if(n & 1 == 1){
            ans = ans * x  % mod ;
        }
        x = x * x % mod;
        n >>= 1;
    }
    return ans % mod;
}
ll a1[22][22];
ll a2[22][22];
ll a3[22][22];
int main(){
    ll t ;
    cin >> t ;
    while(t--){
        ll n;
        cin >> n ;
        for(ll i  = 0 ; i < n ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                cin >> a1[i][j];
            }
        }
        for(ll i  = 0 ; i < n ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                cin >> a2[i][j];
            }
        }
        ll f = 1 ;
        ll ans = 6;
        for(ll i  = 0 ; i < n && f ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                if(a1[i][j] != a2[i][j]){
                    f = 0;
                    break;
                }
            }
        }
        if(f) ans = 0;
        for(ll i  = 0 ; i < n ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                a3[i][j] = a1[n-1-j][i];
            }
        }
        f= 1;
        for(ll i  = 0 ; i < n && f ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                if(a2[i][j] != a3[i][j]){
                    f = 0;
                    break;
                }
            }
        }
        if(f) ans = min(ans,1LL);
        for(ll i  = 0 ; i < n ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                a3[i][j] = a1[n-i-1][n-j-1];
            }
        }
        f= 1;
        for(ll i  = 0 ; i < n && f ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                if(a2[i][j] != a3[i][j]){
                    f = 0;
                    break;
                }
            }
        }
        if(f) ans = min(ans,2LL);
        for(ll i  = 0 ; i < n ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                a3[i][j] = a1[j][n-i-1];
            }
        }
        f= 1;
        for(ll i  = 0 ; i < n && f ; i ++){
            for(ll j = 0 ; j < n ; j ++){
                if(a2[i][j] != a3[i][j]){
                    f = 0;
                    break;
                }
            }
        }
        if(f) ans = min(ans,1LL);
        if(ans == 6){
            cout << -1 << endl;
        }else{
            cout << ans << endl;
        }
    }

    return 0 ;
}