#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
struct NODE{
	char str[18];
	int w;
};
struct NODE info[100100];
int cmp(const void* p,const void *q)
{
	struct NODE elem1=*(struct NODE*)p;
	struct NODE elem2=*(struct NODE*)q;
	return elem2.w-elem1.w;
}
int main(void)
{
	int i,j;
	int n,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&info[i].w,info[i].str); 
	}
	qsort(info,n,sizeof(struct NODE),cmp);
	scanf("%d",&k);
	printf("%s",info[k].str);
	return 0;
}

