#include<stdio.h>
int main()
{
	int n,m,atk,a[10],i,flag=0,j;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
		if(a[i]==0)
		{
			scanf("%d",&atk);
		}
	}
	for(i=0;i<n;i++)
	{
		if(a[i]==2&&n>1)
		{
			flag=1;
			break;
		}
		else if(a[i]==0)
		{
			for(j=0;j<n;j++)
			{
				if(a[j]==1)
				{
					if(m==0&&atk>=2500)
					{
						flag=1;
						break;
					}
					if(m==1&&atk>2100)
					{
						flag=1;
						break;
					}
				}
			}
		}
	}
	if(flag==1)
	{
		printf("haoye");
	}
	else
	{
		printf("QAQ");
	}
	return 0;
}


