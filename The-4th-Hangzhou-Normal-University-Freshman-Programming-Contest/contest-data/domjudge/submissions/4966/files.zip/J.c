# include <stdio.h>
typedef struct{
	int x;
	int k;
	int id;
}card;
int cmp(const void *a,const void *b){
	card *p=(card *)a,*q=(card *)b;
	return (q->x)-(p->x);
}
int main(){
	int n,m,i,c=0,d=0,e=0;
	card stu[12];
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&stu[i].x);
		if(stu[i].x==0){
			scanf("%d",&stu[i].k);
			if(m==0){
				if(stu[i].k>=2500)
					stu[i].id=1;
			}
			else if(m==1){
				if(stu[i].k>=2100)
					stu[i].id=1;
			}
		}
	}
	qsort(stu,n,sizeof(stu[0]),cmp);
	if(stu[0].x==2&&n>=2)c=1;
	else{
		for(i=0;i<n;i++){
			if(stu[i].x==0&&stu[i].id==1){
				d=1;
			}
			if(stu[i].x==1){
				e=1;
			}
		}
		if(d==1&&e==1)c=1;
	}
	if(c==1)printf("haoye\n");
	else printf("QAQ\n");
}
