#include<stdio.h>
struct music {
	int num1;
	char name[15];
};
int main() {
	int a, b, c;
	struct music list[100000], temp;
	scanf("%d", &a);
	for (b = 0; b < a; b++) {
		scanf("%d %s", &list[b].num1, list[b].name);
	}
	int x, d;
	scanf("%d", &x);
	int y = 0;
	int max = 0,n;
	for (b = 0; b < a; b++) {
		if (max < list[b].num1) {
			max = list[b].num1;
			n = b;
		}
	}
	if (x == 0)
		printf("%s", list[n].name);
	else {
		while (x >= 0) {
			x--;
			int maxs = max;
			max = 0;
			for (b = 0; b < a; b++) {
				if (max < list[b].num1 && list[b].num1 < maxs) {
					max = list[b].num1;
					n = b;
				}
			}
			if (x == 0) {
				printf("%s", list[n].name);
			}
		}
	}
	return 0;
}
