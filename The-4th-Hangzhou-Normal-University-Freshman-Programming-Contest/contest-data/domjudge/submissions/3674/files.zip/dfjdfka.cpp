#include<bits/stdc++.h>
using namespace std;
const int N=2e5;
int a[N];
void solve(){
	int n;cin>>n;
	int sum=0;
	for(int i=1;i<=n;i++)cin>>a[i];
	int l=1,r=1;
	int ans=0;
	while(r<=n){
		sum+=a[r++];
		while(sum>7777)
			sum-=a[l++];
		if(sum==7777)ans++;
	}
	cout<<ans<<'\n';
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
