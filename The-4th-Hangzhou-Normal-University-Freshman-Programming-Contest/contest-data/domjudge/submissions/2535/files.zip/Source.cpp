#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
struct hh{
	int a;
char aa[25];
};
struct hh hhh[100001];
int comp(const void* p, const void* q) {
	return ((struct hh*)q)->a - ((struct hh*)p)->a;
}
int main()
{
	int n,k;
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &hhh[i].a);
		scanf("%s", hhh[i].aa);
	}
	qsort(hhh, n, sizeof(hh), comp);
	scanf("%d", &k);
	printf("%s", hhh[k].aa);
	return 0;
}
