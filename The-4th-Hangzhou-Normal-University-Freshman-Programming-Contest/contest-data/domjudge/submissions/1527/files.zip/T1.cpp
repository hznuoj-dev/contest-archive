#include<bits/stdc++.h>

using namespace std;

int T;
int n;
int a[10000];

int main()
{
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=1;i<=100;++i) a[i] = 0;
		char c;
		int ans =  0;
		for(int i=1;i<=n;++i){
			cin>>c;
			if(c<='Z' && c>='A'){
				a[c-'A'+1]++;
				if(a[c-'A'+1] == 2){
					ans+=2;
					a[c-'A'+1]-=2;
				}
			}if(c<='z'&&c>='a'){
				a[c-'a'+27]++;
				if(a[c-'a'+27] == 2){
					ans+=2;
					a[c-'a'+27]-=2;
				}
			}
		}
		for(int i=1;i<=100;++i){
			if(a[i]){
				ans++;
				break;
			}
		}
		
	
		printf("%d\n",ans);
	}
	return 0;
}
