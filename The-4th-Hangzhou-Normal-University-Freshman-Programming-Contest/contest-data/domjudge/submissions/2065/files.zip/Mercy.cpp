#include<bits/stdc++.h>
using namespace std;

struct str{
	int love;
	string name;
}song[100005];
struct cmp{
	bool operator()(str a,str b){
		return a.love>b.love;
	}
};
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>song[i].love>>song[i].name;
	}
	sort(song,song+n,cmp() );
	int k;
	cin>>k;
	cout<<song[k].name;
} 
