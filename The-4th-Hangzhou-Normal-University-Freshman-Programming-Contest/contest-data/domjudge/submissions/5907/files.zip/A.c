#include<stdio.h>
int main()
{
	int T;
	int n,i,num=0,j;
	char flag[53]="abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char s[100000];
	scanf("%d",&T);
	while(T--)
	{
		int sdf[52]={0};
		num=0;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%c",&s[i]);
		}
		for(j=0;j<53;j++)
		{
			for(i=0;i<n;i++)
			{
				if(s[i]==flag[j])
				{
					sdf[j]+=1;
					
				}
			}
		}
		for(i=0;i<53;i++)
		{
			if(sdf[i]>1&&sdf[i]%2==0)
			{
			
			num+=sdf[i];
			}
			else if(sdf[i]>1&&sdf[i]%2==1)
			{
				num+=(sdf[i]-1);
			}
		}
		for(i=0;i<53;i++)
		{
			if(sdf[i]==1||sdf[i]%2==1)
			{
				num+=1;
				break;
			}
		}
		printf("%d\n",num);
	}
	
	return 0;
}
