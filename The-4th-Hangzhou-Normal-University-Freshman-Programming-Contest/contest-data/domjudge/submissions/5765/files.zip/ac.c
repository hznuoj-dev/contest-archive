#include<stdio.h>
struct every
{
	int zui;
	char a[20];
}ge[100000], *p1,*p2,*term;
int main()
{
	int n, i;
	int k;
	scanf("%d", &n);
	for (i=0;i<n;i++)
		scanf("%d %s",&ge[i].zui, ge[i].a);
	scanf("%d", &k);
	p1 = ge;
	if (k <= (n / 2))
	{
		for (i = 0; i < k + 1; i++,p1++)
		{
			for (p2=p1+1; p2<(ge+n); p2++)
			{
				if (p1->zui<p2->zui)
				{
					*term = *p1;
					*p1 = *p2;
					*p2 = *term;
				}
			}
		}
		printf("%s\n", ge[k].a);
	}
	else
	{
		for (i = 0; i < k + 1; i++, p1++)
		{
			for (p2 = p1 + 1; p2 < (ge + n); p2++)
			{
				if (p1->zui > p2->zui)
				{
					*term = *p1;
					*p1 = *p2;
					*p2 = *term;
				}
			}
		}
		printf("%s\n", ge[n - 1 - k].a);
	}
	return 0;
}
