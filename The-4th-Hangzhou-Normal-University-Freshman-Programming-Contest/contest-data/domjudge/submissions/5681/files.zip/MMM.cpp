#include <bits/stdc++.h>
using namespace std;

char s[1001][30];
char en[30];

int main()
{
	int t,i,j,len,n;
	char c;
	
	cin >> t;
	while(t--)
	{
		
		for(i=1;;i++)
		{
			cin >> s[i];
			len=strlen(s[i]);
			c=s[i][len-1];
			if(c=='.' || c=='?' || c=='!')
				break;
		}
		n=i;
		for(i=0;i<=len-2;i++)
			en[i]=s[n][i];
		for(i=1;i<=n/2;i++)
		{
			if(i==1)
			{
				cout << s[i] << ' ';
				for(i=0;i<=len-2;i++)
					cout << en[i];
				cout << ' ';
		    }
			else if(i!=n/2)
				cout << s[i] << ' ' << s[n-i+1] << ' ';
			else
			{
				if(n%2)
			 		cout << s[i] << ' ' << s[n-i+1] << ' ' << s[n/2+1] << c;
				else
					cout << s[i] << ' ' << s[n-i+1] << c;
			}
		}
	cout << '\n';
	}
	
	return 0;
}
