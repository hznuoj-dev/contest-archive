#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct ac{
	int w;
	char s[16];
};
int cmp(const void *p,const void *q)
{
	struct ac *pp=(struct ac *)(p);
	struct ac *pq=(struct ac *)(q);
	int a=pp->w;
	int b=pq->w;
	return b-a;
}
int main()
{
	int sum,sum2,i,j,x,n;
	struct ac a[100009];
	long long int t;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld%s",&a[i].w,a[i].s);
	}
	qsort(a,n,sizeof(struct ac),cmp);
	scanf("%d",&x);
	printf("%s",a[x].s);
	return 0;
}
