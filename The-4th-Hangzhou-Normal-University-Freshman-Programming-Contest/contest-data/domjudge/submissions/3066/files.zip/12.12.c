#include<stdio.h>
int main(void)
{
	int t=0;
	scanf("%d",&t);
	while(t--)
	{
		int n=0,x=0,i=0,r=0;
		scanf("%d %d",&n,&x);
		if(x==0)
		printf("no");
		else
	{
		for(i=1;i<=n;i++)
		{
			if(i*x%n==0)
			{r=1;break;}
			else
			r=0;
		}
		if(r==1)
		printf("yes\n");
		else
		printf("no\n");
	}
	}
	return 0;
}
