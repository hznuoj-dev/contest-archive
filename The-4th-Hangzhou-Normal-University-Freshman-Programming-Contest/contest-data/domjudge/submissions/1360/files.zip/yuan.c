#include<stdio.h>
int main(){
	int n;
	while(n--){
		printf("Welcome to HZNU\n");
	}
	return 0;
}
