#include<stdio.h>
int main()
{
	struct G
	{
		int wi;
		char si[16];
	}g[10000],d;
	int n,i,k;
	int j,o;
	while(scanf("%d",&n)!=EOF)
	{
	
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&g[i].wi,g[i].si);
	}
	scanf("%d",&k);
	for(i=0;i<n-1;i++)
	{
		o=i;
		for(j=i;j<n;j++)
		{
			if(g[o].wi<g[j].wi)
			{
				o=j;
			}
		}
		if(o!=i)
		{
			d=g[o];
			g[o]=g[i];
			g[i]=d;
			
		}
	}
	printf("%s\n",g[k].si);
	}
	return 0;
}
