#include<stdio.h>
struct m{
	int a;
	char name[1000]; 
};
int comp(const void *p,const void *q){
	return ((struct m *)q)->a-((struct m *)p)->a;	
}
int main(){
	int n,i,k;
	struct m b[100];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d%s",&b[i].a,b[i].name);
	}
	scanf("%d",&k);
	qsort(b,n,sizeof(struct m),comp);
		printf("%s\n",b[k].name);	
return 0;}


