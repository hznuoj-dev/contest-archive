#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		scanf("%d",&n);
    	getchar();
		char a[n];int i,j;
		for(i=0;i<n;i++){
			
		scanf("%c",&a[i]);
		getchar();
		}
	
		for(i=0;i<n-1;i++){
			int flag=0;
			if(a[i]=='0')continue;
			for( j=i+1;j<n;j++){
				if(a[j]=='0')continue;
				if(a[j]==a[i]){
			    a[j]='0';
			    flag=1;
			    break;
					}
					
			}
			if(flag)a[i]='0';
			else a[i]='1';
		}
		
		if(a[n-1]!='0')a[n-1]='1';
		int c=0;
		for( i=0;i<n;i++){
			if(a[i]=='1'){
				c++;
				break;
			}
		}
		
		for( i=0;i<n;i++){
			if(a[i]=='0')
			c++;
		}
		printf("%d\n",c); 
	}
	return 0;
}

