#include<stdio.h>
#include<stdlib.h>
struct song{
	char name[20];
	int love;
};
int cmp(const void*_a,const void*_b){
	struct song*a=(struct song*)_a;
	struct song*b=(struct song*)_b;
	return b->love - a->love;
}
int main(void){
	int n,i,n_yd;
	scanf("%d",&n);
	struct song s[n];
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].love,&s[i].name);
	}
	scanf("%d",&n_yd);
	qsort(s,n,sizeof(struct song),cmp);
	printf("%s\n",s[n_yd].name);
	return 0;
}

