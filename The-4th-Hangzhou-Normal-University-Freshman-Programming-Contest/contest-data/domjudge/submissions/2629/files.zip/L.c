	#include<stdio.h>
int main()
{
	long long int t,n,x;
	scanf("%lld",&t);
	while(t--)
	{
		scanf("%lld %lld",&n,&x);
		if(x==0)
		{
			printf("no\n");
		}
		else
		{
			printf("yes\n");
		}
	}
	return 0;
}

