#include<stdio.h>
int main(){
	int t;
	
	scanf("%d",&t);
	while(t--){
	int n,x;
		scanf("%d%d",&n,&x);
		if(n%x==0)
		printf("yes\n");
		else
		printf("no\n");
	}return 0;
} 
