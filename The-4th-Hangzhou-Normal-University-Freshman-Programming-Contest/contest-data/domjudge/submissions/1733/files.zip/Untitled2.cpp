#include<stdio.h>
int main(void)
{
	int T;
	int n;
	scanf("%d",&T);
	while(T--)
	{
		int h=0;
		scanf("%d",&n);
		int a[n+1];
		for(int i=0 ; i<n ;i++)
		{
			scanf("%d",&a[i]);
		}
		
		for(int i=0 ; i<n ;i++)
		{
			int sum=0;
			for(int j=i ; j<n ;j++)
			{
				sum+=a[j];
				if(sum == 7777)
				{
					h++;
					break;
				}else if(sum > 7777)
				{
					break;
				}
			}	
		}
		printf("%d\n",h);
	}
	return 0;
 } 
