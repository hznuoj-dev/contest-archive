#include<bits/stdc++.h>
#define res register int
#define ll long long
#define N 100050
using namespace std;
int n,m,p,q,t,len,tot,head,tail;
char c[N];
char c2;
char c1[50][1050];
char c3[1050];
char symbol;
int a[70];
int main()
{
    scanf("%d",&t);
    scanf("%c",&c2);
    while(t>0)
    {
    	for(res i=1;i<=60;i++)
    	a[i]=0;
    	tot=0;
    	
    	c2=' ';
    	len=0;
    	while(c2!='\n')
    	{
    		scanf("%c",&c2);
    		c[++len]=c2;
		}
		len=len-1;
        symbol=c[len];
        head=0;
        for(res i=1;i<=len;i++)
        if(!(((c[i]>='A')and (c[i]<='Z'))or ((c[i]>='a')and (c[i]<='z'))))
        {
        	++tot;
        	for(res j=1;j<=i-head-1;j++)
        	c1[tot][j]=c[head+j],a[tot]++;
        	head=i;
		}
		
		head=1,tail=tot;
		for(res i=1;i<=tot;i++)
		{
			if(i%2!=0) 
			{
			  for(res j=1;j<=a[head];j++)
			  printf("%c",c1[head][j]);
			  if(i!=tot) printf(" ");
			  head++;
		    }
			if(i%2==0)
			{
		      for(res j=1;j<=a[tail];j++)
			  printf("%c",c1[tail][j]);
				if(i!=tot) printf(" ");
				tail--;
			}
		}
        printf("%c\n",symbol);
		
    	t--;
	}
}
