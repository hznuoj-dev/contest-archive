#include<stdio.h>
int main(void){
	int n,k,i,j,c;
	long e;
	scanf("%d",&n);
	long a[n+1];
	int d[n+1];
	char b[n+1][16];
	for(i=0;i<n;i++){
		scanf("%ld",&a[i]);
		scanf(" %s",b[i]);
		d[i]=-1;
	}
		scanf("%d",&k);
	for(i=0;i<=k;i++){
		c=-1;
		for(j=0;j<n;j++){
			if(d[j]==-1){
				if(c==-1){
					c=j;
					e=a[j];
				}
				else if(a[j]>e){
					c=j;
					e=a[j];
				}
			}
		}
		d[c]=i;
	}
		printf("%s",b[c]);
	return 0;
}
