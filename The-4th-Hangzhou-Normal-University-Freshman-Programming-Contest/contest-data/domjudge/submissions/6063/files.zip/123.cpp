# include <stdio.h>
int main(void)
{
	int n,m;
	int K,D;
	int i;
	int x;
	int flag=0;
	scanf("%d%d",&n,&m);
	int temp=n;
	int count=0;
	int a=0;
	while (n--)
	{
		
		scanf("%d",&x);
		if (temp>=2&&x==2)
		{
		
			count++;
			break;
			
		}	
		if (x==0&&x==m)
		{
			scanf("%d",&K);
			if (K>=2500)
				flag++;	
		}
		
		else if (x==0&&x!=m)
		{
			scanf("%d",&K);
			if (K>2100);
				flag++; 
		}
		if (x==1)
		{
			a++;
			
		}
		if (a>0)
		{
			if (K>2100)
				flag++;
		}
			
		
	}
	
	if (count>0||flag>=2)
		printf("haoye\n");
	
	else
		printf("QAQ\n");
			
	
	
	return 0;	
} 
