//
//  main.c
//  好想听肆宝唱歌啊
//
//  Created by 徐文哲 on 2021/12/12.
//

#include <stdio.h>
#include <stdlib.h>
struct m{
    int w;
    char song[16];
};
int comp(const void *p,const void *q)
{
    return ((struct m *)q)->w-((struct m *)p)->w;
}
int main(void)
{
    int n,k,i;
    scanf("%d",&n);
    struct m p[n];
    for(i=0;i<n;i++)
    {
        getchar();
        scanf("%d %s",&p[i].w,p[i].song);
    }
    scanf("%d",&k);
    qsort(p,n,sizeof(struct m),comp);
    printf("%s",p[k].song);
    return 0;
}
