#include<stdio.h>
#include<string.h>
int main()
{
	int n,i,num[150]={0};
	char  s[100001];
	int t;
	scanf("%d",&t);
	while(t--)
	{
	scanf("%d",&n);
	for(i=0;i<n;i++)
    {	scanf("%s",&s[i]);	
		num[int(s[i])]++; 
	}
	int max=0,sum=0;
    for(i=0;i<150;i++)
    {
      if(num[i]%2!=0&&num[i]>max)	
      {
		 max=num[i];
	  }	
	}
	sum+=max;
	 for(i=0;i<150;i++)
    {
      if(num[i]%2==0)	
      {
		 sum+=num[i];
	  }	
	}
	printf("%d\n",sum);
		for(i=0;i<150;i++)
    {
		num[int(s[i])]=0; 
	}
	sum=0;
	max=0; 
	}
	return 0;
 } 
