#include <iostream>
#include <vector>
#include <map>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int q;
	cin>>q;
	while(q--){
		int n;
		cin>>n;
		vc<vc<int>> arr1(n,vc<int>(n));
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				cin>>arr1[i][j];
			}
		}
		vc<vc<int>> arr2(n,vc<int>(n));
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				cin>>arr2[i][j];
			}
		}
		int result=0;
		for(int i=0;i<n&&result==0;i++){
			for(int j=0;j<n&&result==0;j++){
				if(arr1[i][j]!=arr2[i][j]) result=1;
			}
		}
		if(result==0) {
			cout<<result<<endl;
			continue;
		}
		for(int i=0;i<n&&result==1;i++){
			for(int j=0;j<n&&result==1;j++){
				if(arr1[j][n-i-1]!=arr2[i][j]) result=2;
			}
		}
		if(result==1) {
			cout<<result<<endl;
			continue;
		}
		else result=1;
		for(int i=0;i<n&&result==1;i++){
			for(int j=0;j<n&&result==1;j++){
				if(arr1[n-j-1][i]!=arr2[i][j]) result=2;
			}
		}
		if(result==1) {
			cout<<result<<endl;
			continue;
		}
		for(int i=0;i<n&&result==2;i++){
			for(int j=0;j<n&&result==2;j++){
				if(arr1[n-i-1][n-j-1]!=arr2[i][j]) result=-1;
			}
		}
		cout<<result<<endl;
	}
	return 0;
}