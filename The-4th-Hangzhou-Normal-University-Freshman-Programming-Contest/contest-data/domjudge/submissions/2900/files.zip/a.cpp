#include<stdio.h>
int main(){
	int n,t,i,j,y,s=0,p=0;
	int a[55]={0};
	char x;
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		s=0,p=0;
		scanf("%d",&n);
		for(j=1;j<=n;j++){
			getchar();
			x=getchar();
			if(x>='a'&&x<='z'){
				y=x-'a'+1;
			}
			else if(x>='A'&&x<='Z'){
				y=x-'A'+27;
			}
			a[y]++;
			
		}
		for(j=1;j<=52;j++){
			if(a[j]>0){
				if(a[j]==1&&p==0){
					s+=1;
					p++;
				}
				else if(a[j]%2==0){
					s+=a[j];
				}
				else if(a[j]%2!=0&&a[j]>1){
					if(p==0){
						s+=a[j];
						p++;
					}
					else{
						s+=a[j]-1;
					}
				}
			}
		}
		printf("%d\n",s);
	}
}
