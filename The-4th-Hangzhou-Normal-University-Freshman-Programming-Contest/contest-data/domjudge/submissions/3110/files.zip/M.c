#include<stdio.h>
#include<string.h>

int main(void){
	char ch[1001][50];
	char str;
	int n,i,j,k;
	scanf("%d",&n);
	while(n--){
		for(i=0;;i++){
			getchar();
			scanf("%s",ch[i]);
			int len=strlen(ch[i]);
			if(ch[i][len-1]=='.'||ch[i][len-1]=='?'||ch[i][len-1]=='!'){
				str=ch[i][len-1];
				ch[i][len-1]='\0';
				break;
			}
		}
		k=i;
		for(i=0,j=k;i<=j;i++,j--){
			if(i==j){
				printf("%s",ch[i]);
			}
			else printf("%s %s",ch[i],ch[j]);
			if(i!=j-1&&i!=j) printf(" ");
		}
		printf("%c\n",str);
	}
	return 0;
}

