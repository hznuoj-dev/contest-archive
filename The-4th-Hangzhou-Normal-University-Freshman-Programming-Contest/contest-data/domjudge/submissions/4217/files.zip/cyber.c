#include<stdio.h>
#include<string.h>
#include<stdlib.h>
long long a[100008];
char b[100008];
int main(){
int n,i,k,t,j,ret,f;
long long sum;
scanf("%d",&t);
while(t--){
	ret=0;
	sum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
	scanf("%d",&a[i]);
	b[i]=1;
	} 
	for(i=0;i<n;i++){
		f=0;
		sum=0;
		for(j=i;j<n;j++)
		{
			sum+=a[j];
			if(sum==7777)
			{ret++;
				break;
			}
			if(sum>7777)
			break;
		}
	}
	printf("%d\n",ret);
}
return 0;
}

