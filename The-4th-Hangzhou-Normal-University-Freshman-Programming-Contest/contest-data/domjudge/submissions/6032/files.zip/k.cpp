#include <stdio.h>
#include <stdlib.h>

struct song {
	char name[20];
	int w;
};

int comp(const void *p, const void *q) {
	return ((struct song *)q)->w - ((struct song *)p)->w;
}

int main() {
	int t, n, x, i, j, k;
	scanf("%d", &n);
	struct song a[100000];
	for (i = 0; i < n; i++) {
		scanf("%s%d", a[i].name, &a[i].w);
	}
	scanf("%d", &k);
	qsort(a, n, sizeof(struct song), comp);
	printf("%s\n", a[k].name);
	return 0;
}