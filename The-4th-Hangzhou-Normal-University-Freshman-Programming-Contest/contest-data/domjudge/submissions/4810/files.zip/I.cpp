#include<stdio.h>
#include<string.h>
struct song{
	int like;
	char name[15];
};
int main(){
	int n,i,j,max,k;
	struct song choose[100000],chooseb[100000];
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d%s",&choose[i].like,choose[i].name);
	max=0;
	for(i=0;i<n;i++){
		for(j=i;j<n;j++){
			if(choose[max].like<=choose[j].like)
				max=j;
		}
		chooseb[i].like=choose[max].like;
		strcpy(chooseb[i].name,choose[max].name);
		max=i+1;
	}
	scanf("%d",&k);
	printf("%s",chooseb[k].name);
	return 0;
}