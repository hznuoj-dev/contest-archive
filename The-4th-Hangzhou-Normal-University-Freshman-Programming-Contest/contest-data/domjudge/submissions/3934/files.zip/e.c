#include<stdio.h>
#include<math.h>
int main(){
	int n, m, i, j, c, min, k;
	scanf("%d%d", &n, &m);
	int f[n][m];
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d", &f[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<m-1;j++){
			c=f[i][j]-f[i][j+1];
			f[i][j]=fabs(c);
		}
	}
//	for(i=0;i<n;i++){
//		for(j=0;j<m;j++){
//			printf("%d ", f[i][j]);
//		}
//		printf("\n");
//	}
	for(i=0;i<n;i++){
		for(j=1;j<m;j++){
			f[i][j]+=f[i][j-1];
		} 
	}
//	for(i=0;i<n;i++){
//		for(j=0;j<m;j++){
//			printf("%d ", f[i][j]);
//		}
//		printf("\n");
//	}
	min=f[0][0];
	for(i=0;i<n;i++){
		for(j=0;j<m-1;j++){
			if(min>f[i][j]){
				k=f[i][j];
				f[i][j]=min;
				min=k;
			}
		}
	}
//	for(i=0;i<n;i++){
//		for(j=0;j<m;j++){
//			printf("%d ", f[i][j]);
//		}
//		printf("\n");
//	}
	printf("%d\n", min);
}
