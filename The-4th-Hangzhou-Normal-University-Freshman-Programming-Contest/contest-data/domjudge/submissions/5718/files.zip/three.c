#include<stdio.h>
#include<string.h> 
int main(){
	int n,i,sum,t,mark[130],temp;
	scanf("%d",&n);
	char str[n];
	sum=0;
	for(i=0;i<130;i++){
		mark[i]=0;
	}
	for(i=0;i<n;i++){
		getchar();
		scanf("%c",&str[i]);
		temp=str[i];
		mark[temp]++;
	}
	for(i=0;i<130;i++){
		sum=sum+mark[i]/2;
	}
	if(sum*2==n){
		printf("%d\n",sum*2);
	}
	else{
		printf("%d\n",sum*2+1);
	}
} 
