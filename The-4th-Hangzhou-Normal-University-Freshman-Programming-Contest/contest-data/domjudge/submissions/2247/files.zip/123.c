#include<stdio.h>
#include<stdlib.h>
struct fan
{
	int a;
	char name[20];
};
int comp(const void *p,const void *q)
{
	return ((struct fan *)q)->a-((struct  fan *)p)->a; 
}
	struct fan b[1000000];
int main()
{
	int n;
	scanf("%d",&n);
	int i;
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&b[i].a,b[i].name);
	}
	qsort (b,n,sizeof(struct fan),comp);
int k;
scanf("%d",&k);
for(i=0;i<n;i++)
{
	if(i==k)
	printf("%s\n",b[i].name);
}
return 0;
} 
