#include<stdio.h>
int main(){
	int T,n,i,s,j;
	char a[100000];
	scanf("%d",&T);
	while(T--){
		s=0;int flag[100000]={0};
		scanf("%d",&n);
		for(i=0;i<n;++i){
			scanf("%c",&a[i]);
			getchar();
		}
		for(i=0;i<n-1;++i){
			flag[i]=1;
			for(j=i+1;j<n;++j){
				if(flag[j]==0&&(a[i]==a[j])){
					s=s+2;
					flag[j]=1;
				}
			}
		}
		if(s==n){
			printf("%d\n",s);
		}
		else{
			printf("%d\n",s+1);
		}
	}
} 
