#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
#include<stdlib.h>
struct st {
	long int a;
	char b[100];
};
int comp(const void* p, const void* q)
{
	return ((struct st*)q)->a - ((struct st*)p)->a;
}
int main(void)
{
	struct st mu[1000];
	int n, m, i;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%ld%s", &mu[i].a, &mu[i].b);
	}
	scanf("%d", &m);
	qsort(mu, n, sizeof(struct st), comp);
	int j;
	for (j = m; j < n; j++)
	{
		printf("%s\n", mu[j].b);
	}
	system("pause");
	return 0;
}