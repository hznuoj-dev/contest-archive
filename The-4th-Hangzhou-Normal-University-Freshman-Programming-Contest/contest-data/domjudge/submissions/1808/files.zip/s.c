#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int main(){
	char alph[52],ch;
	int t,n,i,j,num,sum;
	scanf("%d",&t);
	while(t--){
		memset(alph,0,sizeof(alph));
		sum=0;
		scanf("%d\n",&n);
		for(i=0;i<n;i++){
			scanf("%c",&ch);
			if(ch==' '){
				i--;
				continue;
			}
			if(ch>='a')num=ch-'a'+26;
			else num=ch-'A';
			alph[num]++;
		}
		for(i=0;i<52;i++){
			if(alph[i]){
				sum=sum+(alph[i]/2)*2;
				alph[i]=alph[i]%2;
			}
		}
		for(i=0;i<52;i++){
			if(alph[i]){
				sum++;
				break;
			}
		}
		if(i==52)sum--;
		printf("%d\n",sum);
	}


}