
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
	int P;
	int chen, bao;
	scanf("%d", &P);
	while (P--)
	{
		scanf("%d %d", &chen, &bao);
		if (bao == 0)
		{
			printf("no\n");
		}
		else
		{
			printf("yes\n");
		}
		
	}
}