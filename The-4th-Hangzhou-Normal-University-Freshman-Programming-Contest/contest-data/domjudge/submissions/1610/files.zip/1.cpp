#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	for(int i=0;i<t;i++)
	{
		int a,b;
		cin>>a>>b;
		if(b==0)
			cout<<"no"<<endl;
		else
			cout<<"yes"<<endl;
	}
}
