#include<stdio.h>
#include<string.h>
int main()
{
	struct son
{
	int xi;
	char name[16];

};
	struct son ge[100001];
	struct son t;
	int n, k;
	int m;
	int i, j;
	scanf("%d", &n);
	
	for (i = 0; i < n; i++)
	{
		scanf("%d", &ge[i].xi);
		getchar();
		fgets(ge[i].name,15,stdin);
	}
	scanf("%d", &k);
	for (j = 0; j < n - 1; j++)
	{
		m = j;
		for (i = j+1; i < n; i++)
		{
			if (ge[m].xi < ge[i].xi)
			{
				m = i;
			}
			if (m != j)
			{
				t = ge[m];
				ge[m] = ge[j];
				ge[j] = t;
			}
		}
	}
	printf("%s\n", ge[k].name);

	return 0;
}

