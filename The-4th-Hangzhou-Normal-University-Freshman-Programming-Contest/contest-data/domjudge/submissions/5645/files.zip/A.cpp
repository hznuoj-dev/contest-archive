#include <stdio.h>
#include <stdlib.h>

int cmp( const void *a, const void *b ) {
	return *(char *)a - *(char *)b;
}

int main () {
	int n, m, i, c, end = 0, x = 1;
	scanf("%d", &n);
	char a[100000];
	while (n--) {
		for (i = 0; i < 100000; i++) {
			a[i] = '0';
		}
		scanf("%d", &m);
		getchar();
		for (i = 0; i < m; i++) {
			scanf("%c", &a[i]);
			getchar();
		}

		qsort(a, m, sizeof(a[0]), cmp);
		x = 0;
		for (i = 0; i < m; i++) {
			if (a[i] == a[i + 1]) {
				x = x + 1;
			}
			if (a[i] != a[i + 1] && x != 0) {
				end = end + x + 1;
				end = (end / 2) * 2;
				x = 0;
			}
		}
		if ((2 * (end / 2) + 1) >= m)
			printf("%d\n", m);
		else
			printf("%d\n", (2 * (end / 2) + 1));
		end = 0;
	}
}