#include<stdio.h>
typedef struct{
	int cishu;
	char name[20]
}sing;
int main(void){
	sing s1[100];
	int n,i,k=0,a=0,j,t=0;
	char ch=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&s1[i].cishu,s1[i].name);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++){
		for(j=0;j<n-1-i;j++){
			if(s1[i].cishu>s1[i+1].cishu){
				t=s1[i].cishu;s1[i].cishu=s1[i+1].cishu;s1[i+1].cishu=t;
			}
		}
	}
	printf("%s",s1[0].name);
} 
