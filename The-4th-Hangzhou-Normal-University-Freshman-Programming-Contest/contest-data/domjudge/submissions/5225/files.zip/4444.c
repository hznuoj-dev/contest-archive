#include<stdio.h>
int main(viod) {
	int t, i, j, n, p, x, flag;
	scanf("%d", &t);
	for (i = 1; i <= t; i++) {
		scanf("%d%d", &n, &p);
		flag = 0;
		if (p == 0) {
			printf("no\n");
			return 0;
		}
		else {
			printf("yes\n");
			return 0;
		}
			for (j = 0; j < n; j++) {
				int a[1000] = { 0 };
				x = j;
				while (1) {
					x = (x + p) % n;
					a[x] += 1;
					if (a[x] == 2) {
						break;
					}
					if (x == j) {
						flag = 1; break;
					}
				}
			}

			printf("yes\n");


	}
	return 0;
}












