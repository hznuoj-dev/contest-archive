#include<stdio.h>
#include<stdlid.h>
struct mus {
	long long int num;
	char name[16];
	int k;
};
int comp(const void* p, const void* q) {
	return((struct mus)*q)->num - ((struct mus)*p)->num;
}
int main() {
	struct mus ge[100001];
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%lld%s%d", &ge[i].num, ge[i].name, &ge[i].k);
	}
	qsort(ge, n, sizeof(struct mus), comp);
	printf("%s", ge[k + 1].name);

	