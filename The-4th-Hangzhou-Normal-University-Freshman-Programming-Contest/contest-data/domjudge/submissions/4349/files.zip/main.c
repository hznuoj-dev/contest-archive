#include<stdio.h>
int main()
{
    int n,m,card,sum=0,dam,use1=0,use2=0;
    scanf("%d%d",&n,&m);
    int t;
    t=m==0?2500:2100;
    for (int i=0; i<n; i++) {
        scanf("%d",&card);
        if (card==0) {
            scanf("%d",&dam);
            sum+=dam;
        }
        else if (card==1){
            use1++;
         
        }
        else if(card==2){
            use2++;
           
        }
    }
    if (n>=2&&use2>=1) {
        printf("haoye");
    }
    else if (sum>=t&&use1>=0){
        printf("haoye");
    }
    else {
        printf("QAQ");
    }
 return 0;
 }
