#include<stdio.h>
int main(){
	int T,x,y;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&x,&y);;
		if(y==0){
			printf("NO");
		}
		else
			printf("YES");
	}
}
