#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
struct ge{
	long long xi;
	char name[20];
}a[100010];

int main(){
	int n,k;
	long long xi;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%s",&a[i].xi,a[i].name);
	}
	for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			if(a[j].xi>a[i].xi) {
			struct ge temp;	
			temp=a[j];
			a[j]=a[i];
			a[i]=temp;
			}
		}
	}
	scanf("%d",&k);
	printf("%s",a[k+1].name);
	return 0;
}
