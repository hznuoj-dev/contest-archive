#include <stdio.h>
int main()
{
	int t;
	scanf("%d\n",&t);
	int a[52];
	
	while(t--){
		for(int i=0;i<52;i++) a[i]=0;
		int n;
		scanf("%d\n",&n);
		char str[n];
		int sum=0;
		fgets(str);
		for(int i=0;i<n;i++)
		{
			if(str[2*i]>='A'&&str[2*i]<='Z') 
			    a[str[2*i]-'A']+=1;
			else a[str[2*i]-'a'+26]+=1;
			
		}
		int max=0;
		for(int i=0;i<52;i++)
		{
			if(a[i]%2==1&&a[i]>max) 
		    	max=a[i];
			if(a[i]%2==0) 
			    sum+=a[i];
		}
		sum = sum + max;
		printf("%d\n",sum);
	}
	
	return 0;
}
