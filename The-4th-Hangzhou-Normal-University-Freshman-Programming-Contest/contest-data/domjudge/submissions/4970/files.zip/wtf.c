﻿
#include<stdio.h>
#include<math.h>
#include<string.h>
int main() {
	int i, t, k, j;
	char bq[16][16], m[100];
	int sb[100];
	scanf("%d", &t);
	for (i = 0; i < t; i++) {
		scanf("%d", &sb[i]);
		scanf("%s", bq[i]);
	}
	for (i = 1; i < t; ++i) {
		for (j = 0; j < t - i; ++j) {
			if (sb[j] < sb[j + 1]) {
				strcpy(m, bq[j]);
				strcpy(bq[j], bq[j + 1]);
				strcpy(bq[j + 1], m);
				k = sb[j];
				sb[j] = sb[j + 1];
				sb[j + 1] = k;
			}
		}
	}
	scanf("%d", &k);
	printf("%s\n", bq[k]);

}

