#include<stdio.h>
#include<stdlib.h>
struct song{
	long long int level;
	char geming[19];
};
int comp(const void*p,const void *q){
	return((struct song*)q)->level-((struct song*)p)->level;
}
int main(void){
struct song s[10000];
long long int n,k;
scanf("%lld",&n);
for(long long int i=0;i<n;i++){
	scanf("%lld %s",&s[i].level,s[i].geming);
}
scanf("%lld",&k);
qsort(s,n,sizeof(struct song),comp);
for(long long int i=k;i<n;i++){
printf("%s\n",s[i].geming);
}
 return 0;
}
