#include<stdio.h>
#include<stdlib.h>
int cmp(const void*a,const void*b)
{
	return (*(int*)a-*(int*)b);
}
char name[100011][17]={0};
int a[100011]={0},b[100011]={0};
main()
{
	int n,k,max=0,i,q,p;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		b[i]=a[i];
		scanf("%s",name[i]);
	}
	scanf("%d",&k);
	qsort(b,n,sizeof(int),cmp);
	for(q=1;q<=n;q++)
	{
		if(b[n-k]==a[q])
			break;
    }
	printf("%s",name[q]);
}