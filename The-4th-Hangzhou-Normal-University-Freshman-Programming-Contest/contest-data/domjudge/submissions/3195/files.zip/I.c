#include<stdio.h>
#include<stdlib.h>
int comp(const void *p, const void *q);
struct b {
	long long w;
	char name[20];
};
int comp(const void *p, const void *q) {
	return (*(int *)q - *(int *)p);
}
int main() {
	struct b a[100000];
	int n, i, k;
	scanf("%d", &n);
	for (i = 0;i < n;i++) {
		scanf("%lld %s", &a[i].w, a[i].name);
	}
	scanf("%d", &k);
	qsort(a, n, sizeof(struct b), comp);
	printf("%s\n",a[k].name);
	return 0;
}
