#include<stdio.h>

int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int n;
		scanf("%d",&n);
		int s[100666];
		int i;
		for(i=1;i<=n;i++){
			scanf("%d",&s[i]);
			
		}
		int count=0;
		int j;
		int sum;
		for(i=1;i<=n-1;i++){
			sum=s[i];
			//if(sum==7777)
			for(j=i+1;j<=n;j++){
				sum=sum+s[j];
				if(sum==7777){
					count++;
					break;
				}
				
			}
		}
		printf("%d\n",count);
	}
	return 0;
} 
