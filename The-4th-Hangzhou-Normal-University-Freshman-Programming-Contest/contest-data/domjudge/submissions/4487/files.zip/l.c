#include<stdio.h>
#include<string.h>
#include<math.h>
struct g{
	int cd;
	char gm[16];
};
int comp(const void *p,const void *q){
	return ((struct g *)q)->cd-((struct g *)p)->cd;
}
int main(void){
	struct  g a[100000];
	struct g max,t;
	int i,n,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
		scanf("%d %s",&a[i].cd,&a[i].gm); 
	scanf("%d",&k);
	qsort(a,n,sizeof(struct g),comp);
	printf("%s",a[k].gm); 
	return 0;
}
