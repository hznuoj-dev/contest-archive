#include<stdio.h>
struct w{
	char b;
	int c;
}; 
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,r=0;
		int j;
		scanf("%d",&n);
		char k;
		struct w hw[n];
		for(int i=0;i<n;i++){
			k=getchar();
			getchar();
			for(j=0;j<r;j++){
				if(k==hw[j].b){
					hw[j].c++;
				}	
			}
			if(j==r){
				hw[r].b=k;
				hw[r].c=1;
				r++;
			};
		}
		int zs=n,cd=0;
		for(int i=0;i<r;i++){
			if(hw[i].c%2==0){
				cd+=hw[i].c;
				zs-=hw[i].c;
			}
			
		}
		if(zs>0)cd+=1;
		printf("%d\n",cd);
	}
}
