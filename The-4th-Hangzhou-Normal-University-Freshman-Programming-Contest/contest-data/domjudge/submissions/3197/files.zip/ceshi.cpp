#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main() {
	int t, a, b;
	scanf("%d", &t);
	while (t--) {
		scanf("%d %d", &a, &b);
		if (b == 0) {
			printf("no\n");
			continue;
		}
		printf("yes\n")
	}
	return 0;
}