#include<stdio.h>
#include<string.h>
int main() {
	int n, k, i, j, x, y, z;
	long long int w[100000];
	char s[100000];
	int t[100000];
	scanf("%d", &n);

	for (i = 0; i < n; i++) {
		scanf("%lld %s", &w[i], &s[i]);
	}

	scanf("%d", &k);
	if (k == 0) {
		for (i = 0; i < n; i++) {
			if (w[i] > w[k]) {
				k = i;
			}
		}
		printf("%s", s[k]);
	}
	else {
		for (i = 0; i < n; i++) {
			int z = w[i];
			for (j = 0; j < n; j++) {
				if (z < w[j]) {
					z = w[j];
				}
				t[i] = j;
			}
		}
		y = t[k];
		printf("%s", s[y]);


	}
	return 0;
}

