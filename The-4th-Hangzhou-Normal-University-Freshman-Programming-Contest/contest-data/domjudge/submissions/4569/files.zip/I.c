#include<stdio.h>
#include<stdlib.h>
struct stu{
	char s[16];
	int w;
};
int comp(const void*p,const void*q){
	return((struct stu *)q)->w-((struct stu *)p)->w;
}
int main(void){
	
	
	int n,i,k;
	scanf("%d",&n);struct stu stua[n];
		for(i=0;i<n;i++){
			scanf("%d%s",&stua[i].w,stua[i].s);
		}
		scanf("%d",&k);
	qsort(stua,n,sizeof(struct stu),comp);
//	for(i=0;i<n-1;i++){
//		k=i;
//		for(j=i+1;j<n;j++)
//		if(stua[j].w>stua[k].w)
//		k=j;
//		t=stua[k];stua[k]=stua[i];stua[i]=t;
//	}
			printf("%s",stua[k].s);
	return 0;

} 
