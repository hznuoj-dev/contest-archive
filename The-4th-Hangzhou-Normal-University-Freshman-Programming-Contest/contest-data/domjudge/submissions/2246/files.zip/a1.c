#include<stdio.h>
#include<string.h>
int main(){
	int t,n,m,i,j,x,y;
	char sa[100010];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		getchar();
		m=0;
		while(n--){
			scanf("%c",&sa[m++]);
		}
		for(i=0,y=0;i<m;i++){
			for(j=i+1,x=1;j<m;j++){
				if(sa[j]==sa[i]&&sa[i]!='0'){
					x++;
					sa[j]='0';
				}
			}
			y=x/2+y;
		}
		if(2*y==m){
			printf("%d\n",m);
		}else if(2*y<m){
			printf("%d\n",2*y+1);
		}
	}
	return 0;
}
