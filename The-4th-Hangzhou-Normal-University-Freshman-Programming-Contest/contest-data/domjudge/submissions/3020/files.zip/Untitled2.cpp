#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct sad{
	int like;
	char c[30];
}n[1000000];
int cmp(const void*p,const void*q){
	return ((struct sad*)q)->like-((struct sad*)p)->like; 
}
int main(){
	int num,k;
	scanf("%d",&num);
	for(int i=0;i<num;i++){
		getchar();
		scanf("%d %s",&n[i].like,n[i].c);
	}
	qsort(n,num,sizeof(n[0]),cmp);
	scanf("%d",&k);
	printf("%s",n[k].c);
}
