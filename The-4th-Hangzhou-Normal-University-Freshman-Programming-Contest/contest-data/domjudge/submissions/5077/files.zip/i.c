#include <stdio.h>
int main(){
	int n,i,k,w;
	char s[100];
	scanf("%d",&t);
	while(t--){
		scanf("%d %c",&w,&s[i]);
		k=n-1;
		scanf("%d",k);
		
	}
	printf("%d",k+1);
}
