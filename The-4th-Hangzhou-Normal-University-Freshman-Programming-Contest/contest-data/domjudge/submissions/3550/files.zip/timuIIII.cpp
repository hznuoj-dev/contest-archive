#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main (){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,x,flag=1;
		scanf("%d %d",&n,&x);
		if(n<x){
			printf("no\n"); 
			flag=0;
		}
		if(x==0){
			printf("no\n");
			flag=0;
		}
		if(flag==1){
			printf("yes\n");
		}
	} 
	return 0;
} 
