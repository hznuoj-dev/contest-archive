#include<stdio.h>
#include<stdlib.h>
struct student
{
	long long int xiai;
	char b[100];
}temp;

struct student a[100005];
int comp(const void *p,const void *q)
{
	return ((struct student *)q)->xiai-((struct student *)p)->xiai;
}

int main()
{
	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&a[i].xiai,a[i].b);
	}
	qsort(a,n,sizeof(struct student),comp);
	scanf("%d",&k);
	printf("%s",a[k].b);
	return 0;
}