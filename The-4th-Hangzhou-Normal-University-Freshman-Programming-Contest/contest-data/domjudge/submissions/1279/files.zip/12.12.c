#include<stdio.h>
int main()
{
	int n = 0;
	scanf("%d",&n);
	while(n--)
	{
		printf("Welcome to HZNU\n");
	}
	return 0;
}