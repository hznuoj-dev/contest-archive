#include <bits/stdc++.h>
using namespace std;

int main()
{
	int t,n,x;
	
	cin >> t;
	while(t--)
	{
		cin >> n >> x;
		if(x!=0)	cout << "yes" << '\n';
		else	cout << "no" << '\n';
	}
}
