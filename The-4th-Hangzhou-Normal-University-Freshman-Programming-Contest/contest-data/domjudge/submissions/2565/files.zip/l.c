#include <stdio.h>
int main(void)
{
	int T, n, x;
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d",&n, &x);
		if (x)printf("yes");
		else printf("no");
		putchar('\n');
	}

	return 0;
}