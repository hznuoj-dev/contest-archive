#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
int n, i, j, temp;
int main()
{
	long long a, b;
	scanf("%d", &n);
	while (n--)
	{
		scanf("%lld%lld", &a, &b);
		if (b!=0)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}