#include<bits/stdc++.h>
using namespace std;
long long a[500001];

int main () {
	int t,c,n;
	int num;
	cin>>t;

	for(int i = 1; i <= t; i++) {
		cin>>n;
		a[0] = 0;
		c = 0;
		for(int j = 1; j <= n; j++) {
			scanf("%d",&num);
			a[j] = a[j-1] + num;
		}
		for(int p = 1; p <= n; p++) {
			for(int q = p - 1; q >= 0; q--) {
				if(a[p]-a[q]==7777) {
					c++;
					break;
				}
				if(a[p]-a[q]>7777) {
					break;
				}
			}
		}
		cout<<c<<"\n";
	}
	return 0;
}
