#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct music
{
	int love;
	char m[200];
}sing[100005];

int cmp(const void *p,const void *q)
{
 struct music *pp = (struct music*)p;
 struct music *pq = (struct music*)q;
 int a = pp->love;
 int b = pq->love;
 return b-a;
}

int main()
{
	int n,i,j,k;
	scanf("%d",&n);
	i=1;
	for(i=0;i<n;++i)
	{
		scanf("%d %s",&sing[i].love,sing[i].m);
	}
	scanf("%d",&k);
	qsort(sing,n,sizeof(struct music),cmp);
	printf("%s",sing[k].m);
	return 0;
}
