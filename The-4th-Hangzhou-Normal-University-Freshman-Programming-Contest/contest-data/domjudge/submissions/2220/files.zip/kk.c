#include<stdio.h>

int main(void){
	printf("");
	return 0;
}

