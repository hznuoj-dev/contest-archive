#include<stdio.h>
char name[100011][17]={0};
int a[100011]={0};
main()
{
	int n,k,max=0,i,q,ci=0,p;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&a[i]);
		scanf("%s",name[i]);
	}
	scanf("%d",&k);
	for(p=1;p<=k+1;p++)
	{
		max=0;
		for(q=1;q<=n;q++)
		{
			if(a[max]<a[q])max=q;
		}
		if(p<k+1)a[max]=0;
		else ci=max;
	}
	printf("%s\n",name[ci]);
}