#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<cmath>
using namespace std;
int main(){
	int t;
	cin>>t;
	while(t--){
		long int n,i;
		cin>>n;
		char c;
		getchar();
		long int len=0;
		multimap<char,long int>ss;
		multimap<char,int>::iterator pos;
		for(i=0;i<n;i++){
		cin>>c;
		pos=ss.find(c);
		if(pos==ss.end()){
			ss.insert(make_pair(c,1));
		}
		else{pos->second++;}
	} 
		for(pos=ss.begin();pos!=ss.end();pos++){
		len+=(pos->second)/2;
		}
		for(pos=ss.begin();pos!=ss.end();pos++){
			if(pos->second%2!=0)len++;break;
		}
  cout<<len<<endl;

} 
} 
