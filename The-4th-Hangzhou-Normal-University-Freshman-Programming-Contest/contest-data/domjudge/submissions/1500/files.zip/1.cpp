#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;

int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cout<<"Welcome to HZNU"<<endl;
	}
	system("pause");
}
