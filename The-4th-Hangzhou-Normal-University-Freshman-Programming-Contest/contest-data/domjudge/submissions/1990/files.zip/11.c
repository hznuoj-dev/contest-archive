#include<stdio.h>
#include<stdlib.h>
typedef struct{
	int a;
	char b[100];
}I;
int compare(const void*p,const void*q)
{
	I *c=(I*)p,*d=(I*)q;
	return d->a-c->a;
}
int main()
{
	int n;
	scanf("%d",&n);
	I st[n];int i;int y;
	for(i=0;i<n;i++)
	{
		scanf("%d%s",&st[i].a,st[i].b);
	}
	scanf("%d",&y);
	qsort(st,n,sizeof(I),compare);
	printf("%s\n",st[y].b);
	return 0;
}
