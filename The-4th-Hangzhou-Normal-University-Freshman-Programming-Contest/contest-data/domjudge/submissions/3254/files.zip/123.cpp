# include <stdio.h>
int a[5000];
int main(void)
{
	int T;
	int n;
	int i, j, k;
	int temp;
	int sum;
	int count;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d", &n);
		for (i = 0; i < n; ++i)
		{
			scanf("%d", &a[i]);
		}
		for (i = 0; i < n - 1; ++i)
		{
			k = i;
			for (j = i + 1; j < n; ++j)
			{
				if (a[j] < a[k])
				{
					k = j;
				}

			}
			temp = a[k];
			a[k] = a[i];
			a[i] = temp;
		}
		count = 0;
		for (i = 0; i < n - 1; ++i)
		{
			sum = a[i];

			for (j = i + 1; j < n; ++j)
			{
				
				sum = sum + a[j];
				if (sum == 7777)
				{
					count++;
					sum=sum-a[j];
					continue;
				}
			}
		}
		printf("%d\n", count);
	}

	return 0;
}
