//l
#include<stdio.h>
int main(){
	int flag;
	long long t,n,x,count,num,turn;
	scanf("%lld",&t);
	while(t--){
		scanf("%lld %lld",&n,&x);
		flag=0;
		if(x==0){
			printf("no\n");
		}
		else{
			printf("yes\n");
		}
	}
} 
