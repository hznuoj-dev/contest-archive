//#include <iostream>
//#include <vector>
//#include <map>
//using namespace std;
//#define vc vector
//#define pii pair<int,int>
//
//const int mod=1e9+7;
//typedef long long ll;
////struct NUM{
////	char arr[3][3];
////}num[10];
//int time[2][6];
//
//char num[10][3][3]={{{' ','_',' '},
//					{'|',' ','|'},
//					{'|','_','|'}},
//					
//					{{' ',' ',' '},
//					{' ',' ','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{' ','_','|'},
//					{'|','_',' '}},
//					
//					{{' ','_',' '},
//					{' ','_','|'},
//					{' ','_','|'}},
//					
//					{{' ',' ',' '},
//					{'|','_','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{'|','_',' '},
//					{' ','_','|'}},
//					
//					{{' ','_',' '},
//					{'|','_',' '},
//					{'|','_','|'}},
//					
//					{{' ','_',' '},
//					{' ',' ','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{'|','_','|'},
//					{'|','_','|'}},
//					
//					{{' ','_',' '},
//					{'|','_','|'},
//					{' ','_','|'}}};
//void putNum(int *num1){
//	for(int i=0;i<3;i++){
//		for(int j=0;j<6;j++){
//			cout<<num[j][i][0]<<num[j][i][1]<<num[j][i][2];
//		}
//		cout<<'\n';
//	}
//}
//int cmp(vc<vc<char>> &a,vc<vc<char>> &b){
//	for(int i=0;i<3;i++){
//		for(int j=0;j<3;j++){
//			if(a[i][j]!=b[i][j]) return 0;
//		}
//	}
//	return 1;
//}
//void inPut(){
//	vc<vc<vc<char>>> tim1(6,vc<vc<char>>(3,vc<char>(3)));
//	for(int k=0;k<2;k++){
//		for(int i=0;i<3;i++){
//		for(int cur=0;cur<6;cur++){
//			for(int j=0;j<3;j++){
//				scanf("%c",&time1[cur][i][j]);
//			}
//		}
//	}
//	for(int i=0;i<6;i++){
//		for(int j=0;j<10;j++){
//			if(cmp(time1[i],num[j])) time[k][i]=j;
//		}
//	}
//	}
//}	
//
//int main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);
//	inPut();
//	putNum(time[0]);
//	
//	return 0;
//}
#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cout.tie(0);
	cin.tie(0);
	int n,m;
	cin>>n>>m;
	queue<pii> que;
	for(int i=0;i<m;i++){
		int num;
		cin>>num;
		que.push(make_pair(num,num));
	}
	for(int i=1;i<n;i++){
		int total=que.size();
		vc<int> arr(m);
		for(int j=0;j<m;j++){
			cin>>arr[j];
		}
		sort(arr.begin(),arr.end());
		while(total--){
			pii cur=que.front(); que.pop();
			vc<int>::iterator l=lower_bound(arr.begin(),arr.end(),cur.first);
			vc<int>::iterator r=lower_bound(arr.begin(),arr.end(),cur.second);
			if(*r!=cur.second) r--;
			if(l<=r) que.push(cur);
			else{
				if(r+1!=arr.end()) que.push(make_pair(cur.first,*(r+1)));
				if(l!=arr.begin()) que.push(make_pair(*(l-1),cur.second));
			}
		}
	}
	int min=1<<30;
	while(!que.empty()){
		pii cur=que.front(); que.pop();
		if(min>cur.second-cur.first) min=cur.second-cur.first;
	}
	cout<<min;
	return 0;
}