#include<stdio.h>
#include<string.h>
int main()
{
	char a[100005];
	int b[53];
	int n,i,m,sum,sum1;
	scanf("%d",&n);
	while(n>0)
	{
		for(i=1;i<=52;++i)
		b[i]=0;
		sum=0;sum1=1;
		scanf("%d",&m);
		getchar();
		scanf("%[^\n]",a);
		for(i=0;i<strlen(a);++i)
		{
			if(a[i]>='a'&&a[i]<='z')
			b[a[i]-'a'+1]++;
			else if(a[i]>='A'&&a[i]>='Z')
			b[a[i]-'A'+27]++;
		}
		for(i=1;i<=52;++i)
		{
			if(b[i]%2==0) 
			{
				sum=sum+b[i];
			}
		}
		for(i=1;i<=52;++i)
		{
			if(b[i]%2==1&&b[i]>=3) 
			{
				sum1=sum1+b[i]-1;
			}
		}
		printf("%d\n",sum+sum1);
		n=n-1;
	}
	return 0;
}
