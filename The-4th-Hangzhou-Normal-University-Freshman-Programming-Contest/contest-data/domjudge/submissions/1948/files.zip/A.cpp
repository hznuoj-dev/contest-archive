#include<bits/stdc++.h>
using namespace std;
const int N=100010;

int t;
int n;
char a[N];
int f[60];

int main(){
	cin >>t ;
	while(t--){
		cin >> n;
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++){
			cin >> a[i];
			f[a[i]-65]++;
		} 
		int maxo=0,maxj=0;
		for(int i=1;i<=60;i++){
			if(f[i]>0){
				if(f[i]%2==0&&f[i]>maxo){
					maxo=f[i];
				} else if(f[i]%2==1&&f[i]>maxj){
					maxj=f[i];
				}
			}
		}
		cout << (maxj+maxo)<<'\n';
	}
	


return 0;
}

