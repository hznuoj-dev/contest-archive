#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main() {
	
	int flag=0;
	
	int t;
	int n;
	
	int i,j,k;
	
	int a[100001];
	int b[100001];
	
	scanf("%d",&t);
	while(t--) {
		scanf("%d",&n);
		for(i=0;i<n;i++) {
			scanf("%d",&a[i]);
		}
		//��� 
		for(j=0;j<n;j++) {
			for(k=j+1;k<n;k++) {
				b[j]=(a[j]+a[k]);
			}
		}
		//
		for(k=0;k<n;k++) {
			if(b[k]==7777) {
				flag++;
			}
		}
		//
		printf("%d\n",flag);	
	}
	return 0;
} 
