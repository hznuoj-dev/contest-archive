
#define N 100001
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
int arr[N] = { 0 };
char brr[N][30] = { 0 };
char trr[N] = { 0 };
int main()
{
	int P, i, j, t;
	int chen;

	scanf("%d", &P);
	for (i = 0; i < P; i++)
	{
		scanf("%d %s", &arr[i], &brr[i]);
	}
	for (i = 0; i < P - 1; i++)
	{
		for (j = 0; j < P - 1 - i; j++)
		{
			if (arr[j + 1]>arr[j])
			{
				t = arr[j]; arr[j] = arr[j + 1]; arr[j + 1] = t;
				strcpy(trr, brr[j]); strcpy(brr[j], brr[j + 1]); strcpy(brr[j + 1], trr);
			}
		}
	}
	scanf("%d", &chen);
	printf("%s", brr[chen]);
}