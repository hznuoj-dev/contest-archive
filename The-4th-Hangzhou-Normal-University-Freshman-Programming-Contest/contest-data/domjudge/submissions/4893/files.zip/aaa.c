/*********************************************************************
    ������:
    ����: 2021-12-12 15:15
    ˵��:
*********************************************************************/
#include <stdio.h>

int sum[256];

int main() {
	int t, i, j, k, n, nn, nn2, mm, num[10] = {0};
	char a;
	scanf("%d", &t);
	getchar();
	for (i = 0; i < t; i++) {
		k = 1;
		for (j = 0; j < 256; j++) {
			sum[j] = 0;
		}
		mm = nn = nn2 = 0;
		scanf("%d", &n);
		getchar();
		while (n--) {
			a = getchar();
			getchar();
			sum[a]++;
		}
		for (j = 0; j < 256; j++) {
			if (sum[j] % 2) {
				if (!nn2)
					mm = sum[j];
				else if (sum[j] > mm)
					mm = sum[j];
			} else if (sum[j])
				nn += sum[j];
		}
		num[i] = nn + mm;
	}
	for (i = 0; i < t; i++) {
		printf("%d\n", num[i]);
	}
	return 0;
}
