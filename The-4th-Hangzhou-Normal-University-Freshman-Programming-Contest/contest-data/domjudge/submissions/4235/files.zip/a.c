#include <stdio.h>
int main()
{
	int T,ch[64]={0},n,i,s,sum,m;
	char a[2];
	scanf("%d",&T);
	while(T--)
	{
		sum=0;
		scanf("%d",&n);
		m=n;
		while(n--)
		{
			scanf("%s",a);
			s=(int)(a[0])-65;
			ch[s]++;
		}
		for(i=0;i<64;i++)
		{
			sum=sum+2*(ch[i]/2);
		}
		if(m>sum)
		sum++;
		printf("%d\n",sum);
	}
 }
