#include<stdio.h>
#include<stdlib.h>
struct girl{
    char name[20];
    int time;
};
int comp(const void *p,const void *q){
    return((struct girl *)q)->time-((struct girl *)p)->time;
}
int main(){
    struct girl godness[100000];
    
        int n,i;
        scanf("%d",&n);
        for(i=0;i<n;i++){
            scanf("%d %s",&godness[i].time,godness[i].name);
        }
        qsort(godness,n,sizeof(struct girl),comp);
        int k,m;
    scanf("%d",&k);
    i=k;
            printf("%s",godness[i].name);
        }

        
