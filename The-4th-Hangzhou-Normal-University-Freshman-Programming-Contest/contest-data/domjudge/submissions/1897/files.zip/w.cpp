#include<stdio.h>
int main(){
	int t,x,y;
	long long int n,m;
	scanf("%d",&t);
	while(t--){
		x=0;
		scanf("%lld %lld",&n,&m);
		if(m==0)
		printf("no\n");
		else
		printf("yse\n");
	}
}
