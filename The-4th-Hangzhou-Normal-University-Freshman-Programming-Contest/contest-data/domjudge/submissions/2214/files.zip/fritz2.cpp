#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<cmath>
#include<cctype>
using namespace std;
int main(){
int n;
cin>>n;
while(n--){
	cout<<"��Welcome to HZNU"<<endl;
}
} 
