#include<stdio.h>
#include<string.h>
#include<math.h>
struct data{
	long long int love;
	char name[16];
}song;
int main(){
	long long int i,n,k,j,t,m,flag;;
	char n1[16];
	scanf("%lld",&n);
	struct data song[n+1];
	for(i=0;i<n;i++){
		scanf("%lld",&song[i].love);
		scanf("%s",song[i].name );
}
	scanf("%lld",&k);
	while(1){
		flag=0;
		for(m=0;m<n-1;m++){
				if(song[m+1].love >song[m].love ){
					t=song[m+1].love ;
					song[m+1].love=song[m].love;
					song[m].love=t;
					strcpy(n1,song[m+1].name );
					strcpy(song[m+1].name ,song[m].name );
					strcpy(song[m].name ,n1);
					flag=1;
				}		
		} 
		if(flag==0) break;
	}
	printf("%s",song[k].name );
	
	return 0;
} 
