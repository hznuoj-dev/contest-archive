#include<stdio.h>
struct song{
	int c;
	char a[15];
};
int main(void){
	int i,n,k;
	scanf("%d",&n);
	struct song num[n];
	for(i=0;i<n;i++){
		scanf("%d%s",&num[i].c,num[i].a);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++){
		if(num[i].c==k){
			printf("%s",num[i].a);
			break;
		}
		
	}
	return 0;
}

