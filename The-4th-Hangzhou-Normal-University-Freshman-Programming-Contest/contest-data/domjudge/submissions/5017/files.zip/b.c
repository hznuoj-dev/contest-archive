#include <stdio.h>
int main(void) {
	int n,m,flag1=0,x[10],atk[10],flag2=0,i;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&x[i]);
		if(x[i]==0){
			scanf("%d",&atk[i]);
			if(m==0){
				if(atk[i]>=2500)
					flag1=1;
			}
			else if(m==1){
				if(atk[i]>2100)
					flag1=1;
			}
		}
	}
	for(i=0;i<n;i++){
		if(x[i]==1){
			if(flag1==1){
				flag2=2;
			}
		}
	}
	for(i=0;i<n;i++){
		if(x[i]==2){
			if(flag1==0){
				if(n>=2){
					flag2=1;
				}
			}
		}
	}
	for(i=0;i<n;i++){
		if(flag2==1){
			if(n>2&&x[i]==0){
				if(m==0){
				if(atk[i]>=2500)
					flag2=2;
			}
			else if(m==1){
				if(atk[i]>2100)
					flag2=2;
			}
			}
		}
	}
	if(flag2==2){
		printf("haoye");
	}
	else printf("QAQ");
	return 0;
}

