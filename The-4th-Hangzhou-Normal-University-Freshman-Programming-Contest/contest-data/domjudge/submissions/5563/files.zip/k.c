#include <stdio.h>
#include <stdlib.h>
int comp(const void *p, const void *q){
	return (*(int *)q - * (int *)p);
}
struct number {
	long long int w;
	char s[20];

};
struct number a[100000];
long long int change[100000];

int main() {
	int n, i, j;
	scanf("%d", &n);
	for (i = 1; i < n+1; i++) {
		scanf("%lld%s", &a[i].w, a[i].s);
		change[i] = a[i].w;
	}
	qsort(change, 100000, sizeof(long long int), comp);
	int k;
	scanf("%d", &k);
	for (i = 1; i < n+1; i++) {
		if (change[k] == a[i].w){
			printf("%s\n", a[i].s);
	}
}
}


