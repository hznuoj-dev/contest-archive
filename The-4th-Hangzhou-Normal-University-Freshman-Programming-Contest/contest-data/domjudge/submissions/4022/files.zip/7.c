#include <stdio.h>
int main(void){
	int a[100][100];
	int b[100][100];
	
	int t,i,j,flag,n;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		flag=1;
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&a[i][j]);
			}
		}
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&b[i][j]);
				if(flag&&b[i][j]!=a[i][j])flag=0;
			}
		}
		if(flag==0){
			flag=2;
			for(i=0;i<n;i++){//shun
				for(j=0;j<n;j++){
					if(a[i][j]!=b[j][n-i-1]){
						flag=0;
						break;
					}
				}
				if(a[i][j]!=b[n-j-1][n-i-1]){
						flag=0;
						break;
					}
			}
		}
		if(flag==0){
			flag=2;
			for(i=0;i<n;i++){//ni
				for(j=0;j<n;j++){
					if(a[i][j]!=b[n-j-1][i]){
						flag=0;
						break;
					}
				}
				if(a[i][j]!=b[n-j-1][i]){
						flag=0;
						break;
					}
			}
		}
		if(flag==0){
			flag=3;
			for(i=0;i<n;i++){//fan
				for(j=0;j<n;j++){
					if(a[i][j]!=b[n-i-1][n-j-1]){
						flag=0;
						break;
					}
				}
			}
		}
		
		if(flag==1){
			printf("0\n");
		}else if(flag==2){
			printf("1\n");
		}else if(flag==3){
			printf("2\n");
		}else{
			printf("-1\n");
		}
	}
	return 0;
}
