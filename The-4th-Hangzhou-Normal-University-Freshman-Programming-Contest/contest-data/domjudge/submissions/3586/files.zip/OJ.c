#include <stdio.h>
int num[100000];

int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int n, i, j, sum = 0, count = 0;
		scanf("%d", &n);
		for (i = 0; i < n; i++) {
			scanf("%d", &num[i]);
			if (num[i] == 7777) {
				count++;
			}
		}
		for (i = 0; i < n; i++) {
			sum = 0;
			sum += num[i];
			for (j = i + 1; j < n; j++) {
				sum += num[j];
				if (sum == 7777) {
					count++;
				}
			}
		}
		printf ("%d\n", count);
	}
}