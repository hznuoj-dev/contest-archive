#include<stdio.h>

int main(void) {
	int t,n,x,i,flag;
	scanf("%d",&t);
	while(t--){
		flag=0;
		scanf("%d %d",&n,&x);
		if(x!=0){
			for(i=1;i<=n;i++){
				if(i*x/n==0){
					flag=1;
					break;
				}
			}
		}
		if(flag)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}


