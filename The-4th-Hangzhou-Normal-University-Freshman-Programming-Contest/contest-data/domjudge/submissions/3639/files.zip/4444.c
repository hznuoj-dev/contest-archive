#include<stdio.h>
int main(viod) {
	int t , i, j, n, p, x,flag;
	scanf("%d", &t);
	flag = 0;
	for (i = 1; i <= t; i++) {
		scanf("%d%d", &n, &p);
		int a[1000] = { 0 };
		for (j = 0; j < n; j++) {
			x = j;
			while (1) {
				x = (x + p + 1) % n -1;
				a[x] += 1;
				if (a[x] == 2) {
					break;
				}
				if (x == j) {
					flag = 1; break;
				}
			}
		}
		if (flag == 1)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}











