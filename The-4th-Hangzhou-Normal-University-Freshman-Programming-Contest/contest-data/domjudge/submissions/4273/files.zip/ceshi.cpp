#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct a {
	int a;
	char b[15];
};

int nmx(const void *p, const void *q) {
	struct a *pp = (struct a *)(p);
	struct a *qq = (struct a *)(q);
	int a = pp->a, b = qq->a;
	return b - a;
}


int main() {
	int t, i;
	scanf("%d", &t);
	struct a a[t];
	for (i = 0; i < t; i++)
		scanf("%d %s", &a[i].a, a[i].b);
	scanf("%d", &i);
	qsort(a, t, sizeof(struct a), nmx);
	printf("%s", a[i].b);

	return 0;
}



