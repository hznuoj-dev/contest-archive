#include<stdio.h>
struct g
	{
		long long id;
		char ge[30];
		long long pos;
	};
struct g kt[100010];
int main()
{
	long long T,i,max,p,j,l;
	scanf("%lld",&T);
	for(i = 0;i < T;i++)
	{
		scanf("%lld %s",&kt[i].id,kt[i].ge);
	}
	scanf("%lld",&l);
	for(j = 0;j < T;j++)
	{
		for(i = 0;i < T;i++)
		{
			max = 0;
			if(kt[i].id > max)
			{
				max = kt[i].id;
				p = i;
			}
		}
		kt[p].id = 0;
		kt[p].pos = j;
	}
	for(i = 0;i < T;i++)
	{
		if(kt[i].pos == l)
		{
			printf("%s",kt[i].ge);
		}
	}
	return 0;
} 
