#include<stdio.h>
int main(void){
	int n;
	scanf("%d",&n);
	int a,b;
	while(n--){
	scanf("%d%d",&a,&b);
	if(b!=0){
		printf("yes\n");
	}	
	if(b==0){
		printf("no\n");
	}
	}
	return 0;
}
