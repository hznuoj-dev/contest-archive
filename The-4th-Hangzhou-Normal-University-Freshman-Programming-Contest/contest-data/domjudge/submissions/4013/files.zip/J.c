#include<stdio.h>
struct Card_stru
{
	int card;
	int atk;
}a[11];
int main()
{
	int n, m;
	int i;
	int flag1 = 0,flag2=0,flag3=0;
	scanf("%d%d",&n,&m);
	if (n <= 1) printf("QAQ\n");
	else if(n>1)
	{
		for (i = 0; i < n; i++)
		{
			scanf("%d", &a[i].card);
			if (a[i].card == 0)
			{
				scanf("%d", &a[i].atk);
				if (m == 0 && a[i].atk >= 2500) flag1 = 1;
				else if (m == 1 && a[i].atk > 2100) flag1 = 1;
			}
		}
		if (flag1 == 1)
		{
			for (i = 0; i < n; i++)
			{
				if (a[i].card == 1) flag2 = 1;
				else if (a[i].card == 2 && n > 3) flag2 = 1;
			}
			if (flag2 == 1) printf("haoye\n");
			else if (flag2 == 0) printf("QAQ\n");
		}
		else if (flag1 == 0)
		{
			for (i = 0; i < n; i++)
			{
				if (a[i].card == 2 && n > 3) flag3 = 1;
			}
			if (flag3 == 1) printf("haoye\n");
			else if (flag3 == 0) printf("QAQ\n");
		}
	}
	return 0;
}