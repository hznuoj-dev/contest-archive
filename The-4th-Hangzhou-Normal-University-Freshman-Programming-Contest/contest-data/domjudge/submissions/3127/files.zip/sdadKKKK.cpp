#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int w[100][100], s[100][100];
int main(void) {
	int T;
	int n, i, j, k, i1, j1, flag;
	scanf("%d", &T);
	while (T--) {
		flag = 0;
		scanf("%d", &n);
		for (i = 1; i <= n; ++i) {
			for (j = 1; j <= n; ++j) {
				scanf("%d", &w[i][j]);
			}
		}
		for (i1 = 1; i1 <= n; ++i1) {
			for (j1 = 1; j1 <= n; ++j1) {
				scanf("%d", &s[i1][j1]);
			}
		}

		i1 = 1;
		for (i = 1; i <= n; ++i) {
			if (flag == 1) {
				break;
			}
			j1 = 1;
			for (j = 1; j <= n; ++j) {

				if (w[i][j] != s[i1][j1]) {
					flag = 1;
					break;
				}
				++j1;
			}
			++i1;
		}
		if (flag == 0) {
			printf("0\n");
		}
		i1 = 1;
		if (flag == 1) {
			for (j = 1; j <= n; ++j) {
				if (flag == 2) {
					break;
				}
				j1 = 1;
				for (i = n; i >= 1; --i) {

					if (w[i][j] != s[i1][j1]) {
						flag = 2;
						break;
					}
					++j1;
				}
				++i1;
			}
		}

		if (flag == 1) {
			printf("1\n");
		}
		if (flag == 2) {
			i1 = 1;
			for (i = n; i >= 1; --i) {
				if (flag == 3) {
					break;
				}
				j1 = 1;
				for (j = n; j >= 1; --j) {

					if (w[i][j] != s[i1][j1]) {
						flag = 3;
						break;
					}
					++j1;
				}
				++i1;
			}

		}
		if (flag == 2) {
			printf("2\n");
		}
		if (flag == 3) {
			i1 = 1;
			for (j = n; j >= 1; --j) {
				if (flag == 4) {
					break;
				}
				j1 = 1;
				for (i = 1; i <= n; ++i) {

					if (w[i][j] != s[i1][j1]) {
						flag = 4;
						break;
					}
					++j1;
				}
				++i1;
			}

		}
		if (flag == 3) {
			printf("1\n");
		} else if (flag == 4) {
			printf("-1\n");
		}

	}
}