#include<stdio.h>
#include<math.h>
int main(void){
	int t,n,x,c=0,i,m=1;
	long long int s;
	scanf ("%d",&t);
	while(t--){
		scanf("%d%d",&n,&x);
		if(x!=0)
		printf("yes\n");
		else
        printf("no\n");
	}
	return 0;
}
