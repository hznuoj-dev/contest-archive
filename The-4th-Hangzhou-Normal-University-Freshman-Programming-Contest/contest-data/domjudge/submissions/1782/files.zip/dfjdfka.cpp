#include<bits/stdc++.h>
using namespace std;
void solve(){
	cout<<"Welcome to HZNU"<<'\n';
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
