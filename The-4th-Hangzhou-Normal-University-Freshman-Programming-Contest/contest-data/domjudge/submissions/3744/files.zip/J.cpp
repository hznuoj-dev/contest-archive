#include<bits/stdc++.h>
using namespace std;
int monst;
int main()
{ int n,m,k,l,i,j,bury=0,black=0,ph=0,flag;
  cin>>n>>flag;
  if (flag==1) flag=2100; else flag=2500;
  for (i=1;i<=n;i++)
   { cin>>m; 
     if (m==0) 
	 { cin>>monst;
	   if (monst>=flag) ph=1;
     }
     if (m==1) bury=1;
	 if (m==2) black=1; 
   }
  if (black==1 && n>=2) { cout<<"haoye"; return 0;}
  if (ph==1 && bury==1) { cout<<"haoye"; return 0;}
  cout<<"QAQ"; return 0;
  
}
