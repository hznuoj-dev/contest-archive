#include <stdio.h>
#include <string.h>
int main(void)
{
	int j,t,i,s;
	long long len;
	scanf("%d",&t);
	getchar();
	char a[32000],*p,b[1001][31],c;
	while(t--)
	{
		i=1;
		s=1;
		gets(a);
		len=strlen(a);
		c=a[len-1];
		p=strtok(a," .");
		while(p)
		{
			strcpy(b[i++],p);
			p=strtok(NULL," .!?");			
		}
		if(i==3)
		{
			printf("%s %s",b[2],b[1]);
			printf("%c",c);
			printf("\n");
			continue;
		}
		printf("%s",b[1]);
		printf(" %s",b[i-1]);
		for(j=2;j<=(i-1)/2;j++)
		{
			printf(" %s",b[j]);
			printf(" %s",b[i-j]);
		}
		if((i-1)%2==1)
		{
			printf(" %s",b[(i-1)/2+1]);
		}
		printf("%c",c);
		printf("\n");
	}
	return 0;
}
