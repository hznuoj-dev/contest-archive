#include<stdio.h>
int main(void){
	int n,m;
	int a,d;
	int flag=-1;
	scanf("%d %d",&n,&m);
	int x[n];
	int t=n;
	while(n--){
		scanf("%d",&x[t-
		n]);
		if(x[t-n]==0){
		scanf("%d",&a);
	}
	if(t==1){
	flag=1;
		break;
	}
	if(t>2&&x[t-n]==2){
	flag=1;
		break;
	}
	if(m==0&&a>=2500&&x[t-n]==1)
		flag=1;
	 if(m==1&&a>=2100&&x[t-n]==1)
		flag=1;      	
} 
if(flag==1){
printf("haoye");
}
else{
	printf("QAQ");
}
return 0;
}







