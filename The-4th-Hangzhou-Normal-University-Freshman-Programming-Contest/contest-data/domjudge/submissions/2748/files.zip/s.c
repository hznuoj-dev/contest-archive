#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
char word[1000][40];
int main(){
	int t,n,l,i;
	char ch;
	scanf("%d\n",&t);
	while(t--){
		n=0;
		l=0;
		memset(word,'\0',sizeof(word));
		while(ch=getchar()){
			if(ch==' '){
				n++;
				l=0;
			}
			else if(ch=='.'||ch=='!'||ch=='?'){
				l=0;
				n++;
				break;
			}else{
				word[n][l]=ch;
				l++;
			}
		}
		getchar();
		for(i=0;i<n/2;i++){
			printf("%s",word[i]);
			printf(" ");
			printf("%s",word[n-1-i]);
			if(i!=n/2-1)printf(" ");
		}
		if(n%2==1)printf(" %s",word[(n-1)/2]);
		printf("%c\n",ch);
	}
}