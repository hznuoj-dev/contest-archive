#include <iostream>
#include <vector>
#include <map>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int n,sit;
	cin>>n>>sit;
	if(sit) sit=2100;
	else sit=2500;
	int flag=0;
	int a=0,b=0;
	for(int i=0;i<n;i++){
		int k;
		cin>>k;
		if(k==2&&n>=2) flag=1; 
		else if(k==1) b=1;
		else{
			int atk;
			cin>>atk;
			if(atk>sit||atk==sit&&sit==2500) a=1;
			
		}
		if(a*b) flag=1;
	}
	if(flag) cout<<"haoye\n";
	else cout<<"QAQ\n";
	return 0;
}

//#include <iostream>
//#include <vector>
//#include <map>
//using namespace std;
//#define vc vector
//#define pii pair<int,int>
//
//const int mod=1e9+7;
//typedef long long ll;
////struct NUM{
////	char arr[3][3];
////}num[10];
//int time[2][6];
//
//char num[10][3][3]={{{' ','_',' '},
//					{'|',' ','|'},
//					{'|','_','|'}},
//					
//					{{' ',' ',' '},
//					{' ',' ','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{' ','_','|'},
//					{'|','_',' '}},
//					
//					{{' ','_',' '},
//					{' ','_','|'},
//					{' ','_','|'}},
//					
//					{{' ',' ',' '},
//					{'|','_','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{'|','_',' '},
//					{' ','_','|'}},
//					
//					{{' ','_',' '},
//					{'|','_',' '},
//					{'|','_','|'}},
//					
//					{{' ','_',' '},
//					{' ',' ','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{'|','_','|'},
//					{'|','_','|'}},
//					
//					{{' ','_',' '},
//					{'|','_','|'},
//					{' ','_','|'}}};
//void putNum(int *num1){
//	for(int i=0;i<3;i++){
//		for(int j=0;j<6;j++){
//			cout<<num[j][i][0]<<num[j][i][1]<<num[j][i][2];
//		}
//		cout<<'\n';
//	}
//}
//int cmp(int *a,int *b){
//	for(int i=0;i<3;i++){
//		for(int j=0;j<3;j++){
//			if(*(a+j*3+i)!=*(b+j*3+i)) return 0;
//		}
//	}
//	return 1;
//}
//void inPut(){
//	char time1[6][3][3];
//	for(int k=0;k<2;k++){
//		for(int i=0;i<3;i++){
//		for(int cur=0;cur<6;cur++){
//			for(int j=0;j<3;j++){
//				scanf("%c",&time1[cur][i][j]);
//			}
//		}
//	}
//	for(int i=0;i<6;i++){
//		for(int j=0;j<10;j++){
//			if(cmp((int *)time1[i],(int *)num[j])) time[k][i]=j;
//		}
//	}
//	}
//}	
//
//int main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);
//	inPut();
//	putNum(time[0]);
//	
//	return 0;
//}


