#include <stdio.h>
#include <stdlib.h>
struct f{
	long long a;
	char s[100];
};
int com(const void *q,const void *p){
	return ((struct f *)p)->a - ((struct f *)q)->a;
}
int main(){
	long long n,k;
	struct f h[100];
	scanf("%lld",&n);
	for(int i=0;i<n;i++){
	scanf("%lld %s",&h[i].a,h[i].s);
	}
	scanf("%lld",&k);		
	qsort(h,n,sizeof(struct f),com);	
		
		printf("%s\n",h[k].s);
		return 0;
}
