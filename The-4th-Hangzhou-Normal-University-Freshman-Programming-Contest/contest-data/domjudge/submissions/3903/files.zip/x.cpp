#include<stdio.h>
#include<stdlib.h>
struct number{
	int num;
	char name[15];
};
int comp(const void *p,const void *q){
	return((struct number *)q)->num-((struct number *)p)->num;
}
int main(){
	struct number a[100];
	int n,i,k,w;
	scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++){
	scanf("%d %s\n",&a[i].num,a[i].name);	
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(struct number),comp);
	if(k==0){
		printf("%s",a[0].name);
	}
	else{
		printf("%s",a[k].name);
	}
	return 0;
}
