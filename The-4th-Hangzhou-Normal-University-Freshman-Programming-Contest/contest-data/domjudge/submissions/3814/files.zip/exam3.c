#include<stdio.h>
struct a{
	char str[50];
	long long int x;	
};
int main(void)
{
	struct a song[100];
	long long int n,i,k=0,p,y;
	long long int rank[100];
	scanf("%lld",&n);
	for(i=0;i<n;i++){
		scanf("%lld %s",&song[i].x,song[i].str);
		rank[i] = i;
	}
	scanf("%lld",&k);
	for (p=1;p<n;p++) {
			for (i=0;i<n-p;i++) {
				if (song[rank[i]].x > song[rank[i + 1]].x) {
					y = rank[i];
					rank[i] = rank[i + 1];
					rank[i + 1] = y;
				}
			}
		}
	printf("%s",song[rank[n-1-k]].str);
	return 0;
}
