//#include<stdio.h>
//	int main()
//	{
//		int n,i;
//		scanf("%d",&n);
//		for(i=0;i<n;i++)	printf("Welcome to HZNU\n");
//		return 0;
//	}
//#include<stdio.h>
//char a[100001];
//	int main()
//	{
//		int t,n,i;
//		scanf("%d",&t);
//		while(t--)
//		{
//			scanf("%d",&n);
//			for(i=0;i<n;i++)
//			{
//				scanf("%d",&a[i]);
//			}
//		}
//		return 0;
//	}
//#include<stdio.h>
//#include<string.h>
//#include<stdlib.h>
//int comp(const void *p,const void *q);
//struct sibao
//{
//	long long int w[10];
//	char s[20];	
//}a[100001];
//	int main()
//	{
//		int n,i,j,k,m;
//		scanf("%d",&n);
//		for(i=0;i<n;i++)
//		{
//			scanf("%lld %s",a[i].w,a[i].s);
//		}
//		scanf("%d",&m);	
//		qsort(&a[0].w,n,sizeof(struct sibao),comp);
//		printf("%s\n",a[m].s); 
//		return 0;
//	}
//int comp(const void *p,const void *q)
//{
//	return (*(int *)q-*(int *)p);
//}
//#include<stdio.h>
//	int main()
//	{
//		int t,n,i,temp,ans=0,haha=0;
//		char zimu;
//		int a[123]={0};
//		scanf("%d",&t);
//		while(t--)
//		{
//			scanf("%d",&n);
//			getchar();
//			for(i=0;i<n;i++)
//			{
//				scanf("%c",&zimu);
//				temp=zimu;
//				if(temp<65||temp>90&&temp<97||temp>122)
//				{
//					i--;
//					continue;
//				}
//				a[temp]++;
//			}
//			for(i=0;i<123;i++)
//			{
//				if(a[i]>=2)	
//				{
//					ans+=a[i]/2*2;
//					if(a[i]%2!=0)	haha=1;
//				}
//				else if(a[i]==1)	haha=1;
//			}
//			if(haha==1)	ans++;
//			printf("%d\n",ans);
//			for(i=0;i<123;i++)
//			{
//				a[i]=0;	
//			}
//			ans=0;
//			haha=0;
//		}
//		return 0;
//	}
//#include<stdio.h>
//	int main()
//	{
//		int t,n,x;
//		scanf("%d",&t);
//		while(t--)
//		{
//			scanf("%d %d",&n,&x);
//			if(x!=0)	printf("yes\n");
//			else	printf("no\n");
//		}
//		
//		return 0;
//	}
#include<stdio.h>
#include<math.h>
#include<stdlib.h>
long long a[11][1000001];
	int main()
	{
		int n,m,i,j,min=0,ans,q,p;
		long long temp;
		
		scanf("%d %d",&n,&m);
		for(i=0;i<n;i++)
		{
			for(j=0;j<m;j++)
			{
				scanf("%lld",&a[i][j]);
				if(a[i][j]>min)	min=a[i][j];
			}	
		}
		p=0;
		while(p<n)
		{
			q=0;
			while(q<m)
			{
				temp=a[p][q];
				for(i=0;i<n;i++)
				{
					for(j=0;j<m;j++)
					{
						if(i!=p||j!=q)	
						{
							ans=abs(temp-a[i][j]);
							if(min>ans)	min=ans;
						}
					}
				}
				q++;
			}
			p++;
		}
		
		printf("%d\n",min);
		return 0;
	}
