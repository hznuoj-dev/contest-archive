#include<string.h>
#include <stdio.h>
#include<math.h>


int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int a, b;
		scanf("%d %d", &a, &b);
		if (b != 0)
			printf("yes\n");
		else
			printf("no\n");
	}
}










