#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int main(){
	int i,n,m,f=0,x,y,fchu=0,h=0,z;
	scanf("%d %d",&n,&m);
	z=n;
	while(n--)
	{
		scanf("%d",&x);
		if(x==0)
		{
			scanf("%d",&y);
			if(m==0&&y>=2500)
			f=1;
			else if(m==1&&y>2500)
			f=1;
		}
		else if(x==1)
		{
			fchu=1;
		}
		else
		{
			h=2;	
		}
	}
	if(h==2&&z>1||f==1&&fchu==1)
	printf("haoye");
	else
	printf("QAQ");
	return 0;
}
