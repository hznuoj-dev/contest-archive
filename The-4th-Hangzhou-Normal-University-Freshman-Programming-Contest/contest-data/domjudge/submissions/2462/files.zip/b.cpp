#include<stdio.h>
int main(){
	int t,n,m,i;
	scanf("%d",&t);
	while(t--){
		int flag=0;
		scanf("%d %d",&m,&n);
		if(n!=0){
			for(i=1;i<=1000000;i++){
				if((m*i)%n==0){
					flag=1;
					break;
				}
			}
		}
		if(flag==1){
			printf("yes\n");
		}
		else if(flag==0||n==0){
			printf("no\n");
		}
	}
	return 0;
} 
