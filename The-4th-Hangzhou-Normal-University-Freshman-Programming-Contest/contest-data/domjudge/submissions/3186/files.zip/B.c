#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>

int main()
{
	int n,i,j,k,t,a[100005];
	scanf("%d",&t);
	while(t--)
	{
		k=0;
		int sum=0;
		scanf("%d",&n);
		for(i=1;i<=n;i++)
			scanf("%d",&a[i]);
		for(i=1;i<=n;i++)
		{
			sum=a[i];
			for(j=i+1;j<=n;j++)
			{
				sum+=a[j];
				if(sum==7777)
				{
					k++;
					break;
				}
			}
		}
		printf("%d\n",k);
	}
}
