#include<stdio.h>
#include<stdlib.h> 
struct music{
 char a[16];
 int w;
}b[100];
int cmp(const void *p,const void *q)
{
 return ((struct music *)q)->w-((struct music *)p)->w;
}
int main(void)
{
 int n,k;
 int i;
 scanf("%d",&n);
 for(i=0;i<n;i++)
 {
  scanf("%d%s",&b[i].w,b[i].a);
 }
 scanf("%d",&k);
qsort(b,n,sizeof(struct music),cmp);

 for(i=0;i<n;i++)
 {
     if(i==k)
  printf("%s\n",b[i].a);
 }
 return 0;
}
