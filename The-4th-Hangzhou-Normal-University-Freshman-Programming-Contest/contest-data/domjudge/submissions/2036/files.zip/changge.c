#include<stdio.h>
struct song
{
	long long int love;
	char ge[20];
}a[100000];
int main()
{
	struct song temp;
	int n,i,k,j,K;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&a[i].love,a[i].ge);
	}
	scanf("%d",&K);
	for(i=0;i<n-1;i++)
	{
			k=i;
			for(j=i+1;j<n;j++)
			{
				if(a[j].love>a[k].love)
					k=j;
			}
			temp=a[k];
			a[k]=a[i];
			a[i]=temp;
	}
	printf("%s\n",a[K].ge);
	return 0;
}