#include<stdio.h>
int main(){
	int t,n,i,j,c=0,s=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
	int a[n];
	for(i=0;i<n;i++)scanf("%d",&a[i]);
	for(i=0;i<n;i++){
		for(j=i;j<n;j++){
			s=s+a[j];if(s==7777){c++;s=0;
			}
		}
	}
	printf("%d",c);c=0;
	}
	return 0;
}
