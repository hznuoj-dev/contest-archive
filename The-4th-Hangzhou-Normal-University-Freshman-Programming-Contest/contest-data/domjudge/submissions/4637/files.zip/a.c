#include<stdio.h>
#include<string.h>
char a[100005];
void fun(char str[]);
int huiwen(char s[]);
int main(){
	char *p;
	int t,i,n,j=0;
    scanf("%d",&t);
	while(t--){
	scanf("%d",&n);
	getchar();
    gets(a);
    fun(a);
    printf("%d\n",huiwen(a));
}
	return 0;
}
void fun(char str[]){
	char *p=str;
	int i=0;
	while(*p){
		if(*p!=' ')
		str[i++]=*p;
		p++;
	}
	str[i]='\0';
}
int huiwen(char s[]){
	int m=strlen(s);
	int b[52]={0};
	int i;
		for(i=0;i<m;i++){
		if(s[i]>='a'&&s[i]<='z')
		b[s[i]-'a']++;
		else
		b[s[i]-'A'+26]++;
	
	}
	for(i=0;i<52;i++)
		if(1==b[i]%2)
		m--;
		if(m==strlen(s))
		return m;
		else 
		return m+1;
}
