#include<stdio.h>
int main(void){
	long long t,n,x,set,b,i,per=0;
	scanf("%lld",&t);
	for(i=1;i<=t;i++){
		per=0;
		scanf("%lld%lld",&n,&x);
		
		if(x==0)
		printf("no\n");
		
		else 
		printf("yes\n");
		
		
	}
	
	
	return 0;
}
