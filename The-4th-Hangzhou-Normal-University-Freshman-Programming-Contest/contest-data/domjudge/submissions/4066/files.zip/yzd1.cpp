#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
int main () {
	int f1=0,f2=0;
	cnm;
	int n,m;
	cin >> n >> m;
	while (1){
		int x,y;
		cin >> x;
		if (x==0){
			cin >> y;
			if ((m==0&&y>=2500)||(m==1&&y>2100)){
				f1=1;
				n--;
			}
		}
		else if (x==1) {
			if (f1) {
			f2=1;
			n--;
			}
		}
		else if (x==2){
			if (f1==0&&n>=1){
				f2=1;
				n--;
			}
		}
		if (f2) {
		cout << "haoye";
		break;
	}
}
if (f2==0) cout << "QAQ";
	return 0;
}
