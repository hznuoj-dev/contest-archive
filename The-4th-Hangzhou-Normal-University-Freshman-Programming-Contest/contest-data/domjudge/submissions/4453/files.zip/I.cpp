#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
typedef struct{
	int b;
	char a[16];
}ptr;
int cmp(const void*p,const void*q){
	ptr *a,*b;
	a=*(ptr*)p;
	b=*(ptr*)q;
	return a->b-b->b;
}
int main (){
	int n,i,k;
	ptr diange[100001];
	scanf("%d",&n);
	for(i=0;i<n;++i){
		scanf("%d %s",&diange[i].b,diange[i].a);
	}
	qsort(diange,n,sizeof(ptr),cmp);
	scanf("%d",&k);
	printf("%s",diange[k].a);
} 
