#include<stdio.h>
#include<string.h>
struct g{
	long long int a;
	char c[20];
};
struct g g1[100001];
int main(){
	int t,m,n,i,j,x;
	char f[20];
	long long int e;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%lld %s",&g1[i].a,g1[i].c);
	} 
	scanf("%d",&x);
	for(i=0;i<t-1;i++){
		for(j=0;j<t-i-1;j++){
			if(g1[j].a<g1[j+1].a){
				e=g1[j].a;
				g1[j].a=g1[j+1].a;
				g1[j+1].a=e;
				strcpy(f,g1[j].c);
				strcpy(g1[j].c,g1[j+1].c);
				strcpy(g1[j+1].c,f);
			}
		}
	}
	puts(g1[x].c); 
}
