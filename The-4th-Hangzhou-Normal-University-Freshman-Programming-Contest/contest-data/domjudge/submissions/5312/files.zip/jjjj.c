#include<stdio.h>
int main(void){
	int n,m;
	int a;
	int flag=0;
	scanf("%d %d",&n,&m);
	int x[n];
	int t=n;
	int i=n;
	while(n--){
		scanf("%d",&x[t-n]);
		if(x[t-n]==0){
		scanf("%d",&a);
	}
	if(t>=2&&x[t-n]==2){
	flag=1;
		break;
	}
	if(m==0&&a>=2500){
		while(i--){
		if(x[t-i]==1){
		flag=1;
		break;}
}
	}
	 if(m==1&&a>=2100){
	 		while(i--){	
		if(x[t-i]==1){
		flag=1;
		break;}
}
	 }
}
if(flag==1){
printf("haoye\n");
}
else{
	printf("QAQ\n");
}
return 0;
}
