#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int cmp(const void *a,const void *b){
	int p1=*(int*)a;
	int p2=*(int*)b;
return p2-p1;
}
typedef struct{
int a;
char song[20];
}data;
data d[100010];
main(){
int n,k,i,j,a[100000];

scanf("%d",&n);
for(i=1;i<=n;i++){
scanf("%d %s",&d[i].a,d[i].song);
}
qsort(d+1,n,sizeof(data),cmp);
scanf("%d",&k);
printf("%s",d[k+1].song);
}
