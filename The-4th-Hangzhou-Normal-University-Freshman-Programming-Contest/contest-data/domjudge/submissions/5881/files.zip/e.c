#include<stdio.h>
int main()
{
	int t,n;
	int i,j;
	int s1[25][25],s2[25][25],s3[25][25],s4[25][25],c[25][25];
	int flag1,flag2,flag3,flag4;
	scanf("%d",&t);
	while(t--)
	{
		flag1=1;
		flag2=1;
		flag3=1;
		flag4=1;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				getchar();
				scanf("%d",&s1[i][j]);
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				getchar();
				scanf("%d",&c[i][j]);
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				s2[i][j]=s1[n-j-1][i];
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				s3[i][j]=s1[n-i-1][n-j-1];
			}
		}
		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				s4[i][j]=s1[j][n-i-1];
			}
		}

		for(i=0;i<n;i++)
		{
			for(j=0;j<n;j++)
			{
				if(s1[i][j]!=c[i][j])
				{
					flag1=0;
				}
				if(s2[i][j]!=c[i][j])
				{
					flag2=0;
				}
				if(s3[i][j]!=c[i][j])
				{
					flag3=0;
				}
				if(s4[i][j]!=c[i][j])
				{
					flag4=0;
				}
			}
		}
		if(flag1==1)
			printf("0\n");
		else if(flag2==1)
			printf("1\n");
		else if(flag3==1)
			printf("2\n");
		else if(flag4==1)
			printf("1\n");
		else
			printf("-1\n");
	}
}