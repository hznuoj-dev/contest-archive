#include <stdio.h>
#include <string.h>
struct g
{
	char na[20];
	long long int pp;
}gg[100004];
int main()
{
	int a,b,c,d,e;
	long long int f;
	char l[20];
	scanf("%d",&a);
	
	for(b=1;b<=a;b++)
	{
		scanf("%ld %s",&gg[b].pp,gg[b].na);
	}
	scanf("%d",&e);
	for(c=1;c<a;c++)
	{
		for(d=a;d>c;d--)
		{
			if(gg[d].pp<gg[d-1].pp)
			{
				f=gg[d].pp;
				gg[d].pp=gg[d].pp;
				gg[d-1].pp=f;
				strcpy(l,gg[d].na);
				strcpy(gg[d].na,gg[d-1].na);
				strcpy(gg[d-1].na,l);
			}
		}
		
	}
	printf("%s\n",gg[a-e].na);
	return 0;
}