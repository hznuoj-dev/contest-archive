#include <stdio.h>
int main(void){
	int n,m,k,t=0,i,flag=0,max=0;
	int a[10000];
	int b[10000];
	int atk=2500,def=2100;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&k);
		a[k]++;
		if(k==0){
			scanf("%d",&b[t]);
			t++;
		}
	}
	for(i=0;i<t;i++){
		if(max<b[i])max=b[i];
	}
	if(m==0){
		if(max>atk)flag=1;
	}
	if(m==1){
		if(max>def)flag=1;
	}
	if(flag==1&&a[1]>0)flag=2;
	if(a[0]+a[1]>0&&a[2]>0)flag=2;
	if(flag=2){
		printf("haoye\n");
	}else{
		printf("QAQ\n");
	}
	return 0;
}
