#include<stdio.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,t,i,j,y,s,p;
	char x;
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		int a[100]={0};
		s=0;
		p=0;
		scanf("%d",&n);
		for(j=1;j<=n;j++){
			getchar();
			x=getchar();
			if(x>='a'&&x<='z'){
				y=x-'a'+1;
			}
			else if(x>='A'&&x<='Z'){
				y=x-'A'+27;
			}
			a[y]=a[y]+1;	
		}
		for(j=1;j<=60;j++){
			if(a[j]>0){
				if(a[j]==1&&p==0){
					s+=1;
					p++;
				}
				else if(a[j]%2==0){
					s+=a[j];
				}
				else if(a[j]%2!=0&&a[j]>1){
					if(p==0){
						s+=a[j];
						p++;
					}
					else{
						s+=a[j]-1;
					}
				}
			}
		}
		printf("%d\n",s);
	}
}
