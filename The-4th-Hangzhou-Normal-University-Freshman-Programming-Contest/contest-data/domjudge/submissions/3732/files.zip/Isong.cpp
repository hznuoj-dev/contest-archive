#include <stdio.h>
#include <stdlib.h>
struct num{
	long long int no;
	char name[21]; 
};
int cmp(const void *p,const void *q)
{
	struct num *pp = (struct num *)(p);
	struct num *pq = (struct num *)(q);
	int a = pp -> no;
	int b = pq -> no;
	return b - a;
} 
int main()
{
	struct num a[100001];
	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%lld%s",&a[i].no,a[i].name);
	}
	qsort(a,n,sizeof(struct num),cmp);
	scanf("%d",&k);
	printf("%s\n",a[k].name);
	return 0;
} 
