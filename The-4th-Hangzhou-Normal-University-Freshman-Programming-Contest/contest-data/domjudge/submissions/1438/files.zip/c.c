#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
main(){
int n,i,j,a,b,c,sum;
int ch[1000]={0};
char ca;
scanf("%d",&n);
while(n--){
	sum=0;
scanf("%d",&a);
for(i=1;i<=a;i++){
	getchar();
	scanf("%c",&ca);
	ch[ca]++;
}
for(i=1;i<=999;i++){
	if(ch[i]%2==0){
		sum=sum+ch[i];
		ch[i]=0;
	}
	else if(ch[i]%2!=0){
	sum=sum+ch[i]-1;
	ch[i]=1;
	}
}
for(i=1;i<=999;i++){
	if(ch[i]==1){
	sum++;
	break;
	}
}
printf("%d\n",sum);
}
getch();
}