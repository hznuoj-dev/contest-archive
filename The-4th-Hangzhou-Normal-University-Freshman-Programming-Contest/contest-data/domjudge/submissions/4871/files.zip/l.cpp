#include<stdio.h>
int main(){
	int t,n,x;
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		scanf("%d %d",&n,&x);
		if(x==0)printf("no\n");
		else printf("yes\n");
	}
} 
