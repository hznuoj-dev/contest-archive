#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#define ARRAY_SIZE 100001

struct student {
	int score;
	char name[16];
};

int comp(const void *p, const void *q) {
	return ((struct student *)q)->score - ((struct student *)p)->score;
}

int main() {
	struct student  studentArray[ARRAY_SIZE];
	int i, n, k;
	scanf("%d", &n);
	for (i = 0; i <= n - 1; i++) {
		scanf("%d%s", &studentArray[i].score, studentArray[i].name);
	}
	qsort(studentArray, n, sizeof(struct student), comp);
	scanf("%d", &k);
	printf("%s", studentArray[k].name);
	return 0;
}