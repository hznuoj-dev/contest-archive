#include <stdio.h>
#include <stdlib.h> 
typedef struct{
	char a[16];
	int b;
}diange;
int cmp(const void*a,const void*b){
	diange*p,*q;
	p=(*diange)*a;
	q=(*diange)*b;
	if(q->b>p->b)
	return 1;
	else if(q->b==p->b)
	return 0;
	else
	return -1;
}
int main (){
	diange diange1[100000];
	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;++i){
		scanf("%d %s",&diange1[i].b,diange1[i].a);
	}
	scanf("%d",&k);
	qsort(b,n,sizeof(diange),cmp);
	printf("%s",diange1[k+1].a]);
} 
