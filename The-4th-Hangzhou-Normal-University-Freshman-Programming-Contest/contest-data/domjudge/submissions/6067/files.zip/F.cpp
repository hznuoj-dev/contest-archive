#include <bits/stdc++.h>
using namespace std;
char ch[50000];
string str[1010];
int main(){
	int i,n,j,k,r,l;
	char fh;
	cin>>n;
	for (i=0;i<n;++i){
		j=0;
		k=0;
		gets(ch);
		while (ch[j]!='\0'){
			if (ch[j] == ' ') k++;
			else if (ch[j]== '.') fh='.';			
			else if (ch[j]=='?') fh='?';				
			else if (ch[j]=='!') fh='!';	
			else str[k]=str[k]+ch[j];
			j++;
		}
		k+=1;
		r=k;
		l=1;
		for (j=1;j<=k;j++){
			if (j%2==0) {
				cout<<' '<<str[r];	
				r=r-1;
			}
			else {
				cout<<' '<<str[l];
				l+=1;	
			}
		}
		cout<<fh<<'\n';
	}
	return 0;
}
