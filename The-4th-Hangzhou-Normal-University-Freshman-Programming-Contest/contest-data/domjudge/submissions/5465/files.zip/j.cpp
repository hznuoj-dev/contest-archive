#include<bits/stdc++.h>
using namespace std;

int main(){
	int n,m,atk,sum=0;
	bool xiaomie=0,muxue=0;
	cin>>n>>m;
	int n0=n;
	while(n0--){
		int card;
		cin>>card;
		if(card==0){
			cin>>atk;
			if(atk>2100||atk==2100&&m==0){
				xiaomie=1;
			}
		}else if(card==1){
			muxue=1;
		}else if(card==2&&n>=2){
			cout<<"haoye";
			return 0;
		}
		if(xiaomie==1&&muxue==1){
			cout<<"haoye";
			return 0;
		}
	}
	cout<<"QAQ";
}
