#include<stdio.h> 
#include<stdlib.h>
#include<math.h>
struct ge{
	long long int x;
	char name[20];
};
int cmp(const void *p,const void *q)
{
	struct ge *pp = (struct ge *)(p);
	struct ge *pq = (struct ge *)(q);
	int a = pp->x;
	int b = pq->x;
	return b - a;
} 
int main()
{	
 int i,n,k;
 scanf("%d",&n);
 struct ge a[n];
 for(i=0;i<n;++i)
 {
 	scanf("%lld%s",&a[i].x ,a[i].name );
 }
 qsort(a,n,sizeof(struct ge),cmp);
 scanf("%d",&k);
 printf("%s\n",a[k].name);
 return 0;
}
