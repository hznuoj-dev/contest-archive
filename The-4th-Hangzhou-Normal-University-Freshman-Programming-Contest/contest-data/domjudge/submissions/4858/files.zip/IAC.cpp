#include<stdio.h>
#include<string.h>
struct son
{
	int xi;
	char name[16];

};
int main()
{
	struct son ge[100001];
	struct son t;
	int n, k;
	int m;
	int i, j;
	while(scanf("%d", &n)!=EOF){
	
	for (i = 0; i < n; i++)
	{
		scanf("%d %s", &ge[i].xi,ge[i].name);
	}
	scanf("%d", &k);
	for (j = 0; j < n - 1; j++)
	{
		m = j;
		for (i = j+1; i < n; i++)
		{
			if (ge[m].xi < ge[i].xi)
			{
				m = i;
			}
			if (m != j)
			{
				t = ge[m];
				ge[m] = ge[j];
				ge[j] = t;
			}
		}
	}
	printf("%s\n", ge[k].name);
}
	return 0;
}

