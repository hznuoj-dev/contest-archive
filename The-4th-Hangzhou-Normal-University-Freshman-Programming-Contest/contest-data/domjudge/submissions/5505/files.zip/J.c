#include<stdio.h>
int main()
{
	int n, m,sp,k,flag=1;
	scanf("%d %d", &n, &m);
	while (n > 0)
	{
		scanf("%d", &sp);
		if (sp == 0)
		{
			scanf("%d", &k);
			if (m == 0 && k >= 2500)
				flag = 0;
			if (m == 1 && k >= 2100)
				flag = 0;
		}
		if (sp == 1&&flag==0)
		{
			flag = -1;
		}
		if (sp == 2 && flag == 1 && n > 1)
		{
			flag = -1;
			n--;
		}
		n--;
	}
	if (flag == -1)
	{
		printf("haoye");
	}
	else
		printf("QAQ");
	return 0;
}