#include<stdio.h>
#include<string.h>
long int a[20000];
char c[2000];
char b[2000][200];
int main()
{
	int n,i,j,k,e;
	scanf("%ld",&n);
	for(i=0;i<n;i++)
	{
		scanf("%ld %s",&a[i],b[i]);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(a[j]<a[j+1])
			{
				e=a[j+1];
				a[j+1]=a[j];
				a[j]=e;
				strcpy(c,b[j+1]);
				strcpy(b[j+1],b[j]);
				strcpy(b[j],c);
			}
		}
	}
	scanf("%d",&k);
	printf("%s\n",b[k]);
	return 0;
}