#include<bits/stdc++.h>
using namespace std;
void solve(){
	int n, ans=0;
	cin>>n;
	map<char,int>mp;
	for(int i=0;i<n;i++){
		char ch;cin>>ch;
		mp[ch]++;
		if(mp[ch]==2){
		ans+=2;
		mp[ch]-=2;
		}
	}
	if(n!=ans)ans++;
	cout<<ans<<'\n';
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
