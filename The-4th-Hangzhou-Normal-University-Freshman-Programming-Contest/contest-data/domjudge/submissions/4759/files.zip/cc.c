#include<stdio.h>
char ci[100000];
main()
{
	int T;
	long long  n, i, j, len;
	scanf("%d", &T);
	while (T--){
		len = 0;
		scanf("%lld", &n);
		getchar();
		for (i = 0;i < n;i++){
			scanf("%c", &ci[i]);
			getchar();
		}
		for (i = 0;i < n;i++){
			if (ci[i] == -1)
				continue;
			for (j = i+1;j < n;j++){
				if (ci[i] == ci[j] && ci[j] != -1){
					ci[i] = -1;
					ci[j] = -1;
					len += 2;
					break;
				}
			}
		}
		if (len != n)
			printf("%lld\n", len + 1);
		else
			printf("%lld\n", len);
	}
}

