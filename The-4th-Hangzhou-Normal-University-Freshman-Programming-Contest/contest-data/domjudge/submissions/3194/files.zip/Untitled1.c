#include <stdio.h>
#include <string.h>
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int a[1000000];
		int k=0, n, m, j=0, i;
		scanf("%d %d",&n,&m);
		while(1){
			k=(k+m)%n;
			if(k==0){
				printf("yes\n");
				break;
			}
			a[j++]=k;
			for(i=0;i<j;i++){
				if(a[i]==k){
					printf("no\n");
					i=j+1;
				}
				if(i>j)
					break; 
			}
		}
	}
}

