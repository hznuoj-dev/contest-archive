#include<stdio.h>
#include<stdlib.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int *num;
		int n;
		int cnt=0;
		scanf("%d",&n);
		num=(int *)malloc(n*sizeof(int));
		for(int i=0;i<n;i++){
			scanf("%d",&num[i]);
		}
		int sum=0,flag=0;
		for(int i=0;i<n;i++){
			flag=0;
			if(num[i]<=7777){
			sum=num[i];
			}
			else
			continue;
			for(int j=i+1;j<=n;j++){
				if(sum==7777)
				{
					flag=1;
					break;
				}
				else if(sum>7777)
				break;
				else
				sum+=num[j];
			}
			if(flag)
			cnt++;
		}
		printf("%d\n",cnt);
		free(num);
	}
	return 0;
}
