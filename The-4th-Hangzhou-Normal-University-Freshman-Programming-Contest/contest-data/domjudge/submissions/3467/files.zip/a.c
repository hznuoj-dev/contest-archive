#include<stdio.h>
int main(){
	int t,n;
	char s[1001];
	int x,l,a[52]={0};
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(x=0;x<52;x++){
			a[x]=0;
		}
		l=0;
		for(x=0;x<n;x++){
			scanf(" %c",&s[x]);
			if('a'<=s[x]&&s[x]<='z'){
				a[s[x]-71]++;
			}
			else{
				a[s[x]-65]++;
			}
		}
		for(x=0;x<52;x++){
			l+=(a[x]/2)*2;
		}
		printf("%d\n",l+1);
	}
	return 0;
}
