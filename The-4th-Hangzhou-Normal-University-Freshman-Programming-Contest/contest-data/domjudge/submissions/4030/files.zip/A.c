#include <stdio.h>
#include <string.h>
int a[100000];
int main(void) {
    int T;
    int n,i,j;
    int sum=0,max=0;
    scanf("%d",&T);
    while (T--) {
        scanf("%d",&n);
        char str[n][2];
        for (i=0; i<n; i++) {
            a[i]=0;
			scanf("%s",str[i]);
        }
        for (i=0; i<n; i++) {
            for (j=i; j<n; j++) {
                if (str[i][0]==str[j][0]&&str[j][0]!='0') {
                    a[i]=a[i]+1;
                    if (i!=j) {
                        str[j][0]='0';
                    }
                    
                }
            }
        }
        for (i=0; i<n; i++) {
            if (a[i]%2==0) {
                sum=sum+a[i];
                a[i]=0;
            }
        }
        max=a[0];
        for (i=0; i<n; i++) {
            if (max<a[i]) {
                max=a[i];
            }
        }
        sum=sum+max;
        printf("%d\n",sum);
        sum=0;
    }
    return 0;
}
