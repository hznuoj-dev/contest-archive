#include<stdio.h> 
int main()
{	
 int t,n,k,i,p,j;
 char c[1000000];
 scanf("%d",&t);
 while(t--)
 {
 	p=0;
 	scanf("%d",&n);
 	getchar();
 	for(i=0;i<n;++i)
 	{
 		scanf("%c",&c[i]);
 		getchar();
	}
	for(i=0;i<n;++i)
		{
			for(j=i+1;j<n;++j)
			{
				if(c[i]==c[j]&&c[i]!='0'&&c[j]!='0')
				{
					c[i]=c[j]='0';
					p=p+1;
					break;
				}
			}
		}
	printf("%d\n",2*p+1); 
    }
}
