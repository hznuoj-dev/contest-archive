#include <stdio.h>
#include <string.h>
struct STU
{
	int w;
	char m[1000];
};
int main ()
{
 int n,i,j,t,k;
 struct STU stu[100000];
 scanf("%d",&n);
 for(i=1;i<=n;i++)
 {
  	scanf("%d %s",&stu[i].w,stu[i].m);
 }
    for(i=1;i<n;i++)
    {
    	for(j=1;j<n-i;j++)
    	{
    		if(stu[i].w>stu[i+1].w)
    		{
    			t=stu[i].w;
    			stu[i].w=stu[i+1].w;
    			stu[i+1].w=t;
			}
		}
	}
	scanf("%d",&k);
	for(i=1;i<=n-k;i++)
	printf("%s\n",stu[i].m);
    return 0;
}
