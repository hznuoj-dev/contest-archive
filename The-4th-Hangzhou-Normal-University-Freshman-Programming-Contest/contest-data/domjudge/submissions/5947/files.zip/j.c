#include<stdio.h>
struct sa{
	int x;
	int k;
};
int main(void)
{
	int f=0,e=0;
	int a1=0,a2=0;
	int n,m;
	struct sa a[11];
	scanf("%d%d",&n,&m);
	int i;
	for(i=0;i<n;++i)
	{
		scanf("%d",&a[i].x);
		if(a[i].x==1) a1=1;
		if(a[i].x==2) a2=1;
		if(a[i].x==0)
		{
			scanf("%d",&a[i].k);
		}
	}
	if(a2==1&&n>=2) printf("haoye");
	else
	{
	if(m==0)
	{
		for(i=0;i<n;++i)
		{
			if(a[i].x==0)
			{
				if(a[i].k>=2500)
				{
					if(a1==1)
					{
						f=1;
					}
				}
			}
		}
	}
	else if(m==1)
	{
		for(i=0;i<n;++i)
		{
			if(a[i].x==0)
			{
				if(a[i].k>2100)
				{
					if(a1==1)
					{
						f=1;
					}
				}
			}
		}
	}
	if(f==1) printf("haoye\n");
	else if(f==0) printf("QAQ\n");
	}
	return 0;
}
