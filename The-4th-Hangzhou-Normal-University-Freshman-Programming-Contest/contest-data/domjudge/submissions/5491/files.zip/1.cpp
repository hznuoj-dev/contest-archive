#include <stdio.h>
#include <string.h>
int a[100000];
char name[100000][16];
int main(){
	int n,k,t,max;
	char d[16];
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d %s",&a[i],name[i]);
	}
	scanf("%d",&k);
	for(int i=0;i<k+1;i++){
		max=i;
		for(int j=i+1;j<n;j++){
			if(a[j]>a[max])
				max=j;
		}
		if(max!=i){
			t=a[i];
			a[i]=a[max];
			a[max]=t;
			strcpy(d,name[i]);
			strcpy(name[i],name[max]);
			strcpy(name[max],d);
		}
	}
	printf("%s",name[k]);
	return 0;
}
