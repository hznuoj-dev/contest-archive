#include <stdio.h>

int main(void) {
	int t,i,j,flag;
	scanf("%d",&t);
	while(t--){
		int n,sum=0;
		scanf("%d",&n);
		char a[n];
		for(i=0;i<n;i++){
			scanf("%c",&a[i]);
			getchar();
		}
		for(i=0;i<n;i++)
			for(j=i+1;j<n;j++){
				flag=1;
				if(a[i]==a[j]||a[i]==a[j]+32)
					flag=0;
				if(flag)
					sum++;
			}
		printf("%d\n",sum*2-1);
	}

	return 0;
}

