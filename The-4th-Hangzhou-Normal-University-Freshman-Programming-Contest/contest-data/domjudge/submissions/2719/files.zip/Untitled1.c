#include<stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		int arr[10000];
		scanf("%d",&n);
		int i=0;
		while(i<n){
			scanf("%d",&arr[i]);
			i++;
		}
		i=0;
		int cnt=0;
		while(i<n){
			int j=i;
			int zong=0;
			while(j<n){
				zong=zong+arr[j];
				if(zong==7777){
					cnt=cnt+1;
					break;
				}
				if(zong>7777){
					break;
				}
				j++;
			}
			i++;
		}
		printf("%d\n",cnt);
	}
	return 0;
} 
