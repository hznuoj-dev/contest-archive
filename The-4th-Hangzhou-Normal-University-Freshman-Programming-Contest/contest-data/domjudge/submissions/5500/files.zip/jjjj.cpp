#include <cstdio>
#include <algorithm>
#include <set>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <climits>
#include <stack>
#include <map>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include<time.h>
#define tententen tql666
#define PI acos(-1) 
typedef long long int ll; 	 
using namespace std;
	int main(){
		int a[3];
		memset(a,0,sizeof(a));
		int n,m, t,s,k,i,j,x,y,atk,def;
	    cin >> n>> k;
	    int kz=1;
	    if(k==0){
		    for(i=1;i<=n;++i){
		    	cin>>m;
			    if(m==0){
			    	cin>>atk;
		            if(atk>=2500){
		            	a[m]=1;
					}
		        }else{
		     		a[m]=1;
			    }
	        }
	    }else{
	    	for(i=1;i<=n;++i){
		    	cin>>m;
			   if(m=0){
			    	cin>>atk;
		            if(atk>=2100){
		            	a[m]=1;
					}
		        }else{
		            a[m]=1;	    	 	
			    }
	        }
		}
		if(a[2]==1&&n>=2)
			kz=0;
		if(a[0]&&a[1])
			kz=0;
	    if(kz==0){
	    	cout<<"haoye"<<endl;
		}else{
			cout<<"QAQ"<<endl;
		}
    return 0;
}