#include<stdio.h>
#include<stdlib.h>
struct pome {
	int a;
	char str[20];
};
int main() {
	int n, k;
	struct pome c[100000];
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%lld%s", &c[i].a, c[i].str);
	}
	for (int i = 0; i < n - 1; i++) {
		for (int j = 0; j < n - 1 - i; j++) {
			struct pome m;
			if (c[j].a < c[j + 1].a) {
				m = c[j];
				c[j] = c[j + 1];
				c[j + 1] = m;
			}
	    }
	}
	scanf("%d", &k);
	printf("%s", c[k].str);
	return 0;
}
