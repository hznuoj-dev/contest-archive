#include <bits/stdc++.h>
using namespace std;

int a[21][21];
int b[21][21];
int c[21][21];

int main()
{
	int t,n;
	int m;
	int i,j;
	int ans,flag;
	
	cin >> t;
	while(t--)
	{
		cin >> n;
		ans=-1;
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				cin >> a[i][j];
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				cin >> b[i][j];
				
		ans=0;flag=1;
		for(i=1;i<=n;i++)
			for(j=1;j<=n;j++)
				if(a[i][j]!=b[i][j])
					flag=0;
		if(flag)
		{
			cout << ans << '\n';
			continue;
		}
		for(m=1;m<=3;m++)
		{
			for(i=1;i<=n;i++)
				for(j=1;j<=n;j++)
					 c[i][j]=a[n-j+1][i];
			ans++;flag=1;
			for(i=1;i<=n;i++)
				for(j=1;j<=n;j++)
					if(c[i][j]!=b[i][j])
					{
						flag=0;
						break;
					}
						
			if(flag)	break;
			for(i=1;i<=n;i++)
				for(j=1;j<=n;j++)
					a[i][j]=c[i][j];
		}
		if(ans==3)	ans=1;
		
		if(flag)	cout << ans << '\n';
		else	cout << -1 << '\n';
	}
	
	return 0;
}
