#include<stdio.h>
#include<stdlib.h>

int main(void)
{
	int num[52];
	int T, b, group, sum;
	char ch;

	scanf("%d", &T);
	while (T--) {
		for (int i = 0; i < 52; i++)
			num[i] = 0;
		b = 0, sum = 0;
		scanf("%d", &group);
		
		while (group--) {
			scanf(" %c", &ch);
			if (ch >= 'a' && ch <= 'z')
				num[ch - 'a']++;
			if (ch >= 'A' && ch <= 'Z')
				num[ch - 'A' + 26]++;
		}
			
		
		for (int i = 0; i < 52; i++) {
			//printf("%d ", num[i]);
			sum += (num[i] / 2) * 2;
			if (num[i] % 2)b = 1;
		}
		if (b)sum++;
		printf("%d", sum);
		if (T)putchar('\n');
	}

	return 0;
}