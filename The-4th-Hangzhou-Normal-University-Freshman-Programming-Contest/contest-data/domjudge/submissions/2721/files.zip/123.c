
#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);//n�����ƣ�m��Ӣ�۱�����ʽ 
    int i;
    int a[20];
    int k;
    int attach=0;
    
    for(i=0;i<n;i++)
    {
		scanf("%d",&a[i]);
		if(a[i]==0)
		{
			scanf("%d",&k);
			attach=k+attach;
			//k��ʾ������ 
		}
		
	}
	if(m==0)
	{
		if(attach>=2500)
		printf("haoye\n");
		else 
		printf("QAQ\n");
	} 
	else if(m==1)
	{
		if(attach>2100)
		printf("haoye\n");
			else 
				printf("QAQ\n");
	}
	return 0;
}
