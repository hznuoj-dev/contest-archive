#include <stdio.h>
 int main (){
 	int t,i;
	 int n,x;
	 scanf("%d",&t);
	 scanf("%d%d",&n,&x);
	 for(i=0;i<t;i++){
        if(x==0)
 		printf("no\n");
 		else 
 		printf("yes\n");
}
	 return 0;
 }
