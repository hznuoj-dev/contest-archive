#include<stdio.h>
#include<stdlib.h>
int comp(const void* p, const void* q);
struct music {
	int num1;
	char name[15];
};
struct music list[100000];

int main() {
	int a, b, c;
	scanf("%d", &a);
	for (b = 0; b < a; b++) {
		scanf("%d %s", &list[b].num1, list[b].name);
	}	
	int x;
	scanf("%d", &x);
	qsort(list, a, sizeof(struct music), comp);
	printf("%s", list[x].name);
	return 0;
}
int comp(const void* p, const void* q) {
	struct music* p1 = (struct high*)p;
	struct music* p2 = (struct high*)q;
	int d = p1->num1;
	int f = p2->num1;
	return f - d;
}
