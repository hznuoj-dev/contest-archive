#include <stdio.h>

int main() {
	int x;
	int a, b;
	scanf("%d", &x);
	while (x--) {
		scanf("%d %d", &a, &b);
		if (b == 0) {
			printf("no\n");
		} else {
			printf("yes\n");
		}
	}
}