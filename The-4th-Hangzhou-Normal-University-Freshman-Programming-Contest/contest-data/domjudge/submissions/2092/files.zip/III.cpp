#include<stdio.h>
#include<stdlib.h>
struct sing{
	int w;
	char s[20];
};
int cmp(const void *p,const void *q)
{
	struct sing *pp = (struct sing *)(p);
	struct sing *pq = (struct sing *)(q);
	int x = pp->w;
	int y = pq->w;
	return y - x;
}
int main(void)
{
	int n,i,k;
	struct sing a[1000];
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%d %s",&a[i].w,a[i].s);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(struct sing),cmp);
	printf("%s\n",a[k].s);
	return 0;
}
