#include <stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n,x;
		scanf("%d %d",&n,&x);
		if(x==0) printf("no\n");
		else printf("yes\n");
		
	}
	
	return 0;
}
