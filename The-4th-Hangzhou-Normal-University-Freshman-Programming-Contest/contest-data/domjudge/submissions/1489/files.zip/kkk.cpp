#include<iostream>
using namespace std;
int main() {
	int n;
	cin >> n;
	while (n--) {
		cout << "Welcome to HZNU" << endl;
	}
}