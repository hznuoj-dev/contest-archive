#include <stdio.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
	int n,x;
	scanf("%d %d",&n,&x);
	if(x==0){
	printf("NO\n");
	}	
	int q=0;
	int w=x;
	if(x>n){
		w=x;
	}else{
	w=n;	
	}
	while(w--){
	q++;
	if(q%n==0){
		printf("YES\n");
		break;
	}	
	}
	if(q==w){
		printf("No\n");
		
	}
	
	
	}
	return 0;
}
