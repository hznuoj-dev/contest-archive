#include <stdio.h>
#include <math.h>
int a[10][1000000];
int main(void){
	int n,m,i,j,k,min,d;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			if(j==0) min=a[i][j];
			for(k=j+1;k<m;k++){
				if(abs(a[i][k]-a[i][j])<min) min=abs(a[i][k]-a[i][j]);
			}
		}
		if(i==0) d=min;
		else{
			if(min<d) d=min;
		}
	}
	printf("%d",d);
	return 0;
}










