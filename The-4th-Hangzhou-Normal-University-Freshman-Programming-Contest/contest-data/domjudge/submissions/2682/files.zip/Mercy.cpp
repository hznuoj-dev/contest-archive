#include<bits/stdc++.h>
using namespace std;

int main(){
	int n,m,atk;
	bool xiaomie=0,muxue=0;
	int card[15];
	cin>>n>>m;
	for(int i=0;i<n;i++){
		cin>>card[i];
		if(card[i]==0){
			cin>>atk;
			if(atk>2100){
				xiaomie=1;
			}else if(atk>=0&&m==0){
				xiaomie=1;
			}
		}
		if(card[i]==1){
			muxue=1;
		}
		if(card[i]==2){
			if(n>=2){
				cout<<"haoye";
				return 0;
			}
		}
		if(xiaomie==1&&muxue==1){
			cout<<"haoye";
			return 0;
		}
	}
	cout<<"QAQ";
}
