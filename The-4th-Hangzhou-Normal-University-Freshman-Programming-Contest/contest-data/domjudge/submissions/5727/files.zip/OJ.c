#include <stdio.h>
#include <string.h>
int cmp(const void *a, const void *b);

struct high {
	long long a;
	char name[16];
};
struct high song[100000];

int main() {
	int n, k, i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%lld %s", &song[i].a, &song[i].name);
	}
	scanf("%d", &k);
	qsort(song, n, sizeof(struct high), cmp);
	printf ("%s", song[k].name);
}

int cmp(const void *a, const void *b) {
	struct high *p1 = (struct high *)a;
	struct high *p2 = (struct high *)b;
	int d = p1->a;
	int f = p2->a;
	return f - d;
}