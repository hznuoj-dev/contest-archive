#include<stdio.h>
int main(){
	int n,m,t,y;
	scanf("%d",&n);
	for(m=0;m<n;m++){
		scanf("%d %d",&t,&t);
		if(t==0)
		  printf("no\n");
		else
		  printf("yes\n");
	}
	return 0;
}
