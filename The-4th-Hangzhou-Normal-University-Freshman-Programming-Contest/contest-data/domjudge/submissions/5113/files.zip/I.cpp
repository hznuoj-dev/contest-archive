/*I*/
#include<stdio.h>
#define MAX 10000000 
struct stu{
	int w;
	char song[20];
};
int main(void)
{
	int n, i, k, j, l, index;
	struct stu a[MAX], temp;
	scanf("%d", &n);
	for(i=0;i<n;i++){
		scanf("%d", &a[i].w);
		scanf("%s", a[i].song);
	}
	scanf("%d", &k);
	for(j=0;j<n;j++){
		index=j;
		for(l=j+1;l<n;l++){
			if(a[j].w<a[l].w){
				index=l;
			}
		}
		temp=a[index];
		a[index]=a[j];
		a[j]=temp;
	}
	printf("%s", a[k+1].song);
	return 0;
}
