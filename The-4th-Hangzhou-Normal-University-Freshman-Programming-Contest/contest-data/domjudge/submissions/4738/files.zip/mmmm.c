#include "stdio.h"
struct otaku{
 int w;
 char song[16];
};
int comp(const void *p,const void *q)
{
 return ((struct otaku *)q)->w-((struct otaku *)p)->w;
}
int main(void)
{
 int n,k,i,j;
 scanf("%d",&n);
 struct otaku p[n];
 for(i=0;i<n;i++)
 {
  getchar();
  scanf("%d %s",&p[i].w,p[i].song);
 }
 scanf("%d",&k);
 qsort(p,n,sizeof(struct otaku),comp);
 printf("%s",p[k].song);
 return 0;
}
