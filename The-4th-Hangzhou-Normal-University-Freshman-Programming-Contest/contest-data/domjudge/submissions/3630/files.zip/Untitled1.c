#include<stdio.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
char s[100000][16];
int comp(const void *p,const void *q){
	return (*(int *)q-*(int *)p);
}
int main()
{
	int i,n,k;
	scanf("%d",&n);
	int a[n],b[n];
	for(i=0;i<n;i++)
	{
	scanf("%d%s",&a[i],s[i]);
	b[i]=a[i];
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(int),comp);
	for(i=0;i<n;i++)
	{
	if(a[k]==b[i])
	printf("%s\n",s[i]);
	}
	return 0;
}

