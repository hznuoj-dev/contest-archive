#include <stdio.h>
#include <string.h>
int w[200]={0};
int main()
{
	int t,i;
	scanf("%d",&t);
	getchar();
	int n,m;
	char ch;
	int count1=0,count2=0;
	while(t--)
	{
		count1=0,count2=0;
		scanf("%d",&n);
		getchar();
		while(n--)
		{
			scanf("%c",&ch);
			getchar();
			m=ch;
			w[m]++;
		}
		for(i=0;i<200;i++)
		{
			if(w[i]==1)
			{
				++count1;
				continue;
			}
			else if(w[i]%2!=0&&w[i]>1)
			{
				count2+=w[i]-1;
				++count1;
			}
			else if(w[i]%2==0)
				count2+=w[i];		
		}
		if(count1>1&&count2>0)
			count2+=2;
		else if(count1>1&&count2==0)
			count2+=1;
		else if(count1==1)
			count2+=1;
		printf("%d\n",count2);
		memset(w,0,sizeof(w));
	}
				
	return 0;
}
