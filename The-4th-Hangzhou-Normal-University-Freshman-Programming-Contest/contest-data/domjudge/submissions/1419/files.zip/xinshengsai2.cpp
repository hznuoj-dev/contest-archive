/*#include<stdio.h>
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		int Y,A,x;
		int n=0;
		int m=0;
		int c=0;
		int d=0;
		scanf("%d %d",&Y,&A);
		if(A>0){
			if(Y+A<10000){
		for(int i=Y;i<=Y+A;i++){
			if(i%4==0&&i%100!=0||i%400==0)
		     n++;
	}
		printf("%d\n",n);
	}
	else{
		if(19998-(Y+A)>Y){
		for(int i=Y;i<=(9999-(Y+A-9999));i++){
		if(i%4==0&&i%100!=0||i%400==0)
		     c++;
	}
	printf("%d\n",c);
}
        if(19998-(Y+A)<=Y){
		for(int i=19998-(Y+A);i<=Y;i++){
		if(i%4==0&&i%100!=0||i%400==0)
		     d++;
	}
	printf("%d\n",d);
}
}
}
	if(A<=0){
		for(int i=Y+A;i<=Y;i++){
			if(i%4==0&&i%100!=0||i%400==0)
			m++;
		}
		printf("%d\n",m);
	}
	}

return 0;	
		
	}*/
/*#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int a[100];
	double sum=0.0;
	int max=a[0];
	int min=a[0];
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
		sum+=a[i];
		if(a[i]>max){
			max=a[i];
		}
		if(a[i]<min){
			min=a[i];
		}
	}
	printf("%d %d %.1f",max,min,sum/n);
	return 0;
}	*/
#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	while(n--){
		printf("Welcome to HZNU\n");
	}
	return 0;
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
