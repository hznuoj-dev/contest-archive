#include<stdio.h>
int main()
{
	int n, m, b, i, as = 0;
	scanf("%d", &n);
	while (n--)
	{
		scanf("%d %d", &m, &b);
		if (b == 0)
			printf("no\n");
		else
		{
			if (m % b == 0)
				printf("yes\n");
			else
			{
				for (i = 2; i <= 10; i++)
				{
					if (m * i % b == 0)
					{
						printf("yes\n");
						as = 1;
						break;
					}
				}
				if (as == 0)
					printf("no\n");
			}
		}
		as = 0;
	}

	return 0;
}