#include<stdio.h>
struct song{
	int num;
	char str[20];
};
int comp(const void *p,const void *q){
	return ((struct song*)q)->num-((struct song*)p)->num;
}
struct song a[100000];
int main(){
    int i,n,m;
    scanf("%d",&n);
    for(i=0;i<n;i++){
    	scanf("%d %s",&a[i].num,&a[i].str);
	}
	scanf("%d",&m);
	qsort(a,n,sizeof(struct song),comp);
	printf("%s",a[m].str);
	return 0;
}
