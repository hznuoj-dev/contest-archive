#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char w[100050];

int main(void) {
	int T, n, i, j, cnt = 0, flag;
	char a;
	a = '*';
	scanf("%d", &T);
	while (T--) {
		cnt = 0;
		memset(w, 0, sizeof(w));
		scanf("%d", &n);
		getchar();
		for (i = 0; i < n; ++i) {
			scanf("%c", &w[i]);
			getchar();
		}

		for (i = 0; i < n; ++i) {
			for (j = i + 1; j < n; ++j) {
				if (w[i] == a) {
					break;
				}
				if (w[i] != a) {
					if (w[i] == w[j]) {
						w[j] = a;
						cnt++;
						break;
					}
				}

			}
		}
		if (cnt * 2 < n) {
			printf("%d\n", cnt * 2 + 1);
		} else if (cnt * 2 == n) {
			printf("%d\n", cnt * 2);
		}

	}




}

