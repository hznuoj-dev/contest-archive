#include<stdio.h>
int main()
{
	int a;
	long long int n, x;
	scanf("%d", &a);
	while (a--)
	{
		scanf("%ld%ld", &n, &x);
		if (n * x != 0) {
			printf("yes");
		}
		else
			printf("no");
	}
	return 0;
}