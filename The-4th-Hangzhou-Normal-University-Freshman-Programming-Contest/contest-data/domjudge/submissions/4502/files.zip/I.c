#include <stdio.h>
#include <stdlib.h>
struct song{
	 int w;
	char a[100];
};
int comp(const void *p, const void *q){
	return ((struct song*)q)->w - ((struct song *)p)->w;
}
int main(void){
	int n, i, k;
	struct song arr[100000];
	scanf("%d", &n);
		for (i = 0; i < n; i++){
			scanf("%d", &arr[i].w);
			scanf("%s", arr[i].a);
		}
		scanf("%d", &k);
		qsort(arr, n, sizeof(struct song), comp);
		for (i = 0; i < n; i++){
			if (i == k)
				printf("%s\n", arr[i].a);
		}
	
	return 0;
}
