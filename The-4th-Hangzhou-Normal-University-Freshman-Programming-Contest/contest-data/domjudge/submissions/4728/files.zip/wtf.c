﻿
#include<stdio.h>
#include<math.h>
#include<string.h>
int main() {
	int i, t, k, j;
	char bq[100][100], m[100];
	long long sb[100];
	scanf("%d", &t);
	for (i = 0; i < t; i++) {
		scanf("%lld", &sb[i]);
		scanf("%s", bq[i]);
	}
	for (i = 0; i < t - 1; i++) {
		for (j = 0; j < t - 1 - i; j++) {
			if (sb[j] < sb[j + 1]) {
				strcpy(m, bq[j]);
				strcpy(bq[j], bq[j + 1]);
				strcpy(bq[j + 1], m);
				k = sb[j];
				sb[j] = sb[j + 1];
				sb[j + 1] = k;
			}
		}
	}
	scanf("%d", &k);
	printf("%s\n", bq[k]);

}

