#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	for(int z=0;z<n;z++){
		printf("Welcome to HZNU\n");
	}
	return 0;
}
