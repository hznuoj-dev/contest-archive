#include<stdio.h>
#include<stdlib.h>
#include<string.h>		
int main()
{
	int n,m,i,a,q=0,flag=0;
	int x[10]={0},k=0,maxa=0;
    scanf("%d%d",&n,&m);
    for(i=0;i<n;i++)
    {
    	scanf("%d",&a);
    	x[a]++;
    	if(a==0)
    	{
    		scanf("%d",&k);
    		if(k>maxa)
    		{
    			maxa=k;
			}
		}
	}
	if(m==0)
	{
		if(x[2]!=0&&(n-x[2]-x[1]>=1))
	    {
		printf("haoye\n");
	    }
	    else if(x[0]!=0&&x[1]!=0&&maxa>=2500)
	    {
	    	printf("haoye\n");
		}
		else
		{
			printf("QAQ\n");
		}
	}
	if(m==1)
	{
		if(x[2]!=0&&(n-x[2]-x[1]>=1))
	    {
		printf("haoye\n");
	    }
	    else if(x[0]!=0&&x[1]!=0&&maxa>=2100)
	    {
	    	printf("haoye\n");
		}
		else
		{
			printf("QAQ\n");
		}
	}
}
 
