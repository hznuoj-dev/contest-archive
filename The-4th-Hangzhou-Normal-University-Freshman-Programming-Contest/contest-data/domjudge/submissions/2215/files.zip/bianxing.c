#include<stdio.h>
int main()
{
	int a[1000];
	int t;
	int n,x,i,k;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&x);
		for(i=0;i<n;i++)
		{
			a[i]=-1;
		}
		for(i=0,k=0;k<2*n;i+=x,k++)
		{
			a[i]=i;
			if(i>=n)
			{
				i=i+x-n+1;
			}
		}
		if(a[x])
		{
			printf("yes\n");
		}
		else
		{
			printf("no\n");
		}
	}
	return 0;
}
