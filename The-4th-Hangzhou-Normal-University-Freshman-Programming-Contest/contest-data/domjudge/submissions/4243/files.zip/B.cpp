#include<bits/stdc++.h>
using namespace std;
const int N=100010;

int t;
int n;
int a[N];
int pre[N];
int main(){
	cin >>t;
	while(t--){
		cin >>n;
		for(int i=1;i<=n;i++) cin >>a[i];
		pre[1]=a[1];
		for(int i=2;i<=n;i++) pre[i]=a[i]+pre[i-1];
		int ans=0;
		for(int i=n;i>=1;--i){
			int l=0,r=i-1;
			int mid;
			while(l<=r){
				mid=(l+r)/2;
				int k=pre[i]-pre[mid];
				if(k==7777)break;
				else if(k>7777) l=mid+1;
				else if(k<7777) r=mid-1;
			}
			if(l<=r)ans++;
		}
		cout << ans << '\n';
	} 


return 0;
}

