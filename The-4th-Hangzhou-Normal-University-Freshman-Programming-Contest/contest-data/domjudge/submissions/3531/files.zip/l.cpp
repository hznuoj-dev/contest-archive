#include<bits/stdc++.h>
using namespace std;

int main(){
	int t,n,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&x);
		if(x==0||n<=2)
			printf("no\n");
		int t;
		if(n<x){
			t=x;
			x=n;
			n=t;
		}
		int i=0,num,flag=0;
		while(i<100){
			num=n%x;
			x=x-num;
			if(num==0){
				flag=1;
				break;
			}
		}
		if(flag=1)
			printf("yes\n");
		else
			printf("no\n");
	} 
	return 0;
} 
