#include<stdio.h>
int main(){
	int a,b,c;
	scanf("%d",&a);
	while(a--){
		scanf("%d %d",&b,&c);
		if(b!=0&&c!=0){
			printf("yes\n");
		}
		else printf("no\n");
	}
	return 0;
} 
