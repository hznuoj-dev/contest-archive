#include <stdio.h>
#include <string.h>
char arr[100000];
char str[100000];
char arrs[100000];
int main(void)
{
	int t;
	scanf("%d",&t);
	getchar();
	while(t--){
		int n;
		scanf("%d",&n);
		getchar();
		int i,j,p;
		gets(arr);
		int len=strlen(arr);
		int k=0;
		for(i=0;i<len;i++){
			if(arr[i]!=' '){
				str[k]=arr[i];
				k++;
			}
		}
		int m=0;
		int flag=0;
		for(i=0;i<k;i++){
			for(j=0;j<k;j++){
				if(str[i]==str[j]&&i!=j){
					if(m==0){
						arrs[m]=str[i];
						m++;
					}
					else{
						for(p=0;p<m;p++){
							if(str[i]==arrs[p]){
								flag=1;
							}
						}
						if(flag==0){
							arrs[m]=str[i];
							m++;
						}
					}
				}
			}
		}
		if(2*m==n)
		printf("%d\n",2*m);
		else
		printf("%d\n",2*m+1);
	}
	return 0;
 } 
