#include <bits/stdc++.h>
using namespace std; 
string s[1050];
string fh;
int main()
{
	int T,n,i,slen;
	scanf("%d",&T);
	while (T--)
	{
		n=1;
		while (1)
		{
			cin >> s[n];
			slen=s[n].length();
			if (s[n][slen-1]=='.' || s[n][slen-1]=='!' || s[n][slen-1]=='?') 
			{
				fh=s[n][slen-1];
				s[n]=s[n].substr(0,slen-1);
				break;
			}
			n++;
		}
		int q=1,f=1;
		while (q<=n)
		{
			if (f==1) 
			{
				cout << s[q] << " ";
				f*=-1;
				q++;
			}
			else if (f==-1) 
			{
				cout << s[n] << " ";
				f*=-1;
				n--;
			}
		}
		printf("\b");
		cout << fh << endl;		
	}
	
}
