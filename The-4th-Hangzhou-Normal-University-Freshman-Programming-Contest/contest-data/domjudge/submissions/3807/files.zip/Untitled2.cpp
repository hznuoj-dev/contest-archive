#include<stdio.h>
#include<string.h>

int main(){
	int n;
	scanf("%d",&n);
	getchar();
	for(n;n>0;n--){
	
char a[1001][31]={0};
int i =0;
char s;
char str[30001];
int temp = 0;
fgets(str,30001,stdin);
char *p = str;
while(*p!='!'&&*p!='?'&&*p!='.')
{
   a[i][temp] = *p;
   temp++;
   p++;
   
   if(*p==' '){
   i++;  
   temp = 0;
}
}
i++;
temp  =0;
for(int k =1;k<=i;k++)
{
	if(k%2==1){
	printf("%s",a[temp]);
	}
	else{
	printf("%s",a[i-temp-1]);
    }
	if(k%2==0)
	temp++;
}
printf("%c",*p);
if(n!=1)
printf("\n");

for(int k =0;k<i;k++){
	for(int i = 0;i<31;i++)
	a[k][i]='1';
}
}
}
