#include<bits/stdc++.h>
using namespace std;
map<char,int> mp;
int main()
{

	char c;
	int N;
	int tmp;
	int cnt=0;
	cin>>N;
	int n;
	while(N--)
	{
		mp['a']=0;
		mp['b']=0;
		mp['c']=0;
		mp['d']=0;
		mp['e']=0;
		mp['f']=0;
		mp['g']=0;
		mp['h']=0;
		mp['i']=0;
		mp['j']=0;
		mp['k']=0;
		mp['l']=0;
		mp['m']=0;
		mp['n']=0;
		mp['o']=0;
		mp['p']=0;
		mp['q']=0;
		mp['r']=0;
		mp['s']=0;
		mp['t']=0;
		mp['u']=0;
		mp['v']=0;
		mp['w']=0;
		mp['x']=0;
		mp['y']=0;
		mp['z']=0;
		mp['A']=0;
		mp['B']=0;
		mp['C']=0;
		mp['D']=0;
		mp['E']=0;
		mp['F']=0;
		mp['G']=0;
		mp['H']=0;
		mp['I']=0;
		mp['J']=0;
		mp['K']=0;
		mp['L']=0;
		mp['M']=0;
		mp['N']=0;
		mp['O']=0;
		mp['P']=0;
		mp['Q']=0;
		mp['R']=0;
		mp['S']=0;
		mp['T']=0;
		mp['U']=0;
		mp['V']=0;
		mp['W']=0;
		mp['X']=0;
		mp['Y']=0;
		mp['Z']=0;
		cnt=0;
		cin>>n;
		tmp=n;
		while(n--)
		{
			cin>>c;
			mp[c]++;
			if(mp[c]%2==0)
			{
				mp[c]-=2;
				cnt+=2;
				tmp=tmp-2;
			}
		}
		if(tmp==0)
		{
			cout<<cnt<<'\n';
		}
		else
		{
			cout<<cnt+1<<'\n';			
		}

	}
	
}
