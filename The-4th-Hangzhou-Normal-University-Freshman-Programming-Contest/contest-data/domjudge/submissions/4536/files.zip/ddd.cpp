#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct z {
	int a;
	char b[16];
};
int m(const void* a, const void* b) {
	struct z* p1 = (struct z*)a;
	struct z* p2 = (struct z*)b;
	int d = p1->a;
	int f = p2->a;
	return f - d;
}
int main(void) {
	int n;
	scanf("%d", &n);
	struct z g[n];
	int i = 0;
	while (i != n) {
		scanf("%d %s", &g[i].a, g[i].b);
		i++;
	}
	int k;
	scanf("%d", &k);
	qsort(g, n, sizeof(struct z), m);
	printf("%s", g[k].b);
}

