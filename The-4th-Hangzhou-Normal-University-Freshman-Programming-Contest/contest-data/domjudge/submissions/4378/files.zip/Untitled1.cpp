#include<stdio.h>
#include<stdlib.h>
struct loy{
 int x;
 char name[30];
 
};
int cmp(const void*p,const void*q);
int cmp(const void*p,const void*q)
{
 struct loy *pp=(struct loy *)(p);
 struct loy *pq=(struct loy *)(q);
 int a=pp->x;
 int b=pq->x;
 return b-a;
}
int main()
{ 
 int t,n,j,k,x;
  scanf("%d",&n);
  struct loy a[n];
  for(j=0;j<n;j++)
  {
   scanf("%d%s",&a[j].x,a[j].name);
  }
  qsort(a,n,sizeof(struct loy),cmp);
   scanf("%d",&k); 
   printf("%s\n",a[k].name);
 return 0;
}
 
