#include<stdio.h>

int main(void){
int n;
scanf("%d",&n);
for(int i=0;i<n;i++){

printf("Welcome to HZNU");
if(i!=n-1)
printf("\n");
}
}
