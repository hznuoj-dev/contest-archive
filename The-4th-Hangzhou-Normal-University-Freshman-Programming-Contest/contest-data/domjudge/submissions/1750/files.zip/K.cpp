#include<stdio.h>
int main()
{
	int a;
	scanf("%d",&a);
	while(a>1)
	{
		printf("Welcome to HZNU\n");
		a--;
	}
	printf("Welcome to HZNU");
 } 
