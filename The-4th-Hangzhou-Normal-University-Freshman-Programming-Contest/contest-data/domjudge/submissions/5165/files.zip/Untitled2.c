#include<stdio.h>
int main()
{
	int T;
	int n,x;
    scanf("%d",&T);
    while(T--)
{
    	scanf("%d%d",&n,&x);
    if(x==0)
   {
	printf("no\n");
   }
	else
	if(x!=0)
	{
		printf("yes\n");
	}
}
	return 0;
}

