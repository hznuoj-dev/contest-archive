#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct bom{
	char a[2];
};
int comp(const void*p,const void*q)
{
	int s1=((struct bom*)p)->a;
	int s2=((struct bom*)q)->a;
	return s1<s2? 1:-1;
}
int main()
{
	int T,n,i,j;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		int t=1;
		struct bom ch[n+1];
		for(i=0;i<n;i++)
		{
			scanf("%s",ch[i].a );
		}
		qsort(ch,n,sizeof(struct bom),comp);
		for(i=1;i<=n;i++)
		{
			if(strcmp(ch[i].a ,ch[i-1].a )==0)
			t=t+2;
			i++;
		}
		printf("%d\n",t);
	}
} 
