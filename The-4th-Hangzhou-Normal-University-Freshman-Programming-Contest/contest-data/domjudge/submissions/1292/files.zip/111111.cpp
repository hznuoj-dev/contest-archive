#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<map>
#include<iomanip>
#include<ctime>
using namespace std;

int main()
{
	int n;
	cin >> n;
	while (n--)
	{
		cout << "Welcome to HZNU" << endl;
	}

}