/*#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int a[100005];
int main()
{
    int t;
    int sum;
    int flag=0;
    int i,j;
    int n;
    scanf("%d",&t);
    while(t--){
    	flag=0;
    	scanf("%d",&n);
    	for(i=0;i<n;i++){
    		scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			sum=a[i];
			if(sum==7777){
				flag++;
			}
			else{
				for(j=i+1;j<n;j++){
					sum+=a[j];
					if(sum==7777){
					    flag++;
					    break;
					}
					else if(sum>7777)
					    break;
				}
			}
				
				
	   }
	   	
		printf("%d\n",flag);
	}
	return 0;
}*/
/*#include<stdio.h>
#include<string.h>
int shunshi(int *a,int *b,int n);
int nishi(int *a,int *b,int n);
int pandun(int*a,int *b,int n);
int a[25][25],b[25][25];
int main()
{
	int t;
	int i,j;
	int n;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&a[i][j]);
			}
		}
		for(int i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&b[i][j]);
			}
		}
	}
	
}
int panduan(int *a,int *b,int n){
	int i,j;
	int flag=0;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(a[i][j]!=b[i][j]);
			flag=1;
		}
	}
	if(flag==1){
		return 0;
	}
	else
	    return 1;
}
int shunshi(int *a,int *b,int n){
	int temp;
	int c[n][n];
	while(panduan(a,b)==0){
		
	}
}*/
#include<stdio.h>
int a[20][2];
int main()
{
	int n;
	int i=0;
	int k;
	int flag2=0;
	int flag0=0,flag1=0;
	int zitai;
	scanf("%d %d",&n,&zitai);
	//printf("n=%d zitai=%d",n,zitai);
	if(zitai==0){
		k=2500;
	} 
	else{
		k=2100;
	}
	//printf("k=%d",k);
	
	for(i=0;i<n;i++){
		
		scanf("%d",&a[i][0]);
		if(a[i][0]==0){
			scanf("%d",&a[i][1]);
			if(a[i][1]>=k){
				flag0=1;
			}
		}
		else if(a[i][0]==2){
			flag2=1;
		}
		else if(a[i][0]==1){
			flag1=1;
		}
		//printf(" %d %d %d %d\n",i,flag0,flag1,flag2);
		//printf("a[%d][0]=%d a[%d][1]=%d\n",i,a[i][0],i,a[i][1]);
		
	}
	if(flag0==1&&flag1==1){
		printf("haoye");
	}
	else if(flag2==1&&n>=2){
		 printf("haoye");
    }
	else{
		printf("QAQ");
	}
	return 0;
	
}
