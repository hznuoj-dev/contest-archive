#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
	char ch[10000][10000];
char dh[100][100];
int main(void){
	int n,i,j,y,k,x;
	char str[100]={' '};
scanf("%d",&n);

while(n--){
getchar();
	i=0;
	j=0;
	while((ch[i][j]=getchar())!='\n'){
		if(ch[i][j]==' '){
			ch[i][j]='\0';
			i++;
			j=0;
		}
		else if(ch[i][j]=='.'||ch[i][j]=='!'||ch[i][j]=='?'){
			dh[0][0]=ch[i][j];
			ch[i][j]=' ';
			break;
		}
		else j++;
	}
	if(i==0) printf("%s%c",ch[0],dh[0][0]);
else{
	if(i%2==1){
		for(k=0;k<=i/2;++k){
		printf("%s ",ch[k]);
	if(k==1)	printf("%s ",ch[i-k]);
	else printf("%s",ch[i-k]);
	}
	printf("%c",dh[0][0]);
	printf("\n");
	}
	else {
		for(k=0;k<i/2;++k){
		printf("%s ",ch[k]);
	if(k==1)	printf("%s ",ch[i-k]);
	else printf("%s",ch[i-k]);
	}
	printf("%s",ch[i/2]);
	printf("%c",dh[0][0]);
	printf("\n");
	}
	for(j=0;j<i;++j)
	strcpy(ch[j],str);}
}
	return 0;
} 
