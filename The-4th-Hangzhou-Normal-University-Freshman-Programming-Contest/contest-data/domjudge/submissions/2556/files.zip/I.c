#include<stdio.h>
#include<string.h>
struct song{
	long long w;
	char s[20];
}p[100001],q;
int main(void){
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%lld %s",&p[i].w,p[i].s);
	}
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1-i;j++){
			if(p[j].w<p[j+1].w){
				q=p[j];
				p[j]=p[j+1];
				p[j+1]=q;
			}
		}
	}
	scanf("%d",&k);
	printf("%s\n",p[k].s);
	return 0;
}

