#include<stdio.h>
#include<stdlib.h>
struct song
{
	long long int numb;
	char mz[20];
};
struct song a[100005];
int comp(const void *p,const void *q);
int main()
{
	int t,i,k;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%lld",&a[i].numb);
		scanf("%s",a[i].mz);
	}
	scanf("%d",&k);
	qsort(a,t,sizeof(struct song),comp);
	printf("%s\n",a[k].mz);
}
int comp(const void *p,const void *q)
{
	return(((struct song*)q)->numb-((struct song*)p)->numb);
}