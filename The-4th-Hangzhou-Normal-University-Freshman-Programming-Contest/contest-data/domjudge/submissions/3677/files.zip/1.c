#include<stdio.h>
#include<string.h>
#include<math.h>
int main() {
	int n, i, j, t, sum, x;
	char zi;
	scanf("%d", &t);
	while (t--) {
		sum = 0;
		char a[10000];
		int b[10000] = { 0 };
		x = 0;
		//getchar();
		scanf("%d", &n);
		getchar();
		for (i = 0; i < 2 * n; i++) {
			scanf("%c", &zi);
			b[zi]++;

		}
		//scanf("%c", &a[i]);


		for (i = 65; i < 123; i++) {
			if (b[i] % 2 == 0) {
				sum += b[i];
			}
			else if (b[i] > x) {
				x = b[i];
			}
		}
		sum += x;
		printf("%d\n", sum);


	}
}