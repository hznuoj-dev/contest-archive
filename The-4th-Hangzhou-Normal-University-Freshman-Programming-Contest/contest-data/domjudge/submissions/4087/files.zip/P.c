#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main(void)
{
	int T,len,i,j;
	scanf("%d",&T);
	while(T--){
		int cnt=1;
		char words[1010][32],ch;
		scanf("%s",words[0]);
		len=strlen(words[0]);
		if((words[0][len-1]=='.'||words[0][len-1]=='!'||words[0][len-1]=='?')==0){
			while(1){
				scanf(" %s",words[cnt]);
				cnt++;
				len=strlen(words[cnt-1]);
				if(words[cnt-1][len-1]=='.'||words[cnt-1][len-1]=='!'||words[cnt-1][len-1]=='?'){
					ch=words[cnt-1][len-1];
					words[cnt-1][len-1]='\0';
					break;
				}
			}
		}else{
			ch=words[0][len-1];
			words[0][len-1]='\0';
		}
		int times=cnt/2;
		printf("%s %s",words[0],words[cnt-1]);
		for(i=1;i<times;i++){
			printf(" %s %s",words[i],words[cnt-1-i]);
		}
		if(cnt%2){//odd
			printf(" %s%c\n",words[times],ch);
		}else{
			printf("%c\n",ch);
		}
	}
	return 0;
}
