#include<stdio.h>
#include<string.h>
int main(){
	int c=0,i,t,a[200]={0},j,b,n,k;
	char s[10010],ch;
	scanf("%d",&t);
	getchar();
	for(k=1;k<=t;k++){
		scanf("%d",&n);
		getchar();
	  for(j=0;j<=n*2-1;j++){
		  ch=getchar();
		  b=ch-64;
		  if(b>=1&&b<=26||b>=33&&b<=58){
		  a[b]=a[b]+1;
		  if(a[b]==2){
			  c=c+2;
			  a[b]=0;
		  }
		  }
	  }
	j=0;
	for(i=1;i<60;i++){
		if(a[i]==1){
			j=1;
			a[i]=0;
		}
	}
	c=c+j;
	printf("%d\n",c);
	c=0;
	}
}
			