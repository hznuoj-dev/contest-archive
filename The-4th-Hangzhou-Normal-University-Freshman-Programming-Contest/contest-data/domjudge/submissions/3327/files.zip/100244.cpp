#include <iostream>
using namespace std;
int b[100001];
char c[100001][16];
void mystrcpy(char a[],char b[])
{
	int i;
	for(i=0;b[i]!='\0';++i)
	{
		a[i] = b[i];
	}
}
void qsort1(int l,int r)
{
	int i,j,mid,p;
	i=l;
	j=r;
	mid=b[(l+r)/2];
	char temp1[16];
	do
	{
		while (b[i]<mid)
			++i;
		while (b[j]>mid)
			--j;
		if (i<=j)
		{
			p=b[i];
			b[i]=b[j];
			b[j]=p;
			mystrcpy(temp1,c[i]);
			mystrcpy(c[i],c[j]);
			mystrcpy(c[j],temp1);
			i++;
			j--;
		}
	}while(i<=j);
	if (l<j)
		qsort1(l,j); 
	if (i<r)
		qsort1(i,r);
}
int main()
{
	int n;
	cin>>n;
	int i;
	for(i=0;i<n;++i)
	{
		cin>>b[i]>>c[i];	
	}
	int g;
	cin>>g;
	qsort1(0,n-1);
	cout<<c[n-g-1]<<endl;
}
