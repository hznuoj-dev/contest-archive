#include <stdio.h>
int a[1000000];
int main(void){
	int n,x,y,t,i,flag,s;
	scanf("%d",&t);
	while(t--){
		s=0;
		flag=0;
		scanf("%d %d",&n,&x);
		if(x!=0)flag=1;
		
		if(flag){
			printf("yes\n");
		}else{
			printf("no\n");
		}
	}
	return 0;
} 
