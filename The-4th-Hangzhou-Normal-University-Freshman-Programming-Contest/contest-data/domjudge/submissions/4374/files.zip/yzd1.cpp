#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
int main () {
	int f1=0,f2=0;
	cnm;
	int n,m,x,y;
	cin >> n >> m;
	while (n){
	 cin >> x;
	 if (x==0){
	 	cin >> y;
	 	if ((m==0&&y>=2500)||(m==1&&y>2100)){
	 		f1=1;
	 		n--;
		 }
	 }
	 else if (x==1&&f1==1) {
	 	f2=1;
	 	n--;
	 }
	 else if (x==2){
	 	f2=1;
	 	n-=2;
	 }
	 if (f2) {
	 cout << "haoye";
	 break;
	}
}
if (f2=0) cout << "QAQ";
	return 0;
}
