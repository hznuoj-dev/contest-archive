#include<stdio.h>
#include<string.h>
int main(viod) {
	int n, i, j, a[10000][3], w, temp, k; char b[10000][30] = { 0 };
	scanf("%d", &n);
	for (i = 1; i <= n; i++) {
		scanf("%d", &a[i][1]);
		a[i][2] = i;
		getchar();
		scanf("%s", b[i]);
	}
	scanf("%d", &k);
	for (i = 1; i < n; i++) {
		w = 0;
		for (j = 1; j <= n - i; j++) {
			if (a[j][1] < a[j + 1][1]) {
				temp = a[j][1];
				a[j][1] = a[j + 1][1];
				a[j + 1][1] = temp;
				w = 1;
				temp = a[j][2];
				a[j][2] = a[j + 1][2];
				a[j + 1][2] = temp;
			}	
		}
		if (w == 0)
			break;
	}
	for (i = 0; i <(signed) strlen(b[a[k + 1][2]] ); i++) {
		printf("%c", b[a[k + 1][2]][i]);
	}
	
	return 0;
}











