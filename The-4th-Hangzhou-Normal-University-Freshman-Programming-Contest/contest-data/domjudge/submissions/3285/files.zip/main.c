//
//  main.c
//  L.cpp
//
//  Created by 陶艾嘉 on 2021/12/12.
//

#include <stdio.h>
int main(){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,x,y;
        scanf("%d %d",&n,&x);
        y=2*n-2;
        if(y%x==0){
            printf("yes\n");
            }
    else
        printf("no\n");
    }
}
