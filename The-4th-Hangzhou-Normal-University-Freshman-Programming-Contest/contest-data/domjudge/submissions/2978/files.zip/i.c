#include<stdio.h>
#include<stdlib.h> 
struct g{
	int cs;
	char name[16];
};
int compar(const void*p,const void*q){
	return ((struct g*)q)->cs-((struct g*)p)->cs;
}
int main(){
	int n,xh,i;
	scanf("%d",&n);
	struct g gq[n];
	for(i=0;i<n;i++){
		scanf("%d%s",&gq[i].cs,gq[i].name);
	}
	scanf("%d",&xh);
	qsort(gq,n,sizeof(gq[0]),compar);
	for(i=0;i<n;i++){
		if(gq[i].cs==xh)
		break;
	}
	printf("%s",gq[i+1].name);
}
