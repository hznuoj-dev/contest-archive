#include<stdio.h>
struct gm{
	long long int bh;
	char s[16];
};
struct gm a[100001];
int cmp( const void *a,const void *b){
	return ((struct gm *)a)->bh-((struct gm *)b)->bh;
	}
int main(){
	struct gm ch;
	int n,k,x,y;
	scanf("%d",&n);
	for(x=0;x<n;x++){
		scanf("%lld %s",&a[x].bh,a[x].s);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(a[0]),cmp);
	puts(a[n-k-1].s);
	return 0;
}
