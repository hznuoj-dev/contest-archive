//l
#include<stdio.h>
int main(){
	int flag;
	long long t,n,x,count,num;
	scanf("%lld",&t);
	while(t--){
		scanf("%lld %lld",&n,&x);
		flag=0;
		if(x==0){
			printf("no\n");
		}
		else{
			count=n;
			
			num=1000000000;
			while(num--){
			if(count-x>=0)count-=x;
			else count=count+n-x;
			if(count==0){flag=1;break;}
			if(count==x){break;}
			}
			
			if(flag==1)printf("yes\n"); else printf("no\n");
		}
	}
} 
