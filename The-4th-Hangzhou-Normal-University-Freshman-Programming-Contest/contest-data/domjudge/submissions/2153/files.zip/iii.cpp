#include<bits/stdc++.h>

using namespace std;
map<int ,string > p;
const int N=1e5+10;
int a[N];
int main()
{
	int n,cnt=0;
	cin >> n;
	for(int i=1;i<=n;i++)
	{
		int x; string ch;
		cin >> x >> ch;
		p[x]=ch;
		a[++cnt]=x;	
	}
	int k;
	cin >> k;
	cout << p[a[cnt-k]];
}
