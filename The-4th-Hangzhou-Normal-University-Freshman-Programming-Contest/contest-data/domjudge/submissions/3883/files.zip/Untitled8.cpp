#include <stdio.h>
#include <string.h>

int main(void){
	int t;
	scanf("%d",&t);
	getchar();
	char s[100000];
	char part[1010][50];
	for (int i=1; i<=t; i++){
		memset(s, 0, sizeof(s));
		for(int j=0; j<1010; j++) memset(part[j], 0, sizeof(part[j]));
		fgets(s,1010,stdin);
		int length=strlen(s);
		int c1=0,c2=0;
		for (int j=0; j<length-2; j++){
			if (s[j]==32) {
				j++;
				c1++;
				c2=0;
			}
			part[c1][c2]=s[j];
			c2++;
		}
		
		if (c1>=1) printf("%s %s",part[0],part[c1]);
		if (c1==0) printf("%s",part[0]);
		for (int j=1; j<(c1+1)/2; j++) printf(" %s %s",part[j],part[c1-j]);
		if (c1%2==0 && c1!=0) printf(" %s",part[c1/2]);
		printf("%c\n",s[length-2]);
	}
	return 0;
}
