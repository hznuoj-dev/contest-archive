#include <string.h>
#include <stdio.h>
#include <math.h>


int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int n;
		scanf("%d", &n);
		char ch[10005];
		int i;
		for (i = 0; i < 2 * n; i++) {
			scanf("%c", &ch[i]);
		}
		int sum = 0, j;
		for (i = 0; i < n * 2; i++) {
			for (j = i + 1; j < n * 2; j++) {
				if (ch[i] == ch[j] && ch[j] != NULL && ch[j] != ' ') {
					sum++;
					ch[j] == NULL;
					break;
				}
			}
		}
		if (sum == 0)
			printf("1\n");
		else if (sum == n)
			printf("%d\n", 2 * sum);
		else if (sum != n)
			printf("%d\n", 2 * sum + 1);
	}
}









