#include<stdio.h>
#include<math.h>
#include<string.h>
int main (){
	int t=0,n=0,x=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&x);
		if(x==0){
			printf("no\n");
		} else {
			printf("yes\n");
		}
	}
	return 0;
}
