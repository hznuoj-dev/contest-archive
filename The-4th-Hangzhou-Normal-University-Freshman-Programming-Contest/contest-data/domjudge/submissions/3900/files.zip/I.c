#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int n,w,k,i,j,t,max;
	scanf("%d",&n);
	char a[n];
	char s[17];
	for(i=0;i<n;i++){
		scanf("%s %s",&a[i],&s[i]);
		strcpy(a,s);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++){
		max=i;
		for(j=i+1;j<n;j++){
			if(a[j]>a[max])
				max=j;
				t=a[max];
				a[max]=a[j];
				a[j]=t;
		}	
	}
	for(i=0;i<n;i++){
		if(i==n-k-1)
			printf("%s",a[i]);
	}
	return 0;	
}
