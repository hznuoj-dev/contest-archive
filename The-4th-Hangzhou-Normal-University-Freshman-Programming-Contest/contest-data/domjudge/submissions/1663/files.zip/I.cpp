#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct ko{
	int m;
	char l[40];
}; 
int mp(const void *p,const void *q)
{
	
	struct ko *pp =(struct ko *)p;
	struct ko *pq = (struct ko *)q;
	int a= pp->m ;
	int b= pq->m ;
	return b-a;
}
int main()
{
	struct ko a[10000];
	int n, i, j, k;
	scanf("%d", &n);
	for(i=0;i<n;++i)
	{
		scanf("%d %s", &a[i].m ,a[i].l );
 	}
 	qsort(a,n,sizeof(struct ko ),mp);
 	scanf("%d", &k);
 	//for(i=0;i<n;++i)
	//{
	//	printf("%d %s\n", &a[i].m ,a[i].l );
 	//}
 	printf("%s\n", a[k].l );
	
}
