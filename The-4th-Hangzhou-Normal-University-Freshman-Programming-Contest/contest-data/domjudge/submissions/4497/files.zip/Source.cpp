#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
char a[100000];
char b[1003][35];
char c[1003][35];
int main()
{
	int T,j,i;
	int aa;//��ż����
	char ha;
	scanf("%d", &T);
	getchar();
	while (T--) {
		memset(a, '\0', sizeof(a));
		memset(b, '\0', 1003*35);
		memset(c, '\0', 1003 * 35);
		fgets(a,30003,stdin);
		int z=j = i = 0;
		while (a[i]!='\n')
		{
			if (a[i] == ' ') {
				j = j + 1;
				z = 0;
			}
			else
			{
				b[j][z] = a[i];
				z = z + 1;
			}
			i = i + 1;
		}
		aa = j /2+1;
		for (int i = 0; i <aa; i++)
		{
			strcpy(c[2*i], b[i]);
		}
		int aaa = 1;
		if (j % 2 == 0) {
			for (int i = aa; i <= j; i++)
			{
				strcpy(c[j - aaa], b[i]);
				aaa += 2;
			}
		}
		else
		{
			for (int i = aa; i <= j; i++)
			{
				strcpy(c[j+1 - aaa], b[i]);
				aaa += 2;
			}
		}
		ha = c[1][z - 1];
		c[1][z - 1] = '\0';
		for (int i = 0; i <= j; i++)
		{
			printf("%s", c[i]);
			if (i != j ) {
				printf(" ");
			}
			else
			{
				printf("%c\n", ha);
			}
		}
	}
	return 0;
}
