#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
char s[100001][17];
int main()
{
	int T,n,sum=0,i,k,a[100001],b[100001],j;

	scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&a[i],s[i]);
		b[i]=a[i];
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(a[j]>a[j+1])
			{
				k=a[j];
				a[j]=a[j+1];
				a[j+1]=k;
			}
		}
	}
	scanf("%d",&k);
	for(i=0;i<n;i++)
	{
		if(a[n-k-1]==b[i])
		{
			printf("%s",s[i]);
		}
	}
 } 
