#include<stdio.h>
int num[100001];
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		int cnt=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%d",&num[i]);
		}
		int sum=0,flag=0;
		for(int i=0;i<n;i++){
			sum=num[i];
			flag=0;
			for(int j=i+1;j<=n;j++){
				if(sum==7777)
				{
					flag=1;
					break;
				}
				else if(sum>7777)
				break;
				else
				sum+=num[j];
			}
			if(flag)
			cnt++;
		}
		printf("%d\n",cnt);
	}
	return 0;
}
