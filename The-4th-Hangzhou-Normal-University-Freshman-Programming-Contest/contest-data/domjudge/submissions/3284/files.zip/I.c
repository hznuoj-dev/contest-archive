#include<stdio.h>
#include<stdlib.h>
struct song{
		int w;
		char s[20];
	};
int comp(const void *p,const void *q){
	return ((struct song *)q)->w-((struct song *)p)->w;
}
struct song PT[100001];
int main(void){

	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&PT[i].w,PT[i].s);
	}
	qsort(PT,n,sizeof(PT[0]),comp);
	scanf("%d",&k);
	printf("%s",PT[k].s);
	return 0;
} 
