#include<stdio.h>
int main (){

long long T;
long long a,b; 
long long t;
scanf("%lld",&T);
while(T--)
{
	scanf("%lld %lld",&a, &b);
	t = 2 * (a - 1);
		 if(b == 0)
	{
		printf("no");
	}
	
   else	if(t% b== 0){
		printf("yes");
		
	}
     else 
	{
		printf("no");
	}
}

}
