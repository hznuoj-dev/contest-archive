#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
int a1[30][30],a2[30][30];
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		long long a,b,k;
		scanf("%ld%ld",&a,&b);
		if(b==0) printf("no\n");
		else{
			for(k=1;k<=a;k++){
				if(a*k%b==0){
					printf("yes\n");
					break;
				}
			}
			if(k>a) printf("no\n");
		}
	}
	return 0;
}
