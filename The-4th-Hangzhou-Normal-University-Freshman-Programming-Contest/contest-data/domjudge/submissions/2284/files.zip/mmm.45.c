//
#include<stdio.h>
int main(void) {
	int t;
	scanf("%d", &t);
	while (t--) {
		int n, x;
		scanf("%d%d", &n, &x);
		if (x == 0)
			printf("no\n");
		if (x != 0) {
			if (n % x == 0)
				printf("yes\n");
			else
				printf("no\n");
		}
	}
	return 0;
}