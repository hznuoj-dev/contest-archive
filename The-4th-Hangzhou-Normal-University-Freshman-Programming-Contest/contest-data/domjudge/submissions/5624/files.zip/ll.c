#include<stdio.h> 
char str[100000];
int main() {
	int n, i, ret, t, mark[130], temp;
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &n);
		ret = 0;
		for (i = 0; i < 130; i++) {
			mark[i] = 0;
		}
		for (i = 0; i < n; i++) {
			getchar();
			scanf("%c", &str[i]);
			temp = str[i];
			mark[temp]++;
		}
		for (i = 0; i < 130; i++) {
			ret += mark[i] / 2;
		}
		if (ret * 2 == n) {
			printf("%d\n", ret * 2);
		}
		else {
			printf("%d\n", ret * 2 + 1);
		}
	}
	return 0;
}