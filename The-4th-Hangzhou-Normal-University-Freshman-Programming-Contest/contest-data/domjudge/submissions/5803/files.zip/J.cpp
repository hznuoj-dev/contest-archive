#include <stdio.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);
	int x,y,max=0,count0=0,count1=0,count2=0;
	while(n--)
	{
		scanf("%d",&x);
		if(x==0)
		{
			scanf("%d",&y);
			if(y>max)
				max=y;
			++count0;	
		}
		else if(x==1)
			++count1;
		else if(x==2)
			++count2;	
	} 
	if(m==0&&max>=2500&&count1!=0)
		printf("haoye\n");
	else if(m==1&&max>2100&&count1!=0)
		printf("haoye\n");
	else if(count2!=0)
	{
		/*if(((m==0&&max>=2500)||(m==1&&max>2100))&&(count1!=0||count0>=2||count2>=2))
			printf("haoye\n");
		else 
			printf("QAQ\n");*/	
		if(count1!=0||count0!=0||count2>=2)	
			printf("haoye\n");
		else 
			printf("QAQ\n");	
	}
	else 
		printf("QAQ\n");	
	return 0;
}
