#include<bits/stdc++.h>
using namespace std;

int n,m,k;

int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>m>>k;
		if(k==0)cout<<"no"<<'\n';
		else{
			if(m>=k)cout<<"yes"<<'\n';
			else cout<<"no"<<'\n';
		}
	}
	
	
	
	
	
	return 0;
} 
