#include<stdio.h>

long long ans[100050];
int main(){
	long long n,k,i,j,count,answer,sum;

	scanf("%lld",&n);
	while(n--){
		scanf("%lld",&k);
		count=k;
		answer=0;
		i=1;
		while(k--){
			scanf("%lld",&ans[i]);
			i++;
		}
		for(i=1;i<=count;i++){//�߶������ۼ� 
			sum=0;
			j=i;
			while(sum<7777){
				sum=sum+ans[j];
				if(j==count)break; //
				j++;
			}
			if(sum==7777)answer++;
		}
		printf("%lld\n",answer);
	}

}
