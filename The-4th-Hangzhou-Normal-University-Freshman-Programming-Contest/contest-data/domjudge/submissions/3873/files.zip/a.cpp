#include<stdio.h>
int a[52];
int main(void){
	int t,n,b,ans;
	scanf("%d",&t);
	while(t--){
		ans=1;
		for(int i=0;i<52;i++)
			a[i]=0;
		scanf("%d",&n);
		getchar();
		b=getchar();
		if(b<'a')a[26+b-'A']++;
		else a[b-'a']++;
		for(int i=1;i<n;i++){
			scanf(" %c",&b);
			if(b<'a')a[27+b-'A']++;
			else a[b-'a']++;
		}
		for(int i=0;i<52;i++)
			ans+=a[i]/2;
		if(ans*2-1<n)printf("%d\n",ans*2-1);
		else printf("%d\n",n);
	}
	return 0;
}
