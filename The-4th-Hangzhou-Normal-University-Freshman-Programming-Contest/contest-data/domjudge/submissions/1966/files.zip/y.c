#include<stdio.h>
#include<string.h>
int main (){
	int n,i,t;
	int k;
	int max;
	char c;
	int a[1001];
	scanf("%d",&t);
	while(t--){
		k=0;
		for(i=0;i<201;i++){
			a[i]=0;
		}
		scanf("%d",&n);
		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&c);
			a[c]=a[c]+1;	
		}
		max=0;
		for(i=0;i<201;i++){
		if(a[i]%2==1&&a[i]>max){
			max=a[i];
		}
		}
		for(i=0;i<201;i++){
			if(a[i]%2==0){
				k=k+a[i];
			}
		}
		k=k+max;
		printf("%d\n",k);
	}
}