#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;
struct acm
{
	int w;
	string name;
}a[100005];
int cmp(struct acm a,struct acm b)
{
	return a.w>b.w;
}
int main()
{
	int n;
	cin>>n;
	int i;
	for(i=0;i<n;i++)
	{
		cin>>a[i].w>>a[i].name;

	}
	sort(a,a+i,cmp);
	int k;
	cin>>k;
	cout<<a[k].name;
}
