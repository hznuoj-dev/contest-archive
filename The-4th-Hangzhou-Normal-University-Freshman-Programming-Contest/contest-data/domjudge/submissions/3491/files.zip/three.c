# include<stdio.h>
int main(){
    int T,n,k,i,j;
    scanf("%d",&T);
    while(T--)
    {
    	k=0;
        scanf("%d",&n);
        int a[100000];
        for (j=1; j<=n; j++)
        {
            scanf("%d",&a[j-1]);
        }
        for (i=0; i<n; i++)
        {
            int sum=0;
            for (j=i; j<n; j++)
            {
                sum+=a[j];
                if (sum==7777)
                {
                    k++;
                    break;
                }
                else if(sum>7777)
                {
                    break;
                }
            }
        }
        printf("%d\n",k);
    }
    return 0;
}
