#include<bits/stdc++.h>

using namespace std;

int n,m;

int main()
{
	int atk,nowatk;
	scanf("%d%d",&n,&m);
	if(m == 0) atk = 2500;
	else atk = 2100;
	int flag = 0,pohuai = 0,youyi = 0;
	int size;
	for(int i=1;i<=n;++i){
		scanf("%d",&size);
		if(size == 2){
			if(n>1){
				flag = 1;
			}
		}if(size == 0){
			scanf("%d",&nowatk);
			if(nowatk >= atk){
				pohuai = 1;
			}
		}if(size == 1){
			youyi = 1;
		}
	}
	if(flag == 1 || (pohuai==1 && youyi == 1)){
		printf("haoye");
	}else{
		printf("QAQ");
	}
	return 0;
}
