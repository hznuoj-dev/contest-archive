#include<stdio.h>
#include<stdlib.h>
struct song {
	int a;
	char b[100];
};
int comp(const void* p, const void* q) {
	return ((struct song*)q)->a-((struct song *)p)->a;
}
int main() {
	int t;
	struct song x;
	int k;
	struct song g[100];
	scanf("%d", &t);
	for (int i = 0; i < t; i++) {
		scanf("%d%s", &g[i].a, g[i].b);
	}
	qsort(g, t, sizeof(struct song), comp);
	scanf("%d", &k);
	printf("%s", g[k].b);
	return 0;
}