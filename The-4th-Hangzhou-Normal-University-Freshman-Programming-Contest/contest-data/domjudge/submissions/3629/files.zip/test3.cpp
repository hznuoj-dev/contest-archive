#include<bits/stdc++.h>
#define res register int
#define ll long long
#define N 100050
using namespace std;
int n,m,p,q;
char c;
bool condi,allow1,allow2,allow3;
int main()
{
    scanf("%d%d",&n,&condi);
    for(res i=1;i<=n;i++)
    {
    	scanf("%d",&q);
    	if(q==0)
    	{
    		scanf("%d",&p);
    		if(((condi==0) and (p>=2500))or((condi==1) and (p>2100)))
    		allow1=true;
		}
		if(q==1) allow2=true;
		if(q==2) allow3=true;
	}
	if(allow1 and allow2)
	{
	  printf("haoye");
	  return 0;
    }
	if((allow3) and n>=2) 
	{ 
	   printf("haoye");
	   return 0;
    }
	printf("QAQ");
}
