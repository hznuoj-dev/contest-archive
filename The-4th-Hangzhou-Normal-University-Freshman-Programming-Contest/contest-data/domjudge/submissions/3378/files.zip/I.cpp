#include<stdio.h>
#include<stdlib.h>
struct song
{
	long long w;
	char name[20];
};
int comp(const void*p, const void*q) {
	return(*(int*)q - *(int*)p);
}
int main() {
	long n, k;
	struct song songarray[n - 1];
	scanf("%ld", &n);
	for (long i = 0; i < n; i++)
	{
		scanf("%lld%s", &songarray[i].w, songarray[i].name);
	}
	scanf("%ld", &k);
	qsort(songarray,n ,sizeof(struct song), comp);
	printf("%s\n", songarray[k].name);
	return 0;
}
