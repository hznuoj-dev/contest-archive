#include<stdio.h>
int main(){
	int T,n,sum=0,brr[10000];
	char arr[10000];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=0;i<n;i++ ){
			scanf(" %c",&arr[i]);
			brr[i]=0;
		}
		for(int i =0;i<n;i++){
			for(int I=i+1;I<n;I++){
				if(arr[i]==arr[I]&&brr[i]==0&&brr[I]==0){
					sum+=2;
					brr[i]=1;brr[I]=1;
				}
			}
		}
		for(int i =0;i<n;i++){
			if(brr[i]==0){
				sum+=1;break;
			}
		}
		printf("%d\n",sum);
		for(int i =0;i<n;i++){
			arr[i]='\0';
			brr[i]=0;
		}
		sum=0;
	}
} 
