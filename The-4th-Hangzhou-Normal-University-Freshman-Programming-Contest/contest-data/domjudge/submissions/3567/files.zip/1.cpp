#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		int a[100]={0};
		for(int i=0;i<n;i++)
		{
			char x;
			cin>>x;
			if(x>='a'&&x<='z')
			{
				if(a[x-'a'+1]==0)
					sum++;
				a[x-'a']++;
			}
			else if(x>='A'&&x<='Z')
			{
				if(a[x-'A'+26]==0)
				sum++;
				a[x-'A'+26]++;
			}		
		}
		int num=0;
		int b=0;
		for(int i=0;i<60;i++)
		{
			if(a[i]%2==0)
				num+=a[i];
			else if(a[i]==1&&b==0)
			{num+=1;b=1;}
			else if(a[i]%2==1)
				num+=a[i]-1;
		}
		cout<<num<<endl;
	}
	//system("pause");
}
