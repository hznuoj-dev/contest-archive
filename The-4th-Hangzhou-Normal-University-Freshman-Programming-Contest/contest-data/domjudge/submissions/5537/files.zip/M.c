#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>

int main()
{
	int i,j,t,m,n,l;
	char s[1005][35];
	char k[40000],h;
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		m=0,n=0;
		memset(s,'\0',sizeof(s));
		memset(k,'\0',sizeof(k));
		gets(k);
		for(i=0;i<strlen(k)-1;i++)
		{
			if(k[i]>='0'&&k[i]<='9'||k[i]>='a'&&k[i]<='z'||k[i]>='A'&&k[i]<='Z')
			{
				s[m][n]=k[i];
				n++;
			}
			else if(k[i]==' ')
			{
				m++;
				n=0;
			}	
		}
		printf("%s ",s[0]);
		printf("%s ",s[m]);
		printf("%s ",s[1]);
		printf("%s ",s[m-1]);
		for(l=2;l<m-1;l++)
		{
			if(l<m-2)
				printf("%s ",s[l]);
			else
				printf("%s",s[l]);
		}
		printf("%c",k[strlen(k)-1]);
		printf("\n");
	}
	return 0;
}
