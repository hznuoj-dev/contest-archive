#include<stdio.h>
#include<string.h>
char a[1011][32]={0};
main()
{
	int t,i,p,n,q;
	char k;
	scanf("%d",&t);
	while(t--)
	{
		i=1;
		if(t>0)
		{
		  while(1)
		  {
            scanf("%s",a[i]);
			scanf("%c",&k);
			if(k==' ')i++;
			else break;
		  }
		}
		else 
		{
			while(scanf("%s",a[i])!=EOF)
				i++;
		}
		n=i;
		p=strlen(a[i])-1;
		k=a[i][p];
		for(q=1;q<=n;q++)
		{
			if (q%2==1) printf("%s",a[(q+1)/2]);
			else printf("%s",a[n+1-q/2]);
			if (q<n) printf(" ");
			else printf("%c\n",k);
		}
	}
}