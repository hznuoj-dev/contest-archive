#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int main(){
	int n,t,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&x);
		if(x)printf("yes\n");
		else printf("no\n");
	}
}