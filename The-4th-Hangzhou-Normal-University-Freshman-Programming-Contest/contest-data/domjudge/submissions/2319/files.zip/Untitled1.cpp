#include<stdio.h>
int main()
{
	int n,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Welcome to HZNU\n"); 
	}
	return 0;
}
