#include <stdio.h>
#include <math.h>
#include <string.h>
int pi=10000;
int main(){ 
    int n,i,t,j,s=0;
    char a[pi];
    scanf("%d",&t);
    while(t--){
    	scanf("%d",&n);
    	for(i=1;i<=n;i++){
    		scanf("%s",&a[i]);
		}
		for(i=1;i<=n-1;i++){
			for(j=i+1;j<=n;j++){
				if(a[i]==a[j]){
					s=s+1;
				}
			}
		}
		if(s*2!=n&&s!=0){
			printf("%d\n",s*2+1);
		}else if(s*2==n){
			printf("%d\n",s*2);
		}else if(s==0){
			printf("1\n");
		}
		s=0;
	}
	return 0;
}


