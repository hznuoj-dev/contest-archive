#include<stdio.h>
char a[10000];
int b[10000];
int main()
{
	int m,t,n,i,k,j,sum;
	char s;
	scanf("%d",&t);
	for(m=0;m<t;m++)
	{
			getchar();
		scanf("%d",&n);
		k=0;
		sum=0;
		for(i=0;i<n;i++)
		{
			b[i]=0;
		}
		for(i=0;i<n;i++)
		{
			getchar();
			scanf("%c",&s);
			for(j=0;j<k+1;j++)
			{
					if(j==k)
				{
					a[j]=s;
					k=k+1;
					break;
				}
				if(a[j]==s)
				{
					b[j]=b[j]+1;
				}
			}
		}
		for(i=0;i<k;i++)
		{
			if((b[i]+1)%2==0)
			{
				sum=sum+b[i]+1;
			}
		}
		sum=sum+1;
		printf("%d\n",sum);
	}
	return 0;
}

