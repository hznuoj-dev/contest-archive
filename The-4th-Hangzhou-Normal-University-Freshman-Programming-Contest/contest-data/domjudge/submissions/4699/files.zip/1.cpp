#include<stdio.h>
#include<math.h>
int main()
{
		int T,n,x,c=0,i,m=1;
		long long int s;
		scanf("%d",&T);
		while(T--)
		{
		scanf("%d%d",&n,&x);
		if(x!=0)
		  printf("yes\n");
		else
		printf("no\n");
	}
}
