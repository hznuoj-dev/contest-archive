#include<stdio.h>
#pragma warning(disable:4996)
struct songs
{
	int likes;
	char name[16];
}s[100000];
int main()
{
	int n, i, j, k, t;
	struct songs* max;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &s[i].likes);
		scanf("%s", s[i].name);
	}
	scanf("%d", &k);
	t = 0;
	for (i = 0; i < n; i++)
	{
		max = &s[0];
		for (j = 0; j < n; j++)
		{
			if (max->likes < s[j].likes)
				max = &s[j];
		}
		t++;
		if (t == k + 1)
		{
			printf("%s", max->name);
			break;
		}
		else
			max->likes = -1;
	}
	return 0;
}