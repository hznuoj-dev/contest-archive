#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char in[1001][32];
int main(void)
{
	int T, group, i;
	char ch;

	scanf("%d", &T);
	while (T--) {
		group = 1;
		while (1) {
			scanf("%s", in[group]);
			ch = getchar();
			if (ch == '\n')
				break;
			group++;
		}
		ch = in[group][strlen(in[group]) - 1];
		in[group][strlen(in[group]) - 1] = 0;
		if (group % 2) {
			for (i = 1; i <= group / 2; i++) {
				printf("%s %s ", in[i], in[group+1-i]);
			}
			printf("%s%c",in[i],ch);
		}
		else {
			for (i = 1; i <= group / 2; i++) {
				printf("%s %s", in[i], in[group + 1 - i]);
				if (i != group / 2)
					putchar(' ');
				else
					putchar(ch);
			}
		}

		if (T)putchar('\n');
	}

	return 0;
}