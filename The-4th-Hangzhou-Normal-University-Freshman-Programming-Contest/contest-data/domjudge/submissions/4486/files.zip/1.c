#include<stdio.h>
#include<stdlib.h>
struct z
{
	int like;
	char name[20];
}music[100000];
int cmp(const void* a, const void* b)
{
	struct z *aa = (struct z*)a;
	struct z *bb = (struct z*)b;
	return bb->like - aa->like;
}
int main()
{
	int n, i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d%s", &music[i].like, music[i].name);
	}
	int k;
	scanf("%d", &k);
	qsort(music, n, sizeof(struct z), cmp);
	printf("%s\n", music[k].name);
	return 0;
}