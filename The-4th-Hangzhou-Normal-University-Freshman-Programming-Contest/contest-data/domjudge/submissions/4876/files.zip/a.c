#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int n,m,i,t,time,t1,timetotal,total;
	char ch[200];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		timetotal = 0;
		scanf("%d",&m);
		getchar();
		for(t=0;t<m;t++){
			if(t!=m-1)
			scanf("%c ",&ch[t]);
			else ch[t]=getchar();
		}
		for(t=0;t < m-1;t++){
			time = 1;
			for(t1=t+1;t1<m;t1++){
				if(ch[t] != 32 && ch[t] == ch[t1]){
					ch[t1]=' ';
					time++;
				}
			}
			timetotal+=(time/2);
		}
		if(timetotal*2<m){
			total=timetotal*2+1;
			printf("%d\n",total);
		}
		else {
			total=timetotal*2;
			printf("%d\n",total);
		}
	}
	return 0;
}
