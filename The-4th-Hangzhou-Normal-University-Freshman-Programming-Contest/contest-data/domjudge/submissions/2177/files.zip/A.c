#include<stdio.h>
int main(void){
	int T,num_ou,flag_jishu,i,n,m,N;
	char si;
	scanf("%d",&T);
	while(T--){
		N=0;flag_jishu=0;num_ou=0;
		int num[123]={0};
		scanf("%d",&n);getchar();
		while(n--){
			scanf("%c",&si);getchar();
			m=si;num[m]++;
		}
		for(m='A';m<='Z';m++){
			if((num[m]!=0&&num[m]%2==0)||(num[m]>=3)) num_ou+=num[m]/2;
			if(num[m]%2==1) flag_jishu=1; 
		}
		for(m='a';m<='z';m++){
			if((num[m]!=0&&num[m]%2==0)||(num[m]>=3)) num_ou+=num[m]/2;
			if(num[m]%2==1) flag_jishu=1; 
		}
		if(flag_jishu==0) printf("%d\n",num_ou*2);
		else if(flag_jishu==1) printf("%d\n",num_ou*2+1);
	}
	return 0;
}

