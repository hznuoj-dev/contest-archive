#include <bits/stdc++.h>
using namespace std;
int a[10][100010];
int main(){
	int i,t,n,j,s,k,l;
	cin>>t;
	for (i=0;i<t;++i){
		cin>>n;
		s=0;
		l=1;
		a[i][0]=0;
		for (j=0;j<n;++j){
			cin>>k;
			if (j>0)a[i][j+1]=a[i][j]+k;
			else a[i][j+1]=k;
		}
		k=0;
		while (k<=n && l <= n){
			if (a[i][l]-a[i][k] >= 7777){
				if (a[i][l]-a[i][k] == 7777) s++;
				k++;
			}else l++;
		}
		cout<<s<<'\n';
	}
	return 0;
} 
