#include<stdio.h>
int main()
{
	int a,b;
	char x[]="Welcome to HZNU";
	scanf("%d",&a);
	for(b=0;b<a;b++)
	{
		printf("%s\n",x);
	}
	return 0;
 } 
