#include<stdio.h>
main() {
	int t;
	while (t--) {
		int n, x;
		scanf("%d%d", &n, &x);
		if (x == 0)
			printf("no");
		else
			printf("yes");
	}
}