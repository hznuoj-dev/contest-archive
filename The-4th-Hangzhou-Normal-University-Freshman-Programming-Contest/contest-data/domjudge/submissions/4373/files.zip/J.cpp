#include<stdio.h>
int main()
{
	int n,status;
	int num,i,m,j,f=0;
	int atk[12]={0},chuwai=0,qipai=0;
	scanf("%d %d",&n,&status);
	i=1;
	m=n;
	if(status==0)
	{
		while(m--)
		{
		scanf("%d",&num);
		if(num==0)
		{
			scanf("%d",&atk[i]);
			i++;
		}
		if(num==1)
			chuwai++;
		if(num==2)
			qipai++;
		}
		for(j=1;j<=n;j++)
		{
			if((atk[j]>=2500&&chuwai>0)||(n>=2&&qipai>0))
			{
				printf("haoye\n");
				f=1;
				break;
			}
		}
		if(f==0)
			printf("QAQ\n");
	}
	else if(status==1)
	{
		while(m--)
		{
		scanf("%d",&num);
		if(num==0)
		{
			scanf("%d",&atk[i]);
			i++;
		}
		if(num==1)
			chuwai++;
		if(num==2)
			qipai++;
		}
		for(j=1;j<=n;j++)
		{
			if((atk[j]>2100&&chuwai>0)||(n>=2&&qipai>0))
			{
				printf("haoye\n");
				f=1;
				break;
			}
		}
		if(f==0)
			printf("QAQ\n");
	}
}