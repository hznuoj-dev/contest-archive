#include<stdio.h>
int main(){
	int T,n,len=1;
	char c[100000];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=0;i<n;i++)
		    c[i]=getchar();
		for(int i=0;i<n-1;i++){
			for(int j=i+1;j<n;j++){
				if(c[i]==c[j])
					len+=2;
			}
		}
		printf("%d",len);
		len=1;
		for(int i=0;i<n;i++)
			c[i]=' ';
	}
	return 0;
}