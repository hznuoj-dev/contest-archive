#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void)
{
	
	int t,a,b,max,flag; 
	scanf("%d",&t);
	while(t--)
	{
		max=0,flag=0;
		scanf("%d %d", &a, &b);
		max = a > b ? a : b;
		while (max % a != 0 || max % b != 0)
		{
			max++;
			if(max % a == 0 && max % b == 0)
			{
				flag=1;
			}
		}
		if(max)
		printf("yes\n");
		else
		printf("no\n");
	}
	return 0;
}
