#include<stdio.h>
#include<string.h>
long long shu,a[100001],huan,pan[100001],wei,max,yy;
char str[100001][16];
int main()
{
	int t,i,j,k;
	
	scanf("%d",&t);
	for(i=1;i<=t;i++)
	{
		scanf("%lld %s",&shu,str[i]);
		a[i]=shu;
		pan[i]=1;
	}
	scanf("%d",&k);
	yy=0;
	for(i=1;i<=t;i++)
	{
		max=0;
		for(j=1;j<=t;j++)
		{
			if(a[j]>max&&pan[j]==1)
			{
				max=a[j];
				wei=j;
			}
		}
		pan[wei]=0;
		yy=yy+1;
		if(yy==k+1)
		{
			printf("%s",str[wei]);
			return 0;
		}
	}
}
