#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int comp(const void *p,const void *q){
	return strcmp(p,q);
}
int main(){
	int t,i,j=0,n,sum=0;
	char b;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		scanf("%c",&b);
		int a[30]={0};
		char c[n];
		for(i=0;i<n;i++){
			scanf("%c",&c[i]);
			if(c[i]==' '){
				scanf("%c",&c[i]);
			}
		}
		scanf("%c",&b);
		
		qsort(c,n,sizeof(char),comp);
		for(i=0;i<n-1;i++){
			if(c[i]==c[i+1]){
				a[j]++;
				i++;
			}else{
				j++;
			}
		}
		
		for(i=0;i<=j;i++)sum+=a[i];
        if(2*sum!=n)printf("%d",sum*2+1);
        else printf("%d",n);
		sum=0;
		j=0;
		
		
		if(t){
			printf("\n");
		}
	}
	return 0;
}
