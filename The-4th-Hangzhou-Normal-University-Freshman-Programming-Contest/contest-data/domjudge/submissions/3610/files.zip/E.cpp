#include<stdio.h>
#include<math.h>
int main(){
	int n,m;
	scanf("%d%d",&n,&m);
	int a[n][m];
	for(int i=0;i<n;i++){
		for(int z=0;z<m;z++){
			scanf("%d",&a[i][z]);
		}
	}
	int d=100000;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			for(int x=0;x<n;x++){
				for(int y=0;y<m;y++){
					if(x!=i){
						if(abs(a[i][j]-a[x][y])<d){
							d=abs(a[i][j]-a[x][y]);
							o=a[i][j];
							p=a[x][y];
						}
					}
				}
			}
		}
	}
	printf("%d",d);
	return 0;
}
