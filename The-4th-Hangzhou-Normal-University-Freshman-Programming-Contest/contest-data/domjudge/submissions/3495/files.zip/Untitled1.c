#include <stdio.h>
#include <string.h>
int a[1000000];
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m,i,k,j=0;
		scanf("%d %d",&n,&m);
		while(j<n){
			k=(k+m)%n;
			a[k]=1;
			j++;
		}
		for(i=0;i<n;i++){
			if(a[k]==0){
				printf("no\n");
				break;
			}
			if(a[k]==1)
				continue;
		}
		if(i==n)
			printf("yes\n");
	}
}

