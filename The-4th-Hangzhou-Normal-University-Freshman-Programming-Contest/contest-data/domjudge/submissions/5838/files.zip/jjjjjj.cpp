#include<stdio.h>
int main(){
	int n,m,i,j;
	int flag1=0,flag2=0,flag3=0;
	scanf("%d %d",&n,&m);
	if(m==0) 
	j=2500;
	else 
	j=2100;
	int s[n],t[n];
	for(i=0;i<n;i++){
		scanf("%d",&s[i]);
		if(s[i]==0){
			scanf("%d",&t[i]);
			if(m==0&&t[i]>=2500||m==1&&t[i]>2100)
			 flag1=1;
		}
		else if(s[i]==1){
			if(flag1) 
			flag2=1;
			else flag3=1;
		}
		else if(flag3&&flag1) 
		flag2=1;
	}
	if(n==0||n==1) 
	printf("QAQ\n");
	else if(n>1){
		for(i=0;i<n;i++){
			if(s[i]==2||flag2){
				printf("haoye\n");
				break;
			}
		}
		if(i==n) printf("QAQ\n");
	}
	
}

