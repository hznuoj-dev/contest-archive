#include <stdio.h>
int main(){
   int t;
   scanf("%d",&t);
   long long int n,x;
   while(t--){
   scanf("%lld%lld",&n,&x);
   if(x==0)
   printf("no\n");
   else
   printf("yes\n");
   }







	return 0;	 
}
