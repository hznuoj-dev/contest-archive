#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
struct stu{
		int x;
		char name[211];
	}s[100003];
int main(void){
	int n,i,j,y;
	
	int com(const void*a,const void*b){
		return ((struct stu*)b)->x-((struct stu*)a)->x;
	}
	scanf("%d",&n);
	for(i=0;i<n;++i){
		scanf("%d %s",&s[i].x,s[i].name);
	}
	qsort(s,n,sizeof(struct stu),com);
	scanf("%d",&y);
	printf("%s",s[y].name);
	
	
	
	
	
	
	
	
	
	return 0;
} 
