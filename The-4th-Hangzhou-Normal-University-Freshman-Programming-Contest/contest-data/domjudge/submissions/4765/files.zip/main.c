#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
struct song{
    long long int w[20];
    char name[20];
};
int main(){
    int t,ccc;
    struct song qaq[100009];
    scanf("%d",&t);
    for(int i=0;i<t;i++){
        scanf("%lld %s",qaq[i].w,qaq[i].name);
    }
    scanf("%d",&ccc);
    
    qsort(&qaq[0].w,t,sizeof(struct song),comp);
    
    printf("%s\n",qaq[ccc].name);
    
    return 0;
}
int comp(const void *p,const void *q){
    return (*(int *)q-*(int *)p);
}

