#include<stdio.h>
struct song
{
	long long int num;
	char name[16];
};
int main(void)
{
	struct song a[100000],m;
	long long int n,i,j,k,min,s;
	scanf("%lld",&n);
	getchar();
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&a[i].num,a[i].name);
	}
	getchar();
	scanf("%lld",&k);
	for(i=0;i<n;i++)
	{
		min=a[i].num;
		s=i;
		for(j=i;j<n;j++)
		{
			if(a[j].num<min)
			{
				min=a[j].num;
				s=j;
			}
		}
		if(s!=i)
		{
			m=a[i];
			a[i]=a[s];
			a[s]=m;
		}
		if(i==k)
			break;
	}
	printf("%s",a[k].name);
	return 0;
}
