#include<stdio.h>
struct zu{
	long long w;
	char s[20];
}song[100001],ti;
int main(void){
	long long n,k,i,x,y,p;
	scanf("%lld",&n);
	for(i=1;i<=n;i++){
		scanf("%lld%s",&song[i].w,song[i].s);
	}
	scanf("%lld",&k);
	for(x=1;x<=n-1;x++){
		p=x;
		for(y=x+1;y<=n;y++){
			if(song[p].w<song[y].w){
			p=y;}
		}
		if(p!=x){
		
		ti=song[x];
		song[x]=song[x+1];
		song[x+1]=ti;}
	}
	
	printf("%s",song[k+1].s);
	 
	return 0;
}
