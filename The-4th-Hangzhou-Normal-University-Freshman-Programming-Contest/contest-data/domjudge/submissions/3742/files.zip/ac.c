#include<stdio.h>
struct every
{
	int zui;
	char a[20];
}ge[100000], term;
int main()
{
	int n, i, j;
	int k;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d %s", &ge[i].zui, ge[i].a);
	}
	scanf("%d",&k);
	for (i = 0; i < n-1; i++)
	{
		for (j = i + 1; j < n; j++)
		{
			if (ge[i].zui < ge[j].zui)
			{
				term = ge[i];
				ge[i] = ge[j];
				ge[j] = term;
			}
		}
	}
	printf("%s\n", ge[k].a);
	return 0;
}
