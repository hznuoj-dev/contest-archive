#include<bits/stdc++.h>
using namespace std;
int main()
{ int i,j,k,l,n,m;
  cin>>n;
  for (i=1;i<=n;i++)
   { cin>>k>>m;
     if (m==0) { cout<<"no"<<"\n"; continue;}
     cout<<"yes"<<"\n";
   }
}
