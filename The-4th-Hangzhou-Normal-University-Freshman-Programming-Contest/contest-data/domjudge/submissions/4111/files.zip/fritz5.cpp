#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<cmath>
#include<cctype>
using namespace std;
int main(){
int t;
cin>>t;
while(t--){
	int n,i;
	cin>>n;
	long int color;
	vector<long long int>s1,s2;
	map<int,long int>s3,s4;
	for(i=1;i<=n*n;i++){
	cin>>color;
	s1.push_back(color);
	s3.insert(make_pair(i,color));
	}
	for(i=1;i<=n*n;i++){
	cin>>color;
	s2.push_back(color);
	s4.insert(make_pair(i,color));
	}
	int one=0,two=0,three=0,four=0;
	vector<long long int>hz1;
	map<int,long int>::iterator pos;
	for(i=n;i>0;i--){
	for(pos=s3.begin();pos!=s3.end();pos++){
		if(((pos->first)-i)%n==0)hz1.push_back(pos->second);
	}
}

if(s1==s2)cout<<"0"<<endl;
else{


	if(hz1==s2)(one=1);
	reverse(s1.begin(),s1.end());
	if(s1==s2)two=1;
reverse(hz1.begin(),hz1.end());
if(hz1==s2)three=1;
if(one==1){
	cout<<"1"<<endl;
}
else if(two==1){
	cout<<"2"<<endl;
}
	else if(three==1){
		cout<<"1"<<endl;
	}
	else{
		cout<<"-1"<<endl;
	}
}
}
}
