#include<bits/stdc++.h>
using namespace std;
struct xx{
	int xiai;
	string name;	
}song;
bool operator <(const xx a,const xx b){
	return a.xiai < b.xiai ;
}
int main(){
	priority_queue <xx> p;
	int n;
	scanf("%d",&n);
	while(n--){
		cin>>song.xiai>>song.name;
		p.push(song);
	}
	int x;
	scanf("%d",&x);
	while(x--){
		p.pop();
	}
	song=p.top();
	cout<<song.name; 
}
