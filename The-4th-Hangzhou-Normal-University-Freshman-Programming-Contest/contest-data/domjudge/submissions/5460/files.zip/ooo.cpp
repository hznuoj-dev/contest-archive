#include<stdio.h>
struct song {
	int a;
	char b[100];
};
struct song g[100000];
struct song x;
int main() {
	int t;
	int k;
	scanf("%d", &t);
	for (int i = 0; i < t; i++) {
		scanf("%d%s", &g[i].a, g[i].b);
	}
	for (int i = 1; i < t; i++) {
		for (int j = 0; j < t; j++) {
			if (g[j].a < g[j + 1].a) {
				x = g[j];
				g[j] = g[j + 1];
				g[j + 1] = x;
			}
		}
	}
	scanf("%d", &k);
	printf("%s", g[k].b);
	return 0;
}