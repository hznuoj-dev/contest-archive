#include<stdio.h>
int main() {
	int t;
	long long n,x;
	scanf("%d",&t);
	while(t>0){
		scanf("%lld%lld",&n,&x);
		if(x==0)
		printf("no");
		if(x!=0)
		printf("yes");
		t--;
	} 
	return 0;
}
