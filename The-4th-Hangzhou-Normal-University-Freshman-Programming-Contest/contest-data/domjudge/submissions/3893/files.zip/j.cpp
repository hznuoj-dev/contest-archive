#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,m,tmp,rr;
	int k,atk=0,def=0,zhi=0,hei=0;
	cin>>n>>m;
	tmp=n;
	while(tmp--)
	{
		cin>>k;
		if(k==1)
		{
			zhi=1;
		}
		else if(k==2)
		{
			hei=1;
		}
		else if(k==0)
		{
			cin>>rr;
			if(m==0)
			{
				if(rr>atk)
				{
					atk=rr;
				}
			}
			else
			{
				if(rr>def)
				{
					def=rr;
				}
			}
		}
	}
	if(hei==1&&n>=2)
	{
		cout<<"haoye";
		return 0;
	}
	else if(m==0&&atk>=2500&&zhi==1)
	{
		cout<<"haoye";
		return 0;
	}
	else if(m==1&&def>2100&&zhi==1)
	{
		cout<<"haoye";
		return 0;
	}
	cout<<"QAQ";
	
}
