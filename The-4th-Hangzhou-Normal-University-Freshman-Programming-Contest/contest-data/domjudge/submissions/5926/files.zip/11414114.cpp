#include <stdio.h>
#include <stdlib.h>

int cmp(const void *p,const void *q)
{
	int *pp = (int*)p;
	int *pq = (int*)q;
	return *pq-*pp;
}

int main()
{
	long long m,n;
	int i;
	scanf("%lld %lld",&m,&n);
	int a[m*n];
	for(i=0;i<m*n;i++)
	{
		scanf("%d",&a[i]);
	}
	qsort(a,m*n,sizeof(int),cmp);
	/*for(i=0;i<m*n;i++)
	{
		printf("%d ",a[i]);
	}*/
	int min = a[0] - a[1];
	for(i=0;i<m*n-1;++i)
	{
		if(a[i]-a[i+1] < min)
			min = a[i] - a[i+1];
	}
	printf("%d\n",min);
	
		
	
	
	
	return 0;
}
