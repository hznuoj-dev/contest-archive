#include<stdio.h>
int main()
{
	int n, m, b, i, as = 0;
	scanf("%d", &n);
	while (n--)
	{
		as = 0;
		scanf("%d %d", &m, &b);
		if (n > 0)
		{
			if (b == 0)
				printf("no\n");
			else
			{
				if (m % b == 0)
					printf("yes\n");
				else
				{
					for (i = 2; i <= 10; i++)
					{
						if (m * i % b == 0)
						{
							printf("yes\n");
							as = 1;
							break;
						}
					}
					if (as == 0)
						printf("no\n");
				}
			}
		}
		else {
			if (b == 0)
				printf("no");
			else
			{
				if (m % b == 0)
					printf("yes");
				else
				{
					for (i = 2; i <= 10; i++)
					{
						if (m * i % b == 0)
						{
							printf("yes");
							as = 1;
							break;
						}
					}
					if (as == 0)
						printf("no");
				}
			}

		}
	}

	return 0;
}