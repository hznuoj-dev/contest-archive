#include<stdio.h>
int main(){
	int t,n,i,j,flag,sum;
	scanf("%d",&t);
	while(t--){
		flag=0;
		scanf("%d",&n);
	int a[n+1];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i]);
	}
	for(i=0;i<n;i++)
	{	
		sum=0;
		for(j=0;j<n-i;j++)
		{
			sum=sum+a[i+j];
			if(sum==7777)
			{
			flag++;
			break;
			}
		}
		
	}
	printf("%d\n",flag);
	}
	
	return 0;
}
