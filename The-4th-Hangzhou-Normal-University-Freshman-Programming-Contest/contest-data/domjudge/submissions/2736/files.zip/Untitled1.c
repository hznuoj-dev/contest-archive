#include <stdio.h>
#include <stdlib.h>
struct music{
	int love;
	char name[25];
};
int comp(const void *p,const void *q){
	return ((struct music *)q)->love-((struct music *)p)->love;
}
int main() {
    struct music song[10010];
    int n,i,k,j;
    scanf("%d",&n);
    for(i=0;i<n;i++){
    	scanf("%d %s",&song[i].love,song[i].name);
	}
	scanf("%d",&k);
	qsort(song,n,sizeof(struct music),comp);
	printf("%s\n",song[k].name);
	return 0; 
}
