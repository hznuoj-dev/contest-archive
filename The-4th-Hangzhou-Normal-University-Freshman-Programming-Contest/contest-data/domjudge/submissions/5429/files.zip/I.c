#include<stdio.h>
#include<stdlib.h>
struct a{
	long long int love;
	char name[16];
};
int comp(const void *p,const void *q){
	return((struct a*)p)->love-((struct a*)q)->love;
}
int main(){
	int n,min,k; 
	struct a b[100000];
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%lld %s",&b[i].love,b[i].name);
    }
    scanf("%d",&k);
    qsort(b,n,sizeof(struct a),comp);
    printf("%s\n",b[n-k-1].name);
}
