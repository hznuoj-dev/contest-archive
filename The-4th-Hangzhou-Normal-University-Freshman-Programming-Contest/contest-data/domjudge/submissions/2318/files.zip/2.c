#include <stdio.h>
struct point {
	int m;
	char s[20];
}a[100000];
int cmp(const *p,const *q);
int main(void){
	struct point 	sw;
	int i,n,k,j;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i].m,a[i].s);
	}
	qsort(a,n,sizeof(struct point),cmp);
	scanf("%d",&k);
	printf("%s",a[k].s);
	return 0;
} 
int cmp(const *p,const *q){
	return ((*(struct point*)q).m-(*(struct point *)p).m);
}
