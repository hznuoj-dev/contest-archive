#include<stdio.h>
struct song{
	int w;
	char s[20];
};
int main(void)
{
	int n,k;
	scanf("%d",&n);
	struct song sing[n],temp;
	int i,j;
	for(i=0;i<n;++i)
	{
		scanf("%d %s",&sing[i].w,sing[i].s);
	}
	scanf("%d",&k);
	for(i=1;i<=n;++i)
	{
		for(j=0;j<n-i;++j)
		{
			if(sing[j].w<sing[j+1].w)
			{
				temp=sing[j];
				sing[j]=sing[j+1];
				sing[j+1]=temp;
			}
		}
	}
	printf("%s",sing[k].s);
	return 0;
}

