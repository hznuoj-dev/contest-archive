#include <stdio.h>
int main(){
	int n,t,x;
	scanf("%d",&n);
	while(n--){
		scanf("%d %d",&t,&x);
		if(x!=0){
			printf("yes\n");
		}
		else{
			printf("no\n");
		}
	}
} 
