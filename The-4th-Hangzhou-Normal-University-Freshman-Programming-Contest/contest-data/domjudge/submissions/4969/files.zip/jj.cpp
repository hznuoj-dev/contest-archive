#include <stdio.h>

int main() {
	int n, m;
	int a[100][1], i, k;
	int flag = 0, sum = 0;
	scanf("%d%d", &n, &m);
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i][1]);
		if (a[i][1] == 0) {
			scanf("%d", &k);
		}
		if (m == 0) {
			if (k >= 2500 && a[i][1] == 1) {
				flag = 1;
			}

		}
		if (m == 1) {
			if (k >= 1200 && a[i][1] == 1) {
				flag = 1;
			}

		}
		if (n > 1 && a[i][1] == 2) {
			flag = 1;
		}
		if (a[i][1] == 1) {
			sum++;
			if (sum >= n)
				flag = 0;
		}
	}
	if (flag == 1) {
		printf("haoye");
	} else {
		printf("QAQ");
	}


}


