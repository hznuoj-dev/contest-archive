#include<stdio.h>
#include<stdlib.h>
struct song{
	char name[21];
	long long int num;
}p[100000];
int comp(const void *p,const void *q){
	struct song *min=(struct song *)(p);
	struct song *max=(struct song *)(q);
	int a;
	int b;
	int c;
	c=b-a;
	c=(max->num)-(min->num);
	return b-a;
}
int main(){
	int n,i;
	int T;
	scanf("%d",&n); 
	for(i=0;i<n;++i){
		scanf("%lld%s",&p[i].num,p[i].name);
	}
	qsort(p,n,sizeof(struct song),comp);
	scanf("%d",&T);
	printf ("%s\n",p[T].name);
	return 0;
}
