#include<stdio.h>

long long ans[100050];
int main(){
	long long n,k,i,count,answer,sum,*p;

	scanf("%lld",&n);
	while(n--){
		scanf("%lld",&k);
		count=k;
		answer=0;
		i=1;
		p=&ans[1];
		while(k--){
		scanf("%lld",p);
			p++;
		
		}
		for(i=1;i<=count;i++){//�߶������ۼ� 
			sum=0;
			p=&ans[i];
			while(sum<7777){
				sum+=*p; //
				if(p==&ans[count])break;
				p++;
				
			}
			if(sum==7777)answer++;
		}
		printf("%lld\n",answer);
	}

}
