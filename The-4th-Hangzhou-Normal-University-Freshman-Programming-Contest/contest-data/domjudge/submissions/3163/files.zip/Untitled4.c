#include<stdio.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int t,n,i;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		getchar();
		int a[122],sum = 0;
		for(i = 65;i <= 122 ;i++) a[i] = 0;		
		char alpha,space;
		for(i = 0; i < n; ++i)
		{
			if(i!=n-1) scanf("%c%c",&alpha,&space);
			else scanf("%c",&alpha);
			int pos = alpha;
			a[pos]++;
		}
		int max = 0;
		for(i = 65;i <= 122 ;i++)
		{
			if( (a[i]%2==0)) 
				sum += a[i];	
			else if(a[i]%2)
			{
				if(a[i]>max) max = a[i];
			}			
		}
		printf("%d\n",sum+max);
	}
}
