#include <stdio.h>
struct stu{
	int num;
	char name[16];
};
struct stu s[100001];
int cmp(void *p, void *q)
{
	return ((struct stu *)q)->num - ((struct stu *)p)->num;
}
int main(void)
{
	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%d%s",&s[i].num,s[i].name);
	}
	scanf("%d",&k);
	qsort(s,n,sizeof(struct stu),cmp);
	printf("%s\n",s[k].name);
}
