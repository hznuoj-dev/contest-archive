#include<bits/stdc++.h>
using namespace std;
struct song {
	long long w;
	string s;
} a[100001];

bool cmp(song first, song second) {
	if(first.w > second.w) return 1;
	else return 0;
}

int main () {
	int n,w,k;

	cin>>n;

	for(int i = 1; i <= n; i++) {
		cin>>a[i].w>>a[i].s;
	}
	sort(a+1,a+n+1,cmp);
	cin>>k;
	cout<<a[k+1].s;
	return 0;
}
