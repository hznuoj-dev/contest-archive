#include<stdio.h>
#include<string.h>
void sort(char* a[]);
void print(char* a[]);
int main(){
	int t,long;
	char a[] = { 0 };
	scanf("%d", &t);
	while(t--){
		i = 1;
		while (scanf("%s", a[i]) != EOF) {
			i++;
		}
		long = i-1;
		sort(a);
		print(a);
		printf("%c\n", a[long + 1]);

	
	
	}
}
void sort(char* a[])
{
	int i, j;
	char* temp;
	for (i = 1; i < long-1; i++)
	{
		for (j = 1; j < long-1; j++)
		{
			if (strcmp(a[j], a[j + 1]) > 0)//�ַ����Ƚ�:>0��ʾǰ����ַ����Ⱥ���Ĵ��򽻻�
			{
				temp = a[j];
				a[j] = a[j + 1];
				a[j + 1] = temp;
			}
		}
	}
}
void print(char* a[])
{
	int i;
	for (i = 1; i < long-1; i++)
	{
		printf("%s ", a[i]);
	}
}

