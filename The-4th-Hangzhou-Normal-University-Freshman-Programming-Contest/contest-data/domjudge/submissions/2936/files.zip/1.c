#include <stdio.h>
#include <string.h>
int main(void)
{
	int T;
	scanf("%d",&T);
	char a[100000];
	int b[100000];
	while(T--)
	{
		int n;
		scanf("%d",&n);
		getchar();
		int i;
		for(i=0;i<n;i++)
		{
			scanf("%c",&a[i]);
			b[i]=1;
			getchar();
		}
		int j;
		int count=0;
		for(i=0;i<n;i++)
		{
			if(b[i]==0) continue;
			for(j=i+1;j<n;j++)
			{
				if((a[i]==a[j])&&b[j]==1)
				{
					count+=2;
					b[j]=0;
					b[i]=0;
					break;
				}
			}
		}
		if(n>count) printf("%d\n",count+1);
		else printf("%d\n",count);
	}
	return 0;
} 
