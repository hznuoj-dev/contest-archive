#include<stdio.h>
#include<stdbool.h>
int main(void)
{
	int n, m, x, k, i;
	int A = 2500;
	int D = 2100;
	bool a[10];
	scanf("%d%d", &n, &m);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &x);
		if (x == 1 )
		{
			a[1] = true;
		}
		else if (x == 2)
		{
			a[2] = true;
		}
		else
		{
			scanf("%d", &k);
			if ((k >= A)||(k>=D))
			{
				a[0] = true;
			}
		}
	}
	if (a[0] && a[1])
		printf("haoye");
	else if (n > 1 && a[2])
		printf("haoye");
	else
		printf("QAQ");
	return 0;
}