#include<iostream>
#include<string>
using namespace std;
int main()
{
	int T;
	cin>>T;
	getchar();
	while(T--)
	{
		string str;
		int cnt=0;
		int n;
		cin>>n;
		getchar();
		for(int i=0;i<n;i++)
		{
			char ch;
			char blank;
			cin>>ch;
			if(str.find(ch)==-1)
			{
				str+=ch;
			}
			else
			{
				str.erase(str.find(ch)+1);
				cnt++;
				cnt++;
			}
		}
		if(str.empty()!=1)
		{
			cnt++;
		}
		cout<<cnt<<endl;
	}
		
	return 0;
}
