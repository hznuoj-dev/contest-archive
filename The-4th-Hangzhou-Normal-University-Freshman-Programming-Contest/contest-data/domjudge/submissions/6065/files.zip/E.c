#include<stdio.h>
#include<math.h>
int a[11][100010];
int main(void)
{
	int n,m,i,j,t,y;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;++i)
	{
		for(j=0;j<m;++j)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;++i)
	{
		for(j=0;j<m-1;++j)
		{
			y=abs(a[i][j]-a[i][j+1]);
		}
	}
	return 0;
}
