#include<stdio.h>
#define array 100001
int cd[1000000001];
struct song
{
	int cd[1000000001];
	char name[16];
};
int main()
{
	struct song z[array];
	int n, k;
	scanf("%d", &n);
	for (int i = 0;i < n;i++)
	{
		scanf("%d%s", &z[i].cd, z[i].name);
	}
	int i = 0, j = 0;
	struct song p;
	for (i = 0;i < n - 1;i++)
	{
		for (j = 0;j < n - i - 1;j++)
		{
			if (z[j].cd < z[j + 1].cd)
			{
				p = z[j];
				z[j] = z[j + 1];
				z[j + 1] = p;
			}
		}
	}
	scanf("%d", &k);
	printf("%s", z[k].name);
	return 0;
}
