#include <stdio.h>
#include <math.h>
int main(void) {
	int n,i,x,j,m,a[100][100],min,num,k;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	min=a[0][0]-a[1][0];
	min=abs(min);
	for(i=1;i<n;i++){
		for(j=0;j<m;j++){
			for(k=0;k<m;k++){
				num=a[i][j]-a[i-1][k];
				num=abs(num);
				if(num<min){
					min=num;
				}
			}
		}
	}
	printf("%d",min);
	return 0;
}

