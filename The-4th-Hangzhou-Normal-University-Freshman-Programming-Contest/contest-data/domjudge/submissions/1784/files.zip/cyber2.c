#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
int n,i,t,j,ret,sum,max;
char a[10005];
scanf("%d",&t);
while(t--)
{sum=0;
ret=1;
max=0;
scanf("%d",&n);
getchar();
	for(i=0;i<n;i++)
	{
	if(i==0)
	scanf("%c",&a[i]);
	else
	scanf(" %c",&a[i]);
	}
	for(i=0;i<n;i++)
	{ret=1;
		for(j=0;j<n;j++)
		{
			if(a[i]==a[j]&&a[i]!='9'&&a[j]!='9'&&j!=i)
			{
				ret++;
				a[j]='9';
				}
		}
			a[i]='9';
			if(ret%2==0)
			sum+=ret;
			else{
				if(max<ret)
			max=ret;}
	}
	printf("%d\n",sum+max);
 } 
return 0;
} 
