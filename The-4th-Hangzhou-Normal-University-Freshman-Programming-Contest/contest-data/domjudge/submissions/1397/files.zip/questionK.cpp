#include<iostream>
#include<algorithm>
using namespace std;
int main(void){
	int n;
	cin>>n;
	while(n--){
		cout<<"Welcome to HZNU"<<endl;
	}
} 
