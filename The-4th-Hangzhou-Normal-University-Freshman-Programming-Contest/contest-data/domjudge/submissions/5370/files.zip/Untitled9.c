#include<stdio.h>
#include<string.h>
#include<math.h>
struct zu{
	char word[256];
}a[256];
int main(void){
	int t,d=1,g,i,x,len,y;
	scanf("%d",&t);
	for(x=1;x<=t;x++){
	d=1;
	while(~scanf("%s",a[d].word)){
	d=d+1;
	}
	d=d-1;
	g=d;
	len=strlen(a[d].word);
	printf("%s ",a[1].word);
	for(y=0;y<len-1;y++)
	printf("%c",a[d].word[y]);
	printf(" ");
	for(i=2;i<=d/2-1;i++){
		printf("%s ",a[i].word);
		printf("%s ",a[d-i+1].word);
	}
	printf("%s ",a[d/2].word);
    
	if(d%2==1){
	printf("%s ",a[d-d/2+1].word);
	printf("%s",a[d/2+1].word);	}
	else
	printf("%s",a[d-d/2+1].word);
	
	printf("%c\n",a[g].word[len-1]);
	
	
	}
	
	return 0;
}
