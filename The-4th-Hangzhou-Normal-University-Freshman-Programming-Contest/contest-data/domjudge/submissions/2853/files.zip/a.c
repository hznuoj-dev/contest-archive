
#include<stdio.h>
#include<math.h>
long num[1000010] = { 0 }, ans[1000010] = { 0 };
int main()
{
	int n;
	long m, i = 0, min = 0, minn = 0,j = 0;
	scanf("%d %ld", &n,&m);
	while (n--)
	{
			while (scanf("%d",&num[i]) != EOF)
			{
				if (i == m - 1)
				{
					break;
				}
				i += 1;
			}
			for (i = 0; i < m-1; i++)
			{
				ans[i] = abs(num[i] - num[i + 1]);
				if (i == 0)
					min = ans[i];
				if (ans[i] < min)
				{
					min = ans[i];
		        }
			}
			if(j==0)
			minn = min;
			if (min < minn)
				minn = min;
			j = 1;
			i = 0;
	}
	printf("%ld", minn);
}