#include <stdio.h>
struct s{
	long long int xa;
	char s[20];
};
int main(){
	int n;
	scanf("%d",&n);
	struct s song[n];
	int i,j;
	for(i=0;i<n;i++){
		scanf("%lld %s",&song[i].xa,song[i].s);
	}
	struct s temp;
	int x,dianguo;
	scanf("%d",&dianguo);
	for(i=0;i<n;i++){
		x = i;
		for(j=i+1;j<n;j++){
			if(song[x].xa<song[j].xa){
				x = j;
			}
		}
		temp = song[i];
		song[i] = song[x];
		song[x]=temp;
	}
	printf("%s\n",song[dianguo].s);
}
