#include<stdio.h> 
int main(void){
	int n,i,sum,t,mark[130],k;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		char str[n];
		sum=0;
		for(i=0;i<130;i++){
			mark[i]=0;
		}
		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&str[i]);
			k=str[i];
			mark[k]++;
		}
		for(i=0;i<130;i++){
			sum+=mark[i]/2;
		}
		if(sum*2==n){
			printf("%d\n",sum*2);
		}
		else{
			printf("%d\n",sum*2+1);
		}		
	} 
	return 0;
}
