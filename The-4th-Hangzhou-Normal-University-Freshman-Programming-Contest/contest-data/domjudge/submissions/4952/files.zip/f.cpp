#include<iostream>
using namespace std;
int arr1[30][30];
int arr2[30][30];

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				cin>>arr1[i][j];
			}
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				cin>>arr2[i][j];
			}
		}
		int flag=0;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(arr1[i][j]!=arr2[i][j])
				{
					flag=1;
					break;
				}
			}
			if(flag)	break;
		}
		if(flag==0)
		{
			cout<<"0";
			if(t)	cout<<endl;
			continue;
		}
		flag=0;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(arr2[i][j]!=arr1[j][n-1-i])
				{
					flag=1;
					break;
				}
			}
			if(flag)	break;
		}
		if(flag==0)
		{
			cout<<"1";
			if(t)	cout<<endl;
			continue;
		}
		flag=0;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(arr2[i][j]!=arr1[n-1-j][i])
				{
					flag=1;
					break;
				}
			}
			if(flag)	break;
		}
		if(flag==0)
		{
			cout<<"1";
			if(t)	cout<<endl;
			continue;
		}
		flag=0;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				if(arr2[i][j]!=arr1[n-1-i][n-1-i])
				{
					flag=1;
					break;
				}
			}
			if(flag)	break;
		}
		if(flag==0)
		{
			cout<<"2";
			if(t)	cout<<endl;
			continue;
		}
		cout<<"-1";
		if(t)	cout<<endl;
		
		
		
		
	}

		
	return 0;
}
