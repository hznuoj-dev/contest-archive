#include<stdio.h>

int main(){
	int n,m,i;
	scanf("%d%d",&n,&m);
	int a[n],atk[10]={0};
	int max,flag=0;
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0)scanf("%d",&atk[i]);
	}
	max=atk[0];
	for(i=1;i<10;i++){
		if(atk[i]>max)max=atk[i];
	}
	if(n>=2){
		for(i=0;i<n;i++){
			if(a[i]==2){
				flag=1;
				break;
			}
		}
	}
	if(m==0){
		if(max>=2500){
			for(i=0;i<n;i++){
				if(a[i]==1){
					flag=1;
					break;
				}
			}
		}
	}else{
		if(max>2100){
			for(i=0;i<n;i++){
				if(a[i]==1){
					flag=1;
					break;
				}
			}
		}
	}
	if(flag)printf("haoye");
	else printf("QAQ");
	return 0;
}
