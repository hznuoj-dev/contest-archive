#include <bits/stdc++.h>
using namespace std; 
int a[100005];
int main()
{
	int T,i,j,n;
	scanf("%d",&T);
	while (T--)	
	{
		scanf("%d",&n);
		for (i=1; i<=n; i++)
		{
			scanf("%d",&a[i]);
		}
		i=1; j=1;
		int s=0;
		int sum=a[1];
		while (j<=n)
		{
			if (sum==7777)
			{
				s++;
				sum=sum-a[i];
				i++;
			} 
			else 
			if (sum<7777)
			{
				if (j==n) break;
				j++; 
				sum=sum+a[j];
			}
			else
			if (sum>7777)
			{
				sum=sum-a[i];
				i++;
			}
		}
		printf("%d\n",s);
	}
}
