#include<stdio.h>
#include<string.h>
int main(void){
	int t,i,n=0;
	scanf("%d\n",&t);
	while(t--){
		char word[1005][40];
		for(i=0;i<n;i++){
			word[i][0]='\0'; 
		}
		for(i=0;;i++){
			scanf("%s",word[i]);
			if(word[i][strlen(word[i])-1]=='.'||word[i][strlen(word[i])-1]=='!'||word[i][strlen(word[i])-1]=='?'){
				word[i+1][0]=word[i][strlen(word[i])-1];
				word[i][strlen(word[i])-1]='\0';				
				n=i+1;
				break;
			}
		}		
		if(n%2==0){
			for(i=0;i<n/2-1;i++){
				printf("%s ",word[i]);
				printf("%s ",word[n-1-i]);
			}
			printf("%s %s%c\n",word[n/2-1],word[n/2],word[n][0]);
		}
		else if(n%2==1){
			for(i=0;i<n/2;i++){
				printf("%s ",word[i]);
				printf("%s ",word[n-1-i]);
			}
			printf("%s%c\n",word[n/2],word[n][0]);
		}
	}
	return 0;	
}
