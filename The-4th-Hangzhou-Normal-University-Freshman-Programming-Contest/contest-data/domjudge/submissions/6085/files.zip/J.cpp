#include<stdio.h>
int main()
{
	int n, m, x[11], k[11], f = 0, g = 0, h = 0;
	scanf_s("%d %d", &n, &m);
	while (n--)
	{
		int i = 0;
		scanf_s("%d", &x[i]);
		if (x[i] == 0)
		{
			scanf_s("%d", &k[i]);
		}
		i++;
	}
	for (int i = 0;i < n;i++)
	{
		if (x[i] == 2)
		{
			f += 1;
		}
		else if (x[i] == 0)
		{
			if (m == 0 && k[i] >= 2500)
			{
				g += 1;
			}
			else if (m == 1 && k[i] >= 2100)
			{
				g += 1;
			}
		}
		else if (x[i] == 1)
		{
			h += 1;
		}
	}
	if ((f > 0 && n >= 2) || (g > 0 && h > 0))
	{
		printf("haoye");
	}
	else
	{
		printf("QAQ");
	}
	return 0;
}

