#include<stdio.h>
struct song{
	long long int cd;
	char gm[16];
};
int main()
{
	long long int T,i;
	scanf("%lld",&T);
	struct song song[T];
	for(i=0;i<T;i++)
	{
		scanf("%lld",&song[i].cd);
		char a;
		scanf("%c",&a);
		gets(song[i].gm);
	}
	long long int k;
	scanf("%lld",&k);
	long long int j,m;
	for(j=0;j<T-1;j++)
	{
		for(m=j+1;m<T;m++)
		{
			
			if(song[j].cd>song[m].cd)
			{
			    struct song song1;
				song1 = song[j];
				song[j] = song[m];
				song[m] = song1;
			}
		}
	}
	long long int x;
	x = T - k;
	puts(song[x-1].gm);
	return 0;
}
