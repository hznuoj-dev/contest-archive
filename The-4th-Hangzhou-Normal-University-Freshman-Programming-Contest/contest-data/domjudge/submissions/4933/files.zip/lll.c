#include<stdio.h>
#include<string.h>
int main(){
	int n;
	int z=0;
	int str[10000];
	scanf("%d",&n);
	int x=n;
	while(n--){
		int a[1000];
		int i=0,k=0;
		int z;
		for(i=1;i<=x;i++){
			scanf("%s",&str[i]);
		}
		int y;
		scanf("%d",&y);
		z=x-y;
		for(k=1;k<=z;k++){
			int max=0;
			if(a[k]>max){
				max=a[k];
		}	
		}
		printf("%s\n",str[k]);
	}
	return 0;
}
