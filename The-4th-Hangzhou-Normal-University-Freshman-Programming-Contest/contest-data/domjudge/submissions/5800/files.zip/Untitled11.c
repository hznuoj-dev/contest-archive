#include<stdio.h>
#include<string.h>
main(){
	int t;
	char a[40000];
	char b[1000][31];
	char c;
	int i,j,k,n;
	scanf("%d",&t);
	getchar();
	while(t--){
		memset(b,'\0',sizeof(b));
		gets(a);
		k=strlen(a);
		c=a[k-1];
		j=0;
		n=0;
		for(i=0;i<k;i++){
			if(a[i]!=' '&&a[i]!='.'&&a[i]!='!'&&a[i]!='?'){
				b[j][n]=a[i];
				n++;
			}
			else{
				j++;
				n=0;
			}
		}
		if(j%2==1){
			for(i=0;i<=j/2;i++){
				if(i!=j/2){
					printf("%s %s ",b[i],b[j-i-1]);
				}
				else{
					printf("%s",b[i]);
					printf("%c\n",c);
				}
			}
		}
		else{
			for(i=0;i<=j/2;i++){
				if(i<j/2-1){
					printf("%s %s ",b[i],b[j-i-1]);
				}
				else if(i==j/2-1){
					printf("%s %s",b[i],b[j-i-1]);
				}
				else{
					printf("%c\n",c);
				}
			}
		}
	}
}
