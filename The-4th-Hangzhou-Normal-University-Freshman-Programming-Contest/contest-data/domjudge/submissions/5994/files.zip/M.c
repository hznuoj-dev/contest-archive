#include<stdio.h>
#include<string.h>
main()
{
	int T, len, i, j,k,c,number;
	char str[30001][30001], temp;
	scanf("%d", &T);
	while (T--)
	{
		for (i = 0;;i++)
		{
			scanf("%s", str[i]);
			len = strlen(str[i]);
			if (str[i][len - 1] == '.' ||
				str[i][len - 1] == '!'||
				str[i][len - 1] == '?' ) 
			{
				temp = str[i][len - 1];
				str[i][len - 1] = '\0';
				break;
			}
		}
		if ((i + 1) % 2 == 0)
		{
			number = 1;
			for (j = 0;j <( i+1)/2;j++)
			{
				len = strlen(str[j]);
				str[j][len] = number;
				str[j][len + 1] = '\0';
				number += 2;
			}
			number -= 2;
			number++;
			for (;j < i + 1;j++)
			{
				len = strlen(str[j]);
				str[j][len] = number;
				str[j][len + 1] = '\0';
				number -= 2;
			}
		}
		else 
		{
			number = 1;
			for (j = 0;j < (i+1+1)/2;j++)
			{
				len = strlen(str[j]);
				str[j][len] = number;
				str[j][len + 1] = '\0';
				number += 2;
			}
			number -= 2;
			number--;
			for (;j < i+1 ;j++)
			{
				len = strlen(str[j]);
				str[j][len] = number;
				str[j][len + 1] = '\0';
				number -= 2;
			}
		}
		number = 1;
		for (j = 0;j < i + 1;j++)
		{
			for (k = 0;k < i + 1;k++)
			{
				len = strlen(str[k]);
				if(str[k][len-1]==number)
				{ 
					for (c = 0;c < len - 1;c++)
						printf("%c", str[k][c]);
					if(j != i)
					printf(" ");
					break;
				}
			}
			number++;
		}
		printf("%c", temp);
		printf("\n");
	}
}

