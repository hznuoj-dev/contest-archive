#include<stdio.h>
#include <stdlib.h>
#define N 10000 
	struct oo{
		long long int num;
		char name[50];
	};
int cmp(const void *p,const void *q)
{
	struct oo *pp = (struct oo *)(p);
	struct oo *pq = (struct oo *)(q);
	int a = pp -> num;
	int b = pq -> num;
	return b - a;
}
int main(){
	struct oo a[N];
	long long int n,p;
	 scanf("%lld",&n);	
		
		for (long long int i=0;i<n;++i)
		{
			scanf ("%lld %s" , &a[i].num , a[i].name);
		}
		
		qsort (a,n,sizeof(struct oo),cmp);
		scanf("%lld",&p);
		printf ("%s\n" , a[p].name); 
	}
