#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	int t, i, n, k;
	char f[1000][30];
	
	scanf("%d", &t);
	while(t--){
		for(i=0;i<1000;i++){
			scanf("%s", f[i]);
			n+=1;
			if((f[i][0]=='.')||(f[i][0]=='!')||(f[i][0]=='?')) break;
		}
		i=0;
		k=n;
		n-=1;
		while(i<n){
			printf("%s ", f[i++]);
			printf("%s ", f[n--]);
		}
		printf("%s", f[k]);
	}
}
