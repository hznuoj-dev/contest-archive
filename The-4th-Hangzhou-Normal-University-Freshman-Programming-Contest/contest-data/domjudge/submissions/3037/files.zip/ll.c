#include<stdio.h>
int main() {
	int i, sum, flag, n[10000],t,m;
	scanf("%d", &t);
	while (t--) {
		sum = 0;
		flag = 0;
		scanf("%d", &m);
		for (i = 0; i < m; i++) {
			scanf("%d", &n[i]);
		}
		flag = 0;
		for (i = 0; i < m; i++) {
			int j = i;
			sum = 0;
			for (; j >= 0; j--) {
				sum += n[j];
				if (sum == 7777) {
					flag++;
				}
			}
		}
		printf("%d", flag);
	}
	return 0;
}