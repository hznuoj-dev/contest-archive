#include<stdio.h>
main(){
	int i,n;
	scanf("%d",&n);
	for(i=1;i<=n;i++)
	{
		printf("Welcome to HZNU\n");
	}
}
