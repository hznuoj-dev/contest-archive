#include<stdio.h>
#include<string.h>
int main(void) 
{
	int p,x,lenb,c[100],sum,i,j,t,z;
	char b[10001],a[101];
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		scanf("%d",&x);
		getchar();
		scanf("%[^\n]",b);
     lenb=strlen(b);
     for(i=0;i<100;++i)
     {
     	c[i]=0;
    	a[i]='\0';
	 }
	 sum=0;
	 p=0;
	 z=0;
     for(i=0;i<lenb;++i)
     {
     	for(j=0;j<p+1;++j)
     	{
     		if(b[i]!=' ')
     		{
     			z++;
     			if(b[i]==a[j])
			{
				c[j]++;
				if(c[j]>=2)
				{
					c[j]=c[j]-2;
					sum=sum+2;
				}
				break;
			}
			    if(j==p)
			{
				a[p]=b[i];
     		   c[p]=1;
     		   p++;
			}
			}
			else break;
		}
	 }
	 if(z>sum)printf("%d\n",sum+1);
	 else printf("%d\n",sum);
	}
}


