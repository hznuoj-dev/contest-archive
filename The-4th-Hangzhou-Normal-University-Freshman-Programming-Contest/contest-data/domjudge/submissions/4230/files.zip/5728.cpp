#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct ge{
	int w;
	char s[20];
}stiff[100100];
int cap(const void *p,const void *q)
{
	struct ge *pp=(struct ge*)(p);
	struct ge *pq=(struct ge*)(q);
	int a = pp->w;
	int b = pq->w;
	return b-a;
}

int main()
{
    int t,n,x,i,j,flag=0;
    scanf("%d",&t);
    int cs=t;
    while(t--)
    {
    	scanf("%d%d",&n,&x);
    	flag=0;
    	if(x==0)
    	flag=1;
		if(flag==0)
    	printf("yes\n");
    	else
    	printf("no\n");
	}
	return 0;
} 
