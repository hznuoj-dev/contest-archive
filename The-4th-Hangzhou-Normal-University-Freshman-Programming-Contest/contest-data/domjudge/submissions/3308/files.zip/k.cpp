#include<stdio.h>
#include<string.h>
struct music
{
	int love;
	int flag;
	char m[200];
}sing[100005];

int main()
{
	int n,i,j,k,max,x;
	scanf("%d",&n);
	i=1;
	for(i=1;i<=n;++i)
	{
		scanf("%d %s",&sing[i].love,sing[i].m);
	}
	scanf("%d",&k);
	for(i=0;i<=k;++i)
	{
		max=-1;
		for(j=1;j<=n;++j)
		{
			if(sing[j].flag==0&&sing[j].love>max)
			{
				max=sing[j].love;
				x=j;
			}
		}
		sing[x].flag=1;
	}
	printf("%s",sing[x].m);
	return 0;
}
