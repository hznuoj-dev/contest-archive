#include<stdio.h>
int main() {
	int n, m,x,y,z;
	scanf("%d%d%d%d%d", &n, &m,&x,&y,&z);
	if (n == 0&&z==1) {
		if (m == 1) {
			if (y >= 2500) {
				printf("��haoye");
			}
			else printf("QAQ");
		}
		if (m == 0) {
			if (y >= 2100) {
				printf("��haoye");
			}
			else printf("QAQ");
		}
	}
	if (n == 2 && x == 2) {
		printf("��haoye");
	}
	else printf("QAQ");