#include<stdio.h>
int main(void){
	int n;
	scanf("%d",&n);
	if(n>=1 && n<=100){
		while(n--){			
	        printf("Welcome to HZNU");
	    }
	}
	return 0;
}
