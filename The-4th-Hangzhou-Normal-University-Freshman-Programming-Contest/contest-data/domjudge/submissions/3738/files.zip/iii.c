/*********************************************************************
    ������:
    ����: 2021-12-12 14:39
    ˵��:
*********************************************************************/
#include <stdio.h>
#include <stdlib.h>

struct a {
	long aa;
	char ac[16];
} ar[10000];

int com(void const *ap, void const *bp) {
	return ((struct a *)ap)->aa < ((struct a *)bp)->aa;
}

int main() {
	int n, i, k;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%ld %s", &ar[i].aa, ar[i].ac);
	}
	qsort(ar, n, sizeof(ar[0]), com);
	scanf("%d", &k);
	printf("%s", ar[k].ac);

	return 0;
}
