#include<stdio.h>
int main()
{
	int t;
	scanf("%d", &t);
	while (t--)
	{
		int b[124] = { 0 };
		int c[124];
		int n, i, sum = 0;
		char a;
		scanf("%d", &n);
		getchar();
		for (i = 0; i < 2 * n; i++)
		{
			scanf("%c", &a);
			if (i % 2 == 0)
				b[(int)a]++;
		}
		for (i = 0; i < 124; i++)
		{
			if (b[i] % 2 == 0)
			{
				sum += b[i];
			}
		}
		int j = 0;
		for (i = 0; i < 125; i++)
		{
			if (b[i] % 2 == 1)
			{
				c[j] = b[i];
				j++;
			}
		}
		int max = c[0];
		for (i = 1; i < j; i++)
		{
			if (max < c[i])
			{
				max = c[i];
			}
		}
		sum += max;
		printf("%d\n", sum);
	}
	return 0;
}