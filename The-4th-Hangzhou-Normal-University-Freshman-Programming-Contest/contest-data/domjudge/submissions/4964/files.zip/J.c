#include <stdio.h>
int main()
{
	int n,m,b=0,c=0,q,f=0,atk;
	scanf("%d%d",&n,&m);
	while(n--)
	{
		scanf("%d",&q);
		if(q==0)
		{
			scanf("%d",&atk);
			if(m==0)
			{
				if(atk>=2500)
				f=1;
			}
			else
			{
				if(atk>2100)
				f=1;
			}
		}
		if(q==1)
		b++;
		if(q==2)
		c++;
	}
	if((f==1&&b>0)||(c>0&&n>1))
	printf("haoye");
	else
	printf("QAQ");
}
