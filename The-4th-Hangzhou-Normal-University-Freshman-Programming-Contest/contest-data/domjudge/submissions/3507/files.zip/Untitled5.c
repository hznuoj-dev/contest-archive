#include<stdio.h>
#include <stdlib.h>
#include <stdio.h>
int main(void){
	int n,m,i,s=0,t=0,p=0,e=0,q=0;
	scanf("%d%d",&n,&m);
	int d[n],a[n];
	for(i=0;i<n;i++){
		scanf("%d",&d[i]);
		if(d[i]==0){
			scanf("%d",&a[i]);
				if(a[i]>=2500){
				q++;}
			if(a[i]>=2100){
				e++;}
		}
	}
	if(n<2){
		printf("QAQ\n");
	}
	else{
		for(i=0;i<n;i++){
			if(d[i]==1){
				s++;}
			if(d[i]==2){
				t++;}
			if(d[i]==0){
				p++;}}
	if(s==0){
		if(t==0){
			printf("QAQ\n");
		}
		else{
				printf("haoye\n");
		}
	}
	else{
		if(t==0){
			if(p==0){
				printf("QAQ\n");
			}
			else{
				if(m==0){
					if(q==0){
						printf("QAQ\n");
					}
					else{
						printf("haoye\n");
					}
				}
				else{
					if(e==0){
						printf("QAQ\n");
					}
					else{
						printf("haoye\n");
					}
				}
			}
		}
		else{
			printf("haoye\n");
		}
	}}
	
	
return 0;
}

