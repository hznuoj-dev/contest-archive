#include<stdio.h>
#include<string.h>
int main(){
	int n;
	long long a[100000];
	char str[10000];
	scanf("%d",&n);
	int x=n;
	while(n--){
		int a[1000];
		int i=0,k=0;
		int m;
		for(i=1;i<=x;i++){
			scanf("%d",&a[i]);
			scanf("%s",&str[i]);
		}
		int y;
		scanf("%d",&y);
		m=x-y;
		for(k=1;k<=m;k++){
			int max=0;
			if(a[k]>max){
				max=a[k];
		}	
		printf("%s\n",str[k]);
	}
	}
	return 0;
}
