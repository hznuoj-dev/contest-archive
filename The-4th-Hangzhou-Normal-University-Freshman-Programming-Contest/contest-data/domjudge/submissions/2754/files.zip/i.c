#include<stdio.h>
int main(){
	long int t,n,x,i,s=0,a[100]={0};
	scanf("%ld",&t);
	while(t--){
		scanf("%ld%ld",&n,&x);
		while(1){
			s=s+x;
			if(x==0){
				printf("no\n");
				break;
			}
			if(s>=n)
				s=s%n;
			if(s==0){
				printf("yes\n");
				break;
			}
			if(s<100){
				a[s]=a[s]+1;
				if(a[s]==2){
					printf("no\n");
					s=0;
					break;
				}
			}
		}
		for(i=1;i<100;i++)
				a[i]=0;
	}
	return 0;
}
