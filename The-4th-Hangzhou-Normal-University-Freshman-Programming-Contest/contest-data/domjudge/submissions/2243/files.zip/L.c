#include <stdio.h>
int main(){
	int t;
	int n,step;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&step);
		if(step>0){
			printf("yes\n");
		}
		else	printf("no\n");
		}
	return 0;
}
