#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#define pzc 666
using namespace std;
struct ss{
	int wi;
	char s[20];
}a[5010];
int cmp(struct ss a,struct ss b)
{
	if(a.wi>b.wi) return 1;
	else return 0;	
}
int main()
{
	long long x,y;
	int t,n,i,j,k,b,c,l,f,d;	
	char ch;
	cin>>n;i=0;
	while(i<n)
	{
		scanf("%d %s",&a[i].wi,a[i].s);
		i++;
	}
	sort(a,a+n,cmp);
	cin>>d;
	cout<<a[d].s;
}
