#include<stdio.h>
struct a{
	int c;
	char b[100];
};
int main(){
	struct a pzy[100001];
	int n;
		scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d%s",&pzy[i].c,pzy[i].b);
	}
	int k��temp;
	scanf("%d",&k);
	 int index[100001];
    for(int i=0;i<n;i++){
    	index[i]=i;
	}
    for(int i = 0; i < n- 1; i++) {
        for(int j = 0; j < n- i - 1; j++) {
            if(pzy[index[j]].c < pzy[index[j + 1]].c) {
               temp = index[j];
                index[j] = index[j + 1];
                index[j + 1] = temp;
            }
        }
    }
	printf("%s\n",pzy[index[k]].b);
}
