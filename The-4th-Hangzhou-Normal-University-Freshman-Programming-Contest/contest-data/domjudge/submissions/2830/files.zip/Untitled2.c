#include<stdio.h>
#include<stdlib.h>	
char ch[100010];
int main()
{
	int n,t,i,j,ans,b[1000]={0};
	scanf("%d",&t);
	while(t--)
	{
 	    scanf("%d",&n);			
		ans=0;
		for(i=0;i<n;i++)
		{
			scanf(" %c",&ch[i]);
			b[ch[i]-'A']++;
			{
				if(b[ch[i]-'A']==2)
				{
					ans+=2;
					b[ch[i]-'A']=0;
				}
			}
		}
		if(n>ans)
		    ans++;
		printf("%d\n",ans);
    }
} 
 
