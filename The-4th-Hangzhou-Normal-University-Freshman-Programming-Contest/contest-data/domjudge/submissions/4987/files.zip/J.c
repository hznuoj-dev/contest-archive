#include<stdio.h>
#include<string.h>
int main(void){
	int n,m,i,z=0,j;
	scanf("%d%d",&n,&m);
	int a[n],k[n];
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&k[i]);
		}
	}
	if(m==0){
		for(i=0;i<n;i++){
			if(a[i]==2&&n!=1){
				z=1;
				printf("haoye");
			}
		}
		if(z==0){
			for(i=0;i<n;i++){
				if(a[i]==0&&k[i]>=2500){
					for(j=0;j<n;j++){
						if(j!=i&&a[j]==1){
							z=1; 
							printf("haoye");
						}
					} 
				}
			}
		}
	}
	else if(m==1){
		for(i=0;i<n;i++){
			if(a[i]==2&&n!=1){
				z=1;
				printf("haoye");
			}
		}
		if(z==0){
			for(i=0;i<n;i++){
				if(a[i]==0&&k[i]>=2100){
					for(j=0;j<n;j++){
						if(j!=i&&a[j]==1){
							z=1;
							printf("haoye");
						}
					} 
				}
			}
		}
	}
	if(z==0)
		printf("QAQ");
	return 0;
}
