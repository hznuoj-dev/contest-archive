#include <stdio.h>
int s[100004]={0};
int main()
{
	int a,b,c,d,i,p;
	int * q;
	int * k;
	scanf("%d",&a);
	while(a--)
	{
		d=0;
		q=s;
		scanf("%d",&b);
		for(i=0;i<b;i++,q++)
			scanf("%d",q);
		q=s;
		for(i=0;i<b;i++,q++)
		{
			c=*q;
			k=q+1;;
			for(p=i+1;p<=b;p++,k++)
			{
				if(c==7777)
				{
					d=d+1;
					break;
				}
				else if(c>7777)
					break;
				c=c+*k;
			}
		}
		for(i=0;i<b;i++)
			s[i]=0;
		printf("%d\n",d);
	}
	return 0;
}