#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
const int maxn=1000010;
int a[11][maxn];
int main(){
	int n,m;
	cin>>n>>m;
	vector<int> vec;
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++){
			cin>>a[i][j];
		}
		sort(a[i],a[i]+m);
	}
	for(int i=0;i<n;i++){
		vec.push_back(a[i][0]);
	}
	sort(vec.begin(),vec.end());
	cout<<vec[n-1]-vec[0];
	return 0;
}
 
