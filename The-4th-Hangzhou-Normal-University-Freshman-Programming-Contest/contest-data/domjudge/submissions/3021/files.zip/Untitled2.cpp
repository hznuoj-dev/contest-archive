#include<stdio.h>
int main(){
	int	T;
	int n;
	scanf("%d",&T);
	while(T--){
		int t=0,a[100000]={0};
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			scanf("%d",&a[i]);
			
		}
		for(int i=1;i<=n;i++){
			
			for(int j=0;j<n;j++){
				int sum=a[j];
				for(int m=j+1;m<j+i;m++){
					if(m>n-1){
						sum=0;
						break;
					}
					sum+=a[m];
					if(sum>7777)
						break;
				}
				if(sum==7777)
					t++;
			}
		}
		printf("%d",t);
	}
}
