#include <stdio.h>
int main()
{
	
	int n,m;
	scanf("%d %d",&n,&m);
	int x[n];
	int k[n];
	int i;
	for(i=0;i<n;++i)
	{
		scanf("%d",&x[i]);
		if(x[i])
			;
		else
			scanf("%d",&k[i]);
	}
	if(n<=1)
		printf("QAQ\n");
	else if(m==0)
	{
		int flag1 = 0;
		int flag2 = 0;
		for(i=0;i<n;++i)
		{
			if(x[i]==0 && k[i] >= 2500)
			{
				flag1 = 1;
			}
			else if(x[i]==1)
			{
				flag2 = 1;
			}
			else if(x[i]==2 && n>=3)
				flag2 = 1;
		}
		if(flag1&&flag2)
		{
			printf("haoye\n");
		}
		else
			printf("QAQ\n");
	}
	else if(m==1)
	{
		int flag1 = 0;
		int flag2 = 0;
		for(i=0;i<n;++i)
		{
			if(x[i]==0 && k[i] >= 2100)
			{
				flag1 = 1;
			}
			else if(x[i]==1)
			{
				flag2 = 1;
			}
			else if(x[i]==2 && n>=3)
				flag2 = 1;
		}
		if(flag1&&flag2)
		{
			printf("haoye\n");
		}
		else
			printf("QAQ\n");
	}
	
	
	return 0;
}
