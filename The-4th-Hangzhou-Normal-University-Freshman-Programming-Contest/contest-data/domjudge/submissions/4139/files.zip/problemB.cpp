#include<stdio.h>
int main()
{
	int t,n;
	scanf("%d",&n);
	while(n--)
	{
		scanf("%d",&n);
		int a[n];
		int i,j,k,l,flag=0;
		for(i=0;i<n;i++) scanf("%d",&a[i]);
		for(j=0;j<n;j++)
		{
			for(k=j+1;k<n;k++)
			{
				for(l=k+1;l<n;l++)
				{
					if(a[j]+a[k]+a[l]==7777)
					flag++;
				}
			}
		}
		printf("%d\n",flag);
	}
}
