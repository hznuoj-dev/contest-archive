#include<bits/stdc++.h>
using namespace std;
int a[21][21];
int b[21][21];
int main () {
	int t,c,n,jud;

	cin>>t;

	for(int i = 1; i <= t; i++) {
		cin>>n;
		for(int j = 1; j <= n; j++) {
			for(int k = 1; k <= n; k++) {
				cin>>a[j][k];
			}
		}
		for(int j = 1; j <= n; j++) {
			for(int k = 1; k <= n; k++) {
				cin>>b[j][k];
			}
		}

		jud = 1;

		for(int j = 1; j <= n; j++) {
			for(int k = 1; k <= n; k++) {
				if(a[j][k]!=b[j][k]) {
					jud = 0;
					break;
				}
			}
		}
		if(jud) {
			cout<<"0\n";
			continue;
		}

		jud = 1;

		for(int j = 1; j <= n; j++) {
			for(int k = 1; k <= n; k++) {
				if(a[n-k+1][j]!=b[j][k]) {
					jud = 0;
					break;
				}
			}
		}
		if(jud) {
			cout<<"1\n";
			continue;
		}

		jud = 1;
		for(int j = 1; j <= n; j++) {
			for(int k = 1; k <= n; k++) {
				if(a[k][n-j+1]!=b[j][k]) {
					jud = 0;
					break;
				}
			}
		}
		if(jud) {
			cout<<"1\n";
			continue;
		}

		jud = 1;
		for(int j = 1; j <= n; j++) {
			for(int k = 1; k <= n; k++) {
				if(a[n-j+1][n-k+1]!=b[j][k]) {
					jud = 0;
					break;
				}
			}
		}
		if(jud) {
			cout<<"2\n";
			continue;
		}
		cout<<"-1\n";
	}
	return 0;
}
