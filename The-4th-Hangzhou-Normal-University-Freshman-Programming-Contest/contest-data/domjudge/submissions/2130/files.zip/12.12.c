#include<stdio.h>
int main(void)
{
	int n=0;
	scanf("%d",&n);
	for(;n>0;n--)
	{printf("Welcome to HZNU\n");}
	return 0;
}
