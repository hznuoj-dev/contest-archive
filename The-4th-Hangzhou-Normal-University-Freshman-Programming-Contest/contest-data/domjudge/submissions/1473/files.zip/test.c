#include<stdio.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
int cmp(const void*p,const void *q)
{
	int *pp = (int*)(p);
	int *pq = (int*)(q);
	return *pp-*pq;
}
int main()
{
	int n,m,i,j,min=10000000;
	scanf("%d%d",&n,&m);
	int a[n][m];
	for(i=0;i<n;++i)
	{
		for(j=0;j<m;++j)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;++i)
	{
		qsort(a[n][m],m,sizeof(int),cmp);
		for(j=0;j<m-1;++j)
		{
			if(abs(a[i][j]-a[i][j+1])<min)
			min = abs(a[i][j]-a[i][j+1]);	
		}
	}
	printf("%d",min);
}
