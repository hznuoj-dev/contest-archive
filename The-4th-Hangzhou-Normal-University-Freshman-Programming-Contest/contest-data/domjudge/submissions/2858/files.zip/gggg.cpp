#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int t,n,x,i;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&x);
		for(i=1;i<=x;i++)
		{
			if((n*i)%x==0)
			{
				printf("yes\n");
				break;
			}
		}
		if(i==x+1)
		printf("no\n");
	}
	
}
