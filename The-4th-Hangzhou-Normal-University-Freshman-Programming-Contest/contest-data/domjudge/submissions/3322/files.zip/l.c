#include<stdio.h>
int main(void){
	int t,i,l,n,x;
	long long int j;
	scanf("%d",&t);
	while(t--){
		l=0;
		i=0;
		scanf("%d%d",&n,&x);
		if(x==0){
			printf("no\n");
		}
		else{
			printf("yes\n");
		}
	}
	return 0;
}
