#include<stdio.h>
#include<stdlib.h>
struct song{
	long num;
	char name[16];
};
int comp (const *p,const *q){
	return ((struct song *)q)->num-((struct song *)p)->num;
}
int main(void){
	int n,i,k;
	scanf("%d",&n);
	struct song array[n];
	for(i=0;i<n;i++){
		scanf("%ld%s",&array[i].num,array[i].name);
	}
	scanf("%d",&k);
	qsort(array,n,sizeof(struct song),comp);
	printf("%s",array[k].name);
	return 0;
} 
