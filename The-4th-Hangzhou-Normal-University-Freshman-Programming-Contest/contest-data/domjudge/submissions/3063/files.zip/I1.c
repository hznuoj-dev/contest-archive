#include<stdio.h>
struct student {
	int w;
	char a[17];
};
int main() {
	int n, i, j;
	struct student b[100000];
	struct student k;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d %s", &b[i].w, b[i].a);
	}
	int num1;
	scanf("%d", &num1);
	for (i = 0; i < n - 1; i++) {
		for (j = 0; j < n - i - 1; j++) {
			if (b[i].w < b[i + 1].w) {
				k = b[i];
				b[i] = b[i + 1];
				b[i + 1] = k;
			}
		}
	}
	printf("%s", b[num1].a);
}
