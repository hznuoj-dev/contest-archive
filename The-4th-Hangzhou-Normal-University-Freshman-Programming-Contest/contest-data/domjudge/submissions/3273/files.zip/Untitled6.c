#include<stdio.h>
#include<string.h>
int main()
{
	int t;
	char s[1010][35];
	scanf("%d",&t);
	getchar();
	while(t--){
		int i=0;
		while(1){
			scanf("%s",&s[i]);
			char a=getchar();
			if(a=='\n')
			break;
			i++;
		}
		int flag;
		char point=s[i][strlen(s[i])-1];
		s[i][strlen(s[i])-1]='\0';
		if((i+1)%2==0)
		flag=0;
		else
		flag=1;
		int m=(i+1)/2;
		for(int j=0;j<m;j++){
			printf("%s %s",s[j],s[i-j]);
			if(!(j==m-1&&!flag))
			printf(" ");
		}
		if(flag)
		printf("%s%c\n",s[i/2],point);
		else
		printf("%c\n",point);
	}
	return 0;
}
