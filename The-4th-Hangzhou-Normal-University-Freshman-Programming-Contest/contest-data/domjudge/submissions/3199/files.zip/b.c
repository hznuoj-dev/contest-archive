#include<stdio.h>
int main(){
	int t, n, i, j, m, s, f[100000];
	scanf("%d", &t);
	while(t--){
		m=0;
		scanf("%d", &n);
		for(i=0;i<n;i++){
			scanf("%d", &f[i]);
		}
		for(i=0;i<n;i++){
			s=0;
			for(j=i;j<n;j++){
			    s+=f[j];
				if(s==7777){
					m+=1;
					break;
				} 
			}
		}
		printf("%d\n", m);
	}
	
}
