#include<stdio.h>
struct wzy{
	long long int id;
	char zjh[16];
}tt[100001];
int main()
{
	int n,i,j,num;
	struct wzy max;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&tt[i].id,&tt[i].zjh);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(tt[j].id>tt[j+1].id)
			{
				max=tt[j];
				tt[j]=tt[j+1];
				tt[j+1]=max;
			}
		}
	}
	scanf("%d",&num);
	for(i=0;i<n-num;i++)
	{
		printf("%s\n",tt[i].zjh);
	}
	system("pause");
	return 0;
}