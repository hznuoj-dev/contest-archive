#include"stdio.h"
int main(void){
long int n1[21][21],n2[21][21];
long int a,b,e,t,z1=0,y1=0,z2=0,bb=0;
scanf("%ld",&t);
while(t--){
scanf("%ld",&e);
z1=0;y1=0;z2=0;bb=0;
for(a=0;a<e;a++)
for(b=0;b<e;b++)
scanf("%ld",&n1[a][b]);
for(a=0;a<e;a++)
for(b=0;b<e;b++){
scanf("%ld",&n2[a][b]);
if(n2[a][b]==n1[a][b]) bb++;
if(n2[a][b]==n1[e-b-1][a]) z1++;
if(n2[a][b]==n1[b][e-a-1]) y1++;
if(n2[a][b]==n1[e-a-1][e-b-1]) z2++;}
if(bb==e*e) printf("0\n");
else if(z1==e*e||y1==e*e) printf("1\n");
else if(z2==e*e) printf("2\n");
else printf("-1\n");}
return 0;}
