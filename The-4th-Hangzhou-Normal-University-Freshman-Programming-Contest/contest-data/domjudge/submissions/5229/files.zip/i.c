#include <stdio.h>
#include <stdlib.h>
struct music
{
	int w;
	char s[20];
}sing [200000];

int cmp(const void *p,const void *q)
{
	struct music *pp = (struct music*)p;
	struct music *pq = (struct music*)q;
	int a = pp ->w;
	int b = pq ->w;
	return b-a;
 } 
int main()
{
	int n,i,j,k,t;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&sing[i].w,sing[i].s);
	}
	scanf("%d",&k);
	qsort(sing,n,sizeof(struct music),cmp);
	printf("%s",sing[k].s);
	return 0;
}
