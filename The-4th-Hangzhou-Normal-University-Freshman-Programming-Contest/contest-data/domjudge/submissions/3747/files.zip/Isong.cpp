#include <stdio.h>
struct num{
	int no;
	char name[21]; 
};
int main()
{
	struct num a[100001],t;
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%d %s",&a[i].no,a[i].name);
	}
	for(i=0;i<n-1;++i)
	{
		for(j=0;j<n-i-1;++j)
		{
			if(a[j].no<a[j+1].no)
			{
				t = a[j];
				a[j] = a[j+1];
				a[j+1] = t;
			} 
		}
	}
	scanf("%d",&k);
	printf("%s\n",a[k].name);
	return 0;
} 
