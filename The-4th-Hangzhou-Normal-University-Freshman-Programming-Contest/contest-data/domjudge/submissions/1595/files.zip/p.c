#include <stdio.h>
int main()
{
	int asda,ccc;
	scanf("%d",&asda);
	for(ccc=0;ccc<asda;ccc++)
	{
		printf("Welcome to HZNU\n");
	}
	return 0;
}