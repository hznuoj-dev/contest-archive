#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
typedef struct
{
	char s[16];
	long long int w;
}like;
int main()
{
	like a[10000];
	long int n;
	long long int k;
	scanf("%ld",&n);
	for(int i=0;i<n;i++)
	{
		scanf("%lld%s",&a[i].w,a[i].s);
	}
	scanf("%lld",&k);
	if(n==1)
		printf("%s",a[0].s);
	else
	{
	qsort(a,n,sizeof(a[0]),comp);
	printf("%s",a[k+1].s);
	}
	return 0;
}
int comp(const void *p,const void *q)
{
	like a=*(like*)p;
	like b=*(like*)q;
	return b.w-a.w;
}
