#include<stdio.h>
int main(){
	int t;
	long long a,b;
	scanf("%d",&t);
	while(t>0){
	scanf("%lld %lld",&a,&b);
	if(a%b==0)printf("yes");
	else printf("no");
	t--;
	}
	return 0;
} 
