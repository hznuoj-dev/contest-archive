# include <stdio.h>
int main(void)
{
	int n,m;
	int K,D;
	int i;
	int x;
	int flag=0;
	scanf("%d%d",&n,&m);
	int temp=n;
	int count=0;
	while (n--)
	{
		
		scanf("%d",&x);
		if (n>=2&&x==2)
		{
		
			count=1;
			break;
		}	
		if (x==0&&x==m)
		{
			scanf("%d",&K);
			if (K>=2500)
				flag++;	
		}
		
		else if (x==0&&x!=m)
		{
			scanf("%d",&K);
			if (K>2100);
				flag++; 
		}
		if  (K>2100&&x==1)
		{
			flag++;
			break;
			}	
			
		
	}
	if (count==1||flag>=2)
		printf("haoye");
	
	else
		printf("QAQ");
			
	
	
	return 0;	
} 
