#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
cmp(char* a, char* b)
{
	return *a - *b;
}
int n, i, j;
int main()
{
	int nn;
	char num[100005];
	scanf("%d", &n);
	while (n--)
	{
		int sum=0;
 		scanf("%d", &nn);
		getchar();
		for (i = 0; i < nn; i++)
		{ 
			scanf("%c", &num[i]);
			getchar();
		}
		qsort(num, nn, sizeof(num[0]), cmp);
		for (i = 0; i < nn-1; i++)
		{
			if (num[i] == num[i + 1])
			{
				sum += 2;
				i++;
			}
		}
		if (sum != nn)
			sum++;
		printf("%d\n", sum);
	}
	return 0;
}