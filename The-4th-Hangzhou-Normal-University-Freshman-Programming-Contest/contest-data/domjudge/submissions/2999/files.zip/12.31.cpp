#include<stdlib.h>
#include<stdio.h>
struct song
{
	char a[30];
	int  num;
};
int cmp(  const void*p,const void*q)
{
	return  *(int *)q-*(int *)p;
}
int main() 
{
	int n,i,c[100000],k;
	struct song son1[100001];
	scanf("%d",&n);
    for(i=0;i<n;++i)
    {
       scanf("%d%s",&son1[i].num,son1[i].a);
       c[i]=son1[i].num;
	}	
  qsort(c,n,sizeof(int),cmp);
     scanf("%d",&k);
     for(i=0;i<n;++i)
     {
     	if(son1[i].num==c[k])
     	{
     		printf("%s\n",son1[i].a);
     		break;
		}
	 }
}


