//
//  main.c
//  L.cpp
//
//  Created by 陶艾嘉 on 2021/12/12.
//

#include <stdio.h>
int main(void){
    int t;
    scanf("%d",&t);
    while(t--){
        int n,x;
        scanf("%d %d",&n,&x);
        if((2*n-2)%x==0&&n>x){
            printf("yes\n");
            }
    else
        printf("no\n");
    }
}
