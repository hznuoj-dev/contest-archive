#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	long long t,x,n;
	scanf("%lld",&t);
	while(t--)
	{
		scanf("%lld %lld",&n,&x);
		if(x == 0)
		{
			printf("no\n");
		}
		else
		{
			printf("yes\n");
		}
	}
	return 0;
} 
