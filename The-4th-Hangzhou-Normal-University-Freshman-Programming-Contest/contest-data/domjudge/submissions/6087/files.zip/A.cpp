#include<stdio.h>

int main()
{
	int a,b,sum=0,x[200000],num=0;
	scanf("%d",&a);
	while(a--)
	{
		num=0;
		scanf("%d",&b);
		for(int i=1;i<=b;i++)
		{
			scanf("%d",&x[i]);
		}
		for(int i=1;i<=b;i++)
		{
			sum=0;
			for(int j=i;j<=b;j++)
			{
				sum=sum+x[j];
				if(sum==7777)
				{
					num++;
					break;
				}
				else if(sum>7777)
				{
					break;
				}
			}
		}
		if(a>=1)
		printf("%d\n",num);
		else
		printf("%d",num);
	}
	
	return 0;
}
