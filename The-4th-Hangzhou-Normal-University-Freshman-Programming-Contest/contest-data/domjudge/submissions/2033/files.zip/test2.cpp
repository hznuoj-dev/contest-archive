#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define res register int
using namespace std;
int n,m,p,q,x,y,t;
int main()
{
	scanf("%d",&t);
	while(t>0)
	{
		scanf("%d%d",&x,&y);
		if(y!=0) printf("yes\n");
		else printf("no\n");
		t--;
	}
}
