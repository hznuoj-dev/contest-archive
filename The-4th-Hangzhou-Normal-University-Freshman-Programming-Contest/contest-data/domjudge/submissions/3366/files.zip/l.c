#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int t,i,total,jump;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d %d",&total,&jump);
		if(jump == 0 || (total % jump !=0 && jump % total !=0))
			printf("no\n");
		else printf("yes\n");
	}
	return 0;
}
