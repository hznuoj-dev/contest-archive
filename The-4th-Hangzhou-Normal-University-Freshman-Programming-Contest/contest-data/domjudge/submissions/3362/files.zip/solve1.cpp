#include<bits/stdc++.h>

using namespace std;
const int maxn=1e6+10;
int a[maxn];

int main()
{
    int n,T;
    cin>>T;
    while(T--){
    scanf("%d",&n);
    for(int i=1;i<=n;i++){
        scanf("%d",&a[i]);
    }    

    int now=1;
    int ans=0;
    int sum=0;
    for(int i=1;i<=n;i++){
        while(now<=n&&sum<7777){
            sum+=a[now];
            now++;
        }
        if(now>n&&sum<7777)break;
        //cout<<i<<" "<<now-1<<endl;
        if(sum==7777)ans++;
        sum-=a[i];
    }
    cout<<ans<<endl;
    }
}

/*
2 3 
5 7 6 
9 8 2 

2 6 5 7 8 9
*/