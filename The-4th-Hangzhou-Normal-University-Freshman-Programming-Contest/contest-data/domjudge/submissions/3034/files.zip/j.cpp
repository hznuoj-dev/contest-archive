#include<stdio.h>
int main(void)
{
	int n,m;
	int a,b,c;
	scanf("%d %d",&n,&m);
	scanf("%d",&a);
	if(a==0){
	scanf("%d",&b);}
	scanf("%d",&c);
	if(m==0&&a==0&&b>=2500&&c==1)
		printf("haoye");
	else if(m==0&&a==0&&b>=2500&&c==2&&n>=3)
		printf("haoye");
	else if(m==1&&a==0&&b>=2500&&c==1||n>=3) 
	printf("haoye");
	else
	printf("QAQ");
	return 0;
}
