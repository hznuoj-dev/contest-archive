#include <stdio.h>

int main(void){
	int t;
	scanf("%d",&t);
	for (int i=1; i<=t; i++){
		int n;
		int a[200]={0};
		char le;
		int sum=0;
		scanf("%d",&n);
	
		for(int j=1; j<=n; j++){
			getchar();
			scanf("%c",&le);
			a[le]++;
		}
		int judge=0;
		for(int j=0; j<200; j++){
			if (a[j]%2==1) judge=1;
			a[j]/=2;
			sum+=a[j];
		}
		printf("%d\n",sum*2+judge);
	}
	return 0;
} 
