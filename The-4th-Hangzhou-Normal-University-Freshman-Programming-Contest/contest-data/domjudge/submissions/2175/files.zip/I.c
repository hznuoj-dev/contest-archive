# include <stdio.h>
# include <stdlib.h>
typedef struct{
	int num;
	char name[18];
}song;
int cmp(const void *a,const void *b){
	song *p=(song *)a,*q=(song *)b;
	return (q->num)-(p->num);
}
song stu[100010];
int main(){
	int n,k,i;
	
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d%s",&stu[i].num,stu[i].name);
	}
	scanf("%d",&k);
	qsort(stu,n,sizeof(stu[0]),cmp);
	printf("%s\n",stu[k].name); 
}
