#include<stdio.h>
#include<string.h>
int main(void){
	int T,i,j,n,m;
	scanf("%d",&T);
	while(T--){
		char s[1010][35], fh;
		for(i=0;i<1010;i++){
			scanf("%s",s[i]);
			n=strlen(s[i]);
			if(s[i][n-1]=='.'||s[i][n-1]=='!'||s[i][n-1]=='?'){
				m=i+1;fh=s[i][n-1];s[i][n-1]='\0';break;
			}
		}
	//������Ϊ���� 
		if(m%2!=0){
			for(i=0,j=m-1;i<=m/2;i++,j--){
				if(i==j) printf("%s",s[i]);
				else printf("%s %s ",s[i],s[j]);
			}
		}
	//������Ϊż�� 
		else{
			for(i=0,j=m-1;i<m/2;i++,j--){
				if(i<m/2-1) printf("%s %s ",s[i],s[j]);
				else printf("%s %s",s[i],s[j]);
			}
		}
		printf("%c\n",fh);
	}
	return 0;
}

