#include<stdio.h>
#include<string.h>
#include<stdlib.h>	
int main() {
	
	int n,m;
	int x[11];
	int i; 
	int k[11];
	
	int atk=0;
	int def=2100;
	int hp=2500;
	
	scanf("%d %d",&n,&m);//n �������� �� m ״̬
	
	if(m==1) hp+=def;
	
	for(i=0;i<n;i++) {
		scanf("%d",&x[i]);
		if(x[i]==0){
			scanf("%d",&k[i]);
		} else {
			k[i]=0;
		}//������
		atk+=k[i];
	}

	if(atk>=hp) {
		printf("haoye\n");
	} else {
		printf("QAQ\n");
	}
	
	return 0;
}
