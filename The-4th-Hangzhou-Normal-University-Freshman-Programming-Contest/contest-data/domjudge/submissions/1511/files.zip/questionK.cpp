#include<iostream>
#include<algorithm>
using namespace std;
int main(void){
	int n,a,b;cin>>n;
	while(n--){
		cin>>a>>b;
		if(b%a==0)
			cout<<"no"<<endl;
		else
			cout<<"yes"<<endl;
	}
} 
