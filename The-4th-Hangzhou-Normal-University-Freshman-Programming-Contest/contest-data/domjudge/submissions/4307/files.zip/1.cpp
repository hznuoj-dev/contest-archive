#include<stdio.h>
int main(void)
{
	int T;
	scanf("%d",&T);
	while(T<=10)
	{
		int n;
		int ai,sum,m;
		scanf("%d %d",&n,&ai);
		for(ai=1;ai<=n;++ai)
		m=ai/4;
		m=(int)sum==7777;
		printf("%d\n",m);
}
}

