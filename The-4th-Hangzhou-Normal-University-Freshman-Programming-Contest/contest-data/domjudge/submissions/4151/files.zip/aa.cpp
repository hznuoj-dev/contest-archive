#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#define pzc 666
using namespace std;
int a[100010];
int main()
{
	int n,m,f,win,x[14]={0},k[14]={0},a,b,c,i,j;
	cin>>n>>m;f=1;win=0;i=0;
	while(i<n)
	{
		cin>>x[i];
		if(x[i]==0) cin>>k[i];
		if(x[i]==0) a++;
		if(x[i]==1)	b++;
		if(x[i]==2) c++;
		i++;
	}
	if(c>0&&n>1) win=1;
	if(m==0)
	{
		for(i=0;i<n;i++)
			if(k[i]>=2500) f=0;
	}
	else if(m==1)
	{
		for(i=0;i<n;i++)
			if(k[i]>2100) f=0;
	}
	for(i=0;i<n&&win==0;i++)
	{
		if(x[i]==1&&f==0)
			win=1;
	}
	if(win) cout<<"haoye";
	else cout<<"QAQ";
}
