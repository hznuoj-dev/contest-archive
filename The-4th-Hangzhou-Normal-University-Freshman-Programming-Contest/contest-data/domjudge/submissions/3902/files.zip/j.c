#include <stdio.h>

int main(void) {
	int n, m;
	int k, r = 0, flag = 0;
	scanf("%d %d", &n, &m);
	int x[n];
	for (int i = 0; i < n; i++) {
		scanf("%d", &x[i]);
		if (x[i] == 0) {
			scanf("%d", &k);
			if (m == 0)
				r = k - 2500;
			else
				r = k - 2100;
		} else if (x[i] == 1)
			flag = 1;
		else
			flag = 2;
	}
	if (n >= 2) {
		if ((r >= 0 && flag == 1) || flag == 2)
			printf("haoye\n");

		else
			printf("QAQ\n");
	} else
		printf("QAQ\n");
	return 0;
}