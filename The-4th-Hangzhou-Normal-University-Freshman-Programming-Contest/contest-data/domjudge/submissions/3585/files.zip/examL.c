#include<stdio.h>
int main(void)
{
	int t,i,n,x;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d%d",&n,&x);
		if(x == 0)
		    printf("no\n");
		else
		    printf("yes\n");
	}
	return 0;
}
