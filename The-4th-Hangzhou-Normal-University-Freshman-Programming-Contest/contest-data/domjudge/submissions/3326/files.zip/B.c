#include<stdio.h>
#include<string.h>

int main(void){
	int t,n,i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int a[100001],sum=0,b=0;
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			b=0;
			for(j=i;j<n;j++){
				b+=a[j];
				if(b==7777){
					sum++;
					break;
				}
				else if(b>7777){
					break;
				}
			}
		}
		printf("%d\n",sum);
	}
	return 0;
}

