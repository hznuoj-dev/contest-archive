#include <stdio.h>

int main(void) {
	int n,t,i,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int a[n][n],b[n][n];
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
			scanf("%d",&a[i][j]);
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
			scanf("%d",&b[i][j]);
	 int f1=1,f2=1,f3=1;
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
			if(a[j][n-i-1]!=b[i][j]){
				f1=0;
				break;
			}
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
			if(a[n-j-1][i]!=b[i][j]){
				f2=0;
				break;
			}
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
			if(a[n-j-1][i]!=b[j][n-i-1]){
				f3=0;
				break;
			}
		if(t>0){
		if(f1||f2)
			printf("1\n");
		else if(f3)
			printf("2\n");
		else 
			printf("-1\n");
		}
		else{
			if(f1||f2)
			printf("1");
		else if(f3)
			printf("2");
		else 
			printf("-1");
		}
	}

	return 0;
}
