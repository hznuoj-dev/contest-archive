#include<stdio.h>
int main()
{
	int t,i,n,x,s=0;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&x);
		for(i=0;i<1000000;i++)
		{
			s+=x;
			if(s>n)
				s=s-n;
			else if(s==n)
			{
				printf("yes\n");
				break;
			}
			else if(s<n)
				continue;
		}
		if(i==1000000)
			printf("no\n");
		s=0;
	}
	return 0;
}