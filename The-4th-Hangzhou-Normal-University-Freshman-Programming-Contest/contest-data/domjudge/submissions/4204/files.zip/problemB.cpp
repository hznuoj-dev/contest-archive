#include<stdio.h>
int main()
{
	int t;
	long int n;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%ld",&n);
		int a[n];
		long int i,j,k,l;
		int flag=0;
		for(i=0;i<n;i++) scanf("%d",&a[i]);
		for(j=0;j<n;j++)
		{
			for(k=j+1;k<n;k++)
			{
				for(l=k+1;l<n;l++)
				{
					if(a[j]+a[k]+a[l]==7777)
					flag++;
				}
			}
		}
		printf("%d\n",flag);
	}
}
