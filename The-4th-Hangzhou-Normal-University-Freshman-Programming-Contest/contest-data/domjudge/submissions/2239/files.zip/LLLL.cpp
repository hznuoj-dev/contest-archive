#include <stdio.h>

int main() {
	int t;
	long long int n, x;
	scanf("%d", &t);
	while (t--) {
		int flag = 0;
		scanf("%lld%lld", &n, &x);
		if (x == 0) {
			printf("no\n");
		} else {
			for (int i = 1; i < 10000; i++) {
				n = n * i;
				if (n % x == 0) {
					flag = 1;
				}
			}
		}

		if (flag == 1)
			printf("yes\n");
	}
	return 0;
}