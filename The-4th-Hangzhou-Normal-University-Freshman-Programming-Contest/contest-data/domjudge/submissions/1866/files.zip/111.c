/*#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int a[6000];
int main()
{
    int t;
    int sum;
    int flag=0;
    int i,j;
    int n;
    scanf("%d",&t);
    while(t--){
    	scanf("%d",&n);
    	for(i=0;i<n;i++){
    		scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			sum=a[i];
			if(sum==7777){
					flag++;
					continue;
			}
			for(j=i+1;j<n;j++){
				sum+=a[j];
                if(sum==7777){
					flag++;
					break;
			    }
		    	
			}
		}
		printf("%d\n",flag);
	}
	return 0;
}*/
#include<stdio.h>
#include<stdlib.h>
struct cao{
	int love;
	char name[20];
}a[100005],temp;
int main()
{
	int n;
	int k;
	int i,j;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i].love,&a[i].name);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++){
		int x=i;
		for(j=i+1;j<n;j++){
			if(a[x].love<a[j].love){
				x=j;
			}
		}
		if(x!=i){
			temp=a[i];
			a[i]=a[x];
			a[x]=temp;
		}
	}
	printf("%s",a[k].name);
	return 0;
}

