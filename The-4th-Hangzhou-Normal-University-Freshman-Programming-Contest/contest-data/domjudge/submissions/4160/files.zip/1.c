#include<stdio.h>

int main(){
	int n,m;//->n������,m����������̬
	int i;
	scanf("%d %d",&n,&m);
	int s[22];
	int a[22];
	for(i=1;i<=n;i++){
		scanf("%d",&s[i]);
		if(s[i]==0){
			scanf("%d",&a[i]);
		}
	}
	/////////////////////////////////////
	if(m==0){
		int flag=0;
		for(i=1;i<=n;i++){
			if(s[i]==0&&a[i]>=2500){
				for(i=1;i<=n;i++){
					if(s[i]==1){
						flag=1;
						break;
					}
				}
			}
		}
		///////////--->���޿���ĹѨ����
		for(i=1;i<=n;i++){
			if(s[i]==2){
				if(n-1>0){
					flag=1;
				}
			}
		}
		////////////////---->�ں˳��� 
		if(flag==1){
			printf("haoye\n");
		}
		else{
			printf("QAQ\n");
		}
	}
	
	
	else if(m==1){
		int flag=0;
		for(i=1;i<=n;i++){
			if(s[i]==0&&a[i]>2100){
				for(i=1;i<=n;i++){
					if(s[i]==1){
						flag=1;
						break;
					}
				}
			}
		}
		///////////--->���޿���ĹѨ����
		for(i=1;i<=n;i++){
			if(s[i]==2){
				if(n-1>0){
					flag=1;
				}
			}
		}
		////////////////---->�ں˳��� 
		if(flag==1){
			printf("haoye\n");
		}
		else{
			printf("QAQ\n");
		}
	}
	
	
	
	 
	 
	return 0;
} 
