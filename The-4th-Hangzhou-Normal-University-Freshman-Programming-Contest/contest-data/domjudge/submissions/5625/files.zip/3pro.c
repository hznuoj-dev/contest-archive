#include<stdio.h>
int main() {
	int t,x,n;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &n, &x);
		if (x == 0) printf("no\n");
		if (x != 0) printf("yes\n");
	}
	return 0;
}





