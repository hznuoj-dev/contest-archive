#include<stdio.h>
#include<string.h>
int main(void){
	int t,i,n,sum,x,y,n1;
	char s[100000],ch;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		n1=n;
		i=0;
		ch=getchar();
		s[0]=getchar();
		n-=1;
		sum=0;
		while(n--){
			ch=getchar();
			ch=getchar();
			if(i<0){
				i=0;
				s[i]=ch;
				x=2;
			}
			else{
			for(x=0;x<=i;x++){
				if(s[x]==ch){
					for(y=x;y<i;y++)
						s[y]=s[y+1];
					x=i;
					i-=1;
					sum+=1;
				}
			}
			if(x!=i+2){
				s[i+1]=ch;
				i+=1;
			}
			}
		}
		if(n1==1)
			printf("1\n");
		else if(i==n1-1)
			printf("1\n");
		else if(i<0)
			printf("%d\n",sum*2);
		else
			printf("%d\n",sum*2+1);
	}
return 0;
}