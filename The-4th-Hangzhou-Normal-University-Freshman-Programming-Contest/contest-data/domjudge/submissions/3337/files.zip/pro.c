#include<stdio.h>
int main(){
	struct sing{
		int x;
		char str[16];
	};
	struct sing s[100001];
	struct sing t;
	int n,i,k,j,l;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].x,s[i].str);	
	}
	for(i=0;i<n;i++){
		j=i;
		for(l=i+1;l<n;l++)
		   if(s[l].x>s[j].x)
		      j=l;
		t=s[i];
		s[i]=s[j];
		s[j]=t;
	}
	scanf("%d",&k);
	printf("%s",s[k].str);
	return 0;
}
