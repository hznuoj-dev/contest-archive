#include<stdio.h>
void cnm(int, int);
int main()
{
	int T, gs, qw;
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d", &gs, &qw);
		cnm(gs, qw);
	}
	return 0;
}
void cnm(int n, int y) {
	int x = 0, a = 0;
	for (int i = 0; i < 100; i++) {
		if (x + y >= n) {
			x = x + y - n;
		}
		x += y;
		if (x == 0) {
			a = 1;
			break;
		}
	}
	if (a == 0) {
		printf("yes\n");
	}
	if (a == 1) {
		printf("no\n");
	}
}
