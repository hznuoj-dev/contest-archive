#include<bits/stdc++.h>
using namespace std;
int like[100010]; 
int main(){
	int n,a;
	string s;
	scanf("%d",&n);
	map<int,string> m;
	for(int i=1;i<=n;i++){
		cin>>like[i]>>s;
		m[like[i]]=s;
	}
	sort(like+1,like+1+n);
	scanf("%d",&a);
	for(int i=n-a;i>=1;i--){
		cout<<m[like[i]]<<'\n';
	}
	return 0;
}
