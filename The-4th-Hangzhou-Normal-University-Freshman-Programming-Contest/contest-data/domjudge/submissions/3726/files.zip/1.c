#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
struct fe{
	char c;
	int a;
};
int main (){
	int t=0;
	char x;
	scanf("%d",&t);
	while(t--){
		int n=0,i=0,h=0,f=0,g=0;
		struct fe ff[100100];
		scanf("%d",&n);
		getchar();
		while(n--){
			scanf("%c",&x);
			if(x==' '){
				n++;
				continue;
			}
			g=0;
			for(i=0;i<f;i++){
				if(x==ff[i].c){
					ff[i].a++;
					g=1;
				}
			}
			if(g==0){
				ff[f].c=x;
				ff[f].a++;
				f++;
			}
		}
		for(i=0;i<f;i++){
			h=h+ff[i].a/2*2;
			ff[i].a=ff[i].a%2;
		}
		for(i=0;i<f;i++){
			if(ff[i].a==1){
				h++;
				break;
			}
		}
		printf("%d\n",h);
	}
	return 0;
}

