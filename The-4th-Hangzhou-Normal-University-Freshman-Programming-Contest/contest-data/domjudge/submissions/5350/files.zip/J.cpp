#include<bits/stdc++.h>
using namespace std;
int main(){
	long long i,n,zhuangtai,j,zhonglei,ATK,judge,success;//judge��ʾ�Ƿ����Ĺ��
	success=judge=0;//��ʼû��Ĺ�� 
	cin>>n>>zhuangtai;
	for(i=1;i<=n;i++){
		judge=0;//���� 
		cin>>zhonglei;
		if(zhonglei==0){
			cin>>ATK;
		if(zhuangtai==0){
			if(ATK>=2500){
				judge=1;//��Ĺ�� 
			}
		}else{
			if(ATK>2100){
				judge=1;
			}
		}
	    }
		if(zhonglei==1){
			if(judge==1){
				success=1;
				break;
			}
		}
		if(zhonglei==2){
			if(i<n&&judge==0){
				success=1;
				break;
			}
		}
	}
	if(success==1){
		cout<<"haoye";
	}else{
		cout<<"QAQ";
	}
	return 0;
}
