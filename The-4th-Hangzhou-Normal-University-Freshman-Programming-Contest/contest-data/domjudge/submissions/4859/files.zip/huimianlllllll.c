//#include<stdio.h>
//#include<stdlib.h>
//struct stu{
//		long long int x;
//		char a[20];
//	};
//	struct stu opp[100000],t;
//int comp(const void *p,const void *q)
//{
//	return ((struct stu *)p)->x - ((struct stu *)q)->x;
//}
//int main()	
//{	
//	
//	int n,i,j,k;
//	scanf("%d",&n);
//	for(i=0;i<n;i++)
//	{
//		scanf("%lld %s",&opp[i].x,opp[i].a);
//	}
//	scanf("%d",&k);
//    for(i=0;i<n;i++)
//	qsort(opp,n,sizeof(long long int),comp);
//	for(i=0;i<n;i++)
//	{
//		printf("%lld %s\n",opp[i].x,opp[i].a);
//	}
//	printf("%s\n",opp[k].a);
//	return 0;
//}
#include<stdio.h>
int main()
{
	int n,m,i,ac,flag=0,j;//ac�ǹ����� 
	int type[15];
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%d",&type[i]);
		if(type[i]==0)
		{
			scanf("%d",&ac);
		} 
	}
	if(n==0||n==1) printf("QAQ");
    else
    {
    	for(i=0;i<n;i++)
    	{
    		if(type[i]==2)
    		{
    			printf("haoye");
    			flag=1;
    			break;
			}
			else
			{ 
			if(type[i]==0&&m==0&&ac>=2500)
				{
					for(j=0;j<n;j++)
					{
						if(type[j]==1)
						{
							printf("haoye");
							flag=1;
							break;
						}
					}
					//if(type[j]!=1) printf("QAQ");
				}
//			if(type[i]==0&&m==0&&ac<2500)
//			  printf("QAQ");
			  if(type[i]==0&&m==1&&ac>2100)
			  {
			  	for(j=0;j<n;j++)
			  	{
			  		if(type[i]==1)
			  		{
			  			printf("haoye");
			  			flag=1;
			  			break;
					  }
				  }
				 // if(type[j]!=1) printf("QAQ");
			  }
			  //
			}
		}
		if(flag==0) printf("QAQ");
	}
	return 0;
 } 

