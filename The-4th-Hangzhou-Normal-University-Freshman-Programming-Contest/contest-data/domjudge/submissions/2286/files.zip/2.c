#include <stdio.h>
int main(void){
	int t,n,i,c,d,j;
	int a[100000];
	scanf("%d",&t);
	while(t--){
		c=0;
		d=0;
		j=0;
		scanf("%d",&n);
		for(i=0;i<n;++i){
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;++i){
			d+=a[i];
			j++;
			if(d==7777){
				c++;
				i=j-i;
				j=0;
				d=0;
			}
			if(d>7777){
				i=j-i;
				d=0;
				j=0;
			}
		}
		printf("%d\n",c);
	}
	return 0;
} 
