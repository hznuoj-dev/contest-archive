#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
int a1[30][30],a2[30][30];
int main(){
	int n,m;
	scanf("%d",&m);
	for(int k=1;k<=m;k++){
		scanf("%d",&n);
		for(int x=1;x<=n;x++){
			for(int y=1;y<=n;y++){
				scanf("%d",&a1[x][y]);
			}
		}
		for(int x=1;x<=n;x++){
			for(int y=1;y<=n;y++){
				scanf("%d",&a2[x][y]);
			}
		}
		int a=1,b=1,c=1,d=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(a1[i][j]!=a2[i][j]) a=0;
				if(a1[i][j]!=a2[j][n-i+1]) b=0;
				if(a1[i][j]!=a2[n-j+1][i]) c=0;
				if(a1[i][j]!=a2[n-i+1][n-j+1]) d=0;                                                                                                                                                                                                                                                                                                                                                                                                                                                
			}
		}
		if(a==1) printf("0\n");
		else if(b==1||c==1) printf("1\n");
		else if(d==1) printf("2\n");
		else printf("-1\n");
	}
	
	
	return 0;
}
