#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int main(){
	int n,atk,zl,fh,hh=0,mx=0,s=0,nn;
	scanf("%d %d",&n,&fh);
	nn=n;
	while(nn--){
		scanf("%d",&zl);
		if(zl==0){
			scanf("%d",&atk);
			if(fh==0){
				if(atk>=2500){
					s=1;
				}
			}else{
				if(atk>=2100){
					s=1;
				}
			}
		}
		if(zl==1)mx=1;
		if(zl==2)hh=1;
	}
	if((s==1&&mx==1)||(hh==1&&n>1)){
		printf("haoye");
	}else{
		printf("QAQ");
	}
}