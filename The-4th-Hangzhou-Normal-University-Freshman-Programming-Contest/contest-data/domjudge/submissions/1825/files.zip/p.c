#include <stdio.h>
int main()
{
	int a,b,c,d,e;
	scanf("%d",&a);
	while(a--)
	{
		scanf("%d %d",&b,&c);
		if(c==0)
			printf("no\n");
		else
			printf("yes\n");
	}
	return 0;
}