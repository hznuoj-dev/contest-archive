#include<bits/stdc++.h>
using namespace std;

int main () {
	int t;
	int a,b;
	cin>>t;
	for(int i = 1; i <= t; i++) {
		cin>>a>>b;
		if(b==0){
			cout<<"no";
		}else{
			cout<<"yes";
		}
		cout<<"\n";
	}
	return 0;
}
