#include<stdio.h>
int main(){
	int T, n, i, a[1000];
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		
	}
} 
