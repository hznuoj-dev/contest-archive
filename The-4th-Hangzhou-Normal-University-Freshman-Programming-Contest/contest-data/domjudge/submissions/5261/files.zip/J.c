#include <stdio.h>
int main(void){
	int i,n,m,s1,s2,flag,live1=1,live2=1,win=1;
	scanf("%d%d",&n,&m);
	if(m=0)
	{
		s1=2500;
	}
	else 
		s1=2100;
	for(i=0;i<n;i++)
	{
		scanf("%d",&flag);
		if(flag==0)
		{
			scanf("%d",&s2);
			if(s2>s1)
			{
				live1=0;
			}
		}
		else if(flag==1)
		{
			live2=0;
		}
		else if(flag==2)
		{
			if(n>1)
				win=0;
		}	
	}
	if(live1==0&&live2==0)
	{
		win=0;
	}
	if(win==0)
	{
		printf("haoye\n");
	}
	else
		printf("QAQ\n");
	return 0;
}

