#include <stdio.h>
long long *right(long long *a,int n);
long long *left(long long *a,int n);
int comp(long long *a,long long *b,int n);
int main(void)
{
	int t,ans,ans1;
	scanf("%d",&t);
	while(t--)
	{
		int n;
		ans=-1;
		ans1=-1;
		scanf("%d",&n);
		long long a[n+1][n+1],b[n+1][n+1],c[n+1][n+1];
		long long *x,*y,*z;
		x=b;
		y=a;
		z=c;
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				scanf("%lld",y+((i-1)*n+j));
			}
		}
		for(int i=0;i<n;i++)
		{
			for(int j=0;j<n;j++)
			{
				scanf("%lld",z+((i-1)*n+j));
			}
		}		
		if(comp(y,z,n))
		{
			printf("0\n");
			continue;
		}
		x=right(y,n);
		if(comp(z,x,n))
		{
			ans=1;
		}
		else
		{
			for(int i=2;i<4;i++)
			{
				x=right(x,n);
				if(comp(z,x,n))
				{
					ans=i;
					break;
				}
			}			
		}
		x=left(y,n);
		if(comp(z,x,n))
		{
			ans1=1;
		}
		else
		{
			for(int i=2;i<4;i++)
			{
				x=left(y,n);
				if(comp(z,x,n))
				{
					ans1=i;
					break;
				}
			}			
		}
		if(ans1<ans)
		{
			printf("%d\n",ans1);
		}
		else
		{
			printf("%d\n",ans);
		}
		

		
	}
	return 0;
}
long long *right(long long *a,int n)
{
	long long *b;
	b=(long long*)malloc((n*n)*sizeof(long long));
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			*(b+(i-1)*n+j)=*(a+(n+1-j-1)*n+i);
		}
	}
	return b;
}
long long *left(long long *a,int n)
{
	long long *b;
	b=(long long*)malloc((n*n)*sizeof(long long));
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			*(b+(i-1)*n+j)=*(a+(j-1)*n+n+1-i);
		}
	}
	return b;
}
int comp(long long *a,long long *b,int n)
{
	int flag=1;
	for(int i=1;i<=n;i++)
	{
		for(int j=1;j<=n;j++)
		{
			if(*(a+(i-1)*n+j)!=*(b+(i-1)*n+j))
			{
				flag=0;
				break;
			}
		}
	}
	return flag;
}
