#include<stdio.h>
int a[130];
int main(){
	int i,number,n,x,sum,j,K;
	char ch;
	scanf("%d",&number);
	for(i=1;i<=number;i++){
		scanf("%d",&n);
		sum=0;
		while(n!=0){
			scanf("%c",&ch);
			if(ch>='A'&&ch<='Z'||ch>='a'&&ch<='z'){
			a[ch]++;n--;}
		}
		for(K='A';K<='z';K++){
			if(a[K]>0&&a[K]%2==0) sum+=a[K];
			a[K]=0;
		}
		printf("%d\n",sum+1);
	}
	return 0;
}
