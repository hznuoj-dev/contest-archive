#include<stdio.h>
int main(void){
	int n,k,i,j,c;
	scanf("%d",&n);
	long a[n+1],e;
	char b[n+1][16];
	for(i=0;i<n;i++){
		scanf("%ld",&a[i]);
		getchar();
		scanf("%s",b[i]);
	}
		scanf("%d",&k);
	if(k<n){
	for(i=0;i<=k;i++){
		e=-1;
		for(j=0;j<n;j++){
			if(a[j]>e){
					c=j;
					e=a[j];
				}
			}
		a[c]=-100;
	}
		printf("%s",b[c]);
}
	return 0;
}
