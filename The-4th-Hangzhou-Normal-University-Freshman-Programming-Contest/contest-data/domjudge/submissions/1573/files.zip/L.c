#include<stdio.h>
int main(){
	int t;
	long long int a,b;
	scanf("%d",&t);
	while(t--){
		scanf("%lld %lld",&a,&b);
		if(b==0||a==0){
			printf("no\n");
		}
		else if(a*2%b==0){
			printf("yes\n");
		}
		else{
			printf("no\n");
		}
	}
	return 0;
}
