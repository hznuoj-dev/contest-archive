#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n,m,tmp,rr;
	int k,atk,def,zhi=0,hei=0;
	cin>>n>>m;
	tmp=n;
	while(tmp--)
	{
		if(hei==1&&n-tmp>=2)
		{
			cout<<"haoye";
			return 0;
		}
		cin>>k;
		if(k==1)
		{
			zhi=1;
		}
		else if(k==2)
		{
			hei=1;
		}
		else if(k==0)
		{
			cin>>rr;
			if(m==0)
			{
				if(rr>=2500&&zhi==1)
				{
					cout<<"haoye";
					return 0;
				}
				
			}
			else
			{
				if(rr>2100&&zhi==1)
				{
					cout<<"haoye";
					return 0;
				}
			}
		}
		
	}
	if(m==0)
	{
		if(rr>=2500&&zhi==1)
		{
			cout<<"haoye";
			return 0;
		}
				
	}
	else
	{
		if(rr>2100&&zhi==1)
		{
			cout<<"haoye";
			return 0;
		}
	}	
	cout<<"QAQ";
	
}
