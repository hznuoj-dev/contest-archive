#include<stdio.h>
void cnm(int, int);
int main()
{
    int T, gs, qw;
    scanf("%d", &T);
    while (T--) {
        scanf("%d %d", &gs, &qw);
        cnm(gs, qw);
    }
    return 0;
}
void cnm(int x, int y) {
    int all = x;
    if (y == 0) {
        all = 0;
    }
    for (int i = 0; i < 2000; i++ ) {
        all -= y;
        if (all < 0) {
            all += x;
        }
        if (all == 0) {
            break;
        }
    }
    if (all == 0) {
        printf("yes\n");
    }
    else {
        printf("no\n");
    }
}
