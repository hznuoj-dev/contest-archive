#include<bits/stdc++.h>

using namespace std;

int t,n;
int a[100005];
int head,tail;

int main()
{
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;++i){
			scanf("%d",&a[i]);
		}
		head = 1;tail = 1;
		int ans = 0,sum = a[1];
		while(tail<=n && head<=n){
			if(sum == 7777){
				ans++;
			}
			if(sum >= 7777){
				sum -= a[head];
				head++;
			}if(sum < 7777){
				tail++;
				sum += a[tail];
			}
		}
		printf("%d\n",ans);
	}
}
