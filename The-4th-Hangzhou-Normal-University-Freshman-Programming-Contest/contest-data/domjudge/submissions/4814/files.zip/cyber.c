#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int a[100008];
char b[100008];
int main(){
int n,i,k,t,j,ret,f;
int sum;
scanf("%d",&t);
while(t--){
	ret=0;
	sum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++){
	
		sum=0;
		for(j=i;j<n;j++)
		{
			sum+=a[j];
			if(sum>=7777)
			{
				break;
			}
			
		}
		if(sum==7777)
			ret++;
	}
	printf("%d\n",ret);
}
return 0;
}

