#include<stdio.h>
struct o{
	int a;
	char b[16];
};
struct o oa[100000];
int main()
{
	int n,i,j,t;
	
	struct o ot;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&oa[i].a,&oa[i].b);
	}
	scanf("%d",&t);
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(oa[j].a<oa[j+1].a)
			{
				ot=oa[j];
				oa[j]=oa[j+1];
				oa[j+1]=ot;
			}
		}
	}
	printf("%s\n",oa[t].b);
	return 0;
}
