#include <stdio.h>
#include <stdlib.h>
int comp(const void *p,const void *q){
	return (*(int*)p-*(int*)q);
}
struct cs{
	int a;
	char arr[16];
};
int b[100000];
struct cs s[100000];
int main(void)
{
	int n;
	scanf("%d",&n);
	int i;
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].a,&s[i].arr);
		b[i]=s[i].a;
	}
	qsort(b,n,sizeof(int),comp);
	int k;
	scanf("%d",&k);
	int j;
	
	int m=b[n-k-1];
	for(i=0;i<n;i++){
		if(m==s[i].a){
			printf("%s",s[i].arr);
			break;
		}
	}
	return 0;
}
