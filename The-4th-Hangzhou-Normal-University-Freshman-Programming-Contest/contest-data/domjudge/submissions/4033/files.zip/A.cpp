#include<bits/stdc++.h>
using namespace std;
long long a[10010];
int main(){
	long long n,i,m,j,count,amount,max;
	char c;
	cin>>n;
    for(i=1;i<=n;i++){
    	cin>>m;
    	max=0;
    	count=0;
    	for(j=0;j<=57;j++){
    		a[j]=0;
		}
    	for(j=1;j<=m;j++){
    		cin>>c;
    	    a[c-'A']++;
        }
        for(j=0;j<=57;j++){
        	if(a[j]%2==0&&a[j]!=0){
        		count+=a[j];
			}else if(a[j]%2!=0&&a[j]!=0){
				count=(a[j]/2)*2+count;
				max++;
			}
		}
        amount=count+1;
		cout<<amount<<"\n";
	}
	return 0;
}
