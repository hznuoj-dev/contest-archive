#include<stdio.h>
int main(){
	int T,n,a[5000],sum=0,total=0;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(int i=0;i<n;i++)
			scanf("%d",&a[i]);
		for(int i=0;i<n;i++){
			for(int j=i;j<n;j++){
				sum+=a[j];
				if(sum==7777)
					total++;
				else if(sum>7777)
					break;
			}
			sum=0;
		}
		printf("%d",total);
		total=0;
	}
	return 0;
}
