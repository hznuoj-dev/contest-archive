#include<bits/stdc++.h>
#define res register int
#define N 100050
#define inf 0x3f3f3f3f
using namespace std;
int n,m,p,q,t,head,tail,total,sum;
int a[N];
int main()
{
	scanf("%d",&t);
	while(t>0)
	{
		scanf("%d",&n);
		for(res i=1;i<=n;i++)
		scanf("%d",&a[i]);
		sum=0;
		head=1;tail=1;
		total=a[1];
		while(head<n)
		{
			if(total>7777) total-=a[head],head++;
			if(total==7777) total-=a[head],head++,sum++;
			tail++;
			total+=a[tail];
			if(total>7777) total-=a[head],head++;
			if(total==7777) total-=a[head],head++,sum++;
			if((tail==n)and(total<7777)) break;
		}
		printf("%d\n",sum);
		t--;
	}
}
