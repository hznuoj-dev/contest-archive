#include <stdio.h>
#include <stdlib.h>
#include <math.h>
struct ko{
	long long int m;
	char l[40];
}; 
int mp(const void *p,const void *q)
{
	
	struct ko *pp =(struct ko *)p;
	struct ko *pq = (struct ko *)q;
	int a= pp->m ;
	int b= pq->m ;
	return b-a;
}
int main()
{
	struct ko a[100000000];
	int n, i, k;
	scanf("%d", &n);
	for(i=0;i<n;++i)
	{
		scanf("%d %s", &a[i].m ,a[i].l );
 	}
	scanf("%d", &k);
 	qsort(a,n,sizeof(struct ko ),mp);
 	printf("%s\n", a[k].l );
	
}
