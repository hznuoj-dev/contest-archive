#include<stdio.h>
#include<string.h>
int main()
{
	int T, n, song[100001], i, j, count, sum;
	scanf("%d", &T);

		while (T--)
		{
			count = 0;
			sum = 0;
			scanf("%d", &n);

			for (i = 1; i <= n; i++)
			{
				scanf("%d", &song[i]);
			}
			for (i = 1; i <= n; i++)
			{
				for (j = i; j <= n; j++)
				{
					sum += song[j];
					if (sum == 7777)
						count++;
				}
				sum = 0;

			}
			printf("%d\n", count);

		}
}
