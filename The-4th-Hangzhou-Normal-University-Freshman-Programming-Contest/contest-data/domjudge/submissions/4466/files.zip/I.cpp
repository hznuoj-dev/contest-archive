#include <bits/stdc++.h>
using namespace std;

string s[100001];
int a[100001];


int main()
{
	int n;
	int i,j,k,num;
	int t1;
	string t2;
	
	cin >> n;
	for(i=1;i<=n;i++)
		cin >> a[i] >> s[i];
	cin >> num;
	for(i=1;i<=n-1;i++)
	{
		k=i;
		for(j=k+1;j<=n;j++)
			if(a[j]>a[k])
				k=j;
		if(k!=i)
		{
			t1=a[i];a[i]=a[k];a[k]=t1;
			t2=s[i];s[i]=s[k];s[k]=t2;
		}
	}
	
	cout << s[num+1];
	return 0;
}
