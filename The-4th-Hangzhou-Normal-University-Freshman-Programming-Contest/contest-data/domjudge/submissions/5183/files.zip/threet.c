#include<stdio.h>
int main(){
	int t,n;
	scanf("%d",&t);
	while(t--){
		int k=0,pj;
		scanf("%d",&n);
		int a[n];
		int i,j,sum1=0,sum;
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
			sum1=sum1+a[i];
		}
		if(sum1>7777){
		for(i=0;i<n;i++){
			sum=0;
			for(j=i;j<n;j++){
				sum=sum+a[j];
				if(sum==7777){
					k++;
					break;
				}
				else if(sum>7777){
					break;
				}
			}		
		}
	    }
		printf("%d\n",k);
	}
}
