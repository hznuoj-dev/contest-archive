#include <stdio.h>
#include <stdlib.h>
struct music {
	long long int a;
	char b[20];
}m[100000];
int comp(const void *p,const void *q){
	return ((struct music *)q)->a-((struct music *)p)->a;
}
int main(void){
	int T,i;
	int k;
	scanf("%d",&T);
	for(i=0;i<T;i++){
		scanf("%lld%s",&m[i].a,&m[i].b);
	}
	scanf("%d",&k);
	qsort(m,T,sizeof(struct music),comp);
	for(i=0;i<T;i++){
		if(i==k) printf("%s",m[i].b);
	}
	return 0;
}










