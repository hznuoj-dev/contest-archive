#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#include<queue>
#define MogeKo qwq

using namespace std;

const int maxn = 1e5+10;

int t,n,L,R,sum,ans,a[maxn];

int main() {
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i = 1;i <= n;i++)
			scanf("%d",&a[i]);
		L = R = 1;
		sum = ans = 0;
		for(int i = 1;i <= n;i++){
			sum += a[R++];
			while(sum > 7777)
				sum -= a[L++]; 
			if(sum == 7777) ans++;
		}
		printf("%d\n",ans);	
	}
	return 0;
}
