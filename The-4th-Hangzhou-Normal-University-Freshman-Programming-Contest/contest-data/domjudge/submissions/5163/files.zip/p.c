#include <stdio.h>
int s[100004]={0};
int main()
{
	int a,b,c,d,i,p;
	scanf("%d",&a);
	while(a--)
	{
		d=0;
		scanf("%d",&b);
		for(i=0;i<b;i++)
			scanf("%d",&s[i]);
		for(i=0;i<b;i++)
		{
			c=s[i];
			for(p=i+1;p<=b;p++)
			{
				if(c==7777)
				{
					d=d+1;
					break;
				}
				else if(c>7777)
					break;
				c=c+s[p];
			}
		}
		for(i=0;i<b;i++)
			s[i]=0;
		printf("%d\n",d);
	}
	return 0;
}