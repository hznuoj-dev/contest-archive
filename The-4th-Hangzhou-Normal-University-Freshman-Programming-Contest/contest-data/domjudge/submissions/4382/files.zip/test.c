#include<stdio.h>
main() {
	int n,i,a[100000],m,j=0,k,tem;
	char b[100000][15];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		scanf("%s", &b[i]);
	}
	scanf("%d", &k);
	for (i = 0; i < n; i++) {
		for (m = i + 1; m < n; m++) {
			if (a[i] < a[m]) {
				tem = a[i];
				a[i] = a[m];
				a[m] = tem;
			}
		}
	}
	for (i = 0; i < n; i++) {
		if (i > k) {
			j = i;
		}
	}
	printf("%s", b[j]);
}