#include <stdio.h>
int main(){
	int t,n,i,s,max,m;
	char x,y;
	int c[52];
	scanf("%d",&t);
	while(t--){
		for(i=0;i<52;i++){
			c[i]=0;
		}
	scanf("%d",&n);
	for(i=0;i<n;i++){
		if(i==0){
			getchar();
		scanf("%c",&x);
		}
		else
		scanf("%c%c",&y,&x);
		if(x>='a'&&x<='z'){
			m=x-'a'+26;
		}
		else if(x>='A'&&x<='Z'){
			m=x-'A';
		}
		c[m]=c[m]+1;
	}
	max=0;
	s=0;
	for(i=0;i<52;i++){
		if(c[i]%2==0&&c[i]!=0)
		s=s+c[i];
		else if(c[i]%2==1&&c[i]>max){
			s=s-max+c[i];
		    max=c[i];
		}
	}
	printf("%d\n",s);
	}
	return 0;
} 
