#include<stdio.h>
int main (){

int T,a,b;
scanf("%d",&T);
while(T--)
{
	scanf("%d %d",&a, &b);
		 if(b == 0)
	{
		printf("no");
	}
	
	if(2 * a % b == 0){
		printf("yes");
		
	}
     else 
	{
		printf("no");
	}
}

}
