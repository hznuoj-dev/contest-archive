//#include<iostream>
//#include<string>
//#include<cstring>
//#include<algorithm>
//#include<cmath>
//#include<ctype.h>
//using namespace std;
//
//int main()
//{
//	
//	//system("pause");
//}









//#include<iostream>
//#include<string>
//#include<cstring>
//#include<algorithm>
//#include<cmath>
//#include<ctype.h>
//using namespace std;
//
//int main()
//{
//	int t;
//	cin>>t;
//	while(t--)
//	{
//		int n;
//		cin>>n;
//		int a[22][22]={0};
//		int b[22[22]={0};
//		for(int i=1;i<=n;i++)
//		{
//			for(int w=1;w<=n;w++)
//			{
//				cin>>a[i][w];
//			}
//		}
//		for(int i=1;i<=n;i++)
//		{
//			for(int w=1;w<=n;w++)
//			{
//				cin>>b[i][w];
//			}
//		}
//		int i;
//		for(i=1;i<5;i++)
//		{
//			int c[1][22]
//			for(w=2;w<=n;w++)
//			{
//				a[w-1][1]=a[w][1]; 
//			} 
//			for(w=2;w<=n;w++)
//			{
//				a[w-1][1]=a[w][1]; 
//			} 
//		}
//	}
//	//system("pause");
//}











#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	for(int w=0;w<t;w++)
	{
		int n;
		cin>>n;
		int a[100005];
		int sum=0;
		for(int i=0;i<n;i++)
		{
			cin>>a[i];
			int num=0;
			for(int s=i;s>=0;s--)
			{
				num+=a[s];
				if(num==7777)
				{
					sum++;
					break;
				}
				if(num>=7777)
				break;
			}
		}	
		cout<<sum<<endl;
	}
	//system("pause");
}
