#include<stdio.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int n,i,j,sum=0;
		int a[100001];
		scanf("%d",&n);
		for(i=0;i<n;++i)
		{
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;++i)
		{
			for(j=i;j<n;++j)
			{
				if (a[i]+a[j]==7777)
				sum++;
			}
		}
		printf("%d",sum);
	}
	return 0;
} 
