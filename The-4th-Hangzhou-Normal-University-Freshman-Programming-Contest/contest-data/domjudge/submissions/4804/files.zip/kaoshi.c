# include <stdio.h>

long int a[100001], t, c[100001];
char str[100001][16];

int main(void)
{
	int n, i, j, k;
	 	
	scanf("%d", &n);

	for(i=0; i<n; i++)
	{
		scanf("%ld", &a[i]);
		getchar();
		
		gets(&str[i][0]);
	}

	scanf("%d", &k);

	for(i=0; i<n; i++)
		c[i] = a[i];

	for(i=0; i<n-1; i++)
		for(j=0; j<n-1-i; j++)
			if(c[j]<c[j+1])
			{
				t = c[j];
				c[j] = c[j+1];
				c[j+1] = t;
			}

	for(i=0; i<n; i++)
		if(a[i] = c[k])
		{
			printf("%s\n",str[i]);
			
			break;
		}
	return 0;
}