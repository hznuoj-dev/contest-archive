#include<stdio.h>
#include<string.h>
main(){
	int f,j,i,n,T;char c[300000],b[1000][30],a[1000][30];
	scanf("%d",&T);
	while(T--)
	{

}
