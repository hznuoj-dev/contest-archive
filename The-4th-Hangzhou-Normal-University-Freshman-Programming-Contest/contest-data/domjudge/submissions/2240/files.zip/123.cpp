# include <stdio.h>
int main(void)
{
	int t;
	long long n;
	long long x;
	scanf("%d",&t);
	while (t--)
	{
		scanf("%lld%lld",&n,&x);
		if (x==0)
			printf("no\n");
		else if (n>x)
		{
			if (n%x<x)
				printf("yes\n");
		}
		else if (n==x)
			printf("yes\n");
		else if (x>n)
		{
			if (x%n<n)
				printf("yes\n");
		}
	
	}
	
	
	
	return 0;
}
