#include <stdio.h>
int main()
{
	int t,x,n;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&x);
		if(n%x==0||2*n%x==0)
			printf("yes\n");
		else
			printf("no\n");	
	}
}
