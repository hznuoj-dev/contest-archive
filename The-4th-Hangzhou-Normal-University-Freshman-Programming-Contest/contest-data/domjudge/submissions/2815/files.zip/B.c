#include <stdio.h>
#include <string.h>
#include <math.h>
int main ()
{
    int t,a[10005],n,i,j,k;
    scanf("%d",&t);
    while(t--)
    {
        int x=0;
        long long sum=0;
     scanf("%d",&n);
     for(i=0;i<n;i++)
     {
     scanf("%d",&a[i]);
     }
     int l=0,r=0;
     sum=a[0];
     while(r<n)
     {
         while(sum>7777)
         {
             sum=sum-a[l];
             l++;
         }
         if(sum==7777)
            x++;
         r++;
         sum=sum+a[r];
     }
    printf("%d\n",x);
    }
}
