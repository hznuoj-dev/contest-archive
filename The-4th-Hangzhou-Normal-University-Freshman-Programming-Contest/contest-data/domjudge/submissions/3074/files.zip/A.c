#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 
#include<ctype.h> 
int main()
{
	int length,i,t,n,m,flag1,flag[100005];
	char s[100005],k;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d",&n);
		m=0;length=0;
		memset(flag,0,sizeof(flag));
		while(n)
		{
			scanf("%c",&k);
			if(isalpha(k))
			{
				s[m++]=k;
				n--;
			}
		}
		for(i=0;i<m;i++)
		{
			flag[s[i]-'A'+1]++;
		}
		for(i=0;i<70;i++)
		{
			if(flag[i]%2==0)
				length+=flag[i];
		}
		int max=0;
		for(i=0;i<70;i++)
		{
			if((flag[i]==1||flag[i]%2==1)&&flag[i]>max)
			{
				max=flag[i];
			}
		}
		printf("%d\n",length+max);
	}
	return 0;
}
