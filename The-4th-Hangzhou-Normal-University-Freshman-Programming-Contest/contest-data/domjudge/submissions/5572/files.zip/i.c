#include<stdio.h>
int a[10100]; 
struct gm{
	int w;
	char s[16];
}name[10100];
int main(void)
{
	int n,i,j,t,k;
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%d%s",&name[i].w ,name[i].s );
	}
	for(i=0;i<n;++i)
	{
		a[i]=name[i].w ;
	}
	for(i=0;i<n;++i)
	{
		for(j=0;j<n-i;++j)
		{
			if(a[j]<a[j+1])
			{
				t = a[j];
				a[j] = a[j+1];
				a[j+1] = t;
			} 
		}
	}
	scanf("%d",&k);
	for(i=0;i<n;++i)
	{
		if(a[k]==name[i].w )
		{
			printf("%s\n\n",name[i].s );
		}
	}
	return 0;
}
