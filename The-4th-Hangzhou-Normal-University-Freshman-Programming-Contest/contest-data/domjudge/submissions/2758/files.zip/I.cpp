#include<stdio.h>
struct gequ{
  long long int redu; 
  char name[15];
};
int main(){
 struct gequ a[100010];
 int T,k;
 scanf("%d",&T);
 for(int i=1;i<=T;i++){
  scanf("%lld %s",&a[i].redu,a[i].name);
 }
 for(int i=1;i<=T;i++){
	 for(int j=T;j>i;j--){
		 if(a[j].redu>a[j-1].redu){
		   struct gequ temp;
		   temp=a[j];
		   a[j]=a[j-1];
		   a[j-1]=temp;
		 }
	 }
 }
 scanf("%d",&k);
 printf("%s\n",a[k+1].name);
}