#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#define MogeKo qwq

using namespace std;

const char s1[] = "+------+";
const char s2[] = "--------+";

int n,m;
int x,cnt,a[10];
bool flag;

void pline() {
	printf("%s",s1);
	for(int i = 0; i < n; i++)
		printf("%s",s2);
	printf("\n");
}

void insert() {
	scanf("%d",&x);
	flag = false;
	for(int j = 1; j <= cnt; j++) {
		if(flag) {
			a[j-1] = a[j];
			if(j == cnt) a[j] = x;
		}
		if(a[j] == x) flag = true;
	}
	if(!flag) {
		if(cnt < n) a[++cnt] = x;
		else {
			for(int i = 1; i <= cnt; i++)
				a[i-1] = a[i];
			a[cnt] = x;
		}
	}
}

int main() {
	scanf("%d%d",&n,&m);
	pline();
	printf("|      |");
	for(int i = 0; i < n; i++)
		printf("  0x%02x  |",i);
	printf("\n");
	pline();
	for(int i = 0; i < m; i++) {
		insert();
		printf("| 0x%02x |",i);
		for(int i = 1; i <= cnt; i++)
			printf(" 0x%04x |",a[i]);
		for(int i = cnt+1; i <= n; i++)
			printf("        |");
		printf("\n");
		pline();
	}
	return 0;
}

