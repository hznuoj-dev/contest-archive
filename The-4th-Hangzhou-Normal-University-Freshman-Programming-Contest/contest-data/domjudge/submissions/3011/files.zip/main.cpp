#include <stdio.h>
#include <stdlib.h>
struct xh{
	long long b;
	char a[10000];
};
int cump(const void *p, const void *q){
	return ((*(struct xh *)p).b-(*(struct xh *)q).b);
}

int main(){
int i,m;
long long t;
struct xh n[10000];
scanf("%lld",&t);
printf("%lld",t);
for(i=0;i<t;i++){
	scanf("%lld %s",&n[i].b,n[i].a);
}
scanf("%d",&m);
qsort(n,t,sizeof(struct xh),cump);
printf("%s",n[t-m-1].a);
return 0;
}















