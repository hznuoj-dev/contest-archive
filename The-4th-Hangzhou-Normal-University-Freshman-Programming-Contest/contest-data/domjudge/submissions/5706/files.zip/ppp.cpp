#include<stdio.h> 
int main()
{	
  int n;
 int t,i,p,j;
 
 scanf("%d",&t);
 while(t--)
 {
 	p=0;
 	scanf("%d",&n);
 	char c[n];
 	getchar();
 	for(i=0;i<n;++i)
 	{
 		scanf("%c",&c[i]);
 		getchar();
	}
	for(i=0;i<n;++i)
		{
			for(j=i+1;j<n;++j)
			{
				if(c[i]==c[j]&&c[i]!='0')
				{
					c[i]=c[j]='0';
					p=p+1;
					break;
				}
			}
		}
	if((2*p+1)<=n)
	{
		printf("%d\n",2*p+1); 
	}
	else
	printf("%d\n",n);
    }
}
