//#include<stdio.h>
//	int main()
//	{
//		int n,i;
//		scanf("%d",&n);
//		for(i=0;i<n;i++)	printf("Welcome to HZNU\n");
//		return 0;
//	}
//#include<stdio.h>
//char a[100001];
//	int main()
//	{
//		int t,n,i;
//		scanf("%d",&t);
//		while(t--)
//		{
//			scanf("%d",&n);
//			for(i=0;i<n;i++)
//			{
//				scanf("%d",&a[i]);
//			}
//		}
//		return 0;
//	}
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
struct sibao
{
	long long int w[10];
	char s[20];	
}a[100001];
	int main()
	{
		int n,i,j,k,m;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%lld %s",a[i].w,a[i].s);
		}
		scanf("%d",&m);	
//		for(i=0;i<n;i++)
//		{
//			k=i;
//			for(j=i+1;j<n;j++)
//			{
//				if(strlen(a[k].w)<strlen(a[j].w))	k=j;
//				else if(strlen(a[k].w)==strlen(a[j].w)&&strcmp(a[k].w,a[j].w)<0)	k=j;
//			}
//			if(k!=i)	//����w[k]��w[i],����s[k]��s[i] 
//			{
//				temp=a[k];
//				a[k]=a[i];
//				a[i]=temp;
//			}
//		} 
		//for(i=0;i<n;i++)	printf("%s %s\n",a[i].w,a[i].s);
		qsort(&a[0].w,n,sizeof(struct sibao),comp);
		//for(i=0;i<n;i++)	printf("%s %s\n",a[i].w,a[i].s);
		printf("%s\n",a[m].s); 
		return 0;
	}
int comp(const void *p,const void *q)
{
	return (*(int *)q-*(int *)p);
}
