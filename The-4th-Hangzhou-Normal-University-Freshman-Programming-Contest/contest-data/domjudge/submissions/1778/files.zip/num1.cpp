#include<stdio.h>
#include<string.h>
#include<math.h>
int main(){
	int T;
	scanf("%d",&T);
	int n;
	while(T--){
	char str[100001];
    int mark[100001];
    scanf("%d",&n); 
	for(int i=0;i<n;i++){
	  scanf(" %c",&str[i]);
	  mark[i]=1;
	}
	int j=0;
	for(int i=0;i<n;i++){
		if(mark[i]==1){
			for(j=i+1;j<n;j++){
				if(mark[j]==1&&str[i]==str[j]){
				  mark[j]=0;
				  mark[i]=0;
				  break;
				}
			}
		}
	}
	int sum=0;
	int flag=0;
	for(int i=0;i<n;i++){
		if(mark[i]==0){
		  sum+=1;
		}
		else{
		 flag=1;
		}
	}
	if(sum==0){
	 printf("1\n");
	}
	else if(sum!=0&&flag==1){
		printf("%d\n",sum+1);
	}
	else if(sum!=0&&flag==0){
	   printf("%d\n",sum);
	}
	}
}