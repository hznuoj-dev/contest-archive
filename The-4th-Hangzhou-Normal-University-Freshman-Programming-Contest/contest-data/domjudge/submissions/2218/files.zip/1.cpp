#include<bits/stdc++.h>
using namespace std;

int main(){
	int t,a,b;
	scanf("%d",&t);
	for(int i=1;i<=t;i++){
		scanf("%d%d",&a,&b);
		if(b!=0) printf("yes\n");
		else printf("no\n");
	}
	return 0;
}
