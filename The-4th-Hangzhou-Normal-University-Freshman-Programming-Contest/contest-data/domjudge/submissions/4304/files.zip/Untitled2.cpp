#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int t,n[3]={0},num,now,atk;
	scanf("%d%d",&t,&now);
	for(int i=0;i<t;i++){
		scanf("%d",&num);
		if(num==0){
			scanf("%d",&atk);
			if(now==0&&atk>=2500)n[0]=1;
			else if(now==1&&atk>2100)n[0]=1;
		}
		else if(num==1)n[1]=1;
		else n[2]=1;
	}
	if(n[1]+n[0]==2||(n[2]==1&&t>1))printf("haoye");
	else printf("QAQ");
}

