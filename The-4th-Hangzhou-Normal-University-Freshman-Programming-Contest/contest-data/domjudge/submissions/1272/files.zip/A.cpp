#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
int main(){
	int n;
	cin>>n;
	while(n--){
		cout<<"Welcome to HZNU"<<endl;
	}
	return 0;
}
 
