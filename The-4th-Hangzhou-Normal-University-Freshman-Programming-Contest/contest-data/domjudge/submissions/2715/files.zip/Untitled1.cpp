#include<stdio.h>
#include<string.h>
#include<math.h>
int main(void)
{
	int t,a,b,max,flag; 
	scanf("%d",&t);
	while(t--)
	{
		max=0,flag=0;
		scanf("%d %d", &a, &b);
		if(b==0)
		{
			printf("no\n");	
		}
		else
		{
			printf("yes\n");
		}
		
	}
	return 0;
}
