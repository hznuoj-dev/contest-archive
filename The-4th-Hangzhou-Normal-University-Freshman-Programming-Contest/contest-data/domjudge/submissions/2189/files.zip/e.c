#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int n,m,i,t,min;
	scanf("%d%d",&n,&m);
	int num[n*m];
	for(i=0;i<n;i++){
		for(t=0;t<m;t++){
			scanf("%d",&num[t+i*m]);
		}
	}
	min = num[1]-num[0];
	for(i=0;i<n*m;i++){
		for(t=i+1;t<n*m;t++){
			if(abs(num[t]-num[i])<min){
				min=abs(num[t]-num[i]);
			}
		}
	}
	printf("%d",min);
	return 0;
}
