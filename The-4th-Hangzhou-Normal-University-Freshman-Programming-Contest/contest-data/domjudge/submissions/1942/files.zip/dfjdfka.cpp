#include<bits/stdc++.h>
using namespace std;
void solve(){
	int n,x;cin>>n>>x;
	if(n%x==0||2*n%x==0)cout<<"yes\n";
	else cout<<"no\n";
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
