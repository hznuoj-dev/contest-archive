#include<stdio.h>
int main()
{
	int t;
	long long color1[25][25];
	long long color2[25][25];
	long long color3[25][25];
	scanf("%d",&t);
	while(t--){
		int n;
		scanf("%d",&n);
		
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				scanf("%lld",&color1[j][k]);
			}
		}
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				scanf("%lld",&color2[j][k]);
			}
		}
		int flag0=1;
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(color2[j][k]!=color1[j][k])
				{
					flag0=0;
					break;
				}
			}
		}
		int flag1=1;
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				color3[n-1-k][j]=color1[j][k];
			}
		}
//		printf("late\n");
//		for(int j=0;j<n;j++){
//			for(int k=0;k<n;k++){
//				printf("%d ",color3[j][k]);
//			}
//			printf("\n");
//		}
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(color2[j][k]!=color3[j][k])
				{
					flag1=0;
					break;
				}
			}
		}
		int flag2=1;
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				color1[n-1-k][j]=color3[j][k];
			}
		}
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(color2[j][k]!=color1[j][k])
				{
					flag2=0;
					break;
				}
			}
		}
		int flag3=1;
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				color3[n-1-k][j]=color1[j][k];
			}
		}
		for(int j=0;j<n;j++){
			for(int k=0;k<n;k++){
				if(color2[j][k]!=color3[j][k])
				{
					flag3=0;
					break;
				}
			}
		}
		if(flag0==1)
		printf("0\n");
		else if(flag1==1||flag3==1)
		printf("1\n");
		else if(flag2==1)
		printf("2\n");
		else
		printf("-1\n");
		
		
	}
	return 0;
}
