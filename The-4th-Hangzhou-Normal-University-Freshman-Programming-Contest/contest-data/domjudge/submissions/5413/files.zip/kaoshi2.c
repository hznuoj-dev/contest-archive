#include <stdio.h>
int main(){
	long int n,s;
	int i,flag;
	  struct music{
  	long long int num;
  	char name[16];
  };
    scanf("%ld",&n);
    struct music x[n],k;
    for(i=0;i<n;i++)
    scanf("%lld%s",&x[i].num,x[i].name);
    scanf("%ld",&s);
    do{
    	flag=0;
	    for(i=0;i<n-1;i++){
    	if(x[i].num<x[i+1].num){
    		k=x[i];x[i]=x[i+1];x[i+1]=k;flag=i+1;
    	}
		}n=flag;
    }while(flag);
	
    printf("%s",x[s].name);
	return 0;	 
}
