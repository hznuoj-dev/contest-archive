#include <stdio.h>
struct cs{
	int a;
	char arr[16];
};
int b[100000];
struct cs s[100000];
int main(void)
{
	int n;
	scanf("%d",&n);
	int i;
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].a,&s[i].arr);
		b[i]=s[i].a;
	}
	int k;
	scanf("%d",&k);
	int j;
	for(i=0;i<n;i++){
		for(j=i+1;j<n;j++){
			if(b[j]>b[i]){
				int t;
				t=b[j];
				b[j]=b[i];
				b[i]=t;
			}
		}
	}
	int m=b[k];
	for(i=0;i<n;i++){
		if(m==s[i].a){
			printf("%s",s[i].arr);
			break;
		}
	}
	return 0;
}
