#include<stdio.h>
int main(){
	int T,n,num,c;
	char a[100001]; 
	scanf("%d",&T);
	while(T--){
		c=0; 
		scanf("%d",&n);
		num=n+1;
		for(int i=0;i<n;i++){
			scanf("%s",&a[i]);
		}
		for(int i=0;i<n;i++){
			if(a[i]<'Z'){
				num--; 
				c++;
			}
		}
		for(int i=0;i<n;i++){
			for(int j=i+1;j<n;j++){
				if(a[i]==a[j]){
					num--;
				}
			}
		}
		if(c==n){
			num=0;
		}
		if(c==n-1){
			num=1;
		}
		printf("%d\n",num);
    } 
}
