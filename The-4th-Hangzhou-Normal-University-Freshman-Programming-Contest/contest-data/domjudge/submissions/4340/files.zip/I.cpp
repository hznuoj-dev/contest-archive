#include<stdio.h>
#include<stdlib.h>
struct name
{
	char name1[100];
	int num;
};
int main()
{
		struct name s[100];
		int i, n;
		scanf("%d", &n);
		for (i = 0; i < n; i++)
		{
			scanf("%d%s", &s[i].num, s[i].name1);
		}
			int k;
			scanf("%d", &k);
			printf("%s\n", s[k+1].name1);
	return 0;
}