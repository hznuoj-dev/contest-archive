#include <stdio.h>
#include <stdlib.h>
#include <time.h>
struct bom{
	int a;
	char ch[20];
};
int comp(const void*p,const void*q)
{
	int s1=((struct bom*)p)->a;
	int s2=((struct bom*)q)->a;
	return s1<s2? 1:-1;
}
int main()
{
	int n,i,j,k;
	scanf("%d",&n);
	struct bom w[n+1];
	for(i=0;i<n;i++)
	{
		scanf("%d%s",&w[i].a,w[i].ch);
	}
	scanf("%d",&k);
	qsort(w,n,sizeof(struct bom),comp);
	printf("%s",w[k].ch);
}
