#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,x;
		scanf("%d %d",&n,&x);
		if(x==0||n==0)
			printf("no\n");
		else
			printf("yes\n");
	}
	return 0;
}
