#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int t,len,num;
	char c[1015][31];
	scanf("%d",&t);
	while(t--){
		memset(c,'\0',sizeof(c));
		for(num=1;num;num++){
			getchar();
			scanf("%s",c[num]);
			len=strlen(c[num]);
			if(c[num][len-1]=='.'||c[num][len-1]=='!'||c[num][len-1]=='?'){
				num++;
				c[num][0]=c[num-1][len-1];
				c[num-1][len-1]='\0';
				break;
			}
		}
		printf("%s",c[1]);
		for(int i=1;i<num/2;i++){
			printf(" %s %s",c[num-i],c[i+1]);
		}
		if(num%2==1)printf(" %s",c[num/2+1]);
		printf("%s\n",c[num]);
	}
}

