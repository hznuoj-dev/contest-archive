#include "iostream"
#include "string.h"
#include "stdio.h"
#include "stdlib.h"
using namespace std;
struct node {
    char a[105];
} s[105];
int main() {
    int n, m, t;
    scanf("%d", &t);
    int ans = 1;
    while(t--){
        int i=1;
        while(~scanf("%s",&s[i].a)){
            char k=s[i].a[strlen(s[i].a)-1];
            if(k=='.'||k=='!'||k=='?'){
                break;
            }
            i++;
        }
        int l=i;
        for (int j = 1; j <= (i/2+(i&1)); j++) {
            cout << s[j].a << " ";
            if(j==l)continue;
            cout <<s[l].a<<" ";
            l--;
        }
        for(int h=0;h<i;h++)
            printf("%d",s[h].a);
        printf("%c",s[i].a[strlen(s[i].a)-1]);
    }

    return 0;
}