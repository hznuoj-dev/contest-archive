#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main () {
	int t;
	int n;
	int k;
	scanf("%d",&t);
	while(t--) {
		scanf("%d %d",&n,&k);	
		if(n==2&&k%2==1)printf("NO\n");
		else if(k==0)printf("NO\n");
		else printf("Yes\n");
	}
	return 0;
}
