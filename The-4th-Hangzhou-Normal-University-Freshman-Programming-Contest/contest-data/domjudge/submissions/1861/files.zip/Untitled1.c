#include<stdio.h>
int arr[100000];
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		long long n;
		scanf("%lld",&n);
		long long i=0;
		while(i<n){
			scanf("%d",&arr[i]);
			i++;
		}
		int cnt=0;
		int zong=0;
		i=0;
		while(i<n){
			long long j=i;
			while(j<n){
				zong=zong+arr[j];
				if(zong==7777){
					cnt=cnt+1;
					zong=0;
					break;
				}
				if(zong>7777){
					zong=0;
					break;
				}
				j++;
			}
			i++;
		}
		printf("%d",cnt);
	}
	return 0;
} 
