#include <stdio.h>
#include <string.h>
 
int expandAround(char * str, int left, int right)
{
    while(str[left] == str[right]  && left >= 0 && right < strlen(str))
    {
        left--;
        right++;
    }
    
    return right - left - 1;
}
 
int max(int a, int b)
{
    if(a > b)
        return a;
    return b;
}
 
int main()
{
	int t,n; 
    char str[1000];
    scanf("%d",&t);
    while(t--)
    {
    	scanf("%d",&n);int m = 0;
    	while(gets(str)){
        
        for(int i = 0; i < strlen(str); i++)
        {
            int len1 = expandAround(str, i, i);  
            int len2 = expandAround(str, i, i + 1);
            int len = max(len1, len2);
            m = max(m, len);
        } printf("%d\n", m);
    }
       
    }
    return 0;
}
