#include<stdio.h>
int main(void){
	int t,x,n;
	int i;
	scanf("%d",&t);
	int a[t][2];
    for(i=0;i<t;i++){
    	scanf("%d%d",&a[i][1],&a[i][2]);
	}
	for(i=0;i<t;i++){
		if(a[i][2]==0){
			printf("no\n");
		}
		else {
			printf("yes\n");
		}
	}
	return 0;
}
