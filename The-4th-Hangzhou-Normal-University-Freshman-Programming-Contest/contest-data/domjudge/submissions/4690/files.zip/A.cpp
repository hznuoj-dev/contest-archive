#include<stdio.h>

int main()
{
	int x,b,sum=0,max=0,i,j;
	int g[1000]={0};
	char a[1000],o;
	scanf("%d",&x);
	while(x--)
	{
		sum=0;
		max=0;
		scanf("%d",&b);
		for( i=1;i<=b;i++)
		{
			scanf("%s",&o);
			for( j=1;j<=b;j++)
			{
				if(g[j]==0)
				{
					a[j]=o;
					g[j]++;
					break;
				}
				else if(a[j]==o)
				{
					g[j]++; 
				}
					
			}
		}
		for(i=1;i<=b;i++)
		{
			if(g[i]%2==0)
			{
				sum+=g[i];
			}
			else
			{
				if(g[i]>max)
				max=g[i];
			}
		}
		sum+=max;
		for(i=1;i<=b;i++)
		{
			if(g[i]%2!=0&&g[i]!=max)
				sum=sum+g[i]-1;
		 } 
		printf("%d\n",sum);
		for(i=0;i<=b;i++)
		{
			g[i]=0;
		}
	}
	
	return 0;
}
