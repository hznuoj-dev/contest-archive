#include<stdio.h>
int main()
{
	int T;
	long long n, i;
	char c[100];
	scanf("%d", &T);
	while (T--)
	{
		 long long r = 0;
		scanf("%lld", &n);
		for (i = 0; i < n; i++)
		{
			scanf("%s", &c[i]);
		}
		for (i = 0; i < n; i++)
		{
			long long a = i, b;
			for (b = i;b<=n; b++)
			{
				if (c[a] == c[b+1])
				{
					r = r + 1;
				}
			}
		}
		if (r == 0 || n % 2 != 0)
		{
			printf("%lld\n", r * 2 + 1);
		}
		else if(n%2==0)
		{
			printf("%lld\n",r*2);
		}
	}
}