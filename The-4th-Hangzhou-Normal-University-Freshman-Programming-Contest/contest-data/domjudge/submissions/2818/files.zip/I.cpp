#include<bits/stdc++.h>
using namespace std;
struct song{
	long long k;
	string name;
};
int main(){
    long long n,i,j,k,l;
    struct song s[100010];
    cin>>n;
    for(i=1;i<=n;i++){
    	cin>>s[i].k>>s[i].name;
	}
	cin>>l;
	cout<<s[n-l].name;
	return 0;
}
