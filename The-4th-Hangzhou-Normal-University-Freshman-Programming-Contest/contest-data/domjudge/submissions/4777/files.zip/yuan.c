
#include <stdio.h>
#include <string.h>
#pragma warning(disable:4996)
int main() {
    int n; int  l[10]; char c[100][100]; int m;
    scanf_s("%d", &n);
    for (int i = 0; i < n; i++)
    {
        scanf_s("%d", &l[i]);
        getchar();
        gets(c[i]);
    }
    scanf_s("%d", &m);
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
        {
            if (l[j] > l[i])
            {
                char s[100];
                strcpy(s, c[i]);
                strcpy(c[i], c[j]);
                strcpy(c[j], s);
            }
        }
    }
    printf("%s", c[m]);
}