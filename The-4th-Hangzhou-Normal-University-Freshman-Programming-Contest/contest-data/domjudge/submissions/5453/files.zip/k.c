#include<stdio.h> 
#include<stdlib.h>
struct stu{
	int w;
	char str[10000];
};
int comp(const void *p,const void *q){ //���� ���Ӵ�С 
	return ((struct stu *)q)->w-((struct stu *)p)->w; 
}
int main()
{
	struct stu stu[100000];
	long long n,k;
	int i;
	scanf("%lld",&n);
	for( i=0;i<n-1;i++){
		scanf("%d%s",&stu[i].w,stu[i].str);
	}
	qsort(stu,n,sizeof(struct stu),comp);
	scanf("%lld",&k);
	printf("%s",stu[k].str);
	return 0;
}
