#include<stdio.h>
#include<stdlib.h>
struct a{
	char w[10];
	char s[18];
};
int comp(const void *p,const void *q){
	return ((struct a*)q)->w-((struct a*)p)->w;
}

int main(){
	 long long int n,k;
struct a a1[1000];
	scanf("%lld",&n);
	for(int i=0;i<n;i++){
		scanf("%s %s",a1[i].w,a1[i].s);
	}
	scanf("%lld",&k);
	qsort(a1,n,sizeof(struct a),comp);
		puts(a1[k].s);
	
}