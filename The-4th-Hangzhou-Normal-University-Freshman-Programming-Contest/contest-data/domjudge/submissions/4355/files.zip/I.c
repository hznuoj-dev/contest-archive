#include<stdio.h>
#include<stdlib.h>
struct song{
	long long int level;
	char geming[19];
};
int comp(const void *p,const void *q){
 struct song*mg=(struct song*)(p);
 struct song*zn=(struct song*)(q);
 int a=mg->level;
 int b=zn->level;
 return b-a;
}
int main(void){
struct song s[10000];
long long int n,k;
scanf("%lld",&n);
for(long long int i=0;i<n;i++){
	scanf("%lld %s",&s[i].level,s[i].geming);
}
scanf("%lld",&k);
qsort(s,n,sizeof(struct song),comp);
printf("%s\n",s[k].geming);
 return 0;
}
