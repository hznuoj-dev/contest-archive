#include <iostream>
#include <vector>
#include <map>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int q;
	cin>>q;
	map<int,string> mp;
	while(q--){
		int n;
		string s;
		cin>>n>>s;
		mp[n]=s;
	}
	int n=mp.size();
	int a;
	cin>>a;
	n=mp.size()-a;
	n--;
	map<int,string>::iterator cur=mp.begin();
	for(int i=0;i<n;i++,cur++){}
	cout<<cur->second;
	return 0;
}

//#include <iostream>
//#include <vector>
//#include <map>
//using namespace std;
//#define vc vector
//#define pii pair<int,int>
//
//const int mod=1e9+7;
//typedef long long ll;
////struct NUM{
////	char arr[3][3];
////}num[10];
//int time[2][6];
//
//char num[10][3][3]={{{' ','_',' '},
//					{'|',' ','|'},
//					{'|','_','|'}},
//					
//					{{' ',' ',' '},
//					{' ',' ','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{' ','_','|'},
//					{'|','_',' '}},
//					
//					{{' ','_',' '},
//					{' ','_','|'},
//					{' ','_','|'}},
//					
//					{{' ',' ',' '},
//					{'|','_','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{'|','_',' '},
//					{' ','_','|'}},
//					
//					{{' ','_',' '},
//					{'|','_',' '},
//					{'|','_','|'}},
//					
//					{{' ','_',' '},
//					{' ',' ','|'},
//					{' ',' ','|'}},
//					
//					{{' ','_',' '},
//					{'|','_','|'},
//					{'|','_','|'}},
//					
//					{{' ','_',' '},
//					{'|','_','|'},
//					{' ','_','|'}}};
//void putNum(int *num1){
//	for(int i=0;i<3;i++){
//		for(int j=0;j<6;j++){
//			cout<<num[j][i][0]<<num[j][i][1]<<num[j][i][2];
//		}
//		cout<<'\n';
//	}
//}
//int cmp(int *a,int *b){
//	for(int i=0;i<3;i++){
//		for(int j=0;j<3;j++){
//			if(*(a+j*3+i)!=*(b+j*3+i)) return 0;
//		}
//	}
//	return 1;
//}
//void inPut(){
//	char time1[6][3][3];
//	for(int k=0;k<2;k++){
//		for(int i=0;i<3;i++){
//		for(int cur=0;cur<6;cur++){
//			for(int j=0;j<3;j++){
//				scanf("%c",&time1[cur][i][j]);
//			}
//		}
//	}
//	for(int i=0;i<6;i++){
//		for(int j=0;j<10;j++){
//			if(cmp((int *)time1[i],(int *)num[j])) time[k][i]=j;
//		}
//	}
//	}
//}	
//
//int main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);
//	inPut();
//	putNum(time[0]);
//	
//	return 0;
//}


