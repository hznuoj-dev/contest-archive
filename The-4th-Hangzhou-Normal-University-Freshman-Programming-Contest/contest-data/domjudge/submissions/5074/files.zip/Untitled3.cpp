#include<stdio.h>
#include<stdlib.h>
int main(void)
{
 	int i,a,b,c[20],xue,flag=0,max=0;
 	scanf("%d %d",&a,&b);
 	if(a<=1)
 	{
 		printf("QAQ\n");
	}
	else
	{
		for(i=0;i<a;i++)
	 	{
	 		scanf("%d",&c[i]);
	 		if(c[i]==0)
	 		{
	 			scanf("%d",&xue);
	 			if(max<=xue)
	 			{
	 				max=xue;
				}
			}
			else if(c[i]==2)
			{
				printf("haoye\n");
				break;
			}
			else if(c[i]==1)
			{
				flag=1;
			}
		}
			if(max>=2500&&b==0&&flag==1)
			{
			printf("haoye\n");	
			}
			else if(max>2100&&b==1&&flag==1)
			{
				printf("haoye\n");
			}
			else
			{
				printf("QAQ\n");
			}
		
	}
 	
	return 0;
} 
