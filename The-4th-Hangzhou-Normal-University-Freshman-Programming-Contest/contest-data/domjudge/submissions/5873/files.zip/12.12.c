//#include<stdio.h>
//	int main()
//	{
//		int n,i;
//		scanf("%d",&n);
//		for(i=0;i<n;i++)	printf("Welcome to HZNU\n");
//		return 0;
//	}
//#include<stdio.h>
//char a[100001];
//	int main()
//	{
//		int t,n,i;
//		scanf("%d",&t);
//		while(t--)
//		{
//			scanf("%d",&n);
//			for(i=0;i<n;i++)
//			{
//				scanf("%d",&a[i]);
//			}
//		}
//		return 0;
//	}
//#include<stdio.h>
//#include<string.h>
//#include<stdlib.h>
//int comp(const void *p,const void *q);
//struct sibao
//{
//	long long int w[10];
//	char s[20];	
//}a[100001];
//	int main()
//	{
//		int n,i,j,k,m;
//		scanf("%d",&n);
//		for(i=0;i<n;i++)
//		{
//			scanf("%lld %s",a[i].w,a[i].s);
//		}
//		scanf("%d",&m);	
//		qsort(&a[0].w,n,sizeof(struct sibao),comp);
//		printf("%s\n",a[m].s); 
//		return 0;
//	}
//int comp(const void *p,const void *q)
//{
//	return (*(int *)q-*(int *)p);
//}
//#include<stdio.h>
//	int main()
//	{
//		int t,n,i,temp,ans=0,haha=0;
//		char zimu;
//		int a[123]={0};
//		scanf("%d",&t);
//		while(t--)
//		{
//			scanf("%d",&n);
//			getchar();
//			for(i=0;i<n;i++)
//			{
//				scanf("%c",&zimu);
//				temp=zimu;
//				if(temp<65||temp>90&&temp<97||temp>122)
//				{
//					i--;
//					continue;
//				}
//				a[temp]++;
//			}
//			for(i=0;i<123;i++)
//			{
//				if(a[i]>=2)	
//				{
//					ans+=a[i]/2*2;
//					if(a[i]%2!=0)	haha=1;
//				}
//				else if(a[i]==1)	haha=1;
//			}
//			if(haha==1)	ans++;
//			printf("%d\n",ans);
//			for(i=0;i<123;i++)
//			{
//				a[i]=0;	
//			}
//			ans=0;
//			haha=0;
//		}
//		return 0;
//	}
//#include<stdio.h>
//	int main()
//	{
//		int t,n,x;
//		scanf("%d",&t);
//		while(t--)
//		{
//			scanf("%d %d",&n,&x);
//			if(x!=0)	printf("yes\n");
//			else	printf("no\n");
//		}
//		
//		return 0;
//	}
//#include<stdio.h>
//#include<math.h>
//#include<stdlib.h>
//#include<time.h>
//long long a[11][1000001];
//	int main()
//	{
//		int n,m,i,j,min=0,ans,q,p,sum;
//		long long temp;
//		
//		scanf("%d %d",&n,&m);
//		for(i=0;i<n;i++)
//		{
//			for(j=0;j<m;j++)
//			{
//				scanf("%lld",&a[i][j]);
//				if(a[i][j]>min)	min=a[i][j];
//			}	
//		}
////		p=0;
////		while(p<n)
////		{
////			q=0;
////			while(q<m)
////			{
////				temp=a[p][q];
////				for(i=0;i<n;i++)
////				{
////					for(j=0;j<m;j++)
////					{
////						if(i!=p||j!=q)	
////						{
////							ans=abs(temp-a[i][j]);
////							if(min>ans)	min=ans;
////						}
////					}
////				}
////				q++;
////			}
////			p++;
////		}
//		srand(time(NULL));
//		p=rand()%(n-2);
//		q=rand()%(m-2);
//		temp=a[p][q];
//		sum=1;
//		while(sum<m*n-1)
//		{
//			i=rand()%(n-2);
//			j=rand()%(m-2);
//			if((i!=p||j!=q)&&a[i][j]!=-1)
//			{
//				ans=abs(temp-a[i][j]);
//				if(min>ans)	min=ans;
//				sum++;
//				a[p][q]=-1;
//				temp=a[i][j];
//			}
//		}
//		printf("%d\n",min);
//		return 0;
//	}
#include<stdio.h>
	int main()
	{
		int n,m,ka[10],i=0,atk=0,symbol1=0,symbol2=0,ans=0,symbol3=0;		//n������������m�Ǳ�ʾ��ʽ 
		scanf("%d %d",&n,&m);
		getchar();
		for(i=0;i<n;i++)
		{
			scanf("%d",&ka[i]);
			if(ka[i]==0)	scanf("%d",&atk);
		}
			if(m==0&&atk>=2500)	symbol1++;
			else if(m==1&&atk>=2100)	symbol1++;
			for(i=0;i<n;i++)
			{
				if(ka[i]==1)	symbol2++;
			}
			if(n-symbol1-symbol2>1&&symbol1==0)
			{
				for(i=0;i<n;i++)
				{
					if(ka[i]==2)	symbol3=2;
				}
			}
			if(symbol1==1&&symbol2==1)	printf("haoye\n");
			else if(symbol3==2)	printf("haoye\n");
			else printf("QAQ\n");
		return 0;
	}
