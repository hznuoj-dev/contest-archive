#include<stdio.h>
int main(void) {
    long long n, t, x;
    scanf("%lld", &t);
    while (t--) {
        scanf("%lld %lld", &n, &k);
        if (k == 0)
            printf("no");
        else
            printf("yes");
    }


    return 0;
}