#include<stdio.h>
char ans[10050];
int main(){
	int T,n,i,flag;
	char temp;
	int count[52];
	int ans1;
	scanf("%d",&T);
	while(T--){
		for(i=0;i<52;i++){
			count[i]=0;
		
		}
		
		scanf("%d",&n);
		getchar();
		while(n--){
			scanf("%c",&temp);
			getchar();
		
			if(temp<='Z'){count[temp-'A']++;}
			else {count[26+temp-'a']++;}
		}
		ans1=0;
		flag=0;

			for(i=0;i<52;i++){
			//	if((max<count[i])&&(count[i]%2==1))max=count[i];
			ans1=ans1+count[i]/2*2;	
			if(count[i]!=0){
				if(count[i]%2==1)flag=1;
			} 
			}
			ans1=ans1+flag;
			 
		if(T!=0)printf("%d\n",ans1);else printf("%d",ans1);
	}
}
