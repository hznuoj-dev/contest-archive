#include<bits/stdc++.h>
using namespace std;
int gs,hh,mx,flag; 
int main(){
	int n,m,a,atk;
	scanf("%d%d",&n,&m);
	for(int i=1;i<=n;i++){
		scanf("%d",&a);
		if(a==0){
			gs++;
			scanf("%d",&atk);
			if(m==0){
				if(atk>=2500) flag=1;
			}
			else{
				if(atk>2100) flag=1;
			}
		}
		else if(m==1) mx++;
		else hh++;
	}
	if(gs!=0 &&mx!=0 &&flag==1||gs!=0 &&hh!=0||hh!=0 &&mx!=0) printf("haoye\n");
	else printf("QAQ\n");
	return 0;
}
