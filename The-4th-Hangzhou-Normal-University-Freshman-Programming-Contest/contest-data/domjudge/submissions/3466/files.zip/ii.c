#include <stdio.h>
#include <stdlib.h>

struct song{
	int number;
	char a[16];
};
int comp(const void *p,const void *q){
	return ((struct song *)p)->number-((struct song *)q)->number;
}
int main(void){
	struct song array[100001];
	int n,i,pass,exchange,k;
	scanf("%d",&n);
	for(i=0;i<n;++i){
		scanf("%d %s",&array[i].number,array[i].a);
	}
	scanf("%d",&k);
	qsort(array,n,sizeof(struct song),comp);
		printf("%s",array[k].a);
	return 0;
}
