
#include<stdio.h>
int main()
{
	int t;
	int n,x;
	int f;

	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&x);
		f=0;
		if(x==0)
		{
			printf("no\n");
			continue;
		}
		while(f!=0)
		{
			f=(f+x)%n;
		}
		if(f==0)
		{
			printf("yes\n");
		}
	}

	return 0;

}