#include<stdio.h>
char a[100005];
int main()
{
	int T;
	scanf("%d", &T);
	while (T--)
	{
		int i, j, n;
		int word, count = 0,flag=0;
		scanf("%d",&n);
		getchar();
		for (i = 0; i < n; i++)
		{
			scanf("%c",&a[i]);
			getchar();
		}
		for (i = 0; i < n; i++)
		{
			word = 0;
			for (int k = 0; k < i; k++)
			{
				if (a[k] == a[i]) flag=1;
			}
			if (flag == 0)
			{
				for (j = i; j < n; j++)
				{
					if (a[i] == a[j])
					{
						word++;
					}
				}
			}
			if (word == 0) continue;
			else if (word != 0)
			{
				if (word % 2 == 0)
				{
					count += word;
				}
				else
				{
					count += word - 1;
				}
			}
		}
		if (n % 2 == 0)
		{
			if (count == n) printf("%d\n", count);
			else if(count!=n) printf("%d\n",count+1);
		}
		else if (n % 2 != 0)
		{
			printf("%d\n", count+1);
		}
	}
	return 0;
}