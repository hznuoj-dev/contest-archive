#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int cmp(const void*a,const void*b);
struct gg{
	int a;
	char b[16];
};
int main(void){
	int n;
	scanf("%d",&n);
	struct gg g[n];
	int i=0;
    while(i!=n){		
	scanf("%d %s",&g[i].a,g[i].b);
	i++; 
	}
	int k;
	scanf("%d",&k);
	qsort(g,n,sizeof(struct gg),cmp);
	printf("%s",g[k].b);
}
int cmp(const void*a,const void*b){
	struct gg*p1=(struct gg*)a;
	struct gg*p2=(struct gg*)b;
    int d=p1->a;
	int f=p2->a;	
return f-d;
}

