#include<stdio.h>
struct zu{
	long long w;
	char s[20];
}song[100001],ti;
int main(void){
	long long n,k,i,x,y;
	scanf("%lld",&n);
	for(i=1;i<=n;i++){
		scanf("%lld%s",&song[i].w,song[i].s);
	}
	scanf("%lld",&k);
	for(x=1;x<=k+1;x++){
		for(y=n-1;y>=x;y--){
			if(song[y].w<song[y+1].w){
			ti=song[y+1];
			song[y+1]=song[y];
			song[y]=ti;}
		}
	}
	
	printf("%s",song[k+1].s);
	 
	return 0;
}
