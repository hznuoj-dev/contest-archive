#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	int t,i,j,n,sum=0,sum1=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		getchar();
		int a[n];
		for(i=0;i<n;i++)a[i]=0;
		char c[n],d[n];
		for(i=0;i<n;i++){
			scanf("%c",&c[i]);
			if(c[i]==' '){
				scanf("%c",&c[i]);
			}
			d[i]=c[i];
		}
		getchar();
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(d[i]==c[j]){
					c[j]='0';
					a[i]++;
				}
			}
		}
		for(i=0;i<n;i++){
			sum+=a[i]/2;
			sum1+=a[i];
		}
		if(sum==0)printf("1");
		else if(sum*2==sum1)printf("%d",sum1);
		else printf("%d",sum*2+1);
		sum=0;
		sum1=0;
		if(t){
			printf("\n");
		}
	}
	return 0;
}
