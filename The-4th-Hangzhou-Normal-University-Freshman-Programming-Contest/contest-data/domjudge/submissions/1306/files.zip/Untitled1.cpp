#include<stdio.h>
int main()
{
	int i;
	scanf("%d",&i);
	printf("Welcome to HZNU\n");
} 
