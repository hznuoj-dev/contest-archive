#include<stdio.h>
#include<stdlib.h>
struct stu{
	char name[20];
	long long int w;
//	 
};
int comp(const void*p,const void*q){
	return((struct stu *)q)->w-((struct stu *)p)->w;
}
int main(void){
	struct stu stua[100];
	int n,t,i,k;
	scanf("%d",&n);
//	while(n--){}
//		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d%s",&stua[i].w,stua[i].name);
		}
		scanf("%d",&k);
		qsort(stua,n,sizeof(struct stu),comp);
		for(i=n-1;i>k-1;i--){
			printf("%s\n",stua[i].name);
		}
	
	return 0;

} 
