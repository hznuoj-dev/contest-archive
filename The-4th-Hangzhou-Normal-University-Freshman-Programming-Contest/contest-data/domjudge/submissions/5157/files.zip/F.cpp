/*F*/
#define MAX 100
#include<stdio.h>
void spin(int *a, int n);
int main(void)
{
	int t, n, k, i, j, temp, l, flag;
	int a[MAX][MAX], b[MAX][MAX];
	scanf("%d", &t);
	for(k=1;k<=t;k++){
		scanf("%d", &n);
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d", &a[i][j]);
			}
		}
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d", b[i][j]);
			}
		}
		for(l=1;l<=4;l++){
			flag=1;
			for(i=0;i<n;i++){
				for(j=0;j<n;j++){
					if(a[i][j]!=b[i][j]){
						flag=0;
						break;
					}
				}
			}
			if(flag){
			    printf("%d", 1);
			    break;
			}
			spin(*a, n);			
		}
		if(flag==0){
			printf("%d", -1);
		}
	}
	return 0;
}
void spin(int *a, int n)
{
	int c[MAX][MAX];
	int i, j, *p=a, *q=a;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			c[j][n-i]=*(p++);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			*(q++)=c[i][j];
		}
	}
}
