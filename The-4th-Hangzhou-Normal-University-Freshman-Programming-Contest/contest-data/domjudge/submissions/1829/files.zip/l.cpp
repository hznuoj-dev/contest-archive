#include<bits/stdc++.h>
using namespace std;
int a[100010];
int main()
{
	int n,x;
	int N;
	cin>>N;
	while(N--)
	{
		cin>>n>>x;
		if(x==0)
		{
			cout<<"no"<<'\n';
		}
		else
		{
			cout<<"yes"<<'\n';
		}
	}
}
