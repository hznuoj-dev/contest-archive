#include<stdio.h>
int main(void){
        int n,m,i,y,u,p,q,x;
        scanf("%d %d",&n,&m);
		int a[n];
		q=x=y=u=p=0;
        for(i=0;i<n;i++){
        	scanf("%d",&a[i]);
        	if(a[i]==0){
			scanf("%d",&q);
			if(q>x){
				x=q;
				
			}
  }
			if(a[i]==1){
        		y=1;
			}
			if(a[i]==0){
				u=1;
			}
		}
		if(n>=2){
		
        for(i=0;i<n;i++){
            if(a[i]==2){
        	printf("haoye");
        	p=1;
        	break;
		}
		}
	}
	if(p!=1){
	
	  if(y==1&&u==1){
		    if(m==0&&x>=2500){
			printf("haoye");
		}
	          else if(m==1&&x>2100){
	 	     printf("haoye"); 
	 }
	        else
	       printf("QAQ");
	 }
	 else
	 printf("QAQ");
}
}
		
	
	

