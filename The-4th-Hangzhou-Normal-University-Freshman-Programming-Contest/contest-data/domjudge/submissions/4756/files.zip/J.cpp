#include<stdio.h>
int main (){
	int n,m,a[11],k,i,flag=1,flag1=1;
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;++i){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&k);
			if(m==0){
				if(k>=2500){
					flag=0;
				}
			}
			else{
				if(k>2100){
					flag=0;
				}
			}
		}
		else if(a[i]==1&&flag==0){
			flag1=0;
		}
		else if(a[i]==2&&flag==1&&i!=n){
			flag1=0;
		}
	}
	if(flag1==0){
		printf("haoye");
	}
	else{
		printf("QAQ")
	}
} 
