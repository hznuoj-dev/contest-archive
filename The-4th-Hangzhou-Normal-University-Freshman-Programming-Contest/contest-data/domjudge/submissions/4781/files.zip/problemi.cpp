#include <iostream>
#include <string.h>
using namespace std;
struct sum {
	string s;
	int x;
	int y;
};
char ch;
int n,k;
struct sum a[100010];
void sort (int l, int r);
int main (){
	
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i].x >> a[i].s;
		a[i].y=i;
	}
	sort(1,n);
	cin >> k;
	cout << a[n-a[k].y].s << '\n';
}
void sort (int l, int r)
{
	int i=l,j=r,m=a[(l+r)/2].x,temp;
	char ch1[100];
	do{
		while (a[i].x < m) i++;
		while (a[j].x > m) j--;
		if (i <= j) {
			temp=a[i].x; a[i].x=a[j].x; a[j].x=temp;
			temp=a[i].y; a[i].y=a[j].y; a[j].y=temp;
			i++;
			j--;
		}
	}while (i <= j);
	if (l < j) sort (l,j);
	if (i < r) sort (i,r);
}
