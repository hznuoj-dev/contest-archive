#include<stdio.h>
#include<stdlib.h>
struct g{
	long long int a;
	char b[200];
};
int comp(const void*p, const void *q){
	return ((struct g *)q)->a - ((struct g *)p)->a;
}
int main(void){
	struct g gg[1000];
	int n, k;
	scanf("%d", &n);
	for (int i = 0; i<n; i++){
		scanf("%lld%s", &gg[i].a, gg[i].b);
	}
	scanf("%d", &k);
	qsort(gg, n, sizeof(struct g), comp);
	printf("%s",gg[k].b);
	return 0;
}