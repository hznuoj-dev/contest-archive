#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int a[100008];
int main(){
int n,i,k,t,j,ret,f,ti;
int sum;
scanf("%d",&t);
while(t--){
	ti=0;
	ret=0;
	sum=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
	scanf("%d",&a[i]);
	for(j=i-1;j>=ti;j--)
	{
		if(a[j]<7777)
		a[j]+=a[i];
	if(a[j]>=7777){
		ti=j+1;
	if(a[j]==7777)
		{
			ret++;
			a[j]++;
		}
		break;}
	} 
	}
	if(a[n-1]==7777)
	ret++;
	printf("%d\n",ret);
}
return 0;
}

