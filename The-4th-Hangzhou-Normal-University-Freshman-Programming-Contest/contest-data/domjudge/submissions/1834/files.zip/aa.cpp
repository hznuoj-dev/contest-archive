#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#define pzc 666
using namespace std;
int main()
{
	long long x,y;
	int t,n,i,j,k,a,b,c,l,f,d;
	char ch;
	int s[200];
	cin>>t;
	while(t--)
	{
		memset(s,0,sizeof(0));
		cin>>n;f=0;d=0;getchar();
		while(n--)
		{
			ch=getchar();getchar();
			s[ch]++;
			if(s[ch]%2==1) f++;
			else {
			d+=2;f--;} 
		}
		if(f!=0) f=1;
		cout<<d+f<<endl;
	}
}
