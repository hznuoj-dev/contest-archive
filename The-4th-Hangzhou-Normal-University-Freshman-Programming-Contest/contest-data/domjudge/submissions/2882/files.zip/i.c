#include<stdio.h>
#include<stdlib.h> 
struct song{
	int w;
	char s[16];
};
int comp(const void *p,const void *q);
int main(void){
	int n,i,k;
	scanf("%d",&n);
	struct song a[n];
	for(i=0;i<n;i++){
	scanf("%d%s",&a[i].w,&a[i].s);
	}
	qsort(a,n,sizeof(a[0]),comp);
	scanf("%d",&k);
	printf("%s",a[k].s);
	return 0;
}
int comp(const void *p,const void *q)
{
	return (*(int *)q-*(int *)p);
}
