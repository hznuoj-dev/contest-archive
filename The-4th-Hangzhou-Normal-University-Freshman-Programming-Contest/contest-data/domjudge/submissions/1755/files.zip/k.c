#include <stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	printf("welcome to HZNU\n");
}
