#include<bits/stdc++.h>

using namespace std;

int t;

struct nod{
	int len;
	string s;
}a[1005];

int main()
{
	char c;
	string s;
	scanf("%d",&t);
	while(t--){
		int n=0;
		cin>>s;
		while(1){
			n++;
			int len = s.length();
			a[n].s = s;
			a[n].len = len;
			if(s[len-1] == '.' || s[len-1] == '!' || s[len-1] == '?'){
				c = s[len-1];
				a[n].len--;
				break;
			}
			cin>>s;
		}
		int flag = 1;
		int head = 1,tail = n,now = 1;
		while(head<=tail){
			if(flag == 1){
				flag = 0;
			}
			else printf(" ");
			if(now == 1){
				
				for(int i=0;i<a[head].len;++i){
					cout<<a[head].s[i];
				}
				head++;
			}if(now == 0){
				
				for(int i=0;i<a[tail].len;++i){
					cout<<a[tail].s[i];
				}
				tail--;
			}now = 1-now;
		}printf("%c\n",c);
	}
	return 0;
}
