#include<stdio.h>
int main(void)
{
	int n,k,i;
	char w, s;
	scanf("%d",&n);
	while(n--)
	{
		scanf("%d%c",&w,&s);
		
	}
}
