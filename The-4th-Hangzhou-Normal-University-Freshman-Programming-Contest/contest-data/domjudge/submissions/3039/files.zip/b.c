#include <stdio.h>
int main(void) {
	int n,i,t,x;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d %d",&n,&x);
		if(n!=0){
			printf("yes\n");
		}
		else printf("no\n");
	}
	return 0;
}

