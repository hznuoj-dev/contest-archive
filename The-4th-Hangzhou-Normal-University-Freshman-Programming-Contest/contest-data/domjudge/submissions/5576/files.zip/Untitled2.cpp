#include<stdio.h>
#include<string.h>
int t,num,res,star=0,end,sum,n[1000000];
int main(){
	scanf("%d",&t);
	while(t--){
		sum=res=end=star=0;
		scanf("%d",&num);
		for(int i=0;i<num;i++){
			scanf("%d",&n[i]);
		}
		while(star<num){
			if(end!=num){
			    for(end;sum<7777&&end<num;end++){
				   sum+=n[end];
			    }
			}
			for(star;sum>7777&&star<num;star++){
				sum-=n[star];
			}
			if(sum==7777)res++;
			sum-=n[star];
			star++;
		}
		printf("%d",res);
		if(t>0)printf("\n");
	}
}

