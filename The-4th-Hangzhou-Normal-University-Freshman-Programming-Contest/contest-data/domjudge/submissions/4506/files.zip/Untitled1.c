#include <stdio.h>
#include <string.h>
void swap(long long int *x,long long int *y){
	int t=*x;
	*x=*y;
	*y=t;
}
int main(void){
	long long int a[100000];
	char name[10000][16];
	char d[16];
	int n, i, j, k, max;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%lld %s",&a[i],name[i]);
	}
	scanf("%d",&k);
	for(i=0;i<k+1;i++){
		max=i;
		for(j=i+1;j<n;j++){
			if(a[j]>a[max])
				max=j;
		}
		if(max!=i){
			swap(&a[i],&a[max]);
			strcpy(d,name[i]);
			strcpy(name[i],name[max]);
			strcpy(name[max],d);
		}
	} 
	printf("%s\n",name[k]);
}

