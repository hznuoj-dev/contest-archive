#include<bits/stdc++.h>
#define inf 0x3f3f3f3f
#define res register int 
using namespace std;
int n,m;
int main()
{
	scanf("%d",&n);
	for(res i=1;i<=n;i++)
	printf("Welcome to HZNU\n");
}
