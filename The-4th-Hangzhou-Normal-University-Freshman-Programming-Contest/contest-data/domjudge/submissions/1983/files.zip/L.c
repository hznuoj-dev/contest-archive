#include<stdio.h>
int main(){
	int t,n,x,k;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&x);
		if(x*1.0/n!=0)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}
