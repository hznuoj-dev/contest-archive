
#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;
int a[22][22]={0};
int b[22][22]={0};
int c[22][22]={0};
int ff(int n)
{
	for(int i=1;i<=n;i++)
	{
		for(int w=1;w<=n;w++)
		{
			if(c[i][w]!=b[i][w])
			return 0;		
		}
	}
	return 1;
}
int f(int n)
{
	for(int i=1;i<=n;i++)
	{
		c[1][i]=a[1][i];		
	}
	for(int i=1;i<=n;i++)
	{
		c[n][i]=a[n][i];		
	}
	for(int i=1;i<=n;i++)
	{
		c[i][1]=a[i][1];		
	}
	for(int i=1;i<=n;i++)
	{
		c[i][n]=a[i][n];		
	}
	if(ff(n)==1)
	{
		return 0;
	}
	for(int i=1;i<=n;i++)
	{
		c[1][i]=a[i][1];		
	}
	for(int i=1;i<=n;i++)
	{
		c[n][i]=a[n-i+1][n];		
	}
	for(int i=1;i<=n;i++)
	{
		c[i][1]=a[n][i];		
	}
	for(int i=1;i<=n;i++)
	{
		c[i][n]=a[1][i];		
	}
	if(ff(n)==1)
	return 1;
	for(int i=1;i<=n;i++)
	{
		c[1][i]=a[n][n-i+1];		
	}
	for(int i=1;i<=n;i++)
	{
		c[n][i]=a[n-i+1][1];		
	}
	for(int i=1;i<=n;i++)
	{
		c[i][1]=a[n-i+1][n];		
	}
	for(int i=1;i<=n;i++)
	{
		c[i][n]=a[n-i+1][1];		
	}
	if(ff(n)==1)
	return 2;
	for(int i=1;i<=n;i++)
	{
		c[i][1]=a[1][n-i+1];		
	}
	for(int i=1;i<=n;i++)
	{
		c[i][n]=a[n-i+1][n];		
	}
	for(int i=1;i<=n;i++)
	{
		c[1][i]=a[i][n];		
	}
	for(int i=1;i<=n;i++)
	{
		c[n][i]=a[i][1];		
	}
	if(ff(n)==1)
	return 1;
	return -1;
}

int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		cin>>n;
		
		for(int i=1;i<=n;i++)
		{
			for(int w=1;w<=n;w++)
			{
				cin>>a[i][w];
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int w=1;w<=n;w++)
			{
				cin>>b[i][w];
			}
		}
		int x=f(n);
		cout<<x<<endl;
	}
	//system("pause");
}










//#include"stdio.h"
//#include"string.h"
//#include"math.h"
//#include"stdlib.h"
//
//int main()
//{
//	int t;
//	scanf("%d",&t);
//	for(int w=0;w<t;w++)
//	{
//		int n;
//		scanf("%d",&n);
//		int a[100005];
//		int sum=0;
//		for(int i=0;i<n;i++)
//		{
//			scanf("%d",&a[i]);
//			int num=0;
//			for(int s=i;s>=0;s--)
//			{
//				num+=a[s];
//				if(num==7777)
//				{
//					sum++;
//					break;
//				}
//				if(num>=7777)
//				break;
//			}
//		}	
//		printf("%d\n",sum);
//	}
//	//system("pause");
//}
