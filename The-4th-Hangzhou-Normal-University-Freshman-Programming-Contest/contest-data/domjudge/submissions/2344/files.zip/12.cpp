#include<stdio.h>
int main(void){
	int t;
	long long n,x;
	scanf("%d",&t);
	while(t--){
		scanf("%lld%lld",&n,&x);
		if(n<x||x==0)
			printf("no\n");
		else
			printf("yes\n");
	}
	return 0;
}