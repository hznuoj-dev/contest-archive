#include<stdio.h>
 
int main(){
	int t;
	scanf("%d",&t);
	int n,x;
	int i;
	while(t--){
		scanf("%d %d",&n,&x);
		if(x==0){
			printf("no\n");
		}
		else
			printf("yes\n");
	}
	return 0;
}
