#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int main(){
	int x,y;
	x=2500,y=2100;
	int i,j,n,m,a[11],b[11],c[3];
	memset(c,0,sizeof(c));
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		c[a[i]]+=1;
		if(a[i]==0){
			scanf("%d",&b[i]);
		}
	}
	if(c[2]>0&&n>=2)
		printf("haoye\n");
	else if(c[1]>0&&c[0]>0){
		for(i=0;i<n;i++){
			if(a[i]==0){
				if(m==0&&b[i]>=x){
					printf("haoye\n");
					break;
				}
				else if(m==1&&b[i]>=y){
					printf("haoye\n");
					break;
				}
				else
					continue;
			}
		}
		if(i==n)
		printf("QAQ\n");
	}
	else
		printf("QAQ\n");
}
