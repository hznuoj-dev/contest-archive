#include<stdio.h>
#include<stdlib.h>
struct song{
	long long int level;
	char geming[19];
};
int comp(const void*p,const void *q){
	return((struct song*)q)->level-((struct song*)p)->level;
}
int main(void){
struct song s[10000];
int n,k;
scanf("%d",&n);
for(int i=0;i<n;i++){
	scanf("%lld %s",&s[i].level,s[i].geming);
}
scanf("%d",&k);
qsort(s,n,sizeof(struct song),comp);
for(int i=k;i<n;i++){
printf("%s ",s[i].geming);
}
 return 0;
}
