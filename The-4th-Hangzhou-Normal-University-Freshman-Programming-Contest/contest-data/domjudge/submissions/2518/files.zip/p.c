#include <stdio.h>
struct g
{
	char na[20];
	long long int pp;
	int rank;
	
}gg[100004];
int rank1[100004];
int main()
{
	int a,b,c,d,e;
	scanf("%d",&a);
	for(b=1;b<=a;b++)
	{
		scanf("%ld %s",&gg[b].pp,gg[b].na);
	}
	for(c=1;c<=a;c++)
	{
		for(d=1;d<=a;d++)
		{
			if(gg[c].pp<gg[d].pp)
				gg[b].rank=gg[b].rank+1;
		}
		rank1[gg[b].rank]=c;
	}
	scanf("%d",&e);
	printf("%s\n",gg[rank1[e]].na);
	return 0;
}