#include <stdio.h>
#include <math.h>
int main(void){
	int T,i,a,b,c,ans;
	int N[100],j,k;
	long long int x[40][20];
	scanf("%d",&T);
	for(i=0;i<T;i++){
		a=0;
		b=0;
		c=0;
		scanf("%d",&N[i]);
		for(j=0;j<2*N[i];j++){
			for(k=0;k<N[i];k++){
				scanf("%lld",&x[j][k]);
			}
		}
		for(j=0;j<N[i];j++){
			for(k=0;k<N[i];k++){
				if(x[j][k]==x[2*N[i]-1-j][N[i]-1-j]) a=a+1;
			}
		}
		for(j=0;j<N[i];j++){
			for(k=0;k<N[i];k++){
				if(x[j][k]==x[k][2*N[i]-1-j]) b=b+1;
			}
		}
		for(j=0;j<N[i];j++){
			for(k=0;k<N[i];k++){
				if(x[j][k]==x[2*N[i]-1-k][j]) c=c+1;
			}
		}
		if(a==N[i]*N[i]) ans=2;
		else if(b==N[i]*N[i]) ans=1;
		else if(c==N[i]*N[i]) ans=1;
		else ans=-1;
		printf("%d\n",ans);
	}
	return 0;
}

















