#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	int t, n, i, sum,j;
	int a[100000];
	scanf("%d", &t);
	while(t--)
	{
		int k = 0;
		
		scanf("%d", &n);
		for(i=0;i<n;++i)
		{
			scanf("%d", &a[i]);
		}
		for(i=0;i<n;++i)
		{
			sum = 0;
			for(j=i;j<n;++j)
			{
				sum +=a[j];
				if(sum==7777)
				{
					++k;
				}
			}
		}
		printf("%d\n", k);
	}
}
