#include<stdio.h>
int main()
{
	int n;
	scanf("%d", &n) != EOF;
	while (n > 0)
	{
		printf("Welcome to HZNU\n");
		n--;
	}
	return 0;
}