#include <stdio.h>
#include <string.h>
#include <stdlib.h>
char w[1050][35];

int main(void) {
	int T, i, j, k, n;
	scanf("%d", &T);
	while (T--) {
		i = 0, j = 0;
		while (scanf("%s", w[i]) != EOF) {
			k = strlen(w[i]) - 1;
			if (w[i][k] == '.' || w[i][k] == '!' || w[i][k] == '?') {
				i++;
				break;
			}
			i++;
		}
		n = i;
		printf("%s ", w[0]);
		for (i = 0; i < k; ++i) {
			printf("%c", w[n - 1][i]);
		}
		if (n > 1) {
			printf(" ");
		}

		for (i = 1; i < n; ++i) {
			if (n % 2 == 1) {
				if (2 * i == n - 1) {
					printf("%s", w[i]);
					break;
				}
				printf("%s", w[i]);
				printf(" ");
				printf("%s", w[n - 1 - i]);
				printf(" ");
			} else {

				printf("%s", w[i]);
				printf(" ");
				printf("%s", w[n  - i - 1]);
				printf(" ");
				if (n - 2 * i == 2) {

					break;
				}
			}

		}
		printf("%c", w[n - 1][k]);
		printf("\n");
	}
}