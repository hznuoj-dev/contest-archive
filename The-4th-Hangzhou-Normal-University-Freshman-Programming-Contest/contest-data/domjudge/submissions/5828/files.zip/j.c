#include <stdio.h>
#include <math.h>
#include <string.h>
int main(void){
	int n,m,i,end=0;
	scanf("%d%d",&n,&m);
	int a[n],f[n+1],b;
	memset(f,1,sizeof(f));
	for(i=0;i<n;i++){
		scanf("%d %d",&a[i],&b);
		if(a[i]==0){
			if(m==0)
				if(b>=2500)
					f[i]=0;
			else if(m==1)
				if(b>=2100)
					f[i]=0;
		}
		else if(a[i]==1){
			if(f[i-1]==0){
				end=1;
				break;
			}
		}
		else if(a[i]==2){
			if(f[i-1]==1){
				end=1;
				break;
			}
		}
	}
	if(end)
		printf("haoye");
	else
		printf("QAQ");
	return 0;
}

