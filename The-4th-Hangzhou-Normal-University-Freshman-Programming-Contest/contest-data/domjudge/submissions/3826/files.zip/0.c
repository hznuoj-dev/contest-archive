#include<stdio.h>
int main(){
	int n, m, k, i, b, c, o, d=0, a[10];
	scanf("%d %d",&n,&m);
	if(m==0){
		c=2500;
	}
	else if(m==1){
		c=2100;
	}
	for(i=0;i<=n;i++){
		scanf("%d",&a[i]);
		
		if(a[i]==0){
			scanf("%d",&b);
			if(b>=c){
				o=0;
			}
		}
		else if(a[i]==1){
			if(o==0){
				printf("haoye");
				break;
			}
		}
		else if(a[i]==2){
			if(i+2<n){
				printf("haoye");
				break;
			}
		}
		if(i+1==n){
			printf("QAQ");
			break;
		}
		if(o==0){
			d=d+1;
			if(d==2){
				o=1;
			}
		}
	}
	return 0;
}
