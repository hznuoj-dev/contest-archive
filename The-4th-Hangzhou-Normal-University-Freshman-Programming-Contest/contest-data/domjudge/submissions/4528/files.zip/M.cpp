#include<stdio.h>
#include<string.h>
char a[1000][1000];
char b[1][1000];
int main(){
	int n,m;
	scanf("%d",&n);
	for(int j=0;j<n;j++){
		for(int z=0;a[z-1][strlen(a[z-1])-1]!='.'&&a[z-1][strlen(a[z-1])-1]!='!'&&a[z-1][strlen(a[z-1])-1]!='?';z++){
			scanf("%s",a[z]);
			m=z+1;
		}
	b[0][0]=a[m-1][strlen(a[m-1])-1];
		a[m-1][strlen(a[m-1])-1]='\0';
		if(m%2==0){
			for(int z=0;z<=m/2-1;z++){
				printf("%s %s",a[z],a[m-1-z]);
				if(z==m/2-1){
					printf("%c",b[0][0]);
				}
				else{
					printf(" ");
				}
			}
		}
		else{
			for(int z=0;z<=(m-1)/2-1;z++){
				printf("%s %s",a[z],a[m-1-z]);
				if(z==(m-1)/2-1){
					printf(" %s",a[(m-1)/2]);
					printf("%c",b[0][0]);
				}
				else{
					printf(" ");
				}
			}
		}
		printf("\n");
	}
	return 0;
}
