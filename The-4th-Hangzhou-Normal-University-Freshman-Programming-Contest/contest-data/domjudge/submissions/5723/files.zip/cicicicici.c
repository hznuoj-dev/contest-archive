#include<stdio.h>
#include<string.h>
char a[1011][32]={0};
main()
{
	int t,i,p,n,q;
	char k;
	scanf("%d",&t);
	while(t--)
	{
		i=1;
		while(1)
		{
            scanf("%s",a[i]);
			scanf("%c",&k);
			if(k==' ')i++;
			else if(k=='\n') break;
		}
		n=i;
		p=strlen(a[i])-1;
		k=a[i][p];
		a[i][p]='\0';
		for(q=1;q<=n;q++)
		{
			if (q%2==1) printf("%s",a[(q+1)/2]);
			else printf("%s",a[n+1-q/2]);
			if (q<n) printf(" ");
			else printf("%c\n",k);
		}
	}
}