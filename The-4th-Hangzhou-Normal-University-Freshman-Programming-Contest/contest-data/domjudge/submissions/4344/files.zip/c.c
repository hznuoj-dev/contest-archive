#include<stdio.h>
#include<stdlib.h>
int ai[53000];
char ge[53000][16];
main()
{
	int n,k;
	int i,j;
	int pai=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&ai[i],&ge[i]);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++)
	{
		pai=0;
		for(j=0;j<n;j++)
		{
			if(ai[i]<ai[j])
				pai++;
		}
		if(pai==k)
		{
			printf("%s\n",ge[i]);
			break;
		}
	}
}