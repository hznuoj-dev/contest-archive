#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
main(){
int t,x,i,j,n;
long long k,g;
scanf("%d",&t);
while(t--){
	k=0;
scanf("%d %d",&n,&x);
if(x==0){
printf("no\n");}
else{
printf("yes\n");}
}

}
