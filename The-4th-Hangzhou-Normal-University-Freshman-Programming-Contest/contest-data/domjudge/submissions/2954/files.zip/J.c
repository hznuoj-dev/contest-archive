#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int cmp(const void*p,const void *q)
{
	return *(int*)p-*(int*)q;
}
int main(void)
{
	int i,j;
	int n,m,flag=0,heihe=0;
	int shoupai[15],att[15]={0};
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",shoupai+i);
		if(shoupai[i]==0){
			scanf("%d",att+i);
		}else if(shoupai[i]==1){
			flag=1;
		}else if(shoupai[i]==2){
			heihe=1;
		}
	}
	qsort(att,n,sizeof(int),cmp);
	if(m==0){
		if(att[n-1]>=2500){
			if(flag==0){
				if(heihe){
					if(n>1){
						printf("haoye");
					}else{
						printf("QAQ");
					}
				}else{
					printf("QAQ");
				}
			}else{
				printf("haoye");
			}
		}else{
			printf("QAQ");
		}
	}else if(m==1){
		if(att[n-1]>2100){
			if(flag==0){
				if(heihe){
					if(n>1){
						printf("haoye");
					}else{
						printf("QAQ");
					}
				}else{
					printf("QAQ");
				}
			}else{
				printf("haoye");
			}
		}else{
			printf("QAQ");
		}
	}
	return 0;
}
