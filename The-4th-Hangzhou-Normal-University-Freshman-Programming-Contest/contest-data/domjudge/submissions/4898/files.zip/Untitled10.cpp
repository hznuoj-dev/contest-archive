#include <stdio.h>

int main(void){
	int t;
	scanf("%d",&t);
	for (int i=1; i<=t; i++){
		int n;
		scanf("%d",&n);
		int matrix1[n][n],matrix2[n][n],matrix3[n][n];
		for (int x=0; x<n; x++){
			for (int y=0; y<n; y++){
				scanf("%d",&matrix1[x][y]);
			}
		}
		for (int x=0; x<n; x++){
			for (int y=0; y<n; y++){
				scanf("%d",&matrix2[x][y]);
			}
		}
		int c=0;
		for (int j=1; j<=4; j++){
		
			c=j;
			int judge=1;
			for (int x=0; x<n; x++){
				for (int y=0; y<n; y++){
					matrix3[x][y]=matrix1[n-1-y][x];
				}
			}
			
			for (int x=0; x<n; x++){
				for (int y=0; y<n; y++){
					matrix1[x][y]=matrix3[x][y];
					if (matrix1[x][y]!=matrix2[x][y]) judge=0;
				}
			}
			if (judge==1) break;
			if (j==4) c=5;
		}
		if(c==5) printf("-1\n");
		else if (c<=2) printf("%d\n",c);
		else if (c>2 && c<=4) printf("%d\n",4-c);
	} 
	
	
	
	return 0;
}
