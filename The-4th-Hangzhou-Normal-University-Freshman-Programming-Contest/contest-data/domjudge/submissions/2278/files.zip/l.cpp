#include<bits/stdc++.h>
using namespace std;

int main(){
	int t,n,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&x);
		int flag=0;
		if(x==0)
			printf("no\n");
		else if(n%x==0||n%x==x-1)
			printf("yes\n");
		else
			printf("no\n");
	} 
	return 0;
} 
