#include<stdio.h>
int main(){
	int T,i;
	long long n,x;
	scanf("%d",&T);
	while(T--){
		scanf("%lld %lld",&n,&x);
		for(i=1;i<n;i++){
			if(i*n%x==0){
				printf("yes\n");
				break;
			}
		}
		if(i==n)
			printf("no\n");
	}
	return 0;
}
