#include<stdio.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		printf("Welcome to HZNU\n");
	}
	return 0;
}
