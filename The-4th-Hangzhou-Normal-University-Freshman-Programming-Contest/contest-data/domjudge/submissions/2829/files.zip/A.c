#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 
#include<ctype.h> 
int main()
{
	int i,t,n,flag1,flag[100005];
	char s[100005];
	scanf("%d",&t);
	while(t--)
	{
		memset(flag,0,sizeof(flag));
		flag1=0;
		scanf("%d",&n);
		getchar();
		gets(s);
		int len=strlen(s),length=0;
		for(i=0;i<len;i++)
		{
			if(isalpha(s[i]))
			{
				flag[s[i]-'A'+1]++;
			}
		}
		for(i=0;i<70;i++)
		{
			if(flag[i]%2==0)
			{
				length+=flag[i];
			}	
		}
		int max=0;
		for(i=0;i<70;i++)
		{
			if(flag[i]%2==1&&flag[i]>max)
			{
				max=flag[i];
			}
		}
		printf("%d\n",length+max);
	}
	return 0;
}
