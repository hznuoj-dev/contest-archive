#include<stdio.h>
#include<string.h>
int main(){
	int n,k,i,j,x;
	long long int w[100000];
	char s[20][10000],t[20][10000];
	scanf("%d",&n);
	
		for(i=0;i<n;i++){
			scanf("%lld %s",&w[i],&s[i]);
		}
		
	scanf("%d",&k);
	if(k==0){
		for(i=0;i<n;i++){
			if(w[i]>w[k]){
				k=i;
			}
		}
		printf("%s",s[k]);
	}
	else{
		for(i=0;i<n;i++){
			for(j=0;j<n-1;j++){
				if(w[j]<w[j+1]){
					x=w[j];w[j]=w[j+1];w[j+1]=x;
					strcpy(t[j],s[j]);
					strcpy(s[j],s[j+1]);
					strcpy(s[j+1],t[j]);
				}
			}
		}
		
			printf("%s",s[k]);
		
			
	}
	return 0;
}
