#include<stdio.h> 
int main()
{	
 long long int n;
 int t,i,p,j;
 char c[100009];
 scanf("%d",&t);
 while(t--)
 {
 	p=0;
 	scanf("%lld",&n);
 	getchar();
 	for(i=0;i<n;++i)
 	{
 		scanf("%c",&c[i]);
 		getchar();
	}
	for(i=0;i<n;++i)
		{
			for(j=i+1;j<n;++j)
			{
				if(c[i]==c[j]&&c[i]!='0'&&c[j]!='0')
				{
					c[i]=c[j]='0';
					p=p+1;
					break;
				}
			}
		}
	printf("%d\n",2*p+1); 
    }
}
