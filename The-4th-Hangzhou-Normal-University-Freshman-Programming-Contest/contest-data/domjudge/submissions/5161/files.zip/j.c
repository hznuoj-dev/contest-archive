#include<stdio.h >
#include<stdlib.h >
int main(){
	int n,m,i=0,j,ex,t,p,g;
	scanf("%d%d",&n,&m);
	t=n;
	int x[n],k[n];
	for(i=0;i<n;i++){
		scanf("%d",&x[i]);
		if(x[i]==0)
			scanf("%d",&k[i]);
	}
	for(i=0;i<t;i++){
		if(t>=2 && x[i]==2){
			ex=1;
		}
	}
	for(i=0;i<n;i++){
		if(x[i]==0)
			p=1;
	}
	for(i=0;i<n;i++){
		if(k[i]>=2500||k[i]>2100)
			g=1;
	}
	if(t>=2&&g==1){
		for(i=0;i<n;i++){
			if(p==1&&x[i]==1)
				ex=1;
		}
	}
	if(ex)
		printf("haoye\n");
	else 
		printf("QAQ\n");
	return 0;
}
