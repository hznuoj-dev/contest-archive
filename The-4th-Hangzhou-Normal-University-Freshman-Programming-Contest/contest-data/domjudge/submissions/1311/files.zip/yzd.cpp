#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
int main () {
    cnm;
    int t;
    cin >> t;
    while (t--){
        cout << "Welcome to HZNU" <<endl;
    }

    return 0;
}