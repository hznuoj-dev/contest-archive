#include<stdio.h>
#include<stdlib.h>
#include<string.h> 
typedef struct{
	int cishu;
	char name[20]
}sing;
int cmp(const void*a,const void*b){
	sing *p=(sing*)a,*q=(sing*)b;
	if(p->cishu<q->cishu)
	return 1;
	else if(p->cishu>q->cishu)
	return -1;
	else return 0;
}
int main(void){
	sing s1[100];
	int n,i,k=0,a=0,j,t=0;
	char ch=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&s1[i].cishu,s1[i].name);
	}
	scanf("%d",&k);
	qsort(s1,n,sizeof(sing),cmp);
	for(i=0;i<n;i++){
		if(i==k)
			printf("%s",s1[i].name);
	}
	return 0;
} 
