#include<stdio.h>
struct song
{
	int favor;
	char name[1000];
}stu[100001];
int main()
{
	int n,i,t,k,j;
	struct song temp;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&stu[i].favor,stu[i].name);
	}
	scanf("%d",&k);
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(stu[j].favor<stu[j+1].favor)
			{
				temp=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=temp;
			}
		}
	}
	printf("%s",stu[k].name);
	return 0;
}
