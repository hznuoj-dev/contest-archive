
#define N 100001
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
int arr[N] = { 0 };
char brr[N][16] = { 0 };

int main()
{
	char trr[16] = { 0 };
	int P, i, j, t;
	int chen, flag;
	scanf("%d", &P);
	for (i = 0; i < P; i++)
	{
		scanf("%d %s", &arr[i], &brr[i]);
	}
	for (i = 0; i < P - 1; i++)
	{
		flag = 0;
		for (j = 0; j < P - 1 - i; j++)
		{
			if (arr[j + 1]>arr[j])
			{
				t = arr[j]; arr[j] = arr[j + 1]; arr[j + 1] = t;
				strcpy(trr, brr[j]); strcpy(brr[j], brr[j + 1]); strcpy(brr[j + 1], trr);
				flag = 1;
			}
		}
		if (flag == 0)
			break;
	}
	scanf("%d", &chen);
	printf("%s", brr[chen]);
}