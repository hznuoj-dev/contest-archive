#include<stdio.h>
#include<string.h>
int main(){
	int n;
	long w[10001],t;
	char s[10001][16],s1[16];
	int k;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%ld",&w[i]);
		getchar();
		scanf("%s",s[i]);                           
	}
	scanf("%d",&k);
	k=k+1;
	for (int i=n;i>1;i--){
		for (int j=n;j>n-i+1;j--){
			if(w[j]>w[j-1]){
				t=w[j];
				w[j]=w[j-1];
				w[j-1]=t;
				strcpy(s1,s[j]);
				strcpy(s[j],s[j-1]);
				strcpy(s[j-1],s1);
			}                            
		}
	}
	printf("%s",s[k]);
	return 0;
}
