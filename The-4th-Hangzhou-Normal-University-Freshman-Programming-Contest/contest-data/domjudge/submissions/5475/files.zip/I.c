#include <stdio.h>
#include <stdlib.h>

struct music{
	int w;
	char s[20];
};

int comp(const void *p,const void *q){
	return ((struct music *)q)->w-((struct music *)p)->w;
}

int main(){
	int n,k,i;
	scanf("%d",&n);
	struct music lyx[n];
	for(i=0;i<n;i++){
		scanf("%d %s",&lyx[i].w,lyx[i].s);
	}
	scanf("%d",&k);
	qsort(lyx,n,sizeof(struct music),comp);
	for(i=k;i<k+1;i++){ 
		printf("%s\n",lyx[i].s);} 
	return 0; 
} 
