#include<stdio.h>
int main(){
	int t,n,m,i,j,a,x,sa[10],y=1,sc[10];
	scanf("%d %d",&n,&m);
	for(i=0;i<10;i++){
		sa[i]==3;
	}
	j=0;
	while(n--){
		scanf("%d",&sa[j]);
		if(sa[j]==0){
			scanf("%d",&sc[j]);
		}
		j++;
	}
	for(i=0;i<j;i++){
		if(sa[i]==2){
			if(j>1){
				printf("haoye");
				y=0;
			}
		}else if(sa[i]==0){
			if(m==0&&sc[i]>=2500){
				for(a=0;a<j;a++){
					if(sa[a]==1){
						printf("haoye");
				        y=0;
				        break;
					}
				}
			}else if(m==1&&sc[i]>2100){
				for(a=0;a<j;a++){
					if(sa[a]==1){
						printf("haoye");
				        y=0;
				        break;
					}
				}
			}
		}
		if(y==0){
			break;
		}
	}
	if(y){
		printf("QAQ");
	} 
	return 0;
}
