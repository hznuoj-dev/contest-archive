#include <stdio.h>
#include <stdlib.h>
struct f{
	long long a;
	char s[16];
};
int comp(const void *q,const void *p){
	return ((struct f *)p)->a - ((struct f *)q)->a;
}
int main(){
	long long n,k,i;
	struct f h[100000];
	scanf("%lld",&n);
	for(i=0;i<n;i++){
	scanf("%lld %s",&h[i].a,h[i].s);
	}
	scanf("%lld",&k);		
	qsort(h,n,sizeof(struct f),comp);	
		for(i=0;i<n;i++){
			if(i==k){
		printf("%s",h[k].s);
		}
		}
		return 0;
}
