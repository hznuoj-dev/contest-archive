#include<stdio.h>
int main(void){
	int t=0,n,i,j,a=0,b=0,c=0,k,h;
	char ch[100000];
	scanf("%d",&h);
	for(k=0;k<h;k++){
		scanf("%d",&n);
		a=0;b=0;c=0;
		for(i=0;i<n;i++){
			scanf("%c",&ch[i]);
		}
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				t=ch[i]-ch[j]; 
				if(t==0&&i!=j){
					a=a+1;
				}
			}
		}
		if(a==0){
			printf("1\n");
			continue;
		}
		else if(a!=0){
			for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				t=ch[i]-ch[j];
				if(t==0){
					b=1;
					break;
				} 
			}
			if(b!=1){
				c++;
				break;
			}
		}
		printf("%d\n",a+c);
		continue;
		}
	}
	return 0;
} 
