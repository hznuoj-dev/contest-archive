#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int comp(const void *q, const void *p);

struct si {
	int love;
	char name[16];
};
struct si song[100050];

int k[100050];

int main(void) {

	long long t;
	int n, i, j, i1, j1, flag;
	struct si x;
	scanf("%d", &n);
	for (i = 0; i < n; ++i) {
		scanf("%d", &song[i].love);
		scanf("%s", song[i].name);
	}
	scanf("%lld", &t);
	qsort(song, n, sizeof(struct si), comp);
	printf("%s\n", song[t].name);




}

int comp(const void *q, const void *p) {
	struct si *qq = (struct si *)(q);
	struct si *pp = (struct si *)(p);
	int h = qq->love;
	int k = pp->love;
	return k - h;
}
