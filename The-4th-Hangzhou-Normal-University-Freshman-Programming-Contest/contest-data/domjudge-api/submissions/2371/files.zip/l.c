#include<stdio.h>
int main(void)
{
	int t,n,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&x);
		if(x!=0)
			printf("yes\n");
		else if(x==0)
			printf("no\n");
	}
	return 0;
}
