#include<stdio.h>
main() {
	int n,i,a[100000],max,j=0,k;
	char b[100000][15];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		scanf("%s", &b[i]);
	}
	scanf("%d", &k);
	max = a[0];
	for (i = k+1; i < n; i++) {
		if(a[i]>max){
			max = a[i];
			j = i;
		}
	}
	printf("%s", b[j]);
}