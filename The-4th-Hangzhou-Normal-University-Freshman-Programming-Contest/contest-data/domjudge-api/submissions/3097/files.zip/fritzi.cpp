#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<cmath>
#include<cctype>
using namespace std;
int main(){
long int n,i,j;
cin>>n;
map<long long int,string>ss;
long long int w;
string s;
for(i=0;i<n;i++){
	cin>>w>>s;
  ss.insert(make_pair(w,s));
}
map<long long int,string>::iterator pos;
long int k;
cin>>k;
pos=ss.end();
while(k--){
	pos--;
}pos--;
cout<<pos->second<<endl;
}
