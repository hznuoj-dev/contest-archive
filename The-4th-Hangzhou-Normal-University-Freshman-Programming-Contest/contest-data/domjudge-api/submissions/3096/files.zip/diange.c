#include <stdio.h>
#include <stdlib.h>
typedef struct{
	char s[16];
	long long w;
} e;
int comp(void *p,void *q)
{
	long long a,b;
	a=((e*)p)->w;
	b=((e*)q)->w;
	if(a>b)
	{
		return -1;
	}
	else
	{
		return 1;
	}
}
int main(void)
{
	long long n,k;
	scanf("%lld",&n);
	e m[n];
	for(int i=0;i<n;i++)
	{
		scanf("%lld%s",&m[i].w,m[i].s);
	}
	qsort(m,n,sizeof(e),comp);
	scanf("%lld",&k);
	printf("%s\n",m[k].s);
	return 0;
}
