#include<stdio.h>
int a[3];
int main(void){
	int n,m,x,k,tr=0;
	scanf("%d",&n,&m);
	if(m==0)m=2500;
	else m=2100;
	for(int i=0;i<n;i++){
		scanf("%d",&x);
		if(x==1){
			scanf("%d",k);
			if(k>m)tr=1;
		}else if(x==2){
			a[1]=1;
		}else{
			a[2]=1;
		}
	}
	if(tr&&a[1]||a[2]&&n>1)printf("haoye\n");
	else printf("QAQ\n");
}
