#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	getchar(); 
	for(int w=0;w<t;w++)
	{
		string a[1002];
		string ch;
		getline(cin,ch);
		//string xh=ch.substr(0, 4);
		int j=0;
		int k=0;
		int x=ch.size()-1;
		string str=ch.substr(x, 1);
		for(int i=0;i<x;i++)
		{
			if(ch[i]==' ')
			{
				a[k]=ch.substr(j, i-j);
				k++;
				j=i+1;
			}
			if(i==x-1)
			{
				a[k]=ch.substr(j, i-j+1);
				k++;
				j=i+1;
			}
		}
		int i=0;j=k-1;
		while(i<=j)
		{
			if(i!=0)
				cout<<" ";
			if(i!=j)
				cout<<a[i]<<" "<<a[j];
			else
				cout<<a[i];
			i++;
			j--; 
		}
		cout<<str<<endl;
	}
	//system("pause");
}











//#include<iostream>
//#include<string>
//#include<cstring>
//#include<algorithm>
//#include<cmath>
//#include<ctype.h>
//using namespace std;
//
//int main()
//{
//	int t;
//	cin>>t;
//	for(int w=0;w<t;w++)
//	{
//		int n;
//		cin>>n;
//		int a[100005];
//		for(int i=0;i<n;i++)
//		{
//			cin>>a[i];
//		}
//		int i=0,j=0;
//		int num=0;
//		int sum=0;
//		while(j<n)
//		{
//			num+=a[j];
//			j++;
//			if(num==7777)
//			{
//				sum++;
//			}
//			while(num>=7777)
//			{
//				num-=a[i];
//				i++;
//			}
//		}
//		cout<<sum<<endl;
//	}
//	//system("pause");
//}
