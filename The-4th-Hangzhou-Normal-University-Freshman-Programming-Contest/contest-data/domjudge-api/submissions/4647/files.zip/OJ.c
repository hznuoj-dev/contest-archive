#include <stdio.h>
#include <string.h>

int main() {
	int t, b, c;
	char word[40000], word1[1005][35] = { 0 };
	scanf("%d", &t);
	getchar();
	while (t--) {
		char word1[1005][35] = { 0 };
		gets(word);
		int x = 0, y, z = 0;
		int f = strlen(word) - 1;
		while (z < f) {
			y = 0;
			for (b = z; word[b] != ' '; b++) {
				word1[x][y] = word[b];
				y++;
				if (b == f - 1)
					break;
			}
			x++;
			z = b + 1;
		}
		int t = 0, h = x - 1, g = x;
		if (x % 2 == 0) {
			while (g > 0) {
				printf("%s ", word1[t]);
				printf("%s", word1[h]);
				if (g != 2)
					printf(" ");
				t++;
				h--;
				g -= 2;
			}
			printf("%c\n", word[strlen(word) - 1]);
		} else {
			while (g > 1) {
				printf("%s ", word1[t]);
				printf("%s ", word1[h]);
				t++;
				h--;
				g -= 2;
			}
			int u = x / 2;
			printf("%s", word1[u]);
			printf("%c\n", word[strlen(word) - 1]);
		}
	}
	return 0;
}
