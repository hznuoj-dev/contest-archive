#include<stdio.h>
#include<string.h>
int main(void){
	char s[10001][31],c;
	int t,x,i,n,y;
	scanf("%d ",&t);
	while(t--){
		i=1;
		while(scanf("%s",s[i])!=EOF){
			n=strlen(s[i]);
			if(s[i][n-1]=='.'||s[i][n-1]=='?'||s[i][n-1]=='!')
				break;
			i+=1;
		}
		c=s[i][n-1];
				s[i][n-1]='\0';
				y=(i+1)/2;
		for(x=1;x<y;x++)
			printf("%s %s ",s[x],s[i-x+1]);
		if(i%2==1)
			printf("%s",s[y]);
		else{
			printf("%s %s",s[y],s[y+1]);
		}
		printf("%c\n",c);
	}
}