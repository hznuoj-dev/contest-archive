#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<map>
#include<iomanip>
#include<ctime>
using namespace std;

class tzg
{
public:
	int x;
	string name;
};
tzg a[100010];
bool cmp(tzg a, tzg b)
{
	return a.x > b.x;
}
int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i].x >> a[i].name;
	}
	sort(a, a + n, cmp);
	int k;
	cin >> k;
	cout << a[k].name;
}