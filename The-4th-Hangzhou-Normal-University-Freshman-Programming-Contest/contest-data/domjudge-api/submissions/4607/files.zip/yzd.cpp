#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
char a[100001];
int b[54];
int main () {
	cnm;
	int t;
	cin >> t;
	while (t--){
		int ans=1;
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		int n;
		cin >> n;
		for (int i = 0 ; i<n ; i++){
			cin >> a[i];
			b[a[i]-65]++;
		}
		for (int i = 0 ; i<54 ; i++){
			if (b[i]!=1) ans+=b[i];
		}
		cout << ans <<endl;
	}
	return 0;
}
