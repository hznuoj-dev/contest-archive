#include<stdio.h>//�ٻٻ����������˻˻�����
#pragma warning(disable:4996)
int main()
{
	int n, m;
	int sum = 0, card, atk, kind = 0, fhr;
	scanf("%d %d", &n, &m);
	if (m == 1)
		fhr = 2101;
	else
		fhr = 2500;
	while (n--)
	{
		scanf("%d", &card);
		if (card == 0)
		{
			scanf("%d", &atk);
			sum += atk;
		}
		else if (card == 1)
			kind = 1;
		else if (card == 2)
		{
			if (n >= 2)
			{
				kind = 2;
				break;
			}
		}
	}

	if (kind == 2)
		printf("haoye");
	else if (kind == 1)
	{
		if (sum >= fhr)
			printf("haoye");
		else
			printf("QAQ");
	}
	else
		printf("QAQ");
	return 0;
}
