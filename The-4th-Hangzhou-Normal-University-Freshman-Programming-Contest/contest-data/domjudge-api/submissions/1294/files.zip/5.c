#include<stdio.h>
#include<math.h>
int main(void)
{
	int t, x, y,i,j,m,n;
	scanf("%d", &t);
	for (i = 1; i <= t; i++) {
		n = 0;
		scanf("%d%d", &x, &y);
		m = x + y;
		for (j = 0; j <= abs(x - m); j++) {
			if ((m + j) % 4 == 0 && (m + j) % 100 != 0)
				n++;
			if ((m + j) % 400 == 0)
				n++;
		}
		printf("%d\n", n);
	}
	return 0;
}









