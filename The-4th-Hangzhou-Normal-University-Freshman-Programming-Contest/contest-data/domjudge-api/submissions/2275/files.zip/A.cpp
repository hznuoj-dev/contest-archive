#include <bits/stdc++.h>
using namespace std;

int main(){
	int n,t,x,i;
	cin>>t;
	for (i=0;i<t;++i){
		cin>>n>>x;
		if (x==0) cout<<"no"<<'\n';
		else cout<<"yes"<<'\n';
	}
	
	return 0;
} 
