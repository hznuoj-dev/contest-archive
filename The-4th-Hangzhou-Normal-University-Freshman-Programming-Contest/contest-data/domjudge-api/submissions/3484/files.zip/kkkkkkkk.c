#include<stdio.h>
#include<stdlib.h>
struct fb {
	int a;
	char x[16];
};
int comp(const void *p,const void *q) {
	return ((struct fb *)q)->a-((struct fb *)p)->a;
}
int main() {
	int n,k,i;
	scanf("%d",&n);
	struct fb y[n];
	for(i=0; i<n; i++) {
		scanf("%d%s",&y[i].a,y[i].x);
	}
	scanf("%d",&k);
	qsort(y,n,sizeof(struct fb),comp);
	printf("%s",y[k].x);
	return 0;
}


