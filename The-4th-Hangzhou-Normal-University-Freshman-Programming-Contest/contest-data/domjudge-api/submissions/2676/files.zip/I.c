#include<stdio.h>
struct song_stru 
{
	long long num;
	char name[20];
}a[100001],t;
int main()
{
	int i,j,n;
	scanf("%d",&n);
	for (i = 0; i < n; i++)
	{
		scanf("%lld%s",&a[i].num,a[i].name);
	}
	int k;
	scanf("%d",&k);
	for (j = 0; j < n - 1; j++)
	{
		for (i = j+1; i < n; i++)
		{
			if (a[i].num > a[j].num)
			{
				t = a[j];
				a[j] = a[i];
				a[i] = t;
			}
		}
	}
	printf("%s\n",a[k].name);
	return 0;
}