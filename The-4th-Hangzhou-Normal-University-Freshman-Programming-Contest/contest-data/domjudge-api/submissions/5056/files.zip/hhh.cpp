#include<stdio.h>
int main(){
	int m,n,i,j,t,a[12],x;
	int s,y,y1,y2,b[12];
	scanf("%d %d",&n,&m);
	x=0;
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0){
		scanf("%d",&b[x]);
		x=x+1;
	}
	}
	s=0;
	y=0;
	y1=0;
	y2=0;
	for(i=0;i<x;i++){
			if(m==0){
		if(b[i]>=2500)
		y=1;
	}
	if(m==1){
		if(b[i]>2100)
		y=1;
	}
		}
		for(i=0;i<n;i++){
			if(a[i]==1)
			y1=1;
			if(a[i]==2)
			y2=1;
		}
	
	
 if((y==1&&y1==1)||(y2==1&&n>=2))
	printf("haoye");
	else
	printf("QAQ");

}
