#include <stdio.h>
#include <stdlib.h>

struct a {
	int w;
	char s[16];
};

int comp (const void *p, const void *q) {
	return ((struct a *)q)->w - ((struct a *)p)->w;
}

int main(void) {
	int n, k;
	scanf("%d", &n);
	struct a r[n];
	for (int i = 0; i < n; i++) {
		scanf("%d %s", &r[i].w, r[i].s);

	}
	scanf("%d", &k);
	qsort(r, n, sizeof(struct a), comp);

	printf("%s\n", r[k + 1].s);

	return 0;
}