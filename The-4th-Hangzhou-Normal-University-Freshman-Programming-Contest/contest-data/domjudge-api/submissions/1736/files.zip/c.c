#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
main(){
int t,x,i,j,n,k;
scanf("%d",&t);
while(t--){
	k=0;
scanf("%d %d",&n,&x);
for(i=1;i<=10;i++){
	if(x==0){
		i=11;
	break;}
	k=i*x;
	if(k%n==0){
	break;}

}
if(i==11){
printf("no\n");}
else{
printf("yes\n");}
}
}
