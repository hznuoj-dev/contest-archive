#include<stdio.h>

int main(void) {
	int n,i,j,k;
	scanf("%d",&n);
	struct sing{
		int w;
		char s[15];
	}p[n+1];
	for(i=0;i<n;i++){
		scanf("%d %s",&p[i].w,p[i].s);
	}
	for(i=0;i<n;i++){
		for(j=0;j<n-1;j++){
			if(p[j].w>p[j+1].w){
				p[n+1]=p[j];
				p[j]=p[j+1];
				p[j+1]=p[n+1];
			}
		}
	}
	scanf("%d",&k);
	printf("%s",p[n-1-k].s);
	return 0;
}

