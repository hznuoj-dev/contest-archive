//#include<stdio.h>
//#include<stdlib.h>
//struct stu{
//		long long int x;
//		char a[20];
//	};
//	struct stu opp[100000],t;
//int comp(const void *q,const void *p)
//{
//	return ((struct stu *)q)->x - ((struct stu *)p)->x;
//}
//int main()	
//{	
//	
//	int n,i,j,k;
//	scanf("%d",&n);
//	for(i=0;i<n;i++)
//	{
//		scanf("%lld %s",&opp[i].x,opp[i].a);
//	}
//	scanf("%d",&k);
//	for(i=0;i<n;i++)
//	{
//	qsort(opp[i].a,n,sizeof(int),comp);
//    }
//	printf("%s\n",opp[k].a);
//	return 0;
//}
#include<stdio.h>
int main()
{
	int n,t,x,a,i;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&x);
		if(x!=0)
		{
			printf("yes\n");
		}
		else printf("no\n");
		
		
	}
	return 0;
}
