#include <iostream>
using namespace std;
int n,p,t;
int a[200];
char ch;
int main ()
{
	cin >> n; 
	for (int i = 1; i <= n; i++)
		{
			cin >> t;
			for (int j = 1; j <= t; j++)
				{
					cin >> ch;
					p=(int)ch;
					a[p]++;
				}
			int max=0,flag=0;
			for (int j = 65; j <= 90; j++)
				if (a[j] % 2 != 0)
				{
					flag=1;
					max=max+a[j]/2;
				} 
				else max=max+a[j]/2;
			for (int j = 97; j <= 97+25; j++)
				if (a[j] % 2 != 0)
				{
					flag=1;
					max=max+a[j]/2;
				} 
				else max=max+a[j]/2;
			max=max*2+flag;
			cout << max << '\n';
			for (int j = 65; j <= 200; j++)
				a[j]=0;				
		}
}
