#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct A{
	int n;
	char c[100000];
	
};
int comp(const void *p,const void *q)
{
	return ((struct A *)q)->n-((struct A *)p)->n;
}
int main(void)
{
	int t;
	scanf("%d",&t);
	struct A a[t];
	int i;
	for(i=0;i<t;i++)
	{
		scanf("%d %s",&a[i].n,a[i].c);
		getchar();
	}
	qsort(a,t,sizeof(struct A),comp);
	int m;
	scanf("%d",&m);
	printf("%s",a[m].c);
	return 0;
} 
