#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct song {
	long long love;
	char s[20];
};
int com(const void*a,const void *b){
	return ((struct song*)b)->love - ((struct song *)a)->love;
}
struct song a[100001],e;
int main (){
	int k,n,i,j;
	
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%lld%s",&a[i].love,a[i].s);
	}
	qsort(a,n,sizeof(struct song),com);
	scanf("%d",&k);
	printf("%s",a[k].s);
}