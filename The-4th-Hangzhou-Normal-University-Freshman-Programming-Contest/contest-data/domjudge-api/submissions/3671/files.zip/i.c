#include<stdio.h>
struct mus {
	long long int num;
	char name[16];
};
int main() {
	struct mus ge[100001];
	int n,t;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%lld%s", &ge[i].num, ge[i].name);
	}
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (ge[j].num < ge[j + 1].num) {
				t = ge[j].num;
				ge[j].num = ge[j + 1].num;
				ge[j + 1].num = t;
			}
		}
	}
	int k;
	scanf("%d", &k);
	printf("%s", ge[k + 1].name);

	