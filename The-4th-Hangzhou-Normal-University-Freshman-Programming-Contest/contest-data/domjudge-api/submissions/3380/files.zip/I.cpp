#include <stdio.h>
#include <stdlib.h>
struct s{
 int x;
 char ch[20];
};
int comp(const void*a,const void*b){
return ((struct s*)b)->x-((struct s*)a)->x;
}
struct s a[100000];
int main(){
 int n,i,k;
 scanf("%d",&n);
 for(i=0;i<n;i++){
  scanf("%d %s",&a[i].x,a[i].ch);
 }
 qsort(a,n,sizeof(struct s),comp);
 scanf("%d",&k);
 printf("%s\n",a[k].ch);
return 0;
}
