#include<bits/stdc++.h>
using namespace std;

int main(void){
	int t,n,x;
	scanf("%d",&t);
	for (int i=1;i<=t;i++){
		scanf("%d%d",&n,&x);
		if (x!=0) printf("yes\n");
		else printf("no\n");
	} 
	return 0;
}

