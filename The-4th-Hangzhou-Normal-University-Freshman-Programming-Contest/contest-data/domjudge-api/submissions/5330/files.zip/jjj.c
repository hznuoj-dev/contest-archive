/*********************************************************************
    ������:
    ����: 2021-12-12 13:43
    ˵��:
*********************************************************************/
#include <stdio.h>

int main() {
	int n, m, x[10], i, j = 0, y[10], num1 = 0, num2 = 0;
	scanf("%d%d", &n, &m);
	if (!n) {
		printf("QAQ");
		return 0;
	}// number of the cards :n ; the situation of the pheonix :m
	for (i = 0; i < n; i++) {
		scanf("%d", &x[i]); //get the information of the card
		if (!x[i]) {
			scanf("%d", &y[j]);//i2f it is monster get its attack degree
			j++;
		}
		if (x[i] == 1)//the pointer ,ruin the monster when you have enough attack degree monster
			num1++;
		if (x[i] == 2)//the black core
			num2++;
	}
	if (num2 && n > 1) {
		printf("haoye");
		return 0;
	}
	if (num1 < 1) {
		printf("QAQ");
		return 0;
	}
	m = (m == 1 ? 2500 : 2100);
	printf("%d", m);
	for (i = 0; i < j; i++) {
		if (y[i] >= m) {
			printf("haoye");
			return 0;
		}
	}
	printf("QAQ");
	return 0;
}
