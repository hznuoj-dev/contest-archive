#include<stdio.h>
struct ch
{
	char s1;
	int b;
};
int main()
{
	struct ch f[100001];
	int t,k,i,n,sum,flag=0;
	scanf("%d",&t);
	while(t--)
	{
		i=0;
		scanf("%d",&k);
		getchar();
		while(i<k)
		{
			f[i].s1=getchar();
			getchar();
			f[i].b=1;
			i++;
		}
		for(i=0;i<k;i++)
		{
			for(n=0;n<k;n++)
			{	
				if(n<i&&f[i].s1==f[n].s1)
				{
					break;
				}
				if(f[i].s1==f[n].s1&&n>i)
				{
					f[i].b=f[i].b+1;
					f[n].b=0;
				}
			}
		}
		flag=0,sum=0;
		for(i=0;i<k;i++)
		{
			if (f[i].b>=2&&f[i].b%2==1&&flag==0)
			{
				sum+=1;
				flag+=1;
			}
			if(f[i].b==1&&flag==0)
			{
				sum+=1;
				flag+=1;
			}
			if(f[i].b>=2)
			{
				sum+=f[i].b/2;
			}
		}
		if(flag==0)
		{
			printf("%d\n",2*sum);
		}
		else if(flag==1)
		{
			printf("%d\n",2*(sum-1)+1);
		}
	}
	return 0;
}

