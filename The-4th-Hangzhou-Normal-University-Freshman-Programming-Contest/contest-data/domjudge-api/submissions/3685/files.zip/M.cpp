#include<bits/stdc++.h>
using namespace std;
int main()
{ string a[1010]; 
  int len,n,m,j,k,l,i,p;
  char fh;
  cin>>n;
  for (i=1;i<=n;i++)
  { len=0;
    while ( (a[len][a[len].length()-1]!='!' && a[len][a[len].length()-1]!='.'&&a[len][a[len].length()-1]!='?') || len==0)
    {
     len++;
     cin>>a[len];
    }
     fh=a[len][a[len].length()-1];
     a[len][a[len].length()-1]='\0';
    for (j=1;j<=len;j++)
    {if (j==2 || len==1)
	 { for (p=0;p<a[len].length()-1;p++)
	    cout<<a[len][p];
     } else
     if (j%2==0) cout<<a[len-j/2+1]; else cout<<a[j/2+1];
     if (j!=len) cout<<" ";
    }
    cout<<fh<<"\n";
  }
} 
