#include <stdio.h>
struct bom{
	int a;
	char ch[20];
};
int main()
{
	int n,i,j,k;
	scanf("%d",&n);
	struct bom w[n+1],t;
	for(i=1;i<=n;i++)
	{
		scanf("%d%s",&w[i].a,w[i].ch);
	}
	scanf("%d",&k);
	for(i=1;i<n;i++)
	{
		for(j=1;j<=n-i;j++)
		{
			if(w[j].a <w[j+1].a )
			t=w[j],w[j]=w[j+1],w[j+1]=t;
		}
	}
	printf("%s",w[k+1].ch );
}
