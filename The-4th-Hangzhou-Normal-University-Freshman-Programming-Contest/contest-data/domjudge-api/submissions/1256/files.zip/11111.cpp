#include<bits/stdc++.h>
#include<iosfwd>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<string>
#include<vector>
#include<stack>
#include<bitset>
#include<cstdlib>
#include<cmath>
#include<set>
#include<list>
#include<deque>
#include<map>
#include<queue>  
#define endl '\n'; 
using namespace std;
typedef long double ld;
typedef long long ll;
const double eps = 1e-6;
const ll INF = 2e5+100;
#define ywh666 ios_base::sync_with_stdio(0);cin.tie(0);
bool is_prime(ll a){
    if(a < 0) return false;
    if(a == 0 || a == 1 ) return false;
    if(a == 2 || a == 3) return true;
    for(ll i = 2 ; i <= sqrt(a) ; ++i){
        if(a % i == 0) return false;
    }
    return true;
}
const ll  mod = 1e9+7;
ll qpow(ll x , ll n ){
    ll ans = 1;
    while(n > 0){
        if(n & 1 == 1){
            ans = ans * x  % mod ;
        }
        x = x * x % mod;
        n >>= 1;
    }
    return ans % mod;
}
int main(){
    ll n ;
    cin >> n ;
    while(n--){
        cout << "Welcome to HZNU" << endl;
    }


    return 0 ;
}