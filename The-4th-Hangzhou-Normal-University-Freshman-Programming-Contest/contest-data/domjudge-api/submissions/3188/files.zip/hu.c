#include<stdio.h>
int main()
{
	int n,  w ,i;
	char s[15];
	char c[15];
	scanf("%d", &n);
	scanf("%d", &w);
	while (n--)
	{
		scanf("%d", &i);
		if (i < w)
		{
			scanf("%s", s);
			w = i;
		}
		else
			scanf("%s", c);
	}
	printf("%s", s);
	return 0;
}