#include <stdio.h>
int main(){
	
	char c[100];
	long long a,b=0,n;
	scanf("%lld",&n);
	while(n--){
	scanf("%lld",&a);
	for(int i=0;i<a;i++){
		scanf(" %c",&c[i]);
		
	}	
		if(a==2||a==1){
			printf("1\n");
		}
		else{
		for(int i=0;i<a;i++){
			for(int j=i+1;j<a;j++){
				if(c[i]==c[j]){
					b=b+2;
					break;
				}
			}
		}
		printf("%lld\n",b+1);
		}
	}
	return 0;
}
