#include<stdio.h>
struct song
{
	int favor;
	char name[10000];
}n[100005],t1;
int main()
{
	int t;
	int i,j;
	int k;
	scanf("%d",&t);
	for(i=0;i<t;i++)
	{
		scanf("%d %s",&n[i].favor,n[i].name);
	}
	scanf("%d",&k);
	for(i=0;i<t-1;i++)
	{
		for(j=0;j<t-1-i;j++)
		{
			if(n[j].favor<n[j+1].favor)
			{
		     	t1=n[j];
				n[j]=n[j+1];
				n[j+1]=t1;
			}
		}
	}
	printf("%s",n[k].name);
	return 0;
}
