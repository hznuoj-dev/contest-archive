#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct ge {
	long long paiming;
	char name[20];
} ;
int comp(const void *p, const void *q);

int main() {
	int n, k;
	struct ge a[100];
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%lld %s", &a[i].paiming, a[i].name);
	}
	scanf("%d", &k);
	qsort(a, n, sizeof(ge), comp);
	printf("%s", a[k].name);
}

int comp(const void *p, const void *q) {
	return ((ge *)q)->paiming - ((ge *)p)->paiming;
}