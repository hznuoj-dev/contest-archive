#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#define MogeKo qwq

using namespace std;

int n,m,x,y;
int p[2];
bool f[5];

int main() {
	scanf("%d%d",&n,&m);
	p[0] = 2500;
	p[1] = 2101;
	for(int i = 1; i <= n; i++) {
		scanf("%d",&x);
		if(x == 1) f[1] = true;
		else if(x == 2) f[2] = true;
		else {
			scanf("%d",&y);
			if(y >= p[m]) f[0] = true;
		}
	}
	if(f[1] && f[0]) printf("haoye");
	else if(f[2] && n>1) printf("haoye");
	else printf("QAQ"); 
	return 0;
}

