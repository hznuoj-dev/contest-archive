#include<stdio.h>
int main(void){
	int T,f;
	long long n,i,j,b,k,t,m;
	char c[100000],d[100000];
	scanf("%d",&T);
	getchar();
	while(T--){
		long long a[100000]={0};
		b=0;
		scanf("%lld",&n);
		getchar();
		for(i=0;i<n;++i){
			scanf("%c",&c[i]);
			getchar();
			f=1;
			for(j=0;j<b;++j){
				if(c[i]==d[j]){
					a[j]++;
					f=0;
					break;
				}
			}
			if(f){
				d[b]=c[i];
				a[b]++;
				b++;
			}
		}
		t=0;
		m=0;
		for(k=0;k<b;++k){
			if(a[k]%2==1){
				if(t==0){
					t=1;
					m+=a[k];
				}
				else
					m+=a[k]-1;
			}
			else
				m+=a[k];
		}
		printf("%d\n",m);
	}
	return 0;
}