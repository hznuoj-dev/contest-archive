#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#define MogeKo qwq

using namespace std;

int t,n,x;

int main() {
	scanf("%d",&t);
	while(t--) {
		scanf("%d%d",&n,&x);
		if(x) printf("yes\n");
		else printf("no\n");
	}
	return 0;
}

