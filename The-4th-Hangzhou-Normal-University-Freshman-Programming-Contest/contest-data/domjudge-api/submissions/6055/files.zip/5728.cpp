#include<stdio.h>
#include<string.h>
int main()
{
    int n,i,t,j,flag=0;
    char spe,s[1010][30],d[1010][30],f[1010][30];
    scanf ("%d" ,&t);
    while(t--)
    {
    	i=n=0;
    	while(scanf("%s",s[i])!=EOF)
    	{
    		n++;
    		int len=strlen(s[i]);
    		if(s[i][len-1]=='.'||s[i][len-1]=='!'||s[i][len-1]=='?')
    		{
    			spe=s[i][len-1];
    			s[i][len-1]='\0';
    			break;
			}
			i++;
    	}
    
    	if(n%2==1)
    	{
    		for(i=0;i<=n/2;++i)
			{
				strcpy(d[i],s[i]);
			}
			for(i=n-1;i>n/2;++i)
			{
				strcpy(f[i],s[i]);
			}
		}
		else
		{
			for(i=0;i<n/2;++i)
			{
				strcpy(d[i],s[i]);
			}
			for(i=n-1;i>=n/2;++i)
			{
				strcpy(f[i],s[i]);
			}
		}
		int x=0,y=0;
		for(i=0;i<n;i++)
		{
			if(i%2==0)
			{
				printf("%s",d[x++]);
				if(x<n/2)
				printf(" ");
			}else
			{
				printf("%s",f[y++]);
				if(y<n/2)
				printf(" ");
			}
		}
		printf("%c\n",spe);
		
	}
    return 0;
} 
