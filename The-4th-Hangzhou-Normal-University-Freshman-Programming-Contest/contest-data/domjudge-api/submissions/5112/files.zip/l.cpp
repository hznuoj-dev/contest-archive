#include<stdio.h>
int main() {
	int n, a, b;
	scanf("%d", &n);
	while (n--) {
		scanf("%d %d", &a, &b);
		if (b != 0) {
			printf("yes\n");
		}
		else {
			printf("no\n");
		}
	}
	return 0;
}