#include<bits/stdc++.h>

using namespace std;
const int N=1e5+10;
int a[N],ans[N]; 
int main()
{
	int t;
	cin >> t;
	for(int i=1;i<=t;i++)
	{
		int n,cnt=0,d=0;
		cin >> n;
		for(int i=1;i<=n;i++)
		{
			char ch;
			cin >> ch;
			int x=ch;
			a[x]++;
			if(a[x]==1)
			{
				ans[++d]=x;
			}
			if(a[x]%2==0&&a[x]!=0) cnt+=2;
			
		}
		if(cnt==0) cnt++;
		else if(cnt<n) cnt++;
		cout << cnt << '\n';
		for(int i=1;i<=d;i++)
		a[ans[i]]=0;
	}
	return 0;
}
