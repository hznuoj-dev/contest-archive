#include <stdio.h>
int main(void)
{
    int a,t,c,k,flag1=0,flag2=0,flag3=0;
    scanf("%d%d",&t,&a);
    while(t--){
    	scanf("%d",&k);
    	if(k==0){
    		scanf("%d",&c);
    		if(a==0){
				if(c>=2500) flag1=1;
			}
			else {
				if(c>2100) flag1=1;
			}
		}
		else if(k==1) flag2=1;
		else flag3=1;
		
	}
	if((flag1==1&&flag2==1)||(flag3==1&&t>1)) printf("haoye");
	else printf("QAQ");
	return 0;
}