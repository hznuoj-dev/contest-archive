#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <sstream>
#include<bits/stdc++.h>
#define ll long long
#define INF 1e6
#define MAXZ 100050 
#define pancake std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
using namespace std;
ll qm (ll base , ll power , ll m){
    ll result = (ll) 1 % m;
    ll t = (ll) base;
    while (power){
        if(power & 1){
            result = result * t % m ;
        }
            t = t * t % m;
            power >>= 1 ;
    }
    return result;
}
typedef struct stu{
       ll a;
       string b;
}stu;
bool cmp (stu x , stu y){
        return x.a > y.a;
}
stu ss[100050];
int main(){
    pancake;
    ll t;
    cin >> t;
    while(t --){
        int big[30] = {0} , small[30] = {0};
        ll n;
        cin >> n;
        while(n --){
            char temp;
            cin >> temp;
            if(temp >= 'A' && temp <= 'Z') big[temp - 'A'] ++;
            else small[temp - 'a'] ++;
        }
        int sum = 0;
        for(int i = 0 ; i < 26 ; i ++){
            if(big[i] >= 2) sum += big[i];
            if(small[i] >= 2) sum += small[i];
        }
        cout << sum + 1 << endl;
    }
    return 0;
}