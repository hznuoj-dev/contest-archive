#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct Mus{
	int num;
	char name[20];
};
int cmp(const void *p,const void *q)
{
	struct Mus *pp =(struct Mus *)(p);
	struct Mus *pq =(struct Mus *)(q);
	int a= pp->num;
	int b= pq->num;
	return b-a;
}
int main()
{
	struct Mus a[101];
	long long t,n,i,k;
		scanf("%lld",&n);
		for(i=0;i<n;++i)
		{
			scanf("%d%s",a[i].num,&a[i].name);
		}
		qsort(a,n,sizeof(struct Mus),cmp);
	scanf("%lld",&k);
	printf("%s",a[k+1].name);	
	return 0;
}
