#include<stdio.h>
#include<string.h>
int main()
{
	int t,i,j,o,p,q;
	char a[2000][32];
	
	scanf("%d",&t);
	while(t--)
	{
		o=0;
		
		for(i=0;a[i][0]!='\n';i++)
		{
           scanf("%s",a[i]);
		   o++;
		    if(a[i][strlen(a[i])-1]==33||a[i][strlen(a[i])-1]==63||a[i][strlen(a[i])-1]==46)
				break;
		}
		p=strlen(a[o-1]);
		if(o>2)
		{
		if(o%2==0)
		{
		for(i=0;i<o/2;i++)
		{
			printf("%s ",a[i]);
			if(i!=0)
			{
			printf("%s",a[o-1-i]);
			if(i!=o/2-1)
				printf(" ");
			}
			else
			{
				for(q=0;q<p-1;q++)
				printf("%c",a[o-i-1][q]);
				printf(" ");
			}
		}
		}
		else
		{
			for(i=0;i<(o+1)/2;i++)
		{
			printf("%s",a[i]);
			if(i!=(o-1)/2)
					printf(" ");
			if(i==(o-1)/2)
					continue;
			else
			{
			if(i!=0)
			{
			printf("%s ",a[o-1-i]);
			}
			else
			{
				for(q=0;q<p-1;q++)
				printf("%c",a[o-i-1][q]);
				printf(" ");
			}
			}
		}
		}
		
		printf("%c",a[o-1][p-1]);
		printf("\n");
		}
		else
		{
			for(i=0;i<o;i++)
			{
				printf("%s",a[i]);
				if(i==0)
					printf(" ");
			}

			printf("\n");
		}
	}
	return 0;
}
