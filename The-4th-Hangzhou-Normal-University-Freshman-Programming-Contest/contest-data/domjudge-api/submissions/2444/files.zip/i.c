#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int comp(const void *p,const void *q){
	return (*(int *)q-*(int *)p);
}
	int w[100001],v[100001];
	char s[100001][20];
int main(){
	int i,n,k,z;
	char c;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&w[i],&s[i]);
		v[i]=w[i];
	}
	scanf("%d",&k);
	qsort(v,n,sizeof(int),comp);
	z=v[k];
	for(i=0;i<n;i++){
		if(w[i]==z){
			printf("%s\n",s[i]);
			break;
		}
	}
}
