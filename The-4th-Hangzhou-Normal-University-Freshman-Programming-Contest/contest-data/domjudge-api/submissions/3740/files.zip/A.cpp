#include <stdio.h>
#include <string.h>


int main () {
	int n, m, i, c, end = 0, x = 1;
	scanf("%d", &n);
	char a[100000];
	while (n--) {
		scanf("%d", &m);
		getchar();
		for (i = 0; i < m; i++) {
			scanf("%c", &a[i]);
			getchar();
		}
		for (i = 0; i < m - 1; i++) {
			for (c = i + 1; c < m; c++) {
				if (a[i] == a[c] && a[c] != 0) {
					x += 1;
					a[c] = 0;
				}
			}
			end = end + x / 2;
			x = 1;
		}
		printf("%d\n", 2 * end + 1);
		end = 0;
		x = 1;
	}
}