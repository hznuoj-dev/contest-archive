#include<stdio.h>
#include<stdlib.h>
struct love
{
	int a;
	char b[20];
};
int comp(const void *p,const void *q)
{
	return (*(int *)q - *(int *)p);
}
int main(void)
{
	int n;
	scanf("%d",&n);
	int c[n];
	struct love s[n];
	for(int i=0; i<n ;i++)
	{
		scanf("%d %s",&s[i].a,s[i].b);
		c[i]=s[i].a;
	}
	qsort(c,n,sizeof(int),comp);
	int k;
	scanf("%d",&k);
	for(int i=0;i<n;i++)
	{
		if(s[i].a == c[k])
		{
			printf("%s\n",s[i].b);
			break;
		}
		
	}
	
	
	return 0;
}
