#include<stdio.h>
int main()
{
	int n,t,x,i,flag;
	scanf("%d",&t);
	while(t--)
	{
		flag=0;
		scanf("%d%d",&n,&x);
		if(x==0)
		{
			printf("no\n");
			continue;
		}
		if(x%n==0)
		{
			printf("yes\n");
			continue;
		}
		while(x>n&&x%n!=0)
		{
			x-=n;
		}
		for(i=1;i<=n*x;i++)
		{
			if(n*i%x==0)
			{flag=1;
			break;}
		}
		if(flag==1)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}
