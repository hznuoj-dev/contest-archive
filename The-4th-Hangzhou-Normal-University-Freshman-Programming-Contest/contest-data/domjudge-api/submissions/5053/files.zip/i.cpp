#include<stdio.h>
#include<stdlib.h>
struct song
{
	long long int g;
	char name[1000];
};
int main()
{
	int n,i,j,k,m;
	scanf("%d",&n);
	struct song a[100];
	for(i=0;i<n;++i)
	{
		scanf("%lld %s",&a[i].g,a[i].name);
	}
	scanf("%d",&k);
	for(j=0;j<n+1;++j)
	{
		if(a[j].g<=a[j+1].g)
		{
			m=a[j+1].g,a[j+1].g=a[j].g,a[j].g=m;
		}
	}
	printf("%s",a[n-k-1].name);
	return 0;
}
