#include <stdio.h>
int main(){
	int t,n,x,i,b;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&x);
		b=0;
		if(x==0){
			printf("no"); 
		}
		else{
	
		for(i=0;b==0;i+=x){
			if(i/n==0){
				b++;
			}
		}
		if(b>0){
			printf("yes");
		}
		else{
			printf("no");
			}}}	
	return 0;
} 
