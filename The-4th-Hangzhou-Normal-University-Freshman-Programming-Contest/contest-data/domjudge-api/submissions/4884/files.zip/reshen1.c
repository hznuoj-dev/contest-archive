#include<stdio.h>
struct music {
	int num1;
	char name[15];
};
int main() {
	int a, b, c;
	struct music list[100000], temp;
	scanf("%d", &a);
	for (b = 0; b < a; b++) {
		scanf("%d %s", &list[b].num1, list[b].name);
	}
	for (b = 0; b < a - 1; b++) {
		for (c = 0; c < a - b - 1; c++) {
			if (list[c].num1 < list[c + 1].num1) {
				temp = list[c];
				list[c] = list[c + 1];
				list[c + 1] = temp;
			}
		}
	}
	int x;
	scanf("%d", &x);
	printf("%s", list[x].name);
	return 0;
}

