#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *a, const void *b) {
	return *(int*)a-*(int*)b;
}
int a[11][100001];
int main()
{
	int n,m,min=1000000001,i,j,z,cha,fakemin;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
	qsort(a[i],m,sizeof(int),comp);
	}
	for(i=0;i<n;i++)
	{
		fakemin=1000000002;
		for(j=0;j<m-1;j++)
		{
			cha=fabs(a[i][j]-a[i][j+1]);
			if(cha<fakemin)
			{
				fakemin=cha;
			}
		}
		if(fakemin<min)
		min=fakemin;
	}
	printf("%d\n",min);
 } 
