#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int t,num,n[5000],sum,res;
	scanf("%d",&t);
	while(t--){
		res=0;
		scanf("%d",&num);
		for(int i=0;i<num;i++){
			scanf("%d",&n[i]);
		}
			for(int k=0;k<num;k++){
				sum=n[k];
				for(int j=k+1;j<num;j++){
					sum+=n[j];
					if(sum==7777)res++;
					else if(sum>7777)break;
				}
				if(sum<7777)break;
			}
		printf("%d",res);
		if(t>0)printf("\n");
	}
}

