#include<stdio.h>
main()
{
	int n,m;
	int i,ka,a;
	int flag=0,f1=0,f2=0;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++)
	{
		scanf("%d",&ka);
		if(ka==0)
		{
			scanf("%d",&a);
			if(m==0)
			{
				if(a>=2500)
					f1=1;
			}
			else
			{
				if(a>2100)
					f1=1;
			}
		}
		else if(ka==2)
		{
			flag=1;
			break;
		}
		else if(ka==1)
			f2=1;
	}
	if((f1==1 && f2==1) || flag==1)
		printf("haoye\n");
	else
		printf("QAQ\n");
}