#include<stdio.h>
int main(){
	int	T;
	long n;
	scanf("%d",&T);
	while(T--){
		int t=0,a[100000]={0};
		scanf("%ld",&n);
		for(int i=0;i<n;i++){
			scanf("%d",&a[i]);
			
		}
		for(int i=2;i<=n;i++){
			
			for(int j=0;j<n-i+1;j++){
				int sum=0;
				sum+=a[j];
				for(int m=j+1;m<j+i;m++){
					
					sum+=a[m];
					if(sum>7777)
						break;
				}
				if(sum==7777)
					t++;
			}
		}
		printf("%d\n",t);
	}
}
