#include<stdio.h>
#include<stdlib.h>
struct Stu
{
 	char name[21];
 	long long num;
}; 
int cmp(const void *p,const void *q)
{
 	return((struct Stu *)q)->num-((struct Stu *)p)->num;
}
int main(void)
{
 	struct Stu a[101];
 	int i,j,h,b,k;
 		scanf("%d",&b);
 		for(i=0;i<b;++i)
 		{
 			scanf("%lld %s",&a[i].num,a[i].name);
		}
		qsort(a,b,sizeof(struct Stu),cmp);
		scanf("%d",&k);	
		printf("%s\n",a[k].name);
	return 0;
} 
