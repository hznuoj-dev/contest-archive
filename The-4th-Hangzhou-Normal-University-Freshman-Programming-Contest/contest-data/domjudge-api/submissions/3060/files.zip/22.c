#include<stdio.h>
#include<stdlib.h>
char a[100005]={0};
int comp(const void*p,const void*q)
{
	return(*(int *)q-*(int *)p);
}
struct ge
{
	int a;
	char b[20];
}c[100001];
int main()
{
	int n,k,i,j,flag;
	struct ge t;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&c[i].a);
		getchar();
		scanf("%s",&c[i].b);
		getchar();
	}
	scanf("%d",&k);
	qsort(c,n,sizeof(struct ge),comp);
	printf("%s\n",c[k].b);
	return 0;
}