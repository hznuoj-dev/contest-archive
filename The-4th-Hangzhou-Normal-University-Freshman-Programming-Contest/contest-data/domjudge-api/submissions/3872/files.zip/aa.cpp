#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#define pzc 666
using namespace std;
int a[100010];
int main()
{
	int n,m,k,f,win,xi;
	cin>>n>>m;f=1;win=0;
	while(n--)
	{
		cin>>xi;
		if(xi==0)
		{
			cin>>k;
			if(m==0)
			{
				if(k>=2500) f=0;//mudi
			}
			else if(m==1)
			{
				if(k>2100) f=0;
			}
		}
		else if(xi==1&&f==0)
		{
			win=1;break;
		}
		else if(xi==2&&f==1&&n>0)
		{
			win=1;break;
		}
	}
	if(win) cout<<"haoye";
	else cout<<"QAQ";
}
