#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
int main(void){
	int x,i,n,gong,flag=0;
	int ch[10000];
scanf("%d%d",&n,&x);
for(i=0;i<n;++i){
	scanf("%d",&ch[i]);
	if(ch[i]==0) {
	scanf("%d",&gong);
	if(x==0&&gong>=2500) flag=1;
	else if(x==1&&gong>2100) flag=1;
	}
}
for(i=0;i<n;++i){
	if(ch[i]==1&&flag) {
		printf("haoye");
		break;
	}
	else if(ch[i]==2&&flag&&n>2) {
		printf("haoye");
		break;
	}
}
if(i>=n) printf("QAQ");
	return 0;
} 
