#include <stdio.h>.
int main(void)
{
	long long int t, n, x;
	scanf_s("%lld", &t);
	while (t--)
	{
		scanf_s("%lld %lld", &n, &x);
		if (x != 0)
		{
			printf("yes\n");
		}
		else
		{
			printf("no\n");
		}
	}
}