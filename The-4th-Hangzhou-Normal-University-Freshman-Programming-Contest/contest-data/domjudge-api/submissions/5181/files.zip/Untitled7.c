#include<stdio.h>
int main(void){
	int n, m, k, i, b, c, o, d=0, a[10];
	scanf("%d %d",&n,&m);
	if(m==0){
		c=2500;
	}
	else if(m==1){
		c=2100;
	}
	o=1;
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&b);
			if(b>=c){
				o=0;
			}
			else
			    c=c-b;
		}
		else if(a[i]==1){
			if(o==0){
				printf("haoye");
				break;
			}
		}
		else if(a[i]==2){
			if(i+2<n && o==1){
				printf("haoye");
				break;
			}
		}
		if(i+1==n){
			printf("QAQ");
			break;
		}
		if(o==0){
			d=d+1;
			if(d==2){
				o=1;
				if(m==0){
	            	c=2500;
            	}
            	else if(m==1){
	            	c=2100;
            	}
            	d=0;
			}
		}
	}
	return 0;
}
