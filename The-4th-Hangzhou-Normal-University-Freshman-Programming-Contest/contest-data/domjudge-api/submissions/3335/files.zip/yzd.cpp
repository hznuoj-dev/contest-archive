#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
typedef struct point {
	int x;
	char a[25];
}point;
int cmp (const void *p , const void *q){
	return (*(point *)q).x - (*(point *)p).x;
}
point b[100001];
int main () {
    cnm;
    int n;
	cin >> n;
	for (int i = 0 ; i<n ; i++){
		cin >> b[i].x >> b[i].a;
	}
	/*for (int i = 0 ; i<n ; i++){
		cout << b[i].a <<endl;
	} */
	qsort (b,n,sizeof(point),cmp);
	/*for (int i = 0 ; i<n ; i++){
		cout << b[i].a <<endl;
	}*/
	int k;
	cin >> k;
	cout << b[k].a;
    return 0;
}
