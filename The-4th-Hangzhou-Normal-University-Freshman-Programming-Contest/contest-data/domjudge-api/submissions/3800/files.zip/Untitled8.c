#include<stdio.h>
#include<string.h>
main(){
	int n,k;
	long long a[100001];
	char b[100001][16];
	int i,j,temp;
	char c[16];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%lld %s",&a[i],b[i]);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++){
		for(j=0;j<n-i-1;j++){
			if(a[j]<a[j+1]){
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
				strcpy(c,b[j]);
				strcpy(b[j],b[j+1]);
				strcpy(b[j+1],c);
			}
		}
	}
	printf("%s",b[k]);
}
