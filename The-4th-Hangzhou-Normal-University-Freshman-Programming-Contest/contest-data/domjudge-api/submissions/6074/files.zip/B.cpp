#include<stdio.h>
int main(){
  int T;
  int n;
  int a[100000];
  scanf("%d",&T);
  while(T--){
    scanf("%d",&n);
	for(int i=0;i<n;i++){
	 scanf("%d",&a[i]);
	}
	int num=0;
	for(int i=2;i<=n;i++){
		for(int j=0;j<n-i+1;j++){
			int sum=0;
			for(int q=0;q<i;q++){
			  sum+=a[j+q];
			  if(sum>7777){
			    break;
			  }
			}
			if(sum==7777){
			 num+=1;
			}
		}
	}
	printf("%d\n",num);
  }
}