#include <bits/stdc++.h>
using namespace std; 
int cu[500],tcu[500];
int main()
{
	int n,m,i,j,a,mint,q,cun;
	scanf("%d%d",&n,&m);
	printf("+------"); for (j=2; j<=n+1; j++) printf("+--------"); printf("+\n");
	printf("|      |");	
	for (j=0; j<n; j++) printf("  0x%02x  |",j);printf("\n");		
	
	printf("+------");
	for (j=2; j<=n+1; j++) printf("+--------"); printf("+\n");
	
	for (i=0; i<=n; i++) cu[i]=-1;
	int cus=0;
	for (i=0; i<m; i++)
	{

		scanf("%d",&a);
		q=0;
		while (cu[q]!=a && q<=cun) q++;
		if (q<=n) 
		{			
			if (q>cun) 
			{
				cu[q]=a;
				tcu[q]=i;
				cun=q;
			}
			else 
			{
				for (j=q; j<=cun-1; j++)
				{
					cu[j]=cu[j+1];
					tcu[j]=tcu[j+1];				
				}
				cu[cun]=a;
				tcu[cun]=i;
			}
		}
		else 
		{
			int mint=1;
			for (j=1; j<=n-1; j++)
			{
				cu[j]=cu[j+1];
				tcu[j]=tcu[j+1];
				
			}
			cu[n]=a;
			tcu[n]=i;
		}
		printf("| 0x%02x |",i);
		for (j=1; j<=n; j++) 
			if (cu[j]!=-1) printf(" 0x%04x |",cu[j]);
			else printf("        |");
		printf("\n");
		printf("+------");
		for (j=2; j<=n+1; j++) printf("+--------"); printf("+\n");
	}
	
	
}
