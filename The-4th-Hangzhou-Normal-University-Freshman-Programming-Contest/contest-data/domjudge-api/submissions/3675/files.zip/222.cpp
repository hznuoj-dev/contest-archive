#include<stdio.h>

int main(){
	int t,n;
	int i,k,j;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int a[n],cnt=0;
		for(i=0;i<n;i++) scanf("%d",&a[i]);
		for(k=0;k<n;k++){
			 	int sum = a[k];
			for(j=k+1;j<n;j++){
				sum+=a[j];	
				if(sum==7777) cnt++;
			}
			
		}
		printf("%d\n",cnt);
	}
	
	
	return 0;
}
