#include<bits/stdc++.h>
#define res register int
#define ll long long
#define inf 0x3f3f3f3f
#define N 50
using namespace std;
int a[N][N],b[N][N],c[N][N];
int n,m,t,timee;
bool allow,allow1;
inline void rotate() 
{
	int l;
	for(res i=1;i<=n/2;i++) 
	{
		for(res j=i;j<n-i+1;j++) 
		{
			l=a[i][j];
			a[i][j]=a[n-j+1][i];
			a[n-j+1][i]=a[n-i+1][n-j+1];
			a[n-i+1][n-j+1]=a[j][n-i+1];
			a[j][n-i+1]=l;

		}

	}

}

inline bool compared() {
	for(res i=1; i<=n; i++)
		for(res j=1; j<=n; j++)
			if(a[i][j]!=b[i][j])
				return false;
	return true;
}

int main() {
	scanf("%d",&t);
	while(t>0) 
	{
		allow=false;
		allow1=false;
		scanf("%d",&n);
		for(res i=1; i<=n; i++)
			for(res j=1; j<=n; j++)
				scanf("%d",&a[i][j]);
		for(res i=1; i<=n; i++)
			for(res j=1; j<=n; j++)
				scanf("%d",&b[i][j]);

		for(res i=1; i<=4; i++) 
		{
			rotate();
			allow=compared();
			if(allow) {
				allow1=true;
				timee=i;
				break;
			}
		}
		if(allow1) {
			printf("%d\n",min(timee,4-timee));
		} 
		else printf("-1\n");
		t--;
	}
}
