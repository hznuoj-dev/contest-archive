#include<stdio.h>
#include<stdlib.h>
#include<string.h>
char in[1001][32];
int main(void)
{
	int  AD, group;
	scanf("%d %d",&group, &AD);
	
	int sha1 = 0, sha2 = 0, she = 0, in;
	for (int i = 0; i < group; i++) {
		scanf("%d", &in);
		if (in == 0) {
			scanf("%d", &in);
			if (in >= 2500 && AD == 0)
				sha1 = 1;
			if (in > 2100 && AD)
				sha1 = 1;
		}
		else if (in == 1)sha2 = 1;
		else if (in == 2) she = 1;
	}
	if (she && group > 1) {
		printf("haoye");
		goto a;
	}
	if (sha1 && sha2) {
		printf("haoye");
		goto a;
	}
	printf("QAQ");
	
		a:
	return 0;
}