#include<stdio.h>
#include<math.h>
int main()
{
	int t,n,m,i,j,x,sum=0;
	scanf("%d",&t);
	/*int a[11][10e7],b[10e9];
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++)
	{
		for(j=0;j<m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}*/
	while(t--)
	{
		scanf("%d%d",&n,&x);
		//sum+=n;
		if(n!=0&&x==0)
		{
			printf("no\n");
		}
		else //if(sum%x==0)
		{
			printf("yes\n");
		}
		/*else
		{
			do{
				sum+=(n-1);
				if(sum%x==0)
				{
					printf("yes\n");
					break;
				}
			}
			while(sum<10e9);
			
			printf("no\n");
			
		}*/
	}	
}
