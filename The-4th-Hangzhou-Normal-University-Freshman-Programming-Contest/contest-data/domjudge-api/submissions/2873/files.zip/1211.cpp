#include<stdio.h>
#include<string.h>
int mian()
{
	char s[1000];
	int i=0;	
	while(scanf("%s",s[i])!=EOF)
	{
	   if(i==0)
	   printf("%s",s);
	   else if(i%2==0)
	   {printf("%s %s",s[i],s[i-1]);
	   }
	   else if(i%2!=0)
	   {continue;
	   }	
		i++;
	}
	return 0;
 } 
