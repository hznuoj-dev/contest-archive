#include<stdio.h>
#include<string.h>
int song[100000];
int f(int a)
{
	int count=0;
	long long int sum =0;
	int i,j;
	for (i = 1; i <= a; i++)
		{
			sum=0;
			for (j = i; j <= a; j++)
			{
				sum += song[j];
				if (sum == 7777)
					count++;
				if (sum > 7777)
					break;
			}
        }
        return count;
}
int main()
{
	int T, n,i,a;
	scanf("%d", &T);
	while (T--)
	{

		scanf("%d", &n);
		for (i = 1; i <= n; i++)
		{
			scanf("%d", &song[i]);
		}
		a=f(n);
		}
		printf("%d\n", a);
return 0;
	}


