#include<stdio.h>
struct song_stru 
{
	int num;
	char name[20];
}a[100500],b[100500],t;
int main()
{
	int i,j,n;
	scanf("%d",&n);
	for (i = 0; i < n; i++)
	{
		scanf("%d%s",&a[i].num,a[i].name);
		b[i] = a[i];
	}
	int k;
	scanf("%d",&k);
	for (j = 0; j < n - 1; j++)
	{
		for (i = j+1; i < n; i++)
		{
			if (b[i].num > b[j].num)
			{
				t = b[j];
				b[j] = b[i];
				b[i] = t;
			}
		}
	}
	printf("%s",b[k].name);
	return 0;
}