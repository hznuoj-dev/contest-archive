#include<stdio.h>
main()
{
	long long n,x;
	int t;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lld %lld",&n,&x);
		if(x!=0)
			printf("yes\n");
		else
			printf("no\n");
	}
}