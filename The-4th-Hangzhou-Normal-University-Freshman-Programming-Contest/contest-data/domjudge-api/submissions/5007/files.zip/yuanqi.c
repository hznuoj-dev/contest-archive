#include<stdio.h>
struct biaolie
{
	char name[16];
	int xiaidu;
}gedan[10001];
int main()
{
	int n, i, k, max, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &gedan[i].xiaidu);
		scanf("%s", gedan[i].name);
	}


	scanf("%d", &k);
	for (i = 0; i < k; i++)
	{
		max = gedan[0].xiaidu;
		for (j = 0; j < n; j++)
		{
			if (gedan[j].xiaidu > max)
				max = gedan[j].xiaidu;
		}
		for (j = 0; j < n; j++)
		{
			if (max == gedan[j].xiaidu)
				gedan[j].xiaidu = 0;
		}
	}


	max = gedan[0].xiaidu;
	for (i = 0; i < n; i++)
	{
		if (gedan[i].xiaidu > max)
		{
			max = gedan[i].xiaidu;
		}
	}
	for (i = 0; i < n; i++)
	{
		if (max == gedan[i].xiaidu)
			printf("%s\n", gedan[i].name);
	}
	return 0;
}