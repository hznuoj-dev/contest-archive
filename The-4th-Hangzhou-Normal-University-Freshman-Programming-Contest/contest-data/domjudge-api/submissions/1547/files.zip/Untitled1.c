#include<stdio.h>
char c[100001];
int cnt[52]={0};
int main()
{
	int sumc=0;
	int t,n;
	scanf("%d",&t);
	int sum;
	while(t--)
	{
		int flag=0;
		sum=0;
		sumc=0;
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			getchar();
			scanf("%c",&c[i]);
			sumc++;
			if(c[i]>=65&&c[i]<=90)
			cnt[c[i]-65]++;
			if(c[i]>=97&&c[i]<=97+25)
			cnt[c[i]-97+26]++;
		}
		for(int i=0;i<52;i++){
			if(cnt[i]%2==0)
			sum+=cnt[i];
			else{
			sum+=cnt[i]-1;
			flag=1;
			}
		}
		if(flag)
		printf("%d\n",sum+1);
		else
		printf("%d\n",sum);
		for(int i=0;i<52;i++){
			cnt[i]=0;
		}
	}
	return 0;
}
