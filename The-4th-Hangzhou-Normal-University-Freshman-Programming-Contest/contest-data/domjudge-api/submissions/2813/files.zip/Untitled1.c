#include <stdio.h>
#include <string.h>
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int k=0, n, m, j=0, i;
		scanf("%d %d",&n,&m);
		while(1){
			k=(k+m)%n;
			if(m==0){
				printf("no\n");
				break;
			}
			if(k==0){
				printf("yes\n");
				break;
			}
		}
	}
}

