#include<stdio.h>
int main(void){
	long long int t,n,x;
	scanf("%d",&t);
	while(t--){
			scanf("%lld %lld",&n,&x);
			if(x<=n&&x!=0)
				printf("YES\n");
			else
				printf("NO\n");
	}
return 0;
}
