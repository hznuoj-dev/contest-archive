#include<stdio.h>
struct song
{
	int love;
	char name[15];
 }jy[100005];
 int main()
 {
 	int i,j;
 	struct song temp;
 	int t;
 	int q;
 	scanf("%d",&t);
 	for(i=0;i<t;i++)
 	{
 		scanf("%d%s",&jy[i].love,jy[i].name);
	 }
	 for(i=0;i<t-1;i++)
	 {
	 	for(j=0;j<t-1-i;j++)
	 	{
	 		if(jy[j].love <jy[j+1].love )
	 		{
	 		temp=jy[j];
	 		jy[j]=jy[j+1];
	 		jy[j+1]=temp;
	 		}
		}
	 }
	scanf("%d",&q);
	printf("%s",jy[q].name );
 	return 0;
 }
