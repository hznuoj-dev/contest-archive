#include<stdio.h>
#include<string.h>
int main(){
	int t,num,res;
	long long int n[5000],sum;
	scanf("%d",&t);
	while(t--){
		res=0;
		scanf("%d",&num);
		for(int i=0;i<num;i++){
			scanf("%lld",&n[i]);
		}
		for(int k=0;k<num;k++){
			sum=n[k];
			for(int j=k+1;j<num;j++){
				sum+=n[j];
				if(sum==7777)res++;
				else if(sum>7777)break;
			}
			if(sum<7777)break;
		}
		printf("%d\n",res);
	}
}

