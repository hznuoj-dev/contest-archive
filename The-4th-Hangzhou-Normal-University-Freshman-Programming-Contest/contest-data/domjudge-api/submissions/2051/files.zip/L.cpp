#include<stdio.h>
int main()
{
	int t,i,f;
	long long int n,x;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lld %lld",&n,&x);
		if(x!=0)
			printf("yes\n");
		else
			printf("no\n");
	}
}