#include<stdio.h>
int main(){
	long long int t,n,x;
	scanf("%lld",&t);
	while (t--){
		int cnt=0;
		scanf("%lld%lld",&n,&x);
		if(x!=0){
			for(int i=0;i<10000;i++){
				n=n*i;
			}
			if(n%x==0) cnt=1;
			else cnt=0;
		}else cnt=0;
	if(cnt==1)printf("yes\n");
	else printf("no\n");	
	}
}
