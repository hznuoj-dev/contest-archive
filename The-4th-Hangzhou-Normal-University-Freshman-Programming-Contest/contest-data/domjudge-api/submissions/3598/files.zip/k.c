#include<stdio.h>    
int main()
{
	int t,flag,count;
	long long n;
	char ch[1000];
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		scanf("%d",&n);
		flag=0,count=0;
		for(int j=0;j<n;j++){
			scanf(" %c",&ch[j]);
		}
		for(int j=0;j<n;j++){
			for(int k=j+1;k<n;k++){
				if(ch[j]==ch[k]){
					count++;
					flag=1;
				}		
			}		
		}
		int a=2*count;
		int b=2*count+1;
		if(flag==1){
			if(n%2==0)
				printf("%d\n",a);		
			else
				printf("%d\n",b);
		}
		else
			printf("1\n");	
	}
	return 0;
} 
