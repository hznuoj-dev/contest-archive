#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct g{
	char name[20];
	int ci;
};
int cmp(const void*p,const void*q);
struct g ge[10004];
int main(){
int n,i,k;
scanf("%d",&n);
for(i=0;i<n;i++)
scanf("%d %s",&ge[i].ci,ge[i].name);
qsort(ge,n,sizeof(ge[0]),cmp);
scanf("%d",&k);
printf("%s",ge[k].name);
return 0;
}
 int cmp(const void*p,const void*q){
 	return((struct g*)q)->ci-((struct g*)p)->ci;
 }
