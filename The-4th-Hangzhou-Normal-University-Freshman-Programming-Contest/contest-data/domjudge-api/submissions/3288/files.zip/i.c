#include<stdio.h>
int main(){
	long int t,n,x,s=0,a=0;
	scanf("%ld",&t);
	while(t--){
		scanf("%ld%ld",&n,&x);
		if(x!=0)
			printf("yes\n");
		else
			printf("no\n");
}
}
