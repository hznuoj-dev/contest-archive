#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main() {
	int t, a[100000], b, s, sum, i, f;
	scanf("%d", &t);
	while (t--) {
		sum = 0;
		s = 0;
		scanf("%d", &b);
		for (i = 0; i < b; i++)
			scanf("%d", &a[i]);
		for (i = 0, f = 0; i < b; i++) {
			s += a[i];
			if (s == 7777) {
				sum++;
				s = 0;
				i = f;
				f++;
			}
		}
		printf("%d\n", sum);

	}

	return 0;
}