#include<bits/stdc++.h>
using namespace std;

int sum[100005];
int main(){
	int t;
	cin>>t;
	while(t--){
		int a,b;
		cin>>a>>b;
		if(b==0){
			cout<<"no\n";
		}else{
			cout<<"yes\n";
		}
	}
} 
