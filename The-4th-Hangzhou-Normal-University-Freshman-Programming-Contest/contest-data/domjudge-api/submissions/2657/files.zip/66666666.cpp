#include<stdio.h>
#include<stdlib.h>
typedef struct{
 int cd;
 char mz[16];
}sing;
comp(const void *p,const void *q){
 return ((sing *)q)->cd - ((sing *)p)->cd;
}
int main(){
 int n,i,k,j,t;
 scanf("%d",&n);
 sing a[n];
 for(i=0;i<n;i++){
  scanf("%d%s",&a[i].cd,a[i].mz);
 }
 scanf("%d",&k);
 qsort(a,n,sizeof(sing),comp);
 printf("%s",a[k].mz);
}
