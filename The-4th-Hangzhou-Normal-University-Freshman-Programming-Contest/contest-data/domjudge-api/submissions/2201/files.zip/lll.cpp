#include <cstdio>
#include <algorithm>
#include <set>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <climits>
#include <stack>
#include <map>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include<time.h>
#define tententen tql666
#define PI acos(-1) 
typedef long long int ll; 
using namespace std;
int main(){
	int t,x,n;
	cin>>t;
	while(t--){
 	  int flag=0;
	   	cin>>n>>x;
	   	if(x!=0)
	   	    flag=1;
  	if(flag==1)
  		cout<<"yes"<<endl;
  	else
  		cout<<"no"<<endl;
  }
	return 0;
}
