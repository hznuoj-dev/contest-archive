#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q)
{
	return(*(char*)p-*(char*)q);
}
char b[100005]={0};
int main()
{
	int t,n,i,j,c,s;
	char e;
	scanf("%d",&t);
	while(t--)
	{
		c=1;
		s=0;
		scanf("%d",&n);
		getchar();
		scanf("%c",&b[0]);
		for(i=1;i<n;i++)
			scanf(" %c",&b[i]);
		qsort(b,n,sizeof(char),comp);
		for(i=0;i<n;i++)
		{
			if(b[i]==b[i+1])
				c++;
			else
			{
				s+=(c/2)*2;
				c=1;
			}
		}
		if(s!=n)
		printf("%d\n",s+1);
		else
			printf("%d\n",s);
		memset(b,0,sizeof(b));
	}
	return 0;
}