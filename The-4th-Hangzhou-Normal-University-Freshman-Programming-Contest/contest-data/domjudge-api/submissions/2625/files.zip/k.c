#include<stdio.h>
#include<stdlib.h>
struct wai {
	long long int time;
	char name[30];
};
int comp(const void *p, const void *q) {
	return((struct wai *)q)->time - ((struct wai *)p)->time;
}
int main() {
	struct wai student[100];
	int  n,k;
	scanf("%d", &n);
		for (int i = 0;i < n;i++) {
			scanf("%lld%s", &student[i].time, student[i].name);
		}
		scanf("%d", &k);
		qsort(student, n, sizeof(struct wai), comp);
		
			printf("%s\n", student[k].name);
		
}
