#include<stdio.h>
int main(void){
	int n,i,j,k,d=-1;
	scanf("%d",&n);
	long long a[n+1],c;
	char b[n+1][20];
	for(i=0;i<n;i++){
		scanf("%lld %s",&a[i],b[i]);
	}
	scanf("%d",&k);
	for(i=0;i<=k;i++){
		c=0;
		for(j=0;j<n;j++){
			if(a[j]>c){
				c=a[j];
				d=j;
			}
		}
		a[d]=0;
	}
	printf("%s",b[d]);
	return 0;
}
