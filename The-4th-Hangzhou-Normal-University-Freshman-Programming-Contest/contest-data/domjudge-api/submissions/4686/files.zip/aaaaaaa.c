#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
char a[10005][350],str[300005],ch;
int main(){
	int t,i,len,wz,x,j;
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		wz=0;
		x=0;
		gets(str);
		len=strlen(str);
		for(i=0;i<len;i++)
		{
			if(str[i]=='!'||str[i]=='?'||str[i]=='.')
			{
				ch=str[i];
				break;
			}
			if(str[i]==' ')
			{
				wz++;
				x=0;
				continue;
			}
			a[wz][x]=str[i];
			x++;
		}
		wz++;
		for(i=0;i<=wz/2-1;i++)
		{
			if(i==0)
			printf("%s %s",a[i],a[wz-1-i]);
			else
			printf(" %s %s",a[i],a[wz-1-i]);
		}
		if(wz%2&&wz>1)
			printf(" %s",a[wz/2]);
		else if(wz%2)
			printf("%s",a[wz/2]);
		printf("%c\n",ch);
		for(i=0;i<=wz;i++)
		{
			for(j=0;j<=30;j++)
			a[i][j]='\0';
		}
	}
	return 0;
}
