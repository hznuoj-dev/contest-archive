#include<stdio.h> 
#include<string.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,x;
		scanf("%d %d",&n ,&x);
		if(x==0){
			printf("no");
		}
		if(n%x==0){
			printf("yes");
		}
		else
		printf("no");
	}
	return 0;
}
