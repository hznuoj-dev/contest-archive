#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	int n;
	int a,b;
    scanf("%d",&n);
    char ch;
    for(int i=1;i<=n;i++)
    {
        int x[26]={0};
        int X[26]={0};
        int s=0;
        scanf("%d ",&a);
        int o=0;
        for(int j=1;j<=a;j++)
        {
            scanf("%c%*c",&ch);
            if(ch<='z'&&ch>='a')
            {
                b=ch-'a';
                x[b]=x[b]+1;
                x[b]=x[b]%2;
            }
            else if(ch<='Z' &&ch>='A')
            {
                b=ch-'A';
                X[b]=(X[b]+1)%2;
            }
        }
        for(int j=0;j<26;j++)
        {
            s=s+x[j];
            s=s+X[j];
        }
        if(s==a)
        printf("1\n");
        else
        {
            if(a%2==1)
            {
                printf("%d\n",a-s+1);
            }
            else
            {
                printf("%d\n",a-s);
            }
        }

    }
    return 0;
}
