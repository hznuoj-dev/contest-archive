#include <stdio.h>
int main(){
	int t,n,i,j,k,s;
	int a[10000];
	scanf("%d",&t);
	while(t--){
		k=0;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for(i=0;i<n-1;i++){
			s=a[i];
				for(j=i+1;j<n;j++){
				 if(s+a[j]<7777)
				  s=s+a[j];
				 else if(s+a[j]>7777)
				  break;
				 else if(s+a[j]==7777){
				  k++;
				  break;	
				}
			}	
		}
	printf("%d\n",k);
	}
	return 0;
}
