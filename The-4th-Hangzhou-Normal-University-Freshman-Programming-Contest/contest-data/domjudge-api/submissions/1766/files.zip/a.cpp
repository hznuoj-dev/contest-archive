#include<stdio.h>
int main()
{
	int sum=0,t,i,n,a[5001];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("Welcome to HZNU\n");
	}
}
