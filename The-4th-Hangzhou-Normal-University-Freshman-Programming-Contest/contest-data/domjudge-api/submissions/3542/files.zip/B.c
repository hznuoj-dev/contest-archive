#include <stdio.h>
int main(void){
	int t,n,i,j;
	scanf("%d",&t); 
	for(;t>0;t--)
	{
		int flag=0;
		scanf("%d",&n);
		int a[n];
		for(i=0;i<n;i++)
			scanf("%d",&a[i]);
		for(i=0;i<n;i++)
		{
			int sum=0;
			for(j=i;j<n;j++)
			{
				sum+=a[j];
				if(sum>7777)
				{
					break;
				}
				else if(sum==7777)
				{
					flag+=1;
					break;
				}
			}
		}
		printf("%d",flag);	
	}
	return 0;
}

