#include <stdio.h>
#include <string.h>
#include <stdlib.h>
int comp(void *p,void *q)
{
	int a,b;
	a=*(int*)p;
	b=*(int*)q;
	if(a>b)
	{
		return 1;
	}
	else
	{
		return -1;
	}
}
int main(void)
{
	int t,sum;
	long long n,i,m;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lld",&n);
		m=0;
		int *a,*p;
		a=(int*)malloc(n*sizeof(int));
		i=0;
		p=a;
		while(i<n)
		{
			scanf("%d",p);
			p++;
			i++;
		}
		qsort(a,n,sizeof(int),comp);
		i=0;
		while(i<n)
		{
			sum=0;
			p=a+i;
			while(p<a+n)
			{
				sum+=*(p);
				p++;
				if(sum==7777)
				{
					m++;
					sum-=*(p-1);
				}
				
			}
			i++;
		}
		printf("%d\n",m);
		
	}
	return 0;
}
