/*nclude<stdio.h>
long m[100001] = { 0 };
int main()
{
	int n, i = 0, asd = 0;
	char str[50];

	scanf("%d", &n);
	for (n; n > 0; n--)
	{
		scanf("%d %s", &m[i], str);
		i += 1;
	}
	scanf("%d", &asd);

	return 0;
}*/
#include<stdio.h>
char asd[100010];
int main()
{
	int T;
	long long  n, i = 0, j = 0, len = 0;
	scanf("%d", &T);
	while (T--)
	{

		scanf("%lld", &n);
		getchar();
		for (i = 0; i < n; i++)
		{
			scanf("%c", &asd[i]);
			getchar();
		}
		for (i = 0; i < n; i++)
		{
			if (asd[i] == -1)
				continue;
			for (j = i + 1; j < n; j++)
			{
				if (asd[i] == asd[j] && asd[j] != -1)
				{
					asd[i] = -1;
					asd[j] = -1;
					len += 2;
					break;
				}
			}
		}
		if (len == n)
			printf("%lld\n", len);
		else
			printf("%lld\n", len + 1);
		len = 0;
	}
	return 0;
}