#include <stdio.h>
#include <stdlib.h>
#include <string.h>



int main() {
	int t;
	scanf("%d", &t);
	while (t--)
		printf("Welcome to HZNU\n");
	return 0;
}