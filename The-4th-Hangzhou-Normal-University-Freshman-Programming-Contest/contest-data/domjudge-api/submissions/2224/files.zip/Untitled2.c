#include<stdio.h>
int main()
{
	int a[100000];
	int T,n,i,j,sum=0,x=0;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			for(j=i;j<n;j++){
			sum+=a[j];
			if(sum==7777)
			x++;
		}
		sum=0;
		}
		printf("%d\n",x);
		x=0;
	}
	return 0;
}
