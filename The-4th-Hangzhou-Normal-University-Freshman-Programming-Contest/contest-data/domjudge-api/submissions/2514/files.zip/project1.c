#include<stdio.h>

int main(void)
{
	int t,x,n,i,flag=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&x);
		if(x==0){
			printf("no\n");
			continue;
		}
		for(i=n-1;i<1000000;i+=i){
			if(i%x==0){
				flag=1;
				break;
			}
		}
		if(flag==1){
			printf("yes\n");
		}
		else if(flag==0){
			printf("no\n");
		}
	}
    return 0;
}

