#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	for(int w=0;w<t;w++)
	{
		int n;
		cin>>n;
		int a[100005];
		for(int i=0;i<n;i++)
		{
			cin>>a[i];
		}
		int i=0,j=0;
		int num=0;
		int sum=0;
		while(j<n)
		{
			num+=a[j];
			j++;
			if(num==7777)
			{
				sum++;
			}
			while(num>=7777)
			{
				num-=a[i];
				i++;
			}
		}
		cout<<sum<<endl;
	}
	//system("pause");
}
