#include<stdio.h>
int main(){
    int t;
    int m,n;
    scanf("%d",&t);
    while(t--){
    
        scanf("%d %d",&m,&n);
   
        if((n>0)&&(m%n==0))
            printf("yes\n");
            else
                printf("no\n");
        }
}

