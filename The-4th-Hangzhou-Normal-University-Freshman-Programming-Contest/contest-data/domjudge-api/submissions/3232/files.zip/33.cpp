#include<stdio.h> 
int main()
{	
 int t,n,k,flag,i;
 char c[10000];
 scanf("%d",&t);
 while(t--)
 {
 	scanf("%d",&n);
 	getchar();
 	for(i=0;i<n;++i)
 	{
 		scanf("%c",&c[i]);
 		getchar();
	}
    k=c[0];
	if(n%2==0)
	{
		flag=1;
		for(i=1;i<n;++i)
		{
			k=k^c[i];
		}
		if(k==0)
		{
			printf("%d\n",n);
		}
		else if(k!=0)
		{
			printf("1\n");
		}		
	}
    if(n%2!=0)
	{
		flag=0;
		k=c[0];
		for(i=1;i<n;++i)
		{
			k=k^c[i];
		}
		for(i=0;i<n;++i)
		{
			if(k==c[i])
			{
				printf("%d\n",n);
				flag=1;
				break;
			}
		}
		if(flag==0)
		{
			printf("1\n");
		}	    
	}
 }
 return 0;
}
