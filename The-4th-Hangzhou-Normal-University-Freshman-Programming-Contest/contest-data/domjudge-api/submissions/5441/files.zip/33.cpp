#include <stdio.h>
int main()
{
 int n,i,t,p,l,sum;
    scanf("%d",&t);
    while(t--)
    {
    	p=0;
		l=0;
    	sum=0;
    	scanf("%d",&n);
    	int a[n][10];
    	for(i=0;i<n;++i)
    	{
    		scanf("%d",&a[i][0]);
		}
		for(i=0;i<n;++i)
    	{
    		sum=sum+a[i][0];   		
			if(sum>7777)
			{
				sum=sum-a[l][0];
				l=l+1;
			}
			if(sum==7777)
    		{
    			p=p+1;
			}
		}
		printf("%d\n",p);
	}
	return 0;
}
