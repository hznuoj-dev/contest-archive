#include<stdio.h>
int main() {
	int n;
	scanf_s("%d", &n);
	while (n--) {
		printf("Welcome to HZNU\n");
	}
	return 0;
}