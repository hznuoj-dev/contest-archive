#include<stdio.h>
char m[100000];
int main(void){
	int T,n,count=0,i,j;
	scanf("%d",&T);getchar();
	while(T--){
		scanf("%d",&n);
		count=0;
		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&m[i]);
		}
		
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(m[i]=='9')
				break;
				if(m[i]==m[j]&&(j!=i)){
					m[i]=m[j]='9';
					count++;
					break;
				}
			}
		}
		if(n-count*2>=1)
			printf("%d\n",count*2+1);
		else
		printf("%d\n",count*2);
	}
	return 0;
}

