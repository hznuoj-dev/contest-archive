#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
int a1[30][30],a2[30][30];
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int a,b;
		scanf("%d%d",&a,&b);
		if(b==0) printf("no\n");
		else{
//			if(__gcd(a,b)>1) printf("yes\n");
			if(a*1000%b==0) printf("yes\n");
			else printf("no\n");
		}
	}
	return 0;
}
