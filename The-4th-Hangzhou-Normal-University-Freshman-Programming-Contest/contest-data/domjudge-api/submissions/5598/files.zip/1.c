#include<stdio.h>
#include<string.h>
int main(){
	int T;
	scanf("%d",&T);
	getchar();
	while(T--){
		int i=1;
		char s[1666][66];
		char t;
		while(scanf("%s",s[i]),t=(getchar())!='\n'){
			i++;
		}
		int len;
		int j;
		len=strlen(s[i]);
		//printf("%d\n",i);
		//printf("%d\n",len);
//		for(j=1;j<=i;j++){
//			printf("%s ",s[j]);
//		}
		int c;
		int g;
		if(i==1){
			printf("%s\n",s[1]);
		}
		else if(i==2){
			printf("%s ",s[1]);
			printf("%s\n",s[2]);
		}
		
		else{
			
			
			
		
		
		
		
		if(i%2!=0){
			for(c=1;c<=(i/2);c++){
			printf("%s ",s[c]);
			if(i-c+1==i){
				for(g=0;g<len-1;g++){
					printf("%c",s[i+c-1][g]);
				}
				printf(" ");
			}
			else{
				printf("%s ",s[i-c+1]);
			}
			
		}
		    printf("%s",s[(i+1)/2]);
			printf("%c\n",s[i][len-1]);
		}
		
		
		
		
		
		
		else{
			
			for(c=1;c<=(i/2);c++){
				
			    printf("%s ",s[c]);
				
			if(i-c+1==i){
				for(g=0;g<len-1;g++){
					printf("%c",s[i+c-1][g]);
				}
				printf(" ");
			}
			else{
				if(i-c+1==i/2+1){
					printf("%s",s[i-c+1]);
				}
				else{
					printf("%s ",s[i-c+1]);
				}
			}
			
		}
			printf("%c\n",s[i][len-1]);
		}
		
		
	}
	}
	return 0;
} 
