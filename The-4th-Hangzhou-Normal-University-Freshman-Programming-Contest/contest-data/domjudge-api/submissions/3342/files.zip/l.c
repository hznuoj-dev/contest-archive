#include <stdio.h>
int main(void) 
{
	int t,n,x;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&x);
		if(x==0)
			printf("no");
		else
			printf("yes");
			if(t!=0)
			printf("\n");
	}
    
	return 0;
}
