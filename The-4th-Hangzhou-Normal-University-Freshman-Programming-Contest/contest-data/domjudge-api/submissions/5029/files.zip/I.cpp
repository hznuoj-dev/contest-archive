#include<stdio.h>
int main(){
  int i,n,k,t,max;
  long a[10000];
  char b[10000][17];
  int sign[10000];
  scanf("%d",&n);
  for (i=1;i<=n;i++){
  	scanf("%ld",&a[i]);
  	scanf("%s",b[i]);
  } 
  k=1;
  while (k<=n){
  	max=0;
  	for (i=1;i<=n;i++){
  	  if (a[i]>max) {
  		sign[k]=i;
  		max=a[i];
	  }
   }
	a[sign[k]]=0;
	k++; 
  }
  scanf("%d",&t);
  printf("%s",b[sign[t+1]]);
  return 0;
}
