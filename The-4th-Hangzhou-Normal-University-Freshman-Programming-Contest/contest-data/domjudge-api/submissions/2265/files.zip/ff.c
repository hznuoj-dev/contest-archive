#include<stdio.h>
int pan[1000001];
int main()
{
	int k,i,qi,a,b;
	scanf("%d",&k);
	while(k--)
	{
		scanf("%d %d",&a,&b);
		for(i=0;i<a;i++)
		{
			pan[i]=1;
		}
		qi=0;
		for(i=0;i<a*10;i++)
		{
			qi=qi+b;
			if(qi>a-1)
			{
				qi=qi-a;
			}
			pan[qi]=0;
		
		}
		if(pan[0]==0&&b!=0)
		{
			printf("yes\n");
		}
		else if(pan[0]!=0||b==0)
		{
			printf("no\n");
		}
	}
	return 0;
}
