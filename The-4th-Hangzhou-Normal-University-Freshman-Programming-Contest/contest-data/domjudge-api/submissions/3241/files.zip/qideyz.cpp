#include<stdio.h>
#include<string.h>
int main(){
	int t,n;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int a[10000]={0};
		for(int i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		int sum=0;
		int jg=0;
		for(int i=0;i<n;i++){
			sum=0;
			for(int j=i;j<n;j++){
			sum+=a[j];
			if(sum==7777)
			{
				jg+=1;
				break;
			}else if(sum>7777){
				break;
			}
		}
		}
		printf("%d\n",jg);
		jg=0;
	}
}
