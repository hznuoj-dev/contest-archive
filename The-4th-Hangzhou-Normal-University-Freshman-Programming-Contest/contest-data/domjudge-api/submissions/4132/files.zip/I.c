#include<stdio.h>
int n, w[100000], i, j, t, k;
char* p[100000], * p1, c[100000][15];
int main()
{
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d %s", &w[i], c[i]);
		p[i] = c[i];
	}
	scanf("%d", &k);
	for (i = 0; i < n; i++)
	{
		for (j = i + 1; j < n; j++)
		{
			if (w[i] < w[j])
			{
				t = w[i];
				w[i] = w[j];
				w[j] = t;
				p1 = p[i];
				p[i] = p[j];
				p[j] = p1;
			}
		}
	}
	printf("%s", p[k]);
	return 0;
}