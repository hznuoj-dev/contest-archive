#include<stdio.h>
int main()
{
	int t,flag=0;
	long long n ,x,k=1;
	scanf("%d",&t);
	while(t--)
	{
		flag=0;
		scanf("%lld%lld",&n,&x);
		if(x==0)
		{
			printf("no\n");
		}
		else
		{
			
				while(k<n)
				{
					if((k*x)%n==0)
					{
						flag=1;
						break;
					}
					
					k++;
				}
				if(flag=1)
				{printf("yes\n");
				}
			
		}
	}
}
