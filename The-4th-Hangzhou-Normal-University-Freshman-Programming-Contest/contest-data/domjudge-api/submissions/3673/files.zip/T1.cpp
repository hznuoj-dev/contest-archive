#include<bits/stdc++.h>
using namespace std;

int n;
int a[25][25];
int b[25][25];

int s[25][25];
int l[25][25];
int y[25][25];

int main()
{
	int t;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				scanf("%d",&a[i][j]);
			}
		}for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				scanf("%d",&b[i][j]);
			}
		}
		
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				y[n-i+1][n-j+1] = a[i][j];
			}
		}
		
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				s[j][n-i+1] = a[i][j];
			}
		}
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				l[n-i+1][n-j+1] = s[i][j];
			}
		}
		int ans = 3;
		int flag = 3;
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				if(y[i][j]!=b[i][j]){
					flag = 0;
					break;
				}
			}
		}
		
		if(flag == 3){
			ans = 2;
		}flag = 1;
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				if(s[i][j]!=b[i][j]){
					flag = 0;
					break;
				}
			}
		}if(flag == 1) ans = 1;
		flag = 1;
		for(int i=1;i<=n;++i){
			for(int j=1;j<=n;++j){
				if(l[i][j]!=b[i][j]){
					flag = 0;
					break;
				}
			}
		}if(flag == 1) ans = 1;
		
		if(ans == 3)printf("-1\n");
		else printf("%d\n",ans);
	}
	return 0;
}
