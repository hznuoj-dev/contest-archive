#include <bits/stdc++.h>
using namespace std;
int a[25][25],b[25][25];

int main(){
	int t,i,n,j,k,s,m;
	int x,y,z;
	cin>>t;
	for (i=0;i<t;++i){
		cin>>n;
		x=1;
		y=1;
		z=1;
		m=1;
		s=-1;
		for (j=1;j<=n;++j){
			for (k=1;k<=n;++k){
				cin>>a[j][k];
			}
		}
		for (j=1;j<=n;++j){
			for (k=1;k<=n;++k){
				cin>>b[j][k];
				if (b[j][k] !=a[n-j+1][n-k+1] ) y=0;
				if (b[j][k] !=a[n-k+1][j]) x=0;
				if (b[j][k] !=a[k][n-j+1]) z=0;
				if (b[j][k] !=a[j][k]) m=0;
			}
		}
		if (m==1) s=0;
		else if (x==1 || z==1) s=1;
		else if (y==1) s=2;
		cout<<s<<'\n';
	}
	return 0;
}
