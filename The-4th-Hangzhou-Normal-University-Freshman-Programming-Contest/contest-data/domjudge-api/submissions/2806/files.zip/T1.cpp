#include<bits/stdc++.h>

using namespace std;

int n;
struct nod{
	int w;
	string s;
}e[100005];

bool com(nod a,nod b){
	return a.w>b.w;
}

int main()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%d",&e[i].w);
		cin>>e[i].s;
	}
	sort(e+1,e+1+n,com);
	int k;
	scanf("%d",&k);
	cout<<e[k+1].s;
	return 0;
}
