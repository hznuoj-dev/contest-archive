#include<stdio.h>
#include<stdlib.h>
int main(){
	int T;
	scanf("%d",&T);
	while(T--){
		long n;
		int t=1;
		char ch;
		scanf("%ld",&n);
	//	scanf("%c",&ch);
		scanf("\n%c",&ch);
		char str[60];
		char *p;
		int strs[60]={0};
		int *q;
		q=strs;
		p=str;
		*p=ch;
		n--;
		*q=1;
		while(n--){
			scanf(" %c",&ch);
			int b;
			b=t;
			for(int i=0;i<b;i++){
				if(*(p+i)==ch){
					*(q+i)=*(q+i)+1;
					break;
				}
				else if(*(p+i)!=ch&&i==t-1){
					*(p+t)=ch;
					*(q+t)=1;
					t++;
				}
			}
		}
		long max=0;
		int a=100,i;
		for(i=0;i<t;i++){
			if(max<*(q+i)&&*(q+i)%2==1){
				max==*(q+i);
				a=i;
			}
		}
		long sum=0;
		if(a==100){
			for(i=0;i<t;i++){
				if(*(q+i)%2==0)
					sum+=*(q+i);
			}
			printf("%ld\n",sum);
		}
		else{
			sum+=strs[a];
			for(i=0;i<t;i++){
				if(*(q+i)%2==0)
					sum+=*(q+i);
			}
			printf("%ld\n",sum);
		}

	}
}
