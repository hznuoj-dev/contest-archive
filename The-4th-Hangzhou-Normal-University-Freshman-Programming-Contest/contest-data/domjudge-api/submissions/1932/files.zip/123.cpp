# include <stdio.h>
int main(void)
{
	int t;
	int n;
	int x;
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d%d",&n,&x);
		if (x==0)
			printf("no\n");
		else if (n%x==0)
			printf("yes\n");
		else if (n%x==1)
			printf("yes\n");
	}
	
	
	
	return 0;
}
