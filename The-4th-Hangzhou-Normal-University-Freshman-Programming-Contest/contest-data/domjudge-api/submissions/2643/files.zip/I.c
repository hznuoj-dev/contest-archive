#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct song{
	long long w;
	char s[20];
}p[100001];
int cmp(const void *a,const void *b){
	return ((struct song *)b)->w - ((struct song *)a)->w;
}
int main(void){
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%lld %s",&p[i].w,p[i].s);
	}
	qsort(p,n,sizeof(struct song),cmp);
	scanf("%d",&k);
	printf("%s\n",p[k].s);
	return 0;
}

