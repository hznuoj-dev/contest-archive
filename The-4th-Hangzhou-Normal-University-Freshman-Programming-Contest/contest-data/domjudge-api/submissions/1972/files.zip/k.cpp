#include<stdio.h>
#include<string.h>
struct music
{
	int love;
	char m[20];
}sing[100005];

int main()
{
	int n,i,j,k;
	char s[20];
	int a;
	scanf("%d",&n);
	i=1;
	for(i=1;i<=n;++i)
	{
		scanf("%d %s",&sing[i].love,sing[i].m);
	}
	scanf("%d",&k);
	for(i=1;i<=n;++i)
	{
		for(j=n;j>=i+1;--j)
		{
			if(sing[j].love>sing[j-1].love)
			{
				a=sing[j].love;sing[j].love=sing[j-1].love;sing[j-1].love=a;
				strcpy(s,sing[j].m);strcpy(sing[j].m,sing[j-1].m);strcpy(sing[j-1].m,s);
			}
		}
	}
	printf("%s",sing[k+1].m);
	return 0;
}
