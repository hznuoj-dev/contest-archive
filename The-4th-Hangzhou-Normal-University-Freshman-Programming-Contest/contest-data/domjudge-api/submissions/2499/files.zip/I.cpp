#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct Stu{
	char name[222];
	long long int num;
};
int cmp(const void *p,const void *q)
{
	struct Stu *pp=(struct Stu *)(p);
	struct Stu *pq=(struct Stu *)(q);
	int a=pp->num;
	int b=pq->num;
	return b-a; 
}
int main()
{
	struct Stu a[20001];
	int t,n,i=0,x;
	scanf("%d",&t);
	x=t;
	while(t--)
	{
			scanf("%lld%s",&a[i].num,a[i].name);
			qsort(a,x,sizeof(struct Stu),cmp);
			i++;
		
	}
	scanf("%d",&x);	
	printf("%s",a[x].name);
		
}
