#include <stdio.h>
#include <string.h>
#include <math.h>
#include <stdlib.h>
int main()
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		int n;
		scanf("%d",&n);
		int a[n][n];
		int b[n][n];
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				scanf("%d",&a[i][j]);
			}
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				scanf("%d",&b[i][j]);
			}
		}
		int c[n][n];
		int i,j;
		int flag=0;
	for(int pp=1;pp<=3;pp++){
		flag=0;
		int numa=0,numb=0;
		for(i=0;i<n;i++){
			numb=0;
			for(j=n-1;j>=0;j--){
				c[numa][numb]=a[j][i];
				numb+=1;
			}
			numa+=1;
		}
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				a[i][j]=c[i][j];
			}
		}
		
	    for(i=0;i<n;i++){
	    	for(j=0;j<n;j++){
	    		if(c[i][j]==b[i][j]) continue;
	    		else break;
			}
			if(j==n) continue;
			else break;
		}
		if(i==n) {
		    flag = 1;
		    if(pp==3) printf("1\n");
			else printf("%d\n",pp);
		} 
		else continue;
	}
	    if(flag==0) printf("-1\n");
		
	}
	
	return 0;
}
