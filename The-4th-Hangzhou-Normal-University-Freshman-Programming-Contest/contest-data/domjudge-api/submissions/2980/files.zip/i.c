#include<stdio.h>
#include<stdlib.h>

typedef struct MyStruct
{
	long long num;
	char name[18];
}aa;

aa list[100005];
 
int cmp(const void* a, const void* b) {
	if (((aa*)a)->num < ((aa*)b)->num)
		return (1 - 0);
	if (((aa*)a)->num == ((aa*)b)->num)
		return (0 - 0);
	if (((aa*)a)->num > ((aa*)b)->num)
		return (0 - 1);
}
int main(void) 
{
	int group, n;
	scanf("%d",&group);
	for (int i = 0; i < group; i++)
		scanf("%lld %s", &list[i].num, list[i].name);
	qsort(list, group, sizeof(list[0]),cmp);
	scanf("%d", &n);
	printf("%s", list[n].name);
	return 0;
}