#include <stdio.h>
int main(void){
	int n,m,x[10],k,flag,z;
	int i,d;
	scanf("%d%d",&n,&m);
	if(n==1){
		scanf("%d",&x[i]);
		if(x[i]==0) scanf("%d",&k);
		printf("QAQ");
	}
	else{
		flag=0;
		d=0;
		z=0;
		for(i=0;i<n;i++){
			scanf("%d",&x[i]);
			if(x[i]==0){
				scanf("%d",&k);
				if((m==0&&k>=2500)||(m==1&&k>2100)) flag=1;
			}
			else if(x[i]==1){
				d=1;
			}
			else if(x[i]==2) z=1;
		}
		if((d==1&&flag==1)||z==1) printf("haoye");
		else printf("QAQ");
	}
	return 0;
}

















