#include<stdio.h>
#include<string.h>
#include<ctype.h>
int main()
{
	char n[100000];
	char s[1010][40];
	char bd;
	long long t,i,k,p,j,o,q,f;
	scanf("%lld\n",&t);
	while(t--)
	{
		memset(n,'\0',sizeof(n));
		memset(s,'\0',sizeof(s));
		f = o = p = 0;
		int temp = 1;
		scanf("%[^\n]s",n);
		getchar();
		k = strlen(n);
		bd = n[k-1];
		for(i = 0;i < k;i++)
		{
			if(n[i] ==' ')
			{
				q = 0;
				for(j = p;j < i;j++)
				{
					s[o][q] = n[j];
					q++;
				}
				o++;
				p = i+1;
			}
		}
		for(i = k-1;i>0;i--)
		{
			q = 0;
			if(n[i] == ' ')
			{
				for(j = i+1;j < k-1;j++)
				{
					s[o][q] = n[j];
					q++;
				}
				break;
			}
		}
		i = 0;
		printf("%s",s[i]);
		i++;
		temp = o;
		while(temp--)
		{
			if(f == 0)
			{
				printf(" %s",s[o]);
				o--;
				f = 1;
			}
			else
			{
				printf(" %s",s[i]);
				i++;
				f = 0;
			}
		}
		if(t==0)
		{
			printf("%c",bd);
		}
		else
		{
			printf("%c\n",bd);
		}
	}
	return 0;
} 
