#include <stdio.h>
int main(){
	int t,i;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		printf("Welcome to HZNU\n");
	}
	return 0;
} 
