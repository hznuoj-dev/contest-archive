#include<bits/stdc++.h>
using namespace std;
const int N=100010;

int t;
int n;
int flag;
char a; 
int f[60];

int main(){
	cin >>t ;
	while(t--){
		cin >> n;
		memset(f,0,sizeof(f));
		for(int i=1;i<=n;i++){
			cin >> a;
			f[a-65]++;
		} 
		int maxo=0,maxj=0;
		for(int i=0;i<=60;i++){
			if(f[i]>0){
				if(f[i]%2==0){ //����ż���� 
					maxo+=f[i];
				}else if(f[i]%2==1){
					maxo+=f[i]-1;
					flag=1;
				} 
			}
		}
		if(flag==0)
			cout << maxo<<'\n';
		else cout << (maxo+1)<<'\n';
	}
return 0;
}



