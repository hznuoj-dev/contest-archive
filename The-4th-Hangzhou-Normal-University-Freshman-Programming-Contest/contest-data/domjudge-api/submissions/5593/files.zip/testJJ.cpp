#include<bits/stdc++.h>
using namespace std;

int main(){
	int num, form, leixing, muxue = 0, heihe = 0, atk[11], i = 0, max, b;

	scanf("%d %d", &num, &form);
	b = num;
	while(num--){
		scanf("%d", &leixing);
			if(leixing == 0){
				i++;
				scanf("%d", &atk[i]);
				max = atk[1];
			}else if(leixing == 1){
				muxue++;
			}else if(leixing == 2){
				heihe++;
			}
		}
		for(int m = 1;m < i; m++){
			if(max < atk[m+1]){
				max = atk[m+1];
			}
		}
		
	if(b >= 2){	
		if (heihe != 0){
			printf("haoye");
		}else{
			if(muxue == 0){
				printf("QAQ");
			}else{
				if(form == 0){
					if ( max >= 2500){
						printf("haoye");
					}else{
						printf("QAQ");
					}
				}else if(form == 1){
					if( max >= 2100){
						printf("haoye");
					}else{
						printf("QAQ");
					}
					
				}
			}
			
		}
	}else{
		printf("QAQ");
	}



	
	return 0;
}
