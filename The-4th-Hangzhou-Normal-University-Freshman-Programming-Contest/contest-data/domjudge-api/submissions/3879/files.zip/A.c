#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 
#include<ctype.h> 
int main()
{
	int i,t,n,m;
	char k,s[100005];
	scanf("%d",&t);
	while(t--)
	{
		m=0;
		scanf("%d",&n);
		while(n)
		{
			scanf("%c",&k);
			if(k>='a'&&k<='z'||k>='A'&&k<='Z')
			{
				s[m++]=k;
				n--;
			}
		}
		int h,flag[100]={0};
		for(i=0;i<m;i++)
		{
			h=s[i]-'A'+1;
			flag[h]++;
		}
		int glag=0,max=-1,imax,q=0;
		for(i=1;i<=70;i++)
		{
			if((flag[i]==1||flag[i]%2==1)&&flag[i]>max)
			{
				max=flag[i];
				imax=i;
				glag=1;
			}
		}
		if(glag==1)
			flag[imax]=0;
		for(i=1;i<70;i++)
		{
			if(flag[i]%2==0)
				q=q+flag[i];
			else if(flag[i]!=0)
				q=q+flag[i]-1;
		}
		if(max!=-1) 
			q=q+max;
		printf("%d\n",q);
	}
	return 0;
}
