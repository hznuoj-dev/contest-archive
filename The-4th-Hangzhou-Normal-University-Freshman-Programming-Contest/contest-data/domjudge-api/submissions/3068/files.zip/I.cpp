#include<stdio.h>
#include<stdlib.h>
struct name
{
	char name1[100];
	int num;
};
int comp(const void* p, const void* q) {
	return ((struct name*)p)->num - ((struct name*)q)->num;
}
int main()
{
		struct name s[100];
		int i, n;
		scanf("%d", &n);
		for (i = 0; i < n; i++)
		{
			scanf("%d%s", &s[i].num, s[i].name1);
		}
		qsort(s, n, sizeof(struct name), comp);
		for (i = 0; i < n; i++)
		{
			int k;
			scanf("%d", &k);
			printf("%s\n", s[i-k].name1);
		}
	return 0;
}