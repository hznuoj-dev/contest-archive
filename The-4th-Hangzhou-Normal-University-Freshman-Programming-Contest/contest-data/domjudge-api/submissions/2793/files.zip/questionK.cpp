#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
struct gequ{
	int chendu;
	string geming;
}haoge[100010];
void SWAP(int a,int b){
	swap(haoge[a].chendu,haoge[b].chendu);
	swap(haoge[a].geming,haoge[b].geming);
}
int main(void){
	int n,a;string b;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a>>b;
		haoge[i].chendu=a;
		haoge[i].geming=b;
	}
	for(int i=1;i<=n;i++){
		int index=i;
		for(int j=i;j<=n;j++){
			if(haoge[index].chendu<haoge[j].chendu){
				index=j;
			}
		}
		SWAP(index,i);
	}
	int m;cin>>m;
	cout<<haoge[m+1].geming;
} 
