#include<stdio.h>
int main(){
	int n,i,j,k;
	scanf("%d",&n);
struct{
	long long int x;
	char a[17];
}p[n],t;
	for(i=0;i<n;i++){
		scanf("%lld%s",&p[i].x,p[i].a);	
	}
	scanf("%d",&k);
	for(i=0;i<k+1;i++){
		for(j=0;j<n-1;j++){
			if(p[j].x<p[j+1].x){
				t=p[j];
				p[j]=p[j+1];
				p[j+1]=t;
				
			}
		}
	}
	
	printf("%s",p[k].a) ;
	return 0;
} 
