#include<stdio.h>
#include<string.h>
#include<math.h>
struct data{
	long long int love;
	char name[16];
}song;
int main(){
	long long int i,n,k,j,t,m,flag;;
	char n1[16];
	struct data song[10^5];
	scanf("%lld",&n);
	for(i=0;i<n;i++){
		scanf("%lld%s",&song[i].love ,song[i].name );
	};
	scanf("%lld",&k);
	while(1){
		flag=0;
		for(m=0;m<n-1;m++){
			for(j=m+1;j<n;j++){
				if(song[j].love >song[j-1].love ){
					t=song[j].love ;
					song[j].love=song[j-1].love;
					song[j-1].love=t;
					strcpy(n1,song[j].name );
					strcpy(song[j].name ,song[j-1].name );
					strcpy(song[j-1].name ,n1);
					flag=1;
				}
			}
		} 
		if(flag==0) break;
	}
	puts(song[k].name );
	
	return 0;
} 
