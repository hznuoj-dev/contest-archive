#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
struct Point {
    long long wi;
    string si;
};
Point aa[100001];
int main () {
    cnm;
    int n;
    cin >> n;
    for (int i = 0 ; i<n ; i++){
        cin >> aa[i].wi >> aa[i].si;
    }
    for (int i = 0 ; i<n ; i++){
        for (int j = 0 ; j<n-i-1 ; j++){
        if (aa[j].wi<aa[j+1].wi) {
            swap(aa[j],aa[j+1]);
        }
        }
    }
    /*for (int i = 0 ; i<n ; i++){
        cout << aa[i].si<<endl;
    }*/
    int k;
    cin >> k;
    cout << aa[k].si;
    
    return 0;
}