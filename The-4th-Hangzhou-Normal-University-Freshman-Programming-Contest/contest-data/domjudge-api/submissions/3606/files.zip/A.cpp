#include<stdio.h>
#include<string.h>
char a[100005];
int main()
{
	int t,i,sum,max;
	long long int n;
	int asc[152]={0};
	scanf("%d",&t);
	while(t--)
	{
		
		scanf("%lld",&n);
		getchar();
		for(i=0;i<n*2;i++)
		{
			scanf("%c",&a[i]);
			asc[(int)a[i]]++;
		}
		sum=0;
		max=0;
		for(i=65;i<=150;i++)
		{
			if(asc[i]%2==0)
				sum=sum+asc[i];
			else
				max=asc[i];
		}
		printf("%d\n",sum+max);
		memset(a,0,sizeof(a));
		memset(asc,0,sizeof(asc));
	}
}