#include<stdio.h>
int main()
{
	int a,b,c;
	scanf("%d",&a);
	while(a>1)
	{
		scanf("%d%d",&b,&c);
		if(c==0)
		{
			printf("no\n");
		}
		else
			printf("yes\n");
			a--; 
	}
	scanf("%d%d",&b,&c);
		if(c==0)
		{
			printf("no");
		}
		else
			printf("yes");

 } 
