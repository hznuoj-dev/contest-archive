# include <stdio.h>

int main(void)
{
	int i;
	
	scanf("%d", &i);

	for(i; i>0; i--)
		printf("Welcome to HZNU\n");


	return 0;
}