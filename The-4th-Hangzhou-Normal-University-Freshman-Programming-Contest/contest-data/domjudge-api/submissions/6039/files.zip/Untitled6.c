#include<stdio.h>
int main(){
	int n,m,k;
	scanf("%d%d",&n,&m);
	int i=0;
	int x;
	int flag;
	while(i<n){
		scanf("%d",&x);
		if(x==0){
			scanf("%d",&k);
			if(m==0){
				if(k>2100){flag=0;}
						else{
					if(i=n-1){printf("QAQ\n");
					}
					else
					flag=1;}
			}
			else{
				if(k>2100){flag=0;}
				else{
					if(i=n-1){printf("QAQ\n");
					}
					else
					flag=1;}
			}
		}
		else if(x==1){
			if(flag==0){
				printf("haoye\n");
			}
			else{
				if(i=n-1){
					printf("QAQ\n");
				}
			}
		}
		else{
			if(flag==1){
				printf("haoye\n");
			}
			else{
				if(i=n-1){
					printf("QAQ\n");
				}
			}
		} 
	}
	return 0;
}
