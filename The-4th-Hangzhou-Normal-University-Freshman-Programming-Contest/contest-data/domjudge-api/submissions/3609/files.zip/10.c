#include <stdio.h>
int main(void){
	int n,m,a[10],k[10],i,d,flag=0,j;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;++i){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&k[i]);	
		}
	}
	for(i=0;i<n;++i){
		if(a[i]==2&&n>=2){
			flag=1;
			break;
		}
		if(a[i]==1){
			for(j=0;j<n;++j){
				if(a[j]==0){
					if((m==0&&k[j]>=2500)||(m==1&&k[j]>2100)){
						flag=1;
						break;
					}
				}
			}
		}
		if(a[i]==0){
			continue;
		}
	}
	if(flag==1){
		printf("haoye");
	}
	else if(flag==0){
		printf("QAQ");
	}
	return 0;
} 
