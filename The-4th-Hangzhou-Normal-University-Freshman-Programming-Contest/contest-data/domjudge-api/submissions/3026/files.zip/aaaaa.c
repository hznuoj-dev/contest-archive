#include <stdio.h>
int n[1000000],x[1000000];
int main(void){
	int t,i;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d%d",&n[i],&x[i]);
		if(x[i]==0) printf("no\n");
		else printf("yes\n");
	}
	return 0;
}










