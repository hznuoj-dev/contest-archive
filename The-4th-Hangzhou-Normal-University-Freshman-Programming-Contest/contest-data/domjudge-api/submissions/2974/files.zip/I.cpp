#include<stdio.h>
#include<stdlib.h>
struct song
{
	long long w;
	char name[20];
};
int comp(const void*p, const void*q) {
	return((struct song*)q)->w - ((struct song*)p)->w;
}
int main(void) {
	long n, k;
	scanf("%ld", &n);
	struct song songarray[n - 1];
	for (long i = 0; i < n; i++)
	{
		scanf("%lld%s", &songarray.w, songarray.name);
	}
	scanf("%ld", &k);
	qsort(songarray, n - 1, sizeof(struct song), comp);
	printf("%s", songarray[k].name);
	return 0;
}