#include<stdio.h>
#define max(a,b) a>=b?a:b 
int main(void){
	int n,m,x,y,i,flag_1=0,Max=-1;
	scanf("%d %d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&x);
		if(x==2&&n>=2){
			printf("haoye\n");return 0;//�ں�ֱ��Ĩ�� 
		}
		else if(x==1) flag_1=1; //�ж��Ƿ���Ĺָ 
		else if(x==0){
			scanf("%d",&y);Max=max(Max,y);
		} 
	}
	if(m==0&&flag_1==1&&Max>=2500) printf("haoye\n");
	else if(m==1&&flag_1==1&&Max>2100) printf("haoye\n");
	else printf("QAQ\n");
	return 0;
}

