#include<stdio.h>
#include<stdlib.h>
struct Stu
{
 	char name[21];
 	long long num;
}; 
int cmp(const void *p,const void *q)
{
 	return((struct Stu *)q)->num-((struct Stu *)p)->num;
}
int main(void)
{
 	struct Stu a[101];
 	long long N,i,j,h,b,k;
 		scanf("%lld",&b);
 		for(i=0;i<b;++i)
 		{
 			scanf("%lld %s",&a[i].num,a[i].name);
		}
			qsort(a,b,sizeof(struct Stu),cmp);
			scanf("%lld",&k);	
			for(i=b-1;i>=k;--i)
		{
			printf("%s\n",a[i].name);
		}

	return 0;
} 
