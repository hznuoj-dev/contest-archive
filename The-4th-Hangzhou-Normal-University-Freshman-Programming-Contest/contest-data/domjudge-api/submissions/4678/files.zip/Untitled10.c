#include<stdio.h>
main(){
	int n,m;
	int i,j,k,temp;
	int a[10],b[10],d[10];
	int c[3];
	for(i=0;i<3;i++){
		c[i]=0;
	}
	scanf("%d %d",&n,&m);
	j=0;
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		c[a[i]]++;
		if(a[i]==0){
			scanf("%d",&b[j]);
			j++;
		}
	}
	if(c[2]!=0&&n>1){
		printf("haoye");
	}
	else{
		if(c[1]!=0){
			for(i=0;i<j;i++){
				for(k=0;k<j-i-1;k++){
					if(b[k]<b[k+1]){
						temp=b[k];
						b[k]=b[k+1];
						b[k+1]=temp;
					}
				}
			}
			if(m==0&&b[0]>=2500||m==1&&b[0]>=2100){
				printf("haoye");
			}
			else{
				printf("QAQ");
			}
		}
		else{
			printf("QAQ");
		}
	}
}
