#include<stdlib.h>
#include<stdio.h>
int main() 
{
	int a,n,x;
   scanf("%d",&a);
	while(a--)
	{
		scanf("%d%d",&n,&x);
		if(x==0)
		{
			printf("no\n"); 
		}
		else printf("yes\n");
	}
	
}


