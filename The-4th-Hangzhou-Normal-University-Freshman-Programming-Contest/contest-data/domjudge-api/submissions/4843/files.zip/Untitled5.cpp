#include<stdio.h>
int main(void){
	int n,k,i,j;
	scanf("%d",&n);
	long a[n+1],e;
	char b[n+1][16];
	for(i=0;i<n;i++){
		scanf("%ld",&a[i]);
		getchar();
		scanf("%s",b[i]);
	}
		scanf(" %d",&k);
	int f=-1;
	for(i=0;i<=k;i++){
		e=0;
		f=-1;
		for(j=0;j<n;j++){
			if(a[j]>e){
					f=j;
					e=a[j];
				}
			}
		a[f]=-100;
	}
		printf("%s",b[f]);
	return 0;
}
