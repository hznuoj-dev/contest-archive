#include<stdio.h>

#include<stdlib.h>
int main()
{
	struct hehe{
		char ar[16];
		int youxian;
		struct hehe *next;
	};
	int n,max,i;
	struct hehe *head,*p1,*p2;
	int flag=0;
	struct hehe *P,*P1,*P2,*Ptshang;
	int k;
	scanf("%d",&n);

    p1=p2=(struct hehe *)malloc(sizeof(struct hehe));
    scanf("%d %s",&p2->youxian,&p2->ar);
	head=p1;
	for(i=2;i<=n;i++)
	{
		p1=(struct hehe *)malloc(sizeof(struct hehe));
		scanf("%d %s",&p1->youxian,&p1->ar);
		p2->next=p1;
		p2=p1;
	}
	p2->next=NULL;
	scanf("%d",&k);

	for(i=1;i<=k;i++)
	{
		flag=0;
		for(P=head; ; )
		{
			if(flag==0)
			{
				max=P->youxian;
				flag=1;
				P1=P;
			}
			else
			{
				if(max<P->youxian)
				{
					max=P->youxian;
					P1=P;
					P2=Ptshang;
					flag=2;
				}
			}
			if(P->next==NULL)
				break;
			Ptshang=P;
			P=P->next;
		}
		if(flag==1)
			head=P1->next;
		else
		    P2->next=P1->next;
	}

	P=head;
	for(P1=head->next; ; )
	{
	    if(P1==NULL)
		{
			printf("%s\n",P->ar);
			break;
		}
		else
		{
		   if(P->youxian<P1->youxian)
			   P=P1;
		}
		P1=P1->next;
	}
	
	return 0;
}
