#include<stdio.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,m,flag=0;
	scanf("%d %d",&n,&m);
	int fh;
	if(m==0) fh=2500;
	else fh=2100;
	int a[3]={0},i,x,k;
	for(i=1;i<=n;i++){
		scanf("%d",&x);
		if(x==0){
			scanf("%d",&k);
			if(k>=fh) a[0]++;
		}
		else a[x]++;
	}
	if(a[0]>0&&a[1]>0){
		flag=1;
	} 
	else if(a[2]>0&&n>=2){
		flag=1;
	}
	if(flag==1) printf("haoye");
	else printf("QAQ");
}
