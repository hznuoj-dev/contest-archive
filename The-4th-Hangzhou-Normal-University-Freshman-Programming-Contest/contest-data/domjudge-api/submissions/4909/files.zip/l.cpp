#include<stdio.h>

int main()
{
	int t,flag=0;
	long long x,n;
	scanf("%d",&t);
	while(t--)
	{
		flag=0;
		scanf("%lld %lld",&n,&x)
		if(x==0)
		{
			flag=1;
		}
		if(flag==1)
		{
			printf("no\n");
		}
		else
		{
			printf("yes\n");
		}
	}
	return 0;
}
