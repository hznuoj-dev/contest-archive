#include<stdio.h>
int main(){
	int m,n,fhr,i,jie;
	int a[11][3];
	int sign[3];
  scanf("%d%d",&n,&m);
  for (i=0;i<=2;i++) sign[i]=0;
  if (m==1) fhr=2100;
    else fhr=2500;
  for (i=1;i<=n;i++){
  	scanf("%d",&a[i][1]);
  	sign[a[i][1]]=1;
  	if (a[i][1]==0) scanf("%d",&a[i][2]);
  } 
  jie=0;
  if (sign[0]==1&&sign[1]==1){
  	for (i=1;i<=n;i++){
  		if (a[i][1]==0){
  			if (a[i][2]>=fhr) {
  				jie=1;
  				break;
			  }
		  }
	  }
  }
  if (sign[2]==1&&n>=2) jie=1;
  if (jie==1) printf("haoye");
    else printf("QAQ");
  return 0;
}
