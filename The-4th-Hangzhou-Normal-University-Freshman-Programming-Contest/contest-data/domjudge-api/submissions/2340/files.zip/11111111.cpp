#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main (){
	long long int m,n,i,j;
	scanf("%lld %lld",&n,&m);
	long long int a[n][m];
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%lld",&a[i][j]);
		}
	}
	long long int min,ans[n],k;
	for(i=0;i<n;i++){
		ans[i]=fabs(a[i][0]-a[i][1]);
		for(j=0;j<m;j++){
			for(k=j+1;k<m;k++){
				if(fabs(a[i][j]-a[i][k])<ans[i]){
					ans[i]=fabs(a[i][j]-a[i][k]);
				}
			}
		}
	}
	min = ans[0];
	for(i=1;i<n;i++){
		if(ans[i]<min){
			min=ans[i];
		}
	}
	printf("%lld",min);
	return 0;
} 
