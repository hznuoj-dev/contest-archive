#include<stdio.h> 
int main()
{ 
// long long int n;
   int t,i,p,j,n,d;
   p=0;
 char c[100010];
 scanf("%d",&t);
 while(t--)
 {
  scanf("%d",&n);
  getchar();
  for(i=0;i<n;++i)
  {
   scanf("%c",&c[i]);
   getchar();
 }
 for(i=0;i<n;i++)
  {
   for(j=i+1;j<n;j++)
   {
    if(c[i]==c[j]&&c[i]!='0'&&c[j]!='0')
    {
     c[i]=c[j]='0';
     p++;
     break;
    }
   }
  }
  d=2*p+1;
 printf("%d\n",d); 
    }
	return 0;
	}
