#include<bits/stdc++.h>
using namespace std;
int main(){
	int t,n,x;
	cin>>t;
	for(int i=0;i<t;i++){
		cin>>n>>x;
		if(x==0){printf("no\n");
		}
		else{printf("yes\n");}
	}
	return 0;
}
