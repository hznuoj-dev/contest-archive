#include<iostream>
#include<vector>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		vector<string>centence;
		bool flag=1;
		char node;
		while(1)
		{
			string str;
			cin>>str;
			if(str.at(str.size()-1)=='.'||str.at(str.size()-1)=='!'||str.at(str.size()-1)=='?')
			{
				node=str.at(str.size()-1);
				str.erase(str.size()-1,1);
				flag=0;
			}
			centence.push_back(str);
			if(flag==0)
			{
				break;
			}
		}
		bool flag2=1;
		int l=0;
		int r=0;
		for(int i=0;i<centence.size();i++)
		{
			if(i==centence.size()-1)	flag2=0;
			switch(i%2)
			{
			case 0:
				cout<<centence.at(l);
				l++;
				if(flag2)	cout<<" ";
				break;
			case 1:
				cout<<centence.at(centence.size()-1-r);
				r++;
				if(flag2)	cout<<" ";
				break;
			}
		}
		cout<<node<<endl;
		
		
	}
		
	return 0;
}
