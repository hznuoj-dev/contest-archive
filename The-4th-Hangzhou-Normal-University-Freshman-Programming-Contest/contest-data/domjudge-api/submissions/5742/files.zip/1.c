#include <string.h>
#include <stdio.h>
#include <math.h>

int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int n,a[500][500],b[500][500],re=-1;
		scanf("%d", &n);
		int i, j;
		for (i = 1;i <= n;i++) {
			for (j = 1;j <= n;j++) {
				scanf("%d", &a[i][j]);
			}
		}
		for (i = 1;i <= n;i++) {
			for (j = 1;j <= n;j++) {
				scanf("%d", &b[i][j]);
			}
		}
		int st = 1, end = n;
		if (a[1][1] = b[n][n] && a[1][n] == b[n][1] && a[n][n] == b[1][1] && a[n][1] == b[1][n]) {
			printf("2\n");
			re = 1;
		}
		else if (a[1][1] = b[1][n] && a[1][n] == b[n][n] && a[n][n] == b[n][1] && a[n][1] == b[1][1]) {
			printf("1\n");
			re = 1;
		}
		else if (a[1][1] = b[n][1] && a[1][n] == b[1][1] && a[1][n] == b[1][1] && a[n][1] == b[n][n]) {
			printf("1\n");
			re = 1;
		}
		if (re == -1)
			printf("-1\n");
	}
}









