#include<iostream>
#include<algorithm>
using namespace std;
int main(void){
	int n,a,b;cin>>n;
	while(n--){
		cin>>a>>b;
		if(b!=0)
			cout<<"yes"<<endl;
		else
			cout<<"no"<<endl;
	}
} 
