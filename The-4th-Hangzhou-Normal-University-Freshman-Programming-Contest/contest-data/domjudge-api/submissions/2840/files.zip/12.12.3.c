#include<stdio.h>
#include<stdlib.h>
int comp(const void * p,const void * q)
{
	return ((*(long long int*))p - (*(long long int *))q);
}
struct song
{
	long long int a;
	char b[20];
};
int main()
{
	struct song arr[100000];
	long long int brr[100000];
	int n = 0, i = 0,k=0;
	scanf("%d",&n);
	for(i = 0; i < n; i++)
	{
		scanf("%lld %s",&arr[i].a,arr[i].b);
		brr[i] = arr[i].a;
	}
	scanf("%d",&k);
	qsort(brr,n,sizeof(long long int),comp);
	for(i = 0; i < n; i++)
	{
		if(brr[k - 1] == arr[i].a)
		{
			printf("%s\n",arr[i].b);
			break;
		}
	}
}
