#include<stdio.h>
#include<stdlib.h>
int cmp(const void*a,const void*b){
	return *(int *)a-*(int *)b;
}
int main(){
int a[100000];
char s[100000][15];
	int n;
	int *b;
	b = (int *)malloc(1000000002*sizeof(int));
	scanf("%d",&n);
	for(int i =0;i<n;i++){
	scanf("%d %s",&a[i],s[i]);

b[a[i]] = i+1;
}
	qsort(a,n,sizeof(a[0]),cmp);
	int x;
	scanf("%d",&x);
	int re = a[n-x-1];
	printf("%s",s[b[re]-1]);
	free(b);
}
