#include<stdio.h>
int main(){
  int t,i,j,m,n,a,b,k,sign;
  int remain[100]; 
  remain[1]=0;
  k=2;
  sign=1;
  scanf("%d",&t);
  for (i=1;i<=t;i++){
  	scanf("%d%d",&m,&n);
  	sign=1;
  	if (n==0) {
  		printf("no");
  		sign=0;
	  }
	if (n==1||n==2) {
		printf("yes");
		sign=0;
	}
  	a=m;
  	b=n;
  	while (sign>0) {
  		while (a>b){
  			b=b+n;
		  }
		if (a==b) {
			printf("yes");
			sign=0;
			break;
		}
		else {
			remain[k]=b-a;
			k++;
			for (j=1;j<k-1;j++){
				if (remain[j]==remain[k]) {
				  printf("no");
				  sign=0;
			      break;	
				}
			}
		}
		a=a+m;
	  }
	if (i!=t) printf("\n");
  } 
  return 0;
}
