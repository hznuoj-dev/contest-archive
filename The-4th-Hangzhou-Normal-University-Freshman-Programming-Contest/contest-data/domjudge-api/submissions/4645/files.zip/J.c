#include <stdio.h>
int main(){
	int n,m;
	int x,k,flag=0;
	scanf("%d%d",&n,&m);
	while(n--){
		scanf("%d",&x);
		if(x==1||x==2)	flag==0;
		if(x==0)	scanf("%d",&k);
		if(m==0){
			if(k>=2500)	flag++;
		}else if(m==0){
			if(k>=2100)	flag++;
		}
	}
	if(flag)	printf("haoye");
	else	printf("QAQ");
	return 0;
}
