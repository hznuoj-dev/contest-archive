#include <stdio.h>
main()
{
	int T, N, song[21][21], lu[21][21], temp[21][21];
	int i, j;
	int sxb = 0,llf=0;
	scanf("%d", &T);
	while (T--)
	{
		sxb = 0;
		llf = 0;
		scanf("%d", &N);
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
			{
				scanf("%d", &song[i][j]);
				temp[i][j] = song[i][j];
			}
		}
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				scanf("%d", &lu[i][j]);
		}
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				if (song[i][j] != lu[i][j])
					sxb = 1;
		}
		if (sxb == 0) {
			llf = 4;
			goto here;
		}
		sxb = 0;
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				song[j][N - i + 1] = temp[i][j];
		}
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				temp[i][j] = song[i][j];
		}

		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				if (song[i][j] != lu[i][j])
					sxb = 1;
		}
		if (sxb == 0) {
			llf = 1;
			goto here;
		}
		sxb = 0;
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				song[j][N - i + 1] = temp[i][j];
		}
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				temp[i][j] = song[i][j];
		}

		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				if (song[i][j] != lu[i][j])
					sxb = 1;
		}
		if (sxb == 0) {
			llf = 2;
			goto here;
		}
		sxb = 0;
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				song[j][N - i + 1] = temp[i][j];
		}
		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				temp[i][j] = song[i][j];
		}

		for (i = 1; i <= N; i++) {
			for (j = 1; j <= N; j++)
				if (song[i][j] != lu[i][j])
					sxb = 1;
		}
		if (sxb == 0) {
			llf = 3;
			goto here;
		}
		sxb = 0;
	here:
		if (llf == 0)
			printf("-1\n");
		if (llf == 1 || llf == 3)
			printf("1\n");
		if (llf == 2)
			printf("2\n");
		if (llf == 4)
			printf("0\n");
		
	}
}