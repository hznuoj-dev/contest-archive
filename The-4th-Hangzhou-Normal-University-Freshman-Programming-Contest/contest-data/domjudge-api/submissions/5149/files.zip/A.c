#include<stdio.h>
int main(void){
	int n,T,i,sum,k,p;
	int num[52];
	char str;
	scanf("%d",&T);
	while(T--){
		sum=0;
		k=0;
		for(i=0;i<53;i++){
			num[i]=0;
		}
		scanf("%d",&n);
		getchar();
		while(n--){
			scanf("%c",&str);
			getchar();
			if('A'<=str&&str<='Z'){
				p=str-'A';
				num[p]++;
			} 
			if('a'<=str&&str<='z'){
				p=str-'a'+26;
				num[p]++;
			}
		}
		for(i=0;i<53;i++){
			if(num[i]!=0){
				if(num[i]%2==0){
					sum+=num[i];
				}
				else{
					k=i;
					sum+=num[i]-1; 
				}
			}
		}
		if(k!=0) sum+=1; 
		printf("%d\n",sum);
	}	
	return 0;
} 
