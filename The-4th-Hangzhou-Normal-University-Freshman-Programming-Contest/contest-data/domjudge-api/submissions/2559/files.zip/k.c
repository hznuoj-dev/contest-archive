#include<stdio.h>
int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int a, b;
		scanf_s("%d%d", &a, &b);
		if (b == 0) { printf("no\n"); }
		if (a % b == 0) {
				printf("yes\n");
			}
		else {
			for (int k = 0;; k++) {
				if ((k * a) % b == 0) { printf("yse\n"); }
				else { printf("no\n"); }
				break;
			}
		}
		}
	return 0;
}
