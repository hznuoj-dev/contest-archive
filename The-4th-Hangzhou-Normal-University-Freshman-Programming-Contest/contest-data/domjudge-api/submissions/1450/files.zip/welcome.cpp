#include<bits/stdc++.h>
using namespace std;

int main(void){
	int n;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		if (i!=1) printf("\n");
		printf("Welcome to HZNU");
	}
	return 0;
}
