#include<stdio.h>
#include<string.h>
main()
{
	char k,b[55]={0};
	int t,n,ci,i,flag,num;
	int a[55]={0};
	scanf("%d",&t);
	while(t--)
	{
		ci=0;
		num=1;
		scanf("%d",&n);
		scanf("%c",&k);
		strcpy(b[num],k);
		a[1]=1;
		n--;
		while(n--)
		{
			scanf("%c",&k);
			for(i=1;i<=num;i++)
			{
				if(strcmp(b[i],k)==0)a[i]++;
				else {
					num++;
					strcpy(b[num],k);
					a[num]++;
				}
		}
		flag=0;
		for(i=1;i<=num;i++)
		{
			if(a[i]%2==0)ci=ci+a[i];
			else 
			{
				flag=1;
				ci=ci+a[i]-1;
			}
			a[i]=0;
		}
		printf("%d\n",ci+flag);
	}
}