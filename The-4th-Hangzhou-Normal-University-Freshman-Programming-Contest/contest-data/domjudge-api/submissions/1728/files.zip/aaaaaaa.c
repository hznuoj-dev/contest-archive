#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int a[100005]={0};
int main(){
	int t,x,n;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&x);
		if(x==0)
		{
			printf("no\n");
			continue;
		}
		else
		printf("yes\n");
	} 
	return 0;
}
