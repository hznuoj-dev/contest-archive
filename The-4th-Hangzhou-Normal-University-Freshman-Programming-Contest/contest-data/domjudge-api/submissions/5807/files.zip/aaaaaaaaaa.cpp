#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
char a[100010];
int b[128];
int main(){
	int n,m;
	int count=0,sum=0,s=0,cc=0;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
	    scanf("%d",&m);
			for(int j=1;j<=m;j++){
				scanf("%s",&a[j]);
				b[a[j]]++;
			}
			for(int k=48;k<=122;k++){
				if(b[k]%2==1) {
					if(b[k]>1)
					count=count+b[k]/2;
					cc=1;
				}
				else if (b[k]%2==0&&b[k]!=0) sum=sum+b[k]/2;
			}
			s=2*sum;
			if(count==0&& cc==1) s++;
			else if(count!=0&&cc==1) s=s+2*count+1; 
			printf("%d\n",s);
		for(int j=48;j<=122;j++){
			b[j]=0;
		}
		for(int j=1;j<=m;j++){
				a[j]='\0';
			}
			count=0;sum=0;s=0;cc=0;
		}
	return 0;
}
