#include<bits/stdc++.h>
using namespace std;
    string name[100010];
    long long s[100010],a[100010];
int main(){
    long long n,i,k;
    map<long long,string> p;
    cin>>n;
    for(i=0;i<n;i++){
    	cin>>s[i]>>name[i];
    	p[s[i]]=name[i];
	}
	cin>>k;
	sort(s,s+n);
	cout<<p[s[n-i]];
    return 0;
}
