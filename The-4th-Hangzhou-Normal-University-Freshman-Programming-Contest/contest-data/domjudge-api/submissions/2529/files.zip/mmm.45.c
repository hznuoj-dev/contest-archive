//
#include<stdio.h>
int main(void) {
	int t;
	scanf("%d", &t);
	while (t--) {
		int n, x, h;
		scanf("%d%d", &n, &x);
		if (x == 0)
			printf("no\n");
		if (x != 0) {
			for (int i = 0; ; i++) {
				h = i * n;
				if (h % x == 0) {
					printf("yes\n");
					break;
				}
			}
		}
	}
	return 0;
}