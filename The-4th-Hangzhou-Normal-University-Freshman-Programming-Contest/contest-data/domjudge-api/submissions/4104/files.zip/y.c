#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct song {
	long long love;
	char s[20];
};
int com(const void*a,const void *b){
	return ((struct song*)b)->love - ((struct song *)a)->love;
}
struct song a[100001],e;
int main (){
	int i,t;
	long n;
	int k;
	int max;
	char c;
	long a[1001];
	scanf("%d",&t);
	while(t--){
		k=0;
		for(i=0;i<1001;i++){
			a[i]=0;
		}
		scanf("%ld",&n);
		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&c);
			a[c]=a[c]+1;	
		}
		max=0;
		for(i=0;i<1001;i++){
		if(a[i]%2==1&&a[i]>max){
			max=a[i];
		}
		}
		for(i=0;i<1001;i++){
			if(a[i]%2==0){
				k=k+a[i];
			}
			else{
				if(a[i]>0){
					k=k+a[i]-1;
				}
		}
		}
		k=k+1;
		printf("%d\n",k);
	}
}