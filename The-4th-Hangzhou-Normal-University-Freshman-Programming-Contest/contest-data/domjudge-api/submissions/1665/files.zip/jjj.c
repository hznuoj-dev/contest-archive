/*********************************************************************
    ������:
    ����: 2021-12-12 13:43
    ˵��:
*********************************************************************/
#include <stdio.h>

int main() {
	int n, m, x[10], i, j = 0, y[10] = {0}, num1 = 0, num2 = 0;
	scanf("%d%d", &n, &m);
	for (i = 0; i < n; i++) {
		scanf("%d", &x[i]);
		if (!x[i]) {
			scanf("%d", &y[j++]);
		}
		if (x[i] == 1)
			num1++;
		if (x[i] == 2)
			num2++;
	}
	if (num2 && n >= 2) {
		printf("haoye");
		return 0;
	}
	if (num1 == 0) {
		printf("QAQ");
		return 0;
	}
	m = (m == 0 ? 2500 : 2100);
	for (i = 0; i < j; i++) {
		if (y[i] >= m) {
			printf("haoye");
			return 0;
		}
	}
	printf("QAQ");
	return 0;
}
