#include<stdio.h>
#include<stdlib.h>
struct song{
	long long int level;
	char geming[19];
};
int comp(const void*p,const void *q){
	return((struct song*)q)->level-((struct song*)p)->level;
}
int main(void){
struct song s[10000];
long long int n,k,i;
scanf("%lld",&n);
i=0;
while(i<n){
	scanf("%lld %s",&s[i].level,s[i].geming);
	i=i+1;
}
scanf("%lld",&k);
qsort(s,n,sizeof(struct song),comp);
printf("%s\n",s[k].geming);
 return 0;
}
