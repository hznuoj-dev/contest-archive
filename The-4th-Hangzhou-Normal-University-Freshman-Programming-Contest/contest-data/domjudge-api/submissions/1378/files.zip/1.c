#include<stdio.h>
#include<math.h>
#include<string.h>
int main (){
	int n=0;
	scanf("%d",&n);
	while(n--){
		printf("Welcome to HZNU\n");
	}
	return 0;
}
