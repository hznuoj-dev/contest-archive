#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int comp(int a,int b){
	return b-a;
}
int main(){
	int n,i,k;
	scanf("%d",&n);
	struct xx{
		int w;
		char s[20];
	};
	struct xx x[n];
	int a[n];
	for(i=0;i<n;i++){
		scanf("%d %s",&x[i].w,&x[i].s);
		a[i]=x[i].w;
	}
	scanf("%d",&k);
	
/*	int leap=1;
	struct xx t;
	while(leap){
		leap=0;
		for(i=0;i<n-1;i++){
			if(x[i].w<x[i+1].w){
				t=x[i];
				x[i]=x[i+1];
				x[i+1]=t;
				leap=1;
			}
		}
	}*/
	
	qsort(a,n,sizeof(int),comp);
	for(i=0;i<n;i++){
		if(a[k]==x[i].w){
			printf("%s",x[i].s);
			break;
		}
	}
	return 0;
}
