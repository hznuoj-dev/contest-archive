#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#define pzc 666
using namespace std;
	char sa[]={' ','_',' ',' ',' ',' ',' ','_',' ',' ','_',' ',' ',' ',' ',' ','_',' ',' ','_',' ',' ','_',' ',' ','_',' ',' ','_',' ','\0'};
	char sb[]={'|',' ','|',' ',' ','|',' ','_','|',' ','_','|','|','_','|','|','_',' ',' ','_',' ',' ',' ','|','|','_','|','|','_','|','\0'};
	char sc[]={'|','_','|',' ',' ','|','|','_',' ',' ','_','|',' ',' ','|',' ','_','|','|','_','|',' ',' ','|','|','_','|',' ','_','|','\0'};
int h1,m1,ss1,k,h2,m2,ss2,f,h3,m3,ss3;
	char s1[19],s2[19],s3[19];
int pd(char s1[],char s2[],char s3[],int n);
void dy1(int a,int b,int c);
void dy2(int a,int b,int c);
void dy3(int a,int b,int c);
int main()
{
	/*
   		_ 	_		 _		_   _ 	 _    _
	|  	_|	_|	|_|	|_     |_	 |  |_|  |_|
	|  |_	_|	  |  _|	   |_|   |  |_|   _|*/

	//d[]={' ',' ','',' ','_',' ',' ','_',' ',' ',' ',' ',' ','_',' ',' ','_',' ',' ','_',' ',' ','_',' ',' ','_',' ','\0'};
	scanf("%s",s1);
	scanf("%s",s2);
	scanf("%s",s3);

	h1=0,m1=0,ss1=0,k=0;
		h1=pd(s1,s2,s3,0)*10+pd(s1,s2,s3,3);
		m1=pd(s1,s2,s3,6)*10+pd(s1,s2,s3,9);
		ss1=pd(s1,s2,s3,12)*10+pd(s1,s2,s3,15);
		
	scanf("%s",s1);
	scanf("%s",s2);
	scanf("%s",s3);
	h2=0,m2=0,ss2=0,k=0;
		h2=pd(s1,s2,s3,0)*10+pd(s1,s2,s3,3);
		m2=pd(s1,s2,s3,6)*10+pd(s1,s2,s3,9);
		ss2=pd(s1,s2,s3,12)*10+pd(s1,s2,s3,15);
	//shuru	
	f=h1*3600+m1*60+ss1-h2*3600-m2*60-ss2;
	if(f>0) cout<<"early"<<endl;
	else if(f<0) cout<<"late"<<endl;
	else cout<<"gang gang hao"<<endl;
	if(f<0) f=-f;
	h3=f/3600;m3=f/60-h3*60;ss3=f%60;
	dy1(h3,m3,ss3);
	dy2(h3,m3,ss3);
	dy3(h3,m3,ss3);
//	printf("%c",s1[1]);
//	printf("%s\n",a);
//	printf("%s\n",b);
//	printf("%s\n",c);
}
void dy1(int a,int b,int c)
{
	int j,i;
	j=a/10;i=3;
	while(i--)
		printf("%c%c%c",s1[j*3],s1[j*3+1],s1[j*3+2]);
	j=a%10;i=3;
	while(i--)
		printf("%c%c%c",s1[j*3],s1[j*3+1],s1[j*3+2]);
	j=b/10;i=3;
	while(i--)
		printf("%c%c%c",s1[j*3],s1[j*3+1],s1[j*3+2]);
	j=b%10;i=3;
	while(i--)
		printf("%c%c%c",s1[j*3],s1[j*3+1],s1[j*3+2]);
	j=c/10;i=3;
	while(i--)
		printf("%c%c%c",s1[j*3],s1[j*3+1],s1[j*3+2]);
	j=c%10;i=3;
	while(i--)
		printf("%c%c%c",s1[j*3],s1[j*3+1],s1[j*3+2]);			
}
void dy2(int a,int b,int c)
{
	int j,i;
	j=a/10;i=3;
	while(i--)
		printf("%c%c%c",s2[j*3],s2[j*3+1],s2[j*3+2]);
	j=a%10;i=3;
	while(i--)
		printf("%c%c%c",s2[j*3],s2[j*3+1],s2[j*3+2]);
	j=b/10;i=3;
	while(i--)
		printf("%c%c%c",s2[j*3],s2[j*3+1],s2[j*3+2]);
	j=b%10;i=3;
	while(i--)
		printf("%c%c%c",s2[j*3],s2[j*3+1],s2[j*3+2]);
	j=c/10;i=3;
	while(i--)
		printf("%c%c%c",s2[j*3],s2[j*3+1],s2[j*3+2]);
	j=c%10;i=3;
	while(i--)
		printf("%c%c%c",s2[j*3],s2[j*3+1],s2[j*3+2]);			
}
void dy3(int a,int b,int c)
{
	int j,i;
	j=a/10;i=3;
	while(i--)
		printf("%c%c%c",s3[j*3],s3[j*3+1],s3[j*3+2]);
	j=a%10;i=3;
	while(i--)
		printf("%c%c%c",s3[j*3],s3[j*3+1],s3[j*3+2]);
	j=b/10;i=3;
	while(i--)
		printf("%c%c%c",s3[j*3],s3[j*3+1],s3[j*3+2]);
	j=b%10;i=3;
	while(i--)
		printf("%c%c%c",s3[j*3],s3[j*3+1],s3[j*3+2]);
	j=c/10;i=3;
	while(i--)
		printf("%c%c%c",s3[j*3],s3[j*3+1],s3[j*3+2]);
	j=c%10;i=3;
	while(i--)
		printf("%c%c%c",s3[j*3],s3[j*3+1],s3[j*3+2]);			
}
int pd(char s1[],char s2[],char s3[],int n)
{
	int i,k;
	i=0;k=0;
	while(k==0)
	{
		if(s1[n]==sa[i]&&s1[n+1]==sa[i+1]&&s1[n+2]==sa[i+2])
			if(s2[n]==sb[i]&&s2[n+1]==sb[i+1]&&s2[n+2]==sb[i+2]) 
				if(s3[n]==sc[i]&&s3[n+1]==sc[i+1]&&s3[n+2]==sc[i+2]) k=1;
		i=i+3;
	}
	return i/3;		
}
