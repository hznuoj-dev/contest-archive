#include<stdio.h>
int main()
{
	int T,temp,f;
	long long n,i,j;
	char c[100010];
	scanf("%d",&T);
	int a[100010];
	while(T--)
	{
		temp =f=0;
		scanf("%lld",&n);
		for(i = 0;i < n;i++)
		{
			getchar();
			scanf("%c",&c[i]);
			a[i] = 1;
		}
		for(i = 0;i < n;++i)
		{
			for(j = i+1;j < n;++j)
			{
				if((c[i] == c[j])&&(a[i]==1&&a[j]==1))
				{
					temp++;
					a[i] = a[j] = 0;
				}
			}
		}
		for(i = 0;i < n;i++)
		{
			if(a[i] == 1)
			{
				f = 1;
				break;
			}
		}
		if(f == 1&& temp != 0)
		{
			printf("%d",temp*2+1);
		}
		else if(temp==0&&f == 1)
		{
			printf("1");	
		}
		else
		{
			printf("%d",temp*2);
		}
		if(T!=0)
		{
			printf("\n");
		} 
	}
	return 0;
}
