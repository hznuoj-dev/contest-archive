#include <stdio.h>
int w[100010]={0};
int main()
{
	int t;
	scanf("%d",&t);
	int i,j,n,count=0,tt=0;
	while(t--)
	{
		count=0;
		scanf("%d",&n);
		for(i=0;i<n;i++)
			scanf("%d",&w[i]);
		for(i=0;i<n;i++)
		{
			tt=0;
			for(j=i;j<n;j++)
			{
				tt+=w[j];
				if(tt==7777)
				{
					++count;
					break;
				}
				else if(tt>7777)
				{
					break;
				}	
			}
		}	
		printf("%d\n",count);
	}
	return 0;
}
