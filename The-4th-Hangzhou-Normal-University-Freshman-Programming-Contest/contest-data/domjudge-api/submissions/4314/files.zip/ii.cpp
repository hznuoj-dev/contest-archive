#include<stdio.h>
struct ge{
	long long int x;
	char name[20];
};struct ge a[100000],t;
int main()
{	
	int n;
	int i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld",&a[i].x);
		getchar();
		scanf("%s",a[i].name);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(a[j].x<a[j+1].x)
			{
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
			}
		}
	}
	printf("%s\n",a[k].name);
	return 0;
}
