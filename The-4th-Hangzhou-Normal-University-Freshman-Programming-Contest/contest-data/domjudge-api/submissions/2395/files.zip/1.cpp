#include<stdio.h>
int main(void)
{
	int n;
	scanf("%d",&n);
   while(1<=n<=100)
	{
	printf("Welcome to HZNU\n");}
}
