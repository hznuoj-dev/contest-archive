#include<stdio.h>
#include<process.h>
struct song
{
	int favor;
	char name[20];
}stu[100001];
void swap(struct song *p1,struct song *p2)
{
	struct song t;
	if(p1->favor<p2->favor)
	{
		t=*p1;
		*p1=*p2;
		*p2=t;
	}
}
int main()
{
	int i,j,k;
	int n;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&stu[i].favor,stu[i].name);
	}
	scanf("%d",&k);
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(stu[j].favor<stu[j+1].favor)
			{
				swap(&stu[j],&stu[j+1]);
			}
		}
	}
	printf("%s",stu[k].name);
system("pause");
return 0;
}