#include<bits/stdc++.h>
using namespace std;
int n,m,q,f,sum;
int a[52];
char ch;
int main(){
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>m;
		sum=0;
		f=0;
		for(int k=0;k<52;k++)a[k]=0;
		for(int j=1;j<=m;j++){
			getchar();
			ch=getchar();
			if(ch>='A'&&ch<='Z'){
				a[ch-'A'+26]++;
			}
			else a[ch-'a']++;
		}
		sort(a,a+52);
		for(int h=51;h>=0;h--){
			if(a[h]==1&&f==0){
				sum=sum+a[h];
				f=1;
			}
			else if(a[h]%2==0)sum=sum+a[h];
		}
		cout<<sum<<'\n';
	}
	
	
	
	
	
	return 0;
}
