#include<bits/stdc++.h>
using namespace std;
int a[100010];
char s[100010][16];
int b[100010];
int main(){
	int n,k;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i]>>s[i];
		b[i]=a[i];
	}
	cin>>k;
	sort(a,a+n);
	int t=n-k-1;
	for(int i=0;i<n;i++){
		if(a[t]==b[i]){
			t=i;
			break;
		}
	}
	cout<<s[t];
	return 0;
}
