#include<stdio.h>as
#include<stdlib.h>
struct music{
	long long xh;
	char name[20];
};
int px(const void *p,const void *q)
{
	return((struct music *)q)->xh - ((struct music *)p)->xh;
}
int main(void)
{
	struct music musicArray[110000];
	int n;
	long long k,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld%s",&musicArray[i].xh,musicArray[i].name);
	}
	qsort(musicArray,n,sizeof(struct music),px);
	scanf("%lld",&k);
	printf("s\n",musicArray[k+1].name);
}
