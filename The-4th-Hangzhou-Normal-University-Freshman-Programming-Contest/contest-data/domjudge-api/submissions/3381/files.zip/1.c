#include<stdio.h>
int main(void){
	int a,b,t,i,x,y,shu[256],d=0,k,per=0,dang=0,shuang=0;
	char word[256];
	scanf("%d",&t);
	for(i=1;i<=t;i++){
		dang=0;
		d=0;
		shuang=0;
		scanf("%d",&a);
		for(b=1;b<=a;b++){
			scanf("%s",&word[b]);
		}
		for(x=1;x<=a;x++){
			d=d+1;
			for(y=1;y<=a;y++){
				if(word[x]==word[y]){
				shu[d]=shu[d]+1;}
				if(word[x]==word[y]&&x!=y){
					for(k=y;k<a;k++){
						word[k]=word[k+1];
					}a=a-1;
				}
				
			}
		}
	for(x=1;x<=d;x++){
		if(shu[x]%2==1)
		dang=1;
	}
	for(x=1;x<=d;x++){
		if(shu[x]%2==0)
		{
			shuang=shuang+shu[x];
		}
	}
	printf("%d\n",shuang+dang);
	}
	
	
	
	return 0;
} 
