#include<stdio.h>
#include<string.h>

int main() {
	int t, len, i, j,k;
	char s[30][1000] = { "" }, c, s1[30][1000] = { "" };
	scanf("%d", &t);
	while (t--) {
		for (i = 0; i < 1000; i++) {
			scanf("%s", s[i]);
			len = strlen(s[i]);
			if (s[i][len - 1] == '.' || s[i][len - 1] == '!' || s[i][len - 1] == '?') {
				c = s[i][len - 1];
				s[i][len - 1] = '\0';
				break;
			}
		}
		if (i % 2 == 0) {
			for (j = 0; j <= i / 2; j++) {
				if (j != i / 2) {
					printf("%s ", s[j]);
					printf("%s ", s[i - j]);
				}
			}
			printf("%s%c\n", s[i / 2], c);
		}
		else {
			for (j = 0; j <= i / 2; j++) {
				if (j != i / 2) {
					printf("%s ", s[j]);
					printf("%s ", s[i - j]);
				}
				else {
					printf("%s ", s[j]);
					printf("%s%c\n", s[i - j], c);
				}
			}
		}
	}
}