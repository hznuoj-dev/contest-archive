#include<bits/stdc++.h>
using namespace std;
bool primer(int x){
	for(int i=2;i<=x/i;i++){
		if(x%i==0)return 1;
	}
	return 0;
}
void solve(){
	int n,x;cin>>n>>x;
	if(x==0){
		cout<<"no\n";
		return;
	}
	int y=(n-1)/x+1;
	if(primer(x)&&y%x!=0)cout<<"no\n";
	else cout<<"yes\n";
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
