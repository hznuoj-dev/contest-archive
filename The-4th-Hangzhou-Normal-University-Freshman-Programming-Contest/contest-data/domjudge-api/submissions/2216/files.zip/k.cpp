#include<stdio.h>
#include<string.h>
struct music
{
	int love;
	int flag;
	char m[20];
}sing[100005];

int main()
{
	int n,i,j,k,max,sum,maxi;
	scanf("%d",&n);
	i=1;
	for(i=1;i<=n;++i)
	{
		scanf("%d %s",&sing[i].love,sing[i].m);
	}
	scanf("%d",&k);
	for(i=0;i<=k;++i)
	{
		max=-1;
		for(j=1;j<=n;++j)
		{
			if(sing[j].flag==0&&sing[j].love>max)
			{
				max=sing[j].love;
				maxi=j;
			}
		}
		sing[maxi].flag=1;
	}
	printf("%s",sing[maxi].m);
	return 0;
}
