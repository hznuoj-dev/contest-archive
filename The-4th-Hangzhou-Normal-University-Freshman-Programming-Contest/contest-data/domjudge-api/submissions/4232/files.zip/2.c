#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int n=0,m=0,i=0,h=0,g=0;
	int a=0,b=0;
	int aa[12]={0}; 
	scanf("%d %d",&n,&m);
	if(m==0){
		a=2500;
	} else if(m==1){
		a=2100;
	} 
	for(i=0;i<n;i++){
		scanf("%d",&aa[i]);
		if(aa[i]==0){
			scanf("%d",&b);
			if(b>=a){
				h=1;
			}
		}
	}
	for(i=0;i<n;i++){
		if(h==1&&aa[i]==1){
			g=1;
			break;
		}
		if(aa[i]==2&&n>=2){
			g=1;
			break;
		}
	}
	if(g==1){
		printf("haoye");
	} else {
		printf("QAQ");
	}
	return 0;
}
