#include<stdio.h>
#include<string.h>

int main(void){
	int t,n,m;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&m);
		if(m==0) printf("no\n");
		else printf("yes\n");
	}
	return 0;
}

