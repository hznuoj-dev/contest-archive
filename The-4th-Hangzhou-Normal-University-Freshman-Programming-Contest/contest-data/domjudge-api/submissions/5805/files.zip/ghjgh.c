#include<stdio.h>
int main(){
	int n,x,m,stk,p=0,t,q;
	scanf("%d%d",&n,&x);
	t=n;
	while(n--){
		scanf("%d",&m);
		if(m==0){
			scanf("%d",&stk);
		}
		if(m==2&&t>=2){
		q=2;
			
		}else{if(x==0&&m==0&&stk>2500){
			p+=1;
		}else{
			if(m==0&&stk>2100){
				p+=1;
			}
		}
		
			
		}
	if(p==1&&m==1){
		q=2;
	}	
		
		
		
	}
	if(q==2){
		printf("haoye");
		
	}else{
		printf("QAQ");
	}
	
	return 0;
} 
