#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#define MogeKo qwq

using namespace std;

int t,n,a[100],flag,ans;
char s[10];

void init(){
	flag = 0;
	ans = 0;
	memset(a,0,sizeof(a));
}

int main() {
	scanf("%d",&t);
	while(t--){
		init();
		scanf("%d",&n);
		for(int i = 1;i <= n;i++){
			scanf("%s",s);
			a[s[0]-'A']++;
		}
		for(int i = 0;i <= 'z'-'A';i++){
			if(a[i]%2) flag = 1;
			ans += a[i]/2; 
		}
		printf("%d\n",ans*2+flag);
	}
	return 0;
}
