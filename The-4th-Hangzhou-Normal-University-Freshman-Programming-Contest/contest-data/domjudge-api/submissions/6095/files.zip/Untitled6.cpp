#include<stdio.h>
#include<string.h>
int main(void){
	int T,i,j,t,k,b,c,d;
	scanf("%d",&T);
	while(T>0){
		char a[1000][31]={NULL};
		scanf(" %c",&a[0][0]);
		i=0;
		j=0;
		while(a[i][j]!='.'&&a[i][j]!='!'&&a[i][j]!='?'){
			j+=1;
			scanf("%c",&a[i][j]);
			if(a[i][j]==' '){
				i+=1;
				j=0;
				scanf("%c",&a[i][j]);
			}
		}
		k=strlen(a[i]);
		c=i/2;
			for(j=0;j<c;j++){
				if(j!=0)
				printf(" %s%s",a[j],a[i-j]);
				else{
					printf("%s",a[0]);
					for(b=0;b<k-1;b++){
						printf("%c",a[i][b]);
					}
				}
		        }
		if(i%2==0){
			d=strlen(a[c]);
			for(b=0;b<d-1;b++){
						printf("%c",a[c][b]);
					}
	    	printf("%c\n",a[i][k-1]);
		}
		else{
			printf("%s",a[c]);
			d=strlen(a[c+1]);
			for(b=0;b<d-1;b++){
						printf("%c",a[c+1][b]);
					}
			printf("%c\n",a[i][k-1]);
		}
		T-=1;
		}
	return 0;
}
