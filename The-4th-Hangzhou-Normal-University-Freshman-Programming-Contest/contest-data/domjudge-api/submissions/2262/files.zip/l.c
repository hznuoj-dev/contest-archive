#include <stdio.h>
#include <math.h>
#include <string.h>
int pi=10000;
int main(){ 
    int n,i,t,x;
    char a[pi];
    scanf("%d",&t);
    while(t--){
    	scanf("%d %d",&n,&x);
    	if(n*x!=0){
    		printf("yes\n");
		}else{
			printf("no\n");
		}
	}
	return 0;
}


