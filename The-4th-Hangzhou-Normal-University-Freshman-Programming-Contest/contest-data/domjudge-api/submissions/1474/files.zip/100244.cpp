#include <iostream>
using namespace std;
int main()
{
	int T;
	cin>>T;
	while (T--)
	{
		int a,b;
		cin>>a>>b;
		if (b!=0)
		{
			cout<<"yes"<<endl;
		}
		else
		{
			cout<<"no"<<endl;
		}
	}
}
