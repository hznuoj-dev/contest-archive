#include<stdio.h>
int a[100000];
void out(int a[100000],int n){
	int i,j,cnt=0;
		for(i=0;i<n;i++){
			int sum=a[i];
			j=i+1;
			while(j<n){
			if(sum+a[j]==7777){
			cnt++;
			break;
			}
			else if(sum+a[j]<7777){
				sum+=a[j];
			    j++;
			}
			}
			
		}
		printf("%d\n",cnt);
}
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int i,n;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		out(a,n);
	}
}
