#include <iostream>
#include <vector>
#include <map>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int q;
	cin>>q;
	while(q--){
		vc<string> arr;
		char c;
		while(1){
			string s;
			cin>>s;
			int n=s.size();
			if(s[n-1]=='.'||s[n-1]=='!'||s[n-1]=='?'){
				arr.push_back(s.substr(0,s.size()-1));
				c=s[n-1];
				break;
			}
			arr.push_back(s);
		}
		int i=1,j=arr.size()-1;
		cout<<arr.front();
		while(i<j){
			cout<<' '<<arr[j]<<' '<<arr[i];
			i++;
			j--;
		}
		if(i==j) cout<<' '<<arr[i];
		cout<<c<<endl;
	}
	return 0;
}

