#include <stdio.h>

int main(void)
{
	int n,m;
	scanf("%d %d",&n,&m);
	int a[11];
	int b[11];
	int i;
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&b[i]);
		}
	}
	int flag=0;
	int j,k;
	for(i=0;i<n;i++){
		if(a[i]==2&&n>=2){
			flag=1;
		}
		if(a[i]==0&&m==0&&b[i]>=2500){
			for(j=0;j<n;j++){
				if(a[j]==1){
					flag=1;
					break;
				}
			}
		}
		if(a[i]==0&&m==1&&b[i]>2100){
			for(k=0;k<n;k++){
				if(a[k]==1){
					flag=1;
					break;
				}
			}
		}
		if(flag==1)
		break;
	}
	if(flag==1)
	printf("haoye");
	else
	printf("QAQ");
	return 0;
 } 
