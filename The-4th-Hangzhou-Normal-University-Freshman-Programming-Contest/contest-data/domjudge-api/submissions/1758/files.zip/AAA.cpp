#include <cstdio>
#include <algorithm>
#include <set>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <climits>
#include <stack>
#include <map>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include<time.h>
#define tententen tql666
#define PI acos(-1) 
typedef long long int ll; 
using namespace std;
int main(){
	int t,x,n,k;
	char s;
	map<char,int>mymap;
	cin>>t;
	while(t--){
 	  	cin>>n;
 	  	for (int i = 1; i <= n; i++) {
			cin >> s;
			auto iter = mymap.find(s);
	        if (iter== mymap.end()) 
	                mymap[s] = 1;
	        else
					mymap[s]=mymap[s]+1;
		}
		int flag=0;
 	    k=mymap.size();
 	    for (auto it = mymap.begin(); it != mymap.end(); it++) {
			 if(it->second==1){
			 	flag=1;
			 }
			 x+=it->second/2;
		}
		x=x+flag;
 	  cout<<x<<endl;
 }
	return 0;
}

 /*map<string, g int>mp;
	int cmp(const pair<string,  int>& x, const pair<string,  int>& y) {
   	 	return x.second < y.second;
	}
	int main() {
		int n, t,s;
	    cin >> n;
	    for (int i = 1; i <= n; i++) {
	        string name = "";
	        cin >> name >> t;
	        auto iter = mp.find(name);
	        s = t * 1000000000 + i;
	        if (iter!= mp.end()) {/*相同取小*/ /*
	            if(s< mp[name])
	                mp[name] = s;
	        }
	        else {
	            mp[name] = s;
	        }
	    }
	    vector<pair<string,  int> >v(mp.begin(), mp.end());
	    vector<pair<string, g int> >::iterator it;
	    sort(v.begin(), v.end(), cmp);
	    for (it = v.begin(); it != v.end(); it++) {
	            cout << it->second %1000000000 << endl;
	    }
    return 0;
}	 */