#include<stdio.h>
#include<string.h>
char a[100005];
int b[100005]={0};
int main()
{
	int t,n,i,j,sum,k,word;
	scanf("%d",&t);
	while(t--)
	{
		sum=0;
		scanf("%d",&n);
		getchar();
		for(i=0;i<n;i++)
		{
			scanf("%s",&a[i]);
		}
		for(i=0;i<n;i++)
		{
			word=0;
			for(k=0;k<i;k++)
			{
				if(a[k]==a[i])
				{
					word+=1;
				}
			}
			if(word==0)
			{
				for(j=i;j<n;j++)
				{
					if(a[i]==a[j])
					{
						b[i]+=1;
					}
				}
				sum+=b[i]/2;
			}
			else
			{
				continue;
			}
		}
		if(sum==0)
		{
			printf("1\n");
		}
		else if((sum*2+1)>n)
		{
			printf("%d\n",n);
		}
		else
		{
			printf("%d\n",sum*2+1);
		}	
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
	}
	return 0;
}