#include<stdio.h>
#include<string.h>
int main(){
	int n,i,m,k,ATK=2500,DEF=2100,a,flag=0;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a);
		if(a==2&&i<n-1){
		i=i+1;
		if(flag==0){
			printf("haoye");
			break;
		}
		}
		if(a==0){
			scanf("%d",&k);
			if(m==0&&k>=ATK)
				flag=1;
			else if(m==1&&k>DEF)
				flag=1;
		}
		if(flag==1&&a==1){
			printf("haoye\n");
				break;
		}
	}
	if(i==n)
		printf("QAQ\n");
	return 0;
}