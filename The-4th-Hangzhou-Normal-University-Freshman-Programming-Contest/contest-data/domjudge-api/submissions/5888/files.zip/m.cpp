#include<stdio.h>
#include <string.h>
int main(void)
{
	int t;
	scanf_s("%d", &t);
	while (t--)
	{
		char str[30][1000] = { 0 };
		char tem[100];
		for (int i = 0; i < 30; i++)
		{
			gets_s(str[i]);
		}
		for (int i = 0; i < 29; i++)
		{
			for (int j = 0; j < 29 - i; j++)
			{
				if (strcmp(str[j], str[j + 1]) > 0)
				{
					strcpy(tem, str[j]);
					strcpy(str[j], str[j + 1]);
					strcpy(str[j + 1], tem);
				}
			}
		}
		for (int i = 0; i < 30; i++)
		{
			printf("%s\n", str[i]);
		}
		return 0;
	}
}