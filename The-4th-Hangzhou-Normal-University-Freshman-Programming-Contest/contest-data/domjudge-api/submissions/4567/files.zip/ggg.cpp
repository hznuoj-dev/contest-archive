#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
struct In 
{ 
int x; 
char s[16]; 
}; 
int cmp(const void *a ,const void *b ) 
{ 
	In *c = (In *)a; 
	In *d = (In *)b; 
	return c->x - d->x;
} 
int main()
{
	int T,n,sum=0,i,k;
	In a[100001];
	scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&a[i].x,a[i].s);
	 } 
	 qsort(a,n,sizeof(a[0]),cmp);
	 scanf("%d",&k);
	 printf("%s\n",a[n-k-1].s);
 } 
