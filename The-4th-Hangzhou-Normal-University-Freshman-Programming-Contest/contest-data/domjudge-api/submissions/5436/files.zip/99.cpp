#include<stdio.h>
struct card{
	long long a;
	char s[16];
}
int main(void){
	struct card g[100000];
	struct card b;
	long long n,k,i,j,t,f;
	scanf("%lld",&n);
	for(i=0;i<n;++i)
		scanf("%lld %s",&g[i].a,g[i].s);
	scanf("%lld",&k);
	for(i=0;i<=k;++i){
		t=i;
		f=0;
		for(j=i+1;j<n;++j){
			if(g[t].a<g[j].a){
				t=j;
				f=1;
			}
		}
		if(f){
			b=g[i];
			g[i]=g[t];
			g[t]=b;
		}
	}
	printf("%s\n",g[k].s);
	return 0;
}