#include<stdio.h>
struct song {
	int a;
	char b[100];
};
int main() {
	int t;
	struct song x;
	int k;
	struct song g[100];
	scanf("%d", &t);

	for (int i = 0; i < t; i++) {
		scanf("%d%s", &g[i].a, g[i].b);
	}
	for (int i = 1; i < t; i++) {
		for (int j = 0; j < t; j++) {
			if (g[j].a < g[j + 1].a) {
				x = g[j];
				g[j] = g[j + 1];
				g[j + 1] = x;
			}
		}
	}
	scanf("%d", &k);
	printf("%s", g[k].b);
	return 0;
}