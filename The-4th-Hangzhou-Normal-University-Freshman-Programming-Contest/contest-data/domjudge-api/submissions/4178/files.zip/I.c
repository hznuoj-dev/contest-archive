#include <stdio.h>
#include <stdlib.h>
struct ge{
	int w;
	char s[16];
};
int comp(const void *p,const void *q){
	return ((struct ge *)q)->w-((struct ge *)p)->w;
}
int main(){
	struct ge stffarr[100001];
	int i,n,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&stffarr[i].w,stffarr[i].s);
	}
	scanf("%d",&k);
	qsort(stffarr,n,sizeof(struct ge),comp);
	printf("%s",stffarr[0+k].s);
	return 0;
}

