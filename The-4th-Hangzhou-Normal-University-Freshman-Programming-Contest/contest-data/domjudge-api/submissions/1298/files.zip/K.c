#include<stdio.h>
int main(void){
  int n;
scanf("%d",&n);
for(int i=0;i<n;i++){
	printf("Welcome to HZNU\n");
}
 return 0;
}
