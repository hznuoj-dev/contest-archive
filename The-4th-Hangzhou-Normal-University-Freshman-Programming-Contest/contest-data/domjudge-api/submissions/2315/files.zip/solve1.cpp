#include<bits/stdc++.h>

using namespace std;
const int maxn=1e6+10;
struct node{
    int id;
    int num;
}a[maxn];
bool cmp(node x,node y)
{
    return x.num<y.num;
}
int main()
{
    int n,m;
    scanf("%d%d",&n,&m);
    int cnt=0;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=m;j++){
            int num;
            scanf("%d",&num);
            a[++cnt].id=i;
            a[cnt].num=num;
        }
    }    

    sort(a+1,a+n*m+1,cmp);

    int now=1;
    int have[15]={0};
    int pos=0;
    int ans=a[n*m].num-a[1].num;
    for(int i=1;i<=n*m;i++){
        while(pos<n&&now<=n*m){
            if(have[a[now].id]==0){
                have[a[now].id]=1;
                pos++;
            }else{
                have[a[now].id]++;
            }
            now++;
        }
        if(now>n*m&&pos<n)break;
        //cout<<i<<" "<<now-1<<endl;
        ans=min(ans,a[now-1].num-a[i].num);

        have[a[i].id]--;
        if(have[a[i].id]==0)pos--;
    }
    cout<<ans<<endl;
}

/*
2 3 
5 7 6 
9 8 2 

2 6 5 7 8 9
*/