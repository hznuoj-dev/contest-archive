#include<stdio.h>
	struct stu{
		int x;
		char a[20];
	};
int main()
{
	struct stu opp[10000],t;
	int n,i,j,k;
	scanf("%d",&n);

	for(i=0;i<n;i++)
	{
		scanf("%d %s",&opp[i].x,opp[i].a);
	}
	scanf("%d",&k);
	for(j=0;j<n-1;j++)
	{
		for(i=0;i<n-1-j;i++)
		{
			if(opp[i].x<opp[i+1].x)
			{
				t=opp[i];opp[i]=opp[i+1];opp[i+1]=t;
			}
		}
	}
	printf("%s\n",opp[k].a);
	return 0;
}
