#include<bits/stdc++.h>
using namespace std;

int main(){
	int t,n,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&x);
		int flag=0;
		if(x==0)
			printf("no\n");
		for(int i=1;i<=9;i++){
			if(n*i%x==0)
				flag=1;
		}
		if(flag==1)
			printf("yes\n");
		else if(flag==0)
			printf("no\n");
	} 
	return 0;
} 
