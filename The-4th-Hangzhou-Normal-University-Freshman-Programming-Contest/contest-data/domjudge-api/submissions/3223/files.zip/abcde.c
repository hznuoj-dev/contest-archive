#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
int main(void){
	int x,i,n;
scanf("%d",&n);
while(n--){
	scanf("%d",&x);
	int ch[100009]={0};
	int sum=0,j,y=7777;
	for(i=0;i<x;++i)
	scanf("%d",&ch[i]);
	for(i=0;i<x;++i){
		for(j=i;j<x;++j)	{
			if(y-ch[j]>0) y=y-ch[j];
		else if(y-ch[j]==0) {
			sum++;
			break;
		}
		else break;
		}	
	}
	printf("%d\n",sum);
}
	return 0;
} 
