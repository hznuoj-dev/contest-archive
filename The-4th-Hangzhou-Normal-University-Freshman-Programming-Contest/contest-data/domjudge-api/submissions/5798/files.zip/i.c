#include <stdio.h>
#include <stdlib.h>

struct music {
	int b;
	char s[20];
};

int comp(const void *p, const void *q) {
	return ((struct music *)q)->b - ((struct music *)p)->b;
}

int main() {
	int n, k, i;
	scanf("%d", &n);
	struct music x[n];

	for (i = 0; i < n; i++) {

		scanf("%d %s", &x[i].b, x[i].s);
	}

	scanf("%d", &k);
	qsort(x, n, sizeof(struct music), comp);

	for (i = k; i < k + 1; i++) {

		printf("%s\n", x[i].s);
	}

	return 0;
}