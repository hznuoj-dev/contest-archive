#include <bits/stdc++.h>
using namespace std; 
int f,n;
int a[50][50],b[50][50],at[50][50];
void pd()
{
	int i,j;
	for(i=1; i<=n; ++i)
		for(j=n; j>=1; --j)
			at[i][n-j+1]=a[j][i];
	for (i=1; i<=n; i++)
		for (j=1; j<=n; j++)
			a[i][j]=at[i][j];
	
	for (i=1; i<=n; i++)
		for (j=1; j<=n; j++)
			if (a[i][j]!=b[i][j]) return;
	
	f=1;		
}
void pd1()
{
	int i,j;
	for (i=1; i<=n; i++)
		for (j=1; j<=n; j++)
			if (a[i][j]!=b[i][j]) return;
	
	f=1;		
}
int main()
{
	int T,i,j;
	scanf("%d",&T);
	while (T--)
	{
		scanf("%d",&n);
		for (i=1; i<=n; i++)
			for (j=1; j<=n; j++)
				scanf("%d",&a[i][j]);
		for (i=1; i<=n; i++)
			for (j=1; j<=n; j++)
				scanf("%d",&b[i][j]);
		
		int s=0;
		f=0;
		pd1();
		while (f!=1 && s<3)
		{
			s++;
			pd();
		}
		if (f==1)
		{
			if (s==3) s=s-2;
			printf("%d\n",s);
		}
		else printf("-1\n");
	}
	
}
