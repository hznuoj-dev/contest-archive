#include<stdio.h>
int main(){
	int n,m,i,t,flag1=0,flag2=0,flag3=0;
	scanf("%d%d",&n,&m);
	if(m==0) t=2500;
	else t=2100;
	int a[n],b[n];
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&b[i]);
			if(m==0&&b[i]>=2500||m==1&&b[i]>2100) flag1=1;
		}
		else if(a[i]==1){
			if(flag1) flag2=1;
			else flag3=1;
		}
		else if(flag3&&flag1) flag2=1;
	}
	if(n==0||n==1) printf("QAQ\n");
	else if(n>1){
		for(i=0;i<n;i++){
			if(a[i]==2||flag2){
				printf("haoye\n");
				break;
			}
		}
		if(i==n) printf("QAQ\n");
	}
	
}


