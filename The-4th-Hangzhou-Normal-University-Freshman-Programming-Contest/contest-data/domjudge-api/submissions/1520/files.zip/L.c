# include <stdio.h>
# include <math.h>
int main(){
	int t,n,x,i,b,c;
	scanf("%d",&t);
	while(t--){
		scanf("%d%d",&n,&x);
		c=0;
		b=n;
		if(x==0)c=0;
		else {
			for(i=n;n<=10e6;n=n+b){
				if(n%x==0){
					c=1;
					break;
				}
			}
		}
		if(c==1)printf("yes\n");
		else printf("no\n");
	}
}
