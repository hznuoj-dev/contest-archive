#include<stdio.h>
int main(){
	int n,m,a[1000],k,i,check=0,check1=0,j=0,check2=0;
	scanf("%d%d",&n,&m);
	int sum0=0,sum1=0,f=-1;
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0){
			j++;
			scanf("%d",&k);
			if(m==0){
				sum0=sum0+k;
			}
			else if(m==1){
				sum1=sum1+k;
			}
			if(sum0>=2500||sum1>2100){
				check=1;
			}
		}
		else if(a[i]==1){
			j++;
		    check1=1;
		}
		else if(a[i]==2){
			f++;
			check2=1;
		}
	}
	if(check==1&&check1==1){
		printf("haoye\n");
	}
	else if((j>0||f>0)&&check2==1){
		printf("haoye\n");
	}
	else{
		printf("QAQ\n");
	}
}
