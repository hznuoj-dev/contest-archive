#include<bits/stdc++.h>
using namespace std;
int a[100010];
int main()
{  int sum=0,ans=0,i,j,k,n,m,l,r;
   cin>>n;
   for (i=1;i<=n;i++)
   {  cin>>m;
      l=1;
      for (i=1;i<=m;i++)
      { cin>>k;
        a[i]=a[i-1]+k;
        if (a[i]>7777)
		{  while (a[i]>7777)
		  {
		   if (a[l]>=k) { a[i]-=a[l]; break;}
		   if (a[i-l]<=k) { a[i]-=a[i-l+1]; break;}
		   l++;
	      }
		} 
		if (a[i]==7777) ans++;
      }
      cout<<ans<<"\n";
   }
}
  
   

 

