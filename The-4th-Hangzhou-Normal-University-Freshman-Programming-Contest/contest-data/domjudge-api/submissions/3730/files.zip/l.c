#define _CRT_SECURE_NO_WARNINGS 1
#include<stdio.h>
int main(void)
{
	int n;
	long int a, b;
	scanf("%d", &n);
while(n--)
	{
		scanf("%ld%ld", &a, &b);
		if (b == 0)
		{
			printf("no\n");
		}
		else
			printf("yes\n");
	}
	
	return 0;
}