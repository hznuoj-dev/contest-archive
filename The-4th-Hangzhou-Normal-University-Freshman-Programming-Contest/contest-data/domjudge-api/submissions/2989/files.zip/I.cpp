#include <cstdio>
#include <algorithm>
#include <set>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <climits>
#include <stack>
#include <map>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include<time.h>
#define tententen tql666
#define PI acos(-1) 
typedef long long int ll; 	 
using namespace std;
	int cmp(const pair<ll, string>& x, const pair<ll, string>& y) {
   	 	return x.first > y.first;
	}
	int main(){
		int n, t,s,k,x;
	    cin >> n;
	    map<ll, string>mp;
	    for (int i = 1; i <= n; i++) {
	        string name ;
	        cin >> x >>name;
	        mp[x] = name;
	    }
	    cin>>k;
	    vector<pair<ll, string> >v(mp.begin(), mp.end());
	    vector<pair<ll, string> >::iterator it;
	    sort(v.begin(), v.end(), cmp);
	    int j=0;
		for (it = v.begin(); it != v.end(); it++) {
			if(j==k)
	            cout << it->second << endl;
	        ++j;
	    }
    return 0;
}