#include<stdio.h>
#include<string.h>
int main()
{
	int T,sum,i,j,z;
	char a[50000];
	scanf("%d",&T);
	getchar();
	while(T--)
	{
		char b[1000][31]={};
		sum=0,z=0;
		gets(a);
		for(i=0;i<strlen(a);i++)
		{
			if(a[i]==' ')
			{
				sum++;
				if(z==0)
				{
					for(j=0;j<i;j++)
					b[sum][j]=a[j];
					z=i+1;
				}
				else
				{
					for(j=z;j<i;j++)
					b[sum][j-z]=a[j];
					z=i+1;
				}
			}
			else if(i==strlen(a)-1)
			{
				sum++;
				for(j=z;j<i;j++)
				b[sum][j-z]=a[j];
				z=i+1;
			}
		}
		for(i=1;i<=(sum+1)/2;i++)
		{	
			if(i!=(sum+1)/2)
			printf("%s %s ",b[i],b[sum+1-i]);
			else if(sum%2==0)
			printf("%s %s",b[i],b[sum+1-i]);
			else if(sum%2==1)
			printf("%s",b[i]);
		}
		printf("%c%c\n",a[strlen(a)-1],a[strlen(a)]);
	}
	return 0;	
} 
