#include<stdio.h>
int main()
{
	int t,i,j,f;
	long long int n,x;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%lld %lld",&n,&x);
		f=0;
		for(i=1;i<=1000001&&x!=0;i++)
		{
			if((n*i)%x==0)
			{
				printf("yes\n");
				f=1;
				break;
			}
		}
		if(f==0||x==0)
			printf("no\n");
	}
}