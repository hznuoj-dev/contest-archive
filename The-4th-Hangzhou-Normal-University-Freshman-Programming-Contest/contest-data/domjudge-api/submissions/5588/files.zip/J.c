#include<stdio.h>
#include<process.h>
int main(){
	int n,m,x[100],i,k[100],j,h=0,w=0;
	scanf("%d %d",&n,&m);
for(i=0;i<n;i++){
	scanf("%d",&x[i]);
	if(x[i]==0) scanf("%d",&k[i]);
}
	 for(j=0;j<n;j++){
		 if(x[j]==2&&n>=2 ){
		 h=1;
		 w=1;
		 } 
	 }
	
	 if(m==0){
		for(j=0;j<n;j++){
		          if(x[j]==0&&k[j]>=2500) h=1;
		          if(x[j]==1)w=1;
		                } 
	   
	            }
	else
	{
		for(j=0;j<n;j++){
		
		if(x[j]==0&&k[j]>2500) h=1;
		if(x[j]==1)w=1;
		}
	   
	
	} 
	 if(h==1&&w==1)  printf("haoye");
		else printf("QAQ");
	system("pause");
return 0;
}