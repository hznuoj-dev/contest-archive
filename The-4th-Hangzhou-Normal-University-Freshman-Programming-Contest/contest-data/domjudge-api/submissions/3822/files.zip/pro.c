#include<stdio.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
int main(){
	struct sing{
		int x;
		char str[16];
	};
	struct sing s[100001];
	struct sing t;
	int n,i,k,j,l;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].x,s[i].str);	
	}
	qsort(s,n,sizeof(struct sing),comp);
	scanf("%d",&k);
	printf("%s",s[k].str);
	return 0;
}
int comp(const void *p,const void *q){
	return (*(int *)q-*(int *)p);
}
