#include<stdio.h>
#include<stdlib.h>
#define nb 10^5
typedef struct{
	int cd;
	char mz[16];
}sing; 
int comp(const void*p,const void*q){
	return ((sing*)q)->cd-((sing*)p)->cd;
}
int main(void){
	sing a[nb];
	int i;
	int k,n;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d%s",&a[i].cd,a[i].mz);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(sing),comp);
	printf("%s",a[k].mz);
	return  0;
}
