#include<bits/stdc++.h>
using namespace std;
string s[1010]; 
int main(){
	char ch;
	int n,i=0;
	scanf("%d",&n);
	while(n){
		n--;
		for(int j=0;j<=i;j++){
			s[j]={};
		}
		i=0;
		scanf("%c",&ch);
		while(ch!='.' &&ch!='?' &&ch!='!'){
			if(ch==' '){
				i++; 
			}
			s[i]+=ch;
			scanf("%c",&ch);
		}
		for(int j=0,k=i;j<=(i-1)/2;j++,k--){
			cout<<s[j]<<s[k];
		} 
		if(i%2==0) cout<<s[i/2]<<ch<<'\n';
		 else cout<<ch<<'\n';
	} 
	return 0;
}
