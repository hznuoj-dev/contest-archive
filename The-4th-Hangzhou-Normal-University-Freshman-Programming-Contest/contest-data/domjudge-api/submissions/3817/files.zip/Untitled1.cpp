#include<stdio.h>
#include<stdlib.h>
int main(void)
{
 	int i,a,b,c,k,xue,flag=0;
 	scanf("%d %d",&a,&b);
 	if(b==0)
 	xue=2500;
 	else
 	xue=2100;
 	for(i=0;i<a;i++)
 	{
 		scanf("%d",&k);
 		if(k==0)
 		{
 			scanf("%d",&c);
 			xue-=c;
		}
		else if(k==1)
		{
			flag=1;
		}
		else if(flag==2)
		{
			xue=0;
		}
	}
	if(xue<=0&&flag==1)
	{
		printf("haoye\n");
	}
	else
	{
		printf("QAQ\n");
	}
	return 0;
} 
