#include <stdio.h>
#include <stdlib.h>
struct stff{
	int w;
	char s[16];
};
int comp(const void *p,const void *q){
	return ((struct stff *)q)->w-((struct stff *)p)->w;
}
int main(){
	struct stff stffarr[100001];
	int i,n,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&stffarr[i].w,stffarr[i].s);
	}
	scanf("%d",&k);
	qsort(stffarr,n,sizeof(struct stff),comp);
	printf("%s",stffarr[0+k].s);
	return 0;
}
