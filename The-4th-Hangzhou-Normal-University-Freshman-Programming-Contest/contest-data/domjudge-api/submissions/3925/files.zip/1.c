#include<stdio.h>
#include<string.h>
#include<math.h>
int main() {
	int n, i, j, t, w, x;
	char zi;
	scanf("%d", &t);
	while (t--) {
		w = 0;
		char a[10000];
		int arr[10000] = { 0 };
		x = 0;
		int tt=0;
		//getchar();
		scanf("%d", &n);
		getchar();
		for (i = 0; i < 2 * n; i++) {
			scanf("%c", &zi);
			arr[zi]++;

		}
		//scanf("%c", &a[i]);
		for (int i = 65; i < 91; i++) {
			if (arr[i] % 2 == 0) {
				w = w + arr[i];
			}
			else {
				w = w + arr[i] - 1;
				tt = 1;
			}
		}
		for (int i = 97; i < 123; i++) {
			if (arr[i] % 2 == 0) {
				w = w + arr[i];
			}
			else {
				w = w + arr[i] - 1;
				tt = 1;
			}
		}
		if (tt == 1) {
			w = w + 1;
		}
		printf("%d\n", w);
		/*for (i = 65; i < 123; i++) {
			if (b[i] % 2 == 0) {
				sum += b[i];
			}
			else if (b[i] > x) {
				x = b[i];
			}
		}
		sum += x;
		printf("%d\n", sum);*/


	}
}