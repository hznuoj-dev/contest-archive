#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int w[100][100], s[100][100];
int main(void) {
	int T;
	int n, i, j, k, i1, j1, flag;
	scanf("%d", &T);
	while (T--) {
		scanf("%d%d", &i, &j);
		if (j == 0) {
			printf("no\n");
		} else {
			printf("yes\n");
		}
	}

}