#include<stdio.h>
void bubble(long long int a[],int array);
int main(){
	int T;
	long long int n,a[10000];
	scanf("%d",&T);
	
	while (T--){
		int sum=0;
		int p;
	scanf("%lld",&n);
	for(int i=0;i<n;i++){
		scanf("%lld",&a[i]);
	}
	
	bubble(a,n);
	
	for(int j=0;j<n;++j){
		p=a[j];
	for(int i=j+1;p<7777;i=i+1){
		p+=a[i];
		if(p==7777) sum++;
		else sum=sum;
	}
	}
	for(int j=0;j<n;++j){
		p=a[j];
	for(int i=j+1;p<7777;i=i+2){
		p+=a[i];
		if(p==7777) sum++;
		else sum=sum;
	}
	}
	for(int j=0;j<n;++j){
		p=a[j];
	for(int i=j+1;p<7777;i=i+3){
		p+=a[i];
		if(p==7777) sum++;
		else sum=sum;
	}
	}
	for(int j=0;j<n;++j){
		p=a[j];
	for(int i=j+1;p<7777;i=i+4){
		p+=a[i];
		if(p==7777) sum++;
		else sum=sum;
	}
	}
	printf("%d",sum);
	}
}

void bubble(long long int a[],int array){
	int pass,i,t,n;
	for(pass=1;pass<array;++i){
		n=0;
		for(i=0;i<array-pass;++i){
			if(a[i]>a[i+1]){
				t=a[i];
				a[i]=a[i+1];
				a[i+1]=t;
				n=1;
			}
		}
		if(n==0)
		break;
	}
}
