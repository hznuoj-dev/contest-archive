#include<bits/stdc++.h>

using namespace std;

int main()
{
	int  n ,m;
	int flag=0,flag1=0;
	cin  >> n >> m;
	for(int i=1;i<=n;i++)
	{
		int x;
		cin >> x;
		if(x==2&&n>1)
		{
			cout << "haoye";
		
			return 0;
		} 
		else if(x==1)
		{
			flag=1;
		 	if(flag1==1)
		 	{
		 		cout << "haoye";
		 		return 0;
			}
		}
		else if(x==0)
		{
			int ak;
			cin >> ak;
			if(m==0)
			{
				if(ak>=2500) 
				{
					flag1=1;
					if(flag==0)
					{
					cout << "haoye";
		 			return 0;
					}	
				}
			}
			else if(m==1)
			{
				if(ak>2100) 
				{
					flag1=1;
					if(flag==0)
					{
					cout << "haoye";
		 			return 0;
					}	
				}
			}
		}
	
	}
	cout <<"QAQ" ;
	return 0;
}
