#include<stdio.h>
int n,i,k,pass,x,pm[100000],t;
	long long a[100000];
	char s[100000][17];
int main(void){
	scanf("%d",&n);
	for(x=0;x<n;x++){
			pm[x]=x;
	}
	for(i=0;i<n;i++){
		scanf("%lld",&a[i]);
		scanf(" %s",s[i]);
	}
	scanf("%d",&k);
	if(k<n/2){
	for(pass=1;pass<=k+1&&pass<n;pass++){
			for(x=n-1;x>=pass;x--){
				if(a[pm[x]]>a[pm[x-1]]){
					t=pm[x];
					pm[x]=pm[x-1];
					pm[x-1]=t;
				}
			}
		}
		printf("%s\n",s[pm[k]]);
	}
	else{
		for(pass=1;pass<=n-k+1&&pass<n;pass++){
			for(x=1;x<=n-pass;x++){
				if(a[pm[x-1]]<a[pm[x]]){
					t=pm[x];
					pm[x]=pm[x-1];
					pm[x-1]=t;
				}
			}
		}
			printf("%s\n",s[pm[k]]);
	}
}