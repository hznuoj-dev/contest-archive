#include<bits/stdc++.h>
using namespace std;
bool primer(int x){
	for(int i=2;i<=x/i;i++){
		if(x%i==0)return 1;
	}
	return 0;
}
void solve(){
	int n,x;cin>>n>>x;
	if(x)cout<<"yes\n";
	else cout<<"no\n";
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
