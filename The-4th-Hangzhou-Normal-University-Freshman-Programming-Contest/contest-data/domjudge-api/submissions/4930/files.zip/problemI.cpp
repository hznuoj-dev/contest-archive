#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int cmp(const void* e1,const void* e2);
struct ge
{
	long long int w;
	char s[16];
};
int main()
{
	long long int n,i;
	scanf("%lld",&n);
	struct ge a[n];
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&a[i].w,a[i].s);
	}
	long long int k;
	scanf("%lld",&k);
	qsort(a,n,sizeof(struct ge),cmp);
	printf("%s",a[k+1].s);
}
int cmp(const void* e1,const void* e2)
{
	return (*(struct ge*)e1).w-(*(struct ge*)e2).w;
}

