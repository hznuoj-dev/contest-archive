#include<bits/stdc++.h>
using namespace std;
struct song {
	long long w;
	string s;
} a[100001];

int main () {
	int n,w,al;

	cin>>n;

	for(int i = 1; i <= n; i++) {
		cin>>a[i].w>>a[i].s;
	}
	for(int i = 1; i <= n; i++) {
		for(int j = n; j > i; j--) {
			song k;
			if (a[j].w > a[j-1].w) {
				k = a[j];
				a[j] = a[j-1];
				a[j-1] = k;
			}
		}
	}
	cin>>al;
	cout<<a[al+1].s;
	return 0;
}
