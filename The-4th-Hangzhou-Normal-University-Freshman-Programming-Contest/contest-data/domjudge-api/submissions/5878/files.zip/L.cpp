#include<iostream>
#include<string>
#include<algorithm>
#include<map>
#include<set>
#include<functional>
using namespace std;
int main() {
	//def 2100
	//atk 2500
	int n, m;
	cin >> n >> m;
	set<int, greater<int> > g;
	int mu = 0;
	int hei = 0;
	int guai = 0;
	//m 0 atk 1 def
	for (int i = 0; i < n; i++) {
		int card;
		cin >> card;
		if (card == 0) {
			int at;
			cin >> at;
			g.insert(at);
			guai++;
		}
		if (card == 1) {
			mu++;
		}
		if (card == 2) {
			hei++;
		}
	}
	auto it = g.begin();

	
	
		if (m == 0) {
			if (*it >= 2500&&mu>0) {
				cout << "haoye" << endl;
			}
			else {
				if (hei > 0 && (guai + mu) > 0) {
					cout << "haoye" << endl;
				}else
				cout << "QAQ" << endl;
			}
		}
		else {
			if (*it >= 2100&mu>0) {
				cout << "haoye" << endl;
			}
			else {
				if (hei > 0 && (guai + mu) > 0) {
					cout << "haoye" << endl;
				}else
				cout << "QAQ" << endl;
			}
		}
	}
