#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
typedef struct{
	char a[20];
	int w;
}ST;
int com(const void*a,const void*b){
	int *p=(int*)a,*q=(int*)b;
	return ((ST*)p)->w-((ST*)q)->w;}
int main(){
	int n;
	scanf("%d",&n);
	ST str[n];
	int k,i;
		for(i=0;i<n;i++){
		scanf("%d %s",&str[i].w,str[i].a);}
		qsort(str,n,sizeof(str[0]),com);
		scanf("%d",&k);
		
		printf("%s\n",str[n-k-1].a);
			
	return 0;
}
