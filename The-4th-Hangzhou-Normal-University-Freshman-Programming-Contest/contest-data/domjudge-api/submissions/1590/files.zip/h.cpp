#include<stdio.h>
#include<math.h>
long long int a[1000000];
int main(){
	int i,m,n,t,j;
	long long int min;
	scanf("%d %d",&n,&m);
	min=1000000000;
	
	for(i=0;i<m*n;i++){
		scanf("%lld",&a[i]);
	}
	for(i=0;i<m*n;i++){
		for(j=i+1;j<m*n;j++){
			if(min>=fabs(a[i]-a[j])){
				min=fabs(a[i]-a[j]);
			}
		}
	}
	
	printf("%lld",min);
} 
