#include<stdio.h>
#include<string.h>
int w[100001];
char s[100001][20];
char s0[100001][20];
int main(void){
	int n, i, k;
	scanf("%d", &n);
	for(i=0;i<n;++i){
		//scanf("%d %s", &w[i], s[i]);
		scanf("%d %[^\n]s", &w[i], s[i]);
		getchar();
	}
	scanf("%d", &k);
	//paixu
	int p, j, t0;
	for(p=0;p<n;++p){
		j=p;
		for(i=p+1;i<n;++i){
			if(w[i]>w[j])
				j=i;
		t0=w[p];w[p]=w[j];w[j]=t0;
		strcpy(s0[0], s[p]);strcpy(s[p], s[j]);strcpy(s[j], s0[0]);
		}
	}//da->xiao
	//for(i=0;i<n;++i){
	//	printf("%d %s\n", w[i], s[i]);
	//}
	//printf("%s", s[k]);
	printf("%s", s[k]);
	return 0;
}
