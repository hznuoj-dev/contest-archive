#include<stdio.h>
struct song
{
	int favor;
	char name[50];
}stu[100001],temp;
void paixu(struct song stu[],int n)
{
	int i,j;
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-1-i;j++)
		{
			if(stu[j].favor<stu[j+1].favor)
			{
				temp=stu[j];
				stu[j]=stu[j+1];
				stu[j+1]=temp;
			}
		}
	}
}
int main()
{
	
	int n,i,j,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&stu[i].favor,stu[i].name);
	}
	scanf("%d",&k);
	paixu(stu,n);
	printf("%s",stu[k].name);
	return 0;
}
