#include<stdio.h>
int main(){
	int n,x;
	scanf("%d",&n);
	for(x=0;x<n;x++){
		printf("Welcome to HZNU\n");
	}
	return 0;
}
