# include <stdio.h>
# include <stdlib.h>
int comp(const void *p,const void *q);
struct Song
{
	long long grade;
	char name[100];	
	
};
struct Song stu[100000];
int main(void)
{
	
	long long n,m;
	long long i;
	scanf("%lld",&n);
	for (i=0;i<n;++i)
	{
		scanf("%lld %s",&stu[i].grade,stu[i].name);
	}
	qsort (stu,n,sizeof (struct Song),comp);
	scanf ("%lld",&m);
	for (i=m;i<n-1;++i)
		printf("%s ",stu[i].name);
	printf("%s",stu[i].name);
	
	
	return 0;
}
int comp(const void *p,const void *q)
{
	return ((struct Song*)q)->grade-((struct Song*)p)->grade;
}
