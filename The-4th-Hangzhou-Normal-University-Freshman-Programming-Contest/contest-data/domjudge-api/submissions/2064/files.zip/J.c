#include<stdio.h>
#include<string.h>

int main(void){
	int n,m,q,p,i;
	scanf("%d %d",&n,&m);
	int flag1=0,flag2=0;
	for(i=1;i<=n;i++){
		scanf("%d",&q);
		if(q==0){
			if(q==0) scanf("%d",&p);
			if(m==0&&p>=2500){
				flag1=1;
			}
			else if(m==1&&p>2100){
				flag1=1;
			}
		}
		if(q==1){
			if(flag1==1){
				flag2=1;
			}
		}
		if(q==2){
			if(i<=n-1){
				flag2=1;
			}
		}
	}
	if(flag2==1) printf("haoye\n");
	else printf("QAQ\n");
	return 0;
}

