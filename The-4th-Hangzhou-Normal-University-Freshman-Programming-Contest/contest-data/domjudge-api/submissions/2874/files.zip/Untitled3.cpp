#include<stdio.h>
#include<stdlib.h>
#include<math.h>
struct yoo{
	long long int num;
	char a[17];
};
int cmp(const void *p,const void *q)
{
	struct yoo *pp=(struct yoo *)(p);
	struct yoo *pq=(struct yoo *)(q);
	int a=pp->num;
	int b=pq->num;
	return b-a;
}
int main()
{
	struct yoo b[1001];
	long long int n,i,k;
	scanf("%lld",&n);
	for(i=0;i<n;i++)
	scanf("%lld%s",&b[i].num,b[i].a);
	qsort(b,n,sizeof(struct yoo),cmp);
	scanf("%lld",&k);
	printf("%s\n",b[k].a);
}
