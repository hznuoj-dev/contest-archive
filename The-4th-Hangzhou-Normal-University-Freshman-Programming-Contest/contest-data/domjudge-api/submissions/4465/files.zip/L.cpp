#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main() {
	int n;
	cin >> n;
	while (n--) {
		int n, x;
		cin >> n >> x;
		if (x == 0) {
			cout << "no" << endl;
		}
		else {
			cout << "yes" << endl;
		}
	}
}