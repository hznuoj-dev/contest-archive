#include<bits/stdc++.h>
using namespace std;
int t,n,x;

int main(){
	cin >>t;
	while(t--){
		cin >>n >>x;
		if(x==0)cout << "No\n";
		else 
			if(n%x<=1)cout <<"Yes\n";
			else cout << "No\n";
	}
	
return 0;
} 
/*1 1 1 1 1 1/1 1 1 1 1 1
  0   0   0   0*/
