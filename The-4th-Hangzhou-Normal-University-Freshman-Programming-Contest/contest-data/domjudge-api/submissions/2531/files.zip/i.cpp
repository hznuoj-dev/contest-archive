#include<bits/stdc++.h>
using namespace std;
struct ge{
	int b;
	char s[16];
}a[100010];
bool cmp1(ge a,ge b){
	return a.b<b.b;
}
int main(void){
	int n,m,i=0,k,j;
	scanf("%d",&n);
	j=n;
	while(j--){
		scanf("%d",&a[i].b);
		k=0;getchar();
		while((a[i].s[k]=getchar())!='\n'){
			k++;
		}
		a[i].s[k]='\0';
		i++;
	}
	sort(a,a+i,cmp1);
	scanf("%d",&k);
	puts(a[k].s);
	return 0;
}
