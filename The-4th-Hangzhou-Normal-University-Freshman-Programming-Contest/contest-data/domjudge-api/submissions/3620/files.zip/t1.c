#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct song{
		int num;
		char name[16];
		};
int comp(const int*p,const int*q){
	return ((struct song *)q)->num-((struct song *)p)->num;
}
int main(void) {
	int n,k,i;
	scanf("%d",&n);
	struct song s[n];
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].num,s[i].name);
	}
	scanf("%d",&k);
	qsort(s,n,sizeof(struct song),comp);
	printf("%s",s[k].name);	
	return 0;
}
