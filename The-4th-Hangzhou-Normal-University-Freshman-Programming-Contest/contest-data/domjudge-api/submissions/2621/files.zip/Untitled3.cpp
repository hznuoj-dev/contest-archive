#include<stdio.h>
int main(void){
	int t,n,x,i,j;
	scanf("%d",&t);
	while(t>0){
		scanf("%d %d",&n,&x);
		if(x==0)
		printf("no\n");
		else
		printf("yes\n");
		t-=1;
	}
	return 0;
}
