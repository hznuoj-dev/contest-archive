#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
int N, i, j;
fx(long long a[][30], long long temp[][30], int n)
{
	for (i = 0; i <= n/2; i++)
	{
		for (j = i; j < n - i; j++)
			temp[j][n - i - 1] = a[i][j];
		for (j = i; j < n - i; j++)
			temp[j][i] = a[n - i - 1][j];
		for (j = i + 1; j < n - i - 1; j++)
			temp[i][n-j-1] = a[j][i];
		for (j = i + 1; j < n - i - 1; j++)
			temp[n - i - 1][n - j-1] = a[j][n - i - 1];
	}
}
int main()
{
	int n,ans=-1,k,kk=0;
	long long a[30][30], b[30][30], temp[30][30],temp1[30][30],temp2[30][30];
	scanf("%d", &N);
	while (N--)
	{
		kk=k = 0;
		scanf("%d", &n);
		for (i = 0; i < n; i++)
			for (j = 0; j < n; j++)
				scanf("%lld", &a[i][j]);
		for (i = 0; i < n; i++)
			for (j = 0; j < n; j++)
				scanf("%lld", &b[i][j]);

		for (i = 0; i < n; i++)
			for (j = 0; j < n; j++)
			{
				if (a[i][j] != b[i][j])
					k++;
			}
		if (k == 0)
		{
			printf("0\n");
			kk++;
			continue;
		}

		k = 0;
		fx(a, temp, n);
		for (i = 0; i < n; i++)
			for (j = 0; j < n; j++)
			{
				if (temp[i][j] != b[i][j])
					k++;
			}
		if (k == 0)
		{
			printf("1\n");
			kk++;
			continue;
		}

		k = 0;
		fx(temp, temp1, n);
		for (i = 0; i < n; i++)
			for (j = 0; j < n; j++)
			{
				if (temp1[i][j] != b[i][j])
					k++;
			}
		if (k == 0)
		{
			printf("2\n");
			kk++;
			continue;
		}

		k = 0;
		fx(temp1, temp2, n);
		for (i = 0; i < n; i++)
			for (j = 0; j < n; j++)
			{
				if (temp2[i][j] != b[i][j])
					k++;
			}
		if (k == 0)
		{
			printf("1\n");
			kk++;
			continue;
		}
		k = 0;
		if (kk == 0)
			printf("-1\n");
	}
	return 0;
}