#include<stdio.h>
#include<string.h>
int main (){
	int t,i,len;
	char c[1000][31];
	scanf("%d",&t);
	while(t--){
		for(i=0;i>-1;i++){
			getchar();
			memset(c[i],'\0',sizeof(c[i]));
			scanf("%s",c[i]);
			len=strlen(c[i]);
			if(c[i][len-1]=='.'||c[i][len-1]=='!'||c[i][len-1]=='?')break;
		}
		i++;
		c[i][0]=c[i-1][len-1];
		c[i-1][len-1]='\0';
		printf("%s",c[0]);
		for(int k=1;k<(i+1)/2;k++){
			printf(" %s %s",c[i-k],c[k]);
		}
		if((i+1)%2==1)printf(" %s",c[(i+1)/2]);
		printf("%s",c[i]);
		if(t>0)printf("\n");
	}
}
