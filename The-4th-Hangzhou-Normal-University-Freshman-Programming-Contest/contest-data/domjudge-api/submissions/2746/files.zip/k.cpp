#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#define MogeKo qwq

using namespace std;

int n;

int main() {
	scanf("%d",&n);
	while(n--)
		printf("Welcome to HZNU\n"); 
	return 0;
}

