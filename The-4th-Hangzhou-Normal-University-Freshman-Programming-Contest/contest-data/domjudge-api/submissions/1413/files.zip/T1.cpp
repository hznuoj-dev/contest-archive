#include<bits/stdc++.h>

using namespace std;

int T;
int n;
int a[27*2];

int main()
{
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		memset(a,0,sizeof(a));
		char c;
		for(int i=1;i<=n;++i){
			cin>>c;
			if(c<='Z'&&c>='A'){
				a[c-'A'+1]++;
			}if(c<='z'&&c>='a'){
				a[c-'a'+1+26]++;
			}
		}int ans = 0,flag = 0;
		
		for(int i=1;i<=27*2;++i){
			while(a[i]>=2){
				ans+=2;
				a[i]-=2;
			}if(a[i]&&flag==0){
				ans++;
				flag = 1;
			}
		}
		printf("%d\n",ans);
	}
	return 0;
}
