#include<stdio.h>
#include<string.h>
int main()
{
	int t,i,x,y,j,k;
	char a[40010];
	char q;
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		k=0;
		while(scanf("%c",&q)&&q!='\n')
		{
			a[k++]=q;
		}
		a[k]='\0';
		x=0,y=k-1;
		while(x<y)
		{
			for(i=x;i<k-1;i++)
			{
				if(a[i]!=' ')
				{
					printf("%c",a[i]);
				}else{
					x=i+1;
					break;
				}	
			}
			if(x<y)
			{
				printf(" ");
				for(i=y-1;i>=0;i--)
				{
					if(a[i]==' ')
					{
						for(j=i+1;j<y;j++)
						{
							printf("%c",a[j]);
						}
						y=i;
						break;
					}	
				}
				if(y>x)
					printf(" ");
			}
		}
		printf("%c\n",a[k-1]);
		memset(a,0,k);
	}
	return 0;
}
