#include<bits/stdc++.h>
using namespace std;

int main(){
	int n,m,atk,suma=0;
	bool xiaomie=0,muxue=0;
	int card;
	cin>>n>>m;
	for(int i=0;i<n;i++){
		cin>>card;
		if(card==0){
			cin>>atk;
			suma+=atk;
			if(suma>2100){
				xiaomie=1;
			}else if(suma>=0&&m==0){
				xiaomie=1;
			}
		}
		if(card==1){
			muxue=1;
		}
		if(card==2&&n>=2){
			cout<<"haoye";
			return 0;
		}
		if(xiaomie==1&&muxue==1){
			cout<<"haoye";
			return 0;
		}
	}
	cout<<"QAQ";
}
