#include<stdio.h>
int main(){
	int t;
	int a,b;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		if(b==0||a==0){
			printf("no\n");
		}
		else if((a-1)*2%b==0){
			printf("yes\n");
		}
		else{
			printf("no\n");
		}
	}
	return 0;
}
