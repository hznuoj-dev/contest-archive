#include<stdio.h>
int main() {
	int n;
	scanf("%d", &n);
	while (n > 0) {
		printf("Welcome to HZNU\n");
		n--;
	}
	return 0;
}
