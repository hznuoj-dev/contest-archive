#include <stdio.h>
struct point {
	int m;
	char s[100];
};
int main(void){
	struct point a[1000],sw;
	int i,n,k,j;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i].m,a[i].s);
	}
	for(i=0;i<n;i++){
		for(j=n-1;j>i;j--){
			if(a[j].m>a[j-1].m){
				sw=a[j];
				a[j]=a[j-1];
				a[j-1]=sw;
			}
		}
	}
	scanf("%d",&k);
	printf("%s",a[k].s);
	return 0;
} 
