#include<stdio.h>
struct zm
{
	char s1;
	int b;
};
int main()
{
	struct zm a[100000];
	int j,t,k,i,n,sum,x;
	x=0;
	
	scanf("%d",&t);

	for(j=0;j<t;j++)
	{
		i=0;
		scanf("%d",&k);
		getchar();
		while (i<k)
		{
			a[i].s1=getchar();
			getchar();
			a[i].b=1;
			i++;
		}
				sum=0;
		x=0;
		for (i = 0; i < k; i++)
		{
			for ( n = 0; n < k; n++)
			{
				
				if (n<i&&a[i].s1==a[n].s1)
				{
					break;
				}
				if (a[i].s1==a[n].s1&&n>i)
				{
				
					a[i].b=a[i].b+1;
					a[n].b=0;
				}
			}
		}
		for (i= 0;i < k; i++)
		{
			if (a[i].b>=2)
			{
				sum=sum+a[i].b/2;
			}
			if (a[i].b==1&&x==0)
			{
				sum=sum+1;
				x=x+1;
			}
			if (a[i].b>=2&&a[i].b%2==1&&x==0)
			{
				sum=sum+1;
				x=x+1;
			}
		}
		if(x==1)
		printf("%d\n",(sum-1)*2+1);
		if(x==0)
		printf("%d\n",sum*2);
	}

	return 0;
}
