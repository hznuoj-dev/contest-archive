#include<stdio.h>
struct sing {
	int w;
	char name[100];
};
int main() {
	int k, i, n, j;
	struct sing ok[100];
	scanf("%d", &n);
	for (i = 0;i < n;i++) {
		scanf("%d %s", &ok[i].w,ok[i].name);
	}
	for (j = 0;j < n;j++) {
		for (i = 0;i < n - j;i++) {
			if (ok[i].w < ok[i + 1].w) {
				struct sing change;
				change = ok[i];
				ok[i] = ok[i + 1];
				ok[i + 1] = change;
			}
		}
	}
	scanf("%d", &k);
	for (k;k < j;k++) {
		printf("%s\n", ok[k].name);
	}
	return 0;
}
