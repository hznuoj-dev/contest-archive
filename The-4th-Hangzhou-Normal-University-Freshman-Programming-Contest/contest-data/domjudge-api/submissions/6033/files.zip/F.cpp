#include<bits/stdc++.h>
using namespace std;
int a1[25][25],a2[25][25];
int pd(int fx,int m,int x,int y);
int main()
{ int flag,i,j,k,l,n,m;
  cin>>n;
  for (i=1;i<=n;i++)
   { cin>>m;
     flag=0;
     for (j=1;j<=m;j++)
      for (k=1;k<=m;k++)
       cin>>a1[j][k];
     for (j=1;j<=m;j++)
      for (k=1;k<=m;k++)
       cin>>a2[j][k];
     for (j=0;j<=3;j++)
	  if (pd(j,m,1,1)) 
	  { if (j!=3) cout<<j<<"\n"; else cout<<"1"<<"\n"; flag=1; break; }
	if (!flag) cout<<"-1"<<"\n";  
   }
}
int pd(int fx,int m,int x,int y)
{ if (x>m) return 1;
  if (fx==0) 
  { if (a1[x][y]!=a2[x][y]) return 0;
    if (!pd(fx,m,x+y/m,y%m+1)) return 0; else return 1; 
  }
  if (fx==1) 
  { if (a1[x][y]!=a2[y][m-x+1]) return 0;
    if (!pd(fx,m,x+y/m,y%m+1)) return 0; else return 1; 
  }
  if (fx==2) 
  { if (a1[x][y]!=a2[m-x+1][m-y+1]) return 0;
    if (!pd(fx,m,x+y/m,y%m+1)) return 0; else return 1; 
  }
  if (fx==3) 
  { if (a1[x][y]!=a2[m-y+1][x]) return 0;
    if (!pd(fx,m,x+y/m,y%m+1)) return 0; else return 1; 
  }
   
    

}

