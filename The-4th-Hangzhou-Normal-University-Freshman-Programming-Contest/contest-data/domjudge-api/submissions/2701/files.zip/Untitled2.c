#include<stdio.h>
#include<stdlib.h>	
char ch[100000];
int main()
{
	int n,t,i,j,ans;

	scanf("%d",&t);
	while(t--)
	{
 	    scanf("%d",&n);			
		ans=0;
		for(i=0;i<n;i++)
		{
			scanf(" %c",&ch[i]);
			//printf("%c\n",ch[i]);
			for(j=0;j<i;j++)
			{
				if(ch[i]==ch[j]&&ch[j]!='0')
				{
					ch[i]='0';
					ch[j]='0';
					ans+=2;
					break;
				}
			}
		}
		if(n>ans)
		    ans++;
		printf("%d\n",ans);
    }
} 
 
