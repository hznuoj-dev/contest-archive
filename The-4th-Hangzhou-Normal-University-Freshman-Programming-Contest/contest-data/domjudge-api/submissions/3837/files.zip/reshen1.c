#include<stdio.h>
#include<string.h>
int main() {
	int a, b, c;
	char str1[30100], str2[1005][35] = { 0 };
	scanf("%d", &a);
	getchar();
	while (a--) {
		char str2[1005][35] = { 0 };
		gets(str1);
		int x = 0, y, z = 0;
		int f = strlen(str1) - 1;
		while (z < f) {
			y = 0;
			for (b = z; str1[b] != ' '; b++) {
				str2[x][y] = str1[b];
				y++;
				if (b == f - 1)
					break;
			}
			x++;
			z = b + 1;
		}
		int t = 0, h = x-1, g = x;
		if (x % 2 == 0) {
			while (g > 0) {
				printf("%s ", str2[t]);
				printf("%s", str2[h]);
				if (g != 2)
					printf(" ");
				t++;
				h--;
				g -= 2;
			}
			printf("%c\n", str1[strlen(str1) - 1]);
		}
		else {
			while (g > 1) {
				printf("%s ", str2[t]);
				printf("%s ", str2[h]);
				t++;
				h--;
				g -= 2;
			}
			int u = x / 2;
			printf("%s", str2[u]);
			printf("%c\n", str1[strlen(str1) - 1]);
		}
	}
	return 0;
}
