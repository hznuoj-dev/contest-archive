#include<stdio.h>
struct ge{
	long long int a;
	char x[99999];
}m[100000];
int main(void){
	 long long int n;
	scanf("%lld",&n);
	int i,j;
	for(i=0;i<n;i++){
		scanf("%lld %s",&m[i].a ,m[i].x );
	}
	struct ge q;
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1-i;j++){
			if(m[j].a <m[j+1].a ){
				q=m[j];
				m[j]=m[j+1];
				m[j+1]=q;
			}
		}
		
	}
	long long int k;
	scanf("%lld",&k);
	printf("%s\n",m[k].x );
	return 0;
}

