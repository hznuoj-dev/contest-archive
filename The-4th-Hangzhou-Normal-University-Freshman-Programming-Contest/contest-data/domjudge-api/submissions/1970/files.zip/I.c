#include<stdio.h>
int main()
{
	int t;
	long long a, b;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%lld%lld", &a, &b);
		if (b != 0)
		{
			printf("yes\n");
		}
		else
		{
			printf("no\n");
		}
	}
	return 0;
}