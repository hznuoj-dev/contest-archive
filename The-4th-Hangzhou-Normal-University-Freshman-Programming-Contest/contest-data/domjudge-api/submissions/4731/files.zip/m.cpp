#include<stdio.h>
char a[1000][31],fu[1000];
int main(void){
	int t,i,j,k,tr,tr1;
	scanf("%d",&t);
	while(t--){
		getchar();
		j=0,tr1=0;
		while((a[0][j]=getchar())!=' '){
			if(a[0][j]=='.'||a[0][j]=='!'||a[0][j]=='?'){
				tr1=1,fu[0]=a[0][j],tr=1;
				break;
			}
			j++;
		}
		a[0][j]='\0';
		for(i=1;i<1000&&tr1==0;i++){
			j=0,tr=0;
			while((a[i][j]=getchar())!=' '){
				if(a[i][j]=='.'||a[i][j]=='!'||a[i][j]=='?'){
					fu[i]=a[i][j],tr=1;
					break;
				}
				j++;
			}
			a[i][j]='\0';
			if(tr)break;
		}
		printf("%s",a[0]);
		for(k=1;k<=i/2;k++){
			printf(" %s %s",a[i-k+1],a[k]);
		}if((i&1)&&tr1==0)printf(" %s",a[k]);
		if(tr1)printf("%c\n",fu[0]);
		else printf("%c\n",fu[i]);
	}
	return 0;
}
