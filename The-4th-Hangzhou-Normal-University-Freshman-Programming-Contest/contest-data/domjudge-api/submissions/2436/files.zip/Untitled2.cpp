#include<stdio.h>
int main(void)
{
	int T;
	int n;
	scanf("%d",&T);
	while(T--)
	{
		int h=0;
		scanf("%d",&n);
		int a[100001];
		for(int i=0 ; i<n ;i++)
		{
			scanf("%d",&a[i]);
		}
		
		for(int i=0 ; i<n ;i++)
		{
			int *p=&a[i]; 
			int sum=0;
			while(p != &a[n+1])
			{
				sum+=*p;
				p++;
				if(sum == 7777)
				{
					h++;
					break;
				}else if(sum >7777)
				{
					break;
				}
			}
			
		}
		printf("%d\n",h);
	}
	return 0;
 } 
