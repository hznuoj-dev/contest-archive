#include <cstdio>
#include <algorithm>
#include <set>
#include <cstring>
#include <cstdio>
#include <vector>
#include <queue>
#include <climits>
#include <stack>
#include <map>
#include <cmath>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include<time.h>
#define tententen tql666
#define PI acos(-1) 
typedef long long int ll; 
using namespace std;
int main(){
	int t,x,n,k;
	char s;
	cin>>t;
	while(t--){
 	  	cin>>n;
 	  	map<char,int>mymap;
 	  	x=0;
 	  	for (int i = 1; i <= n; i++) {
			cin >> s;
			auto iter = mymap.find(s);
	        if (iter== mymap.end()) 
	                mymap[s] = 1;
	        else
					mymap[s]=mymap[s]+1;
		}
		int flag=0;
 	    for (auto it = mymap.begin(); it != mymap.end(); it++) {
			 if(it->second%2==1){
			 	flag=1;
			 }
			 x+=it->second/2*2;
		}
		x=x+flag;
 	  	cout<<x<<endl;
 }
	return 0;
}
