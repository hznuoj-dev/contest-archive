#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<cmath>
#include<cctype>
using namespace std;
int main(){
	int t;
	cin>>t;
	while(t--){
		map<char,long int>ss;
		map<char,long int>::iterator pos;
		long int n,i;
		cin>>n;
		getchar();
		char c;
		for(i=0;i<n;i++){
			cin>>c;
			pos=ss.find(c);
			if(pos!=ss.end()){
				pos->second++;
			}
			else{ 
			ss.insert(make_pair(c,1));
			}
		}
		long int sum=0;int js=0;
	
		for(pos=ss.begin();pos!=ss.end();pos++){
			if((pos->second)%2!=0)
			{js=1;break;
			}
	
		}
	
		
		for(pos=ss.begin();pos!=ss.end();pos++){
			sum+=(pos->second/2)*2;
		}
	
		
		if(js==1)sum++;
		cout<<sum<<endl;
	}
}
