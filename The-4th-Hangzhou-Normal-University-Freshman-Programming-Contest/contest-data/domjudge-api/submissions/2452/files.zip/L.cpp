#include<bits/stdc++.h>
using namespace std;
int main(){
	long long n,i,k,l;
	cin>>n;
	for(i=1;i<=n;i++){
		cin>>k>>l;
		if(l==0){
			cout<<"no"<<"\n";
		}else{
			cout<<"yes"<<"\n";
		}
	}
	return 0;
}
