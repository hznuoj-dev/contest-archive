#include<stdio.h>
int main (){
	int T;
	scanf_s("%d",&T);
	while(T--){
		int N,t;
		int a[20][20],b[20][20],c[20][20],d[20][20],e[20][20];
		scanf_s("%d",&N);
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				scanf("%d",&a[i][j]);
			}
		}
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				scanf("%d",&b[i][j]);
			}
		}
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				c[i][j]=a[j][N-i-1];
			}
		}	
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				d[i][j]=c[j][N-i-1];
			}
		}
		for(int i=0;i<N;i++){
			for(int j=0;j<N;j++){
				d[i][j]=e[j][N-i-1];
			}
		}
		int n=1,m=1,mm=1;
		for(int i=0;i<N;i++){
			for(int j=0;j<=i;j++){
				if(c[i][j]!=b[i][j]){
					n=0;
					break;
				}
			}
		}
		if(n==1){
			printf("1\n");
			T--;
		}
		for(int i=0;i<N;i++){
			for(int j=0;j<=i;j++){
				if(e[i][j]!=b[i][j]){
					mm=0;
					break;
				}
			}
		}
		if(mm==1){
			printf("1\n");
			T--;
		}
		for(int i=0;i<N;i++){
			for(int j=0;j<=i;j++){
				if(d[i][j]!=b[i][j]){
					m=0;
					break;
				}
			}
		}
		if(m==1){
			printf("2\n");
			T--;
		}
		else printf("-1\n");
	}
}