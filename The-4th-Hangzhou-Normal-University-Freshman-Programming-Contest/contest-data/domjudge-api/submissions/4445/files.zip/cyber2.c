#include<stdio.h>
#include<string.h>
int main(){
int n,biao,atk,pai,goal,f,deng1,deng2,i,muzhi;
scanf("%d %d",&n,&biao);
deng1=0;
deng2=0;
muzhi=0;
if(biao==0)
goal=2500;
else
goal=2100;
i=n;
while(i--){
scanf("%d",&pai);
if(pai==0)
{
	scanf("%d",&atk);
	if(biao==0&&atk>=goal)
	deng1=1;
	if(biao==1&&atk>goal)
	deng1=1;
}
else if(pai==1)
muzhi=1;
else if(pai==2)
deng2=1;
}
if(deng2==1&&n>1||deng1==1&&muzhi==1)
printf("haoye\n");
else
printf("QAQ\n");
return 0;
} 
