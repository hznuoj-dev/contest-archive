#include<stdio.h>
#include<string.h>
char c[100000];
int main(){
	int t,m,n,i,j,x,y;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%c",&c[i]);
		}
		m=0;
		x=0;
		y=0;
		for(i=0;i<n;i++){
			x=(int)c[i];
			for(j=i+1;j<n;j++){
				y=(int)c[j];
				if(x==y){
				m=m+1;
				break;
		}
			}
		}
		if(2*m+1>n)
		printf("%d\n",n);
		else
		printf("%d\n",2*m+1);
	}
	} 
