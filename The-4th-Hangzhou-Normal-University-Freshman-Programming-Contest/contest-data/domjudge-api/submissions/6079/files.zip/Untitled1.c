#include<stdio.h>

int main()
{
	int t,a[100000],i,b,sum,n,d;
	d=0;
	sum=0;
	scanf("%d",&t);
	while (t--)
	{
		scanf("%d",&b);
		i=0;
		while (i<b)
		{
			scanf("%d",&a[i]);
			i++;
		}
		for ( i = 0; i < b; i++)
		{
				for (n = i; n < b; n++)
				{
					sum=sum+a[n];
					if (sum>7777)
					{
						sum=0;
						break;
					}
					if (sum==7777)
					{
						d=d+1;
						sum=0;
						break;
					}
				}
		}
		printf("%d\n",d);
		d=0;
	}
	
	system("pause");
	return 0;
}
