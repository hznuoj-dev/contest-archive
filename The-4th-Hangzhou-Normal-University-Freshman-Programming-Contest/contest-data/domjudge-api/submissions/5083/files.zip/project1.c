#include<stdio.h>
struct sing{
	int w;
	char s[16];
}stff[100001];
int main(void)
{
	struct sing temp;
	long long int n,i,j,k,m,t;
	scanf("%lld",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&stff[i].w,stff[i].s);
	}
	scanf("%lld",&t);
	for(j=0;j<n;j++){
        if(stff[j].w<stff[j+1].w){
        temp=stff[j];
        stff[j]=stff[j+1];
        stff[j+1]=temp;
        }
        if(j==n-1){
            i=-1;
            n--;
        }
    }
	printf("%s\n",stff[t].s);
    return 0;
}

