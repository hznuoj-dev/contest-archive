#include<stdio.h>
#include<stdlib.h>
int cmp(const void*a,const void*b);
void S(char*a,char*b);
struct t{
	int n;
    char s[31];
};
struct t ta[1000];
int i=0;
int main(){
	int t;int j=0;
	scanf("%d",&t);
	getchar();
	while(t--){
		int u,v;
		for(u=0;u<1000;u++){
			ta[u].n=1001;
			for(v=0;v<31;v++)
			ta[u].s[v]=NULL;
		}
		i=0;
		fflush(stdin);
		char str[31000];
		fgets(str,3100,stdin); 
		char* start=str;
		char* end=str;
		while(*end!='.' &&*end!='!' &&*end!='?'){
			if(*end==' '){
			S(start,end-1);
			i++;
			end++;
			start=end;
		}
		else end++;
		}
		S(start,end-1);
		i++;
		char c=*end;
		if(i%2==0){
		for(j=0;j<i/2;j++){
			ta[j].n=(j+1)*2-1;
		}	
		for(j=i/2;j<i;j++){
			ta[j].n=(i-j)*2;
		}
		}
		else{
			for(j=0;j<(i+1)/2;j++){
				ta[j].n=(j+1)*2-1;
			}
			for(j=(i+1)/2;j<i;j++){
				ta[j].n=(i-j)*2;
			}
		}
	
		qsort(ta,1000,sizeof(struct t),cmp);
		int z;
		for( z=0;z<i-1;z++){
			
			printf("%s ",ta[z].s);
		}
		printf("%s",ta[i-1].s);
		printf("%c",c);
		printf("\n");
}
}
void S(char*a,char*b){
	int j=0;
	for(a;a<=b;a++){
		ta[i].s[j]=*a;
		j++;
	}
	ta[i].s[j]='\0';
}
int cmp(const void*a,const void*b){
	struct t *p1=(struct t*)a;
	struct t *p2=(struct t*)b;
	return p1->n-p2->n;
}
