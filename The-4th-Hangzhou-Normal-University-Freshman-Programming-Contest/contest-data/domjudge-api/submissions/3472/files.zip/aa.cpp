#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#include<algorithm>
#define pzc 666
using namespace std;
int a[100010];
int main()
{
	int t,n,d,ai,i,j,sum;
	cin>>t;
	while(t--)
	{
		memset(a,0,sizeof(a));
		cin>>n;d=0;sum=0;i=0;j=0;
		while(j<n)
			scanf("%d",&a[j++]);
		j=0;
		while(i<n&&j<n)
		{
			sum+=a[j];j++;
			while(sum>7777)
			{
				sum-=a[i];
				i++;
			}
			if (sum==7777)
				d++;
		}
		while(sum>7777)
		{
			sum-=a[i];i++;
			if(sum==7777) d++;
		}	
		cout<<d<<endl;
	}
}
