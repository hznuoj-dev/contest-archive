#include<stdio.h>
int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int n, w = 1, num = 0;
		int num1;
		int i, j;
		char a[100000];
		scanf("%d", &n);
		getchar();
		for (i = 0; i < n; i++) {
			scanf("%c", &a[i]);
			getchar();
		}
		for (i = 0; i < n - 1; i++) {
			for (j = i+1; j < n; j++) {
				if (a[i] == a[j]) {
					w = 0;
				}
			}
			if (w == 1) {
				num++;
			}
		}
		num1 = n - num;
		if (num == n) {
			printf("1\n");
		}
		else if (num1 % 2 == 0&&num==0) {
			printf("%d\n", num1);
		}
		else if(num1%2==0&&num!=0){
			printf("%d",num1+1);
		}
		else printf("%d\n", num1);
	}
}
