#include<stdio.h>
#include<math.h>
int main(){
	int t,n,m;
	long long int s;
	scanf("%d",&t);
	while(t--){
		 scanf("%d%d",&n,&m);
		if(m!=0)
		    printf("yes\n");
		else
		    printf("no\n");
	} 
	return 0;
}
