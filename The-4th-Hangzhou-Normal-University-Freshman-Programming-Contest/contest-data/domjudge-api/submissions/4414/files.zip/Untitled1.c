#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int comp(const void *p,const void *q){
	return strcmp(p,q);
}
int main(){
	int t,i,j=0,n,sum=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		getchar();
		int a[30]={0};
//		for(i=0;i<n;i++)a[i]=0;
		char c[n];
		for(i=0;i<n;i++){
			scanf("%c",&c[i]);
			if(c[i]==' '){
				scanf("%c",&c[i]);
			}
		}
		getchar();
		
		qsort(c,n,sizeof(char),comp);
//		for(i=0;i<n;i++)printf("%c ",c[i]);
		for(i=0;i<n-1;i++){
			if(c[i]==c[i+1]){
				a[j]++;
			}else{
				j++;
			}
		}
		
		for(i=0;i<=j;i++)a[i]++;
//		for(i=0;i<=j;i++)printf("%d ",a[i]);
		for(i=0;i<=j;i++){
			if(a[i]%2==0){
				sum+=a[i];
			}else{
				sum+=a[i]-1;
			}
		}
        printf("%d",sum+1);
		sum=0;
		j=0;
		
		
		if(t){
			printf("\n");
		}
	}
	return 0;
}
