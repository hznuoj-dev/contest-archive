#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int f(int aa[21][21],int bb[21][21],int n);
int main (){
	int t=0,n=0,a=0;
	int i=0,j=0;
	int aa[21][21]={0};
	int bb[21][21]={0};
	int cc[21][21]={0};
	scanf("%d",&t);
	while(t--){
		a=0;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&aa[i][j]);
			}
		}
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&bb[i][j]);
			}
		}
		while(a<4){
			if(f(aa,bb,n)){
				for(i=0;i<n;i++){
					for(j=0;j<n;j++){
						cc[j][n-1-i]=aa[i][j];
					}
				}
				for(i=0;i<n;i++){
					for(j=0;j<n;j++){
						aa[i][j]=cc[i][j];
					}
				}
				a++;
			} else {
				break;
			}
		}
		if(a==4){
			printf("-1\n");
		} else{
			if(a>2){
				printf("%d\n",4-a);
			} else {
				printf("%d\n",a);
			}
		}
	}
	return 0;
}
int f(int aa[21][21],int bb[21][21],int n){
	int x=0,y=0;
	for(x=0;x<n;x++){
		for(y=0;y<n;y++){
			if(aa[x][y]!=bb[x][y]){
				return 1;
				break;
			}
		}
	}
	return 0;
}
