#include <stdio.h>
int main(void)
{
    long long d[200]={0};
    char ch;
    long long  a,b;
    scanf("%lld",&a);
    while(a--){
    	for(int i=0;i<200;i++){
    		d[i]=0;
		}
    	long long sum = 0;
    	scanf("%lld",&b);
    	for(long long i=0;i<b;i++){
    		scanf(" %c",&ch);
    		long long n = ch;
		    d[n]++;
		}
		for(long long i=20;i<=200;i++){
			if(d[i]>0){
				long long t=d[i]/2;
				sum+=t;
			}
		}
		if(b==2*sum) printf("%lld\n",2*sum);
		else printf("%lld\n",2*sum+1);
		
		
	}
	return 0;
}