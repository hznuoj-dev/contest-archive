/*#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int a[100005];
int main()
{
    int t;
    int sum;
    int flag=0;
    int i,j;
    int n;
    scanf("%d",&t);
    while(t--){
    	flag=0;
    	scanf("%d",&n);
    	for(i=0;i<n;i++){
    		scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			sum=a[i];
			if(sum==7777){
				flag++;
			}
			else{
				for(j=i+1;j<n;j++){
					sum+=a[j];
					if(sum==7777){
					    flag++;
					    break;
					}
					else if(sum>7777)
					    break;
				}
			}
				
				
	   }
	   	
		printf("%d\n",flag);
	}
	return 0;
}*/
/*#include<stdio.h>
#include<stdlib.h>
struct cao{
	int love;
	char name[20];
}a[100005],temp;
int cmp(const void *p,const void *q){
	return (int*)((((struct cao*)q)->love)-(((struct cao*)p)->love));
}
int main()
{
	int n;
	int k;
	int i,j;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i].love,&a[i].name);
	}
	scanf("%d",&k);
    qsort(a,n*sizeof(struct cao),n,cmp);
    printf("%s\n",a[0].name);
    printf("%s\n",a[1].name);
    printf("%s\n",a[2].name);
	printf("%s",a[k].name);
	return 0;
}*/
#include<stdio.h>
#include<string.h>
char a[50000],b[50000];
int main()
{
	int t;
	int flag=0;//��� 
	int i,j,l,r,x,y;
	int danci=0;
	int len;
	scanf("%d",&t);
	getchar();
	while(t--){
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		flag=0;
		danci=1;
		gets(a);
		len=strlen(a); 
		l=0;r=len-2;
		while(l<=r){
			if(danci%2==1){
				i=l;
				while(a[i]!=' '){
					i++;
				}
				x=i-1;
				for(i=l;i<=x;i++){
					b[flag]=a[i];
					flag++;
				}
				b[flag]=' ';
				flag++;
				l=x+2;
				danci++; 
			}
			else{
				i=r;
				while(a[i]!=' '){
					i--;
				}
				x=i+1;
				for(i=x;i<=r;i++){
					b[flag]=a[i];
					flag++;
				}
				b[flag]=' ';
				flag++;
				r=x-2;
				danci++; 
			}
		}
		b[flag-1]=a[strlen(a)-1];
		printf("%s\n",b);
		
	}
 } 
