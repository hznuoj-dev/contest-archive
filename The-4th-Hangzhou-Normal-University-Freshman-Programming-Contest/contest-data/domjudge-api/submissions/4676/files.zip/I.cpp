#include<stdio.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
struct like
{
	char s[16];
	int w;
};
int main()
{
	int n;
	int k;
	scanf("%d",&n);
	like a[n];
	for(int i=0;i<n;i++)
	{
		scanf("%d%s",&a[i].w,a[i].s);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(struct like),comp);
	printf("%s",a[k].s);
	return 0;
}
int comp(const void *p,const void *q)
{
	return ((struct like*)q)->w-((struct like*)p)->w;
}
