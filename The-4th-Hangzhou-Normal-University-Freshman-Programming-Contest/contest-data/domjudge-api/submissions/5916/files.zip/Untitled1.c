#include <stdio.h>
#include <string.h>
int main(){
	int n,k,t,max,i,j;
	int a[100010];
	char name[100010][16];
	char d[16];
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d%s",&a[i],name[i]);
	}
	scanf("%d",&k);
	for(i=1;i<=k+1;i++){
		max=i;
		for(j=i+1;j<=n;j++){
			if(a[j]>a[max])
				max=j;
		}
		if(max!=i){
			t=a[i];
			a[i]=a[max];
			a[max]=t;
			strcpy(d,name[i]);
			strcpy(name[i],name[max]);
			strcpy(name[max],d);
		}
	}
	printf("%s",name[k+1]);
	return 0;
}
