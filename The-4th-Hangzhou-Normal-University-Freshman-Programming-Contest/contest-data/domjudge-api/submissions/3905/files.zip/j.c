#include<stdio.h>
int main(){
	int n,m;
	scanf("%d%d",&n,&m);
	int i,x[10],flag=0;
	for(i=0;i<n;i++){
	
		scanf("%d",&x[i]);
		if(x[i]==0){
			int k;
			scanf("%d",&k);
			if(k>=2500&&m==0) flag=1;
			if(k>2100&&m==1) flag=1;
		}
	}
		for(i=0;i<n;i++){
			if(flag==1&x[i]==1) flag=2;
		}
		for(i=0;i<n;i++){
			if(x[i]==2&&n>=2) flag=2;
		}
		if(flag==2) printf("haoye\n");
		else printf("QAQ\n");
	return 0;
} 
