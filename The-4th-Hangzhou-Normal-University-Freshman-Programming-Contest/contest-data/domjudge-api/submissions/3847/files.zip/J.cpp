#include <bits/stdc++.h>
using namespace std;

int a[11];
int b[11];
int c[3];

int main()
{
	int m,n;
	int i,j;
	int heihe=0,muxue=0;
	int flag=0;
	
	cin >> n >> m;
	for(i=1;i<=n;i++)
	{
		cin >> a[i];
		c[a[i]]++;
		if(a[i]==0)	cin >> b[i];
		else if(a[i]==1)	muxue=1;
		else heihe=1;
	}
	if(heihe)
	{
		cout << "haoye";
		return 0;
	}
	else
	{
		if(!muxue)
		{
			cout << "QAQ";
			return 0;
		}
		for(i=1;i<=n;i++)
		{
			if(a[i]==0)
			{
				if(m)
				{
					if(b[i]>2100)
						flag=1;
				}
				else
					if(b[i]>=2500)
						flag=1;
			}
			if(flag)
			{
				cout << "haoye";
				return 0;
			}
		}
	}
}
