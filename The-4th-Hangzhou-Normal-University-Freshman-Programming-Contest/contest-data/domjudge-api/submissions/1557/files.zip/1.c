#include<stdio.h>
#include<string.h>
#include<process.h>
int main()
{
	void print_zimu();
	int n,i;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		 print_zimu();
	}
	system("pause");
	return 0;
}
void print_zimu()
{
	printf("Welcome to HZNU\n"); 
}