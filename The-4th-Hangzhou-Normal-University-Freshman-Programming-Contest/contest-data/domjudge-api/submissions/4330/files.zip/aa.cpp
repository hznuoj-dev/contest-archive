#include<stdio.h>
#include<string.h>
int main() {
	int T;
	int n;
	char c[10000];
	scanf("%d",&T);
	for(int i=1; i<=T; i++) {
	    int a[130]= {0};
		int sum=0;
		scanf("%d",&n);
		getchar();
		scanf("%[^\n]",c);
		char *p=c;
		for(int j=0; j<strlen(c); j++) {
			if(*p!=' '&&*p!='\0') {
				a[*p]=a[*p]+1;
				if(a[*p]>=2) {
					sum=sum+2;
					a[*p]=a[*p]-2;
				}
			}
			p++;
		}
		 if(sum==0){
		 	sum=sum+1;
		 }
		 else if(sum>0&&n%2==1){
		 	sum=sum+1;
		 }
		printf("%d\n",sum);
		
	}
	return 0;
}
