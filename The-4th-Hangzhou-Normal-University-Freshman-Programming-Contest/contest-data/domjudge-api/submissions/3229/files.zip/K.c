#include<stdio.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		printf("Welcome to HZNU\n");
	}
	return 0;
}
