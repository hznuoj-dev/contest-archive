#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct music{
	long long xh;
	char name[20];
};
int main(void)
{
	struct music musicArray[110000];
	char str2[20];
	int n;
    long long i,j,k,t;

	scanf("%d",&n);
	
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&musicArray[i].xh,musicArray[i].name);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(musicArray[j].xh<musicArray[j+1].xh)
			{
				
				strcpy(str2,musicArray[j].name);
				strcpy(musicArray[j].name,musicArray[j+1].name);
				strcpy(musicArray[j+1].name,str2);
			}
		}
	}
	scanf("lld",&k); 
	printf("%s\n",musicArray[k+1].name);	
}
