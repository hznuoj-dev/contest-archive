#include<stdio.h>
#include<math.h>
#include<ctype.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int n,m,i,atk,form;
	int a[3]={0};
	scanf("%d%d",&n,&m);
	if(m==0)
	{
		int max = 0;
		for(i=0;i<n;++i)
		{
			scanf("%d",&form);
			if(form==0)
			{
				scanf("%d",&atk);
				if(atk>max) max = atk;
			}
			else a[form]++;
		}
		if(max>=2500&&a[1]) printf("haoye");
		else if(a[2] && n>=2) printf("haoye");
		else printf("QAQ");
	}
	else
	{
		int max = 0;
		for(i=0;i<n;++i)
		{
			scanf("%d",&form);
			if(form==0)
			{
				scanf("%d",&atk);
				if(atk>max) max = atk;
			}
			else a[form]++;
		}
		if(max>2100&&a[1]) printf("haoye");
		else if(a[2] && n>=2) printf("haoye");
		else printf("QAQ");
	}
} 
