#include<bits/stdc++.h>
using namespace std;
int a[100010];
int main()
{  int sum=0,ans=0,i,j,k,n,m,l,r;
   cin>>n;
   for (i=1;i<=n;i++)
   {  cin>>m;
      for (i=1;i<=m;i++)
      { l=1;
        cin>>a[i];
        sum+=a[i];
        while (sum>=7777)
        {if (sum==7777) ans++;
         sum-=a[l];
         l++;
        }
      }
      cout<<ans<<"\n";
   }
  
   

 
} 
