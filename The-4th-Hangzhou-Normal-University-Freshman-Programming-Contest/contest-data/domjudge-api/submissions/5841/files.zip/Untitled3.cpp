#include <stdio.h>
int main(void)
{
    int d[200]={0};
    char ch;
    int a,b;
    scanf("%d",&a);
    while(a--){
    	int sum = 0;
    	scanf("%d",&b);
    	for(int i=0;i<b;i++){
    		scanf(" %c",&ch);
    		int n = ch;
		    d[n]++;
		}
		for(int i=20;i<=200;i++){
			if(d[i]>0){
				int t=d[i]/2;
				sum+=t;
			}
		}
		if(b==2*sum) printf("%d\n",2*sum);
		else printf("%d\n",2*sum+1);
		
		
	}
	return 0;
}