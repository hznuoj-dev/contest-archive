#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct a {
  long long x;
  char nam[16]; 
};
int inc (const void * a,const void *b){
return * (int * )b-* (int *)a;
}
int main(){
  int t,n;

  scanf("%d",&n);
  struct a mus[n];
  long long z[n];
  for(int i=0;i<n;i++){
     scanf("%lld %s",&mus[i].x,mus[i].nam);
     z[i]=mus[i].x ;
     }
  scanf("%d",&t);
  qsort(z,n,sizeof(mus[0].x),inc);
  for(int i=0;i<n;i++){
    if(z[t]==mus[i].x)
    printf("%s\n",mus[i].nam);  
  } 
  return 0;
}
