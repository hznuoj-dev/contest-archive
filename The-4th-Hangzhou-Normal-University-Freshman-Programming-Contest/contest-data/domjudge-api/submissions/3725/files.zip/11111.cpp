#include<stdio.h>
#include<string.h>
int main()
{
	int t,n[100000],m[1000],q,k,i;
	char z[2],a[1000000];
	scanf("%d",&t);
//	gets(z);
	for(int i=0;i<t;i++)
	{
		scanf("%d %s",&n[i],&a[15*i]);
	}
	scanf("%d",&k);
	for(int i=0;i<t;i++)
	{
		m[i]=n[i];
	}
	for(i=0;i<t;i++)
	{
		q=n[0];
		if(n[i]<n[i+1])
		{
			q=n[i+1];
			n[i+1]=n[i];
			n[i]=q;
		}
	}
	for(i=0;i<t;i++)
	{
		if(n[k]==m[i])
		{
			q=i;
			break;
		}
	}	
	int b=i*15;
	for(i=b;i<b+15;i++)
	{
		if(a[i]==' ')
		break;
		printf("%c",a[i]);
		
	}
	
		
	
		
}
