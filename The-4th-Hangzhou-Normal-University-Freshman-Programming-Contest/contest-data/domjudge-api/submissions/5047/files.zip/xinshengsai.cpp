#include <stdio.h>
#include <string.h>
struct student{
	int n;
	char str[20];
};
int main()
{
	int n;
	scanf("%d",&n);
	struct student a[n];
	for(int i=0;i<n;i++){
		scanf("%d %s",&a[i].n,a[i].str);
	}
	int k;
	scanf("%d",&k);
	int temp,exchange;
	char str1[20];
	for(int i=0;i<n-1;i++){
		exchange=0;
		for(int j=0;j<n-i-1;j++){
			if(a[j].n<a[j+1].n){
				temp=a[j].n;
				a[j].n=a[j+1].n;
				a[j+1].n=temp;
				exchange=1;
				strcpy(str1,a[j].str);
				strcpy(a[j].str,a[j+1].str);
				strcpy(a[j+1].str,str1);
			}
		}
	}
	for(int i=0;i<n;i++)
	{
		if(k!=0) k--;
		else printf("%s\n",a[i].str);
		
	}

	return 0;
}
