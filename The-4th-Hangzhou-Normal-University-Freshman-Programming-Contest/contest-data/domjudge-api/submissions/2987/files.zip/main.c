#include <stdio.h>
int main(){
    int n,a,b,flag;
    scanf("%d",&n);
    for (int i=0; i<n; i++) {
        flag=0;
        scanf("%d%d",&a,&b);
        if (a==0||b==0){
            printf("yes\n");
            continue;}
        else{
            for (int i=1; i<500; i++) {
                if (i*b%a==0) {
                    printf("yes\n");
                    flag++;
                    break;
                }
            }
        }
        if (flag==0)
            printf("no\n");
    }
}
