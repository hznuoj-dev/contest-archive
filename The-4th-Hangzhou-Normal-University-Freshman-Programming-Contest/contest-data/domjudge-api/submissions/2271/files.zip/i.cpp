#include<bits/stdc++.h>
using namespace std;
struct ge{
	int b;
	string s;
}a[100010];
bool cmp1(ge a,ge b){
	return a.b>b.b;
}
int main(void){
	int n,m,i=0,k,j;
	string s;
	scanf("%d",&n);
	j=n;
	while(j--){
		scanf("%d%s",&a[i].b,&a[i].s);
		i++;
	}
	sort(a,a+n,cmp1);
	scanf("%d",&k);
	cout<<a[k+1].s;
	return 0;
}
