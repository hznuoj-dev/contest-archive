#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
const int maxn=100010;
int a[maxn];
struct ge{
	int x;
	string name;
};
bool operator<(ge a, ge b){
	return a.x>b.x;
}
int main(){
	int n;
	cin>>n;
	ge vec[maxn];
	for(int i=0;i<n;++i){
		cin>>vec[i].x>>vec[i].name;
	}
	int k;
	cin>>k;
	sort(vec,vec+n);
	cout<<vec[k].name;
	return 0;
}
 
