#include<stdio.h>
main()
{
	int t, n, x;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d%d", &n, &x);
		if (x != 0)
			printf("yes\n");
		else
			printf("no\n");
	}
}
/*#include<stdio.h>
#include<string.h>
#define Long_size 10000
main()
{
	int T, n, i;
	char c[Long_size],m;
	scanf("%d", &T);
	while (T--)
	{
		int k = 1, x = 0, sum1 = 0, sum2 = 1, same_number[100] = {0}, y = 0;
		for (i = 0; i < 100; i++)
			same_number[i] = 1;
		scanf("%d", &n);
		getchar();
		for (i = 0; i < n; i++)
		{
			scanf("%c", &c[i]);
			getchar();
		}
		for (i = 1; i < n; i++)
		{
			if (c[i] == c[0])
			{
				same_number[x]++;
				m = c[i];
				c[i] = c[k];
				c[k] = m;
				k++;
			}
 		}
		sum1 += same_number[x];
		x++;
		y = k;
		while (sum1 != n)
		{
			for (i = k + 1; i < n; i++)
			{
				if (c[i] == c[y])
				{
					same_number[x]++;
					m = c[i];
					c[i] = c[k];
					c[k] = m;
					k++;
				}
			}
			sum1 += same_number[x];
			x++;
			y = k;
		}
		for (i = 0; i < x; i++)
			sum2 += same_number[x] / 2*2;
		printf("%d\n", sum2);
	}
}*/
