#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
int main()
{
	int n,m,A;
	int y=0, z=0,x1=0,x2=0;
	int a[11]={0};
	int b[11]={0};
	scanf("%d %d", &n, &m);
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
		if (a[i] == 0) {
			scanf("%d", &b[i]);
			if (b[i] >= 2500) {
				x1 = 1;
			}
			if (b[i] > 2100)
			{
				x2 = 1;
			}
		}
		if (a[i] == 1) {
			y = 1;
		}
		if (a[i] == 2) {
			z = 1;
		}
	}
	if (z == 1 && n > 1) {
		printf("haoye");
	}
	else if (y&&x1)
	{
		printf("haoye");
	}
	else if (y&&m&&x2)
	{
		printf("haoye");
	}
	else
	{
		printf("��QAQ");
	}
}
