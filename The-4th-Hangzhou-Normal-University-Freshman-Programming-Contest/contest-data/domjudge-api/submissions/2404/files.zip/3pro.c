#include<stdio.h>
int main() {
	int t,n,i,j;
	int c[5000],a[5000];
	int temp,count=0;
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &n);
		for (i = 0; i < n; i++) {
			scanf("%d", &c[i]);
		}
		for (i = 0; i < n; i++) {
			for (j = n - 1; j > i; j--) {
				if (c[j] <= c[j - 1]) {
					temp = c[j];
					c[j] = c[j - 1];
					c[j - 1] = temp;
					a[i] = c[i];
				}
			}
		}
		for (j = 0; j < n; j++) {
			for (i = j; i < n; i++) {
				if (c[i] < 7777) {
					c[i + 1] = c[i] + c[i + 1];
				}
				if (c[i + 1] == 7777) {
					count++;
					c[i + 1] = c[i + 1] - a[i + 1];
				}
			}
			printf("%d\n", count);
		}
	}
	return 0;
}





