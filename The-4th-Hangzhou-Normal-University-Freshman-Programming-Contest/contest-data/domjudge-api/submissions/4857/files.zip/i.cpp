#include<stdio.h>
#include<string.h>
int main(){
	int n,z;
	/*char s1[16];*/
	char s[1000][16];
	long long w[1000],t;
	int k;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%lld%s",&w[i],s[i]);
	}
	scanf("%d",&k);
	for (int i=1;i<n;i++){
	z=1;
		for (int j=1;j<n-i+1;j++){
			if (w[j]<w[j+1]){
				t=w[j];
				w[j]=w[j+1];
				w[j+1]=t;
			
				z=0;
			}
		}
		if(z==1){
			break;
		}
	}
    printf("%s",s[k+1]);
    return 0;
}
