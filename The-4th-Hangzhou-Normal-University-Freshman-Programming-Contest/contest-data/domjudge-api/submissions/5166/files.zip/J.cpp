#include <stdio.h>
int main()
{
	int n, m,i,  k;
	int a[4];
	int flag=0;
	scanf("%d%d", &n, &m);
	for(i=0;i<n;++i)
	{
		scanf("%d", &a[i]);
		if(a[i]==0)
			scanf("%d", &k);
	}
	for(i=0;i<n;++i)
	{
		if(n>=2&&a[i]==2)
		{
			for(i=0;i<n;++i)
			{
				if(a[i]!=2)
				{
					flag=1;
					break;
				}
			}
		}	
	}
	for(i=0;i<n;++i)
	{
		if((m==0&&a[i]==0&&k>=2500)||(m==1&&a[i]==0&&k>2100))
		{
			for(i=0;i<n;++i)
			{
				if(a[i]==1)
				{
					flag=1;
					break;
				}
			}
		}	
	}
	if(flag==1)
		printf("haoye\n");
	else
		printf("QAQ\n");		
}
