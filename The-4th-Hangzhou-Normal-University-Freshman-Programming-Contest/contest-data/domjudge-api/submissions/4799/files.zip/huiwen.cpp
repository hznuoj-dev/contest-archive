#include <stdio.h>
#include <math.h>
#include <string.h>
int main(void){
 int t,i,n,sum,f=1;
 int a[52];
 char c;
 scanf("%d",&t);
 while(t--){
  memset(a,0,sizeof(a));
  scanf("%d",&n);
  getchar(); 
  for(i=0;i<n;i++){
   scanf("%c",&c);
   getchar();
   if(c>='a'&&c<='z')
    a[0+c-'a']++;
   else
    a[26+c-'A']++;
  }
  if(n==1||n==2){
   printf("1\n");
   sum=0;
   f=1;
   continue;
  }
  for(i=0;i<52;i++){
   if(a[i]%2==0){
    sum=sum+a[i];
   }
   else if(a[i]%2!=0){
    if(f==1){
     sum=sum+a[i];
     f=0;
    }
    else
     sum=sum+a[i]-1;
   }
  }
  printf("%d\n",sum);
  sum=0;
  f=1;
 }
 return 0;
}
