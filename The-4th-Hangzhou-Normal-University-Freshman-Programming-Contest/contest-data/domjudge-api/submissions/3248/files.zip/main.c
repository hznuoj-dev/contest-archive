#include <stdio.h>
#include <stdlib.h>
struct song{
    int s;
    char name[15];
}a[100];
int comp(const void*a,const void*b){
    struct song*pa=(struct song*)a;
    struct song*pb=(struct song*)b;
    int i=pa->s;
    int j=pb->s;
    return j-i;
}
    int main(int argc, const char * argv[]) {
        int n,m;
    scanf("%d",&n);
    for (int i=0; i<n; i++) {
        scanf("%d %s",&a[i].s,a[i].name);
    }
        qsort(a, n, sizeof(a[0]), comp);
    scanf("%d",&m);
        printf("%s\n",a[m].name);
        
    return 0;
    
}
