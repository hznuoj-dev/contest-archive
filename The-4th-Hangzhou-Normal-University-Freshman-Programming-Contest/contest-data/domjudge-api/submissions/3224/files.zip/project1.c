#include<stdio.h>
struct sing{
	int w;
	char s[16];
}stff[100001];
int main(void)
{
	struct sing temp;
	int n,i,j,k,m,t;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d %s",&stff[i].w,stff[i].s);
	}
	scanf("%d",&t);
	for(j=1;j<=1+t;j++){
		for(k=j+1;k<=n;k++){
			if(stff[j].w<stff[k].w){
				temp=stff[k];
				stff[k]=stff[j];
				stff[j]=temp;
			}
		}
	}
	printf("%s",stff[1+t].s);
    return 0;
}

