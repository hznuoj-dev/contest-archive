#include <stdio.h>
#include <stdlib.h>
#include <math.h>
int main()
{
	int t, n, x;
	scanf("%d", &t);
	while(t--)
	{
		int flag=0;
		scanf("%d%d", &n, &x);
		if(x!=0)
		{
			for(int i=0;i<10;++i)
			{
				int j = i*n;
				if(j%x==0)
				{
					flag=1;
					break;
				}
			}
			if(flag==1)
			{
				printf("yes\n");
			}
			else
			{
				printf("no\n");
			}
		}
		else
		{
			printf("no\n");
		}
	}
}
