#include<stdio.h>
#include<string.h>
const int mod=1e9+7;
const int maxn=100010;
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		char item;
		int count=0;
		char x[1010][40];
		for(int i=0; ;i++){
			scanf("%s",x[i]);
			count++;
			int n=strlen(x[i]);
			if(x[i][n-1]=='.'){
				char s[100];
				strncpy(s,x[i],n-1);
				strcpy(x[i],s);
				item='.';
				break;
			}
			if(x[i][n-1]=='?'){
				char s[100];
				strncpy(s,x[i],n-1);
				strcpy(x[i],s);
				item='?';
				break;
			}
			if(x[i][n-1]=='!'){
				char s[100];
				strncpy(s,x[i],n-1);
				strcpy(x[i],s);
				item='!';
				break;
			}
		}
		if(count%2==1){
			for(int i=0;i<count/2;i++){
				printf("%s",x[i]);
				printf(" ");
				printf("%s",x[count-i-1]);
				printf(" ");
			}
			printf("%s",x[count/2]); 
			printf("%c\n",item);
		}else {
			for(int i=0;i<=(count/2)-1;i++){
				printf("%s",x[i]);
				printf(" ");
				printf("%s",x[count-i-1]);
				if(i!=(count/2)-1) printf(" ");
			}
			printf("%c\n",item);
		}
	}
	return 0;
}
 
