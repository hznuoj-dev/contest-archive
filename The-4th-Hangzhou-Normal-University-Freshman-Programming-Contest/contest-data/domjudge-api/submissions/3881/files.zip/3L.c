#include <stdio.h>

int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int n, x;
		int s;
		scanf("%d %d", &n, &x);
		if (x == 0)
			printf("no\n");
		else  {
			if (n > x) {
				s = n % x;
				if (s == 0 || (n - s) % x == 0)
					printf("yes\n");
				else
					printf("no\n");
			} else {
				s = x % n;
				if (s == 0 || (x - s) % n == 0)
					printf("yes\n");
				else
					printf("no\n");
			}
		}
	}
	return 0;
}