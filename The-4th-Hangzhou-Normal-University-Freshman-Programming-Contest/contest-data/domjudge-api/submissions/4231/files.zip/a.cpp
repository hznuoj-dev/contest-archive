#include <stdio.h>


int main() {
	int t, z[100000], a, i, j, s, ss;
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &a);
		for (i = 0; i < a; i++)
			scanf("%d", &z[i]);
		for (i = 0, s = 0, ss = 0; i < a; s = 0, i++) {
			for (j = i; j < a; j++) {
				s += z[j];
				if (s == 7777) {
					ss++;

					break;
				}
			}
		}
		printf("%d\n", ss);
	}


}