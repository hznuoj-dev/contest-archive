#include<bits/stdc++.h>
#include<iosfwd>
#include<cstdio>
#include<cstring>
#include<algorithm>
#include<iostream>
#include<string>
#include<vector>
#include<stack>
#include<bitset>
#include<cstdlib>
#include<cmath>
#include<set>
#include<list>
#include<deque>
#include<map>
#include<queue>  
#define endl '\n'; 
using namespace std;
typedef long double ld;
typedef long long ll;
const double eps = 1e-6;
const ll INF = 2e5+100;
#define ywh666 ios_base::sync_with_stdio(0);cin.tie(0);
bool is_prime(ll a){
    if(a < 0) return false;
    if(a == 0 || a == 1 ) return false;
    if(a == 2 || a == 3) return true;
    for(ll i = 2 ; i <= sqrt(a) ; ++i){
        if(a % i == 0) return false;
    }
    return true;
}
const ll  mod = 1e9+7;
ll qpow(ll x , ll n ){
    ll ans = 1;
    while(n > 0){
        if(n & 1 == 1){
            ans = ans * x  % mod ;
        }
        x = x * x % mod;
        n >>= 1;
    }
    return ans % mod;
}
int main(){
    ll t ;
    cin >> t ;
    while(t--){
        ll n ;
        cin >> n ;
        vector<ll> a(n+1);
        vector<ll> sum(n+1);
        map<ll,ll> mp;
        ll ans = 0 ;
        a[0] = 0 ;
        sum[0] = 0;
        for(ll i = 1 ; i <= n ; i ++){
            cin >> a[i];
        }
        for(ll i = 0 ;  i < 7777 ; i ++){
            mp[i] = -1;
        }
        mp[0] = 0;
        for(ll i = 1 ; i <= n ;  i ++){
            sum[i] = sum[i-1] + a[i];
            if(mp[sum[i]%7777] != -1) {
                if(sum[i] - sum[mp[sum[i]%7777]] == 7777) {
                    ans ++ ;
                }
            }
            mp[sum[i] % 7777] = i ;
    }
    cout << ans << endl;
    }
      


    return 0 ;
}