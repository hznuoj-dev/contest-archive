#include<stdio.h>
struct sing{
	int w;
	char s[16];
}stff[100001];
int main(void)
{
	struct sing temp;
	int n,i,j,k,m,t;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&stff[i].w,stff[i].s);
	}
	scanf("%d",&t);
	for(j=0;j<=n-1;j++){
		if(stff[j].w<stff[j+1].w){
			temp=stff[j];
			stff[j]=stff[j+1];
			stff[j+1]=temp;
		}
	}
	for(k=n-1;k>0;k--){
		if(stff[k].w>stff[k-1].w){
			temp=stff[k];
			stff[k]=stff[k-1];
			stff[k-1]=temp; 
		}
	}
	printf("%s",stff[t].s);
    return 0;
}

