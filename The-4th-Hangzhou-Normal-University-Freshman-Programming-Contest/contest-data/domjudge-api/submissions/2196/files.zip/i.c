#include<stdio.h>
#include<stdlib.h>
struct song{
	int like;
	char name[15];
};
int comp(const void*p,const void*q){
	return ((struct song*)q)->like-((struct song *)p)->like;
} 
int main(){
	int n,i;
	scanf("%d",&n);
	struct song s[100000];
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].like,s[i].name);
	}
	int k;
	scanf("%d",&k);
	//ϲ���̶�����
	qsort(s,n,sizeof(struct song),comp);
	printf("%s",s[k].name);
	return 0;
}
