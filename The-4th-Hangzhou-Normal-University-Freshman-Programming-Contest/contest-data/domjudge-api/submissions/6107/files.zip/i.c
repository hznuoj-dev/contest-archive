#include<stdio.h>
#include<stdlib.h>

struct g{
	int w;
	char s[99];
} ge[999];
  int comp(const void *p,const void *q){
 return ((struct g *)q)->w-((struct g *)p)->w;
}
int main(){
	int i,n,m;
	scanf("%d",&n);
	scanf("%d",&m);
	for(i=0;i<n;i++)
	{
	scanf("%d%s",&ge[i].w,ge[i].s);
	}
	qsort(ge,n,sizeof(struct g),comp);
	printf("%s\n",ge[m].s);
	
	return 0;

}