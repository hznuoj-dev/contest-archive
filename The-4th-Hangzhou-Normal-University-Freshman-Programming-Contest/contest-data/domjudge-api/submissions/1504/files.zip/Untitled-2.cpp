#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <sstream>
#include<bits/stdc++.h>
#define ll long long
#define INF 1e6
#define MAXZ 100050 
#define pancake std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
using namespace std;
ll qm (ll base , ll power , ll m){
    ll result = (ll) 1 % m;
    ll t = (ll) base;
    while (power){
        if(power & 1){
            result = result * t % m ;
        }
            t = t * t % m;
            power >>= 1 ;
    }
    return result;
}
typedef struct stu{
       ll a;
}stu;
bool cmp (stu x , stu y){
        if(x.a == y.a) return false;
        return x.a > y.a;
}
queue<int> que;
int main(){
    pancake;
    ll t;
    cin >> t;
    while(t --){
        ll n , x;
        cin >> n >> x;
        if(x == 0) cout << "no" << endl;
        else cout << "yes" << endl;
    }
    return 0;
}