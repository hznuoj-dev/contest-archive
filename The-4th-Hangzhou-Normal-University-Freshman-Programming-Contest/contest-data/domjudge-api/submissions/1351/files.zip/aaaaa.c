#include <stdio.h>
int main(void){
	int T,i;
	scanf("%d",&T);
	for(i=0;i<T;i++){
		printf("Welcome to HZNU\n");
	}
	return 0;
}










