#include <stdio.h>
int main() {
	int t;
	long int n, x;
	scanf("%d", &t);
	while (t--) {
		scanf("%ld %ld", &n, &x);
	}
		if (x != 0) {
			printf("yes\n");
		}
		else {
			printf("no\n");
		}
	}
