#include<stdio.h>
int main(){
	int n,t,x;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d %d",&t,&x);
		if(x==0) printf("no\n");
		else printf("yes\n");
	}
}
