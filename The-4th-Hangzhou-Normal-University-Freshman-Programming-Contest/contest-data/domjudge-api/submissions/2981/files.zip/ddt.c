#include <stdio.h>
#include <math.h>
#include <string.h>
int pi=100005;
typedef struct{
	int cd;
	char gm[20];
}DG;
int cmp(const void *a,const void *b){
	DG *p=(DG *)a;
	DG *q=(DG *)b;
	return q->cd-p->cd;
}
int main(){ 
    DG tmp[pi],stu;
    int n,i,j,k;
    scanf("%d",&n);
    for(i=1;i<=n;i++){
    	scanf("%d %s",&tmp[i].cd,&tmp[i].gm);
	}
	qsort(tmp+1,n,sizeof(tmp[1]),cmp);
	scanf("%d",&k);
	printf("%s",tmp[k+1].gm);
	return 0;
}


