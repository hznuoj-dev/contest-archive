#include<stdio.h>
#include<string.h>
int main (){
	int t,n,same[52],res,flag;
	char c;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		memset(same,0,sizeof(same));
	while(n--){
		getchar();
		scanf("%c",&c);
		if(c>='a'&&c<='z')same[c-'a']++;
		else same[c-'A'+26]++;
	}
	res=0;
	flag=0;
	for(int i=0;i<52;i++){
		if(same[i]%2==1)flag=1;
	    res+=same[i]/2;
	}
	res*=2;
	if(flag==1)res++;
	printf("%d\n",res);
	}
}
