#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
int main(void){
	int x,i,n;
	int y;
	char ch[100011];
	scanf("%d",&n);
	while(n--){
		scanf("%d",&x);
		getchar();
		int s[10001]={0};
		int sum=0;
		int flag=1;
		for(i=0;i<x;++i){
			scanf("%s",&ch[i]);
			y=ch[i];
			s[y]++;
			if(s[y]%2==0) sum++;
		}
		for(i=30;i<=140;++i){
			if(s[i]%2==1) flag=0;
		}
		if(!flag)
		printf("%d\n",sum*2+1);
		else printf("%d\n",sum*2);
	}
	return 0;
} 
