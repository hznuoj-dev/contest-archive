#include <string.h>
#include <stdio.h>
#include <math.h>

char ch[1000][35];
int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int i, m, n;
		for (i = 1; i <= 1005; i++) {
			scanf("%s", ch[i]);
			m = strlen(ch[i]);
			if (ch[i][m - 1] == '.' || ch[i][m - 1] == '!' || ch[i][m - 1] == '?')
				break;
		}
		printf("%s ", ch[1]);
		for (n = 0; n < m - 1; n++)
			printf("%c", ch[i][n]);
		printf(" ");
		for (int j = 2; j <= i / 2; j++) {
			printf("%s ", ch[j]);
			printf("%s", ch[i - j + 1]);
			if (j != i / 2)
				printf(" ");
		}
		if (i % 2 != 0)
			printf("%s", ch[i / 2 + 1]);
		printf("%c", ch[i][m - 1]);
		printf("\n");
	}
}









