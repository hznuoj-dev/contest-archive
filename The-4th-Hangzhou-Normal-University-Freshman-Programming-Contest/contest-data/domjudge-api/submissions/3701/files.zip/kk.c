#include<stdio.h>

int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m,i;
		scanf("%d%d",&n,&m);
		if(m!=0) printf("yes\n");
		if(m==0) printf("no\n");
		
	} 
	return 0;
}

