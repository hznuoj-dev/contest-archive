#include<stdio.h>
#include<stdlib.h>
struct a{
	long long int w;
	char s[18];
};
int comp(const void *p,const void *q){
	return ((struct a*)q)->w-((struct a*)p)->w;
}
struct a a1[1000];
int main(){
	long long int n,k;
	scanf("%lld",&n);
	for(int i=0;i<n;i++){
		scanf("%lld %s",&a1[i].w,a1[i].s);
	}
	scanf("%lld",&k);
	qsort(a1,n,sizeof(struct a),comp);
		puts(a1[k].s);
	
}