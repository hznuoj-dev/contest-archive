#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int a[1000050],b[10000500]={0},c[10050]={0};
int com(const void*a,const void*b)
{
	return *(int *)a-*(int *)b;	
} 
int main(){
	int i,t,n,sum,wz=1,j,shang;
	scanf("%d",&t);
	while(t--)
	{
		shang=1;
		sum=0;
		wz=2;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
		}
		qsort(a,n,sizeof(a[0]),com);
		b[1]=a[0];c[a[0]]++;
		for(i=1;i<n;i++)
		{	
			for(j=shang;j>=1;j--)
			{
				if(a[i]+b[j]>7777)
					continue;
				else if(c[a[i]+b[j]]!=0)
					c[a[i]+b[j]]+=c[b[j]];
				else
				{
					b[wz]=a[i]+b[j];
					c[a[i]+b[j]]+=c[b[j]];
					wz++;	
				}	
			}
			if(c[a[i]]!=0)
			{
				c[a[i]]++;
			}
			else
			{
				c[a[i]]++;
				b[wz]=a[i];
				wz++;
			}
			shang=wz-1;	
		}
		printf("%d\n",c[7777]);
	}
	return 0;
}
