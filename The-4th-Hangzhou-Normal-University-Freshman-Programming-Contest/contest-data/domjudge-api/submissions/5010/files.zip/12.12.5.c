#include<stdio.h>
struct goji
{
	int a;
	int b;
};
int main()
{
	int n = 0,m = 0, i = 0,flag = 0;
	int c0 = 0,c1 = 0,c2 = 0,count = 0;
	struct goji arr[20];
	scanf("%d %d",&n,&m);
	for(i = 0; i < n;i++)
	{
		scanf("%d",&arr[i].a);
		if(arr[i].a==0)
		{
			scanf("%d",&arr[i].b);
			c0++;
			if(m == 0&& arr[i].b >= 2500)
				count++;
			if(m == 1&& arr[i].b > 2100)
				count++;
		}
		if(arr[i].a==1)
		{
			c1++;
		}
		if(arr[i].a==2)
		{
			c2++;
		}
	}
	if((c0>0||c1 > 0) && c2 > 0)
		flag = 1;
	else if(count >0 &&c1>0)
	    flag = 1;
	if(flag == 1)
		printf("haoye");
	else
		printf("QAQ");
}