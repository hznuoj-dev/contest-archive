#include<bits/stdc++.h>

using namespace std;
const int N=1e5+10;
int a[N]; 
int main()
{
	int t;
	cin >> t;
	for(int i=1;i<=t;i++)
	{
		int n,cnt=0;
		cin >> n;
		for(int i=1;i<=n;i++)
		{
			char ch;
			cin >> ch;
			int x=ch;
			a[x]++;
			if(a[x]%2==0&&a[x]!=0) cnt+=2;
			
		}
		if(cnt==0) cnt++;
		else if(cnt<n) cnt++;
		cout << cnt << '\n';
	}
	return 0;
}
