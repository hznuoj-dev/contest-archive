#include<stdio.h>
#include<stdlib.h>
struct girl{
    char name[10];
    int time;
};
int comp(const void *p,const void *q){
    return((struct girl *)q)->time-((struct girl *)p)->time;
}
int main(){
    struct girl ns[100];
    
        int n,i;
        scanf("%d",&n);
        for(i=0;i<n;i++){
            scanf("%d %s",&ns[i].time,ns[i].name);
        }
        qsort(ns,n,sizeof(struct girl),comp);
        int k;
		scanf("%d",&k);i=k;
		printf("%s",ns[i].name) ;
	}
		
