/*#include<stdio.h>
main()
{
	char k;
	int t,n,ci,i,flag;
	int a[55]={0};
	scanf("%d",&t);
	while(t--)
	{
		ci=0;
		scanf("%d",&n);
		while(n--)
		{
			scanf("%c",&k);
			if(((int)k<=90)&&((int)k>=65))
				a[(int)k-64]++;
			else if(((int)k<=122)&&((int)k>=97))
				a[(int)k-70]++;
		}
		flag=0;
		for(i=1;i<=52;i++)
		{
			if(a[i]%2==0)ci=ci+a[i];
			else 
			{
				flag=1;
				ci=ci+a[i]-1;
			}
			a[i]=0;
		}
		printf("%d\n",ci+flag);
	}
}
*/
#include<stdio.h>
main()
{
	int t,n,x;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&x);
		if(x==0)printf("no\n");
		else printf("yes\n");
	}
}