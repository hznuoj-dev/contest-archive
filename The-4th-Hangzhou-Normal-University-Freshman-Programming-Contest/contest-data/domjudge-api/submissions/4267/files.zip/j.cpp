#include<bits/stdc++.h>
using namespace std;
int v0=0,v1=0,v2=0,v4=0;
int main()
{
	int n,m;
	cin>>n>>m;
	for(int i=0;i<n;i++)
	{
		int now;
		cin>>now;
		if(now==0)
		{
			int x;
			cin>>x;
			if(m==0)
			{
				if(x>=2500)	v0++;
				else v4++;
			}
			else
			{
				if(x>2100)		v0++;
				else v4++;
			}
		}
		else if(now==1)
		{
			v1++;
		}
		else
		{
			v2++;
		}
	}
	if(v0!=0&&v1!=0)
	{
		cout<<"haoye";
	}
	else if(v2!=0)
	{
		if(v1!=0||v4!=0)
			cout<<"haoye";
		else
			cout<<"QAQ";
	}
	else
	{
		cout<<"QAQ";
	}
	
	return 0;
}
