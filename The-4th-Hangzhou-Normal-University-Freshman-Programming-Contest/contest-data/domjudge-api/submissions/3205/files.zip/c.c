#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
main(){
int n,m,i,j,a[1000][3],atk;
scanf("%d %d",&n,&m);
for(i=1;i<=n;i++){
scanf("%d",&a[i][1]);
if(a[i][1]==0){
scanf("%d",&a[i][2]);
if(m==1){
	if(a[i][2]>=2100){
	atk=1;}
	else
atk=0;}
else{
	if(a[i][2]>=2500){
	atk=1;}
	else
atk=0;}
}
}

for(i=1;i<=n;i++){
	if(a[i][1]==2&&n>=2){
	printf("haoye\n");
	break;}
	else if(a[i][1]==1&&atk==1){
			printf("haoye\n");
			break;
	}
}
if(i==n+1){
printf("QAQ\n");}
}
