#include<stdio.h>
int main()
{
	int t;
	int n;
	int a[21][21], b[21][21];
	int i, j, x,y,z,w;
	scanf("%d", &t);
	while (t--)
	{
		x = 1;
		y = 1;
		w = 1;
		z = 2;
		scanf("%d", &n);
		for (i = 1; i <= n; i++)
		{
			for (j = 1; j <= n; j++)
			{
				scanf("%d", &a[i][j]);
			}
		}
		for (i = 1; i <= n; i++)
		{
			for (j = 1; j <= n; j++)
			{
				scanf("%d", &b[i][j]);
			}
		}
		for (i = 1; i <= n; i++)
		{
			for (j = 1; j <= n; j++)
			{
				if (a[i][j] != b[i][j])
				{
					w = 0;
					break;
				}
			}
		}
		for (i = 1; i <= n; i++)
		{	
			for (j = 1; j <= n; j++)
			{
				if (a[n - j + 1][i] != b[i][j])
				{
					x = 0;
					break;
				}
			}
		}
		for (i = 1; i <= n; i++)
		{
			for (j = 1; j <= n; j++)
			{
				if (a[j][n - i + 1] != b[i][j])
				{
					y = 0;
					break;
				}
			}
		}
		for (i = 1; i <= n; i++)
		{
	        for (j = 1; j <= n; j++)
			{
				if (a[n-i+1][n-j+1] != b[i][j])
				{
					z = 0;
					break;
				}
			}
		}
		if (w == 1)
		{
			printf("0\n");
		}
        else if (x == 1 || y == 1)
		{
			printf("1\n");
		}
		else if (x == 0 && y == 0 && z == 2)
		{
			printf("2\n");
		}
		else if (x == 0 && y == 0 && z == 0)
		{
			printf("-1\n");
		}
	}
	return 0;
}



