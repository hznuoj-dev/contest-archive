#include<stdio.h>
struct letterarray
{
	char x[100000];
	int y[100000] = { 1 };
};
int main(void) {
	int T, n, ;
	scanf("%d", &T);
	struct letter letterarray;
	for (int i = 0; i < T; i++)
	{
		scanf("%d", &n);
		for (int j = 0; j < n; j++)
		{
			scanf("%c", letterarray.x[j]);
		}
		for (int a = 1;a < n;a++) {
			{
				if ((letterarray.x[a])==(letterarray.x[0]))
				{
					letterarray.y[0] += 1;
				}
				else
				{
					letterarray.y[a] += 1;
				}
			}
		}
	}
	int sum = 0;
	int time = 0;
	for (int b = 0; b < n; b++) {
		if ((letterarray.y[b])%2 == 0)
		{
			sum += letterarray.y[b];
		}
		else
		{
			sum += letterarray.y[b];
			sum -= 1;
			time += 1;
		}

	}
	if (time > 0)
	{
		sum += 1;
	}
	printf("%d", sum);
	return 0;
}
