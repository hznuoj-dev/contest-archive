#include<stdio.h>
#include<stdlib.h>
struct S
{
	int w;
	char s[16];	
};
int cmp(const void *p,const void *q)
{
	return ((struct S*)p)->w-((struct S*)q)->w;
}
int main()
{
	int n,x,i,k;
	scanf("%d",&n);
	struct S a[n];
	for(i=0;i<n;i++)
	scanf("%d %s",&a[i].w,a[i].s);
	scanf("%d",&k);
	qsort(a,n,sizeof(struct S),cmp);
	printf("%s",a[n-1-k].s);
	return 0;	
} 
