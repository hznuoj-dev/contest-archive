#include<stdio.h>
int main() {
	int n = 0;
	int m = 0;
	int flag = 0;
	int flag1 = 0;
	int flag2 = 0;
	int i = 0;
	int a[10];
	int b[10];
	scanf("%d", &n);
	scanf("%d", &m);
	for (i = 0; i < n; i++) {
		scanf("%d", &a[i]);
		if (a[i] == 0) {
			scanf("%d", &b[i]);
		}
	}
	for (i = 0; i < n; i++) {
		if (a[i] == 2&&n>1) {
			flag = 1;
			break;
		}
	}
	for (i = 0; i < n; i++) {
		if (a[i] == 0) {
			if (m == 0) {
				if (b[i] >= 2500) {
					flag1 = 1;
					break;
				}
			}
			else {
				if (b[i] >= 2100) {
					flag1 = 1;
					break;
				}
			}
		}
	}
	for (i = 0; i < n; i++) {
		if (a[i] == 1) {
			if (flag1 = 1 ) {
				flag = 1;
			}
		}
	}
	if (flag == 1) {
		printf("haoye");
	}
	else {
		printf("QAQ");
	}
	return 0;
}