#include<stdio.h>
int main()
{
	int T, n, i, j, l;
	char c[100000], t;
	scanf("%d", &T);
	while (T--)
	{
		l = 0;
		scanf("%d", &n);
		getchar();
		for (i = 0; i < n; i++)
		{
			scanf("%c", &c[i]);
		}
		getchar();
		for (i = 0; i < n; i++)
		{
			for (j = i + 1; j < n; j++)
			{
				if (c[i] == c[j])
				{
					t = c[i + 1];
					c[i + 1] = c[j];
					c[j] = t;
					l++;
					i++;
				}
			}
		}
		if ((2 * l) == n)
			printf("%d\n", 2 * l);
		else
			printf("%d\n", 2 * l + 1);
	}
	return 0;
}