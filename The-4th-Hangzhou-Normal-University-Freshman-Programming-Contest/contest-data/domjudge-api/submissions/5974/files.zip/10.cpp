#include<stdio.h>
int main(void){
	int n,m,i,x[10],k,f=2;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;++i){
		scanf("%d",&x[i]);
		switch(x[i]){
		case 0:
			scanf("%d",&k);
			if(f==1)
				f==2;
			else{
				switch(m){
				case 0:
					if(k>=2500)
						f=1;
					break;
				case 1:
					if(k>=2100)
						f=1;
					break;
				}
			}
			break;
		case 1:
			if(f==1)
				f=0;
			break;
		case 2:
			if(f==2&&i<n-1){
				i++;
				f=0;
			}
			break;
		}
		if(f==0)
			break;
	}
	if(f==0)
		printf("haoye\n");
	else
		printf("QAQ\n");
	return 0;
}