#include <stdio.h>
#include <stdlib.h>
struct song{
	long long a;
	char name[20]; 
};
int comp(const void*p,const void*q){
	return ((struct song*)q)->a - ((struct song*)p)->a;
}
int main()
{
	struct song arr[100010];
	int n,k;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d %s",&arr[i].a,arr[i].name);
	}
	scanf("%d",&k);
	qsort(arr,n,sizeof(struct song),comp);
	printf("%s",arr[k].name);
	return 0;
}
