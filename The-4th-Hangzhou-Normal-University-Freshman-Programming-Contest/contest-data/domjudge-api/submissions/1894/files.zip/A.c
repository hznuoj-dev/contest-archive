//#define _CRT_SECURE_NO_WARNINGS
//����K
#include <stdio.h>
//#include <process.h>
int main()
{
	int n;
	scanf("%d",&n);

	while(n--)
	{
		printf("Welcome to HZNU\n");
	}

//	system("pause");
	return 0;
}


//����
//#include <stdio.h>
//#include <process.h>
//
//struct Song
//{
//	long long int rank;
//	char name[20]
//}
//
//int main()
//{
//	int n;
//	scanf("%d",&n);
//
//
//}
