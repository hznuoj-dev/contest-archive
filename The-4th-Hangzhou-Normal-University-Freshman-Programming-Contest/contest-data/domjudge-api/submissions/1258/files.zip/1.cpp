#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	for(n;n>0;n--){
		printf("Welcome to HZNU");
		if(n!=1)
		printf("\n");
	}
}
