#include<stdio.h>
#include<stdlib.h>
main(){
	int t;
	scanf("%d",&t);
	while(t--){
	printf("Welcome to HZNU\n");
	}

}