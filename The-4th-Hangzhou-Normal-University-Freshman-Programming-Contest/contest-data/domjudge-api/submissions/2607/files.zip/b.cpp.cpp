#include<stdio.h>
int rt(int n,int x)
{
	int t=x;
	if(x==0)return 0;
	else
	{
		x=x-(n%x);
		if(x==t)
		{
			return 1;
		}
		return rt(n,x);
	}
}
int main()
{
	int sum,sum2,i,j,x,t,n,a[100009];
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d%d",&n,&x);
		if(rt(n,x))printf("yes\n");
		else printf("no\n");
	} 
	return 0;
}
