//#include <iostream>
//#include <vector>
//#include <map>
//using namespace std;
//#define vc vector
//#define pii pair<int,int>
//
//const int mod=1e9+7;
//typedef long long ll;
//
//int main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0);
//	cout.tie(0);
//	int n;
//	cin>>n;
//	map<int,string> mp;
//	while(n--){
//		int n;
//		string s;
//		cin>>n>>s;
//		mp[n]=s;
//	}
//	int n=mp.size();
//	n=mp.size()-n;;
//	n--;
//	auto cur=mp.begin();
//	for(int i=0;i<n;i++,cur++){}
//	cout<<cur->second<<endl;
//	return 0;
//}
#include <iostream>
#include <vector>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cin.tie(0);
	int q;
	cin>>q;
	while(q--){
		int n;
		cin>>n;
		vc<int> arr(n+1,0);
		for(int i=1;i<=n;i++){
			cin>>arr[i];
		}
		for(int i=1;i<=n;i++) arr[i]+=arr[i-1];
		int sum=0;
	for(int i=1;i<=n;i++){
		int l=i+1,r=n;
		int flag=0;
		while(l<=r){
			int mid=(l+r)>>1;
			int num=arr[mid]-arr[i-1];
			if(num==7777){
				flag=1;
				break;
			}
			else if(num<7777){
				l=mid+1;
			}
			else{
				r=mid-1;
			}
		}
		if(flag) sum++;
	}
	cout<<sum<<endl;
	}
	
	return 0;
}
