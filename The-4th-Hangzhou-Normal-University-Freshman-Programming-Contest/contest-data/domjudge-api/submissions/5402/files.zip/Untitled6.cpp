#include<stdio.h>
int main(void){
	int n,m,i,j,s=1,a,b=0,c=0;
	scanf("%d %d",&n,&m);
	for(i=0;i<n&&s==1;i++){
		scanf("%d",&j);
		if(j==2){
			if(n>1){
				printf("haoye");
				s=0;
			}
		}
		else if(j==0){
			scanf(" %d",&a);
			if(m==1){
				if(a>2100)
				b=1;
			}
			else if(m==0){
				if(a>=2500)
				b=1;
			}
		}
		else if(j==1){
			c=1;
		}
	}
	if(b==1&&c==1&&s==1){
		printf("haoye");
				s=0;
	}
	if(s==1){
		printf("QAQ");
	}
	return 0;
}
