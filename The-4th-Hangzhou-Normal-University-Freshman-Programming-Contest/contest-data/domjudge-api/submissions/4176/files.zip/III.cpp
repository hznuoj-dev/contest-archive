#include<stdio.h>
#include<stdlib.h>
struct sing{
	long long w;
	char *s[20];
};
int cmp(const void *p,const void *q)
{
	struct sing *pp = (struct sing *)(p);
	struct sing *pq = (struct sing *)(q);
	long long x = pp->w;
	long long y = pq->w;
	return y - x;
}
int main(void)
{
	int n,i,k;
	struct sing a[10000];
	scanf("%d",&n);
	for(i=0;i<n;++i)
	{
		scanf("%lld%s",&a[i].w,&a[i].s);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(struct sing),cmp);
	printf("%s\n",&a[k].s);
	return 0;
}
