#include <string.h>
#include <stdio.h>

int main() {
	int n, i, j, k, r, s, min, max;
	long long b[100000];
	char a[16][100000];
	scanf("%d", &n);
	for (i = 0; i < n; ++i) {
		scanf("%lld %s", &b[i], a[i]);
	}
	max = b[0];
	scanf("%d", &k);
	while (k--) {
		r = 0;
		for (i = 1; i < n; ++i) {
			if (max < b[i]) {
				max = b[i];
				r = i;
			}
		}
		for (s = r; s < n - 1; ++s) {
			strcpy(a[s], a[s + 1]);
			b[s] = b[s + 1];
		}
		max = b[0];
		--n;
	}
	max = b[0];
	for (i = 0; i < n - 1; ++i) {
		if (max < b[i]) {
			max = b[i];
			j = i;
		}
	}
	printf("%s", a[j]);
	return 0;
}
