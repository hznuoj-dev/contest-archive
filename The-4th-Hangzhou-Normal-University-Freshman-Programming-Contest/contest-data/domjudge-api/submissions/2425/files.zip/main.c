#include<stdio.h>
int main(){
    struct song{
        long long love;
        char name[20];
    };
    int n,i,k,t;
    struct song num[100000],temp;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%lld%s",&num[i].love,num[i].name);
    }
    scanf("%d",&k);
    for(i=0;i<=k;i++){
        t=i;
        for(int j=i+1;j<n;j++){
            if(num[j].love>num[t].love){
                t=j;
            }
        }
        temp=num[t];num[t]=num[i];num[i]=temp;
    }
    printf("%s\n",num[k].name);
    return 0;
}
