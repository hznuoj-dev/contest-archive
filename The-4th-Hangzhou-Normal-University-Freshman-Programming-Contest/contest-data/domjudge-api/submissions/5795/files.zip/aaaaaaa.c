#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
char a[11][1000005]={0};
int main(){
	int n,m,i,j,min=99999,sum=0,minx;
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		for(j=1;j<=m;j++)
		{
			scanf("%d",&a[i][j]);
		}
	}
	for(i=1;i<=m;i++)
	{
		for(j=1;j<=m;j++)
		{
			if(min>abs(a[1][i]-a[2][j]))
			min=abs(a[1][i]-a[2][j]);
		}
	}
	sum+=min;
	for(i=3;i<=n;i++)
	{
		minx=99999;
		for(j=1;i<=m;j++)
		{
			if(abs(min-a[i][j])<minx)
			minx=abs(min-a[i][j]);	
		}
		min=minx;
		sum+=min;
	}
	printf("%d",sum);
	return 0;
}
