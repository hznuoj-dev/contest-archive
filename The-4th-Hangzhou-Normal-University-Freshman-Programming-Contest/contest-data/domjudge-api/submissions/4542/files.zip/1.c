#include <stdio.h>
#include <string.h>
#include <math.h>
int main()
{
	int n;
	int a,b;
    scanf("%d",&n);
    for(int i=1;i<=n;i++)
    {
        int x[26]={0};
        int Y[26]={0};
        int s=0;
        scanf("%d ",&a);
        for(int j=1;j<=a;j++)
        {
            scanf("%c%*c",&ch);
            if(ch<='z'&&ch>='a')
            {
                b=ch-'a';
                x[b]=x[b]+1;
            }
            if(ch<='Z' &&ch>='A')
            {
                b=ch-'A';
                Y[b]=Y[b]+1;
            }
        }
        for(int j=0;j<26;j++)
        {
            s=s+x[j]-(x[j]%2);
            s=s+Y[j]-(Y[j]%2);
        }
        if(s==0)
            printf("1");
        else
        {
            if(a%2==1)
        {
            printf("%d",s+1);
        }
        else
        {
            printf("%d",s);
        }
        }

            printf("\n");
    }
    return 0;
}
