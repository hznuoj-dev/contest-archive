#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
int main()
{
	int P, t, M;
	scanf("%d", &M);
	while (M--)
	{

		scanf("%d", &P);
		int arr[10000];
		for (t = 0; t < P; t++)
		{
			scanf("%d", &arr[t]);
		}
		long sum = 0;
		int len = P;
		int i = 0;
		int j = 0;
		int flag = 0;
		long maxnum = 1;
		int nums = 0;
		char str[10240] = { 0 };
		for (i = 0; i < len; i++)
		{
			maxnum = maxnum * 2;
		}

		for (i = 1; i <= maxnum; i++)
		{
			sum = 0;
			for (j = 0; j < len; j++)
			{
				flag = (i >> j) % 2;
				if (flag == 1)
				{
					sum += arr[len - j - 1];
					sprintf(str + strlen(str), "%d ", arr[len - j - 1]);
				}
			}
			if (sum == 7777)
			{
				nums++;
			}
			str[0] = 0;
		}
		printf("%d", nums);
	}

}