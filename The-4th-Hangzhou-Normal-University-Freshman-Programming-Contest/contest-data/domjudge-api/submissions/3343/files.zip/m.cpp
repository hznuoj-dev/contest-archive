#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
#define MogeKo qwq

using namespace std;

bool check(char c) {
	if(c == '.') return true;
	if(c == '!') return true;
	if(c == '?') return true;
	return false;
}

int t,n;
char s[50][1005],end;

int main() {
	scanf("%d",&t);
	while(t--) {
		for(n = 1; ; n++) {
			scanf("%s",s[n]);
			int i = strlen(s[n]);
			if(check(s[n][i-1])) {
				end = s[n][i-1];
				s[n][i-1] = '\0';
				break;
			}
		}
		for(int i = 1;i <= n/2;i++){
			if(i == 1) printf("%s",s[i]);
			else printf(" %s",s[i]);
			printf(" %s",s[n-i+1]);
		}
		if(n&1) printf(" %s",s[n/2+1]);
		printf("%c\n",end);
	}
	return 0;
}

