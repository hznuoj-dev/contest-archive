#include <stdio.h>
typedef struct{
	int t;
	int k;
} e;
int main(void)
{
	int n,m,a,flag=0,f=0,i;
	scanf("%d%d",&n,&m);
	if(m)
	{
		a=2100;
		flag=1;
	}
	else
	{
		a=2500;
	}
	e r[n+1];

	for(i=1;i<=n;i++)
	{
		scanf("%d",&r[i].t);
		if(r[i].t)
		{
			continue;
		}
		scanf("%d",&r[i].k);
	}
	for(i=1;i<=n;i++)
	{
		if(r[i].t==0)
		{
			if(flag)
			{
				if(r[i].k>m)
				{
					for(int j=1;j<=n;j++)
					{
						if(r[j].t==1)
						{
							f=1;
							break;
						}
					}
					if(f)
					{
						break;
					}
				}
			}
			else
			{
				if(r[i].k>=m)
				{
					for(int j=1;j<=n;j++)
					{
						if(r[j].t==1)
						{
							f=1;
							break;
						}
					}
					if(f)
					{
						break;
					}
				}				
			}
		}
		else if(r[i].t==2&&n>=2)
		{
			break;
		}
	}
	if(i<=n)
	{
		printf("haoye");
	}
	else
	{
		printf("QAQ");
	}	
	return 0;
}
