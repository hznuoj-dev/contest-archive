#include<bits/stdc++.h>
#define wtn tql
using namespace std;
int main(void){
	int t;cin>>t;
	while(t--){
		int n,x;cin>>n>>x;
		if(x==0)cout<<"no"<<endl;
		else cout<<"yes"<<endl;	}
return 0;
}

