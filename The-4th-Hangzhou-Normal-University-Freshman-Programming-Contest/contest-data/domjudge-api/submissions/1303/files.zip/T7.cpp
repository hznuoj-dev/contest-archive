#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main (){
	int t;
	scanf("%d",&t);
	while(t--){
		printf("Welcome to HZNU\n");
	}
	return 0;
} 
