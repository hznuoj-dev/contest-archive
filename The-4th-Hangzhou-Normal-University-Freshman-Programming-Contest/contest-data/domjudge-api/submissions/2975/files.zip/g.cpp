#include<stdio.h>
#include<string.h>
struct g{
	 int a;
	char c[20];
	int k;
};
struct g g1[100001];
int main(){
	int t,m,n,i,j,x;
	char f[20];
	 int e;
	scanf("%d",&t);
	for(i=0;i<t;i++){
		scanf("%d %s",&g1[i].a,g1[i].c);
	} 
	scanf("%d",&x);
	for(i=0;i<t;i++){
		for(j=0;j<t;j++){
			if(i!=j){
			if(g1[i].a<g1[j].a){
				g1[i].k=g1[i].k+1;
			}
			}
		}
	}
	for(i=0;i<t;i++){
		if(g1[i].k==x)
		puts(g1[i].c);
	}
}
