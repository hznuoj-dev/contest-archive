#include<string.h>
#include <stdio.h>
#include<math.h>

struct a {
	long long int b;
	char ch[20];
};
int main() {
	int n;
	scanf("%d", &n);
	long long int i;
	struct a sum[10001];
	for (i = 0;i < n;i++) {
		scanf("%lld", &sum[i].b);
		scanf("%s", sum[i].ch);
	}
	long long int pass,t;
	char s[20];
	for (pass = 1;pass < n;pass++) {
		for (i = 0;i < n - pass;i++) {
			if (sum[i].b < sum[i + 1].b) {
				t = sum[i].b;
				sum[i].b = sum[i + 1].b;
				sum[i + 1].b = t;
				strcpy(s, sum[i].ch);
				strcpy(sum[i].ch, sum[i + 1].ch);
				strcpy(sum[i + 1].ch, s);
			}
		}
	}
	long long int m;
	scanf("%lld", &m);
	printf("%s", sum[m].ch);
}










