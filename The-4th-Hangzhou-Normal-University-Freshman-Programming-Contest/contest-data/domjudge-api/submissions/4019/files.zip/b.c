#include<stdio.h>
int main(void)
{
	int t,i,j,n,sum=0,k=0;
	int a[100000];
	scanf("%d",&t);
	while(t--){
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%d",&a[i]);
	for(i=0;i<n;i++){
		k=0,sum=0;
	for(j=i;j<n;j++)
		k=k+a[j];
		if(k==7777)
			sum=sum+1;
			}
			printf("%d",sum);
			}
}
