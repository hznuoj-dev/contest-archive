#include<bits/stdc++.h>
using namespace std;
struct song{ 
char name[20];
int like;  
};
struct song a[100100];
int a1[100100];
int main()
{ int n,i,j,ans,m,k,l,o,p;
  cin>>n;
  for (i=0;i<n;i++)
  {
   cin>>a[i].like>>a[i].name;
   a1[i]=a[i].like ;
  }
  sort(a1,a1+n);
  cin>>k;
  ans=a1[n-k-1];
  for (j=0;j<n;j++)
   if (ans==a[j].like) { cout<<a[j].name; return 0;}
}
