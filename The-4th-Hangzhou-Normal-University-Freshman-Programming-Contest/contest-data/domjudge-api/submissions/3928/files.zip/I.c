#include<stdio.h>
#include<stdlib.h>
typedef struct {
	long long int a;
	char b[20];
}song;
int cmp(const void *x,const void *y)
{
	return -((*(song*)x).a-(*(song*)y).a);
}
song c[100000];
main(){
	int i,n,k;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&c[i].a,&c[i].b);
	}
	scanf("%d",&k);
	qsort(c,n,sizeof(song),cmp);
	printf("%s\n",c[k].b);
}
