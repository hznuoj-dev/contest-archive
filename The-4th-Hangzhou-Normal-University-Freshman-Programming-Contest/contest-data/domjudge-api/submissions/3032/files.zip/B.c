#include <stdio.h>
int main(){
	int i,j,a[100000],t,n;
	scanf("%d",&t);
	while(t--){
		int flag=0,sum;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for(j=0;j<n;j++){
			sum=0;
			for(i=j;i<n;i++){
				sum+=a[i];
				if(sum==7777) flag++;
				else continue;
		}
	}
		printf("%d\n",flag);
	}
return 0;
}

