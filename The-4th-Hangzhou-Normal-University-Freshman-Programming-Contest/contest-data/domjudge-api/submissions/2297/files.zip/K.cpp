#include<bits/stdc++.h>
using namespace std;
int a[52];
int main(){
	int t,n;
	cin>>t;
	for(int i=1;i<=t;i++){
		cin>>n;
		for(int j=0;j<n;j++){
			char c;
			cin>>c;
			if(c>='a' && c<='z'){a[c-97]++;}
			else{a[c-65+26]++;}	
		}
		int sum=0,flag=1;
		for(int j=0;j<52;j++){
			if(a[j]%2==0){
				sum+=a[j];
			}
			else{
				if(flag==1){
					sum+=a[j];
					flag=0;
				}
				else{
					sum=sum+a[j]-1;
				}
			}
		}
		cout<<sum<<'\n';
		for(int j=0;j<52;j++){
			a[j]=0;
		}
	}
	
	return 0;
}
