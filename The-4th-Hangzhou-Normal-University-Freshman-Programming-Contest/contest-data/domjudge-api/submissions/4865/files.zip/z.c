#include<stdio.h>
#include<stdlib.h>
struct ss{
	char a[20];
	int c;
}; 

int compint(const void *p,const void *q){
	struct ss *a=(struct ss*)p,*b=(struct ss*)q;
	return b->c - a->c;
}

int main(){
	struct ss a[100008];
	int t;int n,x;
	scanf("%d",&n);
	for(t=0;t<n;t++){
		scanf("%d %s",&a[t].c,a[t].a);
		}
		scanf("%d",&x);
		qsort(a,n,sizeof(struct ss),compint);
		printf("%s",a[x].a);
	return 0;
}
