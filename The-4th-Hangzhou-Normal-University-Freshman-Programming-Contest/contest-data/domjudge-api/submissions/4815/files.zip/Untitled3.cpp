#include<stdio.h>
#include<stdlib.h>
int main(void)
{
 	int i,a,b,c[20],xue,max=0;
 	scanf("%d %d",&a,&b);
 	for(i=0;i<a;i++)
 	{
 		scanf("%d",&c[i]);
 		if(c[i]==0)
 		{
 			scanf("%d",&xue);
 			if(max<=xue)
 			{
 				max=xue;
			}
		}
	}
	if(max>=2500&&b==0)
	{
		for(i=0;i<a;++i)
		{
			if(c[i]==1)
			{
				printf("haoye\n");
				break;
			}
			
		}
	}
	else if(max>2100&&b==1)
	{
		for(i=0;i<a;++i)
		{
			if(c[i]==1)
			{
				printf("haoye\n");
				break;
			}
			
		}
	}
	else if(a>=2)
	{
		for(i=0;i<a;++i)
		{
			if(c[i]==2)
			{
				printf("haoye\n");
				break;
			}
			
		}
	}
	else
	{
		printf("QAQ\n");
	}
	
	return 0;
} 
