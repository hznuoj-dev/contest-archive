#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h> 
struct music{
 char a[16];
 long long int w;
}b[100],t;
int cmp(const void *p,const void *q)
{
 return ((struct music *)q)->w-((struct music *)p)->w;
}
int main(void)
{
 long long int n;
 int i,k;
 scanf("%lld",&n);
 for(i=0;i<n;i++)
 {
  scanf("%lld%s\n",&b[i].w,b[i].a);
 }
 scanf("%d",&k);
qsort(b,n,sizeof(struct music),cmp);

 for(i=0;i<n;i++)
 {
     if(i==k)
  printf("%s",b[i].a);
 }
 return 0;
}
