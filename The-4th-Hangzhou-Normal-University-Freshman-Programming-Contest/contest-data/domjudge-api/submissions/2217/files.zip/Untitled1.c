#include<stdio.h>

int main(){
	int n,i,k;
	scanf("%d",&n);
	struct xx{
		int w;
		char s[20];
	};
	struct xx x[n];
	for(i=0;i<n;i++){
		scanf("%d %s",&x[i].w,&x[i].s);
	}
	scanf("%d",&k);
	int leap=1;
	struct xx t;
	while(leap){
		leap=0;
		for(i=0;i<n-1;i++){
			if(x[i].w<x[i+1].w){
				t=x[i];
				x[i]=x[i+1];
				x[i+1]=t;
				leap=1;
			}
		}
	}
	printf("%s",x[k].s);
	return 0;
}
