#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define t 50
struct songs{
	int love;
	char name[16];
};
int comp(const void *p, const void *q){
	return ((struct songs *)q)->love-((struct songs *)p)->love;
}
main(){
	struct songs song[t];
	int i,n;
	int k;
	scanf("%d",&n);
	for(i=0;i<n;++i){
		scanf("%d %s",&song[i].love,song[i].name);
	}
	qsort(song,n,sizeof(struct songs),comp);
	scanf("%d",&k);
	printf("%s",song[k].name);
}
