#include<stdio.h>
#include<stdlib.h>
typedef struct{
	int like;
	char name[16];
}ge;
comp(const void *p,const void *q){
	return ((ge *)q)->like - ((ge *)p)->like;
}
int main(){
	int n,i,k,j,t;
	scanf("%d",&n);
	ge a[n];
	for(i=0;i<n;i++){
		scanf("%d%s",&a[i].like,a[i].name);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(ge),comp);
	printf("%s",a[k].name);
}
