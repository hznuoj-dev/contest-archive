#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
 struct data{
long long a;
int b;
};
int cmp(const void *a,const void *b){
struct	data p1=*(struct data*)a;
struct data p2=*(struct data*)b;
return p1.a-p2.a;
}
struct data a[10000001];
main(){
int n,m,i,j,min,z,k;
scanf("%d %d",&n,&m);
for(i=1;i<=n;i++){
	for(j=1;j<=m;j++){
	scanf("%lld",&a[(i-1)*m+j].a);
	a[(i-1)*m+j].b=i;
	}
}
qsort(a+1,n*m,sizeof(a[1]),cmp);
z=1;
k=n*m;
for(i=k;i>=2;i--){
	for(j=i-1;j>=1;j--){
		if(z==1&&a[i].b!=a[j].b){
		min=a[i].a-a[j].a;
		z=0;
		k=j+1;
		break;
		}
		else if(z==0&&a[i].b!=a[j].b){
			if(a[i].a-a[j].a<min){
			min=a[i].a-a[j].a;
			k=j+1;
			break;
			}
			if(a[i].a-a[j].a>=min)
				break;
		}
	}
	if(min==0){
	break;}
}
printf("%d",min);
}
