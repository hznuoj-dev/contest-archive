#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main() {
	int n;
	cin >> n;
	while (n--) {
		int n, x;
		cin >> n >> x;
		const int N = n;
		int map[100001] = { 0 };
		bool ans = false;
		int i = 0;
		if (x == 0) {
			cout << "no" << endl;
			continue;
		}
		if (n % x == 0) {
			ans = true;
		}
		else {
			while (map[i] == 0||i==0) {
				map[i] = 1;
				i += x;
				if (i > n - 1) {
					i %= n;
				}
				
				if (i == 0) {
					ans = true;
					break;
				}
			}
		}
		if (ans) {
			cout << "yes" << endl;
		}
		else {
			cout << "no" << endl;
		}
	}
}