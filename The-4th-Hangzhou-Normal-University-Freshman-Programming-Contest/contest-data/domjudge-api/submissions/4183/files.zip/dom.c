#include<stdio.h>
 
int main(){
	int n,t,i,count=1;
	char a[100000];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);getchar();
		for(i=0;i<n;i++){
		scanf("%c",&a[i]);getchar();
		}
		//printf("%c%c",a[0],a[1]);
		if(n==1){printf("%d\n",n);
		}else{
		
		for(i=0;i<n;i++){
			if(a[i]==a[i+1]){
			count=count+1;
			}
		
			
		}
	//	printf("%d",count);
		if(count==n){printf("%d\n",n);}
		else{
		
		
		if(count%2==0){
			printf("%d\n",count+1);}
		else{
		printf("%d\n",count);
	}
	}
}
count=1;
}
	return 0;
} 
 
