#include <stdio.h>
struct s{
	int xa;
	char str[20];
};
int main(){
	int n;
	scanf("%d",&n);
	struct s song[n];
	int i,j;
	for(i=0;i<n;i++){
		scanf("%d %s",&song[i].xa,song[i].str);
	}
	getchar();
	struct s temp;
	int x,dianguo;
	scanf("%d",&dianguo);
	for(i=0;i<n;i++){
		x = i;
		for(j=i+1;j<n;j++){
			if(song[x].xa<song[j].xa){
				x = j;
			}
		}
		temp = song[i];
		song[i] = song[x];
		song[x]=temp;
	}
	for(i=0;i<n;i++){
		printf("%s\n",song[i].str);
	}
	printf("%s",song[dianguo].str);
}
