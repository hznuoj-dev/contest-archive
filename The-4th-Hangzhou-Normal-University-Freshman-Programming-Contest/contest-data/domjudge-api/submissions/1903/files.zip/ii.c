#include<stdio.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
struct song{
	int w;
	char s[20];
};
int main(void)
{
	int n,k;
	scanf("%d",&n);
	int like[n];
	struct song sing[n],temp;
	int i,j;
	for(i=0;i<n;++i)
	{
		scanf("%d %s",&sing[i].w,sing[i].s);
		like[i]=sing[i].w;
	}
	scanf("%d",&k);
	qsort(like,n,sizeof(int),comp);
	for(i=0;i<n;++i)
	{
		if(like[k]==sing[i].w)
		printf("%s",sing[i].s);
	}
	return 0;
}
int comp(const void *p,const void *q)
{
	return (*(int *)q-*(int *)p);
}
