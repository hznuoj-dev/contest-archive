#include <stdio.h>
int main(void)
{
	int T, x, y, n, b, x0, y0;
	int c1[25][25] = { {0} };
	int c2[25][25] = { {0} };
	scanf("%d", &T);
	while (T--) {
		b = 1;
		scanf("%d", &n);
		for (x = 1; x <= n; x++)
			for (y = 1; y <= n; y++)
				scanf("%d", &c1[x][y]);
		for (x = 1; x <= n; x++)
			for (y = 1; y <= n; y++)
				scanf("%d", &c2[x][y]);

		for (x = 1; x <= n; x++)
			for (y = 1; y <= n; y++)
				if (c1[x][y] != c2[x][y]) { b = 0; }
	
		if (b) { printf("0"); goto a; }
		b = 1;

		for (x = 1; x <= n; x++)
			for (y = 1; y <= n; y++)
				if (c1[y][n + 1 - x] != c2[x][y]) { b = 0; }

		if (b) { printf("1"); goto a; }
		b = 1;

		for (x = 1; x <= n; x++)
			for (y = 1; y <= n; y++)
				if (c1[n + 1 - x][n + 1 - y] != c2[x][y]) { b = 0; }
		if (b) { printf("2"); goto a; }
		b = 1;

		for (x = 1; x <= n; x++)
			for (y = 1; y <= n; y++)
				if (c1[n + 1 - y][x] != c2[x][y]) { b = 0; }
		if (b) { printf("1"); goto a; }
		else printf("-1");
		a:
		if (T)
			putchar('\n');
	}

	return 0;
}