#include<stdio.h>
int main()
{
	int t;
	int mode,atk[10]={0};
	int o;
	int card[10];
	int sum=0;
	scanf("%d%d",&t,&mode);
	int isdie=0;
	int isexp=0;
	int min=10001;
	int flag=0;
	for(int i=0;i<t;i++){
		scanf("%d",&card[i]);
		if(card[i]==0){
		scanf("%d",&o);
		if(o<min)
		min=o;
		atk[i]=o;
		sum+=atk[i];
	}
	}
	if(sum>2100&&mode==1)
		isdie=1;
	if(sum>=2500&&mode==0)
		isdie=1;
	if(isdie==0){
	printf("QAQ\n");
	goto a;
	}
	isdie=0;
	
	if(t>=3){
		for(int i=0;i<t;i++){
			if(card[i]==2&&((mode==1&&sum-min>2100)||(mode==0&&sum-min>=2500))){
			printf("haoye\n");
			flag=1;
			goto a;
		}
		}
		for(int i=0;i<t;i++){
			if(card[i]==1){
			printf("haoye\n");
			flag=1;
			break;
		}
		}
		if(flag==0){
			printf("QAQ\n");
		}
	}
	else{
		for(int i=0;i<t;i++){
			if(card[i]==1){
			printf("haoye\n");
			flag=1;
			break;
		}
		}
		if(flag==0){
			printf("QAQ\n");
		}
	}
	a:
	return 0;
}
