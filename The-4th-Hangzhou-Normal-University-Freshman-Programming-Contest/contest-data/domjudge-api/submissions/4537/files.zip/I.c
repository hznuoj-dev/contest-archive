#include<stdio.h>
#include<string.h>
#include<stdlib.h>	
int comp(const void *a, const void *b) {
//  	return (*(int*)a) > (*(int*)b) ? 1 : -1;//��������
	return (*(int*)a) > (*(int*)b) ? -1 : 1;//�������� 
}

int main() {
	
	struct song {
		int w;
		char s[16];
	};
	struct song p[100001];
	
	int n;
	int i,k,j;
	
	int temp1;
	char temp2;
	
	scanf("%d",&n);
	for(i=0;i<n;i++) {
		scanf("%d %s",&p[i].w,p[i].s);
	}
	
	qsort(p,n,sizeof(struct song),comp);//����
	
	scanf("%d",&k);
	
	printf("%s",p[k].s);
	
	return 0;
}
