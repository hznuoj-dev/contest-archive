#include<stdio.h>
int main()
{
	int n;
	int i;
	char s[]="Welcome to HZNU";
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		printf("%s\n",s);
	}
	return 0;
 } 
