#include<stdio.h>
#include<stdlib.h>
struct cnm {
	int cd;
	char name[1000];
}; struct cnm shn[100];
int comp(const void* p, const void* q);
int main()
{
	int T,i,sl;
	scanf("%d", &T);
	for (i = 1; i <= T; i++) {
		scanf("%d %s", &shn[i].cd, shn[i].name);
	}
	qsort(shn, T, sizeof(struct cnm), comp);
	scanf("%d", &sl);
	printf("%s",shn[sl].name);
	return 0;
}
int comp(const void* p, const void* q) {
	return ((struct cnm*)p)->cd - ((struct cnm*)q)->cd;
}