#include<stdio.h>
#include<string.h>
struct music
{
	int love;
	char m[200];
}sing[100005];

int main()
{
	int n,i,j,k,m;
	char s[20];
	scanf("%d",&n);
	i=1;
	for(i=1;i<=n;++i)
	{
		scanf("%d %s",&sing[i].love,sing[i].m);
	}
	scanf("%d",&k);
	for(i=1;i<=k+1;++i)
	{
		for(j=n;j>i;--j)
		{
			if(sing[j].love>sing[j-1].love)
			{
				m=sing[j].love;sing[j].love=sing[j-1].love;sing[j-1].love=m;
				strcpy(s,sing[j].m);strcpy(sing[j].m,sing[j-1].m);strcpy(sing[j-1].m,s);
			}
		}
	}
	printf("%s",sing[k+1].m);
	return 0;
}
