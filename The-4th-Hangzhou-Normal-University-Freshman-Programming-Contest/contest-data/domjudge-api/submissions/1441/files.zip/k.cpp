#include<bits/stdc++.h>
using namespace std;

int main(){
	int t;
	cin >>t;
	while(t--){
		cout << "Welcome to HZNU\n";
	} 


return 0;
}

