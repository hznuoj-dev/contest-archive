#include <stdio.h>
#include <string.h>
int main(void){
	int t, i, j;
	scanf("%d",&t);
	while(t--){
		int flag[52];
		memset(flag,0,sizeof(flag));
		int n, ans=0, k, flag1=1;
		char s[100000];
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf(" %c",&s[i]);
			if(s[i]>='A'&&s[i]<='Z')
				k=s[i]-65;
			if(s[i]>='a'&&s[i]<='z')
				k=s[i]-71;
			flag[k]++;
		}
		for(j=0;j<52;j++){
			if(flag[j]%2==0){
				ans+=flag[j];
			}
			else if(flag1){
				ans+=1;
				flag1=0;
			}
		}
		printf("%d\n",ans);
	}
}

