#include<stdio.h>
struct ge{
	int love;
	char name[20];
};
int main(){
	int n,k,i,j;
	scanf("%d",&n);
	struct ge a[n];
	struct ge t;
	for(i=1;i<=n;i++)scanf("%d%s",&a[i].love,a[i].name);
	scanf("%d",&k);
	for(i=1;i<=n-1;i++){
		for(j=1;j<=n-i-1;j++){
			if(a[i].love<a[i+1].love){
				t.love =a[i+1].love;
				a[i+1].love =a[i].love;
				a[i].love =t.love ;
			}
		}
	}
	printf("%s",a[n-k].name);
	return 0;
}
