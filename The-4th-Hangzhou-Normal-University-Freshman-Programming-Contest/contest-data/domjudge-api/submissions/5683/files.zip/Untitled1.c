#include <stdio.h>
int i,n,m,s1,s2,flag;
int l1=1,l2=1,win=1;
int main(void){
	scanf("%d%d",&n,&m);
	if(m==1)
	{
		s1=2101;
	}
	else
		s1=2500;
	for(i=0;i<n;i++)
	{
		scanf("%d",&flag);
		if(flag==0)
		{
		scanf("%d",&s2);
			if(s1<=s2)
			{
				l1=0;
			}
		}
		if(flag==1)
		{
			l2=0;
		}
		if(flag==2)
		{
			if(n>1)
			win=0;
		}	
	}
	if(l1==0&&l2==0){win=0;}
	if(win==0){printf("haoye\n");}
	else printf("QAQ\n");
	return 0;
}
