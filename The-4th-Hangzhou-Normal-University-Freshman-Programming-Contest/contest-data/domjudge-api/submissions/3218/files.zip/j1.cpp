#include<stdio.h>
int main(void){
	int n,m,gongji[100],zl[100],flag=0,k=0,h=0;
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++){
		scanf("%d",&zl[i]);
		if(zl[i]==0){
			scanf("%d",&gongji[i]);
		}
	}
		if(n==1)
	printf("QAQ");
	else if(n>1){
	
for(int i=0;i<n;i++){
	 if(zl[i]==2)
	 flag++;
    }
if(flag>0)
		printf("haoye");
	else {
		flag=0;
		for(int i=0;i<n;i++){
	if(zl[i]==0){
		if(gongji[i]>=2500&&m==0)
		flag++;
		if(gongji[i]>=2100&&m==1)
		flag++;
	}
	if(zl[i]==1)
	h++;
	if(flag>=1&&h>=1){
	k++;
	printf("haoye");
	}
	}
	if(k==0)
	printf("QAQ");
}
}

	}

