#include<stdio.h>
#include<math.h>
int main(){
	int n,m,i,j,a,b,s,k;
	scanf("%d %d",&n,&m);
	int a[n][m];
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			for(k=j+1;k<m;k++){
				s=fabs(a[i][j]-a[i][k]);
			}
		}
	}
}
