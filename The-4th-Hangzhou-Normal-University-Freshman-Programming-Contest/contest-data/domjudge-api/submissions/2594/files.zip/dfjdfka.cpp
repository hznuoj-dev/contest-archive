#include<bits/stdc++.h>
using namespace std;
const int N=2e5;
bool ok1,ok2,ok3;
void solve(){
	int n,m,k;cin>>n>>m;
	int a,b;
	for(int i=0;i<n;i++){
		cin>>a;
		if(a==0){
			cin>>b;
			if(m==0 and b>=2500)ok1=true;
			if(m==1 and b>=2100)ok1=true;
		}
		if(a==1)ok2=true;
		if(a==2)ok3=true;
	}
	if(ok3&&n>=2||ok1&&ok2)cout<<"haoye";
	else cout<<"QAQ";
}
int main(){
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
}
