#include<stdio.h>
char b[100000][10];
int main(){
	int t;
	int o[100000]={0};
	int a,p=0;
	scanf("%d",&t);
	for(int z=0;z<t;z++){
		for(int j=0;j<100000;j++){
			o[j]=0;
		} 
		getchar();
		p=0;
		scanf("%d",&a);
		for(int j=0;j<a;j++){
			scanf("%s",b[j]);
		}
		for(int j=0;j<a;j++){
			for(int i=0;i<a;i++){
				if(j!=i){
					if(b[j][0]==b[i][0]&&o[j]!=1&&o[i]!=1){
						p+=1;
						o[j]=1;
						o[i]=1;
						break;
					}
				}
			}
		}
		if(a>p*2){
			printf("%d\n",p*2+1);
		}
		else{
			printf("%d\n",p*2);
		}
	}
	return 0;
} 
