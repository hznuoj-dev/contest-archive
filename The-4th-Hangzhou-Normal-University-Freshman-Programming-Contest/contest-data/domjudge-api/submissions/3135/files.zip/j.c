#include <stdio.h>
#include <math.h>
#include <string.h>
int pi=100005;
typedef struct{
	int zl;
	int ds;
}KP;
int main(){ 
    KP tmp[pi];
    int n,m,f,i,k=0,z=0,h=0;
    scanf("%d %d",&n,&m);
    if(m==0){
    	f=2500;
	}else{
		f=2100;
	}
	for(i=1;i<=n;i++){
		scanf("%d",&tmp[i].zl);
		if(tmp[i].zl==0){
			scanf("%d",&tmp[i].ds);
		}
		if(tmp[i].zl==2){
			k=1;
		}else if(tmp[i].zl==1){
			h=1;
		}
	}
	if(k==1){
		if(n>=2){
			printf("haoye");
		}else{
			printf("QAQ");
		}
	}else if(h==1){
		if(n<2){
			printf("QAQ");
		}else{
			for(i=1;i<=n;i++){
				if(tmp[i].zl==0){
					if(tmp[i].ds>=f){
						z=1;
						break;
					}
				}
			}
			if(z==0){
				printf("QAQ");
			}else{
				printf("haoye");
			}
		}
	}else{
		printf("QAQ");
	}
	return 0;
}


