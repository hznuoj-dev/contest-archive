#include<stdio.h>
int ai[100000];
char ge[100000][15];
main()
{
	int n,a,i=0,j,k;
	int pai=0;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&ai[i],&ge[i]);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++)
	{
		pai=0;
		for(j=0;j<n;j++)
		{
			if(ai[i]>ai[j])
				pai++;
		}
		if(pai==n-k-1)
		{
			printf("%s\n",ge[i]);
			break;
		}
	}
}