#include<stdio.h>
struct mus {
	long long int num;
	char name[16];
};
int main() {
	struct mus ge[100001],t[100001];
	int n,;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%lld%s", &ge[i].num, ge[i].name);
	}
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			if (ge[j] < ge[j + 1]) {
				t[j] = ge[j];
				ge[j]= ge[j + 1];
				ge[j + 1]= t[j];
			}
		}
	}
	int k;
	scanf("%d", &k);
	printf("%s", ge[k + 1].name);

	