#include <stdio.h>

int main(void){
	int t,n,i,j,ans,count1,count2,count3,count4;
	int a[20][20],b[20][20];
	scanf("%d",&t);
	while(t--){
		count1=0;
		count2=0;
		count3=0;
		count4=0;
		scanf("%d",&n);
		for(i=0;i<n;++i){
			for(j=0;j<n;++j){
				scanf("%d",&a[i][j]);
			}
		}
		for(i=0;i<n;++i){
			for(j=0;j<n;++j){
				scanf("%d",&b[i][j]);
			}
		}
		if(n==1){
			if(a[0][0]==b[0][0]){
				if(t!=0){
					printf("-1\n");
				}
				else{
					printf("-1");
				}
			}
			else{
				if(t!=0){
					printf("0\n");
				}
				else{
					printf("0");
				}
			}
		}
		else{
			for(i=0;i<n;++i){
				for(j=0;j<n;++j){
					if(a[i][j]==b[n-1-j][i]){
						count1++;
					}
					else if(a[i][j]==b[n-1-i][n-1-j]){
						count2++;
					}
					else if(a[i][j]==b[j][n-1-i])
						count3++;
					else if(a[i][j]==b[i][j])
						count4++;
				}
			}
			if(count1==(n*n)){
				ans=1;
				if(t!=0)
				printf("%d\n",ans);
				else
				printf("%d",ans);
			}
			else if(count2==(n*n)){
				ans=2;
				if(t!=0)
				printf("%d\n",ans);
				else
				printf("%d",ans);
		}
			else if(count3==(n*n)){
				ans=1;
				if(t!=0)
				printf("%d\n",ans);
				else
				printf("%d",ans);
			}
			else if(count4==(n*n)){
				ans=0;
				if(t!=0)
				printf("%d\n",ans);
				else
				printf("%d",ans);
			}
			else{
				ans=-1;
				if(t!=0)
				printf("%d\n",ans);
				else
				printf("%d",ans);
			}
		}
	}
    return 0;
}

