#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

struct kaipai {
	int x;
	int k;
};

int main() {
	int n, m, flag1 = 0, flag2 = 0, flag3 = 0;
	struct kaipai a[11];
	scanf("%d %d", &n, &m);
	for (int i = 0; i < n; i++) {
		scanf("%d", &a[i].x);
		if (a[i].x == 0) {
			scanf("%d", &a[i].k);
		}
	}
	for (int i = 0; i < n; i++) {
		if (n > 1) {
			if (a[i].x == 0) {
				if (m == 0) {
					if (a[i].k >= 2500) {
						for (int j = 0; j < n; j++) {
							if (a[j].x == 1) {
								flag1 = 1;
								break;
							}
						}
					}
				} else {
					if (a[i].k > 2100) {
						for (int j = 0; j < n; j++) {
							if (a[j].x == 1) {
								flag2 = 1;
								break;
							}
						}
					}
				}

			}
		}
		if (a[i].x == 2) {
			if (n > 1) {
				flag3 = 1;
			} else {
				flag3 = 0;
			}
		}

	}
	if (flag1 == 1 || flag2 == 1 || flag3 == 1) {
		printf("haoye");
	} else {
		printf("QAQ");
	}
}