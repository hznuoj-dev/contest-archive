#include<stdio.h>
int main(void)
{
	int a,b,c,d;
	scanf("%d%d",&a,&b);
	int n,m,g=0,h,l,o=0;
	if(b==0)
	{
		b=2500;
	}
	else{
		b=2100;
	}
	int x[a];
	for(c=0;c<a;c++)
	{
		scanf("%d",&x[c]);
		if(x[c]==0)
		{
			scanf("%d",&h);
			if(h>=b)
			{
				o=1;
			}
			
		}
		if(x[c]==1)
		{
			if(o==1)
			{
				g=1;
			}
		}
		if(x[c]==2)
		{
		
				if(a>=2)
				{
					g=1;
				}
			
		}
	}
	if(g==1)
	{
		printf("haoye");
	}
	else{
		printf("QAQ");
	}
	return 0;
	
}
