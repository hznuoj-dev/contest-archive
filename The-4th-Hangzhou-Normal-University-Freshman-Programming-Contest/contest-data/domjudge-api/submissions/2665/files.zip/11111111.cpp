#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
int main (){
	long int m,n,i,j;
	scanf("%ld %ld",&n,&m);
	long int a[n][m];
	for(i=0;i<n;i++){
		for(j=0;j<m;j++){
			scanf("%ld",&a[i][j]);
		}
	}
	long int min,k,jm;
	min=fabs(a[0][0]-a[1][0]);
	for(i=0;i<n;i++){
		for(jm=0;jm<m;jm++){
			for(k=i+1;k<n;k++){
				for(j=0;j<m;j++){
					if(fabs(a[i][jm]-a[k][j])<min){
						min =fabs(a[i][jm]-a[k][j]);
					}
				}
			}
		}
	}
	printf("%ld",min);
	return 0;
} 
