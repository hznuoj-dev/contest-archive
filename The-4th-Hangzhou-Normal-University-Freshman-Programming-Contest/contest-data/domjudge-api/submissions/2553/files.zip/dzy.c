#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
struct p
{
	long long love;
	char song[100];
}all[100005],temp;
int n, i, j;
int main()
{
	int done;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%lld %[^\n]", &all[i].love, all[i].song);
	}
	scanf("%d", &done);
	for(i=0;i<n;i++)
		for (j = i; j < n - i - 1; j++)
		{
			if (all[j].love < all[j+1].love)
			{
				temp = all[j];
				all[j] = all[j + 1];
				all[j + 1] = temp;
			}
		}
	printf("%s\n", all[done].song);
	return 0;
}