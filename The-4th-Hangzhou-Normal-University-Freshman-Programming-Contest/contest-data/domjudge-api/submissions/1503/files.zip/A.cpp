#include<stdio.h>
int main(){
	int t;
	int a,p=0;
	scanf("%d",&t);
	for(int z=0;z<t;z++){
		getchar();
		p=0;
		scanf("%d",&a);
		char b[a][2];
		for(int j=0;j<a;j++){
			scanf("%s",&b[j]);
		}
		for(int j=0;j<a;j++){
			for(int i=0;i<a;i++){
				if(j!=i){
					if(b[j][0]==b[i][0]){
						p+=1;
					}
				}
			}
		}
		if(a>p){
			printf("%d\n",p+1);
		}
		else{
			printf("%d\n",p);
		}
	}
	return 0;
} 
