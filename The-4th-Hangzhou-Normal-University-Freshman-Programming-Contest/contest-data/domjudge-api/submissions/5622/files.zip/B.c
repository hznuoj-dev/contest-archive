#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int T,n,sum1=0,sum2=0,k=0,i;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		int a[n];
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			sum1+=a[i];
			if(sum1==7777){
				k++;
			}	
		}
		for(i=n-1;i>=0;i--){
			sum2+=a[i];
			if(sum2==7777){
				k++;
			}
		}
		printf("%d\n",k);
	}
	return 0;
}
