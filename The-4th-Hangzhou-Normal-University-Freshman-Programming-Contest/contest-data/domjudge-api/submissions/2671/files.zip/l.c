#include<stdio.h>
#include<stdlib.h>
struct wzy{
	long long int id;
	char zjh[16];
}tt[100001];
int cmp( const void *a,const void *b){
	return ((struct wzy *)a)->id-((struct wzy *)b)->id;}
int main()
{
	int n,i,j,num;
	struct wzy max;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld",&tt[i].id);
		getchar();
		gets(tt[i].zjh);
		
	}
	qsort(tt,n,sizeof(tt[0]),cmp);
	scanf("%d",&num);
	
		printf("%s\n",tt[n-num-1].zjh);
	return 0;
}