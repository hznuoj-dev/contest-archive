#include<stdio.h>
#define atk 2500
#define def 2100
int main(){
	int n,m,x;
	int gsk[10]={0},jnk[10]={0},b=0;
	scanf("%d %d",&n,&m);
	for(x=0;x<n;x++){
		scanf("%d",&jnk[x]);
		if(jnk[x]==0){
			scanf("%d",&gsk[x]);
		}
	}
	for(x=0;x<n;x++){
		if(jnk[x]==2&&n>1){
			printf("haoye\n");
			break;
		}
	}
	if(m==0){
		for(x=0;x<n;x++){
			if(gsk[x]>=atk){
				b=1;
			}
		}
		for(x=0;x<n;x++){
			if(jnk[x]==1&&b==1){
				printf("haoye\n");
				break;
			}
		}
	}
	else{
		for(x=0;x<n;x++){
			if(gsk[x]>def){
				b=1;
			}
		}
		for(x=0;x<n;x++){
			if(jnk[x]==1&&b==1){
				printf("haoye\n");
				break;
			}
		}
	}
	printf("QAQ\n");
	return 0;
}
