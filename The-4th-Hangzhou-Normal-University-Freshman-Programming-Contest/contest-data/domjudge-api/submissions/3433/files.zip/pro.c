#include<stdio.h>
int main(){
	struct sing{
		int x;
		char str[16];
	};
	struct sing s[100001];
	struct sing t;
	int n,i,k,j,l;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&s[i].x,s[i].str);	
	}
	scanf("%d",&k);
	printf("%s",s[n-k-1].str);
	return 0;
}
