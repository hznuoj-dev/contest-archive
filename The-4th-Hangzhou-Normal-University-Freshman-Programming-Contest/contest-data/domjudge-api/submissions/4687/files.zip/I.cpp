#include<stdio.h>
#include<stdlib.h>
struct gequ{
  long long int redu; 
  char name[15];
};
int comp(const void*p,const void*q){
     return ((struct gequ*)p)->redu<((struct gequ*)q)->redu?1:-1;
}
struct gequ a[100000];
int main(){
 int T,k;
 scanf("%d",&T);
 for(int i=0;i<T;i++){
  scanf("%lld %s",&a[i].redu,a[i].name);
 }
/* for(int i=1;i<=T;i++){
	 for(int j=T;j>i;j--){
		 if(a[j].redu>a[j-1].redu){
		   struct gequ temp;
		   temp=a[j];
		   a[j]=a[j-1];
		   a[j-1]=temp;
		 }
	 }
 }*/
 qsort(a,T,sizeof(struct gequ),comp);
 scanf("%d",&k);
 printf("%s\n",a[k].name);
}

/*#include<stdio.h>
#include<string.h>
long long int a[100001];
char name[100001][15];
int main(){
  int n;
  int k;
  scanf("%d",&n);
  for(int i=1;i<=n;i++){
   scanf("%lld %s",&a[i],name[i]);
  }
  for(int i=1;i<=n;i++){
	 for(int j=n;j>i;j--){
		 if(a[j]>a[j-1]){
		   long long int temp;
		   temp=a[j];
		   a[j]=a[j-1];
		   a[j-1]=temp;
		   char name1[15];
		   strcpy(name1,name[j]);
		   strcpy(name[j],name[j-1]);
		   strcpy(name[j-1],name1);
		 }
	 }
 }
  scanf("%d",&k);
 printf("%s\n",name[k+1]);
}*/