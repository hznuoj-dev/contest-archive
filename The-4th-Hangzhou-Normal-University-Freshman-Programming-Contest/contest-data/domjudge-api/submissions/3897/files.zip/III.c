#include<stdio.h>
#include<stdlib.h>
int cmp(const void*a,const void*b);
struct t{
	int w;
	char s[16];
};
int main(){
	int n;
	scanf("%d",&n);
	struct t ta[n];
	int i;
	for(i=0;i<n;i++){
		scanf("%d %s",&ta[i].w,ta[i].s);
	}
	int k;
	scanf("%d",&k);
	qsort(ta,n,sizeof(struct t),cmp);
	printf("%s",ta[k].s);
}
int cmp(const void*a,const void*b){
	struct t *p1=(struct t*)a;
	struct t *p2=(struct t*)b;
	return p2->w-p1->w; 
}
