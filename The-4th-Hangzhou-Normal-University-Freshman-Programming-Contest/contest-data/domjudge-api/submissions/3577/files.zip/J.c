#include<stdio.h>
main(){
	int k,i,n,m,s,max,mag1=0,mag2=0;
	scanf("%d %d",&n,&m);
	max=0;
	for(i=0;i<n;i++)
	{
		scanf("%d",&k);
		if(k==1)
			mag1++;
		if(k==2)
			mag2++;
		if(k==0)
		{
			scanf("%d",&k);
			if(k>max)
				max=k;
		}
	}
	if(n>=2&&mag2!=0)
		printf("haoye\n");
	else if(m==1&&max>=2500&&mag1!=0)
		printf("haoye\n");
	else if(m==0&&max>2100&&mag1!=0)
		printf("haoye\n");
	else
		printf("QAQ\n");
}
