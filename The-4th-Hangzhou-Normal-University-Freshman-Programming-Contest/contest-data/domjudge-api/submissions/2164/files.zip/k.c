#include<stdio.h>    
#include<stdlib.h>
int main()
{
	int t;
	long long n,x;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		scanf("%d%d",&n,&x);
		int flag=0;	
		if(x!=0)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
} 
