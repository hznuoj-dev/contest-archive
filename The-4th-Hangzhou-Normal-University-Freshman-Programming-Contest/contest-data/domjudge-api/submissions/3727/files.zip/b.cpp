#include<stdio.h>
struct song {
	int x;
	char y;
};
int main() {
	int n,i,k,j;
	struct song sing[10001];
	struct song temp[1];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d %s", &sing[i].x, sing[i].y);
	}
	scanf("%d", &k);
	for(i=0;i<n-1;i++)
		for(j=0;j<n-i-1;j++)
			if (sing[j].x > sing[j + 1].x) {
				temp[0] = sing[j];
				sing[j] = sing[j + 1];
				sing[j + 1] = temp[0];
			}
	printf("%s", sing[n-k-1].y);
	return 0;
}