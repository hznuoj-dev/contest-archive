#include<stdio.h>
int main(){
	int t,i,flag;
	int a,b;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&a,&b);
		if(b==0){
			printf("no\n");
		}
		else{
			printf("yes\n");
		}
		
	}
	return 0;
}
