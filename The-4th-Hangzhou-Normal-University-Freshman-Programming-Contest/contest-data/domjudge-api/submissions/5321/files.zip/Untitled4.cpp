#include<stdio.h>
#include<stdlib.h>
int cmp(const void*a,const void*b){
	return *(int *)a-*(int *)b;
}
int main(){
int a[100010];// int b[100010];
char s[100010][16];
	int n;
	int *b;
	b = (int *)malloc(100010*sizeof(int));
	scanf("%d",&n);
	for(int i =0;i<n;i++){
	scanf("%d %s",&a[i],s[i]);
    b[i] = a[i];
}
	qsort(a,n,sizeof(a[0]),cmp);
	int x;
	int m =0;
	scanf("%d",&x);
	int re = a[n-x-1];
	for(int k = 0;k<n;k++)
	{
		if(b[k]==re){
			m = k;
			break;
		}
		
	 } 
	printf("%s",s[m]);
//	free(b);
}
