#include<stdio.h>
struct letter
{
	char x[100000];
	int y[100000] = { 1 };
};
int main(void) {
	int T, n, i;
	char a;
	scanf("%d", &T);
	for (int i = 0; i < T; i++)
	{
		scanf("%d", &n);
		for (int j = 0; j < n; j++)
		{
			scanf("%c", letter.x[j]);
		}
		for (int a = 1;a < n;a++) {
			{
				if ((letter.x[a])==(letter.x[0]))
				{
					letter.y[0] += 1;
				}
				else
				{
					letter.y[a] += 1;
				}
			}
		}
	}
	int sum = 0;
	int time = 0;
	for (int b = 0; b < n; b++) {
		if ((letter.y[b])%2 == 0)
		{
			sum += letter.y[b];
		}
		else
		{
			sum += letter.y[b];
			sum -= 1;
			time += 1;
		}

	}
	if (time > 0)
	{
		sum += 1;
	}
	printf("%d", sum);
	return 0;
}
