#include<stdio.h>
#include<string.h>
typedef struct{    
	int n;
	char ch;
}C;

int main(){
	int t,l;
	scanf("%d",&t);
	for(l=0;l<t;l++)
	{
		int n;
		int m,x,c;
		int y=0;
		char abc;
		char qwe;
		scanf("%d",&n);
		getchar();
		char a[n];
		for(m=0;m<n;m++)
		{
			if(m==n-1)scanf("%c",&a[m]);
			else scanf("%c ",&a[m]);
		}
		C b[100001];
		for(m=0;m<n;m++)
		{
			b[m].n=0;
		}
		b[0].ch=a[0];
		b[0].n=1;
		for(m=1;m<n;m++)
		{
			c=0;
			for(x=0;x<m;x++)
			{
				if(a[m]==a[x])
				{
				    b[x].n=b[x].n+1;
				    c=1;
				    break;
				}
			}
			if(c==0)
			{
				b[m].n=1;
				b[m].ch=a[m];
			}
		}
		for(m=0;m<n;m++)
		{
			if(b[m].n>=2)y=y+b[m].n-b[m].n%2;
		}
		for(m=0;m<n;m++)
		{
			if(b[m].n%2==1)
			{
			  y=y+1;
			  break;
		    }
		}
		printf("%d\n",y);
	}
	return 0;
}
