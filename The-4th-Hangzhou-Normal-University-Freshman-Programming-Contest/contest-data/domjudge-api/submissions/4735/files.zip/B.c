#include<stdio.h>
int main(void){
	int t, n, a[5000], sum, ans, i, j, k, flag=0, m=0;
	scanf("%d", &t);
	while(t--){
		sum=0;
		ans=0;
		scanf("%d", &n);
		for(i=0;i<n;++i){
			scanf("%d", &a[i]);
		}
		for(i=0;i<n;++i){
			flag=0;
			sum=0;
			for(j=i+1;j<n;++j){
				/*sum+=a[j];
				if(sum==7777){ans++;}
				else if(sum>7777){break;}
				*/
				sum=0;
				for(k=i;k<=j;++k){
					sum+=a[k];
					if(sum==7777){ans++;goto loop;printf("i, j=%d %d\n", i, j);}//
					else if(sum>7777){break;goto loop;}
									
				}
			}//j end;
				loop: 
				m=1;
		}
		printf("%d", ans);
	}
	return 0;
}
