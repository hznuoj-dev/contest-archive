#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<cmath>
#include<cctype>
using namespace std;
int main(){
int t;
cin>>t;
long int n,x;
while(t--){

cin>>n>>x;
if(x==0)cout<<"no"<<endl;
else{cout<<"yes"<<endl;
}
} }
