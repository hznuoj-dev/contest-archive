#include<bits/stdc++.h>
using namespace std;
const int N=2e5;
string a[N];
void solve(){
	string s;
	char ch;
	int cnt=0;
	while(cin>>s){
		bool ok=1;
		ch=s[s.size()-1];
		if(ch>='a'&&ch<='z'||ch>='A'&&ch<='Z'||ch>='0'&&ch<='9')ok=0;
		if(ok){
			s.erase(s.size()-1);
			a[++cnt]=s;
			break;
		}
		a[++cnt]=s;
	}
	int l=1,r=cnt;
	vector<string>ans;
	while(l<=r){
		ans.push_back(a[l]);
		ans.push_back(a[r]);
		l++,r--;
	}
	for(int i=0;i<cnt-1;i++)
		cout<<ans[i]<<' ';
	cout<<ans[cnt-1]<<ch<<'\n';
}
int main(){
	int t=1;
	cin>>t;
	while(t--){
		solve();
	}
}
