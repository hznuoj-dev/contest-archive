#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,i;
	cin>>n;
	for(i=1;i<=n;i++){
	cout<<"Welcome to HZNU\n";
	}
	return 0;
}
