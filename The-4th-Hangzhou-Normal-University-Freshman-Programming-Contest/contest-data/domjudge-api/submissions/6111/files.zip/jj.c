#include<stdio.h>

int main(void){
	int n,m,i,k,c1,c2;
	scanf("%d%d",&n,&m);
	int a[n],flag1=0,flag2=0,flag3=0;
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
			if(a[i]==0&&m==0){
				scanf("%d",&k);
				if(k>=2500)
				flag1=1;
			}
			if(a[i]==0&&m==1){
				scanf("%d",&k);
				if(k>2100)
				flag1=1;
			}
			if(a[i]==1) flag2=2;
			if(a[i]==2) flag3=3;
		}
		if(flag1==1&&flag2==2)
		printf("haoye");
		else if(n>=2&&flag3==3) 
		printf("haoye");
		else printf("QAQ");
	return 0;
}

