#include<stdio.h>
#include<stdlib.h>
#define A 100000
struct song{
	long long int xx;
	char arr[200];
};
int comp(const void *p, const void *q)
{
	return ((struct song *)q)->xx - ((struct song *)p)->xx;
}
int main()
{
	int arr1[101] = { 0 };
	char arr2[21][101] = { 0 };
	int arr3[21] = { 0 };
	int arr4 = 0;
	struct song aa[A];
	long long int j, k;
	scanf("%lld", &j);
	for (int i = 0; i<j; i++){
		scanf("%lld%s", &aa[i].xx, aa[i].arr);
	}
	scanf("%lld", &k);
	qsort(aa, j, sizeof(struct song), comp);
	printf("%s\n", aa[k].arr);

}