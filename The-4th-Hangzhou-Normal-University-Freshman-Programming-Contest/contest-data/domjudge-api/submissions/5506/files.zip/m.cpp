#include<bits/stdc++.h>
using namespace std;
char s[1010][40];
int main(){
	int t;
	cin>>t;
	char b;

	for(int i=0;i<t;i++){
		getchar();
		int j=0,k=0,sum=0;
		scanf("%c",&s[j][k]);
		while((s[j][k]>='a' && s[j][k]<='z') || (s[j][k]>='A' && s[j][k]<='Z') || (s[j][k]>='0' && s[j][k]<='9') || s[j][k]==' '){
			if(s[j][k]==' '){
				s[j][k]='\0';
				j++;
				k=0;
				scanf("%c",&s[j][k]);
				sum++;
			}
			else{
				k++;
				scanf("%c",&s[j][k]);
			}
		}
		sum++;
		b=s[j][k];
		s[j][k]='\0';
		j=0;
		for(j=0;j<sum/2-1;j++){
			cout<<s[j]<<' '<<s[sum-j-1]<<' ';
		}
		cout<<s[j]<<' '<<s[sum-j-1];
		if(sum%2==1){
			cout<<' '<<s[sum/2]<<b<<'\n';
		}
		else{
			cout<<b<<'\n';
		}
	}
	return 0;
}
