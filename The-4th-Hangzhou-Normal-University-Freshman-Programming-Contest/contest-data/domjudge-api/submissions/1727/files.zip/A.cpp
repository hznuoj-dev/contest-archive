#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
const int maxn=100010;
int a[maxn];
int main(){
	int T;
	cin>>T;
	while(T--){
		int n;
		cin>>n;
		vector<int> vec;
		int count=0;
		for(int i=0;i<n;i++){
			int a;
			scanf("%d",&a);
			if(a<=7777) vec.push_back(a);
		}
		for(int i=0;i<vec.size();++i){
			int ans=0;
			for(int j=i;j<vec.size();++j){
				ans+=vec[j];
				if(ans>7777) break;
				if(ans==7777) count++;
			}
		}
		cout<<count<<endl;
	}
	return 0;
}
 
