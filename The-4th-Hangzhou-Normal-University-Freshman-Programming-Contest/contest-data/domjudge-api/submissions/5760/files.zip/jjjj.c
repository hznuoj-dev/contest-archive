#include<stdio.h>
int main(void){
	int n,m;
	int flag=0,flag2,flag3;
	scanf("%d %d",&n,&m);
	int x[n];
	int a[n];
	int t=n;
	int i=n;
	while(n--){
		scanf("%d",&x[t-n]);
		if(x[t-n]==0){
		scanf("%d",&a[t-n]);
	}
	if(m==0&&a[t-n]>=2500||m==1&&a[t-n]>2100){
		flag=1;
}
	
	else if(x[n-t]==1){
		if(flag){
			flag2=1;
			flag3=1;
		}
		}
		else if(flag3&&flag)
			flag2=1;
		}
	if(n==0||n==1)
	 printf("QAQ\n");
 else {
 while(i--){
		if(x[n-i]==2||flag2){
				printf("haoye\n");
				break;
			}
		}
		if(n-i==n) printf("QAQ\n");
	}
return 0;
}
