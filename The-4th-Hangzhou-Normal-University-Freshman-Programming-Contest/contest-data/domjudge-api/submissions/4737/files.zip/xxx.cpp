#include<stdio.h>
int main() {
	int t;
	int x, y;
	int a;
	int n;
	scanf("%d", &t);
	while (t--) {
		a = 0;
		scanf("%d%d", &n, &y);
		x = 0;
		for (int i = 0; i < 100; i++) {
			if (x + y >= n) {
				x = x + y - n;
			}
			x += y;
			if (x == 0) {
				a = 1;
				break;
			}
		}
		if (a == 0) {
			printf("yes\n");
		}
		if (a == 1) {
			printf("no\n");
		}
	}
	return 0;
}