#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
int a1[30][30],a2[30][30];
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		long long a,b,k,kk=1;
		scanf("%lld%lld",&a,&b);
		if(b==0) printf("no\n");
		else{
			for(k=1;k<=a+1;k++){
				kk=kk+a;
				if(kk%b==1){
					printf("yes\n");
					break;
				}
				if(kk>a){
					kk=kk%b;
				}
			}
			if(k>a+1) printf("no\n");
		}
	}
	return 0;
}
