#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
const int maxn=100010;
int a[maxn];
int main(){
	int T;
	cin>>T;
	while(T--){
		int n;
		cin>>n;
		int count=0;
		for(int i=0;i<n;i++){
			cin>>a[i];
		}
		for(int i=0;i<n;++i){
			int ans=0;
			for(int j=i;j<n;++j){
				ans+=a[j];	
				if(ans==7777) count++;
			}
		}
		cout<<count<<endl;
	}
	return 0;
}
 
