#include <stdio.h>
int main()
{
	int n,m;
	int k[20];
	int x[20];
	scanf("%d%d",&n,&m);
	int i;
	int flag1,flag2,flag3;
	flag1 = flag2 = flag3 = 0;
	for(i=0;i<n;++i)
	{
		scanf("%d",&x[i]);
		if(x[i]==0)
		{
			scanf("%d",&k[i]);
			
		}
		if(x[i]==1)
			flag2 = 1;
		if(x[i]==2)
			flag3 = 1;
		
	}
	if(flag3==1 && n > 1)
	printf("haoye\n");
	else
	{
		if(flag2 == 0)
		{
			printf("QAQ\n");
		}
		else
		{
			if(m==0)
			{
				for(i=0;i<n;++i)
				{
					if(x[i]==0 && k[i] >= 2500)
					{
						printf("haoye\n");
						flag1 = 1;
						break;
					}
				}
				if(flag1 == 0)
				{
					printf("QAQ\n");
				}
			}
			else
			{
				for(i=0;i<n;++i)
				{
					if(x[i]==0 && k[i] > 2100)
					{
						printf("haoye\n");
						flag1 = 1;
						break;
					}
				}
				if(flag1 == 0)
				{
					printf("QAQ\n");
				}
			}
		}
	}
	
	return 0;
}
