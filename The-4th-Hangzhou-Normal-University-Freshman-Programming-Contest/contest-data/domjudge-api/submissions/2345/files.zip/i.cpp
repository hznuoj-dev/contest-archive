#include<iostream>
#include<map>
using namespace std;
multimap<int,string>mp;
int main()
{
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		int a;
		string b;
		cin>>a>>b;
		mp.insert(make_pair(a,b));
	}
	multimap<int,string>::iterator it=mp.end();
	it--;
	int m;
	cin>>m;
	for(int i=0;i<m;i++)
	{
		it--;
	}
	cout<<it->second<<endl;
		
	return 0;
}
