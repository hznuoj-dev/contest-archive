#include<stdio.h>
int main(){
	int T,n;
    scanf("%d",&T);
    while(T--){
    	printf("Welcome to HZNU\n");
	}
}
