#include<stdio.h>
int main() {
	int t;
	scanf_s("%d", &t);
	while (t--) {
		int a, b,c=0;
		scanf("%d%d", &a, &b);
		if (b == 0) { printf("no\n"); }
		for (int k = 1;k<100000; k++) {
				if ((k * a) % b == 0) { 
					c = 1;
					break;
				}
			}
		if (c == 1) { printf("yse\n"); }
		if (c == 0) { printf("no\n"); }
		}	

	return 0;
}
