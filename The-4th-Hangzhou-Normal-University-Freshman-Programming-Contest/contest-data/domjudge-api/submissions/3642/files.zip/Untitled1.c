#include <stdio.h>
#include <string.h>
int a[1000000];
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,m,i,k=0,j=0;
		memset(a,0,sizeof(a));
		scanf("%d %d",&n,&m);
		while(1){
			k=(k+m)%n;
			if(a[k]==1){
				printf("no\n");
				break;
			}
			else
				a[k]=1;
			if(k==0){
				printf("yes\n");
				break;
			}
		}
	}
}

