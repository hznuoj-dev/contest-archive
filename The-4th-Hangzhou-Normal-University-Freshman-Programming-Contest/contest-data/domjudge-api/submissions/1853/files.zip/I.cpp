#include <stdio.h>
#include <string.h>
int a[100005];
char s[100005][30];
void qsort(int l,int r)
{
	int i,j,m,p;
	char st[30];
	i=l; j=r;
	m=a[(l+r)/2];
	do
	{
		while (a[i]>m) i++;
		while (a[j]<m) j--;
		if (i<=j) 
		{
			p=a[i]; a[i]=a[j]; a[j]=p;
			strcpy(st,s[i]); strcpy(s[i],s[j]); strcpy(s[j],st);
			i++; j--;
		}
	}  while  (i<=j);
	if (l<j) qsort(l,j);
	if (i<r) qsort(i,r);
}

int main()
{
	int N,i,k;
	scanf("%d",&N);
	for (i=1; i<=N; i++) 
	{
		scanf("%d%s",&a[i],s[i]);
	}	
	qsort(1,N);
	scanf("%d",&k);
	printf("%s\n",s[k+1]);
} 
