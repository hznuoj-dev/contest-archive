#include<stdio.h>

int main(void){
	int n,m,i,k,c1,c2;
	scanf("%d%d",&n,&m);
	int a[n],flag=0,item=0;
	if(m==0){
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
			if(a[i]==0){
				scanf("%d",&k);
				if(k>=2500)
				flag=1;
			}
			if(a[i]==1) flag=1;
			if(a[i]==2) flag=2;
		}
		if(flag==1&&item==1)
		printf("QAQ");
		else if(n>=2&&flag==2) 
		printf("QAQ");
		else printf("haoye");
	}
	else if(m==1){
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
			if(a[i]==0){
				scanf("%d",&k);
				if(k>2100)
				flag=1;
			}
			if(a[i]==1) flag=1;
			if(a[i]==2) flag=2;
		}
		if(flag==1&&item==1)
		printf("QAQ");
		else if(n>=2&&flag==2) 
		printf("QAQ");
		else printf("haoye");
	}
	return 0;
}

