#include<stdio.h>
int main() {
	int x;
	scanf("%d", &x);
	while (x--) {
		printf("Welcome to HZNU\n");
	}
}