#include<bits/stdc++.h>
#define wtn tql
using namespace std;
int main(void){
	int t;cin>>t;
	while(t--){
		char s[1010][40];
		int n=0;
		char bdfh;
		while(1){
			cin>>s[n];
			n++;
			char bd=s[n-1][strlen(s[n-1])-1];
			if(bd=='.'||bd=='!'||bd=='?'){
				bdfh=bd;
				break;
			}
		}
		cout<<s[0];
		for(int i=1;i<n/2;i++){
			cout<<" "<<s[i]<<" "<<s[n-i-1];
		}
		if(n%2==1)cout<<" "<<s[n/2];
		cout<<bdfh<<endl;
	}
return 0;
}

