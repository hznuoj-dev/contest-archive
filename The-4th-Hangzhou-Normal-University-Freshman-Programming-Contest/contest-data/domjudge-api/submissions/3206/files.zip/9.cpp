#include<stdio.h>
#include<string.h>
int main(void){
	long long n,i,j,t,f,k,a[10000];
	char s[10000][16],c[16];
	scanf("%lld",&n);
	for(i=0;i<n;++i)
		scanf("%lld %s",&a[i],&s[i]);
	scanf("%lld",&k);
	for(i=1;i<n;++i){
		f=1;
		for(j=0;j<n-i;++j){
			if(a[j]<a[j+1]){
				t=a[j];
				a[j]=a[j+1];
				a[j+1]=t;
				strcpy(c,s[j]);
				strcpy(s[j],s[j+1]);
				strcpy(s[j+1],c);
				f=0;
			}
		}
		if(f)
			break;
	}
	printf("%s\n",s[k]);
	return 0;
}