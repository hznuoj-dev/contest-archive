#include <stdio.h>

int main() {
	int t, n, i, j, k, s, num;
	int a[10000];
	scanf("%d", &t);
	while (t--) {
		s = 0;
		num = 0;
		scanf("%d", &n);
		for (i = 0; i < n; i++)
			scanf("%d", &a[i]);
		for (i = 0; i < n; i++) {
			for (j = 1; j <= n - i; j++) {
				for (k = 0, s = 0; k < j; k++) {
					s += a[i + k];

				}


				if (s == 7777)
					num += 1;
			}
			if (s > 7777);
			continue;
		}
		printf("%d\n", num);
	}
	return 0;
}