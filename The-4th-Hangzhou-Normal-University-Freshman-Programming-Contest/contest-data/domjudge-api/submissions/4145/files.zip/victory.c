
#include<stdio.h>
int main() {
	int n, p, x, t;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &n, &x);
		if (n == 0)
			printf("yes\n");
		else if (x == 0)
			printf("no\n");
		else if (x != 0) {
			int p = (n * n - n) % x;
			if (p == 0)
				printf("yes\n");
			else
				printf("no\n");
		}
	}
	return 0;
}
