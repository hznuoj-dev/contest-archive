#include<stdio.h>
struct m
{
	char s1;
	int b;
};
int main()
{
	int t,k,i,n,sum,h;
	h=0;	
	scanf("%d",&t);
	while (t--)
	{
		i=0;
		scanf("%d",&k);
		struct m z[3*k];
		getchar();
		
		while (i<k)
		{
			z[i].s1=getchar();
			getchar();
			z[i].b=1;
			i++;
		}
		for (i = 0; i < k; i++)
		{
			for ( n = 0; n < k; n++)
			{
				if (z[i].s1==z[n].s1&&n>i)
				{
				
					z[i].b=z[i].b+1;
					z[n].b=0;
				}
				if (n<i&&z[i].s1==z[n].s1)
				{
					break;
				}
			}
		}
		sum=0;
		h=0;
		for (i= 0;i < k; i++)
		{
			if (z[i].b==1&&h==0)
			{
				sum=sum+1;
				h=h+1;
			}
			if (z[i].b>=2&&z[i].b%2==1&&h==0)
			{
				sum=sum+1;
				h=h+1;
			}
			if (z[i].b>=2)
			{
				sum=sum+z[i].b/2;
			}
			
		}
		if(h==0)
		printf("%d\n",sum*2);
		if(h==1)
		printf("%d\n",(sum-1)*2+1);
	}

	return 0;
}

