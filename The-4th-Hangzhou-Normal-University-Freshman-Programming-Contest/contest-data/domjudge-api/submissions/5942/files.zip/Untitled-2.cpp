#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <sstream>
#include<bits/stdc++.h>
#define ll long long
#define INF 1e6
#define MAXZ 100050 
#define pancake std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
using namespace std;
ll qm (ll base , ll power , ll m){
    ll result = (ll) 1 % m;
    ll t = (ll) base;
    while (power){
        if(power & 1){
            result = result * t % m ;
        }
            t = t * t % m;
            power >>= 1 ;
    }
    return result;
}
typedef struct stu{
       ll a;
       string b;
}stu;
bool cmp (stu x , stu y){
        return x.a > y.a;
}
int main(){
    ll t;
    cin >> t;
    while(t --){
        ll n;
        cin >> n;
        ll mp1[25][25] , mp2[25][25];
        for(int i = 1 ; i <= n ; i ++){
            for(int j = 1 ; j <= n ; j ++){
                cin >> mp1[i][j];
            }
        }
        for(int i = 1 ; i <= n ; i ++){
            for(int j = 1 ; j <= n ; j ++){
                cin >> mp2[i][j];
            }
        }
        int time[5];
        memset(time , 0 , sizeof(time));
        if(mp1[1][1] == mp2[1][n]){
           time[1] ++;
           time[3] ++;
        } 
        if(mp1[1][1] == mp2[n][n]) time[2] ++;
        if(mp1[1][1] == mp2[n][1]){
            time[1] ++;
            time[3] ++;
        }
        if(mp1[1][1] == mp2[1][1]) time[0] ++;
        bool fz = true;
        for(int i = 1 ; i <= n ; i ++){
            for(int j = 1 ; j <= n ; j ++){
                bool ff = false;
                if(mp1[i][j] == mp2[i][j] && time[0]) ff = true;
                if((mp1[i][j] == mp2[j][n - i + 1] || mp1[i][j] == mp2[n - j + 1][i]) && (time[1] || time[3])) ff = true;
                if(mp1[i][j] == mp2[n - i + 1][n - j + 1] && time[2]) ff = true;
                if(ff == false){
                    fz = false;
                    break;
                }
            }
            if(fz == false) break;
        }
        if(fz == true){
            if (time[0]) cout << 0 << endl;
            else if(time[1] || time[3]) cout << 1 << endl;
            else cout << 2 << endl;
        } 
        else cout << -1 << endl;
    }
    return 0;
}