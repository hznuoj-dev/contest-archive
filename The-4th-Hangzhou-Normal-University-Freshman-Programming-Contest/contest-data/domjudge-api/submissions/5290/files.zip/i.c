#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#define N 20
#define M 9999

struct song{
	long long int like;
	char name[N];
};
int comp(const void *p,const void *q){
	return ((struct song *)q)->like-((struct song *)p)->like;
}
int main(){
	struct song s[M];
	struct song most;
	int n;
	scanf("%d",&n);
	int i;
	for(i=0;i<n;i++){
		scanf("%lld %s",&s[i].like,s[i].name);
	}
	int k;
	scanf("%d",&k);
		qsort(s,n,sizeof(struct song),comp);
			printf("%s",s[k].name);
	return 0;
}
