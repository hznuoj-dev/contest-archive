#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int main(){
	int t, n, i, j, s, m;
	scanf("%d", &t);
	while(t--){
		m=0;
		scanf("%d", &n);
		int f[n];
		for(i=0;i<n;i++){
			scanf("%d", &f[i]);
		}
		for(i=0;i<n;i++){
			s=f[i];
			for(j=i+1;j<n;j++){
				s+=f[j];
				if(s==7777){
					m+=1;
					break;
				}
			}
		}
		printf("%d\n", m);
	}
	
}
