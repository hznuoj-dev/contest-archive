#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
typedef struct{
long long a;
int b;
}data;
int cmp(const void *a,const void *b){
	long long p1=*(long long*)a;
	long long p2=*(long long*)b;
return p1-p2;
}
data a[10000001];
main(){
int n,m,i,j,min,z;
scanf("%d %d",&n,&m);
for(i=1;i<=n;i++){
	for(j=1;j<=m;j++){
	scanf("%lld",&a[(i-1)*m+j].a);
	a[(i-1)*m+j].b=i;
	}
}
qsort(a+1,n,sizeof(data),cmp);
z=1;
for(i=n*m;i>=1;i--){
	for(j=i-1;j>=1;j--){
		if(z==1&&a[i].b!=a[j].b){
		min=abs(a[i].a-a[j].a);
		z=0;
		break;
		}
		else if(z==0&&a[i].b!=a[j].b){
			if(abs(a[i].a-a[j].a)<min){
			min=abs(a[i].a-a[j].a);
			}
		}
	}
}
printf("%d",min);
}
