#include<stdio.h>
int main(){
	int n,m,sum,min;
	long long int sha[100000];
	scanf("%d%d",&n,&m);
	for(int i=0;i<n;i++){
		for(int j=0;j<m;j++)
		scanf("%lld",&sha[i*m+j]);
	}
	min=sha[0]-sha[m];
	if(sha[0]<sha[m])
        min*=(-1);
	for(int i=0;i<n-1;i++){
		for(int k=0;k<m;k++){
		    for(int j=(i+1)*m;j<n*m;i++){
			    sum=sha[i*m+k]-sha[j];
                if(sha[i*m+k]<sha[j])
                    sum*=(-1);
                if(sum<min)
                    min=sum;
				if(min==0)
					break;
			}
		    if(min==0)
			    break;
	    }
	    if(min==0)
		    break;
	}
	printf("%d",min);
	return 0;
}