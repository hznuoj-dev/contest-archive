#include <stdio.h>
 int main (){
    int t,i,a,b;
	scanf("%d",&t);
	for(i=0;i<t;i++){
	scanf("%d%d",&a,&b);
        if(b == 0)
 		printf("no\n");
 		else 
 		printf("yes\n");
    }
	 return 0;
 }
