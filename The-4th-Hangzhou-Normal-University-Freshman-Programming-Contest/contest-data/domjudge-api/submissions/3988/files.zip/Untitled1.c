#include <stdio.h>
#include <string.h>
void swap(long long int *x,long long int *y){
	int t=*x;
	*x=*y;
	*y=t;
}
int main(void){
	long long int a[100000];
	char name[10000][16];
	char d[16];
	int n, i, j, k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i],name[i]);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++){
		for(j=n-1;j>i;j--){
			if(a[j]>a[j-1]){
				swap(&a[j],&a[j-1]);
				strcpy(d,name[j]);
				strcpy(name[j],name[j-1]);
				strcpy(name[j-1],d);
			}
		}
	} 
	printf("%s",name[k]);
}

