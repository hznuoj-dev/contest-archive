#include<stdio.h>
#include<stdlib.h>
struct temp
{
	int w;
	char s[100];
};
int cmp(const void*a,const void*b)
{
    return (*(struct temp*)b).w-(*(struct temp*)a).w;
}
struct temp temp[100000];
int main()
{
	int n,k,i;
	
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&temp[i].w,temp[i].s);
		//printf("%d %s",temp[i].w,temp[i].s);
	}	
	scanf("%d",&k);
	qsort(temp,n,sizeof(struct temp),cmp);
	printf("%s\n",temp[k].s);
 } 
