#include <iostream>
#include <vector>
#include <map>
using namespace std;
#define vc vector
#define pii pair<int,int>

const int mod=1e9+7;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	int q;
	cin>>q;
	map<int,string> mp;
	while(q--){
		int m;
		string s;
		cin>>m>>s;
		mp[m]=s;
	}
	int n=mp.size();
	n=mp.size()-n;;
	n--;
	map<int,string>::iterator cur=mp.begin();
	for(int i=0;i<n;i++,cur++){}
	cout<<cur->second<<endl;
	return 0;
}

