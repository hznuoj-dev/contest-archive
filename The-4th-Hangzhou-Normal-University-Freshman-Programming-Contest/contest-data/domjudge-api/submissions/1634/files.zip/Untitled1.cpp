#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int main(){
	int T,i,x,a[100],sum1,sum2;
	char c;
	scanf("%d",&T);
	while(T--){
		memset(a,0,sizeof(a));
		sum1 =0,sum2=0;
		scanf("%d",&x);
		getchar();
		for(i=0;i<x;i++){
			scanf("%c",&c);
			getchar();
			if(c<='Z'&&c>='A')
			a[c-'A'+26]+=1;
			else
			a[c-'a']+=1;	
		}
		for(i=0;i<52;i++){
			if(a[i]!=0){
				if(a[i]%2==0){
					sum1+=a[i]/2;
				}
				else
					sum2+=1;
			}
		}
		if(sum1==0&&sum2!=0)
			printf("1\n");
		else if (sum1==0&&sum2==0)
			printf("0\n");
		else if (sum2==0)
			printf("%d\n",sum1*2);
		else
			printf("%d\n",sum1*2+1);
			
	}



}
