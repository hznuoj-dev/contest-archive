#include<stdio.h>
#include<string.h>
#include<math.h>
int main() {
	long long t, number, a[100000], sum, i, j, k, result;
	scanf("%lld", &t);
	while (t--) {
		sum = 0;
		scanf("%lld", &number);
		for (i = 1; i <= number; i++) {
			scanf("%lld", &a[i]);
		}
		for (i = 1; i <= number; i++) {
			for (j = i + 1; j <= number; j++) {
				result = 0;
				for (k = i; k <= j; k++) {
					result += a[k];
				}
				if (result == 7777)
					sum++;
			}
			for (i = 1; i <= number; i++) {
				if (a[i] == 7777)
					sum++;
			}
		}
		printf("%lld\n", sum);
	}
	return 0;
}