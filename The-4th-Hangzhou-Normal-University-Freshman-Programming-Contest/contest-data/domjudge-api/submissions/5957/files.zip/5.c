#include <stdio.h>
int cmp(const void*p,const void*q);
void fun(int h,int n,int);
int count=0;
int a[100000];
int main(void){
	int i,n,t;
	count=0;
	scanf("%d",&t);
	while(t--){
		count=0;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		qsort(a,n,sizeof(int),cmp);
		fun(0,n,0);
		printf("%d\n",count);
	}
	return 0;
} 

int cmp(const void*p,const void*q){
	return (*(int*)p-*(int*)q);
}
void fun(int h,int n,int sum){
	int i;
	for(i=h;i<n;i++){
		if(sum+a[i]<7777){
			sum+=a[i];
			fun(i+1,n,sum);
			sum-=a[i];
		}
		if(sum+a[i]==7777){
			count++;
		}
//		if(sum+a[i]>7777){
//			break;
//		}
	}
}

