
#include<stdio.h>
struct sing {
	long long int w;
	char name[16];
};
struct sing ok[100000];
struct sing change;
int main() {
	int k, i, n, j;
	scanf("%d", &n);
	for (i = 0;i < n;i++) {
		scanf("%lld %s", &ok[i].w, ok[i].name);
	}
	for (j = 0;j < n;j++) {
		for (i = 0;i < n - j;i++) {
			if (ok[i].w < ok[i + 1].w) {
				change = ok[i];
				ok[i] = ok[i + 1];
				ok[i + 1] = change;
			}
		}
	}
	scanf("%d", &k);
	printf("%s\n", ok[k].name);
	return 0;
}
