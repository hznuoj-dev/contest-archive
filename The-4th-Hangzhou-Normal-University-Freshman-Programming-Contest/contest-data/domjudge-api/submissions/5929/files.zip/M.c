#include<stdio.h>
int main() {
	int n, m,x[10],k[10],i,f=0,c1=0,ki=0;
	scanf("%d %d", &n, &m);
	for (i = 0; i < n; i++) {
		scanf("%d", &x[i]);
		if (x[i] == 0) {
			scanf("%d", &k[i]);
			if (k[i] >= 2500) {
				ki = 1;
			}
			else if (k[i] <= 2100) {
				ki = -1;
			}
		}
		if (x[i] == 1) {
			c1 = 1;
		}
		if (x[i] == 2&&n>1) {
			f = 1;
		}
	}
	if (f != 1) {
		if (c1 == 1) {
			if (ki == 1) {
			f = 1;
			}
		}
		else if (ki == 0) {
			if (m == 1) {
				f = 1;
			}
		}
	}
	if (f)
		printf("haoye");
	else
		printf("QAQ");
}