//
//  main.c
//  K.c
//
//  Created by 陶艾嘉 on 2021/12/12.
//

#include <stdio.h>
int main(){
    int n,i;
    scanf("%d",&n);
    for(i=0;i<n;i++)
        printf("Welcome to HZNU\n");
}
