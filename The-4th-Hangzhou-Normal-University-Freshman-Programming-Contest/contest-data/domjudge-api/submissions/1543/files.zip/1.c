#include<stdio.h>

int ans[10005];
int main(){
	int n,k,i,j,count,answer,sum;
	scanf("%d",&n);
	while(n--){
		scanf("%d",&k);
		count=k;
		answer=0;
		i=1;
		while(k--){
			scanf("%d",&ans[i]);
			i++;
		}
		for(i=1;i<=count;i++){
			sum=0;
			j=i;
			while(sum<7777){
				sum=sum+ans[j];
				j++;
			}
			if(sum==7777)answer++;
		}
		printf("%d\n",answer);
	}

}
