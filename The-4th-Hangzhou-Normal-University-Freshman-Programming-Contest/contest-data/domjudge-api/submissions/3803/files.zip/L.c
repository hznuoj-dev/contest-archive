#include<stdio.h>
#define N 2
#define LENGTH 10
int yyqx(int n){
	int dp[N + 1][LENGTH]{ {0} };
    dp[0][0] = 1;
    for(int i = 1; i <= N; i++ )
    {
        for(int j = 0; j < LENGTH; j++)
        {
            dp[i][j] = dp[i-1][(j - 1 + LENGTH) % LENGTH] + dp[i-1][(j + 1) % LENGTH];
        }
    }
    return dp[N][0];
}
}
int main(){
	int n,t,x;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&x);
		if(yyqx())
		printf("yes\n");
		else
		printf("no\n");
	}	
} 
