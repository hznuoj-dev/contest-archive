//
//  main.c
//  Ayanoto 变形记
//
//  Created by 徐文哲 on 2021/12/12.
//

#include <stdio.h>

int main(void) {
    int t;
    scanf("%d",&t);
    while (t--) {
        long int n,x;
        scanf("%ld%ld",&n,&x);
        if (x>0) {
            printf("yes\n");
        }
        else
            printf("no\n");
    }
    return 0;
}
