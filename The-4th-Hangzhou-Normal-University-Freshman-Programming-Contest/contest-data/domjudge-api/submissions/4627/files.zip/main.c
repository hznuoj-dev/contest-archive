#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *p,const void *q);
struct song{
    long long int w;
    char name[20];
};which[100010];
int main(){
    int n,i,j,k,m;
    scanf("%d",&n);
    for(i=0;i<n;i++){
        scanf("%lld%s",&which[i].w,which[i].name);
    }
    scanf("%d",&m);
    
    qsort(&a[0].w,n,sizeof(struct song),comp);
    
    printf("%s\n",which[m].name);
    
    return 0;
}
int comp(const void *p,const void *q){
    return (*(int *)q-*(int *)p);
}
