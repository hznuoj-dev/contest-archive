#include<stdio.h>
#include<stdlib.h>
struct g{
	long long int a;
	char b[100];
};
int comp(const void *p, const void *q)
{
	return ((struct g *)q)->a - ((struct g *)p)->a;
}
int main(){
	long long int n;
	int t;
	struct g gg[1000];
	scanf_s("%lld", &n);
	for (int i = 0; i < n; i++)
	{
		scanf_s("%lld%s", &gg[i].a, gg[i].b, 1000);
	}
	qsort(gg, n, sizeof(struct g), comp);
	scanf_s("%d", &t);
	printf("%s", gg[t].b);
}