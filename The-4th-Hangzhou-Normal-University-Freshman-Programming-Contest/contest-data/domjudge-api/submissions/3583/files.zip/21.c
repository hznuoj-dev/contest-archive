#include<stdio.h>
int main()
{
	int n,t,x,i,flag;
	scanf("%d",&t);
	while(t--)
	{
		flag=0;
		scanf("%d%d",&n,&x);
		if(x==0)
		{
			printf("no\n");
		}
		else
		{
			printf("yes\n");
		}
	}
	return 0;
}
