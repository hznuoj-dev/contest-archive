#include<stdio.h>
#include<string.h>
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>

int a[100], b, c, t, T, p, n;
char s[10];

void init(){
 b = 0;
 c = 0;
 memset(a,0,sizeof(a));
}

int main() {

    scanf("%d",&t);
    while(t--){

  scanf("%d",&n);

    
  for(int i = 1;i <= n;i++)
  {
    scanf("%s",s);
    a[s[0]-'A']++;
  }
  
  
  for(int i = 0;i <= 'z'-'A';i++)
  {
  
   if(a[i] % 2)
   {
   b = 1;
   c = c +  a[i]/2;
   }


  }
  printf("%d\n",c * 2 + b);
 }

}
