#include<stdio.h>
#include<string.h>
main(){
	int t;
	int n;
	int i;
	char d;
	int intd;
	int flag=0;
	
	int sum=0;
	int a[130]={0};
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(i=0;i<n;i++){
			getchar();
		scanf("%c",&d);
		intd=(int)d;
		a[intd]++;
		}
		for(i=65;i<=124;i++){
			if(a[i]%2==0&&a[i]!=0){
			sum+=a[i];
			}
			else if(a[i]>2){
				sum+=a[i]-1;
				if(flag==0){
					sum++;
					flag=1;
				}
			}
			if(a[i]==1&&flag==0){
			sum++;
			flag=1;
			}
		}
		printf("%d\n",sum);
		sum=0;
		flag=0;
		memset(a,0,sizeof(a));
	}
}