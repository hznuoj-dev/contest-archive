#include<stdio.h>
int main(){
	int n;
	scanf("%d",&n);
	int i=0;
	while(i<n){
		printf("Welcome to HZNU\n");
		i++;
	}
}
