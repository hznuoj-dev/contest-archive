#include<stdio.h>
int main() {
	int T;
	scanf_s("%d", &T);
	while (T--) {
		printf("Welcome to HZNU\n");
	}
	return 0;
}