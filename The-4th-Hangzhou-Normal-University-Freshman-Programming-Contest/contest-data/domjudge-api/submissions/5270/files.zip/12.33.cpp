#include<stdio.h>
#include<string.h>
int main(void) 
{
	int p,x,lenb,c[120],sum,i,j,t,z;
	char b[10001],a[121],d[100];
	scanf("%d",&t);
	
	while(t--)
	{
		scanf("%d",&x);
		for(i=0;i<n;++i)
		{
		scanf("%s",d);
		strcpy(b,d);	
		}
     lenb=strlen(b);
     for(i=0;i<120;++i)
     {
     	c[i]=0;
    	a[i]='\0';
	 }
	 sum=0;
	 p=0;
	 z=0;
     for(i=0;i<lenb;++i)
     {
     	for(j=0;j<p+1;++j)
     	{
     			if(b[i]==a[j])
			{
				c[j]++;
				if(c[j]>=2)
				{
					c[j]=c[j]-2;
					sum=sum+2;
				}
				break;
			}
			    if(j==p)
			{
				a[p]=b[i];
     		   c[p]=1;
     		   p++;
			}
		}
	 }
	 
	 if(lenb>sum)
	 {
	 	printf("%d\n",sum+1);
	 }
	 if(lenb==sum) 
	 {
	 	printf("%d\n",sum);
	 }
	}
}

