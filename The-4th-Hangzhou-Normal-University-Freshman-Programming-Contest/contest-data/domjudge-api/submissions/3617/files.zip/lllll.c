#include <stdio.h>
int main() {
	long long n, x, i;
	long t;
	scanf("%d", &t);
	while (t--) {
		scanf("%I64d%I64d", &n, &x);
		i = n % x;
		if (i == 0)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}