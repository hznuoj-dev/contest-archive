#include <stdio.h>
struct s{
	long long int xa;
	char str[100];
};
int main(){
	int n;
	scanf("%d",&n);
	struct s song[n];
	int i,j;
	for(i=0;i<n;i++){
		scanf("%lld %s",&song[i].xa,song[i].str);
	}
	struct s temp;
	int x,dianguo;
	scanf("%d",&dianguo);
	for(i=1;i<n;i++){
		x=0;
		for(j=0;j<n-i;j++){
			if(song[j].xa<song[j+1].xa){
				temp = song[j];
				song[j]= song[j+1];
				song[j+1] = temp;
				x=1;				
			}
		}
		if(x==0)break;
	}
	printf("%s",song[dianguo].str);
	return 0;
}
