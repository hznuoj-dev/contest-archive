#include<stdio.h>
int main()
{
	int n,m,i,j,k,l,flag=0,atk,md=0,x,def;

	scanf("%d %d",&n,&m);
	if(m==0)
	{
	for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		if(x==0)
		{
			scanf("%d",&atk);
			if(atk>=2500)
				md=1;
		}
		if(x==1)
		{
			if(md==1){
				flag=1;
				printf("haoye\n");break;}
		}
		if(x==2)
		{
			if(md==0){
				flag=1;
				printf("haoye\n");break;}
		}
	}
	}
	if(m==1)
	{
		for(i=0;i<n;i++)
	{
		scanf("%d",&x);
		if(x==0)
		{
			scanf("%d",&def);
			if(atk>=2100)
				md=1;
		}
		if(x==1)
		{
			if(md==1){
				flag=1;
				printf("haoye\n");break;}
			
		}
		if(x==2)
		{
			if(md==0)
			{
				flag=1;
				printf("haoye\n");
				break;}
			
			
		}
	}
	}
	if(flag==0)
		printf("QAQ\n");
	return 0;
}

	
