#include<stdio.h>
#include<stdlib.h>
struct song
{
	long rank;
	char name[15];
};
int cmp(const void* a, const void* b) {
	return ((struct song*)b)->rank - ((struct song*)a)->rank;
}
int main() {
	int n, i,k;
	struct song want[10000];
	scanf("%d", &n);
	for (i = 0; i < n; i++)
		scanf("%ld %s", &want[i].rank, want[i].name);
	scanf("%d", &k);
	qsort(want, n, sizeof(struct song), cmp);
	for (i = 0; i < n; i++) {
		if (i == k)
			printf("%s", want[i].name);
	}
	return 0;
}