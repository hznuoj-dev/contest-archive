#include <stdio.h>
int main(){
	int b;
	scanf("%d",&b);
	for(int i=0;i<b;i++){
		printf("Welcome to HZNU\n");
	}
	return 0;
	
}
