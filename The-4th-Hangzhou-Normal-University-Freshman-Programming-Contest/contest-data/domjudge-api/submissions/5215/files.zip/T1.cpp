#include<bits/stdc++.h>

using namespace std;

int q[1000005],top;

int n,m;

int ans = INT_MAX;

bool com(int a,int b){
	return a<b;
}

int main()
{
	int x;
	int l=INT_MAX,r=-1;
	scanf("%d%d",&n,&m);
	int a[n+1][m+1]={};
	for(int i=1;i<=n;++i){
		for(int j=1;j<=m;++j){
			scanf("%d",&x);
			a[i][j] = x;
		}
	}

	for(int i=1;i<=n;++i){
		sort(a[i]+1,a[i]+1+n,com);
	}
	int now = 1,last;
	for(int j=1;j<=m;++j){
		last = a[1][j];
		top = 0;
		q[++top] = a[1][j];
		last = a[1][j];
		while(now<n){
			int to = lower_bound(a[now+1]+1,a[now+1]+1+m,last)-a[now+1];
			if(to == m+1) to--;
			q[++top] = min(abs(last-a[now+1][to]),abs(a[now+1][to+1]-last));
			last = q[top];
			now++;
		}
		sort(q+1,q+1+top,com);
		int sum = 0;
		for(int i=2;i<=top;++i){
			sum += a[i]-a[i-1];
		}ans = min(ans,sum);
		
	}
	printf("%d",ans);
	
	
	return 0;
}
