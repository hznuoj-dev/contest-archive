#include<stdio.h>
int main() {
	int n,m,a[10],k,i=0,p=0,b[10],g=0,h=0,l=0,j,sum,c,f;
	scanf("%d%d",&n,&m);
	for(j=0; j<n; j++) {
		scanf("%d",&a[i]);
		if(a[i]==0) scanf("%d",&k);
		i++;
	}
	if(n<=1) printf("QAQ\n");
	if(n>1) {
		for(j=0; j<n; j++) {
			if(a[j]==0) {
				g=1;
				k=b[p];
				p++;
			}
			if(a[j]==1) h=1;
			if(a[j]==2) l=1;
		}
		if(l==1) printf("haoye\n");
		else if(g==1&&h==1) {
			if(m=0) {
				sum=2500;
				for(c=0; c<p; c++) {
					if(b[c]>=sum) {
						printf("haoye\n");
						break;
					}
				}
			} else {
				sum=2100;
				for(c=0; c<p; c++) {
					if(b[c]>sum) {
						printf("haoye\n");
						break;
					}
				}
			}
		} else printf("QAQ\n");
	}
}
