#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int main(){
	int T,i,x,y,a[100],sum1,sum2;
	char c;
	scanf("%d",&T);
	while(T--){
		scanf("%d %d",&x,&y);
		if(y==0)
		printf("no\n");
		else
		printf("yes\n");
	}
}
