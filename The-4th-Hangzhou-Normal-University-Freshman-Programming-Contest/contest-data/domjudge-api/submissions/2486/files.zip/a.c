#include<stdio.h>
int main() {
	int T;
	long long n;
	char a[100001];
	char b[100001] = {'\0'};
	int c[100001] = {0};
	int j = 1;
	int sum=0;
	int p=0;
	scanf("%d", &T);
	getchar();
	while (T--) {
		sum = 0;
		scanf("%lld", &n);
		getchar();
		for (int i = 1; i <= n; i++) {
			scanf("%c", &a[i]);
			getchar();
			for (j = 1; j <= i; j++) {
				if (a[i] == b[j]) {
					c[j] = c[j] + 1;
					break;
				}
				else {
					if (b[j] == '\0') {
						b[j] = a[i];
						c[j] = c[j] + 1;
						break;
					}
				}
			}
		}
		for (int i = 1; i <= n; i++) {
			p=0;
			if (c[i] >= 2) {
				sum = sum + 2;
				p++;
			}
		}
		if (p!= n) {
			sum += 1;
		}
		printf("%d\n", sum);
	}

}