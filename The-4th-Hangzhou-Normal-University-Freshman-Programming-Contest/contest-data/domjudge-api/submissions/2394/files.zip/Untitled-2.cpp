#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <sstream>
#include<bits/stdc++.h>
#define ll long long
#define INF 1e6
#define MAXZ 100050 
#define pancake std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
using namespace std;
ll qm (ll base , ll power , ll m){
    ll result = (ll) 1 % m;
    ll t = (ll) base;
    while (power){
        if(power & 1){
            result = result * t % m ;
        }
            t = t * t % m;
            power >>= 1 ;
    }
    return result;
}
typedef struct stu{
       ll a;
       string b;
}stu;
bool cmp (stu x , stu y){
        return x.a > y.a;
}
stu ss[100050];
int main(){
    pancake;
    ll n;
    ll k;
    cin >> n;
    for(int i = 0 ; i < n ; i ++){
        cin >> ss[i].a >> ss[i].b;
    }
    cin >> k;
    sort(ss , ss + n , cmp);
    cout << ss[k].b;
    return 0;
}