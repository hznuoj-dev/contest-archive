#include <iostream>
#include <cstdio>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <deque>
#include <vector>
#include <queue>
#include <string>
#include <cstring>
#include <map>
#include <stack>
#include <set>
#include <sstream>
#include<bits/stdc++.h>
#define ll long long
#define INF 1e6
#define MAXZ 100050 
#define pancake std::ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
using namespace std;
ll qm (ll base , ll power , ll m){
    ll result = (ll) 1 % m;
    ll t = (ll) base;
    while (power){
        if(power & 1){
            result = result * t % m ;
        }
            t = t * t % m;
            power >>= 1 ;
    }
    return result;
}
typedef struct stu{
       ll a;
       string b;
}stu;
bool cmp (stu x , stu y){
        return x.a > y.a;
}
stu ss[100050];
int main(){
    pancake;
    ll n , m;
    ll atk = 2500 , def = 2100;
    cin >> n >> m;
    int num[15];
    ll sum = 0 , sumnum = 0;
    ll k;
    bool f0 = false , f1 = false , f2 = false;
    for(int i = 0 ; i < n ; i ++){
        cin >> num[i];
        if(num[i] == 0){
            cin >> k;
            sum += k;
            sumnum ++;
            f0 = true;
        }
        else if(num[i] == 1) f1 = true;
        else if(num[i] == 2) f2 = true;
    }
    cout << sum << endl;
    if(f2 == true && n >= 2) cout << "haoye";
    else if(f2 == true && n == 1) cout << "QAQ";
    else{
        if(f1 == false) cout << "QAQ";
        else{
            if(m == 0 && sum >= atk) cout << "haoye";
            else if(m == 1 && sum > def) cout << "haoye";
            else cout << "QAQ";
        }
    }
    return 0;
}