#include<stdio.h>

int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,x;
		int i,j;
		int flag=0;
		scanf("%d %d",&n,&x);
		if(x!=0){
		for(i=0;i*x<=n+1;i++){
			if(x*i%3==0){
				flag=1;
				break;
			}
		}
		if(flag==1)
		printf("yes\n");
		else
		printf("no\n");
	}else printf("no\n");
}
	return 0;
}

