#include<stdio.h>
#pragma warning(disable:4996)
int main() {
	int n = 0;
	scanf("%d", &n);
	while (n--) {
		printf("Welcome to HZNU\n");
	}
	return 0;
}