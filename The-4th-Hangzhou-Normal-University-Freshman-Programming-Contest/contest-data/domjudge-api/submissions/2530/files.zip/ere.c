#include<stdio.h>
int main()
{
	int T,temp,f;
	long long n,i,j;
	char c[100010];
	scanf("%d",&T);
	int a[100010];
	while(T--)
	{
		temp = 0;
		f = 0;
		scanf("%lld",&n);
		for(i = 0;i < n;i++)
		{
			getchar();
			scanf("%c",&c[i]);
			a[i] = 1;
		}
		for(i = 0;i < n;i++)
		{
			for(j = i+1;j < n;j++)
			{
				if((c[i] == c[j])&&(a[i]==1&&a[j]==1))
				{
					temp++;
					//printf("\n%c %c\n",c[i],c[j]);
					a[i] = a[j] = 0;
				}
			}
		}
		//printf("%d\n",temp);
		for(i = 0;i < n;i++)
		{
			if(a[i] == 1)
			{
				f = 1;
				break;
			}
		}
		if(f == 1&& temp != 0)
		{
			printf("%d\n",temp*2+1);
		}
		else if(temp==0&&f == 1)
		{
			printf("1\n");	
		}
		else if(f == 0)
		{
			printf("%d\n",temp*2);
		}
	}
	return 0;
}
