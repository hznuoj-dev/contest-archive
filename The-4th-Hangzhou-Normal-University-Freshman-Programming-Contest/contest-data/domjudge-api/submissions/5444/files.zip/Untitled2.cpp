#include<stdio.h>
#include<string.h>

int main(){
	int n;
	scanf("%d",&n);
	getchar();
	for(n;n>0;n--){
	
char a[1001][32]={0};
int i =0;
char s;
char str[30001];
int temp = 0;
fgets(str,30001,stdin);
int l =0;
while(str[l]!='!'&&str[l]!='?'&&str[l]!='.')
{
   a[i][temp] = str[l];
   temp++;
   l++;
   
   if(str[l]==' '){
   i++;  
   temp = 0;
}
}
i++;
temp  =0;
for(int k =1;k<=i;k++)
{
	if(k%2==1){
	printf("%s",a[temp]);
	}
	else{
	printf("%s",a[i-temp-1]);
    }
	if(k%2==0)
	temp++;
}
printf("%c",str[l]);
if(n!=1)
printf("\n");

}
}

