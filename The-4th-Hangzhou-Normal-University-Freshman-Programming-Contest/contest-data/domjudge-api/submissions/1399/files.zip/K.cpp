#include<stdio.h>
int main()
{
	int xx, yy;
	int P;
	scanf("%d", &P);
	while (P--)
	{
		printf("Welcome to HZNU\n");
	}
}
