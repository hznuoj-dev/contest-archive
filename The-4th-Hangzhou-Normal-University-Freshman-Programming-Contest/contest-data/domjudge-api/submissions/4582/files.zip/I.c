#include<stdio.h>
#include<stdlib.h>
#define array 100000
struct song{
	long long int level;
    char  geming[19];
} ;
int comp(const void *p,const void *q){
 return ((struct song*)q)->level-((struct song*)p)->level;
}
int main(void){
   struct song s[array];
   long long int n,k;
    scanf("%lld",&n);
    for(int i=0;i<n;i++){ 
    scanf("%lld %s",&s[i].level,s[i].geming);
     }
  qsort (s,n,sizeof(struct song),comp);
  scanf("%lld",&k); 
 printf("%s\n",s[k].geming);
   return 0;
}
