#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<map>
#include<iomanip>
#include<ctime>
using namespace std;
bool cmp(char a, char b)
{
	return a > b;
}
int main()
{
	int t;
	cin >> t;
	getchar();
	while (t--)
	{
		int x;
		cin >> x;
		getchar();
		string a;
		getline(cin, a);
		sort(a.begin(), a.end(),cmp);
		int sum = 0;
		for (int i = 0; i < x; i++)
		{
			if (a[i] == a[i + 1] && a[i] != ' ' && a[i + 1] != ' ')
			{
				sum += 2;
				a[i] = ' ';
				a[i + 1] = ' ';
			}
		}
		if (sum < x)sum += 1;
		cout << sum << endl;
	}
}