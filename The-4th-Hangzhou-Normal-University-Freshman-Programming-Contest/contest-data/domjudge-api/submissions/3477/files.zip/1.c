#include <string.h>
#include <stdio.h>
#include <math.h>
int b(void* sum1, void* sum2);

int b(void* sum1, void* sum2) {
	long long int a, b;
	a = *((long long int*)sum1);
	b = *((long long int*)sum2);
	if (a == b)
		return 0;
	else if (a > b)
		return 1;
	else if (a < b)
		return -1;
}
char ch[100050][18];

int main() {
	int t;
	long long int a[100050];
	scanf("%d", &t);
	for (int i = 0; i < t; i++) {
		scanf("%lld", &a[i]);
		scanf("%s", ch[i]);
	}
	qsort(a, t, sizeof(long long int), b);

	int m;
	scanf("%d", &m);
	printf("%s", ch[t - m - 1]);
	printf("\n");
}









