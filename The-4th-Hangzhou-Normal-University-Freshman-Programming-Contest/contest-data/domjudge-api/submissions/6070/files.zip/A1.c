������:
[��������]

Ҫ��˯��ĳ��hhj :
    [��������]

��Խ :
#include <stdio.h>
#include<math.h>
    int main()
{
    int n, m, t[20], p[20], i, j, a = 1, b = 1, flag = 1;
    scanf("%d%d", &n, &m);
    for (i = 0; i < n; i++)
    {
        scanf("%d", &t[i]);
        if (t[i] == 0)
            scanf("%d", &p[i]);
        else
            p[i] = 0;
    }
    for (i = 0; i < n; i++)
    {
        if (t[i] == 2)
            a = 0;
        if (t[i] == 1)
            b = 0;
    }
    if (a == 0 && n > 1)
        printf("haoye\n");
    else
    {
        if (b == 1)
            printf("QAQ\n");
        else
        {
            if (m == 0)
            {
                for (i = 0; i < n; i++)
                {
                    if (p[i] >= 2500)
                    {
                        printf("haoye\n");
                        flag = 0;
                        break;
                    }
                }
            }
            if (m == 1)
            {
                for (i = 0; i < n; i++)
                {
                    if (p[i] > 2100)
                    {
                        printf("haoye\n");
                        flag = 0;
                        break;
                    }
                }
            }
            if (flag == 1)
                printf("QAQ\n");
        }
    }
    return 0;
}
