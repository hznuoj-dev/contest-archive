#include<bits/stdc++.h>
using namespace std;
int a[100010];
char s[100010][16];
int b[100010];
int main(){
	int n,k;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i]>>s[i];
		b[i]=i;
	}
	cin>>k;
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(a[j]<a[j+1]){
				int m=a[j];a[j]=a[j+1];a[j+1]=m;
				int p=b[j];b[j]=b[j+1];b[j+1]=p;
			}
		}
	}
	cout<<s[b[k-1]];
	return 0;
}
