#include<stdio.h>
int main()
{
	int n,N,m,x,f,flag1=0,flag2=0,flag3=0;
	scanf("%d %d",&n,&m);
	N=n;
	while(n--)
	{
		scanf("%d",&x);
		if(x==0)
		{
			scanf("%d",&f);
			if(m==0)
			{
				if(f>=2500)
				flag1=1;
			}
			else if(m==1)
			{
				if(f>=2100);
				flag1=1;
			}
		}
		else if(x==1)
		flag2=1;
		else if(x==2)
		flag3=1;
	}
	if((flag1==1&&flag2==1)||(flag3==1&&N>=2))
	printf("haoye");
	else
	printf("QAQ");
	return 0;	
} 
