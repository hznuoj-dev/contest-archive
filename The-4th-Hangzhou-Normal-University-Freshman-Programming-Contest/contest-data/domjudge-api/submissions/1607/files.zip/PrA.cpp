#include<bits/stdc++.h>
using namespace std;

int main () {
	int t,c,n;
	char ch;
	cin>>t;
	int a[52];

	for(int i = 1; i <= t; i++) {
		c = 0;
		for(int j = 0; j <= 51; j++) {
			a[j]=0;
		}
		cin>>n;
		for(int j = 1; j <= n; j++) {
			cin>>ch;
			if(ch>='a'&&ch<='z') {
				a[ch-'a']++;
			} else {
				a[ch-'A'+26]++;
			}
		}
		for(int j = 0; j <= 51; j++) {
			if(a[j]%2==1) c = 1;
		}
		for(int j = 0; j <= 51; j++) {
			c += a[j]/2*2;
		}
		cout<<c<<"\n";
	}
	return 0;
}
