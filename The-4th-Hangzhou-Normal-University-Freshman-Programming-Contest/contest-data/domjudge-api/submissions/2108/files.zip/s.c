#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
struct xa{
		int cd;
		char name[100];
	}xx[100100];
int cmp(const void*a,const void* b){
	struct xa* p=(struct xa*) a;
	struct xa* q=(struct xa*) b;
	
	return q->cd-p->cd;
}
int main(){
	int n,i,k;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&xx[i].cd,xx[i].name);
	}
	qsort(xx,n,sizeof(struct xa),cmp);
	scanf("%d",&k);
	printf("%s",xx[k].name);
}