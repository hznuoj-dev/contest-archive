#include<stdio.h>
#include<string.h>
int main(){
	int n,t;
	char s1[16];
	char s[10001][16];
	int w[10001];
	int k;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%d %s",&w[i],s[i]);
	}
	scanf("%d",&k);
	for (int i=1;i<n;i++){
		for (int j=1;j<n;j++){
			if (w[j]<w[j+1]){
				t=w[j];
				w[j]=w[j+1];
				w[j+1]=t;
				strcpy(s1,s[j]);
				strcpy(s[j],s[j+1]);
				strcpy(s[j+1],s1);
			}
		}
	}
    printf("%s\n",s[k+1]);
}
