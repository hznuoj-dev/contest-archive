#include<stdio.h>
#include<stdlib.h>
struct song_stru 
{
	int num;
	char name[20];
}a[100001],t;
int comp(const void* p, const void* q)
{
	return ((struct song_stru*)q)->num - ((struct song_stru*)p)->num;
}
int main()
{
	int i,j,n,k,x;
	scanf("%d",&n);
	for (i = 0; i < n; i++)
	{
		scanf("%lld%s",&a[i].num,a[i].name);
	}
	scanf("%d",&k);
	qsort(a, n, sizeof(struct song_stru), comp);
	printf("%s\n",a[k].name);
	return 0;
}