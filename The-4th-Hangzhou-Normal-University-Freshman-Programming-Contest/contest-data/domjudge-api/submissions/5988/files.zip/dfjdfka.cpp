#include<bits/stdc++.h>
using namespace std;
const int N=1e6+10;
int a[13][N];
bool st[N];
void solve(){
	int ans=9999999;
	int n,m;cin>>n>>m;
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++)
			cin>>a[i][j];
	int x,y,z;
	for(int i=0;i<n;i++)sort(a[i],a[i]+m);
	for(int i=0;i<n;i++)
		for(int j=0;j<m;j++){
			for(int k=0;k<n;k++){
				if(i==k)continue;
				x=*lower_bound(a[k],a[k]+m,a[i][j]);
				y=abs(a[i][j]-x);
				ans=min(ans,y);
			}
		}
	cout<<ans;
}
int main(){
	int t=1;
	//cin>>t;
	while(t--){
		solve();
	}
}
