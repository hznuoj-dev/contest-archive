#include<bits/stdc++.h>
using namespace std;
int a[100010];
int main(){
	int t,n;
	cin>>t;
	for(int i=0;i<t;i++){
		cin>>n;
		for(int j=0;j<n;j++){
			cin>>a[j];
		}
		int b=0;
		int sum=0;
		int st=0;
		for(int j=0;j<n;j++){
			sum+=a[j];
			if(sum==7777){
				b++;
				sum=sum-a[st];	
				st++;
			}
			else if(sum>7777){
				sum=sum-a[st];
				st++;
			}
		}
		cout<<b<<'\n';
	}
	return 0;
}
