#include<bits/stdc++.h>
using namespace std;
int a[10];
int atk[10];
int main(){
	int n,m;
	cin>>n>>m;
	int flag1=0,flag2=0;
	for(int i=0;i<n;i++){
		cin>>a[i];
		if(a[i]==0)cin>>atk[i];
		if(a[i]==1)flag1=1;
		if(a[i]==2)flag2=1;	
	}
	int flag=0;
	if(flag2==1 && n>=2){
		flag=1;
		printf("haoye");
	}
	else if(flag1==1){
		for(int i=0;i<n;i++){
			if(a[i]==0 && (atk[i]-m)>2100){
				printf("haoye");
				flag=1;
				break;
			}
		}
	}
	if(flag=0)printf("QAQ");
	return 0;
}
