#include<stdio.h>
int main()
{
	int n, m, b, asd = 0;
	scanf_s("%d", &n);
	for(n;n>0;n--)
	{

		scanf_s("%d%d", &m, &b);
		if (n > 1)
		{
				if (b == 0)
					printf("no\n");
				else
					printf("yes\n");

		}
		else
		{
			if (b == 0)
				printf("no");
			else
				printf("yes");

		}
	}
	return 0;
}