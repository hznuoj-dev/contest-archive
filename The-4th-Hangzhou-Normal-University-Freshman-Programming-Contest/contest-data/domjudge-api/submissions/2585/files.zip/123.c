//#include<stdio.h>
//#include<stdlib.h>
//struct fan
//{
//	int a;
//	char name[20];
//};
//int comp(const void *p,const void *q)
//{
//	return ((struct fan *)q)->a-((struct  fan *)p)->a; 
//}
//	struct fan b[1000000];
//int main()
//{
//	int n;
//	scanf("%d",&n);
//	int i;
//	for(i=0;i<n;i++)
//	{
//		scanf("%d %s",&b[i].a,b[i].name);
//	}
//	qsort (b,n,sizeof(struct fan),comp);
//int k;
//scanf("%d",&k);
//for(i=0;i<n;i++)
//{
//	if(i==k)
//	printf("%s\n",b[i].name);
//}
//return 0;
//} 
#include<stdio.h>
int main()
{
	int n,m;
	scanf("%d %d",&n,&m);//n�����ƣ�m��Ӣ�۱�����ʽ 
    int i;
    int a[20];
    int k;
    int attach=0;
    
    for(i=0;i<n;i++)
    {
		scanf("%d",&a[i]);
		if(a[i]==0)
		{
			scanf("%d",&k);
			attach=k+attach;
			//k��ʾ������ 
		}
		
	}
	if(m==0)
	{
		if(attach>=2500)
		printf("haoye\n");
	} 
	else if(m==1)
	{
		if(attach>2100)
		printf("QAQ\n");
	}
	return 0;
}
