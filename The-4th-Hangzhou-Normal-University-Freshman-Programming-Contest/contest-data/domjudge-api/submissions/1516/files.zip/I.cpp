
#include <stdio.h>
#include <string.h>
#include<stdlib.h>
int main()
{
	int P, i, j, t;
	int chen;
	char trr[20000] = { 0 };
	long int arr[20000] = { 0 };
	char brr[20000][20] = { 0 };
	scanf("%d", &P);
	for (i = 0; i < P; i++)
	{
		scanf("%d %s", &arr[i], &brr[i]);
	}
	for (i = 0; i < P - 1; i++)
	{
		for (j = 0; j < P - 1 - i; j++)
		{
			if (arr[j + 1]>arr[j])
			{
				t = arr[j]; arr[j] = arr[j + 1]; arr[j + 1] = t;
				strcpy(trr, brr[j]); strcpy(brr[j], brr[j + 1]); strcpy(brr[j + 1], trr);
			}
		}
	}
	scanf("%d", &chen);
	printf("%s", brr[chen]);
}