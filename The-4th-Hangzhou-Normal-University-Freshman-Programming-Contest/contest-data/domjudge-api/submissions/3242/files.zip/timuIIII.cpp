#include<stdio.h>
#include<string.h>
#include<math.h>
#include<stdlib.h>
typedef struct ge{
	int xiai;
	char gm[30];	
}ge;
int cmp(const void *p, const void *q){
	ge xx = *(ge *)p ;
	ge yy = *(ge *)q ;
	return yy.xiai-xx.xiai ;
}
int main (){
	int n,i,k;
	scanf("%d",&n);
	ge a[100];
	for(i=0;i<n;i++){
		scanf("%d %s",&a[i].xiai,a[i].gm);
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(ge),cmp);
	
	printf("%s",a[k].gm);
	return 0;
} 
