#include <stdio.h>
int main()
{
	int a,b,c,d,e,is1,is2;
	scanf("%d %d",&a,&b);
	is1=0;
	is2=0;
	if(b==0)
	{
		while(a--&&is1!=2)
		{
			scanf("%d",&c);
			if(c==0)
			{
				scanf("%d",&d);
				if(d>=2500)
					is1=is1+1;
			}
			else if(c==1)
				is1=is1+1;
			else if(c==2)
			{
				printf("haoye\n");
				break;
			}
		}
		if(is1==2)
			printf("haoye\n");
	}
	else
	{
		while(a--&&is1!=2)
		{
			scanf("%d",&c);
			if(c==0)
			{
				scanf("%d",&d);
				if(d>=2100)
					is1=is1+1;
			}
			else if(c==1)
				is1=is1+1;
			else if(c==2)
			{
				printf("haoye\n");
				break;
			}
		}
		if(is1==2)
			printf("haoye\n");
	}
	return 0;
}