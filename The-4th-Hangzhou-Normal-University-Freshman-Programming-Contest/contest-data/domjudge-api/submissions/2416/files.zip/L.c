#include<stdio.h>
int main(){
	int t,i,flag;
	long long int a,b;
	scanf("%d",&t);
	while(t--){
		scanf("%lld %lld",&a,&b);
		
		for(i=1;i<=b+1;i++){
			if(b*i%a==0){
				flag==1;
			}
			else{
				flag==0;
			}
		}
		if(b==0){
			flag==0;
		}
		if(flag==1){
			printf("yes\n");
		}
		else{
			printf("no\n");
		}
	}
	return 0;
}
