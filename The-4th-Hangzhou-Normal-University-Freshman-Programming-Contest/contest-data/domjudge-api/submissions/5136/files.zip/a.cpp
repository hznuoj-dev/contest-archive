#include<stdio.h>
int main() {
	int T;
	scanf("%d", &T);
	while (T--) {
		int n,i,j,count=0,sum=0;
		char a[10000];
		int b[10000] = { 1 };
		scanf("%d", &n);
		for(i = 0;i < n; i++)
			scanf("%c", &a[i]);
		for (i = 0; i < n; i++) {
			for (j = i + 1; j < n; j++) {
				if (a[i] == a[j]) {
					b[i]++;
					a[j] = '0';
				}
			}
		}
		for (i = 0; i < n; i++) {
			if (b[i] != 1 && b[i] % 2 != 0)
				count++;
		}
		if (count == 0) {
			for (i = 0; i < n; i++) {
				while (b[i] != 1)
					sum += b[i];
			}
			if(n-sum!=0)
			printf("%d", sum + 1);
			else
				printf("%d", sum);
		}
		else if(count==1){
			for (i = 0; i < n; i++) {
				while (b[i] != 1)
					sum += b[i];
			}
				printf("%d", sum + 1);
		}
		else{
			for (i = 0; i < n; i++) {
				while (b[i] != 1)
					sum += b[i];

		}
			
			printf("%d", sum - count + 1);
	}
	return 0;
}