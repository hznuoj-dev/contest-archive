#include<stdio.h>
int main(){
	int T,n,i,s,j,flag[100000]={0};
	char a[100000];
	while(T--){
		s=0;
		scanf("%d",&n);
		for(i=0;i<n;++i){
			scanf("%c",&a[i]);
		}
		for(i=0;i<n-1;++i){
			flag[i]=1;
			for(j=i+1;j<n;++j){
				if(flag[j]==0&&(a[i]==a[j])){
					s++;
					flag[j]=1;
				}
			}
		}
		printf("%d\n",s+1);
	}
} 
