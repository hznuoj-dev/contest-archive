#include<stdio.h>
int main() {
	int t;
	int x, y;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &x, &y);
		if (y == 0 || x < y) {
			printf("no\n");
		}
		else {
			printf("yes\n");
		}
	}
	return 0;
}

