#include<stdio.h>
int main(){
	int g;
	scanf("%d",&g);
    while(g--){
    	printf("Welcome to HZNU\n");
	}
	return 0;
}
