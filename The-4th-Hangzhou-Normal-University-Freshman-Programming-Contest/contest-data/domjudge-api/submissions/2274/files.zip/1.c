#include<stdio.h>
#include<string.h>
main()
{
	int t,i=0,j,x;
	char a[35],b[1002][35];
	char ch;
	scanf("%d",&t);
	while(t--)
	{
		while(scanf("%s",&a)!=EOF)
		{
			i++;
			j=strlen(a);
			if(a[j-1]=='.' || a[j-1]=='!' || a[j-1]=='?')
			{
				for(x=0;x<j-1;x++)
				{
					b[i][x]=a[x];
				}
				b[i][x]='\0';
				b[i+1][0]=a[j-1];
				b[i+1][1]='\0';
				break;
			}
			else
			{
				strcpy(b[i],a);
			}			
		}
		if(i%2==0)
		{
			for(x=1;x<=(i+1)/2;x++)
			{
				if(x!=(i+1)/2)
				{
					printf("%s ",b[x]);
					printf("%s ",b[i-x+1]);
				}
				else
				{
					printf("%s ",b[x]);
					printf("%s",b[i-x+1]);
				}
			}
		}
		else
		{
			for(x=1;x<=(i+1)/2-1;x++)
			{
				if(x!=(i+1)/2-1)
				{
					printf("%s ",b[x]);
					printf("%s ",b[i-x+1]);
				}
				else
				{
					printf("%s ",b[x]);
					printf("%s ",b[i-x+1]);
				}
			}
			printf("%s",b[(i+1)/2]);
		}
		printf("%c\n",b[i+1][0]);
		i=0;
		j=0;
		x=0;
	}
}