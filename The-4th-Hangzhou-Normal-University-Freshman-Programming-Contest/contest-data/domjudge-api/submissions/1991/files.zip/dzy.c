#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
int n, i, j, temp;
int main()
{
	int num;
	char word[1005][40];
	char fuhao;
	scanf("%d", &n);
	while (n--)
	{
		memset(word, '\0', sizeof(word));
		i = 0;
		while (~scanf("%s", word[i]))
		{
			if (word[i][strlen(word[i]) - 1] == '.' || word[i][strlen(word[i]) - 1] == '!' || word[i][strlen(word[i]) - 1] == '?')
				break;
			i++;
		}
		fuhao = word[i][strlen(word[i]) - 1];
		word[i][strlen(word[i]) - 1] = '\0';
		num = i + 1;
		if (num % 2 == 0)
		{
			for (i = 0; i < num / 2; i++)
			{
				printf("%s", word[i]);
				printf(" ");
				printf("%s", word[num - i - 1]);
				if (i != num / 2 - 1)
					printf(" ");
			}
			printf("%c\n", fuhao);
		}
		else
		{
			for (i = 0; i < num / 2; i++)
			{
				printf("%s", word[i]);
				printf(" ");
				printf("%s", word[num - i - 1]);
				printf(" ");
			}
			printf("%s%c\n", word[num/2], fuhao);
		}
	}
	return 0;
}