#include<stdio.h>
#include<string.h>
#include<stdlib.h>


int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int n,x;
		scanf("%d%d",&n,&x);
		int i;
		int len=n*x;
		if(x==0) 
			{
				printf("no\n");
			}
		for(i=1;i<1000&&x!=0;i++)
		{
			int flag=i*x;
			if(flag%n==0)
			{
				printf("yes\n");
				break;
			}
	
			if(i==len)
			{
				printf("no\n");
			}
		}
	}	  
	return 0;
}

