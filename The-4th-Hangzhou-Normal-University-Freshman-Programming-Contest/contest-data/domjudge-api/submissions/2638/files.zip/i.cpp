#include<stdio.h>
#include<stdlib>
int comp(const void* p, const void* q);
int main() {
	int n;
	scanf("%d", &n);
	struct array {
		int a;
		char b[20];
		int c;
	};
	struct A[100000];
	int i,j;
	for (i=0;i<n;i++){
		scanf("%d %s", &A[i].a,A[i].b);
		qsort(A, n, sizeof(struct array), comp);
	}
	int comp(const void* p, const void* q) {
		return (*(int*)q - *(int*)p);
	}
	printf("%s\n", A[c].b);
	return 0;
}