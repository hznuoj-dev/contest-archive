//#define _CRT_SECURE_NO_WARNINGS
//����K
//#include <stdio.h>
//#include <process.h>
//int main()
//{
//	int n;
//	scanf("%d",&n);
//
//	while(n--)
//	{
//		printf("Welcome to HZNU\n");
//	}
//
//	system("pause");
//	return 0;
//}


//����I
#include <stdio.h>
//#include <process.h>

struct Song
{
	long long int rank;
	char name[20];
}number[1000001],temp;

int main()
{
	int n,i,j,k,sum;
	scanf("%d",&n);

	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&number[i].rank,&number[i].name);
	}

	scanf("%d",&sum);

	for(i=0;i<n-1;i++)
	{
		k=i;
		for(j=i+1;j<n;j++)
		{
			if(number[j].rank > number[k].rank)
			{
				k=j;
			}

			temp=number[k];
			number[k]=number[i];
			number[i]=temp;
		}
	}

	printf("%s\n",number[sum].name);

//	system("pause");
	return 0;
}


//����A
//���Ĵ�
//#include <stdio.h>
//#include <process.h>
//int main()
//{
//	int T,n;
//	scanf("%d %d",&T,&n);
//
//
//}


//����B
//����7777
//#include <stdio.h>
//#include <process.h>
//int arr[1000001];
//int main()
//{
//	int T,n,i,j=0;
//	scanf("%d %n",&T,&n);
//
//	for(i=0;i<n;i++)
//	{
//		scanf("%d",&arr[i]);
//	}
//
//	for(i=0;i<n;i++)
//	{
//		for(j=i+1;j<n;j++)
//		{
//			if()
//		}
//
//	}
//
//}



 