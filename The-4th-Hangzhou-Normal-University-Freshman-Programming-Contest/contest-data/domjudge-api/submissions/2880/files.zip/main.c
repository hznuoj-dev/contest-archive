#include<stdio.h>
int main(){
    long long t,n,x;
    scanf("%lld",&t);
    while(t--){
        scanf("%lld%lld",&n,&x);
        if(x>=1){
            printf("YES\n");
        }
        else{
            printf("NO\n");
        }
    }
    return 0;
}
