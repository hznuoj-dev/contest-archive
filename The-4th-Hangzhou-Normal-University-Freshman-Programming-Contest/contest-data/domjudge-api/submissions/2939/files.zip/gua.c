#include<stdio.h>
int main(void){
	long long t,n,x,set,b,i,per=0;
	scanf("%lld",&t);
	for(i=1;i<=t;i++){
		per=0;
		scanf("%lld%lld",&n,&x);
		set=x;
		b=set;
		if(b==0){
		per=1;
		printf("no\n");}
		while(per==0){
		b=b+x;
		if(b>=n)
		b=b-n;
		if(b==set){
		printf("no\n");
		per=1;}
		else if(b==0){
		printf("yse\n");
		per=1;}
		}
	}
	
	
	return 0;
}
