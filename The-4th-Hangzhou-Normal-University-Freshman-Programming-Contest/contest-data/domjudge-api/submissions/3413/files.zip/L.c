#include<stdio.h>
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		long long int n,x;
		scanf("%lld %lld",&n,&x);
		if(x!=0)
		{
			printf("yes");
		}
		else printf("no");
	}
	return 0;
}
