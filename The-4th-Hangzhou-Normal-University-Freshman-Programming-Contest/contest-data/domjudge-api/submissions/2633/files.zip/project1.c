#include<stdio.h>

int main(void)
{
	int t,x,n,i,flag=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&x);
		if(x==0){
			printf("no\n");
			continue;
		}
		else printf("yes\n");
	}
    return 0;
}

