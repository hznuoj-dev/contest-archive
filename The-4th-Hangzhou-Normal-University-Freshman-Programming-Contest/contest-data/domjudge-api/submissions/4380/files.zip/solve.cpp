#include<bits/stdc++.h>
using namespace std;
const int b=1e5+10;
char ch,s[b];
static int a[b];
int main(void){
	int t,n,ans;
	int sin1,sin2,dou;
	dou=0;
	ans=0;
	scanf("%d",&t);
	
	for(int i=1;i<=t;i++){
		scanf("%d",&n);
		getchar();
		int j=1;sin1=sin2=0;dou=0;
		ans=0;
		while (j<=n){
			int k=1;
			scanf("%c",&ch);
			getchar();
			s[j]=ch;a[j]++;
			while (k<j){
				if (s[j]==s[k]){
					a[k]++;a[j]=0;
					n--;j--;
					break;
				}
				k++;
			}
			
			j++;		
		}
		for (int h=1;h<=n;h++){
			if (a[h]%2==0) ans+=a[h];
			else if (a[h]>1) {
				ans+=(a[h]-1);
				sin2++;
			}
			else sin1++;
		}
		for (int m=1;m<=n;m++){
			a[m]=0;
		}
		if (sin2>0||sin1>0) ans++;
		else ans--;
		if (i!=t)printf("%d\n",ans);
		else printf("%d",ans);
	}
	return 0;
}

