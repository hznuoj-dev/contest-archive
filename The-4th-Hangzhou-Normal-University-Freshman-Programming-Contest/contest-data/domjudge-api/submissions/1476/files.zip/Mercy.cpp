#include<bits/stdc++.h>
using namespace std;

int cnt[55];
int main(){
	int n;
	
	cin>>n;
	while(n--){
		int t;
		int len=0;
		bool flag=0;
		cin>>t;
		while(t--){
			char in;
			cin>>in;
			if(in>='A'&&in<='Z'){
				cnt[in-'A']++;
			}else if(in>='a'&&in<='z'){
				cnt[in-'a'+26]++;
			}
		}
		for(int i=0;i<=51;i++){
			if(flag==0&&cnt[i]%2==1){
				len+=cnt[i];
				flag=1;
			}else if(cnt[i]%2==0){
				len+=cnt[i];
			}else{
				len+=cnt[i]-1;
			}
			cnt[i]=0;
		}
		cout<<len<<'\n';
	}
} 
