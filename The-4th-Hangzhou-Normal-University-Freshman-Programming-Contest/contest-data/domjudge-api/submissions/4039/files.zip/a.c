#include<stdio.h>
int main(void){
	int t,n,i,sum=1;
	char str[100001];
	scanf("%d",&t);
	while(t--){
		int sum=1;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	scanf("%c",str[i]);
	int j;
	for(i=0;i<n;i++){
	for(j=i+1;j<n;j++)
	if(str[i]==str[j])
		sum=sum+2;
	
	}
	printf("%d\n",sum);
	sum=1;
	}
return 0;
}
