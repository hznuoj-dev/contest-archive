#include<stdio.h>
int a[100010],sum[100010];
int main(void){
	int t,n,ans;
	scanf("%d",&t);
	while(t--){
		for(int i=0;i<100010;i++){
			a[i]=0,sum[i]=0;
		}
		ans=0;
		scanf("%d",&n);
		scanf("%d",&a[0]);
		sum[0]=a[0];
		for(int i=1;i<n;i++){
			scanf("%d",&a[i]);
			sum[i]=sum[i-1]+a[i];
		}
		for(int i=0;i<n;i++){
			if(sum[i]==7777)ans++;
		}
		for(int i=0;i<n-1;i++){
			for(int j=i+1;j<n;j++){
				if(sum[j]-sum[i]==7777)ans++;
			}
		}
		printf("%d\n",ans);
	}
}
