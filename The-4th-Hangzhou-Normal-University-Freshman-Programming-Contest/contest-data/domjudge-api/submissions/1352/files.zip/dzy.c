#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
int n, i, j, temp;
int main()
{
	int a, b;
	scanf("%d", &n);
	while (n--)
	{
		scanf("%d%d", &a, &b);
		if (b <= a && b >= 1)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}