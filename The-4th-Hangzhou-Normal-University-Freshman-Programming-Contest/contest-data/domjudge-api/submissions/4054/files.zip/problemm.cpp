#include <iostream>
using namespace std;
struct sum {
	char s[40];
	int x;
};
char s1[40],ch,s2;
int n,l,r;
int main () 
{
	struct sum a[1010];
	cin >> n ;
	for (int i = 1; i <= n; i++)
		{
			getchar();
			int w=0,p=0;
			ch=getchar();
			while (ch != '.' && ch != '?' && ch != '!')
			{
				if (ch == ' ') {
					w++;
					a[w].x=p;
					for (int j = 1; j <= p; j++)
						a[w].s[j]=s1[j];
					p=0;
				}
				else {
					p++;
					s1[p]=ch;
				}
				ch=getchar();
			}
			w++;
			a[w].x=p;
			for (int j = 1; j <= p; j++)
				a[w].s[j]=s1[j];	
			s2=ch;
			l=1; r=w; 
			int j=1;
			while (1){				
				if (j == w) break;
				for (int j = 1; j <= a[l].x; j++)
					cout << a[l].s[j];
				cout << ' ';
				j++;
				l++;
				if (j == w) break;
				for (int j = 1; j <= a[r].x; j++)
					cout << a[r].s[j];
				cout << ' ';
				j++;
				r--;
				if (j == w) break;
			}
			for (int j = 1; j <= a[r].x; j++)
					cout << a[r].s[j];
				cout << s2 << '\n';
		}	
	
}
