#include<stdio.h>

int main()
{
	int n,m;
	int zhonglei,weili[10],i,guai=0,zhiming=0,hei=0,j;
	int flag=0,h;
	scanf("%d %d",&n,&m);
	for(i=1,j=1;i<=n;i++)
	{
		scanf("%d",&zhonglei);
		if(zhonglei==0)
		{
			scanf("%d",&weili[j]);
			guai+=1;
			j+=1;
		}
		if(zhonglei==1)
			zhiming+=1;
		if(zhonglei==2)
			hei+=1;
	}
	if(hei>0&&zhiming>0)
		flag=1;
	else if(hei>0&&guai>0)
	{
		if(m==0)
		{
			for(h=1;h<j;h++)
			{
				if(weili[h]<2500)
					flag=1;
				else
					continue;
			}
		}
		else
		{
			for(h=1;h<j;h++)
			{
				if(weili[h]<2100)
					flag=1;
				else
					continue;
			}
		}
	}
	else if(guai>0&&zhiming>0)
	{
		if(m==0)
		{
			for(h=1;h<j;h++)
			{
				if(weili[h]>=2500)
					flag=1;
				else
					continue;
			}
		}
		else
		{
			for(h=1;h<=j;h++)
			{
				if(weili[h]>=2100)
					flag=1;
				else
					continue;
			}
		}
	}
	if(flag==1)
		printf("haoye\n");
	else
		printf("QAQ\n");
	
	return 0;
}

		
		

