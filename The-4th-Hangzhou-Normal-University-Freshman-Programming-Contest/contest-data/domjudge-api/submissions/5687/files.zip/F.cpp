#include<bits/stdc++.h>
using namespace std;

int t;
int n;
int a[50][25];
int b[25][25];
int solve(){
	int ans1=4,ans=-1;
	int flag=1;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(a[i+n][j]!=a[i][j]){
				flag=0;
				break;
			}
		}
		if(flag==1){
			ans1=0;
			break;
		} 
	} 
	if(flag==0){
		for(int k=1;k<=3;k++){
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++){
					b[i][j]=a[j][n-i+1];
				}
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++){
					a[i][j]=b[i][j];
				}
			flag=1;
			for(int i=1;i<=n;i++)
				for(int j=1;j<=n;j++){
					if(a[i+n][j]!=b[i][j]){
						flag=0;
						break;
					}
				}
			if(flag==1){
				ans1=k;
				break;
			}
		}
	}
	
	if(ans1!=4){
		if(ans1==3)ans=1;
		else ans=ans1;
	}
	return ans;
}

int main(){
	cin >>t;
	while(t--){
		cin >> n;
		memset(b,0,sizeof(b));
		memset(a,0,sizeof(a));
		for(int k=0;k<=1;k++){
			for(int i=k*n+1;i<=n*(k+1);i++)
				for(int j=1;j<=n;j++) 
					cin >>a[i][j];
		}
		int q=solve();
		cout << q <<'\n';
	}
return 0;
}

