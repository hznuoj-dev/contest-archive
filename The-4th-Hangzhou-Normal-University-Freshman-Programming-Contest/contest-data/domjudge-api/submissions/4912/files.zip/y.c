#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct song {
	long long love;
	char s[20];
};
int com(const void*a,const void *b){
	return ((struct song*)b)->love - ((struct song *)a)->love;
}
struct song a[100001],e;
int main (){
 int f1=0,f2=0,f3=0,f4=0,f=0;
 int n,m;
 int i;
 int a;
 int k;
 scanf("%d%d",&n,&m);
 for(i=1;i<=n;i++){
	 scanf("%d",&k);
	 if(k==0){
		 scanf("%d",&a);
		if(m==1){
			if(a>2100){
				f1=1;
			}
		}
		else{
			if(a>=2500){
				f1=1;
			}
		}
	 }
	 if(k==1){
		 f2=1;
	 }
	 if(k==2){
		 f3=1;
	 }
}
 if((f1==1&&f2==1)||(f3==1&&n>1)){
	 printf("haoye");
 }
 else{
	 printf("QAQ");
 }
}