#include<stdio.h>
#include <stdlib.h>
struct song{
	long long int cd;
	char gm[16];
};
int cmpfunc (const void * a, const void * b)
{
   return ( *(int*)a - *(int*)b );
}
int main()
{
	long long int T,i;
	scanf("%lld",&T);
	struct song song[T];
	for(i=0;i<T;i++)
	{
		scanf("%lld",&song[i].cd);
		char a;
		scanf("%c",&a);
		gets(song[i].gm);
	}
	long long int k;
	scanf("%lld",&k);
	qsort(song[T].cd, T, sizeof(long long int), cmpfunc);
	long long int x;
	x = T - k;
	puts(song[x-1].gm);
	return 0;
}
