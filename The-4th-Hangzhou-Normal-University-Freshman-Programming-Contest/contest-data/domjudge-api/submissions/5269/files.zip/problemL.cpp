#include<stdio.h>
int main(void)
{
	int t;
	scanf("%d",&t);
	while(t--)
	{
		double n,x;
		scanf("%lf %lf",&n,&x);
		int flag=0;
		if(x>0)
		{for(int i=1; ;i++)
		{
			if(x*i>=n)
			{
				flag=1;
				break;
			}
		}
		if(flag==0) printf("no\n");
		else printf("yes\n");}
		else printf("no\n");
	}
	return 0;
}
