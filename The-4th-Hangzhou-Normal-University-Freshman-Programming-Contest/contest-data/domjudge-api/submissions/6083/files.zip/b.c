#include<stdio.h>
int main(){
	int i,j,n,t,a[5010],s=0,c=0;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d",&a[i]);
		}
		for(i=0;i<n-1;i++){
			s=s+a[i];
			j=i+1;
			while(s<7777){
				s=s+a[j];
				if(s==7777)
					c=c+1;
				j++;
			}
			s=0;
		}
		printf("%d\n",c);
		c=0;
	}
}
