#include <stdio.h>
#include <string.h>

int main(void){
	int n;
	scanf("%d",&n);
	int rank[n]={0};
	char name[n][30];
	int index[n]={0};
	for (int i=0; i<n; i++) memset(name[i], 0, sizeof(name[i]));
	for (int i=0; i<n; i++){
		index[i]=i;
		scanf("%d %s",&rank[i],name[i]);
	}
	int k;
	scanf("%d",&k);
	for (int i=0; i<k+1; i++){
		for (int j=n-1; j>i; j--){
			if (rank[index[j]]>rank[index[j-1]]){
				int temp=index[j];
				index[j]=index[j-1];
				index[j-1]=temp;
			}
		}
	}
	
	printf("%s\n",name[index[k]]);
	return 0;
}
