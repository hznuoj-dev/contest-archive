#include <string.h>
#include <stdio.h>
#include <math.h>

int main() {
	int t;
	scanf("%d", &t);
	while (t--) {
		int a, i, j, sum = 0;
		scanf("%d", &a);
		char ch[200001];
		for (i = 0; i < a * 2; i++) {
			scanf("%c", &ch[i]);
			if (ch[i] == ' ') {

				continue;
			}
			else {
				for (j = 0; j < i; j++) {
					if (ch[i] == ch[j] && ch[j] != ' ') {
						ch[j] = '1';
						sum++;
						break;
					}
				}
			}
		}
		if (sum == 0)
			printf("1\n");
		else if (sum * 2 == a)
			printf("%d\n", sum * 2);
		else if (sum * 2 != a)
			printf("%d\n", sum * 2 + 1);
	}
}









