#include<stdio.h>
#include<stdlib.h>
main(){
	int  t;
	int n;
	int flag=0;
	int i;
	int x;
	scanf("%d",&t);
	while(t--){
	scanf("%d %d",&n,&x);
	if(x==1){
	printf("yes\n");
	continue;
	}
	for(i=0;i<=n+2;i++){
		if((x*i)%n==0&&x!=0){
		flag=1;
		printf("yes\n");
		break;
		}
	}
	if(flag==0){
	printf("no\n");
	}
	flag=0;
	}
}