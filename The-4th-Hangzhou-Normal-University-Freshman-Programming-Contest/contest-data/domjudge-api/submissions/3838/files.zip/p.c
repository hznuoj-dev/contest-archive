#include <stdio.h>
int main()
{
	int a,b,c,d,e,is1,is2,is3;
	scanf("%d %d",&a,&b);
	is1=0;
	is2=0;
	is3=0;
	if(b==0)
	{
		while(a>0)
		{
			scanf("%d",&c);
			if(c==0)
			{
				scanf("%d",&d);
				if(d>=2500)
					is1=is1+1;
			}
			else if(c==1)
				is3=is3+1;
			else if(c==2&&a>=2)
			{
				printf("haoye\n");
				break;
			}
			a=a-1;
		}
		if((is1>=1&&is3>=1))
			printf("haoye\n");
		else
			printf("QAQ\n");
		
	}
	else
	{
		while(a>0)
		{
			scanf("%d",&c);
			if(c==0)
			{
				scanf("%d",&d);
				if(d>=2100)
					is1=is1+1;
			}
			else if(c==1)
				is3=is3+1;
			else if(c==2&&a>=2)
			{
				printf("haoye\n");
				break;
			}
			a=a-1;
		}
		if((is1>=1&&is3>=1))
			printf("haoye\n");
		else
			printf("QAQ\n");
	}
	return 0;
}