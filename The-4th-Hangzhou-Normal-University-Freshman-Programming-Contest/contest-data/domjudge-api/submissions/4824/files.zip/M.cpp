#include<bits/stdc++.h>
using namespace std;

int t;
int n,l;
char ch;
char a[1010][35];

int main(){
	cin >>t;
	while(t--){
		n=0;
		do{
			scanf("%s",a[n]);
			l=strlen(a[n]);
			n++;
		} while(a[n-1][l-1]!='.'&&a[n-1][l-1]!='?'&&a[n-1][l-1]!='!');
		ch=a[n-1][l-1];
		a[n-1][l-1]='\0';
		cout <<a[0];
		int q=1,h=n-1;
		for(int i=1;i<n;i++){
			if(i%2==1)cout <<' '<<a[h--];
			else cout <<' '<< a[q++];
		}
		cout <<ch << '\n';
	}

return 0;
}

