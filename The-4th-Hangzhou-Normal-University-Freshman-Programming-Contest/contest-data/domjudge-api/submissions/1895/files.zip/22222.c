#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
int main(void){
	int n,i,j,y,x;
	scanf("%d",&n);
	while(n--){
		scanf("%d%d",&x,&y);
		if(y==0) printf("no\n");
		else printf("yes\n");
	}

	
	
	
	
	
	
	
	return 0;
} 
