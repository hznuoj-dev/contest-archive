#include <stdio.h>
int main(void){
	int n,m,a[10],k[10],i,d,flag,j;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;++i){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&k[i]);	
		}
		else{
			continue;
		}
	}
	for(i=0;i<n;++i){
		if(a[i]==2&&n>=2){
			flag=1;
			break;
		}
		if(a[i]==1){
			for(j=0;j<n;++j){
				if(a[i]==0){
					if((m==0&&k[i]>=2500)||(m==1&&k[i]>2100)){
						flag=1;
						break;
					}
				}
			}
		}
	}
	if(flag==1){
		printf("haoye");
	}
	else {
		printf("QAQ");
	}
	return 0;
} 
