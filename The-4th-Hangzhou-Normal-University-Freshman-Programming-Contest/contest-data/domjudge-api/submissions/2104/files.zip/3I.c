#include<stdio.h>
struct ge{
		long long int a;
		char b[16];
	};
int main(void){
	int n;
	scanf("%d",&n);
	struct ge g[n],temp;
	int t=n;
	while(n--){
		scanf("%lld %s",&g[t-n].a,&g[t-n].b);
	}
	int i,j;
	for(i=1;i<t;i++){
		for(j=1;j<t;j++){
			if(g[j-1].a<g[j].a){
				temp=g[j-1];
				g[j-1]=g[j];
				g[j]=temp;
			}
		}
	}
	int k;
	scanf("%d",&k);
	printf("%s",g[k]);
	return 0;
}
