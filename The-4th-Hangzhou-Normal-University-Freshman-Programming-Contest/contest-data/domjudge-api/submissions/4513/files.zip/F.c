
#include<stdio.h>
int main()
{
	int T;
	int N;
	int a[21][21],b[21][21];
	int i,j;
	int c;
	int t;

	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&N);

		for(i=1;i<=N;i++)
		{
			for(j=1;j<=N;j++)
			{
				scanf("%d",&a[i][j]);
			}
		}

		for(i=1;i<=N;i++)
		{
			for(j=1;j<=N;j++)
			{
				scanf("%d",&b[i][j]);
			}
		}
		
		
		for(c=1;c<=3;c++)
		{
			for(i=1;i<=N;i++)
			{
				for(j=i+1;j<=N;j++)
				{
					t=a[i][j];
					a[i][j]=a[j][i];
					a[j][i]=t;
				}
			}
			for(i=1;i<=N/2;i++)
			{
				for(j=1;j<=N;j++)
				{
					t=a[i][j];
					a[i][j]=a[N+1-i][j];
					a[N+1-i][j]=t;
				}
			}

			for(i=1;i<=N;i++)
			{
				for(j=1;j<=N;j++)
				{
					if(a[i][j]!=b[i][j])
					{
						break;
					}
				}
				if(j!=N+1)
				{
					break;
				}
			}

			if(i==N+1)
			{
				printf("1\n");
				break;
			}
		}
		if(c==4)
		{
			printf("-1\n");
		}
	}
	return 0;
}
