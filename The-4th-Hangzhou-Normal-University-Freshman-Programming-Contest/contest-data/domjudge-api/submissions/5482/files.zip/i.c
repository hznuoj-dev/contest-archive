#include <stdio.h>
#include <stdlib.h>
int comp(const void* p, const void* q);
int comp(const void* p, const void* q) {
	return (*(int*)q - *(int*)p);
}
struct number {
	long long int na;
	char mu[16];

};
struct number ge[100000];
long long int change[100000];

int main() {
	int n, i, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%lld%s", &ge[i].na, ge[i].mu);
		change[i] =ge[i].na;
	}
	qsort(change, 100000, sizeof(long long int), comp);
	int k;
	scanf("%d", &k);
	for (i = 0; i < n; i++) {
		if (change[k] == ge[i].na)
			printf("%s\n",ge[i].mu);
	}
}

