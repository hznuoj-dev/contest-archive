#include<stdio.h>
char a[100005]={0};
struct ge
{
	int a;
	char b[20];
}c[100001];
int main()
{
	int n,k,i,j,flag;
	struct ge t;
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d",&c[i].a);
		getchar();
		scanf("%s",&c[i].b);
		getchar();
	}
	scanf("%d",&k);
	for(j=0;j<n-1;j++)
		for(i=0;i<n-j-1;i++)
			if(c[i].a<c[i+1].a)
			{t=c[i];c[i]=c[i+1];c[i+1]=t;}
	printf("%s\n",c[k].b);
	return 0;
}