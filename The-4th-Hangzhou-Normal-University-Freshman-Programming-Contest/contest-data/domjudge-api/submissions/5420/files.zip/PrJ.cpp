#include<bits/stdc++.h>
using namespace std;
int x[11];
int k[11];

int main () {
	int n,m;
	int one = 0, two = 0;
	int win = 0;
	cin>>n>>m;
	for(int i = 1; i <= n; i++) {
		cin>>x[i];
		if(x[i]==0) {
			cin>>k[i];
		}
		if(x[i]==1) {
			one = 1;
		}
		if(x[i]==2) {
			two = 1;
		}
	}
	if(two) {
		if(n-1>0) {
			win = 1;
		}
	} else if(one) {
		if(m) {
			for(int i = 1; i <= n; i++) {
				if(k[i]>2100) {
					win = 1;
					break;
				}
			}
		} else {
			for(int i = 1; i <= n; i++) {
				if(k[i]>=2500) {
					win = 1;
					break;
				}
			}
		}
	}
	if(win) {
		cout<<"haoye";
	} else {
		cout<<"QAQ";
	}
	return 0;
}
