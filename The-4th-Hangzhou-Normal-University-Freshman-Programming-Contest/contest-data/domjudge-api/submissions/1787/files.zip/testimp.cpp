#include<stdio.h>
int main (){

int T;
long long a,b; 
scanf("%d",&T);
while(T--)
{
	scanf("%lld %lld",&a, &b);
		 if(b == 0)
	{
		printf("no\n");
	}
	
   else	if(2 * (a - 1) % b == 0){
		printf("yes\n");
		
	}
     else 
	{
		printf("no\n");
	}
}

}
