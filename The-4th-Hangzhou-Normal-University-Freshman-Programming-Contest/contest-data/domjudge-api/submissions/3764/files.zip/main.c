//
//  main.c
//  好想听肆宝唱歌啊
//
//  Created by 徐文哲 on 2021/12/12.
//

#include <stdio.h>

int main(void) {
    int n,i,k,j;
    scanf("%d",&n);
    struct w{
        long long int r;
        char ming[1000];
    };
    struct w a[n],t;
    for (i=0; i<n; i++) {
        scanf("%lld%s",&a[i].r,a[i].ming);
    }
    scanf("%d",&k);
    for (i=0; i<n-1; i++) {
        for (j=0; j<n-1; j++) {
            if (a[j].r<a[j+1].r) {
                t=a[j];
                a[j]=a[j+1];
                a[j+1]=t;
            }
        }
    }
    printf("%s\n",a[k].ming);
    return 0;
}
