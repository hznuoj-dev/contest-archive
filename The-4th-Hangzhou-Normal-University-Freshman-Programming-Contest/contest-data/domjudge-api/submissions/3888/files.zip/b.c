#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct
{
	int ai;
	char name[20];	
}ge[100000];
main()
{
	int n,a,i=0,j,k;
	int pai=0;
	char s[20];
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&a,&s);
		ge[i].ai=a;
		strcpy(ge[i].name,s);
	}
	scanf("%d",&k);
	for(i=0;i<n;i++)
	{
		pai=0;
		for(j=0;j<n;j++)
		{
			if(ge[i].ai>ge[j].ai)
				pai++;
		}
		if(pai==n-k-1)
		{
			printf("%s\n",ge[i].name);
			break;
		}
	}
}