#include <stdio.h>
int main()
{
	int n,m,i,a[11],s;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;++i)
	{
		scanf("%d",&a[i]);
		if(a[i]==0)
			scanf("%d",&s);
	}
	if((m==0&&s>=2500)||(m==1&&s>2100))
	{
		printf("haoye");
	}
	else
	{
		printf("QAQ");
	}
}
