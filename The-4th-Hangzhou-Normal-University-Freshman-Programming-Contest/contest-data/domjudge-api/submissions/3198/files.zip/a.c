#include<stdio.h>
int main(){
	int t,n;
	char s[1001];
	int x,max,l,a[52];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		int a[125]={0};
		max=0;
		for(x=0;x<n;x++){
			scanf(" %c",&s[x]);
			if('a'<=s[x]&&s[x]<='z'){
				a[s[x]-71]++;
			}
			else{
				a[s[x]-65]++;
			}
		}
		for(x=0;x<52;x++){
			if(max<a[x]){
				max=a[x];
			}
		}
		if(max==1){
			l=1;
		}
		else{
			l=n;
		}
		printf("%d\n",l);
	}
	return 0;
}
