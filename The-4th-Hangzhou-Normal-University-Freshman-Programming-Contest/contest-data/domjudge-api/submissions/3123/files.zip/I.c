#include<stdio.h>
#include<stdlib.h>
struct song{
	long long int level;
	char geming[19];
};
int comp(const void*p,const void *q){
	return((struct song*)q)->level-((struct song*)p)->level;
}
int main(void){
struct song s[10000];
int n,k;
scanf("%d",&n);
for(int j=0;j<n;j++){
	scanf("%lld %s",&s[j].level,s[j].geming);
}
scanf("%d",&k);
qsort(s,n,sizeof(long long int),comp);
for(int i=k;i<n;i++){
printf("%s\n",s[i].geming);
}
 return 0;
}
