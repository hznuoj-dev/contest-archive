#include<stdio.h>
#include<string.h>
#define array_size 100000
#include<stdlib.h>
struct st{
	int a;
	char b[16];
};
int comp(const void *p,const void *q){
	return (*(struct st*)p).a-(*(struct st*)q).a;
}
int main(void){
	struct st starray[array_size];
	int i,n,s;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&starray[i].a,starray[i].b);
	}
	scanf("%d",&s);
	qsort(starray,n,sizeof(struct st),comp);
	for(i=n-s-1;i<n-s;i++){
			printf("%s\n",starray[i].b);
	}
	
return 0;
}
