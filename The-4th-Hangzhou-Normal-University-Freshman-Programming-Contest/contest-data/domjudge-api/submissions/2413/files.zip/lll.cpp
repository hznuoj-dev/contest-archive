#include<bits/stdc++.h>

using namespace std;
map<int ,string > p;
const int N=1e5+10;
int a[N];
int main()
{
	int t;
	cin >> t;
	for(int i=1;i<=t;i++)
	{
		int x,n;
		cin  >> x >> n;
		if(n==0) cout << "no" << '\n';
		else cout << "yes" << '\n';
	}
	return 0;
}

