#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
int n, i, j;
int main()
{
	int zhuangtai, ka[20][2]={0},flag=0;
	scanf("%d%d", &n, &zhuangtai);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &ka[i][0]);
		if (ka[i][0] == 0)
			scanf("%d", &ka[i][1]);
	}
	for (i = 0; i < n; i++)
	{
		if (ka[i][0] == 2 && n >= 2)
			flag = 1;
	}
	for (i = 0; i < n; i++)
	{
		if (ka[i][0] == 1)
		{
			for (i = 0; i < n; i++)
			{
				if (ka[i][0] == 0 && zhuangtai == 0 && ka[i][1] >= 2500)
					flag = 1;
				if (ka[i][0] == 0 && zhuangtai == 1 && ka[i][1] > 2100)
					flag = 1;
			}
		}
	}
	if (flag == 1)
		printf("haoye\n");
	else
		printf("QAQ\n");
	return 0;
}