#include<bits/stdc++.h>
using namespace std;
double a[500001];

int main () {
	int t,c,n;
	int num;
	cin>>t;

	for(int i = 1; i <= t; i++) {
		cin>>n;
		a[0] = 0;
		c = 0;
		for(int j = 1; j <= n; j++) {
			scanf("%d",&num);
			a[j] = a[j-1] + num;
		}
		int l=0,r=1;
		while(r<=n) {
			if(a[r]-a[l]==7777) {
				c++;
				r++;
			} else if(a[r]-a[l]<7777) {
				r++;
			}
			else if(a[r]-a[l]>7777) {
				l++;
			}
		}
		cout<<c<<"\n";
	}
	return 0;
}
