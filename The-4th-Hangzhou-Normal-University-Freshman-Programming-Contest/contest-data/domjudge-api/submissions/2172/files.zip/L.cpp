#include<stdio.h>
int main(void) {
	int t;
	long long n, x;
	scanf("%d", &t);
	for (int i = 0; i < t; i++)
	{
		scanf("%lld", &n);
		scanf("%lld", &x);
		if (x==0)
		{
			printf("no\n");
		}
		else
		{
			printf("yes\n");
		}
	}
	return 0;
}