#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int cmp(const void *p,const void *q);
struct ge{
	int a;
	char name[20];
};
struct ge ff[100100];
int main (){
	int n=0,k=0,i=0;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&ff[i].a,ff[i].name);
	}
	scanf("%d",&k);
	qsort(ff,n,sizeof(ff[0]),cmp);
	printf("%s",ff[k].name);
	return 0;
}
int cmp(const void *p,const void *q){
	struct ge *a=(struct ge *)p;
	struct ge *b=(struct ge *)q;
	return b->a - a->a;
}
