#include<stdio.h>
#include<string.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
struct ge{
	long long xi;
	char name[20];
}a[100010];

int main(){
	int n,k,max;
	long long xi;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d%s",&a[i].xi,a[i].name);
	}
	scanf("%d",&k);
	for(int s=1;s<=k+1;s++){
		max=0;
		for(int i=1;i<=n;i++){
			if(a[i].xi>max) max=i;
		}
		if(s!=k+1){
			a[max].xi=0;
		}else if(s==k+1) break;
	}
//	for(int i=1;i<n;i++){
//		for(int j=i+1;j<=n;j++){
//			if(a[j].xi>a[i].xi) {
//			struct ge temp;	
//			temp=a[j];
//			a[j]=a[i];
//			a[i]=temp;
//			}
//		}
//	}
	printf("%s",a[max].name);
	return 0;
}
