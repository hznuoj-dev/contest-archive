#include<stdio.h>
struct a{
	char str[50];
	int x;	
};
int main(void)
{
	struct a song[100];
	int n,i,k=0,p,y;
	int rank[100];
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d%s",&song[i].x,song[i].str);
		rank[i] = i;
	}
	scanf("%d",&k);
	for (p=1;p<n;p++) {
			for (i=0;i<n-p;i++) {
				if (song[rank[i]].x > song[rank[i + 1]].x) {
					y = rank[i];
					rank[i] = rank[i + 1];
					rank[i + 1] = y;
				}
			}
		}
	printf_s("%s",song[rank[n-1-k]].str);
	return 0;
}
