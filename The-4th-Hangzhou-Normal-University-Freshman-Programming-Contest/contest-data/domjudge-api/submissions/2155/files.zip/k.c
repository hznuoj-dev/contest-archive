#include<stdio.h>
int main() {
    int t, n, x;
    scanf_s("%d", &t);
    while (t--) {
        scanf_s("%d %d", &n, &x);
        if (x > 0) {
            printf("yes\n");
        }
        else printf("no\n");
    }
}