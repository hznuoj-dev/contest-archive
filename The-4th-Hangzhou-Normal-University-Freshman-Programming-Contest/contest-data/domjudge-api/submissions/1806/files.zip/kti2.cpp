#include<stdio.h>
int main()
{
	int a,n,nima=0,flag=0,fusen;
	long long int x,i;
	scanf("%d",&a);
	while(a--)
	{
		nima=0;
		flag=0;
		scanf("%d%lld",&n,&x);
		fusen=x;
		if(x==0)
		{
			nima=1;
		}
		if(x==1||x==2||x==3)
		{
			flag=1;
		}
		for(i=1;(i*x)<1000000000;++i)
	   {
	   	if(flag==1||nima==1)
	   	{
	   		break;
		}
		if(x%n==0)
		{
			flag=1;
			break;
		}
		x= i*fusen;
	   }
	   if(flag==1)
	   {
	   	printf("yes\n");
	   }
	   else printf("no\n");
	}

}
