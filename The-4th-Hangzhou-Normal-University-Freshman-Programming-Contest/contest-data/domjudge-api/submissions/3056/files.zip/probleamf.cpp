#include <iostream>
using namespace std;
int a[100][100],b[100][100];
int t,n;
int main (){
	cin >> t;
	for (int i = 1; i <= t; i++)
	{
		cin >> n;
		for (int j = 1; j <= n; j++)
			for (int k = 1; k <= n; k++)
				cin >> a[j][k];
		for (int j = 1; j <= n; j++)
			for (int k = 1; k <= n; k++)
				cin >> b[j][k];
		int sum=0,x=0,y=0,flag=0,f1,f2;
		for (int p = 1; p <= 4; p++)
		{		
			sum++;	flag=0;
			if (p == 1) {
				for (int j = 1; j <= n; j++)
					{		
						for (int k = 1; k <= n; k++)
							if (a[j][k] != b[j][k])
								{
								flag=1;
								break;			
								}
						if (flag) break;
					}
				if (!flag) break;
			}
			else if (p == 2){ 
				for (int j = 1; j <= n; j++)
					{
						for (int k = 1; k <= n; k++)
							if (a[k][n-j+1] != b[j][k])
							{
								flag=1;
								break;			
							}
						if (flag) break;
					}
					if (!flag) break;
			} else if (p == 3){ 
				for (int j = 1; j <= n; j++)
					{
						for (int k = 1; k <= n; k++)
							if (a[n-j+1][n-k+1] != b[j][k])
							{
								flag=1;
								break;			
							}
						if (flag) break;
					}
					if (!flag) break;
			}else if (p == 4){ 
				for (int j = 1; j <= n; j++)
					{
						for (int k = 1; k <= n; k++)
							if (a[n-k+1][j] != b[j][k])
							{
								flag=1;
								break;			
							}
						if (flag) break;
					}
					if (!flag) break;
			}
			
		}
		if (sum == 4 && flag) cout << -1 << '\n';
		else
			{
				sum--;
				if (sum > 2) sum=4-sum;
				cout << sum << '\n'; 
			}
	}
}
