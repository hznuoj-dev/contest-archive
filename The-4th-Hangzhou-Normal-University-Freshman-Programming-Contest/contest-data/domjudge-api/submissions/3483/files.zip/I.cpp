#include<stdio.h>
#include<stdlib.h>
int comp(const void* p, const void* q);
struct song {
	int w;
	char name[20];
};
int comp(const void* p, const void* q) {
	return (*(int*)q - *(int*)p);
}
int main() {
	int n, k, i, j;
	struct song A[100000];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d %s", &A[i].w, A[i].name);
	}
	scanf("%d", &k);
	qsort(A, n, sizeof(struct song), comp);
	printf("%s\n", A[k].name);
	return 0;
}
