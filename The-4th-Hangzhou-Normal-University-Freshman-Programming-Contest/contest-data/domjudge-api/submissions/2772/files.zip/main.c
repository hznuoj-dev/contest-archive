#include<stdio.h>
#include "stdlib.h"
#include "string.h"
typedef struct o{
    int a;
    char s[100];
}g;
int cmp(const void *a,const void *b);
int main(void){
    int n,i,k;
    scanf("%d",&n);
    g p[n];
    for(i=0;i<n;i++){
        scanf("%d%s",&p[i].a,&p[i].s);
    }
    qsort(p,n,sizeof(p[0]),cmp);
    scanf("%d",&k);
    printf("%s",p[k].s);
}
int cmp(const void *a,const void *b){
    g c=*(g*)a;
    g d=*(g*)b;
    return c.a>d.a? 0:1;
}
