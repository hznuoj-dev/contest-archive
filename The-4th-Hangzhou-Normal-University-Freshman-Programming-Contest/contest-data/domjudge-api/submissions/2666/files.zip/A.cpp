#include <bits/stdc++.h>
using namespace std;
struct ge{
	int ai;
	char name[16];
} di[100010];
void zhao(ge *p,int n){
	int i,j,z;
	for (i=0;i<n-1;++i){
		for (j=i+1;j<n;++j){
			if (p[j].ai>p[i].ai) swap(p[j],p[i]);
		}
	}
	
}
int main(){
	int n,t,i,z;
	cin>>n;
	for (i=0;i<n;++i){
		scanf("%d %s",&di[i].ai,di[i].name);
	}
	cin>>t;
	zhao(di, n);
	cout<<di[t].name;
	return 0;
} 
