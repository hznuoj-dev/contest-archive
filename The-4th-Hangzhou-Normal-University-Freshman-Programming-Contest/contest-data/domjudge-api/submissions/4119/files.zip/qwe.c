#include<stdio.h>
int main()
{
	int n, m, b;
	scanf_s("%d", &n);
	while (n--)
	{
		scanf_s("%d%d", &m, &b);

		{
			if (b == 0)
				printf("no\n");
			else
				printf("yes\n");
		}
	}
	return 0;
}