#include<iostream>
#include<algorithm>
#include<cstdio>
#include<cstring>
#include<map>
#include<vector>
#include<queue>
#include<cmath>
#include<cctype>
using namespace std;
int main(){
int n,m,i,j;
cin>>n>>m;
int num;
int one=0,two=0,zero=0;int maxn=0;
int gj;
 for(i=0;i<n;i++){
 	cin>>num;
 	if(num==1){
 		one++;
	 }
	 else if(num==2){
	 	two++;
	 }
	 else if(num==0){	
	zero++; 
 	cin>>gj;
 	if(gj>maxn){
 		maxn=gj;
	 }
 }
}
int hf=0;
if(two>=1&&zero>=1){
	
	if(m==0){
		if(maxn>=2500)hf=1;
	}
	else if(m==1){
		if(maxn>2100)hf=1;
	}
}
else if(one>=1&&zero>=1){
	if(m==0){
		if(maxn>=2500){
			hf=1;
		}
	}
	else{
		if(maxn>2100){
			hf=1;
		}
	}
}
if(hf==1)cout<<"haoye"<<endl;
else cout<<"QAQ"<<endl;
}
