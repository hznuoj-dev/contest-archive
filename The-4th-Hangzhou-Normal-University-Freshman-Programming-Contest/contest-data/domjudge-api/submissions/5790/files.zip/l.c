#include <stdio.h>

int main() {
	int t;
	long long int s, k;
	scanf("%d", &t);

	while (t--) {
		scanf("%lld %lld", &s, &k);

		if (k != 0)
			printf("yes\n");
		else
			printf("no\n");
	}

	return 0;
}