#include<stdio.h>
#include<stdlib.h>
#include<string.h>
struct ge{
	int xiai;
	char name[16];
};
int main(){
	int t, n, i, j;
	struct ge f[1000];
	struct ge r;
	scanf("%d", &t);
	for(i=0;i<t;i++){
		scanf("%d%s", &f[i].xiai, f[i].name);
	}
	scanf("%d", &n);
	for(j=0;j<t-1;j++){
		for(i=0;i<t-j;i++){
			if(f[i].xiai<f[i+1].xiai){
				r=f[i];
				f[i]=f[i+1];
				f[i+1]=r;
			}
		}
	}
	printf("%s", f[n].name);
}
