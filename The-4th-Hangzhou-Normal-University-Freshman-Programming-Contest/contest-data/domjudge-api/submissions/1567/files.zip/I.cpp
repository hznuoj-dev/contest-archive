#include <stdio.h>
#include <string.h>

struct song {
	int a;
	char b[20];
};

int main () {
	int x, d, max, weizhi, i;
	weizhi = 0;
	scanf("%d", &x);
	struct song m[1000];
	for (i = 0; i < x; i++) {
		scanf("%d", &m[i].a);
		scanf("%s", m[i].b);
	}
	scanf("%d", &d);
	while (d--) {
		max = 0;
		weizhi = 0;
		for (i = 0; i < x; i++) {
			if (m[i].a >= max) {
				max = m[i].a;
				weizhi = i;
			}
		}
		m[weizhi].a = -1;
	}
	max = 0;
	for (i = 0; i < x; i++) {
		if (m[i].a >= max) {
			max = m[i].a;
			weizhi = i;
		}
	}
	printf("%s", m[weizhi].b);
}