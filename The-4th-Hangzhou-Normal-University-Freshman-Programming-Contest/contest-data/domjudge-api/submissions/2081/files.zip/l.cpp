#include<iostream>
using namespace std;
int main()
{
	int t;
	cin>>t;
	while(t--)
	{
		int n;
		int x;
		cin>>n>>x;
		if(x==0)
		{
			cout<<"no"<<endl;
			continue;
		}
		if(n%x==0)
		{
			cout<<"yes"<<endl;
		}
		else
		{
			cout<<"no"<<endl;
		}
	}
		
	return 0;
}
