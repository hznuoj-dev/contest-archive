#include<stdio.h>
struct gm{
	long long int bh;
	char s[16];
};
struct gm a[100000];
int main(){
	struct gm ch;
	int n,k,x,y;
	scanf("%d",&n);
	for(x=0;x<n;x++){
		scanf("%lld %s",&a[x].bh,a[x].s);
	}
	scanf("%d",&k);
	for(x=0;x<n;x++){
		for(y=x+1;y<n;y++){
			if(a[x].bh<a[y].bh){
			  ch=a[x];a[x]=a[y];a[y]=ch;
			}
		}
	}
	if(k==0){
		puts(a[0].s);
	}
	else{
		puts(a[k].s);
	}
	return 0;
}
