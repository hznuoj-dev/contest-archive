#include<stdio.h>
int main()
{
	int x;
	scanf("%d",&x);
	while(x--)
	{
		int m,n;
		scanf("%d%d",&m,&n);
		if (n==0||n>m)
		printf("no\n");
		else
		printf("yes\n");
	}
	return 0;
} 
