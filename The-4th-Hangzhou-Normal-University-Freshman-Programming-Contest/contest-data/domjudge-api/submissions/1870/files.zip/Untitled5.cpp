#include <stdio.h>

int main(void){
	int n,x,t;
	scanf("%d",&t);
	for(int i=1; i<=t; i++){
		scanf("%d %d",&n,&x);
		int c=0,n1=n;
		while(n1-x!=0){
			n1=n1-x;
			while (x>n1) n1+=n;
			c++;
			if (c==3000000) break;
		}
		if (c!=3000000){
			printf("yes\n");
		}
		else printf("no\n");
	}
	return 0;
}
