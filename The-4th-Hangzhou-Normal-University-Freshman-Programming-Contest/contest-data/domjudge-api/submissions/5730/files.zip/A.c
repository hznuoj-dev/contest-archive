#include <stdio.h>

int main(void) {
	int t,i,j,flag,k;
	scanf("%d",&t);
	while(t--){
		int n,sum=0,sum1=0;
		scanf("%d",&n);
		char a[n];
		int b[130];
		for(i=60;i<130;i++)
			b[i]=0;
		getchar();
		for(i=0;i<n;i++){
			scanf("%c",&a[i]);
			b[a[i]]++;
			getchar();
		}
		for(i=60;i<130;i++)
			sum+=b[i]/2;
		if(n>sum*2)
			printf("%d",2*sum+1);
		else
			printf("%d",2*sum);
		
	}

	return 0;
}

