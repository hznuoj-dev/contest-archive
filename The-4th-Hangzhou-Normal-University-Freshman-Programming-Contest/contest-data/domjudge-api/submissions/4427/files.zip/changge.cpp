#include<bits/stdc++.h>

using namespace std;
map<int ,string> p;
set<int >a;
int main()
{
	int n;
	cin >> n;
	for(int i=n;i>=1;i--)
	{
		int x;
		string ch;
		cin >> x >> ch;
		p[x]=ch;
		a.insert(x);
	}
	int k;
	cin >> k;
	int cnt=0;
	set<int >::iterator it;
	for(it=a.begin();it!=a.end();it++)
	{
		cnt++;
		if(cnt==n-k)
		cout << p[*it];
	}
	
	return 0;
}
