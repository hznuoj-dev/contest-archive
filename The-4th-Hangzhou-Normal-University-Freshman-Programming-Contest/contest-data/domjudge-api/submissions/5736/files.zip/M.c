#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
int main()
{
	int T;
	scanf("%d", &T);
	char word[1001][31];
	while (T--)
	{
		int i = 0; int x; int k;
		do
		{
			scanf("%s", word[i]);
			i++;
		} while (getchar() != '\n');

		x = strlen(word[i - 1]);
		if (i == 1)
		{
			printf("%s\n", word[0]);
		}
		else
		{


			printf("%s ", word[0]);
			for (k = 0; k < x - 1; k++)
			{
				printf("%c", word[i - 1][k]);
			}

			for (k = 2; k <= i / 2; k++)
			{
				printf(" %s", word[k - 1]);
				printf(" %s", word[i - k]);
			}
			if (i % 2 != 0)
			{
				printf(" %s", word[i / 2]);
			}
			printf("%c\n", word[i - 1][x - 1]);
		}
	}
	return 0;
}

