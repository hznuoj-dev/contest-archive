#include<stdio.h>
#include<stdlib.h>
#include<string.h>		
char str[110][1010][50];
int main()
{
	int x,t,i,j;
	scanf("%d",&t);
	for(x=0;x<t;x++)
	{
		i=0;
		while(scanf("%s",str[x][i])!=EOF)
		{
			if(str[x][i][strlen(str[x][i])-1]=='.'||str[x][i][strlen(str[x][i])-1]=='!'||str[x][i][strlen(str[x][i])-1]=='?')
			{
				break;
			}
			i++;
		}
		if(i==0)
		{
			printf("%s",str[x]);
		}
		else
		{
		printf("%s ",str[x][0]);
		for(j=0;j<strlen(str[x][i])-1;j++)
		{
			printf("%c",str[x][i][j]);
		}
		for(j=1;j<(i+1)/2;j++)
		{
			printf(" %s %s",str[x][j],str[x][i-j]);
		}
		if(i%2==0)
		{
			printf(" %s",str[x][j]);
		}
		printf("%c\n",str[x][i][strlen(str[x][i])-1]);
	    }
	}
} 
 
