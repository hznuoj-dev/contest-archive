#include<stdio.h>
int main(){
	int t, n, i, c=0, x;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&x);
		if(x==0){
			printf("NO");
			break;
		}
		for(i=1;i<=500000;i++){
			if(i*n%x==0){
				c=c+1;
				break;
			}
		}
		if(c==0){
			printf("NO\n");
		}
		else
		    printf("YES\n");
	}
	return 0;
}
