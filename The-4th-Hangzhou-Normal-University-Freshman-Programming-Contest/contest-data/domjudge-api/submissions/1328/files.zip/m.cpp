#include <stdio.h>
#include <string.h>

int main() {
	int n, i;
	scanf("%d", &n);
	while (n--) {
		printf("Welcome to HZNU\n");
	}
	return 0;
}