#include <stdio.h>
int main(void){
	int i,n,m,s1,s2,flag,l1=1,l2=1,w=1;
	scanf("%d%d",&n,&m);
	if(m==0)
		s1=2500;
	else
		s1=2101;
	for(i=0;i<n;i++)
	{
		scanf("%d",&flag);
		if(flag==0)
		{
		scanf("%d",&s2);
			if(s1<=s2)
				l1=0;
		}
		else if(flag==1)
			l2=0;
		else if(flag==2)
			if(n>1)
			w=0;
	}
	if(l1==0&&l2==0)
		w=0;
	if(w==0)
		printf("haoye\n");
	else
		printf("QAQ\n");
	return 0;
}

