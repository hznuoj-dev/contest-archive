#include<stdio.h>
#include<stdlib.h>
#include<string.h>		
int main()
{
	int i,j,t,n;
	char a[1010][100];
    scanf("%d",&t);
	while(t--)
	{
		i=0;
		while(~scanf("%s",a[i]))
		{		
			n=strlen(a[i]);	
			i++;
			if(a[i-1][n-1]=='.'||a[i-1][n-1]=='?'||a[i-1][n-1]=='!')
			{
				break;
			}
		}
		if(i==1)
		{
			puts(a[i-1]);
		}
		else
		{
			printf("%s ",a[0]);
			for(j=0;j<n-1;j++)
			{
				printf("%c",a[i-1][j]);
			}
			for(j=1;j<i/2;j++)
			{
				printf(" %s %s",a[j],a[i-j-1]);
			}
			if(i%2==1)
			{
				printf(" %s",a[j]);
			}
			printf("%c\n",a[i-1][n-1]);
		} 
	}	
}
 
