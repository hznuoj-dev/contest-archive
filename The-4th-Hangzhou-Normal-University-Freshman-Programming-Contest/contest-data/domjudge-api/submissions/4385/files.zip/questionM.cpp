#include<iostream>
#include<algorithm>
#include<stdio.h>
using namespace std;
string str[1010];char ch[100100];
int main(void){
	int n=1,k;//cin>>n;
	while(n--){
		int j=0;
		while(1){
			j++;ch[j]=getchar();
			if(ch[j]=='.'||ch[j]=='!'||ch[j]=='?')
				break;
		}
		int i=1;j=0;
		while(ch[j]!='.'&&ch[j]!='!'&&ch[j]!='?'){
			if(ch[j]!=' '){
				str[i]+=ch[j];j++;
			}else{
				i++;j++;
			}
		}
		if(i%2==0){
			for(k=1;k<i/2;k++){
				cout<<str[k]<<" "<<str[i-k+1]<<" ";
			}
			cout<<str[k]<<" "<<str[i-k+1]<<ch[j];
		}else{
			for(k=1;k<=i/2;k++){
				cout<<str[k]<<" "<<str[i-k+1]<<" ";
			}
			cout<<str[i/2+1]<<ch[j];
		}
	}
	return 0;
} 
