#include<bits/stdc++.h>
using namespace std;

int squ1[25][25],squ2[25][25];
int main(){
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				cin>>squ1[i][j];
			}
		}
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				cin>>squ2[i][j];
			}
		}
		//˳ʱ��90 
		bool flag=1;
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(squ1[i][j]!=squ2[j][n+1-i]){
					flag=0;
					break;
				}
			}
		}
		if(flag==1){
			cout<<"1\n";
			continue;
		}
		//��ʱ��90
		flag=1; 
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(squ1[i][j]!=squ2[n+1-j][i]){
					flag=0;
					break;
				}
			}
		}
		if(flag==1){
			cout<<"1\n";
			continue;
		}
		//180
		flag=1; 
		for(int i=1;i<=n;i++){
			for(int j=1;j<=n;j++){
				if(squ1[i][j]!=squ2[n+1-i][n+1-j]){
					flag=0;
					break;
				}
			}
		}
		if(flag==1){
			cout<<"2\n";
			continue;
		}
		cout<<"-1\n";
	}
} 
