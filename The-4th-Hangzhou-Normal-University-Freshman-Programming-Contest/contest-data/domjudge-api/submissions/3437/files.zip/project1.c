#include<stdio.h>
struct sing{
	int w;
	char s[16];
}stff[100001];
int main(void)
{
	struct sing max;
	int n,i,j,k,m,t,flag=0;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d %s",&stff[i].w,stff[i].s);
	}
	scanf("%d",&t);
	printf("%s",stff[n-t].s);
    return 0;
}

