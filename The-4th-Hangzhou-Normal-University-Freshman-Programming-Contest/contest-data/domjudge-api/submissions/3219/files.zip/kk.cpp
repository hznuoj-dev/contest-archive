#include<stdio.h>
#include<string.h>
int main(){
	int N;
	scanf("%d",&N);
	char a[N+1][16];
	int b[N+1];
	int min;
	for(int i=0;i<N;i++){
	scanf("%d %s",&b[i],a[i]);	
	}
	int e;
	scanf("%d",&e);
		for(int j=0;j<=e-1;j++){
		int	t=0;
		min=b[0];
		for(int i=0;i<N-j;i++){
					if(b[i]>min){
						min=b[i];
						t=i;
					}
					
				}
					
				for(int i=t;i<N-j;i++){
								b[i]=b[i+1];	
							}	
				for(int i=t;i<N-j;i++){
					strcpy(a[i],a[i+1]);	
				}
	
					
		
	}
	
				
				
				printf("%s",a[N-e-1]);	
				
			
								
return 0;	
}
