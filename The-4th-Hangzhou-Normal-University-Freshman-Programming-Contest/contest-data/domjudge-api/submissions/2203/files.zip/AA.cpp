#include<bits/stdc++.h>
const int mod=1e9+7;
using namespace std;
const int maxn=100010;
int main(){
	int T;
	cin>>T;
	while(T--){
		map<char,int> mapp;
		int n;
		cin>>n;
		for(int i=0;i<n;++i){
			char x;
			cin>>x;
			mapp[x]++;
		}
		int ans=0;
		int flag=0;		
		for(auto j : mapp){
			if(j.second%2==0) ans+=j.second;
			else flag=1;
		}
		if(flag==1) cout<<ans+1<<endl;
		else cout<<ans<<endl;
	}
	return 0;
}
 
