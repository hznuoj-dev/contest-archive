#include<stdio.h>
#include<math.h>
#include<stdlib.h>
#include<string.h>
#include<ctype.h>
int main()
{
	int i,n,m,k,gong,flag=0,glag=0;
	scanf("%d %d",&n,&m);
	for(i=1;i<=n;i++)
	{
		scanf("%d",&k);
		if(k==0)
		{
			scanf("%d",&gong);
			if(m==0)
			{
				if(gong>=2500)
					flag=1;
			}
			else if(m==1)
			{
				if(gong>2100)
					flag=1;
			}
		}
		if(k==1&&flag==1)
			glag=1;
		if(k==2&&n>1)
			glag=1;
	}
	if(glag)
		printf("haoye");
	else
		printf("QAQ");
	return 0;
} 
