#include<stdio.h>
int main(void){
	int t,n,i,sum;
	char str[5001];
	scanf("%d",&t);
	while(t--){
			int b=0;
		scanf("%d",&n);
		for(i=0;i<n;i++){
			scanf("%d ",&str[i]);
			sum+=str[i];
			if(sum==7777)
				b++;		
		}
	}
	printf("%d\n",b);
return 0;
}

