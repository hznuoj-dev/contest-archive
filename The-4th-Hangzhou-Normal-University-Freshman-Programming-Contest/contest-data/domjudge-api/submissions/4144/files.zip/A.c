#include<stdio.h>
#include<string.h>
int main(void){
	int T, n, i, t, sum, ans, flag1, flag2;
	int w[200];
	char a;
	scanf("%d", &T);
	while(T--){
		sum=0;
		flag1=0;
		flag2=0;
		scanf("%d", &n);
		getchar();
		for(i=0;i<128;++i)w[i]=0;
		for(i=0;i<n;++i){
			scanf("%c", &a);
			getchar();
			t=a;
			if((a>='A' && a<='Z')||(a>='a' && a<='z')) w[t]=w[t]+1;
			//printf("%d!\n", t);//
		}
		for(i=0;i<128;++i){
			if(w[i]==1)flag1=1;
			else if((w[i]>=2)&&(w[i]%2==0)){
				flag2=1;
				sum+=w[i];
			}
			else if(w[i]>=2&&(w[i]%2==1)){
				flag2=1;
				flag1=1;
				sum+=w[i]-1;
			}
			//printf("%d ", w[i]);
		}
		if(flag1==0)ans=sum;
		else if((flag1==1) && (flag2==0))ans=1;
		else if((flag1==1) && (flag2==1))ans=sum+1;
		//printf("%d\n", sum);
		printf("%d\n", ans);
	}
}
