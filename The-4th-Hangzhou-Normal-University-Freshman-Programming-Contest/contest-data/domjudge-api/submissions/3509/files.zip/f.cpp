#include<bits/stdc++.h>
#define wtn tql
using namespace std;
int a[30][30];int b[30][30];
int xt(int n){
	for(int i=1;i<=n;i++){
			for(int u=1;u<=n;u++)if(b[u][i]!=a[u][i])return 0;
	}
	return 1;
}
void xz(int n){
	int c[30][30];
	for(int i=1;i<=n;i++){
			for(int u=1;u<=n;u++)c[u][i]=a[i][n-u+1];
	}
	for(int i=1;i<=n;i++){
			for(int u=1;u<=n;u++)a[u][i]=c[u][i];
	}
}

int main(void){
	int t;cin>>t;
	while(t--){
		int n;cin>>n;
		
		for(int i=1;i<=n;i++){
			for(int u=1;u<=n;u++)cin>>a[u][i];
		}
		for(int i=1;i<=n;i++){
			for(int u=1;u<=n;u++)cin>>b[u][i];
		}
		int sum=0;
		while(xt(n)!=1){
			xz(n);
			sum++;
			if(sum>5){
				sum=-1;
				break;
			}
		}
		if(sum>2)sum-=2;
		cout<<sum<<endl;
		
	}
return 0;
}

