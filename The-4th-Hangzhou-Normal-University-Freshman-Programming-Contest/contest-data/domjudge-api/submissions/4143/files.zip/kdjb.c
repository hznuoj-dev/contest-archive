#include<stdio.h>
int main()
{
	int T;
	int n;
	int a[100000];
	int i;
	int x, y;
	int yizhi;
	int num = 0;
	scanf("%d", &T);
	while (T--)
	{
		num = 0;
		scanf("%d", &n);
		for (i = 0; i < n; i++)
		{
			scanf("%d", &a[i]);
		}
		for (x = 0; x < n; x++)
		{
			yizhi = a[x];
			for (y = x + 1; y < n; y++)
			{
				yizhi = yizhi + a[y];
				if (yizhi == 7777)
				{
					num = num + 1;
					break;
				}

			}
		}
		printf("%d", num);
	}
}