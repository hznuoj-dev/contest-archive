#include<stdio.h>
struct love
{
	long long int a;
	char b[20];
};

int main(void)
{
	int n;
	scanf("%d",&n);
	struct love s[n];
	for(int i=0; i<n ;i++)
	{
		scanf("%lld %s",&s[i].a,s[i].b);
	}
	
	for(int i=1 ;i<n ;i++)
	{
		struct love t;
		int pass = 0;
		for(int j=0;j<n-i ;j++)
		{
			if(s[j].a < s[j+1].a)
			{
				t=s[j];
				s[j]=s[j+1];
				s[j+1]=t;
				pass = 1;
			}
			
		}
		if(pass == 0)
			break;
	}
	int k;
	scanf("%d",&k);
	printf("%s\n",s[k].b);
	return 0;
}
