#include <stdio.h>

int main(){
    int n, t, i, j, k, w;
    scanf("%d", &t);
    int a[t];
    for(i = 0; i < t; i++){
    	scanf("%d", &n);
    	int c1[n][n];
    	int c2[n][n];
    	int b[n][n];
    	for(j = 0; j < n; j++){
    		for(k = 0; k < n; k++){
    			scanf("%d", &c1[j][k]);
    		}
    	}
    	int q = 1;
    	for(j = 0; j < n; j++){
    		for(k = 0; k < n; k++){
    			scanf("%d", &c2[j][k]);
    		    if(c1[j][k] != c2[j][k]){
    				q = 0;
    			}
			}
    	}
    	if(q == 1){
    		a[i] = 0;
    	}
    	else{
    		int w = 1;
    		while(w < 4){
    			int v;
    			q = 1;
    			for(j = 0; j < n; j++){
    				for(k = 0; k < n; k++){
    			        b[k][n - 1 - j] = c1[j][k];			
    				}
    			}
    			for(j = 0; j < n; j++){
    				for(k = 0; k < n; k++){
    			        c1[j][k] = b[j][k];			
    				}
    			}  				 
				for(j = 0; j < n; j++){
    				for(k = 0; k < n; k++){
    		            if(c1[j][k] != c2[j][k]){
    		            	q = 0;
    		            	break;
   			            }			
   					}
   					if(q == 0)   break;
    			}
				if(q == 0){
					w = w + 1;
				}  		  
				else{
					break;
				}  	
    		}
    		if(w >= 4){
    			a[i] = -1;
    		}
    		else{
    			if(w == 3||w == 1){
    				a[i] = 1;
    			}
    			else if(w == 2){
    				a[i] = 2;
    			}
    		}
    	}
    }
	for(i = 0; i < t; i++){
    	printf("%d\n", a[i]);
    }
  
    return 0;
}




