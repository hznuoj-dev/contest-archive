#include<stdio.h>
int main(void)
{
	int a,b,c,d;
	scanf("%d",&a);
	for(b=0;b<a;b++)
	{
		scanf("%d%d",&c,&d);
		if(d==0)
		{
			printf("no\n");
		}
		else{
			printf("yes\n");
		}
	}
	return 0;
}
