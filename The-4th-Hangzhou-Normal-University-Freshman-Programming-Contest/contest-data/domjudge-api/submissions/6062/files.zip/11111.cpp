#include<stdio.h>
#include<string.h>
int main()
{
	int t,n[100000],m[100000],q,k,i,j;
	char a[1000000];
	scanf("%d",&t);
	for(int i=0;i<t;i++)
	{
		scanf("%d %s",&n[i],&a[15*i]);
	}
	for(int i=0;i<t;i++)
	{
		m[i]=n[i];
	}
	for(i=0; i<t; i++)
	{
        for(j=0; j<t-i; j++)
		{
            if(n[j] <n[j+1])
			{
                t = n[j];
                n[j] = n[j+1];
                n[j+1] = t;
            }
        }
    }
	scanf("%d",&k);
	for(i=0;i<t;i++)
	{
		if(n[k]==m[i])
		{
			q=i;
			break;
		}
	}	
	int b=(q)*15;
	for(i=b;i<b+15;i++)
	{
		if(a[i]==' ')
		break;
		printf("%c",a[i]);
		
	}	
}
