#pragma warning(disable:4996)
/*#include<stdio.h>
struct biaolie
{
	char name[16];
	int xiaidu;
}gedan[10001];
int main()
{
	int n, i, k, max, j;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &gedan[i].xiaidu);
		scanf("%s", gedan[i].name);
	}
	scanf("%d", &k);
	for (i = 0; i < k; i++)
	{
		max = gedan[0].xiaidu;
		for (j = 0; j < n; j++)
		{
			if (gedan[j].xiaidu > max)
				max = gedan[j].xiaidu;
		}
		for (j = 0; j < n; j++)
		{
			if (max == gedan[j].xiaidu)
			{
				gedan[j].xiaidu = 0;
				break;
			}
		}
	}
	max = gedan[0].xiaidu;
	for (i = 0; i < n; i++)
	{
		if (gedan[i].xiaidu > max)
		{
			max = gedan[i].xiaidu;
		}
	}
	for (i = 0; i < n; i++)
	{
		if (max == gedan[i].xiaidu)
		{
			printf("%s", gedan[i].name); break;
		}
	}
	return 0;
}*/
#include<stdio.h>
int main()
{
	int T, n, x;
	scanf("%d", &T);
	while (T--)
	{
		scanf("%d%d", &n, &x);
		if (x == 0)
		{
			printf("no\n");
		}
		else printf("yes\n");
	}
	return 0;
}