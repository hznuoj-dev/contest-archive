#include<stdio.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,i,a[n+1],j,k,c[100005]={0},d[n+1];
	char x,b[100005][16];
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%d",&a[i]);
		d[i]=a[i];
		getchar();
		j=1;
		while((x=getchar())!='\n'){
			b[i][j]=x;
			j++;
		}
		c[i]=j-1;
	}
	scanf("%d",&k);
	sort(a+1,a+1+n);
	for(i=1;i<=n;i++){
		if(a[n-k]==d[i]) break;
	}
	for(j=1;j<=c[i];j++){
		putchar(b[i][j]);
	}
}
