#include<stdio.h>
int main(){
	int t,n;
	char s;
	int x,l,a[257],sum;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(x=0;x<257;x++){
			a[x]=0;
		}
		l=0;
		sum=0;
		for(x=0;x<n;x++){
			scanf(" %c",&s);
			a[s]++;
		}
		for(x='a'+0;x<='z'+0;x++){
			sum+=a[x];
			l+=(a[x]/2)*2;
		}
		for(x='A'+0;x<='Z'+0;x++){
			sum+=a[x];
			l+=(a[x]/2)*2;
		}
		if(sum!=l){
			l++;
		}
		printf("%d\n",l);
	}
	return 0;
}
