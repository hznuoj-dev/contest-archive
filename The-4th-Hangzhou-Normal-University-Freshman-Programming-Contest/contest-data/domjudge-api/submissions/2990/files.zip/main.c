#include<stdio.h>
#include<string.h>
char a[100000];
int b[100000];
int main()
{
	int t,n,sum,len,totle;
	int i, j,k,term;
	scanf("%d", &t);
	while (t--)
	{
		scanf("%d", &n);
		getchar();
		gets(a);
		len = strlen(a);
		k = 0;
		totle = 0;
		for (i = 0; i < len; i++)
		{
			sum = 1;
			if (a[i] == ' ' || a[i] == '\0')
				continue;
			for (j = i+1; j < len; j++)
			{
				if (a[i] == a[j] && a[i] != '\0' && a[j] != '\0'&&a[i]!=' '&&a[j]!=' ')
				{
					sum += 1;
					a[j] = '\0';
				}
			}
			b[k] = sum;
			k += 1;
		}
		for (i = 0; i < k-1; i++)
		{
			for (j = i + 1; j < k; j++)
			{
				if (b[i] < b[j])
				{
					term = b[i];
					b[i] = b[j];
					b[j] = term;
				}
			}
		}
		totle += b[0];
		for (i = 1; i < k; i++)
		{
			if (b[0] % 2 == 0)
			{
				if (b[i] % 2 == 0)
				{
					totle += b[i];
					continue;
				}
				else
				{
					totle += b[i];
					break;
				}
			}
			else
			{
				if (b[i] % 2 == 0)
				{
					totle += b[i];
					continue;
				}
				else
					break;
			}
		}
		printf("%d\n", totle);
	}
	return 0;
}
