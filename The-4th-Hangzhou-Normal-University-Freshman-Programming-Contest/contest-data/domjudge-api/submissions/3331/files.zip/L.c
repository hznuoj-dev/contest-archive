#include<stdio.h>
#include<string.h>
#include<stdlib.h>

int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		int n,x;
		scanf("%d%d",&n,&x);
		int i=1;
		int lon=n*x;
		for(;i<=lon;i++)
		{
			int len=x*i;
			if(len==n) 
			{
				printf("yes\n");
				break;
			}
			else if(len>n)
			{
				x=x*i%n;
			}
			
			
		}
		if(i>lon) printf("no\n");
	}	  
	return 0;
}

