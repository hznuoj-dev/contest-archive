#include<stdio.h>
#include<string.h>
char a[100000]; 
main(){
	int f,i,T,n,b[200]={0},sum;
	scanf("%d",&T);
	while(T--)
	{
		f=1;sum=0;
		memset(b,0,sizeof(b));
		memset(a,0,sizeof(a));
		scanf("%d",&n);
		getchar();
		for(i=0;i<2*n-1;i++)
		{
			scanf("%c",&a[i]);
			if((a[i]>='a'&&a[i]<='z')||(a[i]>='A'&&a[i]<='Z'))
				b[a[i]]++;
		}
		for(i=0;i<200;i++)
		{
			if(b[i]%2==0)
				sum+=b[i];
			if(b[i]%2!=0&&f)
			{
				sum++;
				f=0;
			}
		}
		printf("%d\n",sum);
	}

}
