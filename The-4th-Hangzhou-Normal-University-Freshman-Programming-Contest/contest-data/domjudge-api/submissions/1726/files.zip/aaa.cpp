#include<stdio.h>
int main(){
	int i,number,n,x;
	scanf("%d",&number);
	for(i=1;i<=number;i++){
		scanf("%d%d",&n,&x);
		if(x>=0&&n!=1){
			printf("yes\n");
		}else{
			printf("no\n");
		}
	}
	return 0;
}
