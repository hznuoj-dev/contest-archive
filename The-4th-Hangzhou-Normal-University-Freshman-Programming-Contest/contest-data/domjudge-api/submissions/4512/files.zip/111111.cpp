#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<map>
#include<iomanip>
#include<ctime>
using namespace std;
int main()
{
	int t;
	cin >> t;
	while (t--)
	{
		string a[1010];
		char x;
		int n = 0;
		for (int i = 0;; i++)
		{
			n++;
			cin >> a[i];
			int l = a[i].length();
			if (a[i][l-1] == '.' || a[i][l-1] == '!' || a[i][l-1] == '?')
			{
				x = a[i][l-1];
				break;
			}
		}
		for (int i = 0, j = n - 1; i < j; i++, j--)
		{
			if (j == n - 1)
			{
				cout << a[i];
				cout << ' ';
				cout << a[j]<<'\b';
			}
			else
			{
				cout << ' ';
				cout << a[i];
				cout << ' ';
				cout << a[j];
			}
			
		}
		if (n % 2 != 0)
			{
			if (n == 1)
				cout << a[(n - 1) / 2]<<"\b";
			else
				cout<<' ' << a[(n - 1) / 2];
			}
		cout << x << endl;
	}
}