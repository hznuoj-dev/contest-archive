#include <stdio.h>
int main(void) {
	struct sing{
		 long long int num;
		char ch[15];
	}sing[10000],t;
	int n,i,x,j;
	scanf("%d",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&sing[i].num,sing[i].ch);
	}
	scanf("%d",&x);
	for(i=0;i<n;i++){
		for(j=1;j<n;j++){
			if(sing[j].num>sing[j-1].num){
				t=sing[j];
				sing[j]=sing[j-1];
				sing[j-1]=t;
			}
		}
	}
	printf("%s",sing[x].ch);
	return 0;
}

