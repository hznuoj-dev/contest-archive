#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#define pzc 666
using namespace std;
int main()
{
	long long x,y;
	int t,n,i,j,k,a,b,c,l,f;
	char ch[40][35],s;
	cin>>t;
	while(t--)
	{
		memset(ch,0,sizeof(ch));
		i=1;
		while(scanf("%s",ch[i]),strchr(ch[i],'.')==NULL&&strchr(ch[i],'!')==NULL&&strchr(ch[i],'?')==NULL)
		{
			i++;
		}
		l=strlen(ch[i]);
		f=ch[i][l-1];
		ch[i][l-1]='\0';
		j=1;k=i;
		while(j<=k)
		{
			if(k-j>1)
				cout<<ch[j]<<" "<<ch[k]<<" ";
			else if(k-j==1) cout<<ch[j]<<" "<<ch[k];
			else  cout<<ch[j];
			j++;k--;
		}
		printf("%c\n",f);
		
	}
	;
}
