#include<stdio.h>
int main(){
  int n,m;
  int a[11];
  int flag=0;
  int flag1=0;
  int whether=0;
  scanf("%d %d",&n,&m);
  int sum=0;
  int b[11];
  int q=0;
  for(int i=0;i<n;i++){
    scanf("%d",&a[i]);
	if(a[i]==0){
	 scanf("%d",&b[q]);
	 q+=1;
	}
	else if(a[i]==1){
	flag=1;
	}
	else if(a[i]==2){
	flag1=1;
	}
  }
  if(flag==0&&flag1==0){
     printf("QAQ\n");
	 return 0;
  }
  if(flag==1){
	  if(m==0){
		  for(int i=0;i<q;i++){
		  if(b[i]>=2500){
		  printf("haoye\n");
		  return 0;
		  }
		 }
	  }
	  else if(m==1){
		   for(int i=0;i<q;i++){
		  if(b[i]>2100){
		  printf("haoye\n");
		  return 0;
		  }
		 }
	  }
  }
  if(flag1==1 && n>=2){
	   printf("haoye\n");
	   return 0;
  }
  printf("QAQ\n");
  return 0;
}