#include<stdio.h>
#include<stdlib.h>

struct Stu{
	char name[20];
	 int num;
}a[100100];
 int cmp(const void *p,const void *q)
{
	struct Stu *pp=(struct Stu *)(p);
	struct Stu *pq=(struct Stu *)(q);
	int a=pp->num;
	int b=pq->num;
	return b-a; 
}
int main()
{
	
	int t,i,n;
	scanf("%d",&t);
	for(i=0;i<t;++i)
	{
		scanf("%d%s",&a[i].num,a[i].name);
	}
	qsort(a,t,sizeof(struct Stu),cmp);
	scanf("%d",&n);
	printf("%s",a[n].name); 
	return 0;
}
