#include<stdio.h>
int main() {
	int a[10000],flag[10000];
	char c[10000][16];
	int n, i, t, k, ci;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d %s", &a[i], c[i] );
		flag[i] = 1;
	}
	scanf("%d", &ci);
	for (t = 1; t <= ci; t++)
	{
		k = 0;
		for (i = 1; i < n; i++)
		{
			if (a[i] > a[k])
			{
				if (flag[i] == 1)
					k = i;
			}
		}
		flag[k] = 0;
	}
	k = 0;
	for (i = 1; i < n; i++)
	{
		if (a[i] > a[k] && flag[i] == 1)
		{
			k = i;
		}
	}
	printf("%s\n",c[k]);
	return 0;
}