#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int n,m,temptumb=0,tempblack=0,tempatk=0,card,atk;
	scanf("%d %d",&n,&m);
	while(n--)
	{
		scanf("%d",&card);
		if(card==0)
		{
			scanf("%d",&atk);
			if(atk>=2500&&m==0)
			{
				tempatk=1;
			}
			if(atk>2100&&m==1)
			{
				tempatk=1;
			}
		}
		if(card==1)
		{
			temptumb=1;
		}
		if(card==2)
		{
			tempblack=1;
		}
	}
	if(tempblack==1&&n>1)
	{
		printf("haoye\n");
	}
	else if(tempatk==1&&temptumb==1)
	{
		printf("haoye\n");
	}
	else
	{
		printf("QAQ\n");
	}
 } 
