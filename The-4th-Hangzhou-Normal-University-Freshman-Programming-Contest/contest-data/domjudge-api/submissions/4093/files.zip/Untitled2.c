#include<stdio.h>
int main()
{
	int t,n,a;
	scanf("%d",&t);
	while(t--)
	{
		scanf("%d %d",&n,&a);
		if(a!=0)
			printf("yes\n");
		else
			printf("no\n");
	}
	return 0;
}
