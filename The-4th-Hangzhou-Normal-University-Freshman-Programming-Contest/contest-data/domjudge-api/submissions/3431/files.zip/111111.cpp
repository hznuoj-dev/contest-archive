#include<iostream>
#include<string>
#include<cmath>
#include<algorithm>
#include<cstring>
#include<vector>
#include<cstdlib>
#include<cstdio>
#include<map>
#include<iomanip>
#include<ctime>
using namespace std;
int a[10010];
bool cmp(int a, int b)
{
	return a > b;
}
int main()
{
	int t;
	cin >> t;
	while (t--)
	{
		int n;
		cin >> n;
		for (int i = 0; i < n; i++)
		{
			cin >> a[i];
		}
		sort(a, a + n,cmp);
		int cou = 0;
		for (int i = 0; i < n; i++)
		{
			int sum = 0;
			for (int j = i; j < n; j++)
			{
				sum += a[j];
				if (sum > 7777)
				{
					sum -= a[j];
				}
				else if (sum == 7777)
				{
					cou++;
				}
			}
		}
		cout << cou << endl;
	}
}