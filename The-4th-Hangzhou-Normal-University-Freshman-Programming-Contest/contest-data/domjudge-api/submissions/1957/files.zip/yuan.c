#include<stdio.h>
#pragma warning(disable:4996)
struct songs
{
	int likes;
	char name[20];
}s[111111];
int main()
{
	int n, i, j, k, t;
	struct songs* max;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &s[i].likes);
		scanf("%s", s[i].name);
	}
	scanf("%d", &k);

	max = &s[0];
	t = 0;
	for (i = 0; i < n; i++)
	{
		for (j = 0; j < n; j++)
		{
			if (max->likes < s[j].likes)
				max = &s[j];
		}
		t++;
		if (t == k + 1)
		{
			printf("%s", max->name);
			break;
		}
		else
			max->likes = -1;
	}
	return 0;
}