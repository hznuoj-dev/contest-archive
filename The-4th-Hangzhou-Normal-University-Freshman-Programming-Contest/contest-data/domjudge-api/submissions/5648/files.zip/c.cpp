#include<bits/stdc++.h>
#define wtn tql
using namespace std;
struct wp {
	int x,y;
};wp wps[2010][2020]; 
void find(int x0,int y0,int ti){
	for(int i=0;i++;i<n){
		if(wps[i][timers].bnz==0&&wps[i][timers].x=x0&&wps[i][timers].y=y0){
			wps[i][timers].bnz=1;
			wps[i][timers].bnztime=ti;
		}
	}
}
int x0[2020],y0[2020];//�������� 
int main(void){
	int n;cin>>n;
	for(int i=0;i<n;i++){
		int y,x;cin>>x>>y;
		wps[i][timers][0].x=x;wps[i][timers][0].y=y;
	}
	
	int q;cin>>q;
	int timers=0;
	while(q--){
	timers++;
		int cz;cin>>cz;getchar();
		switch(cz){
			case 1:
				char fx;
				int step;
				cin>>fx>>step;
				if(fx=='Y')y0[timers]=y0[timers-1]+step;
				if(fx=='X')x0[timers]=x0[timers-1]+step;
				if(x0[timers]*y0[timers]!=0){//ǿ�ƻع�ԭ�� 
					x0[timers]=0,y0[timers]=0;
				} 
				find(x0[timers],y0[timers],timers);
				
				
				break;
			case 2:
				for(int i=0;i<n;i++){
					wps[i][timers].x=-wps[i][timers].x;wps[i][timers].y=-wps[i][timers].y;
				}
				break;
			case 3:
				for(int i=0;i<n;i++){
					if(wps[i][timers].x=0)wps[i][timers].x=wps[i][timers].y;
					else if(wps[i][timers].y=0)wps[i][timers].y=wps[i][timers].-x;
				}
				break;
			case 4:
				break;
			
		}
		
	} 
return 0;
}

