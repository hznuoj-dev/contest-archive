#include <stdio.h>
#include <string.h>
int main(void)
{
	int t,d;
	long long n,sum;
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		sum=0;
		long long b[123]={0};
		scanf("%lld",&n);
		getchar();
		char a[n+1];
		scanf("%c",&a[1]);
		getchar(); 
		for(int i=2;i<=n;i++)
		{
			scanf("%c",&a[i]);
			getchar();
			d=a[i];
			b[d]++;
		}
		for(int i='A';i<='Z';i++)
		{
			sum+=b[i]/2*2;
		}
		for(int i='a';i<='z';i++)
		{
			sum+=b[i]/2*2;
		}
		if(n>sum)
		{
			sum++;
		}
		if(sum==1&&n==2&&a[1]==a[2])
		{
			sum++;
		}
		printf("%lld\n",sum);
		
	}
	return 0;
}
