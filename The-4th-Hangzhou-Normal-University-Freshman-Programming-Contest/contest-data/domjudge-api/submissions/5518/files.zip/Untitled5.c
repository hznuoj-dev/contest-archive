#include<stdio.h>
#include<stdlib.h>
#include<string.h>		
int main()
{
	int n,m,i,j,a,q=0,flag=0;
	int x[10],k[100];
    scanf("%d%d",&n,&m);
    for(i=0;i<n;i++)
    {
    	scanf("%d",&a);
    	x[a]++;
    	if(a==0)
    	{
    		scanf("%d",&k[q]);
    		q++;
		}
	}
	if(x[2]!=0&&(n-x[2]>=1))
	{
		printf("haoye\n");
	}
	else if(x[0]!=0&&x[1]!=0)
	{
		if(m==0)
		{
			for(i=0;i<q;i++)
			{
				if(k[i]>=2500)
				{
					flag=1;
					printf("haoye\n");
					break;
				}				
			}
			if(flag==0)
			{
				printf("QAQ\n");
			}
		}
		else if(m==1)
		{
			for(i=0;i<q;i++)
			{
				if(k[i]>=2100)
				{
					flag=1;
					printf("haoye\n");
					break;
				}				
			}
			if(flag==0)
			{
				printf("QAQ\n");
			}
		}
	}
	else
	{
		printf("QAQ\n");
	}
}
 
