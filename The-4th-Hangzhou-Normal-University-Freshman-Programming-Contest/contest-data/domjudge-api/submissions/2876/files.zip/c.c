#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
main(){
	int i,j,len,n,z;
char a[100][100],d;
scanf("%d",&n);
while(n--){
	z=0;
	i=1;
	while(scanf("%s",a[i])!=EOF){
	len=strlen(a[i]);
	if(a[i][len-1]=='.'||a[i][len-1]=='!'||a[i][len-1]=='?'){
	break;
	}
	i++;
	}
d=a[i][len-1];
a[i][len-1]='\0';
for(j=1;j<=i;j++){
	if(j==1)
		printf("%s",a[j/2+1]);
	else if(j%2==1)
printf(" %s",a[j/2+1]);
	else
		printf(" %s",a[i-j/2+1]);
}
printf("%c\n",d);
}
}
