#include<stdio.h>
#include<string.h>
#include<stdlib.h>
struct student{
	int w;
	char s[20];
};
int cmp(const void *a,const void *b)
{
	struct student *p=(struct student *)a,*q=(struct student *)b;
	return q->w - p->w;
}
int main(){
	int n,i,k;
	struct student stu[10005];
	scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%d %s",&stu[i].w,stu[i].s);
		}
		scanf("%d",&k);
		qsort(stu,n,sizeof(struct student),cmp);
		printf("%s",stu[0+k].s);
	return 0;
}
