#include <stdio.h>
#include <string.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n;
		int a[52];
		scanf("%d",&n);
		int i;
		for(i=0;i<52;i++){
			a[i]=0;
		}
		char temp;
		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&temp);
			if(temp>='A'&&temp<='Z'){
				a[temp-'A']++;
			}
			else if(temp>='a'&&temp<='z'){
				a[temp-'a'+26]++;
			}
		}
		int len = 0;
		int max=0;
		for(i=0;i<52;i++){
			if(a[i]!=0){
				if(a[i]%2==0){
					len+=a[i];	
				}
				else if(a[i]%2==1){
					if(max<a[i])max = a[i];
				}
			}
		}
		len=len+max;
		printf("%d\n",len);
	}
}
