#include<stdio.h>
#include<string.h>
int main()
{
    int n, m, i, song[11], lu[10], mudi = 0, chuwai = 0, gua = 0;
    scanf("%d %d", &n, &m);
    
       
        for (i = 1; i <= n; i++)
        {
            scanf("%d", &song[i]);
            if (song[i] == 0)
            {
                scanf("%d", &lu[i]);
                if ((lu[i] >= 2500 && m == 0) || (lu[i] > 2100 && m == 1))
                    mudi = 1;
            }
        }
        if (mudi == 0)
        {
            for (i = 1; i <= n; i++)
            {
                if (song[i] == 2)
                    gua = 1;
                if (gua == 1 && n >= 2) {
                    printf("haoye");
                    return 0;
                }

            }
        }
        if (mudi == 1)
        {
            for (i = 1; i <= n; i++)
            {
                if (song[i] == 1)
                    chuwai = 1;
            }
            if (chuwai == 1) {
                printf("haoye");
                return 0;
            }
        }
        printf("QAQ");
    }
