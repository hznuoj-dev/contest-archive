#include<stdio.h>
#include<string.h>
int main(){
	int n;
	scanf("%d",&n);
for(n;n>0;n--){
	int a,x;
	int flag = 0;
	scanf("%d %d",&a,&x);
	if(x==0)
	printf("no\n");
	else{
	
	for(int i =0;i<a;i++){
		int temp = i;
		if(flag)
		break;
		for(int i =1;i<=20;i++)
		{temp = (temp +1+x)%a - 1;
		if(temp = i)
		{
		flag = 1;
		break;
		}
		}
		
	}
	if(flag)
	printf("yes\n");
	else
	printf("no\n");
}
}
}
