#include<bits/stdc++.h>

using namespace std;
int a[25][25],b[25][25];
int a1[25][25],a2[25][25],a3[25][25];
int ans[4];
void run(int n)
{
	for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				cin >> a[i][j];
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				cin >> b[i][j];
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				a1[j][n-i+1]=a[i][j];
				a2[i][n-j+1]=a[i][j];
				a3[n-j+1][i]=a[i][j];
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(a1[i][j]!=b[i][j]) 
				{
					ans[1]=1;
				}
			}
		}
		for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(a[i][j]!=b[i][j]) 
				{
					ans[0]=1;
				}
			}
		}
			for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(a2[i][j]!=b[i][j]) 
				{
					ans[2]=1;
				}
			}
		}
			for(int i=1;i<=n;i++)
		{
			for(int j=1;j<=n;j++)
			{
				if(a3[i][j]!=b[i][j]) 
				{
					ans[3]=1;
				}
			}
		}
		if(ans[1]==0) cout << '1' << '\n';
		else if(ans[3]==0)  cout << '1' << '\n';
		else if(ans[2]==0)  cout << '2' << '\n';
		else if(ans[0]==0) cout << '0' << '\n';
		else cout << "-1"<< '\n';
}
int main()
{
	int t;
	cin >> t;
	for(int i=1;i<=t;i++)
	{
		int n;
		cin >> n;
		run(n);
	}
	return 0;
}
