#include<stdio.h>
int a[55] = { 0 };
void pre() {
	for (int i = 0; i < 52; i++) {
		a[i] = 0;
	}
}
int main() {
	int n, t, i, o = 0, l, x;
	char c;
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &n);
		n = 2 * n;
		l = 0;
		o = 0;
		pre();
		while (n--) {
			scanf("%c", &c);
			if (c != '\n' && c != ' ') {
				x = c - 65;
				if (x > 25) {
					x -= 6;
				}
				a[x]++;
			}
		}
		for (i = 0; i < 52; i++) {
			if (a[i] % 2 == 1) {
				l += a[i] - 1;
				o++;
			}
			else {
				l += a[i];
			}
		}
		if (o > 0) {
			l++;
		}
		printf("%d\n", l);
	}
}