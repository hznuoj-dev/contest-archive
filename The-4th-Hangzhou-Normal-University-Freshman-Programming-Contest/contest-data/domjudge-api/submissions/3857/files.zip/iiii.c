#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct s{
	int w;
	char s[16];
};
int comp(const int*k,const int*q){
	return ((struct s *)q)->w-((struct s *)k)->w;
}
int main(void) {
	int n,x,i,j;
	scanf("%d",&n);
	struct s st[n];
	for(i=0;i<n;i++){
		scanf("%d %s",&st[i].w,st[i].s);
	}
	scanf("%d",&x);
	qsort(st,n,sizeof(struct s),comp);
	printf("%s",st[x].s);
	return 0;
}
