#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>
int comp(const void *p,const void *q){
	return (*(int *)q-*(int *)p);
}
int main(){
	int i,n,j,z1,z2,z3,T;
	scanf("%d",&T);
	while(T--){
		scanf("%d",&n);
		int x[n][n],y[n][n];
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
				scanf("%d",&x[i][j]);
		for(i=0;i<n;i++)
			for(j=0;j<n;j++)
				scanf("%d",&y[i][j]);
		z1=0,z2=0,z3=0;
		for(i=0;i<n;i++)
			for(j=0;j<n;j++){
					if(x[i][j]==y[j][n-i-1])
						z1+=1;
					if(x[i][j]==y[n-j-1][i])
						z2+=1;
					if(x[i][j]==y[n-i-1][n-j-1])
						z3+=1;
				}
		if(z1==n*n||z2==n*n)
			printf("1\n");
		else if(z3==n*n)
			printf("2\n");
		else
			printf("-1\n");
		}
	}
	

