#include<cstdio> 
#include<string>
#include<bits/stdc++.h>
using namespace std;
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		char c[1010][40],s;
		int p=0,q=0;
		getchar();
		while(scanf("%c",&s)&&s!='\n'){
			if(s=='.'||s=='!'||s=='?')break;
			if(s!=' '){
				c[p][q]=s;
				q++;
			}
			else {
				c[p][q]='\0';
				p++,q=0;
			}
		}
		for(int i=0;i<p/2;i++){
			printf("%s ",c[i]);
			if(p%2==0&&i==p/2)	printf("%s",c[p-i]);
			else	printf("%s ",c[p-i]);
			
		}
		if (p%2==0)printf("%s",c[p/2]);
		else {
			printf("%s %s",c[p/2],c[p/2+1]);
		}
		printf("%c\n",s);
	}
}
