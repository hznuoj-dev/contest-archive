#include<stdio.h>
#include<stdlib.h>
struct fa{
	int a;
	char b[16];
};
int comp(const void *a,const void *b){
	struct fa *p=(struct fa*)a,*q=(struct fa*)b;
	return q->a-p->a;
}
int main(){
	int t,n,m=0,i,j,x,y;
	struct fa sa[100000];
	scanf("%d",&t);
	while(t--){
		scanf("%d",&sa[m].a);
		scanf("%s",sa[m].b);
		m++;
	}
	scanf("%d",&n);
	qsort(sa,m,sizeof(sa[0]),comp);
	printf("%s",sa[n].b);
	return 0;
}
