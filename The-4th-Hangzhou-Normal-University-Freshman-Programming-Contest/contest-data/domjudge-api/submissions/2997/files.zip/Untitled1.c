#include <stdio.h>
#include <string.h>
int main(void){
	int t;
	scanf("%d",&t);
	while(t--){
		int k=0, n, m, j=0, i;
		scanf("%d %d",&n,&m);
		if(m>n){
			k=m/n;
			if(n*k==m&&m%n!=0)
				printf("no\n");
			else
				printf("yes\n");
		}
		else{
			for(;m<=n;m+=m){
				if(m==n)
					printf("yes\n");
			}
			if(m>n)
				printf("no\n");
		}
	}
}

