#include<stdio.h>
int main(void){
	int t, n, a[5000], sum, ans, i, j;
	scanf("%d", &t);
	while(t--){
		sum=0;
		ans=0;
		scanf("%d", &n);
		for(i=0;i<n;++i){
			scanf("%d", &a[i]);
		}
		for(i=0;i<n;++i){
			sum=0;
			for(j=i;j<n;++j){
				sum+=a[j];
				if(sum==7777){ans++;}
				else if(sum>7777){break;}
			}
		}
		printf("%d", ans);
	}
	return 0;
}
