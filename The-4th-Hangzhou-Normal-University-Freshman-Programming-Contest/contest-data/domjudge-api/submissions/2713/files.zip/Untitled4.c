#include<stdio.h>
#include<string.h>
main(){
	int t;
	int m,n,len,i,j,k;
	char temp;
	char a[200000];
	char b[100000];
	scanf("%d",&t);
	while(t--){
		len=0;
		scanf("%d",&n);
		m=n;
		getchar();
		gets(a);
		for(i=0,j=0;i<2*n;i=i+2,j++){
			b[j]=a[i];
		}
		for(i=0;i<n;i++){
			for(j=i+1;j<n;j++){
				if(b[j]==b[i]){
					len=len+2;
					for(k=j;k<n;k++){
						b[k]=b[k+1];
					}
					n--;
				}
			}
		}
		if(len!=m){
			len++;
		}
		printf("%d\n",len);
	}
}



