#include <stdio.h>
#include <string.h>
#include <stdlib.h>

struct si {
	int love;
	char name[16];
};
struct si song[100050];

int main(void) {
	long long t;
	int n, i, j, k, i1, j1, flag;
	struct si x;
	scanf("%d", &n);
	for (i = 0; i < n; ++i) {
		scanf("%d", &song[i].love);
		scanf("%s", song[i].name);
	}
	scanf("%lld", &t);
	for (i = 1; i < n; ++i) {
		for (j = 0; j < n - i; ++j) {
			if (song[j].love < song[j + 1].love) {
				x = song[j];
				song[j] = song[j + 1];
				song[j + 1] = x;
			}
		}
	}
	printf("%s\n", song[t].name);




}