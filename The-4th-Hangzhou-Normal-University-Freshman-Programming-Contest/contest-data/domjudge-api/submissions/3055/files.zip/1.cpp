#include<iostream>
#include<string>
#include<cstring>
#include<algorithm>
#include<cmath>
#include<ctype.h>
using namespace std;

int main()
{
	int t;
	cin>>t;
	for(int w=0;w<t;w++)
	{
		int n;
		cin>>n;
		int a[100005];
		for(int i=0;i<n;i++)
		{cin>>a[i];}
		int sum=0;
		for(int i=0;i<n;i++)
		{
			int num=a[i];
			for(int q=i+1;q<n;q++)
			{
				num+=a[q];
				if(num==7777)
				{sum++;break;}
				else if(num>7777)
				{break;}
			}
		}
		cout<<sum<<endl;
	}
}
