#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct s{
		int a;
		char b[16];
		};
int comp(const int*p,const int*q){
	return ((struct s *)q)->a-((struct s *)p)->a;
}
int main(void) {
	int n,x,i,j;
	scanf("%d",&n);
	struct s st[n];
	for(i=0;i<n;i++){
		scanf("%d%s",&st[i].a,st[i].b);
	}
	scanf("%d",&x);
	qsort(st,n,sizeof(struct s),comp);
	printf("%s",st[x].b);	
	return 0;
}

