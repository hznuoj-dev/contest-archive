#include<bits/stdc++.h>
using namespace std;
int n,m;
int x,a,k;
int zt;// 0 ���� 1 Ĺ�� 2���ˣ�
int main(){
	cin >> n >> m;
	if(m==0)k=2101;
	else k=2500;
	
	while(n--){
		cin >> x;
		if(x==2&&n>0)zt=2;
		if(x==1&&zt==1)zt=2; 
		a=0;
		if(x==0) cin >>a;
		if(a>=k&&zt!=2) zt= 1;
	} 
	if(zt==2)cout << "haoye";
	else cout << "QAQ"; 


return 0;
}

