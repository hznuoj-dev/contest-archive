#include<bits/stdc++.h>
using namespace std;
int main(void){
	int n,m,ent,atk,max,min;min=0;
	max=0;int flag=0;int flagg=0;
	scanf("%d%d",&n,&m);
	for (int i=1;i<=n;i++){
		scanf("%d",&ent);
		if (ent==0){
			scanf("%d",&atk);
			if (atk>max) max=atk;
		}
		else if(ent==1) flag++;
		else if (ent==2) flagg++;
	}
	if (m==0) min=2500;
	else min=2100;
	if (max>=min&&flag>0) printf("haoye");
	else if(n>=2&&flagg>0) printf("haoye");
	else printf("QAQ");
	return 0;
}

