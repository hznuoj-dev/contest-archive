#include<stdio.h>
#include<stdlib.h>
struct pome {
	int a;
	char str[20];
};
int comp(const void* p, const void* q) {
	return (*(struct pome*)q).a - (*(struct pome*)p).a;
}
int main() {
	int n, k;
	struct pome c[100000];
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%d%s", &c[i].a, c[i].str);
	}
	qsort(c, n, sizeof(struct pome), comp);
	scanf("%d", &k);
	printf("%s", c[k].str);
	return 0;
}
