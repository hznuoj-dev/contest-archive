#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
char b[100001];
int a[60];
int main () {
    cnm;
    int t;
    cin >> t;
    while (t--){
    	int f1=0;
    	memset(a,0,sizeof(a));
    	memset(b,0,sizeof(b));
    	int max = -1e9;
    	int ans;
    	int n,k;
    	cin >> n;
    	for (int i = 0 ; i<n ; i++){
    		cin >> b[i];
    		a[b[i]-65]++;
		}
		for (int i = 0 ; i<60 ; i++){
			if (a[i]%2==1&&a[i]>max) {
				max=a[i];
				f1=1;
				k=i;
			}
		}
		if (f1) {
			ans = max;
			a[k]=0;
		}
		else ans = 0;
		for (int i = 0 ; i<60 ; i++){
			if (a[i]%2==0) ans+=a[i];
			else ans+=a[i]-1; 
		}
		cout << ans << endl;
	}
    return 0;
}
