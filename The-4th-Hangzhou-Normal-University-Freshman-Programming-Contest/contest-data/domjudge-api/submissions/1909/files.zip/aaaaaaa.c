#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
struct gg{
	char name[20];
	int x;
}a[100005];
int com(const void*a,const void*b)
{
	const struct gg* p=a;
	const struct gg* q=b;
	return q->x-p->x;
}
int main(){
	int n,i,k; 
	scanf("%d",&n);
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&a[i].x,a[i].name);
		getchar();
	}
	scanf("%d",&k);
	qsort(a,n,sizeof(a[0]),com);
	printf("%s",a[k].name);
	return 0;
}
