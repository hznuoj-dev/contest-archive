#include<stdio.h>
#include<stdlib.h>
#include<string.h>		
char str[1010][50];
int main()
{
	int n,t,i,j,ans,b[1000]={0};
	scanf("%d",&t);
	while(t--)
	{
		i=0;
		while(scanf("%s",str[i])!=EOF)
		{
			if(str[i][strlen(str[i])-1]=='.'||str[i][strlen(str[i])-1]=='!'||str[i][strlen(str[i])-1]=='?')
			{
				break;
			}
			i++;
		}
		printf("%s ",str[0]);
		for(j=0;j<strlen(str[i])-1;j++)
		{
			printf("%c",str[i][j]);
		}
		for(j=1;j<(i+1)/2;j++)
		{
			printf(" %s %s",str[j],str[i-j]);
		}
		if(i%2==0)
		{
			printf(" %s",str[j]);
		}
		printf("%c\n",str[i][strlen(str[i])-1]);
	}
} 
 
