#include <stdio.h>
#include <stdlib.h> 
int comp(const void *p,const void *q);
int main(void){
	int i,n,k;
	scanf("%d",&n);
	int w[n],c[n];
	char str[n][16];
	for(i=0;i<n;i++)
	{
		scanf("%d%s",&w[i],str[i]);
		c[i]=w[i];
	}
		scanf("%d",&k);
	qsort(w,n,sizeof(int),comp);
	for(i=0;i<n;i++)
	{
		if(w[k]==c[i])
		printf("%s\n",str[i]);
	}
	return 0;
}
int comp(const void *p,const void *q)
{
	return (*(int *)p-*(int *)q);
}
