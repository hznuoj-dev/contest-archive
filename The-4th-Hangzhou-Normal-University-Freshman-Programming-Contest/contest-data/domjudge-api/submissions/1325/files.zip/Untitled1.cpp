#include<stdio.h>
int main()
{
	int i;
	scanf("%d",&i);
	while(i--)
	printf("Welcome to HZNU\n");
} 
