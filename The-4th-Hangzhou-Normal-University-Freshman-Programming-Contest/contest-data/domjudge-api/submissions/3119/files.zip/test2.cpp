#include<bits/stdc++.h>
#define res register int
#define ll long long
#define inf 0x3f3f3f3f
#define N 100050
using namespace std;
int n,m,p,q;
char c[20];
struct song
{
	int val;
	char name[20];
}songs[N];

void sort(int l,int r)
{
    int mid=songs[(l+r)/2].val;
    int i=l,j=r;
    do{
        while(songs[i].val>mid) i++;
        while(songs[j].val<mid) j--;
        if(i<=j)
        {
            swap(songs[i],songs[j]);
            i++;
            j--;
        }
    }while(i<=j);
    if(l<j) sort(l,j);
    if(i<r) sort(i,r);
}

int main()
{
	scanf("%d",&n);
	for(res i=1;i<=n;i++)
	{
	  scanf("%d",&songs[i].val);
	  scanf("%s",&songs[i].name);	  
    }
    
    sort(1,n);
   
    scanf("%d",&m);
	
	m=m+1;
	
	printf("%s\n",songs[m].name);  
  
}
