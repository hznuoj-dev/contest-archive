#include<stdio.h>
int main()
{
	int n;
	scanf("%d", &n);
	while (n--)
	{
		printf("Welcome to HZNU\n");
	}
	return 0;
}


