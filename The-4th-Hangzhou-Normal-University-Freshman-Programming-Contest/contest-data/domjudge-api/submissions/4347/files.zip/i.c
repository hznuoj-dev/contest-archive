#include<stdio.h>
#include<stdlib.h>
struct student{
	int w;
	char s[20];
};
int cmp(const void *p,const void *q)
{
	return ((struct student*)q)->w - ((struct student*)p)->w;
}
int main(){
	int n,i,k;
	struct student stu[100001];
	scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%d %s",&stu[i].w,stu[i].s);
		}
		scanf("%d",&k);
		qsort(stu,n,sizeof(struct student),cmp);
		printf("%s",stu[0+k].s);
	return 0;
}
