#include<stdio.h>
#include<math.h>
#include<bits/stdc++.h>
using namespace std;
char a[1005][33];
int main(){
	int n,i,j,len,k;
	scanf("%d",&n);
	char x;
	for(i=1;i<=n;i++){
		j=1,len=1;
		x=getchar();
		while(x!='.'&&x!='!'&&x!='?'){
			if(x==' '){
				a[j][len]=x;
				j++;
				len=1;
			}
			else{
				a[j][len]=x;
				len++;
			}
			x=getchar();
		}
		a[j][len]=' ';
		getchar();
		for(k=1;k<=j/2;k++){
			len=1;
			while(a[k][len]!=' '){
				putchar(a[k][len]);
				len++;
			}
			putchar(a[k][len]);
			len=1;
			while(a[j-k+1][len]!=' '){
				putchar(a[j-k+1][len]);
				len++;
			}
			if(j%2!=0){
				putchar(a[j-k+1][len]);
			}
			else if(j%2==0&&k!=j/2){
				putchar(a[j-k+1][len]);
			}
		}
		if(j%2!=0){
			len=1;
			while(a[(j+1)/2][len]!=' '){
				putchar(a[(j+1)/2][len]);
				len++;
			}
		}
		putchar(x);
		printf("\n");
	}
}
