#include<stdio.h>
int main(){
	int n,s;
	scanf("%d %d",&n,&s);
	int a[3] = {0};
	int m[10]  ={0};
	int temp = -1;
	for(int i =0;i<n;i++)
	{int x;
	scanf("%d",&x);
	
	if(x==0){
    temp++;	
	scanf("%d",&m[temp]);
} 
     else if(x==1)
     a[x]++;
     else
     a[2]++;
		
	}
int flag= 0;
if(s==0){
	temp++;
	for(int i =0;i<temp;i++)
	if(m[i]>=2500)
	{
	flag = 1;
	temp--; 
	break;
	}
	
	
	if(a[1]>=1&&flag==1){
	printf("haoye");
    goto end;	}   
	if(a[2]>=1&&(temp>0||a[1]>=1)){
	printf("haoye");
    goto end;	}   
    printf("QAQ");
    
}  
   else	if(s==1){
	temp++;
	for(int i =0;i<temp;i++)
	if(m[i]>2100)
	{
	flag = 1;
	temp--; 
	break;
	}
	
	
	if(a[1]>=1&&flag==1){
	printf("haoye");
    goto end;	}   
	if(a[2]>=1&&(temp>0||a[1]>=1)){
	printf("haoye");
    goto end;	}   
    printf("QAQ");
    
}	
	
	
	
	
	
	
	end:;
	
	
}
