#include<stdio.h>
#include<stdlib.h>
struct a{
	long long int w;
	char s[15];
};
int comp(const void *p,const void *q){
	return ((struct a*)p)->w-((struct a*)q)->w;
}
int main(){
	int n,k;
	scanf("%d",&n);
	struct a a1[10000];
	for(int i=0;i<n;i++){
		scanf("%lld %s",&a1[i].w,a1[i].s);
	}
	scanf("%d",&k);
	qsort(a1,n,sizeof(struct a),comp);
	for(int i=0;i<n-k;i++){
		printf("%s\n",a1[i].s);
	}
}