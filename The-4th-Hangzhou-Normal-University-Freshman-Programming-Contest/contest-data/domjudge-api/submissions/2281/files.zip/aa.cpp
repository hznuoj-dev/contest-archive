#include<iostream>
#include<cctype>
#include<string>
#include<cstring>
#include<cmath>
#define pzc 666
using namespace std;
int a[1000010];
int main()
{
	long long x,y;
	int t,n,i,j,k,b,c,l,f,d;	
	char ch;
	cin>>t;
	while(t--)
	{
		cin>>n>>x;
		k=x;memset(a,0,sizeof(a));
		while(k!=0)
		{
			if(a[k]==1) break;
			a[k]=1;
			k=(k+x)%n; 
		}
		if(k==0&&x!=0) cout<<"yes"<<endl;
		else cout<<"no"<<endl;
	}
}
