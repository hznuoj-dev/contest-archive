#include<stdio.h>
int main()
{
	int t;
	int mode,atk[10]={0};
	int card[10];
	scanf("%d%d",&t,&mode);
	int isdie=0;
	int isexp=0;
	for(int i=0;i<t;i++){
		scanf("%d",&card[i]);
		if(card[i]==0)
		scanf("%d",&atk[i]);
	}
	for(int i=0;i<t;i++){
		if(atk[i]>=2100&&mode==1)
			isdie=1;
		if(atk[i]>=2500&&mode==0)
			isdie=1;
	}
	if(isdie==0){
	printf("QAQ\n");
	return 0;
}	
	isdie=0;
	int flag=0;
	if(t>=3){
		for(int i=0;i<t;i++){
			if(card[i]==2){
			printf("haoye\n");
			flag=1;
			goto a;
		}
		}
		for(int i=0;i<t;i++){
			if(card[i]==1){
			printf("haoye\n");
			flag=1;
			break;
		}
		}
		if(flag==0){
			printf("QAQ\n");
		}
	}
	else{
		for(int i=0;i<t;i++){
			if(card[i]==1){
			printf("haoye\n");
			flag=1;
			break;
		}
		}
		if(flag==0){
			printf("QAQ\n");
		}
	}
	a:
	return 0;
}
