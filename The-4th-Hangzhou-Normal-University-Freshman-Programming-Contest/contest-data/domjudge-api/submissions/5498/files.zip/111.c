/*#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int a[100005];
int main()
{
    int t;
    int sum;
    int flag=0;
    int i,j;
    int n;
    scanf("%d",&t);
    while(t--){
    	flag=0;
    	scanf("%d",&n);
    	for(i=0;i<n;i++){
    		scanf("%d",&a[i]);
		}
		for(i=0;i<n;i++){
			sum=a[i];
			if(sum==7777){
				flag++;
			}
			else{
				for(j=i+1;j<n;j++){
					sum+=a[j];
					if(sum==7777){
					    flag++;
					    break;
					}
					else if(sum>7777)
					    break;
				}
			}
				
				
	   }
	   	
		printf("%d\n",flag);
	}
	return 0;
}*/
/*#include<stdio.h>
#include<string.h>
int shunshi(int *a,int *b,int n);
int nishi(int *a,int *b,int n);
int pandun(int*a,int *b,int n);
int a[25][25],b[25][25];
int main()
{
	int t;
	int i,j;
	int n;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		for(int i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&a[i][j]);
			}
		}
		for(int i=0;i<n;i++){
			for(j=0;j<n;j++){
				scanf("%d",&b[i][j]);
			}
		}
	}
	
}
int panduan(int *a,int *b,int n){
	int i,j;
	int flag=0;
	for(i=0;i<n;i++){
		for(j=0;j<n;j++){
			if(a[i][j]!=b[i][j]);
			flag=1;
		}
	}
	if(flag==1){
		return 0;
	}
	else
	    return 1;
}
int shunshi(int *a,int *b,int n){
	int temp;
	int c[n][n];
	while(panduan(a,b)==0){
		
	}
}*/
#include<stdio.h>
int a[20][2];
int main()
{
	int n;
	int atk=2500,def=2100;
	int i=0;
	int k;
	int flag=0;
	int flag0=0,flag1=0;
	int zitai;
	scanf("%d %d",&n,&zitai);
	//printf("%d %d",n,zitai);
	if(zitai==0){
		k=atk;
	} 
	else{
		k=def;
	}
	for(i=0;i<n;i++){
		scanf("%d",&a[i][0]);
		//printf("a[i][0]=%d",a[i][0]);
		if(a[i][0]==0){
			scanf("%d",&a[i][1]);
			//printf("a[i][1]=%d",a[i][1]);
		}
	}
	for(i=0;i<n;i++){
		if(a[i][0]==2&&n>=2){
			//printf("haoye\n");
			flag=1;
			break;
		}
	}
	if(flag==1){
		printf("haoye\n");
	}
	else{
		for(i=0;i<n;i++){
			if(a[i][0]==0&&a[i][1]>=k){		
					flag0=1;
			}
			else if(a[i][0]==1){
				flag1=1;
			}
		}
		if(flag0==1&&flag1==1){
			printf("haoye\n");
		}
		else{
			printf("QAQ\n");
		}
    }
	
}
