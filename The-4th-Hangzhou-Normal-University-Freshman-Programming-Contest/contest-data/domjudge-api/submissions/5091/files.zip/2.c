#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct A{
	int lx;
	int sz;
};
int main(void)
{
	int flag=0;
	int n,m;
	scanf("%d%d",&n,&m);//m��ʾ״̬
	int sum; 
	if(m==0) sum=2500;
	else sum=2100;
	int i;
	struct A a[100];
	for(i=0;i<n;i++)
	{
		scanf("%d",&a[i].lx);
		if(a[i].lx==0)
		{
			scanf("%d",&a[i].sz);
		}
	}
	int j;
	for(i=0;i<n;i++)
	{
		if(a[i].lx==2)
		{
			if(n>=2)
			{
				printf("haoye");
				flag=1;
				break;
			}
		} 
	}
	for(i=0;i<n;i++)
	{
		if(a[i].lx==1)
		{
			for(j=0;j<n;j++)
			{
				if(a[j].lx==0)
				{
					if(m==0)
					{
						if(a[j].sz>=sum)
						{
							sum=0;
						}
					}
					else
					{
						if(a[j].sz>sum)
						{
							sum=0;
						}
					}
				}
			}
			if(sum==0&&flag==0){
				printf("haoye");
				flag=1;
			}
		}
	}
	if(flag==0) printf("QAQ");
	return 0;
} 
