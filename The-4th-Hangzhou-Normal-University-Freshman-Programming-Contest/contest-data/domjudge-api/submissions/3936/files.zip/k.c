#include<stdio.h>
struct poems {
	long long int a;
	char b[500];
};
int main() {
	int t;
	struct poems c[500];
	scanf("%d", &t);
	for (int i = 0; i < t; i++) {
		scanf("%lld%s", &c[i].a, c[i].b);
	}
	int d;
	scanf("%d", &d);
	for (int i = 0; i < t - 1; i++) {
		for (int j = 0; j < t - 1-i; j++) {
			struct poems m;
			if (c[j].a < c[j + 1].a) {
				m = c[j];
				c[j] = c[j + 1];
				c[j + 1] = m;
			}
		}
	}
	printf("%s\n", c[d].b);
	return 0;
}
