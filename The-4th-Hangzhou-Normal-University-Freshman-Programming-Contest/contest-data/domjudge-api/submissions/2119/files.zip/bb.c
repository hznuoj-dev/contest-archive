#include<stdio.h>
int main(void)
{
	int t;
	int n;
	int a[100010];
	scanf("%d",&t);
	int i,j,k;
	while(t--)
	{
		int count=0;
		scanf("%d",&n);
		for(i=0;i<n;++i)
		{
			scanf("%d",&a[i]);
		}
		for(i=0;i<n;++i)
		{
			int s=a[i];
			for(j=i+1;j<n;++j)
			{
				s+=a[j];
				if(s==7777)
				{
					count++;
					break;
				}
			}
		}
		printf("%d\n",count);
	}
	return 0;
}

