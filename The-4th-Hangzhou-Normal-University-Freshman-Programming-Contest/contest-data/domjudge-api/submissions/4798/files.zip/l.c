#include<stdio.h>
int main() {
	int n = 0;
	int t = 0;
	int x = 0;
	scanf("%d", &t);
	while (t--) {
		scanf("%d%d", &n, &x);
		if (x != 0) {
			printf("yes\n");
		}
		else {
			printf("no\n");
		}
	}
}