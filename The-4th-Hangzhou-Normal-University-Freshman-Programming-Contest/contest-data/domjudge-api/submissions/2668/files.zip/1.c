#include<stdio.h>

#include<string.h>
int main()
{
	int a,T,flag=0,result,length,i,j;
	char ar[100001];
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&a);
			result=0;
			flag=0;
			getchar();
			gets(ar);
			length=strlen(ar);
			for(i=0;ar[i]!='\0';i++)
			{
				for( ;ar[i]=='1'||ar[i]==' '; )
						i++;
				if(ar[i]=='\0')
					break;
				for(j=i+2; ; )
				{
					for( ;ar[j]=='1'; )
						j+=2;
					if(ar[i]==ar[j])
					{
						result+=1;
						ar[i]='1';
						ar[j]='1';
						flag=1;
						break;
					}
					if(ar[j+1]=='\0')
						break;
					j+=2;
				}
			}
			if(flag==0)
				printf("1\n");
			else if(flag!=0&&(result*2+1)<(length/2+1)||flag!=0&&(result*2+1)==(length/2+1))
			    printf("%d\n",result*2+1);
			else if(flag!=0&&(result*2+1)>(length/2+1))
				printf("%d\n",result*2);
	
	}
		
		return 0;
	}




