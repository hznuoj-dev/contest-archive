#include<stdio.h> 
#include<string.h>
struct juzi{
	char a[100];
};
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		struct juzi b[10000];
		int i=0,j;
		scanf("%s",b[i].a );
		while(b[i].a[0]!='.'||b[i].a[0]!='!'||b[i].a[0]!='?'){
			i++;
			scanf("%s",b[i].a );
		}
		for(j=0;j<i;j++){
			if(j%2==0){
				printf("%s",b[j].a );
			}
			else{
				printf("%s",b[i-1-j].a );
			}
			if(j!=i-1){
				printf(" ");
			}
		}
		printf("%c\n",b[i].a[0]);
	}
}
 
