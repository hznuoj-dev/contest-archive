#include<stdio.h>
int main(void){
	int n,k,i,j,e,c;
	scanf("%d",&n);
	long long a[n+1];
	int d[n+1];
	char b[n+1][16];
	for(i=0;i<n;i++){
		scanf("%lld",&a[i]);
		scanf("%s",b[i]);
		d[i]=-1;
	}
	for(i=0;i<n;i++){
		c=-1;
		for(j=0;j<n;j++){
			if(d[j]==-1){
				if(c==-1){
					c=j;
					e=a[j];
				}
				else if(a[j]>e){
					c=j;
					e=a[j];
				}
			}
		}
		d[c]=i;
	}
	scanf("%d",&k);
	for(i=0;i<n;i++){
		if(d[i]==k)
		printf("%s",b[i]);
	}
	return 0;
}
