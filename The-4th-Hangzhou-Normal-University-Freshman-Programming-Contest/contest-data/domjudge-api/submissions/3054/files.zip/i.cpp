#include<stdio.h>
#include<stdlib>
int comp(const void* p, const void* q);
struct array {
	int a;
	char b[20];
};
int comp(const void* p, const void* q) {
	return (*(struct array*)q - *(struct array*)p);
}
int main() {
	int n, k, i, j;
	struct array A[100000];
	scanf("%d", &n);
	for (i=0;i<n;i++){
		scanf("%d %s", &A[i].a,A[i].b);
	}
	scanf("%d", &k);
	qsort(A, n, sizeof(struct array), comp);
	printf("%s\n", A[k].b);
	return 0;
}