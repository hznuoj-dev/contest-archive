#include<stdio.h>
#include<process.h>
int main()
{
	int n,m,i,flag=0,atk[11],md=0,x[11],def[11];
	int d=0,c=0;
	scanf("%d %d",&n,&m);
	if(m==0)
	{
	for(i=0;i<n;i++)
	{
		scanf("%d",&x[i]);
		if(x[i]==0)
		{
			scanf("%d",&atk[d++]);
		}
	}
	for(i=0;i<n;i++)
	{
		if(x[i]==0)
		{
			if(atk[c++]>=2500)
			{
				md=1;
			}
		}
		if(x[i]==1)
		{
			if(md==1){
				flag=1;
				printf("haoye\n");break;}
		}
		if(x[i]==2)
		{
			i++;
			if(i>n)
			{
				printf("QAQ\n");
				break;
			}
			if(md==0)
			{
				printf("haoye\n");
				break;
			}
		}

	}
	}
	if(m==1)
		{
	for(i=0;i<n;i++)
	{
		scanf("%d",&x[i]);
		if(x[i]==0)
		{
			scanf("%d",&def[d++]);
		}
	}
	for(i=0;i<n;i++)
	{
		if(x[i]==0)
		{
			if(def[c++]>2100)
			{
				md=1;
			}
		}
		if(x[i]==1)
		{
			if(md==1){
				flag=1;
				printf("haoye\n");break;}
		}
		if(x[i]==2)
		{
			i++;
			if(i>n)
			{
				printf("QAQ\n");
				break;
			}
			if(md==0)
			{
					flag=1;
				printf("haoye\n");break;}
		}
				

	}
	}
	if(flag==0)
		printf("QAQ\n");
	system("pause");
	return 0;
}

	
