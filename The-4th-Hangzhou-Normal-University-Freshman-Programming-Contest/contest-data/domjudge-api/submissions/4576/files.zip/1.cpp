#include<stdio.h>
#include<math.h>
int main(void)
{
		int T,n,x,c=0,i,d=1;
		long long int s;
		scanf("%d",&T);
		while(T--)
		{
		scanf("%d%d",&x,&n);
		if(x!=0)
		printf("yes\n");
		else
		printf("no\n");
	}
}
