#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<math.h>
int main(){
	int t,i,len,wz,x,j;
	char a[1005][35],str[30005],ch;
	scanf("%d",&t);
	getchar();
	while(t--)
	{
		wz=0;
		x=0;
		gets(str);
		len=strlen(str);
		ch=str[len-1];
		for(i=0;i<len-1;i++)
		{
			if(str[i]==' ')
			{
				wz++;
				x=0;
				continue;
			}
			a[wz][x]=str[i];
			x++;
		}
		wz++;
		for(i=0;i<=wz/2-1;i++)
		{
			if(i==0)
			printf("%s %s",a[i],a[wz-1-i]);
			else
			printf(" %s %s",a[i],a[wz-1-i]);
		}
		if(wz%2)
		printf(" %s",a[wz/2]);
		printf("%c\n",ch);
		for(i=0;i<=wz;i++)
		{
			for(j=0;j<30;j++)
			a[i][j]='\0';
		}
	}
	return 0;
}
