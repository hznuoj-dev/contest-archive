#include<iostream>
#include<string>
using namespace std;
int main() {
	int n;
	cin >> n;
	getchar();
	while (n--) {
		string p;
		string s;
		string cs[10000];
		getline(cin, s);
		int cnt = 1;
		int num = count(s.begin(), s.end(), ' ');
		num++;
		bool j=false;
		if (num % 2 == 0) {
			j = true;
		}
		int ou;
		if (j) {
			ou = num + 2;
		}
		else {
			ou = num + 1;
		}
		for (int i = 0; i < s.length(); i++) {
			if (s[i] == ' ') {
				cnt++;
				if (cnt > (num + 1) / 2) {
					ou-=2;
				}
				continue;
			}
			else if (s[i] == '.'||s[i]=='!'||s[i]=='?') {
				p = s[i];
				break;
			}
			else {
				if (cnt <= (num + 1) / 2) {
					cs[2 * cnt - 1] += s[i];
				}
				else {
					cs[ou] += s[i];
				}
				
			}
		}
		for (int i = 1; i <= num; i++) {
			cout << cs[i];
			if (i != num)cout << " ";
		}
		cout << p << endl;

	}
}