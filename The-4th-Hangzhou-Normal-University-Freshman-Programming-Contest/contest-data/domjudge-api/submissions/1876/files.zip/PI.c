#include<stdio.h>
typedef struct{
	int like;
	char name[16];
}sing;
int main(){
	int n,i,k,j,t;
	scanf("%d",&n);
	int b[n];
	sing a[n];
	for(i=0;i<n;i++){
		scanf("%d%s",&a[i].like,a[i].name);
		b[i]=a[i].like;
	}
	scanf("%d",&k);
	for(i=1;i<n;i++){
		for(j=0;j<n-i;j++){
			if(b[j]>b[j+1]){
				t=b[j];
				b[j]=b[j+1];
				b[j+1]=t;
			}
		}
	}
	for(i=0;i<n;i++){
		if(a[i].like==b[n-1-k]){
			printf("%s",a[i].name);
			break;
		}
	}
}
