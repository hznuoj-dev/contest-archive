#include <stdio.h>
int main(){
	int t;
	int n,step;
	scanf("%d",&t);
	while(t--){
		scanf("%d %d",&n,&step);
		if(step>0){
			printf("Yes\n");
		}
		else	printf("No\n");
		}
	return 0;
}
