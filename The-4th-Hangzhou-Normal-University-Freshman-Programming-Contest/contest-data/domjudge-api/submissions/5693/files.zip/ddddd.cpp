#include<stdio.h>
#include<string.h>

struct number {
	long long love;
	char name[100];
};
int main() {
	int n,  k, i;
	char p[1000];
	struct number get[1000];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%lld%s", &get[i].love, get[i].name);
	}
	for (i = 0; i < n - i; i++) {
		for (int j = 0; j < n - i - 1; j++) {
			if (get[j].love < get[j + 1].love) {
				long long	temp = get[j].love;
				get[j].love = get[j + 1].love;
				get[j + 1].love = temp;
				strcpy(p, get[j].name);
				strcpy(get[j].name, get[j + 1].name);
				strcpy(get[j + 1].name, p);
			}
		}
	}
	scanf("%d", &k);
	printf("%s", get[k].name);

}

