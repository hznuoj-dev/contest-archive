#include<stdio.h>
int main()
{
	int x;
	scanf("%d",&x);
	printf("Welcome to HZNU");
	return 0;
} 
