#include<bits/stdc++.h>

using namespace std;
map<int ,string> p;
int a[100010];
int main()
{
	int n;
	cin >> n;
	for(int i=n;i>=1;i--)
	{
		int x;
		string ch;
		cin >> x >> ch;
		p[x]=ch;
		a[i]=x;	
	}
	int k;
	cin >> k;
	cout << p[a[k+1]];
	return 0;
}
