#include<stdio.h>
struct ge{
	int a;
	char x[100000];
}m[100000];
int main(void){
	int n;
	scanf("%d",&n);
	int i,j;
	for(i=0;i<n;i++){
		scanf("%d %s",&m[i].a ,m[i].x );
	}
	struct ge q;
	for(i=0;i<n-1;i++){
		for(j=0;j<n-1-i;j++){
			if(m[j].a <m[j+1].a ){
				q=m[j];
				m[j]=m[j+1];
				m[j+1]=q;
			}
		}
		
	}
	int k;
	scanf("%d",&k);
	printf("%s\n",m[k].x );
	return 0;
}

