#include<stdio.h>
#include<stdlib.h>
struct man
{
	long long num;
	char name[17];
	int flag;
	
}song[10050],*p;


int main(){
	long long n,temp,i,max,back,k;
	scanf("%lld",&temp);
	n=temp;
	p=song;
	while(temp--){
		scanf("%lld",&p->num);
		scanf("%s",p->name);
	p++;	
	}
	//��ʼ��0 
		for(i=0;i<n;i++){
			song[i].flag=0;
		}	
	scanf("%lld",&k);
	//����Ŀ��ֵ 
	while(k--) {
			max=0;
			back=10049;//���޹�ֵ 
			p=song;
			for(i=0;i<n;i++){//�ҳ����ı��Ϊ0 
				if(max<p->num&&p->flag==0){
					p->flag=1;
					max=p->num;
					song[back].flag=0;//
					back=i;
					}
				p++;
			}
			
	}
//ɾ������ k�� 
	 			max=0;
	 			back=10049;//���޹�ֵ 
	 			p=song;
	 			for(i=0;i<n;i++){//�ҳ����ı��Ϊ0 
	 				if(max<p->num&&p->flag==0){
	 					p->flag=1;
	 					max=p->num;
	 					song[back].flag=0;//
	 					back=i;
	 					}
	 				p++;
	 			}
	 			printf("%s",song[back].name);
	 		
}
