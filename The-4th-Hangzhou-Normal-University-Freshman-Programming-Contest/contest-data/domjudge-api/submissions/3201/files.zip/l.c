#include<stdio.h>
int main(void){
	int t,i,l,n,x;
	long long int j;
	scanf("%d",&t);
	while(t--){
		l=0;
		i=0;
		j=0;
		scanf("%d%d",&n,&x);
		if(x==0){
			printf("no\n");
		}
		else{
			while(j<1000000000000){
				i=i+x;
				j++;
				if(i==n){
					l=1;
					printf("yes\n");
					break;
				}
				if(i>n){
					i=i-n;
				}
			}
			if(l==0){
				printf("no\n");
			}
		}	
	}
	return 0;
}
