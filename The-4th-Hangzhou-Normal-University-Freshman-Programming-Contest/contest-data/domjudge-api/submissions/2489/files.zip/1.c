#include<stdio.h>
struct xinxi{
	long long int w;
	char name[20];
}s[100666];
int comp(const void *a,const void *b){
	struct xinxi *p = (struct xinxi*)a;
	struct xinxi *q = (struct xinxi*)b;
	return p->w < q->w ?1:-1;
}
int main(){
	int n;
	scanf("%d",&n);
	int i;
	for(i=1;i<=n;i++){
		getchar();
		scanf("%lld %s",&s[i].w,s[i].name);
	}
	qsort(s+1,n,sizeof(s[1]),comp);
//	for(i=1;i<=n;i++){
//		printf("%lld %s\n",s[i].w,s[i].name);
//	}
    int k;
    scanf("%d",&k);
    printf("%s\n",s[k+1].name);
	return 0;
} 
