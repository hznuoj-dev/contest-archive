#include<stdio.h>
int main() {
	int n, i,k,w[100000],j,t;
	char s[20][20],m;
	scanf("%d", &n);
	getchar();
	for (i = 0; i < n; i++) {
		scanf("%d", &w[i]);
		scanf("%s",&s[i]);
	}
	for (i = 0; i < n; i++) {
		for (j = 0; j < n-i-1; j++) {
			if (w[j] < w[j + 1]) {
				t = w[j];
				w[j] = w[j + 1];
				w[j + 1] = t;
				m = s[j];
				s[j] == s[j + 1];
				s[j + 1] == m;
			}
		}
	}
	scanf("%d", &k);
	printf("%s", s[k]);
	return 0;
}

