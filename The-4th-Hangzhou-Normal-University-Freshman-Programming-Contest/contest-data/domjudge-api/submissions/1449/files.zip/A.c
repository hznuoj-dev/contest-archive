#include<stdio.h> 
int main(void){
	int t,n,i,mark[130],sum;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		char str[n];
		sum=0;
		for(i=0;i<130;i++){
			mark[i]=0;
		}
		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&str[i]);
			mark[str[i]]++;
		}
		for(i=0;i<130;i++){
			sum+=mark[i]/2;
		}
		printf("%d\n",sum*2+1);
	} 
	return 0;
}
