#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
int n, i, j, temp;
int main()
{
	scanf("%d", &n);
	while (n--)
	{
		printf("Welcome to HZNU\n");
	}
	return 0;
}