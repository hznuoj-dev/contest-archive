#include<stdio.h>
int main() {
	int n,k, m, i,flag = 0;
	int pai[10] = { 0 };
	scanf("%d %d", &n, &m);
	for (i = 0;i < n;i++) {
		scanf("%d", &pai[i]);
		if (pai[i] == 0) {
			scanf("%d", &k);
			if (m == 0 && k >= 2500)
				flag = 1;
		}
		else if (m == 1 && k > 2100)
			flag = 1;
		if (pai[i] == 1&&flag==1) {
			printf("haoye\n");
			break;
		}
		if (pai[i] == 2 && i > 1) {
			flag = 1;
			printf("haoye\n");
			break;
		}
		}
	if (flag == 0)
			printf("QAQ\n");
}