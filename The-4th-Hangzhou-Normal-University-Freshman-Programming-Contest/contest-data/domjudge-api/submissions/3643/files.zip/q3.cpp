#include<stdio.h>
#include<string.h>
struct music{
	long long xh;
	char name[20];
};
int main()
{
    long long n,i,j,k,t;
    char str2;
	struct music musicArray[110000];
	scanf("%lld",&n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s",&musicArray[i].xh,musicArray[i].name);
	}
	for(i=0;i<n-1;i++)
	{
		for(j=0;j<n-i-1;j++)
		{
			if(musicArray[j].xh<musicArray[j+1].xh)
			{
				strcmp(str2,musicArray[j].name);
				strcmp(musicArray[j].name,musicArray[j+1].name);
				strcmp(musicArray[j+1].name,str2);
			}
		}
	}
	scanf("lld",&k);
	printf("%s\n",musicArray[k+1].name);	
}
