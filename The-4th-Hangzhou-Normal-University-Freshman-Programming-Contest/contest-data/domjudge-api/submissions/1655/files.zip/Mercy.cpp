#include<bits/stdc++.h>
using namespace std;

int sum[100005];
int main(){
	int cnt=0;
	int t;
	cin>>t;
	while(t--){
		int n;
		cin>>n;
		for(int i=1;i<=n;i++){
			cin>>sum[i];
			sum[i]+=sum[i-1];
		}
		for(int i=0;i<n;i++){
			for(int j=i+1;j<=n;j++){
				int ans=sum[j]-sum[i];
				if(ans==7777){
					cnt++;
				}else if(ans>7777){
					break;
				}
			}
		}
		cout<<cnt<<'\n';
		cnt=0;
	}
} 
