#include<stdio.h>
#include<string.h>
#include<cstdio>
#include<iostream>
#include<cmath>
#include<cstring>
using namespace std;
 const int maxn = 1e5+10;
int t;
int n;
int p;

int b;
int sum;
int st;
int a[maxn];


int main(){


     scanf("%d",&t);
    while(t--){  
    
	scanf("%d",&n);
   for(int i = 1;i <= n;i++) 
     scanf("%d",&a[i]); 
	  p = b = 1;  
	  sum = st = 0;
	    for(int i = 1;i <= n;i++)
		{  
		 sum = sum + a[b++];
		   while(sum > 7777)  
		     sum -= a[p++];    
			 
			 if(sum == 7777) 
			 st++;  
	    }
         printf("%d",st);
}
}
