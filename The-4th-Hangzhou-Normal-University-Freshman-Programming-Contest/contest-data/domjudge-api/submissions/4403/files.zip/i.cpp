#include<stdio.h>
#include<string.h>
int main(){
	int n;
	char s1[16];
	char s[10001][16];
	long long w[10001],t;
	int k;
	scanf("%d",&n);
	for (int i=1;i<=n;i++){
		scanf("%lld %s",&w[i],s[i]);
	}
	scanf("%d",&k);
	for (int i=1;i<n;i++){
		for (int j=1;j<n-i+1;j++){
			if (w[j]<w[j+1]){
				t=w[j];
				w[j]=w[j+1];
				w[j+1]=t;
				strcpy(s1,s[j]);
				strcpy(s[j],s[j+1]);
				strcpy(s[j+1],s1);
			}
		}
	}
    printf("%s",s[k+1]);
}
