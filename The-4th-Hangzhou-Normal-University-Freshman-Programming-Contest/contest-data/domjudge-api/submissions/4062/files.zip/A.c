#include<stdio.h>
char m[100000];
int main(void){
	int T;
	scanf("%d",&T);
	int n;
	while(T--){
		scanf("%d",&n);
		int i,j;

		for(i=0;i<n;i++){
			getchar();
			scanf("%c",&m[i]);
		}
		int count=0;
		for(i=0;i<n;i++){
			for(j=0;j<n;j++){
				if(m[i]==m[j]&&(j!=i)&&m[i]!='9'){
					m[j]='9';
					m[i]='9';
					count++;
				}
			}
		}
		if(n-count*2>=1){
			count=count*2+1;
		}
		else{count=count*2;}
		printf("%d\n",count);
		count=0;
		for(i=0;i<n;i++)
		m[i]='\0';
	}
	return 0;
}

