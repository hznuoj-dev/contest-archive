#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int comp(const void *a, const void *b) {
	return *(int*)a-*(int*)b;
}
int s[5000][5000]={0};
int main()
{
	int T,n,i,a[100001]={0},b[5001]={0},j,sum=0;
	scanf("%d",&T);
	while(T--)
	{
		sum=0;
		scanf("%d",&n);
		for(i=0;i<n;i++)
		{
			scanf("%d",&a[i]);
			b[a[i]]+=1;
		}
		qsort(a,n,sizeof(int),comp);
		for(i=0;i<=n;i++)
		{
			s[i][0]=a[i];
			for(j=i+1;j<=n;j++)
			{
				s[i][j]=s[i][j-1]+a[j];
				if(s[i][j]==7777)
				{
					sum+=b[a[j]];
				}
			}
		}
		printf("%d\n",sum);
	}
 } 
