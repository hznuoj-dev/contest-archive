#include <bits/stdc++.h>
using namespace std; 

int main()
{
	int n,m,max,i,a,d;
	scanf("%d%d",&n,&m);
	if (m==0) max=2500;
	else max=2100;
	int f1=0,f2=0,f0=0;
	for (i=1; i<=n; i++)
	{
		scanf("%d",&d);
		if (d==0) 
		{
			scanf("%d",&a);
			if (a>=max) f0=1;
		}
		if (d==1) f1=1;
		if (d==2) f2=1;
		if ((f0*f1==1) || (f2==1 && n>=2)) 
		{
			printf("haoye\n");
			return 0;
		}
		
	}
	printf("QAQ\n");
}
