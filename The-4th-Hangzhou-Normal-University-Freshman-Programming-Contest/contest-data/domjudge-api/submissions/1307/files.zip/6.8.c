#include<stdio.h>
#include<string.h>
#include<math.h>
int main()
{ 
 long long int x,y;
 char aa[100001],bb[100001],*p1,*p2,ch;
 int n=5,sum=0,i,j,line,row,a[100001],b[100001],len,N,jue,max,min,t,t1;
 scanf("%d",&n);
 while(n--)
 {
 	printf("Welcome to HZNU\n");
  } 
 return 0;
}

