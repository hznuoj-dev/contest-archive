#include <stdio.h>
int main ()
{
int t,a[10005],n,i,j,k,sum=0,x=0;
scanf("%d",&t);
while(t--)
{
 scanf("%d",&n);
 for(i=0;i<=n;i++)
 {
 scanf("%d",&a[i]);
 }
 for(j=0;j<=n;j++)
 {
    for(k=j;k<=n;k++)
    {
        sum=sum+a[k];
    }
    if (sum==7777)
    break;
 }
x=x+1;
printf("%d\n",x);
}
}
