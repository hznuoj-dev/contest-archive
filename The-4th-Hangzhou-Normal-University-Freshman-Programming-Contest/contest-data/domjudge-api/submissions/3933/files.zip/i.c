#include <stdio.h>
#include <string.h>
#include <stdlib.h>
struct s{
		int a;
		char b[16];
		};
		
int comp(const int*p,const int*q){
	return ((struct s *)q)->a-((struct s *)p)->a;
}

int main(void) {
	int n,k,i,j;
	scanf("%d",&n);
	struct s op[n];
	
	for(i=0;i<n;i++){
		scanf("%d%s",&op[i].a,op[i].b);
		
		
	}
	
	scanf("%d",&k);
	
	qsort(op,n,sizeof(struct s),comp);
	printf("%s",op[k].b);
		
	return 0;
}

