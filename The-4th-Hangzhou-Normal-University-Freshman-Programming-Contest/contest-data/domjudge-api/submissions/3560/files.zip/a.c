#include <stdio.h>
#include <string.h>
struct bom{
	char a[2];
	int b;
};
int main()
{
	int T,n,i,j;
	scanf("%d",&T);
	while(T--)
	{
		scanf("%d",&n);
		int t=1;
		struct bom ch[n+1];
		for(i=1;i<=n;i++)
		{
			scanf("%s",ch[i].a );
			ch[i].b =0;
		}
		for(i=1;i<n;i++)
		{
			for(j=i+1;j<=n;j++)
			{
				if(strcmp(ch[i].a,ch[j].a  )==0&&(ch[i].b ==0&&ch[j].b ==0))
				t=t+2;
			}
		}
		printf("%d\n",t);
	}
} 
