#include<stdio.h>
#include<string.h>
int main(){
	int n,i,m,k,ATK=2500,DEF=2100,a[11],flag=0;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(flag==0&&a[i]==2&&i<n-1){
			printf("haoye\n");
			break;
		}
		if(a[i]==0){
			scanf("%d",&k);
			if(m==0&&k>=ATK)
				flag=1;
			else if(m==1&&k>DEF)
				flag=1;
		}
		if(flag==1&&a[i]==1){
			printf("haoye\n");
				break;
		}
	}
	if(i==n)
		printf("QAQ\n");
	return 0;
}