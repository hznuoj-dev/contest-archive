#define _CRT_SECURE_NO_DEPRECATE
#pragma warning(disable:4996)
#include<stdio.h>
#include<math.h>
#include<string.h>
struct p
{
	long long love;
	char song[100];
}all[100005],temp;
int n, i, j;
int main()
{
	int done,k;
	scanf("%d", &n);
	for (i = 0; i < n; i++)
	{
		scanf("%lld %[^\n]", &all[i].love, all[i].song);
	}
	scanf("%d", &done);
	for (i = 0; i < n-1; i++)
	{
		k = i;
		for (j = i; j < n; j++)
		{
			if (all[k].love < all[j].love)
			{
				k = j;
			}
		}
		if (i != k)
		{
			temp = all[i];
			all[i] = all[k];
			all[k] = temp;
		}
	}
	printf("%s\n", all[done].song);
	return 0;
}