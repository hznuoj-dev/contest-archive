#include<stdio.h>
#include<string.h>
main(){
	int t;
	int n,len,i,j,k;
	char temp;
	scanf("%d",&t);
	while(t--){
		len=1;
		scanf("%d",&n);
		getchar();
		char a[2*n];
		char b[n];
		gets(a);
		for(i=0,j=0;i<2*n;i=i+2,j++){
			b[j]=a[i];
		}
		for(i=0;i<n;i++){
			for(j=i+1;j<n;j++){
				if(b[j]==b[i]){
					len=len+2;
					for(k=j;k<n;k++){
						b[k]=b[k+1];
					}
					n--;
				}
			}
		}
		printf("%d\n",len);
	}
}
