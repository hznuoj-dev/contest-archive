#include<stdio.h>
#include<stdlib.h>
struct student {
	int w;
	char a[20];
};
int comp(const void*p,const void*q){
	return((struct student*)q)->w-((struct student*)p)->w;
}
int main() {
	int n, i, j;
	struct student b[100000];
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
		scanf("%d %s", &b[i].w, b[i].a);
	}
	int num1;
	scanf("%d", &num1);
	qsort(b,n,sizeof(struct student),comp);
	printf("%s", b[num1].a);
}
