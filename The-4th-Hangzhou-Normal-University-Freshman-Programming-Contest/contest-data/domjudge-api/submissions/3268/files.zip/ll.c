#include<stdio.h>
int main() {
	int i, sum, flag, n[10000],t,m,j;
	scanf("%d", &t);
	while (t--) {
		scanf("%d", &m);
		for (i = 0; i < m; i++) {
			scanf("%d", &n[i]);
		}
		flag = 0;
		for (i = 0; i < m; i++) {
			sum = 0;
			for (j = i; j < m; j++) {
				sum += n[j];
				if (sum == 7777) {
					flag++;
				}
			}
		}
		printf("%d\n", flag);
	}
	return 0;
}