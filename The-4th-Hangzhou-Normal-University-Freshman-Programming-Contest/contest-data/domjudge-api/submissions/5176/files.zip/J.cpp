#include<stdio.h>
int main(){
  int n,m;
  int a[11];
  int b[11];
  int flag=0;
  int flag1=0;
  int whether=0;
  scanf("%d %d",&n,&m);
  int q=0;
  int sum=0;
  for(int i=0;i<n;i++){
    scanf("%d",&a[i]);
	if(a[i]==0){
	 scanf("%d",&b[q]);
	 sum=sum+=b[q];
	 q+=1;
	}
	if(a[i]==1){
	flag=1;
	}
	if(a[i]==2){
	flag1=1;
	}
  }
  if(flag==0&&flag==0){
   printf("QAQ\n");
   return 0;
  }
  if(flag==1){
	  if(m==0){
		  if(sum>=2500){
		  printf("haoye\n");
		  return 0;
		  }
	  }
	  else if(m==1){
		  if(sum>=2100){
		  printf("haoye\n");
		  return 0;
		  }
	  }
  }
  if(flag1==1){
	  if(m==0){
	   if(n>1&&sum>=2500){
	    printf("haoye\n");
		return 0;
	   }
	  }
	  else if(m==1){
		  if(n>1&&sum>=2100){
		  printf("haoye\n");
		  return 0;
		  }
	  }
  }
  printf("QAQ\n");
  return 0;
}