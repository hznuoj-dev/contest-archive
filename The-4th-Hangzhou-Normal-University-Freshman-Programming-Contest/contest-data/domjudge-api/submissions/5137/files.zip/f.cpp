#include<stdio.h>
int a[20][20],b[20][20],n;
int pd(){
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(a[i][j]!=b[i][j])	return 0;
		}
	}
	return 1;
}void xz(){
	int c[20][20];
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			c[i][j]=a[j][n-i-1];
		}
	}for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			a[i][j]=c[i][j];
		}
	}
}
int main(void){
	int t,tr;
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		tr=0;
		for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				scanf("%d",&a[i][j]);
			}
		}for(int i=0;i<n;i++){
			for(int j=0;j<n;j++){
				scanf("%d",&b[i][j]);
			}
		}
		for(int i=1;i<5;i++){
			if(pd()){
				tr=i;
				break;
			}
			xz();
		}
		if(tr==0)printf("-1\n");
		else if(tr==1)printf("0\n");
		else if(tr==3)printf("2\n");
		else printf("1\n");
	}
}
