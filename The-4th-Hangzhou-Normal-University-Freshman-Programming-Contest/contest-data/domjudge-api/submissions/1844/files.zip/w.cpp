#include<stdio.h>
int main(){
	int t,n,m,x,y;
	scanf("%d",&t);
	while(t--){
		x=0;
		scanf("%d %d",&n,&m);
		if(m==0)
		printf("no\n");
		else
		printf("yse\n");
	}
}
