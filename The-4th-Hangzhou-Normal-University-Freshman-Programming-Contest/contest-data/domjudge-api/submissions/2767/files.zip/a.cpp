#include<bits/stdc++.h>
using namespace std;
int a[30],b[30];
int main()
{ int n,ans,m,k,l,i,j;
  char ch;
  cin>>n;
  for (i=1;i<=n;i++)
   { cin>>m;
     ans=0;
     for (j=1;j<=m;j++)
     { cin>>ch;
       if (ch>='a' && ch<= 'z') a[ch-'a']++;
       if (ch>='A' && ch<= 'Z') b[ch-'A']++;
	 }
	 for (j=0;j<=25;j++)
	  { if (a[j]%2==0) ans+=a[j]; else ans+=a[j]-1; 
	    if (b[j]%2==0) ans+=b[j]; else ans+=b[j]-1;
	  }
	 if (ans%2==0 && ans<m) ans+=1;
	 cout<<ans<<"\n";
   }
}
