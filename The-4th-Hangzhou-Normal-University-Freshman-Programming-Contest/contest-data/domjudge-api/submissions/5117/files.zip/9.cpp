#include<stdio.h>
#include<string.h>
int main(void){
	long long n,k,i,j,t,f,a[10000],b;
	char s[10000][16],c[16];
	scanf("%lld",&n);
	for(i=0;i<n;++i)
		scanf("%lld %s",&a[i],&s[i]);
	scanf("%lld",&k);
	for(i=0;i<=k;++i){
		t=i;
		f=0;
		for(j=i+1;j<n;++j){
			if(a[t]<a[j]){
				t=j;
				f=1;
			}
		}
		if(f){
			b=a[i];
			a[i]=a[t];
			a[t]=b;
			strcpy(c,s[i]);
			strcpy(s[i],s[t]);
			strcpy(s[t],c);
		}
	}
	printf("%s\n",s[k]);
	return 0;
}