#include<stdio.h>
int main(){
	long long int t, n, i, j, m, s, f[100000];
	scanf("%lld", &t);
	while(t--){
		m=0;
		scanf("%lld", &n);
		for(i=0;i<n;i++){
			scanf("%lld", &f[i]);
		}
		for(i=0;i<n;i++){
			s=0;
			for(j=i;j<n;j++){
			    s+=f[j];
				if(s==7777){
					m+=1;
				} 
			}
		}
		printf("%lld\n", m);
	}
	
}
