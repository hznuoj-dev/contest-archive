#include <stdio.h>

int main() {
	int n, m, k, i, a, b = 1, c = 1, d = 0, num[10];
	scanf("%d %d", &n, &m);
	if (m == 0) {
		a = 2100;
	} else
		a = 2500;
	for (i = 0; i < n; i++) {
		scanf("%d", &num[i]);
		if (num[i] == 0) {
			scanf("%d", &k);
			num[i] = k;
		}
	}
	if (a == 2100) {
		for (i = 0; i < n; i++) {
			if (num[i] > a) {
				b = 0;
			}
			if (num[i] == 1) {
				if (b == 0) {
					d = 1;
					c = 0;
				}
			}
			if (num[i] == 2) {
				if (n >= 2) {
					d = 1;
					c = 0;
				}

			}

		}
	}
	if (a == 2500) {
		for (i = 0; i < n; i++) {
			if (num[i] > a) {
				b = 0;
			}
			if (num[i] == 1) {
				if (b == 0) {
					d = 1;
				}
			}
			if (num[i] == 2) {
				if (n >= 2) {
					d = 1;
					c = 0;
				}
			}

		}
	}
	if (d == 1) {
		printf ("hoaye");
	}
	if (c == 1) {
		printf ("QAQ");
	}
}