#include  <stdio.h>
struct geming{
	int w;
	char song[16];
};
int comp(const void *p,const void *q)
{
    return ((struct geming *)q)->w-((struct geming *)p)->w;
}
int main(void)
{
	int n,k,i,j;
	scanf("%d",&n);
	struct geming p[n];
	for(i=0;i<n;i++)
	{
		getchar();
		scanf("%d %s",&p[i].w,p[i].song);
	}
	scanf("%d",&k);
	qsort(p,n,sizeof(struct geming),comp);
	printf("%s",p[k].song);
	return 0;
}
