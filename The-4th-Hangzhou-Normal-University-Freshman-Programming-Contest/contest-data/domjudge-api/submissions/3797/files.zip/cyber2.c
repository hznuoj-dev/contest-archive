#include<stdio.h>
#include<string.h>
char a[5002][31];
int main(){
int n,i,t,j,ret,sum,max,f;
char biao;
scanf("%d",&t);
while(t--)
{i=1;
while(scanf("%s",a[i])){
sum=strlen(a[i]);
if(a[i][sum-1]=='.'||a[i][sum-1]=='!'||a[i][sum-1]=='?')
break;
i++;
}
biao=a[i][sum-1];
a[i][sum-1]='\0';
n=i;
if(n%2!=0){
for(i=1;i<=n/2;i++){
printf("%s ",a[i]);
printf("%s ",a[n-i+1]);}
printf("%s",a[n/2+1]);
}
else{
	for(i=1;i<=n/2;i++){
if(i==1)
printf("%s",a[i]);
else
printf(" %s",a[i]);
printf(" %s",a[n-i+1]);}
}
printf("%c\n",biao);
}
return 0;
} 
