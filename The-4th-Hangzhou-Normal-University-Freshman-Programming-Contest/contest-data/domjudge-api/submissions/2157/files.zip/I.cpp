#include <stdio.h>
#include <stdlib.h>
typedef struct _paixu{
	int p;
	char s[20];
}paixu;
paixu w[100010];
int comp(const void* p,const void* q);
int main()
{
	int i,n;
	scanf("%d",&n);
	getchar();
	for(i=0;i<n;i++)
	{
		scanf("%d %s",&w[i].p,w[i].s);
		getchar();
	}
	int k;
	scanf("%d",&k);
	qsort(w,n,sizeof(paixu),comp);
	printf("%s\n",w[k].s);
	return 0;
}
int comp(const void* p,const void* q)
{
	paixu* pp=(paixu *)p;
	paixu* qq=(paixu *)q;
	return qq->p-pp->p;
}

