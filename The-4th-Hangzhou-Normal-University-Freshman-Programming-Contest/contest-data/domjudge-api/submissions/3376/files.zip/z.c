#include<stdio.h>
int main(){
	int n,m;
	scanf("%d",&n);
	for(m=0;m<n;m++){
		printf("Welcome to HZNU\n");
	}
	return 0;
}
