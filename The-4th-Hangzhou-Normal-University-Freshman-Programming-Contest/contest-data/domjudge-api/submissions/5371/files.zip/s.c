#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<time.h>
#include<math.h>
int main(){
	char ch;
	int t,n,i,j,num,sum,alph[60];
	scanf("%d",&t);
	while(t--){
		memset(alph,0,sizeof(alph));
		sum=0;
		scanf("%d\n",&n);
		for(i=0;i<n;i++){
			scanf("%c",&ch);
			if(ch==' '){
				i--;
				continue;
			}
			if(ch>='a')num=59-('z'-ch);
			else num=ch-'A';
			alph[num]++;
		}
		for(i=0;i<=59;i++){
			if(alph[i]>1){
				sum=sum+alph[i]-alph[i]%2;
				alph[i]=alph[i]%2;
			}
		}
		for(i=0;i<=59;i++){
			if(alph[i]==1){
				sum++;
				break;
			}
		}
		printf("%d\n",sum);
	}


}