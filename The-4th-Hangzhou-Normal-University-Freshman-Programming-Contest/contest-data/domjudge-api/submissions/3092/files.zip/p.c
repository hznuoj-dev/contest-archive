#include <stdio.h>
struct g
{
	char na[20];
	long long int pp;
	int rank;
	
}gg[100004];
int main()
{
	int a,b,c,d,e;
	scanf("%d",&a);
	for(b=1;b<=a;b++)
	{
		scanf("%ld %s",&gg[b].pp,gg[b].na);
	}
	scanf("%d",&e);
	printf("%s\n",gg[a-e].na);
	return 0;
}