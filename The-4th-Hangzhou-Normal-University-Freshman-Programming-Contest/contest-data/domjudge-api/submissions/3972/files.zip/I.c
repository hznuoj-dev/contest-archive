#include<stdio.h>
#include<stdlib.h>
struct ge{
	int love;
	char name[20];
};
int compare(const void*p,const void*q){
	struct ge*c=(struct ge*)p,*d=(struct ge*)q;
	return d->love-c->love;
}
int main(){
	int n,k,i,j;
	scanf("%d",&n);
	struct ge a[n+3];
	for(i=1;i<=n;i++)scanf("%d%s",&a[i].love,a[i].name);
	scanf("%d",&k);
	qsort(a,n,sizeof(a[1]),compare);
	printf("%s",a[k].name);
	return 0;
}
