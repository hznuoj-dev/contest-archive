#include<stdio.h>
#include<stdlib.h>
struct chang
{
	long long int w;
	char s[100];
};
int comp(const void* p, const void* q);

int main()
{
	struct chang c[10000];
	long long int n,i;
	scanf("%lld", &n);
	for(i=0;i<n;i++)
	{
		scanf("%lld %s", &c[i].w, c[i].s);
	}
	qsort(c, n, sizeof(struct chang), comp);
	long long int k;
	scanf("%lld", &k);
	printf("%s", c[k].s);
}
int comp(const void* p, const void* q)
{
	return -(((struct chang*)p)->w - ((struct chang*)q)->w);
}