#include<stdio.h>
#include<stdlib.h>
int main(void)
{
 	int i,a,b,c,k[20],xue,flag=0,sum;
 	scanf("%d %d",&a,&b);
 	if(b==0)
 	xue=2500;
 	else
 	xue=2100;
 	for(i=0;i<a;i++)
 	{
 		scanf("%d",&k[i]);
 		if(k[i]==2)
 		{
 			flag=2;
		}
		else if(k[i]==1)
		{
			flag=1;
		}
		else if(k[i]==0)
		{
			scanf("%d",&c);
			xue-=c;
		}
	}
	if((a>=2&&flag==2)||(xue<=0&&flag==1))
	{
		printf("haoye\n");
	}
	else
	{
		printf("QAQ\n");
	}
	return 0;
} 
