#include<bits/stdc++.h>
using namespace std;
int a[100010];
int main()
{  int sum=0,ans=0,i,j,k,n,m,l,r;
   cin>>n;
   for (i=1;i<=n;i++)
   {  cin>>m;
      l=1;
      for (i=1;i<=m;i++)
      { cin>>a[i];
        sum+=a[i];
       if (a[i]>7777)  {l=i+1; sum=0; }
	    else  
	     while(sum>=7777)
         { if (sum==7777) ans++;
           sum-=a[l];
           l++;
         }
      }
      cout<<ans<<"\n";
   }
}
  
   

 

