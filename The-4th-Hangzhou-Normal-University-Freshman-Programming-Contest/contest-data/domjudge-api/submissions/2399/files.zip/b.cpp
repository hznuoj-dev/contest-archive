#include<stdio.h>
#include<math.h>
#include<string.h>
int main()
{
	long long t,x,n;
	scanf("%lld",&t);
	while(t--)
	{
		scanf("%lld %lld",&n,&x);
		if(n%x==0)
		{
			printf("yes\n");
		}
		else
		{
			printf("no\n");
		}
	}
	return 0;
} 
