#include<stdio.h>
#include<string.h>
#include<math.h>
int main() {
	int t, number, a[100000], sum, i, j, k, result;
	scanf("%d", &t);
	while (t--) {
		sum = 0;
		scanf("%d", &number);
		for (i = 1; i <= number; i++) {
			scanf("%d", &a[i]);
		}
		for (i = 1; i <= number; i++) {
			for (j = i + 1; j <= number; j++) {
				result = 0;
				for (k = i; k <= j; k++) {
					result += a[k];
				}
				if (result == 7777)
					sum++;
			}
			for (i = 1; i <= number; i++) {
				if (a[i] == 7777)
					sum++;
			}
		}
		printf("%d\n", sum);
	}
	return 0;
}