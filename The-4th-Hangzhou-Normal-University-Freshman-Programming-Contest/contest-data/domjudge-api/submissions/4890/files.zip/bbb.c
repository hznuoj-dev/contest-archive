#include<stdio.h>
#define H 100000
int main(){
	int t, n, i, f[H], m, j;
	scanf("%d", &t);
	while(t--){
		m=0;
		scanf("%d", &n);
		for(i=0;i<n;i++){
			scanf("%d", &f[i]);
		}
		for(i=0;i<n;i++){
			if(f[i]==7777){
				m+=1;
			}
			if(i!=n-1){
				for(j=i+1;j<n;j++){
					f[i]+=f[j];
					if(f[i]==7777){
						m+=1;
					}	
				}
			}
		}
		printf("%d\n", m);
	}
}
