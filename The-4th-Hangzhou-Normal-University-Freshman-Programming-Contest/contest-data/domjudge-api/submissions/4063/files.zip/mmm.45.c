//
#include<stdio.h>
#include<stdlib.h>
struct qwe {
	int w;
	char s[16];
};
int comp(const void* p, const void* q) {
	return((*(struct qwe*)q).w-(*(struct qwe*)p).w);
}
struct qwe a[100000];
int main(void) {
	int n;
	scanf("%d", &n);
		
		int k;
		for (int i = 0; i < n; i++) {
			scanf("%d%s", &a[i].w, &a[i].s);
		}
		scanf("%d", &k);
		qsort(a, n, sizeof(struct qwe), comp);
		printf("%s", a[k].s);
	return 0;
}