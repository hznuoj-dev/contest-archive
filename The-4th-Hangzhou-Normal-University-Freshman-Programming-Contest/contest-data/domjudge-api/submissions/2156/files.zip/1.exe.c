/*#include<stdio.h>
#include<string.h>
main(){
	int t;
	int n;
	char d;
	int d1=0;
	int i;
	int sum=0;
	int k=0;
	int a[130]={0};
	scanf("%d",&t);
	while(t--){
		scanf("%d",&n);
		
		while(n--){
			getchar();
		scanf("%c",&d);
		d1=(int)d;
		a[d1]++;
		}
		for(i=65;i<=123;i++){
			if(a[i]%2==0&a[i]!=0){
			sum+=a[i];
			}
			else if(a[i]!=0&&a[i]>2){
				sum+=a[i]-1;
				if(d==0){
				sum++;
				k=1;
				}
			
			}
			else if(a[i]==1&&k==0){
			sum++;
			k=1;
			}
		}
		printf("%d\n",sum);
		sum=0;
		memset(a,0,sizeof(a));
	}
}*/