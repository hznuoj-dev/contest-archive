#include<stdio.h>
int main(void){
	int n,k,i,j,c;
	long e;
	scanf("%d",&n);
	long a[100001];
	char b[100001][16];
	for(i=0;i<n;i++){
		scanf("%ld",&a[i]);
		getchar();
		scanf("%s",b[i]);
	}
		scanf("%d",&k);
	if(k<n){
	for(i=0;i<=k;i++){
		c=-1;
		for(j=0;j<n;j++){
			if(a[j]!=-1){
				if(c==-1){
					c=j;
					e=a[j];
				}
				else if(a[j]>e){
					c=j;
					e=a[j];
				}
			}
		}
		a[c]=-1;
	}
		printf("%s",b[c]);
		}
	return 0;
}
