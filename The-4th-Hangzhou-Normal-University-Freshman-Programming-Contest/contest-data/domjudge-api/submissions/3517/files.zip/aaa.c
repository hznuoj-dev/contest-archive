#include<stdio.h>
#include<string.h>
#include<math.h>
//int i = 0;
int tiao(int n, int x,int i) {
	//int i;
	while (i < n) {
		i += x;
	}
	if (i == n)	return 1;
	else {
		i = i - n;
	}
	if (i == 0)	return 0;
	else
	{
		tiao(n, x,i);
	}
}
int main() {
	int t, n, x,flag;
	scanf("%d", &t);
	while (t--) {
		flag = 0;
		scanf("%d %d", &n, &x);
		if (x == 0) {
			flag = 0;
		}
		else
		{
			flag = 1;
		}
		if (flag == 0) {
			printf("no\n");
		}
		else
			printf("yes\n");
	}
}