#include<stdio.h>
int main(){
	int n,m,a[1000],k,i,check=0,j=0,flag=0;
	scanf("%d%d",&n,&m);
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
		if(a[i]==0){
			scanf("%d",&k);
			if((k>=2500&&m==0)||(k>2100&&m==1)){
				check=1;
			}
			j++;
		}
		else if(a[i]==1){
			j++;
			if(check==1){
				flag=1;
			}
		}
		else if(a[i]==2){
			if(j>0&&check==0){
				flag=1;
			}
		}
	}
	if(flag==1){
		printf("haoye\n");
	}
	else{
		printf("QAQ\n");
	}
}
