#include<stdio.h>
#include<math.h>
#include<string.h>
#include<stdlib.h>
int main()
{
	int T,n,a[100001]={0},sum=0,i;
	scanf("%d",&T);
	while(T--)
	{
		printf("Welcome to HZNU\n");
	}
 } 
