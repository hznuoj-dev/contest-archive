#include<stdio.h>
int main(){
	int t;
	int flag=0;
	scanf("%d",&t);
	while(t--){
		long long int n,x;
		scanf("%lld%lld",&n,&x);
		int i=0;
		for(i=1;i<=n;i++){
			int s=i*x;
			if(s>=n){
			flag=1;
			break;
		}
		else
		flag=0;
		}
		if(flag==1)
		printf("yes\n");
		if(flag==0)
		printf("no\n");
	}
	return 0;
}
