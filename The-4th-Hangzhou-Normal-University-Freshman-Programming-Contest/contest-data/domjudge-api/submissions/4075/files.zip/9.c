#include <stdio.h>
struct sum{
	long long int w;
	char s[20];
};
int main(void){
	long long int n,k,i,j;
	struct sum temp;
	struct sum a[10000];
	scanf("%lld",&n);
	for(i=0;i<n;++i){
		scanf("%lld%s",&a[i].w,a[i].s);
	}
	scanf("%lld",&k);
	for(i=1;i<n;++i){
		for(j=0;j<n-i;++j){
			if(a[j].w<a[j+1].w){
				temp=a[j];
				a[j]=a[j+1];
				a[j+1]=temp;
			}
		}
	}
	printf("%s",a[k].s);
	return 0;
} 
