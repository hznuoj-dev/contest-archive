#include <bits/stdc++.h>
using namespace std;

int a[26];
int b[26];

int main()
{
	int t,n,i,j;
	int m,ans;
	char c;
	
	cin >> t;
	while(t--)
	{
		for(i=0;i<=25;i++)
		{
			a[i]=0;
			b[i]=0;
		}
		
		cin >> n;
		for(i=1;i<=n;i++)
		{
			cin >> c;
			if(c>='A' && c<='Z')	a[c-'A']++;
			else	b[c-'a']++;
		}
		ans=0;m=0;
		for(i=0;i<=25;i++)
		{
			if(a[i]%2==0)	ans+=a[i];
			else if(a[i]>m)	m=a[i];
			if(b[i]%2==0)	ans+=b[i];
			else if(b[i]>m)	m=b[i];
		}
		ans+=m;
		cout << ans << '\n';
	}
	
	return 0;
}
