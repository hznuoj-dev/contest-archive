# include <stdio.h>
# include <math.h>
int main(){
	int t,x,i,b,c;
	long long n;
	scanf("%d",&t);
	while(t--){
		scanf("%lld%d",&n,&x);
		c=0;
		b=n;
		if(x!=0) {
			for(i=n;n<=10e31;n=n+b){
				if(n%x==0){
					c=1;
					break;
				}
			}
		}
		if(c==1)printf("yes\n");
		else printf("no\n");
	}
}
