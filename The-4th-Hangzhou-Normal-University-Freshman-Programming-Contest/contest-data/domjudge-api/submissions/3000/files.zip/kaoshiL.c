#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<math.h>
int main(){
	int t;
	scanf("%d",&t);
	while(t--){
		int n,x;
		scanf("%d %d",&n,&x);
		if(x==0||(x*n)%x!=0)
			printf("no\n");
		if((x*n)%x==0)
		printf("yes\n");
		
	
	}
	return 0;
}
