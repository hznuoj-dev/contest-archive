#include<bits/stdc++.h>
using namespace std;
#define endl '\n'; 
#define cnm ios_base::sync_with_stdio(0);cin.tie(0);
char a[100001];
int b[54];
int main () {
	cnm;
	int t;
	cin >> t;
	while (t--){
		int ans=0,f=0;
		int k = 0;
		int max =-1e9;
		memset(a,0,sizeof(a));
		memset(b,0,sizeof(b));
		int n;
		cin >> n;
		for (int i = 0 ; i<n ; i++){
			cin >> a[i];
			b[a[i]-65]++;
		}
		for (int i = 0 ; i<54 ; i++){
			if (b[i]%2==1&&b[i]>max) {
				max=b[i];
				f=1;
				k=i;
			}
		}
		if (f==1) {
			b[k]=0;
			ans = max;
		}
		else ans = 0;
		for (int i = 0 ; i<54 ; i++){
		    if (b[i]%2==0) ans+=b[i];
		    else if (b[i]%2==1&&b[i]!=1) {
		    	ans+=b[i]-1;
			}
		}
		cout << ans <<endl;
	}
	return 0;
}
