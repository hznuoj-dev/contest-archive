#include<stdio.h>
int main(){
    int t,i,j;
    char c[10001];
    long n;
	int count=0;
    scanf("%d",&t);
    while(t--){
    	scanf("%ld",&n);
    	for(i=0;i<n;i++){
    		scanf("%c",&c[i]);
    		getchar();
		}
		for(i=0;i<n-1;i++){
			for(j=i+1;j<n;j++){
				if(c[i]==c[j]){
					count++;
				}
			}
		}
	if(count==0){
		printf("1\n");
	}
	else{
	printf("%d\n",2*count+1);
	}

	}
	return 0;
}
