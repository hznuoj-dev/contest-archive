#include<stdio.h>
int main(void){
	int x;
	scanf("%d",&x);
	while(x--)
	{
	printf("Welcome to HZNU\n");
	}
}

