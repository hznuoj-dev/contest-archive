#include<stdio.h>
int main()
{
	int T, n, i, j, flag[4] = { 0,0,0,0 };
	int fang1[21][21], fang2[21][21], fang3[21][21], fang4[21][21];
	int zh[21][21];
	scanf("%d", &T);
	while (T > 0)
	{
		scanf("%d", &n);
		for (i = 0; i < n; i++)
		{
			for (j = 0; j < n; j++)
			{
				scanf("%d", &fang1[i][j]);
			}
		}
		for (i = 0; i < n; i++)
		{
			for (j = 0; j < n; j++)
			{
				scanf("%d", &zh[i][j]);
			}
		}
		for (i = 0; i < n; i++)
		{
			for (j = 0; j < n; j++)
			{
				fang2[i][j] = fang1[j][n - i - 1];
			}
		}
		for (i = 0; i < n; i++)
		{
			for (j = 0; j < n; j++)
			{
				fang3[i][j] = fang2[j][n - i - 1];
			}
		}
		for (i = 0; i < n; i++)
		{
			for (j = 0; j < n; j++)
			{
				fang4[i][j] = fang3[j][n - i - 1];
			}
		}
		for (i = 0; i < n; i++)
		{
			for (j = 0; j < n; j++)
			{
				if (fang1[i][j] == zh[i][j])
					flag[1] += 1;
				if (fang2[i][j] == zh[i][j])
					flag[2] += 1;
				if (fang3[i][j] == zh[i][j])
					flag[3] += 1;
				if (fang4[i][j] == zh[i][j])
					flag[4] += 1;
			}
		}
		if (flag[1] == n * n)
			printf("-1\n");
		else
			if (flag[2] == n * n)
				printf("1\n");
			else
				if (flag[3] == n * n)
					printf("2\n");
				else
					if (flag[4] == n * n)
						printf("1\n");
					else
						printf("-1\n");
		T--;
	}
	return 0;
}