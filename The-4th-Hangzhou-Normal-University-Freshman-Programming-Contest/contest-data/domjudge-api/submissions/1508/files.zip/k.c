#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int n,i;
	scanf("%d",n);
	for(i=0;i<n;i++){
		printf("Welcome to HZNU\N");
	}
	return 0; 
}
