#include <stdio.h>

int main(void){
	int n,i;
	scanf("%d",&n);
	for(i=0;i<n-1;++i){
		printf("Welcome to HZNU\n");
	}
	printf("Welcome to HZNU");
    return 0;
}

