#include <stdio.h>
int a[1000000];
int main(void){
	int n,x,y,t,i,flag,s;
	scanf("%d",&t);
	while(t--){
		s=0;
		scanf("%d %d",&n,&x);
		for(i=0;i<n;i++){
			a[i]=0;
		}
		while(1){
			s=(s+x)%n;
			a[s]++;
			if(x==0){
				flag=0;
				break;
			}
			if(s==0){
				flag=1;
				break;
			}
			if(a[s]>=2){
				flag=0;
				break;
			}
		}
		if(flag){
			printf("yes\n");
		}else{
			printf("no\n");
		}
	}
	return 0;
} 
