#include <bits/stdc++.h>
using namespace std; 
int a[200];
int main()
{
	int T,n,i;
	char c;
	scanf("%d",&T);
	while (T--)
	{
		for (i=1; i<=128; i++) a[i]=0;
		scanf("%d",&n);
		getchar();
		for (i=1; i<=n; i++)
		{
			scanf("%c",&c);
			getchar();
			a[c]++;
		}
		int sum=0,f=0;
		for (i=1; i<=128; i++)
		{
			sum=sum+a[i]/2*2;
			if (a[i] % 2==1) f=1;
		}
		sum+=f;
		printf("%d\n",sum);
	}
}
