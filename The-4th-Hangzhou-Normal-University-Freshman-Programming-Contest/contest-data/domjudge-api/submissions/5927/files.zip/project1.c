#include<stdio.h>
#include<stdlib.h>
typedef struct{
	int w;
	char s[16];
}sing;
int comp(const void*a,const void*b){
	sing*pa=(sing*)a;
	sing*pb=(sing*)b;
	int num1=pa->w;
	int num2=pb->w;
	return (int)num2-num1;
}
int main(void)
{
	sing stff[100001];
	long long int n,i,j,k,m,t;
	scanf("%lld",&n);
	for(i=0;i<n;i++){
		scanf("%d %s",&stff[i].w,stff[i].s);
	}
	scanf("%lld",&t);
	qsort(stff,n,sizeof(sing),comp);
	printf("%s",stff[t].s);
    return 0;
}

