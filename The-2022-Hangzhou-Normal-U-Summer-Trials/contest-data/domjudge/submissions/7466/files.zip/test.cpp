#include<iostream>
#include<string>
#include<map>
#include<algorithm>
using namespace std;
const int N=5e5+10;
long long a[N];
long long line[N];
long long sum[N];
int main(){
    long long n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int i=2;i<=n;i++){
        line[i-1]=a[i]-a[i-1];
    }
    line[n]=1e18;
    for(int i=1;i<=n;i++){
        sum[i]=sum[i-1]+line[i];
    }
    sort(line,line+n);
    long long m;
    cin>>m;
    while(m--){
        long long x;
        cin>>x;
        long long ans=0;
        long long l=1,r=n;
        while(l<r){
            long long mid=l+r>>1;
            if(line[mid]>x) r=mid;
            else l=mid+1;
        }
        ans=ans+sum[r-1]+(n-r+1)*x;
        cout<<ans<<endl;
    }
}
