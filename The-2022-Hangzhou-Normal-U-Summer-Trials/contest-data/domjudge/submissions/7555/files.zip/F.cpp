#include <bits/stdc++.h> 
using namespace std;
long long a[100050],sum[100050],bl[100050];
struct node{
	int l,r;	
}b[1000050];
long long ans=0,cnt;
bool cmp(node a,node b)
{
	if (a.l==b.l) return a.r<b.r;
	else return a.l<b.l;
}

void dfs(long long x,long long y)
{
	ans++;
	int l=lower_bound(bl+x,bl+cnt+1,y)-bl;
	while (b[l].l==y)
	{
//	cout << "   " <<  b[x].r << " " << b[l].l << "\n";
		dfs(l,b[l].r);
		l++;
	} 
}

int main()
{
//	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	long long n,k;
	cin >> n >> k;
	for (int i=1; i<=n; i++) 
	{
		cin >> a[i];
		a[i]=a[i]%k;
		sum[i]=sum[i-1]+a[i];
	}
	
	long long l=0,r=1;
	while (l<n)
	{
		long long  dis=sum[r]-sum[l];
		if (dis%k==0)
		{
			cnt++;
			b[cnt].l=l;
			b[cnt].r=r;
			l++;
			while (l<r && (sum[r]-sum[l])%k==0 )
			{
				cnt++;
				b[cnt].l=l;
				b[cnt].r=r;
				l++;
			}
		}	
		if (r<n) r++;	
		else l++;
	}
	sort(b+1,b+1+cnt,cmp);
	for (int i=1; i<=cnt; i++) bl[i]=b[i].l;
	/*	for (int i=1; i<=cnt; i++) { cout << b[i].l << "  "  << b[i].r << "\n";
		}*/
	for (int i=1; i<=cnt; i++)
	{
		dfs(i,b[i].r);
	//	cout << i << " " << ans << "\n";
	}
	
	cout << ans;
}
