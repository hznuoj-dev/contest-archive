#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
long long n,a[N],b[N],c[N],q,t,g,w,ans,f;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(i>=2){
			b[++g]=a[i]-a[i-1];
		}
	}
	for(int i=1;i<n;i++){
		c[i]=c[i-1]+b[i];
	}
	cin>>q;
	while(q--){
		f=0;
		cin>>t;
		for(int i=1;i<n;i++){
			if(b[i]<t){
				f++;
			} else{
				break;
			}
		}
		ans=(n-f)*t;
		ans+=c[f];
		cout<<ans<<'\n';
	}
	return 0;
} 
