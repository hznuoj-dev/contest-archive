#include<bits/stdc++.h>
using namespace std;
#define yes (cout<<"YES\n")
#define no (cout<<"NO\n")
#define endl '\n'
//typedef long long ll;
#define int long long
void sxseven();
signed main() {
	ios::sync_with_stdio(false);
	int _=1;
	//cin >> _;
	while(_--) sxseven();
	return 0;
}
const int N=5e5+5;
unordered_map<int,int> mp;
void sxseven() {
	int n,k;
	cin >> n >> k;
	mp[0]=1;
	int an=0,s=0,x;
	for(int i=1; i<=n; ++i) {
		cin >> x;
		s+=x;
		s%=k;
		an+=mp[s];
		++mp[s];
	}
	cout<<an;
}

