#include <bits/stdc++.h>

using namespace std;

map<char,long long> mp0;

long long value[1005];
string a[1005];

map<long long,string>mp1;





int main() {
	
	
    for(int i = 0 ; i<26 ; i++){
        char tmp;
        cin >> tmp;
        mp0[tmp] = i;
    }

    int n;
    cin >> n;
    int len = 0;
    for(int i = 0 ; i<n ; i++){
    	string s;
    	cin >> s;
    	int tmp = s.length();
    	len = max(len,tmp);
    	a[i] = s;
	}
	for(int i = 0 ; i<n ; i++){
		string tmp = a[i];
		for(int j = 0 ; j<len ; j++){
			value[i] += mp0[tmp[j]] * pow(10,len-j);
		}
		mp1[value[i]] = tmp;
	}
	
	int k;
	cin >> k;
	
	sort(value,value+n);
	
	/*for(int i = 0 ; i<n ; i++){
		cout << value[i] << endl;
	}*/
	
	cout << mp1[value[k-1]] << endl;
	
	
	
	


}

