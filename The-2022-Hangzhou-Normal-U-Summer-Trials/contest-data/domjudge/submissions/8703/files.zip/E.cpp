#include<bits/stdc++.h>

using namespace std;

#define debug(x) cerr << #x << " = " << x << '\n'

typedef long long ll;

const int N = 2e5 + 10;

void solve() {
	int n;
	cin >> n;
	vector<vector<int>> adj(n + 1);
	for (int i = 1; i < n; ++i) {
		int u, v;
		cin >> u >> v;
		adj[u].push_back(v);
		adj[v].push_back(u);
	}
	
	vector<int> sz(n + 1), dep(n + 1);
	function<void(int, int)> dfs = [&](int u, int fa) {
		sz[u] = 1;
		dep[u] = dep[fa] + 1;
		for (auto v : adj[u]) {
			if (v == fa) continue;
			dfs(v, u);
			sz[u] += sz[v];
		}
	};
	
	dfs(1, 0);
	
	int q;
	cin >> q;
	while (q--) {
		int u;
		cin >> u;
		ll ans = (n - 1) * (n - 1);
		for (auto v : adj[u]) {
//			printf("dep[v] = %d ", dep[v]);
			if (dep[v] == dep[u] + 1) ans -= sz[v] * sz[v];
			else ans -= (n - sz[u]) * (n - sz[u]);
		}
		ans = ans / 2 + n - 1;
		cout << ans << '\n';
	}
}

/*
5
1 2
1 3
3 4
3 5
5
1
2
3
4
5
*/ 

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
