#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> PLL;
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define debug(a) cout<<#a<<'='<<a<<endl;
#define fi first
#define se second
#define push_back pb


void solve(){
	string str;
	cin>>str;
	ll ans=0;
	rep(i,0,str.size()){
		if(i<str.size()-3&&str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u'){
			i+=3;
			ans++;
		}
	}
	cout<<ans<<endl;
}

int main(){
	int _=1;
//	cin>>_;
	while(_--)solve();
	return 0;
}
