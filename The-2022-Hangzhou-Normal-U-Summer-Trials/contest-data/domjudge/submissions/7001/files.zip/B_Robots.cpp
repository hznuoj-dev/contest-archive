#include<iostream>
#include<algorithm>
#include<cstring>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
using namespace std;
char mp[200];
string ss[1010];
struct node {
    string ss;
    string org;
}nd[1010];
bool cmp (node n1, node n2) {
    return n1.ss < n2.ss;
}
int main() {
	IOS;
	string s; cin >> s;
	int n = s.size();
	for (int i = 0; i < n; i++) {
		mp[s[i]] = char('a' + i);
	}
	int t; cin >> t;
	for (int i = 1; i <= t; i++) {
		cin >> ss[i];
		int nn = ss[i].size();
        nd[i].org = ss[i];
		for (int j = 0; j < nn; j++) {
			ss[i][j] = mp[ss[i][j]];
		}
        nd[i].ss = ss[i];
	}
    // for (int i = 1; i <= t; i++) {
    //     cout << ss[i] << "&\n";
    // }
	sort(nd + 1, nd + 1 + t, cmp);
	int k; cin >> k;
	cout << nd[k].org << "\n";
}