#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=100000001;
vector<int >v,ss;
map<ll,ll>p;
map<ll,ll>::iterator it;
int main(){
	int n,k;
	cin>>n>>k;
	for(int i=0;i<n;i++){
		int x;
		cin>>x;
		v.push_back(x);
	}
	ll s=0;
	for(int i=0;i<n;i++){
		s+=v[i];
		ss.push_back(s);
	}
	for(int i=0;i<n;i++){
		for(int j=i;j<n;j++){
			p[ss[j]-ss[i]]++;
			p[ss[j]]++;
		}
	}
	ll maxs=0;
	for(it=p.begin();it!=p.end();it++){
		if(it->first%3==0&&maxs<it->second)
		maxs=it->second;
	}
	cout<<maxs<<endl;
}
