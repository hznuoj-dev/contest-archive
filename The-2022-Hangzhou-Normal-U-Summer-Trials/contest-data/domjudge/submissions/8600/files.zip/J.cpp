#include<bits/stdc++.h>
using namespace std;
int n,tmp;
int ty,l;
char x,y;
char ans[100005];
int p[28][100005],pp[28];
bool flag;
string f="The final string is empty";
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>ty;
		if(ty==2){
			pp[ans[l]-'a']--;
			l--;
			
		}
		else if(ty==1){
			cin>>x;
			ans[++l]=x;
			p[ans[l]-'a'][++pp[ans[l]-'a']]=l;
		}
		else{
			cin>>x>>y;
			tmp=pp[x-'a'];
			for(int j=1;j<=tmp;j++){
				ans[p[x-'a'][j]]=y;
				p[y-'a'][++pp[y-'a']]=p[x-'a'][j];
			}
			pp[x-'a']=0;
			sort(p[y-'a']+1,p[y-'a']+1+pp[y-'a']);
		}
	}
	if(l==0){
		cout<<f;
	}
	else{
		for(int i=1;i<=l;i++){
			cout<<ans[i];
		}
	}
	return 0;
}
