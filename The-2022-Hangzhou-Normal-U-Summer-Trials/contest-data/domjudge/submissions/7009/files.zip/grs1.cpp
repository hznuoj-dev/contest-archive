#include<bits/stdc++.h>
#define rson rt<<1|1
#define lson rt<<1
#define pb push_back
#define endl '\n'
#define x first
#define y second
#define LLINF 9223372036854775807
#define IOS ios::sync_with_stdio(0); cin.tie(0); 
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;

const int N=101000;

int n;
ll k;

int main()
{  
	IOS 
    cin>>n>>k;
    map<ll,ll>mp;
    mp[0]=1;
    ll sum=0,ans=0;
    for(int i=1;i<=n;i++){
        ll x;cin>>x;
        sum+=x;
        if(mp.count(sum%k))
        ans+=mp[sum%k];
        mp[sum%k]++;
    }
    cout<<ans<<endl;
    return 0;
}