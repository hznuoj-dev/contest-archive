#include<bits/stdc++.h>
using namespace std;
int n;
string s1;
string s[1010];
int a[1010];
int k;
int d[100];
bool cmp(string a,string b){
	int s=min(a.size(),b.size());
	for(int i=0;i<s;i++){
		if(d[a[i]-'a'+1]!=d[b[i]-'a'+1]){
			return d[a[i]-'a'+1]<d[b[i]-'a'+1];
		}
	}
	return a.size()<b.size();
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>s1;
	cin>>n;
	for(int i=0;i<26;i++){
		d[s1[i]-'a'+1]=i;
	}
	for(int i=1;i<=n;i++){
		cin>>s[i];
	}
	sort(s+1,s+n+1,cmp);
	cin>>k;
	cout<<s[k]<<endl;
} 
