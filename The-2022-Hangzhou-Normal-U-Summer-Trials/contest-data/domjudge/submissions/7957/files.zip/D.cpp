#include <bits/stdc++.h>

using namespace std;

string st;
int pos[30];

struct node
{
    string a;
    string b;
    bool operator<(const node &p) const
    {
        return b < p.b;
    }
} s[1005];

string to_hash(string a)
{
    for (int i = 0; i < a.size(); i++)
        a[i] = char('a' + pos[a[i] - 'a']);
    return a;
}

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    cin >> st;
    for (int i = 0; i < st.size(); i++)
        pos[st[i] - 'a'] = i;
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> s[i].a;
        s[i].b = to_hash(s[i].a);
        // cout << s[i].b << endl;
    }
    sort(s + 1, s + 1 + n);
    // for(int i = 1; i <= n; i ++){
    //     cout << s[i].a << " " << s[i].b << endl;
    // }
    int k;
    cin >> k;
    cout << s[k].a;

    return 0;
}