#include  <bits/stdc++.h>
using namespace std;

int n;
unsigned long long num[500010];

int search(int x)
{
    int l = 0, r = n;
    int mid;

    while (l < r)
    {
        mid = (l+r+1)/2;
        if (num[mid+1]-num[mid] > x) r = mid-1;
        else if (num[mid+1]-num[mid] <= x) l = mid;
    }
    return l;
}

int work()
{
    int i, j;
    unsigned long long t, t0;
    int q;
    scanf("%d", &n);

    for (i = 1; i <= n; i++)
        scanf("%lld", &num[i]);
    num[n+1] = 1000000000000000000; // 10^18
    
    scanf("%d", &q);
    for (i = 0; i < q; i++)
    {
        scanf("%lld", &t); // 时间
        t0 = search(t); // 查完的人
        printf ("%lld\n", num[t0+1]-num[1] + t*(n-t0));
    }

    return 0;
}

int main()
{
    int T = 1;
    //scanf("%d", &T);
    while (T--) work();
    //getchar();getchar();getchar();
    return 0;
}
