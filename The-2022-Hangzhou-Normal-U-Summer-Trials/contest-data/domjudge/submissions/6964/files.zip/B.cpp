#define _CRT_SECURE_NO_WARNINGS
#include<cstdio>
#include<cstring>
#include<map>
#include<algorithm>
#include<string>
#include<iostream>
using namespace std;

map <char, int> mp;

string s[1013];

bool cmp(string x, string y)
{
	int lx = x.length();
	int ly = y.length();
	int l = min(lx, ly);
	for (int i = 0; i < l; i++)
	{
		if (mp[x[i]] != mp[y[i]]) return mp[x[i]] < mp[y[i]];
	}
	return lx < ly;
}

int main()
{
	char tmp[31];
	scanf("%s", tmp);
	for (int i = 0; i < 26; i++)
	{
		mp[tmp[i]] = i + 1;
	}
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		cin >> s[i];
	}
	sort(s + 1, s + n + 1, cmp);
	int m;
	scanf("%d", &m);
	cout << s[m];
}
