#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef long long ll;
const int N=2e5+7;
map<char,char>mp;

struct node{
	string ori;
	string now;
}s1[N];

bool operator <(node a,node b){
	return a.now<b.now;
}

void solve(){
	mp.clear();
	string s;
	cin >> s;
	int k=s.size();
	for (int i=0;i<k;i++){
		mp[s[i]]='a'+i;		
	}
	int n;
	cin >> n;
	for (int i=1;i<=n;i++){
		cin >> s1[i].ori;
		int k=s1[i].ori.size();
		for (int j=0;j<k;j++){
			s1[i].now+=mp[s1[i].ori[j]];			
		}				
	}
	sort(s1+1,s1+1+n);
	int K;
	cin >> K;
	cout << s1[K].ori << '\n';
	
	
}

signed main(){
	ios::sync_with_stdio(0);
	int t=1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}

