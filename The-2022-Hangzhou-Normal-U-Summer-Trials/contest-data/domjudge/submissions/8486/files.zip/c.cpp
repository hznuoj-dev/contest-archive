#include<bits/stdc++.h>
using namespace std;
const int N = 500005;

int main(){
	int n,i,q;
	unsigned long long a[N],cha[N];
	unsigned long long ans,t,st,ed;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%lld",&a[i]);
        if(i>=2){
            cha[i] = a[i] - a[i-1] + 1;
        }
	}
	scanf("%d",&q);
	vector<pair<unsigned long long,unsigned long long>> v;
	while(q--){
		scanf("%lld",&t);
		ans = 0;
		while(!v.empty()){
			v.pop_back();
		}
        for(i=2;i<=n;i++){
            if(t<cha[i]){
                break;
            }
        }
        int res = i;
        st = a[1];
        ed = a[res-1] + t - 1;
        v.push_back({st,ed});
		for(i=res;i<=n;i++){
			st = a[i];
			ed = a[i] + t - 1;
			v.push_back({st,ed});
		}
		st = v[0].first;
		ed = v[0].second;
		for(i=1;i<v.size();i++){
			if(v[i].first<=ed){
				ed = v[i].second;
			}else{
				ans += ed - st + 1;
				st = v[i].first;
				ed = v[i].second;
			}
		}
		ans += ed - st + 1;
		printf("%lld\n",ans);
	}
	return 0;
}

