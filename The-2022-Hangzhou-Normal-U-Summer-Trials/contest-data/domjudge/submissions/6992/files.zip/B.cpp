#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	string s;cin>>s;
	vector<int> hs(26);
	for(int i=0;i<26;i++) hs[s[i]-'a']=i;
	int n;cin>>n;
	vector<string> a(n);
	for(int i=0;i<n;i++) cin>>a[i];
	int K;cin>>K;
	auto cmp=[&](char x,char y,bool mod){
		int l=hs[x-'a'];
		int r=hs[y-'a'];
		return (mod?l<r:l>r);
	};
	sort(a.begin(),a.end(),[&](auto x,auto y)->int{
		int l=min(x.size(),y.size());
		for(int i=0;i<l;i++)
		if(cmp(x[i],y[i],1)) return 1;else
		if(cmp(x[i],y[i],0)) return 0;
		return x.size()<y.size();
	});
	cout<<a[K-1]<<"\n";
	return 0;
}