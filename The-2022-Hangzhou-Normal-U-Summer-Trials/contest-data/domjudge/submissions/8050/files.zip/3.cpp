#include<bits/stdc++.h>
#define sync_flow ios::sync_with_stdio(false);cin.tie(0)
#define zf(i,l,r) for(int i=l;i<=r;i++)
#define df(i,r,l) for(int i=r;i>=l;i--)
#define lowbit(x) (x&(-x))
#define no cout<<"no solution"
using namespace std;
typedef long long ll;
const ll maxn=55;
typedef struct NODE{
	ll x,y;
}id;
typedef struct NODE2{
	id aa,bb;
	ll cnt;
}node;
node tmp;
ll ans=0,n;
id a,b;
int vis[maxn][maxn]={0};
char mp[maxn][maxn];
queue<node>q;

inline bool judge(const id l,const id r){
	if(l.x==r.x&&l.y==r.y)return true;
	return false;
}
inline bool equal(const node l,const node r){
	if(judge(l.aa,r.aa)&&judge(l.bb,r.bb)&&l.cnt==r.cnt)return true;
	return false;
}
void pushr(const node nd){
	tmp.aa=nd.aa;
	ll tag=0;
	if(nd.aa.y<n){
		if(mp[nd.aa.x][nd.aa.y+1]!='*'){
			tmp.aa.y++;
			tmp.cnt=nd.cnt+1;
			tag=1;
		}
	}
	tmp.bb=nd.bb;
	if(nd.bb.y<n){
		if(mp[nd.bb.x][nd.bb.y+1]!='*'){
			tmp.bb.y++;
			if(!tag)tmp.cnt=nd.cnt+1;;
		}
	}
	if(!equal(nd,tmp)){
		if(!vis[tmp.aa.x][tmp.aa.y])q.push(tmp);
		vis[tmp.aa.x][tmp.aa.y]=1;
	}
	return ;
}
void pushl(const node nd){
	tmp.aa=nd.aa;
	ll tag=0;
	if(nd.aa.y>1){
		if(mp[nd.aa.x][nd.aa.y-1]!='*'){
			tmp.aa.y--;
			tmp.cnt=nd.cnt+1;;
			tag=1;
		}
	}
	tmp.bb=nd.bb;
	if(nd.bb.y>1){
		if(mp[nd.bb.x][nd.bb.y-1]!='*'){
			tmp.bb.y--;
			if(!tag)tmp.cnt=nd.cnt+1;;
		}
	}
	if(!equal(nd,tmp)){
		if(!vis[tmp.aa.x][tmp.aa.y])q.push(tmp);
		vis[tmp.aa.x][tmp.aa.y]=1;
	} 
	return ;
}
void pusht(const node nd){
	tmp.aa=nd.aa;
	ll tag=0;
	if(nd.aa.x>1){
		if(mp[nd.aa.x-1][nd.aa.y]!='*'){
			tmp.aa.x--;
			tmp.cnt=nd.cnt+1;;
			tag=1;
		}
	}
	tmp.bb=nd.bb;
	if(nd.bb.x>1){
		if(mp[nd.bb.x-1][nd.bb.y]!='*'){
			tmp.bb.x--;
			if(!tag)tmp.cnt=nd.cnt+1;;
		}
	}
	if(!equal(nd,tmp)){
		if(!vis[tmp.aa.x][tmp.aa.y])q.push(tmp);
		vis[tmp.aa.x][tmp.aa.y]=1;
	}
	return ;
}
void pushb(const node nd){
	tmp.aa=nd.aa;
	ll tag=0;
	if(nd.aa.x<n){
		if(mp[nd.aa.x+1][nd.aa.y]!='*'){
			tmp.aa.x++;
			tmp.cnt=nd.cnt+1;;
			tag=1;
		}
	}
	tmp.bb=nd.bb;
	if(nd.bb.x<n){
		if(mp[nd.bb.x+1][nd.bb.y]!='*'){
			tmp.bb.x++;
			if(!tag)tmp.cnt=nd.cnt+1;;
		}
	}
	if(!equal(nd,tmp)){
		if(!vis[tmp.aa.x][tmp.aa.y])q.push(tmp);
		vis[tmp.aa.x][tmp.aa.y]=1;
	}
	return ;
}
int main()
{
	sync_flow;
	cin>>n;
	zf(i,1,n){
		zf(j,1,n){
			cin>>mp[i][j];
			if(mp[i][j]=='a'){
				a.x=i,a.y=j;
			}else if(mp[i][j]=='b'){
				b.x=i,b.y=j;
			}
		}
	}
	tmp.aa=a,tmp.bb=b,tmp.cnt=0;
	q.push(tmp);
	vis[tmp.aa.x][tmp.aa.y]=1;
	while(!q.empty()){
		node st=q.front();
		if(judge(st.aa,st.bb)){
			ans=st.cnt;
			break;
		}
		q.pop(); 
		pushr(st);
		pushl(st);
		pusht(st);
		pushb(st);
	}
	if(q.empty())no;
	else cout<<ans;
	return 0;
}
//E
