#include  <bits/stdc++.h>
using namespace std;

int work()
{
    int i, j, t;
	char c;
	int n = 0;
	int sum = 0;

	while (~scanf("%c", &c))
	{
		if (c == 'h') n = 1;
		else if (c == 'z')
		{
			if (n == 1) n = 2;
			else n = 0;
		}
		else if (c == 'n')
		{
			if (n == 2) n = 3;
			else n = 0;
		}
		else if (c == 'u')
		{
			if (n == 3) n = 0, sum++;
			else n = 0;
		}
		else if (c == '\n') break;
	}
	printf ("%d", sum);

    return 0;
}

int main()
{
    int T = 1;
    //scanf("%d", &T);
    while (T--) work();
    //getchar();getchar();getchar();
    return 0;
}
