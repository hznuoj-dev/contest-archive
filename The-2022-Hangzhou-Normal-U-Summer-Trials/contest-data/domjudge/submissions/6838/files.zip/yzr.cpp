#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
typedef long long ll;
string s;
int main()
{
	getline(cin,s);
	int count=0;
	for(int i=0;i<s.size();i++){
	if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')
		count++;
	}
	cout<<count;
	return 0;
}