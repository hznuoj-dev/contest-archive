#include<bits/stdc++.h>
using namespace std;
#define N 100005
#define int long long

void solve(){
	string s,fi = "hznu";
	cin >> s;
	int t = 0;
	for(int i = 0;i + 4 <= s.length();i++) if(s.substr(i,4) == fi) t++;
	cout << t;
}

signed main(){
	int t = 1;
	while(t--) solve();
}
