﻿//#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
map<int, int>mp;
int main()
{
    int n, k;
    cin >> n>>k;
    int a[1000005];
    
    int sum = 0;
    for (int i = 1; i <= n; i++)
    {
        scanf("%d", &a[i]);
        map<int, int>b;
        for (auto t : mp)
        {

            b[(t.first + a[i])%k]=t.second ; 
            if ((t.first + a[i])%k==0)sum+=t.second;

            //cout << t.first<<""<<t.second<<endl;
        }
        mp = b;
        mp[a[i] % k] += 1;
        if (a[i] % k == 0)sum+=1;


    }

    cout << sum;


}
