#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef long long ll;
const int N=2e+7;
map<char,char>mp;
void solve(){
	int q;
	cin >> q;
	string s;
	while (q--){
		int x;
		cin >> x;
		if (x==1){
			char ch;
			cin >> ch;
			s+=ch;
		}
		else if (x==2){
			if (!s.empty()){
				s.pop_back();
			}
		}
		else{
			char ch1,ch2;
			cin >> ch1 >> ch2;
			int k=s.size();
			for (int i=0;i<k;i++){
				if (s[i]==ch1){
					s[i]=ch2;
				}
			}
		}
	}
	if (s.empty()){
		cout << "The final string is empty\n";
	}
	else{
		cout << s << '\n';
	}
	

}

signed main(){
	ios::sync_with_stdio(0);
	int t=1;
//	cin >> t;	
	while (t--){
		solve();
	}
	return 0;
}

