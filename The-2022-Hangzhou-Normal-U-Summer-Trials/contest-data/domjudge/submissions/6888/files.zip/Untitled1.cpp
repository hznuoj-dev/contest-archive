#include<bits/stdc++.h>
using namespace std;
int main()
{
	int sum=0;
	string a;
	cin>>a;
	//cout<<a.size();
	for(int i=0;i<a.size()-3;)
	{
		if(a[i]=='h'&&a[i+1]=='z'&&a[i+2]=='n'&&a[i+3]=='u')
		{
			sum++;
			i+=4;
		}
		else
		i++;
	 } 
	cout<<sum;
} 
