#include <stdio.h>
#include <stdlib.h>

typedef struct {
	long long id;
	long long val;
} My;

int main()
{
	int n, p = 0;
	long long k, *a;
	My count[100007];
	long long cnt = 0, sum = 0;
	
	scanf("%d %lld", &n, &k);
	a = (long long *) malloc (n * sizeof(long long));
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &a[i]);
	}
	for (int i = 0; i < n; i++)
	{
		sum += a[i];
		if (sum % k == 0)
		{
			cnt++;
		}
		int j = 0;
		for (; j < p; j++)
		{
			if (count[j].id == sum % k)
			{
				cnt += count[j].val;
				count[j].val++;
				break;
			}
		}
		if (j == p)
		{
			count[p].id = sum % k;
			count[p].val = 1;
			p++;
		}
	}
	printf("%lld", cnt);
	
	return 0;
}
/*6 3
0 1 2 4 7 7*/
