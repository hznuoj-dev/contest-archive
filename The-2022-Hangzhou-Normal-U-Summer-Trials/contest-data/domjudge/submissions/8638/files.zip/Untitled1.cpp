#include<stdio.h>
int a[500086];
int t[500086];
long long n,q,ans;
int main(){
	scanf("%lld",&n);
	for(int i=0;i<n;++i){
		scanf("%d",&a[i]);
	}
	scanf("%lld",&q);
	for(int i=0;i<q;++i){
		scanf("%d",&t[i]);
	}
	if(q==0) printf("0\n");
	for(int i=0;i<q;++i){
		ans=t[i];
		for(int j=0;j<n-1;++j){
			if(t[i]<=a[j+1]-a[j]) ans+=t[i];
			else  ans+=a[j+1]-a[j];
		}
		printf("%lld\n",ans);
	}
}
 
