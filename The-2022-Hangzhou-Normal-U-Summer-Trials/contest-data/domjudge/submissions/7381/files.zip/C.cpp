#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> PII;
const int INF = 0x3f3f3f3f, MAXN = 1e6 + 10;

void solve() {
    int n;
    cin >> n;
    vector<ll> a(n);
    for(int i = 0; i < n; i ++) {
        cin >> a[i];
    }
    vector<int> b;
    for(int i = 1; i < n; i ++) {
        b.push_back(a[i] - a[i - 1]);
    }
    sort(b.begin(), b.end());
    vector<int> temp = b;
    temp.resize(unique(temp.begin(), temp.end()) - temp.begin());
    vector<int> c(temp.size());
    int id = 0, j = 0;
    for(int i = 1; i < n; i ++) {
        if(b[i] != b[i - 1]) {
            c[j ++] = i - id;
            id = i;
        }
    }
    c[j ++] = n - id;
    map<ll, ll> mp;
    ll res = 0, kk = n;
    for(int i = 0; i < temp.size(); i ++) {
        if(i)
            res += (temp[i] - temp[i - 1] + 1) * kk;
        else 
            res += temp[i] * kk;
        mp[temp[i]] = res;
        kk -= c[i];
    }
    for(int i = 1; i < c.size(); i ++) {
        c[i] += c[i - 1];
    }
    vector<int> ww = temp;
    for(int i = 1; i < ww.size(); i ++) {
        ww[i] += ww[i - 1];
    }
    int q;
    cin >> q;
    while(q --) {
        ll t;
        cin >> t;
        if(t <= ww[0]) {
            cout << t * n << '\n';
            continue;
        }
        int x = upper_bound(temp.begin(), temp.end(), t) - 1 - temp.begin();
        ll res = mp[temp[x]] + (t - ww[x]) * (n - c[x]);
        cout << res << '\n';
    }
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int _ = 1;
    //cin >> _;
    while(_ --) {
        solve();
    }
    return 0;
}