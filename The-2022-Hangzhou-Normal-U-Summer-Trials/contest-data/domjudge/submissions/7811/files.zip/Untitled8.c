#include<stdio.h>
#include<string.h>

int main(){
	char s[26];
	char z[1001];
	int n,k,num;
	int i,j,m;
	scanf("%s",s);
	scanf("%d",&n);
	char a[n][1005];
	for(i=0;i<n;i++){
		scanf("%s",a[i]);
	}
	scanf("%d",&k);
	int b[26];
	for(i=0;i<strlen(s);i++){
		num=s[i]-'a';
		b[num]=i;
	}
	int max=strlen(a[0]);
	for(i=0;i<n-1;i++){
		if(strlen(a[i])<strlen(a[i+1])){
			max=strlen(a[i+1]);
		}
	}
	for(j=0;j<n;j++){
		if(b[a[j][0]-'a']>b[a[j+1][0]-'a']){
			strcpy(z,a[j]);
			strcpy(a[j],a[j+1]);
			strcpy(a[j+1],z);
		}
	}
	for(i=1;i<max;i++){
		for(j=0;j<n;j++){
			for(m=0;m<n-j-1;m++){
			    if(a[m][i-1]==a[m+1][i-1]){
			        if(b[a[m][i]-'a']>b[a[m+1][i]-'a']){
				        strcpy(z,a[m]);
				        strcpy(a[m],a[m+1]);
				        strcpy(a[m+1],z);
			        }
		        }
	        }
		}
	}
	printf("%s",a[k-1]);
	return 0;
}


