#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
using namespace std;

int main()
{
	Daybreak7;
	int n;
	cin>>n;
	long long a[n+10];
	for(int i=0;i<n;i++)
		cin>>a[i];
	int q;
	cin>>q;
	while(q--)
	{
		long long t;
		cin>>t;
		long long ans=0,last=0;
		for(int i=0;i<n-1;i++)
		{
			ans+=a[i]+t-1-last;
			last=max(a[i+1]-1,a[i]+t-1);
		}	
		ans+=a[n-1]+t-1-last; 
		cout<<ans<<endl;
	}
}
