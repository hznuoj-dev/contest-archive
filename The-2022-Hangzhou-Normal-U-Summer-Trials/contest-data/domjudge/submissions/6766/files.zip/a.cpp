#include<bits/stdc++.h>
#define int long long
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
const int N = 2e5 + 10;
int a[N];
typedef pair<int,int> PII;
typedef long long ll;
const int mod = 998244353;
int n, m;
int gcd(int a,int b) {return b? gcd(b,a%b):a;}
void solve()
{
    string s;
    cin >> s;
    int res = 0;
    for(int i = 0; i + 4 - 1 < s.size(); i ++ )
    {
        string s1 = s.substr(i, 4);
        if (s1 == "hznu") res ++;
    }
    cout << res << endl;
}
signed main()
{

    solve();
}