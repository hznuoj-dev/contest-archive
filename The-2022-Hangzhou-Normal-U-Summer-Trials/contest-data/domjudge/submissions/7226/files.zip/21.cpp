#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

int main()
{
	string str;
	cin >> str;
	int a[200] = {0};
	for(int i = 0; i < 26; i++)
	{
		a[str[i]] = i;
	}
	int n;
	cin >> n;
	string s[n];
	for(int i = 0 ; i < n; i++)
	{
		cin >> s[i];
	}
	int k;
	cin >> k;
	for(int i = 0; i < n - 1; i++)
	{
		int min = i;
		for(int j = i + 1; j < n; j++)
		{
			if(s[j].length() < s[min].length())
			{
				min = j;
			}
			else if(s[j].length() == s[min].length())
			{
				for(int m = 0; m < s[min].length(); m++)
				{
					if(a[s[j][m]] < a[s[min][m]])
					{
						min = j;
						break;
					}
					else if (a[s[j][m]] > a[s[min][m]])
					{
						break;
					}
				}
			}
		}
		if(min != i)
		{
			swap(s[min], s[i]);
		}
	}
	cout << s[k - 1];
}
