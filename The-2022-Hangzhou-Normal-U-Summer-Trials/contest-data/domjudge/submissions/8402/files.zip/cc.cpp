#include<bits/stdc++.h>

using namespace std;
typedef long long ll;
ll a[500010],b[500010];
void solve(){
	ll n,q;
	cin >> n;
	for(ll i=1;i<=n;i++) cin >> a[i];
	for(ll i=1;i<n;i++) b[i]=a[i+1]-a[i];
	cin >> q;
	for(ll i=1;i<=q;i++){
		ll t;cin >>t;
			ll l=1,r=n-1;
			ll mid=0;
			while(l<=r){
				mid=(l+r)/2;
				if(b[mid]>t){
					r=mid-1;
				}else if(b[mid]<t){
					l=mid+1;
				}else break ;
			}
			if(b[mid]==t){
				cout << a[mid+1]+t-1+(n-mid-1)*t -a[1]+1<< '\n'; 
			}else if(b[mid]>t)cout <<a[mid]+t-1+(n-mid)*t -a[1]+1<< '\n'; 
			else{
				cout << a[n]+t-1-a[1]+1 <<'\n';
			}	
	}
}
/*

*/
int main(){
	int t=1;
	//cin >> t;
	while(t--){
		solve();
	}
return 0;
}
