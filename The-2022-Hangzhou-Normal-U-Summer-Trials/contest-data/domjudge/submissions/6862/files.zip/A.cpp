#include<bits/stdc++.h>

using namespace std;
int ans;
string s;
void solve() {
	s="";
	cin >> s;
	ans  = 0;
	int l=s.length()-1;
	for(int i=0;i<=l-3;i++) {
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u') {
			ans++; i=i+3;
		}
	}
	cout << ans << endl;
}

int main(){
	int T=1;
	//cin >> T;
	while(T--)
		solve();
}
