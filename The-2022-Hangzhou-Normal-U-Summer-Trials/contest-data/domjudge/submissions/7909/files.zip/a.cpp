#include<bits/stdc++.h>
using namespace std;
#define ll long long

char f[200];
map<ll,ll>mp;
struct p{
	string a;
	string w;
	int id;
}h[100008];
bool cmp(p a,p b){
	return a.a<b.a;
}
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	string s;
	cin>>s;
	int n;
	cin>>n;
	for(int i=0;i<s.length();i++)
	{
		f[s[i]]=char(i+97);
	}
	for(int i=1;i<=n;i++){
		cin>>h[i].a;
		h[i].w=h[i].a;
		for(int j=0;j<h[i].a.length();j++){
			h[i].a[j]=f[h[i].a[j]]; 
		} 
		
	}
	int k;
	cin>>k;
	sort(h+1,h+1+n,cmp);
	cout<<h[k].w;
} 
