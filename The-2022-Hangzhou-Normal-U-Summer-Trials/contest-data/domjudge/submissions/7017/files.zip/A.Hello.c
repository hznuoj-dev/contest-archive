#include<stdio.h>
#include<string.h>
char a[100010];

int main()
{
	gets(a);
	int i, l = strlen(a), s = 0;
	for (i = 0; i < l - 3; i ++)
	{
		if (a[i] == 'h' && a[i + 1] == 'z' && a[i + 2] == 'n' && a[i + 3] == 'u')
			s ++;
	}
	printf("%d", s);
	return 0;
}
