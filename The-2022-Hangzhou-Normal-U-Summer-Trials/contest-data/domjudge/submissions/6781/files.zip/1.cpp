#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	string s;
	int cnt=0;
	cin>>s;
	for(int i=0;s[i+3];i++){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')cnt++;
	}
	cout<<cnt<<'\n';
	return 0;
}
