#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=5e3+10;
const int SIZE=1000000+100;
const int mod=1e9+7;
int n,m,k;
map<int,int>mp;
string as[1011];
bool cmp(string a,string b){
    for(int i=0;i<a.size();i++){
        int aa=mp[a[i]];
        int bb=mp[b[i]];
        if(aa==bb) continue;
        else return aa<bb;
    }
    return (1==1);
}
void solve(){
    string s;
    cin>>s;
    for(int i=0;i<s.size();i++){
        mp[s[i]]=i;
    }
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>as[i];
    }
    cin>>k;
    sort(as,as+n,cmp);
    cout<<as[k-1]<<endl;
}
void inits(){}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int ts=1;
    inits();
    while(ts--){
        solve();
    }
    return 0;
}