#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s;
	int i, count = 0;
	cin >> s;
	for (i = 3; i < s.length(); i++)
	{
		if (s[i] == 'u' && s[i - 1] == 'n' && s[i - 2] == 'z' && s[i - 3] == 'h')
		{
			count++;
			s[i] = '0';
			s[i - 1] = '0';
			s[i - 2] = '0';
			s[i - 3] = '0';
		}
	}
	cout << count;
	return 0;
}