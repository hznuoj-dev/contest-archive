#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 5e5+10;

ll a[N],d[N];
void solve(){
	int n; cin >> n;
	for(int i=1;i<=n;i++) cin >> a[i];
	for(int i=2;i<=n;i++) d[i]=a[i]-a[i-1];
	int q; cin >> q;
	while(q--){
		ll t; cin >> t;
		int c=lower_bound(d+2,d+n+1,t) - d;
		if(c==n+1){
			cout << a[n]-a[1]+t;
			continue;
		}
		ll ans;
		if(d[c]==t){
			ans = a[c]-a[1] + 1ll*(n-c+1)*t;
		}else {
			ans = a[c-1]-a[1] + 1ll*(n-c+2)*t;
		}
		cout << ans << endl;
	}
	
}
/*


*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
