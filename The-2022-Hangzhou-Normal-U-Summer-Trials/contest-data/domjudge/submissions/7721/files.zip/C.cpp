#include<bits/stdc++.h>
using namespace std;

#define ll long long

const int N=5e5+5;
const int mod=1e9+7;

ll a[N],pre[N];
map<ll,ll>mp;

void solve(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n-1;i++){
		pre[i]=a[i+1]-a[i];
	}
	int q;
	cin>>q;
	while(q--){
		ll t;
		cin>>t;
		int l=0,r=n;
		int tt=upper_bound(pre,pre+n-1,t)-pre;
		ll ans=a[tt]-a[0]+t*(n-tt);
		cout<<ans<<"\n";
	}
}

int main(){
	ios::sync_with_stdio(false);
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}

