#include <bits/stdc++.h>
using namespace std;
#define int long long
int a[100100];
int s[100100];
int is[100100];
int ma[101000];
int n,k;
struct p{
	char c[1100];
	char nw[1100];
	int len;
}st[1100];
bool cmp(p a,p b){
	int lx=min(a.len,b.len);
	for(int i=1;i<=lx;i++){
		if(a.nw[i]<b.nw[i])return 1;
	    if(a.nw[i]>b.nw[i])return 0;
	}
	return 0;
}
signed main() 
{
for(int i=1;i<=26;i++){
	char ch;cin>>ch;
	is['a']=ch;
	ma[ch]=i;
}
cin>>n;
for(int i=1;i<=n;i++){
	cin>>(st[i].c+1);
	st[i].len=strlen(st[i].c+1);
	for(int j=1;j<=st[i].len;j++)
	st[i].nw[j]=ma[st[i].c[j]];
}
sort(st+1,st+1+n,cmp);
cin>>k;
for(int i=1;i<=st[k].len;i++)printf("%c",st[k].c[i]);
}
