#include <bits/stdc++.h>
#define endl '\n'

using namespace std;

typedef long long LL;
const int N = 5e5 + 10;

LL a[N], c[N];

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int i = 1; i < n; i++)
        c[i] = a[i + 1] - a[i];

    int q;
    cin >> q;

    while (q--)
    {
        LL t;
        cin >> t;
        LL pos = upper_bound(c + 1, c + n, t) - c;
        // cout << pos << endl;
        LL ans = a[pos] + t - 1 + (n - pos) * t;
        cout << ans << endl;
    }

    return 0;
}