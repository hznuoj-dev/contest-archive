﻿
#include<iostream>
#include<algorithm>
#include<map>
using namespace std;
map<long long, long long >mp;
int main()
{
    int n;
    long long k;
    scanf("%d%lld", &n, &k);
    long long a[100005];
    
    long long ans = 0;
    long long sum = 0;
    for (int i = 1; i <= n; i++)
    {
        scanf("%lld", &a[i]);
        
    }
    
    for(int i=1;i<=n;i++){

        map<long long, long long>b;
        for (auto t : mp)
        {

            b[(t.first + a[i])%k]=t.second ; 
            if ((t.first + a[i])%k==0)ans+=t.second;

            //cout << t.first<<""<<t.second<<endl;
        }
        mp = b;
        mp[a[i] % k] += 1;
        if (a[i] % k == 0)ans+=1;


    }

    cout << ans;


}
