#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
string s;
ll n;
typedef struct{
	int id;
	char s1;
}h;
typedef struct{
	int id;
	char s1;
	char s2;
}h1;
h a[100010];
h1 c[100010];
h b[100010];
int cnt1,cnt2,cnt3;
ll x;
char s1,s2;
ll d[100];
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>x;
		if(x==1){
			cin>>s1;
			a[++cnt1].id=i;
			a[cnt1].s1=s1;
		}
		if(x==2){
			b[++cnt2].id=i;
		}
		if(x==3){
			cin>>s1>>s2;
			c[++cnt3].id=i;
			c[cnt3].s1=s1;
			c[cnt3].s2=s2;
		}
	}
//		cout<<cnt1<<" "<<cnt2<<endl;
		for(int i=1;i<=30;i++){
			d[i]=i;
		}
		while(cnt1>0){
//			cout<<cnt1<<endl;
			if(cnt2!=0){
				while(b[cnt2].id>a[cnt1].id){
					cnt2--;
					cnt1--;
				}
				}
			if(cnt3!=0){
			if(a[cnt1].id<c[cnt3].id){
					ll ans1=c[cnt3].s1-'a'+1;
					ll ans2=c[cnt3].s2-'a'+1;
					d[ans1]=d[ans2];
					cnt3--;
			}
			else if(a[cnt1].id>c[cnt3].id){
				char k=d[a[cnt1].s1-'a'+1]+'a'-1;
				s=k+s;
				cnt1--;
			}
			}
			else{
				char k=d[a[cnt1].s1-'a'+1]+'a'-1;
				s=k+s;
				cnt1--;
			}
		}
			s!=""?cout<<s<<"\n":cout<<"The final string is empty"<<"\n";
} 
/*
6
1 a
1 c
3 a c
2
2
1 a
*/
