#include <bits/stdc++.h>
using namespace std;
#define  ll long long
const int N = 2e5 + 50;
ll b[N], vis[N], sum[N], cal[N],num[N],ans[N];
ll a[N];
vector<ll>v[N];
vector<ll>w[N];
int cnt;
	int n, q;
void dfs(int u,int fa)
{
	num[u]=1;
	if(cal[u]==1) {
		ans[u]=n-1;
		return;
	}
	for(int i=0; i<cal[u];i++)
	{
		int j= v[u][i];
		if(j==fa) continue;
		dfs(j,u);
		num[u]+=num[j];
	}
	int x=n-num[u];
	for(int i = 0; i<cal[u];i++)
	{
		if(fa==v[u][i]) continue;
		ans[u]+=x*num[v[u][i]];
	}
	for(int i = 0; i<cal[u];i++)
		for(int j = i+1; j<cal[u];j++)
	{
		if(fa==v[u][i]|| fa==v[u][j]) continue;
		ans[u]+=num[v[u][j]]*num[v[u][i]];
	}
	ans[u]+=n-1;
}
int main() {


	scanf("%d", &n);
	for (int i = 1; i <= n - 1; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		v[x].push_back(y);
		v[y].push_back(x);
	}
	for(int i = 1; i<=n; i++)
	{
		cal[i]=v[i].size();
	}
	dfs(1,-1);
	scanf("%d", &q);

	for (int i = 1; i <= q; i++) {
		int x;
		scanf("%d", &x);
		printf("%lld\n",ans[x]);
	}
}
