#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll fac[200010],inv[200010];
ll p=1e9+7;
ll po(ll x,ll y){
	ll b=1;
	while(y){
		if(y&1) b=b*x%p;
		x=x*x%p;
		y/=2;
	}
	return b;
}
void init(){
	ll i;
	fac[0]=1;
	for(i=1;i<=200000;i++) fac[i]=fac[i-1]*i%p;
	inv[200000]=po(fac[200000],p-2);
	for(i=200000;i;i--) inv[i-1]=inv[i]*i%p;
}
ll C(ll n,ll m){
	return fac[n]*inv[m]%p*inv[n-m]%p;
}
ll a[200010],c[200010];
void solve(){
	ll n,s,q,i,j,m,x,y,k,l,r,t,ans=0,mid,sum=0;
	init();
	cin>>n>>s>>q;
	for(i=0;i<=200000;i++) c[i]=C(i+n-1,n-1);
	for(i=1;i<=200000;i++) c[i]=(c[i]+c[i-1])%p;
	for(i=1;i<=n;i++) scanf("%lld",a+i),sum+=a[i];
	while(q--){
		scanf("%lld%lld",&x,&y);
		sum=sum-a[x]+y;
		a[x]=y;
		if(sum>s) printf("0\n");
		else printf("%lld\n",c[s-sum]);
	}
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
//B=clock();
	//printf("%f\n",(double)(B-A)/CLOCKS_PER_SEC);
