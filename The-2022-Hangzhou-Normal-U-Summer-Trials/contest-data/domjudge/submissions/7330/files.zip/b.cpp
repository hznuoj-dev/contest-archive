#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10;
char s[30],str[1010][1010],strr[1010][1010],str1[1010][1010];
map<char,char>mp;
bool cmp(char a[],char b[]){
	int l1=strlen(a),l2=strlen(b);
	if(l1<=l2){
		for(int i=0;i<l1;i++){
			if(a[i]!=b[i])return a[i]>b[i];
		}
	}else{
		for(int i=0;i<l2;i++){
			if(a[i]!=b[i])return a[i]>b[i];
		}
	}
	return 0;
}
void solve(){
	int n,k;
	scanf("%s",&s);
	for(int i=0;i<26;i++)mp[s[i]]='a'+i;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%s",&str[i]);
		int l=strlen(str[i]);
		for(int j=0;j<l;j++){
			str1[i][j]=strr[i][j]=mp[str[i][j]];
		}
	}
	for(int i=0;i<n;i++){
		for(int j=i+1;j<n;j++){
			if(cmp(str1[i],str1[j])){
				swap(str1[i],str1[j]);
			}
		}
	}scanf("%d",&k);k=k-1;
	for(int i=0;i<n;i++){
		int tr=1;
		for(int j=0;j<1010;j++){
			if(str1[k][j]!=strr[i][j])tr=0;
		}
		if(tr){
			printf("%s\n",str[i]);
			return;
		}
	}
}
int main(void){
	int t=1;
	//scanf("%d",&t);
	while(t--)solve();
	return 0;
}
