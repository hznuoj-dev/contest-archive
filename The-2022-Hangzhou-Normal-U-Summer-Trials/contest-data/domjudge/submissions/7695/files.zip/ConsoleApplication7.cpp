﻿//#define _CRT_SECURE_NO_WARNINGS
#include<iostream>
#include<algorithm>
#include<cstring>
#define N 100005
using namespace std;
int n;
int b[N];
int a[N];
int sum[N];
int loo(int x)
{
	int l = 1;
	int r = n - 1;
	while (l < r) {
		int mid = l + r + 1 >> 1;

		if (b[mid] < x)l = mid;
		else r = mid - 1;
	}
	if (b[1] > x)return 0;
	return l;




}
int main()
{

	

	memset(sum, 0, sizeof sum);


	
	cin >> n;
	for (int i = 1; i <= n; i++)
		scanf("%d", &a[i]);

	sort(a+1, a + 1 + n);

	memset(b, 0, sizeof b);

	


	
	for (int i = 1; i < n; i++)
	{

		b[i] = a[i + 1] - a[i];//b表示a直接的差,此时a是有序的
		sum[i] = sum[i - 1] + b[i];

	}
	sort(b + 1, b + n);

	int q;
	cin >> q;
	int query;

	/*
	for (int i = 1; i < n; i++)
		cout << b[i] << " " << "&";
	cout << endl;
	*/
	for (int i = 1; i <= q; i++)
	{

		scanf("%d", &query);

		int t=0;
		t= loo(query);


		int ans = 0;

		ans += sum[t];//加上temp及其之前的所有差的大小
		//cout << t << endl;
		ans += (n  - t) * query;//加速temp之后所以大于temp的空袭


		
	
		cout << ans<<endl;




	}
	


}