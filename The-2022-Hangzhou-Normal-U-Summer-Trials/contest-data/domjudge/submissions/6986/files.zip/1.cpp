#include <stdio.h>
#include <string.h>
char a[100000];
int main()
{
    scanf("%s", a);
    long int l = strlen(a);
    long int i;
    long int num = 0, k = 0;
    for (i = 0; i < l; i++)
    {
        if (k == 0 && a[i] == 'h')
            k++;
        else if (k == 1 && a[i] == 'z')
            k++;
        else if (k == 2 && a[i] == 'n')
            k++;
        else if (k == 3 && a[i] == 'u')
        {
            k = 0;
            num++;
        }
        else
            k = 0;
    }
    printf("%d", num);
    return 0;
}