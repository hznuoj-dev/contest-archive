#include<iostream>
#include<cstdio>
#include<cstring>
using namespace std;
int main(){
	char s[100008];
	int t;
	cin>>t;
	int cz;char x,y;
	for(int i=0;i<t;i++){
		cin>>cz;
		switch(cz){
			case 1:scanf(" %c",&x); s[strlen(s)]=x;break;
			case 2:s[strlen(s)-1]='\0';break;
			case 3:scanf(" %c %c",&x,&y);
			for(int j=0;j<strlen(s);j++){
				if(s[j]==x){
					s[j]=y;
				}
			}
			break;
		}
	}
	if(strlen(s)==0){
		cout<<"The final string is empty";
	}
	for(int i=0;i<strlen(s);i++){
		cout<<s[i];
	}	
}
