#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define moonoom ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
const ll MAXN=5e5+10;
ll delta[MAXN];
ll arr[MAXN];
int main(){
	moonoom;
	long int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>arr[i];
		delta[i]=arr[i]-arr[i-1];
	}
	delta[1]=0;
	long int q;
	cin>>q;
	ll t;
	while(q--){
		cin>>t;
		long int pos=0;
		if(t==0){
			cout<<0<<endl;continue;
		}
		if(delta[n]==t){
			cout<<arr[n]+t-1<<endl;continue;
		}
		if(t>delta[n]){
			cout<<arr[n]+t-1<<endl;continue;
		}
		for(int i=1;i<n;i++){
			if(delta[i]<=t&&delta[i+1]>t){
				pos=i;break;
			}
		}
		//cout<<"pos="<<pos<<endl;
		ll ans=0;
		ans=arr[pos]+t+t-1;
		cout<<ans<<endl;
	}
	
}
