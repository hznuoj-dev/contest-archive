#include <bits/stdc++.h>

using namespace std;

string st;
struct node
{
    string s;
    bool operator<(const node &p) const
    {
        for (int i = 0; i < min((int)s.size(), (int)p.s.size()); i++)
        {
            if (st.find(s[i]) < st.find(p.s[i]))
                return true;
        }
        if ((int)s.size() < (int)p.s.size())
            return true;
        return false;
    }
} s[1005];

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    cin >> st;
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> s[i].s;
    }
    // cout << st.find('c') << endl;
    sort(s + 1, s + 1 + n);
    int k;
    cin >> k;
    // for (int i = 1; i <= n; i++)
    //     cout << s[i].s << endl;
    cout << s[k].s;

    return 0;
}