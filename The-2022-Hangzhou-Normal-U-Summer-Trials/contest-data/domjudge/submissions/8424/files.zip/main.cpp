#include <bits/stdc++.h>
using namespace std;

int main(){
    int q,com;
    string v1;
    scanf("%d ",&q);
    while(q--){
        char a,b;
        scanf("%d",&com);
        if(com==1){
            scanf(" %c",&a);
            v1.push_back(a);
        }else if(com==2){
            if(!v1.empty()){
                v1.pop_back();
            }else{
                continue;
            }
        }else if(com==3){
            if(v1.empty())continue;
            scanf(" %c %c",&a,&b);
            replace(v1.begin(),v1.end(),a,b);
        }
    }
    if(!v1.empty()){
       cout<<v1;
    }else{
        printf("The final string is empty");
    }
    return 0;
}