#include<bits/stdc++.h>
using namespace std;

const int N=1e5+7,M=1e9+7;
long long n;
vector<long long> ch[N];
map<pair<long long,long long>,long long> cnt;

void dfs(long long last,long long now){
	cnt[{last,now}]++;
	for(long long i=0;i<ch[now].size();i++){
		long long next=ch[now][i];
		if(next==last) continue;
		dfs(now,next);
		cnt[{last,now}]+=cnt[{now,next}];
	}
}

void solve(){
	//cin>>n;
	scanf("%lld",&n);
	for(long long i=1;i<n;i++){
		long long u,v;
		//cin>>u>>v;
		scanf("%lld%lld",&u,&v);
		ch[u].push_back(v);
		ch[v].push_back(u);
	}
	dfs(-1,1);
	long long q;
	//cin>>q;
	scanf("%lld",&q);
	for(long long i=0;i<q;i++){
		long long x;
		//cin>>x;
		scanf("%lld",&x);
		long long ans=0;
		/*for(int j=0;j<ch[x].size();j++){
			int y=ch[x][j];
			if(cnt[{x,y}]==0) cnt[{x,y}]=n-cnt[{y,x}];
			ans+=cnt[{x,y}];
			for(int k=j+1;k<ch[x].size();k++){
				int z=ch[x][k];
				if(cnt[{x,z}]==0) cnt[{x,z}]=n-cnt[{z,x}];
				ans+=cnt[{x,y}]*cnt[{x,z}];
			}
		}*/
		vector<long long> num;
		for(long long j=0;j<ch[x].size();j++){
			long long y=ch[x][j];
			if(cnt[{x,y}]==0) cnt[{x,y}]=n-cnt[{y,x}];
			ans+=cnt[{x,y}];
			num.push_back(cnt[{x,y}]);
		}
		for(long long j=1;j<num.size();j++){
			num[j]+=num[j-1];
		}
		for(long long j=num.size()-1;j>0;j--){
			long long y=ch[x][j];
			ans+=cnt[{x,y}]*num[j-1];
		}
		//cout<<ans<<'\n';
		printf("%lld\n",ans);
	}
}

int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int T=1;
	//cin>>T;
	while(T--) solve();
	return 0;
}
