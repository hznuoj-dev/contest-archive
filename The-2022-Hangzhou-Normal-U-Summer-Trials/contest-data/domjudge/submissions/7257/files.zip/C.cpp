#include<iostream>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>
#include<set>

#define ll long long
#define lowbit(x) ((x)&(-(x)))
#define pb push_back
#define vi vector<int>
#define pii pair<int, int>
#define allv(x) (x).begin(), (x).end() 
#define bit32(x) (__builtin_popcount((unsigned int)(x)))
#define bit64(x) (bit32(x>>32)+bit32(x))
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

using namespace std;
const int N = 1e5 + 10;
ll a[N];
int main(){
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++)scanf("%lld",&a[i]);
    int t;
    scanf("%d",&t);
    while(t--)
    {
        ll x;
        scanf("%lld",&x);
        ll res=0;
        for(int i=0;i<n-1;i++)
        {
            if(a[i]+x>a[i+1])res+=a[i+1]-a[i];
            else res+=x;
        }
        res+=+x;
        printf("%lld\n",res);
    }
    return 0;
}