#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	int ans=0;
	int sum=0;
	for(int i=0;i<s.size();i++){
		if(s[i]=='h'&&ans==0){
			ans++;
		}
		else if(s[i]=='z'&&ans==1){
			ans++;
		}
		else if(s[i]=='n'&&ans==2){
			ans++;
		}
		else if(s[i]=='u'&&ans==3){
			sum+=1;
			ans=0;
		}
		else{
			ans=0;
		}
	}
	cout<<sum<<endl;
} 
