#define _CRT_SECURE_NO_WARNINGS
#include<bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using db = double;
using vi = vector<int>;
using mii = map<int, int>;
using PII = pair<int, int>;
using PLL = pair<ll, ll>;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const ll mod = 1e9 + 7;
const int MAXN = 5e5 + 10;
const int N = 2e5 + 10;
#define mem(a,b) memset(a,b,sizeof(a));


struct Node {
	ll sum = 0;
	ll ans = 0;
	vector<int> v;
};
int h[N], e[N], ne[N], idx;

void add(int a, int b) {
	e[idx] = b, ne[idx] = h[a], h[a] = idx++;
}

int in[N];
Node ans[N];
bool st[N];

int main() {
	ll n;
	cin >> n;
	mem(h, -1);
	for (int i = 0; i < n - 1; i++) {
		int v, w;
		scanf("%d%d", & v, &w);
		add(v, w);
		add(w, v);
		in[w]++, in[v]++;
	}
	queue<int> q;

	for (int i = 1; i <= n; i++) {
		if (in[i] == 1) {
			q.push(i);
			st[i] = true;
		}
	}

	while (!q.empty()) {
		int x = q.front();
		q.pop();
		ll d = ans[x].sum + 1;
		for (int i = h[x]; i != -1; i = ne[i]) {
			int j = e[i];
			if (!st[j]) {
				
				ans[j].ans += ans[j].sum * d + d;
				ans[j].sum += d;

				in[j]--;
				if (in[j] == 1) {
					q.push(j);
					st[j] = true;
				}
			}
		}

	}
	int Q;
	cin >> Q;
	while (Q--) {
		int t;
		scanf("%d", &t);
		printf("%lld\n", ans[t].ans + (ans[t].sum + 1) * (n - ans[t].sum - 1));
	}

	return 0;
}