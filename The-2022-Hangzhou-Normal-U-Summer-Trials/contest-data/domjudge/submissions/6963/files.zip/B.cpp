#include <bits/stdc++.h>

using namespace std;
const int N = 1e3 + 10;

char k[N], r[30];

void solve(){
	scanf("%s", r);
	vector<int> id(26);
	for(int i = 0; i < 26; i++){
		id[r[i] - 'a'] = i;
	}
	int n;
	scanf("%d", &n);
	vector<vector<int>> a(n);
	for(int i = 0; i < n; i++){
		scanf("%s", k);
		int m = strlen(k);
		for(int j = 0; j < m; j++){
			a[i].push_back(id[k[j] - 'a']);
		}
	}
	int p;
	scanf("%d", &p);
	sort(a.begin(), a.end());
	string ans;
	for(int i : a[p - 1]){
		ans += r[i];
	}
	cout << ans << '\n';
}

int main(){
	int T = 1;
	while(T--) solve();
	return 0;
}
