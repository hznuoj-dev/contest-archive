﻿// ConsoleApplication1.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//
/*
#include<tchar.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>         
#include<time.h>  
#include<iostream>
#include<fstream>

using namespace std;

ifstream infile;
char buf[100];
int fish_x, fish_y;
bool turn;
int size;
int x, y, vx, vy;

int p_f(int len) {
	int num = 0;
	for (int i = 0; i < len; i++) {
		if (buf[i] == ' ') {
			num++;
		}
	}
	if (num == 2) {//记录的是玩家的数据
		fish_x = 0; fish_y = 0;
		int i;
		for (i = 0; i < len; i++) {
			if (buf[i] == ' ')break;
			fish_x = fish_x * 10 + int(buf[i]-'0');
		}
		i++;
		for (; i < len; i++) {
			if (buf[i] == ' ')break;
			fish_y = fish_y * 10 + int(buf[i]-'0');
		}
		if (buf[len - 1] == '0') {
			turn = false;
		}
		else {
			turn = true;
		}
		return 1;
	}
	else {//记录的是NPC的数据
		for (int i = 0; i < 1; i++) {
			int blank_count = 0;
			//cout << int(buf[0] - '0') << " ";
			for (int j = 0; j < len; j++) {
				if (buf[j] == ' ') {
					blank_count++;
				}

				if (blank_count == 1 && buf[i] != ' ') {
					if (buf[j] == '-')x *= 1;
					else x = x * 10 + int(buf[j] - '0');
				}

				if (blank_count == 2 && buf[j] != ' ') {
					if (buf[j] == '-')y *= 1;
					else y = y * 10 + int(buf[j] - '0');
				}

				if (blank_count == 3 && buf[j] != ' ') {
					if (buf[j] == '-')vx *= 1;
					else vx = vx * 10 + int(buf[j] - '0');
				}
				vy = 0;
			}
		}
		return 2;
	}
}
int main()
{
	infile.open("123.txt", ios::in);

	infile.getline(buf, sizeof(buf));
	int x = p_f(strlen(buf));
	if (x == 1) {
		cout << fish_x << " " << fish_y << endl;
	}
	else {
		cout << buf << endl;
		cout << x << " " << y << " " << vx << " " << vy << endl;
	}
	infile.close();
	return 0;
}
*/

#include<iostream>
#include<string>
#include<cmath>
using namespace std;

int main()
{
	string s;
	cin >> s;
	int count = 0;
	for (int i = 0; i < s.length()-3; i++) {
		if (s[i] == 'h') {
			if (s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') {
				count++;
			}
		}
	}
	cout << count;
	return 0;
}

// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
