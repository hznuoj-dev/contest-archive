#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 5e5 + 5;

int a[maxn];

void solve(){
	string e; cin >> e;
	int ans = 0;
	for(int i = 0; i < (int)e.size() - 3; ++i){
		if(e.substr(i, 4) == "hznu") ans++;
	}
	cout << ans;
}

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
