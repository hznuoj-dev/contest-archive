#include <bits/stdc++.h>
#define vi vector<int>
#define vc vector
#define vll vector<long long>
#define pii pair<int,int>
#define AXY(a,x,y) int x=(a).first,y=(a).second;
#define MID(l,r) int mid=((l)+(r))/2
using namespace std;
typedef long long ll;




#define int ll
signed main(){
	int q=1;
	//cin>>q;
	while(q--){
		string s;
		cin>>s;
		map<char,char> mp;
		
		for(int i=0;i<s.size();i++){
			mp[s[i]]=i+'0';
		}
		int n;
		cin>>n;
		set<string> st;
		for(int i=0;i<n;i++){
			string cur;
			cin>>cur;
			for(char &c:cur){
				c=mp[c];
			}
			st.insert(cur);
		}
		
		int k;
		cin>>k;
		k--;
		auto iter=st.begin();
		for(int i=0;i<k;i++,iter++) ;
		for(char c:*iter){
			
			cout<<s[c-'0'];
		}
		
	}
	return 0;
}
