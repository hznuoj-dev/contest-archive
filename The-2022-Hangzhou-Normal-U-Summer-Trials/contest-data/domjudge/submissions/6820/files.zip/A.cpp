#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main() {
	string s;
	cin >> s;
	string t = "hznu";
	int n = s.size();
	int cnt = 0;
	for (int i = 3; i < n; i++) {
		if (s[i - 3] == t[0] && s[i - 2] == t[1] && s[i - 1] == t[2] && s[i] == t[3]) {
			cnt++;
			i += 3;
		}
	}
	printf("%d\n", cnt);
	return 0;
}