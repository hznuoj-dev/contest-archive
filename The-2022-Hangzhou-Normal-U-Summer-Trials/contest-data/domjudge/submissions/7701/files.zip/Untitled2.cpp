#include<cstring>
#include<iostream>
#include<string>
#include<cstdio>
using namespace std;
string s;
int n,k; 
string o[1006];
int a[166]={0};
int main(){
	cin>>s;
	for(int i=0;i<s.length();++i){//����	
		a[s[i]]=i+1;
	}
	
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>o[i];	
	}
	for(int i=0;i<n;++i){
		for(int j=i;j<n;++j){
			for(int l=0;l<o[i].length();++l){
				if(a[o[i][l]]>a[o[j][l]]){
				string c=o[i];
				o[i]=o[j];
				o[j]=c;
				break;
				}	 
			}
			
		}	
	}

	
	
	/*for(int i=0;i<n;++i){
		cout<<o[i]<<endl;
	}*/
	cin>>k;
	cout<<o[k-1];
} 
