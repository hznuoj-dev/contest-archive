#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N = 5e5 + 5;
const int INF = 0x3f3f3f3f;

ll a[N], s[N];

int main() {
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%lld", &a[i]);
		s[i] = a[i] - a[i - 1];
	}
	ll minr = s[2];
	ll maxr = s[n];
	int q;
	scanf("%d", &q);
	while (q--) {
		ll x;
		scanf("%lld", &x);
		if (n == 1) {
			printf("%lld\n", x);
			continue;
		}
		if (x <= minr) {
			printf("%lld\n", x * n);
		} else if (x >= maxr) {
			printf("%lld\n", x + a[n] - 1);
		} else {
			ll cnt = 0;
			for (int i = 2; i <= n; i++) {
				if (x >= s[i]) {
					cnt += s[i];
				} else {
					cnt += x;
				}
			}
			cnt += x;
			printf("%lld\n", cnt);
		}
	}
	return 0;
}