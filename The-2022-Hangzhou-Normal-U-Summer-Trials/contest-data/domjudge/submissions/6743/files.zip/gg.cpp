#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
	char a[100007];
	cin>>a;
	int cnt=0;
	for(int i=0;i<strlen(a)-4;i++)
	{
		if(a[i]=='h'&&a[i+1]=='z'&&a[i+2]=='n'&&a[i+3]=='u')
		cnt++;
	}
	cout<<cnt<<endl;
}
