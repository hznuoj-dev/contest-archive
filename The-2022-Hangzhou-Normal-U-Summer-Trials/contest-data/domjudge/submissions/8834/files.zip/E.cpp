#include<bits/stdc++.h>

using namespace std;
const int N=5e5+7;
typedef long long ll;
queue<pair<int, pair<int,int> > > q;
queue<pair<int, int> > que;
int n, xa, ya, xb, yb, ans, xxa, xxb, yya, yyb;
char s[55][55];
struct Node {
	int x, y;
}nx[4]={{0, 1}, {1, 0}, {-1, 0}, {0, -1}};
void bfs() {
	q.push({0, {xa, ya}});
	que.push({xb, yb});
	while(q.size()) {
		pair<int, pair<int, int> > now = q.front(); q.pop();
		if(now.second.first==xxb&&now.second.second==yyb) {
			ans = min(ans, now.first);
			//cout << now. first;
			return ;
		}
		for(int i=0;i<4;i++) {
			if(s[now.second.first+nx[i].x][now.second.second+nx[i].y]=='*'||now.second.second+nx[i].y>n||now.second.second+nx[i].y<0||now.second.first+nx[i].x>n||now.second.first+nx[i].x<0) continue; 
			q.push(make_pair(now.first+1, make_pair(now.second.first+nx[i].x, now.second.second+nx[i].y)) );
		}
	}
}
void solve() {
	cin >> n;
	for(int i=0;i<n;i++) {
		scanf("%s", s[i]);
	}
	for(int i=1;i<=n;i++) {
		for(int j=1;j<=n;j++) {
			if(s[i-1][j-1]=='a') {
				xa=i-1; ya=j-1;
			}
			else if(s[i-1][j-1]=='b') {
				xb=i-1; yb=j-1;
			}
		}
	}
	xxa=xa, yya=ya, xxb=xb, yyb=yb;
	while(xxa>0) {
		xxa--; xxb--;
	}
	bfs();
	
		
	if(ans) cout << ans;
	else cout << "no solution" << endl;
} 

int main(){
	//ios :: sync_with_stdio(false); cin.tie(0); cout.tie(0); 
	int T=1;
	//cin >> T;
	while(T--)
		solve();
}
