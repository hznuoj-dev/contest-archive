#include<bits/stdc++.h>
using namespace std;
int n,q;
long long ans,tmp,tmp2,d[500005],sum[500005];
int bi(int x,int y,long long c){
	if(x>y)return x;
	int mid=(x+y)/2;
	if(d[mid]<c){
		x=mid+1;
	}
	else{
		y=mid-1;
	}
	int ans=bi(x,y,c);
	return ans;
}
int main(){
	cin>>n;
	cin>>tmp;
	for(int i=1;i<n;i++){
		cin>>tmp2;
		d[i]=tmp2-tmp-1;
		sum[i]=sum[i-1]+d[i];
		tmp=tmp2;
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		cin>>tmp;
		ans=n;
		tmp--;
		tmp2=bi(1,n-1,tmp);
		tmp2--;
		ans+=(sum[tmp2]+(n-tmp2)*tmp);
		
		cout<<ans<<"\n";
	}
	return 0;
}
