#include<bits/stdc++.h>
#define ll long long
using namespace std;

ll sum[100010], x;
map<pair<int, int>, int> m;
int n, k;
ll ans = 0;

void dfs(int l, int r)
{
    if(l >= r)
        return;
    if(m.find({l, r}) == m.end())
    {
        if((sum[r] - sum[l]) % k == 0)
            ans++;
        m[{l, r}] = 1;
    }
    dfs(l + 1, r);
    dfs(l, r - 1);
}

int main()
{
    scanf("%d %d", &n, &k);
    sum[0] = 0;
    for(int i = 1;i <= n;i++)
    {
        scanf("%lld", &x);
        sum[i] = sum[i - 1] + x;
    }
    dfs(0, n);
    printf("%lld", ans);
    return 0;
}