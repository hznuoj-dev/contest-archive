#include <bits/stdc++.h>
using namespace std;
int a[27];
bool cmp(string b, string c)
{
    int len = b.length() < c.length() ? b.length() : c.length();
    for (int i = 0; i < len; i ++)
    {
        if (a[b[i] - 'a'] != a[c[i] - 'a'])
            return a[b[i] - 'a'] < a[c[i] - 'a'];
    }
    return b.length() < c.length();
}
int main()
{
    string s, str[10100];
    int n;
    cin >> s;
    for (int i = 0; i < s.length(); i ++)
    {
        a[s[i] - 'a'] = i;
    }
    cin >> n;
    for (int i = 0; i < n; i ++)
        cin >> str[i];
    sort(str, str + n, cmp);
    int k;
    cin >> k;
    cout << str[k - 1] << endl;
    system("pause");
}