#include <bits/stdc++.h>
using namespace std;
const int N = 5e5+10;
int a[N] = {0};
int gap[N] = {0};

int search(long long t, int l, int r) {
	if (t > gap[r])
		return r + 1;
	if (t < gap[l])
		return 1;
	while(l != r) {
		int mid = (l + r )>> 1;
		if (t > gap[mid]) {
			l = mid + 1;
		}else if (t < gap[mid]){
			r = mid ;
		}else if (t == gap[mid]){
			return mid;
		}
	}
	return l; 
}

int main() {
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		if (i >= 2)
			gap[i - 1] = a[i] - a[i - 1];
	}
	int qes;
	cin >> qes;
	for (int i = 1; i <= qes; i++) {
		long long t;
		cin >> t;
		long long ans = 0;
		int pos = search(t, 1, n - 1);
		//cout <<"pos = " <<pos << '\n';
		int num = n - pos + 1;
		for (int j = 1; j <= pos - 1; j++) {
			ans += gap[j];
		}
	//	for (int j = 1; j <= pos - 1; j++)
			//cout << "gap[" << j << "]= " << gap[j] << '\n';
		ans += num * t;
		cout << ans << '\n'; 
	}
}
