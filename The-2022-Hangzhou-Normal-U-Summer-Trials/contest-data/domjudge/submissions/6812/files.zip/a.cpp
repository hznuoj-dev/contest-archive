#include <cmath>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <queue>
#include <map>
#include <iomanip>
#include <vector>
#include <string>
#include <set>
#include <sstream>
#include <stack>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#pragma warning(disable:4996)
using namespace std;
#define endl '\n'
#define ll long long
#define io_speed_up ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)

int main(){
	io_speed_up;
	string s;
	cin >>s;
	int num = 0;
	for(int i = 0;i + 3< s.size();i++){
		if(s[i] == 'h' && s[i + 1] == 'z' && s[i + 2]=='n' && s[i + 3] == 'u'){
			num++;
			i+=4;
		}
	}
	cout << num << endl;
}
