#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int maxn=3e3+10;
const ll mod=1e9+7;
int n;
double v[maxn];
double x[maxn],y[maxn],dis[maxn];
int vis[maxn];
int s,t;
priority_queue<pair<double,int> >q;
int chsp(int u){
	if(x[u]>=1&&y[u]>=1) return 1;
	if(x[u]<=-1&&y[u]>=1) return 2;
	if(x[u]<=-1&&y[u]<=-1) return 3;
	if(x[u]>=1&&y[u]<=-1) return 4;
	return 0;
}
double cdis(int u,int v2){
	double sv;
	if(chsp(u)==chsp(v2)){
		sv=v[chsp(u)];
	}else{
		sv=v[0];
	}
	return sqrt((x[u]-x[v2])*(x[u]-x[v2])+(y[u]-y[v2])*(y[u]-y[v2]))/sv;
}
void dij(){
	vis[s]=1;
	while(!vis[t]){
		int u=q.top().second;
		q.pop();
		while(vis[u]){
			u=q.top().second;
			q.pop();
		}
		vis[u]=1;
		for(int i=1;i<=n;i++){
			if(!vis[i]){
				double d=cdis(i,u)+dis[u];
				if(d<dis[i]){
					dis[i]=d;
					q.push(make_pair(-dis[i],i));
				}
			}
		}
	}
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<5;i++){
		scanf("%lf",&v[i]);
	}
	scanf("%lf",&v[0]);
	scanf("%d%d",&s,&t);
	if(s==t){
		printf("0");
		return 0;
	}
	for(int i=1;i<=n;i++){
		scanf("%lf%lf",&x[i],&y[i]);
	}
	dis[s]=0;
	for(int i=1;i<=n;i++){
		if(i==s) continue;
		dis[i]=cdis(s,i);
		//printf("%lf\n",dis[i]);
		q.push(make_pair(-dis[i],i));
	}
	dij();
	printf("%lf",dis[t]);
} 

