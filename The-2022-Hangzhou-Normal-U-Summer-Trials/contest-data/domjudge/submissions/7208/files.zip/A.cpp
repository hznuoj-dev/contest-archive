#include<bits/stdc++.h>
#define ll long long

using namespace std;
map<char, char>p;
string w[1010];
bool cmp(string a, string b)
{
	if (a.size() == b.size())
	{
		string c, d;
		for (int i = 0; i < a.size(); i++)
		{
			c += p[a[i]];
			d += p[b[i]];
		}
		return c < d;
	}
	return a.size() < b.size();
}
int main()
{
	string s;
	cin >> s;
	for (int i = 0; i < 26; i++)
	{
		p[s[i]] = 'a' + i;
	}
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> w[i];
	}
	sort(w, w + n, cmp);
	int k;
	cin >> k;
	cout << w[k-1];
	return 0;
}
