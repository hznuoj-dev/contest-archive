#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 1e5+10;

ll a[N],pre[N];
void solve(){
	int n,k; cin >> n >> k;
	map<int,int>mp;
	for(int i=1;i<=n;i++) cin >> a[i],pre[i]=pre[i-1]+a[i],pre[i]%=k,mp[pre[i]]++;
	int ans=0;
	for(auto c:mp){
		if(c.first==0) ans+=(1ll*c.second*(c.second+1)/2);
		else if(c.second == 1) continue;
		else {
			ans+=(1ll*(c.second-1)*c.second/2);
		}
	}
	cout << ans << endl;
	
}
/*
0 1 2 1 1 1 
1 +  n-1
*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
