#include<bits/stdc++.h>

using namespace std;

int main(){
	string s;
	cin >> s;
	int len=s.size();
	int cnt=0;
	for(int i=0;i<len;i++){
		if(s[i]=='h'){
			if(s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u') cnt++;
		}
	}
	cout << cnt <<endl;
return 0;
}
