#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

string s;

bool ck(int x)
{
	if(s[x]=='h' && s[x+1]=='z' && s[x+2]=='n' && s[x+3]=='u') return true;
	return false;
}

int main()
{
	cin>>s;
	int cnt=0;
	for(int i=0;i<s.size();i++)
	{
		if(ck(i)) cnt++;
	}
	cout<<cnt<<endl;
	return 0;
}
