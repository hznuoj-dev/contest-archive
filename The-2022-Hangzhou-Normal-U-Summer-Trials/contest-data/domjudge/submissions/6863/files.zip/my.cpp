#include <bits/stdc++.h>
#define vi vector<int>
#define vc vector
#define vll vector<long long>
#define pii pair<int,int>
#define AXY(a,x,y) int x=(a).first,y=(a).second;
#define MID(l,r) int mid=((l)+(r))/2
using namespace std;
typedef long long ll;




#define int ll
signed main(){
	int q=1;
	//cin>>q;
	while(q--){
		string s;
		cin>>s;
		int n=s.size();
		int res=0;
		
		for(int i=0;i<n-3;i++){
			if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
				res++;
				i+=3;
			}
		}	
		cout<<res<<endl;
	}
	return 0;
}
