#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int, int> PII;
string str, prt = "hznu";
int KMP(string str, string prt) {
    int cnt = 0;
    int n = str.size(), m = prt.size();
    vector<int>next(m);
    for(int i = 1, k = 0; i < m; i ++) {
        while(k > 0 && prt[i] != prt[k])
            k = next[k - 1];
        if(prt[i] == prt[k]) k ++;
        next[i] = k;
    }
    for(int i = 0, k = 0; i < n ; i ++) {
        while(k > 0 && str[i] != prt[k])
            k = next[k - 1];
        if(str[i] == prt[k])
            k ++;
        if(k == m){
            k = next[k - 1]; 
            cnt ++;
        }
    }
    return cnt;
}
void solve() {
    int xx;
    cin >> str;
    cout << KMP(str, prt);
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    solve();
    return 0;
}