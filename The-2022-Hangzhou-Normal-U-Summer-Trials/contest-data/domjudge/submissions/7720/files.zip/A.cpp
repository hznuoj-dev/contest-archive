#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct node{
	int a,b,c,d,x;
	bool operator < (const node &k) const {
		return k.x<x;
	};
};
priority_queue<node>q;
string s[100];
int get(int a,int b,int c,int d){
	int x=a*50*50*50+b*50*50+c*50+d;
	return x;
}
int X[4]={1,-1,0,0};
int Y[4]={0,0,1,-1};
int mp[7000000];
void solve(){
	int n,i,j,m,x,y,k,l,r,t,ans=0,mid;
	int a,b,c,d;
	cin>>n;
	for(i=0;i<n;i++){
		cin>>s[i];
		for(j=0;j<n;j++){
			if(s[i][j]=='a') a=i,b=j;
			if(s[i][j]=='b') c=i,d=j;
		}
	}
	q.push({a,b,c,d,0});
	x=get(a,b,c,d);
	mp[x]=1;
	//ll cnt=0;
	//clock_t A,B;
	//A=clock();
	while(!q.empty()){
		node k=q.top();
		q.pop();
		if(k.a==k.c&&k.b==k.d){
			printf("%d",k.x);
			return;
		}
		for(i=0;i<4;i++){
			a=k.a+X[i];
			b=k.b+Y[i];
			if(a<0||a>=n||b<0||b>=n||s[a][b]=='*') a=k.a,b=k.b;
			c=k.c+X[i];
			d=k.d+Y[i];
			if(c<0||c>=n||d<0||d>=n||s[c][d]=='*') c=k.c,d=k.d;
			x=get(a,b,c,d);
			if(mp[x]) continue;
			else{
				mp[x]=1;
				q.push({a,b,c,d,k.x+1});
			}
		}
	}
	//B=clock();
	//printf("%f\n",(double)(B-A)/CLOCKS_PER_SEC);
	printf("no solution");
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
