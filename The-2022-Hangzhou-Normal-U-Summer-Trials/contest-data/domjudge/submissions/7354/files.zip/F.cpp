#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n,k,a[100010];
ll b[100010];
map<ll,ll >q;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>k;
	ll sum=0;
	q[0]=1;
	ll ans=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=b[i-1]+a[i];
		sum+=q[b[i]%k]++;
	}
	cout<<sum<<endl;
//	cout<<sum<<endl;
} 
