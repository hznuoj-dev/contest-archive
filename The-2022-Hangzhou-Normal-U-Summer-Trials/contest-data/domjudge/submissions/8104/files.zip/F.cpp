#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
typedef long long ll;
const int N=1e5+10;
const int M=1e9+7;

int a[N],b[N];

void run()
{
	int n,k;
	ll cnt=0;
	
	cin >> n >> k;
	for(int i=1;i<=n;i++)
	{
		cin >> a[i];
		b[i]=a[i]+b[i-1];
	}
	for(int i=1;i<=n;i++)
		for(int j=0;j<i;j++)
			if((b[i]-b[j])%k==0)
				cnt++;
				
	cout << cnt;
}

int main()
{
	int T=1;
	
	ios::sync_with_stdio(0);
	//cin >> T;
	while(T--)
		run();
	
	return 0;
}
