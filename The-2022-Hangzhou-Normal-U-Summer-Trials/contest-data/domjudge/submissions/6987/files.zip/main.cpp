#include <iostream>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <queue>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <limits.h>
#include <stack>
#include <fstream>
#include <list>
#include <sstream>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0)
//#define pb push_back

using namespace std;
 
typedef long long ll;
typedef unsigned long long ull;

typedef pair<ll, int> PII;
const double eps = 2e-9;
const int INF = 1e9 + 10, mod = 998244353;
const double pi = acos(-1.0);
const int N = 1e3 + 10, M = 2e5 + 10, S = 70;
string s[N];
map<char, int> ma;
int n, k;
bool cmp(string &A, string &B)
{
	int mlen = min(A.size(), B.size());
	for (int i = 0; i < mlen; i++)
	{
		if (A[i] == B[i]) continue;
		return ma[A[i]] < ma[B[i]];
	}
	return A.size() < B.size();
}
int main()
{
	IOS;
	string p;
	cin >> p;
	for (int i = 0; i < 26; i++)
	{
		ma[p[i]] = i;
	}
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> s[i];
	}
	sort(s, s + n, cmp);
	cin >> k;
	cout << s[k - 1];


	return 0;
}