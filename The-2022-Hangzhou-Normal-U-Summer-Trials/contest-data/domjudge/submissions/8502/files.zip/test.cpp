#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=50+10;
const int INF=2e18+1000;
const int SIZE=1000000+10;
const int mod=1e9+7;
int n,m,k;
int fa[200];
int t[SIZE];
char x[SIZE];
char y[SIZE];
void solve(){
    cin>>n;
    for (int i = 0; i < n; i ++ ) {
        cin >> t[i];
        if (t[i] == 1) cin >> x[i];
        else if(t[i]==2) continue;
        else cin >> x[i] >> y[i];
    }
    vector<int> ans, p(1000000);
    int cnt=0;
    iota(p.begin(), p.end(), 0);
    for (int i = n - 1; i >= 0; i -- ) {
        if (t[i] == 1) {
            if(cnt){
                cnt--;
                continue;
            }
            ans.push_back(p[x[i]]);
        }
        else if(t[i]==2) cnt++;
        else {
            p[x[i]] = p[y[i]];
        }
    }
    reverse(ans.begin(), ans.end());
    if(ans.size()==0){
        cout<<"The final string is empty"<<endl;
        return ;
    }
    for (int v: ans) cout << (char)v;
    cout<<endl;
}
void inits(){}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int ts=1;
    inits();
    while(ts--){
        solve();
    }
    return 0;
}