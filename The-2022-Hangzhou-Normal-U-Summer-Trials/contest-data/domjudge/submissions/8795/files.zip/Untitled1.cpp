#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
using namespace std;

signed main()
{
	Daybreak7;
	int n,p,s;
	cin>>n>>p>>s;
	int a[n],b[n];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		if(i>0) b[i-1]=a[i]-a[i-1];
	}
	sort(b,b+n-1);
	int k;
	cin>>k;
	int sum=k*s,ans=0;
	for(int i=n-2;i>=0;i--)
	{
		if(b[i]<=sum)
		{
			ans+=b[i];
			sum-=s;
		}
	}
	cout<<p-ans;
}
