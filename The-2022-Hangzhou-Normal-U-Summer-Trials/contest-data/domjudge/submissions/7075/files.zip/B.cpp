#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int dic[200],n,k;
bool cmp(string s1,string s2){
	for (int i=0; i<min(s1.length(),s2.length());i++){
		if (s1[i]==s2[i]){
			continue;
		}else{
			if (dic[s1[i]]<dic[s2[i]]){
				return true;
			}else{
				return false;
			}
		}
	}
	if (s1.length()<s2.length()){
		return true;
	}else{
		return false;
	}
}
int main(){
	string s,ss[1010];
	cin>>s;
	for (int i=0; i<26; i++){
		dic[s[i]]=i;
	}
	cin>>n;
	for (int i=1; i <= n;i++){
		cin>>ss[i];
	}
	cin>>k;
	sort(ss+1,ss+1+n,cmp);
	cout<<ss[k]<<endl;
}
