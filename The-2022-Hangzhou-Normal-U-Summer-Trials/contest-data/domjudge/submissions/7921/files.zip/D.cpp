#include<bits/stdc++.h>

using namespace std;

#define debug(x) cerr << #x << " = " << x << '\n'

typedef long long ll;

const int N = 2e5 + 10;

void solve() {
	int n, k;
	cin >> n >> k;
	vector<ll> a(n + 1);
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
	}
	ll ans = 0;
	map<ll, ll> mp;
	mp[0] = 1;
	ll sum = 0;
	for (int i = 1; i <= n; ++i) {
		sum += a[i];
		sum %= k;
//		printf("sum = %d cnt = %d\n", sum, mp[sum]);
		ans += mp[sum];
		mp[sum]++;
		
	} 
	cout << ans << '\n';
}

/*
3
1 3 8
3
2
3
6
*/ 

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
