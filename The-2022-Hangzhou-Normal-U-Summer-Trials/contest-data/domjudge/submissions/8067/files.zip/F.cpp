#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main(){
	long long n,a[100010],b[100010],k;
	cin>>n>>k;
	b[0]=0;
	for (int i=1; i<=n; i++){
		cin>>a[i];
		b[i]=b[i-1]+a[i];
	}
	long long ans=0; 
	for (int i=1; i<=n; i++){
		for (int j=i; j<=n;j++){
			if ((b[j]-b[i-1])%k==0){
				ans++;
			}
		}
	}
	cout<<ans<<endl;
}
