#include<bits/stdc++.h>
using namespace std;

int main(){
	string ace,a;
	int n,i,j,t;
	cin>>ace;
	map<char,int> m;
	for(i=0;i<ace.size();i++){
		m[ace[i]] = i;
	}
	cin>>n;
	map<int,string> mmp;
	for(i=0;i<n;i++){
		cin>>a;
		int flag = 0;
		if(i==0){
			mmp[i] = a;
		}else{
			for(j=0;j<i;j++){  //zhao
				string s = mmp[j];
				for(t=0;t<a.size();t++){   //shifou dui
					if(a[t]==s[t]){
						if(a.size()<s.size()&&t==a.size()-1){
							flag = 1;
							break;
						}
					}else{
						if(m[a[t]]<m[s[t]]&&t<s.size()){
							flag = 1;
							break;
						}else{
							break;
						}
					}
				}
				if(flag==1){
					for(t=i;t>j;t--){
						mmp[t] = mmp[t-1];
					}
					mmp[j] = a;
					break;
				}
			}
			if(flag==0){
				mmp[i] = a;
			}
		}
	}
	int k;
	scanf("%d",&k);
	cout << mmp[k-1] << endl;
	return 0;
}

