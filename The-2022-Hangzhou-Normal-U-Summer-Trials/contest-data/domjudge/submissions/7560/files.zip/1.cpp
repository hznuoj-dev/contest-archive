#include <bits/stdc++.h>
#define RE0 return 0;
#define FAST ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)
#define ll long long
using namespace std;

ll T = 1, n, m;

ll a[500005];
ll b[500005];

signed main(){
	FAST;
	while(T--){
		cin >> n;
		for(int i=1; i<=n; ++i){
			cin >> a[i];
			if(i != 1)
				b[i - 1] = a[i]-a[i-1];
		}
		for(int i =0;i<=n;++i){
			cout << b[i] << " ";
		}
		cout << endl;
		ll q;
		cin >> q;
		for(int i=1;i<=q;++i){
			ll x;
			cin >> x;
			ll l = 1,r = n - 1,mid,ans = 0;
			while(l <= r){
				mid = (l+r)/2;
				if(b[mid]<=x){
//					cout << mid << " " << a[mid] << endl;
					ans = max(ans,mid);
					l = mid + 1;
				}
				else{
					r = mid - 1;
				}
			}
//			cout << ans << " " << a[ans] << endl;
//			ll num = 0;
			if(ans == n - 1){
				cout << a[n] - a[1] + x << "\n";
			}
			else if(ans){
				ll num = a[ans + 1] - a[1] + (n - ans) * x;
				cout << num << "\n";
			}
			else{
				cout << n * x << "\n";
			}
		}
	}
	RE0
} 

