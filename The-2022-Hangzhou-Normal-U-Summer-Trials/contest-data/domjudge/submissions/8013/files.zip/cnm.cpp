#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=1e6+7;
double inf=1000000000.0;
int n;
bool vis[maxn];
double dist[maxn];
struct qnode{
	int v;
	double c;
	qnode(int _v=0,double _c=0.0):v(_v),c(_c){}
	bool operator <(const qnode &a)const{
		return c>a.c;
	}
};
struct node{
	double x, y;
}p[maxn];
struct edge{
	int v;
	double cost;
	edge(int _v=0,double _cost=0.0):v(_v),cost(_cost){}
};
vector<edge>e[maxn];
double dis(node p1, node p2){
	return sqrt((p1.x-p2.x)*(p1.x-p2.x)+(p1.y-p2.y)*(p1.y-p2.y));
}
void dij(int start){
	memset(vis,false,sizeof(int)*(n+4));
	for(int i=1;i<=n;i++) dist[i]=inf;
	priority_queue<qnode>q;
	dist[start]=0;
	q.push(qnode(start,0.0));
	qnode tmp;
	while(!q.empty()){
		tmp=q.top();
		q.pop();
		int u=tmp.v;
		if(vis[u])continue;
		vis[u]=true;
		for(int i=0;i<e[u].size();i++){
			int v=e[tmp.v][i].v;
			double cost=e[u][i].cost;
			if(!vis[v]&&dist[v]>dist[u]+cost){
				dist[v]=dist[u]+cost;
				q.push(qnode(v,dist[v]));
			}
		}
	}
}
signed main(){
	cin>>n;
	double v1, v2, v3, v4, v0;
	cin>>v1>>v2>>v3>>v4>>v0;
	int start, end;
	cin>>start>>end;
	for(int i=1;i<=n;i++){
		cin>>p[i].x>>p[i].y;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(j==i) continue;
			double v;
			if(p[i].x*p[j].x>=0&&p[i].y*p[j].y>=0){
				if(p[i].x>0&&p[i].y>0) v=v1;
				if(p[i].x<0&&p[i].y>0) v=v2;
				if(p[i].x<0&&p[i].y<0) v=v3;
				if(p[i].x>0&&p[i].y<0) v=v4;
				double w=dis(p[i],p[j])/v;
				e[i].push_back(edge(j,w));
				e[j].push_back(edge(i,w));
			}
			else{
				v=v0;
				double w=dis(p[i],p[j])/v;
				e[i].push_back(edge(j,w));
				e[j].push_back(edge(i,w));
			}
		}
	}
	dij(start);
	printf("%.10f\n", dist[end]);
} 
