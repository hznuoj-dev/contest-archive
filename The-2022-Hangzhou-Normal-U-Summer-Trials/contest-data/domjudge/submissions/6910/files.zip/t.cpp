#include<iostream>
#include<algorithm>
using namespace std;
const int N = 1e3 + 10;
char m[26];
int flect[26];
bool cmp(string a, string b){
    int i = 0;
    for(;i < a.size() && i < b.size(); i++)
        if(flect[a[i] - 'a'] < flect[b[i] - 'a']) return true;
    return a.size() < b.size();
}
string s[N];
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin >> m;
    for(int i = 0; i < 26; i++)
        flect[m[i] - 'a'] = i;
    int t;
    cin >> t;
    for(int i = 0; i < t; i++){
        cin >> s[i];
    }
    sort(s, s + t, cmp);
    int n;
    cin >> n;
    cout << s[n - 1];
}