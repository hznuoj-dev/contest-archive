#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
#define int long long
using namespace std;

map<int,int> mp;
signed main()
{
	Daybreak7;
	int n,k;
	cin>>n>>k;
	int x,num=0;
	for(int i=1;i<=n;i++)
	{
		cin>>x;
		num+=x;
		mp[num%k]++;
	}
	int ans=mp[0]*(mp[0]+1)/2;
	for(int i=1;i<k;i++)
	{
		if(mp[i]!=1)
			ans+=mp[i]*(mp[i]-1)/2;
	}
	cout<<ans;
}
