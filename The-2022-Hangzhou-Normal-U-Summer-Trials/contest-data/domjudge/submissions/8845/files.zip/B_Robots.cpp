#include<iostream>
#include<algorithm>
#include<cstring>
#include<cmath>
#include<queue>
#include<iomanip>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
using namespace std;
typedef long long ll;
typedef double dd;
typedef pair<dd, dd> pdd;
int n, s, t;
int h[3010], ne[6010], e[6010], idx;
dd eps = 1e-8;
dd w[6010];
dd v[10];
pdd pt[3010];
dd tim[3010];
bool st[3010];
int sign(dd x) {
	if (fabs(x) < eps) return 0;
	if (x < 0) return -1;
	return 1;
}
int dcmp(dd x, dd xx) {
	if (fabs(x - xx) < eps) return 0;
	if (x < xx) return -1;
	return 1;
}
dd dist(int a, int b) {
	return sqrt((pt[a].first - pt[b].first) * (pt[a].first - pt[b].first) + (pt[a].second - pt[b].second) * (pt[a].second - pt[b].second));
}
dd calc(int a, int b) {
	pdd p = pt[a], pp = pt[b];
	dd ret = -1;
	dd ddd = dist(a, b);
    //cout <<a<<" "<<b<<" "<< setprecision(6) << ddd << "\n";
	if (p.first < 0 && pp.first < 0 && p.second < 0 && pp.second < 0) {
		ret = ddd / v[3];
	}
	else if (p.first > 0 && pp.first > 0 && p.second > 0 && pp.second > 0) {
		ret = ddd / v[1];
	}
	else if (p.first > 0 && pp.first > 0 && p.second < 0 && pp.second < 0) {
		ret = ddd / v[4];
	}
	else if(p.first < 0 && pp.first < 0 && p.second > 0 && pp.second > 0) {
		ret = ddd / v[2];
	}
	else {
		ret = ddd / v[0];
	}
    //cout << setprecision(6) << ret << "&\n";
	return ret;
}
void add(int a, int b) {
	e[idx] = b, w[idx] = calc(a, b), ne[idx] = h[a], h[a] = idx++;
   // cout <<setprecision(6) <<  w[idx - 1] << "\n";
}
void dijkstra() {
	priority_queue < pair<dd, int>, vector<pair<dd, int>>, greater<pair<dd, int>>>hp;
	for (int i = 1; i <= n; i++) {
		st[i] = 0;
		tim[i] = 1e18;
	}
	hp.push({ s, 0 });
	tim[s] = 0;
	while (hp.size()) {
		auto tt = hp.top(); hp.pop();
		int ver = tt.second; dd tcur = tt.first;
		if (st[ver]) continue;
		st[ver] = 1;
		for (int i = h[ver]; i != -1; i = ne[i]) {
			int j = e[i];
			if (tim[j] > tcur + w[i]) {
				tim[j] = tcur + w[i];
				hp.push({ j, tim[j] });
			}
		}
	}
}
int main() {
	IOS;
    cout.setf(ios::fixed);
	cin >> n;
	for (int i = 1; i <= 4; i++) {
		cin >> v[i];
	}
	cin >> v[0];
	cin >> s >> t;
	for (int i = 1; i <= n; i++) {
		h[i] = -1;
	}
	for (int i = 1; i <= n; i++) {
		cin >> pt[i].first >> pt[i].second;
	}
	for (int i = 1; i <= n; i++) {
		for (int j = i + 1; j <= n; j++) {
			add(i, j);
           // cout << w[idx] << "\n";
            add(j, i);
            
		}
	}
	dijkstra();
	cout <<setprecision(6)<< tim[t] << "\n";
}