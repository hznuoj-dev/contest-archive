#include<bits/stdc++.h>
using namespace :: std;

const int maxn = 5e5+10;
const long long maxe=1e18;
int n;
vector<long long>a;
vector<long long>b;
long long x,last;
long long q,qu;
int i;

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    cin>>n;
    last=0;
    for (i = 0; i < n; i++)
    {
        cin>>x;
        a.push_back(x);
        if (i==0)
        {
            last=x;
        }else
        {
            b.push_back(x-last);
            last=x;
        }
    }
    b.push_back(maxe);
    cin>>q;
    while (q--)
    {
        cin>>qu;
        long long res=0;
        i=lower_bound(b.begin(),b.end(),qu)-b.begin();
        //cout<<i<<endl;
        res=qu*(n-i)+a[i]-1;
        cout<<res<<endl;
    }
    return 0;
}