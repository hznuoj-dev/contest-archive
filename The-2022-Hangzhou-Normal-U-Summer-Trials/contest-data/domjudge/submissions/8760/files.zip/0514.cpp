#include<bits/stdc++.h>
using namespace std;
#define ll long long
// #define double long double
// #define inf 0x3f3f3f3f
const double inf=1e6;
const int maxn=3e3+10;
const int maxm=9e6+10;
const int mod=1e9+7;
int n,m,cnt;
double v1,v2,v3,v4,v0;
int st,ed;
struct point
{
    double x,y;
}p[maxn];
struct edge
{
    int to,next;
    double w;
}e[maxm];
struct node
{
    int id;
    double s;
    node(int a,double b){id=a;s=b;}
    bool operator < (const node a) const{
        return a.s<s;
    }
};
int vis[maxn];
int head[maxn];
double dist[maxn];
priority_queue<node>q;

void add(int x,int y,double w)
{
    e[cnt].to=y;
    e[cnt].w=w;
    e[cnt].next=head[x];
    head[x]=cnt++;
}
void init()
{
    cnt=0;
    for(int i=1;i<=n;i++)  
    {
        head[i]=-1;
        vis[i]=0;
        dist[i]=inf;
    }
}

void dij()
{
    dist[1]=0;
    q.push(node(1,0));
    while(!q.empty())
    {
        node p=q.top();
        q.pop();
        if(vis[p.id])  continue;
        vis[p.id]=1;
        for(int i=head[p.id];~i;i=e[i].next)
        {
            edge t=e[i];
            if(!vis[t.to] && dist[t.to]>dist[p.id]+t.w)
            {
                dist[t.to]=dist[p.id]+t.w;
                q.push(node(t.to,dist[t.to]));
            }
        }
    }
    return;
}
int main()
{
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    // cout.tie(0);
    scanf("%d",&n);
    
    scanf("%lf%lf%lf%lf%lf",&v1,&v2,&v3,&v4,&v0);
    scanf("%d%d",&st,&ed);
    for(int i=1;i<=n;i++)
    {
        scanf("%lf%lf",&p[i].x,&p[i].y);
        // printf("%lf  %lf---\n",p[i].x,p[i].y);
    }
    swap(p[1].x,p[st].x);
    swap(p[1].y,p[st].y);
    swap(p[n].x,p[ed].x);
    swap(p[n].y,p[ed].y);
    init();
    for(int i=2;i<=n-1;i++)
    {
        for(int j=i+1;j<=n-1;j++)
        {
            double ww,vv,d=sqrt(1.0*(p[i].x-p[j].x)*(p[i].x-p[j].x)+(p[i].y-p[j].y)*(p[i].y-p[j].y));
            double xx=p[i].x*p[j].x,yy=p[i].y*p[j].y;
            if(xx<0 || yy<0)  vv=v0;
            else
            {
                if(p[i].x>=0 && p[i].y>=0)  vv=v1;
                else if(p[i].x<=0 && p[i].y>=0)  vv=v2;
                else if(p[i].x<=0 && p[i].y<=0)  vv=v3;
                else if(p[i].x>=0 && p[i].y<=0)  vv=v4;
            }
            ww=d/vv;
            add(i,j,ww);
            add(j,i,ww);
        }
    }
    for(int i=2;i<=n;i++)
    {
        double d=sqrt((p[i].x-p[1].x)*(p[i].x-p[1].x)+(p[i].y-p[1].y)*(p[i].y-p[1].y));
        // double d=sqrt((p[i].x-p[n].x)*(p[i].x-p[n].x)+(p[i].y-p[n].y)*(p[i].y-p[n].y));
        double ww,vv;
        double xx=p[i].x*p[1].x,yy=p[i].y*p[1].y;
        if(xx<0 || yy<0)  vv=v0;
        else
        {
            if(p[i].x>=0 && p[i].y>=0)  vv=v1;
            else if(p[i].x<=0 && p[i].y>=0)  vv=v2;
            else if(p[i].x<=0 && p[i].y<=0)  vv=v3;
            else if(p[i].x>=0 && p[i].y<=0)  vv=v4;
        }
        ww=d/vv;
        add(i,1,ww);
        add(1,i,ww);
    }
    for(int i=2;i<=n-1;i++)
    {
        // double d=sqrt((p[i].x-p[1].x)*(p[i].x-p[1].x)+(p[i].y-p[1].y)*(p[i].y-p[1].y));
        double d=sqrt((p[i].x-p[n].x)*(p[i].x-p[n].x)+(p[i].y-p[n].y)*(p[i].y-p[n].y));
        double ww,vv;
        double xx=p[i].x*p[n].x,yy=p[i].y*p[n].y;
        if(xx<0 || yy<0)  vv=v0;
        else
        {
            if(p[i].x>=0 && p[i].y>=0)  vv=v1;
            else if(p[i].x<=0 && p[i].y>=0)  vv=v2;
            else if(p[i].x<=0 && p[i].y<=0)  vv=v3;
            else if(p[i].x>=0 && p[i].y<=0)  vv=v4;
        }
        ww=d/vv;
        add(i,n,ww);
        add(n,i,ww);
    }
    dij();
    printf("%.10lf",dist[n]);
}