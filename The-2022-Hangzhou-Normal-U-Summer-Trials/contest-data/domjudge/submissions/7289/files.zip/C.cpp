#include<bits/stdc++.h>
using namespace std;
#define N 500005
#define int long long

map<int,int> times,sum;
int num[N];

void solve(){
	int n,als = 0,alt = 0;
	cin >> n;
	for(int i = 1;i <= n;i++) cin >> num[i];
	times[0] = 0,sum[0] = 0;
	for(int i = 2;i <= n;i++) times[num[i] - num[i - 1]]++;
	for(auto it : times){
		alt += it.second;
		als += it.first * it.second;
		times[it.first] = alt;
		sum[it.first] = als;
	}
	int m,now,tmp;
	cin >> m;
//	cout << '\n';
//	for(auto it : times) cout << it.first << ' ' << it.second << ' ' << sum[it.first] << '\n';
//	cout << '\n';
	for(int i = 1;i <= m;i++){
		cin >> now;
		tmp = (*(--times.upper_bound(now))).first;
//		cout << tmp <<' ';
//		cout << times[tmp] << ' ' << sum[tmp] << ' ';
		cout << (n - times[tmp]) * now + sum[tmp] << '\n';
	}
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	times.clear(),sum.clear();
	while(t--) solve();
}

/*
5
1 1 1 1 2
10
0
1

*/
