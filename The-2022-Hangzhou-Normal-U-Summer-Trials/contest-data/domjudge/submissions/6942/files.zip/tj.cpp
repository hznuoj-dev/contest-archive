#include<iostream>
#include<string>
#include<cstdio>
#include<cstring>
typedef long long ll;
using namespace std;
int main(){
char str[2000020];
scanf("%s",str);
int sum = 0;


for(int i = 0;i<99999;i++){
	if(str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u')
	sum++;
}


printf("%d",sum);


} 
