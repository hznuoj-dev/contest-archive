#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=1e6+7;
int n, k;
int a[maxn];
int re[maxn];
int pre[maxn];
signed main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=2;i<=n;i++){
		re[i-1]=a[i]-a[i-1];
	}
	sort(re+1,re+n);
	for(int i=1;i<n;i++){
		pre[i]=pre[i-1]+re[i];
//		cout<<"1cnm "<<pre[i]<<endl;
	}
	int t;cin>>t;
//	cout<<pre[n-1]<<endl;
	while(t--){
		int q;cin>>q;
		if(q>=pre[n-1]){
			cout<<pre[n-1]+q<<endl;
			continue;
		}
		int k=lower_bound(re+1,re+n,q)-re;
		cout<<pre[k-1]+(n-k+1)*q<<endl;
	}
} 
