#include<bits/stdc++.h>
using namespace std;
long long a[500007];
long long cha[500007];
long long n;
void run(){
	long long k;
	cin>>k;
	long long ans=0;
	if(k>=cha[n]){
		ans=a[n]+k-1-(a[1]-1);
	}
	else{
		long long l=1;
		long long r=n;
		while(l<r){
			long long mid=(l+r)>>1;
			if(k<cha[mid]){
				r=mid-1;
			}
			else{
				l=mid+1;
			}
			//cout<<"l="<<l<<endl;
		}
		if(cha[l]>k){
			while(cha[l]>k){
				l--;
			}
		}
		else{
			while(cha[l]<=k){
				l++;
			}
			l--;
		}
		//cout<<"l="<<l<<endl;
		ans=a[l]+(n-l+1)*k-1-(a[1]-1);
	}
	cout<<ans<<endl;
}
int main()
{
	cin>>n;
	for(long long i=1;i<=n;i++){
		cin>>a[i];
		cha[i]=a[i]-a[i-1];
	}
	cha[1]=0;
	long long q;
	cin>>q;
	while(q--){
		run();
	}
	return 0;
}
