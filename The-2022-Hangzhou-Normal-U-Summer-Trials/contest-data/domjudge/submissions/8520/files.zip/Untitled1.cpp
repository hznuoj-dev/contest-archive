#include<cstring>
#include<iostream>
#include<string>
#include<cstdio>
using namespace std;
int a[500086];
int t[500086];
int n,q,ans=0;
int main(){
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>a[i];
	}
	cin>>q;
	for(int i=0;i<q;++i){
		cin>>t[i];
	}
	for(int i=0;i<q;++i){
		ans=t[i];
		for(int j=0;j<n-1;++j){
			if(t[i]<=a[j+1]-a[j]) ans+=t[i];
			else  ans+=a[j+1]-a[j];
		}cout<<ans<<endl;
	}
}
 
