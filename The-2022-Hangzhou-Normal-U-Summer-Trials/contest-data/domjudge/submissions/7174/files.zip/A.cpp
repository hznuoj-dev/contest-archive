#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[100010],b[100010],n;
vector<ll>e[200010];
ll dfs(ll x,ll fa){
	ll i,y,k=0,l;
	b[x]=1;
	for(i=0;i<e[x].size();i++){
		y=e[x][i];
		if(y==fa) continue;
		l=dfs(y,x);
		a[x]+=l*k;
		k+=l;
		b[x]+=l;
	}
	a[x]+=(n-b[x])*k+n-1;
	return b[x];
}
void solve(){
	ll i,j,m,x,y,k,l,r,t,ans=0,q,mid;
	char c;
	cin>>n;
	for(i=1;i<n;i++){
		scanf("%lld%lld",&x,&y);
		e[x].push_back(y);
		e[y].push_back(x);
	}
	x=dfs(1,0);
	cin>>q;
	while(q--){
		scanf("%lld",&x);
		printf("%lld\n",a[x]);
	}
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
