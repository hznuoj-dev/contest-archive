#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=1001;
string s;
bool cmp(string a,string b){
	int la=a.size();
	int lb=b.size();
	int i=0;
	while(i<la&&i<lb){
		if(a[i]==b[i])
		i++;
		else{	
			return s.find(a[i])<s.find(b[i]);
		}
	}
	return la<lb;
}
int main(){
	string ss[N];
	cin>>s;
	int n,k;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>ss[i];
	}
	cin>>k;
	sort(ss,ss+n,cmp);
//	for(int i=0;i<n;i++){
//		cout<<ss[i];
//	}
	cout<<ss[k-1]<<endl;
	
}
