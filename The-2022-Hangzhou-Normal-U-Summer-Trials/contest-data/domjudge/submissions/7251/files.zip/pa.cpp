#include <bits/stdc++.h>
using namespace std;
long long n,k,m,l,r,x;
long long a[500010],b[500010];
int main ()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	b[1]=0;
	for (int i = 2; i <= n; i++)
		b[i]=a[i]-a[i-1]+1;
	cin >> k;
	for (int i = 1; i <= k; i++)
		{
			cin >> x;
			l=1; r=n; 
			while (l <= r) {
				m=(l+r)/2;
				if (b[m] <= x) l=m+1; else r=m-1;
			}
			cout << a[r]-a[1]+(n-r+1)*x << '\n';
		}
	return 0;
}
