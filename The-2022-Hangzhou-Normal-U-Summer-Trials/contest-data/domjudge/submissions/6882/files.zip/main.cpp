#include <bits/stdc++.h>
#include <cstring>
using namespace std;

int main(){
    char s[100005];
    cin>>s;
    int num=0,l=strlen(s);
    for(int i=0;i<l;i++){
        if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
            num++;
        }
    }
    printf("%d",num);
    return 0;
}