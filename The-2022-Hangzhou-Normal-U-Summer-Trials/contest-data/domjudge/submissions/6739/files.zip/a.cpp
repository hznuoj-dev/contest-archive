#include <iostream>
#include <queue>
using namespace std;
using ll = long long;

int ____ = (ios::sync_with_stdio(0), cin.tie(0), cout.tie(0), 1);

using namespace std;

typedef long long LL;
typedef pair<int, int> PII;
const int N = 2e5 + 7, mod = 1e9 + 7, INF = 2e9;
int n, m;
int a[N];

void solve() {
	string s;
	cin >> s;
	int ans=0;
	for(int i=0; i<s.size()-3; i++){
        if(s[i]=='h' && s[i+1]=='z' && s[i+2]=='n' && s[i+3]=='u') ans++;
	}
	cout << ans << endl;
}
int main() {
	int t;
	t = 1;
	//cin >> t;
	while (t--) {
		solve();
	}
}
