#include<bits/stdc++.h>
using namespace std;
#define dbg(x) cerr << #x << " -> " << x << '\n'
typedef unsigned long long ull;
typedef long long ll;
const int N = 5e5 + 10;
const int SIZE = 1110;
int n,m,x,y;
string s;
ll pre[N];
map<char,int>mp;
ll ha[SIZE];
map<ll,string >b;
map<int ,string >a;
int main(){
    cin>>s;
    for(int i=0;i<s.size();++i){
        mp[s[i]]=i+1;
       // cout<<"mp[s[i]]"<<mp[s[i]]<<endl;
    }
    int n;
    cin>>n;
    for(int i=1;i<=n;++i){
        cin>>s;
        ull ans=0;
        for(int j=0;j<s.size();++j){
            ans+=(ans*30+mp[s[j]]);
        }
        ha[i]=ans;
        b[ans]=i;
        a[ans]=s;
        //dbg(s);
    }
    
    int k;
    cin>>k;
    sort(ha+1,ha+1+n);
//    for(int i=1;i<=n;++i){
//    	cout<<"ha[i]"<<ha[i]<<endl;
//	}
    //cout<<ha[k]<<endl;
    cout<<a[ha[k]]<<endl;
    
}