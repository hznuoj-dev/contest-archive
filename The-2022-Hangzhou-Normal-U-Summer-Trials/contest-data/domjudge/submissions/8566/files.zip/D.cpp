#include<bits/stdc++.h>
#define endl '\n'
using namespace std;
const int N=1e5+7;
typedef long long ll;
ll n, ans, son[N];
int vis[N], root;
vector<int > g[N];
void dfs(int u) {
	int sz=g[u].size();
	son[u]=1;
	if(!sz) {
		return ;
	}
	for(int i=0;i<sz;i++) {
		dfs(g[u][i]);
		son[u]+=son[g[u][i]];
	}
}
void solve() {
	cin >> n;
	for(int i=1;i<n;i++) {
		int u, v;
		cin >> u >> v;
		g[u].push_back(v);
		vis[v]=1;
	}
	for(int i=1;i<=n;i++) if(!vis[i]) root=i;
	dfs(root);
	int q;
	cin >> q;
	while(q--) {
		int x;
		cin >> x;
		ans = n-1;
		int sz=g[x].size();
		if(sz==1) {
			ans+=g[x][0]*(n-1-g[x][0]);
		} 
		else if(sz==2) {
			ans+=son[g[x][0]]*(n-1-son[g[x][0]]-son[g[x][1]])+son[g[x][1]]*(n-1-son[g[x][1]]-son[g[x][0]])+son[g[x][0]]*son[g[x][1]];
		}
		cout << ans << endl;
	}
	//for(int i=1;i<=5;i++) cout << son[i] << endl;
}

int main(){
	ios :: sync_with_stdio(false); cin.tie(0); cout.tie(0); 
	int T=1;
	//cin >> T;
	while(T--)
		solve();
}
