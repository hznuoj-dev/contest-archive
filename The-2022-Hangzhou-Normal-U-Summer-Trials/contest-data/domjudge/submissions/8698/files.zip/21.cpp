#include<iostream>

using namespace std;

int main()
{
	int n, k;
	cin >> n >> k;
	int a[n];
	long long sum[n];
	int flag[n] = {0};
	int tim = 0;
	for(int i = 0; i < n; i++)
	{
		cin >> a[i];
		if(i != 0)
		{
			sum[i] = sum[i - 1] + a[i];
		}
		else
		{
			sum[i] = a[i];
		}
	}
	for(int i = 0 ; i < n; i++)
	{
			
		if(!flag[i])
		{
			int t = 0;
			for(int j = i; j < n; j++)
			{
				if(i == 0)
				{
					if(sum[j] % k == 0)
					{
						flag[j + 1] = 1;
						t++;
					}
				}
				else
				{
					if((sum[j] - sum[i - 1]) % k == 0)
					{
						flag[j + 1] = 1;
						t++;
					}
				}
			}
			tim += t * (t + 1) / 2;
		}
		
	}
	cout << tim;
}
