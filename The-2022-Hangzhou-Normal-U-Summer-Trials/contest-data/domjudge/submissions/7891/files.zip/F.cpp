#include<bits/stdc++.h>
using namespace std;
int n,k;
long long ans,tmp;
int a[100005];
map<int,long long>tongyu;

int main(){
	
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		a[i]=(a[i]+a[i-1])%k;
		tongyu[a[i]]++;
	}
	for(int j=0;j<k;j++){
		if(j==0){
			ans+=((tongyu[j]+1)*(tongyu[j])/2);
			continue;
		}
		if(tongyu[j]>0){
			ans+=((tongyu[j]-1)*(tongyu[j])/2);
		}
		
	}
	cout<<ans;
	return 0;
}
