#include<bits/stdc++.h>
using namespace :: std;

map<char,int>M;

bool cmp(string a,string b){
    for (int i = 0; i < min(a.length(),b.length()); i++)
    {
        if (M[a[i]]<M[b[i]])
        {
            return true;
        }else if (M[a[i]]>M[b[i]])
        {
            return false;
        }
    }
    if (a.length()<b.length())
    {
        return true;
    }else
    {
        return false;
    }
    
}

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    string f;
    string s[1010];
    int n;
    int k;
    cin>>f;
    for (int i = 0; i < f.length(); i++)
    {
        M[f[i]]=i;
    }
    cin>>n;
    for (int i = 0; i < n; i++)
    {
        cin>>s[i];
    }
    cin>>k;
    for (int i = 0; i < k; i++)
    {   
        int min=i;
        for (int j = i+1; j < n; j++)
        {
            if(cmp(s[j],s[min])){
                min=j;
            }
        }
        cout<<s[min]<<endl;
        swap(s[min],s[i]);
    }
    return 0;
}