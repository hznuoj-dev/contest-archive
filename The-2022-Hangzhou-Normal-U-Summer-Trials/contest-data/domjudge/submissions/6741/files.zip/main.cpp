#include<bits/stdc++.h>
using namespace std;
int main(){
    string str;
    getline(cin,str);
    int num=0;
    for(int i=0;i<str.length();i++){
        if(str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u'){
            num++;
        }
    }
    cout<<num<<endl;
}