#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[500100],cha[500100];
int main()
{
	ll i,j,n,m;
	ll k,l,t,ma;
	ll ans;
	cin>>n;
	for (i=1;i<=n;i++)
		cin>>a[i];
	ma=0;
	for (i=1;i<=n-1;i++)
	{
		cha[i]=a[i+1]-a[i];
		ma=max(cha[i],ma);
	}
	cin>>m;
	while (m--)
	{
		ans=0;
		cin>>t;
		if (t>ma) 
		{ans=a[n]+t-1; 
		 printf("%lld\n",ans); 
		 continue;} 
		for (i=1;i<=n-1;i++)
		{
			if (cha[i]<t) ans+=cha[i]-t; else break;
		}
		ans+=t*n;
		printf("%lld\n",ans);
	}
}
