#include<bits/stdc++.h>
using namespace std;
#define itn int
#define int long long 
int sum[500050];
void run()
{
	int n;
	cin>>n;
	vector<int>arr;
	for(int i=0;i<n;i++)
	{
		int now;
		cin>>now;
		arr.push_back(now);
	}
	vector<int>v;
	v.push_back(0);
	for(int i=0;i<arr.size()-1;i++)
	{
		int now=arr[i+1]-arr[i];
		v.push_back(now);
	}
	for(int i=1;i<=n;i++)
	{
		sum[i]=v[i]+sum[i-1];
	}
	int q;
	cin>>q;
	while(q--)
	{
		int now;
		cin>>now;
		int ind=lower_bound(v.begin(),v.end(),now)-v.begin();
		int ans=sum[ind-1]+(n-ind+1)*now;
		cout<<ans<<endl;
	}
	
	
	return;
}
signed main()
{
	int T=1;
//	cin>>T;
	while(T--)
	{
		run();
	}
	
	return 0;
}
