#include <iostream>
#include <cstring>
using namespace std;
int main(){
    char a[27], s;
    char str[1001][1010];
    int n, rank, t;
    for(int i = 0; i < 26; i++){
        cin >> s;
        a[s-'a'] = i;
    }
    cin >> n;
    for(int i = 1; i <= n; i++){
        cin >> str[i];
        t = 0;
        for(int j = 1; j < i; j++){
            for(int k = 0; k < strlen(str[j]); k++){
                if(strlen(str[i]) <= k){
                    t = 0;
                    break;
                }
                if(k == strlen(str[j])-1){
                    if(a[str[i][k]-'a'] < a[str[j][k]-'a']){
                        t = 1;
                        break;
                    }
                    t = 0;
                    break;
                }
                if(a[str[i][k]-'a'] < a[str[j][k]-'a']){
                    t = 1;
                    break;
                }
            }
            if(t == 1){
                strcpy(str[0], str[i]);
                int m = i;
                while(m > j){
                    strcpy(str[m], str[m-1]);
                    m--;
                }
                strcpy(str[j], str[0]);
                break;
            }
        }
    }
    cin >> rank;
    cout << str[rank] << '\n';
    return 0;
}
/*#include <iostream>
#include <cstring>
using namespace std;
int main(){
    char str[100010];
    int sum = 0, i, len;
    while(cin >> str){
        sum = 0;
        len = strlen(str);
        for(i = 0; i < len; i++){
            if(str[i] == 'h'){
                if(str[i+1] == 'z' && str[i+2] == 'n' && str[i+3] == 'u'){
                    sum++;
                    i += 3;
                }
            }
        }
        cout << sum << '\n';
    }
    return 0;
}*/