#include<bits/stdc++.h>
using namespace std;
char s[100001];
int main()
{

	int count=0;
	cin>>s;
	if(strlen(s)<4)
	{
		cout<<"0"<<endl;
	}
	else
	{
	for(int i=0;i<strlen(s)-3;i++)
	{
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')
		{
			count++;
		}
	}
	cout<<count<<endl;
  }  
	return 0;
 } 
