#include<bits/stdc++.h>
using namespace :: std;

const int maxn = 5e5+10;

int n;
vector<long long>a;
long long x;
int q,qu;

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    cin>>n;
    for (int i = 0; i < n; i++)
    {
        cin>>x;
        a.push_back(x);
    }
    cin>>q;
    while (q--)
    {
        cin>>qu;
        long long res=0;
        for (int i = 0; i + 1 < n; i++)
        {
            if (a[i+1]-a[i]<=qu)
            {
                res+=a[i+1]-a[i];
            }else{
                res+=qu;
            }
        }
        res+=qu;
        cout<<res<<endl;
    }
    return 0;
}