#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define lowbit(x)(x&-x)
typedef pair<int,int>PII;
const int INF = 0x3f3f3f3f;
typedef pair<int,string>PIS;
typedef pair<double,double>PDD;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
int lcm(int a,int b){return a*b/gcd(a,b);}
#define snow ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
signed main(){
    snow
    string s;
    cin>>s;
    int cnt=0;
    string end="hznu";
    for(int i=0;i<(int)s.size()-3;i++){
        if(s[i]==end[0]&&s[i+1]==end[1]&&s[i+2]==end[2]&&s[i+3]==end[3])cnt++;
    }
    cout<<cnt<<endl;
    return 0;
}