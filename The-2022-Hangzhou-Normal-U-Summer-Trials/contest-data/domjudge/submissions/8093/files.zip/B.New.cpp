#include<bits/stdc++.h>
#include<algorithm>

using namespace std;

char b[1010][1010];
struct hao
{
	long long shu;
	int xuhao;
}c[1010];
int num[140];

long long shu(char p[])
{
	int l = strlen(p);
	long long i, s = 0, k = 1;
	for (i = l - 1; i >= 0; i --)
	{
		s = s + k * num[p[i]];
		k = k * 26;
	}
	return s;
}

int cmp(struct hao m, struct hao n)
{
	return m.shu < n.shu;
}

int main()
{
	char a[30];

	gets(a);
	int i;
	for (i = 0; i < 26; i ++)
	{
		num[a[i]] = i;
	}
	int q;
	scanf("%d\n", &q);
	for (i = 0; i < q; i ++)
	{
		gets(b[i]);
		c[i].xuhao = i;
		c[i].shu = shu(b[i]);
	}
	sort(c, c + q, cmp);
	int m;
	scanf("%d", &m);
	for (i = 0; i < m; i ++)
	{
		printf("%s\n", b[c[i].xuhao]);
	}
	return 0;
}
