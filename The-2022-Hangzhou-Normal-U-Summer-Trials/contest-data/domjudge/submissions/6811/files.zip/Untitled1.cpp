#include<bits/stdc++.h>

using namespace std;

int main(){
	string s;
	cin >> s;
	int ans = 0;
	for(int i =  0 ; i<s.length() ; i++){
		string tmp = "";
		for(int j = i ; j<i+4 ; j++){
			tmp += s[j];
		}
		//cout << tmp << endl;
		if(tmp == "hznu"){
			ans++;
		}
	}
	cout << ans << endl;
} 
