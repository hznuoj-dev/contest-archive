#include<bits/stdc++.h>
using namespace std;

int main(){
	int n=0,q,t;
	cin>>n;
	int a[n+1];
	for(int i = 1; i <= n; i++){
		cin>>a[i];
	}
	cin>>q;
	for(int i = 0; i < q; i++){
		int cnt=0,ans;
		cin>>t;
		if(n==1){
			ans=t;
		}else{
			for(int j = 1; j < n; j++){
				if(a[j]+t-1<a[j+1]){
					cnt+=a[j+1]-(a[j]+t-1)-1;
				}
				ans=a[n]-a[1]+1+t-1-cnt;
			}
		}
		cout<<ans<<"\n";
	}

	return 0;
}
