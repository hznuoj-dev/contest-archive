#include <bits/stdc++.h>

using namespace std;

string st;
string s[10001];

bool cmp(string a, string b)
{
    int sz;
    if ((int)a.size() > (int)b.size())
        sz = b.size();
    else
        sz = a.size();
    for (int i = 0; i < sz; i++)
    {
        if (st.find(a[i]) < st.find(b[i]))
            return true;
    }
    if ((int)a.size() < (int)b.size())
        return true;
    return false;
}

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    cin >> st;
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> s[i];
    }
    // cout << st.find('c') << endl;
    sort(s + 1, s + 1 + n, cmp);
    int k;
    cin >> k;
    // for (int i = 1; i <= n; i++)
    //     cout << s[i].s << endl;
    cout << s[k];

    return 0;
}