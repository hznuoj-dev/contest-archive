#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
const int N = 1e4;
char level[30];
int lev[200] = {0};

int max(int a, int b) {
	return a > b ? a : b;
}

struct Node {
	char s[N];
	int l;
	bool friend operator <(const Node &a, const Node &b) {
		for (int i = 0; i < max(a.l, b.l); i++) {
			if (a.s[i] != b.s[i]) return lev[a.s[i]] < lev[b.s[i]];
		}
	}
}str[N];

int main (void) {
	int n, k;
	memset(level, 0, sizeof(level));
	cin >> level;
	for (int i = 0; i < strlen(level); i++) lev[level[i]] = i;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> str[i].s;
		str[i].l = strlen(str[i].s);
	}
	cin >> k;
	sort(str, str + n);
	cout << str[k - 1].s << endl;
	
	return 0;
}
