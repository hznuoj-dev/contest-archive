#include<bits/stdc++.h>

using namespace std;

map<char,int>vis;

string to[1005];

bool com(string a,string b){
	for(int i=0;i<min(a.length(),b.length());++i){
		if(a[i] != b[i]){
			return vis[a[i]]<vis[b[i]];
		}
	}
	return a.length()<b.length();
}

void solve()
{
	string s;
	cin>>s;
	for(int i=0;i<s.length();++i){
		vis[s[i]] = i;
	}
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		cin>>to[i];
	}
	sort(to+1,to+1+n,com);
	int k;
	scanf("%d",&k);
	for(int i=0;i<to[k].length();++i){
		cout<<to[k][i];
	}
}

int main()
{
	int t=1;
	//scanf("%d",&t);
	while(t--){
		solve();
	}	
	return 0;
}
