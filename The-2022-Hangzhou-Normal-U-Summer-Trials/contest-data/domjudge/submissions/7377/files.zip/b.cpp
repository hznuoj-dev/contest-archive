#include<iostream>
#include<string>
#include<map>
using namespace std;
string s[1007],a,b,st;
int n,k;
map<char,int> mp;
char c;
int main(){
	for(int i=1;i<=26;i++){
		cin>>c;
		mp[c]=i;
	}
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>s[i];
	}
	cin>>k;
	for(int i=0;i<n;i++){
		for(int j=0;j<n-i-1;j++){
			int len=s[j].length()>s[j+1].length()?s[j+1].length():s[j].length();
			for(int ii=0;ii<len;ii++){
				if(mp[s[j][ii]]>mp[s[j+1][ii]]){
					st=s[j];
					s[j]=s[j+1];
					s[j+1]=st;
					break;
				}else if(mp[s[j][ii]]<mp[s[j+1][ii]]){
					break;
				}
			}
		}
	}
	cout<<s[k-1]<<endl;
	return 0;
} 
