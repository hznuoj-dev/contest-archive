#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <numeric>
#include <bitset>
using namespace std;
#define INF 0x3c3c3c3c // 1010580540, 7f7f7f7f:2139062143
#define llINF 9223372036854775807
const double PI = acos(-1.0);
const double eps = 1e-6;
using ll = long long;
using ull = unsigned long long;
using db = double;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
#define fi first
#define se second
#define pb push_back
#define endl '\n'
#define dbg(a) cout << #a << " = " << (a) << '\n';
#define all(c) (c).begin(), (c).end()
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

const int N = 4e5 + 10;

int e[N], ne[N], h[N], idx;
int siz[N];
bool ok[N];

void add(int a, int b){
    e[idx] = b, ne[idx] = h[a], h[a] = idx++;
}

ll cn2(ll n){
    return n * (n - 1) / 2LL;
}

void dfs(int x, int fa){
    siz[x] = 1;
    for(int i = h[x]; i != -1; i = ne[i]){
        int v = e[i];
        if(v == fa) continue;
        ok[i] = 1;
        dfs(v, x);
        siz[x] += siz[v];
    }
}

int main(){
    IOS
    memset(h, -1, sizeof h);
    int n;
    cin >> n;
    for(int i = 0; i < n - 1; i++){
        int a, b;
        cin >> a >> b;
        add(a, b), add(b, a);
    }
    dfs(1, 0);
    int q;
    cin >> q;
    while(q--){
        int x;
        cin >> x;
        ll ans = cn2(n);
        ll sum = 0;
        // cout << "Hello" << endl;
        for(int i = h[x]; i != -1; i = ne[i]){
            if(!ok[i]) continue;
            int v = e[i];
            ans -= cn2(siz[v]);
            // cout << v << ' ' << siz[v] << endl;
            sum += siz[v];
        }
        ans -= cn2(n - 1 - sum);
        cout << ans << endl;
    }
    return 0;
}