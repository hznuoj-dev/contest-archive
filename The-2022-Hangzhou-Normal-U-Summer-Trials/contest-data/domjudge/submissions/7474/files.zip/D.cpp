#include <bits/stdc++.h>
using namespace std;
#define int long long
int n;int ans[100100];
struct p{
	int v,next;
}st[200010];
int head[100100];
int k,sum[100100];
void add(int a,int b){
	st[++k].v=b;
	st[k].next=head[a];
	head[a]=k;
}int t[100100];
int tem[100010];
void dfs(int x,int fa){
	sum[x]=1;int top;
	for(int i=head[x];i;i=st[i].next){
		int v=st[i].v;
		if(v==fa)continue;
		dfs(v,x);
		sum[x]+=sum[v];
		t[x]+=sum[v];
	}
	if(x==1){
			top=0;
		for(int i=head[x];i;i=st[i].next){
			int v=st[i].v;
			if(v==fa)continue;
			else tem[++top]=sum[v];
		}
		int t1=0;
		int t2=0;
		for(int i=1;i<=top;i++){
		//	printf("%lld ",tem[i]);
	t1+=tem[i],t2+=tem[i]*tem[i];}
		ans[x]+=(t1*t1-t2)/2ll;
	}
	else{
		top=0;
		for(int i=head[x];i;i=st[i].next){
			int v=st[i].v;
			if(v==fa)continue;
			else tem[++top]=sum[v];
		}
		tem[++top]=(n-1ll-t[x]);
		int t1=0;
		int t2=0;
		for(int i=1;i<=top;i++)t1+=tem[i],t2+=tem[i]*tem[i];
		ans[x]+=(t1*t1-t2)/2ll;
	}
}
signed main() 
{
cin>>n;
for(int i=1;i<n;i++){
	int a,b;
	cin>>a>>b;
	add(a,b);
	add(b,a); 
}int q;
dfs(1,0);
cin>>q;
for(int i=1;i<=q;i++){
	int tem;
	cin>>tem;
	printf("%lld\n",ans[tem]+n-1);
}
}
