#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
#define fi first
#define se second
using namespace std;
using LL=long long;
using PII=pair<int,int>;
const int N=1e5+10;
int n,m,k;
char s[55][55];
int dx[]={1,0,-1,0},dy[]={0,1,0,-1};
PII a,b;
bool vis[55][55][55][55];
int d[55][55][55][55];
struct node{
	int ax,ay,bx,by;
};
bool check(PII a){
	return (a.first<1 or a.first>n or a.second<1 or a.second>n or s[a.fi][a.se]=='*');
}
int bfs(){
	queue<node>q;
	q.push({a.fi,a.se,b.fi,b.se});
	vis[a.fi][a.se][b.fi][b.se]=1;
	while(q.size()){
		auto t=q.front();q.pop();
		rep(i,0,3){
			PII x,y;
			x={t.ax+dx[i],t.ay+dy[i]},y={t.bx+dx[i],t.by+dy[i]};
			if(x==y){
				return d[t.ax][t.ay][t.bx][t.by]+1;
			}
			if(check(x))x={t.ax,t.ay};
			if(check(y))y={t.bx,t.by};
			if(!vis[x.fi][x.se][y.fi][y.se]){
				q.push({x.fi,x.se,y.fi,y.se});
				d[x.fi][x.se][y.fi][y.se]=d[t.ax][t.ay][t.bx][t.by]+1;
				vis[x.fi][x.se][y.fi][y.se]=1;
			}
		}
	}
	return -1;
}
signed main(){
	ios::sync_with_stdio(0);
	cin>>n;
	rep(i,1,n)rep(j,1,n){
		cin>>s[i][j];
		if(s[i][j]=='a')a={i,j};
		if(s[i][j]=='b')b={i,j};
	}
	int ans=bfs();
	if(ans==-1)cout<<"no solution";
	else cout<<ans-1;
}
