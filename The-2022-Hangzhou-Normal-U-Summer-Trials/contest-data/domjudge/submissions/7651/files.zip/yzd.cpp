#include <bits/stdc++.h>

using namespace std;

map<char,char>mp;

map<string,string>mp1;

string ans[1005];
//"00000000000000000000000000"

int main() {
	for(int i = 0 ; i<26 ; i++){
		char tmp;
		cin >> tmp;
		mp[tmp] = 'A' + i;
	}
	
	int n;
	cin >> n;
	for(int i = 0 ; i<n ; i++){
		string s;
		cin >> s;
		ans[i] = "AAAAAAAAAAAAAAAAAAAAAAAAAA";
		string tmp = "";
		tmp = ans[i];
		for(int j = 0 ; j<s.length() ; j++){
			char ss = mp[s[j]];
			tmp[j] = ss;
		}
		ans[i] = tmp;
		mp1[ans[i]] = s;
		
		
	}
	
	int k;
	cin >> k;
	sort(ans,ans+n);
	
	/*for(int i = 0 ; i<n ; i++){
		cout << ans[i] << endl;
	}*/
	
	cout << mp1[ans[k-1]] << endl;
	
	
	
	
	
	
}

