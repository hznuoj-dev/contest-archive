#include<bits/stdc++.h>
using namespace std;

const int N=1e5+7,M=1e9+7;
string s;

void solve(){
	int q,op;
	char x,y;
	cin>>q;
	while(q--){
		cin>>op;
		if(op==1){
			cin>>x;
			s+=x;
		}else if(op==2){
			if(s.size()>0) s.erase(s.size()-1);
		}else if(op==3){
			cin>>x>>y;
			int pos=s.find(x);
			while(pos>=0&&pos<=s.size()){
				s[pos]=y;
				pos=s.find(x);
			}
		}
	}
	if(s==""){
		cout<<"The final string is empty"<<'\n';
	}else{
		cout<<s<<'\n';
	}
}

int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int T=1;
	//cin>>T;
	while(T--) solve();
	return 0;
}
