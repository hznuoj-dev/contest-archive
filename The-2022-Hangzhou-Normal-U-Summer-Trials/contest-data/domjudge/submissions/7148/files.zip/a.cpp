#include<iostream>
#include<map>
#include<algorithm>
using namespace std;

const int N=1e3+7;
string str[N];
int temp[N];
int a[N];
map<char,int> mp;

bool cmp(string a, string b)
{
    int l1=a.size(),l2=b.size();
    for(int i=0; i<l1 && i<l2; i++){
        if(mp[a[i]]<mp[b[i]]) return true;
        else if(mp[a[i]]>mp[b[i]]) return false;
    }
    if(l1<l2) return true;
    else return false;
}

void merge_sort(int l, int r)
{
    int mid=(l+r)/2;
    int i=l,j=mid+1;
    for(int k=l; k<=r; k++){
        if(j>r || i<=mid && cmp(str[a[i]],str[a[j]])) temp[k]=a[i++];
        else temp[k]=a[j++];
    }
    for(int k=l; k<=r; k++) a[k]=temp[k];
}

int main()
{
    string s;
	cin >> s;
	for(int i=0; i<(int)s.size(); i++) mp[s[i]]=i;
	int n;
	cin >> n;
	for(int i=0; i<n; i++) cin >> str[i];
	int k;
	cin >> k;
	for(int i=0; i<n; i++) a[i]=i;
	merge_sort(0,n-1);
	cout << str[a[k-1]] << endl;

	return 0;
}
