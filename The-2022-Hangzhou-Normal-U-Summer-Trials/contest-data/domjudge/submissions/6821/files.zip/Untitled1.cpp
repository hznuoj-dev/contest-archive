#include <iostream>
#include <string>
using namespace std;
int main(){
	string s;
	getline(cin,s);
	int cnt=0;
	for(int i=0;i<s.length();){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
			i+=4;
			cnt++;
		}
		else i++;
	} 
	cout<<cnt;
} 
