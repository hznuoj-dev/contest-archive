#include<iostream>
#include<unordered_map>
#include<algorithm>
#include<map>
//#define ll long long
#define ll unsigned long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const double eps = 1e-4;
const ll N = 1e6 + 5;
const int M = 1e6 + 5;
const ll mod = 1e9 + 7;
ll n, a[N], q, dis[N], pre[N];


void solve() {
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	if(n == 1){
		cin >> q;
		ll t;
		for(int i = 1; i <= q; i++){
			cin >> t;
			cout << t << "\n";
		}
		return;
	}
	for (int i = 2; i <= n; i++) {
		dis[i - 1] = a[i] - a[i - 1];
		//if(dis[i - 1] > t) pp = i - 1;
	}
	//sort(dis + 1, dis + 1 + n - 1);
	for (int i = 1; i <= n - 1; i++) {
		pre[i] = pre[i - 1] + dis[i];
	}
	ll t;
	cin >> q;
	for (int i = 1; i <= q; i++) {
		cin >> t;
		if(t == 0) {
			cout << 0 << "\n";
			continue;
		}
		ll l = 1, r = n - 1;
		ll mid, p;
		while (l <= r) {
			mid = (l + r) / 2;
			if (dis[mid] <= t) {
				l = mid + 1;
				p = mid;
			}
			else r = mid - 1;
		}
		cout << a[n] - a[1] + t - (pre[n - 1] - pre[p] - (n - 1 - p) * t) << "\n";
	}
}

signed main()
{
	IOS;
	int tt = 1;
	//cin >> t;
	while (tt--)
	{
		solve();
	}

}
