#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n;cin>>n;
	vector<ll> a(n);
	for(int i=0;i<n;i++) cin>>a[i];
	vector<ll> del;
	for(int i=1;i<n;i++) del.emplace_back(a[i]-a[i-1]);
	vector<ll> sum(n-1);
	sum[0]=del[0];
	for(int i=1;i<n-1;i++) sum[i]=sum[i-1]+del[i];
	int qry;cin>>qry;
	while(qry--){
		ll t;cin>>t;
		int p=upper_bound(del.begin(),del.end(),t)-del.begin()-1;
		cout<<1ll*n*t-(1ll*(p+1)*t-sum[p])<<"\n";
	}
	return 0;
}