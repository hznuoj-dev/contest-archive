#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef long long ll;
const int N=2e5+7;
int a[N],pre[N];
void solve(){
	int n,k;
	cin >> n >> k;
	for (int i=1;i<=n;i++){
		cin >> a[i];
		a[i]=a[i]%k;
	}
	for (int i=1;i<=n;i++){
		pre[i]=pre[i-1]+a[i];
	}
	int ans=0;
	for (int i=1;i<=n;i++){
		int t=pre[n]-pre[i-1];
		ans+=t/k;		
	}
	for (int i=1;i<=n;i++){
		if (a[i]==0) ans++;
	}
	cout << ans << '\n';

}

signed main(){
	ios::sync_with_stdio(0);
	int t=1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}

