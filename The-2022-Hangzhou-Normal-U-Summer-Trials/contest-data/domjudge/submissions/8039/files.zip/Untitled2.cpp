#include<iostream>
#include<string>
#include<cstdio>
#include<map>
#include<cstring>
#include<algorithm>
typedef long long ll;
using namespace std;
string s[1007];
int main(){
	map<char,int >mp;
	char str[26];
	cin>>str;
//	getchar();
	
	for(int i = 0;i<26;i++){
	mp[str[i]]=i+1;
}


int n;
cin >> n;
for(int i = 0;i<n;i++)
cin >> s[i];

int t;
cin >> t;
if(n==1)
{
	cout << s[0];
}
else{

for(int i = 0;i<n;i++)
{
	int big = 0;
	int flag = 0;
	for(int j = 0;j<n;j++)
	{
//		if(j==i)
//		break;
		int temp = 0;
		if(s[i].length()==s[j].length()){
		
		while(s[i][temp]==s[j][temp]){
		temp++;
		if(temp>s[i].length())
		break;
	}
		if(mp[s[i][temp]]>mp[s[j][temp]]){
		big ++;}
		
	}
	else if(s[i].length()>s[j].length()){
		while(s[i][temp]==s[j][temp]){
			temp++;
			if(temp>s[j].length()){
				big++;
				break;
			}
		}
		
	}
//		flag = 1;}
		
	}
	
	if(big == t-1)
	{
		cout << s[i];
		break;
	}
}
  
}
} 
