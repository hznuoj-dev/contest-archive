#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 5e5 + 5;

vector<int>g[maxn];
int cnt[maxn], ans[maxn], n; 
void dfs(int rt, int fa){
	vector<int>e;
	for(int i = 0; i < g[rt].size(); ++i){
		int to = g[rt][i];
		if(to == fa) continue;
		dfs(to, rt);
		cnt[rt] += cnt[to];
		e.push_back(cnt[to]);
	}
	for(int i = 0; i < e.size(); ++i) ans[rt] += (n - e[i] - 1) * e[i];
	ans[rt] += (n - cnt[rt]) * (cnt[rt] - 1);
	ans[rt] = ans[rt] / 2 + n - 1;
}

void solve(){
	cin >> n;
	for(int i = 1; i <= n; ++i) cnt[i] = 1;
	for(int i = 1; i < n; ++i){
		int a, b; cin >> a >> b;
		g[a].push_back(b);
		g[b].push_back(a);
	}
	dfs(1, 0);
	int k; cin >> k;
	while(k--){
		int e; cin >> e;
		cout << ans[e] << endl;
	} 
} 

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
