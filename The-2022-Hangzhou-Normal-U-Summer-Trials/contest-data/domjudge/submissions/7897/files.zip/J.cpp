#include <bits/stdc++.h>
#define N 100005
using namespace std;
int q,n,x,y;
int f[N][26];
char c1,c2;
char ans[N];
int main(){
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		int t;
		scanf("%d",&t);
		if(t==2){
			n--;
			for(int j=0;j<26;j++)
				f[n][j]=f[n+1][f[n][j]];
		}
		else if(t==1){
			scanf(" %c",&c1);
			ans[++n]=c1;
			for(int j=0;j<26;j++)
				f[n][j]=j;
		}else{
			scanf(" %c %c",&c1,&c2);
			for(int j=0;j<26;j++)
				if(f[n][j]==c1-'a')f[n][j]=c2-'a';
		}
	}
	for(int i=n;i;i--){
		ans[i]=f[i][ans[i]-'a']+'a';
		for(int j=0;j<26;j++)
			f[i-1][j]=f[i][f[i-1][j]];
	}
	if(n)printf("%s",ans+1);
	else puts("The final string is empty");
	return 0;
}
