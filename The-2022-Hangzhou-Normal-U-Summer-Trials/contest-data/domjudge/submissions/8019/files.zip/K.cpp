#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <numeric>
#include <bitset>
using namespace std;
#define INF 0x3c3c3c3c // 1010580540, 7f7f7f7f:2139062143
#define llINF 9223372036854775807
const double PI = acos(-1.0);
const double eps = 1e-6;
using ll = long long;
using ull = unsigned long long;
using db = double;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
#define fi first
#define se second
#define pb push_back
#define endl '\n'
#define dbg(a) cout << #a << " = " << (a) << '\n';
#define all(c) (c).begin(), (c).end()
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

typedef pair<double, int> pdi;

const int N = 3e3 + 10;

int v[6];

double dis[N];
bool vis[N];
struct point{
    double x, y;
    int t;
}p[N];

double getdis(point& a, point &b){
    return sqrt(double(a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}

int main(){
    IOS
    int n;
    cin >> n;
    for(int i = 1; i <= 4; i++) cin >> v[i];
    cin >> v[0];
    int s, t;
    cin >> s >> t;
    for(int i = 1; i <= n; i++){
        cin >> p[i].x >> p[i].y;
        if(p[i].x > 0 && p[i].y > 0) p[i].t = 1;
        else if(p[i].x < 0 && p[i].y > 0) p[i].t = 2;
        else if(p[i].x < 0 && p[i].y < 0) p[i].t = 3;
        else if(p[i].x > 0 && p[i].y < 0) p[i].t = 4;
        dis[i] = llINF;
    }
    priority_queue<pdi, vector<pdi>, greater<pdi>> q;
    q.push({0, s});
    while(!q.empty()){
        double d = q.top().first;
        int u = q.top().second;
        q.pop();
        if(vis[u]) continue;
        vis[u] = 1;
        for(int i = 1; i <= n; i++){
            if(!vis[i]){
                double dist = getdis(p[u], p[i]);
                if(p[u].t == p[i].t){
                    if(dis[i] > d + (dist / (double)v[p[i].t])){
                        dis[i] = d + (dist / (double)v[p[i].t]);
                        q.push({dis[i], i});
                    }
                }
                else{
                    if(dis[i] > d + (dist / (double)v[0])){
                        dis[i] = d + (dist / (double)v[0]);
                        q.push({dis[i], i});
                    }
                }
            }
        }
    }
    printf("%.10lf\n", dis[t]);
    return 0;
}