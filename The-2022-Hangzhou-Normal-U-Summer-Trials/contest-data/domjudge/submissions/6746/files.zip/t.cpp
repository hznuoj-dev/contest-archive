#include<iostream>
using namespace std;
const int N = 2e5 + 10;
char s[N];
const char *t = "hznu";
int main(){
    scanf("%s", s);
    int cnt = 0;
    for(int i = 0; s[i]; i++){
        bool flag = true;
        for(int j = 0; j < 4; j++){
            if(s[i + j] != t[j]){
                flag = false;
                break;
            }
        }
        cnt += flag;
    }
    printf("%d", cnt);
}