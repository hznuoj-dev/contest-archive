#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	string s;cin>>s;
	int n=s.size();
	int ans=0;
	for(int i=0;i<n-3;i++)
	if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
		ans++;
	}
	cout<<ans<<"\n";
	return 0;
}