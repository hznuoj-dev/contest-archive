#define _CRT_SECURE_NO_WARNINGS
#include<bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using db = double;
using vi = vector<int>;
using mii = map<int, int>;
using PII = pair<int, int>;
using PLL = pair<ll, ll>;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const ll mod = 1e9 + 7;
const int MAXN = 5e5 + 10;
#define mem(a,b) memset(a,b,sizeof(a));

//char s[MAXN];
ll a[MAXN];
ll b[MAXN];
int main() {
	int n;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		scanf("%lld", &a[i]);
		b[i - 1] = a[i] - a[i - 1];
	}
	b[n] = INF;
	
	int q;
	cin >> q;
	while (q--) {
		ll t;
		scanf("%lld", &t);
		ll d = upper_bound(b + 1, b + n, t) - b;
		ll ans = a[d] - a[1] + (n - d + 1) * t;
		printf("%lld\n", ans);
	}


	return 0;
}