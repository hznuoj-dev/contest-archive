#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[500007];
ll b[500007];
int main()
{
	int n;
	cin>>n;
	cin>>a[0];
	b[0]=0;
	for(int i=1;i<n;i++)
	{
		cin>>a[i];
		b[i]=a[i]-a[i-1];
	}
	int q;
	cin>>q;
	ll gg;
	ll temp=0;
	ll cnt=0;
	int flag=0;
	while(q--)
	{
		flag=0;
		cin>>gg;
		ll l=0;
		ll r=n;
		ll mid=(l+r)/2;
		while(l!=r)
		{
			mid=(l+r)/2;
			if(mid==0)
			break;
			if(gg>b[mid])
			{
				l=mid+1;
			}
			else if(gg<b[mid])
			{
				if(gg>=b[mid-1])
				{
					temp=mid;
					cnt=a[mid-1]+gg-a[0];
					flag=1;
					break;
				}
				else
				r=mid-1;
			}
			else
			{
				temp=mid;
				cnt=a[mid-1]+gg-a[0];
				flag=1;
				break;
			}
		}
		if(gg==1)
		{
			cout<<n<<endl;
		}
		else if(!flag)
		{
			cout<<a[n-1]+gg-a[0]<<endl;
		}
		else
		{
			cout<<cnt+gg*(n-temp)<<endl;
		}
	}
	
}
