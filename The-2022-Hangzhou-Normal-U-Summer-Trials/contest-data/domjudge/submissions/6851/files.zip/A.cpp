#include<bits/stdc++.h>
using namespace std;
string s;
int main(){
	int ans = 0, cnt = 0;
	cin >> s;
	while(s.find("hznu", cnt) != s.npos){
		ans++;
		cnt = s.find("hznu", cnt);
		cnt++;
	}
	cout << ans << '\n';
	return 0;
} 
