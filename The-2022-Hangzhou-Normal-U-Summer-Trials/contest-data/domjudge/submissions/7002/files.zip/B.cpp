#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> PII;
const int INF = 0x3f3f3f3f, MAXN = 1e6 + 10;
string table;
map<char,int> mp;
bool cmp(string a, string b) {
    for(int i = 0; i < a.size() && i < b.size(); i ++) {
        if(a[i] != b[i]) {
            return mp[a[i]] < mp[b[i]];
        }
    }
    return a.size() < b.size();
}
void solve() {
    cin >> table;
    for(int i = 0; i < 26; i ++) {
        mp[table[i]] = i;
    }
    int n, k;
    cin >> n;
    vector<string> s(n);
    for(int i = 0; i < n; i ++) {
        cin >> s[i];
    }
    cin >> k;
    sort(s.begin(), s.end(), cmp);
    cout << s[k - 1];
}
int main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int _ = 1;
    //cin >> _;
    while(_ --) {
        solve();
    }
    return 0;
}