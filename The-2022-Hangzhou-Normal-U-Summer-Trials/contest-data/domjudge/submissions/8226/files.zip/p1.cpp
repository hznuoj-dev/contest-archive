#include<bits/stdc++.h>
using namespace std;

long long a[500001];

int main(){
	long long n=0,q;
	long long t,cur,pre,ans;
	cin>>n;
	
	
	cin>>pre;
	cur=pre;
	
	for(long long i = 1; i < n; i++){
		scanf("%lld",&cur);
		a[i]=cur-pre;
		pre=cur;
	}
	

	scanf("%lld",&q);
	for(long long i = 0; i < q; i++){
		cin>>t;
		int l = 1,r = n-1,mid=1;
		while(l<=r){
			mid=(l+r)/2;
			if(a[mid]<t){
				l=mid+1;
			}else if(a[mid]>t){
				r=mid-1;
			}else{
				break;
			}
		}
		while(a[mid]<=t&&mid<n-1)mid++;
		ans=a[mid]+(n-mid)*t;
		cout<<ans<<"\n";
	}

	return 0;
}
