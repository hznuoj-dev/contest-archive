#include <stdio.h>
#include <stdlib.h>

int main()
{
	long long n, k, *a, *count, x[100000008];
	long long cnt = 0, sum = 0, max = 0;
	
	scanf("%lld %lld", &n, &k);
	a = (long long *) malloc (n * sizeof(long long));
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &a[i]);
		if (max < a[i] % k)
		{
			max = a[i] % k;
		}
	}
	count = (long long *) malloc (max * sizeof(long long));
	for (int i = 0; i < k; i++)
	{
		count[i] = 0;
	}
	for (int i = 0; i < n; i++)
	{
		sum += a[i];
		if (sum % k == 0)
		{
			cnt++;
		}
		cnt += count[sum % k];
		count[sum % k]++;
	}
	printf("%lld", cnt);
	
	return 0;
}
