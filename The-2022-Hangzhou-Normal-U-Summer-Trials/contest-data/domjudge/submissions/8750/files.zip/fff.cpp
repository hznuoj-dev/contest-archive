#include<bits/stdc++.h>
using namespace std;
long long int a[100010]={0};
int main(){
	long long int n,k;
	cin>>n>>k;
	for(long long int i=0;i<n;i++){
		cin>>a[i];
	}
	sort(a,a+n);
	long long int sum=0,ans=0;
	for(long long int i=0;i<n;i++){
		sum=0;
		for(long long int j=i;j<n;j++){
			sum+=a[j];
			if(sum%k==0){//&&s[sum]!='1'
				//cout<<sum<<" i = "<<i+1<<" j = "<<j+1<<endl;
				//s[sum]='1';
				ans++;
			}
		}
	}
	cout<<ans<<endl;
} 
