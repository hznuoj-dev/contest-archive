#include<bits/stdc++.h>
typedef long long ll;
#define INF 0x7f7f7f7f //2139062143
#define llINF 1223372036854775807
#define pii pair<int,int > 
using namespace std;
const int N=2e5+10,M=1010,mod=1e9+7;
int n,m,k,t;
int maxn,minn,temp,sum; 
int a[N],b[N]; 
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	string s;
	cin>>s;
	if(s.size()<4)
		cout<<0<<endl;
	else
	{
		int ans=0;
		for(int i=0;i<s.size()-3;i++)
		{
			if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')
				ans++;	
		}
		cout<<ans;
	}
}



