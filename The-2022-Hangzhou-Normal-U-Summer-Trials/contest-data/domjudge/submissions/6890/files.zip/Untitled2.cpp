#include<bits/stdc++.h>
#include<unordered_map>
#define ll long long
#define ull unsigned long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const double eps = 1e-4;
const ll N = 1e6 + 5;
const int M = 1e5 + 5;
const int mod = 1e9 + 7;
string s; 

void solve() {
   cin >> s;
   ll cnt = 0;
   for(int i = 0; i < s.size(); i++){
   	   if(s[i] == 'h'){
   	   	if(i + 3 < s.size())
   	   	   for(int j = i + 1; j <= i + 3; j++){
   	   	   	 if(s[j] == 'z' && s[j + 1] == 'n' && s[j + 2] == 'u'){
   	   	   	 	cnt++;
				 }
			}
	   }
   }
   cout << cnt <<"\n";
}

signed main()
{
	IOS;
	int t = 1;
	//cin >> t;
	while (t--)
	{
		solve();
	}

}
