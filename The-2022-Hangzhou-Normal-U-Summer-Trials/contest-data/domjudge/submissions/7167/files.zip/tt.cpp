#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
const int N = 5e5 + 10;
ll a[N];
ll gap[N];
ll pre[N];
int main(){
    int n;
    scanf("%d", &n);
    for(int i = 1; i <= n; i++)
        scanf("%lld", a + i);
    for(int i = 2; i <= n; i++)
        gap[i - 1] = a[i] - a[i - 1];
    for(int i = 1; i <= n; i++)
        pre[i] = pre[i - 1] + gap[i];
    int t;
    scanf("%d", &t);
    while(t--){
        ll g;
        scanf("%lld", &g);
        int idx = lower_bound(gap, gap + n, g) - gap;
        idx--;
        printf("%lld\n", pre[idx] + (n - idx) * g);
    }
}