#include<stdio.h>
#include<string.h>
int main(){
	char s[100010];
	scanf("%s",&s);
	int i,len,sum=0;
	len = strlen(s);
	for(i=0;i+3<len;i++){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
			sum++;
		}
	}
	printf("%d",sum);
	return 0;
}
