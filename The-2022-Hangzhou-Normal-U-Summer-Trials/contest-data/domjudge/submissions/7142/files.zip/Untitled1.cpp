#include<bits/stdc++.h>
#define ll long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const int N = 2e5 + 5;
const double eps = 1e-5;
const int mod = 1e9 + 7;

ll n;
string ss[1003];
map<char, char> mp;
struct node {
	string s;
	ll id;
	bool operator < (const node& b) const
	{
		return s < b.s;
	}
}a[1003];

void solve()
{
	string s;
	cin >> s;
	for (ll i = 0; i <= 25; i++)
		mp[s[i]] = 'a' + i;
	cin >> n;
	for (ll i = 1; i <= n; i++)
	{
		cin >> ss[i];
		a[i].id = i;
		for (ll j = 0; j < ss[i].size(); j++)
			a[i].s += mp[ss[i][j]];
	}
	sort(a + 1, a + 1 + n);
	//for(ll i = 1; i <= n; i++)
	//	cout << a[i].s <<' ' << a[i].id << '\n'; 
	ll k;
	cin >> k;
	cout << ss[a[k].id];
}

int main()
{
	IOS;
	ll t = 1;
	//cin >> t;
	while (t--)
		solve();
}
