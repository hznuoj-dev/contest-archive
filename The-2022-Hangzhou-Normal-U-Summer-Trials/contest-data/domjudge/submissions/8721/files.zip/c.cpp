#include<bits/stdc++.h>
#define ll long long
using namespace std;

ll c[500050], a[500050];
ll n, x;
ll q, t;


int main()
{
    cin >> n;
    for(ll i = 1;i <= n;i++)
    {
        cin >> a[i];
        if(i != 1)
        {
            c[i - 1] = a[i] - a[i - 1];
        }
    }
    cin >> q;
    for(ll i = 0;i < q;i++)
    {
        cin >> t;
        ll pos = upper_bound(c + 1, c + n + 1, t) - (c + 1);
        if(pos >= n)
            cout << a[n] - a[1] + t << endl;
        else
            cout << a[pos + 1] - a[1] + (n - pos) * t << endl;
    }

    return 0;
}