#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int maxn=1e5+10;

int main(){
	int n;
	int k;
	map<int,ll>m;
	scanf("%d%d",&n,&k);
	ll a;
	ll cut=0;
	ll sum=0;
	m[0]=1;
	for(int i=0;i<n;i++){
		scanf("%lld",&a);
		cut=(cut+a)%k;
		if(m[cut]){
			sum+=m[cut];
		}
		m[cut]++;
	}
	printf("%lld",sum);
} 

