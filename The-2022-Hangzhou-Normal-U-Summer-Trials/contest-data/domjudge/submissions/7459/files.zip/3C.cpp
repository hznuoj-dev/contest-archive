#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

const int N=5e5+10;
int n,q;
ll a[N],s[N],t;

int main()
{
	cin>>n;
	for(int i=0;i<n;i++) cin>>a[i];
	for(int i=0;i<n-1;i++) s[i]=a[i+1]-a[i];
	
	cin>>q;
	while(q--)
	{
		cin>>t;
		ll l=0,r=n-2;
		while(l<r)
		{
			ll mid=l+r >> 1;
			if(s[mid]<t) l=mid+1;
			else r=mid;
		}
		if(t>a[l]) l++;
		ll ans=a[l]-a[0];
		//cout<<"**"<<ans<<' '<<l<<endl;
		if(l<=n-1) ans+=t*(n-l);
		cout<<ans<<endl;
	}
	
	return 0;
}
