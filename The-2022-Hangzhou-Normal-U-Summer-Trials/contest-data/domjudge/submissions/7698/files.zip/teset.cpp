#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(0),cin.tie(0);
#define x first
#define y second
using namespace std;
typedef long long ll;
typedef pair<int,int>PII;
const int N=5e5+7,mod=1e9+7;

int n,m;
ll a[N],b[N],sum[N];

void solve(){
    scanf("%d",&n);
    for(int i=1;i<=n;i++)scanf("%lld",&a[i]);
    for(int i=1;i<n;i++)b[i]=a[i+1]-a[i];
    for(int i=1;i<n;i++)sum[i]=sum[i-1]+b[i];
    int q;scanf("%d",&q);
    for(int i=1;i<=q;i++){
        ll t;scanf("%lld",&t);
        ll ans=0;
        if(t<b[1]){
            ans=t*n;
            cout<<ans<<endl;
            continue;
        }
        ll l=1,r=n-1;
        while(l<r){
            ll mid=(l+r+1)/2;
            if(b[mid]<=t)l=mid;
            else r=mid-1;
        }
        ans=sum[l]+t*(n-1-l)+t;
        cout<<ans<<endl;
    }
}

int main(){
    solve();
    return 0;
}