#include <bits/stdc++.h>
#include<unordered_map>
using namespace std;
const int maxn=5e3+10;
const int mod=1e9+7;
#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define int  long long
#define double long double
double v[10];
struct Point{
	double x,y;
	int flag;
};
double dis[maxn][maxn];
double caldis(Point x,Point y){
	double ans=(x.x-y.x)*(x.x-y.x)+(x.y-y.y)*(x.y-y.y);
	return sqrt(ans);
}
Point no[maxn];
signed main(){
	//fast;
	int n;scanf("%lld",&n);
	for(int i=1;i<=4;i++)scanf("%lf",&v[i]);
	scanf("%lf",&v[0]);
	int st,ed;scanf("%lld%lld",&st,&ed);
	for(int i=1;i<=n;i++){
		scanf("%lf%lf",&no[i].x,&no[i].y);
		if(no[i].x>=1&&no[i].y>=1)no[i].flag=1;
		else if(no[i].x<=-1&&no[i].y>=1)no[i].flag=2;
		else if(no[i].x<=-1&&no[i].y<=-1)no[i].flag=3;
		else if(no[i].x>=1&&no[i].y<=-1)no[i].flag=4;
		else no[i].flag=0;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dis[i][j]=caldis(no[i],no[j]);
			if(no[i].flag==no[j].flag){
				dis[i][j]=dis[i][j]/v[no[i].flag];
			}
			else{
				dis[i][j]=dis[i][j]/v[0];
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dis[st][j]=min(dis[st][i]+dis[i][j],dis[st][j]);
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dis[st][j]=min(dis[st][i]+dis[i][j],dis[st][j]);
		}
	}
	printf("%.10lf\n",dis[st][ed]);
	system("pause");
}