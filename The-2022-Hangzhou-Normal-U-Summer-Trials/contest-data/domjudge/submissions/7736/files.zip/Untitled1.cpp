#include<iostream>
#include<cstring>
#include<vector>
//#include<map>
using namespace std;

int main()
{
	int n,t;
	cin>>n>>t;
	vector<int>v;
	for(int i=0;i<n;i++){
		int x;
		cin>>x;
		v.push_back(x);
	}
	int count=0;
	for(int i=0;i<n;i++){
		for(int j=i;j<n;j++){
			int sum=0;
			for(int k=i;k<=j;k++){
				sum+=v[k]%3;
			}
			if(sum%t==0) count++;
		}
	}
	cout<<count<<endl;
	return 0;
}
