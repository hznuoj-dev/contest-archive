#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 1e5 + 7;

ll a[N];
ll c[N];
ll pre[N];
map<ll,int> cnt;
void solve() {
	int n,k;
	cin >> n >> k;
	ll ans = 0;
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
		pre[i] = (pre[i - 1] + a[i]) % k;
		cnt[pre[i]]++;
	}
	ll tmp = 0;
	for (int i = 1; i <= n; ++i) {
		ans += cnt[tmp];
		cnt[pre[i]]--;
		tmp = (tmp + a[i]) % k;
	}
	cout << ans;
}
int main() {
	ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
/*
6 3
0 1 2 4 7 7
*/
