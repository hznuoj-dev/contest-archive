#include<bits/stdc++.h>
using namespace std;
#define dbg(x) cerr << #x << " -> " << x << '\n'
typedef unsigned long long ull;
typedef long long ll;
const int N = 1e5 + 10;
const int SIZE = 1110;
int n,k;
int a[N];
int pre[N];
int main(){
    cin>>n>>k;
    pre[0]=0;
    for(int i=1;i<=n;++i){
        cin>>a[i];
        pre[i]=a[i]+pre[i-1];

    }
    int i = 0,j = n;
    ll ans=0;
    for(int i=1;i<=n;++i){
    	for(int j=i;j<=n;++j){
    		if((pre[j]-pre[j-i])%k==0){
    			ans++;
    			cout<<"l->"<<j-i<<"r->"<<j<<endl;
			}
		}
	}
//    while(i<=n){
//        while((pre[j]-pre[i])%k!=0&&(pre[j]-pre[i]!=0)&&j<=n ){
//            j++;
//        }
//        
//   }
   cout<<ans<<endl;
    
}
/*
8 3
3 3 3 3 3 3 3 3
*/