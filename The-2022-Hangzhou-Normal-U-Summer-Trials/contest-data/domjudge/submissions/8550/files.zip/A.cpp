#include<bits/stdc++.h>
#define ll long long

using namespace std;
const int N = 1e5 + 10;
ll a[N], b[N];
map<int, int>p,x;
int main()
{
	int n;
	ll k;
	cin >> n >> k;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		b[i] = (b[i - 1] + a[i])%k;
		if (p.find(b[i]) == p.end())
			p[b[i]] = 1;
		else
			p[b[i]]++;
	}
	int sum = p[0];
	int m = 0;
	for (int i = 1; i <= n; i++)
	{
		m = b[i];
		if (x.find(m) == x.end())
		{
			x[m] = 1;
		}
		else
		{
			x[m]++;
		}
		sum += p[m] - x[m];
	}
	cout << sum << endl;
	return 0;
}
