#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n;cin>>n;
	vector<ll> a(n);
	for(int i=0;i<n;i++) cin>>a[i];
	vector<ll> del;del.emplace_back(0);
	for(int i=1;i<n;i++) del.emplace_back(a[i]-a[i-1]);
	vector<ll> sum(n);
	for(int i=1;i<n;i++) sum[i]=sum[i-1]+del[i];
	int qry;cin>>qry;
	while(qry--){
		ll t;cin>>t;
		if(t==0){cout<<"0\n";continue;}
		int p=upper_bound(del.begin(),del.end(),t)-del.begin()-1;
		cout<<1ll*n*t-(1ll*p*t-sum[p])<<"\n";
	}
	return 0;
}