#include<iostream>
#include<algorithm>
#include<cstring>
#include<map>
#include<set>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
using namespace std;
typedef long long ll;
int n;
ll a[500010];
ll ans[500010];
map<ll, int >mp;
map<ll, ll>sum;
map<ll, ll>bj;
map<ll, ll>mp2;//类似前缀和
set<ll>xb;
int main() {
	IOS;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
	}
	for (int i = 1; i <= n - 1; i++) {
		ll dif = a[i + 1] - a[i];
		mp[dif]++;
	}
	int cur = n;
	for (auto it : mp) {
		bj[it.first] = cur;
		cur -= it.second;
	}
	ll pre = 0;
	ll ppp = 0;
	for (auto it : bj) {
		mp2[it.first] = it.second * (it.first - pre) + ppp;
		pre = it.first;
		ppp = mp2[pre];
		xb.insert(it.first);
	}
	//for (auto it : mp2) {
	//	cout << it.first << " " << it.second << "\n";
	//}

	int q; cin >> q;
	while (q--) {
		ll t; cin >> t;
		auto idx = xb.upper_bound(t);
		auto tmp = idx;
		tmp--;
		//cout << mp2[(*tmp)] << "* " << (t - (*tmp)) * bj[(*idx)] << "\n";
		if(idx != xb.end())
		cout << mp2[(*tmp)] + (t - (*tmp)) * bj[(*idx)] << "\n";
		else {
			cout << mp2[(*tmp)] + (t - (*tmp)) * 1 << "\n";
		}
		//cout << (*idx) << " " << (*tmp) << "\n";
		//cout << (*idx).first << " " << (*idx).second << " " << (*tmp).first << " " << (*tmp).second << "\n";
		//cout << (*idx).second + ((*tmp).first - (*idx).first) * bj[(*tmp).first] << "\n";
	}
}