#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e3 + 7;
string s[maxn];
string st;
int com[maxn];
bool cmp(const string& a, const string& b)
{
	for (int i = 0; i < a.size(); i++)
	{
		if (com[a[i]] < com[b[i]])
			return 1;
		else if (com[a[i]] > com[b[i]])
			return 0;
	}
	return 1;
}
int main()
{
	cin >> st;
	for (int i = 0; i < st.size(); i++)
	{
		com[st[i]] = i;
	}
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> s[i];
	}
	sort(s, s + n, cmp);
	int k;
	cin >> k;
	cout << s[k - 1];
}