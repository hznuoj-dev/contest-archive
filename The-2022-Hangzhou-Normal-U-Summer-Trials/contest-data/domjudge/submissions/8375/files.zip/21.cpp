#include<iostream>

using namespace std;

int main()
{
	int n; 
	cin >> n;
	long long arr[n], b[n];
	for(int i = 0 ; i < n; i++)
	{
		cin >> arr[i];
	}
	for(int i = 0; i < n - 1; i++)
	{
		b[i] = arr[i + 1] - arr[i];
	}
	int m;
	cin >> m;
	int k;
	while(m--)
	{
		long long num, sum;
		cin >> num;
		sum = num;
		int l = 0, r = n - 2;
		while(l <= r)
		{
			int mid = (l + r) / 2;
			if(b[mid] > num)
			{
				r = mid - 1;
			}
			else
			{
				l = mid + 1;
			}
		}
		sum += arr[l] - arr[0];
		sum += num * (n - 2 - r);
		cout << sum << endl;
	}
}
