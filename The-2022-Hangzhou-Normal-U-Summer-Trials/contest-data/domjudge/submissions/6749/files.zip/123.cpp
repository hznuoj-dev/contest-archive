#include<bits/stdc++.h>
#define int long long
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;
int t,n,m;
char str[100010];
signed main(){
	FAST
	cin>>str;
	n=strlen(str);
	int sum=0;
	for(int i=3;i<n;i++){
		if(str[i-3]=='h'&&str[i-2]=='z'&&str[i-1]=='n'&&str[i]=='u')sum++;
	}
	cout<<sum<<endl;
} 
