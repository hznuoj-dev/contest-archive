#include<bits/stdc++.h>
using namespace std;
int n,tmp;
int ty,l;
char x,y;
char ans[100005];
int p[28][100005],pp[28],tmp1,tmp2;
bool flag;
string f="The final string is empty";
int main(){
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>ty;
		if(ty==2){
			if(l>0){
				pp[ans[l]-'a']--;
				l--;
			}
		}
		else if(ty==1){
			cin>>x;
			ans[++l]=x;
			p[x-'a'][++pp[x-'a']]=l;
		}
		else{
			cin>>x>>y;
			tmp1=x-'a';
			tmp2=y-'a';
			tmp=pp[tmp1];
			for(int j=1;j<=tmp;j++){
				ans[p[tmp1][j]]=y;
				p[tmp2][++pp[tmp2]]=p[tmp1][j];
			}
			pp[tmp1]=0;
			sort(p[tmp2]+1,p[tmp2]+1+pp[tmp2]);
		}
	}
	if(l==0){
		cout<<f;
	}
	else{
		for(int i=1;i<=l;i++){
			cout<<ans[i];
		}
	}
	return 0;
}
