#include <bits/stdc++.h>
#define ll long long

using namespace std;
typedef pair<int, int> PII;
typedef pair<char, char> PCC;

const int N = 1e6 + 10, mod = 1e9 + 7;

ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a;}
ll lcm(ll a, ll b) { return a * b / gcd(a, b); }
ll qmi(ll a, ll b) { ll res = 1; while(b) { if(b & 1) res = (res * a) % mod; a = (a * a) % mod; b >>= 1;} return res % mod; }

map<char, int> mp;
int n, k;
string s[1010];
map<string, string> ans;

bool cmp(string a, string b)
{
	if(a.size() < b.size()) return true;
	else if(a.size() > b.size()) return false;
	if(a.size() == b.size())
	{
		for (int i = 0; i < a.size(); i ++)
		{
			if(mp[a[i]] < mp[b[i]])
				return true;
		}
		return false;
	}
}

void solve()
{
	string t;
	cin >> t;
	for (int i = 0; i < t.size(); i ++)	mp[t[i]] = i;

	cin >> n;
	for (int i = 1; i <= n; i ++)
	{
		cin >> s[i];
	}

	cin >> k;
	sort(s + 1, s + 1 + n, cmp);
	cout << s[k] << '\n';
}

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
    int T = 1;
	//cin >> T;
	while(T --)
	{
		solve();
	}
    return 0;
}
