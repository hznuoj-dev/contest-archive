#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 5e5+7;
ll a[N];
ll s[N];
int main(){
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
        if(i>=2)s[i-1] = a[i]-a[i-1];
    }
    int q;
    cin>>q;
    while(q--){
        ll t;
        cin>>t;
        ll sum=t;
        for(int i=1;i<=n-1;i++){
            if(t-s[i]>0)sum+=s[i];
            else sum+=t;
        }
        cout<<sum<<endl;
    }
    return 0;
}