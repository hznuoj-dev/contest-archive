#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define moonoom ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
const ll MAXN=5e5+10;

signed main(){
	moonoom;
	long int q;
	cin>>q;
	vector<char>ans;
	vector<char>::iterator pos;
	while(q--){
		int op;char a,b;
		cin>>op;
		if(op==1){
			cin>>a;
			ans.push_back(a);
		}
		else if(op==2){
			if(!ans.empty()){
				ans.pop_back();
			}
		}
		else if(op==3){
			cin>>a>>b;
			for(pos=ans.begin();pos!=ans.end();pos++){
				if(*pos==a)*pos=b;
			}
		}
	}
	if(ans.empty()){
		cout<<"The final string is empty"<<endl;
	}
	else {
		for(pos=ans.begin();pos!=ans.end();pos++){
			cout<<*pos;
		}cout<<endl;
	}
}
