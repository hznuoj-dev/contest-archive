#include<bits/stdc++.h>
using namespace std;

double v1,v2,v3,v4,v0;
struct po
{
	double x,y;
	double ti;
	int no;
}hjj[3005];

double dis(int a,int b)
{
	return sqrt(pow(hjj[a].x-hjj[b].x,2)+pow(hjj[a].y-hjj[b].y,2));
}


double math(int i,int j)
{
	double add;
	if(hjj[i].x*hjj[j].x>0&&hjj[i].y*hjj[j].y>0)
	{
		if(hjj[i].x>0&&hjj[i].y>0)
		{
			add=dis(i,j)/v1;
		}
		else if(hjj[i].x<0&&hjj[i].y>0)
		{
			add=dis(i,j)/v2;
		}
		else if(hjj[i].x>0&&hjj[i].y<0)
		{
			add=dis(i,j)/v4;
		}
		else if(hjj[i].x<0&&hjj[i].y<0)
		{
			add=dis(i,j)/v3;
		}
	}
	else
	{
		add=dis(i,j)/v0;
	}
	return add;
}

bool cmp(po a,po b)
{
	return a.ti<b.ti;
}

int main()
{
	int n;
	cin>>n;
	cin>>v1>>v2>>v3>>v4>>v0;
	int s,t;
	cin>>s>>t;
	for(int i=1;i<=n;i++)
	{
		cin>>hjj[i].x>>hjj[i].y;
		hjj[i].no=i;
	}
	for(int i=1;i<=n;i++)
	{
		hjj[i].ti=math(s,i);
	}
	for(int i=2;i<=n;i++)
	{
		sort(hjj+i,hjj+n+1,cmp);
		for(int j=i+1;j<=n;j++)
		{
			hjj[j].ti=min(hjj[j].ti,hjj[i].ti+math(j,i));
		}
	}
	for(int i=1;i<=n;i++)
	{
		if(hjj[i].no==t)
		{
			cout<<hjj[i].ti;
			return 0;
		}
	}
}
