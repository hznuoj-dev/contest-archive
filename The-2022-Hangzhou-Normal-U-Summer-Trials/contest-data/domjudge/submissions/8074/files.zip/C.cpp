#include <bits/stdc++.h>
#define endl '\n'
#define IOS ios::sync_with_stdio(0)
using namespace std;
typedef long long ll;
const int N = 5e5 + 10;
ll n, q;
ll t;
ll a[N];
ll cha[N];

int check(ll mid)
{
	if (a[mid] + t - 1 >= a[mid + 1] - 1)
		return 1;
	else
		return 0;
}

int main()
{
	//IOS; cin.tie(0), cout.tie(0);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		scanf("%lld", &a[i]);
	}

	for (int i = 1; i < n; ++i)
	{
		cha[i] = a[i + 1] - a[i];	// n - 1��λ�õĲ�ֵ֪����
	}

	scanf("%d", &q);
	while (q--)
	{
		scanf("%lld", &t);
		ll l = 1, r = n - 1, mid;	//�����±�
		while (l <= r)
		{
			mid = (l + r) >> 1;
			if (check(mid) == 1)	//˵�����λ���ǿ��Ա����ǵģ���Ҫ����
				l = mid + 1;
			else
				r = mid - 1;
		}
		if (r == n - 1)	//˵��ȫ����
			cout << a[n] + t - a[1] << endl;
		else
		{
			//cout << "r: " << r << endl;
			cout << a[r + 1] + t  - 1 - a[1] + 1 + (n - r - 1) * t << endl;
		}

	}

	return 0;
}
