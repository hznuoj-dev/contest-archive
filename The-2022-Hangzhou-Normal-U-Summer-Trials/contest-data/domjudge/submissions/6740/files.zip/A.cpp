#include<bits/stdc++.h>
using namespace std;
int main(){
    string s;
    cin >> s;
    int ans = 0;
    for(int i = 0 ; i < s.size() - 3 ; i ++){
        string ss = s.substr(i, 4);
        if(ss == "hznu") ans ++; 
    }
    cout << ans;
}