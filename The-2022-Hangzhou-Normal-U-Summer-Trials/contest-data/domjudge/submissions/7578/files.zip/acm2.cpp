#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
//int a[maxn];
//void solve(){
//	
//}
string a[maxn];
int flag[maxn];
map <char,int> p;
string f(string x,string y){
	int cnt;
	if(x.size()<=y.size()){
		cnt=x.size();
		if(x==y.substr(0,cnt)) return x;
		int t=0;
		while(x[t]==y[t]) t++;
		if(p[x[t]]>p[y[t]]) return y;
		else return x;
	}
	else{
		cnt=y.size();
		if(y==x.substr(0,cnt)) return y;
		int t=0;
		while(x[t]==y[t]) t++;
		if(p[x[t]]>p[y[t]]) return y;
		else return x;	
	}
}
int main(){
	string s;
	cin>>s;
	for(int i=0;i<s.size();i++) p[s[i]]=i;
	int n;
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	int k,cnt=0;
	cin>>k;
	for(int i=1;i<=k;i++){
		for(int j=i+1;j<=n;j++){
			if(f(a[i],a[j])==a[j]) swap(a[i],a[j]);
		}
	}
	cout<<a[k];
	return 0;
}
