#include<bits/stdc++.h>
using namespace std;
struct acm
{
	string ss;
	long long t;
}a[1002];
int c(acm a,acm b)
{
	return a.t>b.t;
}
int main()
{
	string s;
	cin>>s;
	int n;cin>>n;
	int m=s.size();
	for(int i=0;i<n;i++)
	{
		cin>>a[i].ss;
		for(int j=0;j<a[i].ss.size();j++)
		{
			a[i].t=a[i].t*10+m-s.find(a[i].ss[j]);
		}
	}
	sort(a,a+n,c);
	int k;cin>>k;
	cout<<a[k-1].ss<<endl;
}
