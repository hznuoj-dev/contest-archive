#include<bits/stdc++.h>
using namespace std;
#define yes (cout<<"YES\n")
#define no (cout<<"NO\n")
#define endl '\n'
//typedef long long ll;
#define int long long
void sxseven();
signed main() {
	ios::sync_with_stdio(false);
	int _=1;
	//cin >> _;
	while(_--) sxseven();
	return 0;
}
const int N=5e5+5;
int a[N],b[N];
void sxseven() {
	int n;
	cin >> n;
	for(int i=1; i<=n; ++i) {
		cin >>a[i];
		b[i]=a[i]-a[i-1];
	}
	//b 2-n
	int q,x;
	cin >> q;
	while(q--) {
		cin >>x;
		int l=2,r=n,m,an=n+1;
		while(l<=r) {
			m=l+r>>1;
			if(b[m]>=x) {
				an=m;
				r=m-1;
			} else l=m+1;
		}
		--an;
		cout<<a[an]-a[1]+(n-an+1)*x<<endl;

	}
}

