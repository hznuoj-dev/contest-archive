#include <bits/stdc++.h>
using namespace std;
int main() {
	int n, k;
	cin >> n >> k;
	int a[n+1] = {};
	int ans = 0;
	for (int i = 1 ; i <= n; i++) {
		cin >> a[i];	
	}
	for (int i = 1; i <= n; i++) {
		long long sum = 0;
		for (int j = i; j <= n; j++){
			sum += a[j];
			if (sum % k == 0) ans++;
		}
	}
	cout << ans;
}
