#include<iostream>
#include<algorithm>
#include<vector>
#define ll long long
using namespace std;
const int N = 1e5 + 10;
int h[N], ne[N * 2], e[2 * N], idx;
void add(int a, int b){
    e[idx] = b;
    ne[idx] = h[a];
    h[a] = idx++;
}
ll f[N];
vector<ll> p[N];
void dfs(int u){
    f[u]++;
    for(int i = h[u]; ~i; i = ne[i]){
        int v = e[i];
        if(!f[v]){
            dfs(v);
            f[u] += f[v];
            p[u].push_back(f[v]);
        }
    }
}
int main(){
    int n;
    scanf("%d", &n);
    for(int i = 0; i <= n; i++)
        h[i] = -1;
    for(int i = 1 ; i < n; i++){
        int a, b;
        scanf("%d%d", &a, &b);
        add(a, b);
        add(b, a);
    }
    dfs(1);
    int t;
    scanf("%d", &t);
    for(int i = 1; i <= n; i++)
        p[i].push_back(n - f[i]);
    while(t--){
        int u;
        scanf("%d", &u);
        ll sum = n - 1;
        ll res = 0;
        for(ll v : p[u]){
            res += (sum - v) * v;
        }
        res >>= 1;
        res += n - 1;
        printf("%lld\n", res);
    }
}