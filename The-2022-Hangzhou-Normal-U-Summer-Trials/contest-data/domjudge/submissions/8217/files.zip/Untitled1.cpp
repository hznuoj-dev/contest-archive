#include<bits/stdc++.h>
#define ll long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const int N = 1e5 + 5;
const double eps = 1e-5;
const int mod = 1e9 + 7;

ll n; 
vector<ll> a[30];
struct node{
	ll op;
	char ch, ch1;
}q[N];


void solve()
{
	cin >> n;
	ll add = 0, del = 0;
	for(ll i = 1; i <= n; i++)
	{
		cin >> q[i].op;
		if(q[i].op == 1)
			cin >> q[i].ch;
		else if(q[i].op == 3)
			cin >> q[i].ch >> q[i].ch1;
		if(q[i].op == 1)
			add++;
		else if(q[i].op == 2 && add > del)
			del++;
	}
	if(add == del)
	{
		cout << "The final string is empty" << '\n';
		return;
	}
	string s = "";
	ll r = add - del, now = 0, rea = 0;
	for(ll i = 1; i <= n; i++)
	{
		if(q[i].op == 1)
		{
			rea++;
			if(now != r)
				now++;
			s += q[i].ch;
		}
		else if(q[i].op == 2 && s.size())
		{
			if(rea <= r)
				now--;
			rea--;
			s.erase(*s.rbegin());
		}
		else
		{
			for(ll j = 0; j < now; j++)
				if(s[j] == q[i].ch)
					s[j] = q[i].ch1;
		}
	}
	cout << s;
}

int main()
{
	IOS;
	ll t = 1;
	//cin >> t;
	while (t--)
		solve();
}
