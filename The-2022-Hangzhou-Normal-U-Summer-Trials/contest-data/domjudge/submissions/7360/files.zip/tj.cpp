#include<iostream>
#include<string>
#include<cstdio>
#include<map>
#include<cstring>
#include<algorithm>
typedef long long ll;
using namespace std;
string s[1007];
int main(){
	map<char,int >mp;
	char str[26];
	cin>>str;
//	getchar();
	
	for(int i = 0;i<26;i++){
	mp[str[i]]=i+1;
}


int n;
cin >> n;
for(int i = 0;i<n;i++)
cin >> s[i];

int t;
cin >> t;
for(int i = 0;i<n;i++)
{
	int big = 0;
	for(int j = i+1;j<n;j++)
	{
		int temp = 0;
		while(s[i][temp]==s[j][temp])
		temp++;
		if(mp[s[i][temp]]>mp[s[j][temp]])
		big ++;
	}
	if(big == t-1)
	{
		cout << s[i];
		break;
	}
}
  

} 
