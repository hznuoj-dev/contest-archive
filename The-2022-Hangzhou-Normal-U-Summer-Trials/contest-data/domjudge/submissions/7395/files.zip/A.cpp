#include<bits/stdc++.h>

using namespace std;

#define debug(x) cerr << #x << " = " << x << '\n'

typedef long long ll;

const int N = 2e5 + 10;

void solve() {
	string s;
	cin >> s;
	map<char, char> mp, x;
	for (int i = 0; i < s.size(); ++i) {
		mp[s[i]] = char('a' + i);
		x[char('a' + i)] = s[i];
		
	}
	int n;
	cin >> n;
	vector<string> b(n);
	for (int i = 0; i < n; ++i) {
		cin >> b[i];
		for (int j = 0; j < b[i].size(); ++j) {
			b[i][j] = mp[b[i][j]]; 
		}
	}
	sort(b.begin(), b.end());
	int k;
	cin >> k;
	for (int i = 0; i < b[k - 1].size(); ++i) {
		b[k - 1][i] = x[b[k - 1][i]];
 	}
 	cout << b[k - 1] << '\n';
}

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
