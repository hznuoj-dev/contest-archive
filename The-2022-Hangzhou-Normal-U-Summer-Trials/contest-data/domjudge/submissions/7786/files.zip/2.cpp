#include <bits/stdc++.h>
using namespace std;
#define  ll long long
const int N=5e5+50;
struct ed{
	ll c,id;
}num[N];
ll a[N],b[N],vis[N],sum[N],fin[N];
bool cmp( ed x, ed y)
{
	return x.c<y.c;
}
int main()
{
	ll n,q;
	scanf("%lld",&n);
	for(int i = 1 ; i <=n;i++)
	{
		scanf("%lld",&a[i]);
		//b[i]=a[i]-a[i-1];
	//	sum[i]=sum[i-1]+a[i];
	}
	for(int i = 1; i<=n; i++)
	{
		b[i]=a[i+1]-a[i];
	}
	    scanf("%lld",&q);
	for(int i = 1 ; i <=q;i++)
	{	    
		scanf("%lld",&num[i].c);	
		num[i].id=i;
	}
	sort(num+1,num+1+q,cmp);
	ll last=1;
	for(int i = 1; i<=q; i++)
	{
		ll ans= 0;
		for(int j = last; j<=n; j++)
		{
			if(b[j]<=num[i].c) vis[j] = 1,last=j;
			else break;
		}
		//if(i==1) cout<<last<<endl;
		if(last>=n) ans = num[i].c+a[last]-1;
		else 
		ans = a[last+1]+(n-last)*num[i].c-1;
		fin[num[i].id]=ans;
		//printf("%lld\n",ans);
	}
	for(int i = 1; i<=q; i++)
	 printf("%lld\n",fin[i]);
}
