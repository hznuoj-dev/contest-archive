#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
double a[3030],b[3030];
int v[3030];
struct node{
	int id;
	double x,y,w;
	bool operator < (const node &k ) const{
		return k.w<w;
	}
};
priority_queue<node>q;
double v0,v1,v2,v3,v4;
double check(int x,int y){
	double sp=0;
	int fl=0;
	if(a[x]>=1&&a[y]>=1&&b[x]>=1&&b[y]>=1) sp=max(sp,v1),fl=1;
	if(a[x]<=-1&&a[y]<=-1&&b[x]>=1&&b[y]>=1) sp=max(sp,v2),fl=1;
	if(a[x]<=-1&&a[y]<=-1&&b[x]<=-1&&b[y]<=-1) sp=max(sp,v3),fl=1;
	if(a[x]>=1&&a[y]>=1&&b[x]<=-1&&b[y]<=-1) sp=max(sp,v4),fl=1;
	if(fl) return sp;
	else return v0;
}
double c[3030];
void solve(){
	int p,n,s,i,j,m,ans=0;
	cin>>n;
	double sp,x,y,k;
	cin>>v1>>v2>>v3>>v4>>v0;
	int S,T;
	cin>>S>>T;
	for(i=1;i<=n;i++) scanf("%lf%lf",a+i,b+i);
	for(i=1;i<=n;i++) c[i]=1e9;
	c[S]=0;
	double mx;
	for(i=1;i<=n;i++){
		p=1;
		mx=1e9;
		for(j=1;j<=n;j++){
			if(v[j]) continue;
			if(c[j]<mx) mx=c[j],p=j;
		}
		v[p]=1;
		for(j=1;j<=n;j++){
			if(v[j]) continue;
			sp=check(j,p);
			x=sqrt((a[j]-a[p])*(a[j]-a[p])+(b[j]-b[p])*(b[j]-b[p]));
			x=x/sp;
			c[j]=min(c[j],c[p]+x);
		}
	}
	printf("%.8f",c[T]);
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
/*
8
1 a
1 b
1 c
3 c d
2
1 c
3 a c
3 c e
*/
//B=clock();
	//printf("%f\n",(double)(B-A)/CLOCKS_PER_SEC);
