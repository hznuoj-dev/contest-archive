#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <numeric>
#include <bitset>
using namespace std;
#define INF 0x3c3c3c3c // 1010580540, 7f7f7f7f:2139062143
#define llINF 9223372036854775807
const double PI = acos(-1.0);
const double eps = 1e-6;
using ll = long long;
using ull = unsigned long long;
using db = double;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
#define fi first
#define se second
#define pb push_back
#define endl '\n'
#define dbg(a) cout << #a << " = " << (a) << '\n';
#define all(c) (c).begin(), (c).end()
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

const int N = 2e5 + 10;

int f[26];

struct query{
    int op;
    char x, y;
}qu[N];

int main(){
    IOS
    for(int i = 0; i < 26; i++){
        f[i] = i;
    }
    int q;
    cin >> q;
    string ans = "";
    for(int i = 0; i < q; i++){
        int op;
        cin >> op;
        if(op == 1){
            qu[i].op = op;
            cin >> qu[i].x;
        }
        else if(op == 2){
            qu[i].op = op;
        }
        else if(op == 3){
            qu[i].op = op;
            cin >> qu[i].x >> qu[i].y;
        }
    }
    int del = 0;
    for(int i = q - 1; i >= 0; i--){
        if(qu[i].op == 1){
            if(del > 0) del--;
            else ans += f[qu[i].x - 'a'] + 'a';
        }
        else if(qu[i].op == 2){
            del++;
        }
        else if(qu[i].op == 3){
            f[qu[i].x - 'a'] = f[qu[i].y - 'a'];
        }
    }
    reverse(all(ans));
    if(ans.empty()){
        cout << "The final string is empty" << endl;
        return 0;
    }
    cout << ans;
    return 0;
}