#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll N = 1e5 + 7;
const ll M = 1e9 + 7;
ll sum[N], cnt1[N], cnt2[N], a[N], ans, n, k; 

int main(){
	cin >> n >> k;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
		sum[i] = (sum[i - 1] + a[i] % k) % k;
	}
	cnt1[0] = 1;
	for (int i = 1; i <= n; i++){
		if (sum[i] % k < N - 5){
			ans += cnt1[sum[i] % k];
			cnt1[sum[i] % k]++;
		}
		else {
			ans += cnt2[sum[i] % k - N + 5];
			cnt2[sum[i] % k - N + 5]++;
		}
	}
	cout << ans;
} 
