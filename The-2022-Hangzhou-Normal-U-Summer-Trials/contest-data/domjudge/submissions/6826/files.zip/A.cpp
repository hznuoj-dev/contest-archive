#include<bits/stdc++.h>
#define int long long
using namespace std;
string s,t;
int n,ans;
signed main(){
	t="hznu";
	cin >> s;
	for (int i=0;i<s.length();++i) {
		if (s[i]==t[n]) {
			n++;
			if (n==4) {
				n=0;ans++;
			}
		}
		else if (s[i]==t[0]) {
			n=1;
		}
		else n=0;
	}
	cout << ans << endl;
}
