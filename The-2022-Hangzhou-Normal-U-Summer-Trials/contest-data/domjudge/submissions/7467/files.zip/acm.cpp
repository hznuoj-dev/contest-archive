#include<bits/stdc++.h>
using namespace std;

const int N=2e5+7,M=1e9+7;
int n,k;
long long a[N];
map<int,int> cnt;
vector<int> yu;
set<int> num;

void solve(){
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		a[i]=(a[i]+a[i-1])%k;
		cnt[a[i]]++;
		if(num.count(a[i])==0){
			yu.push_back(a[i]);
			num.insert(a[i]);
		}
	}
	if(num.count(0)==0){
		yu.push_back(0);
		num.insert(0);
	}
	cnt[0]++;
	long long ans=0;
	for(int i=0;i<yu.size();i++){
		int t=cnt[yu[i]];
		ans+=1ll*cnt[yu[i]]*(cnt[yu[i]]-1)/2;
	}
	cout<<ans<<'\n';
}

int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int T=1;
	//cin>>T;
	while(T--) solve();
	return 0;
}
