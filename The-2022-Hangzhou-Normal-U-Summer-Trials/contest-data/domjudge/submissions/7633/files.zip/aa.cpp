#include<bits/stdc++.h>
using namespace std;
const int n = 10010;

int main(){
	char c;
	int res=0;
	scanf("%c",&c);
	while(c!='\n'){
		if(c=='h'){
			scanf("%c",&c);
			if(c=='z'){
				scanf("%c",&c);
				if(c=='n'){
					scanf("%c",&c);
					if(c=='u'){
						res++;
					}
				}
			}
		}else{
			scanf("%c",&c);
		}
		
	}
	printf("%d",res);
	return 0;
}

