#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
typedef long long ll;
ll a[N];
map<ll,ll> mp,f;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=2;i<=n;i++){
		mp[a[i]-a[i-1]]=i;
		if(!f[a[i]-a[i-1]])
			f[a[i]-a[i-1]]=i;
	}
	vector<ll> w,ww;
	for(auto x:mp){
		w.push_back(x.first);
		ww.push_back(x.second);
	}
	int t;
	cin>>t;
	while(t--){
		ll q;
		cin>>q;
		ll now=upper_bound(w.begin(),w.end(),q)-w.begin();
		ll res=n-mp[w[now-1]]+1;
		if(now<=0) res=n;
		res*=q;
		if(now>w.back()) res=a[n]+max(q-1,0ll);
		else if(now>0){
			res+=a[mp[w[now-1]]]-1;
		} 
		cout<<res<<endl; 
	}
	return 0;
}