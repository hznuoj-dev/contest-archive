#include<bits/stdc++.h>
using namespace std;
#define ll long long
map<char,int> ch;
string st,p[10100];
bool cmp (string a,string b)
{
	int len;
	len=min(a.length(),b.length());
	for (int i=0;i<len;i++)
	{
		if (a[i]==b[i]) continue;
		if (ch[a[i]]<ch[b[i]]) return true; else return false;
	}
	if (a.length()<b.length()) return true; else return false;
}
int main()
{
	int i,j,n,m,k,l;
	cin>>st;
	for (i=0;i<st.length();i++)
	{
		ch[st[i]]=i;
	}
	cin>>n;
	getchar();
	for (i=1;i<=n;i++)
		cin>>p[i];
	sort(p+1,p+1+n,cmp);
	cin>>m;
	cout<<p[m];
}


