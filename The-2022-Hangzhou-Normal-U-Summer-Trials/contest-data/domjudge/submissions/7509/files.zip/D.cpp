#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,fa[100005],num[100005],ans[100005],q;
vector <int> G[100005];
void dfs(int u) {
	int v;
	for (int i=0;i<G[u].size();++i) {
		v=G[u][i];
		if (v==fa[u]) continue;
		fa[v]=u;dfs(v);
		num[u]+=num[v];
	}
}
void work(int u){
	int v,tmp;
	for (int i=0;i<G[u].size();++i) {
		v=G[u][i];
		if (v==fa[u])   tmp=n-num[u];
		else 			tmp=num[v];
		ans[u]+=tmp*(tmp-1)/2;
	}
}
signed main(){
	cin >> n;int u,v;
	for (int i=1;i<=n;++i) num[i]=1;
	for (int i=1;i<n;++i) {
		cin >> u >> v;
		G[u].push_back(v);
		G[v].push_back(u);
	}
	dfs(1);
	for (int i=1;i<=n;++i) {
		work(i);
	}
	cin >> q;
	while (q--) {
		cin >> u;
		cout <<  n*(n-1)/2-ans[u] << endl;
	}
}
