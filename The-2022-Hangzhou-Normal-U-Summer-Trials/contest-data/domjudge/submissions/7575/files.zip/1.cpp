#include<bits/stdc++.h>
using namespace std;

long long a[100005];
map<long long,long long> ma;

int main()
{
	long long n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		a[i]+=a[i-1];
		ma[a[i]%k]++;
	}
	ma[0]++;
	long long ans=0;
	for(int i=0;i<=n;i++)
	{
		if(ma[a[i]%k]!=0)
		{
			ans+=(ma[a[i]%k]-1)*ma[a[i]%k]/2;
			ma[a[i]%k]=0;
		}
	}
	cout<<ans;
}
