#include<bits/stdc++.h>
using i64 = long long;
using namespace std;
#ifdef ACM_LOCAL
const int N = 1e1 + 10;
#else
const int N = 1e5 + 10;
#endif
i64 sum[N], dp[2][N];
int main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    int n; scanf("%d", &n);
    vector<vector<int>> g(n + 10);
    for(int i = 1;i < n;i ++){
        int u, v;
        scanf("%d%d", &u, &v);
        g[u].push_back(v);
        g[v].push_back(u);
    }

    auto dfs = [&](auto self, int fa, int x) -> void {
        sum[x] = 1;
        for(auto v : g[x]){
            if(v == fa) continue;
            self(self, x, v);
            sum[x] += sum[v];
            dp[0][x] += sum[v];
            dp[1][x] += sum[v] * (n - 1 - sum[v]);
        }
        dp[0][x] += n - sum[x];
        dp[1][x] += (n - sum[x]) * (sum[x] - 1);
        return;
    };
    dfs(dfs, -1, 1);

    int k; scanf("%d", &k);
    while(k --){
        int x; scanf("%d", &x);
        printf("%lld\n", dp[0][x] + dp[1][x] / 2);
    }


    return 0;
}