#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define int ll
using T = pair<int, int>;

const int N = 55;

int n;
char g[N][N];
T a, b;

struct state {
    T a, b;
    bool operator< (const state &rhs) const {
        return a.first < rhs.a.first;
    }
};

using TP = pair<int, state>;

set<state> S;

const int dr[] = { -1, 0, 1, 0 };
const int dc[] = { 0, 1, 0, -1 };

bool is_legal (T x) {
    return x.first >= 1 && x.first <= n && x.second >= 1 && x.second <= n \
        && g[x.first][x.second] == '.';
}

signed main ()
{
    scanf("%d", &n);
    for (int i = 1; i <= n; i ++ ) scanf("%s", g[i] + 1);
    for (int i = 1; i <= n; i ++ )
        for (int j = 1; j <= n; j ++ ) {
            if (g[i][j] == 'a') a = {i, j};
            if (g[i][j] == 'b') b = {i, j};
        }
    priority_queue<TP, vector<TP>, greater<>> pq;
    pq.push({0, {a, b}});
    S.insert({a, b});
    while(pq.size()) {
        auto [step, P] = pq.top();
        auto [na, nb] = P;
        pq.pop();

        if (na == nb) return cout << step << '\n', 0;

        for (int i = 0; i < 4; i ++ ) {
            T nxt1 = { na.first + dr[i], na.second + dc[i] };
            T nxt2 = { nb.first + dr[i], nb.second + dc[i] };
            if (is_legal(nxt1) && !is_legal(nxt2)) {
                if (S.find({nxt1, nb}) != S.end()) {
                    S.insert({nxt1, nb});
                    pq.push({step + 1, {nxt1, nb}});
                }
            } else if (is_legal(nxt1) && is_legal(nxt2)) {
                if (S.find({nxt1, nxt2}) != S.end()) {
                    S.insert({nxt1, nxt2});
                    pq.push({step + 1, {nxt1, nxt2}});
                }
            } else if (!is_legal(nxt1) && is_legal(nxt2)) {
                if (S.find({na, nxt2}) != S.end()) {
                    S.insert({na, nxt2});
                    pq.push({step + 1, {na, nxt2}});
                }
            }
        }
    }
    cout << "no solution";
    return 0;
}