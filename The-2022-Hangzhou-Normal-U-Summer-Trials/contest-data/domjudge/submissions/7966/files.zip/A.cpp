#include<bits/stdc++.h>
using namespace std;
int n,len,k;
string s;
char ex[30];
string in[1007];
struct st{
	string it;
	int id;
}q[1007];
bool cmp(st a,st b){
	return a.it<b.it;
}
int main(){
	cin>>s;
	scanf("%d",&n);
	for(int i=0;i<26;++i){
		ex[(int)(s[i]-'a')]='a'+i;
	}
	for(int i=1;i<=n;++i){
		cin>>in[i];
		len=(int)in[i].size();
		q[i].id=i;
		q[i].it="";
		for(int j=0;j<len;++j){
			q[i].it+=ex[in[i][j]-'a'];
		}
	}
	sort(q+1,q+n+1,cmp);
	cin>>k;
	cout<<in[q[k].id];
	return 0;
}
