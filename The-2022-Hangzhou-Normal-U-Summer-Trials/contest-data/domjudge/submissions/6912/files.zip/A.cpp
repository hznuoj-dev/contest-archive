#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[200];
struct node{
	string s;
}b[1010];
bool cmp(node x,node y){
	int n,m;
	n=x.s.length();
	m=x.s.length();
	for(int i=0;i<min(n,m);i++){
		if(a[x.s[i]]==a[y.s[i]]) continue;
		else return a[x.s[i]]<a[y.s[i]]; 
	}
	return n<m;
}
void solve(){
	int i,j,m,n,x,y,k,l,r,ans=0;
	char c;
	for(i=1;i<=26;i++){
		scanf("%c",&c);
		a[c]=i;
	}
	cin>>n;
	for(i=1;i<=n;i++){
		cin>>b[i].s;
	}
	sort(b+1,b+n+1,cmp);
	cin>>k;
	cout<<b[k].s;
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
