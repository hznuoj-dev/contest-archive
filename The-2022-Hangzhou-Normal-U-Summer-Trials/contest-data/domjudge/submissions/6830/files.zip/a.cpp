#include<iostream>
using namespace std;

int main()
{
    string s;
	cin >> s;
	int ans=0;
	for(int i=0; i<(int)s.size()-3; i++){
        if(s[i]=='h' && s[i+1]=='z' && s[i+2]=='n' && s[i+3]=='u') ans++;
	}
	cout << ans << endl;
	return 0;
}
