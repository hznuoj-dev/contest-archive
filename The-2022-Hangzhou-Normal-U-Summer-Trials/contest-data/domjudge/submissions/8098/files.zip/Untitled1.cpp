#include<cstring>
#include<iostream>
#include<string>
#include<cstdio>
using namespace std;
string s;
int n,k; 
int sum[1006]={0};
string o[1006];
int a[166]={0};
int main(){
	cin>>s;
	for(int i=0;i<s.length();++i){//����	
		a[s[i]]=i+1;
	}
	
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>o[i];	
	}
	for(int i=0;i<n;++i){
		for(int j=i;j<n;++j){
			if(o[i].length()>o[j].length()){
			string c=o[i];
				o[i]=o[j];
				o[j]=c;
			}
		}
	}
	for(int i=0;i<n;++i){
		for(int j=0;j<o[i].length();++j){
			for(int k='a';k<='z';++k){
				if(o[i][j]==k){
					sum[i]+=a[k];
					sum[i]*=10;
				}
			}
		}//cout<<sum[i]<<endl;
	}
	for(int i=0;i<n;++i){
		for(int j=i+1;j<n;++j){
			if(sum[i]>sum[j]){
				string t=o[i];
				o[i]=o[j];
				o[j]=t;
			}
		}
	}
	for(int i=0;i<n;++i){
		cout<<o[i]<<endl;
	}
	cin>>k;
	cout<<o[k-1];
} 
