#include <cmath>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <queue>
#include <map>
#include <iomanip>
#include <vector>
#include <string>
#include <set>
#include <sstream>
#include <stack>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#pragma warning(disable:4996)
using namespace std;
#define endl '\n'
#define ll long long
#define io_speed_up ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
map<char, int>base;
const int maxn = 2e7 + 5;
int head[maxn], ver[maxn], nxt[maxn];
long double d[maxn], edge[maxn];
struct point {
	long double x, y;
}p[3111];
long double v[4], v0;
long double dis(point a, point b){
	return sqrt((a.x - b.x) * (a.x - b.x) + (a.y - b.y) * (a.y - b.y));
}
int tot;
int vis[3111];
priority_queue<pair<long double, int>>q;
void add(int x, int y, long double z){
	ver[++tot] = y, edge[tot] = z, nxt[tot] = head[x], head[x] = tot;
}
void dij(int s){
	for(int i = 0;i <= 3003;i++)d[i] = 1e12;
	d[s] = 0;
	q.push(make_pair(0, s));
	while(!q.empty()){
		int x = q.top().second; q.pop();
		if(vis[x])continue;
		for(int i  = head[x]; i; i = nxt[i]){
			int y = ver[i];
			long double z = edge[i];
			if(d[y] > d[x] + z){
				d[y] = d[x] +z;
				q.push(make_pair(-d[y], y));
			}
		}
	}
}
int quert(point a){
	if(a.x >= 1 && a.y >= 1){
		return 1;
	}
	if(a.x <= -1 && a.y >= 1){
		return 2;
	}
	if(a.x <= -1 && a.y <= -1){
		return 3;
	}
	if(a.x >= 1 && a.y <= -1){
		return 4;
	}
}
long double getspeed(point a, point b){
	long double x1, y1, x2, y2;
	x1 = a.x, x2 = b.x;
	y1 = a.y, y2 = b.y;
	if(quert(a) == quert(b)){
		return v[quert(a) - 1];
	}
	else return v0;
}

int main(){
	io_speed_up;
	int n ;
	cin >> n;
	cin >> v[0] >> v[1] >> v[2] >> v[3] >>v0;
	int s, t;
	cin >> s >>t;
	for(int i = 1;i<=n;i++){
		cin >> p[i].x >> p[i].y;
	}
	for(int i =1;i<=n;i++){
		for(int j = 1;j<=n;j++){
			long double t = dis(p[i],p[j]) / getspeed(p[i], p[j]);
			add(i, j, t);
		}
	}
	dij(s);
	cout  << fixed << setprecision(10)<< d[t];
	//system("pause");
}
