#include<iostream>
using namespace std;
const int N=1e5+10;
char s[N]={'\0'};
int main()
{
    int q;
    cin>>q;
    int n=0;
    while(q--)
    {
        int x;
        char a,b;
        cin>>x;
        if(x==1)
        {
            cin>>a;
            s[n++]=a;
        }
        else if(x==2)
        {
            s[n--]='\0';
        }
        else if(x==3)
        {
            cin>>a>>b;
            for(int i=0;i<n;i++)
            {
                if(s[i]==a) s[i]=b;
            }
        }
    }
    if(n==0) cout<<"The final string is empty"<<endl;
    else
    {
        cout<<s<<endl;
    }
    return 0;
}