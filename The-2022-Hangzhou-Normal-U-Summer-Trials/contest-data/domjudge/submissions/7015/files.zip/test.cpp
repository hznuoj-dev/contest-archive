#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=5e3+10;
const int INF=1e17;
const int SIZE=1000000+10;
const int mod=1e9+7;
int n,m,k;
int a[SIZE];
int pre[SIZE];
vector<int>vec;
void solve(){
    cin>>n;
    for(int i=1;i<=n;i++) cin>>a[i];
    for(int i=2;i<=n;i++){
        vec.push_back(a[i]-a[i-1]);
    }
    vec.push_back(INF);
    sort(vec.begin(),vec.end());
    for(int i=0;i<vec.size();i++){
        if(i==0) pre[i]=vec[i];
        else pre[i]=vec[i]+pre[i-1];
    }
    cin>>k;
    while(k--){
        int t;
        cin>>t;
        int pos=upper_bound(vec.begin(),vec.end(),t)-vec.begin();
        if(pos==0){
            cout<<t*n<<endl;
        }
        else {
            int ans=pre[pos-1];
            ans+=t*(n-pos);
            cout<<ans<<endl;
        }
    }
    return ;
}
void inits(){}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int ts=1;
    inits();
    while(ts--){
        solve();
    }
    return 0;
}