#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
vector<int> son[N];
int f[N];
int dfs(int now,int fa,int r){
	// if(f[now]) return f[now]-1;
	int res=1;
	vector<int> a;
	for(auto x:son[now]){
		if(x==fa) continue;
		int k=dfs(x,now,r);
		res+=k;
		a.push_back(k);
	}
	if(now==r)
	for(int i=0;i<a.size();i++){
		for(int j=i+1;j<a.size();j++)
			res+=a[i]*a[j];
	}
	return res;
}
int main(){
	int n;
	cin>>n;
	for(int i=1;i<n;i++){
		int a,b;
		cin>>a>>b;
		son[a].push_back(b);
		son[b].push_back(a);
	}
	int t;
	cin>>t;
	while(t--){
		int x;
		cin>>x;
		cout<<dfs(x,x,x)-1<<endl;
	}
}