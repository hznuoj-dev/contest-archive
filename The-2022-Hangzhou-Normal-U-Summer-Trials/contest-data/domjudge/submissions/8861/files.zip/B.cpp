#define _CRT_SECURE_NO_WARNINGS
#include<bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using db = double;
using vi = vector<int>;
using mii = map<int, int>;
using PII = pair<int, int>;
using PLL = pair<ll, ll>;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const ll mod = 1e9 + 7;
const int MAXN = 1e3 + 10;
#define mem(a,b) memset(a,b,sizeof(a));

struct Node {
	string s = "";
	int len;
};

int a[30];
char s[30];
Node str[MAXN];
char ss[MAXN];
bool cmp(Node n1, Node n2) {
	int now = 0;
	while (now < min(n1.len, n2.len)) {
		if (n1.s[now] == n2.s[now]) {
			now++;
			continue;
		}
		else {
			char c1 = n1.s[now];
			char c2 = n2.s[now];
			if (a[c1 - 'a'] < a[c2 - 'a']) {
				return true;
			}
			else return false;
		}
	}
	return n1.len < n2.len;

}

int main() {
	scanf("%s", s);
	for (int i = 0; i < 26; i++) {
		a[s[i] - 'a'] = i;
	}
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%s", ss);
		int len = strlen(ss);
		Node N;
		N.len = len;
		for (int i = 0; i < len; i++) {
			N.s.push_back(ss[i]);
		}
		str[i] = N;
	}
	sort(str, str + n, cmp);
	int k;
	cin >> k;
	for (int i = 0; i < k; i++) {
		cout << str[i].s << endl;
	}

	return 0;
}