#include <bits/stdc++.h>
using namespace std;
#define  ll long long
const int N = 2e5 + 50;
ll b[N], vis[N], sum[N], cal[N];
ll a[N];
vector<ll>v[N];
int cnt;
int dfs(int u,int fa)
{
	
	for(int i = 0; i<cal[u];i++)
	{
		if(fa==v[u][i]) continue;
		cnt++;
		dfs(v[u][i],u);
	}
	return cnt;
}
int main() {
	int n, q;

	scanf("%d", &n);
	for (int i = 1; i <= n - 1; i++) {
		int x, y;
		scanf("%d%d", &x, &y);
		v[x].push_back(y);
		v[y].push_back(x);
	}
	for(int i = 1; i<=n; i++)
	{
		cal[i]=v[i].size();
	}
//	cout<<dfs(1,-1)<<endl;
	scanf("%d", &q);
	
	for (int i = 1; i <= q; i++) {
		int x;
		scanf("%d", &x);
		ll ans = 0;
		if (v[x].size() == 1) printf("%d\n", n - 1);
		else{
				for(int i =0; i<cal[x];i++)
				{	
					cnt=1;
					sum[i]=dfs(v[x][i],x);
				//	if(x==1) cout<<sum[i]<<endl<<endl;
				}
				for(int i = 0; i< cal[x];i++)
					for(int j = i+1; j<cal[x];j++)
						ans+=sum[i]*sum[j];
				
			    printf("%lld\n", ans+n-1);
		}
	}
}
