#include<iostream>
#include<vector>
#define int long long
using namespace std;

const int N=1e5+7;
vector<int> g[N];
int k[N];
int kid[N];

void dfs(int u, int fa)
{
    if(g[u].size()==1){
        kid[u]=1;
        return;
    }
    for(int i=0; i<g[u].size(); i++){
        if(g[u][i]==fa) continue;
        dfs(g[u][i],u);
        kid[u]+=kid[g[u][i]];
    }
}

signed main()
{
    int n;
    cin >> n;
    for(int i=0; i<n-1; i++){
        int a,b;
        cin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }/*
    vector<int> v;
    for(int i=1; i<=n; i++){
        if(g[i].size()==1) v.push_back(i);
    }
    for(int i=0; i<v.size(); i++){
        for(int j=0; j<g[v[i]].size(); j++){
            a[g[v[i]][j]]++;
        }
    }*/
    //for(int i=1; i<=n; i++) cout << a[i] << endl;
    for(int i=1; i<=n; i++) kid[i]=1;
    dfs(1,0);
    for(int i=1; i<=n; i++) k[i]=(kid[i]-1)*(n-kid[i]+1)+n-kid[i];
    for(int i=1; i<=n; i++){
        int nn=kid[i]-1;
        for(int j=0; j<g[i].size(); j++){
            if(kid[g[i][j]]>kid[i]) continue;
            nn-=kid[g[i][j]];
            k[i]+=nn*kid[g[i][j]];
        }
    }
    int q;
    cin >> q;
    while(q--){
        int x;
        cin >> x;
        cout << k[x] << endl;
    }
}
