#include<iostream>

using namespace std;
const int N=1e5+10;
char s[N];
int main()
{
    scanf("%s",s);
    int x=0,k=0,num=0;
    for(int i=0;s[i]!='\0';i++)
    {
        if(s[i]=='h'&&k==0) x=i,k=1;
        else if(s[i]=='z'&&k==1) k=2;
        else if(s[i]=='n'&&k==2) k=3;
        else if(s[i]=='u'&&k==3) k=4;
        if(k==4) num++,k=0,i=x;
    }
    cout<<num<<endl;
    return 0;
}