#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
int a[maxn];
//void solve(){
//	
//}
int main(){
	string s;
	cin>>s;
	int cnt=0,pos=0;
	while(pos!=-1){
		pos=s.find("hznu",pos);
		if(pos!=-1) pos+=4;
		cnt++;
	}
	cout<<cnt-1<<"\n"; 
	return 0;
}
