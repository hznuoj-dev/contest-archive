#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
#define int long long
using namespace std;

map<int,int> mp;
signed main()
{
	Daybreak7;
	int n,k;
	cin>>n>>k;
	int x,sum[n+10],num;
	for(int i=0;i<n;i++)
	{
		cin>>x;
		num+=x;
		sum[i]=num%k;
	}
	int ans=0;
	for(int i=0;i<n;i++)
	{
		if(sum[i]==0) ans++;
		ans+=mp[sum[i]];
		mp[sum[i]]++;
	}
	cout<<ans;
}
