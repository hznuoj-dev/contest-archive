#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[500010];
int main()
{
    ll n;
    cin >> n;
    for (ll i = 0; i < n; i ++) cin >> a[i];
    for (ll i = 0; i < n - 1; i ++) a[i] = a[i + 1] - a[i];
    ll q, t;
    cin >> q;
    while(q --)
    {
        ll ans, i;
        ans = 0; 
        cin >> t;
        for (i = 0; i < n - 1; i ++)
        {
            if (a[i] < t)
                ans += a[i];
            else 
                break;
        }
        ans += (n - i) * t;
        cout << ans << endl;
    }
    system("pause");
}