#include<bits/stdc++.h>
using namespace std;
string s,str="hznu";
int a[210],ans;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	int t=0;
	for(int i=0;i<s.size();i++){
		if(str[t]==s[i]){
			t++;
		} else {
			t=0;
			if(s[i]==str[t]){
				t++;
			}
		}
		if(t==4){
			t=0;
			ans++;
		}
	}
	cout<<ans<<'\n';
	return 0;
} 
