#include<bits/stdc++.h>

using namespace std;

#define INF 0x3f3f3f3f3f3f3f3f
#define io ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define PI acos(-1)
#define mem(a,b) memset((a),(b),sizeof(a));

typedef long long ll;
typedef unsigned long long ull;
ll ksm(ll x, ll n) {
    if(n == 0) return 1;
    ll t = 1;
    while(n != 0){
      if(n & 1) t *= x;
      n >>= 1;
      x *= x;
    }
    return t;
}
int main() {
	string s;
	cin>>s;
	int cnt=0;
	for(int i=0;i<s.length();) {
		if(s[i]=='h') {
			if(s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u') {
				cnt++;
				i+=4;
			}
			else i++;
		} 
		else i++;
	}
	cout<<cnt;
	return 0;
} 
