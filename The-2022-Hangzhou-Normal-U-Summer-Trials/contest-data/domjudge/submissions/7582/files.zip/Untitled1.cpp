#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int maxn=1e5+10;
int to[maxn<<1];
int net[maxn<<1];
int cut=0;
int head[maxn];
ll sz[maxn];
int fa[maxn];
ll z[maxn];

void dfs(int u,int f){
	sz[u]=1;
	fa[u]=f;
	for(int i=head[u];i;i=net[i]){
		int v=to[i];
		if(v==f) continue;
		dfs(v,u);
		z[u]+=sz[u]*sz[v];
		sz[u]+=sz[v];
	}
}
void add(int from,int to2){
	to[++cut]=to2;
	net[cut]=head[from];
	head[from]=cut;
}
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	dfs(1,1);
	int q;
	scanf("%d",&q);
	while(q--){
		int x;
		scanf("%d",&x);
		//printf("---%lld\n",z[x]);
		printf("%lld\n",z[x]+sz[x]*(n-sz[x]));
	}
	
} 

