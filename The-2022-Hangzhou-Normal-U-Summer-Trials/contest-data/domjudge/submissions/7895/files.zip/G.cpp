#include<bits/stdc++.h>
using namespace std;
const int MAXN=1e5+5;
const int prime[10]={2,3,5,7,11,13,17,19,23,29};
struct Tree{
	int ul[10],ld[10];bool ult,ldt;
	Tree(){memset(ul,0,sizeof(ul));memset(ld,0,sizeof(ld));}
	Tree operator +(Tree y){
		Tree z;
		for(int i=0;i<10;i++){
			z.ul[i]=ul[i]+y.ul[i];
			z.ld[i]=ld[i];
		}
		z.ult=ult;
		z.ldt=ldt;
		return z;
	}
	Tree operator -(Tree y){
		Tree z;
		for(int i=0;i<10;i++){
			z.ul[i]=ul[i]-y.ul[i];
			z.ld[i]=ld[i];
		}
		z.ult=ult;
		z.ldt=ldt;
		return z;
	}
}Tre[MAXN<<2],Add[MAXN<<2];
Tree _min(Tree x,Tree y){
	Tree z;
	for(int i=0;i<10;i++){
		if(x.ult&&y.ult) z.ul[i]=min(x.ul[i],y.ul[i]);
		else z.ul[i]=(x.ult?x.ul[i]:y.ul[i]);
		if(x.ldt&&y.ldt) z.ld[i]=min(x.ld[i],y.ld[i]);
		else z.ld[i]=(x.ldt?x.ld[i]:y.ld[i]);
	}
	z.ult=x.ult|y.ult;
	z.ldt=x.ldt|y.ldt;
	return z;
}
void PushUp(int rt){Tre[rt]=_min(Tre[rt<<1],Tre[rt<<1|1]);}
void PushDown(int rt){
	if(Tre[rt<<1].ult==1) Tre[rt<<1]=Tre[rt<<1]+Add[rt],Add[rt<<1]=Add[rt<<1]+Add[rt];
	if(Tre[rt<<1|1].ult==1) Tre[rt<<1|1]=Tre[rt<<1|1]+Add[rt],Add[rt<<1|1]=Add[rt<<1|1]+Add[rt];
	memset(Add[rt].ul,0,sizeof(Add[rt].ul));
}
void Mul(int rt,int L,int R,int l,int r,int x,int f){
	if(l<=L&&R<=r){
		for(int i=0;i<10;i++){
			while(x%prime[i]==0){
				Tre[rt].ul[i]+=f;
				Add[rt].ul[i]+=f;
				x/=prime[i];
			}
		}
		return;
	}
	PushDown(rt);
	int mid=(R+L)>>1;
	if(l<=mid) Mul(rt<<1,L,mid,l,r,x,f);
	if(r>mid) Mul(rt<<1|1,mid+1,R,l,r,x,f);
	PushUp(rt);
}
void flip(int rt,int L,int R,int p){
	if(L==R){
		if(Tre[rt].ult==1){
			for(int i=0;i<10;i++){
				Tre[rt].ld[i]=Tre[rt].ul[i];
				Tre[rt].ul[i]=0;
			}
		}else{
			for(int i=0;i<10;i++){
				Tre[rt].ul[i]=Tre[rt].ld[i];
				Tre[rt].ld[i]=0;
			}
		}
		Tre[rt].ult^=1;
		Tre[rt].ldt^=1;
		return ;
	}
	int mid=(R+L)>>1;PushDown(rt);
	if(p<=mid) flip(rt<<1,L,mid,p);
	else flip(rt<<1|1,mid+1,R,p);
	PushUp(rt);
}
Tree Query(int rt,int L,int R,int l,int r){
	if(l<=L&&R<=r) return Tre[rt];
	int mid=(R+L)>>1;PushDown(rt);
	if(r<=mid) return Query(rt<<1,L,mid,l,r);else
	if(l>mid) return Query(rt<<1|1,mid+1,R,l,r);else
	return Query(rt<<1,L,mid,l,r)+Query(rt<<1|1,mid+1,R,l,r);
}
void Build(int rt,int L,int R){
	if(L==R){
		Tre[rt].ult=1;
		Tre[rt].ldt=0;
		return;
	}
	int mid=(R+L)>>1;
	Build(rt<<1,L,mid);Build(rt<<1|1,mid+1,R);
	PushUp(rt);
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n,m;cin>>n>>m;
	Build(1,1,n);
	for(int i=1;i<=m;i++){
		string s;cin>>s;
		if(s=="mul"){
			int L,R,x;cin>>L>>R>>x;
			Mul(1,1,n,L,R,x,1);
		}else
		if(s=="div"){
			int L,R,x;cin>>L>>R>>x;
			Tree c=Query(1,1,n,L,R);
			bool flg=0;
			for(int i=0,y=x;i<10;i++){
				int cnt=0;
				while(y%prime[i]==0) y/=prime[i],cnt++;
				if((c.ldt&&c.ld[i]<cnt)||(c.ult&&c.ul[i]<cnt)){flg=1;break;}
			}
			if(flg){cout<<"NO\n";continue;}
			cout<<"YES\n";
			Mul(1,1,n,L,R,x,-1);
		}else
		if(s=="flip"){
			int x;cin>>x;
			flip(1,1,n,x);
		}
	}
	return 0;
}