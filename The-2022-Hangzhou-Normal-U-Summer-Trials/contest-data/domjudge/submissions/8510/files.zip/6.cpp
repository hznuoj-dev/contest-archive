#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=100000001;
vector<ll>v,ss;
map<ll,ll>p;
map<ll,ll>::iterator it;
int main(){
	int n,k;
	cin>>n>>k;
	for(int i=0;i<n;i++){
		int x;
		cin>>x;
		v.push_back(x);
	}
	ll s=0;
	ss.push_back(0);
	for(int i=0;i<n;i++){
		s+=v[i];
		ss.push_back(s);
	}
	for(int i=0;i<n+1;i++){
		for(int j=i+1;j<n+1;j++){
			p[ss[j]-ss[i]]++;
		}
	}
	ll maxs=0;
//	for(it=p.begin();it!=p.end();it++){
//		cout<<it->first<<" "<<it->second<<endl;
//	}
	for(it=p.begin();it!=p.end();it++){
		if(it->first%k==0)
		maxs+=it->second;
	}
	cout<<maxs<<endl;
}
