#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int maxn = 1e6 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 52;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}

ll dp[maxn][6];
ll a[maxn];
void solve(){
    ll n, p, s, k;
    cin >> n >> p >> s;
    for(int i = 1; i <= n; ++i) {
        cin >> a[i];
    }
    cin >> k;
    for(int i = 1; i <= n; ++i) {
        for(int j = 0; j <= k; ++j) {
            dp[i][j] = 1e18;
        }
    }
    dp[1][0] = a[1];
    for(int i = 2; i <= n; ++i)  {
        for(int u = 0; u <= k; ++u) {
            int l = 1, r = n;
            int last = a[i] - u * s;
            while(l < r) {
                int mid = l + r >> 1;
                if(a[mid] >= last)r = mid;
                else l = mid + 1;
            }
            for(int j = u; j <= k; ++j) {
                dp[i][j] = min({dp[i][j], dp[i-1][j] + (a[i] - a[i - 1]), dp[l][j - u]});
            }
        }
    }
    ll ans = 1e18;
    for(int i = 0; i <= k; ++i) {
        ans = min(ans, dp[n][i] + p - a[n]);
    }
    cout << ans << '\n';
}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}