#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int N = 100010;

int n, k, a[N], p[N];
map<int, int> mp;

signed main ()
{
    scanf("%d%d", &n, &k);
    for (int i = 1; i <= n; i ++ ) scanf("%d", &a[i]);
    if (k == 1) {
        printf("%lld", 1ll * n * (n-1) / 2 + n);
    } else {
        for (int i = 1; i <= n; i ++ ) p[i] = p[i-1] + a[i];
        ll ans = 0;
        mp[0] = 1;
        for (int i = 1; i <= n; i ++ ) {
            for (ll pk = k; pk <= p[i]; pk += k) ans += mp[p[i] - pk];
            if (a[i] == 0) ans += mp[0];
            mp[p[i]] += 1;
//            cout << "now ans " << ans << endl;
        }
        printf("%lld\n", ans);
    }
    return 0;
}