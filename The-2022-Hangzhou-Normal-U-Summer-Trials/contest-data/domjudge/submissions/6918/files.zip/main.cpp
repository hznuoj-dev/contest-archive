#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

int n, m;
string s[maxn];
int v[190];
void solve(){
    string ss;
    cin >> ss;
    for(int i=0;i<ss.size();i++){
        v[ss[i]] = i;
    }
    cin >> n;
    for(int i=1;i<=n;i++) cin >> s[i];
    sort(s+1, s+n+1, [](string a, string b){
        for(int i=0;i<a.size() && i<b.size();i++){
            if(v[a[i]] < v[b[i]]) return true;
            if(v[a[i]] > v[b[i]]) return false;
        }
        return a.size() < b.size();
    });
    cin >> m;
    cout << s[m] << '\n';
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}