#include<bits/stdc++.h>
#define sync_flow ios::sync_with_stdio(false);cin.tie(0)
#define zf(i,l,r) for(int i=l;i<=r;i++)
#define df(i,r,l) for(int i=r;i>=l;i--)
#define lowbit(x) (x&(-x))
using namespace std;
typedef long long ll;
const ll maxn=5e5+55,inf=0x3f3f3f3f3f;
ll n,q,t;
ll a[maxn],dist[maxn],sum[maxn];
int main()
{
	sync_flow;
	cin>>n;
	a[0]=0;
	zf(i,1,n){
		cin>>a[i];
	}
	zf(i,1,n-1){
		dist[i]=a[i+1]-a[i]-1;
	}
	dist[n]=inf;
	sum[0]=0;
	zf(i,1,n-1){
		sum[i]=sum[i-1]+dist[i];
	}
	cin>>q;
	while(q--){
		ll ans=n;
		cin>>t;
		t--;
		df(i,n,1){
				if(dist[i]<=t){
					ans+=sum[i];
					break;
				}else{
					ans+=t;
				}
			}
		cout<<ans<<endl;
	} 
	return 0;
}
//C
