#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int main()
{
	string s;
	int o=0;
	cin>>s;
	for(int i=0;i<s.length();i++){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
			o++;
		}
	}
	printf("%d\n",o);
	return 0;
 } 
