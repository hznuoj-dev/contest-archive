﻿
#include<iostream>
#include<string>
#include<cmath>
using namespace std;
const int N = 1e5;
int main()
{
	char s[N];
	cin >> s;
	int count = 0;
	int len = strlen(s);
	for (int i = 0; i < len - 3; i++) {
		if (s[i] == 'h') {
			if (s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') {
				count++;
			}
		}
	}
	cout << count;
	return 0;
}

/*
#include<iostream>
#include<string>
#include<algorithm>

using namespace std;

int main()
{
	int n, k;
	return 0;
}
*/