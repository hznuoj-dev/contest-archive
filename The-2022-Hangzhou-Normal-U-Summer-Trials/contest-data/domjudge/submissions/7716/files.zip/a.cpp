#include<bits/stdc++.h>
using namespace std;
#define ll long long
int a[100006];
int s[100006];
char f[200];
map<ll,ll>mp;
struct pp{
	int w;
	char x,y;
}p[1000008];
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	int n;
	cin>>n;
	ll r=0;
	for(int i=1;i<=n;i++){
		
		cin>>p[i].w;
		int h=p[i].w;
		if(h==1){
			cin>>p[i].x;
			r++;
		}
		else if(h==3){
			cin>>p[i].x>>p[i].y;
		}
		else {
			if(r>0) r--;
		}
	}
	if(r==0) {
		cout<<"The final string is empty\n";
		return 0;
	}
	for(int i=80;i<=150;i++){
		f[i]=(char)i;
	}
	bool flag=0;
	string ans="";
	int g1=0,g2=0;
	for(int i=n;i>=1;i--){
		if(p[i].w==1){
			g1++;
			if(flag) {
				flag=0;
				continue;
			}
//			cout<<p[i].x<<"55555"<<f[p[i].x]<<"\n";
			ans=f[p[i].x]+ans;
		}
		else if(p[i].w==2){
			flag=1;
			g2++;
			
		}
		else if(p[i].w==3){
			f[p[i].x]=f[p[i].y];
//				cout<<p[i].x<<"55555"<<f[p[i].x]<<"\n";
		}
		
	}
	

	cout<<ans<<"\n";
	
} 
