#include<bits/stdc++.h>
using namespace std;

#define INF ox3f3f3f3f
//
//long long int dfs(int qidian,int n,int maxn,long long int pb[]){
//	long long int s=0;
//	for(int i=qidian;i<=n-1;i++){
//		if(s+pb[i+1]-pb[i]<=maxn){
//			s+=pb[i+1]-pb[i];
//		}else{
//			break;
//		}
//	}
//	return s;
//}

int main(){
	
//	int n,k;
//	cin>>n>>k;
//	
//	for(int i=1;i<=n;i++){
//		cin>>a[i];
//		sum[i]=sum[i-1]+a[i];//ǰ׺�� 
//	}
//	
//	int count=0;
//	map<int,int>mp;
//	
//	for(int i=1;i<=n;i++){
//		
//		for(int j=0;j<i;j++){
//			if((sum[i]-sum[j])%k==0){
//				count++;
//			}
//		}
//	}
//
//	cout<<count<<endl;
	
//	int n;//bike stop ������
//	long long int p;//���յ�ľ���
//	long long int s;//һԪ�����ﳵ�ľ���
//	
//	cin>>n>>p>>s;
//	
//	long long int pb[n+1]={0};//bike stop��λ��
//	
//	for(int i=1;i<=n;i++){
//		cin>>pb[i];
//	} 
//	
//	int k;
//	cin>>k;//Alice����Ǯ��
//	
//	long long int max=k*s;//Alice��Ǯ�������ﳵ�ľ��� 
//	
//	long long int ans=0;//�����ߵľ��� 
//	
//	if(n>1){//��bike stop 
//		long long int s1;
//		s1=pb[1];//�����㵽��һ��վ�Ʊ�����
//		long long int s2=0;
//		int flag=n;//��¼�³���վ�ƺ� 
//		
//		int smax=0;
//		
//		for(int i=1;i<=n-1;i++){
////			if(s2+pb[i+1]-pb[i]<=max){
////				s2+=pb[i+1]-pb[i];
////			}
////			else{
////				flag=i;
////				break;
////			}
//			int u = dfs(i,n,max,pb);
//			if(u>smax){
//				smax=u;
//			}
//		}
//		//ans=s1+p-pb[flag];
//		ans=p-smax;
//	}
//	else{
//		ans=p;
//	}
//	
//	cout<<ans<<endl;

	int q;
	cin>>q;//q�β���
	string s="";
	while(q--){
		int x;
		string ch;
		char a;
		char b;
		cin>>x;
		
		if(x==1){
			cin>>ch;
			s+=ch;
		}
		if(x==2){
			if(!s.empty()){
				string ss="";
				
				
				for(int i=0;i<s.length()-1;i++){
					stringstream sstream;
					string dd;
					//cout<<"****\n"<<s[i]<<"****\n";
					sstream<<s[i];
					sstream>>dd;
					ss+=dd;
				}
				s=ss;
				//cout<<"****"<<ss<<"******\n";
			}
			
		}
		if(x==3){
			cin>>a;
			getchar();
			cin>>b;
			
			for(int i=0;i<s.length();i++){
				if(s[i]==a){
					s[i]=b;
				}
			}
			
		}
		
	} 



	if(s.length()>0){
		cout<<s<<endl;
	}
	else{
		cout<<"The final string is empty\n";
	}




	
	
	return 0;
} 
