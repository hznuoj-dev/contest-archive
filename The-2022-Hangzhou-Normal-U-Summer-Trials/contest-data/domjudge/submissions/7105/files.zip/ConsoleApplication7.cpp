﻿#include<iostream>
#include<algorithm>
#include<string>
#include<map>
using namespace std;
map<char, int>mp;
bool cmp(string a, string b)
{
	int minl = min(a.length(), b.length());
	for (int i = 0; i <minl; i++)
	{
		if (mp[a[i]] > mp[b[i]])return true;
		else if (mp[b[i]] > mp[a[i]])return false;



	}
	
	if (a.length() > b.length())return true;
	else return false;

	





}
int main()
{
	string a;
	cin >> a;

	

	string b[1005];





	for (int i = 0; i < a.length(); i++)
	{
		mp[a[i]] = i;


	}



	int n;
	cin >> n;
	for (int i = 1;i <= n;i++)
	{
		cin >> b[i];



	}
	sort(b+1 , b +1+ n, cmp);
	

	int k;
	cin >> k;
	
	cout << b[n-k+1];



}