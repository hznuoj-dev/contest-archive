#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll N = 1e5 + 7;
const ll M = 1e9 + 7;
ll sum[N], a[N], ans, n, k; 
struct Node{
	ll idx, cnt;
};
vector<Node> v;

int main(){
	cin >> n >> k;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
		sum[i] = (sum[i - 1] + a[i] % k) % k;
	}
	v.push_back((Node){0, 1});
	for(int i = 1; i <= n; i++){
		ll x = sum[i] % k, yes = 0;
		for (int j = 0; j < v.size(); j++){
			if (v[j].idx == x){
				ans += v[j].cnt;
				v[j].cnt++;
				yes = 1;
			}
		}
		if (yes == 0)v.push_back((Node){x, 1});
	}
	cout << ans;
} 
