#include<bits/stdc++.h>
using namespace std;
string s;
int a[100005];
char b[100005],c[100005];
int len=0;
int main()
{
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
		if(a[i]==1){
			cin>>b[i];
			s[len++]=b[i];
		}
		else if(a[i]==2){
			if(len>0){
				s[len--]='\0';
			}
		}
		else if(a[i]==3){
			cin>>b[i]>>c[i];
			for(int j=0;j<len;j++){
				if(s[j]==b[i]){
					s[j]=c[i];
				}
			}
		}
	}
	//s[len]='\0';
	if(len==0){
		cout<<"The final string is empty"<<endl;
	}
	else{
		for(int i=0;i<len;i++){
			cout<<s[i];
		}
		cout<<endl;
	}
 } 
