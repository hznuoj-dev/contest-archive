#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using T = pair<int, int>;

const int N = 200010, P = 1e9 + 7;

int a[N];
int fac[N], infac[N];

int qmi (int x, int k)
{
    int res = 1;
    for (x %= P; k; k >>= 1, x = (ll)x * x % P)
        if (k & 1) res = (ll)res * x % P;
    return res;
}

void init ()
{
    fac[0] = 1;
    for (int i = 1; i < N; i ++ ) fac[i] = (ll)fac[i-1] * i % P;
    infac[N - 1] = qmi(fac[N - 1], P - 2);
    for (int i = N - 2; i >= 0; i -- ) infac[i] = (ll)infac[i+1] * (i + 1) % P;
}

int C (int n, int m) {
    if (n < m) return 0;
    return (ll)fac[n] * infac[m] % P * infac[n-m] % P;
}

int pre[N];

signed main ()
{
    init();
    int n, s, q; cin >> n >> s >> q;

    for (int i = n - 1; i < N; i ++ ) {
        pre[i] = ((ll)pre[i-1] + C(i, n - 1)) % P;
//        cout << C(i, n-1) << endl;
    }

    for (int i = 1; i <= n; i ++ ) cin >> a[i], s -= a[i] - 1;
    for (int i = 1; i <= q; i ++ ) {
        int x, v; cin >> x >> v;
        s = s - (v - 1);
        if (s < n) {
            cout << 0 << endl;
        }
        a[x] = v;
//        cout << "now ns " << s << endl;
        if (s - 1 >= N) while(1);
        cout << pre[s - 1] << endl;
    }
    return 0;
}