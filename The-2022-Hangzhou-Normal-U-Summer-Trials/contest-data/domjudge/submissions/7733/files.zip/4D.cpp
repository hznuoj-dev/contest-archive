#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

const int N=1e5+10;
int n,q,st[N];
vector<int> e[N];

int dfs(int x)
{
	int ans=1;
	for(auto i:e[x])
	{
		if(!st[i])
		{
			st[i]=1;
			//cout<<"point:"<<i<<endl;
			ans+=dfs(i);
		}
		
	}
	return ans;
}

int main()
{
	cin>>n;
	for(int i=1;i<n;i++)
	{
		int a,b;
		cin>>a>>b;
		e[a].push_back(b);
		e[b].push_back(a);
	}
	cin>>q;
	while(q--)
	{
		int x;
		cin>>x;
		if(e[x].size()==1) cout<<n-1<<endl;
		else
		{
			memset(st,0,sizeof st);
			st[x]=1;
			
			int cnt=0;
			int ans[5];
			for(auto i:e[x])
			{
				st[i]=1;
				ans[++cnt]=dfs(i);
			}
			//cout<<ans[1]<<' '<<ans[2]<<' '<<ans[3]<<"**"<<endl;
			if(cnt==2) cout<<ans[1]+ans[2]+ans[1]*ans[2]<<endl;
			else cout<<ans[1]+ans[2]+ans[3]+ans[1]*ans[2]+ans[1]*ans[3]+ans[2]*ans[3]<<endl;
			
		}
	}
	
	return 0;
}
