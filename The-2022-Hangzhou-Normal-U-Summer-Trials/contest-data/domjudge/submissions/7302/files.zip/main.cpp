#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int  maxn = 5e5 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 21;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
ll a[maxn];
void solve(){
    int n, k;
    cin >> n >> k;
    for(int i = 1; i <= n; ++i) {
        cin >> a[i];
        a[i] += a[i - 1];
    }
    for(int i = 1; i <= n; ++i) {
        a[i] %= k;
//        cout << a[i] << '\n';
    }
    sort(a, a + n + 1);
    ll ans = 0;
    for(int i = 0; i <= n; ++i) {
        int r = i;
        while(r < n && a[r + 1] == a[i]) ++ r;
        ans += (r - i + 1) * 1ll * (r  - i) / 2;
        i = r;
    }
    cout << ans << '\n';
}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}