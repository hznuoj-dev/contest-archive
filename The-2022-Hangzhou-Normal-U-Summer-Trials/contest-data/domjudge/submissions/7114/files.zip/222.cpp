#include<bits/stdc++.h>
using namespace std;
int arr[30]={0};
int com(string &str1,string &str2);
int main(){
	string a;
	cin>>a;
	for(int i=0;i<a.length();i++){
		arr[a[i]-'a']=i;
	}
	int n;
	cin>>n;
	string s[1010];
	int len=0;
	for(int i=0;i<n;i++){
		cin>>s[i];
		//len=len<s[i].length()?s[i].length():len;
	}
	int k;
	cin>>k;
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-i-1;j++){
			if(com(s[j],s[j+1])==1)//0:s[j]<a[j+1]  1:s[j]>s[j+1]
			{
				string t=s[j];
				s[j]=s[j+1];
				s[j+1]=t;
			}
		}
	}
	cout<<s[k-1]<<endl;
	return 0;
} 
int com(string &str1,string &str2){
	int flag=-1;
	for(int i=0;i<str1.length()&&i<str2.length();i++){
		if(str1[i]!=str2[i]){
			if(arr[str1[i]-'a']<arr[str2[i]-'a']){
				flag=0;
				break;
			}
			else{
				flag=1;
				break;
			}
		}
	}
	if(flag!=-1){
		return flag;
	}
	else{
		if(str1.length()<str2.length()){
			return 0;
		}
		else
			return 1;
	}
}
