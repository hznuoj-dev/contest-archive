#include<bits/stdc++.h>

using namespace std;
const int N=1e5+7;
typedef long long ll;

ll ans, n, vis[N], k, a[N], sum, cnt;
void solve() {
	cin >> n >> k;
	for(int i=1;i<=n;i++) {
		cin >> a[i];
	}
	for(int i=1;i<=n;i++) {
		if(vis[i]) continue;
		vis[i]=1; sum=0;
		for(int j=i;j<=n;j++) {
			if(!sum) 
				vis[j]=1;
			sum+=a[j];
			if(sum%k==0) {
				//vis[j]=1;
				sum=0; cnt++;
				ans+=cnt;
			}
		}
		if(!cnt&&sum<k) break; 
		cnt=0;
	}
	cout << ans << endl;
}

int main(){
	ios :: sync_with_stdio(false); cin.tie(0); cout.tie(0); 
	int T=1;
	//cin >> T;
	while(T--)
		solve();
}
