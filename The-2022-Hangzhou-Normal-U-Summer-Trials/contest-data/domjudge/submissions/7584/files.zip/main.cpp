#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int  maxn = 5e5 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 52;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
char g[N][N];
int n;
int d[N][N][2];

int dx[] = {0 ,1, 0, -1};
int dy[] = {1, 0, -1, 0};
struct node{
    pair<int,int> s, t;
    int d;
};
bool ck(int x, int y){
    if(x < 1 || y < 1)return false;
    if(x > n || y > n)return false;
    if(g[x][y] == '*')return false;
    return true;
}
bool vis[N][N][N][N];
int bfs() {
    pair<int,int> a , b;
    for(int i = 1; i <= n; ++i) {
        for(int j = 1; j <= n; ++j) {
            if(g[i][j] == 'a') a = {i ,j};
            if(g[i][j] == 'b') b = {i, j};
        }
    }
    queue<node> q;
    q.push({a, b, 0});
    vis[a.first][a.second][b.first][b.second] = true;
    while(!q.empty()) {
        pair<int,int> x, y;
        x = q.front().s;
        y = q.front().t;
        int dis = q.front().d;
        q.pop();
        if(x == y) return dis;
        for(int i = 0; i < 4; ++i) {
            int ix1 = x.first + dx[i];
            int iy1 = x.second + dy[i];
            int ix2 = y.first + dx[i];
            int iy2 = y.second + dy[i];
            if(!ck(ix1, iy1)) {
                ix1 = x.first;
                iy1 = x.second;
            }
            if(!ck(ix2, iy2)) {
                ix2 = y.first;
                iy2 = y.second;
            }
            if(vis[ix1][iy1][ix2][iy2])continue;
            vis[ix1][iy1][ix2][iy2] = true;
            q.push({make_pair(ix1,iy1) , make_pair(ix2,iy2), dis + 1});
        }
    }

    return -1;

}
void solve(){
    cin >> n;
    for(int i = 1; i <= n; ++i) cin >> g[i] + 1;
    int ans = bfs();
    if(ans == -1) cout << "no solution\n";
    else cout << ans << '\n';
}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}