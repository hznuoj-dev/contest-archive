#include<iostream>
#include<algorithm>
#include<cstdio>
#include<math.h>
#include<string.h>
#include<queue>
typedef long long ll;
#define INF 0x3f3f3f3f
using namespace std;
 
#define N 220
 
struct node
{
    int x,y,step;
};
char maps[N][N];
int dir[4][2]={{-1,0},{1,0},{0,-1},{0,1}};    ///����
int vis[N][N];                                ///����߹���
int dist1[N][N],dist2[N][N];        ///Y��M������ľ��룻
int n,m,yx,yy,mx,my;                ///Y,M����ʼλ��
 
void BFS(int x,int y,int dist[][N])  ///BFS������������ǣ��ѣ�x,y�����������̾������dist[][]�����С�
{
    int i;
    node a,b;
    queue<node>Q;
    memset(vis,0,sizeof(vis));
    memset(dist,0,sizeof(dist));
    a.x=x;
    a.y=y;
    a.step=0;
    vis[x][y]=1;
    Q.push(a);
    while(Q.size())
    {
        a = Q.front();
        dist[a.x][a.y]=a.step;  ///��ÿ�εĲ�������dist����
        Q.pop();
 
        for(i=0; i<4; i++)
        {
            int dx,dy;
            dx=a.x+dir[i][0];
            dy=a.y+dir[i][1];
            if(dx>=0 && dy>=0 && dx<n && dy<m && maps[dx][dy]!='*' && !vis[dx][dy])
            {
                b.x=dx;
                b.y=dy;
                b.step=a.step+1;
                vis[dx][dy]=1;
                Q.push(b);
            }
        }
    }
}
 
int main()
{
  	cin >> n;
    int i,j;
        for(i=0;i<n;i++)
        {
            for(j=0;j<n;j++)
            {
                cin>>maps[i][j];
                if(maps[i][j]=='a')
                    yx=i,yy=j;
                if(maps[i][j]=='b')
                    mx=i,my=j;
            }
        }
        BFS(yx,yy,dist1);   ///��Y������ľ������dist1[][]��
        BFS(mx,my,dist2);   ///��M������ľ������dist2[][]��
 
        int Min=INF;
        for(i=0;i<n;i++)
        {
            for(j=0;j<m;j++)          ///�ж�����������KFC����Сֵ����Min
            {
                if(dist1[i][j]!=0 && dist2[i][j]!=0 && dist1[i][j]+dist2[i][j]<Min)        
                    Min=dist1[i][j]+dist2[i][j];
            }
        }
        printf("%d\n",Min*11);
    return 0;
}
/*#include <iostream>
#include <queue>
using namespace std;
typedef long long ll;
int s1,e1,s2,e2;
struct Node {
	int x, y;
	Node(int a=0, int b=0) :x(a), y(b) {}
};
Node node[5001];
 
char G[5001][5001];
bool visited[5001][5001];
 
int dir[4][2] = {{0,1},{1,0},{0,-1},{-1,0}};
int d[5001][5001];
int d2[5001][5001];
int n;
 
bool Valid(int x, int y) {
	if(x < 1 || x > n || y < 1 || y > n) return false;
	if(d[x][y] != -1 || G[x][y] == '*') return false;
	return true;
}
 bool judge(int x, int y) {
	if(x < 1 || x > n || y < 1 || y > n) return false;
	if(d2[x][y] != -1 || G[x][y] == '*') return false;
	return true;
}
void Clear_D() {
	for(int i=1; i<=n; i++)
	{ 	for(int j=1; j<=n; j++)
		{  	d[i][j] = -1;
		    d2[i][j] = -1;
		}
	}
	
		
	return;
}
int ans=0;
void bfs() {
	queue<Node> Q,Q2;
	Q.push(Node(s1, e1));
	Q2.push(Node(s2, e2));
	Clear_D();
	d[s1][e1] = 0;
	d2[s2][e2] = 0;
	while(!Q.empty()) {
		Node k=Q.front();
		Q.pop();
		Node q=Q2.front();
		Q2.pop();
		for(int i=0; i<4; i++) {
			int next_x = k.x + dir[i][0];
			int next_y = k.y + dir[i][1];
			int nx=q.x + dir[i][0];
			int ny=q.y + dir[i][1];
		 		if(G[next_x][next_y]=='*'||next_x < 1 || next_x > n || next_y < 1 || next_y > n)
		 		{   d[next_x][next_y]=d[k.x][k.y];
		 		    next_x=k.x;
		 		    next_y=k.y;
				}
				else 
				{     d[next_x][next_y]=d[k.x][k.y]+1;
				}
		 	if(G[nx][ny]=='*'||nx < 1 || nx > n || ny < 1 || ny > n)
		 	{   	d2[nx][ny] = d2[q.x][q.y];
		 	        nx=q.x;
		 	        ny=q.y;
			 }
			 else 
			 {  		d2[nx][ny] = d2[q.x][q.y] + 1;
			 }
				if(nx==next_x&&ny==next_y)
				{  ans=min(ans,d[next_x][next_y]+d2[nx][ny]);
				}
				Q.push(Node(next_x, next_y));
				Q2.push(Node(nx, ny));
		}
	}
 
}
 
int main() {
	cin >> n;
	for(int i=1; i<=n; i++)
	{   
		for(int j=1; j<=n; j++)
		 {  	cin >> G[i][j];
		   if(G[i][j]=='a')
		    {  s1=i;
		       e1=j;
			}
		 if(G[i][j]=='b')
		    {  s2=i;
		       e2=j;
			}
		 }
		
	}
	bfs();
	if(ans==0)
	{ cout<<"no solution"<<endl;
	}
	else 
    cout<<ans<<endl;
	return 0;
}*/
