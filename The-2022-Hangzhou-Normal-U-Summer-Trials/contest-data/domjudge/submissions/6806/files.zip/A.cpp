#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define wtnnb ios::sync_with_stdio(false);//cin.tie(0);cout.tie(0);
const int N = 1e6+10;
signed main(){
    wtnnb
    string s;
    cin>>s;
    int cost=0;
    for(int i=0;i<s.length()&&i+3<s.length();i++){
    	if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')cost++;
	}
	cout<<cost<<endl;
       
}

