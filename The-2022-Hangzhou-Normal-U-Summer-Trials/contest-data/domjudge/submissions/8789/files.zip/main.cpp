#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int maxn = 1e6 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 3001;
typedef pair<double,int> PII;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
struct node{
    int x, y;
}p[N];
vector<pair<int,double>> adj[N];
double d[N];
bool st[N];
void dijkstra(int u) {
    priority_queue<PII,vector<PII>,greater<void> >q;
    for(int i = 0; i <= 3001; ++i) d[i] = 1e18;
    d[u] = 0;
    q.push({d[u], u});
    while(!q.empty()) {
        auto t = q.top();
        q.pop();
        int ver=t.second;
        double dis=d[ver];
        if(st[ver])continue;
        st[ver]= 1;
        for(auto &[x, y] : adj[u]) {
            if(d[x] > dis + y) {
                d[x] = dis + y;
                q.push({d[x], x});
            }
        }
    }
}
int v0, v1, v2, v3, v4;
int ck(int x, int y, int x1, int y1) {
    if(x >= 1 && y >= 1 && x1 >= 1 && y1 >= 1) return v1;
    if(x <= -1 && y >= 1 && x1 <= -1 && y1 >= 1) return v2;
    if(x <= -1 && x1 <= -1 && y <= -1 && y1 <= -1) return v3;
    if(x >= 1 && x1 >= 1 && y <= -1 && y1 <= -1) return v4;
    return v0;
}
double dis(int x, int y, int x1, int y1) {
    return sqrt(1.0 * (x - x1) * (x - x1) + 1.0 * (y - y1) * (y - y1));
}
void solve(){
    int n;
    cin >> n;
    cin >> v1 >> v2 >> v3 >> v4 >> v0;
    int s, t;
    cin >> s >> t;
    for(int i = 1; i <= n; ++i) {
        auto &[x, y] = p[i];
        cin >> x >> y;
    }
    for(int i = 1; i <= n; ++i) {
        for(int j = i + 1; j <= n; ++j) {
            int ss = ck(p[i].x, p[i].y, p[j].x, p[j].y);
            adj[i].push_back({j, dis(p[i].x, p[i].y, p[j].x, p[j].x) / (1.0*ss)});
        }
    }
    dijkstra(s);
    cout << fixed << setprecision(7) << d[t] << '\n';

}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}