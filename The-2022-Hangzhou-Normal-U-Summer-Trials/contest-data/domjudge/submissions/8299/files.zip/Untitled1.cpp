#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 100005
int a[maxn];
int main()
{
	ll n,k,i,ans=0,j;
	cin>>n>>k;
	int dp[n][n]={0};
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	for(i=1;i<=n;i++)
	{
		dp[i][i]=a[i];
		if(dp[i][i]%k==0)
		ans++;
	}
	for(i=1;i<=n;i++)
	{
		for(j=i+1;j<=n;j++)
		{
			dp[i][j]=dp[i][j-1]+a[j];
			if(dp[i][j]%k==0)
				ans++;
		}
	}
	cout<<ans;
	
} 
