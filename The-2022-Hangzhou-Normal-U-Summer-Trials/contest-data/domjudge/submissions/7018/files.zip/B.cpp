#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> PLL;
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define debug(a) cout<<#a<<'='<<a<<endl;
#define fi first
#define se second
#define pb push_back
#define all(a) a.begin(),a.end()

string str;
map<char,char>mp;

bool cmp1(string x,string y){
	if(x.size()==y.size()){
		rep(i,0,x.size()){
			int pos1,pos2;
			if(x[i]==y[i])continue;
			rep(j,0,26){
				if(str[j]==x[i])pos1=j;
				if(str[j]==y[i])pos2=j;
			}
//			debug(x);
//			debug(y);
//			debug(pos1);
//			debug(pos2);
			return pos1<pos2;
		}
	}
}


void solve(){
	int n,m;
	cin>>str>>n;
	vector<string>a(n),b;
	rep(i,0,n)cin>>a[i];
	cin>>m;
	sort(all(a));
	int siz=a[0].size();
	rep(i,0,n)
		if(a[i].size()==siz)b.pb(a[i]);
	sort(all(b),cmp1);
	cout<<b[0]<<endl;
}

int main(){
	int _=1;
//	cin>>_;
	while(_--)solve();
	return 0;
}
