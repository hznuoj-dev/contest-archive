#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
using namespace std;
using LL=long long;
const int N=1e5+10;
#define int LL
int n,m,k;
vector<int>v[N];
LL a[N],ans[N];
void dfs(int u,int fa){
	a[u]++;
	for(auto x:v[u]){
		if(x==fa)continue;
		dfs(x,u);
		a[u]+=a[x];
	}
}
void dfs1(int u,int fa){
	int sum=0,res=0;
	for(auto x:v[u]){
		if(fa==x)sum+=n-a[u],res+=(n-a[u])*(n-a[u]);
		else sum+=a[x],res+=a[x]*a[x];
	}
	//cout<<res<<' '<<sum<<endl<<endl;
	ans[u]=sum+(sum*sum-res)/2;
	for(auto x:v[u]){
		if(fa==x)continue;
		dfs1(x,u);
	}
}
signed main(){
	ios::sync_with_stdio(0);
	cin>>n;
	rep(i,1,n-1){
		int x,y;cin>>x>>y;
		v[x].push_back(y);
		v[y].push_back(x);
	}
	dfs(1,0);
	dfs1(1,0);
//	for(auto x:v[1])cout<<a[x]<<endl<<endl;
	int q;cin>>q;
	while(q--){
		int x;cin>>x;
		cout<<ans[x]<<'\n';
	}
}
