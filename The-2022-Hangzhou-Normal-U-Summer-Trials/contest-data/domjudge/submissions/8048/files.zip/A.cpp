#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[200];
struct node{
	int op,x,y;
}b[100010];
int find(int x){
	while(a[x]!=x){
		a[x]=a[a[x]];
		x=a[x];
	}
	return x;
}
int c[100010],d[100010];
void solve(){
	int p,n,s,q,i,j,m,x,y,k,l,r,t,ans=0,mid,sum=0;
	cin>>q;
	char cc;
	int op;
	n=0;
	for(i=1;i<=180;i++) a[i]=i;
	for(i=1;i<=q;i++){
		scanf("%d",&op);
		if(op==1){
			n++;
			getchar();
			scanf("%c",&cc);
			d[n]=cc;
			c[n]=i;
			b[i].op=1;
			b[i].x=d[i];
		}
		else if(op==2){
			n--;
			n=max(0,n);
			b[i].op=2;
		}
		else{
			getchar();
			scanf("%c",&cc);
			b[i].x=cc;
			getchar();
			scanf("%c",&cc);
			b[i].y=cc;
			b[i].op=3;
		}
	}
	if(!n){
		printf("The final string is empty");
		return;
	}
	p=n;
	for(i=q;i;i--){
		if(i==c[p]){
			d[p]=find(d[p]);
			p--;
		}
		if(b[i].op==3){
			x=find(b[i].x);
			y=find(b[i].y);
			if(x!=y) a[x]=y;
		}
		if(p==0) break;
	}
	for(i=1;i<=n;i++) printf("%c",d[i]);
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
//B=clock();
	//printf("%f\n",(double)(B-A)/CLOCKS_PER_SEC);
