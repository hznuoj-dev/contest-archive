#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define wtnnb ios::sync_with_stdio(false);//cin.tie(0);cout.tie(0);
const int N = 1e6+10;
ll a[N];
vector<ll>b;
ll s[N];
signed main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int n;cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=1;i<n;i++)b.push_back(a[i+1]-a[i]);
    sort(b.begin(),b.end());
    for(int i=1;i<n;i++)s[i]=s[i-1]+b[i-1];
    
    int q;cin>>q;
    while(q--){
    	ll t;cin>>t;
    	int p=lower_bound(b.begin(),b.end(),t)-b.begin();
    	ll ans=0;
    	ans=(n-p)*t;
    	ans+=s[p];
    	cout<<ans<<endl;
	}
}

