
#include <bits/stdc++.h>
using namespace std;

#define INF 0x3f3f3f3f

#define ll long long
#define endl '\n'
#define null NULL
#define ls p<<1
#define rs p<<1|1
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define vi vector<int>
#define mii map<int,int>
#define pii pair<int,int>
#define ull unsigned long long
#define pqi priority_queue<int>
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define ct cerr<<"Time elapsed:"<<1.0*clock()/CLOCKS_PER_SEC<<"s.\n";
#define ull unsigned long long
#define rep(i,a,b) for(int i=(a);i<=(b);i++)
inline int rd() {//�����Ż������Լӿ����ֵ�����
	char p = 0; int r = 0, o = 0;
	for (; p < '0' || p>'9'; o |= p == '-', p = getchar());
	for (; p >= '0' && p <= '9'; r = (r << 1) + (r << 3) + (p ^ 48), p = getchar());
	return o ? (~r) + 1 : r;
}
void write(int x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
const int M = 2e5 + 10;
const int mod=1e9+7;
const double pi=acos(-1.0);
int qpow(int a,int b){
	int result=1;
	int s=a;
	while(b){
		if(b&1){
			result=(result*a)%mod;
		}
		a=(a*a)%mod;
		b/=2;
	}
	return result;
}
int gcd(int a,int b){
	if(b==0) return a;
	else{
		return gcd(b,a%b);
	}
}

void solve()
{
	string s;
	cin>>s;
	s+="qweqweqweqwe";
	int ans=0;
	for(int i=0;i<(int)s.size()-4;i++){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
			ans++;
		}
	}
	cout<<ans<<endl;
}
signed main()
{
	int t;
//	cin>>t;
	t=1;
	while(t--){
	solve();
	}
}

