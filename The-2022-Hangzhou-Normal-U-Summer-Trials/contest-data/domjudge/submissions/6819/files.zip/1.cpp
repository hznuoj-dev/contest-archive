#include <bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
	string s;
	cin>>s;
	int l=s.size();
	int t=0; 
	for(int i=0;i<=l-4;i++){
		string c;
		for(int j=i;j<i+4;j++){
			c+=s[j];
		}
		if(c=="hznu")
			t++;
	}
	cout<<t<<endl;
}
