#include<bits/stdc++.h>
using namespace std;

#define ll long long

const int N=1e3+5;
const int mod=1e9+7;

string ss[N];
string s;
int vl[30];

struct node{
	ll n,i;
}v[N];

ll fp(ll a,ll b){
	ll ans=1;
	while(b){
		if(b&1)	ans=ans*a%mod;
		a=a*a;
		b>>=1;
	}
	return ans%mod;
}

void gtc(string x){
	for(int i=0;i<26;i++){
		vl[s[i]-'a']=i+1;
	}
}

bool cmp(node x,node y){
	return x.n<y.n;
}

void solve(){
	int n,k,len=0;
	cin>>s>>n;
	gtc(s);
	for(int i=0;i<n;i++){
		cin>>ss[i];
		len=max(len,(int)ss[i].size());
	}
	for(int i=0;i<n;i++){
		v[i].i=i;
		
		for(int j=0;j<ss[i].size();j++){
			v[i].n=(v[i].n+vl[ss[i][j]-'a']*fp(26,1ll*(len-j-1)))%mod;
		}
	}
	sort(v,v+n,cmp);
//	for(int i=0;i<n;i++){
//		cout<<v[i].n<<"\n";
//	}
	cin>>k;
	cout<<ss[v[k-1].i]<<"\n";
}

int main(){
	ios::sync_with_stdio(false);
	int t=1;
	while(t--){
		solve();
	}
	return 0;
}

