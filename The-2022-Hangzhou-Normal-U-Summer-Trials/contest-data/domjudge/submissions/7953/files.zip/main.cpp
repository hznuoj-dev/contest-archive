#include<bits/stdc++.h>
#define ll long long
using namespace std;
int main(){
    int n,k;
    cin>>n>>k;
    int a[n+1];
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    int num=0;
    for(int i=1;i<=n;i++){
        ll sum=a[i];
        for(int j=i;j<=n;j++){
            sum+=a[j];
            if(sum%k==0)num++;
        }

    }
    cout<<num<<endl;
    return 0;
}