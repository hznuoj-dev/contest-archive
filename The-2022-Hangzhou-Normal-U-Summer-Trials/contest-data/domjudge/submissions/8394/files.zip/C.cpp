#include<bits/stdc++.h>
using namespace std;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n;
	cin>>n;
	if(n==1)
	{
		long long x;
		cin>>x;
		int t;
		cin>>t;
		while(t--)
		{
			cin>>x;
			cout<<x<<"\n";
		}
		return 0;
	}
	long long int a[n]={0},b[n]={0};
	for(int k=1;k<=n;k++)
	{
		cin>>a[k];
		if(k>=2)
		{
			b[k-1]=a[k]-a[k-1];//����������� 
		}
	}
	int t,n1;
	cin>>t;
	long long p,ci=0;
	while(t--)
	{
		ci=0;
		cin>>p;
		n1=upper_bound(b,b+n-1,p)-b;
		while(b[n1]>p)
		{
			n1--;
		}
		if(n1==n-1)
		{
			ci=a[n]-a[1]+p;
		}
		else 
		{
			ci=a[n1+1]-a[1]+(n-n1)*p;
		}
        cout<<ci<<"\n";
    }
	return 0;
}
