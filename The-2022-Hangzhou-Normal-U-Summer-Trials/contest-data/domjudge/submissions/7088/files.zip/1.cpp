#include<bits/stdc++.h>

using namespace std;

#define ll long long

const int N = 500005;
ll a[N];

ll b[N];
ll sum[N];
int n;

void check(ll t){
	int to = lower_bound(b+1,b+n,t)-b;
	ll ans = sum[to-1] + (n-to+1)*t;
	printf("%lld\n",ans);
}

void solve()
{
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		scanf("%lld",&a[i]);
		if(i!=1){
			b[i-1]=a[i]-a[i-1];
		}
	}
	for(int i=1;i<n;++i){
		sum[i] = sum[i-1] + b[i];
	}
	b[n] = LONG_LONG_MAX;
	int q;ll t;
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		scanf("%lld",&t);
		check(t);
	}
	
}

int main()
{
	int t=1;
	//scanf("%d",&t);
	while(t--){
		solve();
	}	
	return 0;
}
