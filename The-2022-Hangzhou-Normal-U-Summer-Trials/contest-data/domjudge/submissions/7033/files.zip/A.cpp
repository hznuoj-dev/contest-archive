#include<iostream>
#include<string>
#include<algorithm>
//#include<stdlib>
using namespace std;

int main(void){
	int n, temp=0;
	int a[10]={1, 1, 1, 1};
	string s;
	string s0="hznu";
	getline(cin, s);
	
/*	for(int k=0;k<s.length();++k){
	}*/
	int ans=0;
	for(int i=0;i<s.length();++i){
		if(i>=0 && i<=s.length()-4){
			if(s[i]=='h' && s[i+1]=='z' && s[i+2]=='n' && s[i+3]=='u'){
				ans++;
			}
			else{
				continue;
			}
		}
		else{
			break;
		}
	}

	cout<<ans<<endl;
	
	
	return 0;
	
}
