#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int  maxn = 5e5 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 21;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
vector<int> adj[maxn];
ll sz[maxn];
ll f[maxn];
int n;
void dfs(int u, int fa){
    ++sz[u];
    ll all = 0;
    for(int &v : adj[u])if(v != fa) {
        dfs(v, u);
        f[u] += all * sz[v];
        all += sz[v];
    }
    sz[u] += all;
    f[u] += (n - sz[u]) * all;
}
void solve(){
    cin >> n;
    for(int i = 1; i < n; ++i) {
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }
    dfs(1, 0);
    int q;
    cin >> q;
    while(q -- > 0) {
        int x;
        cin >> x;
        cout << f[x] + n - 1 <<'\n';
    }

}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}