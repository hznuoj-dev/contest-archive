#include <bits/stdc++.h>

using namespace std;

long long a[500005];

long long dex[500005];

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	long long n;
	cin >> n;
	for(int i = 0 ; i<n ; i++){
		cin >> a[i];
	}
	
	long long sum = 0;
	for(int i = 0 ; i<n-1 ; i++){
		dex[i] = a[i+1] - a[i];
		sum += dex[i];
	}
	int q;
	cin >> q;
	for(int i = 0 ; i<q ; i++){
		long long t;
		cin >> t;
		long long ans = t;
		if(t <= dex[0]){
			ans += t*(n-1);
		}
		else if (t > dex[n-2]){
			ans += sum;
		}
		else{
			long long pos = -1;
			for(int i = 0 ; i<n-1 ; i++){
				if(dex[i] > t){
					pos = i;
					break;
				}
			}
			//cout << pos << endl;
			//cout << ans << endl;
			for(int i = 0 ; i<=pos-1 ; i++){
				ans += dex[i];
			}
			
			//cout << ans << endl;
			
			ans += t * (n-pos-1);
			
			//cout << ans << endl;
			
		}
		
		cout << ans << endl;
		
	}
	
	
	
}

