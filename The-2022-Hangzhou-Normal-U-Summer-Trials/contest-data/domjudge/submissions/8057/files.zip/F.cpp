#include<iostream>
#include<set>
#define ll long long
#define endl '\n'
using namespace std;
const int INF=0x3f3f3f3f;
const int N=1e5+7;
const double pi=acos(-1);
int n,k;
int a[N];
ll sum[N];
ll cnt;
ll ans;
multiset<ll>se;
multiset<ll>::iterator it;
int main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin>>n>>k;
	for(int i=0;i<n;++i){
		cin>>a[i];
		if(i==0)sum[0]=a[i];
		else sum[i]+=sum[i-1]+a[i]; 
		se.insert(sum[i]%k);
	}
	ll x=*se.begin();
	for(it=se.begin();it!=se.end();++it){
		if(x!=*it) {
			if(x==0) ans=cnt;
			ans=ans+cnt*(cnt-1)/2;
			cnt=0;
			x=*it;
			it--;
		}
		else cnt++;
	}
	cout<<ans<<endl;
	return 0;
} 