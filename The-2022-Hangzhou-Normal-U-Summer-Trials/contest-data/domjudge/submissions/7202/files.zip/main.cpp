#include <bits/stdc++.h>
using namespace std;

int main(){
    string s1;
    cin>>s1;
    int num[200]={0};
    for(int i=0;i<26;i++){
        num[s1[i]]=i;
    }
    string s[1005],ts;
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        cin>>s[i];
    }
    for(int i=0;i<n;i++){
        int k=i;
        for(int j=i+1;j<n;j++){
            for(int v=0;v<s[i].size();v++){
                if(num[s[k][v]]>num[s[j][v]]){
                    k=j;break;
                }
            }
        }
        if(k!=i){
            ts=s[k];
            s[k]=s[i];
            s[i]=ts;
        }
    }
    int k;
    scanf("%d",&k);
    cout<<s[k-1];
    return 0;
}