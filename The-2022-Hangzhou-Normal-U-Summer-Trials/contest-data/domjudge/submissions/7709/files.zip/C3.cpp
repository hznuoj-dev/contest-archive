﻿#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
#define INF 0x3f3f3f

int a[500007];
int sub[500006];


int pre;
int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i];
		if (i >= 1)
		{
			sub[i - 1] = a[i] - a[i - 1];

		}
	}
	
	int q;
	cin >> q;
	while (q--)
	{
		ll t;
		ll sum ;
		cin >> t;
		sum = t * n;
		for (int i = 0; i < n - 1; i++)
		{
			if (t > sub[i])
				sum -= t - sub[i];
		}
		cout << sum;
	}

	
}
  
