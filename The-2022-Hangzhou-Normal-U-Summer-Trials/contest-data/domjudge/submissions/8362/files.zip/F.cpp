#include<bits/stdc++.h>
using namespace std;
int n;
int ans;
int a[100005],k,sum;
map<int,int>tongyu;
vector<int>p;
int main(){
	
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		scanf("%d",&a[i]);
		a[i]=(a[i]+a[i-1])%k;
		tongyu[a[i]]++;
	}
	for(int i=1;i<=n;i++){
		if(a[i]==0&&tongyu[a[i]]!=0){
			sum=tongyu[a[i]];
			tongyu[a[i]]=0;
		}
		if(tongyu[a[i]]>0){
			p.push_back(tongyu[a[i]]);
			tongyu[a[i]]=0;
		}
	}
	ans+=(sum*(sum+1)/2);
	for(int i=0;i<p.size();i++){
		ans+=(p[i]*(p[i]-1)/2);
	}
	cout<<ans;
	return 0;
}
