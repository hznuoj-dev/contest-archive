#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
long long  ch[N];
signed main(void){
	int n,q;
	long long x;
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%lld",&ch[i]);
	scanf("%d",&q);
	while(q--){
		scanf("%lld",&x);
		long long ans=0;
		if(x>=ch[n]) {
			printf("%lld\n",x-1+ch[n]);
			continue;
		}
		else ans=ans+x;
		for(int i=n-1;i>=1;i--){
			if(x+ch[i]-1>=ch[i+1]) {
			ans=ans+ch[i+1]-1;
			break;
			}
			else ans=ans+x;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
