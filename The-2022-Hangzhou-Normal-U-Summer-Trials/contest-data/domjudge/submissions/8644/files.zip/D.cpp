#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
typedef long long ll;
const int N=1e5+10;
const int M=1e9+7;

struct node{
	vector<int> a;
}tr[N];
vector<int> cc,qzh;
int c[N];
ll ans,cnt;

void dfs(int x)
{
	cnt++;
	c[x]++;
	for(int i=0;i<tr[x].a.size();i++)
		if(!c[tr[x].a[i]])
			dfs(tr[x].a[i]);
}

void run()
{
	int n,q;
	int u,v,x,sum;
	
	cin >> n;
	for(int i=1;i<=n-1;i++)
	{
		cin >> u >> v;
		tr[u].a.push_back(v);
		tr[v].a.push_back(u);
	}
	cin >> q;
	while(q--)
	{
		memset(c,0,sizeof(c));
		cc.clear();
		qzh.clear();
		ans=sum=0;
		cin >> x;
		c[x]++;
		for(int i=0;i<tr[x].a.size();i++)
		{
			cnt=0;
			dfs(tr[x].a[i]);
			cc.push_back(cnt);
			sum+=cnt;
		}
		qzh.push_back(cc[0]);
		for(int i=1;i<cc.size();i++)
		{
			int num=qzh[i-1]+cc[i];
			qzh.push_back(num);
		}
		for(int i=0;i<qzh.size();i++)
			ans+=cc[i]*(sum-qzh[i]);
		cout << ans+n-1 << endl;
	}
}

signed main()
{
	int T=1;
	
	ios::sync_with_stdio(0);
	//cin >> T;
	while(T--)
		run();
	
	return 0;
}
