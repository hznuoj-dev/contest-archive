#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=1e5+10;
struct {
	int to,next;
}edge[maxn<<1];
int cut=0;
int head[maxn];
int sz[maxn];
int fa[maxn];
void dfs(int u,int f){
	sz[u]=1;
	fa[u]=f;
	for(int i=head[u];i;i=edge[i].next){
		int v=edge[i].to;
		if(v==f) continue;
		dfs(v,u);
		sz[u]+=sz[v];
	}
}
void add(int from,int to){
	edge[++cut].to=to;
	edge[cut].next=head[from];
	head[from]=cut;
}
int main(){
	int n;
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		int u,v;
		scanf("%d%d",&u,&v);
		add(u,v);
		add(v,u);
	}
	dfs(1,1);
	int q;
	scanf("%d",&q);
	while(q--){
		int x;
		scanf("%d",&x);
		int cut=0;
		int sum=0;
		for(int i=head[x];i;i=edge[i].next){
			int v=edge[i].to;
			if(v==fa[x]) continue;
			sum+=cut*sz[v]+sz[v];
			cut+=sz[v];
		}
		sum+=cut*(n-sz[x])+n-sz[x];
		printf("%d\n",sum);
	}
	
} 
