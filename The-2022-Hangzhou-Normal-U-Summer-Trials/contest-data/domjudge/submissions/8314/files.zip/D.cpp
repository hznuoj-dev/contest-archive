#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
#define wtnnb ios::sync_with_stdio(false);//cin.tie(0);cout.tie(0);
const int N = 1e6+10;
vector<int>to[N],to2[N];
//int from[N];
//vector<int>e[N];
ll xm[N];//��1Ϊ��������ڵ��� 
ll ans[N];

int vis[N],vis2[N];
int dfs(int f){
	if(to[f].size()==0)return 1;
	int ans2=0;
	for(int i=0;i<to[f].size();i++){
		ans2+=dfs(to[f][i]);
	}
	xm[f]=ans2; 
	//cout<<"from "<<f<<"�����У�"<<ans2<<endl;
	return ans2+1;
}
signed main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int n;cin>>n;
    for(int i=0;i<n-1;i++){
    	int a,b;cin>>a>>b;
    	to2[a].push_back(b);
    	to2[b].push_back(a);
    	//mp[{a,b}]=1;
    	//mp[{b,a}]=1;	
	}
	queue<int>q;
	q.push(1);vis2[1]=1;
	while(q.size()){
		int out=q.front();
		q.pop();
		for(int i=0;i<to2[out].size();i++){
			int to_=to2[out][i];
			if(!vis2[to_]){
				q.push(to_);
				vis2[to_]=1;
				to[out].push_back(to_);
				//from[to_]=out;
			}
		}
	}
/*	for(int i=1;i<=n;i++){
		cout<<i<<"to:";
		for(int u=0;u<to[i].size();u++){
			cout<<to[i][u]<<" ";
		}cout<<endl;
	}
*/ 
	dfs(1);
	
	for(int i=1;i<=n;i++){
		vector<int>v;int sum=0;
		for(int u=0;u<to[i].size();u++){
			v.push_back(xm[to[i][u]]+1);
			sum+=xm[to[i][u]]+1;
		}
		v.push_back(n-1-sum);
		sum=n-1;
		ans[i]=n-1;
		ll s=0;
		for(int u=0;u<v.size();u++){	
			//cout<<"ans"<<i<<"="<<ans[i]<<endl;
			//cout<<v[u]<<" ";
			s+=v[u]*(sum-v[u]);
		}
		ans[i]+=s/2;
		//cout<<"ans"<<i<<"="<<ans[i]<<endl;
	}
	

	ll qq;cin>>qq;
	while(qq--){
		ll x;cin>>x;
		cout<<ans[x]<<endl;
	}
	

    
}
/*
9
1 9
1 4
8 9
9 6
7 8
3 8
2 5
4 5
9
1
2
3
4
5
6
7
8
9


*/
