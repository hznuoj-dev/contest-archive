#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int  maxn = 5e5 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 21;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
ll a[maxn];
void solve(){
    int n;
    cin >> n;
    for(int i = 1; i <= n; ++i) cin >> a[i];
    a[n + 1] = 1e18;
    int q;
    cin >> q;
    while(q -- > 0) {
        ll t, ans = 0;
        cin >> t;
        int l = 1,r = n;
        while(l < r) {
            int mid = l + r >> 1;
            if(a[mid + 1] - a[mid] > t)r = mid;
            else l = mid + 1;
        }
        ans += a[l] - a[1] + (n - l + 1) * t;
        cout << ans << '\n';
    }
}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}