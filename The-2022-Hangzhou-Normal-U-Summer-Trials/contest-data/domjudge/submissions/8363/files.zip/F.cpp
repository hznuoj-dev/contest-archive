#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
int main(){
	long long n,a[100010],b[100010],k,l,r;
	cin>>n>>k;
	b[0]=0;
	for (int i=1; i<=n; i++){
		cin>>a[i];
		a[i]=a[i]%k;
		b[i]=b[i-1]+a[i];
	}
	long long ans=0; 
	long long bs=0;
	while(bs*k<=b[n]){
		l=1;r=1;
		while ((r<=n)){
			if (l>r) {
				r++;
				continue;
			}
			if (b[r]-b[l-1]==bs*k){
				ans++;
			}
			if(b[r]-b[l-1]<bs*k){
				r++;
			}else{
				l++;
			}
//			cout<<l<<" "<<r<<endl;
		}
		bs++;
//		cout<<bs<<" "<<ans<<endl;
//		cout<<endl;
	}
	cout<<ans<<endl;
}
