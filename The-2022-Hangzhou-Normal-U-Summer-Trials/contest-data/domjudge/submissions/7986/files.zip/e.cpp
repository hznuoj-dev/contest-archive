#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 5e1 + 5;

char g[maxn][maxn];

int sign[maxn][maxn][maxn][maxn];

int ay, ax, by, bx, n;

int y[4] = {1, 0, -1, 0};
int x[4] = {0, 1, 0, -1};

struct node {int ay, ax, by, bx;};

bool check(int y, int x){return !(y > n || x > n || y < 1 || x < 1 || g[y][x] == '*');}

int bfs(){
	queue<node>q;
	q.push({ay, ax, by, bx});
	sign[ay][ax][by][bx] = 1;
	while(!q.empty()){
		node e = q.front();
		//cout << e.ay << " " << e.ax << " " << e.by << " " << e.bx << endl;
		q.pop();
		if(e.ax == e.bx && e.ay == e.by) return sign[e.ay][e.ax][e.by][e.bx] - 1;
		for(int i = 0; i < 4; ++i){
			int aay = e.ay + y[i];
			int aax = e.ax + x[i];
			int bby = e.by + y[i];
			int bbx = e.bx + x[i];
			
			
			
			int aa = check(aay, aax);
			int bb = check(bby, bbx);
			
			if(aa && bb){
				if(sign[aay][aax][bby][bbx]) continue;
				sign[aay][aax][bby][bbx] = sign[e.ay][e.ax][e.by][e.bx] + 1;
				q.push({aay, aax, bby, bbx});
			} 
			else if(aa){
				if(sign[aay][aax][e.by][e.bx]) continue;
				sign[aay][aax][e.by][e.bx] = sign[e.ay][e.ax][e.by][e.bx] + 1;
				q.push({aay, aax, e.by, e.bx});
			} 
			else if(bb){
				if(sign[e.ay][e.ax][bby][bbx]) continue;
				sign[e.ay][e.ax][bby][bbx] = sign[e.ay][e.ax][e.by][e.bx] + 1;
				q.push({e.ay, e.ax, bby, bbx});
			} 
		}
	}
	return -1;
}

void solve(){
	cin >> n;
	for(int i = 1; i <= n; ++i){
		string e; cin >> e;
		for(int j = 1; j <= n; ++j){
			g[i][j] = e[j - 1];
			if(g[i][j] == 'a') ay = i, ax = j;
			if(g[i][j] == 'b') by = i, bx = j;
		} 
	}
 	int ans = bfs();
	if(ans == -1) cout << "no solution";
	else cout << ans;
	
}

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
