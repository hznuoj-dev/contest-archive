#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=50+10;
const int INF=2e18+1000;
const int SIZE=1000000+10;
const int mod=1e9+7;
int n,m,k;
string s[100];
struct points
{
    int x,y;
};
struct rec
{
    int ax,ay;
    int bx,by;
    int step;
};
void out(rec a){
    cout<<"ax: "<<a.ax<<" by: "<<a.ay<<endl;
    cout<<"bx: "<<a.bx<<" by: "<<a.by<<endl;
    return ;
}
int dx[4]={0,0,1,-1};
int dy[4]={1,-1,0,0};
bool vis[51][51][51][51];
bool check(int i,int j){
    if(i<1||i>n||j<1||j>n) return false;
    if(s[i][j]=='*') return false;
    return true;
}
void solve(){
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>s[i];
        s[i]="1"+s[i];
    }
    points sta,stb;
    rec st;
    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
        if(s[i][j]=='a'){
            sta.x=i;
            sta.y=j;
            st.ax=i;
            st.ay=j;
        }
        if(s[i][j]=='b'){
            stb.x=i;
            stb.y=j;
            st.bx=i;
            st.by=j;
        }
        }
    }
    st.step=0;
    queue<rec>que;
    que.push(st);
    while(!que.empty()){
        auto now=que.front();
        que.pop();
        if(now.ax==now.bx&&now.ay==now.by){
            cout<<now.step<<endl;
            return ;
        }
        rec to;
        for(int i=0;i<4;i++){
            to.ax=now.ax+dx[i];
            to.ay=now.ay+dy[i];
            to.bx=now.bx+dx[i];
            to.by=now.by+dy[i];
            to.step=now.step+1;
            if(!check(to.ax,to.ay)) to.ax=now.ax,to.ay=now.ay;
            if(!check(to.bx,to.by)) to.bx=now.bx,to.by=now.by;
            if(!vis[to.ax][to.ay][to.bx][to.by]){
                vis[to.ax][to.ay][to.bx][to.by]=1;
                que.push(to);
            }
        }
    }
    cout<<"no solution"<<endl;
    return ;
}
void inits(){}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int ts=1;
    inits();
    while(ts--){
        solve();
    }
    return 0;
}