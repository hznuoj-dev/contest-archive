#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[500005],b[500005],q,x,t;
signed main(){
	cin >> n;
	for (int i=1;i<=n;++i) cin >> a[i];n--;
	for (int i=1;i<=n;++i) {
		b[i]=a[i+1]-a[i];
		//cout << "b[" << i << "]=" << b[i] << endl;
	}
	cin >> q;
	while (q--) {
		cin >> x;
		t=upper_bound(b+1,b+1+n,x)-b;
		//cout << "t=" << t << endl;
		cout << a[t]-a[1]+(n-t+2)*x << endl;
	}
}
