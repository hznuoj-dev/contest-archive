#include<bits/stdc++.h>
using namespace std;
int a[26];
struct Node{
    string  str;
};
int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);
    string str;
    getline(cin,str);
    int n;
    for(int i=0;i<str.length();i++){
        a[str[i]-97]=i;
    }
    cin>>n;
    int k;
    getchar();
    struct Node x[n];
    for(int i=0;i<n;i++){
        getline(cin,x[i].str);
    }
    cin>>k;
    int t;
    for(int i=0;i<n;i++){
        t=i;
        for(int j=i+1;j<n;j++){
            if(x[t].str.length()<x[j].str.length()){
                int flag=0;
                for(int l=0;l<x[t].str.length();l++){
                    if(x[t].str[l]!=x[j].str[l]){
                        flag=1;
                        break;
                    }
                }
                if(flag==0){
                    t=j;
                }else{
                    int flag1=0;
                    int len=x[t].str.length();
                    for(int l=0;l<len;l++){
                        if(a[x[t].str[l]-97]<a[x[j].str[l]-97]){
                            for(int m=0;m<l;m++){
                                if(x[t].str[m]!=x[l].str[m]){
                                    flag1=1;
                                    break;
                                }
                            }
                            if(flag1==0){
                                t=j;
                                break;
                            }
                        }
                    }
                }
            }else{
                int flag1=0;
                int len;
                if(x[t].str.length()<x[j].str.length())len = x[t].str.length();
                else len = x[j].str.length();
                for(int l=0;l<len;l++){
                    if(a[x[t].str[l]-97]<a[x[j].str[l]-97]){
                        for(int m=0;m<l;m++){
                            if(x[t].str[m]!=x[l].str[m]){
                                flag1=1;
                                break;
                            }
                        }
                        if(flag1==0){
                            t=j;
                            break;
                        }
                    }
                }
            }
        }
        struct Node tmp1= x[t];
        x[t]=x[i];
        x[i]=tmp1;
    }
    int xxx;
    cout<<x[n-k].str<<endl;
    return 0;
}