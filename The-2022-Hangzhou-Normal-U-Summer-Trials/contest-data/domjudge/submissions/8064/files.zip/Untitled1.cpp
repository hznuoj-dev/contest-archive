#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int maxn=4e5+10;
const ll mod=1e9+7;
ll fac[maxn],inv[maxn];
ll pow_mod(ll a,ll n){
	ll ret=1;
	while(n){
		if(n&1) ret=ret*a%mod;
		a=a*a%mod;
		n>>=1;
	}
	return ret;
}
void init(){
	fac[0]=1;
	for(int i=1;i<maxn;i++){
		fac[i]=fac[i-1]*i%mod;
	}
}
ll Cc(ll x,ll y){
	//printf("1");
	return fac[x]*pow_mod(fac[y]*fac[x-y]%mod,mod-2)%mod;
}
ll c[maxn];
int main(){
	ll n,q,s;
	init();
	scanf("%lld%lld%lld",&n,&s,&q);
	for(int i=1;i<=n;i++){
		scanf("%lld",&c[i]);
		s-=c[i];
	}
	
	while(q--){
		ll x,v;
		scanf("%lld%lld",&x,&v);
		s-=(v-c[x]);
		c[x]=v;
		if(s<0){
			printf("0\n");
			continue;
		}else if(s==0){
			printf("1\n");
			continue;
		}else{
			printf("%lld\n",Cc(s+n,n));
		}
	}
	
} 

