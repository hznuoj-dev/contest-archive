#include <bits/stdc++.h>
#define N 1005
using namespace std;
char lex[30];
char str[N][N];
char ans[N];
bool f[200][200],F[N];
int n,k;
int check(int a,int b){
	int lena=strlen(str[a]);
	int lenb=strlen(str[b]);
	for(int i=0;i<min(lena,lenb);i++){
		if(str[a][i]==str[b][i])continue;
		if(f[str[a][i]][str[b][i]])return 0;
		else return 1;
	}
	if(lena>lenb)return 1;
	return 0;
}
int main(){
	scanf("%s",lex);
	for(int i=0;i<26;i++)
		for(int j=i+1;j<26;j++)
			f[lex[i]][lex[j]]=1;
	scanf("%d",&n);
	for(int i=1;i<=n;i++)
		scanf("%s",str[i]);
	scanf("%d",&k);
	for(int i=1;i<=k;i++){
		int j=1;
		while(F[j])j++;
		int t=j;
		for(j=j+1;j<=n;j++)
			if(check(t,j))t=j;
		F[t]=1;
		int leni=strlen(str[i]);
		int lent=strlen(str[t]);
		for(j=0;j<=leni;j++)
			str[0][j]=str[i][j];
		for(j=0;j<=lent;j++)
			str[i][j]=str[t][j];
		for(j=0;j<=leni;j++)
			str[t][j]=str[0][j];
	}
	printf("%s",str[k]);
	return 0;
}
