#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
typedef long long ll;
const int N=2e5+10;
const int M=1e9+7;

string s;

void run()
{
	int cnt=0;
	
	cin >> s;
	for(int i=0;i<s.length();i++)
		if(s[i]=='h')
			if(s[i+1]=='z')
				if(s[i+2]=='n')
					if(s[i+3]=='u')
					{
						cnt++;
						i+=3;
					}
					
	cout << cnt;
}

int main()
{
	int T=1;
	
	ios::sync_with_stdio(0);
	//cin >> T;
	while(T--)
		run();
	
	return 0;
}
