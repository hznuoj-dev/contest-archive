#include<bits/stdc++.h>
using namespace std;

int sum[100010], a[100010];
int n, k, ans = 0;

int main()
{
    cin >> n >> k;
    sum[0] = 0;
    for(int i = 1;i <= n;i++)
    {
        cin >> a[i];
        sum[i] = sum[i - 1] + a[i];
    }
    for(int i = 0;i <= n;i++)
    {
        for(int j = i + 1;j <= n;j++)
        {
            if((sum[j] - sum[i]) % k == 0)
                ans++;
        }
    }
    cout << ans;
    return 0;
}