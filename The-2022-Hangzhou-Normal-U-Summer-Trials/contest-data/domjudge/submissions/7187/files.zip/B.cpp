#include<bits/stdc++.h>

#define debug(x) cerr << #x << " = " << x << '\n'

typedef long long ll;

using namespace std;
vector<int> v(100);

int cmp(string a, string b) {
	int n = a.size(), m = b.size(); 
	for (int i = 0; i < min(n, m); ++i) {
		if (v[a[i] - 'a' + 1] > v[b[i] - 'a' + 1]) return 0;
		else return 1;
	}
	if (n > m) return 0;
	else return 1;
}

void solve() {
	string s;
	cin >> s;

	for (int i = 0; i < s.size(); ++i) {
		v[s[i] - 'a' + 1] = i + 1;
	}
	
	int n;
	cin >> n;
	vector<string> b(n);
	for (int i = 0; i < n; ++i) {
		cin >> b[i];
	}
	
//	for (int i = 0; i < n; ++i) {
//		debug(b[i]);
//	}
	sort(b.begin(), b.end(), cmp);
	int k;
	cin >> k;
	cout << b[k - 1] << '\n';
}

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
