#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10;
char s[N],ch,ch1,ch2;
void solve(){
	int q,top=-1,op;
	scanf("%d",&q);
	while(q--){
		scanf("%d",&op);
		if(op==3){
			scanf(" %c %c",&ch1,&ch2);
			for(int i=0;i<=top;i++){
				if(s[i]==ch1)s[i]=ch2;
			}
		}else if(op==1){
			scanf(" %c",&ch);
			s[++top]=ch;
		}else{
			if(top>=0)top--;
		}
	}
	if(top==-1)printf("The final string is empty");
	else for(int i=0;i<=top;i++)printf("%c",s[i]);
}
int main(void){
	int t=1;
	//scanf("%d",&t);
	while(t--)solve();
	return 0;
}
