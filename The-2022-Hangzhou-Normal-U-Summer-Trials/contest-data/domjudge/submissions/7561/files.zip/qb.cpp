#include<bits/stdc++.h>
using namespace std;
vector<string>str,str1;
int main()
{
	
	string a;
	cin>>a;
	int n;
	cin>>n;
	string r="abcdefghijklmnopqrstuvwxyz";
	for(int i=0;i<n;i++)
	{
		string x;
		cin>>x;
		string xx;
		for(int j=0;j<x.length();j++)
		{
			xx+=a.find(x[j])+'a';
		}
		str.push_back(xx);
	}
	sort(str.begin(),str.end());
	for(int i=0;i<n;i++)
	{
		string x=str[i];
		string xx;
		for(int j=0;j<x.length();j++)
		{
			xx+=a.find(x[j])+'a';
		}
		str1.push_back(xx);
	}
	int re;
	cin>>re;
	cout<<str1[re-1];
}
