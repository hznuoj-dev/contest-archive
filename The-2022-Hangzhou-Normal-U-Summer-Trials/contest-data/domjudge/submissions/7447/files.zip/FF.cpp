#include <bits/stdc++.h> 
using namespace std;
long long a[100050],sum[100050];
int main()
{
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	long long n,k,i,j;
	cin >> n >> k;
	for (i=1; i<=n; i++) 
	{
		cin >> a[i];
		a[i]=a[i]%k;
		sum[i]=sum[i-1]+a[i];
	}
	long long ans=0;
	for (i=0; i<=n; i++)
	{
		for (j=i+1; j<=n; j++)
		{
			if ((sum[j]-sum[i])%k==0) ans++;
		}
	}
	cout << ans;
}
