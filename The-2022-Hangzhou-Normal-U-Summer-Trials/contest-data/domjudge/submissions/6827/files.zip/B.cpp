#include<bits/stdc++.h>
using namespace std;
typedef unsigned long long ull;
typedef long long ll;
const int N = 2e5 + 10;
int n,m,x,y;
int a[N];
string s;
int main(){
    cin>>s;
    ll ans=0;
    for(int i=0;i<s.size();++i){
        if(s[i]=='h'){
            if(s[i+1]=='z'){
                if(s[i+2]=='n'){
                    if(s[i+3]=='u'){
                        ans++;
                    }else{
                        i+=2;
                    }
                }else{
                    ++i;
                }
            }else{
                continue;
            }
        }
    }
    cout<<ans<<endl;
}