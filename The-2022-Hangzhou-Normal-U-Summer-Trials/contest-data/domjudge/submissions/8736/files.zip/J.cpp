#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 5e5 + 7;

struct node {
	int op, x, y;
}a[N];

int fa[505];
int find(int x) {
	return x == fa[x] ? x : fa[x] = find(fa[x]);
}
queue<int> ans;
void solve() {
	int q;
	cin >> q;
	for (int i = 1; i <= q; ++i) {
		cin >> a[i].op;
		if (a[i].op == 1) {
			char x;
			cin >> x;
			a[i].x = x - 'a' + 1;
		}
		else if (a[i].op == 2) {
		}
		else {
			char x,y;
			cin >> x >> y;
			a[i].x = x - 'a' + 1;
			a[i].y = y - 'a' + 1;
		}
	}
	for (int i = 0; i <= 500; ++i) {
		fa[i] = i;
	}
	for (int i = q; i >= 1; --i) {
		if (a[i].op == 3) {
			int x = a[i].x;
			int y = a[i].y;
			x = find(x);
			y = find(y);
			if (x != y) {
				fa[x] = y;
			}
		}
		else if (a[i].op == 1) {
			ans.push(find(a[i].x));
		}
		else {
			ans.pop();
		}
	}
	if (ans.empty()) {
		cout << "The final string is empty";
		return;
	}
	string s;
	while (!ans.empty()) {
		s += char(ans.front() + 'a' - 1);
		ans.pop();
	}
	reverse(s.begin(),s.end());
	cout << s;
}
int main() {
	//ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
/*
5
1 2
1 3
3 4
3 5
5
1
2
3
4
5
*/
