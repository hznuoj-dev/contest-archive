#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int N = 1000010;

int main ()
{
    string s; cin >> s;
    int cnt = 0;
    for (int i = 0; i + 3 < s.size(); i ++ ) {
        if (s[i] == 'h' && s[i+1] == 'z' && s[i+2] == 'n' && s[i+3] == 'u') ++ cnt;
    }
    cout << cnt << endl;
    return 0;
}