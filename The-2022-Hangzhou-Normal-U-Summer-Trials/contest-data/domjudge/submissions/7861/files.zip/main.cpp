#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int  maxn = 2e5 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 52;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}


struct node{
    int opt, x, y;
};
int f[maxn];
void solve(){
    int q;
    cin >> q;
    for(int i = 0; i <= 26; ++i)f[i] = i;
    vector<node> a(q);
    for(int i = 0; i < q; ++i) {
        int opt;
        cin >> opt;
        if(opt == 1) {
            string x;
            cin >> x;
            a[i].opt = opt;
            a[i].x = x[0] - 'a';
        } else if(opt == 2){
            a[i].opt = 2;
        } else {
            a[i].opt = 3;
            string x, y;
            cin >> x >> y;
            a[i].x = x[0] - 'a';
            a[i].y = y[0] - 'a';
        }
    }
    reverse(a.begin(), a.end());
    int del = 0;
    string ans;
    for(int i = 0; i < q; ++i) {
        int opt = a[i].opt;
        if(opt == 1 && del) {
            --del;
            continue;
        }
        if(opt == 2) {
            ++del;
            continue;
        }
        if(opt == 1) {
            int x = a[i].x;
            int cur = f[f[x]];
            ans += (cur + 'a');
            continue;
        }
        int x = a[i].x, y = a[i].y;
        f[x] = f[f[y]];
    }
    if(ans.empty()) cout << "The final string is empty" << '\n';
    else {
        reverse(ans.begin(),ans.end());
        cout << ans << '\n';
    }
}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}