#include<iostream>
#include<string>
#include<cstdio>
typedef long long ll;
using namespace std;
int main(){
string s;
getline(cin,s);

ll sum = 0;
for(int i = 0;i<s.length()-3;i++){
	if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')
	sum++;
}
cout <<sum;


} 
