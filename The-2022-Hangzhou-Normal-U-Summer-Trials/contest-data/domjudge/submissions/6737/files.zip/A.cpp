#include <bits/stdc++.h>

using namespace std;

void solve(){
	string s;
	cin >> s;
	int ans = 0;
	for(int i = 0; i + 3 < s.size(); i++){
		if(s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') ans++;
	}
	cout << ans << '\n';
}

int main(){
	int T = 1;
	while(T--) solve();
	return 0;
}
