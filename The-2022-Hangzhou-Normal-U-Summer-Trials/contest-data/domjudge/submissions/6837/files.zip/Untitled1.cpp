#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
	string a;
	cin>>a;
	int top=0;
	int cut=0;
	for(int i=0;i<a.length();i++){
		if(top==0&&a[i]=='h') top++;
		else if(top==1&&a[i]=='z') top++;
		else if(top==2&&a[i]=='n') top++;
		else if(top==3&&a[i]=='u'){
			top=0;
			cut++;
		}else top=0;
	}
	cout<<cut;
} 
