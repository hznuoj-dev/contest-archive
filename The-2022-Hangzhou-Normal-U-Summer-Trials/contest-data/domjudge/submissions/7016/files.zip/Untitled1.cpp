#include<bits/stdc++.h>
using namespace std;
char a[1000005];
int main()
{
	int sum=0,i;
	cin>>a;
	//cout<<a.size();
	for(i=0;i<sizeof(a)-3;)
	{
		if(a[i]=='h'&&a[i+1]=='z'&&a[i+2]=='n'&&a[i+3]=='u')
		{
			sum++;
			i+=4;
		}
		else
		i++;
	 } 
	cout<<sum;
} 
