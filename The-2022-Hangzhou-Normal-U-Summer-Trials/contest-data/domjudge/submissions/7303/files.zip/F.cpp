#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define wtnnb ios::sync_with_stdio(false);//cin.tie(0);cout.tie(0);
const int N = 1e6+10;
ll a[N];
ll s[N];
signed main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int n,k;cin>>n>>k;   
    for(int i=1;i<=n;i++)cin>>a[i];
	ll ans=0;
    for(int i=1;i<=n;i++){
    	s[i]=s[i-1]+a[i];
    	if(s[i]%k==0)ans++;
    	//cout<<"s"<<i<<":"<<s[i]<<endl;
	}
    map<ll,int>mp;
    for(int i=1;i<=n;i++)mp[(s[i]%k)]++;
    
    map<ll,int>::iterator it=mp.begin();
    for(;it!=mp.end();it++){
    	//cout<<it->first<<","<<it->second<<endl;
    	ll cost=0;
    	ll x= it->second;
    	if(x<=0)continue;
    	cost=(x-1)*x/2;
    	ans+=cost;
	}
	cout<<ans<<endl;
}
/*
6 7
0 1 2 4 7 7
*/
