#include<iostream>
#include<algorithm>
#include<string>

using namespace std;

int a[26];

string ans[1007];

int gcd(string A,string B)
{
	int len=min(A.length(),B.length());
	for(int i=0;i<len;++i){
		if(a[A[i]-'a']==a[B[i]-'a'])continue;
		return a[A[i]-'a']<a[B[i]-'a'];
	}
}

int main(){
	string s;
	cin>>s;
	for(int i=0;i<s.length();++i){
		a[s[i]-'a']=i+1;
	}
	int n;
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>ans[i];
	}
	sort(ans,ans+n,gcd);
	int k;
	cin>>k;
	cout<<ans[k-1];
	return 0;
}
