#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=1e6+7;
int n, k;
int a[maxn];
int pre[maxn];
map<int,int>mp;
signed main(){
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		pre[i]=pre[i-1]+a[i];
	}
	for(int i=1;i<=n;i++){
		pre[i]%=k;
	}
	int cnt=0;
	int ans=0;
	for(int i=1;i<=n;i++){
		if(pre[i]==0){
			cnt++;
		}
		else{
			if(mp[pre[i]]){
				ans+=mp[pre[i]];
			}
		}
		mp[pre[i]]++;
	}
	ans+=((cnt+1)*cnt)/2;
	cout<<ans<<endl;
} 
