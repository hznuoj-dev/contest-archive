#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
ll n;
double v[10];
typedef struct{
	ll x;
	ll y;
	ll z;
}h;
h a[3010];
ll s,t;
double b[3010][3010];
double dis[3010];
ll vis[3010];
void dij(){
	for(int i=1;i<=n;i++){
		dis[i]=0x3f3f3f3f;
	}
	memset(vis,0,sizeof vis);
	dis[s]=0;
//	cout<<dis[2]<<endl;
	for(int i=1;i<n;i++){
		int x=0;
		for(int j=1;j<=n;j++)
		if(!vis[j]&&(x==0||dis[j]<dis[x]))x=j;
		vis[x]=1;
		for(int j=1;j<=n;j++){
		dis[j]=min(dis[j],dis[x]+b[x][j]);
//		cout<<j<<" "<<dis[x]<<endl;
		}
	}
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	for(int i=1;i<=5;i++){
		cin>>v[i];
	}
	cin>>s>>t;
	for(int i=1;i<=n;i++){
		cin>>a[i].x>>a[i].y;
		if(a[i].x>=1&&a[i].y>=1)
		a[i].z=1;
		else if(a[i].x<=-1&&a[i].y>=1)
		a[i].z=2;
		else if(a[i].x<=-1&&a[i].y<=-1)
		a[i].z=3;
		else if(a[i].x>=1&&a[i].y<=-1)
		a[i].z=4;
		else 
		a[i].z=5;
	} 
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			double ans=sqrt(pow(a[i].x-a[j].x,2)+pow(a[i].y-a[j].y,2));
//			cout<<a[i].y<<"ss"<<a[j].y<<endl;
//			cout<<ans<<endl;
			if(a[i].z==a[j].z){
				b[i][j]=ans*1.0/v[a[i].z];
			}
			else{
				b[i][j]=ans*1.0/v[5];
			}
//			cout<<i<<" "<<j<<" "<<b[i][j]<<endl;
		}
	}
	dij();
	cout<<fixed<<setprecision(10)<<dis[t]<<endl;
} 
/*

*/
