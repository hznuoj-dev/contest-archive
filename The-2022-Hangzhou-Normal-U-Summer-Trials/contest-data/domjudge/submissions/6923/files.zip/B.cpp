#include<bits/stdc++.h>
#define int long long
using namespace std;
string s,a[1003];int n,k;
map <char,char> mp;
signed main(){
	cin >> s;
	for (int i=0;i<26;++i) mp[s[i]]='a'+i;
	cin >> n;
	for (int i=1;i<=n;++i) {
		cin >> a[i];
		for (int j=0;j<a[i].length();++j) {
			a[i][j]=mp[a[i][j]];
		}
	}
	sort(a+1,a+1+n);
	cin >> k;
	for (int i=0;i<a[k].length();++i) {
		cout << s[a[k][i]-'a'];
	}
}
