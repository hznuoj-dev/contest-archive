#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define fi first
#define se second
#define N 200010
string s;


void solve(){
	ll n,cmp,num,q;
	string c[2000];
	map <char,char> mp;
	cin>>s;
	for(ll i=0;i<s.length();i++){
		mp[s[i]]='0'+i+1;
	}
	cin>>n;
	for(ll i=1;i<=n;i++){
		cin>>c[i];
		for(ll j=0;j<c[i].length();j++){
			c[i][j]=mp[c[i][j]];
		}
	}
	cin>>num;
	sort(c+1,c+n+1);
	for(ll i=0;i<c[num].length();i++){
		q=c[num][i]-'0'-1;
		cout<<s[q];
	}
	
	
	
}

int main(){
	int T=1;
	ios::sync_with_stdio(false);
	//cin>>T;
	while(T--){
		solve();
	}
	return 0;
}
