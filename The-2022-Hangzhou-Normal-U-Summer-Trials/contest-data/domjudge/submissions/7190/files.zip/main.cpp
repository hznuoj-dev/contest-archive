#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

int n;
string a[100];
int f[51][51][51][51];

int v[4][2] = {{0, 1}, {0, -1}, {1, 0}, {-1, 0}};

int ans = 1e9;
void dfs(int x1, int y1, int x2, int y2, int cnt){
    if(x1 == x2 && y1 == y2) ans = min(ans, cnt);
    if(cnt > f[x1][y1][x2][y2]) return;
    f[x1][y1][x2][y2] = cnt;
    for(int i=0;i<4;i++){
        int xx1 = x1 + v[i][0], yy1 = y1 + v[i][1], xx2 = x2 + v[i][0], yy2 = y2 + v[i][1];
        if(xx1 < 1 || xx1 > n || yy1 < 1 || yy1 > n || a[xx1][yy1] == '*'){
            xx1 = x1, yy1 = y1;
        }
        if(xx2 < 1 || xx2 > n || yy2 < 1 || yy2 > n || a[xx2][yy2] == '*'){
            xx2 = x2, yy2 = y2;
        }
        dfs(xx1, yy1, xx2, yy2, cnt+1);
    }
}

void solve(){
    cin >> n;
    int xa, ya, xb, yb;
    for(int i=1;i<=n;i++){
        cin >> a[i];
        a[i] = ' ' + a[i];
        for(int j=1;j<=n;j++){
            if(a[i][j] == 'a') xa = i, ya = j;
            if(a[i][j] == 'b') xb = i, yb = j;
        }
    }
    memset(f, 0x7f, sizeof(f));
    dfs(xa, ya, xb, yb, 0);
    if(ans > 1e9-1) cout << "no solution\n";
    else cout << ans << '\n';
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}