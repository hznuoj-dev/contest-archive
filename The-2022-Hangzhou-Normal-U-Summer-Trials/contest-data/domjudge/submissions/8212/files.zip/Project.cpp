#include<bits/stdc++.h>
#include<unordered_map>
#pragma GCC optimize(2)
#define endl '\n'
#define ll long long
#define ull unsigned long long
#define mem(a, b) memset(a, b, sizeof a)
//#define int ll
#define pii pair<int,int>
#define all(a) a.begin(), a.end()
using namespace std;

#define dbg(x) do { cout << #x << " -> "; err(x); } while(0)

void err()
{
	cout << endl;
}

template<class T, class... Ts>
void err(const T& arg, const Ts &... args)
{
	cout << arg << ' ';
	err(args...);
}

const int maxn = 1e5 + 10;
const ll mod = 1e9 + 10;
const ll MOD = 1000003;
const double eps = 1e-4;
const double pi = acos(-1.0);
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;

ll n, m, k, q;
ll a[maxn];
map<ll, ll> mp;

void solve()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		if (i >= 2)
			mp[a[i] - a[i - 1]]++;
	}
	cin >> q;
	ll cnt;
	while (q--)
	{
		cin >> k;
		if (k >= mp.rbegin()->first)
		{
			cout << a[n] + k - a[1] << endl;
			continue;
		}
		cnt = 0;
		for (auto i : mp)
		{
			if (k >= i.first)
				cnt += i.second * i.first;
			else
				cnt += k;
		}
		cnt += k;
		cout << cnt << endl;
	}
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	//freopen("mosalah.in", "r", stdin);
	int t = 1;
	//cin >> t;
	while (t--)
		solve();
	return 0;
}