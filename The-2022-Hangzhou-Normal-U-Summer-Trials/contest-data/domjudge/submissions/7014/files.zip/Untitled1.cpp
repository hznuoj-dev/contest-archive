#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=1e4;
int m[30];
string s[maxn];
int cmp(string a,string b){
	for(int i=0;i<a.length()&&i<b.length();i++){
		if(m[a[i]-'a']!=m[b[i]-'a']) return m[a[i]-'a']<m[b[i]-'a'];
	}
	return a.length()<b.length();
}
int main(){
	string a;
	cin>>a;
	for(int i=0;i<a.length();i++){
		m[a[i]-'a']=i;
	}
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++) cin>>s[i];
	sort(s,s+n,cmp);
	int k;
	scanf("%d",&k);
	cout<<s[k-1];
} 
