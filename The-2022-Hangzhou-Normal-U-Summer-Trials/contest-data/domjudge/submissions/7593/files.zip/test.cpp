#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=5e3+10;
const int INF=2e18+1000;
const int SIZE=1000000+10;
const int mod=1e9+7;
int n,m,k;
vector<int>g[SIZE];
int f[SIZE];
int ans[SIZE];
void dfs1(int u,int fa){
    f[u]=1;
    for(auto v:g[u]){
        if(v==fa) continue;
        dfs1(v,u);
        f[u]+=f[v];
    }
}
void dfs2(int u,int fa){
    for(auto v:g[u]){
        if(v==fa) continue;
        dfs2(v,u);
    }
    int now=0;
    for(auto v:g[u]){
        if(v==fa) continue;
        ans[u]+=now*f[v];
        now+=f[v];
    }
    ans[u]+=now;
    ans[u]+=(f[1]-f[u]);
    ans[u]+=now*(f[1]-f[u]);
}
void solve(){
    cin>>n;
    for(int i=1;i<n;i++){
        int a,b;
        cin>>a>>b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    dfs1(1,-1);
    dfs2(1,-1);
    cin>>k;
    while(k--){
        int now;
        cin>>now;
        cout<<ans[now]<<endl;
    }
}
void inits(){}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int ts=1;
    inits();
    while(ts--){
        solve();
    }
    return 0;
}