#include <bits/stdc++.h>

#define ll long long
#define PII pair<ll, int>
#define dbg(x) cerr << #x << " = " << x << endl;

using namespace std; 

const int N = 2e5 + 10;
const int INF = 0x3f3f3f3f;         // 1061109567
const ll INFF = 0x3f3f3f3f3f3f3f3f; // 4557430888798830399
const double esp = 1e-8, pi = acos(-1.0);
const int MOD = 998244353;

ll qmi(int a, int b)
{
    ll ret = 1 % MOD;
    while (b)
    {
        if (b & 1) ret = ret * (ll)a % MOD;

        a = a * (ll)a % MOD;
        b >>= 1;
    }
    
    return ret;
}

int gcd(int a, int b)
{
    return b ? gcd(b, a % b) : a;
}

int lowbit(int x)
{
    return x & -x;
}

/////////////////////////////////////////////////////////// 

ll n, k;
ll a[N];

void solve()
{
    cin >> n >> k;
    for (int i = 1; i <= n; i ++ ) cin >> a[i];
    for (int i = 1; i <= n; i ++ ) a[i] += a[i - 1];

    map<ll, ll> mp;
    for (int i = 1; i <= n; i ++ )
    {
        ll t = a[i] % k;
        mp[t] ++;
    }

    ll ret = 0;
    for (auto t : mp)
    {
        ret += (t.second - 1) * t.second / 2;
        if (!t.first) ret += t.second; 
    }

    cout << ret << endl;
}

int main()
{
    ios::sync_with_stdio(0);

    int T = 1;
    //cin >> T;
    //scanf("%d", &T);
    //init();

    while (T--)
    {
        solve();
    }

    return 0;
}
