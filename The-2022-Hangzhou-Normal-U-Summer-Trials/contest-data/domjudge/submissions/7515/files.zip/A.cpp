#include<iostream>
using namespace std;
#include<cstdio>
#include<string.h>

long long subString(char* str, char* sub)
{
    long long count = 0, i, j;
    for (i = 0; i < strlen(str); i++) {
        for (j = 0; j < strlen(sub); j++) {
            if (str[i + j] != sub[j]) {
                break;
            }
        }
        if (j == strlen(sub)) {
            count++;
        }
    }
    return count;
}

int main()
{
    char str[100001], sub[10];
    scanf("%s", str);
    char a[] = "hznu";
    strcpy(sub, a);
    printf("%lld", subString(str, sub));
    return 0;
}
