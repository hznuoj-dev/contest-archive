#include <iostream>
#include <string>
#include <bits/stdc++.h>
using namespace std;
const int maxn=5e5+3;
long long a[maxn];
long long b[maxn];
long long q[maxn];
int main(){
	long long t;
	cin>>t;
	for(long long i=0;i<t;i++){
		cin>>a[i];
	}
	sort(a,a+t);
	for(long long i=1;i<t;i++){
		b[i]=a[i]-a[i-1];
	}
	sort(b,b+t);
	long long n;
	cin>>n;
	for(long long i=0;i<n;i++){
		cin>>q[i];
	}
	long long temp=t;
	long long sum=0;
	long long m=1;
	for(long long i=0;i<n;i++){
		long long j;
		if(i==0) j=0;
		else j=q[i-1];
		for(;j<q[i];j++){
			if(temp<=1){
				sum++;
			}
			else{
				if(j<b[m]) sum+=temp;
				else{
					m++;
					temp--;
					while(j==b[m]){
						m++;
						temp--;
					}
					if(temp<=1){
						sum+=1;
					}
					else sum+=temp;
				}
			}
		}
		cout<<sum<<endl;	
	} 
}
