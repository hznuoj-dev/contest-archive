#include<bits/stdc++.h>
using namespace std;
string a[1005];
map<char,int>mp;
bool compare(string a,string b){
	int lena=a.length(),lenb=b.length();
	for(int i=0;i<min(lena,lenb);i++){
		if(mp[a[i]]<mp[b[i]]){
			return true;
		}
		else if(mp[a[i]]>mp[b[i]]){
			return false;
		}
	}
	if(lena<lenb){
		return true;
	}
	else{
		return false;
	}
}
int main()
{
	string s;
	cin>>s;
	for(int i=0;i<s.length();i++){
		mp[s[i]]=i;
	}
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	for(int i=0;i<n;i++){
		int k=i;
		for(int j=i+1;j<n;j++){
			if(compare(a[j],a[k])){
				k=j;
			}
		}
		if(k!=i){
			string tmp;
			tmp = a[i];
			a[i]=a[k];
			a[k]=tmp;
		}
	}
	int k;
	cin>>k;
	cout<<a[k-1];
}
