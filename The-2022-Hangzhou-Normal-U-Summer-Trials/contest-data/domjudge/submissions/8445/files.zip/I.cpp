#include<bits/stdc++.h>
#define int long long
using namespace std;
const int p=1000000007;
int quick_pow(int x,int n){int res=1;while (n) {if (n&1) res=res*x%p;x=x*x%p;n>>=1;}return res;}
int fac[400005],n,s,q,Cc[400005],sum,x,y,inv[400005],a[400005];
int C(int n,int m){if (n<m) return 0;return fac[n]*inv[m]%p*inv[n-m]%p;}
signed main(){
	fac[0]=1;inv[0]=1;
	for (int i=1;i<=400000;++i) {
		fac[i]=fac[i-1]*i%p;
		inv[i]=quick_pow(fac[i],p-2);
	}
	cin >> n >> s >> q;
	for (int i=n-1;i<=n-1+s;++i) {
		if (i==n-1) Cc[i-(n-1)]=C(i,n-1);
		else Cc[i-(n-1)]=Cc[i-(n-1)-1]+C(i,n-1);
	}
	for (int i=1;i<=n;++i) {
		cin >> a[i];sum+=a[i];
	}
	while (q--) {
		cin >> x >> y;
		sum-=a[x];a[x]=y;sum+=y;
		//cout << "sum=" << sum << ",s=" << s << endl;
		if (sum>s) cout << 0 << endl;
		else cout << Cc[s-sum] << endl;
	}
}
