#include<bits/stdc++.h>
using namespace std;
#define ll long long
char re[30];
map<char,int> a;
int main()
{
	char s[1007][1007];
	cin>>re;
	for(int i=0;i<26;i++)
	{
		a[re[i]]=i;
	}
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>s[i];
	}
	for(int i=0;i<n-1;i++)
	{
		for(int x=0;x<n-i-1;x++)
		{
			if(strlen(s[x])<=strlen(s[x+1]))
			{
				for(int j=0;j<strlen(s[x]);j++)
				{
					int cnt1=a[s[x][j]];
					int cnt2=a[s[x+1][j]];
					if(cnt1>cnt2)
					{
						swap(s[x],s[x+1]);
						break;
					} 
				}
			}
			else
			{
				for(int j=0;j<strlen(s[x+1]);j++)
				{
					int cnt1=a[s[x][j]];
					int cnt2=a[s[x+1][j]];
					if(cnt1>cnt2)
					{
						swap(s[x],s[x+1]);
						break;
					}
				}
			}
		}
	}
	int k;
	cin>>k;
	for(int i=0;i<k;i++)
	{
		cout<<s[i]<<endl;
	}
}
