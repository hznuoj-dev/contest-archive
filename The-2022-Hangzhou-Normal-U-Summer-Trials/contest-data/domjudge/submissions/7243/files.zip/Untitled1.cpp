#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=5e5+10;
ll a[maxn];
ll c[maxn];
int main(){
	int n;
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%lld",&a[i]);
		if(i) c[i-1]=a[i]-a[i-1];
	}
	int q;
	scanf("%d",&q);
	while(q--){
		ll x;
		scanf("%lld",&x);
		int in=upper_bound(c,c+n-1,x)-c;
		//printf("----%d\n",in);
		if(in==n) printf("%lld\n",a[n-1]+x-a[0]);
		else{
			printf("%lld\n",a[n-1]+x-a[0]-(a[n-1]-a[in]-(n-1-in)*x));
		}
	}
	
} 
