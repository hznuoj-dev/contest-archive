#include <stdio.h>
#include <string.h>

const int N = 1e5 + 10;

int main(void)
{
	long n, k, cou = 0;
	long a[N], sum;

	scanf("%ld %ld", &n, &k);
	for (long i = 0; i < n; i++)
	{
		scanf("%ld", &a[i]);
	}
	for (long i = 0; i < n; i++)
	{
		sum = 0;
		for (long j = i; j < n; j++)
		{
			sum += a[j];
			if (sum % k == 0)
				cou++;
		}
	}
	printf("%ld", cou);

	return 0;
}