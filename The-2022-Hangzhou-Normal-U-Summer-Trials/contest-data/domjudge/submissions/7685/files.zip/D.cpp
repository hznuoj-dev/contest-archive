#include <bits/stdc++.h>
#define N 100005
using namespace std;
int n,head[N],cnt;
long long ans[N];
struct Edge{
	int nt,to;
}e[N*2];
void add(int u,int v){
	e[++cnt].nt=head[u];
	head[u]=cnt;
	e[cnt].to=v;
}
long long dfs(int u,int fa){
	vector<int> sz;
	for(int i=head[u];i;i=e[i].nt){
		int v=e[i].to;
		if(v!=fa){
			sz.push_back(dfs(e[i].to,u));
			ans[u]+=sz[sz.size()-1];
		}
	}
	long long sum=0;
	for(int i=0;i<sz.size();i++){
		ans[u]+=sum*sz[i];
		sum+=sz[i];
	}
	ans[u]+=n-sum-1;
	ans[u]+=sum*(n-sum-1);
	return sum+1;
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		int x,y;
		scanf("%d%d",&x,&y);
		add(x,y);
		add(y,x);
	}
	dfs(1,0);
	int q;
	scanf("%d",&q);
	for(int i=1;i<=q;i++){
		int t;
		scanf("%d",&t);
		printf("%lld\n",ans[t]);
	}
	return 0;
}
