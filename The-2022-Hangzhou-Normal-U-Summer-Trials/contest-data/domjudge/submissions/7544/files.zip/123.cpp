#include<bits/stdc++.h>
#define int long long
#define size siz
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;
int t,n,m;
int k[100010],bef[100010],b[100010],cnt;
signed main(){
	FAST
	cin>>n>>m;
	int ans=0;
	map<int,int>mp;
	for(int i=1;i<=n;i++){
		cin>>k[i];
		k[i]%=m;
	}
	for(int i=1;i<=n;i++){
//		cout<<ans<<endl;
		bef[i]=bef[i-1]+k[i];
		bef[i]%=m;
		if(mp[bef[i]]==0)mp[bef[i]]=0;
		ans+=mp[bef[i]]+(bef[i]==0);
		mp[bef[i]]++;
	}
	cout<<ans<<endl;
} 
