#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
long long a[N],b[N],n,k;
map<int,int> mp;
int main()
{
	cin>>n>>k;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		a[i]%=k;
	}
	long long ans=0;
	long long temp=0;
	for(int i=0;i<n;i++)
	{
		temp=(temp+a[i])%k;
		mp[temp]++;
		b[i]=temp;
	}
	long long res=0;
	for(int i=0;i<n;i++)
	{

		ans+=mp[a[i]+res];
		res=(res+a[i])%k;
		mp[res]--;
	}
	cout<<ans<<endl;
}
