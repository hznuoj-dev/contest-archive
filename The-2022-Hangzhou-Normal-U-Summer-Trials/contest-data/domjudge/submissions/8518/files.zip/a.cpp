#include<bits/stdc++.h>
#define int long long
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
const int N = 2e5 + 10;
int a[N], b[N];
string ss;
string s[N];
int dp[N];
vector<int> v[N];
typedef pair<int,int> PII;
typedef long long ll;
const int mod = 998244353;
int n, m;
map<char, int> mp;
int gcd(int a,int b) {return b? gcd(b,a%b):a;}
void solve()
{
    cin >> ss;
    for(int i = 0; i < 26; i ++ )
    {
        mp[ss[i]] = i;
    }
    cin >> n;
    int cnt =0;
    map<string,int> mp1;
    for(int i = 1; i <= n; i ++ )
    {
        string sss;
        cin >> sss;
        if (!mp1[sss])
        {
            s[++ cnt] = sss;
            mp1[sss] = 1;
        }
    }
    for(int i = 1; i <= cnt; i ++ )
    {
        for(int j = i + 1; j <= cnt; j ++ )
        {
            if (s[j].size() < s[i].size())
            {
                swap(s[i],s[j]);
            }
            else if (s[j].size() == s[i].size())
            {
                for(int k = 0; k < s[i].size(); k ++)
                {
                    if (mp[s[i][k]] > mp[s[j][k]])
                    {
                        swap(s[i], s[j]);
                        break;
                    }
                    else if (mp[s[i][k]] < mp[s[j][k]])
                    {
                        break;
                    }
                }
            }
        }
    }
    int k;
    cin >> k;
    cout << s[k] << endl;
}
signed main()
{
    solve();
}
/*
7
qst
qrt
qrs
abce
axy
hxy
abcd
*/