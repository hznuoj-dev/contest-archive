#include<iostream>
using namespace std;
const int N=1e5+10;
long long a[N];
long long b[N];
int main()
{
    long long n,k;
    cin>>n>>k;
    long long num=0;
    for(int i=0;i<n;i++)
    {
        cin>>a[i];
        if(i==0) b[i]=a[i];
        else b[i]=a[i]+b[i-1];
        if(b[i]%k==0) num++;
    }
    for(int i=0;i<n-1;i++)
    {
        for(int j=i+1;j<n;j++)
        {
            if((b[j]-b[i])%k==0) num++;
        }
    }
    cout<<num<<endl;
    return 0;
}