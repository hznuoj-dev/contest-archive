#include<bits/stdc++.h>

using namespace std;

const int N = 100005;

int n,k;
int vis[N];
long long a[N];
long long sum[N];
#define ll long long
bool com(long long a,long long b){
	return a<b;
}
void solve()
{
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i){
		scanf("%lld",&a[i]);
		sum[i] = (sum[i-1]+(a[i]%k))%k;
	}
	sort(sum+1,sum+1+n,com);
	int pre = -1,flag = 0;
	ll ans = 0;
	sum[n+1] = -1;
	for(int i=1;i<=n+1;++i){
		if(sum[i] == 0) ans++;
		if(sum[i] != pre){
			pre = sum[i];
			ans += (flag-1)*(flag-2);
			flag = 1;
		}else{
			flag++;
		}
	}
	printf("%lld",ans);
}

int main()
{
	int t=1;
	//scanf("%d",&t);
	while(t--){
		solve();
	}	
	return 0;
}
