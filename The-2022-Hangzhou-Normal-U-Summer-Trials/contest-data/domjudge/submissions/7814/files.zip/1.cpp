#include<bits/stdc++.h>

using namespace std;

int a[100005];
int sum[100005];

bool com(int a,int b){
	return a<b;
}

int main()
{
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i){
		scanf("%d",&a[i]);
		sum[i] = (sum[i-1]%k+a[i]%k+k)%k;
	}
	
	long long ans = 0;
	sort(sum+1,sum+1+n,com);
	int pre = -1;
	long long flag = 0;
	long long flag0 = 0;
	sum[n+1] = -1;
	for(int i=1;i<=n+1;++i){
		if(sum[i] == 0){
			flag0++;
		}
		if(sum[i]!=pre){
			pre = sum[i];
			ans += flag*(flag-1)/2;
			flag = 1;
		}else{
			flag++;
		}
	}
	ans += flag0;
	printf("%lld",ans);
	return 0;
}
