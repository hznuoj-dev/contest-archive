#include <bits/stdc++.h>
using namespace std;
int main(void){
	int n;
	string str;
	cin>>str;
	string h="hznu";
	int sum=0;
	for(int i=0;i<str.size()-3;++i){
		if(str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u') sum++;
	}
	cout<<sum;
	return 0;
}
