#include<bits/stdc++.h>
#define ll long long
using namespace std;
ll n;
ll a[500010];
ll c[500010];
typedef struct{
	ll ans;
	ll id;
}h;
h b[500010];
ll q,t;
bool cmp(h a,h b){
	return a.ans<b.ans;
} 
ll ans[500010];
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	a[n+1]=2e18+1000;
	cin>>q;
	for(int i=1;i<=n;i++){
		c[i]=a[i+1]-a[i];
	}
	for(int i=1;i<=q;i++){
	cin>>b[i].ans;
	b[i].id=i;
}
sort(b+1,b+q+1,cmp);
sort(c+1,c+n+1);
ll temp=n;
ll cnt=1;
ll sum=0;
for(int i=1;i<=n;i++){
//	cout<<i<<endl;
	if(cnt==q+1)break;
	if(b[cnt].ans>c[i]){
		temp--;
		sum+=c[i];
	}else{
		ans[b[cnt].id]=temp*b[cnt].ans+sum;
		cnt++;
		i--;
	}
}
for(int i=1;i<=q;i++){
	cout<<ans[i]<<endl;
}
} 
