#include<bits/stdc++.h>
using namespace std;
map<char,int>mp;

int main()
{
	string s;
	cin>>s;
	for(int i=0;i<26;i++)
	{
		mp[s[i]]=i;
	}
	int m;
	string n[1010];
	int k;
	cin>>m;
	for(int i=0;i<m;i++)
	{
		cin>>n[i];
	}
	for(int i=0;i<m;i++)
	{
		for(int j=i+1;j<m;j++)
		{
			string temp;
			if(n[i].size()>n[j].size())
			{
				temp=n[i];
				n[i]=n[j];
				n[j]=temp;
			}
		}
	}
	for(int i=0;i<m;i++)
	{
		for(int j=i+1;j<m;j++)
		{
			string temp;
			for(int k=0;k<1001;k++)
			{
				if(mp[n[i][k]]>mp[n[j][k]])
				{
				temp=n[i];
				n[i]=n[j];
				n[j]=temp;
			    }
			    
			}
		}
	}

	cin>>k;
	cout<<n[k-1]<<endl;
	return 0;
}
 
