#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 1e5+10;


void solve(){
	string s; cin >> s;
	int cnt=0;
	for(int i=0;i<s.size()-3;i++){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
			cnt++;
		}
	}
	cout << cnt << endl;
	
}
/*


*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
