#include <bits/stdc++.h>
#define RE0 return 0;
#define FAST ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)
#define pb push_back
#define ll long long
const ll modulo = 1e9+7;
using namespace std;

ll T = 1, n, m;

ll s,q;
ll a[200005];
ll sum = 0;
ll ans[800005];
ll trueans[800005];

long long inv(long long a,long long m){
	if(a == 1)return 1;
		return inv(m%a,m)*(m-m/a)%m;
}


signed main(){
	FAST;
	while(T--){
//		cout << modulo << endl;
		cin >> n >> s >> q;
		for(int i = 1; i <= n; ++i){
			cin >> a[i];
			sum += a[i];
		}
		if(n==1){
			ans[0]=1;
			trueans[0]=1;
		}
		for(int i = 1; i <= (s + n)*2; ++i){
			if(i < (n-1)){
				ans[i]=0;
			}
			else if(i == (n-1)){
				ans[i]=1;
				trueans[i]=1;
			}
			else{
//				ans[i]=ans[i-1]*i/(i-(n-1));
				ans[i]=ans[i-1]*i;
				ans[i]%=modulo;
				ans[i] *= inv(i-(n-1), modulo);
				ans[i]%=modulo;
				trueans[i]=(trueans[i-1]+ans[i]);
				trueans[i]%=modulo;
//				cout << ans[i] << " " << trueans[i] << "\n";
			}
		}
//		for(int i = 1;i<=s+n+1;++i){
//			cout << ans[i] << " " << trueans[i] << endl;
//		}
		for(int i = 1; i<=q;++i){
			int x;
			ll val;
			cin >> x >> val;
			sum += val-a[x];
			a[x]=val;
			if(sum > s){
				cout << "0\n";
			}
			else{
				cout << trueans[s - sum + n - 1]<< "\n";
			}
		}
	}
	RE0
} 

/*

3 5 4
1 1 1
1 1
1 2
2 2
3 2

1 5 3
2
1 1
1 2
1 3

4 5 4
1 1 1 0
1 1
1 2
2 2
3 2

10 100 1
0 0 0 0 0 0 0 0 0 0
1 0

*/

