#include<bits/stdc++.h>
using namespace std;

#define ll long long

const int N=5e5+5;
const int mod=1e9+7;

ll a[N];

void solve(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	int q;
	cin>>q;
	while(q--){
		ll t;
		ll ans=0;
		cin>>t;
		for(int i=1;i<n;i++){
			if(a[i-1]<=a[i] && a[i]<=a[i-1]+t-1)	ans+=a[i]-a[i-1];
			else{
				ans+=t;
			}
		}
		ans+=t;
		cout<<ans<<"\n";
	}
}

int main(){
	ios::sync_with_stdio(false);
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}

