#include<bits/stdc++.h>

using namespace std;

#define INF 0x3f3f3f3f3f3f3f3f
#define io ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define PI acos(-1)
#define mem(a,b) memset((a),(b),sizeof(a));

typedef long long ll;
typedef unsigned long long ull;

ll n,k;
ll arr[100100],cnt[100100];
ll ans=0;

int main() {
	io;
	mem(cnt,0);	
	cin>>n>>k;
	for(int i=1;i<=n;i++) {
		cin>>arr[i];
		cnt[i]=cnt[i-1]+arr[i];
	}
	for(int i=1;i<=n;i++) {
		if(cnt[i]%k==0)ans++;
		for(int j=i-1;j>=1;j--) {
			if((cnt[i]-cnt[j])%k==0) {
				ans++;
			}
		}
	}
	cout<<ans;
	return 0;
}
