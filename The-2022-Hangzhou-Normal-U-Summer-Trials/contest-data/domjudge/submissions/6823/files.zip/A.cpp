#include <bits/stdc++.h>
#include <cstring>
using namespace std;
int main(void){
	string str;
	cin>>str;
	//string h="hznu";
	int sum=0;
	int n=str.size();
	for(int i=0;i<n-3;++i){
		if(str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u') sum++;
	}
	cout<<sum;
	return 0;
}
