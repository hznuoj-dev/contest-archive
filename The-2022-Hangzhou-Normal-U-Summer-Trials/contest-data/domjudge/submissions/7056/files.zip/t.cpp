#include<iostream>
#include<algorithm>
using namespace std;
const int N = 1e3 + 10;
char m[30];
int flect[30];
char s[N][N];
int idx[N];
bool cmp(int a, int b){
    int i = 0;
    for(; s[a][i] && s[b][i]; i++)
        if(flect[s[a][i] - 'a'] < flect[s[b][i] - 'a']) return true;
    return s[b][i + 1];
}
int main(){
    scanf("%s", m);
    for(int i = 0; i < 26; i++)
        flect[m[i] - 'a'] = i;
    int t;
    scanf("%d", &t);
    for(int i = 0; i < t; i++){
        scanf(" %s", s[i]);
        idx[i] = i;
    }
    sort(idx, idx + t, cmp);
    int n;
    scanf("%d", &n);
    puts(s[idx[n - 1]]);
}