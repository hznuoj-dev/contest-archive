#include <bits/stdc++.h>
#define N 500005
using namespace std;
long long n,k,q,t;
long long a[N],c[N],s[N];
int main(){
	scanf("%lld",&n);
	for(int i=1;i<=n;i++)
		scanf("%lld",&a[i]);
	for(int i=1;i<n;i++)
		c[i]=a[i+1]-a[i];
	sort(c+1,c+n);
	for(int i=1;i<n;i++)
		s[i]=s[i-1]+c[i];
	scanf("%lld",&q);
	for(int i=1;i<=q;i++){
		scanf("%lld",&t);
		int l=lower_bound(c+1,c+n,t)-c;
		printf("%lld\n",s[l-1]+(n-l+1)*t);
	}
	return 0;
}
