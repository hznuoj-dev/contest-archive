#include <bits/stdc++.h>
using namespace std;

int main() {
	string a;
	getline(cin, a);
	int ans = 0;
	for (int i = 0; i < a.length(); i++) {
		if (a[i] == 'h' && a[i + 1] == 'z' && a[i + 2] == 'n' && a[i + 3] == 'u') {
			ans++;
			i += 3;
		}
	}
		cout << ans;
} 
