#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

int main(){
	string s;
	ll ans = 0;
	cin >> s;
	for (int i = 0; i < s.size(); i++){
		if (i + 3 >= s.size())break;
		if (s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u')ans++;
	}
	cout << ans;
} 
