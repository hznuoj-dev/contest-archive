#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
const int N = 2e5 + 10;
typedef pair<int,int> PII;
typedef long long ll;
const int mod = 998244353;
int n, m;
map<char, int> mp;
struct Q
{
    int x;
    char s1, s2;
}q[N];
int gcd(int a,int b) {return b? gcd(b,a%b):a;}
void solve()
{
    cin >> n;
    string s;
    map<char, char> mp;
    int r = -1;
    for(int i = 0; i < 26; i ++)
    {
        mp['a' + i] = 'a' + i;
    }
    for(int i = 1; i <= n; i ++)
    {
        int x;
        string s1, s2;
        cin >> x;
        if (x == 1)
        {
            cin >> s1;
            q[i].x = x, q[i].s1 = s1[0];
        }
        else if (x == 2)
        {
            q[i].x = x;
        }
        else if (x == 3)
        {
            cin >> s1 >> s2;
            q[i].x = x, q[i].s1 = s1[0], q[i].s2 = s2[0];
        }
    }
    string ans;
    deque<char> c;
    int res = 0;
    for(int i = n; i >= 1; i --)
    {
        if (q[i].x == 1)
        {
            if (res) res--;
            else
            c.push_front(mp[q[i].s1]);
        }
        else if (q[i].x == 2)
        {
            res ++;
        }
        else
        {
            mp[q[i].s1] = mp[q[i].s2];
        }
    }
    bool flag = false;
    for(auto t : c)
    {
        flag = true;
        cout << t;
    }
    if (!flag)
    {
        cout << "The final string is empty";
    }
}
signed main()
{
    solve();
}
/*
7
qst
qrt
qrs
abce
axy
hxy
abcd
*/