#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

int n, m;
void solve(){
    string s, s2 = "hznu";
    cin >> s;
    int ans = 0;
    for(int i=0;i<s.size()-3;i++){
        for(int j=0;j<4;j++){
            if(s[i+j] != s2[j]) break;
            if(j == 3){
                ans++;
            }
        }
    }
    cout << ans << '\n';
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}