#include<iostream>
using namespace std;
#include<algorithm>

int main()
{
	long long n, a[500005] = {0}, q, t[500005] = {0}, cha[500005] = {0}, sum = 0;
	long long i, j, posion = 0;
	cin >> n;
	for (i = 0; i < n; i++)
		cin >> a[i];
	cin >> q;
	for (i = 0; i < q; i++)
		cin >> t[i];
	for (i = 1; i < n; i++)
		cha[i] = a[i] - a[i - 1];
	for (i = 0; i < q; i++)
	{
		posion = (long long)(upper_bound(cha + 1, cha + n, t[i]) - cha - 1);
		sum = a[posion] - a[0] + 1 + (n - posion) * t[i] - 1;
		cout << sum << endl;
	}
	return 0;
}
