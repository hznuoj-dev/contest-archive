#include<bits/stdc++.h>
using namespace std;
int n,l,maxn,k;
string s,tmp;
int p[28];
struct bi{
	int l;
	
	string f;
}lin[1003];
bool com(const bi&a,const bi&b){
	int len=min(a.l,b.l);
	for(int i=0;i<len;i++){
		if(p[a.f[i]-'a']<p[b.f[i]-'a']){
			return 1;
		}
		else if(p[a.f[i]-'a']>p[b.f[i]-'a']){
			return 0;
		}
	}
	return 1;
}
int main(){
	cin>>s;
	for(int j=0;j<26;j++){
		p[s[j]-'a']=j;
	}
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>lin[i].f;
		lin[i].l=lin[i].f.size();
	}
	sort(lin+1,lin+1+n,com);
	cin>>k;
	cout<<lin[k].f;
	return 0;
}
