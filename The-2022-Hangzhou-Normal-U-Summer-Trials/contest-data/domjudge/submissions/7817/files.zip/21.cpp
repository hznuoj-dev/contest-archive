#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

int a[300] = {0};

bool cmd1(string s1, string s2)
{
	int num1 = s1.length();
	int num2 = s2.length();
	for(int m = 0; m < num1 && m < num2; m++)
	{
		if(a[(int)s1[m]] < a[(int)s2[m]])
		{
			return true;
		}
		else if (a[(int)s1[m]] > a[(int)s2[m]])
		{
			return false;
		}
	}
	if(num1 < num2)
	{
		return true;
	}
	return false;
}

int main()
{
	string str;
	cin >> str;
	getchar();
	int n1 = str.length();
	for(int i = 0; i < n1; i++)
	{
		a[(int)str[i]] = i;
	}
	int n;
	cin >> n;
	getchar();
	string s[n];
	for(int i = 0 ; i < n; i++)
	{
		cin >> s[i];
		getchar();
	}
	int k;
	cin >> k;
	sort(s, s + n, cmd1);
	cout << s[k - 1];
}
