#include <bits/stdc++.h>
#define ll long long

using namespace std;
typedef pair<int, int> PII;
typedef pair<char, char> PCC;

const int N = 1e6 + 10, mod = 1e9 + 7;

ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a;}
ll lcm(ll a, ll b) { return a * b / gcd(a, b); }
ll qmi(ll a, ll b) { ll res = 1; while(b) { if(b & 1) res = (res * a) % mod; a = (a * a) % mod; b >>= 1;} return res % mod; }

map<char, int> mp;
int n, k;
ll s[10100];
map<ll, string> ans;

void solve()
{
	string t;
	cin >> t;
	for (int i = 0; i < t.size(); i ++)	mp[t[i]] = 1000000000 + i;
	
	//for (int i = 0; i < t.size(); i ++)
	//	cout << t[i] << ' ' << mp[t[i]] << '\n';
	cin >> n;
	for (int i = 1; i <= n; i ++)
	{
		string str; cin >> str;
		ll num = 0;
		for (int j = 0; j < str.size(); j ++)
			num += mp[str[j]];
		s[i] = num;
		//cout << num << '\n';
		ans[s[i]] = str;
	}

	cin >> k;
	sort(s + 1, s + 1 + n);
	cout << ans[s[k]] << '\n';
}

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
    int T = 1;
	//cin >> T;
	while(T --)
	{
		solve();
	}
    return 0;
}
