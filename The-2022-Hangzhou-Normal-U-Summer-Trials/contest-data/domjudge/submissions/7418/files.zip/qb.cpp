#include<bits/stdc++.h>
using namespace std;
int main()
{
	string a;
	cin>>a;
	int n;
	cin>>n;
	int minn=10000000;
	string r;
	string p;
	for(int i=0;i<n;i++)
	{
		string x;
		cin>>x;
		if(x.length()<minn)
		{
			minn=x.length();
			r=x;
			for(int i=0;i<r.length();i++)
			{
				p+=a.find(r[i])+'a';
			}
		}
		else if(x.length()==minn)
		{
			string xx;
			for(int i=0;i<x.length();i++)
			{
				xx+=a.find(x[i])+'a';
			}
			if(xx<p)
			{
				p=xx;
				r=x;
			}
		}
	}
	cout<<r;
}
