#include<bits/stdc++.h>
using namespace std;
#define itn int
#define int long long 
map<int,int>mp;
vector<int>arr;
void run()
{
	int n,k;
	cin>>n>>k;
	for(int i=0;i<n;i++)
	{
		int now;
		cin>>now;
		now%=k;
		arr.push_back(now);
	}
	int sum=0;
	int ans=0;
	for(int i=0;i<n;i++)
	{
		if(arr[i]==0) ans++;
		ans+=mp[(3*k-arr[i]-sum)%k];
		sum=(sum+arr[i])%k;
		mp[(arr[i]+k-sum)%k]++;
		
//		cout<<"dbg---> "<<ans<<endl;
	}
	cout<<ans<<endl;
	
	
	
	return;
}
signed main()
{
	int T=1;
//	cin>>T;
	while(T--)
	{
		run();
	}
	
	return 0;
}
