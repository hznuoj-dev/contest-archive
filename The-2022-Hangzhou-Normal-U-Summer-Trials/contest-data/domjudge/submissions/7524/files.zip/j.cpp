#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 5e5 + 5;
vector<char>g[maxn], q;
char sign[maxn], hes[maxn];
void work(int ans, int rt){
	hes[rt] = ans;
	for(int i = 0; i < g[rt].size(); ++i){
		int to = g[rt][i];
		if(sign[to]) continue;
		sign[to] = 1;
		work(ans, to); 
	}
}

void solve(){
	string e = "";
	int n; cin >> n;
	for(char i = 'a'; i <= 'z'; ++i) hes[i] = i;
	for(int i = 1; i <= n; ++i){
		int sign; cin >> sign;
		if(sign == 1){
			char x; cin >> x;
			e.push_back(x);
		}
		else if(sign == 2) e.pop_back();
		else{
			char x, y; cin >> x >> y;
			g[x].push_back(y);
			g[y].push_back(x);
			q.push_back(y);
		}
	}
	
	if(e.empty()){
		cout << "The final string is empty";
		return;
	}
	n = q.size() - 1;
	for(int i = n; i >= 0; --i){
		if(sign[q[i]]) continue;
		sign[q[i]] = 1;
		work(q[i], q[i]);
	}
	for(int i = 0; i < e.size(); ++i) cout << (char)hes[e[i]];
}

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
