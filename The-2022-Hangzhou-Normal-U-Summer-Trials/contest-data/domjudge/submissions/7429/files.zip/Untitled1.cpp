#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
using namespace std;

map<char,int> mp;
int cmp(string s1,string s2)
{
	int len1=s1.length(),len2=s2.length();
	for(int i=0;i<len1&&i<len2;i++)
	{
		if(mp[s1[i]]<mp[s2[i]]) return 1;
		else if(mp[s1[i]]>mp[s2[i]]) return 0;
	}	
	if(len1<len2) return 1;
	else if(len1>len2) return 0;
}
signed main()
{
	Daybreak7;
	string s;
	cin>>s;
	for(int i=0;i<26;i++)
		mp[s[i]]=i;
	int n;
	cin>>n;
	string a[n+10];
	for(int i=0;i<n;i++)
		cin>>a[i];
	sort(a,a+n,cmp);
	int k;
	cin>>k;
	cout<<a[k-1]<<endl;
}
