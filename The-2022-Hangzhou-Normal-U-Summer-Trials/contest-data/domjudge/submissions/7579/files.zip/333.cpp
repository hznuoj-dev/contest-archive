#include<bits/stdc++.h>
using namespace std;
long long int a[500010]={0};
int main(){
	string s="";
	int n;
	cin>>n;
	
	for(int i=0;i<n;i++){
		cin>>a[i];
		s[a[i]]='1';
	}
	int q,num;
	long long int t;
	cin>>q;
	while(q--){
		string str="";
		for(int i=0;i<n;i++){	
			str[a[i]]='1';
		}
		//cout<<str[1];
		int flag=-1;
		num=n;	
		
		cin>>t;
		if(str[t]=='1'){
			cout<<n<<endl;
			continue;
		}
		else{
			/*for(int i=t-1;;i--){
				if(str[i]=='1'){
					flag=t-i;
					break;
				}
			}*/
			flag=t-a[0];
		}
		for(int i=0;i<n;i++){
			for(int j=1;j<=flag;j++){
				if(str[a[i]+j]!='1'){
					str[a[i]+j]='1';
					num++;
					//cout<<a[i]+j<<" ";
				}
			}
		}
		cout<<num<<endl;
	}
}
