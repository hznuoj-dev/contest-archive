#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n,p,s;cin>>n>>p>>s;
	vector f(n+1,vector<int>(6,1e9));
	vector<int> a(n);
	for(int i=0;i<n;i++) cin>>a[i];
	int k;cin>>k;f[0][0]=0;
	for(int i=1;i<n;i++)
	for(int j=0;j<=k;j++){
		f[i][j]=min(f[i][j],f[i-1][j]+a[i]-a[i-1]);
		for(int t=1;t<=j;t++){
			int p=a[i]-t*s;
			int l=lower_bound(a.begin(),a.end(),p)-a.begin();
			if(l==i) continue;
			f[i][j]=min(f[i][j],f[l][j-t]);
		}
	}
	int ans=p;
	for(int i=0;i<=k;i++) ans=min(ans,f[n-1][i]);
	ans+=a[0];ans+=p-a[n-1];
	cout<<ans<<"\n";
	return 0;
}