#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
typedef long long ll;
ll a[N];
ll mp[N];
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int n;
	cin>>n;
    ll sum=1;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=2;i<=n;i++){
		mp[a[i]-a[i-1]]=i;
        if(a[i]!=a[i-1]) sum++;
	}
	vector<ll> w,ww;
	for(int i=1;i<=a[n];i++){
		if(!mp[i]) continue;
        w.push_back(i);
		ww.push_back(mp[i]);
	}
	int t;
	cin>>t;
	while(t--){
		ll q;
		cin>>q;
        ll res;
        if(q==0){
            cout<<0<<endl;
            continue;
        }
        if(q==1){
            cout<<sum<<endl;
            continue;
        }
        if(q>=w.back()){ 
            res=a[n]+q-a[1];
            cout<<res<<endl;
            continue;
        }
        if(q<=w.front()){
            res=sum*q;
            cout<<res<<endl;
            continue;
        }
    	ll now=upper_bound(w.begin(),w.end(),q)-w.begin();
		res=n-mp[w[now-1]]+1;
		res*=q;
		res+=a[mp[w[now-1]]]-a[1];
		cout<<res<<endl; 
	}  
	return 0;
}