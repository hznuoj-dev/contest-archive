#include<bits/stdc++.h>
using namespace std;
const int N = 500005;

int main(){
	int n,i,q;
	long long a[N],cha[N];
    long long ans,t,st,ed;
	scanf("%d",&n);
	for(i=1;i<=n;i++){
		scanf("%lld",&a[i]);
        if(i>=2){
            cha[i] = a[i] - a[i-1] + 1;
        }
	}
	scanf("%d",&q);
	while(q--){
		scanf("%lld",&t);
		ans = 0;
        int l = 2,r = n;
        while(l<r){
            int mid = (l+r) / 2;
            if(t<cha[mid]){
                r = mid ;
            }else{
                l = mid + 1;
            }
        }
        int res = l;
        if(cha[n]<=t){
            res = n + 1;
        }
        st = a[1];
        ed = a[res-1] + t - 1;
        ans += ed - st + 1;
        ans += t * (n - res + 1);
		printf("%lld\n",ans);
	}
	return 0;
}

