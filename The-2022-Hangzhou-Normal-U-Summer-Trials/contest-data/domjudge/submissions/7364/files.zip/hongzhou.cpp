#include <bits/stdc++.h>
using namespace std;
const int N =2e5+10; 
const int mod= 998244353; 
using namespace std;
typedef long long ll;
#define INF 0x3f3f3f3f3f3f3f3f  
string a[1005];
 string s;
bool cmp(string s1,string s2)
{     
   for(int i=0;i<min(s1.length(),s1.length());)
    {    
	  
		     int k=s.find(s1[i]);
		     int b=s.find(s2[i]);
                if(k<b)
                { return 1;
			    }
			    else if(k>b)
			    {   return 0;
				}
				else 
				{ i++;
				}
	}
	if(s1.length()<s2.length())
	{ return 1;
	}
	else 
	{ return 0;
	}
}
int main(){
  
    cin>>s;
    ll n;
    cin>>n;
    for(int i=1;i<=n;i++)
    { cin>>a[i];
	}
    sort(a+1,a+1+n,cmp);
 
	ll k;
	cin>>k;
 	cout<<a[k]<<endl;
	return 0;
}
