#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=5e5+10;
int ch[N];
signed main(void){
	int n,q,x;
	scanf("%lld",&n);
	for(int i=1;i<=n;++i) scanf("%lld",&ch[i]);
	scanf("%lld",&q);
	while(q--){
		cin>>x;
		int ans=0;
		if(x>=ch[n]) {
			printf("%lld\n",x-1+ch[n]);
			continue;
		}
		else ans=ans+x;
		for(int i=n-1;i>=1;i--){
			if(x+ch[i]>=ch[i+1]) {
			//ans=ans+x-1+ch[i];
			ans=ans+ch[i+1]-1;
			break;
			}
			else ans=ans+x;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
