#include<bits/stdc++.h>
#define int long long
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;
struct node{
	char ss;
	int id;
};
int n,f[200010],dx[200010],cnt=30;
char ans[200010];
char x[10],y[10];
int findf(int x){
	return f[x]=(f[x]==x?x:findf(f[x]));
}
signed main(){
	deque<node>que;
	for(int i=0;i<26;i++)ans[i]='a'+i,dx[i]=i;
	for(int i=0;i<=200000;i++)f[i]=i;
	int q;cin>>q;
	while(q--){
		cin>>n;
		if(n==1){
			cin>>x;
			que.push_back({x[0],dx[x[0]-'a']}); 
		} 
		else if(n==2){
			if(!que.empty())que.pop_back();
		}
		else{
			cin>>x>>y;
			if(x[0]!=y[0]){
				f[dx[x[0]-'a']]=dx[y[0]-'a'];
				dx[x[0]-'a']=cnt;
				f[cnt]=cnt;
				ans[cnt]=x[0];
				cnt++;
			}
			
		}
	}
	if(que.empty())cout<<"The final string is empty";
	else{
		while(!que.empty()){
			int id=que.front().id;
			que.pop_front();
			cout<<ans[findf(id)];
		}
	}		
	
}
