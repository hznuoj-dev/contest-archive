#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

void solve(){
	int n;
	scanf("%d", &n);
	vector<ll> a(n), b(n);
	for(int i = 0; i < n; i++){
		scanf("%lld", &a[i]);
	}
	for(int i = 0; i < n - 1; i++){
		b[i] = a[i + 1] - a[i];
	}
	b[n - 1] = 1e18 + 1;
	int q;
	scanf("%d", &q);
	while(q--){
		ll t;
		scanf("%lld", &t);
		int p = upper_bound(b.begin(), b.end(), t) - b.begin();
		ll ans = t * (n - p) + a[p] - a[0];
		printf("%lld\n", ans);
	}
}

int main(){
	int T = 1;
	while(T--) solve();
	return 0;
}
