#include<bits/stdc++.h>
using namespace std;

const int N=1e5+7,M=1e9+7;
string s;
priority_queue<int> pos[37];

void solve(){
	int q,op;
	char x,y;
	cin>>q;
	while(q--){
		cin>>op;
		if(op==1){
			cin>>x;
			s+=x;
			pos[x-'a'].push(s.size()-1);
		}else if(op==2){
			if(s.size()>0){
				pos[s[s.size()-1]-'a'].pop();
				s.erase(s.size()-1);
			}
		}else if(op==3){
			cin>>x>>y;
			while(!pos[x-'a'].empty()){
				s[pos[x-'a'].top()]=y;
				pos[y-'a'].push(pos[x-'a'].top());
				pos[x-'a'].pop();
			}
			/*
			int pos=s.find(x);
			while(pos>=0&&pos<=s.size()){
				s[pos]=y;
				pos=s.find(x);
			}
			*/
		}
		//cout<<s<<'\n';
	}
	if(s==""){
		cout<<"The final string is empty"<<'\n';
	}else{
		cout<<s<<'\n';
	}
}

int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int T=1;
	//cin>>T;
	while(T--) solve();
	return 0;
}
