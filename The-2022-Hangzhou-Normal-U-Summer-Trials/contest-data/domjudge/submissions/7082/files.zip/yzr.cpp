#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
typedef long long ll;
string s;
ll a[200];
string str[2000];
bool cmp(string p,string q){
	for(int i=0;i<min(p.size(),q.size());i++){
	if(a[p[i]]>a[q[i]])
		return false;
	else if(a[p[i]]<a[q[i]])
		return true;
	}
	if(p.size()>q.size())
		return false;
	else
		return true;
}
int main()
{
	getline(cin,s);
	int n;
	int m;
	int k=1;
	for(int i=0;i<s.size();i++)
		a[s[i]]=k++;
	cin>>n;
	getchar();
	for(int i=0;i<n;i++)
		getline(cin,str[i]);
	sort(str,str+n,cmp);
	cin>>m;
	cout<<str[m-1];
	return 0;
}