#include<iostream>
#include<string>
using namespace std;
string s;
int main(){
	getline(cin,s);
	int t=0;
	for(long unsigned int i=0;i<s.length()-3;i++){
		if((s[i]=='h'||s[i]=='H')&&(s[i+1]=='z'||s[i+1]=='Z')&&(s[i+2]=='n'||s[i+2]=='N')&&(s[i+3]=='u'||s[i+3]=='U')){
			t++;
		}
	}
	cout<<t<<endl;
	return 0;
} 
