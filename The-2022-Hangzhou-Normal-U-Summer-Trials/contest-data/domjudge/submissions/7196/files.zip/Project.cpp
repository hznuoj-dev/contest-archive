#include<bits/stdc++.h>
#pragma GCC optimize(2)
#define endl '\n'
#define ll long long
#define ull unsigned long long
#define mem(a, b) memset(a, b, sizeof a)
//#define int ll
#define pii pair<int,int>
#define all(a) a.begin(), a.end()
using namespace std;

#define dbg(x) do { cout << #x << " -> "; err(x); } while(0)

void err()
{
	cout << endl;
}

template<class T, class... Ts>
void err(const T& arg, const Ts &... args)
{
	cout << arg << ' ';
	err(args...);
}

const int maxn = 1e5 + 10;
const ll mod = 1e9 + 10;
const ll MOD = 1000003;
const double eps = 1e-4;
const double pi = acos(-1.0);
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;

ll n, m, k, q;
map<char, int> mp;

struct node {
	string s;
	string check;
	
	bool friend operator < (const node& a, const node& b)
	{
		return a.check < b.check;
	}
}v[1050];

void solve()
{
	string s;
	cin >> s;
	for (int i = 0; i < s.size(); i++)
	{
		mp[s[i]] = i + 1;
	}
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		string check, cnt;
		cin >> check;
		for (int i = 0; i < check.size(); i++)
		{
			cnt += to_string(mp[check[i]]);
		}
		v[i].check = cnt;
		v[i].s = check;
	}
	cin >> k;
	sort(v + 1, v + 1 + n);
	cout << v[k].s;
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	//freopen("mosalah.in", "r", stdin);
	int t = 1;
	//cin >> t;
	while (t--)
		solve();
	return 0;
}