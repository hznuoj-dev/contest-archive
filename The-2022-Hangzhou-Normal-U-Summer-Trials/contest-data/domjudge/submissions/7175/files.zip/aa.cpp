#include<bits/stdc++.h>

using namespace std;
string ss[1010],sss[1010];
void solve(){
	string s;
	cin >> s;
	map<char,int>mp;
	for(int i=0;i<26;i++){
		mp[s[i]]=i+1;
	}
	int n,k;
	cin >> n;
	map<string,int>mp2;
	for(int i=1;i<=n;i++) cin>>ss[i];
	mp2[ss[1]]=1;
	for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			for(int x=0;;x++){
				if(mp[ss[i][x]]==mp[ss[j][x]]) continue;
				else if(mp[ss[i][x]]>mp[ss[j][x]]){
					mp2[ss[i]]++;
					mp2[ss[j]]=mp2[ss[i]]-1;
					break;
				}else{
					mp2[ss[j]]=mp2[ss[i]]+1;
					break;
				}
			}
		}
	}
	cin >> k ;
	map<string,int>::iterator iter;
    iter = mp2.begin();
    while(iter != mp2.end()){
        if(iter->second==k) {
        	cout << iter->first;
        	return ;
        }
        iter++;
    }
}
int main(){
	int t=1;
	//cin >> t;
	while(t--){
		solve();
	}
return 0;
}
