#include <bits/stdc++.h> 
using namespace std;
long long a[100050],sum[100050];
int main()
{
	long long k;
	int i,j,n;
	scanf("%d%lld",&n,&k);
	for (i=1; i<=n; i++) 
	{
		scanf("%lld",&a[i]);
		a[i]=a[i]%k;
		sum[i]=sum[i-1]+a[i];
	}
	long long ans=0;
	for (i=0; i<=n; i++)
		for (j=i+1; j<=n; j++)
			if ((sum[j]-sum[i])%k==0)ans++;
	printf("%lld",ans);
}
