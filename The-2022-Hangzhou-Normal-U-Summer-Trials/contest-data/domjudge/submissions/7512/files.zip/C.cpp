#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define lowbit(x)(x&-x)
typedef pair<int,int>PII;
const int INF = 0x3f3f3f3f;
typedef pair<int,string>PIS;
typedef pair<double,double>PDD;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
int lcm(int a,int b){return a*b/gcd(a,b);}
#define snow ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
vector<int>vec;
const int N = 5e5+10;
int a[N],s[N];
int find(int x){
    return upper_bound(vec.begin(),vec.end(),x)-vec.begin();
}
signed main(){
    snow
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=2;i<=n;i++){
        vec.push_back(a[i]-a[i-1]);
    }
    sort(vec.begin(),vec.end());
    int cnt=1;
    for(auto x:vec){
        s[cnt]=s[cnt-1]+x;
        cnt++;
    }
    int q;
    cin>>q;
    while(q--){
        int x;
        cin>>x;
        int idx=find(x);
        if(idx==0){
            cout<<x*n<<endl;
        }
        else{
            cout<<x*n-(idx*x-s[idx])<<endl;
        }
    }
    return 0;
}