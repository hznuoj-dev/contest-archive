#include<iostream>
#include<string>
#include<map>
#include<algorithm>
using namespace std;
map<long long,long long>mp;
const int N=1e5+10;
long long a[N];
int main(){
    long long n,k;
    cin>>n>>k;
    for(int i=0;i<n;i++){
        cin>>a[i];
        a[i]=a[i]%k;
    }
    long long ans=0;
    long long pre=0;
    for(int i=0;i<n;i++){
        if(a[i]==0){
            ans++;
            mp[a[i+1]]++;
        }
        long long x=(k-a[i]);
        x=(x-pre+k)%k;
        ans+=mp[x];
        mp[a[i]]++;
        pre=(pre+a[i])%k;
    }
    cout<<ans<<endl;
}
