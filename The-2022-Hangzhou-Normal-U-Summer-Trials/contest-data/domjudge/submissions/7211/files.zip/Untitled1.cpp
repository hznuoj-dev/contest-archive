#include<iostream>
#include<algorithm>
#include<string>

using namespace std;
int main(){
	string s;
	getline(cin,s);
	if(s.length()<4){
		cout<<0;
		return 0;
	}
	int ans=0;
	for(int i=0;i<=s.length()-4;++i){
		if(s.substr(i,4)=="hznu")ans++;
	}
	cout<<ans;
	return 0;
}
