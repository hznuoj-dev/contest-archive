#include <bits/stdc++.h>
#include <cstring>
using namespace std;
int ch[260];
string h[200];
bool cmp(string x1,string x2){
	for(int i=0;i<x1.size();++i){
		if(ch[x1[i]]==ch[x2[i]]) continue;
		else if(ch[x1[i]]<ch[x2[i]]) return 1;
		else return 0;
	}
	return x1.size()>x2.size(); 
}
int main(void){
	string str;
	cin>>str;
	int n=str.size();
	for(int i=0;i<n;++i){
		ch[str[i]]=i;
	}
	int t;
	cin>>t;
	for(int i=0;i<t;++i){
		cin>>h[i];
	}
	sort(h,h+t,cmp);
	int k;
	cin>>k;
	cout<<h[k-1];
	return 0;
}
