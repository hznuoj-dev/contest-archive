#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=5e5+10;
ll a[N],b[N];
void solve(){
	int n,q;
	ll t;
	scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%lld",&a[i]);
	for(int i=1;i<n;i++)b[i]=a[i]-a[i-1]-1;
	scanf("%d",&q);
	while(q--){
		scanf("%lld",&t);
		ll l=lower_bound(b,b+n,t)-b-1;
		printf("%lld\n",a[l]-a[0]+(n-l)*t);
	}
}
int main(void){
	int t=1;
	//scanf("%d",&t);
	while(t--)solve();
	return 0;
}
