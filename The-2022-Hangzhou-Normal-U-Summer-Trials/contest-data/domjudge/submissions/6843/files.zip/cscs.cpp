#include <bits/stdc++.h> 
using namespace std;
char s[100050];
int main()
{
//	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int ans=0;
	scanf("%s",s);
	
	for (int i=0; i+3<strlen(s); i++)
	{
		if (s[i]=='h' && s[i+1]=='z' && s[i+2]=='n' && s[i+3]=='u') ans++;
	}
	cout <<ans;
	
}
