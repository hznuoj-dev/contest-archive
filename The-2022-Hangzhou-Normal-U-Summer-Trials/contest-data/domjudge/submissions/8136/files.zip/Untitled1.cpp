#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll N = 1e3 + 7;
multiset<ll> st;

int main(){
	string s = "";
	ll q, len = 0;
	cin >> q;
	while (q--){
		ll x;
		cin >> x;
		if (x == 1){
			char c;
			cin >> c;
			s += c; 
			len++;
		}
		if (x == 2){
			if (len){
				for (int i = s.size() - 1; i >= 0; i--){
					if (s[i] != ' '){
						s[i] = ' ';
						break;
					}
				}
				len--;
			}
		}
		if (x == 3){
			char c1, c2;
			cin >> c1 >> c2;
			for (int i = 0; i < s.size(); i++){
				if (s[i] == c1)s[i] = c2;
			}
		}
	}
	if(len){
		for (int i = 0; i < s.size(); i++){
			if (s[i] != ' ')cout << s[i];
		}
	}
	else cout << "The final string is empty";
} 
