#include<bits/stdc++.h>
using namespace std;
#define ll long long

int main(){
	string a;
	cin>>a;
	int cut=0;
	for(int i=0;i<a.length();i++){
		if(a[i]=='h'&&i+3<a.length()){
			if(a[i+1]=='z'&&a[i+2]=='n'&&a[i+3]=='u') cut++;
		}
	}
	cout<<cut;
} 
