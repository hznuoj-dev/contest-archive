#include <stdio.h>
#include <string.h>
char a[100000];
int main()
{
    scanf("%s", a);
    long int l = strlen(a);
    long int i;
    long int num = 0, k = 0;
    for (i = 0; i < l; i++)
    {
        if (a[i] == 'h')
            k = 1;
        else if (k == 1 && a[i] == 'z')
            k = 2;
        else if (k == 2 && a[i] == 'n')
            k = 3;
        else if (k == 3 && a[i] == 'u')
        {
            k = 0;
            num++;
        }
        else
            k = 0;
    }
    printf("%ld", num);
    return 0;
}
