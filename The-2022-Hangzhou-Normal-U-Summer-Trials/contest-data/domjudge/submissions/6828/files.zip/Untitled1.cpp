#include<bits/stdc++.h>
#define ll long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const int N = 2e5 + 5;
const double eps = 1e-5;
const int mod = 1e9 + 7;

ll n;

void solve()
{
	string s;
	cin >> s;
	ll ans = 0;
	for (ll i = 0; i +3 < s.size(); i++)
		if (s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u')
			ans++;
	cout << ans << '\n';
}

int main()
{
	IOS;
	ll t = 1;
	//cin >> t;
	while (t--)
		solve();
}
