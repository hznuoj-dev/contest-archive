#include<bits/stdc++.h>
#define pb push_back
#define ll long long
#define SIZ(a) (int)a.size()
using namespace std;
const int maxn=1e6+9;
int len[maxn];
struct node{
    int op;
    char x,y;
}a[maxn];
struct change{
    int id;
    char x,y;
};
void solve(){
    int q;
    cin>>q;
    string s;
    for(int i=1;i<=q;i++){
        int op;
        cin>>op;
        if(op==1){
            char x;
            cin>>x;
            s+=x;
            len[i]=SIZ(s);
            a[i].op=op;
            a[i].x=x;
        }else if(op==2){
            if(!s.empty())
                s.pop_back();
            len[i]=SIZ(s);
            a[i].op=op;
        }else {
            char x,y;
            cin>>x>>y;
            len[i]=SIZ(s);
            a[i].op=op;
            a[i].x=x;
            a[i].y=y;
        }
    }
    for(int i=q-1;i>=1;i--){
        len[i]=min(len[i],len[i+1]);
    }
    vector<change>vec;
    for(int i=1;i<=q;i++){
        if(a[i].op==3)vec.pb({len[i],a[i].x,a[i].y});
    }
    map<char,char>mp;
    for(char i='a';i<='z';i++)mp[i]=i;
    int pos=SIZ(s)-1;
    for(int i=SIZ(vec)-1;i>=0;i--){
        while(pos>=vec[i].id){
            s[pos]=mp[s[pos]];
            pos--;
        }
        mp[vec[i].x]=mp[vec[i].y];
    }
    while(pos>=0){
        s[pos]=mp[s[pos]];
        pos--;
    }
    if(s.empty())cout<<"The final string is empty\n";
    else cout<<s<<endl;
}
int main(){
    solve();
}