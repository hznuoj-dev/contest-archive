#include<iostream>
#include<map>
#define ll long long
using namespace std;
const int N = 1e5 + 10;
ll a[N];
map<ll, ll> m;
int main(){
    int n, k;
    scanf("%d%d", &n, &k);
    for(int i = 1; i <= n; i++){
        scanf("%lld", a + i);
        a[i] = a[i] % k;
    }
    ll floor = 0;
    ll res = 0;
    for(int i = n; i >= 0; i--){
        res += m[((k - a[i] - floor) % k + k) % k];
        floor += a[i + 1];
        floor %= k;
        m[(a[i] - floor + 2 * k) % k]++;
    }
    printf("%lld", res);
}