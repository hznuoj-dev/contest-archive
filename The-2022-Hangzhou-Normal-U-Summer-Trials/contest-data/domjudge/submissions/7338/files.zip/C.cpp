#include<iostream>
#include<string>
#include<algorithm>
using namespace std;
struct code{
	long long v;
	int id;
	long long ans;
} f[500050];
bool cmp1(code x,code y){
	return x.v<y.v;
}
bool cmp2(code x,code y){
	return x.id<y.id;
}
long long n,m,a[500050];
int main(){
	cin>>n;
	for (int i=1; i<=n; i++){
		cin>>a[i];
	}
	cin>>m;
	for (int i=1; i<=m; i++){
		cin>>f[i].v;
		f[i].id=i;
	}
	sort(f+1,f+1+m,cmp1);
	int p=1;
	for (int i=1;i<=m;i++){
		while ((a[p]+f[i].v-1>=a[p+1])&&(p<n)){
			p++;
		}
		f[i].ans=a[p]+f[i].v-1-a[1]+1+(n-p)*f[i].v;
	}
	sort(f+1,f+1+m,cmp2);
	for (int i=1;i<=m;i++){
		cout<<f[i].ans<<endl;
	}
}
