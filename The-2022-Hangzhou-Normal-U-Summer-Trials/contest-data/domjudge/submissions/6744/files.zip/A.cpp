#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef long long ll;
const int N=2e+7;
void solve(){
	string s;
	cin >> s;
	int k=s.size();
	int ans=0;
	for (int i=0;i<k;i++){
		string ss=s.substr(i,4);
		if (ss=="hznu"){
			ans++;
		}
		
	}
	cout << ans << '\n';
}

signed main(){
	ios::sync_with_stdio(0);
	int t=1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}
