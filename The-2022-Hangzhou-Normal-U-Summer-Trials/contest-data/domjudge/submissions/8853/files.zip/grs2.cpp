#include<bits/stdc++.h>
#define rson rt<<1|1
#define lson rt<<1
#define pb push_back
#define endl '\n'
#define x first
#define y second
#define LLINF 9223372036854775807
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<double,double> pdd;

const int N=3030;

vector<pdd>g[N];
double dist[N];
double v[N];
bool st[N];
double x[N],y[N];
int n;

int fr(int x,int y){
    if(x>=1&&y>=1)return 1;
    if(x<=-1&&y>=1)return 2;
    if(x<=-1&&y<=-1)return 3;
    if(x>=1&&y<=-1)return 4;
    return 0;
}

void dij(int s){
    for(int i=1;i<=n;i++){
        dist[i]=1e15;
    }
    dist[s]=0;
    priority_queue<pdd,vector<pdd>,greater<pdd>>q;
    q.push({0,s});
    while(q.size()){
        auto w=q.top();
        q.pop();
        int i=w.y;
        if(st[i])continue;
        st[i]=1;
        for(auto now:g[i]){
            double w=now.y;
            int j=now.x;
            if(dist[j]>dist[i]+w){
                dist[j]=dist[i]+w;
                q.push({dist[j],j});
            }
        }
    }
}

int main()
{  
    IOS
    cin>>n;
    for(int i=1;i<=4;i++){
        cin>>v[i];
    }
    cin>>v[0];
    int s,t;
    cin>>s>>t;
    for(int i=1;i<=n;i++){
        cin>>x[i]>>y[i];
    }
    for(int i=1;i<=n;i++){
        for(int j=i+1;j<=n;j++){
            int a=fr(x[i],y[i]);
            int b=fr(x[j],y[j]);
            double dis=sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]));
            if(a==b){
                g[i].pb({j,dis/v[a]});
                g[j].pb({i,dis/v[a]});
            }else {
                g[i].pb({j,dis/v[0]});
                g[j].pb({i,dis/v[0]});
            }
        }
    }
    dij(s);
    cout<<dist[t];
    return 0;
}