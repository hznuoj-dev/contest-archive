#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define int long long
char a[27];int n;
//bool check(string a,string b){
//	for(int i=0;i<=min(a.size(),b.size());i++){
//		if(a[i]==b[i]){
//			continue;
//		}
//		else if(a[i]>b[i]){
//			return false;
//			break;
//		}
//		else if(a[i]<b[i]){
//			return true;
//			break;
//		}
//	}
//}
using namespace std;
signed main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	cin>>a;map<char,int> mp;
	rep(i,0,25){
		mp[a[i]]=i;
	}
	string s1[1020];
	cin>>n;
	rep(i,0,n-1){
		cin>>s1[i];
	}
	int m;cin>>m;
	for(int i=0;i<=m-1;i++){
		int min=i;
		for(int j=i+1;j<=n-1;j++){
			if(s1[j].size()>s1[min].size()){
				for(int h=0;h<=s1[min].size();h++){
					if(mp[s1[j][h]]==mp[s1[min][h]]){
						continue;
					}
					else if(mp[s1[j][h]]>mp[s1[min][h]]){
						break;
					}
					else if(mp[s1[j][h]]<mp[s1[min][h]]){
						min=j;
						break;
					}
				}
			}
			else if(s1[j].size()<=s1[min].size()){
				for(int h=0;h<=s1[j].size();h++){

					if(mp[s1[j][h]]==mp[s1[min][h]]){
						continue;
					}
					else if(mp[s1[j][h]]>mp[s1[min][h]]){
						break;
					}
					else if(mp[s1[j][h]]<mp[s1[min][h]]){
					    min=j;
						break;
					}
				}
			}
		}
		string temp=s1[min];s1[min]=s1[i];s1[i]=temp;
	}
	cout<<s1[m-1]<<endl;
	return 0;
} 
