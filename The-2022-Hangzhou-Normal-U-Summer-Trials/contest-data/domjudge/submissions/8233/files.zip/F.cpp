#include <bits/stdc++.h>
#define endl '\n'
#define IOS ios::sync_with_stdio(0)
using namespace std;
typedef long long ll;
const int N = 1e5 + 10;
ll n, k, ans = 0;
ll a[N], sum[N];

int main()
{
	//IOS; cin.tie(0), cout.tie(0);
	scanf("%lld %lld", &n, &k);
	for (int i = 1; i <= n; ++i)
	{
		scanf("%lld", &a[i]);
		sum[i] = sum[i - 1];
		sum[i] += a[i];
	}

	for (int i = 1; i <= n; ++i)
	{
		for (int j = i; j <= n; ++j)
		{
			ll temp = sum[j] - sum[i - 1];	//��һ������ĺ�
			if (temp % k == 0)
				ans++;
		}
	}

	cout << ans << endl;

	return 0;
}
