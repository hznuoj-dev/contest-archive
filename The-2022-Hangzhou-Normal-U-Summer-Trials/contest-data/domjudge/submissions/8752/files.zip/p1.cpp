#include<bits/stdc++.h>
using namespace std;

int main(){
	int n,k,cnt=0;
	long long a[100001];
	cin>>n>>k;
	a[0]=1;
	
	for(int i = 1; i <= n; i++){
		scanf("%d",&a[i]);
		a[i]+=a[i-1];
	}
	for(int i = 1; i <= n; i++){
		for(int j = i; j <= n; j++){
			if(a[j]-a[i-1]%k==0)cnt++;
		}
	}
	cout<<cnt;

	return 0;
}
