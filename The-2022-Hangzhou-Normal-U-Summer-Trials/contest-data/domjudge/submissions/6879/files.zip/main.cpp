#include <bits/stdc++.h>
using namespace std;
using ll = long long;

const int N = 1000010;

map<char, char> mp, ogi;

int main ()
{
    for(char i = 'a'; i <= 'z'; i ++ ) {
        char x; cin >> x;
        mp[x] = i;
        ogi[i] = x;
    }
    int n; cin >> n;
    vector<string> v(n);
    for (int i = 0; i < n; i ++ ) {
        string ss; cin >> ss;
        for (char &c: ss) c = mp[c];
        v[i] = ss;
    }
    sort(v.begin(), v.end());
    int k; cin >> k;
    for (char c: v[k-1]) cout << ogi[c];
    cout << endl;
    return 0;
}