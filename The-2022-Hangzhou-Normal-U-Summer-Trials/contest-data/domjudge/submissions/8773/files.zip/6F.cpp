#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

const int N=1e5+10;
ll n,k,a[N],s[N],cnt,st[N];
map<int,int> mp;
pii p[N];

ll find(int x)
{
	st[x]=1;
	if(mp[p[x].second+1]) return 1+find(mp[p[x].second+1]);
	return 0;
}

ll cal(int x)
{
	return (1+x)*x/2;
}

int main()
{
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		a[i]%=k;
		s[i]=s[i-1]+a[i];
	}
	
	for(int i=1;i<=n;i++)
	{
		for(int j=i;j<=n;j++)
		{
			if(s[j]-s[i-1]>k) break;
			else if(s[j]-s[i-1]==k)
			{
				p[++cnt]={i,j};
				mp[i]=cnt;
			}
		}
	}
	ll res=0;
	//cout<<cnt<<endl;
	for(int i=1;i<=cnt;i++)
	{
		if(st[i]) continue;
		if(!mp[p[i].second+1]) res++;
		else
		{
			
			int t=find(i)+1;
			res+=cal(t);
			//cout<<cal(t)<<endl;
		}
	}
	cout<<res<<endl;
	return 0;
}
