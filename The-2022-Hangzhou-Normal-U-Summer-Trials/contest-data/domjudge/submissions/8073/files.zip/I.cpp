#include<bits/stdc++.h>
using namespace std;
using ll=long long;
const int MOD=1e9+7;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n,s,q;cin>>n>>s>>q;
	vector<int> fac(n+s+1),inv(n+s+1);
	fac[0]=1;
	for(int i=1;i<=n+s;i++) fac[i]=(ll)fac[i-1]*i%MOD;
	auto qsm=[&](int x,int b){
		int ret=1;
		for(;b;b>>=1,x=(ll)x*x%MOD) if(b&1) ret=(ll)ret*x%MOD;
		return ret;
	};
	inv[n+s]=qsm(fac[n+s],MOD-2);
	for(int i=n+s-1;i>=0;i--) inv[i]=(ll)inv[i+1]*(i+1)%MOD;
	
	auto C=[&](int n,int m)->int{
		return (ll)fac[n]*inv[m]%MOD*inv[n-m]%MOD;
	};
	vector<int> sum(n+1);
	sum[0]=1;
	for(int i=1;i<=s;i++) sum[i]=(sum[i-1]+C(i+n-1,n-1))%MOD;
	vector<int> a(n+1);
	ll m=0;
	for(int i=1;i<=n;i++) cin>>a[i],m+=a[i];
	while(q--){
		int p,x;cin>>p>>x;
		m-=a[p];
		a[p]=x;
		m+=a[p];
		if(m>s) cout<<"0\n";
		else cout<<sum[s-m]<<"\n";
	}
	return 0;
}