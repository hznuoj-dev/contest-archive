#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
	string s;
	int num;
}node[1100];
int main(){
	ios::sync_with_stdio(false);
	string str;
	getline(cin,str);
	int n,k;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>node[i].s;
		node[i].num=0;
		for(int j=0;j<node[i].s.length();j++){
			node[i].num=node[i].num*10+(str.find(node[i].s[j])+1);
		}
	}
	for(int i=0;i<n-1;i++){
		for(int j=0;j<n-1-i;j++){
			if(node[j].num>node[j+1].num||(node[j].num==node[j+1].num&&node[j].s.length()>node[j+1].s.length())){
				Node a;
				a=node[j];
				node[j]=node[j+1];
				node[j+1]=a;
			}
		}
	}
	cin>>k;
	cout<<node[k-1].s<<endl;
	return 0;
}

