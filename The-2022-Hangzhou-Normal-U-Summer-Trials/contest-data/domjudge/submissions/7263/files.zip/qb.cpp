#include<bits/stdc++.h>
using namespace std;
int main()
{
	string a;
	cin>>a;
	int n;
	cin>>n;
	int minn=10000000;
	string r;
	for(int i=0;i<n;i++)
	{
		string x;
		cin>>x;
		if(a.find(x)!=-1)
		{
			if(a.find(x)<minn)
			{
				minn=a.find(x);
				r=x;
			}
		}
	}
	cout<<r;
}
