#include<bits/stdc++.h>
using namespace std;

#define ll long long;

const int N=1e3+5;
const int mod=1e9+7;

string ss[N];
string s;
int vl[30];

void gtc(string x){
	for(int i=0;i<26;i++){
		vl[s[i]-'a']=i;
	}
}

bool cmp(string x,string y){
	for(int i=0;i<min(x.size(),y.size());i++){
		if(vl[x[i]-'a'] < vl[y[i]-'a']){
			return x<y;
		}else if(vl[x[i]-'a'] > vl[y[i]-'a']){
			return x>y;
		}
	}
	if(x.size()<=y.size())	return x<y;
	else	return x>y;
}

void solve(){
	int n;
	cin>>s>>n;
	gtc(s);
	for(int i=0;i<n;i++){
		cin>>ss[i];
	}
	sort(ss,ss+n,cmp);
	int k;
	cin>>k;
	cout<<ss[k-1]<<"\n";
}

int main(){
	ios::sync_with_stdio(false);
	int t=1;
	while(t--){
		solve();
	}
	return 0;
}

