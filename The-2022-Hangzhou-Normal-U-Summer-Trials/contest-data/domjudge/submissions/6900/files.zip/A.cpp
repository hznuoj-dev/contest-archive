#include<bits/stdc++.h>
using namespace std;
#define yes (cout<<"YES\n")
#define no (cout<<"NO\n")
#define endl '\n'
typedef long long ll;
//#define int long long
void sxseven();
signed main() {
	ios::sync_with_stdio(false);
	int _=1;
	//cin >> _;
	while(_--) sxseven();
	return 0;
}
const int N=1e3+5;
unordered_map<int,int> mp,mp1;
string s[N];
void sxseven() {
	string t;cin >> t;
	for(int i=0;i<26;++i){
		mp[t[i]]=i+'a';
		mp1[i+'a']=t[i];
	}
	int n;cin >> n;
	for(int i=1;i<=n;++i){
		cin >>s[i];
		for(int j=0;j<s[i].size();++j){
			s[i][j]=mp[s[i][j]];
		}
	}
	sort(s+1,s+n+1);
	int k;cin >> k;
	for(int j=0;j<s[k].size();++j){
			s[k][j]=mp1[s[k][j]];
		}
	cout<<s[k];
}

