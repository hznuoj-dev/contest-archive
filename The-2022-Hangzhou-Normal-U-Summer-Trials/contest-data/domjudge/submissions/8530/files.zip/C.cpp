#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <numeric>
#include <bitset>
using namespace std;
#define INF 0x3c3c3c3c // 1010580540, 7f7f7f7f:2139062143
#define llINF 9223372036854775807
const double PI = acos(-1.0);
const double eps = 1e-6;
using ll = long long;
using ull = unsigned long long;
using db = double;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
#define fi first
#define se second
#define pb push_back
#define endl '\n'
#define dbg(a) cout << #a << " = " << (a) << '\n';
#define all(c) (c).begin(), (c).end()
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

const int N = 5e5 + 10;
ll a[N], d[N];

int main(){
    IOS
    int n;
    cin >> n;
    for(int i = 1; i <= n; i++) cin >> a[i];
    for(int i = 1; i <= n; i++){
        d[i] = a[i] - a[i - 1];
    }
    int q;
    cin >> q;
    while(q--){
        ll t;
        cin >> t;
        if(t == 0){
            cout << 0 << endl;
            continue;
        }
        if((ll)t > a[n] - a[1]){
            cout << (a[n] - a[1] + (ll)t) << endl;
            continue;
        }
        // cout << "Hello" << endl;
        __int128 ans = 0;
        for(int i = 1, j = 1; i <= n; i++){
            while(j + 1 <= n && a[j + 1] <= a[i] + t) j++;
            // cout << i << ' ' << j << endl;
            ans += (__int128)a[j] + t - a[i];
            i = j;
        }
        cout << (ll)ans << endl;
    }
    return 0;
}