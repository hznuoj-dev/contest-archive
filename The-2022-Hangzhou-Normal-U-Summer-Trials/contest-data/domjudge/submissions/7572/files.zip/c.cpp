#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll inf=1e18-1;
int n;
ll qn,q;
ll num[500007],d[500007],qt[500007];
int main(){
	scanf("%d",&n);
//	scanf("%lld",num+1);
	for(int i=1;i<=n;++i){
		scanf("%lld",num+i);
		d[i]=num[i]-num[i-1];
	};
	d[n+1]=inf;
	sort(d+2,d+n+1);
	for(int i=2;i<=n;++i) qt[i]=qt[i-1]+d[i];
	qt[n+1]=inf;
	cin>>qn;
	while(qn--){
		scanf("%lld",&q);
		int pos=lower_bound(d+2,d+n+1,q+1)-d-1;
//		cout<<"t"<<pos;
		printf("%lld\n",+q*(n-min(pos,n)+1)+qt[min(pos,n)]);
	}
	
	return 0;
}
