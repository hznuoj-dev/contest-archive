#include<iostream>
#include<string>
using namespace std;
long long int a[500007],n,q,t,b[500007];
int main(){
	cin>>n;
	cin>>a[0];
	for(int i=1;i<n;i++){
		cin>>a[i];
		b[i-1]=a[i]-a[i-1]+1;
	}
	cin>>q;
	for(int i=0;i<q;i++){
		cin>>t;
		if(t<=b[0]){
			cout<<n*t<<'\n';
			continue;
		}else if(t<=b[n-2]){
			for(int i=1;i<n-1;i++){
				if(t<=b[i]){
					cout<<(n-i)*t+b[i-1]<<'\n';
					continue;
				}
			}
		}else{
			cout<<a[n-1]+t-1;
		}
		
	}
	return 0;
} 
