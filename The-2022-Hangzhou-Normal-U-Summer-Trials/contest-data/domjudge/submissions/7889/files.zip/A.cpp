#include<bits/stdc++.h>
using namespace std;
#define dbg(x) cerr << #x << " -> " << x << '\n'
typedef unsigned long long ull;
typedef long long ll;
const int N = 1e5 + 10;
const int SIZE = 1110;
int n,k;
int a[N];
int pre[N];
int main(){
    cin>>n>>k;
    pre[0]=0;
    for(int i=1;i<=n;++i){
        cin>>a[i];
        pre[i]=a[i]+pre[i-1];

    }
//    for(int i=1;i<=n;++i){
//        dbg(pre[i]);
//
//    }
    int i = 0,j = 1;
    ll ans=0;
    while(i<=n){
        while((pre[j]-pre[i])%k!=0&&(pre[j]-pre[i]!=0)&&j<=n ){
            j++;
        }
        dbg(j);
        if(j>n)   break;
        while((pre[j]-pre[i])%k==0 && i<=j){
            ans++;
            i++;
        }
   }
   cout<<ans<<endl;
    
}