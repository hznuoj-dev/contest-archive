#include <bits/stdc++.h>
using namespace std;
int pr[150] = {};

struct Str{
	string a;
};

bool cmp(const struct Str p, const struct Str q) {	
	string l = p.a;
	string r = q.a;
	int ll = l.length();
	int lr = r.length();
	for (int i = 0; i < ll; i++) {
		char n1 = l[i];
		char n2 = r[i];
		if (i == ll - 1 && ll < lr) 
			return false;
		else if (pr[n1] < pr[n2])
			return false;
		else if (pr[n1] > pr[n2])
			return true;
	}
}

int main() {
	string ch;
	cin >> ch;
	Str s[1005];	
	
	for (int i = 0; i < 26; i++) {
		pr[ch[i]] = i;
	}

	int n;
	cin >> n;
	for (int i = 0; i < n ; i++) {
		cin >> s[i].a;
	}
	
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if (cmp(s[i], s[j]))
				swap(s[i].a, s[j].a);
		}
	}	
	int p;
	cin >> p;
	cout << s[p-1].a;	
	
} 


