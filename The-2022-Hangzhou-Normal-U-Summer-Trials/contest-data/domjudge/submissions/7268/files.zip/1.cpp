#include<bits/stdc++.h>
#define sync_flow ios::sync_with_stdio(false);cin.tie(0)
#define zf(i,l,r) for(int i=l;i<=r;i++)
#define df(i,r,l) for(int i=r;i>=l;i--)
#define lowbit(x) (x&(-x))
using namespace std;
typedef long long ll;
const ll maxn=1e3+33;
string rule,s[maxn];
map<char,int>mp;
ll n,k;
int cmp(const string &l,const string &r){
	ll len1=l.size(),len2=r.size();
	ll up=min(len1,len2);
	zf(i,0,up-1){
		if(mp[l[i]]!=mp[r[i]]){
			return mp[l[i]]<mp[r[i]];
		}
	}
	return len1<len2;
}	
int main()
{
	sync_flow;
	cin>>rule;
	zf(i,0,rule.size()-1){
		mp[rule[i]]=i;
	}
	cin>>n;
	zf(i,1,n){
		cin>>s[i];
	} 
	cin>>k;
	sort(s+1,s+n+1,cmp);
	cout<<s[k];
	return 0;
}
/*
acbdefghijklmnopqrstuv	wxyz
2
abc
acb
1
*/
