#include<iostream>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>
#include<random>
#include<bitset>
#include<map>
#include<set>
#include<cmath>
#define ll long long
#define lowbit(x) ((x)&(-(x)))
#define pb push_back
#define vi vector<int>
#define pii pair<int, int>
#define allv(x) (x).begin(), (x).end() 
#define bit32(x) (__builtin_popcount((unsigned int)(x)))
#define bit64(x) (bit32(x>>32)+bit32(x))
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
#define rep(i, st, ed) for(int i = st; i <= ed; i++)
#define revp(i, st, ed) for(int i = st; i <= ed; i--)
#define rand() rng()

using namespace std;
mt19937 rng();
const int N = 3e3 + 10;
int kd[N];
double square(double x){return x * x;}
double speed[5];
struct node
{
    int x, y;
}p[N];
bool vis[N];
int n;
double dist[N];
inline double go(node a, node b, int spd){
    return sqrt(square(a.x - b.x) + square(a.y - b.y)) / spd;
}
void spfa(int st){
    memset(dist, 0x5f, sizeof dist);
    queue<int> q;
    q.push(st);
    vis[st] = true;
    dist[st] = 0;
    while(q.size()){
        int cur = q.front();q.pop();
        vis[cur] = false;
        for(int i = 1; i <= n; i++){
            if(i == cur) continue;
            int v = speed[kd[cur]];
            if(kd[cur] != kd[i]) v = speed[0]; 
            double d = go(p[i], p[cur], v);
            if(dist[i] > dist[cur] + d){
                dist[i] = dist[cur] + d;
                if(!vis[i]){
                    q.push(i);
                    vis[i] = true;
                }
            }
        }
    }
}
int main()
{
    scanf("%d", &n);
    rep(i, 1, 4)
        scanf("%lf", speed + i);
    scanf("%lf", speed);
    int st, ed;
    scanf("%d%d", &st, &ed);
    rep(i, 1, n){
        int x, y;
        scanf("%d%d", &x, &y);
        p[i] = {x, y};
        int k = 0;
        if(x >= 1 && y >= 1) k = 1;
        else if(x <= -1 && y >= 1) k = 2;
        else if(x <= -1 && y <= -1) k = 3;
        else if(x >= 1 && y <= -1) k = 4;
        kd[i] = k;
    }
    spfa(st);
    printf("%.10lf", dist[ed]);
}