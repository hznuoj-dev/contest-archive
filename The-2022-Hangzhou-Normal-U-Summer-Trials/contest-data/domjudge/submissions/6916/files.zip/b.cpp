#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 1e3 + 5;

map<char,int>e;
string f[maxn];

bool cmp(string a, string b){
	for(int i = 0; i < (int)min(a.size(), b.size()); ++i){
		if(e[a[i]] != e[b[i]]) return e[a[i]] < e[b[i]];
	}
	return a.size() < b.size();
}

void solve(){
	string a; cin >> a;
	for(int i = 0; i < a.size(); ++i) e[a[i]] = i;
	int n; cin >> n;
	for(int i = 1; i <= n; ++i) cin >> f[i];
	sort(f + 1, f + 1 + n, cmp);
	int k; cin >> k;
	cout << f[k]; 
	
}

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
