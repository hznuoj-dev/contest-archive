#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

map<char,int> mp;
string line,s[1010];

bool cmp(string x,string y)
{
	for(int i=0;i<x.size();i++)
		if(x[i]!=y[i])
			return mp[x[i]]<mp[y[i]];
	
	return x.size()<y.size();	
}

int main()
{
	cin>>line;
	for(int i=0;i<line.size();i++) mp[line[i]]=i;
	int n;
	cin>>n;
	for(int i=0;i<n;i++) cin>>s[i];
	int k;
	cin>>k;
	sort(s,s+n,cmp);
	cout<<s[k-1]<<endl;
	
	return 0;
}
