#include<bits/stdc++.h>
#define tt(i) cout<<"test: "<<i<<'\n';
using namespace std;
typedef long long ll;
map<int,int>q;
int n,k,cnt=0;
//bool isused[100007];
int a[100007],sum[100007];
ll ad=0,ans=0;
queue<int>temp;
int main(){
	cin>>n>>k;
	for(int i=1;i<=n;++i){
		scanf("%d",a+i);
		sum[i]=sum[i-1]+a[i];
		if(a[i]%k==0) ans++;
		if(sum[i]%k==0&&i!=1) ans++;
		ans+=q[sum[i]%k];
		q[sum[i]%k]++;
		
	}
	
//	tt(1)
//	memset(isused,0, sizeof(isused));
//	for(int i=1;i<=n;++i){
//		ad=0;
////		tt(2)
//		if(!isused[i]){
//				for(int j=i;j<=n;++j){
////					tt(3)
//					ad+=a[j];
//					if(ad%k==0){
//						cnt++;
//					}
//					if(isused[j+1]) {
//						cnt+=
//						break;
//					}
//					else isused[j+1]=true; 
//				}
//		}
//		isused[i]=true;
//	}
	cout<<ans;
	return 0;
}
