#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
	string s;
}node[1100];
int a[150];
int main(){
	ios::sync_with_stdio(false);
	for(int i=1;i<=26;i++){
		char c;
		cin>>c;
		a[c]=i;
	}
	int n,k;
	cin>>n;
	cin>>node[0].s;
	for(int i=1;i<n;i++){
		cin>>node[i].s;
		for(int j=i;j>=1;j--){
			int len=node[j].s.length()>=node[j-1].s.length()?node[j-1].s.length():node[j].s.length();
			int flag=0;
			for(int k=0;k<len;k++){
				if(a[node[j].s[k]]>a[node[j-1].s[k]]){
					flag=1;
					break;
				}
				else if(a[node[j].s[k]]==a[node[j-1].s[k]])
					continue;
				else if(a[node[j].s[k]]<a[node[j-1].s[k]]){
					flag=2;
					swap(node[j],node[j-1]);
					break;
				}
			}
			if(flag==1)
				break;
			else if(flag==0){
				if(node[j].s.length()<node[j-1].s.length()){
					swap(node[j],node[j-1]);
				}
			}
			
		}
		
	}
	cin>>k;
	cout<<node[k-1].s<<endl;
	return 0;
}

