#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
const int N=5e5+3;
long long a[N];
int main(){
	int n;
	cin>>n;
	for (int i=0;i<n;i++){
		cin>>a[i];
	}
	int q;
	cin>>q;
	while(q--){
		long long t;
		cin>>t;
		long long big;
		big=t+a[0];
		long long sum=0;
		for(int i=1;i<n;i++){
			if (a[i]<=big)
			sum+=0;
			else {
				sum+=(a[i]-big);
			}
			big=a[i]+t;
		}
		cout<<a[n-1]+t-sum-1<<"\n";
	}
	return 0;
}
