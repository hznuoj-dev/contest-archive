#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 4e5 + 10, mod = 1e9 + 7;

int f[N], id[26], ch[N];
int find(int x){
	int r = x;
	while(x != f[x]) x = f[x];
	while(r != x){
		int j = f[r];
		f[r] = x;
		r = j;
	}
	return x;
}

void solve(){
	int tot = 0;
	for(int i = 0; i < 26; i++){
		tot++;
		id[i] = tot;
		f[tot] = tot;
		ch[tot] = i;
	}
	int n;
	cin >> n;
	vector<int> s;
	for(int i = 1; i <= n; i++){
		int op;
		char x, y;
		cin >> op;
		if(op == 1){
			cin >> x;
			int p = x - 'a';
			s.push_back(id[p]);
		}else if(op == 2){
			if(!s.empty()) s.pop_back();
		}else{
			cin >> x >> y;
			int f1 = id[x - 'a'], f2 = id[y - 'a'];
			f1 = find(f1);f2 = find(f2);
			if(f1 != f2){
				f[f1] = f2;
				tot++;
				id[x - 'a'] = tot;
				f[tot] = tot;
				ch[tot] = x - 'a';
			}
		}
	}
	if(s.empty()){
		cout << "The final string is empty\n";
		return;
	}
	for(int i : s){
		int p = find(i);
		char k = ch[p] + 'a';
		cout << k;
	}
	cout << '\n';
}

int main(){
	int T = 1;
	while(T--) solve();
	return 0;
}
