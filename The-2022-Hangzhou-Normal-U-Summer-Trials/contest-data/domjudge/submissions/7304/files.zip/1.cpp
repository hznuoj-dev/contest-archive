#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>
using namespace std;
const int N=1005;
int a[26];
string str[N];
bool check(string s1,string s2)
{
    bool flag=0;
    int n1=s1.size(),n2=s2.size();
    int i=0;
    while(s1[i]==s2[i]&&i<n1&&i<n2)i++;
    if(i!=n1&&i!=n2)
    {
        return a[s1[i]-'a']<a[s2[i]-'a'];
    }
    else if(i==n1||i==n2)
    {
        return n1<n2;
    }
    else return false;
}

void quick_sort(int l,int r)
{
    if(l>=r)return;
    int i=l-1,j=r+1;
    while(i<j)
    {
        do i++;while(check(str[i],str[l]));
        do j--;while(check(str[l],str[j]));
        if(i<j) swap(str[i],str[j]);
        else break;
    }
    quick_sort(l,j),quick_sort(j+1,r);
}
int main()
{
    string s;
    cin>>s;
    for(int i=0;i<26;i++)
    {
        a[s[i]-'a']=i;
    }
    int n;
    cin>>n;
    for(int i=0;i<n;i++)
    {
        cin>>str[i];
    }
    quick_sort(0,n-1);
    int k;
    cin>>k;
    cout<<str[k-1]<<endl;
}
