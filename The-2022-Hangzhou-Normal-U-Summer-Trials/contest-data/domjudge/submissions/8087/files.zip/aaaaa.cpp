#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
using namespace std;
using LL=long long;
const int N=1e5+10;
int n,m,k;
set<int>v[200];
char str[N];
signed main(){
	ios::sync_with_stdio(0);
	int q;cin>>q;
	int len=0;
	while(q--){
		int op;cin>>op;
		if(op==1){
			len++;
			char ch;cin>>ch;
			int idx=ch-'a';
			v[idx].insert(len);
		}
		else if(op==2){
			if(len==0)continue;
			rep(i,0,25)if(v[i].count(len))v[i].erase(len);
			len--;
		}
		else{
			char x,y;cin>>x>>y;
			int xx=x-'a',yy=y-'a';
			if(v[xx].size()>v[yy].size())swap(v[xx],v[yy]);
			for(auto ch:v[xx])v[yy].insert(ch);
			v[xx].clear();
		}
	}
	if(len==0){
		cout<<"The final string is empty";
		return 0;
	}
	rep(i,0,25){
		for(auto x:v[i])str[x]='a'+i;
	}
	rep(i,1,len)cout<<str[i];
}
