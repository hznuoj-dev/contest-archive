#include<bits/stdc++.h>
using namespace std;
char buf[1000010];
	int main() {
//		ios::sync_with_stdio(false);
//		cin.tie(nullptr);
	scanf("%s", buf);
	char*p=buf;
	int ans=0;
	while(*p!='\0'){
		if(*p=='h'){
			if(*(p+3)=='u'){
				if(*(p+2)=='n'){
					if(*(p+1)=='z'){
						p+=3;
						ans++;			
					}				
				}
			}
			p++;
		}else{
			p++;
		}
	}
	printf("%d",ans);
	}
