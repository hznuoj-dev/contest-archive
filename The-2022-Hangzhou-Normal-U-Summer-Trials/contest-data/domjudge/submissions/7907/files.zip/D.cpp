#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define lowbit(x)(x&-x)
typedef pair<int,int>PII;
const int INF = 0x3f3f3f3f;
typedef pair<int,string>PIS;
typedef pair<double,double>PDD;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
int lcm(int a,int b){return a*b/gcd(a,b);}
#define snow ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
const int N = 2e5+10;
int e[N],ne[N],h[N],idx;
int sum[N];
int number[N];
int n;
void add(int a,int b){
    e[idx]=b;
    ne[idx]=h[a];
    h[a]=idx++;
}
void dfs(int u,int fa){
    int cnt=0;
    int left=0;
    int right=0;
    for(int i=h[u];i!=-1;i=ne[i]){
        int j=e[i];
        if(j==fa)continue;
        cnt++;
        dfs(j,u);
        if(cnt==1)left=number[j];
        else if(cnt==2)right=number[j];
        number[u]+=number[j];
    }
    int up=n-left-right-1;
    sum[u]=n-1+(left*up)+(right*up)+(left*right);
}  
signed main(){
    snow
    cin>>n;
    memset(h,-1,sizeof h);
    for(int i=1;i<=n;i++)number[i]=1;
    for(int i=1;i<=n-1;i++){
        int a,b;
        cin>>a>>b;
        add(a,b);
        add(b,a);
    }
    dfs(1,-1);
    int m;
    cin>>m;
    for(int i=1;i<=m;i++){
        int x;
        cin>>x;
        cout<<sum[x]<<endl;
    }
    // for(int i=1;i<=n;i++)cout<<sum[i]<<endl;
    return 0;
}