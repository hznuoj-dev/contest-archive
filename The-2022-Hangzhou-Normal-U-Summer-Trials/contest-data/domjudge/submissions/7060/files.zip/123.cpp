#include<bits/stdc++.h>
#define int long long
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;
int val[30];
struct node{
	char st[1010];
	bool operator < (const node &x)const{
		int n1=strlen(st);
		int n2=strlen(x.st);
		for(int i=0;i<min(n1,n2);i++){
			if(val[st[i]-'a']!=val[x.st[i]-'a'])return val[st[i]-'a']<val[x.st[i]-'a'];
		}
		return n1<n2;
	}
}k[1010];
int t,n,m;

char str[1010];
signed main(){
	FAST
	cin>>str;
	for(int i=0;i<26;i++)val[str[i]-'a']=i;
	cin>>n;
	for(int i=1;i<=n;i++)cin>>k[i].st;
	sort(k+1,k+n+1);
//	for(int i=1;i<=n;i++)cout<<k[i].st<<endl;
	cin>>m;
	cout<<k[m].st;
} 
