#include <bits/stdc++.h>
using namespace std;
const int maxn=5e5+10;

#define int  long long
int pre[maxn];
int a[maxn];
signed main(){
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		cin>>pre[i];
	}
	for(int i=1;i<n;i++){
		a[i]=pre[i+1]-pre[i];
	}
	int q;cin>>q;
	for(int i=1;i<=q;i++){
		int t;cin>>t;
		int pos=upper_bound(a+1,a+n,t)-a;
		//cout<<pos<<endl;
		int ans=pre[pos]-pre[1];
		ans+=(n-pos+1)*t;
		cout<<ans<<endl;
	}


	//system("pause");
}