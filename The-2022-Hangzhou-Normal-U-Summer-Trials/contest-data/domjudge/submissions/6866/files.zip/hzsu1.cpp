#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define int long long
#define ll long long
using namespace std;
signed main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	string s1;cin>>s1;
	int sum=0;
	int a[4]={'h','z','n','u'};
	rep(i,0,s1.size()-1){
		int flag=1;
		rep(j,0,3){
			if(a[j]!=s1[i+j]){
				flag=0;
				break;
			}
		}
		if(flag){
			i=i+3;
			sum++;
		}
		else{
			continue;
		}
	}
	cout<<sum<<endl;
	return 0;
} 
