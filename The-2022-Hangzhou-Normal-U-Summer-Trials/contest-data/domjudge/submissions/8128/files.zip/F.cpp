#include<bits/stdc++.h>
using namespace std;

#define ll long long

const int N=5e5+5;
const int mod=1e9+7;

ll a[N],pre[N];
map<ll,ll>mp;

void solve(){
	int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	for(int i=1;i<=n;i++){
		pre[i]=(pre[i-1]+a[i])%k;
		mp[pre[i]]++;
	}
	ll ans=0;
	for(auto item:mp){
		ans+=(1ll<<(item.second-1));
	}
	cout<<ans<<"\n";
}

int main(){
	ios::sync_with_stdio(false);
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}

