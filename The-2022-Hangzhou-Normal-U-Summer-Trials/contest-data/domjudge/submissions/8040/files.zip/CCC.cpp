#include <bits/stdc++.h>
#define endl '\n'
#define int unsigned long long
using namespace std;
typedef long long ll;
const int N=5e5+10;
const int M=1e9+7;

int a[N];
map<int,int> c;

void run()
{
	int n,q,t;
	
	cin >> n;
	for(int i=1;i<=n;i++)
	{
		cin >> a[i];
		if(i>1)
			c[a[i]-a[i-1]]++;
	}
	cin >> q;
	map<int,int>::iterator it=c.begin();
	int cheng=n,temp=0;
	while(q--)
	{
		cin >> t;
		while((it->first)<t && it!=c.end())
		{
			cheng-=(it->second);
			temp+=(it->first)*(it->second);
			it++;
		}
		cout << temp+cheng*t << endl;
	}
}

signed main()
{
	int T=1;
	
	ios::sync_with_stdio(0);
	//cin >> T;
	while(T--)
		run();
	
	return 0;
}
