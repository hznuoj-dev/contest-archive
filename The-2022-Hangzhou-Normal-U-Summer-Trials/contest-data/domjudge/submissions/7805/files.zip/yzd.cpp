#include <bits/stdc++.h>

using namespace std;


long long a[500005];

long long dex[500005];

int main() {
	long long n;
	cin >> n;
	for(int i = 0 ; i<n ; i++){
		cin >> a[i];
	}
	for(int i = 0 ; i<n-1 ; i++){
		dex[i] = a[i+1] - a[i];
	}
	for(int i = 0 ; i<n-1 ; i++){
		cout << dex[i] << endl;
	}
	int q;
	cin >> q;
	for(int i = 0 ; i<q ; i++){
		long long t;
		cin >> t;
		long long ans = t;
		for(int j = 0 ; j<n-1 ; j++){
			if(t <= dex[j]){
				ans += t;
			}
			else{
				ans += dex[j];
			}
			//cout << ans << endl;
		}
		
		cout << ans <<endl;
		
	}
	
	
	
}

