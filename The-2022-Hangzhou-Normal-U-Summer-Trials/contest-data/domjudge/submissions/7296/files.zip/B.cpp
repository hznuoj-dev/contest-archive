#include <stdio.h>
#include <string.h>

char lex[30];

int cmp(char *s1, char *s2)
{
	int l1 = strlen(s1), l2 = strlen(s2);
	int min;
	
	if (l1 < l2)
	{
		min = l1;
	}
	else
	{
		min = l2;
	}
	for (int i = 0; i < min; i++)
	{
		for (int j = 0; j < 26; j++)
		{
			if (s1[i] == lex[j] && s2[i] != lex[j])
			{
				return -1;
			}
			else if (s1[i] != lex[j] && s2[i] == lex[j])
			{
				return 1;
			}
		}
	}
	if (l1 == l2)
	{
		return 0;
	}
	if (l1 > l2)
	{
		return 1;
	}
	return -1;
}

int main()
{
	char str[1007][1007];
	int rank[1007] = {0};
	int n, k;
	int min;
	
	scanf("%s", lex);
	scanf("%d", &n);
	for (int i = 0; i < n; i++)
	{
		getchar();
		scanf("%s", str[i]);
	}
	scanf("%d", &k);
	while (k--)
	{
		min = 0;
		while (rank[min] > 0)
		{
			min++;
		}
		for (int i = 0; i < n; i++)
		{
			if (cmp(str[i], str[min]) < 0 && rank[i] == 0)
			{
				min = i;
			}
		}
		rank[min] = 1;
	}
	printf("%s", str[min]);
	
	return 0;
}
