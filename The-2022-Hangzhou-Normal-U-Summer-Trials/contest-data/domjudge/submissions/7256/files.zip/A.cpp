#include <bits/stdc++.h>

using namespace std;

string st;
struct node
{
    string s;
} s[10001];

bool operator<(node a, node b)
{
    int sz;
    if ((int)a.s.size() > (int)b.s.size())
        sz = b.s.size();
    else
        sz = a.s.size();
    for (int i = 0; i < sz; i++)
    {
        if (st.find(a.s[i]) < st.find(b.s[i]))
            return true;
    }
    if ((int)a.s.size() < (int)b.s.size())
        return true;
    return false;
}

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    cin >> st;
    int n;
    cin >> n;
    for (int i = 1; i <= n; i++)
    {
        cin >> s[i].s;
    }
    // cout << st.find('c') << endl;
    sort(s + 1, s + 1 + n);
    int k;
    cin >> k;
    // for (int i = 1; i <= n; i++)
    //     cout << s[i].s << endl;
    cout << s[k].s;

    return 0;
}