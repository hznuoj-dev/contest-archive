#include <bits/stdc++.h> 
using namespace std;
char str[100050];
int tim[100050];
int tit[50][100050];
char tic[50][100050];
char c,c1,c2;
int pos=0;
int t=1;
int main()
{
	int n,f;
	scanf("%d",&n);
	t=1;
	for (int i=1; i<=26; i++) { tit[i][0]++; tit[i][tit[i][0]]=0; tic[i][tit[i][0]]=char('a'+i-1); }
	while (t<=n)
	{
		scanf("%d",&f);
		if (f==1) 
		{ 
			scanf(" %c",&c); pos++;
			str[pos]=c;
			tim[pos]=t; 
		}
		if (f==2) { pos--; if (pos<=0) pos=0; }
		if (f==3)  
		{
			scanf(" %c %c",&c1,&c2);	
				
			tit[c1-'a'+1][0]++;
			tit[c1-'a'+1][tit[c1-'a'+1][0]]=t;
			tic[c1-'a'+1][tit[c1-'a'+1][0]]=c2;
		}
		t++;
	}
	for (int i=1; i<=26; i++) { tit[i][0]++; tit[i][tit[i][0]]=t; tic[i][tit[i][0]]=char('a'+i-1); }

	
	if (pos<=0) { printf("The final string is empty\n"); return 0; }
	else 
	{
		for (int i=1; i<=pos; i++)
		{
			int s=str[i]-'a'+1;
			int l=lower_bound(tit[s]+1,tit[s]+tit[s][0]+1,tim[i])-tit[s];
			int ti=tit[s][l];
			while (ti!=t)
			{
				s=tic[s][l]-'a'+1;
				l=lower_bound(tit[s]+1,tit[s]+tit[s][0]+1,ti)-tit[s];
				ti=tit[s][l];
			}
			printf("%c",tic[s][l]);
		}
		return 0;
	}
	printf("The final string is empty\n");
}
