#include <bits/stdc++.h>

using namespace std;

long long a[500005];

long long dex[500005];

int main() {
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	long long n;
	cin >> n;
	for(int i = 1 ; i<=n ; i++){
		cin >> a[i];
	}
	
	long long sum = 0;
	for(int i = 1 ; i<=n-1 ; i++){
		dex[i] = a[i+1] - a[i];
		sum += dex[i];
	}
	int q;
	cin >> q;
	for(int i = 1 ; i<=q ; i++){
		long long t;
		cin >> t;
		long long ans = t;
		if(t <= dex[1]){
			ans += t*(n-1);
		}
		else if (t >= dex[n-1]){
			ans += sum;
		}
		else{
			long long pos = -1;
			for(int j = 1 ; j<=n-1 ; j++){
				if(dex[j] > t){
					pos = j;
					break;
				}
			}
			for(int j = 1 ; j<=pos-1 ; j++){
				ans += dex[j];
			}
		
			ans += t * (n-pos);
			
		}
		
		cout << ans << endl;
	}
	
}

	
	

