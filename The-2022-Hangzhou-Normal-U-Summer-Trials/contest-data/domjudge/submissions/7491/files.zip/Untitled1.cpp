#include<bits/stdc++.h>
using namespace std;
char dx[27];
string a[1005];
bool cmp(string b,string c)
{
	int i,l,idxb,idxc;
	char *posb,*posc;
	l=min(b.length(),c.length());
	for(i=0;i<l;i++)
	{
		if(b[i]!=c[i])
		{
//			posb=lower_bound(dx,dx+27,b[i]);
//			idxb=distance(dx,posb);
//			cout<<idxb<<endl;
//			posc=lower_bound(dx,dx+27,c[i]);
//			idxc=distance(dx,posc);
//			cout<<idxc<<endl;
			for(int j=0;j<26;j++)
			{
				if(b[i]==dx[j])
				{
					idxb=j;
					break;
				}
			}
			for(int j=0;j<26;j++)
			{
				if(c[i]==dx[j])
				{
					idxc=j;
					break;
				}
			}
			if(idxb<idxc)
			{
				return 1; 
			}
			else
				return 0; 
		}
	}
	if(b.length()>c.length())
	{
		return 0;
	}
	else
		return 1;
}
int main()
{
	int n,k,i;
	cin>>dx;
	cin>>n;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
	}
	cin>>k;
	sort(a,a+n,cmp);
	cout<<a[k-1];
} 
