#include<bits/stdc++.h>
using namespace std;

#define INF ox3f3f3f3f

struct xinxi{
	string name;
	int id;
}ss[1001];


bool comp(struct xinxi x,struct xinxi y){
	return x.name<y.name;
}

int main(){
	
//	int n,k;
//	cin>>n>>k;
//	
//	for(int i=1;i<=n;i++){
//		cin>>a[i];
//		sum[i]=sum[i-1]+a[i];//ǰ׺�� 
//	}
//	
//	int count=0;
//	
//	for(int i=1;i<=n;i++){
//		for(int j=0;j<i;j++){
//			if((sum[i]-sum[j])%k==0){
//				count++;
//			}
//		}
//	}
//
//	cout<<count<<endl;
	
	string s;
	getline(cin,s);
	
	int n;
	cin>>n;
	//string ss[1001];
	for(int i=0;i<1001;i++){
		ss[i].name="";
	}
	
	
	string x[26]={"a","b","c","d","e","f","g","h","i","j","k","l","m","n","o","p","q","r","s","t","u","v","w","x","y","z"};
	
	map<char,string>mp;
	for(int i=0;i<s.length();i++){
		mp[s[i]]=x[i];
	}
	
	getchar();
	string ans[1001];
	for(int i=1;i<=n;i++){
		string t;
		getline(cin,t);
		ans[i]=t;
		ss[i].id=i;
		for(int j=0;j<t.length();j++){
			ss[i].name+=mp[t[j]];
		}
	}
	
	int k;
	cin>>k;
	sort(&ss[1],&ss[n+1],comp);
	 
	
	cout<<ans[ss[k].id]<<endl;
	
	
	return 0;
} 
