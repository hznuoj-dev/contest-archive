#include<bits/stdc++.h>
using namespace std;
int main()
{
	string a;
	cin>>a;
	int p=0;
	int cou=0;
	while(a.find("hznu",p)!=-1)
	{
		p=a.find("hznu",p)+1;
		cou++;
	}
	cout<<cou;
}
