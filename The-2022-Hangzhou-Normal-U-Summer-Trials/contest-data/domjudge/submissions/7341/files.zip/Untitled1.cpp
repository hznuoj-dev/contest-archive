#include <bits/stdc++.h>
using namespace std;
int pr[150] = {};

struct Str{
	string a;
};

bool cmp(const struct Str p, const struct Str q) {	
	string l = p.a;
	string r = q.a;
	for (int i = 0; i < l.length(); i++) {
		if (i == l.length() - 1 && l.length() < r.length()) 
			return false;
		else if (pr[l[i]] < pr[r[i]])
			return false;
		else if (pr[l[i]] > pr[r[i]])
			return true;
	}
}

int main() {
	string ch;
	cin >> ch;
	Str s[1005];	
	
	for (int i = 0; i < 26; i++) {
		pr[ch[i]] = i;
	}

	int n;
	cin >> n;
	for (int i = 0; i < n ; i++) {
		cin >> s[i].a;
	}
	
	for (int i = 0; i < n - 1; i++) {
		for (int j = i + 1; j < n; j++) {
			if (cmp(s[i], s[j]))
				swap(s[i].a, s[j].a);
		}
	}	
	int p;
	cin >> p;
	cout << s[p-1].a;	
	
} 


