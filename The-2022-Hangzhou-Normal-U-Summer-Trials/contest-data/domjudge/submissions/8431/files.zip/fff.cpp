#include<bits/stdc++.h>
using namespace std;
int a[100010]={0};
int main(){
	int n,k;
	string s="";
	cin>>n>>k;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	int sum=0,ans=0;
	for(int i=0;i<n;i++){
		sum=a[i];
		for(int j=i;j<n;j++){
			sum=(j==i?sum:sum+a[j]);
			if(sum%k==0){//&&s[sum]!='1'
				//cout<<sum<<"i="<<i<<"j="<<j<<endl;
				//s[sum]='1';
				ans++;
			}
		}
	}
	cout<<ans<<endl;
} 
