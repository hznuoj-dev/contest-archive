#include <bits/stdc++.h>
using namespace std;
#define int long long
int a[500100];
int d[500100];
int n;
map<int,int> ma;
signed main() 
{
cin>>n;
for(int i=1;i<=n;i++){
cin>>a[i];d[i]=a[i]-a[i-1];}
int q;
cin>>q;
for(int i=1;i<=q;i++){
	int t;
	cin>>t;
	int l=2;int r=n;
	while(l<=r){
		int mid=(l+r)/2;
		if(d[mid]>t)r=mid-1;
		else l=mid+1;
	}
	printf("l=%lld\n",l);
	if(l>n){
		printf("%lld\n",a[n]+t-1);
		continue;
	}
	if(l==2){
		printf("%lld\n",t*n);
		continue;
	}
	printf("%lld\n",a[l-1]-1+(n-(l-2))*t);
}
}
