#include<bits/stdc++.h>
#define int long long
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;
int n;
char x[10],y[10];
signed main(){
	deque<char>que;
	int q;cin>>q;
	while(q--){
		cin>>n;
		if(n==1){
			cin>>x;
			que.push_back(x[0]); 
		} 
		else if(n==2){
			if(!que.empty())que.pop_back();
		}
		else{
			cin>>x>>y;
			int m=que.size();
			while(m--){
				char kk=que.front();
				que.pop_front();
				if(kk==x[0])que.push_back(y[0]);
				else que.push_back(kk);
			}
		}
	}
	if(que.empty())cout<<"The final string is empty";
	else{
		while(!que.empty()){
			cout<<que.front();
			que.pop_front();
		}
	}
		
}
