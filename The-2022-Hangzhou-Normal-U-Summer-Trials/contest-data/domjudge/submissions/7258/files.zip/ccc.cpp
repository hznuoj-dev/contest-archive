#include<bits/stdc++.h>
using namespace std;

const int N=5e5+7,M=1e9+7;
int n,q;
long long a[N],cha[N];

void solve(){
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
		if(i>0) cha[i]=a[i]-a[i-1];
	}
	cin>>q;
	int index=1;
	for(int i=0;i<q;i++){
		long long t;
		cin>>t;
		while(index<n&&cha[index]<=t) index++;
		long long ans=a[index-1]-a[0]+(n-index+1)*t;
		cout<<ans<<'\n';
	}
}

int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int T=1;
	//cin>>T;
	while(T--) solve();
	return 0;
}
