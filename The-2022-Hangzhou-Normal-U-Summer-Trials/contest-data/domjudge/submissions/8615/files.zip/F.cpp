#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[100100];
map <int,int> yu;
int main()
{
	ll k,l,t,ma,n;
	ll i,j,ans=0;
	scanf("%lld %lld",&n,&ma);
	for (i=1;i<=n;i++)
	{
		scanf("%d",&k);
		a[i]=a[i-1]+k;
		if (a[i]%ma==0) ans++;
		ans+=yu[a[i]%ma];
		yu[a[i]%ma]++;
	}
	printf("%lld",ans);
}
