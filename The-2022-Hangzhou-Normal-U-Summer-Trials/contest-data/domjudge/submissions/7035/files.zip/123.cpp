#include<iostream>
#include<cstring>

using namespace std;

int main()
{
	char str[100010];
	cin.getline(str, 100010);
	int n = strlen(str);
	int sum = 0;
	char s[] = "hznu";
	for(int i = 0; i <= n - 4; i++)
	{
		int flag = 1;
		for(int j = 0; j < 4; j++)
		{
			if(s[j] != str[i + j])
			{
				flag = 0;
				break;
			}
		}
		if(flag)
		{
			sum++;
		}
	}
	cout << sum;
}
