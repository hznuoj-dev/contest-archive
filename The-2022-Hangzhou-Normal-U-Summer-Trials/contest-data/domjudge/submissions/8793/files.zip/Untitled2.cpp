#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define moonoom ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
const ll MAXN=5e5+10;
ll sum[MAXN];
ll arr[MAXN];
signed main(){
	moonoom;
	long int n;ll k;
	cin>>n>>k;
	ll ans=0;
	
	for(int i=1;i<=n;i++){
		cin>>arr[i];
		arr[i]%=k;
		sum[i]=sum[i-1]+arr[i];
	}	
	
	for(int len=1;len<=n;len++){
		for(int i=0;i+len<=n;i++){
			if((sum[i+len]-sum[i])%k==0)ans++;
		}
	}
	cout<<ans<<endl;
}
