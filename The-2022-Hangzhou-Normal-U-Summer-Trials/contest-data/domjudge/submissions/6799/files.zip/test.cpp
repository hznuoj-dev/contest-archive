#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=5e3+10;
const int mod=1e9+7;
int t,n,p;
ll a[maxn];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    string s;
    cin>>s;
    int ans=0;
    for(int i=0;i<s.length()-3;i++)  
    {
        if(s.substr(i,4)=="hznu")  ans++;
    }
    cout<<ans;
    return 0;
}










