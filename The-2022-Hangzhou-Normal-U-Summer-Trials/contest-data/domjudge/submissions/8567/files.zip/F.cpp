#include<bits/stdc++.h>
using namespace std;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n,k;
	cin>>n>>k;
	int a[n+1];
	for(int k=1;k<=n;k++)
	{
		cin>>a[k];
	}
	int t=0;
	for(int i=1;i<=n;i++)
	{
		long long int ci=0;
		for(int j=i;j<=n;j++)
		{
			ci=ci+a[j];
			if(ci%k==0) 
			{
//				cout<<i<<" "<<j<<" "<<ci<<endl;
				t++;
			}
		}
	}
	cout<<t;
	return 0;
}
