#include  <bits/stdc++.h>
using namespace std;

int n, k;
unsigned long long num[500100];

int work()
{
    int i, j, t;
    unsigned long long sum = 0;

    scanf("%d%d", &n, &k);
    for (i = 1; i <= n; i++)
    {
        scanf("%lld", &num[i]);
        num[i] = (num[i] + num[i-1]) % k;
    }
            /*for (i = 1; i <= n; i++) printf ("%lld ", num[i]);
            printf ("\n");*/

    for (i = 1; i <= n; i++)
    {
                                //printf ("%d:", i);
        for (j = i; j <= n; j++)
            if ((num[j]-num[i-1]+k)%k==0) sum++;//, printf ("%d:%lld %d:%lld %lld\n  ", j, num[j], i-1, num[i-1], (num[j]-num[i-1])%k);
                                //printf ("\n");
    }
    printf ("%lld", sum);

    return 0;
}

int main()
{
    int T = 1;
    //scanf("%d", &T);
    while (T--) work();
    //getchar();getchar();getchar();
    return 0;
}