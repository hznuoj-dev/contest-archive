#include<bits/stdc++.h>
using namespace std;

#define INF ox3f3f3f3f



int main(){
	
	int n;
	cin>>n;
	
	int a[n+1]={0};
	for(int i=1;i<=n;i++){
		cin>>a[i];
	}
	
	int q;
	cin>>q;
	map<int,int>mp;
	while(q--){
		int count=0;
		
		int t;
		cin>>t;
		
		for(int i=1;i<=n;i++){
			for(int j=0;j<t;j++){
				mp[a[i]+j]++;
			}
		}
		
		cout<<mp.size()<<endl;
	}
	
	

	
	
	return 0;
} 
