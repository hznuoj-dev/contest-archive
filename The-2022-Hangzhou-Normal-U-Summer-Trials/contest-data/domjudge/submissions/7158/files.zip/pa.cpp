#include <bits/stdc++.h>
using namespace std;
long long n,k,m,l,r,x;
long long a[500010];
int main ()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
		cin >> a[i];
	sort(a+1,a+n+1);
	cin >> k;
	for (int i = 1; i <= k; i++)
		{
			cin >> x;
			l=1; r=n; 
			while (l <= r) {
				m=(l+r)/2;
				if (a[m] <= x) l=m+1; else r=m-1;
			}
			if (a[r] <= x) {
				cout << a[r]+(n-r+1)*x-1 << '\n';
			}
		}
	return 0;
}
