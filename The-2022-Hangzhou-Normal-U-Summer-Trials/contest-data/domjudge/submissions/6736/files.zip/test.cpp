#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=5e3+10;
const int SIZE=1000000+100;
const int mod=1e9+7;
int n,m,k;
void solve(){
    string s;
    cin>>s;
    n=s.size();
    int cnt=0;
    for(int i=0;i<n-3;i++){
        if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u') cnt++;
    }
    cout<<cnt<<endl;
}
void inits(){}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int ts=1;
    inits();
    while(ts--){
        solve();
    }
    return 0;
}