#include<bits/stdc++.h>
#include<unordered_map>
#pragma GCC optimize(2)
#define endl '\n'
#define ll long long
#define ull unsigned long long
#define mem(a, b) memset(a, b, sizeof a)
//#define int ll
#define pii pair<int,int>
#define all(a) a.begin(), a.end()
using namespace std;

#define dbg(x) do { cout << #x << " -> "; err(x); } while(0)

void err()
{
	cout << endl;
}

template<class T, class... Ts>
void err(const T& arg, const Ts &... args)
{
	cout << arg << ' ';
	err(args...);
}

const int maxn = 1e5 + 10;
const ll mod = 1e9 + 10;
const ll MOD = 1000003;
const double eps = 1e-4;
const double pi = acos(-1.0);
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;

ll n, m, k, q;
ll a[maxn];
ll b[maxn];
map<ll, ll> mp;

void solve()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		if (i >= 2)
		{
			b[i - 1] = a[i] - a[i - 1];
			mp[a[i] - a[i - 1]] = i - 1;
		}

	}
	cin >> q;
	ll cnt = 0;
	while (q--)
	{
		cin >> k;
		if (*upper_bound(b + 1, b + n, k) == 0)
		{
			cout << a[n] + k - a[1] << endl;
			continue;
		}
		ll check = mp[*upper_bound(b + 1, b + n, k)];
		cnt = a[check] - a[1];
		cnt += (n - check + 1) * k;
		cout << cnt << endl;
	}
}

signed main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); cout.tie(0);
	//freopen("mosalah.in", "r", stdin);
	int t = 1;
	//cin >> t;
	while (t--)
		solve();
	return 0;
}