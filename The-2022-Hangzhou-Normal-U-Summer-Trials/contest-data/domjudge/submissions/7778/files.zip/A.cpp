#include<bits/stdc++.h>
using namespace std;
#define yes (cout<<"YES\n")
#define no (cout<<"NO\n")
#define endl '\n'
//typedef long long ll;
//#define int long long
void sxseven();
signed main() {
	ios::sync_with_stdio(false);
	int _=1;
	//cin >> _;
	while(_--) sxseven();
	return 0;
}
const int N=1e5+5;
struct node{
	int x1,x2;
};
int mp[500][500],n;
string s[55];
void sxseven() {
	cin >> n;
	int x1,x2;
	for(int i=0;i<n;++i){
		cin >> s[i];
		for(int j=0;j<n;++j){
			if(s[i][j]=='a'){
				x1=i*n+j;
			}else if(s[i][j]=='b'){
				x2=i*n+j;
			}
		}
	}
	mp[x1][x2]=1;
	int xx1,xx2;
	queue<node> q;
	node p;
	q.push({x1,x2});
	while(!q.empty()){
		p=q.front();
		q.pop();
		xx1=p.x1;
		xx2=p.x2;
		//cout<<xx1<<' ' <<xx2<<endl;
		for(int i=0;i<4;++i){
			x1=xx1;x2=xx2;
			if(i==1){
				if(xx1%n<n-1)x1=xx1+1;
				if(xx2%n<n-1)x2=xx2+1;
			}else if(i==2){
				if(xx1%n>0)x1=xx1-1;
				if(xx2%n>0)x2=xx2-1;
			}else if(i==3){
				if(xx1/n<n-1)x1=xx1+n;
				if(xx2/n<n-1)x2=xx2+n;
			}else if(i==0){
				if(xx1/n>0)x1=xx1-n;
				if(xx2/n>0)x2=xx2-n;
			}
			if(s[x1/n][x1%n]=='*')x1=xx1;
			if(s[x2/n][x2%n]=='*')x2=xx2;
			if(x1==x2){
				cout<<mp[xx1][xx2];return;
			}
			if(mp[x1][x2])continue;
			mp[x1][x2]=mp[xx1][xx2]+1;
			q.push({x1,x2});
		}
	}
	cout<<"no solution";
}

