#include<bits/stdc++.h>
using namespace std;
#define yes (cout<<"YES\n")
#define no (cout<<"NO\n")
#define endl '\n'
typedef long long ll;
//#define int long long
void sxseven();
signed main() {
	ios::sync_with_stdio(false);
	int _=1;
	//cin >> _;
	while(_--) sxseven();
	return 0;
}
const int N=1e5+5;
string t="hznu";
void sxseven() {
	string s;cin >> s;
	int n=s.size()-3,an=0;
	for(int i=0;i<n;++i){
		for(int j=0;j<4;++j){
			if(s[i+j]!=t[j])break;
			if(j==3) ++an;
		}
	}
	cout<<an;
}

