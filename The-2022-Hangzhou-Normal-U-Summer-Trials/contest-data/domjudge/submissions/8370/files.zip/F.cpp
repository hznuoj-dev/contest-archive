#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define lowbit(x)(x&-x)
typedef pair<int,int>PII;
const int INF = 0x3f3f3f3f;
typedef pair<int,string>PIS;
typedef pair<double,double>PDD;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
int lcm(int a,int b){return a*b/gcd(a,b);}
#define snow ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
const int N = 1e5+10;
int a[N];
int s[N];
signed main(){
    snow
    int n,k;
    cin>>n>>k;
    map<int,int>mp;
    for(int i=1;i<=n;i++)cin>>a[i],a[i]=(a[i-1]+a[i])%k;
    int res=0;
    for(int i=1;i<=n;i++){
        mp[a[i]]++;
        if(a[i]==0)
        res+=mp[a[i]];
        else res+=mp[a[i]]-1;
    }
    cout<<res<<endl;
    return 0;
}