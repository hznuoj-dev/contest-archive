#include <stdio.h>
#include <string.h>

const int N = 1e5 + 10;

int main(void)
{
	int n, i, j;
	unsigned int k, cou = 0, sum;
	unsigned int a[100010];

	scanf("%d %d", &n, &k);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
	}
	if (k == 1)
		cou = n * (n + 1) / 2;
	else
		for (i = 0; i < n; i++)
		{
			sum = 0;
			for (j = i; j < n; j++)
			{
				sum += a[j];
				if (sum % k == 0)
					cou++;
			}
		}
	printf("%ld", cou);

	return 0;
}