#include<bits/stdc++.h>
using namespace std;
const int maxn = 5e5 + 10;
int a[maxn];
int main(){
//	ios::sync_with_stdio(false);
//	cin.tie(0);
	int n;
	cin >> n;
	for(int i = 0; i < n; ++i) cin >> a[i];
	int q;
	cin >> q;
	for(int i = 0; i < q; ++i){
		long long t, ans = 0;
		cin >> t;
		a[n] = a[n - 1] + t;	
		for(int j = 1; j <= n; ++j){		
			if(a[j] - a[j - 1] >= t){
				ans += t * (n - j + 1); 
				break;
			}
			ans += a[j] - a[j - 1];
		}
		cout << ans << '\n';
	}
	return 0;
} 
