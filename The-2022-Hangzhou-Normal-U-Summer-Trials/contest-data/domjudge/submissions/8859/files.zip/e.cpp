#include<bits/stdc++.h>
#define tt(i) cout<<"test: "<<i<<'\n';
using namespace std;
typedef long long ll;
int temp[100007],sum[100007];
struct tr{
	int ct;
	vector<int>son;
}t[100007];
int count(int v){
//	tt(v)
	if(t[v].ct!=0) return t[v].ct;
	int len=t[v].son.size();
	if(len==0) return 0;
	int cntt=0;
	for(int i=0;i<len;++i){
		cntt+=count(t[v].son[i]);
	}
	return t[v].ct=cntt+len;
}
ll cal(int len){//[1,len]
	memset(sum,0,sizeof(sum));
	for(int i=1;i<=len;i++){
		sum[i]=sum[i-1]+temp[i];
	}
	ll res=0;
	for(int i=2;i<=len;i++){
		res+=temp[i]*sum[i-1];
	}
	return res;
}
ll n;int f,to;

int main(){
	cin>>n;
//	tt(1)
	for(int i=1;i<n;++i){
		scanf("%d%d",&f,&to);
		(t[f].son).push_back(to);
//		t[to].ft=f;
	}
//	tt(2)
	count(1);
	
	int _,q;
	cin>>_;
	while(_--){
		scanf("%d",&q);
		int len=t[q].son.size();
		for(int i=1;i<=len;i++){
			temp[i]=t[t[q].son[i-1]].ct+1;
		}
		temp[len+1]=n-1-t[q].ct;
		printf("%lld\n",n-1+cal(len+1));
	}
	return 0;
}
