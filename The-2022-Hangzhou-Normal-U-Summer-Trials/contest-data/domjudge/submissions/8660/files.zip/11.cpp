#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
const int INF=0x3f3f3f3f;
const int N=1e5+7;
const double pi=acos(-1);
ll n;
ll a[N];
ll s[N];
ll q,t;
ll x[N];
ll ans;
int main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>a[i];
		if(i!=0) s[i-1]=a[i]-a[i-1]; 
	}
	x[0]=s[0];
	for(int i=1;i<n-1;++i){
		x[i]+=(x[i-1]+s[i]); 
	}
	cin>>q;
	while(q--){
		cin>>t;
		ans=0;
		ll l=0,r=n,mid;
		while(l<r){
			mid=(l+r)/2;
			if(s[mid]>=t) r=mid-1;
			else{
				l=mid+1;
				ans=max(mid,ans);
			}
		}
		if(n>ans+1) cout<<(n-ans-1)*t+x[ans]<<endl;
		else cout<<t+x[ans-1]<<endl; 
	} 
	return 0;
} 
