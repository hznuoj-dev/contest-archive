#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[100050];
map<int,int>mp;
void solve(){
	ll i,j,m,n,x,y,k,l,r,t,ans=0,q,mid;
	char c;
	cin>>n>>k;
	y=0;
	mp[0]=1;
	for(i=1;i<=n;i++){
		scanf("%lld",&x);
		y=(y+x)%k;
		ans+=mp[y];
		mp[y]++;
	}
	printf("%lld",ans);
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
