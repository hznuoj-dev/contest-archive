#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n;cin>>n;
	vector<vector<int>> G(n+1);
	for(int i=1;i<n;i++){
		int x,y;cin>>x>>y;
		G[x].emplace_back(y);
		G[y].emplace_back(x);
	}
	
	vector<int> siz(n+1);
	vector<long long> ans(n+1);
	function<void(int ,int )> DFS=[&](int x,int fa){
		siz[x]=1;
		for(auto to:G[x]){
			if(to==fa) continue;
			DFS(to,x);siz[x]+=siz[to];
		}
		long long mul=0;
		for(auto to:G[x]){
			if(to==fa) continue;
			mul+=1ll*siz[to]*siz[to];
		}
		mul+=1ll*(n-siz[x])*(n-siz[x]);
		ans[x]=(n-1)+(1ll*(n-1)*(n-1)-mul)/2;
	};
	DFS(1,0);
	int q;cin>>q;
	while(q--){
		int x;cin>>x;
		cout<<ans[x]<<"\n";
	}
	return 0;
}