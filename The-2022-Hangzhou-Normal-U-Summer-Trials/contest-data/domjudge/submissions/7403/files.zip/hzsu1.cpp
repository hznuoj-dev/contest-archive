#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define int long long
#define ll long long
using namespace std;
signed main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int n,temp;

	cin>>n>>temp;	vector<int> a(n);
	rep(i,0,n-1){
		cin>>a[i];

	}
	int number=0;
	rep(i,0,n-1){
		int sum=0;
		rep(j,i,n-1){
			sum+=a[j];
				if(sum%temp==0){
				number++;
			}
		}
		
	}
	cout<<number<<endl;
	return 0;
} 
