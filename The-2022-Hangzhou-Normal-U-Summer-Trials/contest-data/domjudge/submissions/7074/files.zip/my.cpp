#include <bits/stdc++.h>
#define vi vector<int>
#define vc vector
#define vll vector<long long>
#define pii pair<int,int>
#define AXY(a,x,y) int x=(a).first,y=(a).second;
#define MID(l,r) int mid=((l)+(r))/2
#define ALL(arr) arr.begin(),arr.end()
using namespace std;
typedef long long ll;




#define int ll
signed main(){
	
	int n;
	cin>>n;
	vi arr(n);
	for(int &i:arr) cin>>i;
	vi nums(n-1);
	for(int i=0;i<n-1;i++) nums[i]=arr[i+1]-arr[i];
	nums.push_back((int)1e18);
	int q=1;
	cin>>q;
	while(q--){
		int num;
		cin>>num;
		auto pos=lower_bound(ALL(nums),num)-nums.begin();
		int res=0;
		res+=arr[pos]+num-arr[0];
		res+=(n-pos-1)*num;
		cout<<res<<endl;
	}
	return 0;
}
