#include<iostream>
#include<string>
#include<cstdio>
#include<map>
#include<cstring>
#include<algorithm>
typedef long long ll;
using namespace std;
string s[1007];
ll a[100010];
ll sum[100010];

int main(){
	
	ll ans = 0;
ll n,k;
cin >> n >> k;
for(int i = 0;i<n;i++)
{
	cin >> a[i];
}


sum[0] =a[0];

for(int i = 1;i<n;i++)
{
	sum[i] = sum[i-1]+a[i];
	//cout <<"&&&&&&" <<sum[i] <<"***" <<endl;
}

for(int i = 0;i<n;i++)
{
	if(sum[i]==0){
		ans++;
	}
	if(sum[i]!=0)
	{
		break;
	}
}

for(int i = 0;i<n;i++){
for(int j = 2;j<n;j++){
	if(sum[i+j]-sum[i]%k==0||sum[i+j]-sum[i]==0)
	ans++;
}
}
cout  << ans;

} 
