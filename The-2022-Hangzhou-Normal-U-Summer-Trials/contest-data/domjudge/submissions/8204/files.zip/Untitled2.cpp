#include<iostream>
#include<string>
#include<cstdio>
#include<map>
#include<cstring>
#include<cmath>
#include<algorithm>
typedef long long ll;
using namespace std;
string s[1007];
string s1[1007];
	map<char,int >mp;
	int c[22000002];
	
    map<int ,char>mp1;
int main(){

	char str[26];
	cin>>str;
//	getchar();
	
	for(int i = 0;i<26;i++){
	mp[str[i]]=i+1;
	mp1[i+1] = str[i];
}


int n;
cin >> n;
for(int i = 0;i<n;i++){
cin >> s[i];
s1[i] = s[i];
for(int j = 0;j<s[i].length();j++)
{
	s[i][j] = mp[s[i][j]]+'0';
}
//cout << s[i] << "!!!" <<endl;
}
int t;
cin >> t;

sort(s,s+n);
//cout << s[t-1].length();
//cout << mp1[1];
//cout << mp1[2];
//cout << "!!!" << s[t-1][1] <<mp1[s[t-1][1]-'0'];
for(int i = 0;i<s[t-1].length();i++)
cout << mp1[s[t-1][i]-'0'];


} 
