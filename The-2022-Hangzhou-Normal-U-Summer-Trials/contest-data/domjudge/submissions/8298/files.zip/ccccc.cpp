#include<bits/stdc++.h>

using namespace std;
string ss[1010],sss[1010];
void solve(){
	string s;
	cin >> s;
	map<char,int>mp;
	for(int i=0;i<26;i++){
		mp[s[i]]=i+1;
	}
	int n,k;
	cin >> n;
	for(int i=1;i<=n;i++) cin>>ss[i];
	for(int i=1;i<n;i++){
		int index=i;
		for(int j=i+1;j<=n;j++){
			for(int x=0;x<ss[index].size();x++){
				if(mp[ss[index][x]]==mp[ss[j][x]]) continue;
				else if(mp[ss[index][x]]>mp[ss[j][x]]){
					index=j;
					break;
				}else{
					break;
				}
			}
		}
		swap(ss[index],ss[i]);
	}
	cin >> k ;
	cout << ss[k];
}
/*
acbdefghijklmnopqrstuvwxyz
3
acsss
acs
abc
1
*/
int main(){
	int t=1;
	//cin >> t;
	while(t--){
		solve();
	}
return 0;
}
