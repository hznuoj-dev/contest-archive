#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 1e5+10;

vector<int>e[N];
int cnt[N];
int dfs(int x,int fa){
	int ans=1;
	for(auto c:e[x]){
		if(c==fa)continue;
		 ans+=dfs(c,x);
	}
	cnt[x]=ans;
	return ans;
}
void solve(){
	int n; scanf("%d",&n);
	for(int i=1;i<n;i++){
		int u,v; scanf("%d%d",&u,&v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs(1,0);
	int q; scanf("%d",&q);
	while(q--){
		int x; scanf("%d",&x);
		if(e[x].size()==1){
			printf("%d\n",n-1);
		}else {
			vector<ll>v;
			ll ans = 0;
			for(auto c:e[x]){
				if(cnt[c]>cnt[x]){
					v.push_back(cnt[1]-cnt[x]);
				}else {
					v.push_back(cnt[c]);
				}
			}
			for(int i=0;i<(int)v.size();i++){
				ans+=v[i];
				for(int j=i+1;j<(int)v.size();j++){
					ans+=1ll*v[i]*v[j];
				}
			}
			printf("%lld\n",ans);		

		}
	}
}
/*


*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
