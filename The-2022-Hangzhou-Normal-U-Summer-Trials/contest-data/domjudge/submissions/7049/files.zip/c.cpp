#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 5e5 + 5;

int a[maxn], b[maxn];

void solve(){
	int n; cin >> n;
	for(int i = 1; i <= n; ++i) cin >> a[i];
	for(int i = 1; i < n; ++i){
		a[i] = a[i + 1] - a[i];
		b[i] = b[i - 1] + a[i];
	} 
	n--;
	sort(a + 1, a + 1 + n);
	int k; cin >> k;
	while(k--){
		int e; cin >> e;
		int l = 1, r = n, ans = -1;
		while(l <= r){
			int m = l + r >> 1;
			if(a[m] <= e){
				ans = m;
				l = m + 1;
			}
			else r = m - 1;
		}
		if(ans == -1) cout << (n + 1) * e;
		else cout << b[ans] + (n - ans + 1) * e;
		cout << endl;
	}

} 

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
