#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=5e5+10;
int ch[N];
signed main(void){
	int n,q,x;
	scanf("%d",&n);
	for(int i=1;i<=n;++i) scanf("%d",&ch[i]);
	scanf("%d",&q);
	while(q--){
		cin>>x;
		int ans=0;
		for(int i=n;i>=1;i--){
			if(x>ch[i]) {
			ans=ans+x-1+ch[i];
			break;
			}
			else ans=ans+x;
		}
		printf("%lld\n",ans);
	}
	return 0;
}
