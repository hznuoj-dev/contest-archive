#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=500001;
vector<ll>a,v;
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		ll b;
		cin>>b;
		a.push_back(b);
		if(i>0){
			v.push_back(a[i]-a[i-1]);
		}
	}
//	for(int i=0;i<v.size();i++)
//	cout<<v[i]<<" ";
	int q;
	cin>>q;
	while(q--){
		int t;
		cin>>t;
		ll x=0;
		for(int i=0;i<v.size();i++){
			if(v[i]<=t)
			x+=v[i];
			else
			x+=t;
		}
		x+=t;
		cout<<x<<endl;
	}
}
