#include<bits/stdc++.h>
#define ll long long 
using namespace std;
ll a[500100];
ll b[50000];
int main(){
	ios::sync_with_stdio(false);cin.tie();cout.tie();
	ll n;cin>>n;
	for(int i=0;i<n;i++) cin>>a[i];
	ll t;cin>>t;
	while(t--){
		ll sum=0;
		ll nn;cin>>nn;
		bool f=0;
		for(int i=0;i<n-1;i++){
			if(f) {
				sum+=nn*(n-1);break;
			}
			if(a[i]+nn<=a[i+1]) {
				sum+=nn;f=1;
			}
			else {
				if(b[i+1]) sum+=b[i+1];
				else {
					b[i+1]=a[i+1]-a[i];
					sum+=a[i+1]-a[i];
				}
			}
		}
		sum+=nn;
		cout<<sum<<"\n";
	}
}
