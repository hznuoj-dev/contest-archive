#include <iostream>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <queue>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <limits.h>
#include <stack>
#include <fstream>
#include <list>
#include <sstream>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0)
//#define pb push_back

using namespace std;
 
typedef long long ll;
typedef unsigned long long ull;

typedef pair<ll, int> PII;
const double eps = 2e-9;
const int INF = 1e9 + 10, mod = 998244353;
const double pi = acos(-1.0);
const int N = 5e5 + 10, M = 2e5 + 10, S = 70;
ll suma[N];
vector<ll> ys, ys2;
int main()
{
	IOS;
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		int x;
		cin >> x;
		ys.push_back(x);
	}
	
	ys.erase(unique(ys.begin(), ys.end()), ys.end());
	/*
	for (int i = 0; i < ys.size(); i++)
		cout << ys[i] << " ";
	cout << endl;
	*/
	for (int i = 1; i < ys.size(); i++)
	{
		ys2.push_back(ys[i] - ys[i - 1]);
	}
	/*
	for (int i = 0; i < ys2.size(); i++)
		cout << ys2[i] << " ";
	cout << endl;
	*/
	for (int i = 1; i <= ys2.size(); i++)
	{
		suma[i] = suma[i - 1] + ys2[i - 1];
	}
	int q;
	cin >> q;
	while (q--)
	{
		ll t;
		cin >> t;
		if (t == 0) cout << 0 << endl;
		else if (t == 1) cout << ys.size() << endl;
		else
		{
			t -= 1;
			int pos = upper_bound(ys2.begin(), ys2.end(), t) - ys2.begin() + 1;
			//cout << "pos: " << pos << endl;

			ll ans = suma[pos - 1] + t * (ys2.size() + 2 - pos) + ys.size() - pos + 1;
			cout << ans << endl;

		}
	}


	return 0;
}