#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
using namespace std;
using LL=long long;
const int N=5e5+10;
#define int LL
int n,m,k;
int a[N],b[N];
signed main(){
	ios::sync_with_stdio(0);
	cin>>n;
	rep(i,1,n)cin>>a[i];
	rep(i,2,n)b[i]=a[i]-a[i-1]+1;
	int q;cin>>q;
	while(q--){
		int x;cin>>x;
		int p=upper_bound(b+2,b+1+n,x)-b-1;
		int d=(a[1]+x)-a[p];
		int ans=2*x-d+(n-p)*x;
		cout<<ans<<'\n';
	}
}
