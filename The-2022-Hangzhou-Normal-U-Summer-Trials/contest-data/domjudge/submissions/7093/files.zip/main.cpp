#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

int n;
vector<int> vp[maxn];
ll siz[maxn], f[maxn];

void dfs(int p, int fa = 0){
    siz[p] = 1;
    for(int v: vp[p]){
        if(v != fa){
            dfs(v, p);
            f[p] += siz[v] * siz[p];
            siz[p] += siz[v];
        }
    }
}

void solve(){
    cin >> n;
    for(int i=1;i<n;i++){
        int x, y;
        cin >> x >> y;
        vp[x].push_back(y);
        vp[y].push_back(x);
    }
    dfs(1);
    int q; cin >> q;
    while(q--){
        int x;
        cin >> x;
        cout << (1ll * siz[x] * (n - siz[x]) + f[x]) << '\n';
    }
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}