#include <bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;

#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
//#define int  long long
#define ll long long

vector<int>G[maxn];
int sz[maxn];
int fa[maxn];
void dfs(int root){
	if(G[root].size()==1&&root!=1){
		sz[root]=1;
		return;
	}
	for(auto i:G[root]){
		if(i==fa[root])continue;
		fa[i]=root;
		dfs(i);
		sz[root]+=sz[i];
	}
}
signed main(){
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		sz[i]=1;
	}
	for(int i=1;i<=n-1;i++){
		int u,v;cin>>u>>v;
		G[u].push_back(v);
		G[v].push_back(u);
	}
	dfs(1);
	//for(int i=1;i<=n;i++){
	//	cout<<sz[i]<<endl;
	//}
	int q;cin>>q;
	while(q--){
		int x;cin>>x;
		vector<int>vec;
		for(auto i:G[x]){
			if(sz[i]<sz[x])vec.push_back(sz[i]);
			else vec.push_back(n-sz[x]);
		}
		ll sum=0;
		for(auto i:vec){
			//cout<<"cnm "<<i<<endl;
			sum+=i;
		}
		ll ans=0;
		for(auto i:vec){
			ans+=(sum-i)*i;
		}
		ans=ans/(2ll);
		ans+=sum;
		cout<<ans<<endl;
		
	}


	system("pause");
}