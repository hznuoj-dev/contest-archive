#include<iostream>
#include<cstring>
using namespace std;
int main()
{
	string a;
	cin>>a;int i=0;int count=0;
	while(a[i]!=0){
		if(a[i]=='h'){
			if(a[i+1]=='z'){
				if(a[i+2]=='n'){
					if(a[i+3]=='u'){
						count++;i+=3;
					}
				}
			}
		}
		i++;
	}
	cout<<count<<endl;
	return 0;
}
