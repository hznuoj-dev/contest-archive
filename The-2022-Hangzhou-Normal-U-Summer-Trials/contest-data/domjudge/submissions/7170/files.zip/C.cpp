#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[500100],cha[500100];
int main()
{
	int i,j,n,m;
	ll k,l,t,ma;
	double ans;
	cin>>n;
	for (i=1;i<=n;i++)
		cin>>a[i];
	ma=0;
	for (i=1;i<=n-1;i++)
	{
		cha[i]=a[i+1]-a[i];
		ma=max(cha[i],ma);
	}
	sort(cha+1,cha+n);
	cin>>m;
	while (m--)
	{
		ans=0;
		cin>>t;
		if (t>ma) {ans=a[n]+t-1; printf("%.0f\n",ans); continue;} 
		for (i=1;i<=n-1;i++)
		{
			if (cha[i]<t) ans+=cha[i]-t; else break;
		}
		ans+=t*n;
		printf("%.0f\n",ans);
	}
}
