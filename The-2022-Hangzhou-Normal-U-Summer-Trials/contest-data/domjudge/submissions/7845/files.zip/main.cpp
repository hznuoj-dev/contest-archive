#include<bits/stdc++.h>
using namespace std;
using i64 = long long;
using i128 = __int128;
#define inf 0x7f7f7f7f7f7f7f7f
#ifdef ACM_LOCAL
const int N = 1e1 + 10;
#else
const int N = 5e5 + 10;
#endif
i64 a[N], range[N];
i128 sum[N];
inline void write(i128 x){
    if(x < 0){
        putchar('-'); x = -x;
    }
    if(x > 9){
        write(x/10);//上一位
    }
    putchar(x % 10 + '0');//取出来这一位然后putchar
}
int main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    int n; scanf("%d", &n);
    for(int i = 1;i <= n;i ++) scanf("%lld", a + i);
    for(int i = 1;i <= n;i ++) range[i] = a[i + 1] - a[i];
    range[n] = inf;

    i64 last = n;
    for(int i = 1;i < n;i ++){
        sum[i] = last * (range[i] - range[i - 1]), sum[i] += sum[i - 1];
        last --;
    }

    int q; scanf("%d", &q);
    while(q --){
        i64 t; scanf("%lld", &t);
        int p = lower_bound(range + 1, range + n + 1, t) - range;
        i64 more1 = t - range[p - 1];
        i64 more2 = n - p + 1;
        i128 ans = more1 * more2 + sum[p - 1];
        write(ans), putchar('\n');
    }

    return 0;
}