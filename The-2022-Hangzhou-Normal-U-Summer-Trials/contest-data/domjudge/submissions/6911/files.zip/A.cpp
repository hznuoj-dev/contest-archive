#include<bits/stdc++.h>
using namespace std;
int n,ans,tmp;
string s;
int main(){
	cin>>s;
	n=s.size();
	tmp=ans=0;
	while(tmp<n){
		if(s[tmp]=='h'){
			tmp++;
			
			if(s[tmp]=='z'){
				tmp++;
				
				if(s[tmp]=='n'){
					tmp++;
					
					if(s[tmp]=='u'){
						ans++;
						
					}
				}
			}
		}
		else{
			tmp++;
		}
	}
	cout<<ans;
	return 0;
}
