#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int  maxn = 2e5 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 21;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}

void solve(){
    string s;
    cin >> s;
    map<char, int> mp;
    for(int i = 0; i < s.size(); ++i) {
        mp[s[i]] = i;
    }
    int n;
    cin >> n;
    vector<pair<string,string>> x(n);
    for(int i = 0; i < n; ++i) {
        auto &[a,b] = x[i];
        cin >> b;
        for(int j = 0; j < b.size(); ++j) {
            a += mp[b[j]] + 'a';
        }
    }
    sort(x.begin(), x.end());
    int k;
    cin >> k;
    cout << x[k - 1].second << '\n';

}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}