#include<bits/stdc++.h>
#define ll long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const int N = 1e5 + 5;
const double eps = 1e-5;
const int mod = 1e9 + 7;

ll n, ans[N];
vector<ll> g[N];
vector<ll> son[N];
 
ll dfs(ll x, ll fa)
{
	ll sum = 1;
	for(ll i = 0; i < g[x].size(); i++)
	{
		if(fa != g[x][i])
		{
			ll y = dfs(g[x][i], x);
			son[x].push_back(y);
			sum += y;
		}
	}
	son[x].push_back(n - sum);
	return sum;
} 

void solve()
{
	cin >> n;
	for(ll i = 1; i < n; i++)
	{
		ll u, v;
		cin >> u >> v;
		g[u].push_back(v);
		g[v].push_back(u);
	}	
	
	dfs(1, -1);
	for(ll i = 1; i <= n; i++)
	{
		ans[i] = n - 1;
		if(son[i].size() == 1)
			continue;
		ll x = son[i][0];
		for(ll j = 1; j < son[i].size(); j++)
		{	
			ans[i] += son[i][j] * x;
			x += son[i][j];
		}
	}
	
	ll q;
	cin >> q;
	while(q--)
	{
		ll x;
		cin >> x;
		cout << ans[x] <<'\n';
	}
}

int main()
{
	IOS;
	ll t = 1;
	//cin >> t;
	while (t--)
		solve();
}
