#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 1e6 + 7;

int a[N];

ll dp[N][10];
void solve() {
	int n,p,s;
	cin >> n >> p >> s;
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
	}
	int z;
	cin >> z;
	ll ans = 0;
	for (int i = 1; i <= n; ++i) {
		dp[i][z] = 0;
		for (int j = 1; j <= z; ++j) {
			int x = lower_bound(a+1,a+n+1,a[i] - j * s) - a;
			for (int k = j; k <= z; ++k) {
				dp[i][k - j] = max(dp[x][k] + a[i] - a[x],dp[i][k - 1]);
			}
		}
		for (int j = 0; j <= z; ++j) {
			ans = max(ans,dp[i][j]);
		}
	}
	cout << p - ans;
}
int main() {
	ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
/*
6 3
0 1 2 4 7 7
*/
