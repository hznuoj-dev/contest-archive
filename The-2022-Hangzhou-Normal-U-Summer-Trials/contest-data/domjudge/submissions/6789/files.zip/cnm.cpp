#include<bits/stdc++.h>
using namespace std;
#define int long long
signed main(){
	string s;cin>>s;
	int ans=0;
	for(int i=0;i<s.size();i++){
		if(s[i]=='h'){
			int j, k, p;
			j=i+1;
			k=i+2;
			p=i+3;
			if(j>=s.size()||k>=s.size()||p>=s.size()){
				continue;
			}
			if(s[j]=='z'&&s[k]=='n'&&s[p]=='u'){
				ans++;
			}
			else{
				continue;
			}
		}
	}
	cout<<ans<<endl;
} 
