#include<iostream>
#include<string>
#include<cstdio>
#include<map>
#include<cstring>
#include<algorithm>
typedef long long ll;
using namespace std;
ll p;
ll a[2000020];
int main(){
cin >> p;
for(int i = 0;i<p;i++){
	cin >> a[i];
}
ll n;
cin >>n;

for(int i = 0;i<n;i++){
	
	ll ans = 0;
	ll t;
	cin >> t;
	ll temp = 0;
	
	if(p==1){
		cout << t <<endl;
	}
	else
	
	{
	
	while(a[temp]+t>a[temp+1]){
		temp++;
		if(temp==n-1)
		break;
	}
	//cout <<"t="<<t<<"temp=" <<temp <<endl;
	for(int j = 0;j<temp;j++)
	ans += a[j+1]-a[j];		
	
	ans+=t*(n-temp);
	cout << ans <<endl;
}


}

} 
