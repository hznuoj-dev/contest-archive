#include<bits/stdc++.h>
using namespace std;
#define yes (cout<<"YES\n")
#define no (cout<<"NO\n")
#define endl '\n'
//typedef long long ll;
#define int long long
void sxseven();
signed main() {
	ios::sync_with_stdio(false);
	int _=1;
	//cin >> _;
	while(_--) sxseven();
	return 0;
}
const int N=1e5+5;
struct node{
	int x1,y1,x2,y2,cnt;
};
int mp[300][300],n;
string s[55];
int xx[4]={0,0,1,-1};
int yy[4]={1,-1,0,0};
void sxseven() {
	cin >> n;
	int x1,y1,x2,y2;
	for(int i=0;i<n;++i){
		cin >> s[i];
		for(int j=0;j<n;++j){
			if(s[i][j]=='a'){
				x1=i;y1=j;
			}else if(s[i][j]=='b'){
				x2=i;y2=j;
			}
		}
	}
	mp[x1*n+y1][x2*n+y2]=1;
	int xx1,xx2,yy1,yy2;
	queue<node> q;
	node p;
	q.push({x1,y1,x2,y2,0});
	while(!q.empty()){
		p=q.front();
		q.pop();
		xx1=p.x1;
		xx2=p.x2;
		yy1=p.y1;
		yy2=p.y2;
		for(int i=0;i<4;++i){
			x1=p.x1+xx[i];
			x2=p.x2+xx[i];
			y1=p.y1+yy[i];
			y2=p.y2+yy[i];
			if(x1<0)x1=0;
			else if(x1==n)x1=n-1;
			if(y1<0)y1=0;
			else if(y1==n)y1=n-1;
			if(s[x1][y1]=='*')x1=xx1,y1=yy1;
			if(x2<0)x2=0;
			else if(x2==n)x2=n-1;
			if(y2<0)y2=0;
			else if(y2==n)y2=n-1;
			if(s[x2][y2]=='*')x2=xx2,y2=yy2;
			if(x1==x2&&y1==y2){
				cout<<p.cnt+1;return;
			}
			if(mp[x1*n+y1][x2*n+y2])continue;
			mp[x1*n+y1][x2*n+y2]=1;
			q.push({x1,y1,x2,y2,p.cnt+1});
		}
	}
	cout<<"no solution";
}

