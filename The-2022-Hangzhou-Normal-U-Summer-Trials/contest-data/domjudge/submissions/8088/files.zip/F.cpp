#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+50;
const int maxn=1e9+10;
ll sum[N];
ll a[N];
ll b[N];
ll f(ll x){
	ll ans=1;
	for(ll i=1;i<=x;i++){
		ans*=i;
	}
	return ans;
}
int main(){
	ios::sync_with_stdio(false);
	ll n,k;
	cin>>n>>k;
	ll c=0;
	ll ans=0;
	for(ll i=1;i<=n;i++){
		cin>>a[i];
		sum[i]=(sum[i-1]%k+a[i]%k)%k;
		if(sum[i]==0)
			c++;
	}
	ans+=f(c)/f(c-2)/2;
	ans+=c-2;
	for(ll i=1;i<n;i++){
		if(sum[i]==0&&sum[i+1]==0)
			c--;
	}
	ans+=f(c)/f(c-2)/2;
	cout<<ans<<endl;
	return 0;
}

