#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
#define wtnnb ios::sync_with_stdio(false);//cin.tie(0);cout.tie(0);
const int N = 1e6+10;
const ll mo = 1e9+7;
int a[N];
ll b[N];
ll getans(ll s,ll n){
	if(s==0)return 1;
	else if(s<0)return 0;
	
	ll ans=b[s];
	return ans;
}
signed main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int n,s,q;cin>>n>>s>>q;
    b[0]=1;
    for(int i=1;i<N;i++){
    	b[i]=b[i-1]+n*i;
    	b[i]%=mo;
	}
    ll sum=0;
    for(int i=1;i<=n;i++){
    	cin>>a[i];
    	sum+=a[i];
	}

    while(q--){
    	int x,v;cin>>x>>v;	
    	sum+=v-a[x];
    	a[x]=v;
    	cout<<getans(s-sum,n)<<endl;
	}
}

