//#pragma GCC optimize(3)
#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <string>
#include <set>
#include<limits.h>
#include<unordered_map>
#include<unordered_set>
//#include<bits/stdc++.h>

#define int long long
#define IOS std::ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<long long,int> pli;
typedef pair<int,int> pii;
typedef pair<long long,long long> pll;
const int INF = 0x3f3f3f3f;
const double EPS = 1e-6;
const int MOD = 1e9 + 7;
const int MAXN = 3e5+10;
const int N = 1e6+33;

char mp[55][55];
int vis[55][55];
int val[55][55];
map<pll,int>m;
pll a;
pll b;
int n;
int px[4]={0,-1,1,0};
int py[4]={1,0,0,-1};
ll ans=INF;
void bfs(pll a){
    queue<pll>q;
    q.push(a);
    ll v=0;
    while(!q.empty()){
        pll tm=q.front();
        q.pop();
        v++;
        for(int i=0;i<4;i++){
            pll tmp={tm.first+px[i],tm.second+py[i]};
            m[tmp]=min(m[tmp],m[tm]+1);
            if(tmp.first>0&&tmp.second>0&&tmp.first<=n&&tmp.second<=n){
                if(tmp==b){ans=m[tmp];break;}
                if(mp[tmp.first][tmp.second]!='*'&&vis[tmp.first][tmp.second]==0){
                    vis[tmp.first][tmp.second]=1;
                    q.push(tmp);
                }
            }
        }
        
    }
}
void solve(){
    memset(val,0x3f,sizeof val);
    cin>>n;
    for(int i=0;i<=n+1;i++){
        for(int j=0;j<=n+1;j++){
            mp[i][j]='*';
        }
    }
    for(int i=1;i<=n;i++){
        cin>>mp[i]+1;
    }

    for(int i=1;i<=n;i++){
        for(int j=1;j<=n;j++){
             m[{i,j}]=INF;
            if(mp[i][j]=='a'){
                a={i,j};
                m[a]=0;
            }else if(mp[i][j]=='b'){
                b={i,j};
            }
           
        }
    }
    bfs(a);
    if(ans<=10000){
        if(ans%2==0){
            cout<<ans*2<<endl;
        }
        else {
            cout<<(ans+1)*2<<endl;
        }
    }
    else cout<<"no solution"<<endl;
}

void init(){

}






signed main()
{
#ifdef LOCAL
freopen("in.in","r", stdin);
freopen("out.out","w", stdout);
#endif
IOS;

    int cases=1;
    init();
    for(int cas=1;cas<=cases;cas++)
    {
        solve();
    }
}