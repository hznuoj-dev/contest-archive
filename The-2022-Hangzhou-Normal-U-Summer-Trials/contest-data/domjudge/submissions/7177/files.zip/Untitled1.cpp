#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll N = 1e3 + 7;
ll com[30], n, k;
string s1[N];

bool cmp(string s1, string s2){
	ll len = min(s1.size(), s2.size());
	for (int i = 0; i < len; i++){
		if (com[s1[i] - 'a'] < com[s2[i] - 'a'])return true;
		if (com[s1[i] - 'a'] > com[s2[i] - 'a'])return false;
	}
	if (s1.size() < s2.size())return true;
	else return false;
}

int main(){
	string s;
	cin >>s;
	for (int i = 0; i < 26; i++){
		com[s[i] - 'a'] = i;
	}
	cin >> n;
	for (int i = 1; i <= n; i++)cin >> s1[i];
	sort(s1 + 1, s1 + 1 + n, cmp);
	cin >> k;
	cout << s1[k];
} 
