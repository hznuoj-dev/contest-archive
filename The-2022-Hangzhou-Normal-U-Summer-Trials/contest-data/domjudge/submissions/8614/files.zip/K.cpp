#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);
	int n;cin>>n;
	vector<int> v(5);
	for(int i=1;i<=4;i++) cin>>v[i];cin>>v[0];
	int S,T;cin>>S>>T;
	vector<pair<int,int>> p(n+1);
	for(int i=1;i<=n;i++){
		int x,y;cin>>x>>y;
		p[i]={x,y};
	}
	vector<double> dst(n+1,1e18);
	vector<bool> vis(n+1);
	dst[S]=0;
	for(int t=1;t<n;t++){
		double mn=1e18,k=0;
		for(int i=1;i<=n;i++){
			if(dst[i]<mn&&!vis[i]) mn=dst[i],k=i;
		}
		vis[k]=1;
		if(k==T) break;
		for(int i=1;i<=n;i++){
			auto Cal=[&](int l,int r){
				auto point=[](int x,int y){
					if(x>0&&y>0) return 1;
					if(x<0&&y>0) return 2;
					if(x<0&&y<0) return 3;
					if(x>0&&y<0) return 4;
					return 0;
				};
				auto _sqr=[&](int x)->double{return 1.*x*x;};
				auto Get_dst=[&](int l,int r)->double{
					return sqrt(_sqr(p[l].first-p[r].first)+_sqr(p[l].second-p[r].second));
				};
				return Get_dst(l,r)/v[point(p[l].first,p[l].second)==point(p[r].first,p[r].second)?point(p[l].first,p[l].second):0];
			};
			if(!vis[i]) dst[i]=min(dst[i],dst[k]+Cal(k,i));
		}
	}
	printf("%.10lf\n",dst[T]);
	return 0;
}