#include<iostream>
#define ll long long
#define endl '\n'
using namespace std;
const int INF=0x3f3f3f3f;
const int N=5e5+7;
ll n;
ll a[N];
ll s[N];
ll q,t;
ll x[N];
ll ans;
int main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i];
		if(i!=1) s[i-1]=a[i]-a[i-1];//�����ֵ 
	}
	x[1]=s[1];
	for(int i=2;i<=n-1;++i){//��ֵ��ǰ׺�� 
		x[i]+=(x[i-1]+s[i]); 
	}
	cin>>q;
	while(q--){
		cin>>t;
		ans=0;
		ll l=1,r=n,mid;
		while(l<=r){//�����ҵ�����С��t�Ĳ�ֵ 
			mid=(l+r)/2;
			if(s[mid]>=t) r=mid-1;
			else{
				l=mid+1;
				ans=max(mid,ans);
			}
		}
		if(ans==0) cout<<t*n<<endl;
		else{
		if(n>ans) cout<<(n-ans)*t+x[ans]<<endl;
		else cout<<(t+x[ans-1])<<endl;
		}
	} 
	return 0;
} 
