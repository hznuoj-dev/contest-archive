#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 1e5+10;

struct node{
	string s;
	int v;
}a[1010];
bool cmp(node fi,node se){
	return fi.v<se.v;
}
void solve(){
	string s1; cin >> s1;
	map<char,int>mp;
	for(int i=0;i<26;i++){
		mp[s1[i]]=i;
	}
	int n; cin >> n;
	for(int i=1;i<=n;i++){
		cin >> a[i].s;
		for(int j=0;j<(int)a[i].s.size();j++){
			a[i].v=a[i].v*26+(mp[a[i].s[j]]);
		}
		
	}
	sort(a+1,a+n+1,cmp);
	int t; cin >> t;
	cout << a[t].s;
}
/*


*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
