#include<bits/stdc++.h>
#define ll long long
using namespace std;
const int N = 5e5+7;
ll a[N];
int main(){
    int n;
    cin>>n;
    int s[n+1];
    for(int i=1;i<=n;i++){
        cin>>a[i];
        if(i>=2)s[i-1] = a[i]-a[i-1];
    }
    int q;
    cin>>q;
    while(q--){
        ll t;
        cin>>t;
        ll sum=0;
        sum+=n*t;
        if(t<=s[1]) cout<<sum<<endl;
        else {
            ll sum1=0;
            for(int i=1;i<=n-1;i++){
                if(t-s[i]>0)sum1+=t-s[i];
                else break;
            }
            sum-=sum1;
            cout<<sum<<endl;
        }
    }
    return 0;
}