#include <bits/stdc++.h>
using namespace std;
const int N =5e5+10; 
const int mod= 998244353; 
using namespace std;
typedef long long ll;
#define INF 0x3f3f3f3f3f3f3f3f  
ll a[N];
ll sum[N];
ll conut(ll m,ll n){
	ll i,j,sum=1;
	for (i=m,j=0;j<n;j++,i--)
		sum=sum*i/(j+1);
	return sum;
}
int main(){
  ll n,k;
  cin>>n>>k;
  		ll cnt=0;
  sum[0]=0;
  for(int i=1;i<=n;i++)
  { cin>>a[i];
     sum[i]=(sum[i-1]+a[i])%k;
  }
  		sort(sum,sum+n+1);
  				ll s=1;
		for(ll i=1;i<=n;i++){
			if(sum[i]==sum[i-1])
			{ 	s++;
			}
			else{
				cnt+=conut(s,2);
			    s=1;
			}
		}
		cnt+=conut(s,2);
		cout<<cnt<<endl;
	return 0;
}
