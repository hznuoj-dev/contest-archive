#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
long long a[N],b[N],sum[N];
long long n,q,t;
int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	for(int i=1;i<n;i++)
		b[i]=a[i]-a[i-1];
	cin>>q;
	while(q--)
	{
		cin>>t;
		long long x=lower_bound(b,b+n-1,t)-b;
		if(t<b[1])
		cout<<t*(n-x-1)+a[x]-a[0]<<'\n';
		else if(t>=b[1]&&t<=b[n-1])
		{
			if(t==b[x])
				cout<<t*(n-x)+a[x]-a[0]<<'\n';
			else cout<<t*(n-x-1)+a[x]-a[0]<<'\n';
		}
		else if(x==n-1&&t>b[x])	cout<<t+a[n-1]-a[0]<<'\n';
		
	}
} 
