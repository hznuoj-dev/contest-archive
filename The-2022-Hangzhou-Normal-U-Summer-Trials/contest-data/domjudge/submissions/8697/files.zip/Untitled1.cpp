#include<bits/stdc++.h>
#define ll long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const int N = 1e6 + 5;
const double eps = 1e-5;
const int mod = 1e9 + 7;

ll n, p, s, b[N];
ll dp[N][10];

void solve()
{
	cin >> n >> p >> s;
	for(ll i = 1; i <= n; i++)
		cin >> b[i];
	ll k;
	cin >> k;
	for(ll i = 2; i <= n; i++)
	{
		for(ll j = 0; j <= k; j++)
			dp[i][j] = dp[i-1][j];
		for(ll j = i - 1; j >= max(1, i - 10); j--)
		{
			ll x = ceil((b[i] - b[j]) * 1.0 / s);
			if(x > k)
				break;
			for(ll l = x; l <= k; l++)
				dp[i][l] = max(dp[i][l], dp[j][l - x] + b[i] - b[j]);
		}
	}
	ll ans = p;
	for(ll i = 0; i <= k; i++)
		ans = min(ans, p - dp[n][i]);
	cout << ans;
}

int main()
{
	IOS;
	ll t = 1;
	//cin >> t;
	while (t--)
		solve();
}
