#include <bits/stdc++.h>
using namespace std;
const int N =5e5+10; 
const int mod= 998244353; 
using namespace std;
typedef long long ll;
#define INF 0x3f3f3f3f3f3f3f3f  
ll a[N];
ll b[N];
int main(){
  ll n;
   cin>>n;
  for(int i=1;i<=n;i++)
  { cin>>a[i];
  }
  sort(a+1,a+1+n);
  for(int j=1;j<n;j++)
  {   b[j]=a[j+1]-a[j]-1;
  }
   ll q;
   cin>>q;
   while(q--)
   { ll t;
     cin>>t;
     ll ans;
        ans=a[n]+t-1;
	       for(int i=1;i<n;i++)
	        {   if(t<=b[i]) 
	             { ans=ans-b[i]+t-1;
				 }
			}
     cout<<ans<<endl;
     
     
   }
	return 0;
}
