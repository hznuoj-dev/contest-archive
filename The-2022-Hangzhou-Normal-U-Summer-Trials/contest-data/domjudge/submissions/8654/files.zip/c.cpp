#include<bits/stdc++.h>
#define ll long long
using namespace std;

ll sum[500050], c[500050], a[500050];
ll n, x;
ll q, t;


int main()
{
    cin >> n;
    sum[0] = 0;
    for(ll i = 1;i <= n;i++)
    {
        cin >> a[i];
        if(i != 1)
        {
            c[i - 1] = a[i] - a[i - 1];
            sum[i - 1] = sum[i - 2] + c[i - 1];
        }
    }
    cin >> q;
    for(ll i = 0;i < q;i++)
    {
        cin >> t;
        ll pos = upper_bound(c + 1, c + n + 1, t) - (c + 1);
        if(t == 0)
            cout << 0 << endl;
        else if(pos >= n)
            cout << sum[n - 1] + t << endl;
        else
            cout << sum[pos] + (n - pos) * t << endl;
    }

    return 0;
}