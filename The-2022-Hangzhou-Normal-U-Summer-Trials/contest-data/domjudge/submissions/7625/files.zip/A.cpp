#include<bits/stdc++.h>
#define ll long long

using namespace std;
const int N = 5e5 + 10;
const ll M = 1e18 + 10;
ll a[N];
ll b[N];
ll c[N];
int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		scanf_s("%lld", &a[i]);
	}
	for (int i = 1; i < n; i++)
	{
		b[i] = a[i] - a[i - 1]-1;
	}
	b[n] = M;
	for (int i = 1; i <= n; i++)
	{
		c[i] = c[i - 1] + b[i];
	}
	int t;
	cin >> t;
	while (t--)
	{
		ll m;
		scanf_s("%lld", &m);
		ll sum = n;
		m--;
		int i = 1, j = n;
		while (i < j)
		{
			int mid = (i + j) / 2;
			if (b[mid]>m)j = mid;
			else i = mid + 1;
		}
		sum += c[i-1] + m * (n - i+1);
		cout << sum << endl;
	}
	return 0;
}
