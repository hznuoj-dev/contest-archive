#include<iostream>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>

#define ll long long
#define lowbit(x) ((x)&(-(x)))
#define pb push_back
#define vi vector<int>
#define pii pair<int, int>
#define allv(x) (x).begin(), (x).end() 
#define bit32(x) (__builtin_popcount((unsigned int)(x)))
#define bit64(x) (bit32(x>>32)+bit32(x))
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

using namespace std;
const int N = 1e5 + 10;
ll a[N];
int main(){
    ll n,x,k;
    scanf("%lld%lld",&n,&k);
    a[0]=0;
    ll res=0;
    for(int i=1;i<=n;i++)
    {
        scanf("%lld",&x);
        a[i]=a[i-1]+x;
        for(int j=1;j<=i;j++)
        {
            if((a[i]-a[j-1])%k==0)res++;
        }
    }
    printf("%lld",res);
    return 0;
}