#include<bits/stdc++.h>
using namespace std;
char via[26];
struct tb{
	string s,sa;
}sta[1100];
bool cmp(tb a,tb b){
	return a.sa<b.sa;
}
int main(){
//	string via;cin>>via;
	map<char,int> mp;
	char c;
	for(int i=0;i<26;i++){
		cin>>c;
		mp[c]=i;
	}
	int n;cin>>n;
	for(int i=0;i<n;i++){
		cin>>sta[i].s;
		sta[i].sa=sta[i].s;
		for(int j=0;j<(sta[i].s).length();j++){
			(sta[i].sa)[j]='a'+mp[(sta[i].s)[j]];
		}
	}
	sort(sta,sta+n,cmp);
	int k;cin>>k;
//	for(int i=0;i<n;i++) cout<<sta[i].sa<<"\n";
//	for(int i=0;i<n;i++) cout<<sta[i].s<<"\n";
	cout<<sta[k-1].s;
}
