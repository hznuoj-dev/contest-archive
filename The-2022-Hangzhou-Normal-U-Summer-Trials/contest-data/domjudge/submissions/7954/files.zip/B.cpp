#include<bits/stdc++.h>
using namespace std;

#define ll long long

const int N=1e3+5;
const int mod=1e9+7;

string ss[N],s;
int num[30];

struct node{
	string s;
	int i;
}tt[N];

void gtc(string x){
	for(int i=0;i<26;i++){
		num[x[i]-'a']=i;
	}
}

string sg(string x){
	string ret=x;
	for(int i=0;i<x.size();i++){
		ret[i]=num[x[i]-'a']+'a';
	}
	return ret;
}

string gs(string x){
	string ret=x;
	for(int i=0;i<x.size();i++){
		ret[i]=s[x[i]-'a'];
	}
	return ret;
}

void solve(){
	int n,k,len=0;
	cin>>s>>n;
	gtc(s);
	for(int i=0;i<n;i++){
		cin>>ss[i];
		ss[i]=sg(ss[i]);
	}
	sort(ss,ss+n);
	cin>>k;
	cout<<gs(ss[k-1])<<"\n";
}

int main(){
	ios::sync_with_stdio(false);
	int t=1;
	while(t--){
		solve();
	}
	return 0;
}

