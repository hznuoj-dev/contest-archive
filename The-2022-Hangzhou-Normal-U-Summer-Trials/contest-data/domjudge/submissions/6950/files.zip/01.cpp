#include<stdio.h>
#include<stdlib.h>
void quick_sort(int q[], int p[], int l, int r)
{
    if (l >= r) return;
    
    int x = q[(l + r) / 2], i = l - 1, j = r + 1;
    while (i < j)
    {
        do i++; while (q[i] < x);
        do j--; while (q[j] > x);
        if (i < j)
        {
            int t = q[i];
            int y = p[i];
            q[i] = q[j];
            p[i] = p[j];
            q[j] = t;
            p[j] = y;
        }
    }
    
    quick_sort(q, p, l, j);
    quick_sort(q, p, j + 1, r);
}
int main(int argc, char const *argv[])
{
    int n, q;
    scanf("%d %d", &n, &q);
    int i;
    int c;
    int a[10], b[10];
    for (i = 0; i < q; i++)
    {
        scanf("%d %d", &a[i], &b[i]);
        if (a[i] > b[i])
        {
            c = a[i];
            a[i] = b[i];
            b[i] = c;
        }
    }
    int v = 0;
    int num[10] = {0};
    if (q == 1)
    {
        printf("4");
    }
    else
    {
        quick_sort(a, b, 0, q - 1); 
        for (i = 0; i < q - 1; i++)
        {
            if (a[i] == a[i + 1])
            {
                num[b[i] - 1] = 1;
                v++;
            }
            else if (a[i] != a[i + 1])
            {
                num[b[i] - 1] = 1;
                if (num[a[i + 1] - 1] == 1)
                {
                    v++;
                    num[0] = 0;
                    num[1] = 0;
                    num[2] = 0;
                    num[3] = 0;
                    num[4] = 0;
                    num[5] = 0;
                    num[6] = 0;
                    num[7] = 0;
                    num[8] = 0;
                    num[9] = 0;
                }
                else if (num[a[i + 1] - 1] != 1)
                {
                    v += 2;
                    num[0] = 0;
                    num[1] = 0;
                    num[2] = 0;
                    num[3] = 0;
                    num[4] = 0;
                    num[5] = 0;
                    num[6] = 0;
                    num[7] = 0;
                    num[8] = 0;
                    num[9] = 0;
                }
            }
        }
    }
    printf("%d", v + 4);
    system("pause");
    return 0;
}