#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 1e5 + 10;

void solve(){
	int n, k;
	scanf("%d%d", &n, &k);
	vector<int> a(n);
	for(int i = 0; i < n; i++){
		scanf("%d", &a[i]);	
	}
	map<int, int> mp;
	mp[0]++;
	ll ans = 0;
	int sum = 0;
	for(int i = 0; i < n; i++){
		sum += a[i];
		sum %= k;
		ans += mp[sum];
		mp[sum]++;
	}
	printf("%lld\n", ans);
}

int main(){
	int T = 1;
	while(T--) solve();
	return 0;
}
