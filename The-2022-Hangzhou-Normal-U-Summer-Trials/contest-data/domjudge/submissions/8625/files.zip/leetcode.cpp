#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>
#include <list>

using namespace std;

struct node
{
	long long int value;
	long long int num;

	bool operator<(const node cs)
	{
		return num < cs.num;
	}
};

node newn(long long int value, long long int num)
{
	node n;
	n.value = value;
	n.num = num;
	return n;
}

vector<long long int> jg;
vector<long long int> cs;
vector<node> jg1;

long long int find1(long long int source)
{
	int m;
	int l = 0, r = jg1.size() - 1;
	while (l <= r)
	{
		m = (l + r) / 2;
		if (jg1[m].value < source)
		{
			l = m + 1;
		}
		else if (jg1[m].value >= source)
		{
			r = m - 1;
		}
	}
	return jg1[r].num;
}

int main()
{
	long long int cstmp;
	int n;
	int sum;
	long long int sum1;
	int j;
	cin >> n;
	for (int i = 0; i < n; ++i)
	{
		cin >> cstmp;
		if (i)
			jg.push_back(cstmp - cs.back());
		cs.push_back(cstmp);
	}
	sort(jg.begin(), jg.end());
	for (int i = 0; i < n - 1; ++i)
	{
		sum = 0;
		j = i;
		for (; i < n - 1; ++i)
		{
			if (jg[i] == jg[j])
			{
				sum += 1;
			}
			else
			{
				i -= 1;
				break;
			}
		}
		if (!jg1.empty())
			jg1.push_back(newn(jg[j], sum + jg1.back().num));
		else
			jg1.push_back(newn(jg[j], sum));
	}
	cin >> n;
	jg1.insert(jg1.begin(), newn(0, 0));
	for (int i = 0; i < n; ++i)
	{
		cin >> cstmp;
		sum1 = cstmp * (-find1(cstmp) + (jg.size() + 1));
		for (int i = 0; i < jg1.size(); ++i)
		{
			if (jg1[i].value < cstmp)
			{
				sum1 += jg1[i].value * (jg1[i].num - (i ? jg1[i - 1].num : 0));
			}
		}
		cout << sum1 << endl;
	}
}