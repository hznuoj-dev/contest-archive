#include<bits/stdc++.h>
using namespace std;

int main(){
    string str1 = "hznu";
    string str;
    cin >> str;
    int num = 0;
    for(int i = 0; i < str.length(); i++){
        if(str.substr(i, 4) == str1)num++;
    }
    cout << num << '\n';
}