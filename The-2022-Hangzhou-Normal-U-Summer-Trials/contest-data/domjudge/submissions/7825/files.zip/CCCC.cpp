#include<bits/stdc++.h>
using namespace std;
int main()
{
	int n;
	cin>>n;
	long long int a[n]={0};
	for(int k=0;k<n;k++)
	{
		cin>>a[k];
	}
	if(n==1)
	{
		int t;
		cin>>t;
		while(t--)
		{
			long long b=0;
			cin>>b;
			cout<<b<<"\n";
		}
		return 0;
	}
	long long int b[n-1]={0};
	for(int k=1;k<n;k++)
	{
		b[k-1]=a[k]-a[k-1];
	}
	int t,n1;
	cin>>t;
	long long p,ci=0;
	while(t--)
	{
		n1=n;
		ci=0;
		cin>>p;
		for(int k=0;k<n-1;k++)
		{
			if(b[k]<p)
			{
				ci=ci+b[k];
				n1--;
			}
			else break;
		}
		ci=ci+n1*p;
        cout<<ci<<"\n";
    }
	return 0;
}
