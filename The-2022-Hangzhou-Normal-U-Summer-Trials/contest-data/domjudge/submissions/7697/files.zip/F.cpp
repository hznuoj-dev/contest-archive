#include <stdio.h>
#include <string.h>

const int N = 1e5 + 10;

int main(void)
{
	int n, k, cou = 0;
	long a[N], sum;

	scanf("%d %d", &n, &k);
	for (int i = 0; i < n; i++)
	{
		scanf("%ld", &a[i]);
	}
	for (int i = 0; i < n; i++)
	{
		sum = 0;
		for (int j = i; j < n; j++)
		{
			sum += a[j];
			if (sum % (long)k == 0)
				cou++;
		}
	}
	printf("%d", cou);

	return 0;
}