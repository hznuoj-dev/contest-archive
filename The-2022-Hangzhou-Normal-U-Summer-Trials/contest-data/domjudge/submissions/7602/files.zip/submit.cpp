#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define int ll

const int N = 5000010;

int n, dp[N], siz[N];
vector<int> g[N];

void dfs (int u, int p) {
    int sum = 0;
    siz[u] = 1;
    for (int v: g[u]) {
        if (v == p) continue;
        dfs(v, u);
        siz[u] += siz[v];
        dp[u] += siz[v];
        dp[u] += siz[v] * sum;
        sum += siz[v];
//        if (u == 1) cout << "now sum " << sum << endl;
    }
    int lv = n - sum - 1;
//    if (u == 1) {
//        cout << lv << ' ' << sum << endl;
//    }
    dp[u] += lv;
    dp[u] += lv * sum;
}

signed main ()
{
    cin >> n;
    for (int i = 0; i < n - 1; i ++ ) {
        int u, v; cin >> u >> v;
        g[u].push_back(v);
        g[v].push_back(u);
    }
    dfs(1, -1);
//    for (int i = 1; i <= n; i ++ ) cout << dp[i] << endl;
    int q; cin >> q; while(q -- ) {
        int x; cin >> x;
        cout << dp[x] << endl;
    }
    return 0;
}