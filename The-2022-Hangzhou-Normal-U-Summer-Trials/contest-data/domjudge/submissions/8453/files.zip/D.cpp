#include<bits/stdc++.h>
using namespace std;
const int N = 1e5 + 7;

int x, u, v, q, pos;
vector<int>vec[N];
int cnt[N];
int vis[N];

// void dfs(int pos){
//      for(int i = 0; i < vec[pos].size(); i++){
//          if(vec[vec[pos][i]].size() != 1 && vec[vec[pos][i]].size() != 0 && vis[vec[pos][i]] == 0){
//              cnt[pos] += vec[vec[pos][i]].size();
//              vis[vec[pos][i]] = 1;
//              dfs(vec[pos][i]);
//              return; 
//          }
//          else cnt[pos]++;
//      }
// }

int  dfs(int pos, int q){
    int ans = 0;
    for(int i = 0; i < vec[pos].size(); i++){
        if(vec[pos][i] != q && vec[vec[pos][i]].size() != 1){
           ans += dfs(vec[pos][i], pos);
        }
        else if(vec[pos][i] != q && vec[vec[pos][i]].size() == 1){
           ans++;
        }
    }
    return ans + 1;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin >> x;
    for(int i = 0; i < x - 1; i++){
        cin >> u >> v;
        vec[u].push_back(v);
        vec[v].push_back(u);
    }
    cin >> q;
    for(int i = 0; i < q; i++){
        cin >> pos;
        int x1 = x;
        int sum = x - 1;
        for(int i = 0; i < vec[pos].size(); i++){
            int re = dfs(vec[pos][i], pos);
            sum += (re) * (x1 - re - 1);
            x1 = x1 - re;
            // cout << "dfs" << " " << re << ' ';
        }
        cout << sum << '\n';
    }
}
