#include<bits/stdc++.h>
using namespace std;

int main(){
	string s;
	
	int q;
	int op;
	char x,y;
	cin>>q;
	for(int i = 0; i < q; i++){
		cin>>op;
		if(op==1){
			cin>>x;
			s+=x;
		}else if(op==2){
			if(!s.empty()){
				s.erase(s.length()-1,1);
			}
		}else if(op==3){
			cin>>x>>y;
			for(int j = 0; j < s.length(); j++){
				if(s[j]==x)s[j]=y;
			}
		}
	}
	if(s.empty()){
		cout<<"The final string is empty";
	}else{
		cout<<s;
	}

	return 0;
}
