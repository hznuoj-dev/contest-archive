#include<iostream>
#include<algorithm>
using namespace std;
int main(){
	string s;
	cin>>s;
	int n[26];
	int ma=s.length();
	for(int i=0;i<ma;i++){
		n[i]=s[i]-'a';
	}
	int k;
	cin>>k;
	string n1[1002];
	for(int i=0;i<k;i++){
		cin>>n1[i];
	}
	int sum;
	cin>>sum;
	for(int i=0;i<k;i++){
		int x1=n1[i].length();
		for(int j=i+1;j<k;j++){
			int x2=n1[j].length();
			int x=max(x1,x2);
			for(int b=0;b<x;b++){
			if((n[n1[i][b]-'a']<n[n1[j][b]-'a'])){
				string s=n1[i];
				n1[i]=n1[j];
				n1[j]=s;
				break;
			}else if((n[n1[i][b]-'a']==n[n1[j][b]-'a'])&&x1<x2){
				string s=n1[i];
				n1[i]=n1[j];
				n1[j]=s;
				break;
			}
			else break;
		}
		}
	}
	for(int j=k-1;j>=k-sum;j--){
		cout<<n1[j]<<endl;
	}
}
