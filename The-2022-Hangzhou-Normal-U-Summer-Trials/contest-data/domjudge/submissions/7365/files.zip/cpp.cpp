#include<bits/stdc++.h>
using namespace std;
struct zim
{
	string s;
	int x = 0;
};
bool cmp(zim a, zim b)
{
	return a.x < b.x;
}
int main()
{
	zim y[1005];
	string r;
	int n, k, i, j, a[26];
	cin >> r >> n;
	getchar();
	for (i = 0; i < n; i++)
	{
		cin >> y[i].s;
		getchar();
	}
	cin >> k;
	for (i = 0; i < r.length(); i++)
		a[r[i] - 'a'] = i + 1;
	for (i = 0; i < n; i++)
	{
		int c = 1000000;
		for (j = 0; j < y[i].s.length(); j++)
		{
			y[i].x += a[y[i].s[j] - 'a'] * 26 * c;
			c -= 1000;
		}
	}
	sort(y, y + n, cmp);
	cout << y[k - 1].s;
}