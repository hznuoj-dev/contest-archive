#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int maxn = 1e6 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 52;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
int p[] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
int tot, rt;
struct segTree{
    int ls, rs;
    int num[10], lz[10];
    bool f;
}tr[maxn];
#define ls(x) tr[x].ls
#define rs(x) tr[x].rs
void build(int l, int r, int &x) {
    x = ++tot;
    tr[x].f = false;
    if(l == r) {
        return ;
    }
    int mid = l + r >> 1;
    build(l, mid, ls(x));
    build(mid + 1, r, rs(x));
}
void pushDown(int x, int pos) {
    int &m = tr[x].lz[pos];
    if(!m) return;
    if(!tr[ls(x)].f) tr[ls(x)].num[pos] += m, tr[ls(x)].lz[pos] += m;
    if(!tr[rs(x)].f) tr[rs(x)].num[pos] += m, tr[rs(x)].lz[pos] += m;
    m = 0;
    return;
}
void pushUp(int x) {
    tr[x].f = tr[ls(x)].f & tr[rs(x)].f;
    if(tr[x].f) return;
    if(tr[ls(x)].f) {
        for(int i = 0; i < 10; ++i) tr[x].num[i] = tr[rs(x)].num[i];
    } else if(tr[rs(x)].f) {
        for(int i = 0; i < 10; ++i) tr[x].num[i] = tr[ls(x)].num[i];
    } else {
        for(int i = 0; i < 10; ++i) tr[x].num[i] = min(tr[ls(x)].num[i], tr[rs(x)].num[i]);
    }
}
void mul(int l, int r, int L , int R, int x, int pos, int val) {
    if(l <= L && r <= R) {
        tr[x].lz[pos] += val;
        tr[x].num[pos] += val;
        return;
    }
    int mid = l + r >> 1;
    pushDown(x, pos);
    if(mid >= L) mul(l, mid, L, R, ls(x), pos, val);
    if(mid < R) mul(mid + 1, r, L, R, rs(x), pos, val);
    pushUp(x);
}
void div(int l, int r, int L , int R, int x, int pos, int val) {
    if(l <= L && r <= R) {
        if(tr[x].f) return;
        tr[x].lz[pos] -= val;
        tr[x].num[pos] -= val;
        return;
    }
    int mid = l + r >> 1;
    pushDown(x, pos);
    if(mid >= L) mul(l, mid, L, R, ls(x), pos, val);
    if(mid < R) mul(mid + 1, r, L, R, rs(x), pos, val);
    pushUp(x);
}
void filp(int pos, int l, int r, int x) {
    if(l == r) {
        tr[x].f = !tr[x].f;
        return;
    }
    int mid = l + r >> 1;
    for(int i = 0; i < 10; ++i) pushDown(x, i);
    if(mid >= x) filp(x, l, mid, ls(x));
    else filp(x, mid + 1, r, rs(x));
    for(int i = 0; i < 10; ++i) pushUp(x);
}
int query(int l, int r ,int L ,int R, int x, int pos, int val) {
    if(l >= L && r <= R){
        if(tr[x].f) return 1;
        return tr[x].num[pos] >= val;
    }
    int mid = l + r >> 1;
    pushDown(x, pos);
    int res = 1;
    if(mid >= L) res &= query(l, mid, L, R, ls(x), pos, val);
    if(mid < R) res &= query(mid + 1, r, L, R, rs(x), pos, val);
    return res;
}
string s;
struct node{
    vector<pair<int,int>> q;
}X[31];
void solve(){
    int n, m;
    cin >> n >> m;
    for(int i = 2; i <= 30; ++i) {
        int cur = i;
        for(int j = 0; j < 10; ++j) {
            int cnt = 0;
            while(cur % p[j] == 0) cur /= p[j], ++cnt;
            if(cnt != 0) X[i].q.push_back({j, cnt});
        }
    }
    build(1, n, rt);
    while(m -- > 0) {
        cin >> s;
        int l, r, x;
        if(s == "mul") {
            cin >> l >> r >> x;
            for(auto &[a,b] : X[x].q){
                mul(l,r,1,n,rt,a, b);
            }
        } else if(s == "div") {
            cin >> l >> r >> x;
            bool f = 1;
            for(auto &[a,b] : X[x].q) f &= query(l,r,1,n,rt,a, b);
            if(f) cout << "YES\n";
            else cout << "NO\n";
            if(f) {
                for(auto &[a,b] : X[x].q) div(l,r,1,n,rt,a, b);
            }
        } else {
            int ps;
            cin >> ps;
            filp(ps, 1, n, rt);
        }
    }
}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}