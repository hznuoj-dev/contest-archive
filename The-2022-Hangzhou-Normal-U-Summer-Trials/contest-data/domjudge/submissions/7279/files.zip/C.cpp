#include<cstdio>
#include<algorithm>
using namespace std;

int n;
long long a[500015];
int q;
long long t;
long long ans;
long long d[500015];

bool check(int mid, int x)
{
	if (d[mid] >= x) return 1;
	return 0;
}

int bsearch(int x)
{
	int l = 1, r = n, mid, ret;
	while (l <= r)
	{
		mid = (l + r) >> 1;
		if (check(mid, x))
		{
			ret = mid;
			r = mid - 1;
		}
		else l = mid + 1;
	}
	return ret;
}

int main()
{
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		scanf ("%lld", &a[i]);
		d[i - 1] = a[i] - a[i - 1];
	}
	d[n] = 1e18 + 10;
	scanf ("%d", &q);
	while (q--)
	{
		ans = 0;
		scanf ("%lld", &t);
		int pin = bsearch(t);
		ans += a[pin] - a[1];
		ans += (n - pin + 1) * t;
		printf ("%lld\n", ans);
	}
	
	return 0;
}

