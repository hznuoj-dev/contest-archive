#include<bits/stdc++.h>
using namespace std;
#define N 1005
#define int long long

map<char,char> mp;
struct st{
	string fi,aft;
}num[N];

int cmp(st a,st b){
	return a.aft < b.aft;
}

void solve(){
	string s;
	int n;
	cin >> s >> n;
	for(int i = 0;i < s.length();i++ ) mp[s[i]] = 'a' + i;
	for(int i = 1;i <= n;i++){
		cin >> num[i].fi;
		num[i].aft = num[i].fi;
		for(int j = 0;j < num[i].aft.length();j++) num[i].aft[j] = mp[num[i].aft[j]];
	}
	sort(num + 1,num + 1 + n,cmp);
	int k;cin >> k;
	cout << num[k].fi;
}

signed main(){
	int t = 1;
	while(t--) solve();
}
