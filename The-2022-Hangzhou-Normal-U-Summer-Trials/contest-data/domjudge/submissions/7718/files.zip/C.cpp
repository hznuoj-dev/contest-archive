#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 5e5+10;

ll a[N],d[N];
void solve(){
	int n; cin >> n;
	for(int i=1;i<=n;i++) cin >> a[i];
	for(int i=2;i<=n;i++) d[i]=a[i]-a[i-1];
	int q; cin >> q;
	while(q--){
		ll t; cin >> t;
		if(t<=d[2]){
			ll ans=1ll*n*t;
			cout << ans << endl;
			continue;
		}
		int p=lower_bound(d+2,d+n+1,t) - d;	
	//	cout << "p==" << p << endl;
		if(p==n+1){
			ll ans=a[n]-a[1]+t;
			cout << ans << endl;
			continue;
		}
		ll ans;
		if(d[p]==t){
			ans = a[p]-a[1] + 1ll*(n-p+1)*t;
		}else {
			ans = a[p-1]-a[1] + 1ll*(n-p+2)*t;
		}
		cout << ans << endl;
	}
	
}
/*


*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
