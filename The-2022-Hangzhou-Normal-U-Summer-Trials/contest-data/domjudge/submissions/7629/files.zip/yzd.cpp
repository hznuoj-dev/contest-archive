#include <bits/stdc++.h>

using namespace std;

map<char,int>mp;

map<string,string>mp1;

string ans[1005];
//"00000000000000000000000000"

int main() {
	for(int i = 0 ; i<26 ; i++){
		char tmp;
		cin >> tmp;
		mp[tmp] = i;
	}
	
	int n;
	cin >> n;
	for(int i = 0 ; i<n ; i++){
		string s;
		cin >> s;
		ans[i] = "00000000000000000000000000";
		string tmp = "";
		tmp = ans[i];
		int len = s.size();
		for(int j = 0 ; j<26 ; j++){
			char ss = (mp[s[j]]%10)+ '0';
			tmp[j] = ss;
		}
		ans[i] = tmp;
		mp1[ans[i]] = s;
		
		
	}
	
	int k;
	cin >> k;
	sort(ans,ans+n);
	
	cout << mp1[ans[k-1]] << endl;
	
	
	
	
	
	
}

