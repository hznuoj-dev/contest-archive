#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> PLL;
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define debug(a) cout<<#a<<'='<<a<<endl;
#define fi first
#define se second
#define pb push_back
#define all(a) a.begin(),a.end()

string str;
map<char,char>mp;

bool cmp1(string x,string y){
	rep(i,0,min(x.size(),y.size())){
		int pos1,pos2;
		if(x[i]==y[i])continue;
		rep(j,0,26){
			if(str[j]==x[i])pos1=j;
			if(str[j]==y[i])pos2=j;
		}
		return pos1<pos2;
	}
	return x.size()<y.size();
}


void solve(){
	int n,m;
	cin>>str>>n;
	vector<string>a(n),b;
	rep(i,0,n)cin>>a[i];
	cin>>m;
	sort(all(a),cmp1);
//	rep(i,0,n){
//		cout<<a[i]<<endl;
//	}
	cout<<a[m-1]<<endl;
}

int main(){
	int _=1;
//	cin>>_;
	while(_--)solve();
	return 0;
}
