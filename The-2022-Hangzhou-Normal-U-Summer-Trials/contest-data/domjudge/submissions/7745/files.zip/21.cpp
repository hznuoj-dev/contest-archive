#include<cstring>
#include<iostream>
#include<algorithm>

using namespace std;

int a[300] = {0};

bool cmd1(string s1, string s2)
{
	if(s1.length() < s2.length())
	{
		return true;
	}
	else if(s1.length() == s2.length())
	{
		int num = s1.length();
		for(int m = 0; m < num; m++)
		{
			if(a[(int)s1[m]] < a[(int)s2[m]])
			{
				return true;
			}
			else if (a[(int)s1[m]] > a[(int)s2[m]])
			{
				return false;
			}
		}
	}
	return false;
}

int main()
{
	string str;
	cin >> str;
	for(int i = 0; i < 26; i++)
	{
		a[(int)str[i]] = i;
	}
	int n;
	cin >> n;
	getchar();
	string s[n];
	for(int i = 0 ; i < n; i++)
	{
		cin >> s[i];
		getchar();
	}
	int k;
	cin >> k;
	sort(s, s + n, cmd1);
	cout << s[k - 1];
}
