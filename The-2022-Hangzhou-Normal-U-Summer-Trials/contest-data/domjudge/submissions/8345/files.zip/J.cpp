#include<iostream>
#include<string>
#include<cstdio>
using namespace std;

int main(){
	int q,i,j;
	string a="";
	scanf("%d",&q);
	for(i=0;i<q;i++){
		int x;
		char c,d;
		scanf("%d",&x);
		if(x==1){
			scanf(" %c",&c);
			a += " ";
			a[a.length()-1] = c;
		}
		if(x==2){
			if(a.length()!=0){
				a = a.substr(0,a.length()-1);
			}
		}
		if(x==3){
			scanf(" %c %c",&c,&d);
			for(j=0;j<a.length();j++){
				if(a[j]==c){
					a[j]=d;
				}
			}
		}
	}
	if(a.length()==0){
		printf("The final string is empty");
	}else{
		for(i=0;i<a.length();i++){
			printf("%c",a[i]);
		}
	}
	return 0;
}
