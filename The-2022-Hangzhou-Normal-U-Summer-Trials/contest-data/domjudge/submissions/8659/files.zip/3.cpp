#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll inf = 1e18 + 7;
const int maxn = 1e5 + 7;
int a[maxn], n, c[maxn];
inline int lowbit(int x)
{
	return x & (-x);
}
void add(int x, int y)
{
	for (; x <= n; x += lowbit(x))
		c[x] += y;
}
ll ask(int x)
{
	ll ans = 0;
	for (; x; x -= lowbit(x))
		ans += c[x];
	return ans;
}
ll query(int l, int r)
{
	return ask(r) - ask(l - 1);
}
int main()
{
	int  k;
	cin >> n >> k;
	for (int i = 1; i <= n; i++)
	{
		cin >> a[i];
		add(i, a[i]);
	}
	ll ans = 0;
	for (int i = 1; i <= n; i++)
	{
		for (int j = i; j <= n; j++)
		{
			if ((query(i, j) % k) == 0)
				ans++;
		}
	}
	cout << ans << '\n';
}