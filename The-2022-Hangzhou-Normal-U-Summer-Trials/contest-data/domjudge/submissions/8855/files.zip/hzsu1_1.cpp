#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define int long long
#define ll long long
const int NUM = 5e1+20;	
int b[NUM];	
using namespace std;
signed main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int n;cin>>n;
	vector<int> a(n+1);
	
	rep(i,0,n-1) cin>>a[i];
	rep(i,1,n-1){
		b[i]=a[i]-a[i-1];
	}
	int m;cin>>m;

	rep(i,0,m-1){
		int temp;
		cin>>temp;
		int temp1=lower_bound(b,b+n,temp)-b-1;
		int sum=0;sum+=a[temp1]-1;
		sum+=(n-temp1)*temp;
		cout<<sum<<endl;
	}
	return 0;
} 
/*

3
1 3 8
3
2
4
10

*/
