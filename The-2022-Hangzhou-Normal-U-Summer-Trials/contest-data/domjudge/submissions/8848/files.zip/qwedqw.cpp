#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e5 + 10;
long long int a[maxn];
long long int sum[maxn];
long long int sq[maxn];
vector<long long int>vk;
int main(){
    int n;
    long long int k;
    cin>>n>>k;
    memset(sum, 0, sizeof(sum));
    long long int ans = 0;
    for(int i = 1; i <= n; i++){
    	cin>>a[i];
    	sum[i] = sum[i - 1] + a[i];
    	if(a[i]%k == 0)  ans++;
	}	
	for(int i = 1; i <= n; i++){
		sq[i] = sum[i]%k;
		cout<<sq[i]<<endl;
    }
    sort(sq + 1, sq + n + 1);
    int start = 1;
    int end = 1;
    for(int i = 1; i <= n - 1; i++){
    	if(sq[i] == sq[i + 1]){
    		end++;
    		if(end == n){
    			int ck = end - start + 1;
    			ans = ans + ck*(ck - 1)/2;
			}
		}else{
			int ck = end - start + 1;
			ans = ans + (ck)*(ck - 1)/2;
			start = i + 1;
			end = i + 1;
		}
	}
	
	cout<<ans<<endl;
	return 0;
} 
