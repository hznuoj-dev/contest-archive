#include<bits/stdc++.h>
using namespace std;
map<char,int>mp;
int cmp1(string p,string q)
{
	if(p.size()<q.size())
	{
		if(q.find(p))
		{
			return p<q;
		}
	 } 
	 else
	 {
	for(int i=0;i<max(p.length(),q.length());i++)
	{
		if(mp[p[i]]<mp[q[i]])
		{
			return p<q;
		}
	}
}
}
int main()
{
	

    string s;
    string x[1010];
    cin>>s;
    for(int i=1;i<=s.length();i++)
    {
       mp[s[i]]=i;
	}
    int m;
    cin>>m;
    for(int i=1;i<=m;i++)
    {
    	cin>>x[i];
	}
	sort(x+1,x+m+1,cmp1);
  int k;
  cin>>k;
  cout<<x[k]<<endl;
	return 0;
 } 
