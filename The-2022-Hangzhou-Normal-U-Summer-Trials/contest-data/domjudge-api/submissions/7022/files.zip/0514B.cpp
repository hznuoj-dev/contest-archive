#include<bits/stdc++.h>

using namespace std;

int mp[520];
char ch;
int n, k;
string s[1314];
bool cmp(const string & s1, const string & s2) {
	int len = min(s1.length(), s2.length());
	for (int i = 0; i < len; i++) {
		if (s1[i] != s2[i]) {
			return mp[s1[i]] < mp[s2[i]];
		}
	}
	return s1.length() < s2.length();
}
int main () {
	for (int i = 0; i < 26; i++) {
		cin >> ch;
		mp[ch] = i + 1;
	}
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> s[i];
	}
	sort(s, s + n, cmp);
	cin >> k;
	cout << s[k - 1];
	return 0;
}
