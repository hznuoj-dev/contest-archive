#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10;
char s[N];
void solve(){
	scanf("%s",&s);
	int l=strlen(s),cnt=0;//hznu
	for(int i=3;i<l;i++){
		if(s[i]='u'&&s[i-1]=='n'&&s[i-2]=='z'&&s[i-3]=='h')cnt++;
	}
	printf("%d\n",cnt);
}
int main(void){
	int t=1;
	//scanf("%d",&t);
	while(t--)solve();
	return 0;
}
