#include<bits/stdc++.h>
#define ll long long
const int inf=0x3f3f3f3f;
const int maxn=5e5+10;
using namespace std;
ll a[maxn];
struct node{
	ll data;
	friend bool operator <(const node&a,const node&b)
	{
		return a.data>b.data;
	}
};
priority_queue<node>q;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
	cin>>a[i];
	if(i>=2)
	{
		q.push({a[i]-a[i-1]});
	}	
	}
	ll mx=1e18;
	q.push({mx-a[n]});
	ll sum=0;
	int t;
	cin>>t;
	ll pre=0;
	while(t--)
	{
		ll op;
		cin>>op;
		while(q.top().data<op&&!q.empty())
		{
			sum+=q.top().data-pre;
			q.pop();
		}
		sum+=q.size()*(op-pre);
		pre=op;
		cout<<sum<<'\n';
	}
	return 0;
} 
 
 
