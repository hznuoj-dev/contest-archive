#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define int long long
#define ll long long
using namespace std;
signed main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int n,temp;

	cin>>n>>temp;	vector<int> a(n);
	vector<int> sum(n);
	rep(i,0,n-1){
		cin>>a[i];

	}
	int number=0;
	sum[0]=a[0];
	rep(i,1,n-1){
		sum[i]=sum[i-1]+a[i];
	}
	rep(i,0,n-1){
		cout<<sum[i]<<endl;
	}
	for(int i=n-1;i>=0;i--){
		for(int j=i-1;j>=0;j--){
			if((sum[i]-sum[j])%temp==0){
				number++;
				if(sum[0]==0&&j==0){
					number++;
				}
			}
		}
	}
	cout<<number<<endl;
	return 0;
} 


/*
6 3
0 1 2 4 7 7


*/
