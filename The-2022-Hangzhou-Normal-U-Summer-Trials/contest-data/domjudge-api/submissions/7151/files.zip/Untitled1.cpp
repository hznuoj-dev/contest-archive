#include <bits/stdc++.h>

using namespace std;

map<char,int> mp0;

int value[105];
string a[105];

map<int,string>mp1;





int main() {
	
	
    for(int i = 0 ; i<26 ; i++){
        char tmp;
        cin >> tmp;
        mp0[tmp] = i;
    }

    int n;
    cin >> n;
    for(int i = 0 ; i<n ; i++){
    	string s;
    	cin >> s;
    	for(int j = 0 ; j<s.length() ; j++){
    		value[i] += mp0[s[j]];
		}
		a[i] = s;
		
		mp1[value[i]] = s;
		
	}
	
	int k = 0;
	cin >> k;
	
	sort(value,value+n);
	
	/*for(int i = 0 ; i<n ; i++){
		cout << value[i] << endl;
	}*/
	
	cout << mp1[value[k-1]] << endl;
	
	
	
	


}

