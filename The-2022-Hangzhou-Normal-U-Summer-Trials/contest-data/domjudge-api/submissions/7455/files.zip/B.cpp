#include <bits/stdc++.h>
#define ll long long

using namespace std;
typedef pair<int, int> PII;
typedef pair<char, char> PCC;

const int N = 1e6 + 10, mod = 1e9 + 7;

ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a;}
ll lcm(ll a, ll b) { return a * b / gcd(a, b); }
ll qmi(ll a, ll b) { ll res = 1; while(b) { if(b & 1) res = (res * a) % mod; a = (a * a) % mod; b >>= 1;} return res % mod; }

map<char, int> mp;
string t;
int n, k;
string s[N];

bool cmp(string a, string b)
{
	//if(a.size() != b.size()) return a.size() < b.size();

	for (int i = 0; i < min(a.size(), b.size()); i ++)
	{
		if(mp[a[i]] != mp[b[i]])
			return mp[a[i]] < mp[b[i]];
	}
	return a.size() <= b.size();
	//return true;
}

void solve()
{
	cin >> t;
	for (int i = 0; i < t.size(); i ++)	mp[t[i]] = i + 1;

	cin >> n;
	for (int i = 1; i <= n; i ++)
		cin >> s[i];

	sort(s + 1, s + 1 + n, cmp);
	cin >> k;
	cout << s[k] << '\n';
}

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
    int T = 1;
	//cin >> T;
	while(T --)
	{
		solve();
	}
    return 0;
}
