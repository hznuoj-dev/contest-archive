#include<bits/stdc++.h>
using namespace std;
int main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    int q;
    scanf("%d", &q);

    char f[500] = {'\0'};
    auto INIT = [&]() -> void {for(char i = 'a' - 5;i <= 'z' + 2;i ++) f[i] = i;};
    auto find = [&](auto self, char x) -> char {return f[x] = (f[x] == x ? f[x] : self(self, f[x]));};
    auto merge = [&](char x, char y) -> void {f[find(find, x)] = find(find, y);};
    INIT();

    struct node{int op; char x, y;};
    vector<node> vec;
    for(int i = 1;i <= q;i ++){
        int op;
        scanf("%d", &op);
        char x = '\0', y = '\0';
        if(op == 1){
            scanf(" %c", &x);
        }else if(op == 3){
            scanf(" %c %c", &x, &y);
        }
        vec.push_back({op, x, y});
    }

    deque<char> dq;
    int cnt = 0;
    for(int i = q - 1;i >= 0;i --){
        int op = vec[i].op;
        char x = vec[i].x, y = vec[i].y;
        if(op == 1){
            if(cnt > 0) cnt --;
            else dq.push_front((char)find(find, x));
        }else if(op == 2){
            cnt ++;
        }else{
            merge(x, y);
        }
    }
    if(dq.empty()) puts("The final string is empty");
    else for(auto v : dq) printf("%c", v);

    return 0;
}