#include<bits/stdc++.h>
#define ll long long
using namespace std;
string s;
ll n;
typedef struct{
	char s1;
}h;
typedef struct{
	char s1;
	char s2;
}h1;
h a[100010];
h1 c[100010];
int cnt1,cnt2,cnt3;
ll x;
char s1,s2;
ll d[100];
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>x;
		if(x==1){
			cin>>s1;
			a[++cnt1].s1=s1;
		}
		if(x==2){
			cnt2++;
		}
		if(x==3){
			cin>>s1>>s2;
			c[++cnt3].s1=s1;
			c[cnt3].s2=s2;
		}
	}
	if(cnt1<=cnt2){
		cout<<"The final string is empty"<<endl;
	}
	else{
		cnt1-=cnt2;
		for(int i=1;i<=cnt1;i++){
			s+=a[i].s1;
		}
		for(int i=1;i<=30;i++){
			d[i]=i;
		}
		for(int i=1;i<=cnt3;i++){
			ll ans1=c[i].s1-'a'+1;
			ll ans2=c[i].s2-'a'+1;
			for(int i=1;i<=26;i++){
				if(d[i]==ans1){
					d[i]=ans2;
				}
			}
		}
		for(int i=0;i<s.size();i++){
			s[i]=d[s[i]-'a'+1]+'a'-1;
		}
	}
	cout<<s<<endl;
} 
