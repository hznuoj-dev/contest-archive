#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>
#include<vector>
using namespace std;
typedef long long LL;
const int N=5e5+5;
LL s[N];
vector<int> sum[N];
int bsearch(int l,int r,int k)
{
    while(l<r)
    {
        int mid=l+r+1>>1;
        if(s[mid]>=k)r=mid-1;
        else l=mid;
    }
    return l;
}
vector<int> add(vector<int>&A,vector<int>&B)
{
    if(A.size()<B.size())return add(B,A);
    vector<int> C;
    int t=0;
    for(int i=0;i<A.size();i++)
    {
        t+=A[i];
        if(i<B.size())t+=B[i];
        C.push_back(t%10);
        t/=10;
    }
    if(t)C.push_back(t);
    return C;
}
vector<int> mul(vector<int>&A,int b)
{
    vector<int> C;
    int t=0;
    for(int i=0;i<A.size()||t;i++)
    {
        if(i<A.size())t+=A[i]*b;
        C.push_back(t%10);
        t/=10;
    }
    return C;
}
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>s[i];
    }
    for(int i=n;i>1;i--) s[i]-=s[i-1];
    s[1]=0;
    for(int i=2;i<=n;i++)
    {
        LL tmp=s[i];
        vector<int> v1;
        while(tmp)
        {
            v1.push_back(tmp%10);
            tmp/=10;
        }
        sum[i]=add(v1,sum[i-1]);
    }
    int q;
    cin>>q;
    while(q--)
    {
        LL mm;
        cin>>mm;
        int t=bsearch(1,n,mm);
        LL tmp=mm;
        vector<int> v1;
        while(tmp)
        {
            v1.push_back(tmp%10);
            tmp/=10;
        }
        vector<int>v2=mul(v1,n-t+1);
        v2=add(sum[t],v2);
        for(int i=v2.size()-1;i>=0;i--)
        {
            cout<<v2[i];
        }
        cout<<endl;
    }
}
