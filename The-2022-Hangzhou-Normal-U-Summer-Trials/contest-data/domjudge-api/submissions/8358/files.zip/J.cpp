#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 1e5 + 7;

vector<char> ans;
vector<int> v[30];
map<char,char> mp;
vector<pair<int,int>> cnt;
map<pair<char,char>,int> mm;
int cc[30];
int fa[30];
int find(int x) {
	return fa[x] == x ? x : fa[x] = find(fa[x]);
}
void solve() {
	int q;
	cin >> q;
	for (int i = 1; i <= q; ++i) {
		int op;
		cin >> op;
		if (op == 1) {
			char x;
			cin >> x;
			ans.push_back(x);
			if (mp[x]) {
				mm[{x,mp[x]}] = 1;
				int tmp = x - 'a' + 1;
				for (int i = 0; i < v[tmp].size(); ++i) {
					if (v[tmp][i] >= ans.size()) continue;
					ans[v[tmp][i]] = mp[x];
					v[mp[x] - 'a' + 1].push_back(i);
				}
				v[tmp].clear();
			}
			v[x - 'a' + 1].push_back(ans.size() - 1);
		}
		else if (op == 2) {
			ans.pop_back();
		}
		else {
			char x,y;
			cin >> x >> y;
			mp[x] = y;
			cnt.push_back({x,y});
		}
	}
	if (ans.empty()) {
		cout << "The final string is empty";
		return;
	}
	for (int i = 1; i <= 30; ++i) {
		fa[i] = i;
	}
	for (int i = cnt.size() - 1; i >= 0; --i) {
		int x = cnt[i].first - 'a' + 1;
		int y = cnt[i].second - 'a' + 1;
		if (mm[cnt[i]]) cc[x] = 1;
		if (cc[x]) continue;
		if (find(x) != find(y)) {
			fa[x] = y;
		}
	}
	for (int i = 0; i < ans.size(); ++i) {
		cout << char(find(ans[i] - 'a' + 1) + 'a' - 1);
	}
}
int main() {
	ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
/*
5
1 2
1 3
3 4
3 5
5
1
2
3
4
5
*/
