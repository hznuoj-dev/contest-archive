#include<bits/stdc++.h>
#define ll long long
const int inf=0x3f3f3f3f;
const int maxn=5e6+10;
using namespace std;
ll a[maxn];
struct node{
	ll data;
	friend bool operator <(const node&a,const node&b)
	{
		return a.data>b.data;
	}
};
ll ans[maxn];
struct qq{
	int id;
	ll qus;
	friend bool operator <(const qq&a,const qq&b)
	{
		return a.qus<b.qus;
	}	
	
}b[maxn];
priority_queue<node>q;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
	cin>>a[i];	
	}
	sort(a+1,a+1+n);
	for(int i=2;i<=n;i++)
	q.push({a[i]-a[i-1]});
	ll sum=0;
	int t;
	cin>>t;
	for(int i=1;i<=t;i++)
	{
		cin>>b[i].qus;
		b[i].id=i;
	}
	sort(b+1,b+t+1);
	ll pre=0;
	for(int i=1;i<=t;i++)
	{
		ll op=b[i].qus;
		while(q.top().data<op&&!q.empty())
		{
			sum+=q.top().data-pre;
			q.pop();
		}
		sum+=(q.size()+1)*(op-pre);
		pre=op;
		ans[b[i].id]=sum;
	}
	for(int i=1;i<=t;i++)
	cout<<ans[i]<<'\n';
	return 0;
} 
 
 
