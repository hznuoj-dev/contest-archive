#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=5e5+10;
const int mod=1e9+7;
int n,q,k;
ll t;
ll a[maxn],sub[maxn];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n;
    for(int i=1;i<=n;i++)  
    {
        cin>>a[i];
        if(i>1)  sub[i-1]=a[i]-a[i-1];
    }
    cin>>q;
    while(q--)
    {
        cin>>t;
        ll ans=0;
        for(int i=1;i<=n-1;i++)
        {
            if(t<=sub[i])  ans+=t;
            else  ans+=sub[i];
        }
        ans+=t;
        cout<<ans<<"\n";
    }
    return 0;
}










