#include<bits/stdc++.h>
using namespace std;
#define itn int
#define int long long 
vector<int>g[100010];
int V;
int sz[100010];
int fa[100010];
void dfs(int now,int father)
{
	sz[now]=1;
	fa[now]=father;
	for(int i=0;i<g[now].size();i++)
	{
		if(g[now].at(i)==father) continue;
		dfs(g[now].at(i),now);
		sz[now]+=sz[g[now].at(i)];
	}
}
void run()
{
	cin>>V;
	for(int i=0;i<V-1;i++)
	{
		int u,v;
		cin>>u>>v;
		g[u].push_back(v);
		g[v].push_back(u);
	}
	dfs(1,0);
	int q;
	cin>>q;
	while(q--)
	{
		int now;
		cin>>now;
		vector<int>v;
		v.push_back(V-sz[now]);
		for(int i=0;i<g[now].size();i++)
		{
			if(g[now].at(i)==fa[now]) continue;
			v.push_back(sz[g[now].at(i)]);
		}
//		cout<<"dbg--> "<<v.size()<<endl;
		int ans=V-1;
		for(int i=0;i<v.size();i++)
		{
			for(int j=i+1;j<v.size();j++)
			{
				ans+=v[i]*v[j];
			}
		}
		cout<<ans<<endl;
	}
	
	
	
	
	return;
}
signed main()
{
	int T=1;
//	cin>>T;
	while(T--)
	{
		run();
	}
	
	return 0;
}
