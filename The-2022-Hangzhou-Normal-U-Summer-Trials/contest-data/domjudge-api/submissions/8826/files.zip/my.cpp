#include <bits/stdc++.h>
#define vi vector<int>
#define vc vector
#define vll vector<long long>
#define pii pair<int,int>
#define AXY(a,x,y) int x=(a).first,y=(a).second;
#define MID(l,r) int mid=((l)+(r))/2
#define ALL(arr) arr.begin(),arr.end()
using namespace std;
typedef long long ll;






#define int ll
struct NODE{
	int l,r,v=1;
	#define lrs(p) int ls=(p)*2,rs=(p)*2+1
};
vc<NODE> st;
vc<pii> lazy;
vi lock1;
void pushUp(int p){
	lrs(p);
	if(st[p].l!=st[p].r){
		lock1[p]=(lock1[ls]|lock1[rs]);
		st[p].v=__gcd(st[ls].v,st[rs].v);
	}
}
void div2(int p,int x){
	lrs(p);
	if(!lock1[p]){
		st[p].v/=x;
		lazy[p].second*=x;
		return;
	}
	else{
		if(st[p].l==st[p].r){
			st[p].v/=x;
			lazy[p].first=lazy[p].second=1;
			return;
		}
		div2(ls,x);
		div2(rs,x);
		pushUp(p);
		return;
	}
}
void mul2(int p,int x){
	lrs(p);
	if(!lock1[p]){
		st[p].v*=x;
		lazy[p].first*=x;
		return;
	}
	else{
		if(st[p].l==st[p].r){
			st[p].v*=x;
			lazy[p].first=lazy[p].second=1;
			return;
		}
		mul2(ls,x);
		mul2(rs,x);
		pushUp(p);
		return;
	}
	
}
void pushDowm(int p){
	lrs(p);
	int l=st[p].l,r=st[p].r;
	if(l!=r){
		if(lazy[p].first>1) {
			mul2(ls,lazy[p].first);
			mul2(rs,lazy[p].first);
		}
		if(lazy[p].second>1){
			div2(ls,lazy[p].second);
			div2(rs,lazy[p].second);
		}
	}
	lazy[p].first=lazy[p].second=1;
}
void built(int p,int L,int R){
	lrs(p);
	st[p].l=L;
	st[p].r=R;
	if(L==R){
		return;
	}
	MID(L,R);
	built(ls,L,mid);
	built(rs,mid+1,R);
}

void mul(int p,int L,int R,int x){
	pushDowm(p);
	lrs(p);
	int l=st[p].l,r=st[p].r;
	if(L<=l&&r<=R){
		mul2(p,x);
		return;
	}
	MID(l,r);
	if(mid>=L) mul(ls,L,R,x);
	if(mid+1<=R) mul(rs,L,R,x);
	pushUp(p);
}
int div(int p,int L,int R,int x,int op){
	pushDowm(p);
	lrs(p);
	int l=st[p].l,r=st[p].r;
	if(L<=l&&r<=R){
		pushUp(p);
		int gcd=__gcd(st[p].v,x);
		if(gcd==x){
			if(op){
				div2(p,x);
			}
			return 1;
		}
		else return 0;
	}
	MID(l,r);
	int res=1;
	if(mid>=L) res&=div(ls,L,R,x,op);
	if(mid+1<=R) res&=div(rs,L,R,x,op);
	pushUp(p);
	return res;
}
void flip(int p,int pos){
	pushDowm(p);
	lrs(p);
	int l=st[p].l,r=st[p].r;
	if(l==r){
		lock1[p]=1-lock1[p];
		return;
	}
	MID(l,r);
	if(pos<=mid) flip(ls,pos);
	else flip(rs,pos);
	pushUp(p);
}


void printfT(int p,int op){
	pushDowm(p);
	int l=st[p].l,r=st[p].r;
	MID(l,r);
	if(l==r){
		if(op) cout<<st[p].v<<' ';
		else cout<<lock1[p]<<' ';
		return;
	}
	lrs(p);
	printfT(ls,op);
	printfT(rs,op);
	pushUp(p);
	return;
}
signed main(){
	int n;
	cin>>n;
	st.resize(n*4);
	lock1.resize(n*4,0);
	lazy.resize(n*4,{1,1});
	
	built(1,0,n-1);
	int q=1;
	cin>>q;
//	printfT(1,1);
//	cout<<endl;
//	printfT(1,0);
//	cout<<endl;
	while(q--){
		string op;
		cin>>op;
		int l,r,x;
		if(op=="mul"){
			cin>>l>>r>>x;
			l--,r--;
			mul(1,l,r,x);
		}
		else if(op=="div"){
			cin>>l>>r>>x;
			l--,r--;
			if(div(1,l,r,x,0)){
				div(1,l,r,x,1);
				cout<<"YES\n";
			}
			else cout<<"NO\n";
		}
		else if(op=="flip"){
			int p;		
			cin>>p;
			p--;
			flip(1,p);
		}
//		printfT(1,1);
//		cout<<endl;
//		printfT(1,0);
//		cout<<endl;
	}
	
	return 0;
}









