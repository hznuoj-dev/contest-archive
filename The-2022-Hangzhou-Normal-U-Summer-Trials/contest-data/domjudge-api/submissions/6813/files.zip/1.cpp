#include <bits/stdc++.h>
#define RE0 return 0;
#define FAST ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)
using namespace std;

int T = 1, n, m;

string str;
int ans = 0;

signed main(){
	FAST;
	while(T--){
		cin >> str;
		for(int i=0;str.length() >= 4 && i<str.length() - 3;++i){
			if(str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u'){
				++ans;
			}
		}
		cout << ans << "\n";
	}
	RE0
} 

