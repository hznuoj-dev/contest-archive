#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[500050],b[500050];
void solve(){
	ll i,j,m,n,x,y,k,l,r,t,ans=0,q,mid;
	char c;
	cin>>n;
	for(i=1;i<=n;i++){
		scanf("%lld",a+i);
	}
	n--;
	for(i=1;i<=n;i++) a[i]=a[i+1]-a[i];
	sort(a+1,a+n+1);
	for(i=1;i<=n;i++){
		b[i]=b[i-1]+a[i];
	}
	cin>>q;
	while(q--){
		scanf("%lld",&t);
		ans=(n+1)*t;
		l=1,r=n;
		while(l<=r){
			mid=(l+r)/2;
			if(a[mid]>=t) r=mid-1;
			else l=mid+1;
		}
		ans=ans-r*t+b[r];
		printf("%lld\n",ans);
	}
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
