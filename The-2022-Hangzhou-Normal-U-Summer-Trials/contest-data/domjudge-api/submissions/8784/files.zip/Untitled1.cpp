#include<bits/stdc++.h>
using namespace std;

#define INF ox3f3f3f3f



int main(){
	
	int n;
	cin>>n;
	
	long long int a[n+1]={0};
	for(long long int i=1;i<=n;i++){
		cin>>a[i];
	}
	
	int q;
	cin>>q;
	map<int,int>mp;
	while(q--){
		long long int count=0;
		
		long long int t;
		cin>>t;
		
		for(long long int i=1;i<=n;i++){
			for(long long int j=0;j<t;j++){
				mp[a[i]+j]++;
			}
		}
		
		cout<<mp.size()<<endl;
	}
	
	

	
	
	return 0;
} 
