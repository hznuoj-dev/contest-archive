#include<iostream>

using namespace std;
const int N=1e5+10;
char s[N];
int main()
{
    scanf("%s",s);
    int x=0,k=0,num=0;
    for(int i=0;s[i]!='\0';i++)
    {
        if(s[i]=='h')
        {
            if(s[i+1]=='z')
            {
                if(s[i+2]=='n')
                {
                    if(s[i+3]=='u') num++;
                }
            }
        }
    }
    cout<<num<<endl;
    return 0;
}