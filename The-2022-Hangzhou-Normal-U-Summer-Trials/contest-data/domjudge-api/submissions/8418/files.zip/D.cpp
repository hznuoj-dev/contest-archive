#include <bits/stdc++.h>

using namespace std;

typedef long long LL;
const int N = 1e5 + 10;

LL sz[N], st[N], ans[N], n;
vector<int> e[N];

void dfs(int u)
{
    st[u] = 1;
    for (auto i : e[u])
    {
        if (!st[i])
        {
            dfs(i);
            sz[u] += sz[i];
        }
    }
}

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    cin >> n;
    for (int i = 1; i < n; i++)
    {
        int a, b;
        cin >> a >> b;
        e[a].push_back(b);
        e[b].push_back(a);
    }
    for (int i = 1; i <= n; i++)
        sz[i] = 1;
    dfs(1);
    //    cout << "DEBUG";
    //    for(int i = 1; i <= n; i ++) cout << sz[i] << endl;
    //    cout << "debug" << endl;
    //得到每棵子树的节点个数
    for (int i = 1; i <= n; i++)
    {
        ans[i] += n - 1; //每个子孙节点直接到i
        LL sum = 0;
        for (auto j : e[i])
        {
            if (sz[j] < sz[i])
            {
                ans[i] += sz[j] * sum;
                sum += sz[j];
                // if(i == 3)cout << sum << endl;
            }
        }
        ans[i] += (sz[i] - 1) * (n - sz[i]);
    }
    int q;
    cin >> q;
    while (q--)
    {
        int u;
        cin >> u;
        cout << ans[u] << endl;
    }
    return 0;
}