#include<iostream>
#include<string>
using namespace std;
int main(){
	string s;
	cin>>s;
	int ans=0;
	for(int i=0;i<s.length()-3;++i){
		if(s.substr(i,4)=="hznu")ans++;
	}
	cout<<ans;
}
