#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef long long ll;
const int N=5e5+7;
int a[N],d[N];
void solve(){
	int n;
	cin >> n;
	for (int i=1;i<=n;i++){
		cin >> a[i];
	}
	sort(a+1,a+1+n);
	for (int i=2;i<=n;i++){
		d[i]=a[i]-a[i-1]+1;
	}
	
	int q;
	cin >> q;
	while (q--){
		int t;
		int sum=0;
		cin >> t;
		int index=upper_bound(d+2,d+1+n,t)-d;
		sum=(n-index+1)*t;
		sum+=a[index-1]+t-1-a[1]+1;
		cout << sum << '\n';
		
		
	}

}

signed main(){
	ios::sync_with_stdio(0);
	int t=1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}

