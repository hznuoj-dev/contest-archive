#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 1e3 + 7;

map<char,char> mp;
string t[N];
string tmp[N];
map<string,int> id;
int w;
void solve() {
	string s;
	cin >> s;
	for (int i = 0; i < s.size(); ++i) {
		mp[s[i]] = char(i + 'a');
	}
	int n;
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		cin >> t[i];
		tmp[i] = t[i];
		for (int j = 0; j < t[i].size(); ++j) {
			tmp[i][j] = mp[t[i][j]];
		}
		id[tmp[i]] = i;
	}
	sort(tmp+1,tmp+n+1);
	int k;
	cin >> k;
	cout << t[id[tmp[k]]] << '\n';
}
int main() {
	ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
/*
acbdefghijklmnopqrstuvwxyz
2
abc
acb
1
*/
