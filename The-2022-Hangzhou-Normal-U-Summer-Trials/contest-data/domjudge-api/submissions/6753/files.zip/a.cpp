#include<iostream>
using namespace std;
int main(){
	string s;
	cin>>s;
	int sum=0;
	for(int i=0;i<s.length();i++){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
			sum++;
		}
	}
	cout<<sum;
} 
