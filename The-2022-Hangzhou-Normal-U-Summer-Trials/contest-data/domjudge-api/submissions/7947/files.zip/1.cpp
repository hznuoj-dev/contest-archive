#include <bits/stdc++.h>
#define RE0 return 0;
#define FAST ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)
#define ll long long
using namespace std;

ll T = 1, n, m;

ll a[100005];
ll b[100005];
map<int, int> mp;
int cnt;
ll c[100005];
ll ans = 0;
int k;

signed main(){
	FAST;
	while(T--){
		cin >> n >> k;
		for(int i=1;i<=n;++i){
			cin >> a[i];
			a[i] %= k; 
		}
		for(int i =1; i<=n;++i){
			b[i]=b[i-1]+a[i];
			b[i] %= k;
			if(!mp[b[i]])
				c[++cnt]=b[i];
			mp[b[i]]++;
		}
//		cout << "cnt : " << cnt << endl;
//		for(int i = 0; i <= cnt; ++i){
//			cout << c[i] << endl;
//		}
		for(int i =1;i<=cnt;++i){
			ll t = mp[c[i]];
			if(c[i]){
				if(t > 1)
//				cout << c[i] << " : " << (t)*(t-1)/2 << endl;
					ans += (t)*(t-1)/2;
			}
			else{
				++t;
//				cout << c[i] << " : " << (t)*(t-1)/2 << endl;
				ans += (t)*(t-1)/2;
			}
		}
		cout << ans << "\n";
	}
	RE0
} 

