#include<stdio.h>
#include<string.h>

int main()
{
	char alp[30] = {0}, str[1005][1005] = {0}, t[1005] = {0};
	int n, k, i, j, l;
	gets(alp);
	scanf("%d", &n);
	getchar();
	for (i = 0; i < n; i++)
		gets(str[i]);
	scanf("%d", &k);
	for (i = 0; i < n; i++)
	{
		for (j = 0; str[i][j] != '\0'; j++)
		{
			for (l = 0; l < 26; l++)
			{
				if (str[i][j] == alp[l])
				{
					str[i][j] = '0' + l;
				}
			}
		}
	}
	for (i = 0; i < n - 1; i++)
	{
		for (j = 0; j < n - i - 1; j++)
		{
			if (strcmp(str[j], str[j + 1]) > 0)
			{
				strcpy(t, str[j]);
				strcpy(str[j], str[j + 1]);
				strcpy(str[j + 1], t);
			}
		}
	}
	for (i = 0; str[k - 1][i] != '\0'; i++)
		printf("%c", alp[str[k - 1][i] - '0']);
	return 0;
}
