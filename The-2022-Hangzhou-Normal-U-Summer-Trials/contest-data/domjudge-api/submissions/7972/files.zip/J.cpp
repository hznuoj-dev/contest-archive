#include<bits/stdc++.h>
using namespace std;
#define N 100005

struct st{
	int p;
	char ch1,ch2;
}num[N];

map<char,char> mp;

void solve(){
	int n,t = 0;
	string ans = "",a,b;
	cin >> n;
	for(int i = 0;i < n;i++){
		cin >> num[n - i].p;
		if(num[n - i].p == 1) cin >> a,num[n - i].ch1 = a[0];
		else if(num[n - i].p == 3) cin >> a >> b,num[n - i].ch1 = a[0],num[n - i].ch2 = b[0];
	}
	for(int i = 0;i < 26;i++) mp['a' + i] = (char)('a' + i);
	for(int i = 1;i <= n;i++){
		if(num[i].p == 2) t--;
		else if(num[i].p == 1){
			if(t < 0) t++;
			else ans = mp[num[i].ch1] + ans;
		}else mp[num[i].ch1] = mp[num[i].ch2];
		//cout << ans << '\n';
	}
	if(ans.length() == 0) cout << "The final string is empty";
	else cout << ans;
}

int main(){
	ios::sync_with_stdio(0);
	int t = 1;
	while(t--) solve();
}

/*
5
1 a
1 b
1 c
3 a c
1 b
*/
