#include<bits/stdc++.h>
#define int long long
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
const int mod = 1e9+7;
using namespace std;
int n,m,t;
int k[200010];
int o[200010],bef[200010];
int x,y;
int qpow(int x,int y){
	int ans=1;
	while(y){
		if(y%2)ans=(ans*x)%mod;
		x=(x*x)%mod;
		y/=2;
	}
	return ans;
}
void init(){
	int l=1,r=n-1;
	o[1]=1;	
	for(int i=2;i<=200001;i++){
		o[i]=((o[i-1]*(r+1))%mod*(qpow(l,mod-2)))%mod;
		l++,r++;
	}
//	for(int i=1;i<=10;i++)cout<<o[i]<<" ";
//	cout<<endl;
	bef[0]=0;
	for(int i=1;i<=200001;i++){
		bef[i]=(bef[i-1]+o[i])%mod;
//		cout<<bef[i]<<" ";
	}
} 
signed main(){
	cin>>n>>m>>t;
	int sum=0;
	init();
	for(int i=1;i<=n;i++){
		cin>>k[i];
		sum+=k[i];
	}	
	while(t--){
		cin>>x>>y;
		sum+=y-k[x];
		k[x]=y;
		if(sum>m)cout<<0<<endl;
		else cout<<bef[m-sum+1]<<endl;
	}
}
