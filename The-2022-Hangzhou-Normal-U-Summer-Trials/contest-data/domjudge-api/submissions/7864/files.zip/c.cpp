#include<iostream>
#include<string>
using namespace std;
long long int a[500007],n,q,t,b[500007];
int main(){
	cin>>n;
	cin>>a[0];
	b[0]=0;
	for(long long int i=1;i<n;i++){
		cin>>a[i];
		b[i]=a[i]-a[i-1]+1;
	}
	cin>>q;
	for(long long int i=0;i<q;i++){
		cin>>t;
		if(t<b[n-1]){
			for(long long int j=0;j<n;j++){
				if(t<b[j]){
					cout<<(n-j+1)*t+a[j-1]-1<<'\n';
					break;
				}
			}
		}else{
			cout<<a[n-1]+t-1;
		}
		
	}
	return 0;
} 
/*5
1 3 8 16 30
5
5
6
12
13
15*/

