#include <bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,w,l;
int a[N];
char b[N],f[N],c[N],d[N];
map<char,char>e;
int main ()
{
	cin >> n;
	for (int i = 1; i <= n; i++)
		{
			cin >> a[i];
			if (a[i] == 1) {
				cin >> b[i];
			}
			else if (a[i] == 3) {
				cin >> c[i] >> d[i];
			}
		}
	for (int i = 1; i <= 26; i++)			
		e[(char)i+96]=(char)i+96;
	l=0; w=0;
	for (int i = n; i >= 1; i--)
		if (a[i] == 2) {
			l++;
		}
	else if (a[i] == 1) {
		if (l == 0) {
			w++;
			f[w]=e[b[i]];
		}
		}
	else if (a[i] == 3){
			e[c[i]]=e[d[i]];
	}	
	if (w == 0) cout << "The final string is empty";
	else {
		for (int i = w; i >= 1; i--)
			cout << f[i];
	}
	return 0;
}
