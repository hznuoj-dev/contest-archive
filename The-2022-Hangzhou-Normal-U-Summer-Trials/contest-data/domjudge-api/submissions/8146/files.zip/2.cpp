#include <bits/stdc++.h>
using namespace std;
#define  ll long long
const int N = 1e5 + 50;
ll b[N], vis[N], sum[N], cal[N];
ll a[N];

int main() {
int n,k;
scanf("%d%d",&n,&k);
ll ans = 0;
for(int i = 1; i <= n; i++)
{
	scanf("%lld",&a[i]);
	sum[i]=sum[i-1]+a[i];
	
}
for(int i = 1; i<=n; i++)
{
	sum[i]%=k;
	if(sum[i]==0) ans++;
}
for(int i =2; i<=n; i++)
{
	cal[i]=cal[i-1]+i-1;
}
sort(sum+1,sum+1+n);
for(int i = 2; i<=n; i++)
{
	int cnt = 1;
	while(sum[i]==sum[i-1]) {cnt++; i++;}
	if(cnt>1) ans+=cal[cnt];
		
}
printf("%lld",ans);
}
