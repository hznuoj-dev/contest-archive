#include<iostream>
#include<string>
#include<algorithm>
//#include<bits/c++.std>
//#include<stdlibs>
using namespace std;

int main(void){
	int n;
	cin>>n;
	int t;
	char x, y;
	string s="", s0;
	int len=s.length();
	getchar();
	while(n--){
		getline(cin, s0);
		//getchar();
		//cout<<s0;
		//cout<<"t="<<t<<endl;
		t=int(s0[0])-48;
		if(t==1){
			//cin>>x;
			x=s0[2];
			s+=x; 
		}
		else if(t==2){
			//cin>>y;
			len=s.length();
			if(!s.empty()){
				string temp;
				for(int i=0;i<len-1;++i){
					temp[i]=s[i];
				}
				s=temp;
				s[len-1]=NULL;
				len--;
			}
			else{
				cout<<"The final string is empty"<<endl;
				break;
			}
		}
		else if(t==3){
			//cin>>x;
			x=s0[2];
			//getchar();
			//cin>>y;
			y=s0[4];
			for(int i=0;i<s.length();++i){
				if(s[i]==x){
					s[i]=y;
				}
			}
		}
		
	}
	cout<<s;
	
	/*
	5
1 a
1 b
1 c
3 a c
1 b
*/
}
