#include<iostream>
using namespace std;
int main(){
	int n[100005]={0};
	int k,v;
	cin>>k>>v;
	for(int i=0;i<k;i++){
		cin>>n[i];
	}
	long long sum=0,ans=0;
	for(int i=0;i<k;i++){
		sum=0;
		for(int j=i;j<k;j++){
			sum+=n[j];
			if(sum%v==0){
				//cout<<sum<<" "<<i<<" "<<j<<endl;
				ans++;
			}
		}
	}
    cout<<ans;
}
