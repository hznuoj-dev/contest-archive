#include<bits/stdc++.h>
using namespace std;

const int N=1e5+7,M=1e9+7;
int n;
vector<int> ch[N];
map<pair<int,int>,long long> cnt;

void dfs(int last,int now){
	cnt[{last,now}]++;
	for(int i=0;i<ch[now].size();i++){
		int next=ch[now][i];
		if(next==last) continue;
		dfs(now,next);
		cnt[{last,now}]+=cnt[{now,next}];
	}
}

void solve(){
	//cin>>n;
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		int u,v;
		//cin>>u>>v;
		scanf("%d%d",&u,&v);
		ch[u].push_back(v);
		ch[v].push_back(u);
	}
	dfs(-1,1);
	int q;
	//cin>>q;
	scanf("%d",&q);
	for(int i=0;i<q;i++){
		int x;
		//cin>>x;
		scanf("%d",&x);
		long long ans=0;
		/*for(int j=0;j<ch[x].size();j++){
			int y=ch[x][j];
			if(cnt[{x,y}]==0) cnt[{x,y}]=n-cnt[{y,x}];
			ans+=cnt[{x,y}];
			for(int k=j+1;k<ch[x].size();k++){
				int z=ch[x][k];
				if(cnt[{x,z}]==0) cnt[{x,z}]=n-cnt[{z,x}];
				ans+=cnt[{x,y}]*cnt[{x,z}];
			}
		}*/
		vector<long long> num;
		for(int j=0;j<ch[x].size();j++){
			int y=ch[x][j];
			if(cnt[{x,y}]==0) cnt[{x,y}]=n-cnt[{y,x}];
			ans+=cnt[{x,y}];
			num.push_back(cnt[{x,y}]);
		}
		for(int j=1;j<num.size();j++){
			num[j]+=num[j-1];
		}
		for(int j=num.size()-1;j>0;j--){
			int y=ch[x][j];
			ans+=cnt[{x,y}]*num[j-1];
		}
		//cout<<ans<<'\n';
		printf("%d\n",ans);
	}
}

int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int T=1;
	//cin>>T;
	while(T--) solve();
	return 0;
}
