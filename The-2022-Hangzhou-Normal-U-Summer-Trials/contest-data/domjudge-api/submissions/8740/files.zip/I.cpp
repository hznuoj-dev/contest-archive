#include<bits/stdc++.h>
using namespace std;
#define N 200005
#define mod 1000000007
#define int long long

int num[N];

int tri(int r,int c){
	return (c == 1 || c == r) ? 1 : (tri(r - 1,c - 1) + tri(r - 1,c)) % mod;
}

void solve(){
	int n,s,q,sum = 0,l,r;
	cin >> n >> s >> q;
	for(int i = 1;i <= n;i++) cin >> num[i],sum += num[i];
	for(int i = 1;i <= q;i++){
		cin >> l >> r;
		sum += (r - num[l]);
		num[l] = r;
		if(sum > s) cout << "0\n";
		else cout << tri(n + 1 + s - sum,s - sum + 1) << '\n';
	}
}

signed main(){
	ios::sync_with_stdio(0);
	int t = 1;
	while(t--) solve();
}
