#include <bits/stdc++.h>
using namespace std;
char c[1001][1100];
int n;
int xa,ya;int xb,yb;int vis[101][101];
void dfs(int x,int y){
	if(x>n||y>n||y<1||x<1)return ;
	if(vis[x][y])return ;
	if(c[x][y]=='*')return ;
	vis[x][y]=1;
	dfs(x+1,y);
	dfs(x-1,y);
	dfs(x,y+1);
	dfs(x,y-1);
}
int f[51][51][51][51];
//  a zai x y b zai zui xiao bushu
int x[5]={0,0,1,-1};
int y[5]={1,-1,0,0};
struct p{
	int a,b,c,d;
};
void solve(){
	p t;t.a=xa;t.b=ya;t.c=xb;t.d=yb;
	queue<p> q;f[xa][ya][xb][yb]=0;
	q.push(t);
	while(!q.empty()){
		p now=q.front();q.pop();
		p ne;
	    for(int i=0;i<4;i++){
	    	int nxa=now.a+x[i];
	    	int nya=now.b+y[i];
	    	int nxb=now.c+x[i];
	    	int nyb=now.d+y[i];
	    	if(c[nxa][nya]=='*')nxa=now.a,nya=now.b;
	    	if(c[nxb][nyb]=='*')nxb=now.c,nyb=now.d;
			if(nxa>n||nxa<1)nxa=now.a;
			if(nya>n||nya<1)nya=now.b;
			if(nxb>n||nxb<1)nxb=now.c;
			if(nyb>n||nyb<1)nyb=now.d;
	    	if(f[nxa][nya][nxb][nyb]==-1){
	    	f[nxa][nya][nxb][nyb]=(f[now.a][now.b][now.c][now.d]+1);
			q.push({nxa,nya,nxb,nyb});
			}
		}
	}
}
int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++){
		char ch;
		cin>>ch;
		c[i][j]=ch;
		if(ch=='a'){
			xa=i;ya=j;
		}
		if(ch=='b'){
			xb=i;yb=j;
		}
	}
	memset(f,-1,sizeof(f));
	dfs(xa,ya);
	if(!vis[xb][yb]){
		printf("no solution");
		return 0;
	}solve();int ans=1e9;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++){
		if(f[i][j][i][j]==-1)continue;
	//	printf("%d\n",f[i][j][i][j]);
		ans=min(ans,f[i][j][i][j]);
	}
	printf("%d\n",ans);
}
