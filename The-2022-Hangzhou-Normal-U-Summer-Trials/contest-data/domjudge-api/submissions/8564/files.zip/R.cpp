#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 4e5 + 10, mod = 1e9 + 7;
int dx[4] = {0, -1, 0, 1};
int dy[4] = {1, 0, -1, 0};
int mp[100][100], n;

int is(int x, int y){
	if(x < 1 || x > n || y < 1 || y > n) return 0;
	if(mp[x][y]) return 1;
	return 0;
}

struct node{
	int xa, ya, xb, yb;
};

int vis[55][55][55][55];
int dis[55][55][55][55];

void solve(){
	cin >> n;
	int xa, ya, xb, yb;
	for(int i = 1; i <= n; i++){
		for(int j = 1; j <= n; j++){
			char k;
			cin >> k;
			if(k == '*') mp[i][j] = 0; else mp[i][j] = 1;
			if(k == 'a'){
				xa = i;
				ya = j;
			}else if(k == 'b'){
				xb = i;
				yb = j;
			}
		}
	}
	int ans = 2e9;
	queue<node> q;
	q.push({xa, ya, xb, yb});
	vis[xa][ya][xb][yb] = 1;
	dis[xa][ya][xb][yb] = 0;
	while(!q.empty()){
		node t = q.front();
		q.pop();
		xa = t.xa;
		ya = t.ya;	
		xb = t.xb;
		yb = t.yb;
		if(xa == xb && ya == yb){
			ans = min(ans, dis[xa][ya][xb][yb]);
		}
		for(int i = 0; i < 4; i++){
			int txa = xa + dx[i], tya = ya + dy[i];
			if(!is(txa, tya)) txa = xa, tya = ya;
			int txb = xb + dx[i], tyb = yb + dy[i];
			if(!is(txb, tyb)) txb = xb, tyb = yb;
			if(!vis[txa][tya][txb][tyb]){
				vis[txa][tya][txb][tyb] = 1;
				dis[txa][tya][txb][tyb] = dis[xa][ya][xb][yb] + 1;
				q.push({txa, tya, txb, tyb});
			}
		}
	}
	if(ans == 2e9){
		cout << "no solution\n";
	}else{
		cout << ans << '\n';
	}
}

int main(){
	int T = 1;
	while(T--) solve();
	return 0;
}
