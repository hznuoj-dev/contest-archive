#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=5e5+10;
ll a[maxn],b[maxn],c[maxn];
//void solve(){
//	
//}
int main(){
	int n,q;
	cin>>n;
	cin>>a[1];
	for(int i=2;i<=n;i++){
		cin>>a[i];
		b[i-1]=a[i]-a[i-1];
		c[i-1]=c[i-2]+b[i-1];
	}
	sort(b+1,b+n);
	cin>>q;
	ll t,ans;
	for(int i=1;i<=q;i++){
		cin>>t;
		ans=t*n;
		int l=1,r=n-1;
		while(l<=r){
			int mid=(l+r)/2;
			if(t>=b[mid]){
				l=mid+1;
			}
			else r=mid-1;
		}
		l--;
		ans=ans+c[l]-l*t;
		cout<<ans<<"\n";
	}
	return 0;
}
