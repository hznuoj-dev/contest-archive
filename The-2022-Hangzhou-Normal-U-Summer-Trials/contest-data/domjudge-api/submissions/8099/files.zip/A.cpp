#include<bits/stdc++.h>
using namespace std;
#define yes (cout<<"YES\n")
#define no (cout<<"NO\n")
#define endl '\n'
//typedef long long ll;
#define int long long
void sxseven();
signed main() {
	ios::sync_with_stdio(false);
	int _=1;
	//cin >> _;
	while(_--) sxseven();
	return 0;
}
const int N=1e5+5;
struct node{
	int i;char x;
}a[N];
struct nn{
	int i;char x,y;
}b[N];
map<char,char> mp;
char find(char x){
	if(mp[x]==x) return x;
	return mp[x]=find(mp[x]);
}
void sxseven() {
	int n,k=0,m=0,op;char x,y;
	cin >> n;
	for(int i=1;i<=n;++i){
		cin >> op;
		if(op==3){
			cin >> x >> y;
			b[++m].i=i;
			b[m].x=x;
			b[m].y=y;
		}else if(op==2){
			--k;
		}else{
			cin >> x;
			a[++k].i=i;
			a[k].x=x;
		}
	}
	if(k==0){
		cout<<"The final string is empty";
		return;
	}
	string s="";
	for(int i='a';i<='z';++i) mp[i]=i;
	for(int i=k,j=m;i>=1;--i){
		while(a[i].i<=b[j].i){
			mp[b[j].x]=find(b[j].y);
			--j;
		}
		s+=find(a[i].x);
	}
	reverse(s.begin(),s.end());
	cout<<s;
}


