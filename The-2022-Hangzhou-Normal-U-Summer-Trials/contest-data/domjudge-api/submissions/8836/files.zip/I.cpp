#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define int ll
#define wtnnb ios::sync_with_stdio(false);//cin.tie(0);cout.tie(0);
const int N = 1e6+10;
const ll mo = 1e9+7;
int a[N];
ll b[N];
ll ss[N];
ll getans(ll t,ll n){
	if(t==0)return 1;
	else if(t<0)return 0;
	
	ll ans=ss[t];
	return ans;
}
signed main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int n,s,q;cin>>n>>s>>q;
    b[0]=1;
    for(int i=1;i<N;i++){
    	b[i]=b[i-1]*n-b[i-1]*n/2+1;
    	b[i]%=mo;
	}
	ss[0]=1;
	for(int i=1;i<=n;i++){
		ss[i]=ss[i-1]+b[i];
		ss[i]%=mo;
	}
    ll sum=0;
    for(int i=1;i<=n;i++){
    	cin>>a[i];
    	sum+=a[i];
    	
	}

    while(q--){
    	int x,v;cin>>x>>v;	
    	sum+=v-a[x];
    	a[x]=v;
    	cout<<getans(s-sum,n)%mo<<endl;
	}
}

