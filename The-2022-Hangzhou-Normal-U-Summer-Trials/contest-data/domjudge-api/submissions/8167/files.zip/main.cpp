#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

int n, p, s, k;
int a[maxn], f[maxn][6];
int pot[10];

void solve(){
    cin >> n >> p >> s;
    for(int i=1;i<=n;i++){
        cin >> a[i];
    }
    cin >> k;
    a[n+1] = p;
    memset(f, 0x7f, sizeof(f));
    f[1][k] = a[1];
    for(int i=1;i<=k;i++) pot[i] = 1;

    for(int i=2;i<=n;i++){
        for(int j=0;j<=k;j++){
            f[i][j] = f[i-1][j] + a[i] - a[i-1];

            for(int z=1;z<=k-j;z++){
                while(pot[z] < i && a[i] - a[pot[z]] > 1ll * s * z) pot[z]++;
                f[i][j] = min(f[i][j], f[pot[z]][j+z]);
            }
        }
    }
    int ans = p;
    for(int j=0;j<=k;j++) ans = min(ans, f[n][j] + p - a[n]);
    cout << ans << '\n';
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}