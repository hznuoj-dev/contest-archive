#include<bits/stdc++.h>

using namespace std;

#define INF 0x3f3f3f3f3f3f3f3f
#define io ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define PI acos(-1)
#define mem(a,b) memset((a),(b),sizeof(a));

typedef long long ll;
typedef unsigned long long ull;

string s,ss[1010];
int n,k;
int arr[27],cnt[1010][1010];

int main() {
	cin>>s;
	cin>>n;
	mem(arr,0);
	mem(cnt,0);
	for(int i=0;i<s.length();i++) {
		arr[s[i]-97]=i;
	}
	for(int i=0;i<n;i++) {
		cin>>ss[i];
		for(int j=0;j<ss[i].length();j++) {
			cnt[i][j]=arr[ss[i][j]-97];
		}
	}
	cin>>k;
	sort(ss,ss+n,[&](int i,int j){
		return arr[i]<arr[j];
	})
	for(int i=0;i<n;i++) {
		 cout<<ss[i]<<'\n';
	}
	return 0;
} 
