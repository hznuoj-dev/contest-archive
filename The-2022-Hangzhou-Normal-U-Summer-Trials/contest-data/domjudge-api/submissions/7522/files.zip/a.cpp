#include<iostream>
#include<string>
using namespace std;
string s;
int main(){
	getline(cin,s);
	int t=0;
	int a=0;
	for(long unsigned int i=0;i<s.length()-3;i++){
		a=s.find("hznu",i);
		if(a==-1){
			break;
		}
		i=a;
		t++; 
	}
	cout<<t<<endl;
	return 0;
} 
