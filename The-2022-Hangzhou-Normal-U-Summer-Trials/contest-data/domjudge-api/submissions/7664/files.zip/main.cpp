#include<bits/stdc++.h>
using namespace std;
using i64 = long long;
#ifdef ACM_LOCAL
const int N = 1e1 + 10;
#else
const int N = 1e5 + 10;
#endif
int a[N];
int main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    int n, k;
    scanf("%d%d", &n, &k);
    i64 sum = 0;
    map<int, int> cnt;
    cnt[0] = 1;
    i64 ans = 0;
    for(int i = 1;i <= n;i ++){
        scanf("%d", a + i);
        sum += a[i];
        int mod = sum % k;
        ans += cnt[mod];
        cnt[mod] ++;
    }
    printf("%lld\n", ans);

    return 0;
}