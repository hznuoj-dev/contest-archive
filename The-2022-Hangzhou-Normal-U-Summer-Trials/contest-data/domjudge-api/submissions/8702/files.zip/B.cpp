#include<iostream>
#include<cstdio>
#include<cstdlib>
#include<algorithm>
using namespace std;
int main(void){
	long long int n, q, t;
	long long int a[200007]={0};
	
	cin>>n;
	for(long long int i=0;i<n;++i){
		cin>>a[i];
	}

	cin>>q;
	while(q--){
		long long int ans=0;
		cin>>t;
		for(long long int i=0;i<n-1;++i){
			if(a[i]+t-1<a[i+1]){
				ans+=t;
			//	cout<<"i="<<i<<"ans0="<<ans<<endl;
			//	cout<<a[i]+t-1<<" "<<a[i+1]<<endl;
			}
			else {
				ans+=a[i+1]-a[i];
			//	cout<<a[i]+t-1<<" "<<a[i+1]<<endl;
			}
				
		}
		ans+=t;
		cout<<ans<<endl;
	}
	
	return 0;
}
