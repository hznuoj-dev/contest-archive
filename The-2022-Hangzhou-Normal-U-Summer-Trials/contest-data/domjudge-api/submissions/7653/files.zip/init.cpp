#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
ll a[500010], b[500010];
int main()
{
    ll n;
    cin >> n;
    for (ll i = 0; i < n; i ++) cin >> a[i];
    for (ll i = 0; i < n - 1; i ++) a[i] = a[i + 1] - a[i];
    b[0] = a[0];
    for (ll i = 1; i < n - 1; i ++) b[i] = b[i - 1] + a[i];
    ll q, t;
    cin >> q;
    while(q --)
    {
        ll ans, i;
        ans = 0; 
        cin >> t;
        i = lower_bound(a, a + n - 1, t) - a;
        if (i >= n - 1)
            ans = b[n - 2] + t;
        else 
            ans = b[i] - a[i] + (n - i) * t;
        cout << ans << endl;
    }
    system("pause");
}