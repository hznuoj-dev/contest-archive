#include<bits/stdc++.h>
using namespace std;
#define int long long 
const int N=5e3+10;
const int INF=2e18+1000;
const int SIZE=1000000+10;
const int mod=1e9+7;
int n,m,k;
map<int,int>mp;
int a[SIZE];
int sum[SIZE];
void solve(){
    cin>>n>>k;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    int ans=0;
    for(int i=1;i<=n;i++){
        sum[i]=(sum[i-1]+a[i])%k;
        ans+=mp[sum[i]];
        mp[sum[i]]++;
    }
    ans+=mp[0];
    cout<<ans<<endl;
    return ;
}
void inits(){}
signed main(){
    ios::sync_with_stdio(false);
    cin.tie(0); cout.tie(0);
    int ts=1;
    inits();
    while(ts--){
        solve();
    }
    return 0;
}