#include <cstdio>

int main()
{
	int n, k, i, j;
	scanf("%d%d", &n, &k);
	int a[100010], b, cnt = 0;
	a[0] = 0;
	for (i = 1; i <= n; i++)
	{
		scanf("%d", &b);
		a[i] = b % k + a[i - 1];
		a[i] = a[i] % k;
		if (a[i] == 0)
			cnt ++;
	}
	for (i = 1; i <= n; i++)
	{
		for (j = i + 1; j <= n; j++)
		{
			if (a[j] - a[i] == 0)
				cnt ++;
		}
	}
	printf("%d", cnt);
	return 0;
}
