#include<bits/stdc++.h>
using namespace std;
#define N 100005
#define int long long

int num[N],sum;
map<int,int> mp;

void solve(){
	int n,m;
	cin >> n >> m;
	mp[0]++;
	for(int i = 1;i <= n;i++){
		cin >> num[i];
		num[i] = (num[i] + num[i - 1]) % m;
		sum += mp[num[i]];
		mp[num[i]]++;
	}
	cout << sum;
}

signed main(){
	int t = 1;
	while(t--) solve();
}
