#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

int main(){
	ios::sync_with_stdio(false);
	string s;
	getline(cin,s);
	int cnt=0;
	for(int i=0;i<s.length();i++){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
			cnt++;
			i+=3;
		}
	}
	cout<<cnt<<endl;
	return 0;
}

