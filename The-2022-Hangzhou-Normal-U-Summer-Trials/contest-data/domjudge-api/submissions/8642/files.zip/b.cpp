#include<iostream>
#include<algorithm>
#include<cmath>
using namespace std;
int main(){
	string s;
	cin>>s;
	int n[150];
	for(int i=0;i<150;i++){
		n[i]=-1;
	}
	int ma=s.length();
	for(int i=0;i<ma;i++){
		n[s[i]-'a']=i;
	}
	int k;
	cin>>k;
	string n1[1002]={" "};
	for(int i=0;i<k;i++){
		cin>>n1[i];
	}
	int sum;
	cin>>sum;
	for(int i=0;i<k;i++){
		int x1=n1[i].length();
		for(int j=i+1;j<k;j++){
			int x2=n1[j].length();
			int x=max(x1,x2);
			for(int b=0;b<x;b++){
			if(n[abs(n1[i][b]-'a')]!=n[abs(n1[j][b]-'a')]){
				if(n[abs(n1[i][b]-'a')]<n[abs(n1[j][b]-'a')]){
				string f=n1[i];
				n1[i]=n1[j];
				n1[j]=f;
				break;	
				}else break;
			}
			/*if((b==min(x1,x2)-1)&&b!=0){
				if(x1<x2){
				string f=n1[i];	
				n1[i]=n1[j];
				n1[j]=f;
				break;
				} 
			 }*/
		}
		}
	}
		cout<<n1[k-sum];

}
