#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e5+10;
long long a[5*maxn]; 
long long b[5*maxn];
int main()
{
	long long n;
	scanf("%lld",&n);
	long long q;
	for(long long i=0;i<n;i++)
	{
		scanf("%lld",&a[i]);
	}
	for(long long i=0;i<n-1;i++)
	{
		b[i]=a[i+1]-a[i];
	}
	scanf("%lld",&q);
	while(q--)
	{
		long long ans=0;
		long long x;
		scanf("%lld",&x);
        ans=n*x;
		for(long long i=0;i<n-1;i++)
		{
			if(x>b[i])
			{
				ans=ans-(x-b[i]);
			}
		}
		printf("%lld\n",ans);
	}
	return 0;
 } 
 
