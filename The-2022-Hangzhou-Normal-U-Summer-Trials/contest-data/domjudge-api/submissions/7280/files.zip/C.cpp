#include<bits/stdc++.h>

using namespace std;
const int N=5e5+7;
typedef long long ll;

ll ans, n, q, t, k, a[N];
vector<ll> b;
void solve() {
	cin >> n;
	a[0]=0;
	for(int i=1;i<=n;i++) cin >> a[i];
	int pos = unique(a+1,a+1+n) - a - 1;
	for(int i=1;i<=pos;i++) b.push_back(a[i]-a[i-1]);
	cin >> q;
	while(q--) {
		cin >> t;
		if(t==0) {
			cout << 0 << endl; continue;
		}
		if(t==1) {
			cout << pos << endl; continue;
		}
		int cnt = lower_bound(b.begin(), b.end(), t) - b.begin();
		//cout << cnt << "##" << endl;
		ll ans = (pos-cnt+1)*t+a[cnt]-a[1];
		cout << ans << endl;
	}
}

int main(){
	ios :: sync_with_stdio(false); cin.tie(0); cout.tie(0); 
	int T=1;
	//cin >> T;
	while(T--)
		solve();
}
