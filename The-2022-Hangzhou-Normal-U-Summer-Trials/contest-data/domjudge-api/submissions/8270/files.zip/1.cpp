#include<bits/stdc++.h>
using namespace std;
const int N=1e5+10;
int n,k;
long long a[N],b[N],ans;
map <int,int> mp;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		b[i]=a[i]+b[i-1];
		mp[i]=-1;
	}
	for(int i=1;i<=n;i++){
		int g=i;
		if(mp[g]!=-1){
			while(mp[g]!=-1&&g<=n){
				ans++;
				g=mp[g]+1;
			}
			continue;
		}
		for(int j=g;j<=n;j++){	
			if((b[j]-b[g-1])%k==0){
				ans++;
				mp[g]=j;
				g=j+1;
				if(mp[g]!=-1){
					while(mp[g]!=-1&&g<=n){
						ans++;
						g=mp[g]+1;
					}
					break;
				}
			}
		}
	}
	cout<<ans<<'\n';
	return 0;
} 
