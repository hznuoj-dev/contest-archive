#include<bits/stdc++.h>
#define ll long long
const int inf=0x3f3f3f3f;
const int maxn=1e5+10;
using namespace std;
int main()
{
//	ios::sync_with_stdio(false);
//	cin.tie(0);
string a;
	cin>>a;
	int ans=0;
	for(int i=0;i<a.size();i++)
	{
		if(a[i]=='h'&&i+3<a.size())
		{
			if(a[i+1]=='z'&&a[i+2]=='n'&&a[i+3]=='u')
			{
				ans++;
				i+=3;
			}
		}
	}
	cout<<ans;
	return 0;
} 
 
 
