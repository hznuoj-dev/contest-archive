#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
map <char,char> p;
int main(){
	char s[maxn];
	int q,a,k=0;
	char x,y;
	cin>>q;
	for(int i=0;i<26;i++){
		p['a'+i]='a'+i;
	}
	for(int i=1;i<=q;i++){
		cin>>a;
		if(a==1){
			cin>>x;
			s[k]=x;
			k++;
		}
		else if(a==2){
			if(k>=1) k--;
		}
		else{
			cin>>x>>y;
			p[x]=y;
			for(int i=0;i<26;i++){
				if(p['a'+i]==x) p['a'+i]=y;
			}
		}
	}
	if(k!=0) for(int i=0;i<k;i++) cout<<p[s[i]];
	else cout<<"The final string is empty";
	return 0;
}
