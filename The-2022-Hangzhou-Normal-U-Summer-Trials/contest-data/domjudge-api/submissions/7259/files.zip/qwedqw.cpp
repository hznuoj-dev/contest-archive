#include<bits/stdc++.h>
using namespace std;
int sdd[26];
int judge(string s1, string s2){
    if(s1.length() < s2.length()){
    	for(int i = 0; i < s1.length(); i++){
    		if(s1[i] != s2[i]){
    			if(sdd[(int)(s1[i] - 'a')] < sdd[(int)(s2[i] - 'a')]){
    				return 1;
				}
				else  return 0;
			} 
		}
		return 1;
	}else{
		int v = 0;
		while(s1[v] == s2[v] && v < s2.length()){
			v++;
		}
		if(sdd[(int)(s1[v] - 'a')] < sdd[(int)(s2[v] - 'a')])  return 1;
		else  return 0;
	}
}
int main(){
	string s, a[1100];
	cin>>s;
	int n, k;
	cin>>n;
	memset(sdd, 0 ,sizeof(sdd));
	for(int i = 1; i < s.length(); i++){
		sdd[(int)(s[i] - 'a')] = sdd[(int)(s[i - 1] - 'a')] + 1;
	}
	for(int i = 1; i <= n; i++){
		cin>>a[i];
	}
	cin>>k;
	for(int i = 1; i <= n; i++){
	    for(int j = i + 1; j <= n; j++){
	    	if(judge(a[j], a[i])){
	    		swap(a[j], a[i]);
			}
		}
	}
	cout<<a[k]<<endl;
	return 0;
} 
