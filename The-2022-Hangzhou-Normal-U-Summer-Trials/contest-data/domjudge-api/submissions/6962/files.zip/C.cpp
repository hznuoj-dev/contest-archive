﻿#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
#define INF 0x3f3f3f
int main()
{
	string a;
	cin >> a;
	static int count;
	for (int i = 0; i <= int(a.length()-4); i++)
	{
		if (a[i] == 'h')
		{
			string s = "";
			for (int j = i; j <= i + 3; j++)
			{
				s =s+a[j];
			}
			if (s == "hznu")
				count++;
		}
	}
	cout << count;
}
  
