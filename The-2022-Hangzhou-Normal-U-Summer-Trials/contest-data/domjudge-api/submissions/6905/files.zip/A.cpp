﻿#include <stdio.h>

const int N = 1e5 + 10;

int main(void)
{
	char c[N];
	char a[6] = "hznu";
	char* p = a, * o = c, * o_be;
	int cou = 0, i;

	scanf("%s", c);
	while (*o)
	{
		p = a;
		if (*o == *p)
		{
			o_be = o;
			for (i = 0; i < 3; i++)
			{
				o++;
				p++;
				if (*o != *p)
					break;
			}
			if (i == 3)
				cou++;
			else
				o = o_be + 1;
			continue;
		}
		o++;
	}
	printf("%d", cou);


	return 0;
}