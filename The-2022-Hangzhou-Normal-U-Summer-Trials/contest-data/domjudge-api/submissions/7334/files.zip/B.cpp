#include<bits/stdc++.h>
using namespace std;
	string ans[1005],shunxu;
	int fal[27];
bool cmp(string a,string b){
	int q=0;
	while(a[q]){
		while(b[q]){
			if(fal[a[q]-'a']<fal[b[q]-'a']){
			return true;
			}
			else if(fal[a[q]-'a']>fal[b[q]-'a']){
			return false;
			} else if(fal[a[q]-'a']==fal[b[q]-'a']){
				q++;
				
			}
		}
	}
}
int main(){
//	ios::sync_with_stdio(false);
//	cin.tie(nullptr);
	cin>>shunxu;
	int k=0;
	while(shunxu[k]){
		fal[shunxu[k]-'a']=k;
		k++;
	}
	int t;
	cin>>t;
	for(int i=0;i<t;i++){
		cin>>ans[i];		
	}
	sort(ans,ans+t,cmp);
	int num;
	cin>>num;
	cout<<ans[num-1];
	 return 0;
}
