#include<iostream>
#include<algorithm>
#include<queue>
#include<vector>
#define ll long long
using namespace std;
const int N = 50 + 10;
int mov[4][2] = {{1, 0}, {0, 1}, {-1, 0}, {0, -1}};
int pre[N][N], now[N][N];
char mp[N][N];
int n;
inline bool judge(int x, int y){
    if(x < 1 || x > n || y < 1 || y > n) return false;
    return mp[x][y] != '*';
}
struct node
{
    int x, y;
    int cnt;
};

struct snode
{
    int x1, y1;
    int x2, y2;
    int cnt;
};
bool stat[N][N][N][N];
int bfs(node pa, node pb){
    int res = 0x3f3f3f3f;
    int cnt = 0;
    queue<snode> q;
    q.push({pa.x, pa.y, pb.x, pb.y});
    while(q.size()){
        snode cur = q.front();q.pop();
        for(int i = 0; i < 4; i++){
            int x1 = cur.x1 + mov[i][1];
            int y1 = cur.y1 + mov[i][0];
            int x2 = cur.x2 + mov[i][1];
            int y2 = cur.y2 + mov[i][0];
            if(!judge(x1, y1)){
                x1 = cur.x1;
                y1 = cur.y1;
            }
            if(!judge(x2, y2)){
                x2 = cur.x2;
                y2 = cur.y2;
            }
            if(!stat[x1][y1][x2][y2]){
                stat[x1][y1][x2][y2] = true;
                q.push({x1, y1, x2, y2, cur.cnt + 1});
                if(x1 == x2 && y1 == y2) res = min(res, cur.cnt + 1);
            }
        }
    }
    return res;
}
int main(){
    scanf("%d", &n);
    for(int i = 1; i <= n; i++)
        scanf(" %s", mp[i] + 1);
    node pa = {0, 0, 0}, pb = {0, 0, 0};
    for(int i = 1; i <= n; i++)
        for(int j = 1; j <= n; j++){
            if(mp[i][j] == 'a') pa = {i, j, 0};
            else if(mp[i][j] == 'b') pb = {i, j, 0};
        }
    int res = bfs(pa, pb);
    if(res >= 0x3f3f3f3f) puts("no solution");
    else printf("%d", res);
}