#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n,k;cin>>n>>k;
	vector<int> sum(n+1);
	for(int i=1;i<=n;i++){
		int x;cin>>x;
		sum[i]=(sum[i-1]+x)%k;
	}
	unordered_map<int,int> hs;
	hs[sum[0]]++;
	long long ans=0;
	for(int i=1;i<=n;i++){
		if(hs.count(sum[i])) ans+=hs[sum[i]];
		hs[sum[i]]++;
	}
	cout<<ans<<"\n";
	return 0;
}