#include <iostream>
#include <string>
using namespace std;
int n,k;
long long a[100005];
long long b[100005];
int main(){
	cin>>n;
	cin>>k;
	int t=0;
	int temp;
	for(int i=0;i<n;i++){
		cin>>temp;
		b[i]=temp;
		t+=temp;
		a[i]=t;
	}
	int cnt=0;
	for(int i=0;i<n;i++){
		for(int j=i;j<n;j++){
			if(a[j]%k==0){
				//cout<<a[j]<<endl;
				cnt++;
			}
			a[j]-=b[i];
		}
	}
	cout<<cnt;
}
