#include<bits/stdc++.h>
using namespace std;
int main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    string s;
    cin >> s;
    int siz = s.size();
    int ans = 0;
    for(int i = 0;i < siz - 3;i ++){
        if(s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') ans ++;
    }
    printf("%d\n", ans);

    return 0;
}