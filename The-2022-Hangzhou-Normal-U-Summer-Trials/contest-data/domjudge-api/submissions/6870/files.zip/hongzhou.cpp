#include <bits/stdc++.h>
using namespace std;
const int N =2e5+10; 
const int mod= 998244353; 
using namespace std;
typedef long long ll;
#define INF 0x3f3f3f3f3f3f3f3f  
ll a[N];
int main(){
   string s;
    cin>>s;
    ll ans=0;
	for(int i=0;i<s.length();i++)
	{    if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')
	     { ans++;
		 }
	 } 
	 cout<<ans<<endl;
	return 0;
}
