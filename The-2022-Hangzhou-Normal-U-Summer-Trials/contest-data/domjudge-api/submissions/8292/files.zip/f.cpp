#include<bits/stdc++.h>
using namespace std;

int sum[100010], a[100010];
map<pair<int, int>, int> m;
int n, k, ans = 0;

void dfs(int l, int r)
{
    if(l >= r)
        return;
    if((sum[r] - sum[l]) % k == 0 && m.find({l, r}) == m.end())
    {
        ans++;
        m[{l, r}] = 1;
    }
    dfs(l + 1, r);
    dfs(l, r - 1);
}

int main()
{
    cin >> n >> k;
    sum[0] = 0;
    for(int i = 1;i <= n;i++)
    {
        cin >> a[i];
        sum[i] = sum[i - 1] + a[i];
    }
    dfs(0, n);
    cout << ans;
    return 0;
}