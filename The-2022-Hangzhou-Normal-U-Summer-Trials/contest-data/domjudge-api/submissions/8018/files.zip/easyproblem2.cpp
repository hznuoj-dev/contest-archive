#include<bits/stdc++.h>
#define INF 0x3f3f3f3f
#define fr first
#define sc second
using namespace std;
int n;
pair<int,int>posa;
pair<int,int>posb;
int ans[55][55][55][55];
int mp[55][55];
int dir[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
struct node{
    int x1,y1,x2,y2;
};
bool judge(int x,int y){
    if(x<1||x>n||y<1||y>n||mp[x][y])return 0;
    return 1;
}
void solve(){
    memset(ans,INF,sizeof ans);
    cin>>n;
    for(int i=1;i<=n;i++){
        string s;
        cin>>s;
        for(int j=0;j<n;j++){
            if(s[j]=='*'){
                mp[i][j+1]=1;
            }else mp[i][j+1]=0;
            if(s[j]=='a')posa={i,j+1};
            if(s[j]=='b')posb={i,j+1};
        }
    }
    queue<node>q;
    q.push({posa.fr,posa.sc,posb.fr,posb.sc});
    ans[posa.fr][posa.sc][posb.fr][posb.sc]=0;
    int res=INF;
    while(!q.empty()){
        node top=q.front();
        q.pop();
        int x1=top.x1;
        int x2=top.x2;
        int y1=top.y1;
        int y2=top.y2;
        for(int i=0;i<=3;i++){
            int nx1=top.x1+dir[i][0];
            int ny1=top.y1+dir[i][1];
            int nx2=top.x2+dir[i][0];
            int ny2=top.y2+dir[i][1];
            if(!judge(nx1,ny1)){
                nx1=x1;
                ny1=y1;
            }
            if(!judge(nx2,ny2)){
                nx2=x2;
                ny2=y2;
            }
            if(ans[nx1][ny1][nx2][ny2]==INF){
                ans[nx1][ny1][nx2][ny2]=ans[x1][y1][x2][y2]+1;
                if(nx1==nx2&&ny1==ny2)res=min(res,ans[nx1][ny1][nx2][ny2]);
                q.push({nx1,ny1,nx2,ny2});
            }
        }
    }
    if(res==INF)cout<<"no solution\n";
    else cout<<res<<endl;
}
int main(){
    solve();
}