#include<bits/stdc++.h>
#define rson rt<<1|1
#define lson rt<<1
#define pb push_back
#define endl '\n'
#define x first
#define y second
#define LLINF 9223372036854775807
#define IOS ios::sync_with_stdio(0); cin.tie(0); 
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;

const int N=1010;

int n;
string s;
string a[N];

int find(char c){
    for(int i=0;i<26;i++){
        if(c==s[i])return i;
    }
}

bool cmp(string a,string b){
    int n=a.size(),m=b.size();
    for(int i=0;i<min(n,m);i++){
        if(a[i]!=b[i]){
            return find(a[i])<find(b[i]);
        }
    }
    return a.size()<b.size();
}

int main()
{  
	IOS 
    cin>>s;
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    sort(a+1,a+1+n,cmp);
    int k;
    cin>>k;
    cout<<a[k];
    return 0;
}