#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
#define PII pair<int, int>
const int N = 10010;

int main(){
    string s;
    getline(cin,s);
    int i,flag = 0;
    for(i=0;i<=s.size()-4;i++){
        if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
            flag = 1;
            break;
        }
    }
    printf("%d",flag);
    return 0;
}
