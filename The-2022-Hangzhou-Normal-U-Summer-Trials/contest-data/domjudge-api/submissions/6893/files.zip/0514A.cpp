#include<iostream>
#include<cstdio>
#include<string>
#include<cstring>

using namespace std;

string s;
int main () 
{
	getline(cin, s);
	int ans = 0;
	for (int i = 0; i < s.length(); i++) {
		if (s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') {
			ans++;
			i += 3;
		}
	}
	cout << ans;	
	return 0;
}
