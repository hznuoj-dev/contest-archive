#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
int main(){
	string a;
	cin>>a;
	if (a.length()<4){
		cout<<0;
		return 0;
	}
	else if (a.length()==4){
		if (a.substr(0,4)=="hznu"){
			cout<<1;
			return 0;
		}
	}
	else{
		long long sum=0;
		for(int i=0;i<a.length();i++){
			if (a[i]=='h'&&i+3<a.length()){
				if (a.substr(i,i+4)=="hznu"){
					sum++;
					i=i+3;
				}
			}
		}
		cout<<sum;
	}
	return 0;
}
