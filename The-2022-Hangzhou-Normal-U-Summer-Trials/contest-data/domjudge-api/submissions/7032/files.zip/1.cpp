#include<bits/stdc++.h>
using namespace std;

int chan[50];
string hjj[1005];

bool cmp(string a,string b)
{
	for(int i=0;i<min(a.size(),b.size());i++)
	{
		if(a[i]!=b[i])
		{
			return chan[a[i]-'a']<chan[b[i]-'a'];
		}
	}
	return a.size()<b.size();
}


int main()
{
	string s;
	cin>>s;
	for(int i=0;i<26;i++)
	{
		chan[s[i]-'a']=i;
	}
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>hjj[i];
	}
	sort(hjj,hjj+n,cmp);
	int k;
	cin>>k;
	cout<<hjj[k-1];
}
