#include<bits/stdc++.h>
using namespace std;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n,k;
	cin>>n>>k;
	if(k==1)
	{
		long long x;
		x=(1+n)*n/2;
		cout<<x;
		return 0;
	}
	int a[n+1]={0};
	long long int sum=0,ci,ci1=0;
	for(int k=1;k<=n;k++)
	{
		cin>>a[k];
		sum+=a[k];
	}
	if(sum<k)
	{
		cout<<"0";
		return 0;
	}
	int t=0;
	if(sum%k==0) t++;
	for(int i=0;i<n;i++)
	{
		ci1=ci1+a[i];
		ci=sum-ci1;
		for(int j=n;j>i;j--)
		{
			ci=ci-a[j];
			if(ci%k==0) 
			{
				t++;
			}
			if(ci<k) break;
		}
	}
	cout<<t;
	return 0;
}
