#include<bits/stdc++.h>
using namespace std;
const int N=2e5+10,M=1e9+7;
long long n,s,q,a[N],x,val,sum,t,ans;
long long f(long long b){
	long long h=1;
	for(int i=1;i<=b;i++){
		h=h*(n+1);
	}
	return h;
}
long long ff(long long b){
	long long h=1;
	for(int i=1;i<=b;i++){
		h=h*i;
	}
	h=h*n;
	return h;
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n>>s>>q;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum+=a[i];
	}
	while(q--){
		cin>>x>>val;
		sum+=val-a[x];
		t=s-sum;
		if(t==0){
			cout<<"1\n";
			continue;
		}
		if(t<0){
			cout<<"0\n";
			continue;
		}
		if(t==1){
			cout<<n+1<<'\n';
			continue;
		}
		ans=f(t)-ff(t);
		cout<<ans<<'\n';
	}
	return 0;
} 
