#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(0),cin.tie(0);
#define x first
#define y second
using namespace std;
typedef long long ll;
typedef pair<int,int>PII;
const int N=5e5+7,mod=1e9+7;

ll n,m;
ll a[N];
ll h[N],e[N],ne[N],idx;
ll cnt[N],sum[N];
bool st[N];

void add(ll a,ll b){
    e[idx]=b,ne[idx]=h[a],h[a]=idx++;
}

void dfs(int u){
    st[u]=true;
    cnt[u]=1;
    for(int i=h[u];~i;i=ne[i]){
        ll j=e[i];
        if(!st[j]){
            dfs(j);
            cnt[u]+=cnt[j];
            sum[u]+=cnt[j]*(n-1-cnt[j]);
        }
    }
    if(u!=1)sum[u]+=(n-cnt[u])*(cnt[u]-1);
}

void solve(){
    cin>>n;
    memset(h,-1,sizeof h);
    for(int i=1;i<n;i++){
        ll u,v;cin>>u>>v;
        add(u,v);add(v,u);
    }
    dfs(1);
    cin>>m;
    for(int i=1;i<=m;i++){
        ll s;cin>>s;
        cout<<sum[s]/2+n-1<<endl;
    }
}

int main(){
    IOS
    solve();
    return 0;
}