#include <cmath>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <queue>
#include <map>
#include <iomanip>
#include <vector>
#include <string>
#include <set>
#include <sstream>
#include <stack>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#pragma warning(disable:4996)
using namespace std;
#define endl '\n'
#define ll long long
#define io_speed_up ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
const int maxn = 1e6 + 9;
ll dif[maxn];
ll a[maxn];
ll pre[maxn];
int main(){
	io_speed_up;
	int n ;
	cin >> n;
	for(int i = 0;i < n;i++){
		cin >> a[i];
	}
	for(int i = 0;i<n - 1;i++){
		dif[i] = a[i + 1] - a[i];
	}
	pre[0] = dif[0];
	for(int i = 0;i<n-  1;i++){
		pre[i] = pre[i - 1] + dif[i];
	}
	int q;
	cin >>q;
	while(q--){
		int x;
		cin >>x;
		int pos = upper_bound(dif, dif +n - 1, x) - dif;
		if(pos == n - 1){
			cout << x + a[n - 1] - a[0] << endl;
		}
		else {
			ll ans = 0;
			ans += a[pos] - 1;
			ans += (n - 1 - pos) * x;
			ans += x + 1;
			ans -= a[0] + 1;
			cout << ans + 1 << endl;
		}
	}
	system("pause");
}
