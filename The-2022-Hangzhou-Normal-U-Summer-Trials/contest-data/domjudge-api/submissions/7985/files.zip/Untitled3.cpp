#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
using namespace std;

int main()
{
	Daybreak7;
	int n;
	cin>>n;
	long long a[n+10];
	long long b[n+10];
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
		if(i>0) b[i-1]=a[i]-a[i-1];
	}	
	int q;
	cin>>q;
	while(q--)
	{
		long long t;
		cin>>t;
		int pos=0;
		long long ans=0;
		for(int i=0;i<n;i++)
		{
			if(t-1<b[i]) 
			{
				pos=i;
				break;
			}
		}
		ans+=a[pos]-a[0]+(n-pos)*t;
		cout<<ans<<endl;
	}
}
