#include<iostream>
#include<string>
#include<algorithm>
//#include<bits/c++.std>
//#include<stdlibs>
using namespace std;

int main(void){
	int n;
	cin>>n;
	int t;
	char x, y;
	string s="", s0;
	int len=s.length();
	getchar();
	while(n--){
		getline(cin, s0);
		//getchar();
		//cout<<s0;
		//cout<<"t="<<t<<endl;
		t=int(s0[0])-48;
		if(t==1){
			//cin>>x;
			x=s0[2];
			s+=x; 
			len=s.length();
		}
		else if(t==2){
			/*len=s.length();
			if(!s.empty()){
				string temp;
				for(int i=0;i<len-1;++i){
					temp[i]=s[i];
				}
				s=temp;
				s[len-1]=NULL;
				len--;
			}*/
			if(len>0){
				string temp;
				for(int i=0;i<len-1;++i){
					temp[i]=s[i];
				}
				s=temp;
				len--;
			}
			else{
				cout<<"The final string is empty";
				s="";
				break;
			}
		}
		else if(t==3){
			//cin>>x;
			x=s0[2];
			//getchar();
			//cin>>y;
			y=s0[4];
			for(int i=0;i<s.length();++i){
				if(s[i]==x){
					s[i]=y;
				}
			}
		}
		
	}
	if(len==0)cout<<"The final string is empty";
	else 
		cout<<s;
	
	/*
	5
1 a
1 b
1 c
3 a c
1 b
*/
}
