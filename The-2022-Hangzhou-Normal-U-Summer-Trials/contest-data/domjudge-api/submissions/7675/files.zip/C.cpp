#include<bits/stdc++.h>
using namespace :: std;

const int maxn = 5e5+10;
const long long maxe=1e18;
int n;
vector<long long>a;
long long x;
long long q,qu;
int i;

int main(){
    ios::sync_with_stdio(0);
    cin.tie(0);cout.tie(0);
    cin>>n;
    for (i = 0; i < n; i++)
    {
        cin>>x;
        a.push_back(x);
    }
    cin>>q;
    while (q--)
    {
        cin>>qu;
        long long res=0;
        for (i = 0; i + 1 < n; i++)
        {
            if (a[i+1]-a[i]<=qu)
            {
                res+=a[i+1]-a[i];
            }else{
                break;
            }
        }
        res+=qu*(n-i);
        cout<<res<<endl;
    }
    return 0;
}