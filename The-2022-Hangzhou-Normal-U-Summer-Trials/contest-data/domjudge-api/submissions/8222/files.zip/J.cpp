#include<bits/stdc++.h>
using namespace std;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n;cin>>n;
	vector<int> fa(26);
	iota(fa.begin(),fa.end(),0);
	vector<tuple<int,int,int>> a(n);
	for(int i=0;i<n;i++){
		int opt;cin>>opt;
		if(opt==2) a[i]={2,0,0};
		if(opt==1){
			string c;cin>>c;
			a[i]={1,c[0]-'a',0};
		}
		if(opt==3){
			string x,y;cin>>x>>y;
			a[i]={3,x[0]-'a',y[0]-'a'};
		}
	}
	for(int i=n-1;i>=0;i--){
		if(get<0>(a[i])==3){
			int x=get<1>(a[i]),y=get<2>(a[i]);
			if(fa[y]==x) continue;
			fa[x]=fa[y];
		}else
		if(get<0>(a[i])==1){
			get<1>(a[i])=fa[get<1>(a[i])];
		}
	}
	vector<char> stk;
	for(int i=0;i<n;i++){
		if(get<0>(a[i])==1){
			stk.emplace_back(get<1>(a[i])+'a');
		}else
		if(get<0>(a[i])==2){
			stk.pop_back();
		}
	}
	if(stk.size()==0) return cout<<"The final string is empty\n",0;
	for(auto c:stk) cout<<c;
	cout<<"\n";
	return 0;
}