#include<bits/stdc++.h>
using namespace std;
int main(){
	string s;
	int res=0;
	cin>>s;
	int n=s.size();
	for(int i=0;i<n;i++){
		bool st=false;
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'&&i+3<n){
			res++;
		}
		// if(st) res++;
	}
	cout<<res<<endl;
}