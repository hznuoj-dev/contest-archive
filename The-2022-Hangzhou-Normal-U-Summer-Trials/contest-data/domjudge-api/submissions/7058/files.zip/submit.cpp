#include <bits/stdc++.h>
using namespace std;
using ll = long long;
#define int ll

const int N = 5000010;

ll a[N], v[N];
ll pre[N];

signed main ()
{
    int n; cin >> n;
    for (int i = 1; i <= n; i ++ ) cin >> a[i];
    for (int i = 1; i <= n - 1; i ++ ) v[i] = a[i+1] - a[i];
    for (int i = 1; i <= n - 1; i ++ ) pre[i] = pre[i-1] + v[i];
    sort(v + 1, v + n);
    int q; cin >> q; while(q -- ) {
        ll t; cin >> t;
        auto p = upper_bound(v + 1, v + n, t) - v;
//        cout << p << endl;
        ll sum = pre[p-1] + (n - 1 - (p - 1)) * t + t;
        cout << sum << endl;
    }
    return 0;
}