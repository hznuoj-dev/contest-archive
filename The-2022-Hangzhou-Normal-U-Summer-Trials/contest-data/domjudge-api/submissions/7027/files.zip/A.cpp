#include<bits/stdc++.h>

#define debug(x) cerr << #x << " = " << x << '\n'

using namespace std;

void solve() {
	string s;
	cin >> s;
	int ans = 0;
	for (int i = 0; i < s.size(); ++i) {
		if (i + 3 < s.size() && s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') ans++;
	}
	cout << ans << '\n';
}

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
