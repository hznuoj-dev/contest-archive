#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef long long ll;
const int N=2e5+7;
int a[N],pre[N],sum[N<<2];
int n,k;
int ans;
void pushup(int rt){
	sum[rt]=sum[rt<<1]+sum[rt<<1|1];
}

void build (int rt,int l,int r){
	if (l==r){
		sum[rt]=a[l];
		return;
	}
	int m=(l+r)>>1;
	build(rt<<1,l,m);
	build(rt<<1|1,m+1,r);
	pushup(rt);	
}

void quary(int L,int R,int l,int r,int rt){
	if (L<=l && r<=R){
		if (sum[rt]%k==0){
			if (l==r){
				ans++;
				return;
			}
			else{
				ans++;
			}
		}
		else {
			if (l==r){
				return;
			}
		}		
	}
	int m=(l+r)>>1;
	if (L<=m) quary(L,R,l,m,rt<<1);
	if (R>m) quary(L,R,m+1,r,rt<<1|1);
//	return ans;
}


void solve(){
	cin >> n >> k;
	for (int i=1;i<=n;i++){
		cin >> a[i];
	}
	sort(a+1,a+1+n);
	
	int sum1=0;
	for (int i=1;i<=n;i++){
		if (i==((n+1)/2)+1) continue; 
		for (int j=1;j<=n<<2;j++) sum[j]=0;
		build(1,i,n);
		ans=0;
		quary(i,n,i,n,1);	
		sum1+=ans;		
	}

	cout << sum1 << '\n';
	

}

signed main(){
	ios::sync_with_stdio(0);
	int t=1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}

