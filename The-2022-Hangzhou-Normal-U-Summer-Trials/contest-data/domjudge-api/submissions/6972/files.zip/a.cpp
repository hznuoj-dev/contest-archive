#include <cmath>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <queue>
#include <map>
#include <iomanip>
#include <vector>
#include <string>
#include <set>
#include <sstream>
#include <stack>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#pragma warning(disable:4996)
using namespace std;
#define endl '\n'
#define ll long long
#define io_speed_up ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
map<char, int>base;
struct info{
	string s;
	bool operator < (const info x){
		if(x.s.size() != s.size()){
			return x.s.size() > this->s.size();
		}
		for(int i = 0 ;i < s.size();i++){
			if(x.s[i] != s[i])return base[x.s[i]] > base[s[i]];
		}
	}
}a[1005];
int main(){
	io_speed_up;
	for(int i = 0 ;i < 26;i++){
		char x;
		cin >> x;
		base[x] = i;
	}
	int n ;
	cin >> n;
	for(int i = 0; i< n;i++){
		cin >> a[i].s;
	}
	sort(a, a + n);
	int k;
	cin >> k;
	cout <<  a[k - 1].s;
}
