#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
using namespace std;

int main()
{
	Daybreak7;
	string s;
	cin>>s;
	int sum=0;
	int len=s.length();
	for(int i=0;i<len-3;i++)
	{
		if(s.substr(i,4)=="hznu")
			sum++;
	}
	cout<<sum;
}
