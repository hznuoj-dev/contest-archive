#include<bits/stdc++.h>
#define tt(i) cout<<"test: "<<i<<'\n';
using namespace std;
typedef long long ll;

struct tr{
	int ft,ct;
	vector<int>son;
}t[100007];
int count(int v){
	tt(3)
	if(t[v].ct!=0) return t[v].ct;
	int len=t[v].son.size();
	if(len==0) return 0;
	int cntt=0;
	for(int i=0;i<len;++i){
		cntt+=count(t[v].son[i]);
	}
	return t[v].ct=cntt;
}
int n,f,to;

int main(){
	cin>>n;tt(1)
	for(int i=1;i<=n;++i){
		scanf("%d%d",&f,&to);
		(t[f].son).push_back(to);
		t[to].ft=f;
	}
	tt(2)
	count(1);
	
	int _,q;
	cin>>_;
	while(_--){
		scanf("%d",&q);
		printf("%d\n",n-1+(t[q].ct)*(n-t[q].ct-1));
	}
	tt(4)
	return 0;
}
