#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int  maxn = 2e5 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 52;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}


ll a[maxn];
ll fac[maxn], inv[maxn];
ll binom(ll n, ll m) {
    return fac[n] * inv[m] % mod * inv[n - m] % mod;
}
void solve(){
    ll n, s, q;
    cin >> n >> s >> q;
    fac[0] = fac[1] = 1;
    for(int i = 2; i < maxn; ++i) {
        fac[i] = fac[i - 1] * i % mod;
    }
    inv[maxn - 1] = qpow(fac[maxn - 1], mod - 2);
    for(int i = maxn - 2; i >= 0; --i) {
        inv[i] = inv[i + 1] * (i + 1) % mod;
    }
    ll sum = 0;
    for(int i = 1; i <= n; ++i) {
        cin >> a[i];
        sum += a[i];
    }
    while(q -- > 0) {
        ll x, val;
        cin >> x >> val;
        sum += val - a[x];
        a[x] = val;
        s -= sum;
        if(s < 0) {
            cout << 0 << '\n';
        } else if(s == 0) {
            cout << 1 << '\n';
        } else {
            cout << binom(s + n, n) << '\n';
        }
        s += sum;
    }
}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}