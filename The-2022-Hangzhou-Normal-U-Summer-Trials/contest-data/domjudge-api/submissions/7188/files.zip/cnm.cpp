#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=1e3+7;
string s;
int a[maxn];
string st[maxn];
int re[maxn];
bool cmp(string s1, string s2){
	int n1=s1.size(), n2=s2.size();
	for(int i=0;i<min(n1,n2);i++){
		if(a[s1[i]-'a']>a[s2[i]-'a']){
			return s1<s2;
		}
		if(a[s1[i]-'a']<a[s2[i]-'a']){
			return s2<s1;
		}
	}
	if(n1>n2){
		return s2<s1;
	}
	if(n1<n2){
		return s1<s2;
	}
}
signed main(){
	cin>>s;
	for(int i=0;i<s.size();i++){
		a[s[i]-'a']=i+1;
	}
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		cin>>st[i];
	}
	sort(st+1,st+n+1,cmp);
//	for(int i=1;i<=n;i++){
//		cout<<st[i]<<endl;
//	}
	int k;cin>>k;
	cout<<st[k]<<endl;
} 
