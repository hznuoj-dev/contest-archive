#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int s1[500]={0};
bool cmp(string x,string y){
	int t,p=0;
	t=min(x.length(),y.length());
	for(int i=0;i<t;i++){
		if(s1[x[i]]<s1[y[i]]){
			p=1;
			break;
		}
		else
		if(s1[x[i]]>s1[y[i]])
		{
			p=2;
			break;
		}
		
	}
	if(p==0)
	{
		if(x.length()<y.length()){
			return x<y;
		}
		else
		if(x.length()>y.length())
		{
			return y<x;
		}
	}
	else
	if(p==1){
		return x>y;
	}
	else
	if(p==2)
	{
		return y>x;
	}
}
int main()
{
	string s,a[1009];
	cin>>s;
	for(int i=0;i<26;i++){
		s1[s[i]]=i+1;
	}
	int n,k;
	scanf("%d",&n);
	getchar();
	for(int i=0;i<n;i++){
		getline(cin,a[i]);
	} 
	scanf("%d",&k);
	sort(a,a+n,cmp);
	cout<<a[k-1];
	return 0;
 } 
