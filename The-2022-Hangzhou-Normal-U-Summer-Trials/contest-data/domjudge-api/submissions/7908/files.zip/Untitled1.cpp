#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 1000000
ll a[maxn];
ll dis[maxn];
//ll t[maxn];
int main()
{
	ll n,q,i,j,*post,idxt,temp,ans,t;
	cin>>n;
	for(i=0;i<n;i++)
	{
		cin>>a[i];
	}
	cin>>q;
	for(j=0,i=0;i<n-1;i++,j++)
	{
		dis[j]=a[i+1]-a[i];
	}
	for(i=0;i<q;i++)
	{
		cin>>t;
		temp=t-1;
		post=upper_bound(dis,dis+n-1,temp);
		idxt=distance(dis,post);
//		cout<<"*t"<<t<<endl;
//		cout<<idxt<<endl; 
//		cout<<n-idxt<<endl; 
//		cout<<a[idxt]-a[0]<<endl; 
		ans=t*(n-idxt)+a[idxt]-a[0];
		cout<<ans<<endl;
	}
	
} 
