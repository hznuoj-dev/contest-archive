#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
using namespace std;

signed main()
{
	Daybreak7;
	int q;
	cin>>q;
	string s;
	while(q--)
	{
		int a;
		char x,y;
		cin>>a;
		int len;
		if(a!=1) len=s.length();
		if(a==1)
		{
			cin>>x;
			s+=x;
		}
		else if(a==2)
		{
			if(len>=1)
				s=s.substr(0,len-1);
		}
		else
		{
			cin>>x>>y;
			for(int i=0;i<len;i++)
				if(s[i]==x) s[i]=y;
		}
	}
	if(s=="") cout<<"The final string is empty"<<endl;
	else cout<<s;
}
