#include<iostream>
#include<algorithm>
#define ll long long
using namespace std;
const int N = 1e5 + 10;
struct node
{
    int l, r;
    bool lock;
    ll g, dtag, mtag;
}tr[N << 2];
ll gcd(ll a, ll b){
    if(b) return gcd(b, a % b);
    return a;
}
void pushup(int u){
    tr[u].g = gcd(tr[u << 1].g, tr[u << 1 | 1].g);
    tr[u].lock = tr[u << 1].lock | tr[u << 1 | 1].lock;
}
void pushdown(int u){
    if(tr[u].dtag == 1 && tr[u].mtag == 1) return;
    if(tr[u].l == tr[u].r){
        tr[u].dtag = 1;
        tr[u].mtag = 1;
        return;
    }
    int m = tr[u].mtag, d = tr[u].dtag;
    tr[u].dtag = tr[u].mtag = 1;
    if(tr[u << 1 | 1].l == tr[u << 1 | 1].r && tr[u << 1 | 1].lock){
        tr[u << 1 | 1].dtag = 1;
        tr[u << 1 | 1].mtag = 1;
    }else{
        tr[u << 1 | 1].g = tr[u << 1 | 1].g * m / d;
        tr[u << 1 | 1].mtag *= m;
        tr[u << 1 | 1].dtag *= d;
    }
    if(tr[u << 1].l == tr[u << 1].r && tr[u << 1].lock){
        tr[u << 1].dtag = tr[u << 1].mtag = 1;
    }else{
        tr[u << 1].g = tr[u << 1].g * m / d;
        tr[u << 1].mtag *= m;
        tr[u << 1].dtag *= d;
    }
}
void build(int u, int l, int r){
    tr[u] = {l, r, false, 1, 1, 1};
    if(l == r) return;
    int mid = l + r >> 1;
    if(l <= mid) build(u << 1, l, mid);
    if(r > mid) build(u << 1 | 1, mid + 1, r);
}
bool check(int u, int l, int r, ll k){
    if(tr[u].l >= l && tr[u].r <= r){
        if(tr[u].g % k) return false;
        return true;
    }
    bool res = true;
    int mid = tr[u].l + tr[u].r >> 1;
    pushdown(u);
    pushup(u);
    if(l <= mid) res &= check(u << 1, l, r, k);
    if(r > mid) res &= check(u << 1 | 1, l, r, k);
    return res;
}
void div(int u, int l, int r, ll k){
    if(tr[u].l >= l && tr[u].r <= r){
        if(tr[u].l == tr[u].r && tr[u].lock){
            tr[u].dtag = tr[u].mtag = 1;
            return;
        }
        tr[u].g /= k;
        tr[u].dtag *= k;
        return;
    }
    int mid = tr[u].l + tr[u].r >> 1;
    pushdown(u);
    if(l <= mid) div(u << 1, l, r, k);
    else div(u << 1 | 1, l, r, k);
    pushup(u);
}
void flip(int u, int x){
    if(tr[u].l == tr[u].r && tr[u].l == x){
        tr[u].lock = !tr[u].lock;
        return;
    }
    int mid = tr[u].l + tr[u].r >> 1;
    pushdown(u);
    if(x <= mid) flip(u << 1, x);
    else flip(u << 1 | 1, x);
    pushup(u);
}
void mul(int u, int l, int r, ll k){
    if(tr[u].l >= l && tr[u].r <= r){
        if(tr[u].l == tr[u].r && tr[u].lock){
            tr[u].mtag = tr[u].dtag = 1;
            return;
        }
        tr[u].g *= k;
        tr[u].mtag *= k;
        return;
    }
    int mid = tr[u].l + tr[u].r >> 1;
    pushdown(u);
    if(l <= mid) mul(u << 1, l, r, k);
    if(r > mid) mul(u << 1 | 1, l, r, k);
    pushup(u);
}
int main(){
    int n, m;
    scanf("%d%d", &n, &m);
    build(1, 1, n);
    char op[5];
    while(m--){
        scanf(" %s", op);
        if(*op == 'f'){
            int x;
            scanf("%d", &x);
            flip(1, x);
        }else if(*op == 'd'){
            int l, r; 
            ll k;
            scanf("%d%d%lld", &l, &r, &k);
            if(check(1, l, r, k)){
                puts("YES");
                div(1, l , r, k);
            }else{
                puts("NO");
            }
        }else{
            int l, r;
            ll k;
            scanf("%d%d%lld", &l, &r, &k);
            mul(1, l, r, k);
        }
    }
}