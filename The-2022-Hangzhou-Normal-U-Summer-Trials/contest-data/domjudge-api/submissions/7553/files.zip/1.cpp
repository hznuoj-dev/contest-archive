#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
long long n,a[N],b[N],c[N],q,t,g,w,ans,f;
int l,r,mid;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(i>=2){
			b[++g]=a[i]-a[i-1];
		}
	}
	for(int i=1;i<n;i++){
		c[i]=c[i-1]+b[i];
	}
	cin>>q;
	while(q--){
		f=0;
		cin>>t;
		l=1,r=n-1;
		if(b[n-1]<t){
			f=n-1;
			ans=(n-f)*t;
			ans+=c[f];
			cout<<ans<<'\n';
			continue;
		}
		while(l<=r){
			mid=(l+r)/2;
			if(b[mid]>=t&&b[mid-1]<t){
				f=mid-1;
				break;
			}
			if(b[mid]>=t&&b[mid-1]>=t){
				r=mid-1;
			}
			if(b[mid]<t){
				l=mid+1;
			}
		}
		ans=(n-f)*t;
		ans+=c[f];
		cout<<ans<<'\n';
	}
	return 0;
} 
