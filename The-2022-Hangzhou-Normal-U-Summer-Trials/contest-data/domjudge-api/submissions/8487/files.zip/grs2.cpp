#include<bits/stdc++.h>
#define rson rt<<1|1
#define lson rt<<1
#define pb push_back
#define endl '\n'
#define x first
#define y second
#define LLINF 9223372036854775807
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;

const int N=1e6+10;

ll n,p,s;
ll a[N];
ll b[N];
int hav;
ll dp[N][7];
ll ans;
ll sum[N];

int main()
{  
    IOS
    cin>>n>>p>>s;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=1;i<n;i++)b[i]=a[i+1]-a[i],sum[i]=sum[i-1]+b[i];
    ans=a[1]+p-a[n];
    cin>>hav;
    for(int i=1;i<n;i++){
        for(ll j=1;j<=hav;j++){
            for(ll k=0;k<=j;k++){
                dp[i][j]=max(dp[i][j],dp[i-1][j]);
                if(k==0){
                    continue;
                }
                int l=1,r=i;
                ll val=k*s;
                while(l<r){
                    int mid=(l+r)>>1;
                    if(val>=sum[i]-sum[mid-1])r=mid;
                    else l=mid+1;
                }
                if(sum[i]-sum[r-1]<=val)
                dp[i][j]=max(dp[i][j],dp[r-1][j-k]+sum[i]-sum[r-1]);
            }
        }
    }
    ll mx=0;
    for(int i=1;i<n;i++){
        for(int j=0;j<=hav;j++){
            mx=max(mx,dp[i][j]);
        }
    }
    cout<<ans+sum[n-1]-mx<<endl;
    return 0;
}