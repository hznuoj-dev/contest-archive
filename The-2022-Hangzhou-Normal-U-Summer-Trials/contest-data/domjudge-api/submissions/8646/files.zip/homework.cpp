//My big big moon , I love you so much that I feel lonely.
#pragma GCC optimize(3,"Ofast","inline")
#include<bits/stdc++.h>

#define SIZ(a) (long long)a.size()
#define endl '\n'
#define AC return
#define fr first 
#define sc second
#define mem(a,x) memset(a,x,sizeof(a))
#define multi long long  _;   cin >> _; while (_--)INIT(),
#define debug(a) cout << #a << ": " << a << endl
#define out(a) cout << a << endl
#define pb push_back
#define br break 
#define cot continue
#define lc u << 1 
#define rc u << 1 | 1
#define YES cout << "YES" << endl 
#define NO cout << "NO" << endl
#define lowbit(x) (x & (-x))
#define INF 0x3f3f3f3f
#define all(a) (a).begin(),(a).end()
using namespace std;typedef unsigned long long LL;typedef long long ll;const double eps = 1e-7;
const ll maxn = 1e6 + 9;const ll mod = 1e9 + 7;const double pi = acos(-1.0);const ll bas = 13333;
ll qpow(ll base, ll power) {ll result = 1;while (power > 0) {if (power & 1) {result = result * base % mod;}power >>= 1;base = (base * base) % mod;}return result%mod;}
ll gcd(ll a,ll b){return b>0?gcd(b,a%b):a;}ll lcm(ll a,ll b){return a*b/gcd(a,b);}
inline void read(ll &x){x=0;ll f=1;char ch=getchar();	while (!isdigit(ch)){if (ch=='-') f=-1;ch=getchar();}while (isdigit(ch)){x=x*10+ch-48;ch=getchar();}x=x*f;}
ll f[maxn],invf[maxn];
void Calc() {f[0]=f[1]=invf[0]=invf[1]=1;for(ll i=2;i<maxn;i++)f[i]=f[i-1]*i%mod,invf[i]=(mod-mod/i)*invf[mod%i]%mod; for(ll i=2;i<maxn;i++) invf[i]=invf[i-1]*invf[i]%mod;}
ll C(ll n, ll m) {if(n<m) return 0;return f[n]*invf[m]%mod*invf[n-m]%mod;}
//ll s[maxn];void idsu(ll n){for(ll i=0;i<=n;i++)s[i]=i;}ll find(ll x){return x==s[x]?s[x]:s[x]=find(s[x]);}void onion(ll x,ll y){x=find(x);y=find(y);if(x==y)return;s[x]=y;}
void INIT(){}
void init(){}
ll a[maxn];
ll sum[maxn];
void solve(){
    ll n,s,q;
    cin>>n>>s>>q;
    sum[0]=1;
    ll num=0;
    for(ll i=1;i<maxn;i++){
        sum[i]=sum[i-1]+C(i+n-1,n-1);
        sum[i]=(sum[i]+mod)%mod;
    }
    for(ll i=1;i<=n;i++)cin>>a[i],num+=a[i];
    while(q--){
        ll x,val;
        cin>>x>>val;
        num-=a[x];
        num+=val;
        a[x]=val;
        ll now=s-num;
        if(now<0){
            out(0);
            cot;
        }
        out(sum[now]);
    }
    AC;
}
signed main()
{
    std::ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    Calc();
    init();
    //multi 
    solve();
    return 0;
}