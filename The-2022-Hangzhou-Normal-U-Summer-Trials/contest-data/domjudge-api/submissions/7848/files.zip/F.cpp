#include <stdio.h>
#include <string.h>

const int N = 1e5 + 10;

int main(void)
{
	int n, i, j;
	long k, cou = 0, sum;
	int a[500010];

	scanf("%d %ld", &n, &k);
	for (i = 0; i < n; i++)
	{
		scanf("%d", &a[i]);
	}
	if (k == 1)
		cou = (long)n * (n + 1) / 2;
	else
		for (i = 0; i < n; i++)
		{
			sum = 0;
			for (j = i; j < n; j++)
			{
				sum += (long)a[j];
				if (sum % k == 0)
					cou++;
			}
		}
	printf("%ld", cou);

	return 0;
}