#include<stdio.h>

int main(){
	int n,q;
	int i;
	scanf("%d",&n);
	long long a[n],b[n-1],c[n-1];
	for(i=0;i<n;i++){
		scanf("%lld",&a[i]);
	}
	scanf("%d",&q);
	for(i=0;i<n-1;i++){
		b[i] = a[i+1]-a[i];
	}
	c[0] = b[0];
	for(i=1;i<n-1;i++){
		c[i] = c[i-1]+b[i];
	}
	while(q--){
		long long t,l,r,m,ans=0;
		scanf("%lld",&t);
		l = 0;
		r = n-2;
		m = (l+r)/2;
		if(t>b[r]){
			ans = c[r]+t;
		}else if(t<b[l]){
			ans = t*r+t;
		}else{
			while(!(t>=b[l]&&t<=b[r]&&r-l==1)){
				if(t>b[m]){
					l = m;
					m = (l+r)/2;
				}else if(t<b[m]){
					r = m;
					m = (l+r)/2;
				}else{
					ans = c[m];
					break;
				}
			}
		}
		if(ans==0){
			ans = c[l]+(n-r)*t;
		}
		printf("%lld",ans);
		if(q){
			printf("\n");
		}
	}
	return 0;
}
