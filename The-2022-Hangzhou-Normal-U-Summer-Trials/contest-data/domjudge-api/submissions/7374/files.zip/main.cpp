#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

int n, k;
int a[maxn];

void solve(){
    cin >> n >> k;
    for(int i=1;i<=n;i++) cin >> a[i];
    map<int, int> cnt;
    cnt[0]++;
    ll sum = 0, ans = 0;
    for(int i=1;i<=n;i++){
        sum += a[i];
        ans += cnt[sum % k];
        cnt[sum % k]++;
    }
    cout << ans << '\n';
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}