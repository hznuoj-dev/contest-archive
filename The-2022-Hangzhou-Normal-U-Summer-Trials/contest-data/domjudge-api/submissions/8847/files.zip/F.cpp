#include <iostream>
using namespace std;
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#define int long long 
int main() 
{
    int sums[10001];
    int right, left;
    int sumSize;
    int k;
    cin >> sumSize>>k;
    int i;
    for (i = 0; i < sumSize; i++)
    {
        cin >> sums[i];
    }
    int TotalSum = 0;
    int count = 0;
    for (right = sumSize - 1; right >= 0; right--) {
        for (left = right; left >= 0; left--) {
            TotalSum = TotalSum + sums[left];
            if (TotalSum % k==0) {
                count++;
            }
        }
        TotalSum = 0;
    }
    cout << count << endl;
}
