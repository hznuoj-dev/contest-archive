#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(0),cin.tie(0);
#define x first
#define y second
using namespace std;
typedef long long ll;
typedef pair<int,int>PII;
const int N=2e5+7,mod=1e9+7;

int n,m;
int a[N];

void solve(){
    string s;cin>>s;
    int cnt=0;
    for(int i=0;i<s.length();i++){
        if(i+3<s.length()){
            if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')cnt++;
        }
    }
    cout<<cnt;
}

int main(){
    IOS
    //int T;cin>>T;
    //while(T--)
        solve();
    return 0;
}