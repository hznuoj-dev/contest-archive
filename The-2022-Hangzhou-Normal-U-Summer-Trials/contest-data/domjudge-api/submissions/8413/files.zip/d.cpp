#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10;
vector<int>a[N];
ll siz(int b,int x){
	ll l=a[b].size(),sum=1;
	if(l==1)return 1;
	for(int i=0;i<l;i++){
		if(a[b][i]!=x)sum+=siz(a[b][i],b);
	}
	return sum;
}
void solve(){
	int n,k,q,x,u,v;
	scanf("%d",&n);
	for(int i=1;i<n;i++){
		scanf("%d%d",&u,&v);
		a[u].push_back(v);
		a[v].push_back(u);
	}
	scanf("%d",&q);
	while(q--){
		scanf("%d",&x);
		ll ans=0,l=a[x].size();
		for(int i=0;i<l;i++){
			ll si=siz(a[x][i],x);
			ans+=si;
			for(int j=i+1;j<l;j++){
				ans+=si*(siz(a[x][j],x));
			}
		}
		printf("%lld\n",ans);
	}
}
int main(void){
	int t=1;
	//scanf("%d",&t);
	while(t--)solve();
	return 0;
}
