#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 1e5+10;


void solve(){
	int n; cin >> n;
	vector<ll>a(n+1,0);
	vector<ll>d;
	for(int i=1;i<=n;i++) cin >> a[i];
	for(int i=2;i<=n;i++) d.push_back(a[i]-a[i-1]);
	int q; cin >> q;
	while(q--){
		ll t; cin >> t;
		int m=lower_bound(d.begin(),d.end(),t)-d.begin();
		ll ans;
		if(m==(int)d.size()){
			cout << a[n]-a[1]+t;
			continue;
		}
		if(d[m]==t)
			ans=(a[m+2]-a[1])+1ll*(n-(m+1))*t;
		else 
			ans=(a[m+1]-a[1])+1ll*(n-m)*t;
		cout << ans << endl;
	}
	
}
/*


*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
