#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
double a[3030],b[3030];
int v[3030];
struct node{
	int id;
	double x,y,w;
	bool operator < (const node &k ) const{
		return k.w<w;
	}
};
priority_queue<node>q;
double v0,v1,v2,v3,v4;
double check(int x,int y){
	double sp=0;
	int fl=0;
	if(a[x]>=1&&a[y]>=1&&b[x]>=1&&b[y]>=1) sp=max(sp,v1),fl=1;
	if(a[x]<=-1&&a[y]<=-1&&b[x]>=1&&b[y]>=1) sp=max(sp,v2),fl=1;
	if(a[x]<=-1&&a[y]<=-1&&b[x]<=-1&&b[y]<=-1) sp=max(sp,v3),fl=1;
	if(a[x]>=1&&a[y]>=1&&b[x]<=-1&&b[y]<=-1) sp=max(sp,v4),fl=1;
	if(fl) return sp;
	else return v0;
}
double c[3030];
void solve(){
	int p,n,s,i,j,m,ans=0;
	cin>>n;
	double sp,x,y,k;
	cin>>v1>>v2>>v3>>v4>>v0;
	int S,T;
	cin>>S>>T;
	for(i=1;i<=n;i++) scanf("%lf%lf",a+i,b+i);
	q.push({S,a[S],b[S],0});
	while(!q.empty()){
		node k=q.top();
		q.pop();
		if(v[k.id]) continue;
		v[k.id]=1;
		c[k.id]=k.w;
		//printf("%d %.8f\n",k.id,k.w);
		for(i=1;i<=n;i++){
			if(v[i]) continue;
			sp=check(i,k.id);
			x=sqrt((a[i]-a[k.id])*(a[i]-a[k.id])+(b[i]-b[k.id])*(b[i]-b[k.id]));
			x=x/sp;
			q.push({i,a[i],b[i],k.w+x});
		}
	}
	printf("%.8f",c[T]);
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
/*
8
1 a
1 b
1 c
3 c d
2
1 c
3 a c
3 c e
*/
//B=clock();
	//printf("%f\n",(double)(B-A)/CLOCKS_PER_SEC);
