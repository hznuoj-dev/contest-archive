#include <bits/stdc++.h>
using namespace std;
const int maxn=1e3+10;
map<char,int>val;
struct node{
	string s;
	bool operator<(const node &a)const{
		int sz1=s.size();
		int sz2=a.s.size();
		int minn=(sz1,sz2);
		for(int i=0;i<minn;i++){
			if(val[s[i]]!=val[a.s[i]]){
				return val[s[i]]<val[a.s[i]];
			}
		}
		return sz1<sz2;
	}
}no[maxn];
signed main(){
	string s;
	cin>>s;
	for(int i=0;i<26;i++){
		val[s[i]]=i;
	}
	int n;cin>>n;
	for(int i=1;i<=n;i++){
		cin>>no[i].s;
	}
	sort(no+1,no+n+1);
	int k;cin>>k;
	cout<<no[k].s<<endl;
	//system("pause");
}