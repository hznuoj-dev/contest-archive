#include<bits/stdc++.h>
#define rson rt<<1|1
#define lson rt<<1
#define pb push_back
#define endl '\n'
#define x first
#define y second
#define LLINF 9223372036854775807
#define IOS ios::sync_with_stdio(0); cin.tie(0); 
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;

const int N=1e5+10;



int main()
{  
	IOS 
    string s;cin>>s;
    int ans=0;
    for(int i=0;i+3<=(int)s.size()-1;i++){
        if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')ans++;
    }
    cout<<ans<<endl;
    return 0;
}