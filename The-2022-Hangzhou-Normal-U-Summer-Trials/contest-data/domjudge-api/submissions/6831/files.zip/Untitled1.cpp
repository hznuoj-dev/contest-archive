#include<bits/stdc++.h>
using namespace std;
char s[100001];
int main()
{

	int count=0;
	cin>>s;
	for(int i=0;i<strlen(s)-3;i++)
	{
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')
		{
			count++;
			i+=3;
		}
	}
	cout<<count<<endl;
	return 0;
 } 
