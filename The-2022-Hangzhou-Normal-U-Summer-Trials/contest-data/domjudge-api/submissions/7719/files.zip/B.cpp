#include  <bits/stdc++.h>
using namespace std;

int num[1000];
string s[1010];

int cmp(string s1, string s2)
{
    int len1 = s1.length();
    int len2 = s2.length();
    int len = min(len1, len2);
    for (int i = 0; i < len; i++)
        if (num[s1[i]] < num[s2[i]]) return 1;
        else if (num[s1[i]] > num[s2[i]]) return 0;
    if (len1 < len2) return 1;
    return 0;
}

int work()
{
    int i, j, t;
    char c;

    for (i = 0; i < 26; i++)
    {
        scanf("%c", &c);
        num[c] = i;
    } getchar();

    int n;
    scanf("%d", &n);
    for (i = 0; i < n; i++)
    {
        cin >> s[i];
        getchar();
    }

    sort(s, s+n, cmp);

    int k;
    scanf("%d", &k);
    cout << s[k-1];

    return 0;
}

int main()
{
    int T = 1;
    //scanf("%d", &T);
    while (T--) work();
    //getchar();getchar();getchar();
    return 0;
}
