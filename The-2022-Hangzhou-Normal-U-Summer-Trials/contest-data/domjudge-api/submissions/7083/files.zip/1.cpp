#include <bits/stdc++.h>
#define RE0 return 0;
#define FAST ios::sync_with_stdio(false); cin.tie(0); cout.tie(0)
using namespace std;

int T = 1, n, m;

string dic;
string str[10004];
int ans = 0;

int cmp(string a, string b){ //0 a small  1 b small
	for(int i = 0; i < a.length();++i){
		if(b.length()<=i){
			return 0;
		}
		if(a[i]!=b[i]){
			for(int j = 0; j < 26; ++j){
				if(a[i] == dic[j]){
					return 1;
				}
				if(b[i] == dic[j]){
					return 0;
				}
			}
		}
	}
	return 1;
}

signed main(){
	FAST;
	while(T--){
		cin >> dic;
		cin >> n;
		for(int i=0;i<n;++i){
			cin >> str[i];
		}
		sort(str,str+n,cmp);
//		for(int i=0;i<n;++i){
//			cout << str[i] << "\n";
//		}
		int k;
		cin >> k;
		cout << str[k-1] << "\n";
	}
	RE0
} 

