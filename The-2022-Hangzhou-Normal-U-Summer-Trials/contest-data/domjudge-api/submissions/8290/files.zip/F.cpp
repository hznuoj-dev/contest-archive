#include <bits/stdc++.h>
#define ll long long

using namespace std;
typedef pair<int, int> PII;
typedef pair<char, char> PCC;

const int N = 1e6 + 10, mod = 1e9 + 7;

ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a;}
ll lcm(ll a, ll b) { return a * b / gcd(a, b); }
ll qmi(ll a, ll b) { ll res = 1; while(b) { if(b & 1) res = (res * a) % mod; a = (a * a) % mod; b >>= 1;} return res % mod; }

ll n, k;
ll a[N], sum[N], p[N];
vector<ll> v[N];

void solve()
{
	cin >> n >> k;
	for (int i = 1; i <= n; i ++) cin >> a[i], sum[i] = sum[i - 1] + a[i];

	ll ans = 0;
	for (int i = 1; i <= n; i ++)
	{
		p[i] = sum[i] % k;
		if(p[i] == 0) ans ++;
		v[p[i]].push_back(i);
	}
	for (int i = 1; i <= n; i ++)
	{
		ll pos = lower_bound(v[p[i]].begin(), v[p[i]].end(), i) - v[p[i]].begin();
		ans += v[p[i]].size() - pos - 1;
	}	
	cout << ans << '\n';
}

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
    int T = 1;
	//cin >> T;
	while(T --)
	{
		solve();
	}
    return 0;
}
