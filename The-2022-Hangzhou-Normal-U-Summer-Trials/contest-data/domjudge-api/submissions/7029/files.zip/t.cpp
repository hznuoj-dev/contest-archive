#include<iostream>
#include<algorithm>
using namespace std;
const int N = 1e3 + 10;
string m;
int flect[30];
char s[N][N];
int idx[N];
bool cmp(int a, int b){
    int i = 0;
    for(; s[a][i] && s[b][i]; i++)
        if(flect[s[a][i] - 'a'] < flect[s[b][i] - 'a']) return true;
    return s[b][i + 1];
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin >> m;
    for(int i = 0; i < 26; i++)
        flect[m[i] - 'a'] = i;
    int t;
    cin >> t;
    for(int i = 0; i < t; i++){
        cin >> s[i];
        idx[i] = i;
    }
    sort(idx, idx + t, cmp);
    int n;
    cin >> n;
    cout << s[idx[n - 1]];
}