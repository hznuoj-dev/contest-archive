#include<bits/stdc++.h>
using namespace std;
const int N = 500005;

int main(){
	int n,i,q;
	unsigned long long a[N];
	unsigned long long ans,t,st,ed;
	cin>>n;
	for(i=1;i<=n;i++){
		cin>>a[i];
	}
	cin>>q;
	vector<pair<unsigned long long,unsigned long long>> v;
	while(q--){
		cin>>t;
		ans = 0;
		while(!v.empty()){
			v.pop_back();
		}
		for(i=1;i<=n;i++){
			st = a[i];
			ed = a[i] + t - 1;
			v.push_back({st,ed});
		}
		sort(v.begin(),v.end());
		st = v[0].first;
		ed = v[0].second;
		for(i=1;i<n;i++){
			if(v[i].first<=ed){
				ed = v[i].second;
			}else{
				ans += ed - st + 1;
				st = v[i].first;
				ed = v[i].second;
			}
		}
		ans += ed - st + 1;
		cout<<ans<<endl;
	}
	return 0;
}

