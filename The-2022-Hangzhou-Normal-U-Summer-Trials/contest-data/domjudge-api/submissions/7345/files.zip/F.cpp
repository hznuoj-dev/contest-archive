#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <numeric>
#include <bitset>
using namespace std;
#define INF 0x3c3c3c3c // 1010580540, 7f7f7f7f:2139062143
#define llINF 9223372036854775807
const double PI = acos(-1.0);
const double eps = 1e-6;
using ll = long long;
using ull = unsigned long long;
using db = double;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
#define fi first
#define se second
#define pb push_back
#define endl '\n'
#define dbg(a) cout << #a << " = " << (a) << '\n';
#define all(c) (c).begin(), (c).end()
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

const int N = 1e5 + 10;

ll sum[N];
ll a[N];

int main(){
    IOS
    int n, k;
    cin >> n >> k;
    map<int, int> mp;
    mp[0] = 1;
    ll ans = 0;
    for(int i = 1; i <= n; i++){
        cin >> a[i];
        sum[i] += a[i];
        sum[i] %= k;
        mp[sum[i]]++;
    }
    for(auto [u, v] : mp){
        ans += ll(v - 1) * v / 2LL;
    }
    cout << ans;
    return 0;
}