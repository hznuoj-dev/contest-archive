#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=2e5+10;
map <char,char> p;
int main(){
	char s[maxn];
	int q,a,k=0;
	char x,y,ch;
	cin>>q;
	for(int i=1;i<=q;i++){
		cin>>a;
		if(a==1){
			cin>>x;
			s[k]=x;
			p[s[k]]=x;
			k++;
		}
		else if(a==2){
			if(k<=1) s[0]=' ';
			else s[k-1]=' ';
			k--;
		}
		else{
			cin>>x>>y;
			p[x]=y;
			for(int i=0;i<26;i++){
				if(p['a'+i]==x) p['a'+i]=y;
			}
		}
	}
	for(int i=0;i<k;i++) cout<<p[s[i]];
	if(k==0) cout<<"The final string is empty\n";
	return 0;
}
