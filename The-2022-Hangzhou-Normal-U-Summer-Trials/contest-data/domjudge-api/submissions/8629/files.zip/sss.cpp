#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
const int N=1e5+3;
long long a[N];
long long dp[N];
int main(){
	int n;
	cin>>n;
	long long k;
	cin>>k;
	int sum=0;
	int ss=0;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	dp[0]=0;
	for (int i=1;i<=n;i++){
		dp[i]=a[i-1]+dp[i-1];
	}
	for (int i=1;i<=n;i++){
		dp[i]=dp[i]%k;
	}
	sort(dp+1,dp+n+1);
	int popo=1;
	while(popo<=n){
		long long po=upper_bound(dp+1,dp+n+1,dp[popo])-dp;
		long long ppp=po;
		po=po-popo;
		if (dp[popo]==0){
			sum+=((1+po)*po/2);
		}
		else {
			if (po==2)
			sum+=1;
			else if (po!=1){
				sum+=((1+po)*po/2);
			}
		}
		popo=ppp;
	}
	cout<<sum;
	return 0;
}
