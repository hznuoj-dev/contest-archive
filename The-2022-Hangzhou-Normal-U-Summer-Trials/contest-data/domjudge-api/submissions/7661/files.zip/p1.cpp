#include<bits/stdc++.h>
using namespace std;

int main(){
	long long n=0,q;
	long long t;
	cin>>n;
	long long a[n+1];
	long long b[n+1];

	for(long long i = 1; i <= n; i++){
		scanf("%lld",&a[i]);
	}
	for(long long i = 2; i <= n; i++){
		b[i]=a[i]-a[i-1];
	}

	scanf("%lld",&q);
	for(long long i = 0; i < q; i++){
		long long ans=0;
		scanf("%lld",&t);
		for(long long j = 2; j <= n; j++){
			if(t<b[j]){
				ans+=(n-j+2)*t;
				break;
			}
			ans+=b[j];
			if(j==n)ans+=t;
		}
		cout<<ans<<"\n";
	}

	return 0;
}
