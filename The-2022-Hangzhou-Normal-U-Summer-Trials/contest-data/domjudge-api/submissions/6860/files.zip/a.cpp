#include<bits/stdc++.h>
using namespace std;

int main()
{
    string s;
    int ans = 0;
    cin >> s;
    for(int i = 0;i < s.size() - 2;i++)
    {
        if(s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u')
            ans++;
    }
    cout << ans << endl;
    return 0;
}