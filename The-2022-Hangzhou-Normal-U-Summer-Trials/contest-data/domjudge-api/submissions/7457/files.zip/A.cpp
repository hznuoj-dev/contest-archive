#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define all(a) a.begin(), a.end()
#define ios std::ios::sync_with_stdio(false), cin.tie(0), cout.tie(0)
ll ans = 0;
int main(){
    ios;
    int n;
    cin >> n;
    vector<ll> a(n + 1);
    vector<ll> b(n);
    vector<ll> pre(n);
    for(int i = 1; i <= n ; i ++) cin >> a[i];
    for(int i = 1; i <= n - 1 ; i ++) b[i] = a[i + 1] - a[i];
    for(int i = 1; i <= n - 1 ; i ++) pre[i] = pre[i - 1] + b[i];
    int q;
    cin >> q;
    cout << endl;
    while(q--){
        ll x;
        cin >> x;
        ll cnt = lower_bound(b.begin() + 1, b.end(), x) - b.begin() - 1;
       // cout << cnt << endl;
        cout << (n - cnt) * x + pre[cnt] << endl;
    }

    
}