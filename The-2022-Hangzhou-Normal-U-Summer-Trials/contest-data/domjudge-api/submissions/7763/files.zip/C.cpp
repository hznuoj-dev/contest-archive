#include <bits/stdc++.h>
#define ll long long

using namespace std;
typedef pair<int, int> PII;
typedef pair<char, char> PCC;

const int N = 1e6 + 10, mod = 1e9 + 7;

ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a;}
ll lcm(ll a, ll b) { return a * b / gcd(a, b); }
ll qmi(ll a, ll b) { ll res = 1; while(b) { if(b & 1) res = (res * a) % mod; a = (a * a) % mod; b >>= 1;} return res % mod; }

ll n, q;
ll a[N];
__int128_t sum[N];

void solve()
{
	cin >> n;
	vector<ll> v;
	for (int i = 1; i <= n; i ++)
		cin >> a[i];

	v.push_back(0);
	for (int i = 2; i <= n; i ++)
		v.push_back(a[i] - a[i - 1]);
	sort(v.begin(), v.end());

	for (int i = 1; i < v.size(); i ++)
		sum[i] = sum[i - 1] + v[i];
	cin >> q;
	
	while(q --)
	{
		ll t; cin >> t;
		__int128_t pos = lower_bound(v.begin(), v.end(), t) - v.begin();
		pos --;
		ll ans = (__int128_t)n * t - ((__int128_t)t * pos - sum[pos]);
		cout << ans << '\n';
	}
}

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
    int T = 1;
	//cin >> T;
	while(T --)
	{
		solve();
	}
    return 0;
}
