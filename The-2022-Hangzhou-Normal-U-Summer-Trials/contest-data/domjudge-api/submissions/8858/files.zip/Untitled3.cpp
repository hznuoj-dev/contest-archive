#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define moonoom ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
const ll MAXN=5e5+10;
ull arr[MAXN];
ull delta[MAXN];
int main(){
	moonoom;
	ll n;
	cin>>n;
	for(ll i=1;i<=n;i++){
		cin>>arr[i];
		delta[i]=arr[i]-arr[i-1];
	}
	delta[1]=0;
//	for(int i=1;i<=n;i++){
//		cout<<delta[i]<<" ";
//	}cout<<endl;
	
	ll q;
	cin>>q;
	ll t;
	while(q--){
		cin>>t;
		ll pos=0;
		if(t==0){
			cout<<0<<endl;continue;
		}
		if(t>=delta[n]){
			cout<<arr[n]+t-arr[1]<<endl;continue;
		}
		for(int i=1;i<n;i++){
			if(delta[i]<=t&&delta[i+1]>t){
				pos=i;break;
			}
		}
		//cout<<"pos="<<pos<<endl;
		ull ans=0;
		ans=arr[pos]-arr[1]+t*(n-pos)+t;
		cout<<ans<<endl;
	}
	
}
