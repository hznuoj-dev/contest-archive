#include<bits/stdc++.h>

#define debug(x) cerr << #x << " = " << x << '\n'

typedef long long ll;

using namespace std;
vector<int> v(1000);

int cmp(string a, string b) {
	int n = a.size(), m = b.size(); 
	for (int i = 0; i < min(n, m); ++i) {
		if (v[a[i] - 'a' + 1] > v[b[i] - 'a' + 1]) return 0;
		else return 1;
	}
	if (n > m) return 0;
	else return 1;
}

void solve() {
	string s;
	cin >> s;

	for (int i = 0; i < (int)s.size(); ++i) {
		v[s[i] - 'a' + 1] = i + 1;
	}
	
	int n;
	cin >> n;
	string x[100000];
	for (int i = 1; i <= n; ++i) {
		cin >> x[i];
	}
	
//	for (int i = 0; i < n; ++i) {
//		debug(b[i]);
//	}
	sort(x + 1, x + 1 + n, cmp);
	int k;
	cin >> k;
	cout << x[k] << '\n';
}

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
