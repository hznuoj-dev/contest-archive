#include<iostream>
#include<string>
using namespace std;
int main(){
    string s;
    cin>>s;
    string str="hznu";
    int cnt=0;
    for(int i=0;i<(int)s.size()-3;i++){
        if(s.substr(i,4)==str) cnt++;
    }
    cout<<cnt;
}
