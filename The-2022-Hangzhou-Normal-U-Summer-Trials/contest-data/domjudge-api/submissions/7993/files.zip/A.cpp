#include <stdio.h>
#include <string.h>

const int N = 1e3 + 10;

int main(void)
{
	unsigned long long p[500100];
	unsigned long long a, t, sum;
	int n, q;

	scanf("%d", &n);
	for (int i = 0; i < n; i++)
		scanf("%llu", &p[i]);
	scanf("%d", &q);
	for (int i = 0; i < q; i++)
	{
		sum = 0;
		scanf("%llu", &t);
		for (int i = 0; i < n - 1; i++)
		{
			if (p[i + 1] - p[i] <= t - 1)
				sum += p[i + 1] - p[i];
			else
				sum += t;
		}
		sum += t;
		if (i != q)
			printf("%llu\n", sum);
		else
			printf("%llu", sum);
	}

	return 0;
}
