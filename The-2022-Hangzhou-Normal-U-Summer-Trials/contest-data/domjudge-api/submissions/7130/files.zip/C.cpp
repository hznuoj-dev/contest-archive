#include<cstdio>
#include<algorithm>
using namespace std;

int n;
long long a[500015];
int q;
long long t;
long long ans;

int main()
{
	scanf ("%d", &n);
	for (int i = 1; i <= n; i++)
	{
		scanf ("%lld", &a[i]);
	}
	scanf ("%d", &q);
	while (q--)
	{
		ans = 0;
		scanf ("%lld", &t);
		for (int i = 1; i < n; i++)
		{
			ans += min(a[i+1]-a[i], t);
			if (a[i+1]-a[i] >= t)
			{
				ans += (n - i - 1) * t;
				break;
			}
		}
		ans += t;
		printf ("%lld\n", ans);
	}
	
	return 0;
}

