#include<bits/stdc++.h>
#define sync_flow ios::sync_with_stdio(false);cin.tie(0)
#define zf(i,l,r) for(int i=l;i<=r;i++)
#define df(i,r,l) for(int i=r;i>=l;i--)
#define lowbit(x) (x&(-x))
using namespace std;
typedef long long ll;
int main()
{
	//sync_flow;
	string str;
	cin>>str;
	ll ans=0,len=str.size();
	zf(i,0,len-1){
		if(i<=len-4&&str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u'){
			ans++;
		}
	}
	cout<<ans;
	return 0;
}

