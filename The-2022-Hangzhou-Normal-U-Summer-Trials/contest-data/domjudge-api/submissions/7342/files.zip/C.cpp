#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
typedef long long ll;
const int N=5e5+10;
const int M=1e9+7;

ll a[N];
map<int,int> c;

void run()
{
	ll n,q,t;
	
	cin >> n;
	for(int i=1;i<=n;i++)
		cin >> a[i];
	cin >> q;
	
	for(int i=2;i<=n;i++)
		c[a[i]-a[i-1]]++;
	
	map<int,int>::iterator it=c.begin();
	ll cheng=n,ans=0,lat=0,temp=0;
	while(q--)
	{
		cin >> t;
		for(it;it!=c.end() && (it->first)<t;it++)
		{
			cheng-=(it->second);
			temp+=(it->first)*(it->second);
		}
		cout << temp+cheng*t << endl;
	}
}

signed main()
{
	int T=1;
	
	ios::sync_with_stdio(0);
	//cin >> T;
	while(T--)
		run();
	
	return 0;
}
