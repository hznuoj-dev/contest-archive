//#pragma GCC optimize(3)
#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <string>
#include <set>
#include<limits.h>
#include<unordered_map>
#include<unordered_set>
//#include<bits/stdc++.h>

#define IOS std::ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<long long,int> pli;
typedef pair<int,int> pii;
typedef pair<long long,long long> pll;
const int INF = 0x3f3f3f3f;
const double EPS = 1e-6;
const int MOD = 1e9 + 7;
const int MAXN = 3e5+10;
const int N = 1e6+33;

int n,k;
ll a[MAXN];
ll sum[MAXN];
ll cnt[MAXN];
void solve(){
//    cin>>n;for(int i=1;i<=n;i++){cin>>a[i];}
    cin>>n>>k;
    sum[0]=0;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int i=1;i<=n;i++){
        sum[i]=sum[i-1]+a[i];
    }
    ll ans=0;
    cnt[0]=1;
    for(int i=1;i<=n;i++){
        ans+=cnt[sum[i]%k];
        cnt[sum[i]%k]++;
    }
    cout<<ans<<endl;
}

void init(){

}






signed main()
{
#ifdef LOCAL
freopen("in.in","r", stdin);
freopen("out.out","w", stdout);
#endif
IOS;

    int cases=1;
    // cin>>cases;
    init();
    for(int cas=1;cas<=cases;cas++)
    {
        solve();
    }
}