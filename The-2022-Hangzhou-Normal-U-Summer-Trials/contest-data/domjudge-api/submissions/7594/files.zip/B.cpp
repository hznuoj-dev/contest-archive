#include<bits/stdc++.h>
using namespace std;
#define dbg(x) cerr << #x << " -> " << x << '\n'
typedef unsigned long long ull;
typedef long long ll;
const int N = 5e5 + 10;
int n,m,x,y;
ull a[N];
string s;
ull pre[N];
int main(){
    cin>>n;
    a[0]=0;
    for(int i=1;i<=n;++i){
        cin>>a[i];
        pre[i]=a[i]-a[i-1];
    }
    // for(int i=1;i<=n;++i){
    //     cout<<pre[i]<<" ";
    // }
    ll q;
    cin>>q;
    while(q--){
        ull t;
        cin>>t;
        if(t>=a[n]){
            cout<<a[n]+t-1-a[1]+1<<endl;
            return 0;
        }
        ll pos=lower_bound(pre+1,pre+n+1,t)-pre;
        //dbg(pos);
        if(pre[pos]!=t){
            pos--;
            //dbg(t);
        }
        //dbg(pos);
        ull ans=(a[pos]-1)+(n-pos+1)*t-a[1]+1;
        //dbg(ans);
        cout<<ans<<endl;
    }
}