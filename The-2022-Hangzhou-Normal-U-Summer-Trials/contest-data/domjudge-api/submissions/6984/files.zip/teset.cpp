#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(0),cin.tie(0);
#define x first
#define y second
using namespace std;
typedef long long ll;
typedef pair<int,int>PII;
const int N=2e5+7,mod=1e9+7;

int n,m;
int a[N];
map<char,int>mp;
string s[N];

bool check(string x,string y){
    for(int i=0;i<min(x.length(),y.length());i++){
        if(mp[x[i]]<mp[y[i]])return true;
    }
    if(x.length()<y.length())return true;
    else return false;
}

void solve(){
    string ss;cin>>ss;
    for(int i=0;i<26;i++)mp[ss[i]]=i+1;
    cin>>n;
    for(int i=1;i<=n;i++)cin>>s[i];
    cin>>m;
    for(int i=1;i<=n;i++){
        for(int j=n;j>i;j--){
            if(check(s[j],s[j-1])){
                string s1=s[j];
                s[j]=s[j-1];
                s[j-1]=s1;
            }
        }
    }
    cout<<s[m];
}

int main(){
    IOS
    //int T;cin>>T;
    //while(T--)
        solve();
    return 0;
}