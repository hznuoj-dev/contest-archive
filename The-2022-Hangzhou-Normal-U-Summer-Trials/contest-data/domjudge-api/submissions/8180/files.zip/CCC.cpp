#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
typedef long long ll;
const int N=5e5+10;
const int M=1e9+7;

int a[N],t[N],rt[N];
map<int,int> c;
map<int,int> ans; 

void run()
{
	int n,q,tt;
	
	cin >> n;
	for(int i=1;i<=n;i++)
	{
		cin >> a[i];
		if(i>1)
			c[a[i]-a[i-1]]++;
	}
	cin >> q;
	map<int,int>::iterator it=c.begin();
	int cheng=n,temp=0;
	for(int i=1;i<=q;i++)
	{
		cin >> t[i];
		rt[i]=t[i];
	}
	sort(t+1,t+1+q);
	
	for(int i=1;i<=q;i++)
	{
		tt=t[i];
		while((it->first)<tt && it!=c.end())
		{
			cheng-=(it->second);
			temp+=(it->first)*(it->second);
			it++;
		}
		ans[tt]=temp+cheng*tt;
	}
	
	for(int i=1;i<=q;i++)
	{
		cout << ans[rt[i]] << endl;
	}
}

signed main()
{
	int T=1;
	
	ios::sync_with_stdio(0);
	//cin >> T;
	while(T--)
		run();
	
	return 0;
}
