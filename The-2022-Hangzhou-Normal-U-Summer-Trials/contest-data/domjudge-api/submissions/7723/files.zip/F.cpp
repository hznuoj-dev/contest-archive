#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+50;
ll sum[N];
int a[N];
int main(){
	ios::sync_with_stdio(false);
	ll n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum[i]=sum[i-1]+a[i];
	}
	ll cnt=0;
	for(int i=1;i<=n;i++){
		for(int j=0;j<i;j++){
			if((sum[i]-sum[j])%k==0)
			cnt++;
		}
	}
	cout<<cnt;
	return 0;
}

