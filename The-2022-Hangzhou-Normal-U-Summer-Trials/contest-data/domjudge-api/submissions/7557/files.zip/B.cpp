#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N = 1005;
const long long mod = 1e9 + 7;

struct node {
	long long c = 0;
	int id;
} ans[N];

string ss[N];

bool cmp(node a, node b) {
	return a.c < b.c;
}

int main() {
	string s;
	cin >> s;
	int len = s.size();
	map<char, int> cnt;
	for (int i = 0; i < len; i++) {
		cnt[s[i]] = i + 1;
	}
	int n;
	cin >> n;
	for (int i = 0; i < n; i++) {
		string t;
		cin >> t;
		ss[i] = t;
		ans[i].id = i;
		int len1 = t.size();
		for (int j = 0; j < len1; j++) {
			ans[i].c = (ans[i].c * 10 + cnt[t[j]]) % mod;
		}
	}
	sort(ans, ans + n, cmp);
	int k;
	cin >> k;
	cout << ss[ans[k - 1].id] << "\n";
	return 0;
}