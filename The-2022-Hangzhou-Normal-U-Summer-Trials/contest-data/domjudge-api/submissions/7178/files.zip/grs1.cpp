#include<bits/stdc++.h>
#define rson rt<<1|1
#define lson rt<<1
#define pb push_back
#define endl '\n'
#define x first
#define y second
#define LLINF 9223372036854775807
#define IOS ios::sync_with_stdio(0); cin.tie(0); 
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;

const int N=501000;

int n,q;
ll a[N];
ll b[N];
pll T[N];
ll ans[N];

int main()
{  
	IOS 
    cin>>n;
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=1;i<n;i++)b[i]=a[i+1]-a[i];
    b[n]=2e18;
    cin>>q;
    for(int i=1;i<=q;i++){
        cin>>T[i].x;
        T[i].y=i;
    }
    sort(T+1,T+1+q);
    ll res=0;
    for(int i=1,j=1;i<=q;i++){
        ll t=T[i].x,id=T[i].y;
        while(b[j]<t)res+=b[j],j++;
        ans[id]=res+1ll*(n-j+1)*t;
    }
    for(int i=1;i<=q;i++)cout<<ans[i]<<endl;
    return 0;
}