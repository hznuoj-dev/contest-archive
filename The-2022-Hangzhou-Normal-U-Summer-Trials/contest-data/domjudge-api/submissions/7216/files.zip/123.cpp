#include<bits/stdc++.h>
#define int long long
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;
int k[500010];
int t,n,m;
int dx[500010],bef[500010];
char str[1010];
signed main(){
	FAST
	cin>>n;
	for(int i=1;i<=n;i++)cin>>k[i];
	for(int i=2;i<=n;i++)dx[i-1]=k[i]-k[i-1];
	sort(dx+1,dx+n);
	for(int i=1;i<n;i++)bef[i]=bef[i-1]+dx[i];
	cin>>t;
	while(t--){
		cin>>m;
		int ans=k[n]+m-k[1];
		int l=1,r=n-1,lk=0;
		while(l<=r){
			int mid=(l+r)>>1;
			if(dx[mid]<=m){
				lk=mid;
				l=mid+1;
			}
			else r=mid-1;
		}
		ans-=bef[n-1]-bef[lk]-(n-lk-1)*m;
		cout<<ans<<endl;
	}
} 
