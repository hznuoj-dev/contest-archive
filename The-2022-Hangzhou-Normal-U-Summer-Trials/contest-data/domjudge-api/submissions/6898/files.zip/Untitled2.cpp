#include <bits/stdc++.h>
#define endl '\n'
#define IOS ios::sync_with_stdio(0)
using namespace std;

const int N = 1e5 + 10;

char s1[N], s2[N];
int nextt[N];
int ans = 0;

void kmp()
{
	cin >> s1 + 1;
	s2[1] = 'h', s2[2] = 'z', s2[3] = 'n', s2[4] = 'u';
	int len1 = strlen(s1 + 1), len2 = strlen(s2 + 1);
	int j = 0;
	for (int i = 2; i <= len2; ++i)
	{
		j = nextt[i - 1];
		while (j && s2[j + 1] != s2[i])
			j = nextt[j];
		if (s2[j + 1] == s2[i])
			nextt[i] = j + 1;
	}
	j = 0;
	for (int i = 1; i <= len1; ++i)
	{
		while (j && s2[j + 1] != s1[i])
			j = nextt[j];
		if (s2[j + 1] == s1[i])
			j = j + 1;
		if (j == len2)
		{
			ans++;
			j = nextt[j];
		}	
	}
	cout << ans << endl;
}

int main()
{
	//IOS; cin.tie(0), cout.tie(0);
	kmp();
	return 0;
}
