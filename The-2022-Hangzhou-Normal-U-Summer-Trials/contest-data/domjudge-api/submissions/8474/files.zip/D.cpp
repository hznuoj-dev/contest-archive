#include <bits/stdc++.h>
#define endl '\n'
#define IOS ios::sync_with_stdio(0)
using namespace std;
typedef long long ll;
const int N = 1e5 + 10;
int n, q;
vector<int> v[N << 1];
int degree[N];

int main()
{
	//IOS; cin.tie(0), cout.tie(0);
	
	cin >> n;
	for (int i = 1; i <= n - 1; ++i)
	{
		int x, y;
		cin >> x >> y;
		v[x].push_back(y);
		v[y].push_back(x);
		degree[x]++, degree[y]++;
	}

	cin >> q;
	while (q--)
	{
		int xi, sum = 0;
		cin >> xi;
		for (int i = degree[xi]; i >= 1; --i)
		{
			sum += n - 1 - (degree[xi] - i);
		}
		cout << sum << endl;
	}


	return 0;
}
