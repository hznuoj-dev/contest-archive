#include <bits/stdc++.h>
using namespace std;
#define ll long long
int main(){
//    ios::sync_with_stdio(false);
//    cin.tie(nullptr);
    int n;
    scanf("%d",&n);
    ll a[n];
    for(int i=0;i<n;i++)scanf("%lld",&a[i]);
    int q;
    cin>>q;
    while(q--){
        ll t,ans=0;
        scanf("%lld",&t);
        for(int i=0;i<n-1;i++){
            ans+=min(t,a[i+1]-a[i]);
        }
        cout<<ans+t<<'\n';
    }
    return 0;
}
