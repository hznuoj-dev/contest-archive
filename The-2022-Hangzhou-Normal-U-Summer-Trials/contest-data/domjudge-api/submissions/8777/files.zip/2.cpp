 #include<bits/stdc++.h>
 #include<algorithm>
 #include<cmath>
 #include<map>
 using namespace std;
 map<char,int>a;
 map<int,string>x1;
 map<string,int>b;
 map<string,int>len;
 map<int,string>minn;
 map<int,string>neww;
 int y[1010];
 int w[1010];
 int d[1010];
 int main()
 {
     string s;
     cin>>s;
     int n;
     int x=1;
     for(int i=0;i<s.size();i++){
         a[s[i]]=x;
         x++;
         //cout<<a[s[i]]<<endl;
     }
    cin>>n;
    int t=0;
    int len1=0;
    int g=0;
    while(n--){
        string c;
        cin>>c;
        for(int i=0;i<c.size();i++){
            b[c]+=a[c[i]];
        }
        w[t++]=b[c];
        x1[b[c]]=c;
        // cout<<x1[b[c]]<<endl;
    }
    // sort(y,y+g);
    // int u=1;
    // int r=0;
    // int ans=0;
    // d[r]=1;
    // if(y[0]<y[1]){
    //     neww[1]=minn[y[0]];
    //     r++;
    //     d[r]=1;
    // }
    // for(int i=1;i<t;i++){
    //     if(y[i-1]==y[i]){
    //         u++;
    //         d[r]=u;
    //     }else if(y[i-1]<y[i]){
    //         u=1;
    //         r++;
    //         d[r]=1;
    //     }
    // }
    // int w1=0;
    // for(int i=1;i<=r;i++){
    //     if(d[i]!=1){
    //         sort(w+ans,w+ans+d[i]);
    //         for(int j=ans;j<ans+d[i];j++){
    //             neww[j+1]=x1[w[j]];
    //             w1=j+2;
    //         }
    //         ans+=d[i];
    //     }else{
    //         ans+=d[i];
    //         neww[ans]=minn[y[ans-1]];
    //     }
    // }
    sort(w,w+t);
    int m;
    cin>>m;
    cout<<x1[w[m-1]]<<endl;
    return 0;
 }