#include<bits/stdc++.h>
#define Daybreak7 ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define endl "\n"
#define int long long
using namespace std;

signed main()
{
	Daybreak7;
	int n;
	cin>>n;
	int a[n+10];
	for(int i=0;i<n;i++)
		cin>>a[i];
	int q;
	cin>>q;
	while(q--)
	{
		int t;
		cin>>t;
		int ans=0,last=0;
		for(int i=0;i<n;i++)
		{
			ans+=a[i]+t-1-last;
			last=max(a[i+1]-1,a[i]+t-1);
		}	
		cout<<ans<<endl;
	}
}
