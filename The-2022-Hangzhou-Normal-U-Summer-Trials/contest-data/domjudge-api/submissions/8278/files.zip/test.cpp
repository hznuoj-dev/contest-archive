//#pragma GCC optimize(3)
#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <string>
#include <set>
#include<limits.h>
#include<unordered_map>
#include<unordered_set>
//#include<bits/stdc++.h>

#define int long long
#define IOS std::ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<long long,int> pli;
typedef pair<int,int> pii;
typedef pair<long long,long long> pll;
const int INF = 0x3f3f3f3f;
const double EPS = 1e-6;
const int MOD = 1e9 + 7;
const int N = 1e6+33;

    const int MAXN = 3e5+10;

ll e[MAXN];  // ver
ll h[MAXN];  // head
ll ne[MAXN]; // nexts
ll val[MAXN];
ll val2[MAXN];
ll sumval[MAXN];
ll idx;
ll maxx = 0;
void add(ll a, ll b)
{
    e[idx] = b;
    ne[idx] = h[a];
    h[a] = idx++;
}
int n;
int q;
int x;

int query(int x){
    return val2[x];
}

ll dfs(ll u, ll fa)
{
    ll cntzi=0;
    vector<ll>zi;
    ll sumzi=0;
    for (int i = h[u]; i != -1; i = ne[i])
    {
        cntzi++;
        ll y=e[i];
        if(y==fa)continue;
        dfs(y,u);
        zi.push_back(val[y]);
        sumzi+=val[y];
    }
    sumval[u]=sumzi;
    ll ans=0;
    for(int i=0;i<(int)zi.size();i++){
        ans+=(sumzi-zi[i])*zi[i];
    }
    ans/=2;
    ans+=sumzi;
    if(cntzi!=0)val[u]=ans;
    else val[u]=1;
    return val[u];
}



ll dfs2(ll u, ll fa,ll valll)
{
    ll cntzi=0;
    vector<ll>zi;
    ll sumzi=0;
    for (int i = h[u]; i != -1; i = ne[i])
    {
        cntzi++;
        ll y=e[i];
        zi.push_back(val[y]);
        sumzi+=val[y];
    }
    zi.push_back(valll);
    sumzi+=valll;
    ll ans=0;
    for(int i=0;i<(int)zi.size();i++){
        ans+=(sumzi-zi[i])*zi[i];
    }
    ans/=2;
    ans+=sumzi;
    val2[u]=ans;
    for (int i = h[u]; i != -1; i = ne[i])
    {
        ll y=e[i];
        ll vall=sumzi-val[y]+1;
        dfs2(y,u,vall);
    }
    return val[u];
}

void solve(){
    cin>>n;
    memset(h,-1,sizeof h);
    for(int i=1;i<=n-1;i++){
        int xx,yy;
        cin>>xx>>yy;
        add(xx,yy);
    }
    dfs(1,0);
    dfs2(1,0,0);
    cin>>q;
    while(q--){
        cin>>x;
        cout<<query(x)<<endl;
    }
}

void init(){

}






signed main()
{
#ifdef LOCAL
freopen("in.in","r", stdin);
freopen("out.out","w", stdout);
#endif
IOS;

    int cases=1;
    // cin>>cases;
    init();
    for(int cas=1;cas<=cases;cas++)
    {
        solve();
    }
}