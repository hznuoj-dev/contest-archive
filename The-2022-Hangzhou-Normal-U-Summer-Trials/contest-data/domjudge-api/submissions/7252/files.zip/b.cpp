#include<bits/stdc++.h>
using namespace std;
map<char,int> mp1;
map<int,char> mp2; 	
string s;
vector<string > a;
string t;
bool cmp(string s1,string s2)
{
	for(int i=0;i<s1.size();i++)
	{
		if(s1[i]>s2[i])	return false;
	}
	return true;
}
int main()
{ 
	
	cin>>t;
	for(int i=0;i<26;i++)
	{
		mp1[t[i]]=i;
		mp2[i]=t[i];
	}
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>s;
		for(int j=0;j<s.size();j++)
		{
			s[j]=char('a'+mp1[s[j]]);
		}
		a.push_back(s);
	}
	sort(a.begin(),a.end());
	int k;
	cin>>k;
	for(int i=0;i<a[k-1].size();i++)
	{
		char x=char(mp2[a[k-1][i]-'a']);
		cout<<x;
	} 
	
} 
