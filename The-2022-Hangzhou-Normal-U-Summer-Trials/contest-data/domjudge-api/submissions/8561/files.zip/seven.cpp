/*#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int s1[500]={0};
int cmp(string x,string y){
	int t,p=0;
		if(x.length()>y.length()){
			
			return 2;
		}
		else
		if(x.length()<y.length())
		{
			return 1;
		}
	t=x.length();
	for(int i=0;i<t;i++){
		if(s1[x[i]]<s1[y[i]]){
              return 1;
		}
		else
		if(s1[x[i]]>s1[y[i]])
		{
           return 2;
		}
		
	}
}
int main()
{

		
	string s,a[1009];
	cin>>s;
	for(int i=0;i<s.length();i++){
		s1[s[i]]=i+1;
	}
	int n,k;
	scanf("%d",&n);
	getchar();
	for(int i=0;i<n;i++){
		getline(cin,a[i]);
	} 
	scanf("%d",&k);
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			int z=cmp(a[i],a[j]);
			if(z==2)
			{
				string to;
				to=a[i];
				a[i]=a[j];
				a[j]=to;
			}
		}
	}
//	for(int i=0;i<n;i++){
//		cout<<a[i]<<endl;
//	}
	cout<<a[k-1];
	return 0;
 } 
 */
 
 #include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
long long int a[610000],s,b[610000],c[610000]={0};
long long int n,q;
long long int t;
int co(long long int x){
	long long int l=0,r=n-2;
	long long int mid;
	while(l<=r)
	{
	    mid=((l+r)/2);
		if(b[mid]>s)
		{
			r=mid-1;
		}
		else
		if(b[mid]<s)
		{
			l=mid+1;
		}
		else
		if(b[mid]==s)
		{
			break;
		}
	}
	return mid;
}
int main(){


	scanf("%lld",&n);
	for(long long int i=0;i<n;i++){
		scanf("%lld",&a[i]);
		if(i>0)
		{
			b[i-1]=a[i]-a[i-1];
		}
	}
	sort(b,b+n-1);
	for(long long int i=0;i<=n-1;i++){
		if(i==1)
		c[i-1]+=b[i-1];
			else
		c[i-1]+=c[i-2]+b[i-1];
	}
	scanf("%lld",&q);
	for(long long int i=0;i<q;i++){
		scanf("%lld",&s);
		long long int u=co(s);
		if(b[u]>s)
		{
			for(long long int i=u;i>=0;i--)
			{
				if(b[i]<=s)
				{
					t=i+1;
					break;
				}
				else
				if(b[i]>s&&i==0)
				{
					t=0;
				}
			}
		}
		else
		if(b[u]<=s)
		{
			
			for(long long int i=u;i<=n-1;i++)
			{
				if(b[i]>s)
				{
					t=i;
					break;
				}
				else
				if(i==n-1)
				{
					t=n-1;
				}
			}
		}
//		printf("%d\n",u);
	//	printf("%d %d\n",t,c[t-1]);
	     if(t!=0)
		printf("%lld\n",c[t-1]+(n-t)*s);
		else
		if(t==0)
		{
			printf("%lld\n",(n-t)*s);
		}
	}
	return 0;
} 
