#include<bits/stdc++.h>
using namespace std;
int main()
{
	string str;
	getline(cin,str);
	int start=0,n=0;
	start=str.find("hznu");
	while(start!=-1)
	{
        n++;
		start++;
		start=str.find("hznu",start);
	}
	cout<<n;
	return 0;
}
