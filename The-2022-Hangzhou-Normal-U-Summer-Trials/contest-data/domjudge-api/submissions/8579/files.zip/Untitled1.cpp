#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll N = 5e5 + 7;
const ll mod = 1e9 + 7;
ll n, a[N], q, d[N];

int main(){
	cin >> n >> a[1];
	for (int i = 2; i <= n; i++){
		cin >> a[i];
		d[i] = a[i] - a[i - 1];
	}
	cin >> q;
	while (q--){
		ll t, cnt;
		cin >> t;
		ll l = 0, r = n, mid, ans = 0;
		while (l <= r){
			mid = (l + r) / 2;
			if (t >= d[mid]){
				l = mid + 1;
				ans = mid;
			}
			else r = mid - 1;
		}
		cnt = a[ans] - a[1] + t * (n - ans + 1);
		cout << cnt << endl;
	}
} 
