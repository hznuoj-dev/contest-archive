#include <bits/stdc++.h>
using namespace std;
#define int long long
char c[1001000];
signed main() 
{
cin>>(c+1);
int l=strlen(c+1);
int ans=0;
for(int i=1;i<=l-3;i++){
	if(c[i]=='h'&&c[i+1]=='z'&&c[i+2]=='n'&&c[i+3]=='u')ans++;
}cout<<ans<<endl;
}
