#include<string.h>
#include<stdio.h>
int main(){
	char s[100000];
	long long sum=0;
	scanf("%s",&s);
	for(int i=0;i<strlen(s)-3;++i)
	{
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')
		sum++;
	}
	printf("%lld",sum);
} 
