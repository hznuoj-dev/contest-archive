#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[100005],b[100005],k,ans;
map <int,int> mp;
signed main(){
	cin >> n >> k;
	for (int i=1;i<=n;++i) {
		cin >> a[i];b[i]=b[i-1]+a[i];b[i]%=k;
	}
	for (int i=1;i<=n;++i) {
		mp[b[i]]++;
		//cout << "b[" << i << "]=" << b[i] << endl;
	}
	for (int i=1;i<=n;++i) {
		ans+=mp[b[i-1]];
		mp[b[i]]--;
		//cout << "ans[" << i << "]=" << ans << endl;
	}
	cout << ans;
}
