#include<bits/stdc++.h>
#define rson rt<<1|1
#define lson rt<<1
#define pb push_back
#define endl '\n'
#define x first
#define y second
#define LLINF 9223372036854775807
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;
 
const int N=1e5+10;

struct node{
    int p;
    char a,b;
}que[N];

char s[N];
int q;
int len;
int now[N];

int find(int x){
    if(x!=now[x])now[x]=find(now[x]);
    return now[x];
}

int main()
{  
    IOS
    for(int i=1;i<=26;i++)now[i]=i;
    cin>>q;
    for(int i=1;i<=q;i++){
        int p;
        char a,b;
        cin>>p;
        if(p==1){
            cin>>a;
        }else if(p==2){
        }else {
            cin>>a>>b;
        }
        que[i]={p,a,b};
    }
    int rem=0;
    for(int i=q;i>=1;i--){
        int p=que[i].p;
        char a=que[i].a,b=que[i].b;
        if(p==1){
            if(!rem)
            s[++len]='a'+now[a-'a'];
            else rem--;
        }else if(p==2){
            rem++;
        }else {
            int xa=a-'a';
            int xb=b-'a';
            now[xa]=now[xb];
        }
    }
    if(!len){
        cout<<"The final string is empty";
        return 0;
    }
    reverse(s+1,s+1+len);
    for(int i=1;i<=len;i++)cout<<s[i];
    return 0;
}