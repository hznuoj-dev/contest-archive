#include <iostream>
#include <cstring>
const int N = 1e6;
char s[N];
using namespace std;

int main(void) {
	int c = 0;
	memset(s, 0, sizeof(s));
	cin >> s;
	for (int i = 0; i < strlen(s); i++) {
		if (s[i] == 'h' && s[i+1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') c++;
	}
	cout << c << endl;
	
	return 0;
} 
