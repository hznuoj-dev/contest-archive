#include <bits/stdc++.h> 
using namespace std;
long long a[500050],b[500050];
int main()
{
//	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	long long n,q,T;
	cin >> n;
	for (long long i=1; i<=n; i++) cin >> a[i];
	for (long long i=1; i<=n-1; i++) b[i]=a[i+1]-a[i];
	cin >> T;
	while (T--)
	{
		cin >> q;		
		long long l=lower_bound(b+1,b+n,q+1)-b;
		long long ans=a[l]-a[1]+1+q-1;
		ans=ans+(n-l)*q;
		cout << ans << "\n"; 
	}
	
}
