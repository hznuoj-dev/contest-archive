#include <cstdio>
#include <algorithm>
#include <cstring>
#include <iostream>

using namespace std;

int main()
{
	int n, k, i, j;
	cin >> n >> k;
	int a[100010], b;
	a[0] = 0;
	for (i = 1; i <= n; i++)
	{
		scanf("%d", &b);
		b = b % k;
		a[i] = b + a[i - 1];
		a[i] = a[i] % k;
	}
	int cnt = 0;
	for (i = 1; i <= n; i++)
	{
		for (j = i + 1; j <= n; j++)
		{
			if ((a[j] - a[i]) % k == 0)
			{
				cnt ++;
			}
		}
		if (a[i] == 0)
			cnt ++;
	}
	printf("%d", cnt);
	return 0;
}
