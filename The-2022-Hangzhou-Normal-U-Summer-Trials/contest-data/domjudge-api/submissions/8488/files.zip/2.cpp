#include<bits/stdc++.h>
using namespace std;

int dx[4] = {0,0,-1,1};
int dy[4] = {-1,1,0,0};

int _map[55][55];

int vis1[55][55];
int vis2[55][55];

int stai,staj,stbi,stbj;

struct nod{
	int x,y;
	int a,b;
	long long sum;
};

int n;
int flag;
queue<nod>q;

void bfs(){
	nod fto;
	fto.x = stai;
	fto.y = staj;
	fto.a = stbi;
	fto.b = stbj;
	fto.sum = 0;
	vis1[stai][staj] = 1;
	vis2[stbi][stbj] = 1;
	q.push(fto);
	while(!q.empty()){
		nod now = q.front();q.pop();
		for(int k=0;k<4;++k){
			int tx = now.x+dx[k];if(tx<1||tx>n){
				tx = now.x;
			}
			int ty = now.y+dy[k];if(ty<1||ty>n){
				ty = now.y;
			}
			int ta = now.a+dx[k];if(ta<1||ta>n){
				ta = now.a;
			}
			int tb = now.b+dy[k];if(tb<1||tb>n){
				tb = now.b;
			}
			if(_map[tx][ty]==1){
				tx = now.x;
				ty = now.y;
			}if(_map[ta][tb] == 1){
				ta = now.a;
				tb = now.b;
			}
			if(vis1[tx][ty] && vis2[ta][tb]) continue;
			vis1[tx][ty] = 1;
			vis2[ta][tb] = 1;
			if(tx==ta&&ty==tb){
				printf("%lld",now.sum+1);
				flag = 1;
				return;
			}else{
				nod to;
				to.x = tx;to.y = ty;
				to.a = ta;to.b = tb;
				to.sum = now.sum + 1;
				q.push(to);
				//printf("%d %d %d %d\n",to.x,to.y,to.a,to.b);
			}
		}
	}
}

int main()
{
	string s;
	scanf("%d",&n);
	for(int i=1;i<=n;++i){
		cin>>s;
		for(int j=1;j<=n;++j){
			
			if(s[j-1]=='a'){
				_map[i][j] = 0;
				stai = i;staj = j;
			}if(s[j-1] == 'b'){
				_map[i][j] = 0;
				stbi = i;stbj = j;
			}
			
			if(s[j-1] == '.'){
				_map[i][j] = 0;
			}else if(s[j-1] == '*'){
				_map[i][j] = 1;
			}
		}
	}
	
	bfs();
	if(flag==0){
		printf("no solution");
	}
	
	return 0;
}
