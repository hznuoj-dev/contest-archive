#include<bits/stdc++.h>

using namespace std;

void solve() {
	string s;
	cin >> s, s = " " + s; 
	string t = "hznu";
	int ans = 0;
	for (int i = 1; i <= s.size() - 4; ++i) {
		if (s.substr(i, 4) == t) ans++;
	}
	cout << ans << '\n';
}

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
