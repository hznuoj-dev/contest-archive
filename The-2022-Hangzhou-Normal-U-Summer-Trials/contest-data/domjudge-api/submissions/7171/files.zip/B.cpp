#include<iostream>
#include<string>
#include<algorithm>
using namespace std;

string s;

int f(char a,char b){
	int i,ai,bi;
	for(i=0;i<s.length();i++){
		if(a==s[i]){
			ai = i;
		}
		if(b==s[i]){
			bi = i;
		}
	}
	if(ai<bi){
		return -1;
	}else if(ai==bi){
		return 0;
	}else{
		return 1;
	}
}

int cmp(string s1,string s2){
	int i,len1,len2,len;
	len1 = s1.length();
	len2 = s2.length();
	if(len1<len2){
		len = len1;
	} else{
		len = len2;
	}
	for(i=0;i<len;i++){
		if(f(s1[i],s2[i])==-1){
			return 1;
		}else if(f(s1[i],s2[i])==1){
			return 0;
		}
	}
	return 0;
}

int main(){
	string s1[1010];
	int n,k;
	cin>>s;
	cin>>n;
	int i;
	for(i=0;i<n;i++){
		cin>>s1[i];
	}
	cin>>k;
	sort(s1,s1+n,cmp);
	cout<<s1[k-1];
	return 0;
}
