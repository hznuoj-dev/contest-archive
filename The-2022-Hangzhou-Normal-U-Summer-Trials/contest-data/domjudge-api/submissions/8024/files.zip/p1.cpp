#include<bits/stdc++.h>
using namespace std;

struct fun{
	long long v;
	int t;
}cur;

int main(){
	long long n=0,q;
	long long t;
	cin>>n;
	long long a[n+1];
	vector<fun>b;
	
	for(long long i = 1; i <= n; i++){
		scanf("%lld",&a[i]);
	}
	cur.v=a[2]-a[1];
	cur.t=1;
	b.push_back(cur);
	for(long long i = 3; i <= n; i++){
		if(a[i]-a[i-1]==b[(int)b.size()-1].v){
			b[(int)b.size()-1].t++;
		}else{
			cur.v=a[i]-a[i-1];
			b.push_back(cur);
		}
	}

	scanf("%lld",&q);
	for(long long i = 0; i < q; i++){
		long long ans=0;
		scanf("%lld",&t);
		for(long long j = 0; j < b.size(); j++){
			if(t>=b[j].v){
				ans+=b[j].t*b[j].v;
			}else{
				ans+=b[j].t*t;
			}
		}
		ans+=t;
		cout<<ans<<"\n";
	}

	return 0;
}
