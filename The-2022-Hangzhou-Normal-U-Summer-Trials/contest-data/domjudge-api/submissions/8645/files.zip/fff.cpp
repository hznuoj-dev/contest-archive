#include<bits/stdc++.h>
using namespace std;
int a[100010]={0};
int main(){
	int n,k;
	cin>>n>>k;
	for(int i=0;i<n;i++){
		cin>>a[i];
	}
	int sum=0,ans=0;
	for(int i=0;i<n;i++){
		sum=0;
		for(int j=i;j<n;j++){
			sum+=a[j];
			if(sum%k==0){//&&s[sum]!='1'
				//cout<<sum<<" i = "<<i+1<<" j = "<<j+1<<endl;
				//s[sum]='1';
				ans++;
			}
		}
	}
	cout<<ans<<endl;
} 
