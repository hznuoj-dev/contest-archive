#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll N=5e5+7;
ll a[N];
ll b[N];
int main()
{
	int n,k;
	cin>>n>>k;
	ll cnt=0;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	for(int i=0;i<n;i++)
	{
		ll sum=0;
		for(int j=i;j<n;j++)
		{
			sum+=a[j];
			if(sum%k==0)
			cnt++;
		}
	}
	cout<<cnt<<endl;
}
