#include<bits/stdc++.h>
using namespace std;
#define ll long long
double g[3008][3008];
double x[3008],y[3008];
double dis[3008];
int  vis[3008];
ll n;
void dij(){
	for(int i=1;i<=n;i++){
		dis[i]=99999999999999999;
		vis[i]=0;
	}
	dis[1]=0;
	for(int i=1;i<n;i++){
		int x=0;
		for(int j=1;j<=n;j++)
			if(!vis[j]&&(x==0||dis[j]<dis[x]))x=j;
			vis[x]=1;
			for(int j=1;j<=n;j++){
				dis[j]=min(dis[j],dis[x]+g[x][j]);
			}
			
		
	}
}
int main(){
	scanf("%lld",&n);
//	cin>>n;
	ll v1,v2,v3,v4,v0;
	scanf("%lld %lld %lld %lld %lld",&v1,&v2,&v3,&v4,&v0);
//		cin>>v1>>v2>>v3>>v4>>v0;
	
	ll s,t;
	scanf("%lld %lld",&s,&t);
	for(int i=1;i<=n;i++){
		cin>>x[i]>>y[i];
	}
	if(s!=1){
		swap(x[s],x[1]);
		swap(y[s],y[1]);
	}
	
	for(int i=1;i<=n;i++){
		for(int j=i;j<=n;j++){
			if(i==j) g[i][j]=0;
			else if(x[i]>=1&&x[j]>=1&&y[i]>=1&&y[j]>=1){
				g[i][j]=g[j][i]=sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]))/(double)v1;
			}
			else if(x[i]<=-1&&x[j]<=-1&&y[i]>=1&&y[j]>=1){
				g[i][j]=g[j][i]=sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]))/(double)v2;
			}
			else if(x[i]<=-1&&x[j]<=-1&&y[i]<=-1&&y[j]<=-1){
				g[i][j]=g[j][i]=sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]))/(double)v3;
			}
			else if(x[i]>=1&&x[j]>=1&&y[i]<=-1&&y[j]<=-1){
				g[i][j]=g[j][i]=sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]))/(double)v4;
			}
			else {
					g[i][j]=g[j][i]=sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j]))/(double)v0;
			}
		}
	}
	dij();
	
	printf("%.10f\n",dis[t]);
}
