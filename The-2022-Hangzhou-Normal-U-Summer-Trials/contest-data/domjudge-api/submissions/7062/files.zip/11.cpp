#include<bits/stdc++.h>
#define ll long long
#define endl '\n'
using namespace std;
const int INF=0x3f3f3f3f;
const int N=1e5+7;
const double pi=acos(-1);
string s;
string a[1005];
map<char,int>mp;
bool cmp(string a,string b){
	int len=min(a.size(),b.size());
	for(int i=0;i<len;++i){
		if(a[i]!=b[i]) return mp[a[i]]<mp[b[i]];
	}
	return a.size()<b.size();
}
int n;
int k;
int main(){
	ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	cin>>s;
	for(int i=0;i<s.size();++i){
		mp[s[i]]=i;
	}
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i];
	}
	cin>>k;
	sort(a+1,a+1+n,cmp);
	cout<<a[k]<<endl;
	return 0;
} 
