#include<bits/stdc++.h>
#define int long long
#define maxn 1000006
using namespace std;
int a[maxn],n,m,N,f,u,v,k,Sum[6][maxn<<2],Add[6][maxn<<2],p,s;
void update(int z,int L,int R,int C){
	int s,t,Ln=0,Rn=0,x=1;
	for (s=N+L-1,t=N+R+1;s^t^1;s>>=1,t>>=1,x<<=1) {
		Sum[z][s]+=C*Ln;Sum[z][t]+=C*Rn;
		if(~s&1) Add[z][s^1]+=C,Sum[z][s^1]+=C*x,Ln+=x;
		if (t&1) Add[z][t^1]+=C,Sum[z][t^1]+=C*x,Rn+=x;
	}
	for (;s;s>>=1,t>>=1) Sum[z][s]+=C*Ln,Sum[z][t]+=C*Rn;
}
int Query(int z,int L,int R){
	int s,t,Ln=0,Rn=0,x=1,Ans=0;
	for (s=N+L-1,t=N+R+1;s^t^1;s>>=1,t>>=1,x<<=1) {
		if (Add[z][s]) Ans+=Add[z][s]*Ln;
		if (Add[z][t]) Ans+=Add[z][t]*Rn;
		if(~s&1) Ans+=Sum[z][s^1],Ln+=x;
		if (t&1) Ans+=Sum[z][t^1],Rn+=x;
	}
	for (;s;s>>=1,t>>=1) Ans+=Add[z][s]*Ln,Ans+=Add[z][t]*Rn;
	return Ans;
}
signed main(){
	cin >> n >> p >> s;
	for (int i=1;i<=n;++i) cin >> a[i];
	cin >> k;
	
}
