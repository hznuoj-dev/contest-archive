#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
struct Node{
	string s;
	int num;
}node[1100];
int main(){
	ios::sync_with_stdio(false);
	string str;
	getline(cin,str);
	int n,k;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>node[i].s;
		node[i].num=str.find(node[i].s);
	}
	for(int i=1;i<=n-1;i++){
		for(int j=1;j<=n-1-i;j++){
			if(node[j].num>node[j+1].num){
				Node a;
				a=node[j];
				node[j]=node[j+1];
				node[j+1]=a;
			}
		}
	}
	cin>>k;
	int a=0;
	for(int i=1;i<=n;i++){
		if(node[i].num!=-1){
			a++;
			if(a==k){
				cout<<node[i].s<<endl;
				break;
			}
		}
	}
	return 0;
}

