#include<stdio.h>

int main(){
	int n,k;
	scanf("%d%d",&n,&k);
	long long a[n];
	long long i,j,sum,ans=0;
	for(i=0;i<n;i++){
		scanf("%lld",&a[i]);
	}
	for(i=0;i<n;i++){
		sum=0;
		for(j=i;j<n;j++){
			sum+=a[j];
			if(sum%k==0){
				ans++;
			}
		}
	}
	printf("%lld",ans);
	return 0;
}
