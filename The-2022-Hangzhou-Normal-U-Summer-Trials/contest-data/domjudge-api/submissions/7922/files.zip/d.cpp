#include<iostream>
#include<vector>
#define int long long
using namespace std;

const int N=1e5+7;
vector<int> g[N];
int a[N];

signed main()
{
    int n;
    cin >> n;
    for(int i=0; i<n-1; i++){
        int a,b;
        cin >> a >> b;
        g[a].push_back(b);
        g[b].push_back(a);
    }
    vector<int> v;
    for(int i=1; i<=n; i++){
        if(g[i].size()==1) v.push_back(i);
    }
    for(int i=0; i<v.size(); i++){
        for(int j=0; j<g[v[i]].size(); j++){
            a[g[v[i]][j]]++;
        }
    }
    //for(int i=1; i<=n; i++) cout << a[i] << endl;

    int q;
    cin >> q;
    while(q--){
        int x;
        cin >> x;
        cout << (n-1)+a[x]*(n-a[x]-1)+(a[x]-1)*a[x]/2 << endl;
    }
}
