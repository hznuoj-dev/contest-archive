#include <bits/stdc++.h>
using namespace std;
long long sum,n,k,ans;
long long a[100010];
map<int,int>c;
int main ()
{
	cin >> n >> k;
	for (int i = 1; i <= n; i++)
		{
			cin >> a[i];
			sum=sum+a[i];
			ans=ans+c[sum%k];
			if (sum % k == 0) ans++;
			c[sum%k]++;
		}
	cout << ans << '\n';
	return 0;
}
