#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
map<char,int>mp;

bool cmp(string a,string b)
{
	if(a.size()<b.size())
	{
		if(b.find(a))
		{
			return true;
		}
		else
	{
		for(int i=0;i<min(a.size(),b.size());i++)
	{
		if(mp[a[i]]<mp[b[i]])
		return true;
	}
   }
}
if(a.size()==b.size())
{
		for(int i=0;i<min(a.size(),b.size());i++)
	{
		if(mp[a[i]]<mp[b[i]])
		return true;
	}
}
}
int main()
{
    string s;
    string x[1010];
     cin>>s;
    for(int i=0;i<s.length();i++)
    {
       mp[s[i]]=i;
	}
    int m;
    cin>>m;
    for(int i=0;i<m;i++)
    {
    	cin>>x[i];
    }
    sort(x,x+m,cmp);
    /*
    string temp;
	 for(int i=0;i<m;i++)
	 {
	 	for(int j=i+1;j<m;j++)
	 	{
	 		if(x[i].length()<x[j].length())
	 		{
	 			if(x[i].find(x[j]))
	 			{
	 				temp=x[j];
	 				x[j]=x[i];
	 				x[i]=temp;
				 }
			 }
			 else
			 {
			 	for(int k=0;k<min(x[i].length(),x[j].length());k++) 
			 	{
			 		if(mp[x[i][k]]<mp[x[j][k]])
			 		{
			 			temp=x[j];
	 				x[j]=x[i];
	 				x[i]=temp;
					 }
				 }
			 }
		 }
	 }
	 */
	 int k;
	 cin>>k;
  cout<<x[k-1]<<endl;
	return 0;
 } 
 


