#include<bits/stdc++.h>
using namespace std;
char s[100005];
map<char,char>mp;
struct cao{
	char a,b;
}cao[100005];
int a[100005];
char b[100005];
int is[1000];
int len=0;
int main()
{
	for(char i='a';i<='z';i++){
		mp[i]=i;
	}
	int n;
	cin>>n;
	int num=0;//�ṹ����� 
	for(int i=0;i<n;i++){
		cin>>a[i];
		if(a[i]==1){
			cin>>b[i];
			
		}
		else if(a[i]==3){
			cin>>cao[num++].a>>cao[num].b;
		}
	}
	
	int flag=1;
	for(int i=0;i<num;i++){
		flag=1;
		for(int j=i+1;j<num;j++){
			if((cao[i].a==cao[j].b)&&(cao[i].b==cao[j].a)){
				flag=0;
				break;
			}
		}
		if(flag){
			mp[cao[i].a]=cao[i].b;
		}
	}
	for(int i=0;i<n;i++){
		if(a[i]==1){
			s[len++] = mp[b[i]];
		}
		else if(a[i]==2){
			s[len--] = '\0';
		}
	}
	if(len==0){
		cout<<"The final string is empty"<<endl;
	}
	else{
		cout<<s<<endl;
	}
 } 
