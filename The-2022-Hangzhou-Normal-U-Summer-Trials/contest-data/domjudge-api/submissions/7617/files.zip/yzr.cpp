#include<iostream>
#include<algorithm>
#include<string>
using namespace std;
typedef long long ll;
const long long inf=0x3f3f3f3f3f3f;
string s;
const int N=1e6+10;
ll a[N];
ll cha[N];
ll sum[N];
int main()
{
	ll n;
	ll q;
	memset(cha,inf,sizeof(cha));
	cha[0]=0;
	sum[0]=0;
	cin>>n;
	cin>>a[0];
	for(ll i=1;i<n;i++){
		cin>>a[i];
		cha[i]=a[i]-a[i-1];
		sum[i]=cha[i]+sum[i-1];
	}
	cin>>q;
	while(q--){
	ll t;
	cin>>t;
	ll pos=upper_bound(cha+1,cha+n+1,t)-(cha);
	cout<<sum[pos-1]+(n-pos+1)*t<<endl;
	}
	return 0;
}