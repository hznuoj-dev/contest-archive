#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 1e5 + 7;

vector<int> e[N];
int s[N];
int ans[N];
int n;
void dfs(int x,int fa) {
	for (auto i : e[x]) {
		if (i == fa) continue;
		dfs(i,x);
		ans[x] += s[x] * s[i];
		s[x] += s[i];
	}
	ans[x] += (n - s[x] - 1) * s[x];
	s[x] += 1;
}
void solve() {
	cin >> n;
	for (int i = 1; i < n; ++i) {
		int u,v;
		cin >> u >> v;
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs(1,-1);
	int q;
	cin >> q;
	for (int i = 1; i <= q; ++i) {
		int z;
		cin >> z;
		cout << ans[z] + n - 1 << '\n';
	}
}
int main() {
	ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
/*
5
1 2
1 3
3 4
3 5
5
1
2
3
4
5
*/
