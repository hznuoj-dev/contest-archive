#include <bits/stdc++.h>
using namespace std;
#define int long long
int a[100100];
int s[100100];
map<int,int> ma;
int top;
int t[100100];
int n,k;
signed main() 
{
cin>>n>>k;
for(int i=1;i<=n;i++){
cin>>a[i];s[i]=s[i-1]+a[i];}
for(int i=0;i<=n;i++){
	if(!ma[s[i]%k]){
		t[++top]=s[i]%k;
		ma[s[i]%k]++;
	}
	else{
		ma[s[i]%k]++;
	}
}
int ans=0;
for(int i=1;i<=top;i++){
	ans+=ma[t[i]]*(ma[t[i]]-1)/2;
}cout<<ans<<endl;
}
