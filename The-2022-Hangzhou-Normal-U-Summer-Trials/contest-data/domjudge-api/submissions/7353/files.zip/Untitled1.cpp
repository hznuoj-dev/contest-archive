#include<bits/stdc++.h>
#define ll long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const int N = 5e5 + 5;
const double eps = 1e-5;
const int mod = 1e9 + 7;

ll n, a[N], k;
map<ll, ll> mp;

void solve()
{
	cin >> n >> k; 
	ll sum = 0;
	ll ans = 0;
	mp[0] = 1;
	for(ll i = 1; i <= n; i++)
	{
		cin >> a[i];
		sum = (sum + a[i]) % k;
		if(mp[sum])
			ans += mp[sum];
		mp[sum]++;
	}
	cout << ans << '\n';
}

int main()
{
	IOS;
	ll t = 1;
	//cin >> t;
	while (t--)
		solve();
}
