#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define wtnnb ios::sync_with_stdio(false);//cin.tie(0);cout.tie(0);
const int N = 1e6+10;
int v[26];
bool cmp(string x,string y){
	for(int i=0;i<min(x.length(),y.length());i++){
	 	if(x[i]!=y[i])return v[x[i]-'a']<v[y[i]-'a']; 
	} 
}
signed main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
	string s;cin>>s;
	for(int i=0;i<s.length();i++){
		v[s[i]-'a']=i;
	}
	int n;cin>>n;
	string a[1010];
	for(int i=0;i<n;i++){
		cin>>a[i];
		//v[a[i]-'a']=i;
	}
	int k;cin>>k;
	sort(a,a+n,cmp);
	cout<<a[k-1]<<endl;
}

