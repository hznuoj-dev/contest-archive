#include<bits/stdc++.h>
#define ll long long
const int inf=0x3f3f3f3f;
const int maxn=1e5+10;
using namespace std;
ll a[maxn];
ll cnt[maxn];
map<ll,ll>mp;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	ll k;
	int n;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		cnt[i]=a[i]+cnt[i-1];
		cnt[i]%=k;
		mp[cnt[i]]++;
	}
	mp[0]++;
	ll sum=0;
	for(map<ll,ll>::iterator i=mp.begin();i!=mp.end();i++)
	{
		sum+=i->second*(i->second-1)/2;
	}
	cout<<sum;
	return 0;
} 
 
 
