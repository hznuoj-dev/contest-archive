#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int s1[500]={0};
int cmp(string x,string y){
	int t,p=0;
		if(x.length()>y.length()){
			
			return 2;
		}
		else
		if(x.length()<y.length())
		{
			return 1;
		}
	t=x.length();
	for(int i=0;i<t;i++){
		if(s1[x[i]]<s1[y[i]]){
			p=1;
			break;
		}
		else
		if(s1[x[i]]>s1[y[i]])
		{
			p=2;
			break;
		}
		else
		{
			p=0;
		}
		
	}
	if(p==2){

			return 2;
		}
	else
	if(p==1)
	{
			return 1;
	}
	return 0;
}
int main()
{

		
	string s,a[1009];
	cin>>s;
	for(int i=0;i<s.length();i++){
		s1[s[i]]=i+1;
	}
	int n,k;
	scanf("%d",&n);
	getchar();
	for(int i=0;i<n;i++){
		getline(cin,a[i]);
	} 
	scanf("%d",&k);
	for(int i=0;i<n-1;i++){
		for(int j=i+1;j<n;j++){
			int z=cmp(a[i],a[j]);
			if(z==2)
			{
				string to;
				to=a[i];
				a[i]=a[j];
				a[j]=to;
			}
		}
	}
//	for(int i=0;i<n;i++){
//		cout<<a[i]<<endl;
//	}
	cout<<a[k-1];
	return 0;
 } 
 /*
 #include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
long long int n,a[510000],q,s,b[510000],c[510000]={0};
int co(int x){
	int l=0,r=n-2;
	int mid;
	while(l<=r)
	{
	    mid=((l+r)/2);
		if(b[mid]>s)
		{
			r=mid-1;
		}
		else
		if(b[mid]<s)
		{
			l=mid+1;
		}
		else
		if(b[mid]==s)
		{
			break;
		}
	}
	return mid;
}
int main(){
long long int t;
	scanf("%lld",&n);
	for(int i=0;i<n;i++){
		scanf("%lld",&a[i]);
		if(i>0)
		{
			b[i-1]=a[i]-a[i-1];
			if(i==1)
			c[i-1]+=b[i-1];
			else
			c[i-1]+=c[i-2]+b[i-1];
		}
	}
	sort(b,b+n-1);
	for(int i=0;i<n-1;i++){
		if(i==1)
		c[i-1]+=b[i-1];
			else
		c[i-1]+=c[i-2]+b[i-1];
	}
	scanf("%lld",&q);
	for(int i=0;i<q;i++){
		scanf("%lld",&s);
		int u=co(s);
		printf("%d",u);
		if(b[u]>s)
		{
			for(int i=u;i>=0;i--)
			{
				if(b[i]<=s||i==0)
				{
					t=i;
					break;
				}
			}
		}
		else
		if(b[u]<=s)
		{
			for(int i=u;i<=n-1;i++)
			{
				if(b[i]>s)
				{
					t=i;
					break;
				}
				else
				if(i==n-1)
				{
					t=n-1;
				}
			}
		}
		printf("###%d %d \n",t,c[t+1]);
		printf("%lld\n",c[t+1]+(n-t)*s);
	}
	return 0;
} */
