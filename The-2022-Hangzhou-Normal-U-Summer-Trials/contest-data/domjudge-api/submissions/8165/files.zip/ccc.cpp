#include<bits/stdc++.h>
using namespace std;
long long a[100010]={0},d[100010]={0};
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
		if(i>0)
			d[i]=a[i]-a[i-1];//1 �� n-1 
	}
	int q;
	long long t;
	cin>>q;
	while(q--)
	{
		int flag=-1;
		cin>>t;
		if(t>=d[n-1])
		{
			cout<<a[n-1]-a[0]+1+t-1<<endl;
			continue;
		}
		else
		{
			for(int i=1;i<n;i++){
				if(t<=d[i]){
					flag=i; 
					break;
				}
			}
			cout<<a[flag-1]-a[0]+1+(n-flag+1)*t-1<<endl;
		}
	}
}
