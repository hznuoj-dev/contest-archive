#include <bits/stdc++.h>
#define endl '\n'
#define int long long
using namespace std;
typedef long long ll;
const int N=1e5+10;
const int M=1e9+7;

int a[N],b[N];
map<int,int> c;

void run()
{
	int n,k;
	ll cnt=0,sum=0,m;
	
	cin >> n >> k;
	for(int i=1;i<=n;i++)
		cin >> a[i];
	for(int i=1;i<=n;i++)
	{
		sum+=a[i];
		m=sum%k;
		cnt+=c[m];
		c[m]++;
	}
				
	cout << cnt+c[0];
}

signed main()
{
	int T=1;
	
	ios::sync_with_stdio(0);
	//cin >> T;
	while(T--)
		run();
	
	return 0;
}
