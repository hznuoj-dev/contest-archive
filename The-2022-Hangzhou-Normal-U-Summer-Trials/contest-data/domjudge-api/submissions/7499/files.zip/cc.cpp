#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
long long a[N],b[N],sum[N];
long long n,q,t;
int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	for(int i=1;i<n;i++)
		b[i]=a[i]-a[i-1];
	cin>>q;
	while(q--)
	{
		cin>>t;
		long long x=lower_bound(b,b+n-1,t)-b;
		//if(x<n-1||(x==n&&b[x]==t))
		cout<<t*(n-x)+a[x]-a[0]<<endl;
		//else if(x==n&&t>b[x])	cout<<t+a[n]-a[0]<<endl;
		
	}
} 
