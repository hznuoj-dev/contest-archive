#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

const int N=1e5+10;
int n,q,sum[N],st[N];
vector<int> e[N],ans[N];

int dfs(int x)
{
	int cnt=0;
	for(auto i:e[x])
	{
		if(!st[i])
		{
			cnt++;
			st[i]=1;
			int t=dfs(i)+1;
			//cout<<x<<' '<<i<<' '<<t<<' '<<sum[x]<<" ***"<<endl;
			ans[x].push_back(t);
			//if(x==1) cout<<i<<' '<<ans[1].size()<<"**"<<endl;
			//cout<<x<<sum[x]<<"**"<<endl;
			sum[x]+=t;
			
		}
	}
	//cout<<n<<' '<<sum[x]<<' '<<x<<'*'<<endl;
	if(n-sum[x]-1 != 0) ans[x].push_back(n-sum[x]-1);	
	return 0;
}

int main()
{
	cin>>n;
	for(int i=1;i<n;i++)
	{
		int a,b;
		cin>>a>>b;
		e[a].push_back(b);
		e[b].push_back(a);
	}
	int root=1;
	for(int i=1;i<=n;i++)
	{
		if(e[i].size()==2)
		{
			root=i;
			break;
		}
	}
	//cout<<root<<endl;
	//
	dfs(root);
	
	cin>>q;
	while(q--)
	{
		int x;
		cin>>x;
		if(e[x].size()==1) cout<<n-1<<endl;
		else
		{
			int cnt=e[x].size();
			//cout<<ans[x].size()<<"**"<<endl;
			if(cnt==2) cout<<ans[x][0]+ans[x][1]+ans[x][0]*ans[x][1]<<endl;
			else cout<<ans[x][0]+ans[x][1]+ans[x][2]+ans[x][0]*ans[x][1]+ans[x][0]*ans[x][2]+ans[x][1]*ans[x][2]<<endl;
			
		}
	}
	
	return 0;
}
