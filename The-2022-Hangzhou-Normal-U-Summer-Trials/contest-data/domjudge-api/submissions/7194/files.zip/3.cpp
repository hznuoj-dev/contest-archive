#include<iostream>
using namespace std;
const int N=5e5+10;
#define ll long long
ll a[N];
ll b[N];
int main()
{
    int n;
    cin>>n;
    for(int i=0;i<n;i++) cin>>a[i];
    for(int i=0;i<n-1;i++)
    {
        b[i]=a[i+1]-a[i];
    }
    int q;
    cin>>q;
    while(q--)
    {
        ll t;
        cin>>t;
        ll res=0;
        int i;
        for(i=0;i<n-1;i++)
        {
            if(t>b[i]) res+=b[i];
            else break;
        }
        res+=t*(n-i);
        cout<<res<<endl;
    }
    return 0;
}