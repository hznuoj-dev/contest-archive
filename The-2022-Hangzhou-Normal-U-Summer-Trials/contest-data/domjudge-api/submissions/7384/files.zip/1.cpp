#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
long long n,a[N],b[N],q,t,g;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(i>=2){
			b[++g]=a[i]-a[i-1];
		}
	}
	sort(b+1,b+n);
	cin>>q;
	while(q--){
		long long f=0;
		cin>>t;
		for(int i=1;i<n;i++){
			if(b[i]<t){
				f++;
			} else{
				break;
			}
		}
		long long ans=(n-f)*t;
		for(int i=1;i<=f;i++){
			ans+=b[i]; 
		}
		cout<<ans<<'\n';
	}
	return 0;
} 
