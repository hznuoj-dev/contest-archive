#include<bits/stdc++.h>
using namespace std;
string s,str[1010];
int n,k;
map <char,int> mp;
bool cmp(string a,string b){
	int ma=a.size(),mb=b.size();
	if(ma>mb){
		ma=mb;
	}
	for(int i=0;i<ma;i++){
		if(mp[a[i]]<mp[b[i]]){
			return true;
		} else if(mp[a[i]]>mp[b[i]]){
			return false;
		}
	}
	return a.size()<b.size();
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	cin>>n;
	cin.get();
	for(int i=1;i<=n;i++){
		cin>>str[i];
	}
	cin>>k;
	for(int i=0;i<s.size();i++){
		mp[s[i]]=i+1;
	}
	sort(str+1,str+n+1,cmp);
	cout<<str[k]<<'\n';
	return 0;
} 
