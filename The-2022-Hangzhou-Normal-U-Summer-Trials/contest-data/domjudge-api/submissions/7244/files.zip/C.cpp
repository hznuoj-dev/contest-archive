#include<bits/stdc++.h>
using namespace std;
#define int long long
typedef long long ll;
const int N=5e5+7;
int a[N];
void solve(){
	int n;
	cin >> n;
	for (int i=1;i<=n;i++){
		cin >> a[i];
	}
	sort(a+1,a+1+n);
	int q;
	cin >> q;
	while (q--){
		int t;
		int sum=0;
		cin >> t;
		sum=n*t;
		int l=a[1],r=a[1]+t-1;
		for (int i=2;i<=n;i++){
			if (a[i]-a[i-1]+1>t){
				break;
			}
			else{
				sum-=a[i-1]+t-1-a[i]+1;
			}
		}
		cout << sum << '\n';
		
	}

}

signed main(){
	ios::sync_with_stdio(0);
	int t=1;
//	cin >> t;
	while (t--){
		solve();
	}
	return 0;
}

