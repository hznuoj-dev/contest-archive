#include<bits/stdc++.h>
#define ll long long
const int inf=0x3f3f3f3f;
const int maxn=5e2+10;
using namespace std;
struct node{
	int x,y,step;
};
char mp[maxn][maxn];
bool vis[maxn][maxn];
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n;
	cin>>n;
	node a,b;
	for(int i=1;i<=n;i++)
	for(int j=1;j<=n;j++)
	{
	cin>>mp[i][j];
	if(mp[i][j]=='a')
	{
		a.x=i;
		a.y=j;
		}
	if(mp[i][j]=='b')
	{
		b.x=i;
		b.y=j;
		}		
	}
	
	queue<node>q;
	a.step=0;
	b.step=0;
	q.push(a);
	q.push(b);
	queue<node>che;
	bool f=0;
	che.push(b);
	while(!che.empty())
	{
		node bb=che.front();
		che.pop();
		if(a.x==bb.x&&a.y==bb.y)
		{
			f=1;
			break;
		}
		if(vis[bb.x][bb.y])
		continue;
		vis[bb.x][bb.y]=1;
		if(bb.x+1>n||mp[bb.x+1][bb.y]=='*')
		{
		che.push({bb.x,bb.y,bb.step+1});
		}
		else
		che.push({bb.x+1,bb.y,bb.step+1});
		////
		if(bb.x-1<1||mp[bb.x-1][bb.y]=='*')
		{
		che.push({bb.x,bb.y,bb.step+1});	
		}
		else
		che.push({bb.x-1,bb.y,bb.step+1});
		/////
		if(bb.y+1>n||mp[bb.x][bb.y+1]=='*')
		{
		che.push({bb.x,bb.y,bb.step+1});	
		}
		else
		che.push({bb.x,bb.y+1,bb.step+1});
		////
		if(bb.y-1<1||mp[bb.x][bb.y-1]=='*')
		{
			che.push({bb.x,bb.y,bb.step+1});	
		}
		else
		che.push({bb.x,bb.y-1,bb.step+1});
	}
	//solve
	int ans=inf;
	if(f)
	while(!q.empty())
	{
		node aa=q.front();
		q.pop();
		node bb=q.front();
		q.pop();
		if(aa.x==bb.x&&aa.y==bb.y)
		{
			ans=aa.step;
			break;
		}
		if(aa.x+1>n||mp[aa.x+1][aa.y]=='*')
		{
		q.push({aa.x,aa.y,aa.step+1});

		}
		else
		q.push({aa.x+1,aa.y,aa.step+1});
		if(bb.x+1>n||mp[bb.x+1][bb.y]=='*')
		{
		q.push({bb.x,bb.y,bb.step+1});
	
		}
		else
		q.push({bb.x+1,bb.y,bb.step+1});
		////
		if(aa.x-1<1||mp[aa.x-1][aa.y]=='*')
		{
	
		q.push({aa.x,aa.y,aa.step+1});	
		}
		else
		q.push({aa.x-1,aa.y,aa.step+1});
		if(bb.x-1<1||mp[bb.x-1][bb.y]=='*')
		{
		
		q.push({bb.x,bb.y,bb.step+1});	
		}
		else
		q.push({bb.x-1,bb.y,bb.step+1});
		/////
		if(aa.y+1>n||mp[aa.x][aa.y+1]=='*')
		{
	
		q.push({aa.x,aa.y,aa.step+1});	
		}
		else
		q.push({aa.x,aa.y+1,aa.step+1});
		if(bb.y+1>n||mp[bb.x][bb.y+1]=='*')
		{
	
		q.push({bb.x,bb.y,bb.step+1});	
		}
		else
		q.push({bb.x,bb.y+1,bb.step+1});
		////
		if(aa.y-1<1||mp[aa.x][aa.y-1]=='*')
		{
	
		q.push({aa.x,aa.y,aa.step+1});	
		}
		else
		q.push({aa.x,aa.y-1,aa.step+1});
		if(bb.y-1<1||mp[bb.x][bb.y-1]=='*')
		{

			q.push({bb.x,bb.y,bb.step+1});	
		}
		else
		q.push({bb.x,bb.y-1,bb.step+1});
	}
	if(ans==inf)
	cout<<"no solution";
	else
	cout<<ans;
	return 0;
} 
 
 
