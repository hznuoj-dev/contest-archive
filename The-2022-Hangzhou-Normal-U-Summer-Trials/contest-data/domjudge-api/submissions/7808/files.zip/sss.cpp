#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
const int N=5e5+3;
long long a[N];
long long pp[N];
int main(){
	int n;
	cin>>n;
	for (int i=0;i<n;i++){
		cin>>a[i];
	}
	for (int i=1;i<n;i++){
		pp[i]=a[i]-a[i-1];
	}
	int q;
	cin>>q;
	while(q--){
		long long t;
		cin>>t;
		long long big;
		big=t+a[0];
		long long sum=0;
		long long po=lower_bound(pp+1,pp+n,t)-pp;
		if (po>=n){
			cout<<a[n-1]-a[0]+t<<"\n";
		}
		else
			cout<<a[po]+t*(n-po)-a[0]<<"\n";
	}
	return 0;
}
