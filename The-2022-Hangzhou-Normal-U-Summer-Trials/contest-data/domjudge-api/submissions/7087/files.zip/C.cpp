#define _CRT_SECURE_NO_WARNINGS
#include<bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using db = double;
using vi = vector<int>;
using mii = map<int, int>;
using PII = pair<int, int>;
using PLL = pair<ll, ll>;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const ll mod = 1e9 + 7;
const int MAXN = 2e5 + 10;
#define mem(a,b) memset(a,b,sizeof(a));

//char s[MAXN];

int main() {
	int ans = 0;
	string s;
	cin >> s;
	for (int i = 0; i < s.size() - 3; i++) {
		if (s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') {
			ans++;
		}
	}

	cout << ans << endl;

	return 0;
}