﻿#include <stdio.h>
#include <string.h>

const int N = 1e3 + 10;

int newcmp(char* a, char* b, char* c)
{
	while (*a && *b)
	{
		if (*a == *b)
		{
			a++;
			b++;
			continue;
		}
		//printf("different! %c %c %d %d\n",
		//	*a, *b, strchr(c, *a), strchr(c, *b));
		if (strchr(c, *a) < strchr(c, *b)) //a < b
			return 1;
		else
			return -1;
	}
	if (*b != 0 && !*a)
		return 1;
	else if (*a != 0 && !*b)
		return -1;
	return 0;
}

int main(void)
{
	char s[N][N];
	char c[27], * p_c = c, * p;
	char ex[N];
	int n, k;

	scanf("%s", c);
	scanf("%d", &n);
	getchar();
	for (int i = 0; i < n; i++)
	{
		scanf("%s", s[i]);
		getchar();
	}
	scanf("%d", &k);
	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < n - 1 - i; j++)
		{
			if (newcmp(s[j], s[j + 1], c) == -1)
			{
				strcpy(ex, s[j]);
				strcpy(s[j], s[j + 1]);
				strcpy(s[j + 1], ex);
			}
		}
	}
	printf("%s", s[k - 1]);


	return 0;
}