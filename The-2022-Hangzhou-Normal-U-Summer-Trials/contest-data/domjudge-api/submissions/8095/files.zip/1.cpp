#include <bits/stdc++.h>
using namespace std;
#define ll long long
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin>>n;
    ll a[n];
    for(int i=0;i<n;i++)cin>>a[i],a[i]-=(a[0]-1);
    sort(a,a+n);
    int q;
    cin>>q;
    while(q--){
        ll t,ans=0;
        cin>>t;
        ll p = lower_bound(a,a+n,t)-a;
        if(p-1>=0)ans+=a[p-1]-1;
        for(ll i=p-1;i<n-1;i++){
            ans+=min(t,a[i+1]-a[i]);
        }
        cout<<ans+t<<'\n';
    }
    return 0;
}
