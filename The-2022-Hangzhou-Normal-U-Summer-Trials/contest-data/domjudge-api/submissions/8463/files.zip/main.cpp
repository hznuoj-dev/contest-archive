#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 100019;
const signed mode = 1e9 + 7;

struct segTree{
    ll lgcd[maxn << 4], rgcd[maxn << 4];
    ll mul[maxn << 4], div[maxn << 4];
    void push_up(ll p){
        lgcd[p] = __gcd(lgcd[p * 2], lgcd[p*2+1]);
        rgcd[p] = __gcd(rgcd[p * 2], rgcd[p*2+1]);
    }
    void push_mul(ll p, ll m){
        rgcd[p] *= m;
        mul[p] *= m;
    }
    void push_div(ll p, ll m){
        rgcd[p] /= m;
        div[p] *= m;
    }
    void push_down(ll p){
        if(mul[p] != 1){
            push_mul(p*2, mul[p]);
            push_mul(p*2+1, mul[p]);
            mul[p] = 1;
        }
        if(div[p] != 1){
            push_div(p*2, div[p]);
            push_div(p*2+1, div[p]);
            div[p] = 1;
        }
    }

    void build(ll p, ll l, ll r){
        lgcd[p] = 0, rgcd[p] = 1;
        mul[p] = div[p] = 1;
        if(l == r) return;
        ll mid = (l + r) / 2;
        build(p*2, l, mid);
        build(p*2+1, mid+1, r);
    }
    void multipy(ll p, ll l, ll r, ll L, ll R, ll m, bool d){
        if(L > r || l > R) return;
        if(L <= l && r <= R){
            if(!d) push_mul(p, m);
            else push_div(p, m);
            return;
        }
        push_down(p);
        ll mid = (l + r) / 2;
        multipy(p*2, l, mid, L, R, m, d);
        multipy(p*2+1, mid+1, r, L, R, m, d);
        push_up(p);
    }
    ll query(ll p, ll l, ll r, ll L, ll R){
        if(L > r || l > R) return 0;
        if(L <= l && r <= R){
            return __gcd(lgcd[p], rgcd[p]);
        }
        push_down(p);
        ll mid = (l + r) / 2;
        ll res = __gcd(query(p*2, l, mid, L, R),
                      query(p*2+1, mid+1, r, L, R));
        push_up(p);
        return res;
    }
    void filp(ll p, ll l, ll r, ll x){
        if(l == r){
            swap(lgcd[p], rgcd[p]);
            return;
        }
        push_down(p);
        ll mid = (l + r) / 2;
        if(x <= mid) filp(p*2, l, mid, x);
        else filp(p*2+1, mid+1, r, x);
        push_up(p);
    }
}segt;

void solve(){
    ll n, m;
    cin >> n >> m;
    segt.build(1, 1, n);
    for(ll i=1;i<=m;i++){
        string opt;
        ll x, y, z;
        cin >> opt;
        if(opt == "mul"){
            cin >> x >> y >> z;
            segt.multipy(1, 1, n, x, y, z, 0);
        }else if(opt == "div"){
            cin >> x >> y >> z;
            ll res = segt.query(1, 1, n, x, y);
            if(res % z == 0){
                segt.multipy(1, 1, n, x, y, z, 1);
                cout << "YES\n";
            }else cout << "NO\n";
        }else{
            cin >> x;
            segt.filp(1, 1, n, x);
        }
    }
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}