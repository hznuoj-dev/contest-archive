﻿
#include<iostream>
#include<algorithm>
#include<cstring>
using namespace std;

int main()
{
    int n, k;
    cin >> n>>k;
    long a[100005];
    long sum[100005];
    memset(sum, 0, sizeof sum);
    for (int i = 1; i <=n; i++)
    {
        scanf("%lld", &a[i]);
        sum[i] = sum[i - 1] + a[i];
    }
    int ans = 0;
    for (int i = 0; i <= n; i++)
    {

        for (int j = i+1; j <= n; j++)
        {
            if ((sum[j] - sum[i]) % k == 0)ans++;
            
       }

    }

    cout << ans;


}
