#include<bits/stdc++.h>
using namespace std;
int a[26];
struct Node{
    string  str;
    int num;
};
bool cmp(Node x,Node y){
    int len =min(x.str.length(),y.str.length());
    int i;
    for(i=0;i<len;i++){
        if(a[x.str[i]-97]!=a[y.str[i]-97]){
            return a[x.str[i]-97]<a[y.str[i]-97];
        }else if(a[x.str[i]-97]==a[y.str[i]-97]){
            continue;
        }
    }
}
int main(){
    string str;
    getline(cin,str);
    int n;

    for(int i=0;i<str.length();i++){
        a[str[i]-97]=i;
    }
    cin>>n;
    int k;
    getchar();
    struct Node x[n];
    for(int i=0;i<n;i++){
        x[i].num=0;
    }
    for(int i=0;i<n;i++){
        getline(cin,x[i].str);
        for(int j=0;j<x[i].str.length();j++){
            x[i].num+=a[x[i].str[j]-97];
        }
    }
    cin>>k;
    sort(x,x+n,cmp);
    for(int i=0;i<k;i++){
        cout<<x[i].str<<endl;
    }
    return 0;
}