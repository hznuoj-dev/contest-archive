#include <iostream>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <queue>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <limits.h>
#include <stack>
#include <fstream>
#include <list>
#include <sstream>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0)
//#define pb push_back

using namespace std;
 
typedef long long ll;
typedef unsigned long long ull;

typedef pair<ll, int> PII;
const double eps = 2e-9;
const int INF = 1e9 + 10, mod = 998244353;
const double pi = acos(-1.0);
const int N = 85, M = 2e5 + 10, S = 70;

string s;
string p;
int main()
{
	IOS;
	p = "hznu";
	cin >> s;
	int num = 0;
	for (int i = 0; i < s.size(); i++)
	{
		bool flag = true;
		for (int j = 0; j < p.size(); j++)
			if (s[i + j] != p[j])
			{
				flag = false;
				break;
			}
		if (flag) num++;
	}
	cout << num ;


	return 0;
}