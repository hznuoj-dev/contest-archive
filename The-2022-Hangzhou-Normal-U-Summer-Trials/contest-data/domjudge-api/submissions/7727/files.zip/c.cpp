#include<bits/stdc++.h>
#define ll long long
using namespace std;

ll sum[100010], c[100010], a[100010];
ll n, x;
ll q, t;


int main()
{
    cin >> n;
    sum[0] = 0;
    for(ll i = 1;i <= n;i++)
    {
        cin >> a[i];
        if(i != 1)
        {
            c[i - 1] = a[i] - a[i - 1];
            sum[i - 1] = sum[i - 2] + c[i - 1];
        }
    }
    cin >> q;
    for(ll i = 0;i < q;i++)
    {
        cin >> t;
        ll pos = upper_bound(c + 1, c + n + 1, t) - (c + 1);
        if(pos >= n)
            cout << sum[n - 1] + t << endl;
        else
            cout << sum[pos] + (n - pos) * t << endl;
    }

    return 0;
}