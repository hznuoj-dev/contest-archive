#include <bits/stdc++.h>
using namespace std;

int main(){
    long long q;
    int com;
    char a,b;
    string v1;
    scanf("%lld",&q);
    while(q--){
        scanf("%d",&com);
        if(com==1){
            scanf(" %c",&a);
            v1.push_back(a);
        }else if(com==2){
            if(!v1.empty()){
                v1.pop_back();
            }
        }else if(com==3){
            if(v1.empty())continue;
            scanf(" %c %c",&a,&b);
            replace(v1.begin(),v1.end(),a,b);
        }
    }
    if(!v1.empty()){
       cout<<v1;
    }else{
        printf("The final string is empty");
    }
    return 0;
}