#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>
using namespace std;

int main()
{
    string s;
    string str="hznu";
    cin>>s;
    int j=0,res=0;
    for(int i=0;i<s.size();i++)
    {
        while(s[i]==str[j]&&i<s.size()&&j<4)
        {
            i++;
            j++;
        }
        if(j==4)res++,i--;
        j=0;
    }
    cout<<res<<endl;
}
