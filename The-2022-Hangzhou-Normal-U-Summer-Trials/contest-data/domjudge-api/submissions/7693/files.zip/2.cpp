#include<iostream>
#include<cstring>
#include<algorithm>
#include<cstdio>
using namespace std;
typedef long long LL;
const int N=5e5+5;
int a[N];
int s[N],sum[N];
int bsearch(int l,int r,int k)
{
    while(l<r)
    {
        int mid=l+r+1>>1;
        if(s[mid]<k)l=mid;
        else r=mid-1;
    }
    return l;
}
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)
    {
        cin>>a[i];
        if(i>1)s[i]=a[i]-a[i-1],sum[i]=s[i]+sum[i-1];
    }
    int q;
    cin>>q;
    while(q--)
    {
        int m;
        cin>>m;
        int t=bsearch(1,n,m);
        cout<<sum[t]+(n-t+1)*m<<endl;
    }
}
