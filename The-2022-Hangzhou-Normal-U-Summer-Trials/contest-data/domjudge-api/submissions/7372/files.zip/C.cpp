#include<bits/stdc++.h>
using namespace std;
int n,q;
long long ans,tmp,tmp2,d[500005];

int main(){
	cin>>n;
	cin>>tmp;
	for(int i=1;i<n;i++){
		cin>>tmp2;
		d[i]=tmp2-tmp-1;
		tmp=tmp2;
	}
	cin>>q;
	for(int i=1;i<=q;i++){
		cin>>tmp;
		ans=n;
		tmp2=1;
		tmp--;
		for(int j=1;j<n;j++){
			
			if(d[j]>=tmp){
				break;
			}
			else{
				ans+=d[j];
			}
			tmp2++;
		}
		ans+=(n-tmp2+1)*tmp;
		cout<<ans<<"\n";
	}
	return 0;
}
