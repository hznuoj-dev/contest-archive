#include <stdio.h>
#include <string.h>

const int N = 1e5 + 10;

int main(void)
{
	char s[N] = { 0 }, c, c_ex, * p = s, * be = s;
	int num, q, len = 0;

	scanf("%d", &q);
	while (q--)
	{
		scanf("%d", &num);
		if (num == 2)
		{
			if (len == 0)
				continue;
			*p = '\0';
			p--;
			len--;
		}
		else if (num == 1)
		{
			while ((c = getchar()) && c == ' ')
				;
			*p = c;
			p++;
			len++;
		}
		else if (num == 3)
		{

			while ((c_ex = getchar()) && c_ex == ' ')
				;
			while ((c = getchar()) && c == ' ')
				;
			char* o = s;
			while (*o)
			{
				if (*o == c_ex)
					*o = c;
				o++;
			}
		}
	}
	if (!len)
		printf("The final string is empty");
	else
		printf("%s", s);

	return 0;
}