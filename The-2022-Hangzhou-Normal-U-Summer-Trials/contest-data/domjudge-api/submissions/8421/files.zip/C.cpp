#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> PII;
const int INF = 0x3f3f3f3f, MAXN = 1e6 + 10;
#define int ll
void solve() {
    int n;
    cin >> n;
    vector<ll> a(n);
    for(int i = 0; i < n; i ++) {
        cin >> a[i];
    }
    if(n == 1) {
        int q;
        cin >> q;
        while(q --) {
            ll x;
            cin >> x;
            cout << x << '\n';
        }
        return ;
    }
    vector<int> b;
    for(int i = 1; i < n; i ++) {
        b.push_back(a[i] - a[i - 1]);
    }
    sort(b.begin(), b.end());
    vector<int> temp = b;
    temp.resize(unique(temp.begin(), temp.end()) - temp.begin());
    vector<int> c;
    int id = 0, j = 0;
    for(int i = 1; i < b.size(); i ++) {
        if(b[i] != b[i - 1]) {
            c.push_back(i - id);
            id = i;
        }
    }
    // if(id != n - 1)
    c.push_back(b.size() - id);
    for(int i = 1; i < c.size(); i ++) {
        c[i] += c[i - 1];
    }
    vector<ll> res(c.size());
    for(int i = 0; i < c.size(); i ++) {
        res[i] = ((i ? temp[i] - temp[i - 1] : temp[i])) * (n - (i ? c[i - 1] : 0)) ;
    }
    for(int i = 1; i < res.size(); i ++) {
        res[i] += res[i - 1];
    }
    int q;
    cin >> q;
    while(q --) {
        ll t;
        cin >> t;
        if(t <= temp[0]) {
            cout << 1ll * n * t << '\n';
            continue;
        }
        int x = upper_bound(temp.begin(), temp.end(), t) - temp.begin() - 1;
        ll rrr = res[x] + (t - temp[x]) * (n - c[x]);
        cout << rrr << '\n';
    }
}
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int _ = 1;
    //cin >> _;
    while(_ --) {
        solve();
    }
    return 0;
}