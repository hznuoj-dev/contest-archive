#include<iostream>
#include<string>
using namespace std;
int main(){
	string s;
	cin>>s;
	int t=0;
	for(long unsigned int i=0;i<s.length()-3;i++){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
			t++;
		}
	}
	cout<<t<<endl;
	return 0;
} 
