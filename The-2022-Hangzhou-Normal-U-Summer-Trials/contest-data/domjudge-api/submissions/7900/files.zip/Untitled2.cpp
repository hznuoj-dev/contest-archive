#include <iostream>
#include <string>
#include <bits/stdc++.h>
using namespace std;
const int maxn=5e5+3;
int n,k;
long long a[maxn];
long long b[maxn];
long long q[maxn];
int main(){
	long long t;
	cin>>t;
	for(int i=0;i<t;i++){
		cin>>a[i];
	}
	sort(a,a+t);
	for(int i=1;i<t;i++){
		b[i]=a[i]-a[i-1];
	}
	sort(b,b+t);
	long long n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>q[i];
	}
	for(int i=0;i<n;i++){
		long long temp=t;
		long long sum=0;
		long long m=1;
		for(int j=0;j<q[i];j++){
			if(temp==1){
				sum++;
			}
			else{
				if(j<b[m]) sum+=temp;
				else{
					m++;
					temp--;
					sum+=temp;
				}
			}
		}
		cout<<sum<<endl;	
	} 
}
