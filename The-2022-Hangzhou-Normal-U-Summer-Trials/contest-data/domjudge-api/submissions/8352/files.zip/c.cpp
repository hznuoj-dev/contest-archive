#include<iostream>
#include<string>
using namespace std;
long long int a[500007],n,q,t,b[500007];
int main(){
	cin>>n;
	cin>>a[0];
	b[0]=0;
	for(long long int i=1;i<n;i++){
		cin>>a[i];
		b[i]=a[i]-a[i-1];
	}
	cin>>q;
	for(long long int i=0;i<q;i++){
		cin>>t;
		if(t<=b[n-1]){
				long long int l=0,r=n-1;
				while(l<r){
					int m=(r+l)/2;
					if(b[m]<t)
						l=m+1;
					else
						r=m;
				}
				//cout<<"r="<<r<<endl;
				cout<<(n-r+1)*t+a[r-1]-1<<'\n';
		}else{
			cout<<a[n-1]+t-1<<'\n';
		}
		
	}
	return 0;
} 
/*5
1 3 8 16 30
8
1
2
3
5
6
12
14
15*/

