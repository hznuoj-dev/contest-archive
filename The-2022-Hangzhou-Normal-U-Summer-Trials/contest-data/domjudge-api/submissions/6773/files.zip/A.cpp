#include<bits/stdc++.h>
using namespace std;

#define ll long long;

const int N=2e5+5;
const int mod=1e9+7;

void solve(){
	string s;
	int ans=0;
	cin>>s;
	for(int i=0;i<s.size()-3;i++){
		if(s[i]=='h' && s[i+1]=='z' && s[i+2]=='n' && s[i+3]=='u' )ans++;
	}
	cout<<ans<<"\n";
}

int main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int t=1;
//	cin>>t;
	while(t--){
		solve();
	}
	return 0;
}

