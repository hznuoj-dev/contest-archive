#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 2e5 + 10, mod = 1e9 + 7;

ll f[N], inv[N];
ll qpow(ll a, ll b){
	ll res = 1;
	while(b){
		if(b & 1) res = res * a % mod;
		a = a * a % mod;
		b >>= 1;
	}
	return res;
}

ll C(ll n, ll m){
	return f[n] * inv[m] % mod * inv[n - m] % mod;
}

void init(int M){
	f[0] = 1;
	for(int i = 1; i <= M; i++) f[i] = f[i - 1] * i % mod;
	inv[M] = qpow(f[M], mod - 2);
	for(int i = M - 1; i >= 0; i--) inv[i] = inv[i + 1] * (i + 1) % mod;
}

ll ans[N];

void solve(){
	int n, s, q;
	scanf("%d%d%d", &n, &s, &q);
	vector<int> a(n + 1);
	ll sum = 0;
	for(int i = 1; i <= n; i++){
		scanf("%d", &a[i]);
		sum += a[i];
	}
	for(int m = 0; m <= s; m++){
		ans[m] = C(n + m - 1, n - 1);
		if(m) ans[m] = (ans[m] + ans[m - 1]) % mod;
	}
	while(q--){
		int p, x;
		scanf("%d%d", &p, &x);
		sum -= a[p];
		a[p] = x;
		sum += a[p];
		ll m = s - sum;
		if(m < 0){
			printf("0\n");
		}else{
			printf("%lld\n", ans[m]);
		}
	}
}

int main(){
	int T = 1;
	init(2e5);
	while(T--) solve();
	return 0;
}
