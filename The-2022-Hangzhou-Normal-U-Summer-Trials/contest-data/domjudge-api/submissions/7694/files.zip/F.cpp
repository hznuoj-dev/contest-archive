#include<bits/stdc++.h>
using namespace std;
const int N = 1e5 + 7;
int n;
long long k, a[N];
long long b[N]; 
long long cnt[N];
map<int, int>mp;

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin >> n >> k;
    int ans = 0;
    for(int i = 1; i <= n; i++){
       cin >> a[i];
       b[i] = (b[i - 1] + a[i]) % k;
       if(b[i] == 0){
           cnt[i] = ++ans;
       }
    }
    long long sum = 0;
    for(int i = 1; i <= n; i++){
       if(cnt[i] != 0) sum += cnt[i];
       else{
           sum += mp[b[i]];
           mp[b[i]]++;
       }
    }
    cout << sum << '\n';
}