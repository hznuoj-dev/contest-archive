#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int N=500001;
vector<ll>a,v,s;
vector<ll>::iterator it;
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		ll b;
		cin>>b;
		a.push_back(b);
		if(i>0){
			v.push_back(a[i]-a[i-1]);
		}
	}
	ll ss=0;
	s.push_back(0);
	for(int i=0;i<v.size();i++){
		ss+=v[i];
		s.push_back(ss);
		//cout<<v[i]<<endl;
	}
	int q;
	cin>>q;
	while(q--){
		ll t;
		cin>>t;
		ll x=0;
		int i=lower_bound(v.begin(),v.end(),t)-v.begin();
		if(i==v.end()-v.begin())
		x=s[n-1]+t;
		else
		x=s[i]+(v.size()-i+1)*t;
		cout<<x<<endl;
	}
}
