#include<bits/stdc++.h>
using namespace std;
#define inf 0x3f3f3f3f3f3f3f3f
#ifdef ACM_LOCAL
const int N = 1e1 + 10;
#else
const int N = 5e5 + 10;
#endif
__int128 a[N], range[N];
__int128 sum[N];
inline __int128 read() {
    int s = 0,w = 1;
    char ch = getchar();
    while(ch <= '0' || ch > '9') { if( ch == '-') w = -1; ch = getchar(); }
    while(ch >= '0' && ch <= '9') s = s * 10 + ch - '0' ,ch = getchar();
    return s * w;
}
inline void write(__int128 x)
{
    if(x < 0) putchar('-'),x = -x;
    if(x > 9) write(x / 10);
    putchar(x % 10 + '0');
}
int main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    int n; scanf("%d", &n);
    for(int i = 1;i <= n;i ++) a[i] = read();
    for(int i = 1;i < n;i ++) range[i] = a[i + 1] - a[i];
    range[n] = inf;

    int left = n;
    for(int i = 1;i < n;i ++){
        sum[i] = sum[i - 1] + left * (range[i] - range[i - 1]);
        left --;
    }

    int k; scanf("%d", &k);
    while(k --){
        __int128 t = read();
        auto p = lower_bound(range + 1, range + n, t) - range;
        __int128 more = t - range[p - 1];
        __int128 ans = sum[p - 1] + (__int128)(n - p + 1) * more;
        write(ans), putchar('\n');
    }

    return 0;
}