#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[100005],q;
map <char,char> mp;
char ans[100005];
char b[100005],c[100005];
char find(char k){
	if (mp[k]==k) return k;
	return mp[k]=find(mp[k]);
}
signed main(){
	cin >> q;
	for (int i=1;i<=q;++i) {
		cin >> a[i];
		if (a[i]==1) {
			cin >> b[i];n++;
		}
		if (a[i]==2) {
			if (n) n--;
			else a[i]=4;
		}
		if (a[i]==3) cin >> b[i] >> c[i];
	}n=0;
	for (char i='a';i<='z';++i) mp[i]=i;
	for (int i=q;i;--i) {
		if (a[i]==3) mp[find(b[i])]=find(c[i]);
		if (a[i]==1) ans[++n]=(find(b[i]));
		if (a[i]==2) n--;
	}
	if (n==0) {
		cout << "The final string is empty";return 0;
	}
	for (int i=n;i;--i) {
		cout << ans[i];
	}
	
}
