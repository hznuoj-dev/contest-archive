#include<bits/stdc++.h>
using namespace std;
long long a[500001];
int main()
{
	int n;
	scanf("%d",&n); 
	for(int i=0;i<n;i++)
	{
		scanf("%lld",&a[i]);
	}
	int q;
	scanf("%d",&q);
	while(q--)
	{
		long long ans=0;
		long long t;
		scanf("%lld",&t);
		if(a[n-1]-a[n-2]<=t)
		{
			ans=a[n-1]+t-1; 
		} 
		else
		{
		for(int i=0;i<n-1;i++)
		{
			if(t<(a[i+1]-a[i]))
			{
				ans+=a[i]+t-1;
				ans+=t*(n-i-1);
				break;
			}
		}
	  }
		printf("%lld\n",ans);
	 } 
	return 0;
}
 
