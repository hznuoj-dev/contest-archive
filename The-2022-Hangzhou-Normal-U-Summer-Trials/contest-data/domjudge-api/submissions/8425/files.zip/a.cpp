#include<bits/stdc++.h>
using namespace std;
#define ll long long
vector<int>g[100008];

ll a[1000008];
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	ll n,s,q;
	cin>>n>>s>>q;
	ll w=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		w+=a[i];
	}
	if(n==1){
		while(q--){
			ll x,y;
			cin>>x>>y;
			if(y<=s){
				cout<<s-y+1<<"\n";
			}
			else cout<<"0\n";
			
		}
	}
	else {
	
	while(q--){
		ll x,y;
		cin>>x>>y;
		ll k=y-a[x];
//		cout<<"k="<<k<<"\n";
		w+=k;
		a[x]=y;
		if(w>s){
			cout<<0<<"\n";
		}
		else {
		ll e=s-w;
//		cout<<e<<"asd\n";
		ll ans=1+n*((1+e)*(e)/2);
		cout<<ans<<"\n"; 
	}
}
	}
	
	
} 
/*
1 5 1
1 
1 1
*/

