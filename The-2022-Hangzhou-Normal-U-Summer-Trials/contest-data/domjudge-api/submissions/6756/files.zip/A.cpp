#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define fi first
#define se second
#define N 200010

void solve(){
	ll num=0;
	string s;
	cin>>s;
	for(ll i=0;i<s.length();i++){
		if(s.substr(i,4)=="hznu"){
			num++;
		}
	}
	cout<<num;
}

int main(){
	int T=1;
	ios::sync_with_stdio(false);
	//cin>>T;
	while(T--){
		solve();
	}
	return 0;
}
