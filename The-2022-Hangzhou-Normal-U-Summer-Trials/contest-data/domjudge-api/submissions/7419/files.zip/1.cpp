#include <bits/stdc++.h>
using namespace std;
int a[30];
bool cmp(string s1,string s2){
    for(int i=0;s1[i]&&s2[i];i++){
        if(s1[i]!=s2[i])
        return a[s1[i]-'a']<a[s2[i]-'a'];
    }
    return s1.length()<s2.length();
}
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    string s;
    cin>>s;
    for(int i=0;s[i];i++){
        a[s[i]-'a']=i;
    }
    int n;
    cin>>n;
    string ss[n];
    for(int i=0;i<n;i++)cin>>ss[i];
    sort(ss,ss+n,cmp);
    int k;
    cin>>k;
    cout<<ss[k-1]<<'\n';
    return 0;
}
