#include<bits/stdc++.h>
using namespace std;
signed main(){
	string s;cin>>s;
	int ans=0;
	for(int i=0;i<s.size();i++){
		if(s.substr(i,4)=="hznu")ans++;
	}
	cout<<ans;
}
