#include <bits/stdc++.h>

#define ll long long
#define PII pair<ll, int>
#define dbg(x) cerr << #x << " = " << x << endl;

using namespace std; 

const int N = 2e5 + 10;
const int INF = 0x3f3f3f3f;         // 1061109567
const ll INFF = 0x3f3f3f3f3f3f3f3f; // 4557430888798830399
const double esp = 1e-8, pi = acos(-1.0);
const int MOD = 998244353;

ll qmi(int a, int b)
{
    ll ret = 1 % MOD;
    while (b)
    {
        if (b & 1) ret = ret * (ll)a % MOD;

        a = a * (ll)a % MOD;
        b >>= 1;
    }
    
    return ret;
}

int gcd(int a, int b)
{
    return b ? gcd(b, a % b) : a;
}

int lowbit(int x)
{
    return x & -x;
}

/////////////////////////////////////////////////////////// 

string s;
int n, m, k;
vector<pair<ll, string>> v;

bool cmp(pair<ll, string> a, pair<ll, string> b)
{
    if (a.first == b.first) return a.second.length() < b.second.length();
    return a.first < b.first;
}

void solve()
{
    cin >> s;
    s = ' ' + s;
    unordered_map<char, int> mp;
    for (int i = 1; s[i]; i ++ ) mp[s[i]] = i;
    
    cin >> n;
    for (int i = 0; i < n; i ++ )
    {
        string t;
        cin >> t;

        //string tmp = t;
        //reverse(tmp.begin(), tmp.end());
        ll x = 0;
        for (auto c : t)
        {
            x = x * 27ll + mp[c];
        }
        v.push_back({x, t});
    }

    cin >> k;

    sort(v.begin(), v.end(), cmp);

    //for (auto t : v) {dbg(t.first); dbg(t.second);}
    cout << v[k - 1].second << endl;
}

int main()
{
    ios::sync_with_stdio(0);

    int T = 1;
    //cin >> T;
    //scanf("%d", &T);
    //init();

    while (T--)
    {
        solve();
    }

    return 0;
}
