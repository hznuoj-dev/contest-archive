#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> PII;
const int INF = 0x3f3f3f3f, MAXN = 1e6 + 10;
void solve() {
    int n;
    cin >> n;
    vector<ll> a(n + 1);
    for(int i = 1; i < n; i ++) {
        int  u, v;
        cin >> u >> v;
        a[v] ++, a[u] ++;
    }
    int q;
    cin >> q;
    while(q --) {
        ll x;
        cin >> x;
        cout << 1ll * (2ll * n - 1ll - a[x]) * a[x] / 2ll << '\n';
    }
}
signed main() {
    ios::sync_with_stdio(false);
    cin.tie(0);
    int _ = 1;
    //cin >> _;
    while(_ --) {
        solve();
    }
    return 0;
}