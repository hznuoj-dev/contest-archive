#include <bits/stdc++.h>
#include<unordered_map>
using namespace std;
const int maxn=5e3+10;
const int mod=1e9+7;
#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define int  long long
//#define double long double
int v[10];
struct Point{
	int x,y;
	int flag;
};
double dis[maxn][maxn];
double caldis(Point x,Point y){
	int ans=(x.x-y.x)*(x.x-y.x)+(x.y-y.y)*(x.y-y.y);
	return (double)sqrt(ans);
}
Point no[maxn];
signed main(){
	//fast;
	//int a1,a2,a3,a4;cin>>a1>>a2>>a3>>a4;
	//Point x,y;x.x=a1,x.y=a2,y.x=a3,y.y=a4;
	//printf("%.10lf",caldis(x,y));
	int n;scanf("%lld",&n);
	for(int i=1;i<=4;i++)scanf("%lld",&v[i]);
	scanf("%lld",&v[0]);
	int st,ed;scanf("%lld%lld",&st,&ed);
	for(int i=1;i<=n;i++){
		scanf("%lld%lld",&no[i].x,&no[i].y);
		if(no[i].x>=1&&no[i].y>=1)no[i].flag=1;
		else if(no[i].x<=-1&&no[i].y>=1)no[i].flag=2;
		else if(no[i].x<=-1&&no[i].y<=-1)no[i].flag=3;
		else if(no[i].x>=1&&no[i].y<=-1)no[i].flag=4;
		else no[i].flag=0;
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dis[i][j]=caldis(no[i],no[j]);
			if(no[i].flag==no[j].flag){
				dis[i][j]=dis[i][j]/(double)v[no[i].flag];
			}
			else{
				dis[i][j]=dis[i][j]/(double)v[0];
			}
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			dis[st][i]=min(dis[st][j]+dis[j][i],dis[st][i]);
		}
	}
	printf("%.10lf\n",dis[st][ed]);
	//system("pause");
}
