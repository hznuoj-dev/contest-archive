#include<bits/stdc++.h>
using namespace std;

struct fun{
	string i;
	string v;
};

bool cmp(fun a,fun b){
	return a.v<b.v;
}

int main(){
	int n=0,p;
	string ori;
	char ch;
	
	cin>>ori;
	map<int,char>cnt;
	for(int i = 0; i < 26; i++){
		cnt[ori[i]]=i;
	}
	cin>>n;
	fun s[n];
	getchar();
	for(int i = 0; i < n; i++){
		while(1){
			ch=getchar();
			if(ch=='\n')break;
			s[i].v+=cnt[ch]-'0';
			s[i].i+=ch;
		}
	}
	sort(s,s+n,cmp);
	cin>>p;
	cout<<s[p-1].i;

	return 0;
}
