#include <bits/stdc++.h>
using namespace std;
string s;
int i,sum;
int main ()
{
	cin >> s;
	i=0;
	while (i < s.size()){
		if (s[i] == 'h' && s[i+1] == 'z' &&s[i+2] == 'n' && s[i+3] == 'u')
			{
				sum++;
				i=i+4;
			}
		else i++;
	}
	cout << sum << '\n';
}
