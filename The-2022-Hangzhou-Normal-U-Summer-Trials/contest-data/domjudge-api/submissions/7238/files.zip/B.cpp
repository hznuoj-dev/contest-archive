#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define all(a) a.begin(), a.end()
#define ios std::ios::sync_with_stdio(false), cin.tie(0), cout.tie(0)
string s;
int c[200];
int cmp(const string &a, const string &b){
    for(int i = 0 ; i < min(a.size(), b.size()) ; i ++){
        if(c[a[i] - 'a'] > c[b[i] - 'a']){
            return 0;
        }else if(c[a[i] - 'a'] < c[b[i] - 'a']){
            return 1;
        }
    }
    if(a.size() > b.size()) return 0;
    return 1;
}
int main(){
    ios;
    cin >> s;
    for(int i = 0 ; i < s.size(); i ++) c[s[i] - 'a'] = i;
    int n ;
    cin >> n ;
    vector<string> a(n);
    for(int i = 0 ; i < n ; i ++) cin >> a[i];
    sort(all(a), cmp);
    //for(auto i : a) cout << i << endl;
    int x;
    cin >> x;
    cout << a[x - 1];
}