#include<bits/stdc++.h>
using namespace std;
#define LL long long
const int N = 5e5 + 7;

LL n, q;
LL a[N], t, b[N];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    cin >> n;
    for(LL i = 0; i < n; i++){
        cin >> a[i];
        if(i != 0)b[i - 1] = a[i] - a[i - 1];
    }
    cin >> q;
    for(LL i = 1; i <= q; i++){
        LL sum = 0;
        cin >> t;
        if(b[n - 2] <= t){
            sum = a[n - 1] - 1 + t;
            cout << sum << '\n';
            continue;
        }
        else if(b[0] >= t){
            sum = 1ll * n * t;
            cout << sum << '\n';
            continue;
        }
        LL pos = upper_bound(b, b + n, t) - b;
        sum = a[pos] - 1;
        sum += 1ll * (n - pos) * t;
        cout << sum << '\n'; 
    }
}