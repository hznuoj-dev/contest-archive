#include<bits/stdc++.h>
using namespace std;
const int maxn=1e5+10;
map<char,int>mp;
int cmp(string a,string b)
{
	for(int i=0;i<min(a.length(),b.length());i++)
	{
		if(mp[a[i]]<mp[b[i]])
		{
			return a>b;
		}
	}
}
int main()
{
	mp.clear();
string s;
    string x[1010];
    cin>>s;
    for(int i=0;i<s.length();i++)
    {
       mp[s[i]]=i;
	}
    int m;
    cin>>m;
    for(int i=0;i<m;i++)
    {
    	cin>>x[i];
    }
	 sort(x,x+m,cmp);
	 int k;
	 cin>>k;
  cout<<x[k-1]<<endl;
	return 0;
 } 
 


