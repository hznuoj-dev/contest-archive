#include<bits/stdc++.h>

using namespace std;

const int N = 100005;

int f[1000005],vis[1000005];
int n;

int find(int x){
	return x == f[x] ? x:f[x] = find(f[x]);
}

int main()
{
	scanf("%d",&n);
	int now = 0;
	char a,b,c;
	for(int i=1;i<=1000000;++i){
		f[i] = i;
	}
	int flag = 0;
	for(int i=1;i<=n;++i){
		scanf("%d",&flag);
		if(flag == 1){
			cin>>a;
			int to = a-'a'+N;
			f[++now] = f[to+vis[to]*26];
		}else if(flag == 2){
			now--;
			if(now<0) now = 0;
		}else {
			cin>>b>>c;
			int u = b-'a'+N;
			int v = c-'a'+N;
			f[u+vis[u]*26] = f[v+vis[v]*26];
			vis[u]++;
		}
	}
	
	if(now==0){
		printf("The final string is empty");
		return 0;
	}else{
		for(int i=1;i<=now;++i){
			int to = find(f[i]);
			int now = (to-N)%26+'a';
			cout<<(char)now;
		}
	}
}
