#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define lowbit(x)(x&-x)
typedef pair<int,int>PII;
const int INF = 0x3f3f3f3f;
typedef pair<int,string>PIS;
typedef pair<double,double>PDD;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
int lcm(int a,int b){return a*b/gcd(a,b);}
#define snow ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
const int N = 30,M = 1e5+10;
char s[M];
vector<int>vec[M];
int p[M];
int find(int x){
    if(p[x]!=x)p[x]=find(p[x]);
    return p[x];
}
signed main(){
    snow
    int n;
    cin>>n;
    int len;
    len=0;
    for(int i=0;i<30;i++)vec[i].push_back(i);
    for(int i=1;i<=n;i++){
        int x;
        char y;
        cin>>x>>y;
        int yy=y-'a';
        if(x==1)s[len]=y,len++;
        else if(x==2&&len)len--;
        else{
            char y2;
            cin>>y2;
            int yy2=y2-'a';
            for(auto x:vec[yy]){
                vec[yy2].push_back(x);
            }
            vec[yy].clear();
        }
    }
    for(int i=0;i<26;i++){
        for(auto x:vec[i]){
            p[x]=i;
        }
    }
    if(len==0){
        cout<<"The final string is empty"<<endl;
        return 0;
    }
    for(int i=0;i<len;i++){
        int g=s[i]-'a';
        cout<<char(find(g)+'a');
    }
    cout<<endl;
    return 0;
}