#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e6;
long long int a[maxn];
long long int d[maxn];
vector<long long int>vv;
int main(){
    int n , q;
    long long int t;
    cin>>n;
    for(int i = 1; i <= n; i++){
    	cin>>a[i];
	}
	for(int i = 1; i < n; i++){
		d[i] = a[i + 1] - a[i];
	}
	d[n] = 1e18 + 100;
	cin>>q;
	for(int i = 1; i <= q; i++){
		cin>>t;	
		long long int ans = 0;
		int vp = upper_bound(d + 1, d + n + 1, t - 1) - d;
	    if(vp != 1){
	    	ans = ans + t*(n - vp);
	    	ans = ans + a[vp] + t - a[1];
		}else{
			ans = ans + t*n;
		}
	//	cout<<vp<<endl;
		cout<<ans<<endl;
	}
	return 0;
} 
