#include <bits/stdc++.h>
using namespace std;
long long a[500005],num[500005];
int main(){
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%d",&a[i]);
        if(i!=0){
            num[i]=a[i]-a[i-1];
        }
    }
    int q,k;
    scanf("%d",&q);
    for(int i=0;i<q;i++){
        long long sum=0;
        scanf("%d",&k);
        for(int j=1;j<n;j++){
            if(num[j]>k){
                sum+=k;
            }else{
                sum+=num[j];
            }
        }
        sum+=k;
        printf("%lld\n",sum);
    }
    return 0;
}