#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=1e3+10;
const int mod=1e9+7;
int t,n,p,k;
int pos[maxn];
string str[maxn];
int cmp(string a,string b)
{
    int len1=a.length(),len2=b.length();
    for(int i=0;i<min(len1,len2);i++)
    {
        if(pos[a[i]]==pos[b[i]])  continue;
        return pos[a[i]]<pos[b[i]];
    }
    return a<b;
}
int main()
{
    // ios::sync_with_stdio(false);
    // cin.tie(0);
    // cout.tie(0);
    string s;
    cin>>s;
    int len=s.length();
    for(int i=0;i<len;i++)  
    {
        pos[s[i]]=i;
    }
    cin>>n;
    for(int i=1;i<=n;i++)  cin>>str[i];
    sort(str+1,str+1+n,cmp);
    cin>>k;
    cout<<str[k];
    return 0;
}










