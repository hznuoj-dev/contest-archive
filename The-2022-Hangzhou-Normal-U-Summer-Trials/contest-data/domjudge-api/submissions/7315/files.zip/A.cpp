#include<bits/stdc++.h>
using namespace std;
#define yes (cout<<"YES\n")
#define no (cout<<"NO\n")
#define endl '\n'
//typedef long long ll;
#define int long long
void sxseven();
signed main() {
	ios::sync_with_stdio(false);
	int _=1;
	//cin >> _;
	while(_--) sxseven();
	return 0;
}
const int N=1e5+5;
vector<int> e[N],c[N];
int a[N],an[N],n;
void dfs(int x,int fa){
	int u;
	a[x]=1;
	for(int i=0;i<e[x].size();++i){
		u=e[x][i];
		if(u==fa)continue;
		dfs(u,x);
		a[x]+=a[u];
	}
}
void dfss(int x,int fa){
	int u,s=n-a[x];
	an[x]=n-1;
	for(int i=0;i<e[x].size();++i){
		u=e[x][i];
		if(u==fa)continue;
		an[x]+=a[u]*s;
		s+=a[u];
		dfss(u,x);
	}
}
void sxseven() {
	cin >> n;
	for(int i=1,u,v;i<n;++i){
		cin >>u >>v;
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs(1,0);
	dfss(1,0);
	for(int i=1;i<=n;++i)cout<<an[i]<<' ';
	int q,x;cin >>q;
	while(q--){
		cin >> x;
		cout<<an[x]<<endl;
		
	}
}

