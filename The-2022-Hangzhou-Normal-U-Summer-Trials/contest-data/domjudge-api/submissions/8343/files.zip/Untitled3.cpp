#include<bits/stdc++.h>

using namespace std;

#define INF 0x3f3f3f3f3f3f3f3f
#define io ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define PI acos(-1)
#define mem(a,b) memset((a),(b),sizeof(a));

typedef long long ll;
typedef unsigned long long ull;

ll n,arr[500100],q,t;
set<ll>mp;
int main() {
	io;
	cin>>n;
	for(int i=1;i<=n;i++) {
		cin>>arr[i];
	}
	cin>>q;
	while(q--) {
		cin>>t;
		for(int i=1;i<=n;i++) {
			for(int j=arr[i];j<=arr[i]+t-1;j++) {
				mp.insert(j);
			}
		}
		cout<<mp.size()<<'\n';
	}
	return 0;
}
