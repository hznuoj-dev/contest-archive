#include<cstdio>
#include<map>
using namespace std;

long long n;
long long k;
long long a[100015];
long long arr[100015];
long long m[100015];
long long ans;

map <int, int> mp;

long long f(long long x)
{
	long long tmp = 0;
	for (long long i = 1; i <= x; i++) tmp += i;
	return tmp;
}


int main()
{
	scanf ("%lld%lld", &n, &k);
	for (int i = 1; i <= n; i++)
	{
		scanf ("%lld", &a[i]);
		arr[i] = arr[i - 1] + a[i];
		m[i] = arr[i] % k;
		mp[m[i]]++;
	}
	
	
	ans += f(mp[0]);
	mp[0] = 0;
	for (int i = 1; i <= n; i++)
	{
		if (mp[m[i]] > 1)
		{
			ans += f(mp[m[i]] - 1);
			mp[m[i]] = 0;
		}
	}
	
	printf ("%lld\n", ans);
	
	
	
	
	
	
	return 0;
	
}
