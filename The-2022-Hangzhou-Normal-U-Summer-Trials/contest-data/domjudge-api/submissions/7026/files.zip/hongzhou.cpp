#include <bits/stdc++.h>
using namespace std;
const int N =2e5+10; 
const int mod= 998244353; 
using namespace std;
typedef long long ll;
#define INF 0x3f3f3f3f3f3f3f3f  
char a[1100][1001];
char t[1001];
struct node
{  ll res;
   ll id;
}b[1100];
 string s;
ll judge(char s1[])
{    ll ans=0;
   for(int i=0;i<strlen(s1);i++)
    {     for(int j=0;j<s.length();j++)
          {     if(s1[i]==s[j])
                {   ans=ans*10+j+1;
				}
		  }
	}
	return ans;
}
bool cmp(node a,node b)
{ return a.res<b.res;
}
int main(){
  
    cin>>s;
    ll n;
    scanf("%lld",&n);
    for(int i=1;i<=n;i++)
    {   scanf("%s",a[i]);
       b[i].res=judge(a[i]);
       b[i].id=i;
	}
	sort(b+1,b+1+n,cmp);
	ll k;
	scanf("%lld",&k);
	printf("%s\n",a[b[k].id]);
	return 0;
}
