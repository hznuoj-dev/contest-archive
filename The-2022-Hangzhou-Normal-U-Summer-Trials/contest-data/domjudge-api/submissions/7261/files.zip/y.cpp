#include <bits/stdc++.h>
using namespace std;
const int maxn=5e5+10;

#define int  long long

int f[maxn];
void init(){
	f[1]=0;
	f[2]=1;
	for(int i=3;i<=2e5;i++){
		f[i]=i*(i-1)/2;
	}
}

map<int,vector<int>>mp;
signed main(){
	init();
	int n;cin>>n;
	int k;cin>>k;
	mp[0].push_back(0);
	int pre=0;
	for(int i=1;i<=n;i++){
		int x;cin>>x;
		pre+=x;
		pre%=k;
		mp[pre].push_back(i);
	}
	int ans=0;
	for(auto i:mp){
		int sz=i.second.size();
		if(sz>1){
			ans+=f[sz];
		}
	}
	cout<<ans<<endl;


	system("pause");
}