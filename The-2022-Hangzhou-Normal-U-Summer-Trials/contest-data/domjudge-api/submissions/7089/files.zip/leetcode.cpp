﻿#include <iostream>
#include <vector>
#include <unordered_map>
#include <algorithm>

using namespace std;

unordered_map<char, int> dx;
bool cmp(string a, string b);

int main()
{
	string tmp;
	char tmpc;
	for (int i = 0; i < 26; ++i)
	{
		tmpc = getchar();
		dx[tmpc] = i;
	}
	int num;
	cin >> num;
	vector<string> tmpstrs;
	for (int i = 0; i < num; ++i)
	{
		cin >> tmp;
		tmpstrs.push_back(tmp);
	}
	int k;
	cin >> k;
	sort(tmpstrs.begin(), tmpstrs.end(), cmp);
	cout << tmpstrs[k - 1];
}

bool cmp(string a, string b)
{
	if (a.length() != b.length())
		return a.length() < b.length();
	for (int i = 0; i < a.length(); ++i)
	{
		if (a[i] != b[i])
		{
			return dx[a[i]] < dx[b[i]];
		}
	}
}