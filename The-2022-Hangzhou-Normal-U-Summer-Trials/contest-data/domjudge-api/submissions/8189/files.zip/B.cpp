#include<bits/stdc++.h>
#define  tententen ios::sync_with_stdio(false);cin.tie(0),cout.tie(0);
using namespace std;
#define dbg(x) cerr << #x << " -> " << x << '\n'
typedef unsigned long long ull;
typedef long long ll;
const int N = 5e5 + 10;
const int SIZE = 1110;
const ll mod=1e9+7;
int n,m,x,y;
string s;
map<char,ull>mp;
ll ha[SIZE];
map<int ,string >a;
int main(){
	tententen;
    cin>>s;
    for(int i=0;i<s.size();++i){
        mp[s[i]]=i+1;
        //cout<<"mp[s[i]]"<<mp[s[i]]<<endl;
    }
    int n;
    cin>>n;
    for(int i=1;i<=n;++i){
        cin>>s;
        ull ans=0;
        for(int j=0;j<s.size();++j){
            ans=(ans*31+mp[s[j]])%mod;
        }
        
        ha[i]=ans;
        a[ans]=s;
        //dbg(s);
    }
    int k;
    cin>>k;
    sort(ha+1,ha+1+n);
   for(int i=1;i<=n;++i){
  		//cout<<"ha[i]"<<ha[i]<<endl;
	}
    cout<<a[ha[k]]<<endl;
    
}