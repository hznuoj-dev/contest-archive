#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> PLL;
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define debug(a) cout<<#a<<'='<<a<<endl;
#define fi first
#define se second
#define pb push_back
#define all(a) a.begin(),a.end()
ll n,q,t;
int ans[500500];

void init(){
	
}

void solve(){
	cin>>n;
	vector<ll>a(n),b(n);
	rep(i,0,n)cin>>a[i];
	rep(i,1,n)b[i]=a[i]-a[i-1];
	ll minn=*min_element(b.begin()+1,b.end()),maxx=*max_element(b.begin()+1,b.end());
	init();
	cin>>q;
	rep(i,0,q){
		cin>>t;
		if(t<=b[1])cout<<n*minn<<endl;
		else if(t>b[n-1])cout<<a[n-1]-a[0]+t<<endl;
		else{
			int pos=upper_bound(b.begin(),b.end(),t)-b.begin()-1;
//			debug(pos);
			cout<<a[pos]-a[0]+t+(n-pos-1)*t<<endl;
		}
	}
	
}

int main(){
	int _=1;
//	cin>>_;
	while(_--)solve();
	return 0;
}
