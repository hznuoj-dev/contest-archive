#define _CRT_SECURE_NO_WARNINGS
#include<bits/stdc++.h>
using namespace std;
using ll = long long;
using ull = unsigned long long;
using db = double;
using vi = vector<int>;
using mii = map<int, int>;
using PII = pair<int, int>;
using PLL = pair<ll, ll>;
const int inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const ll mod = 1e9 + 7;
const int MAXN = 5e5 + 10;
const int N = 1e6 + 10;
#define mem(a,b) memset(a,b,sizeof(a));

int a[30];
char s[30];
string str[MAXN];
char ss[MAXN];

int trie[N][26];
int cnt[N];
int id;
int k;
void insert(string s, int len) {
	int p = 0;
	for (int i = 0; i < len; i++) {
		int x = s[i] - 'a';
		if (trie[p][x] == 0)trie[p][x] = ++id;
		p = trie[p][x];
	}
	cnt[p]++;
}
void find(string S, int p) {
	if (k <= 0) {
		return;
	}
	if (cnt[p] != 0) {
		for (int i = 0; i < min(cnt[p], k); i++) {
			cout << S << endl;
		}
		k -= cnt[p];
	}

	for (int i = 0; i < 26; i++) {
		int x = s[i] - 'a';
		if (trie[p][x] != 0) {
			find(S + s[i], trie[p][x]);
		}
	}
}


int main() {
	scanf("%s", s);
	for (int i = 0; i < 26; i++) {
		a[s[i] - 'a'] = i;
	}
	int n;
	scanf("%d", &n);
	for (int i = 0; i < n; i++) {
		scanf("%s", ss);
		int len = strlen(ss);
		for (int j = 0; j < len; j++) {
			str[i].push_back(ss[j]);
		}
		insert(str[i], len);
	}
	cin >> k;
	find("", 0);


	return 0;
}