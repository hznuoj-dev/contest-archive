#include<stdio.h>
#include<string.h>

int main()
{
	int sum = 0, i, j;
	char str[100010] = {0};
	int flag[100010] = {0};
	gets(str);
	if (strlen(str) < 4)
		printf("0");
	else
	{
		for (i = 0; i < strlen(str) - 3; i++)
		{
			if (str[i] == 'h' && str[i + 1] == 'z' && str[i + 2] == 'n' && str[i + 3] == 'u' && flag[i] == 0 && flag[i + 1] == 0 && flag[i + 2] == 0 && flag[i + 3] == 0)
			{
				sum++;
				flag[i] = 1;
				flag[i + 1] = 1;
				flag[i + 2] = 1;
				flag[i + 3] = 1; 
			}
		}
		printf("%d", sum);		
	}	
	return 0;
}
