#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 1e5+10;

string a[1010];
struct node{
	string s;
	int id;
}p[1010];
bool cmp(node fi,node se){
	return fi.s < se.s ; 
}
void solve(){
	string s1; cin >> s1;
	map<char,int>mp;
	for(int i=0;i<26;i++){
		mp[s1[i]]=i;
	}
	int n; cin >> n;
	for(int i=1;i<=n;i++){
		cin >> a[i];
		for(int j=0;j<(int)a[i].size();j++){
			p[i].s+=(mp[a[i][j]]+'0');	
		}
		p[i].id=i;
	}
	sort(p+1,p+n+1,cmp);
	int t; cin >> t;
	cout << a[p[t].id];
}
/*


*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
