#include<bits/stdc++.h>
using namespace std;

const int N=2e5+7,M=1e9+7;

void solve(){
	string s;
	cin>>s;
	long long ans=0;
	for(int i=0;i+3<s.size();i++){
		if(s.substr(i,4)=="hznu") ans++;
	}
	cout<<ans<<'\n';
}

int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int T=1;
	//cin>>T;
	while(T--) solve();
	return 0;
}
