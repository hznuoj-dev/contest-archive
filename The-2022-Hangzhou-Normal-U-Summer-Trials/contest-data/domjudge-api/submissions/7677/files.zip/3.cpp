#include<iostream>
using namespace std;
const int N=5e5+10;
#define ll long long
unsigned ll a[N];
unsigned ll b[N];
unsigned ll c[N];
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++) cin>>a[i];
    for(int i=1;i<n;i++)
    {
        b[i]=a[i+1]-a[i];
        if(i>1) c[i]=b[i]+c[i-1];
        else c[i]=b[i];
    }
    int q;
    cin>>q;
    while(q--)
    {
        unsigned ll t;
        cin>>t;
        unsigned ll res=0;
        if(n==1) {cout<<t<<endl;continue;}
        int l=1,r=n-1;
        while(l<r)
        {
            int mid= (l+r) >> 1;
            if(b[mid]>=t) r=mid;
            else l=mid+1; 
        }
        if(b[l]>t) res=c[l-1]+(n-l+1)*t;
        else res=c[l]+(n-l)*t;
        cout<<res<<endl;
    }
    return 0;
}