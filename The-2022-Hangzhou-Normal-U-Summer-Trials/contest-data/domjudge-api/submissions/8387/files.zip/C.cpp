#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
#define int long long 
int  ch[N];
signed  main(void){
	int n,q;
	int x;
	scanf("%lld",&n);
	for(int i=1;i<=n;++i) {
		scanf("%lld",&ch[i]);
	}
	scanf("%lld",&q);
	while(q--){
		scanf("%lld",&x);
		int ans=0,flag=0;
/*		if(x>=ch[n]) {
			printf("%lld\n",x-1+ch[n]);
			continue;
		}
		else ans=ans+x;
		for(int i=n-1;i>=1;i--){
			if(x+ch[i]-1>=ch[i+1]) {
			ans=ans+ch[i+1]-1;
			break;
			}
			else ans=ans+x;
		}*/
		for(int i=n;i>=2;i--){
			if(ch[i]==ch[i-1]) continue;
			if(ch[i]-ch[i-1]<x) {
				ans=ans+x+ch[i]-1;
				flag=1;
				break;
			}
			else  ans=ans+x;
		}
		if(flag==0) ans=ans+x;
		printf("%lld\n",ans);
	}
	return 0;
}
