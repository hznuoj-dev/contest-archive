#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 5e5 + 5;

int a[maxn];
map<int,int>mp;

void solve(){
	int n, k; cin >> n >> k;
	int ans = 0;
	mp[0] = 1;
	for(int i = 1; i <= n; ++i){
		cin >> a[i];
		a[i] += a[i - 1];
		ans += mp[a[i] % k];
		mp[a[i] % k]++;
	}
	cout << ans;
} 

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
