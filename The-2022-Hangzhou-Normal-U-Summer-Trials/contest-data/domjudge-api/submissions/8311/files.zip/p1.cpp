#include<bits/stdc++.h>
using namespace std;

long long a[500001];
long long b[500001];

int main(){
	long long n=0,q;
	long long t,cur,pre,ans;
	cin>>n;
	
	for(long long i = 1; i <= n; i++){
		scanf("%lld",&a[i]);
	}
	for(long long i = 1; i < n; i++){
		b[i]=a[i+1]-a[i];
	}
	

	scanf("%lld",&q);
	for(long long i = 0; i < q; i++){
		cin>>t;
		int l = 1,r = n-1,mid=1;
		while(l<=r){
			mid=(l+r)/2;
			if(b[mid]<t){
				l=mid+1;
			}else if(b[mid]>t){
				r=mid-1;
			}else{
				break;
			}
		}
		while(b[mid]<=t&&mid<n)mid++;
		ans=a[mid]+(n-mid+1)*t-a[1];
		cout<<ans<<"\n";
	}

	return 0;
}
