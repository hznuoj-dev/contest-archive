#include <bits/stdc++.h>
#define N 200005
using namespace std;
char str[N];
int n,ans;
int main(){
	scanf("%s",str);
	n=strlen(str);
	for(int i=0;i<n-3;i++)
		if(str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u')
			ans++;
	printf("%d",ans);
	return 0;
}
