#include <iostream>
#include <cstdio>
#include <cstring>
#include <sstream>
#include <queue>
#include <iomanip>
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include <map>
#include <set>
#include <limits.h>
#include <stack>
#include <fstream>
#include <list>
#include <sstream>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0)
//#define pb push_back

using namespace std;
 
typedef long long ll;
typedef unsigned long long ull;

typedef pair<ll, int> PII;
const double eps = 2e-9;
const int INF = 1e9 + 10, mod = 998244353;
const double pi = acos(-1.0);
const int N = 1e5 + 10, M = 2e5 + 10, S = 70;
ll a[N], n, k;
ll sum[N]; // houmian
map<int, int> ma;

int main()
{
	cin >> n >> k;
	for (int i =1 ; i <= n; i++) scanf("%d", &a[i]);
	for (int i = n; i >= 1; i--) sum[i] = sum[i + 1] + a[i];
	ll ans = 0;
	int temp = 0;
	for (int l = n; l >= 1; l--)
	{
		temp = 0;
		ll x = sum[l] % k;
		if (x == 0) temp += 1;
		temp += ma[x];
		ma[sum[l] % k]++;
		ans += temp;
	}
	cout << ans << endl;



	return 0;
}