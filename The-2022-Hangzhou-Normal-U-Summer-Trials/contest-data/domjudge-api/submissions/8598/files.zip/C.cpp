#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define fi first
#define se second
#define N 500010
ll a[N],c[N],sum[N];

void solve(){
	ll n,q,pro,mi=1e18+1,ma=0,l,r,ans,mid;
	cin>>n;
	for(ll i=1;i<=n;i++){
		cin>>a[i];
		if(i>1) {
		c[i-1]=a[i]-a[i-1];
		sum[i-1]=sum[i-2]+c[i-1];
		mi=min(mi,c[i-1]);
		ma=max(ma,c[i-1]);
		}
	}
	cin>>q;
	for(ll i=1;i<=q;i++){
		cin>>pro;
		if(pro<=mi){
			ans=n*pro;
		}else if(pro>ma){
			ans=a[n]+pro-1;
		}else{
			l=1;
			r=n-1;
			while(l<r){
				mid=(l+r)/2;
				if(c[mid]>pro){
					r=mid;
				}else{
					l=mid+1;
				}
			}
			ans=sum[l-1]+(n-(l-1))*pro;
		}
		cout<<ans<<'\n';
	}
}

int main(){
	int T=1;
	ios::sync_with_stdio(false);
	//cin>>T;
	while(T--){
		solve();
	}
	return 0;
}
