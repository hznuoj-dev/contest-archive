//#pragma GCC optimize(3)
#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <string>
#include <set>
#include<limits.h>
#include<unordered_map>
#include<unordered_set>
//#include<bits/stdc++.h>

#define int long long
#define IOS std::ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<long long,int> pli;
typedef pair<int,int> pii;
typedef pair<long long,long long> pll;
const int INF = 0x3f3f3f3f;
const double EPS = 1e-6;
const int MOD = 1e9 + 7;
const int MAXN = 5e5+10;
const int N = 1e6+33;

int n;
int m;
int t;
ll a[MAXN];
ll b[MAXN];
ull c[MAXN];
ll query(ll t){
    ll pos=upper_bound(b+1,b+1+n,t)-b-1;
    ll ans=c[pos];
    ans+=(n-pos)*t;
    return ans;
}
void solve(){
//    cin>>n;for(int i=1;i<=n;i++){cin>>a[i];}
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    cin>>m;
    a[n+1]=a[n];
    for(int i=1;i<=n;i++){
        b[i]=a[i+1]-a[i];
    }
    b[n]=LONG_LONG_MAX;
    for(int i=1;i<=n;i++){
        c[i]=c[i-1]+b[i];
    }
    while(m--){
        cin>>t;
        cout<<query(t)<<endl;
    }   
}

void init(){

}






signed main()
{
#ifdef LOCAL
freopen("in.in","r", stdin);
freopen("out.out","w", stdout);
#endif
IOS;

    int cases=1;
    // cin>>cases;
    // init();
    for(int cas=1;cas<=cases;cas++)
    {
        solve();
    }
}