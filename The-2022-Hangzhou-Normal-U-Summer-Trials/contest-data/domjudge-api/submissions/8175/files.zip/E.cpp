 #include <bits/stdc++.h>
 #define N 55
 using namespace std;
 char m[N][N];
 int n,f[N][N][N][N];
 struct node{
 	int ax,ay,bx,by;
 }s;
 int main(){
 	scanf("%d",&n);
 	for(int i=1;i<=n;i++)
 		scanf("%s",m[i]+1);
 	for(int i=1;i<=n;i++)
 		for(int j=1;j<=n;j++)
 			if(m[i][j]=='a'){
 				s.ax=i;
 				s.ay=j;
			}else if(m[i][j]=='b'){
				s.bx=i;
				s.by=j;
			}
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			for(int ii=1;ii<=n;ii++)
				for(int jj=1;jj<=n;jj++)
					f[i][j][ii][jj]=0x3f3f3f3f;
	for(int i=1;i<=n;i++)
		m[i][0]=m[0][i]=m[n+1][i]=m[i][n+1]='*';
	f[s.ax][s.ay][s.bx][s.by]=0;
	queue<node> q;
	q.push(s);
	int dx[]={1,-1,0,0};
	int dy[]={0,0,1,-1};
	while(!q.empty()){
		node u=q.front();
		node v;
		q.pop();
		for(int i=0;i<4;i++){
			v=u;
			if(m[u.ax+dx[i]][u.ay+dy[i]]!='*'){
				v.ax=u.ax+dx[i];
				v.ay=u.ay+dy[i];
			}
			if(m[u.bx+dx[i]][u.by+dy[i]]!='*'){
				v.bx=u.bx+dx[i];
				v.by=u.by+dy[i];
			}
			if(f[v.ax][v.ay][v.bx][v.by]<n*n){
				f[v.ax][v.ay][v.bx][v.by]=min(f[v.ax][v.ay][v.bx][v.by],f[u.ax][u.ay][u.bx][u.by]+1);
			}else{
				f[v.ax][v.ay][v.bx][v.by]=f[u.ax][u.ay][u.bx][u.by]+1;
				q.push(v);
			}
		}
	}
	int ans=0x3f3f3f3f;
	for(int i=1;i<=n;i++)
		for(int j=1;j<=n;j++)
			ans=min(ans,f[i][j][i][j]);
	if(ans==0x3f3f3f3f){
		puts("no solution");
	}else cout<<ans;
 	return 0;
 }
