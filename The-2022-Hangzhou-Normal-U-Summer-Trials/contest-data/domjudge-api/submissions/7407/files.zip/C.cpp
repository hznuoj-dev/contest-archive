#include<bits/stdc++.h>
#define ll long long 
using namespace std;
ll a[500100];
int main(){
	ios::sync_with_stdio(false);cin.tie();cout.tie();
	ll n;cin>>n;
	for(int i=0;i<n;i++) cin>>a[i];
	ll t;cin>>t;
	while(t--){
		ll sum=0;
		ll nn;cin>>nn;
		for(int i=0;i<n-1;i++){
			if(a[i]+nn<=a[i+1]) sum+=nn;
			else sum+=a[i+1]-a[i];
		}
		sum+=nn;
		cout<<sum<<"\n";
	}
}
