#include<bits/stdc++.h>
#define ll long long
#define pb push_back
using namespace std;
const ll maxn=1e6+9;
vector<ll>p[maxn];
ll dp[maxn];
ll ans[maxn];
void dfs(ll u,ll fa){
    dp[u]=1;
    for(auto i:p[u]){
        if(i==fa)continue;
        dfs(i,u);
        dp[u]+=dp[i];
    }
}
void getans(ll u,ll fa){
    for(auto i:p[u]){
        if(i==fa)continue;
        getans(i,u);
    }
    ll now=0;
    for(auto i:p[u]){
        if(i==fa)continue;
        ans[u]+=now*dp[i];
        now+=dp[i];
    }
    ans[u]+=now;
    ans[u]+=(dp[1]-dp[u]);
    ans[u]+=now*(dp[1]-dp[u]);
}
void solve(){
    ll n;
    cin>>n;
    for(ll i=1;i<=n-1;i++){
        ll u,v;
        cin>>u>>v;
        p[u].pb(v);
        p[v].pb(u);
    }
    dfs(1,0);
    getans(1,0);
    ll q;
    cin>>q;
    while(q--){
        ll x;
        cin>>x;
        cout<<ans[x]<<endl;
    }
}
signed main(){
    solve();
}