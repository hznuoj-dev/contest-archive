#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int maxn=5e5+10;
ll a[maxn],b[maxn];
//void solve(){
//	
//}
int main(){
	int n,q;
	cin>>n;
	cin>>a[1];
	for(int i=2;i<=n;i++){
		cin>>a[i];
		b[i-1]=a[i]-a[i-1];
	}
	sort(b+1,b+n);
	cin>>q;
	ll t,ans;
	for(int i=1;i<=q;i++){
		cin>>t;
		ans=t*n;
		int k=1;
		while(t>b[k]){
			ans=ans-(t-b[k]);
			k++;
			if(k==n) break;
		}
		cout<<ans<<"\n";
	}
	return 0;
}
