#include<bits/stdc++.h>
#define ll long long

using namespace std;

int main()
{
	string s;
	cin >> s;
	string k = "hznu";
	int sum = 0;
	int q = 0;
	for (int i = 0; i < s.size(); i++)
	{
		if (s[i] == k[q])
			q++;
		else
			q = 0;
		if (q == 4)
		{
			sum++;
			q = 0;
		}
	}
	cout << sum;
	return 0;
}
