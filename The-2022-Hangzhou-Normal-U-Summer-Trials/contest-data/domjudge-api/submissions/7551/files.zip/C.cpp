#include <stdio.h>
#include <stdlib.h>

int main()
{
	long long n, *a, q, t;
	long long cnt;
	
	scanf("%lld", &n);
	a = (long long *) malloc (n * sizeof(long long));
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &a[i]);
	}
	scanf("%lld", &q);
	while (q--)
	{
		cnt = 0;
		scanf("%lld", &t);
		for (int i = 0; i < n; i++)
		{
			if (i < n - 1)
			{
				if (a[i] + t <= a[i + 1])
				{
					cnt += t;
				}
				else
				{
					cnt += (a[i + 1] - a[i]);
				}
			}
			else
			{
				cnt += t;
			}
		}
		printf("%lld\n", cnt);
	}
	
	return 0;
}
