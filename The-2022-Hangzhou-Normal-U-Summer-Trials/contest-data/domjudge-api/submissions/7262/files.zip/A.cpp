#include<bits/stdc++.h>
using namespace std;
const int maxn = 1e3 + 10;
int c[30];//���ÿ����ĸ������������ 
struct New_String{
	string str;
	bool operator < (const New_String &A) const{
		int t = min(str.length(), A.str.length());
		for(int i = 0; i <= t; ++i){
			if(str[i] != A.str[i]){
				return c[(int)(str[i] - 'a')] < c[(int)(A.str[i] - 'a')];
			}
		}
		return str.length() < A.str.length();
	}
}nst[maxn];
string s;
int main(){
	int n;
	cin >> s; cin >> n;
	for(int i = 0; i < s.length(); ++i){//��ȡÿ����ĸ�������ĵ����� 
		int index = (int)(s[i] - 'a');
		c[index] = i + 1;
	}
	for(int i = 0; i < n; ++i) cin >> nst[i].str;
	sort(nst, nst + n);
	int k;
	cin >> k;
	cout << nst[k - 1].str << '\n';
	return 0;
} 
