 #include<bits/stdc++.h>
 #include<algorithm>
 #include<cmath>
 #include<map>
 using namespace std;
 map<char,int>a;
 map<int,string>x1;
 map<string,int>b;
 int w[1010];
 int main()
 {
     string s;
     cin>>s;
     int n;
     int x=1;
     for(int i=0;i<s.size();i++){
         a[s[i]]=x;
         x++;
         //cout<<a[s[i]]<<endl;
     }
    cin>>n;
    int q=0;
    int t=0;
    while(n--){
        string c;
        cin>>c;
        for(int i=0;i<c.size();i++){
            b[c]+=b[c]+a[c[i]];
        }
        w[t++]=b[c];
        x1[b[c]]=c;
        // cout<<x1[b[c]]<<endl;
    }
    sort(w,w+t);
    int m;
    cin>>m;
    cout<<x1[w[m-1]]<<endl;
    return 0;
 }