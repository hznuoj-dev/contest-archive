#include<bits/stdc++.h>
#define io ios::sync_with_stdio(false);cin.tie(0),cout.tie(0);
using namespace std;

typedef long long ll;

ll n, m, k, t, ans;
int top = -1;
int a[100010];
long long pre[100010]; 
long long now = 0;
int cnt[3];
int main () {
	cin >> n >> k;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		pre[i] = pre[i - 1];
		pre[i] += a[i];
		if (pre[i] % k == 0) {
			cnt[0]++;
			ans++;
		}
		if (pre[i] % k == 1) {
			cnt[1]++;
		}
		if (pre[i] % k == 2) {
			cnt[2]++;
		}
		
	}
	for (int i = 1; i <= n - 1; i++) {
		if (a[i] % k == 1) {
			now += 1;
			now %= 3;
		} else if (a[i] % k == 2) {
			now += 2;
			now %= 3;
		}
		cnt[now]--;
		if (now % k == 0) {
			ans += cnt[0];
//			cout << 0 << cnt[0] << ' ';
		} else if (now % k == 1) {
			ans += cnt[1];
//			cout << 1<<  cnt[1] << ' ';
		} else {
			ans += cnt[2];
//			cout << 2 <<  cnt[2] << ' ' ;
		}
	}
	cout << ans;
	return 0;
}
