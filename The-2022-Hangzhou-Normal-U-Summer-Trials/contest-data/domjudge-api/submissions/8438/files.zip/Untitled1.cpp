#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define maxn 100005
#define nmax 100000*50000+5
int a[maxn];
int main()
{
	ll n,k,i,ans=0,j,t;
	cin>>n>>k;
	ll dp[(n*n+1)/2];
	for(i=1;i<=n;i++)
	{
		cin>>a[i];
	}
	dp[1]=a[1];
	t=1;
	for(j=2,i=n;i>=1,j<=n;i--,j++)
	{
		t+=i;
		dp[t]=a[j];
		if(dp[t]%k==0)
		ans++;
	}
	for(i=1;i<=n;i++)
	{
		for(j=i;j<=n-i;j++)
		{
			dp[i+j]=dp[i+j-1]+a[j];
			if(dp[i+j]%k==0)
				ans++;
		}
	}
	cout<<ans;
	
} 
