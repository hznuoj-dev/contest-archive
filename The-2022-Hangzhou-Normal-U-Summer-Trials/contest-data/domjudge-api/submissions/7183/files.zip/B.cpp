#include <bits/stdc++.h>
#define ll long long

using namespace std;
typedef pair<int, int> PII;
typedef pair<char, char> PCC;

const int N = 1e6 + 10, mod = 1e9 + 7;

ll gcd(ll a, ll b) { return b ? gcd(b, a % b) : a;}
ll lcm(ll a, ll b) { return a * b / gcd(a, b); }
ll qmi(ll a, ll b) { ll res = 1; while(b) { if(b & 1) res = (res * a) % mod; a = (a * a) % mod; b >>= 1;} return res % mod; }

map<char, __int128_t> mp;
int n, k;
__int128_t s[1010];
map<__int128_t, string> ans;

void solve()
{
	string t;
	cin >> t;
	__int128_t last = 0;
	for (__int128_t i = 0; i < t.size(); i ++)
	{
		mp[t[i]] = last * 26 + i;
		last = mp[t[i]];
	}
	//cout << last << endl;

	cin >> n;
	for (int i = 1; i <= n; i ++)
	{
		string str; cin >> str;
		__int128_t num = 0;
		for (int j = 0; j < str.size(); j ++)
			num += mp[str[j]];
		s[i] = num;
		//cout << num << '\n';
		ans[s[i]] = str;
	}

	cin >> k;
	sort(s + 1, s + 1 + n);
	cout << ans[s[k]] << '\n';
}

int main()
{
	ios::sync_with_stdio(0);
	cin.tie(0); cout.tie(0);
    int T = 1;
	//cin >> T;
	while(T --)
	{
		solve();
	}
    return 0;
}
