#include <bits/stdc++.h>
using namespace std;
#define ll long long
int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int n;
    cin>>n;
    ll a[n];
    for(int i=0;i<n;i++)cin>>a[i],a[i]-=(a[0]-1);
    ll le[n];
    le[0]=a[0];
    for(int i=1;i<n;i++)le[i]=a[i]-a[i-1];
    int q;
    cin>>q;
    while(q--){
        ll t,ans=0;
        cin>>t;
        if(t==0){
            cout<<0<<'\n';
            continue;
        }
        else if(t==1){
            cout<<n- count(le,le+n,0)<<'\n';
            continue;
        }
        ll p= lower_bound(le,le+n,t)-le;
        if(p-1>=0)ans+=a[p-1]-1;
        if(p<n)cout<<ans+t*(n-p+1)<<'\n';
        else cout<<a[n-1]+t<<'\n';
    }
    return 0;
}
