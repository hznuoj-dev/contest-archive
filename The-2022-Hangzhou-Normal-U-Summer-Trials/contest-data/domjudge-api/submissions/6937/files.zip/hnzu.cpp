#include <iostream>
#include <cstring>
using namespace std;
int main(){
    char str[100010];
    int sum = 0, i, len;
    while(cin >> str){
        sum = 0;
        len = strlen(str);
        for(i = 0; i < len; i++){
            if(str[i] == 'h'){
                if(str[i+1] == 'z' && str[i+2] == 'n' && str[i+3] == 'u'){
                    sum++;
                    i += 3;
                }
            }
        }
        cout << sum << '\n';
    }
    return 0;
}