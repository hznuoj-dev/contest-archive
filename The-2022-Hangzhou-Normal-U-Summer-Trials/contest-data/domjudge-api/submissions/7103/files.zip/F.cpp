#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define wtnnb ios::sync_with_stdio(false);//cin.tie(0);cout.tie(0);
const int N = 1e6+10;
ll a[N];
ll s[N];
signed main(){
    ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
    int n,k;cin>>n>>k;   
    for(int i=1;i<=n;i++)cin>>a[i];
    for(int i=1;i<=n;i++)s[i]=s[i-1]+a[i];
    map<ll,int>mp;
    for(int i=0;i<=n;i++)mp[s[i]%k]++;
    ll ans=0;
    map<ll,int>::iterator it=mp.begin();
    for(;it!=mp.end();it++){
    	ll cost=0;
    	int x= it->second;
    	cost=(x-1)*x/2;
    	ans+=cost;
	}
	cout<<ans<<endl;
}

