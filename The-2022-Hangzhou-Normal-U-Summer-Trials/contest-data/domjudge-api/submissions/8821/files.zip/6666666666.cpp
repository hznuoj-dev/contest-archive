
#include <bits/stdc++.h>
using namespace std;

#define INF 0x3f3f3f3f
#define int long long
#define ll long long
#define endl '\n'
#define null NULL
#define ls p<<1
#define rs p<<1|1
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define vi vector<int>
#define mii map<int,int>
#define pii pair<int,int>
#define ull unsigned long long
#define pqi priority_queue<int>
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define ct cerr<<"Time elapsed:"<<1.0*clock()/CLOCKS_PER_SEC<<"s.\n";
#define ull unsigned long long
#define rep(i,a,b) for(int i=(a);i<=(b);i++)
inline int rd() {//�����Ż������Լӿ����ֵ�����
	char p = 0; int r = 0, o = 0;
	for (; p < '0' || p>'9'; o |= p == '-', p = getchar());
	for (; p >= '0' && p <= '9'; r = (r << 1) + (r << 3) + (p ^ 48), p = getchar());
	return o ? (~r) + 1 : r;
}
void write(int x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
const int M=2e3+10;
map<char,int> ma;
struct node{
	string s;
	int val;
}p[M];
bool cmp(node a,node b){
	return a.val<b.val;
}
signed main()
{
	string s;
	cin>>s;
	int len=s.size();
	for(int i=0;i<len;i++){
		ma[s[i]]=i;
	}
	int n;
	n=rd();
	for(int i=1;i<=n;i++)
	{
		cin>>p[i].s;
		string x=p[i].s;
		p[i].val=0;
		for(int j=0;j<(int)x.size();j++){
			p[i].val=p[i].val*26+ma[x[j]];
		}
	}
	sort(p+1,p+1+n,cmp);
	int k;
	cin>>k;
	cout<<p[k].s<<endl;
	
}
