#include<bits/stdc++.h>
using namespace std;
#define ll long long
int a[100006];
int s[100006];
map<ll,ll>mp;
int main(){
	int n,k;
	cin>>n>>k;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		s[i]=s[i-1]+a[i];
		s[i]=s[i]%k;
	}
	
	ll ans=0;
	ll m=1;
	s[0]=0;
	sort(s,s+1+n);
	for(int i=1;i<=n;i++){
	if(s[i]==s[i-1]){
       m++;		
	}
	else {
		ans+=m*(m-1)/2; 
	    m=1;
	}	
	}
		ans+=m*(m-1)/2; 
	cout<<ans<<"\n";
} 
