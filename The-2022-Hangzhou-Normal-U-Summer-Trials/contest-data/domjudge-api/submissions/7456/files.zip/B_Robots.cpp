#include<iostream>
#include<algorithm>
#include<cstring>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
using namespace std;
typedef long long ll;
const int N = 100010;
const int M = 200010;
int h[N], ne[M], e[M], idx;
void add(int a, int b) {
    e[idx] = b, ne[idx] = h[a], h[a] = idx++;
}
int n;
ll f[N];
ll ff[N];
ll fff[N];
void dfs(int cur, int rt) {
    ll cnt = 0;
    ll sum = 0;
    fff[cur] = 1;
    for (int i = h[cur]; i != -1; i = ne[i]) {
        int j = e[i];
        if(j == rt) continue;
        cnt++;
        dfs(j, cur);
        fff[cur] += fff[j];
        ff[cur] += ff[j];
        sum += ff[j] + 1ll;
    }
    ff[cur] += cnt;
    for (int i = h[cur]; i != -1; i = ne[i]) {
        int j = e[i];
        if(j == rt) continue;
        f[cur] += (ff[j] + 1) * (sum - ff[j] - 1ll);
    }
    f[cur] /= 2ll;
    f[cur] += ff[cur];
    f[cur] += (ff[cur] + 1ll) * (n - fff[cur]);
}
int main() {
	IOS;
    cin >> n;
    for (int i = 1; i <= n; i++) {
        h[i] = -1;
    }
    for (int i = 1; i <= n - 1; i++) {
        int u, v; cin >> u >> v;
        add(u, v); add(v, u);
    }
    dfs(1, -1);
    int q; cin >> q;
    while(q--) {
        int x; cin >> x;
        cout << f[x] << "\n";
    }
}