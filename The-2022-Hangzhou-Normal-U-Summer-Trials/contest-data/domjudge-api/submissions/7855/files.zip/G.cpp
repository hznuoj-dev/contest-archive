#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 1e5 + 10, inf = 2000000000;
int id[10] = {2, 3, 5, 7, 11, 13, 17, 19, 23, 29};
struct Info{
	int a[10];
	void init(int k){
		for(int i = 0; i < 10; i++){
			a[i] = k;
		}
	}
}un[N << 2], lo[N << 2], ans, lz[N << 2];

Info merge(Info a, Info b){
	Info res;
	for(int i = 0; i < 10; i++){
		res.a[i] = min(a.a[i], b.a[i]);
	}
	return res;
}

void apply(int k, Info p){
	for(int i = 0; i < 10; i++){
		un[k].a[i] += p.a[i];
		lz[k].a[i] += p.a[i];
	}
}

void pd(int k){
	apply(k << 1, lz[k]);
	apply(k << 1 | 1, lz[k]);
	lz[k].init(0);
}

void build(int k, int l, int r){
	un[k].init(0);
	lo[k].init(inf);
	lz[k].init(0);
	if(l == r){
		return;
	}
	int mid = (l + r) >> 1;
	build(k << 1, l, mid);
	build(k << 1 | 1, mid + 1, r);
	un[k] = merge(un[k << 1], un[k << 1 | 1]);
	lo[k] = merge(lo[k << 1], lo[k << 1 | 1]);
}

void upd(int k, int l, int r, int ql, int qr, Info x, int f){
	if(l > qr || r < ql) return;
	if(l >= ql && r <= qr){
		for(int i = 0; i < 10; i++){
			un[k].a[i] += x.a[i] * f;
			lz[k].a[i] += x.a[i] * f;
		}
		return;
	}
	pd(k);
	int mid = (l + r) >> 1;
	upd(k << 1, l, mid, ql, qr, x, f);
	upd(k << 1 | 1, mid + 1, r, ql, qr, x, f);
	un[k] = merge(un[k << 1], un[k << 1 | 1]);
}

void change(int k, int l, int r, int p){
	if(l > p || r < p) return;
	if(l == p && r == p){
		for(int i = 0; i < 10; i++){
			int tmp = un[k].a[i];
			un[k].a[i] = lo[k].a[i];
			lo[k].a[i] = tmp;
		}
		return;
	}
	pd(k);
	int mid = (l + r) >> 1;
	change(k << 1, l, mid, p);
	change(k << 1 | 1, mid + 1, r, p);
	un[k] = merge(un[k << 1], un[k << 1 | 1]);
	lo[k] = merge(lo[k << 1], lo[k << 1 | 1]);
}

void qry(int k, int l, int r, int ql, int qr){
	if(l > qr || r < ql) return;
	if(l >= ql && r <= qr){
		ans = merge(ans, un[k]);
		ans = merge(ans, lo[k]);
		return;
	}
	pd(k);
	int mid = (l + r) >> 1;
	qry(k << 1, l, mid, ql, qr);
	qry(k << 1 | 1, mid + 1, r, ql, qr);
}

Info v[31];
char k[10];

void solve(){
	int n, q;
	scanf("%d%d", &n, &q);
	build(1, 1, n);
	while(q--){
		scanf("%s", k);
		if(k[0] == 'm'){
			int l, r, x;
			scanf("%d%d%d", &l, &r, &x);
			upd(1, 1, n, l, r, v[x], 1);
		}else if(k[0] == 'd'){
			int l, r, x, ok = 1;
			scanf("%d%d%d", &l, &r, &x);
			ans.init(inf);
			qry(1, 1, n, l, r);
			for(int i = 0; i < 10; i++){
				if(ans.a[i] < v[x].a[i]) ok = 0;
			}
			if(!ok){
				printf("NO\n");
			}else{
				printf("YES\n");
				upd(1, 1, n, l, r, v[x], -1);
			}
		}else{
			int p;
			scanf("%d", &p);
			change(1, 1, n, p);
		}
	}
}

int main(){
	int T = 1;
	for(int i = 1; i <= 30; i++){
		int t = i;
		for(int j = 0; j < 10; j++){
			int c = 0;
			while(t % id[j] == 0) t /= id[j], c++;
			v[i].a[j] = c;
		}
//		cout << i << ":: ";
//		for(int j = 0; j < 10; j++){
//			cout << v[i].a[j] << ' ';
//		}
//		cout << '\n';
	}
	while(T--) solve();
	return 0;
}
