#include<bits/stdc++.h>

using namespace std;

#define debug(x) cerr << #x << " = " << x << '\n'

typedef long long ll;

const int N = 2e5 + 10;

void solve() {
	int n;
	cin >> n;
	vector<ll> a(n + 1);
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
	} 
	vector<ll> b;
	for (int i = 2; i <= n; ++i) {
		b.push_back(a[i] - a[i - 1] + 1);
	}
	
//	for (int i = 0;i < b.size(); ++i) {
//		debug(b[i]);
//	}
	
	int q;
	cin >> q;
	while (q--) {
		ll t;
		cin >> t;
		if (t < b[0]) {
			cout << t * n << '\n';
			continue;
		}
		
		int p = lower_bound(b.begin(), b.end(), t) - b.begin();
		ll ans = a[p + 1] + (n - p) * t - 1; 
//		printf("p = %d ans = %d\n", p, ans);
		cout << ans << '\n'; 
	}
}

/*
3
1 3 8
3
2
4
10
*/ 

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
