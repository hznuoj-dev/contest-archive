#include<bits/stdc++.h>
using namespace std;
int main()
{
	string s,str[1011];
	getline(cin,s);
	int n;
	cin>>n;
	getchar(); 
	for(int k=0;k<n;k++)
	{
		getline(cin,str[k]);
	}
	int t;
	cin>>t;
	string a;
	for(int i=0;i<t;i++)
	{
		for(int j=n-1;j>i;j--)
		{
			int l1,l2,flag=0;
			int p1,p2;
			l1=str[j].size();
			l2=str[j-1].size();
			for(int k=0;k<min(l1,l2);k++)
			{
				p1=s.find(str[j][k]);
				p2=s.find(str[j-1][k]);
				if(p1<p2)
				{
					a=str[j];
					str[j]=str[j-1];
					str[j-1]=a;
					flag=1;
					break;
				}
				else if(p1>p2)
				{
					flag=1;
					break;
				}
			}
			if(flag==0)
			{
				if(p1<p2)
				{
					a=str[j];
					str[j]=str[j-1];
					str[j-1]=a;
				}
			}
		}
	}
	cout<<str[t-1];
	return 0;
}
