#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
typedef pair<int, int> pii;

bool cmp(pair<string, string> a, pair<string, string> b) {
	return a.first < b.first;
}

int main() {
	string s;
	cin >> s;
	int len = s.size();
	map<char, char> m;
	for (int i = 0; i < len; i++) {
		m[s[i]] = char(i + 'a');
	}
	int n;
	cin >> n;
	vector<pair<string, string>> v(n);
	for (int i = 0; i < n; i++) {
		string t;
		cin >> t;
		int len1 = t.size();
		for (int j = 0; j < len1; j++) {
			v[i].first.push_back(m[t[j]]);
			v[i].second.push_back(t[j]);
		}
	}
	int k;
	cin >> k;
	cout << v[k - 1].second << "\n";
	return 0;
}

