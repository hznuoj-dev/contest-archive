#include<bits/stdc++.h>
using namespace std;
string s;
int cnt=0;
int main(){
	cin>>s;
	for(int i=0;i<(int)s.size()-3;++i){
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u') cnt++;
	}
	cout<<cnt;
	return 0;
}
