#include<bits/stdc++.h>
using namespace std;
long long a[500007];
long long cha[500007];
int n;
void run(){
	long long k;
	cin>>k;
	long long ans=0;
	if(k>=cha[n-1]){
		ans=a[n-1]+k-1;
	}
	else{
		long long l=0;
		long long r=n-1;
		while(l<r){
			long long mid=(l+r)/2;
			if(k<cha[mid]){
				r=mid-1;
				if(r<=l){
					if(cha[l+1]<k){
						l++;
					}
					break;
				}
			}
			else if(k==cha[mid]){
				l=mid;
				break;
			}
			else if(k>cha[mid]){
				l=mid+1;
				if(l>=r){
					if(cha[l]>k){
						l--;
					}
					break;
				} 
			}
			
		}
		//cout<<"l="<<l<<endl;
		ans=a[l]+(n-1)*k-1;
	}
	cout<<ans<<endl;
}
int main()
{
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
		cha[i]=a[i]-a[i-1];
	}
	long long q;
	cin>>q;
	while(q--){
		run();
	}
	return 0;
}
