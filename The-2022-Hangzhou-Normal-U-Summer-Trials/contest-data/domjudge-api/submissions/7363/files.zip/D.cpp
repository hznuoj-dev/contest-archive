#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
const int N = 1e5 + 10;

vector<int> e[N];
int sz[N], n;
ll f[N];

void dfs(int u, int fa){
	sz[u] = 1;
	ll ans = 0;
	for(int i : e[u]){
		if(i == fa) continue;
		dfs(i, u);
		sz[u] += sz[i];
		ans += 1ll * (n - 1 - sz[i]) * sz[i];
	}
	ans += 1ll * (n - sz[u]) * (sz[u] - 1);
	ans /= 2;
	f[u] = ans + n - 1;
}

void solve(){
	scanf("%d", &n);
	for(int i = 1, u, v; i < n; i++){
		scanf("%d%d", &u, &v);
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs(1, 0);
	int q;
	scanf("%d", &q);
	while(q--){
		int u;
		scanf("%d", &u);
		printf("%lld\n", f[u]);	
	}
}

int main(){
	int T = 1;
	while(T--) solve();
	return 0;
}
