#include<bits/stdc++.h>
#define IOS ios::sync_with_stdio(0),cin.tie(0);
#define x first
#define y second
using namespace std;
typedef long long ll;
typedef pair<int,int>PII;
const int N=5e5+7,mod=1e9+7;

ll n,m;
ll a[N];
ll sum[N];

void solve(){
    cin>>n>>m;
    for(int i=1;i<=n;i++)cin>>a[i],a[i]%=m;
    for(int i=1;i<=n;i++)sum[i]=sum[i-1]+a[i];
    ll ans=0;
    for(int len=1;len<=n;len++){
        for(int i=1;i+len-1<=n;i++){
            if((sum[i+len-1]-sum[i-1])%m==0)ans++;
        }
    }
    cout<<ans<<endl;
}

int main(){
    IOS
    solve();
    return 0;
}