#include<bits/stdc++.h>
using namespace std;
#define ll long long
vector<int>g[100008];
const int mod=1e9+7;
ll a[1000008];
ll qpow(ll a,ll b){
	ll ans=1;
	while(b){
		if(b&1){
			ans=ans*a%mod;
		}
		a=a*a%mod;
		b>>=1;
	}
	return ans%mod;
}
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
//	cout<<qpow(2,10)<<"\n";
	ll n,s,q;
	cin>>n>>s>>q;
	ll w=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		w+=a[i];
	}
	if(n==1){
		while(q--){
			ll x,y;
			cin>>x>>y;
			if(y<=s){
				cout<<s-y+1<<"\n";
			}
			else cout<<"0\n";
			
		}
	}
	else {
	
	while(q--){
		ll x,y;
		cin>>x>>y;
		ll k=y-a[x];
//		cout<<"k="<<k<<"\n";
		w+=k;
		a[x]=y;
		if(w>s){
			cout<<0<<"\n";
		}
		else {
		ll e=s-w;
//		cout<<e<<"asd\n";
		ll ans=(1+n*((1+e)*(e)%mod)%mod*qpow(2,mod-2)%mod)%mod;
		cout<<ans%mod<<"\n"; 
	}
}
	}
	
	
} 
/*
1 5 1
1 
1 1
*/

