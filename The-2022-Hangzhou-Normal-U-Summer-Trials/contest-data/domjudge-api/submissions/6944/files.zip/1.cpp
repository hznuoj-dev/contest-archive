 #include<iostream>
 using namespace std;
 int main()
 {
     string s;
     string k="hznu";
     cin>>s;
     int x=1;
     int sum=0;
     for(int i=0;i<s.size()-1;i++){
         if(s[i]=='h'){
             for(int j=i+1;j<=i+3;j++){
                 if(s[j]==k[x]) x++;
                 else break;
             }
         }else{
             x=1;
         }
         if(x==4) sum++; 
     }
     cout<<sum<<endl;
     return 0;
 }