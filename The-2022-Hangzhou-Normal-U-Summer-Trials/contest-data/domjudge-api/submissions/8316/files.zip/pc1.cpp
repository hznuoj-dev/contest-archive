#include<bits/stdc++.h>
using namespace std;
map<char,int>mp;
bool cmp(string a,string b)
{
	if(a.size()<b.size())
	{
		if(b.find(a))
		{
			return true;
		}
	else
	{
		for(int i=0;i<a.size();i++)
		{
			if(mp[a[i]]<mp[b[i]])
			{
				return true;
			}
		}
	}
}
else if(a.size()==b.size())
{
for(int i=0;i<a.size();i++)
		{
			if(mp[a[i]]<mp[b[i]])
			{
				return true;
			}
		}	
}
else
{
	for(int i=0;i<b.size();i++)
	{
		if(mp[a[i]]<mp[b[i]])
		{
			return true;
		 } 
	}
}
}
int main()
{
	mp.clear();
	string s;
	cin>>s;
	for(int i=0;i<26;i++)
	{
		mp[s[i]]=i;
	}
	string n[1010];
	int m,k;
	cin>>m;
	for(int i=0;i<m;i++)
	{
		cin>>n[i];
	}
	sort(n,n+m,cmp);
	cin>>k;
	cout<<n[k-1]<<endl;
	return 0;
}
 
