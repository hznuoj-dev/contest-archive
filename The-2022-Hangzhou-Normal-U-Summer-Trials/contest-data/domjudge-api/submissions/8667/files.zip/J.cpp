#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 1e5 + 7;

pair<int,pair<int,int>> mp[N];

int fa[35];
int find(int x) {
	return x == fa[x] ? x : fa[x] = find(fa[x]);
}
queue<int> ans;
void solve() {
	int q;
	cin >> q;
	for (int i = 1; i <= q; ++i) {
		int op;
		cin >> op;
		if (op == 1) {
			char x;
			cin >> x;
			mp[i] = {1,{x - 'a' + 1,0}};
		}
		else if (op == 2) {
			mp[i] = {2,{0,0}};
		}
		else {
			char x,y;
			cin >> x >> y;
			mp[i] = {3,{x - 'a' + 1,y - 'a' + 1}};
		}
	}
	for (int i = 1; i <= 30; ++i) {
		fa[i] = i;
	}
	for (int i = q; i >= 1; --i) {
		if (mp[i].first == 3) {
			int x = mp[i].second.first;
			int y = mp[i].second.second;
			x = find(x);
			y = find(y);
			if (x != y) {
				fa[x] = y;
			}
		}
		else if (mp[i].first == 1) {
			ans.push(find(mp[i].second.first));
		}
		else {
			ans.pop();
		}
	}
	if (ans.empty()) {
		cout << "The final string is empty";
		return;
	}
	string s;
	while (!ans.empty()) {
		s += ans.front() + 'a' - 1;
		ans.pop();
	}
	reverse(s.begin(),s.end());
	cout << s;
}
int main() {
	ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
/*
5
1 2
1 3
3 4
3 5
5
1
2
3
4
5
*/
