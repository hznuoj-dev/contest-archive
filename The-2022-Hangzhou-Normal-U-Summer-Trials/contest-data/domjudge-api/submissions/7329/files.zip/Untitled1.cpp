#include<iostream>
#include<algorithm>
#include<string>
#define endl "\n"
using namespace std;
typedef long long ll;
const int N=5e5+7;

ll a[N];
ll b[N];

int main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i];
	}
	for(int i=1;i<=n-1;++i){
		b[i]=a[i+1]-a[i];
	}
	int q;
	cin>>q;
	while(q--){
		ll t;
		cin>>t;
		ll sum=0;
		for(int i=1;i<=n-1;++i){
			if(t<=b[i])sum+=t;
			else sum+=b[i];
		}
		sum+=t;
		cout<<sum<<endl;
	}
	return 0;
}
