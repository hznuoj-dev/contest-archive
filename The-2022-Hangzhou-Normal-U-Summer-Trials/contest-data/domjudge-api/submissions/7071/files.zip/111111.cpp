#include<bits/stdc++.h>
using namespace std;
struct acm
{
	string ss;
	int t;
}a[1002];
int c(acm a,acm b)
{
	return a.t<b.t;
}
int main()
{
	string s;
	cin>>s;
	int n;cin>>n;
	int m=s.size();
	for(int i=0;i<n;i++)
	{
		cin>>a[i].ss;
		a[i].t=s.find(a[i].ss);
		if(a[i].t==-1) a[i].t=m;
	}
	int k;cin>>k;
	sort(a,a+n,c);
	for(int i=0;i<k;i++)
	cout<<a[i].ss<<endl;
}
