#include<cstdio>
#include<map>
using namespace std;

struct NODE
{
	char ch;
	bool v = 0;
	int pre;
} c[100015];

int pin, q, n;

struct CHANGE
{
	bool v = 0;
	char x, y;
} change[100015];

map <char, char> mp;

char ans[100015];
int anspin;

int main()
{
	scanf ("%d", &q);
	for (int i = 1; i <= q; i++)
	{
		int opt;
		scanf ("%d", &opt);
		if (opt == 1)
		{
			getchar();
			char ch;
			ch = getchar();
			c[i].ch = ch;
			c[i].v = 1;
			n++;
		}
		if (opt == 2)
		{
			int pin = i;
			while (pin--)
			{
				if (c[pin].v) 
				{
					c[pin].v = 0;
					break;
				}
			}
			n--;
		}
		if (opt == 3)
		{
			getchar();
			char x, y;
			x = getchar();
			getchar();
			y = getchar();
			change[i].v = 1;
			change[i].x = x;
			change[i].y = y;
		}
	}
	
	for (char i = 'a'; i <= 'z'; i++) mp[i] = i;
	
	for (int i = q; i >= 1; i--)
	{
		if (change[i].v) 
		{
			mp[change[i].x] = mp[change[i].y];
			continue;
		}
		if (c[i].v)
		{
			ans[++anspin] = mp[c[i].ch];
		}
	}
	
	if (!n) printf ("The final string is empty\n");
	else for (int i = anspin; i >= 1; i--) printf ("%c", ans[i]);
	
	return 0;
	
}
