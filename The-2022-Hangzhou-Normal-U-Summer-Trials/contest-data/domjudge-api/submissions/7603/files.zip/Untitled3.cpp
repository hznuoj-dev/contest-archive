#include <iostream>
#include <map>
using namespace std;
typedef long long ll;
const int N = 5e5 + 5;
ll qd[N] = {0};
map<ll, ll>m;

int main(void) {
	int n, q, t, ind;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> qd[i];
		if (i > 0) m[qd[i] - qd[i - 1]] = i;
	}
	cin >> q;
	for (int i = 1; i <= q; i++) {
		cin >> t;
		for (ll j = t; j > 0; j--) {
			if (m.count(j)) {
				ind = m[j];
				//
				cout << "ind: " << ind << ' ';
				break;
			}
		}
		if (ind != 0) cout << qd[ind] + (n - ind) * t - 1 << endl;
		else cout << n * t << endl;
		ind = 0;
	}
	return 0;
}
