#include<bits/stdc++.h>
using namespace std;
const int N = 5e1 + 10;
int fx[4] = {0, 0, 1, -1};
int fy[4] = {1, -1, 0, 0};
int mp[N][N], mpt[N][N][N][N];
int xa, ya, xb, yb;
int main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    int n; scanf("%d", &n);
    for(int i = 1;i <= n;i ++){
        for(int j = 1;j <= n;j ++){
            char c; scanf(" %c", &c);
            if(c == '.') mp[i][j] = 1;
            else if(c == 'a') xa = i, ya = j, mp[i][j] = 1;
            else if(c == 'b') xb = i, yb = j, mp[i][j] = 1;
        }
    }

    memset(mpt, -1, sizeof mpt);
    auto bfs = [&]() -> int {
        struct state{int xa, ya, xb, yb, t;};
        queue<state> q;
        q.push({xa, ya, xb, yb, 0});
        while(!q.empty()){
            auto node = q.front();
            int xa = node.xa, ya = node.ya;
            int xb = node.xb, yb = node.yb;
            q.pop();
            if(mpt[xa][ya][xb][yb] != -1) continue;
            int t = node.t;
            mpt[xa][ya][xb][yb] = t;
            if(xa == xb && ya == yb) return t;
            for(int i = 0;i <= 3;i ++){
                int flag1 = 0, flag2 = 0;
                if(mp[xa + fx[i]][ya + fy[i]] == 1) flag1 = 1;
                if(mp[xb + fx[i]][yb + fy[i]] == 1) flag2 = 1;
                if(flag1 == 0 && flag2 == 0) continue;
                int xanxt = xa, yanxt = ya;
                int xbnxt = xb, ybnxt = yb;
                if(flag1 == 1) xanxt += fx[i], yanxt += fy[i];
                if(flag2 == 1) xbnxt += fx[i], ybnxt += fy[i];
                if(mpt[xanxt][yanxt][xbnxt][ybnxt] != -1) continue;
                q.push({xanxt, yanxt, xbnxt, ybnxt, t + 1});
            }
        }
        return -1;
    };
    int ans = bfs();
    if(ans == -1) puts("no solution");
    else printf("%d\n", ans);

    return 0;
}