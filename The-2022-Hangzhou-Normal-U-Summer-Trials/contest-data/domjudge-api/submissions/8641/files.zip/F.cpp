#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[100100];
map <int,int> yu;
int main()
{
	ll k,l,t,ma,n;
	ll i,j,ans=0;
	cin>>n>>ma;
	for (i=1;i<=n;i++)
	{
		cin>>k;
		a[i]=a[i-1]+k;
		if (a[i]%ma==0) ans++;
		ans=ans+yu[a[i]%ma];
		yu[a[i]%ma]++;
	}
	cout<<ans;
}
