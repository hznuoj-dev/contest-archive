#include <bits/stdc++.h>
using namespace  std;
typedef long long ll;
const int  maxn = 2e5 + 10;
const int MOD = 998244353;
const int mod = 1e9 + 7;
const ll  INF = 1e18;
const int N = 21;
ll qpow(ll a, ll b) {
    ll res = 1;
    while(b) {
        if(b & 1) res = res * a % mod;
        a = a * a % mod;
        b >>= 1;
    }
    return res;
}
string s;
string p = "hznu";
void solve(){
    cin >> s;
    int ans= 0;
    for(int i = 0; i < s.size(); ++i) {
        string t;
        if(i + p.size() - 1 >= s.size())break;
        for(int j = 0; j < p.size(); ++j) {
            t += s[i + j];
        }
        if(t == p) ++ans;
    }
    cout << ans << '\n';

}


signed main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr); cout.tie(nullptr);
#ifdef ACM
    freopen("in.txt","r",stdin);
    freopen("out.txt","w",stdout);
#endif
    int t = 1;
//    cin >> t;
    while(t --) solve();
}