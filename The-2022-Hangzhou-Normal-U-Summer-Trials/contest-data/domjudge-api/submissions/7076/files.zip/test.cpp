//#pragma GCC optimize(3)
#include <iostream>
#include <cstdio>
#include <cstring>
#include <algorithm>
#include <vector>
#include <cmath>
#include <queue>
#include <stack>
#include <map>
#include <string>
#include <set>
#include<limits.h>
#include<unordered_map>
#include<unordered_set>
//#include<bits/stdc++.h>

#define int long long
#define IOS std::ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define endl "\n"
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<long long,int> pli;
typedef pair<int,int> pii;
typedef pair<long long,long long> pll;
const int INF = 0x3f3f3f3f;
const double EPS = 1e-6;
const int MOD = 1e9 + 7;
const int MAXN = 3e5+10;
const int N = 1e6+33;
map<char,int>m;
bool cmp(string a,string b){
    for(int i=0;i<min(a.length(),b.length());i++){
        if(m[a[i]]==m[b[i]]){
            continue;
        }else {
            return m[a[i]]<m[b[i]];
        }
    }
    return a.length()<b.length();

}
string s[1005];
void solve(){
    string tmp;
    cin>>tmp;
    for(int i=0;i<(int)tmp.length();i++){
        m[tmp[i]]=i+1;
    }
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>s[i];
    }
    int k;
    cin>>k;
    sort(s,s+n,cmp);
    cout<<s[k-1]<<endl;
}

void init(){

}






signed main()
{
#ifdef LOCAL
freopen("in.in","r", stdin);
freopen("out.out","w", stdout);
#endif
IOS;

    int cases=1;
    // cin>>cases;
    init();
    for(int cas=1;cas<=cases;cas++)
    {
        solve();
    }
}