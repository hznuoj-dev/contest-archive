#include<bits/stdc++.h>
using namespace std;
#define ll long long

const int maxn=1e5+10;
const ll mod=1e9+7;
char a[maxn];
int fa[maxn<<1];
int cut=0;
int cutf=0;
map<int,int>m;
int get(int x){
	if(fa[x]==x) return x;
	return (fa[x]=get(fa[x]));
}
int main(){
	int q;
	scanf("%d",&q);
	for(int i=0;i<maxn*2;i++){
		fa[i]=i;
	}
	while(q--){
		int o;
		scanf("%d",&o);
		//printf("%d\n",o);
		if(o==1){
			char s[10];
			scanf("%s",s);
			if(m[s[0]]){
				fa[++cut]=maxn+m[s[0]];
			}else{
				m[s[0]]=++cutf;
				a[cutf]=s[0];
				fa[++cut]=m[s[0]]+maxn;
			}
		}else if(o==2){
			if(cut>0){
				fa[cut]=cut--;
			}
		}else{
			char s1[10],s2[10];
			scanf("%s%s",s1,s2);
			if(m[s1[0]]){	
				if(!m[s2[0]]){
					m[s2[0]]=m[s1[0]];	
					a[m[s1[0]]]=s2[0];	
				}else{
					fa[m[s1[0]]]=m[s2[0]]+maxn;
				}
				m.erase(s1[0]);
			}
		}
	}
	if(cut==0) printf("The final string is empty");
	else{
		for(int i=1;i<=cut;i++){
			printf("%c",a[get(i)-maxn]);
		}
	}
} 

