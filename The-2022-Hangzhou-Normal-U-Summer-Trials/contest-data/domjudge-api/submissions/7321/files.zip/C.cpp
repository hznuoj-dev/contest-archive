#include<cstdio>
#include<algorithm>
using namespace std;

long long n;
long long a[500015];
long long q;
long long t;
long long ans;
long long d[500015];

bool check(long long mid, long long x)
{
	if (d[mid] >= x) return 1;
	return 0;
}

long long bsearch(long long x)
{
	long long l = 1, r = n, mid, ret;
	while (l <= r)
	{
		mid = (l + r) >> 1;
		if (check(mid, x))
		{
			ret = mid;
			r = mid - 1;
		}
		else l = mid + 1;
	}
	return ret;
}

int main()
{
	scanf ("%lld", &n);
	for (long long i = 1; i <= n; i++)
	{
		scanf ("%lld", &a[i]);
		d[i - 1] = a[i] - a[i - 1];
	}
	d[n] = 1e18 + 10;
	scanf ("%lld", &q);
	while (q--)
	{
		ans = 0;
		scanf ("%lld", &t);
		long long pin = bsearch(t);
		ans += a[pin] - a[1];
		ans += (n - pin + 1) * t;
		printf ("%lld\n", ans);
	}
	
	return 0;
}

