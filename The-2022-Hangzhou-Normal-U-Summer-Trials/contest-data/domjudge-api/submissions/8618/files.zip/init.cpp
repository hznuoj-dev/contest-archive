#include <bits/stdc++.h>
using namespace std;
vector<string>a;
typedef long long ll;
int main()
{
    ll t;
    char str[100010];
    int len = 0;
    cin >> t;
    while(t --)
    {
        int n;
        char c;
        cin >> n;
        if (n == 1)
        {
            cin >> c;
            str[len] = c;
            len ++;
        }
        else if (n == 2)
        {
            if (str[0] == '\0')
                continue;
            else 
            {
                str[len - 1] = '\0' ;
                len --;
            }
        }
        else if (n == 3)
        {
            char k;
            cin >> c >> k;
            for (int i = 0; i < len; i ++)
            {
                if (str[i] == c)
                    str[i] = k;
            }
        }
    }
    if (len == 0)
        cout << "The final string is empty" <<endl;
    else
        cout << str << endl;
    system("pause");
}