#include<bits/stdc++.h>
using namespace std;

const int N=2e5+7,M=1e9+7;
int p[37];
string s[1007];

bool cmp(string a,string b){
	int len=min(a.size(),b.size());
	for(int i=0;i<len;i++){
		if(a[i]!=b[i]){
			return p[a[i]-'a']<p[b[i]-'a'];
		}
	}
	return a.size()<b.size();
}

void solve(){
	string s0;
	cin>>s0;
	for(int i=0;i<s0.size();i++){
		p[s0[i]-'a']=i+1;
	}
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>s[i];
	}
	sort(s,s+n,cmp);
	int k;
	cin>>k;
	for(int i=0;i<k;i++){
		cout<<s[i]<<'\n';
	}
}

int main(){
	ios::sync_with_stdio(false);cin.tie(0);
	int T=1;
	//cin>>T;
	while(T--) solve();
	return 0;
}
