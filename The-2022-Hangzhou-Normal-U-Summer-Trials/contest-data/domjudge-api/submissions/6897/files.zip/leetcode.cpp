﻿#include <iostream>

using namespace std;

int main()
{
	string goal = "hznu";
	string s;
	int state = 0;
	int sum = 0;
	cin >> s;
	for (int i = 0; i < s.length(); ++i)
	{
		if (s[i] == goal[state])
		{
			state += 1;
			if (state == 4)
			{
				state = 0;
				sum += 1;
			}
		}
		else
		{
			state = 0;
			if (s[i] == 'h')
			{
				i -= 1;
			}
		}
	}
	cout << sum;
}