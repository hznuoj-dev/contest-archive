#include <bits/stdc++.h>
#define vi vector<int>
#define vc vector
#define vll vector<long long>
#define pii pair<int,int>
#define AXY(a,x,y) int x=(a).first,y=(a).second;
#define MID(l,r) int mid=((l)+(r))/2
#define ALL(arr) arr.begin(),arr.end()
using namespace std;
typedef long long ll;




#define int ll
signed main(){
	
	int n,k;
	cin>>n>>k;
	vi pre(n+1,0);
	for(int i=1;i<=n;i++)  cin>>pre[i];
	for(int i=1;i<=n;i++)  pre[i]+=pre[i-1];
	map<int,int> mp;
	for(int i=1;i<=n;i++){
		mp[pre[i]%k]++;
	}
	int res=0;
	res+=mp[0];
	for(auto i:mp){
		res+=i.second*(i.second-1)/2;
	}
	cout<<res<<endl;
	return 0;
}
