/*
 * @Author: JSY
 * @Date: 2022-05-14 12:50:31
 * @Last Modified by: JSY
 * @Last Modified time: 2022-05-14 12:50:31
*/

#include<bits/stdc++.h>
using namespace std;
#define ull unsigned long long
#define PII pair<int, int>
const int N = 10010;

int main(){
    string s;
    cin>>s;
    int i,flag = 0;
    for(i=0;i<=s.size()-4;i++){
        if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
            flag = 1;
            break;
        }
    }
    if(flag==1){
        printf("1");
    }else{
        printf("0");
    }
    return 0;
}
