#include<iostream>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>
#include<set>

#define ll long long
#define lowbit(x) ((x)&(-(x)))
#define pb push_back
#define vi vector<int>
#define pii pair<int, int>
#define allv(x) (x).begin(), (x).end() 
#define bit32(x) (__builtin_popcount((unsigned int)(x)))
#define bit64(x) (bit32(x>>32)+bit32(x))
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

using namespace std;
const int N = 1e5 + 10;
ll a[N];
int main(){
    int n;
    scanf("%d",&n);
    //cout<<n;
    ll x1,x2;
    scanf("%lld",&x1);
    //cout<<x1;
    for(int i=1;i<n;i++)
    {
        scanf("%lld",&x2);
        a[i]=x2-x1;
        x1=x2;
        //cout<<a[i]<<' ';
    }
    int T;
    scanf("%d",&T);
    //cout<<T<<endl;
    while(T--)
    {
        ll t;
        scanf("%lld",&t);
        //cout<<t<<' ';
        ll res=0;
        for(int i=1;i<n;i++)
        {
            res+=min(a[i],t);
        }
        res+=t;
        printf("%lld\n",res);
    }
    return 0;
}