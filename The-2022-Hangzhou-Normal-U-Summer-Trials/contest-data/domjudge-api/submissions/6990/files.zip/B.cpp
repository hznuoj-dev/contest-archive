#include<bits/stdc++.h>
using namespace std;

map<char, int>mp;
string str;
string s[1010];
int n, k;

bool comp(string s1, string s2){
    for(int i = 0; i < s1.length() && i < s2.length(); i++){
        if(s1[i] != s2[i]) return mp[s1[i]] < mp[s2[i]];
    }
    return s1.length() < s2.length();
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0),cout.tie(0);
    cin >> str;
    int ans = 0;
    for(int i = 0; i < str.length(); i++){
        mp[str[i]] = ans;
        ans++;
    }
    cin >> n;
    for(int i = 1; i <= n; i++){
        cin >> s[i];
    }
    cin >> k;
    sort(s + 1, s + 1 + n, comp);
    cout << s[k] << '\n';
} 