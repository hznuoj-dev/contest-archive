#include<bits/stdc++.h>
#define int long long
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
const int N = 5e5 + 10;
int a[N], b[N];
string s[N];
typedef pair<int,int> PII;
typedef long long ll;
const int mod = 998244353;
int n, m;
int cnt = 0;
int gcd(int a,int b) {return b? gcd(b,a%b):a;}
map<char, int> mp;
void solve()
{
    cin >> n;
    cnt = 0;
    for(int i = 1; i <= n; i ++ )
    {
        cin >> a[i];
        if (i >= 2) b[++ cnt] = a[i] - a[i - 1];
    }
    int q;
    cin >> q;
    while (q -- )
    {
        int x;
        cin >> x;
        int pos = upper_bound(b + 1, b + cnt + 1, x) - b;
        if (pos == cnt + 1)
        {
            cout << a[n] + x - 1 << endl;
        }
        else
        {
            if (pos >= 2)
            cout << a[pos] - 1 + (n - pos + 1) * x << endl;
            else
            {
                cout << (n - pos + 1) * x << endl; 
            }
        }
    }
}
signed main()
{
    solve();
}
/*
7
qst
qrt
qrs
abce
axy
hxy
abcd
*/