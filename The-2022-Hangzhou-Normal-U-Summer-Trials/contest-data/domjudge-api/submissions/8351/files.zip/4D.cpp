#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

const int N=1e5+10;
ll n,q,sum[N],st[N],res,jl[N];
vector<ll> e[N],ans[N];

int dfs(int x)
{
	int cnt=0,t=1;
	for(auto i:e[x])
	{
		if(!st[i])
		{
			cnt++;
			st[i]=1;
			int tt=dfs(i);
			t+=tt;
			ans[x].push_back(tt);
			sum[x]+=tt;
			
		}
	}
	if(n-sum[x]-1 != 0) ans[x].push_back(n-sum[x]-1);	
	return t;
}

int main()
{
	cin>>n;
	for(int i=1;i<n;i++)
	{
		int a,b;
		cin>>a>>b;
		e[a].push_back(b);
		e[b].push_back(a);
	}
	
	st[1]=1;
	dfs(1);
	
	cin>>q;
	while(q--)
	{
		int x;
		cin>>x;
		if(ans[x].size()==1) cout<<n-1<<endl;
		else
		{
			res=0;
			for(int i=0;i<ans[x].size();i++) res+=ans[x][i];
			for(int i=0;i<ans[x].size();i++)
				for(int j=i+1;j<ans[x].size();j++)
					res+=ans[x][i]*ans[x][j];
			cout<<res<<endl;
		}
	}
	
	return 0;
}
