#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
#define all(a) a.begin(), a.end()
#define ios std::ios::sync_with_stdio(false), cin.tie(0), cout.tie(0)
map<ll,ll> mp;
int main(){
    ios;
    ll n, k, ans = 0;
    cin >> n >> k;
    vector<ll> a(n + 1);
    vector<ll> pre(n + 1);
    for(int i = 1 ; i <= n ; i ++) cin >> a[i];
    for(int i = 1 ; i <= n ; i ++) {
        pre[i] = (pre[i - 1] + a[i]) % k;
    }
    mp[0] = 1;
    for(int i = 1 ; i <= n ; i ++){
        if(a[i] == 0) ans ++;
        if(mp.count(pre[i])) {
            ans += mp[pre[i]];
            mp[pre[i]] ++;
        } 
    }
    cout << ans;
}