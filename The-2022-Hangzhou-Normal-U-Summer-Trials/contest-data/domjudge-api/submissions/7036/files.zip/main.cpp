#include <bits/stdc++.h>
using namespace std;
#define ll __int128
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

ll n, m;
ll a[maxn];
void solve(){
    long long tmp;
    cin >> tmp; n = tmp;
    for(int i=1;i<=n;i++){
        cin >> tmp;
        a[i] = tmp;
    }
    for(int i=1;i<=n;i++) a[i] = a[i+1] - a[i];
    a[n] = 2e18;
    sort(a+1, a+n+1);
    vector<ll> sum(n+1, 0);
    for(int i=1;i<=n;i++) sum[i] = sum[i-1] + a[i];
    int q;
    cin >> q;
    while(q--){
        cin >> tmp;
        ll t = tmp;
        int pos = lower_bound(a+1, a+n+1, t) - a;
        ll ans = sum[pos-1] + (n - pos + 1) * t;
        tmp = ans;
        cout << tmp << '\n';
    }
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}