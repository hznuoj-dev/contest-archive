#include<bits/stdc++.h>
using namespace std;
#define N 100005
#define int long long

vector<int> ans[N],son[N];
int du[N],times[N],vis[N];
queue<int> qu;

void solve(){
	int n,l,r,now,t = 0;
	cin >> n;
	for(int i = 1;i < n;i++){
		cin >> l >> r;
		son[l].push_back(r),son[r].push_back(l);
		du[l]++,du[r]++;
		times[i] = times[i + 1] = 1;
	}
	while(!qu.empty()) qu.pop();
	for(int i = 1;i <= n;i++) if(du[i] == 1) qu.push(i);
	while(!qu.empty()){
		now = qu.front(),qu.pop();
		vis[now] = 1;
		if(++t == n) break;
		for(int i = 0;i < son[now].size();i++){
			if(vis[son[now][i]]) continue;
			ans[son[now][i]].push_back(times[now]);
			times[son[now][i]] += times[now];
			if(--du[son[now][i]] == 1) qu.push(son[now][i]);
		}
	}
	for(int i = 1;i <= n;i++){
		ans[i].push_back(n - times[i]);
		now = 0,t = 1;
		for(int j = 0;j < ans[i].size();j++){
			//cout << ans[i][j] << ' ';
			now += ans[i][j];
			now += (n - t - ans[i][j]) * ans[i][j];
			t += ans[i][j];
		}
		times[i] = now;
		//cout << "--------i=" << i << '\n';
	}
	int m;
	cin >> m;
	for(int i =1;i <= m;i++){
		cin >> now;
		cout << times[now] << '\n';
	}
}

signed main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	int t = 1;
	while(t--) solve();
}

/*
5
1 2
1 3
3 4
3 5
5
1
2
3
4
5

*/
