#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
using namespace std;
using LL=long long;
const int N=1e5+10;
#define int LL
int n,m,k;
int a[N],sum[N];
signed main(){
	ios::sync_with_stdio(0);
	cin>>n>>m;
	map<int,int>mp;
	rep(i,1,n)cin>>a[i],sum[i]=sum[i-1]+a[i];
	rep(i,1,n)mp[sum[i]%m]++;
	int ans=0;
	for(auto &x:mp){
	//	cout<<x.second<<endl;
		ans+=(x.second-1)*x.second/2;
	}
	ans+=mp[0];
	cout<<ans;
}
