#include<bits/stdc++.h>
using namespace std;
const long long maxn=1e5+10;
long long a[5*maxn]; 
int main()
{
	int n;
	cin>>n;
	int q;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	
	cin>>q;
	while(q--)
	{
		long long x;
		cin>>x;
		long long ans=n*x;
		for(int i=0;i<n-1;i++)
		{
			if(x>(a[i+1]-a[i]))
			{
				ans=ans-(x-(a[i+1]-a[i]));
			}
		}
		cout<<ans<<endl;
		
	}
	return 0;
 } 
 
