#include <bits/stdc++.h>
#define vi vector<int>
#define vc vector
#define vll vector<long long>
#define pii pair<int,int>
#define AXY(a,x,y) int x=(a).first,y=(a).second;
#define MID(l,r) int mid=((l)+(r))/2
#define ALL(arr) arr.begin(),arr.end()
using namespace std;
typedef long long ll;






#define int ll
struct NODE{
	int l,r,v=1;
	#define lrs(p) int ls=p*2,rs=p*2+1;
};
vc<NODE> st;
vc<pii> lazy;
vi lock12;
void pushUp(int p){
	lrs(p);
	if(st[p].l!=st[p].r){
		lock12[p]=(lock12[ls]|lock12[rs]);
		st[p].v=__gcd(st[ls].v,st[rs].v);
	}
	
}
void pushDowm(int p){
	lrs(p);
	int l=st[p].l,r=st[p].r;
	if(l!=r){
		lazy[ls].first*=lazy[p].first;
		lazy[ls].second*=lazy[p].second;
		lazy[rs].first*=lazy[p].first;
		lazy[rs].second*=lazy[p].second;
		if(!lock12[ls]) st[ls].v*=lazy[p].first,st[ls].v/=lazy[p].second;
		if(!lock12[rs]) st[rs].v*=lazy[p].first,st[rs].v/=lazy[p].second;
	}
	lazy[p].first=lazy[p].second=1;
}
void built(int p,int L,int R){
	lrs(p);
	st[p].l=L;
	st[p].r=R;
	if(L==R){
		return;
	}
	MID(L,R);
	built(ls,L,mid);
	built(rs,mid+1,R);
}
void mul(int p,int L,int R,int x){
	pushDowm(p);
	lrs(p);
	int l=st[p].l,r=st[p].r;
	if(L<=l&&r<=R){
		lazy[p].first*=x;
		if(!lock12[p]) st[p].v*=x;
		return;
	}
	MID(l,r);
	if(mid>=L) mul(ls,L,R,x);
	if(mid+1<=R) mul(rs,L,R,x);
	pushUp(p);
}
int div(int p,int L,int R,int x,int op){
	pushDowm(p);
	lrs(p);
	int l=st[p].l,r=st[p].r;
	if(L<=l&&r<=R){
		pushUp(p);
		int gcd=__gcd(st[p].v,x);
		if(gcd==x){
			if(op){
				lazy[p].second*=x;
				if(!lock12[p]) st[p].v/=x;
			}
			return 1;
		}
		else return 0;
	}
	MID(l,r);
	int res=1;
	if(mid>=L) res&=div(ls,L,R,x,op);
	if(mid+1<=R) res&=div(rs,L,R,x,op);
	pushUp(p);
	return res;
}
void flip(int p,int pos){
	pushDowm(p);
	lrs(p);
	int l=st[p].l,r=st[p].r;
	if(l==r){
		lock12[p]=1-lock12[p];
		return;
	}
	MID(l,r);
	if(pos<=mid) flip(ls,pos);
	else flip(rs,pos);
	pushUp(p);
}


void printfT(int p,int op){
	pushDowm(p);
	int l=st[p].l,r=st[p].r;
	MID(l,r);
	if(l==r){
		if(op) cout<<st[p].v<<' ';
		else cout<<lock12[p]<<' ';
		return;
	}
	lrs(p);
	printfT(ls,op);
	printfT(rs,op);
	pushUp(p);
	return;
}
signed main(){
	int n;
	cin>>n;
	st.resize(n*4);
	lock12.resize(n*4,0);
	lazy.resize(n*4,{1,1});
	built(1,0,n-1);
	int q=1;
	cin>>q;
//	printfT(1,1);
//	cout<<endl;
//	printfT(1,0);
//	cout<<endl;
	while(q--){
		string op;
		cin>>op;
		int l,r,x;
		if(op=="mul"){
			cin>>l>>r>>x;
			l--,r--;
			mul(1,l,r,x);
		}
		else if(op=="div"){
			cin>>l>>r>>x;
			l--,r--;
			if(div(1,l,r,x,0)){
				div(1,l,r,x,1);
				cout<<"YES\n";
			}
			else cout<<"NO\n";
		}
		else if(op=="flip"){
			int p;		
			cin>>p;
			p--;
			flip(1,p);
		}
//		printfT(1,1);
//		cout<<endl;
//		printfT(1,0);
//		cout<<endl;
	}
	
	return 0;
}









