#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 5e5 + 7;

ll a[N];
ll c[N];
void solve() {
	int n;
	cin >> n;
	for (int i = 1; i <= n; ++i) {
		cin >> a[i];
	}
	for (int i = 1; i <= n; ++i) {
		c[i] = a[i + 1] - a[i];
	}
	c[n] = 1e18l;
	int q;
	cin >> q;
	for (int i = 1; i <= q; ++i) {
		ll t;
		cin >> t;
		ll x = lower_bound(c + 1,c + n + 1,t) - c;
		cout << a[x] - a[1] + (n - x + 1) * t << '\n';
	}
}
int main() {
	ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
/*
3
1 3 8
3
2
4
10
*/
