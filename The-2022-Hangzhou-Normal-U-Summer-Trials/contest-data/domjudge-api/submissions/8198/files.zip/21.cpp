#include<iostream>

using namespace std;

int main()
{
	int n; 
	cin >> n;
	long long arr[n], b[n];
	for(int i = 0 ; i < n; i++)
	{
		cin >> arr[i];
	}
	for(int i = 0; i < n - 1; i++)
	{
		b[i] = arr[i + 1] - arr[i];
	}
	int m;
	cin >> m;
	while(m--)
	{
		long long num, sum;
		cin >> num;
		sum = num;
		for(int i = 0; i < n - 1; i++)
		{
			if(b[i] > num)
			{
				sum += num;
			}
			else
			{
				sum += b[i];
			}
		}
		cout << sum << endl;
	}
}
