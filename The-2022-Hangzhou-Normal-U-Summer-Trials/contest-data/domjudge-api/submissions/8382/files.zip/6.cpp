#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll inf = 1e18 + 7;
const int maxn = 1e5 + 7;
struct
{
	int ope;
	char a, b;
}q[maxn];
char fx[500];
int main()
{
	for (int i = 'a'; i <= 'z'; i++)
	{
		fx[i] = i;
	}
	int cnt2 = 0;
	int n, ope;
	cin >> n;
	char a, b;
	for (int i = 1; i <= n; i++)
	{
		cin >> q[i].ope;
		if (q[i].ope == 1)
			cin >> q[i].a;
		else if (q[i].ope == 2)
			cnt2++;
		else
			cin >> q[i].a >> q[i].b;
	}
	string ans;
	for (int i = n; i >= 1; i--)
	{
		if (q[i].ope == 3)
		{
			fx[q[i].a] = fx[q[i].b];
		}
		else if (q[i].ope == 1)
		{
			if (cnt2)
				cnt2--;
			else
				ans.push_back(fx[q[i].a]);
		}
	}
	reverse(ans.begin(), ans.end());
	if (ans.empty())
		cout << "The final string is empty" << '\n';
	else
		cout << ans << '\n';
}