#include<iostream>
#include<string>
#include<cstdio>
#include<map>
#include<cstring>
#include<algorithm>
typedef long long ll;
using namespace std;
ll p;
ll t[2000020];
ll a[2000020];
int main(){
cin >> p;
for(int i = 0;i<p;i++){
	cin >> a[i];
}
ll n;
cin >>n;
ll thisp = 0;




ll temp = 0;

ll flag = 0;
for(int i = 0;i<n;i++){
	
	ll ans = 0;
//	ll t;
	cin >> t[i];
	
	if(i!=0&&t[i]<=t[i-1]){
    flag = 0;	
	temp = 0;
}
	if(flag==1){
		temp--;
		flag = 0;
	}
	
	if(p==1){
		cout << t[i] <<endl;
	}
	else
	
	{
	
	while(a[temp]+t[i]>a[temp+1]){
	//	cout <<"temp11=" <<temp<<endl;
	//		cout <<"***" <<p-2<<endl;
		if(temp==p-2)
		break;
		
		temp++;
		
	}
	
//	cout <<"t="<<t[i]<<"temp=" <<temp <<endl;

	if(a[temp]+t[i]>a[temp+1]){
		temp++;
		flag =1;
	}
//	cout <<"new temp =" <<temp <<endl;
	ans += a[temp]-a[0];		
	
	ans+=t[i]*(p-temp);
	cout << ans <<endl;
}


}

} 
