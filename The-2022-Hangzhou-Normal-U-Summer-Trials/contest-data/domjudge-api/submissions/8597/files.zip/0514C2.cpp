#include<bits/stdc++.h>
#define io ios::sync_with_stdio(false);cin.tie(0),cout.tie(0);
using namespace std;

typedef unsigned long long ll;

ll n, m, k, t, maxn;
ll a[500010];
ll cha[500010];
ll ans;

int main () {
	io;
	cin >> n;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		if (i != 1) cha[i] = a[i] - a[i - 1];
		maxn = max(maxn, cha[i]);
	}
	cha[1] = 0;
	cin >> k;
	while (k--) {
		ans = 0;
		cin >> t;
		if (t == 0) {
			cout << "0\n";
			continue;
		}
		int num = upper_bound(cha + 1, cha + n + 1, min(maxn, t)) - cha - 1;
		if (a[num] != 0)
			ans += a[num] - a[1];
		ans += 1ll * (n - num + 1) * t;
		cout << ans << '\n';
	}
	return 0;
}
