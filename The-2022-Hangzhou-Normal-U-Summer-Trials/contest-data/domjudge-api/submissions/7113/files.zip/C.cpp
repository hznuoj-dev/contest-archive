#include<bits/stdc++.h>
using namespace std;
using ll=long long;
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n;cin>>n;
	vector<ll> a(n);
	for(int i=0;i<n;i++) cin>>a[i];
	unordered_map<ll,int> hs;
	for(int i=1;i<n;i++){
		hs[a[i]-a[i-1]]--;
	}
	vector<pair<ll,ll> > q;
	q.emplace_back(0,n);
	for(auto x:hs){
		q.emplace_back(x);
	}
	sort(q.begin(),q.end());
	int m=q.size();
	vector<ll> sum(m);
	vector<int> number(m);
	number[0]=n;
	for(int i=1;i<m;i++){
		sum[i]=sum[i-1]+(ll)number[i-1]*(q[i].first-q[i-1].first);
		number[i]=number[i-1]+q[i].second;	
	}
	int qry;cin>>qry;
	while(qry--){
		int t;cin>>t;
		int p=upper_bound(q.begin(),q.end(),pair<ll,ll>{t,n+1})-q.begin()-1;
		cout<<sum[p]+ll(t-q[p].first)*number[p]<<"\n";
	}
	return 0;
}