#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn=1e6+7;
const int mod=1e9+7;
int f[maxn];
int a[maxn];
int qpow(int a, int n){
	int res=1;
	while(n){
		if(n&1) res=(res*a)%mod;
		a=(a*a)%mod;
		n>>=1;
	}
	return res;
}
void init(){
	f[1]=1;
	for(int i=2;i<=200001;i++){
		f[i]=f[i-1]*i;
		if(f[i]>mod){
			f[i]=0;
			break;
		}
	}
}
int rev(int x){
	return qpow(x,mod-2);
}
int c(int m, int n){
	if(f[m]!=0){
		return ((f[m]*rev(f[n]))%mod*rev(f[m-n]))%mod;
	}
	return (c(m-1,n-1)+c(m-1,n))%mod;
}
signed main(){
	init();
	int n, s, q;cin>>n>>s>>q;
	int sum=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum+=a[i];
	}
	for(int i=1;i<=q;i++){
		int x, y;
		cin>>x>>y;
		sum+=y-a[x];
		a[x]=y;
		if(s<sum){
			cout<<0<<endl;
			continue;
		}
		if(s==sum){
			cout<<1<<endl;
			continue;
		}
		int p=s-sum;
		cout<<c(n+p,p)%mod<<endl;
	}
} 
