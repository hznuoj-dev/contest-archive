
#include <bits/stdc++.h>
using namespace std;

#define INF 0x3f3f3f3f

#define ll long long
#define endl '\n'
#define null NULL
#define ls p<<1
#define rs p<<1|1
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define vi vector<int>
#define mii map<int,int>
#define pii pair<int,int>
#define ull unsigned long long
#define pqi priority_queue<int>
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define ct cerr<<"Time elapsed:"<<1.0*clock()/CLOCKS_PER_SEC<<"s.\n";
#define ull unsigned long long
#define rep(i,a,b) for(int i=(a);i<=(b);i++)
inline int rd() {//�����Ż������Լӿ����ֵ�����
	char p = 0; int r = 0, o = 0;
	for (; p < '0' || p>'9'; o |= p == '-', p = getchar());
	for (; p >= '0' && p <= '9'; r = (r << 1) + (r << 3) + (p ^ 48), p = getchar());
	return o ? (~r) + 1 : r;
}
void write(int x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
const int M = 1e5+10;
const int mod=1e9+7;
const double pi=acos(-1.0);
int a[M];
int su[M];
signed main()
{
	int n,k;
	cin>>n>>k;
	rep(i,1,n){
		cin>>a[i];
		a[i]%=k;
	}
	rep(i,1,n){
		su[i]+=su[i-1]+a[i];
//		su[i]%=k;
	}
	
	int ans=0;
	for(int i=1;i<=n;i++){
//		if(su[i])
		for(int j=0;j<i;j++){
			if((su[i]-su[j])%k==0)
			{
				ans++;
			}
		}
	}
//	ans++;
	cout<<ans<<endl;
}
