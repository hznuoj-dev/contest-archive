#include <bits/stdc++.h>
#include<unordered_map>
using namespace std;
const int maxn=2e5+10;
const int mod=1e9+7;
#define fast ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define int  long long

int fac[2*maxn],invfac[2*maxn];
int ksm(int a,int b){
	int res=1;
	while(b){
		if(b&1)res=res*a%mod;
		a=a*a%mod;
		b>>=1;
	}
	return res;
}
int comb(int n,int m){
	if(n<m){
		return 0;
	}
	return fac[n]*invfac[m]%mod*invfac[n-m]%mod;
}
void init(int n,int m){
	fac[0]=1;
	int up=max(n,m)*2;
	for(int i=1;i<=up;i++)fac[i]=fac[i-1]*i%mod;
	invfac[up]=ksm(fac[up],mod-2);
	for(int i=up-1;i>=0;i--){
		invfac[i]=invfac[i+1]*(i+1)%mod;
	}
}
int dp[maxn];
int a[maxn];
signed main(){
	fast;
	init(maxn-10,maxn-10);
	int n,s,q;cin>>n>>s>>q;
	int sum=0;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum+=a[i];
	}
	dp[0]=1;
	for(int i=1;i<=s;i++){
		dp[i]=(dp[i-1]+comb(i+n-1,n-1))%mod;
	}
	while(q--){
		int id,val;cin>>id>>val;
		sum=sum-a[id]+val;
		a[id]=val;
		int yu=s-sum;
		if(yu>=0)cout<<dp[yu]<<endl;
		else cout<<0<<endl;
	}


	system("pause");
}