#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
using namespace std;
using LL=long long;
const int N=2e5+10;
int n,m,k;
string s[N];
map<char,int>mp;
bool cmp(string a,string b){
	for(int i=0;i<min(a.size(),b.size());i++){
		if(mp[a[i]]!=mp[b[i]])return mp[a[i]]<mp[b[i]];
	}
	return a.size()<b.size();
}
signed main(){
	ios::sync_with_stdio(0);
	string role;cin>>role;
	for(int i=0;i<26;i++)mp[role[i]]=i;
	cin>>n;
	rep(i,1,n)cin>>s[i];
	sort(s+1,s+1+n,cmp);
	cin>>k;
	cout<<s[k];
}
