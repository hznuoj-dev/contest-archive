#include <iostream>
#include <algorithm>

using namespace std;

int main()
{
	long long n, *a, q, *b, *sum;
	long long cnt = 0;
	
	scanf("%lld", &n);
	a = (long long *) malloc (n * sizeof(long long));
	b = (long long *) malloc (n * sizeof(long long));
	sum = (long long *) malloc (n * sizeof(long long));
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &a[i]);
		if (i > 0)
		{
			b[cnt] = a[i] - a[i - 1];
			if (cnt == 0)
			{
				sum[cnt] = b[cnt];
			}
			else
			{
				sum[cnt] = sum[cnt - 1] + b[cnt];
			}
			cnt++;
		}
	}
	sort(b, b + cnt);
	scanf("%lld", &q);
	while (q--)
	{
		long long l = 0, r = cnt - 1;
		long long t, mid;
		
		scanf("%lld", &t);
		if (cnt == 0)
		{
			printf("%lld\n", t);
		}
		else
		{
			while (l <= r)
			{
				mid = (l + r) / 2;
				if (b[mid] < t)
				{
					l = mid + 1;
				}
				else if (b[mid] > t)
				{
					r = mid - 1;
				}
				else
				{
					break;
				}		
			}
			if (b[mid] > t)
			{
				mid--;
			}
			if (mid >= 0)
			{
				printf("%lld\n", sum[mid] + (cnt - mid) * t);
			}
			else
			{
				printf("%lld\n", (cnt - mid) * t);
			}
		}
	}
	
	return 0;
}
