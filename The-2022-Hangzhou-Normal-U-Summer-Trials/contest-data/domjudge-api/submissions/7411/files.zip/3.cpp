#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const ll inf = 1e18 + 7;
const int maxn = 5e5 + 7;
ll a[maxn];
ll dif[maxn];
ll pre[maxn];
int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i];
		if (i)
			dif[i] = a[i] - a[i - 1];
	}
	//dif从0到n-2
	pre[0] = dif[0];
	for (int i = 1; i < n; i++)
		pre[i] = pre[i - 1] + dif[i];

	ll q, t;
	cin >> q;
	ll ans;
	while (q--)
	{
		cin >> t;
		ll pos = lower_bound(dif, dif + n, t) - dif;
		ans = pre[pos - 1] + (n - pos + 1) * t;
		cout << ans << '\n';
	}
}