#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define moonoom ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
const ll MAXN=1e5+10;
ull p[MAXN];
ull hsh[MAXN];
int main(){
	
	string ss,a;
	cin>>a;
	ss='#'+a;
	ll ans=0;
	ll len=ss.length();
	p[0]=1;
	for(int i=1;i<=len;i++){
		hsh[i]=hsh[i-1]*131+ss[i]-'a'+1;
		p[i]=131*p[i-1];
	}
	ull num=18432769;
	
	for(int i=4;i<=len;i++){
		if(hsh[i]-hsh[i-4]*p[4]==num)ans++;
	}
	cout<<ans<<endl;

	
}
