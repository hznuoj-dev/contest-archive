#include<bits/stdc++.h>
using namespace std;
const int N=1e3+10;
string q;
string s[N];
map<char,int> mp;
bool check(string a,string b){
	for(int i=0;i<a.size()&&i<b.size();i++){
		if(a[i]==b[i]){
			continue;
		}
		if(mp[a[i]]>mp[b[i]]) return true;
		else return false;
	}
	if(a.size()<b.size())	return false;
	return true; 
}
int main(){
	cin>>q;
	int mm=0;
	for(auto x:q){
		mp[x]=mm++;
	}
	int n;
	cin>>n;
	for(int i=1;i<=n;i++) cin>>s[i];
	for(int i=1;i<n;i++){
		for(int j=i+1;j<=n;j++){
			if(check(s[i],s[j]))
				swap(s[i],s[j]);
		}
	}
	int k;
	cin>>k;
	cout<<s[k];
}