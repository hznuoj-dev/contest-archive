#include<bits/stdc++.h>

using namespace std;
int ans, k, n;
int  mp[200];
string s[1010], str;	
bool cmp(string a, string b) {
	int l1=a.length();
	int l2=b.length();
	int l=min(l1, l2);
	for(int i=0;i<l;i++) {
		if(a[i]!=b[i]) return mp[a[i]]<mp[b[i]];
	}
	return min(l1, l2);
}

void solve() {
	str="";
	cin >> str;
	cin >> n;
	for(int i=0;i<=25;i++) {
		mp[str[i]]=i;
	}
	
	for(int i=1;i<=n;i++) {
		cin >> s[i];
	}
	//cout << n << endl;
	sort(s+1, s+1+n, cmp);
	cin >> k;
	cout << s[k] << endl;
}

int main(){
	int T=1;
	//cin >> T;
	while(T--)
		solve();
}
