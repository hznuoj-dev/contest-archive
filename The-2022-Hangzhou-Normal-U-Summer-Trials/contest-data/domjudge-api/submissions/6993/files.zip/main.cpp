#include<bits/stdc++.h>
using namespace std;
const int N = 1e3 + 10;
string str[N];
int main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    ios_base::sync_with_stdio(0);
    cin.tie(0), cout.tie(0);

    string s;
    cin >> s;
    map<char, char> mp1, mp2;
    for(int i = 0;i < 26;i ++){
        mp1[s[i]] = 'a' + i;
        mp2['a' + i] = s[i];
    }

    int n;
    cin >> n;
    for(int i = 1;i <= n;i ++){
        cin >> str[i];
        for(auto &v : str[i]){
            v = mp1[v];
        }
    }

    sort(str + 1, str + n + 1);
    int k;
    cin >> k;
    int siz = str[k].size();
    for(int i = 0;i < siz;i ++){
        cout << mp2[str[k][i]];
    }


    return 0;
}