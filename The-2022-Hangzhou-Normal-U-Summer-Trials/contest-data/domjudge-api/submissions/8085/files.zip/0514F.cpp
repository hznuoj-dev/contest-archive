#include<bits/stdc++.h>
#define io ios::sync_with_stdio(false);cin.tie(0),cout.tie(0);
using namespace std;

typedef long long ll;

ll n, m, k, t, ans;
int top = -1;
int a[100010];
long long pre[100010];
long long now = 0;
map<int, int> cnt;
set<int> s;
int main () {
	cin >> n >> k;
	for (int i = 1; i <= n; i++) {
		cin >> a[i];
		pre[i] = pre[i - 1];
		pre[i] += a[i];
		if (pre[i] % k == 0) {
			cnt[0]++;
			ans++;
		}
		else {
			cnt[pre[i] % k]++;
		}
		s.insert(pre[i] % k);
	}
	for (int i = 1; i <= n; i++) {
		now += a[i] % k;
		now %= k;
		cnt[now]--;
		ans += cnt[now % k];
	}
	cout << ans;
	return 0;
}
