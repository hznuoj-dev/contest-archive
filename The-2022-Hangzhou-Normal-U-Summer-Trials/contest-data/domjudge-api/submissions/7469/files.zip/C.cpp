#include<bits/stdc++.h>
using namespace std;
#define LL long long
const int N = 5e5 + 7;

int n, q;
LL a[N], t;

int main(){
    // ios::sync_with_stdio(false);
    // cin.tie(0), cout.tie(0);
    cin >> n;
    for(int i = 1; i <= n; i++){
        cin >> a[i];
    }
    cin >> q;
    int pos = 1;
    LL sum = 0;
    for(int i = 1; i <= q; i++){
        cin >> t;
        sum = a[pos] - 1;
        for(int j = pos; j < n; j++){
            if(a[j] + t >= a[j + 1]){
                sum += a[j + 1] - a[j];
                pos = j + 1;
            }
            else{
                sum += t;
            }
        }
        sum += t;
        cout << sum << '\n';
    }
}