#include <bits/stdc++.h>
#define endl '\n'

using namespace std;

typedef unsigned long long uLL;
typedef long long LL;
const int N = 5e5 + 10;

uLL a[N], c[N];

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    LL n;
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> a[i];
    for (int i = 1; i < n; i++)
        c[i] = a[i + 1] - a[i];

    int q;
    cin >> q;

    while (q--)
    {
        LL t;
        cin >> t;
        int pos = upper_bound(c + 1, c + n, t) - c;
        uLL ans = a[pos] + t - 1LL + (uLL)(n - pos) * t;
        cout << ans << endl;
    }

    return 0;
}