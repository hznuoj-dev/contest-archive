#include<bits/stdc++.h>
using namespace std;
char s[100005];
map<char,char>mp;
struct cao{
	char a,b;
}cao[100005];
int a[100005];
char b[100005],c[100005];
int is[1000];
int len=0;
int main()
{
	for(char i='a';i<='z';i++){
		mp[i]=i;
	}
	int n;
	cin>>n;
	int num=0;//�ṹ����� 
	for(int i=0;i<n;i++){
		cin>>a[i];
		if(a[i]==1){
			cin>>b[i];
			s[len++]=b[i];
		}
		else if(a[i]==2){
			if(len>0){
				s[len--]='\0';
			}
		}
		else if(a[i]==3){
			cin>>b[i]>>c[i];
			for(int j=0;j<len;j++){
				if(s[j]==b[i]){
					s[j]=c[i];
				}
			}
		}
	}

	if(len==0){
		cout<<"The final string is empty"<<endl;
	}
	else{
		cout<<s<<endl;
	}
 } 
