#include <iostream>
#include <cstdio>
#include <cstdlib>
#include <algorithm>
#include <cmath>
#include <cstring>
#include <string>
#include <vector>
#include <stack>
#include <queue>
#include <set>
#include <map>
#include <numeric>
#include <bitset>
using namespace std;
#define INF 0x3c3c3c3c // 1010580540, 7f7f7f7f:2139062143
#define llINF 9223372036854775807
const double PI = acos(-1.0);
const double eps = 1e-6;
using ll = long long;
using ull = unsigned long long;
using db = double;
using ld = long double;
using pii = pair<int, int>;
using pll = pair<ll, ll>;
#define fi first
#define se second
#define pb push_back
#define endl '\n'
#define dbg(a) cout << #a << " = " << (a) << '\n';
#define all(c) (c).begin(), (c).end()
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);

const int N = 1e6 + 10;

ll dp[N][10]; // 到i站，花j元的最小
ll a[N], pos[10];

int main(){
    IOS
    int n;
    ll s, p;
    cin >> n >> p >> s;
    for(int i = 1; i <= n; i++) cin >> a[i];
    int k;
    cin >> k;
    for(int i = 0; i <= k; i++) pos[i] = 1;

    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= k; j++){
            while(a[i] - a[pos[j]] > s * j) pos[j]++; 
        }
        for(int j = 0; j <= k; j++){
            dp[i][j] = dp[i - 1][j] + a[i] - a[i - 1];
            for(int t = 1; t <= k; t++){
                if(j - t < 0) break;
                dp[i][j] = min(dp[i][j], dp[pos[t]][j - t]);
            }
        }
    }
    ll ans = dp[n][k] + p - a[n];
    cout << ans;
    return 0;
}