﻿#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
#define INF 0x3f3f3f

int a[500007];
int sub[500006];
ll sum[500007];

int main()
{
	int n;
	cin >> n;
	for (int i = 0; i < n; i++)
	{
		cin >> a[i];
		if (i >= 1)
		{
			sub[i - 1] = a[i] - a[i - 1];

		}
	}

	int q;
	cin >> q;

	static int count;
	
	while (q--)
	{
		ll t;
		cin >> t;
		sum[count] = t * n;
		for (int i = 0; i < n - 1; i++)
		{
			if (t > sub[i])
				sum[count] -= t - sub[i];
		}
		count++;
	}
	for (int i = 0; i < count; i++)
	{
		cout << sum[i] <<endl;
	}


}

