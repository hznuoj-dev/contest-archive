#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 5e5 + 5;

struct node{
	int sign;
	char x, y;
}g[maxn];

char work[maxn];
void solve(){
	int n; cin >> n;
	for(char i = 'a'; i <= 'z'; ++i) work[i] = i;
	for(int i = 1; i <= n; ++i){
		cin >> g[i].sign;
		if(g[i].sign == 1) cin >> g[i].x;
		if(g[i].sign == 3) cin >> g[i].x >> g[i].y;
	}
	int del = 0;
	string ans;
	for(int i = n; i >= 1; --i){
		if(g[i].sign == 1){
			if(del){
				del--;
				continue;
			}
			else ans.push_back(work[g[i].x]);
		}
		else if(g[i].sign == 2){
			del++;
		}
		else{
			work[g[i].x] = work[g[i].y];
		}
	}

	if(ans.empty()) cout << "he final string is empty";
	else{
		reverse(ans.begin(), ans.end());
		cout << ans;
	}
}

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
