#include  <bits/stdc++.h>
using namespace std;

unsigned long long num[500010];
unsigned long long full[500010];

int work()
{
    int i, j;
    unsigned long long t, t0;
    int n, q;
    scanf("%d", &n);

    int maxn = 0;
    scanf("%d", &t0);
    for (i = 1; i < n; i++)
    {
        scanf("%lld", &t);
        num[t-t0]++;
        maxn = maxn > t-t0 ? maxn: t-t0;
        t0 = t;
    }
    for (i = 500000; i > 0; i--)
    {
        full[i] = num[i-1]*(i-1);
        num[i] += num[i+1];
    }
    for (i = 1; i <= 500000; i++)
    {
        full[i] += full[i-1];
    }
                /*for (i = 0; i < 10; i++) printf ("%d ", num[i]);
                printf ("\n");
                for (i = 0; i < 10; i++) printf ("%d ", full[i]);
                printf ("\n");
                printf ("\n");*/

    scanf("%d", &q);
    for (i = 0; i < q; i++)
    {
        scanf("%lld", &t); if (t>500000) t=500000;
                //printf ("(%lld+1)*%lld+%lld) ", num[t], t, full[t]);
        printf ("%lld\n", (num[t]+1)*t+full[t]);
    }

    return 0;
}

int main()
{
    int T = 1;
    //scanf("%d", &T);
    while (T--) work();
    //getchar();getchar();getchar();
    return 0;
}
