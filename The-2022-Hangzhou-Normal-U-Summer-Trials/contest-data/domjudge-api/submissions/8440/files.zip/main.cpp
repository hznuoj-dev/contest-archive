#include<bits/stdc++.h>
#define ll long long
using namespace std;

ll a[500007];
ll s[500007];
ll t;
ll sum;
int main(){
    int n;
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
        if(i>=2)s[i-1] = a[i]-a[i-1];
    }
    int q;
    cin>>q;
    while(q--){
        cin>>t;
        sum=t;
        for(int i=1;i<=n-1;i++){
            if(t-s[i]>0)sum+=s[i];
            else sum+=t;
        }
        cout<<sum<<"\n";
    }
    return 0;
}