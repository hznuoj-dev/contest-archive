#include <bits/stdc++.h>
using namespace std;
#define  ll long long
int main()
{
	char s[200005];
	cin>>s;
	int ans=0;
	int tot = strlen(s);
	for(int i = 0;i<tot-2;i++)
	{
		if(s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')
			ans++;
	}
	cout<<ans<<endl;
}
