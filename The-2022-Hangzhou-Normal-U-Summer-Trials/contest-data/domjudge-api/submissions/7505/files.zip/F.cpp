#include <bits/stdc++.h>
using namespace std;
map<int,int> f;
int n,k,s,t,ans;
int main(){
	scanf("%d%d",&n,&k);
	f[0]=1;
	for(int i=1;i<=n;i++){
		scanf("%d",&t);
		s=(s+t)%k;
		ans+=f[s];
		f[s]++;
	}
	cout<<ans;
	return 0;
}
