﻿#include<iostream>
#include<algorithm>
using namespace std;
int main()
{
	string a;
	cin >>a;
	int ans = 0;
	for(int i=0;i<a.length();i++)
	{
		if (a[i] == 'h') {
			
			if (a[i + 1] == 'z' && a[i + 2] == 'n' && a[i + 3] == 'u') {
				i = i + 3;
				ans++;
			}



		




	 }
	
	
	
	
	
	}


	cout << ans;

}