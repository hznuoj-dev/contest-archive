#include<bits/stdc++.h>
using namespace std;
int main(){
	string s;
	int num=0;
	cin>>s;
	for(int i=0;i<s.length();i++){
		if(s[i]=='h'){
			if(s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u'){
				i+=3;
				num++;
			}
		}
	}
	cout<<num<<endl;
	return 0;
} 
