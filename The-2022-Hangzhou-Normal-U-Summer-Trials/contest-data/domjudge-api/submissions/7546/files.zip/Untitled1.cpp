#include <bits/stdc++.h>

using namespace std;

map<char,int>mp;

map<string,string>mp1;

string ans[1005] = "00000000000000000000000000";

int main() {
	for(int i = 0 ; i<26 ; i++){
		char tmp;
		cin >> tmp;
		mp[tmp] = i;
	}
	
	int n;
	cin >> n;
	for(int i = 0 ; i<n ; i++){
		string s;
		cin >> s;
		string tmp = "";
		tmp = ans[i];
		for(int j = 0 ; j<s.length() ; j++){
			//cout << mp[s[j]] << endl;
			char ss = (mp[s[j]]+1) + '0';
			//cout << ss << endl;
			tmp[j] = ss;
		}
		ans[i] = tmp;
		
		mp1[ans[i]] = s;
		
		
	}
	
	int k;
	cin >> k;
	
	sort(ans,ans+n);
	
	cout << mp1[ans[k-1]] << endl;
	
	
	
	/*for(int i = 0 ; i<n ; i++){
		cout << ans[i] << endl;
	}*/
	
	
	
	
	
	


}

