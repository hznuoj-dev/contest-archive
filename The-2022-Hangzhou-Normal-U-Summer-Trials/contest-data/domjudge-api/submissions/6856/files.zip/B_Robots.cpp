#include<iostream>
#include<algorithm>
#include<cstring>
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);
using namespace std;
int main() {
	IOS;
	string s; cin >> s;
    int n = s.size();
	int cnt = 0;
	for (int i = 0; i < n - 3; i++) {// 0 1 2 3
		if (s[i] == 'h' && s[i + 1] == 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') {
			cnt++;
		}
	}
	cout << cnt << "\n";
}