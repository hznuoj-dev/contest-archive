﻿#include<bits/stdc++.h>
typedef long long ll;
using namespace std;
#define INF 0x3f3f3f
string c[1007];
map<char, int> a;
bool flag[1007];
bool cmp(string c, string b)
{
	for (int pos = 0;; pos++) {
		if (pos == int(b.length()) || a[c[pos]] > a[b[pos]])
		{
			return false;
		}
		else if (pos == int(c.length()) || a[c[pos]] < a[b[pos]])
		{
			return true;
		}
		else
		{
			;
		}
	}
}
int main()
{
	string s;
	cin >> s;
	for (int i = 0; i < int(s.length()); i++)
	{
		a[s[i]] = i+1;
	}

	int n;
	cin >> n;
	int count=0;
	while (n--)
	{
		cin >> c[count++];
	}
	sort(c, c + count , cmp);
	int k;
	cin >> k;
	cout << c[k - 1];
	
	
}
  
