#include<bits/stdc++.h>
using namespace std;
#define int long long 
#define lowbit(x)(x&-x)
typedef pair<int,int>PII;
const int INF = 0x3f3f3f3f;
typedef pair<int,string>PIS;
typedef pair<double,double>PDD;
int gcd(int a,int b){return b?gcd(b,a%b):a;}
int lcm(int a,int b){return a*b/gcd(a,b);}
#define snow ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
const int N = 1e3+10;
string s[N];
map<char,int>mp;
bool cmp(string a,string b){
    int len=min(a.size(),b.size());
    for(int i=0;i<len;i++){
        if(a[i]!=b[i]){
            return mp[a[i]]<mp[b[i]];
        }
    }
    return a.size()<b.size();
}
signed main(){
    snow
    string ss;
    cin>>ss;
    for(int i=0;i<ss.size();i++){
        mp[ss[i]]=i+1;
    }
    int n;
    cin>>n;
    for(int i=1;i<=n;i++)cin>>s[i];
    sort(s+1,s+n+1,cmp);
    int x;
    cin>>x;
    cout<<s[x]<<endl;
    return 0;
}