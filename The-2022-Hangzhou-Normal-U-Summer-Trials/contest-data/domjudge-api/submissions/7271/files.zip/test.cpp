#include<iostream>
#include<string>
#include<map>
#include<algorithm>
using namespace std;
const int N=1e3+10;
map<char,char> mp;
string str[N];
string str1[N];
int main(){
    string s;
    cin>>s;
    for(int i=0;i<s.size();i++){
        mp[97+i]=s[i];
    }
    int n;
    cin>>n;
    for(int i=0;i<n;i++){
        cin>>str[i];
        for(int j=0;j<str[i].size();j++){
            for(int k=0;k<s.size();k++){
                char c='a'+k;
                if(str[i][j]==mp[c])
                {
                        str[i][j]=k+97;
                        break;
                }
            }
        }
    }
    sort(str,str+n);
    string ans;
    int m;
    cin>>m;
    ans=str[m-1];
    for(int i=0;i<ans.size();i++){
        ans[i]=mp[ans[i]];
    }
    cout<<ans;
}
