#include<bits/stdc++.h>
#define int long long
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;
int t,n,m;
int head[100010],f[100010],to[200010],nxt[200010],cnt;
int size[100010],ans[100010];
void add(int u,int v){
	to[cnt]=v;
	nxt[cnt]=head[u];
	head[u]=cnt++;
}
void dfs(int u,int fa){
	size[u]=1;
	for(int i=head[u];i!=-1;i=nxt[i]){
		int v=to[i];
		if(v==fa)continue;
		dfs(v,u);
		ans[u]+=size[v]*(n-size[v]-1);
		size[u]+=size[v];
	}
	ans[u]+=(n-size[u])*(size[u]-1);
}
signed main(){
	FAST
	memset(head,-1,sizeof(head));
	cin>>n;
	for(int i=1;i<=n;i++)f[i]=i;
	for(int i=1,u,v;i<n;i++){
		cin>>u>>v;
		add(u,v);
		add(v,u);
	}
	dfs(1,1);
//	for(int i=1;i<=n;i++)cout<<size[i]<<endl;
	cin>>t;
	while(t--){
		cin>>m;
		cout<<ans[m]/2+n-1<<endl;
	}
} 
