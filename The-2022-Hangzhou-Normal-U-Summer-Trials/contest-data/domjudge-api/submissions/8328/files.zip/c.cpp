#include<bits/stdc++.h>
#define int long long
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
const int N=2e5+10;
int a[N];
typedef pair<int,int> PII;
typedef long long ll;
vector<int> v[N];
const int mod =1e9+7;
int n,m;
int gcd(int a,int b) {return b? gcd(b,a%b):a;}
void solve()
{
    cin >> n >> m;
    for(int i = 1; i <= n; i ++ )
    {
        cin >> a[i];
        a[i] += a[i - 1];
    }
    map<int, int> mp;
    int ans = 0;
    for(int i = 1; i <= n; i ++ )
    {
        a[i] = a[i] % m;
        ans += mp[a[i]];
        if (a[i] == 0) ans ++;
        mp[a[i]] ++;
    }
    cout << ans << endl;
}
signed main()
{
    solve();
}