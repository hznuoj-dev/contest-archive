#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int a[1000010];
int dp[1000010][7];
void solve(){
	int p,n,s,q,i,j,m,x,y,k,ans=0;
	ll l,r,t,mid,sum=0;
	cin>>n>>p>>s;
	for(i=1;i<=n;i++) scanf("%d",a+i);
	cin>>k;
	for(i=2;i<=n;i++){
		for(j=1;j<=k;j++){
			l=1,r=i-1;
			while(l<=r){
				mid=(l+r)/2;
				if(a[i]-a[mid]>j*s) l=mid+1;
				else r=mid-1;
			}
			if(l==i) continue;
			for(int z=0;z<=k-j;z++){
				dp[i][z+j]=max(dp[i][z+j],dp[l][z]+a[i]-a[l]);
				ans=max(ans,dp[i][z+j]);
			}
		}
	}
	printf("%d",p-ans);
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
/*
8
1 a
1 b
1 c
3 c d
2
1 c
3 a c
3 c e
*/
//B=clock();
	//printf("%f\n",(double)(B-A)/CLOCKS_PER_SEC);
