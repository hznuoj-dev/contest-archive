#include<string.h>
#include<stdio.h>
char s[100006];
int main(){
	long long sum=0;
	scanf("%s",&s);
	for(int i=0;i<strlen(s);++i)
	{
		if((s[i]=='h'&&s[i+1]=='z'&&s[i+2]=='n'&&s[i+3]=='u')&&i+3<strlen(s)){
			sum++;
		}
	}
	printf("%lld",sum);
} 
