#include <bits/stdc++.h> 
using namespace std;
int main()
{
	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	long long ans=0;
	string s;
	cin >> s;
	
	for (int i=0; i<s.size()-3; i++)
	{
		if (s[i]=='h' && s[i+1]=='z' && s[i+2]=='n' && s[i+3]=='u') ans++;
	}
	cout <<ans;
	
}
