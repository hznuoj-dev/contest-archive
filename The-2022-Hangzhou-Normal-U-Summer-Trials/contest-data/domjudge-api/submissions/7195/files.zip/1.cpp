#include<bits/stdc++.h>
using namespace std;
int ss[26];
bool cmp(string a,string b){
	for(int i=0;i<a.length()&&i<b.length();i++){
		return ss[a[i]-'a']<ss[b[i]-'a'];
	}
	return a.length()<b.length();
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	string s;
	cin>>s;
	for(int i=0;s[i];i++){
		ss[s[i]-'a']=i;
	}
	int n;
	cin>>n;
	string a[n];
	for(int i=0;i<n;i++)cin>>a[i];
	sort(a,a+n,cmp);
	int k;
	cin>>k;
	cout<<a[k-1]<<'\n';
	return 0;
}
