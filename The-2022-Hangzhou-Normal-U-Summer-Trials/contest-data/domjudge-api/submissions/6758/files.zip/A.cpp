#include<bits/stdc++.h>
using namespace std;
#define ll long long
int main()
{
	int i,j,n,m,k,l,ans=0;
	string st;
	cin>>st;
	for (i=0;i<st.length();i++)
	{
		if (st[i]=='h')
		{
			if (st[i+1]=='z'&&st[i+2]=='n'&&st[i+3]=='u') ans++;
		}
	}
	cout<<ans;
}
