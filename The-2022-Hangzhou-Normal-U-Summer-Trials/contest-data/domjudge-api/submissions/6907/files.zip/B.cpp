#include<bits/stdc++.h>
using namespace std;
#define itn int
map<char,int>mp;
vector<pair< vector<int> ,string> >arr;
void run()
{
	mp.clear();
	arr.clear();
	string str;
	cin>>str;
	for(int i=0;i<str.size();i++)
	{
		mp[str[i]]=i;
	}
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		string str;
		cin>>str;
		vector<int>tmp;
		for(int i=0;i<str.size();i++)
		{
			tmp.push_back(mp[str[i]]);
		}
		arr.push_back(pair< vector<int> ,string>(tmp,str));
	}
	sort(arr.begin(),arr.end());
	int k;
	cin>>k;
	cout<<arr[k-1].second;
	
	
	
	return;
}
int main()
{
	int T=1;
//	cin>>T;
	while(T--)
	{
		run();
	}
	
	return 0;
}
