#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+10;
ll a[N];
ll sum[N];
void solve(){
	ll n,k;
	map<ll,ll>mp;
	scanf("%lld%lld",&n,&k);
	for(int i=0;i<n;i++)scanf("%lld",&a[i]);
	sum[0]=a[0];
	for(int i=1;i<n;i++)sum[i]=sum[i-1]+a[i];
	for(int i=0;i<n;i++)mp[sum[i]%k]++;
	ll ans=mp[0];
	for(pair<ll,ll>i:mp){
		ans+=(i.second*(i.second-1))/2;
	}
	printf("%lld\n",ans);
}
int main(void){
	int t=1;
	//scanf("%d",&t);
	while(t--)solve();
	return 0;
}
