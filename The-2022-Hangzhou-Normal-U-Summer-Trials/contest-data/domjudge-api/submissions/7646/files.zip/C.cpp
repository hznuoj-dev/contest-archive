#include<bits/stdc++.h>
#define ll unsigned long long 
using namespace std;
ll a[500100];
ll b[50000];
int main(){
	ios::sync_with_stdio(false);cin.tie();cout.tie();
	ll n;cin>>n;
	for(int i=0;i<n;i++) cin>>a[i];
	ll t;cin>>t;
	while(t--){
		ll sum=0;
		ll nn;cin>>nn;
		bool f=0;
		for(int i=0;i<n-1;i++){
			if(a[i]+nn<a[i+1]) {
				sum+=a[i]-a[0]+nn*(n-1-i);f=1;
			}
//			else {
//				bool ff=0;
//				for(int j=1;j<n-1-i;j++){
//					if(a[i]+nn>=a[i+1+j]) ff=1;
//					else i+=j-1;
//				}
//				if(!ff) break;
//			}
		}
		if(!f) sum+=a[n-1]-a[0];
		sum+=nn;
		cout<<sum<<"\n";
	}
}
