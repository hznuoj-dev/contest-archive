#include <bits/stdc++.h>
using namespace std;
#define  ll long long
char a[50];
string  s[1005];
	map<char,int> mp;
bool big(string s1,string s2)
{
//	cout<<s1<<" "<<s2<<endl;
	int tot = min(s1.size(),s2.size());
	for(int i = 0; i<tot; i++)
	{
		if(mp[s1[i]]==mp[s2[i]]) continue;
		if(mp[s1[i]]>mp[s2[i]]) return true;
		else return false;
	}
	if(s1.size()>s2.size()) return true;
	else return false;
}
int main()
{

	int n;
	cin>>a;
	for(int i = 0; i<strlen(a);i++)
		mp[a[i]]=i;
//	cout<<mp['b']<<" "<<mp['c']<<endl;
	cin>>n;
//	if(big("acbb","abc")) cout<<"yes"<<endl;
	for(int i = 1; i<=n; i++)
		cin>>s[i];
	for(int i = 1; i<=n; i++)
		for(int j = i+1; j<=n; j++)
			if(big(s[i],s[j]))
			{
			//	cout<<"yes"<<endl;
				string s1=s[i];			
				s[i]=s[j];
				s[j]=s1;
			}
//	for(int i = 1;i<=n; i++)
//		cout<<s[i]<<endl;
	int k;
	cin>>k;
	cout<<s[k];
}
