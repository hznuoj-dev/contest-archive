#include<bits/stdc++.h>
using namespace std;

#define INF ox3f3f3f3f
int a[100001];
int sum[100001];
int main(){
	
	int n,k;
	cin>>n>>k;
	
	for(int i=1;i<=n;i++){
		cin>>a[i];
		sum[i]=sum[i-1]+a[i];//ǰ׺�� 
	}
	
	int count=0;
	
	for(int i=1;i<=n;i++){
		for(int j=0;j<i;j++){
			if((sum[i]-sum[j])%k==0){
				count++;
			}
		}
	}
	
	cout<<count<<endl;
	
	
	return 0;
} 
