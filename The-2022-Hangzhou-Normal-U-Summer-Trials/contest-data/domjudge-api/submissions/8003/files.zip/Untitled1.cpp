#include<iostream>
#include<algorithm>
#include<string>
#define endl "\n"
using namespace std;
typedef long long ll;
const int N=5e5+7;

ll a[N];
ll b[N];
ll c[N];


int main(){
	int n;
	cin>>n;
	for(int i=1;i<=n;++i){
		cin>>a[i];
	}
	for(int i=1;i<=n-1;++i){
		b[i]=a[i+1]-a[i];
	}
	sort(b+1,b+n);
	int q;
	cin>>q;
	while(q--){
		ll t;
		cin>>t;
		ll sum=0;
		ll count=0;
		for(int i=1;i<=n-1;++i){
			if(b[i]<t){
				sum+=b[i];
				count+=1;
			}else{
				break;
			}
		}
		sum+=(n-count)*t;
		cout<<sum<<endl;
	}
	return 0;
}
