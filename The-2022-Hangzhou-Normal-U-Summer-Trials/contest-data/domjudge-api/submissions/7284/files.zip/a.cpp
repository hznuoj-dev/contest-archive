#include<bits/stdc++.h>
#define int long long
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
const int N = 2e5 + 10;
int a[N];
string s[N];
typedef pair<int,int> PII;
typedef long long ll;
const int mod = 998244353;
int n, m;
int gcd(int a,int b) {return b? gcd(b,a%b):a;}
map<char, int> mp;
void solve()
{
    cin >> n;
    for(int i = 1; i <= n; i ++ ) cin >> a[i];
    int q;
    cin >> q;
    while (q --)
    {
        int t;
        cin >> t;
        int l = 2, r = n;
        while (l < r)
        {
            int mid = l + r >> 1;
            if (t < a[mid] - a[mid - 1])
            {
                r = mid;
            }
            else l = mid + 1;
        }
        //cout << l << endl;
        if (t < a[l] - a[l - 1])    
        {
            cout << a[l - 1] - 1 + t * (n - (l - 2)) << endl;
        }
        else
        {
            cout << a[n] + t - 1 << endl;
        }
    }
}
signed main()
{
    solve();
}
/*
7
qst
qrt
qrs
abce
axy
hxy
abcd
*/