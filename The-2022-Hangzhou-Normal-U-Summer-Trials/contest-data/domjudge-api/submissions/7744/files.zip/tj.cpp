#include<iostream>
#include<string>
#include<cstdio>
#include<map>
#include<cstring>
#include<algorithm>
typedef long long ll;
using namespace std;
string s[1007];
ll a[100010];
ll sum[100010];

int main(){
	
	ll ans = 0;
ll n,k;
cin >> n >> k;
cin >> a[0];
sum[0] =a[0];
if(a[0]==0||a[0]%k==0)
ans++;
for(int i = 1;i<n;i++)
{
	cin >> a[i];
	if(a[i]==0||a[i]%k==0)
	ans++;
	
	sum[i] = sum[i-1]+a[i];
	
	if(sum[i]%k==0||sum[i]==0)
	ans++;
	
}



for(int i = 2;i<n;i++){
for(int j = 0;j+i<n;j++){
//	cout << "@@@@@@@@@" << sum[i+j]-sum[j] << "@@@" <<endl;
	if((sum[i+j]-sum[j])%k==0||(sum[i+j]-sum[j])==0)
	ans++;
}
}
cout  << ans;

} 
