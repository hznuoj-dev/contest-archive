#include <stdio.h>
#include <stdlib.h>

int main()
{
	long long n, k, *a, count[100007] = {0};
	long long cnt = 0, sum = 0;
	
	scanf("%lld %lld", &n, &k);
	a = (long long *) malloc (n * sizeof(long long));
	for (int i = 0; i < n; i++)
	{
		scanf("%lld", &a[i]);
	}
	for (int i = 0; i < n; i++)
	{
		sum += a[i];
		if (sum % k == 0)
		{
			cnt++;
		}
		cnt += count[sum % k];
		count[sum % k]++;
	}
	printf("%lld", cnt);
	
	return 0;
}
