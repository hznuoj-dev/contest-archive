#include<bits/stdc++.h>
using namespace std;
string s,str[1010];
int n,k;
bool cmp(string a,string b){
	int ma=a.size(),mb=b.size();
	if(ma>mb){
		swap(ma,mb);
	}
	for(int i=0;i<ma;i++){
		if(s.find(a[i])<s.find(b[i])){
			return true;
		} else if(s.find(a[i])<s.find(b[i])){
			return false;
		}
	}
	return a.size()<b.size();
}
int main(){
	ios::sync_with_stdio(false);
	cin.tie(0);
	cout.tie(0);
	cin>>s;
	cin>>n;
	cin.get();
	for(int i=1;i<=n;i++){
		cin>>str[i];
	}
	cin>>k;
	sort(str+1,str+n+1,cmp);
	cout<<str[k]<<'\n';
	return 0;
} 
