#include<bits/stdc++.h>
using namespace std;
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n;
	cin>>n;
	if(n==1)
	{
		long long x;
		cin>>x;
		int t;
		cin>>t;
		while(t--)
		{
			cin>>x;
			cout<<x<<"\n";
		}
		return 0;
	}
	long long int a[n]={0},b[n-1]={0};
	for(int k=0;k<n;k++)
	{
		cin>>a[k];
		if(k>0)
		{
			b[k-1]=a[k]-a[k-1];
		}
	}
	int t,n1;
	cin>>t;
	long long p,ci=0;
	while(t--)
	{
		n1=n;
		ci=0;
		cin>>p;
		for(int k=0;k<n-1;k++)
		{
			if(b[k]<p)
			{
				ci=ci+b[k];
				n1--;
			}
			else break;
		}
		ci=ci+n1*p;
        cout<<ci<<"\n";
    }
	return 0;
}
