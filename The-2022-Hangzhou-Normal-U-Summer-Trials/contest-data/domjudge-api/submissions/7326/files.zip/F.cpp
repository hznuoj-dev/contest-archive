#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;

int main(void){
	
	int n, k;
	int temp=0;
	int ans=0;
	cin>>n>>k;
	int a[100007]={0};
	int sum[100007]={0};
	
	cin>>a[0];
	sum[0]=a[0];
	for(int i=1;i<n;++i){
		cin>>a[i];
		sum[i]=sum[i-1]+a[i];	
	}
	
	for(int i=0;i<n;++i){
		for(int j=i;j<n;++j){
			temp=sum[j]-sum[i]+a[i];
			if(temp%k==0){
				ans++;
			}
		}
	}
	
	cout<<ans<<endl;
	
	
	return 0;
}
