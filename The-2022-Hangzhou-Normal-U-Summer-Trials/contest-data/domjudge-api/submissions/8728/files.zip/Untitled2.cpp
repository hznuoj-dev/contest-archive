#include<bits/stdc++.h>
#include<unordered_map>
//#define ll long long
#define ll unsigned long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const ll inf = 0x3f3f3f3f;
const ll INF = 0x3f3f3f3f3f3f3f3f;
const double eps = 1e-4;
const ll N = 1e6 + 5;
const int M = 1e5 + 5;
const ll mod = 1e9 + 7;
ll mod2 = 1e5 + 7;
string s, ss; 
ll n, base[1005], m;
ll k = 13333331;
map<char, ll>mp;
struct node{
	ll v;
	string s;
}bb[1005];

bool comp(node a, node b){
	return a.v < b.v;
}

void solve() {
   cin >> s;
   for(int i = 0; i < s.size(); i++){
   	   mp[s[i]] = i + 1;
   }
   //cout << mp['a'] << " " << mp['z'] <<"\n";
  // cout << s << "\n";
   cin >> n;
   ll tot = 0;
   for(int i = 1; i <= n; i++){
	   	cin >> ss;
	   //	cout << ss << "\n";
	   	ll x = 0;
	   	ll xx = 1000;
	   	for(int j = 0; j < ss.size(); j++){
	   		x = (x % mod + mp[ss[j]] * base[xx] % mod) % mod;
	   		xx--;
		}
	/*	if(ss.size() <= 1000){
		//	cout << x <<"\n";
			x = (x * base[1000 - ss.size() + 1]) % mod;
		//	cout << x <<"\n";
		}*/
		bb[++tot].v = x;
		bb[tot].s = ss;
   }
   //cout << bb[1].v << " " << bb[1].s << " " <<  bb[2].v << "\n";
   sort(bb + 1, bb + 1 + tot, comp);
   cin >> m;
   for(int i = 1; i <= m; i++){
   	   cout << bb[i].s <<"\n";
   }
}

signed main()
{
	IOS;
	base[1] = 1; 
	for(int i = 2; i <= 1005; i++){
		base[i] = base[i - 1] * k % mod;
	}
	int t = 1;
	//cin >> t;
	while (t--)
	{
		solve();
	}

}
