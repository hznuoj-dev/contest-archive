#include<stdio.h>

int a[500010], b[500010];

int main()
{
	int n;
	scanf("%d", &n);
	int i;
	for (i = 1; i <= n; i ++)
	{
		scanf("%d", &a[i]);
		b[i] = a[i] - a[i - 1] + 1;
	}
	int t;
	scanf("%d", &t);
	for (i = 0; i < t; i ++)
	{
		int x;
		scanf("%d", &x);
		int l = 1, r = n, mid, s = 0;
		if (x <= b[1])
			s = n * x;
		else if (x >= b[n])
			s = a[n] + x - 1;
		else
		{
			while (l <= r)
			{
				mid = (l + r) / 2;
				if (b[mid] < x)
					l = mid + 1;
				else if (b[mid] > x)
					r = mid - 1;
				else
					break;
			}
			if (b[mid] > x )
				mid = mid - 1;
			s = a[mid] + x - 1 + (n - mid) * x;
		}
		printf("%d\n", s);
	}
	return 0;
}
