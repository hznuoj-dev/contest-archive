#include<iostream>
#include<string>
#include<algorithm>
#include<cstring>
#include<vector>
#include<queue>
#include<map>

#define ll long long
#define lowbit(x) ((x)&(-(x)))
#define pb push_back
#define vi vector<int>
#define pii pair<int, int>
#define allv(x) (x).begin(), (x).end() 
#define bit32(x) (__builtin_popcount((unsigned int)(x)))
#define bit64(x) (bit32(x>>32)+bit32(x))
#define IOS ios::sync_with_stdio(0);cin.tie(0);cout.tie(0);

using namespace std;
const int N = 1e5 + 10;
ll a[N];
int n;
map<char,int>s;
int cmp(string x,string y)
{
    int i=0;
    while(x[i]==y[i])i++;
    return s[x[i]]<s[y[i]]||x.size()>y.size();
    
}
int main(){
    char c;
    for(int i=1;i<=26;i++)
    {
        scanf("%c",&c);
        s[c]=i;
    }
    string str[1010];
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++)
    {
        cin>>str[i];
    }
    sort(str,str+n,cmp);
    int k;
    scanf("%d",&k);
    cout<<str[k-1];
    return 0;
}