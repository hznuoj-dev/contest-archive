#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
void solve(){
	int i,j,m,n,x,y,k,l,r,ans=0;
	string s;
	cin>>s;
	n=s.length();
	for(i=0;i<=n-4;i++){
		if(s.substr(i,4)=="hznu") ans++;
	}
	printf("%d",ans);
}
int main(void){
	int T=1;
	//cin>>T;
	while(T--){
		solve();
	}
}
