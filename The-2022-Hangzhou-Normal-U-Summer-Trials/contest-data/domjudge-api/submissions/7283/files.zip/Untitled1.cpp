#include<bits/stdc++.h>
#define ll long long
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
using namespace std;

const int N = 5e5 + 5;
const double eps = 1e-5;
const int mod = 1e9 + 7;

ll n, a[N];

void solve()
{
	cin >> n;
	for(ll i = 1; i <= n; i++)
		cin >> a[i]; 
	ll q;
	cin >> q;
	while(q--)
	{
		ll ans = 0;
		ll t;
		cin >> t;
		ans += t;
		for(ll i = n - 1; i >= 1; i--)
		{
			if(a[i] + t - 1 < a[i+1])
				ans += t;
			else
			{
				ans += a[i+1] - 1;
				break;
			}
		}
		cout << ans << '\n';
	}
}

int main()
{
	IOS;
	ll t = 1;
	//cin >> t;
	while (t--)
		solve();
}
