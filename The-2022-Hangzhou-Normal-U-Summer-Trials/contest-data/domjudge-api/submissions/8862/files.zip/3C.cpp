#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<int,int> pii;

const int N=5e5+10;
int n,q;
ll a[N],s[N],t;

int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0); 
	cin>>n;
	for(int i=1;i<=n;i++) cin>>a[i];
	for(int i=1;i<n;i++) s[i]=a[i+1]-a[i];
	
	cin>>q;
	while(q--)
	{
		cin>>t;
		ll x=lower_bound(s+1,s+n,t)-s; 
		if(x==n-1 && t>s[n-1]) x++;
		ll ans=a[x]-a[1]+(n-x+1)*t;
		cout<<ans<<endl;
	}
	
	return 0;
}
