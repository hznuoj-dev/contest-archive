#include<bits/stdc++.h>
using namespace std;

long long a[500005],b[500005];
int n;

int find(int t)//1st b[i]>=t
{
	int l=1,r=n;
	while(l<=r)
	{
		int mid=(l+r)/2;
		if(b[mid]<t)
		{
			l=mid+1;
		}
		else
		{
			r=mid-1;
		}
	}
	return l;
}


int main()
{
	cin>>n;
	for(int i=1;i<=n;i++)
	{
		cin>>a[i];
		b[i]=a[i]-a[i-1];
	}
	int q;
	cin>>q;
	while(q--)
	{
		long long t;
		cin>>t;
		int ind=find(t);
		long long ans;
		if(ind!=1)
		{
			ans=a[ind-1]-a[1]+(n-ind+2)*t;
		}
		else
		{
			ans=n*t;
		}
		cout<<ans<<endl;
	}
}
