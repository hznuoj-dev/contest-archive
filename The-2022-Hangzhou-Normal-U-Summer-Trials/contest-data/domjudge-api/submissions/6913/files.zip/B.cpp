#include <bits/stdc++.h>
#define endl '\n'
using namespace std;
typedef long long ll;
const int N=2e5+10;
const int M=1e9+7;

vector<char> c;
string s[1004];

bool cmp(string a,string b)
{
	int lena=a.length(),lenb=b.length();
	int len=min(lena,lenb);
	
	for(int i=0;i<len;i++)
	{
		vector<char>::iterator ita=find(c.begin(),c.end(),a[i]);
		vector<char>::iterator itb=find(c.begin(),c.end(),b[i]);
		if(ita<itb)
			return true;
		else if(ita>itb)
			return false;
	}
	if(lena>lenb)
		return true;
	else
		return false;
}

void run()
{
	char ch;
	int n,k;
	
	for(int i=1;i<=26;i++)
	{
		cin >> ch;
		c.push_back(ch);
	}
	cin >> n;
	for(int i=1;i<=n;i++)
		cin >> s[i];
	cin >> k;
	sort(s+1,s+1+n,cmp);
	cout << s[k];
}

int main()
{
	int T=1;
	
	ios::sync_with_stdio(0);
	//cin >> T;
	while(T--)
		run();
	
	return 0;
}
