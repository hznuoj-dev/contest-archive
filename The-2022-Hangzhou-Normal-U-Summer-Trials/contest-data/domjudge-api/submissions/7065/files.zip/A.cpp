#include<iostream>
#include<string.h>
#include<cstring>
#define ll long long

using namespace std;

int main()
{
	char s[100010];
	cin >> s;
	string k = "hznu";
	int sum = 0;
	int q = 0;
	for (int i = 0; i < strlen(s); i++)
	{
		//cout << k[q] << endl;
		if (s[i] == k[q])
			q++;
		else
		{
			q = 0;
			if (s[i] == k[q])
				q++;
		}
		if (q == 4)
		{
			sum++;
			q = 0;
		}
	}
	cout << sum;
	return 0;
}
