#include<bits/stdc++.h>
using namespace std;
#define int long long
const int maxn = 1e5 + 5;

int signa[maxn << 2], signb[maxn << 2], e[maxn << 2], ee[maxn << 2], now[maxn << 2], a[maxn];

void henshin(int rt){
	e[rt] = __gcd(e[rt << 1], e[rt << 1 | 1]);
	ee[rt] = __gcd(ee[rt << 1], ee[rt << 1 | 1]);
}

void build(int l, int r, int rt){
	signa[rt] = 1;
	signb[rt] = 1;
	if(l == r){
		e[rt] = 1;
		now[rt] = 1;
		return;
	}
	int m = l + r >> 1;
	build(l, m, rt << 1);
	build(m + 1, r, rt << 1 | 1);
	henshin(rt);
}

void down(int rt){
	if(signa[rt] != 1){
		signa[rt << 1] *= signa[rt];
		signa[rt << 1 | 1] *= signa[rt];
		e[rt << 1] *= signa[rt];
		e[rt << 1 | 1] *= signa[rt];
		signa[rt] = 1;
	}
	
	if(signb[rt] != 1){
		signb[rt << 1] *= signb[rt];
		signb[rt << 1 | 1] *= signb[rt];
		e[rt << 1] /= signb[rt];
		e[rt << 1 | 1] /= signb[rt];
		signb[rt] = 1;
	}
}

void flip(int l, int r, int p, int rt){
	if(l == r){
		if(ee[rt]){
			e[rt] = ee[rt];
			ee[rt] = 0;
		} 
		else{
			ee[rt] = e[rt];
			e[rt] = 0;
		} 
		return;
	}
	down(rt);
	int m = l + r >> 1;
	if(p <= m) flip(l, m, p, rt << 1);
	else flip(m + 1, r, p, rt << 1 | 1);
	henshin(rt);
}



void mul(int l,int r, int al, int ar, int x, int rt){
	if(al <= l && r <= ar){
		e[rt] *= x;
		signa[rt] *= x;
		return;
	}
	int m = l + r >> 1;
	down(rt);
	if(al <= m) mul(l, m, al, ar, x, rt << 1);
	if(ar > m) mul(m + 1, r, al, ar, x, rt << 1 | 1);
	henshin(rt);
}

void div(int l, int r, int al, int ar, int x, int rt){
	if(al <= l && r <= ar){
		e[rt] /= x;
		signb[rt] *= x;
		return;
	}
	int m = l + r >> 1;
	down(rt);
	if(al <= m) div(l, m, al, ar, x, rt << 1);
	if(ar > m) div(m + 1, r, al, ar, x, rt << 1 | 1);
	henshin(rt);
}

int ask(int l, int r, int al, int ar, int rt){
	if(al <= l && r <= ar) return e[rt];
	int ans = 0;
	int m = l + r >> 1;
	down(rt);
	if(al <= m) ans = ask(l, m, al, ar, rt << 1);
	if(ar > m) ans = __gcd(ans, ask(m + 1, r, al, ar, rt << 1 | 1));
	henshin(rt);
	return ans;
}

int askk(int l, int r, int al, int ar, int rt){
	if(al <= l && r <= ar) return ee[rt];
	int ans = 0;
	int m = l + r >> 1;
	down(rt);
	if(al <= m) ans = askk(l, m, al, ar, rt << 1);
	if(ar > m) ans = __gcd(ans, askk(m + 1, r, al, ar, rt << 1 | 1));
	henshin(rt);
	return ans;
}

void solve(){
	int n, m; cin >> n >> m;
	build(1, n, 1);
	while(m--){
		string e; cin >> e;
		if(e[0] == 'm'){
			int a, b, c; cin >> a >> b >> c;
			mul(1, n, a, b, c, 1);
		}
		else if(e[0] == 'd'){
			int a, b, c; cin >> a >> b >> c;
			int sign = ask(1, n, a, b, 1);
			int ss = askk(1, n, a, b, 1);
			sign = __gcd(sign, ss);
			//cout << sign << " " << ss << " ";
			if(sign >= c && (sign % c) == 0){
				cout << "YES" << endl;
				div(1, n, a, b, c, 1);
			}
			else cout << "NO" << endl;
 		}
 		else{
 			int p; cin >> p;
 			flip(1, n, p, 1);
 		}
	}
}

signed main(){
	ios::sync_with_stdio(false);
	int t = 1;
	//cin >> t;
	while(t--){
		solve();
	}
	return 0;
}
