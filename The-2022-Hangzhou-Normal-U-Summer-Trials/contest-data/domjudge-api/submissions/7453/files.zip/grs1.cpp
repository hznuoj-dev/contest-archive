#include<bits/stdc++.h>
#define rson rt<<1|1
#define lson rt<<1
#define pb push_back
#define endl '\n'
#define x first
#define y second
#define LLINF 9223372036854775807
#define IOS ios::sync_with_stdio(0); cin.tie(0); 
using namespace std;
typedef long long ll;
typedef unsigned long long ull;
typedef pair<int,int> pii;
typedef pair<ll,ll> pll;

const int N=201000;

ll n;
vector<int>g[N];
ll sz[N];
ll dp[N];

void dfs(int x,int fa){
    sz[x]=1;
    ll sum=0;
    for(int i:g[x]){
        if(i==fa)continue;
        dfs(i,x);
        sz[x]+=sz[i];
    }
    for(int i:g[x]){
        if(i==fa){
            dp[x]+=(n-sz[x])*(sz[x]-1);
        }else {
            dp[x]+=(sz[i])*(n-sz[i]-1);
        }
    }
    
}

int main()
{  
	IOS 
    cin>>n;
    for(int i=1;i<n;i++){
        int a,b;cin>>a>>b;
        g[a].pb(b);
        g[b].pb(a);
    }
    dfs(1,-1);
    int q;
    cin>>q;
    while(q--){
        int t;cin>>t;
        cout<<dp[t]/2+n-1<<endl;
    }
    return 0;
}