#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[1000008];
ll s[100008];
int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);
	cout.tie(0);
	ll n;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>a[i];
		if(i>1)
		s[i-1]=a[i]-a[i-1];
	}
	s[n]=2e18;
	int q;
	cin>>q;
	while(q--){
		ll k;
		cin>>k;
		ll p=lower_bound(s+1,s+1+n,k)-s;
		ll ans=a[p]+(n-p+1)*k;
		cout<<ans-1<<"\n";
	}
} 
