#include<bits/stdc++.h>
using namespace std;
typedef long long ll;

const int N = 5e5 + 5;
const int INF = 0x3f3f3f3f;

int a[N], s[N];

int main() {
	int n;
	scanf("%d", &n);
	for (int i = 1; i <= n; i++) {
		scanf("%d", &a[i]);
		s[i] = a[i] - a[i - 1];
	}
	int minr = s[2];
	int maxr = s[n];
	int q;
	scanf("%d", &q);
	while (q--) {
		int x;
		scanf("%d", &x);
		if (n == 1) {
			printf("%d\n", x);
			continue;
		}
		if (x <= minr) {
			printf("%d\n", x * n);
		} else if (x >= maxr) {
			printf("%d\n", x + a[n] - 1);
		} else {
			int cnt = 0;
			for (int i = 2; i <= n; i++) {
				if (x >= s[i]) {
					cnt += s[i];
				} else {
					cnt += x;
				}
			}
			cnt += x;
			printf("%d\n", cnt);
		}
	}
	return 0;
}