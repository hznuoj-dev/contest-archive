#include<bits/stdc++.h>
using namespace std;
#define int long long
const int N=1e5+10;
int cnt[N],ch[N];
signed main(void){
	int n,k;
	scanf("%lld%lld",&n,&k);
	for(int i=1;i<=n;++i){
		scanf("%lld",&ch[i]);
		cnt[i]=cnt[i-1]+ch[i];
	} 
	int ans=0;
	for(int i=1;i<=n;++i){
		if(ch[i]%3==0) ans++;
		for(int j=i+1;j<=n;++j){
			if((cnt[j]-cnt[i-1])%3==0) ans++;
		}
	}      
	printf("%lld",ans);
		return 0;
}
