#include<bits/stdc++.h>
using namespace std;
const int N=5e5+10;
long long a[N],b[N],sum[N];
long long n,q,t;
int main()
{
	cin>>n;
	for(int i=0;i<n;i++)
		cin>>a[i];
	for(int i=1;i<n;i++)
		b[i]=a[i]-a[i-1]+1;
	cin>>q;
	while(q--)
	{
		cin>>t;
		if(t<b[1])
			cout<<t*n<<'\n';
		else if(t>b[n-1])	
			cout<<t+a[n-1]-a[0]<<'\n';
		else 
		{
			long long l=1,r=n-1;
			while(l<r)
			{
				long long mid=l+r>>1;
				if(b[mid]>=t)r=mid;
				else l=mid+1;		
			}
			if(b[l]==t)
			cout<<t*(n-l+1)+a[l-1]-a[0]-1<<'\n';
			else cout<<t*(n-l+1)+a[l-1]-a[0]<<'\n';
		}
		
		
	}
} 
