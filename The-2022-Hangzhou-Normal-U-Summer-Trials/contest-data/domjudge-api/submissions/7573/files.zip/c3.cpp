#include <bits/stdc++.h>

#define ll long long
#define PII pair<ll, int>
#define dbg(x) cerr << #x << " = " << x << endl;

using namespace std; 

const int N = 5e5 + 10;
const int INF = 0x3f3f3f3f;         // 1061109567
const ll INFF = 0x3f3f3f3f3f3f3f3f; // 4557430888798830399
const double esp = 1e-8, pi = acos(-1.0);
const int MOD = 998244353;

ll qmi(int a, int b)
{
    ll ret = 1 % MOD;
    while (b)
    {
        if (b & 1) ret = ret * (ll)a % MOD;

        a = a * (ll)a % MOD;
        b >>= 1;
    }
    
    return ret;
}

int gcd(int a, int b)
{
    return b ? gcd(b, a % b) : a;
}

int lowbit(int x)
{
    return x & -x;
}

/////////////////////////////////////////////////////////// 

ll n, q, t;
ll a[N], b[N], tot[N];

void solve()
{
    scanf("%lld", &n);
    for (int i = 1; i <= n; i ++ ) scanf("%lld", a + i);

    sort(a + 1, a + 1 + n);
    int cnt = 0;
    for (int i = 1; i <= n; i ++ )
    {
        if (a[i] != a[i - 1]) a[++ cnt] = a[i];
    }
    n = cnt;
    //unique(a + 1, a + 1 + n);
    //for (int i = 1; i <= n; i ++ ) dbg(a[i]);
    
    for (int i = 1; i <= n - 1; i ++ ) b[i] = a[i + 1] - a[i];

    ll now = n;
    for (int i = 1; i <= n - 1; i ++ ) tot[i] = (b[i] - b[i - 1]) * (now --) + tot[i - 1];
    //for (int i = 1; i <= n - 1; i ++ ) dbg(tot[i]);
    scanf("%lld", &q);
    while (q -- )
    {
        ll t;
        scanf("%lld", &t);
        //int x = lower_bound(b, b + n, t) - b;
        ll l = 0, r = n - 1;
        while (l < r)
        {
            ll mid = (l + r + 1) / 2;
            if (b[mid] <= t) l = mid;
            else r = mid - 1;
        }
        
        ll x = l;

        /*dbg(x);
        dbg(b[x]);
        dbg(tot[x]);*/

        ll ret = tot[x];
        if (x) ret += (t - b[x]) * (n - x);
        else ret += n * t;

        printf("%lld\n", ret);
    }
    
}

int main()
{
    //ios::sync_with_stdio(0);

    int T = 1;
    //cin >> T;
    //scanf("%d", &T);
    //init();

    while (T--)
    {
        solve();
    }

    return 0;
}
