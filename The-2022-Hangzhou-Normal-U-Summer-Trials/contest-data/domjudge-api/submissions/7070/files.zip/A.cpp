#include <cstdio>
#include <algorithm>
#include <cstring>

int main()
{
	char st[100010], a[5] = "hznu", *q;
	int l, i, cnt = 0;
	scanf("%s", st);
	l = strlen(st);
	q = st;
	for(; q < st + l; q++)
	{
		if (*q == 'h')
		{
			for (i = 1; i < 4; i++)
			{
				if(q[i] != a[i])
					break;
			}
			if (i == 4)
				cnt++;
		}
	}
	printf("%d", cnt);
	return 0;
}
