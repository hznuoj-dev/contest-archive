#include<iostream>
#include<cstring>
using namespace std;
const int N=1e6+10;
typedef long long ll;
ll a[N],sum[N];
int main(){
	ll n,k;
	ll count=0;
	memset(sum,-1,sizeof(sum));
	cin>>n>>k;
	cin>>a[0];
	sum[0]=a[0];
	for(int i=1;i<n;i++){
	  cin>>a[i];
	  sum[i]=(sum[i-1]+a[i]%k)%k;
	}
	int flag=0;
	ll now,next;
	now=0;
	for(int i=0;i<n;i++){
		if(sum[i]==0&&i!=0){
		count+=i-now+1;
		now=i;
	    }
	
	}
	cout<<count;
return 0;
}