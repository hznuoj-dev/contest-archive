#include<bits/stdc++.h>
using namespace std;

int main(){
	long long n=0,q;
	long long t,prb,ed;
	cin>>n;
	long long a[n+1];
	cin>>a[0];
	a[1]=0;
	for(long long i = 2; i <= n; i++){
		cin>>prb;
		a[n]=prb-a[0];
	}
	sort(a+1,a+1+n);
	cin>>q;
	for(long long i = 0; i < q; i++){
		long long ans;
		cin>>t;
		for(long long j = 1; j <= n; j++){
			if(t<a[j]){
				ans+=(n-j)*t;
				break;
			}
			ans+=a[j]-1;
		}
		cout<<ans<<"\n";
	}

	return 0;
}
