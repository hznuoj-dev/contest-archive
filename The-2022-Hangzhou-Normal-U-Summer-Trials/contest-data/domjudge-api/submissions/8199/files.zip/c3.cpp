#include <bits/stdc++.h>

#define ll long long
#define PII pair<ll, int>
#define dbg(x) cerr << #x << " = " << x << endl;

using namespace std; 

const int N = 1e5 + 10;
const int INF = 0x3f3f3f3f;         // 1061109567
const ll INFF = 0x3f3f3f3f3f3f3f3f; // 4557430888798830399
const double esp = 1e-8, pi = acos(-1.0);
const int MOD = 998244353;

ll qmi(int a, int b)
{
    ll ret = 1 % MOD;
    while (b)
    {
        if (b & 1) ret = ret * (ll)a % MOD;

        a = a * (ll)a % MOD;
        b >>= 1;
    }
    
    return ret;
}

int gcd(int a, int b)
{
    return b ? gcd(b, a % b) : a;
}

int lowbit(int x)
{
    return x & -x;
}

/////////////////////////////////////////////////////////// 

int n, m;
char g[60][60];
bool sta[60][60], stb[60][60], st[60][60];
PII sa, sb;
int ret = INF;
int cnt[60][60];
int dx[] = {1, 0, -1, 0}, dy[] = {0, -1, 0, 1};

void bfs()
{
    queue<pair<PII, int>> qa, qb;
    qa.push({sa, 0});
    qb.push({sb, 0});
    sta[sa.first][sa.second] = stb[sb.first][sb.second] = true;

    for (int i = 0; i < 100000; i ++ )
    {
        auto ta = qa.front(); qa.pop();
        auto tb = qb.front(); qb.pop();

        int ax = ta.first.first, ay = ta.first.second;
        int bx = tb.first.first, by = tb.first.second;

        if (ax == bx && ay == by)
        {
            ret = min(ret, ta.second);
        }

        for (int i = 0; i < 4; i ++ )
        {
            int tax = min(n, ax + dx[i]), tay = min(n, ay + dy[i]);
            int tbx = min(n, bx + dx[i]), tby = min(n, by + dy[i]);

            if (g[tax][tay] == '*')
            {
                tax = ax;
                tay = ay;
            }
            if (g[tbx][tby] == '*')
            {
                tbx = bx;
                tby = by;
            }

            qa.push({{tax, tay}, ta.second + 1});
            qb.push({{tbx, tby}, tb.second + 1});
        }
    }
    
}

bool check()
{
    queue<PII> q;
    //qa.push(sa);
    //qb.push(sb);
    st[sb.first][sb.second] = true;
    q.push(sb);

    while (q.size())
    {
        auto t = q.front(); q.pop();
        int x = t.first, y = t.second;

        for (int i = 0; i < 4; i ++ )
        {
            int tx = x + dx[i], ty = y + dy[i];
            if (tx == sa.first && ty == sa.second) return true;
            if (tx >= 1 && tx <= n && ty >= 1 && ty <= n && !st[tx][ty] && g[tx][ty] == '.')
            {
                st[tx][ty] = true;
                q.push({tx, ty});
            }
        }
    }

    return false;
    
}

void solve()
{
    cin >> n;
    for (int i = 1; i <= n; i ++ )
    {
        for (int j = 1; j <= n; j ++ )
        {
            cin >> g[i][j];
        }
    }

    for (int i = 1; i <= n; i ++ )
    {
        for (int j = 1; j <= n; j ++ )
        {
            if (g[i][j] == 'a') sa = {i, j};
            if (g[i][j] == 'b') sb = {i, j};
        }
    }

    if (!check())
    {
        cout << "no solution\n";
        return;
    }
    
    bfs();

    cout << ret << endl;
}

int main()
{
    ios::sync_with_stdio(0);

    int T = 1;
    //cin >> T;
    //scanf("%d", &T);
    //init();

    while (T--)
    {
        solve();
    }

    return 0;
}
