#include<stdio.h>

int main(){
	long long n,q;
	long long i;
	scanf("%lld",&n);
	long long a[n],b[n-1],c[n-1];
	for(i=0;i<n;i++){
		scanf("%lld",&a[i]);
	}
	scanf("%lld",&q);
	for(i=0;i<n-1;i++){
		b[i] = a[i+1]-a[i];
//		printf("%lld ",b[i]);
	}
//	printf("\n");
	c[0] = b[0];
	for(i=1;i<n-1;i++){
		c[i] = c[i-1]+b[i];
	}
	while(q--){
		long long t,l,r,m,ans=0;
		int flag=1;
		scanf("%lld",&t);
		l = 0;
		r = n-2;
		m = (l+r)/2;
		if(t>=b[r]){
			ans = c[r]+t;
		}else if(t<=b[l]){
			ans = t*n;
		}else{
			while(!(t>=b[l]&&t<=b[r]&&r-l==1)){
				if(t>b[m]){
					l = m;
					m = (l+r)/2;
				}else if(t<b[m]){
					r = m;
					m = (l+r)/2;
				}else{
					ans = c[m]+(n-m-1)*t;
					flag=0;
					break;
				}
			}
			if(flag)ans = c[l]+(n-r)*t;
		}
//		printf("\n%d %d\n",l,r);
		printf("%lld",ans);
		if(q){
			printf("\n");
		}
	}
	return 0;
}
