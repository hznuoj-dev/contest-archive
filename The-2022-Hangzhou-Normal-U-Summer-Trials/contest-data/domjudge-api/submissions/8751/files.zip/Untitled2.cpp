#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define moonoom ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
const ll MAXN=5e5+10;
ll sum[MAXN];
ll arr[MAXN];
signed main(){
	moonoom;
	long int n;ll k;
	cin>>n>>k;
	ll ans=0;
	
	for(int i=1;i<=n;i++){
		cin>>arr[i];
		arr[i]%=k;
		sum[i]=sum[i-1]+arr[i];
	}	
	
	for(int i=1;i<=n;i++){
		if(arr[i]==0)ans++;
	}
	if(arr[1]==0)ans--;
	for(int i=0;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			if((sum[j]-sum[i])%k==0)ans++;
		}
	}
	cout<<ans<<endl;
}
