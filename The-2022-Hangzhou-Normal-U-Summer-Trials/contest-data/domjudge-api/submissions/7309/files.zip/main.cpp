#include<bits/stdc++.h>
using namespace std;
using i64 = long long;
#define inf 0x3f3f3f3f3f3f3f3f
#ifdef ACM_LOCAL
const int N = 1e1 + 10;
#else
const int N = 5e5 + 10;
#endif
i64 a[N], range[N];
i64 sum[N];
inline i64 read() {
    i64 s = 0,w = 1;
    char ch = getchar();
    while(ch <= '0' || ch > '9') { if( ch == '-') w = -1; ch = getchar(); }
    while(ch >= '0' && ch <= '9') s = s * 10 + ch - '0' ,ch = getchar();
    return s * w;
}
inline void write(i64 x)
{
    if(x < 0) putchar('-'),x = -x;
    if(x > 9) write(x / 10);
    putchar(x % 10 + '0');
}
signed main(){
#ifdef ACM_LOCAL
    freopen("data.in", "r", stdin);
    freopen("data.out", "w", stdout);
#endif

    int n = read();
    for(int i = 1;i <= n;i ++) a[i] = read();
    for(int i = 1;i < n;i ++) range[i] = a[i + 1] - a[i];
    range[n] = inf;

    int left = n;
    for(int i = 1;i <= n;i ++){
        sum[i] = sum[i - 1] + left * (range[i] - range[i - 1]);
        left --;
    }

    int k = read();
    while(k --){
        i64 t = read();
        auto p = lower_bound(range + 1, range + n, t) - range;
        i64 more = t - range[p];
        i64 ans = sum[p] + (i64)(n - p + 1) * more;
        write(ans), putchar('\n');
    }

    return 0;
}