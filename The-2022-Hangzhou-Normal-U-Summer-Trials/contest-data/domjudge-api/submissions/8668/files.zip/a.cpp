#include<iostream>
#include<map>
#include<algorithm>
using namespace std;

const int N=1e3+7;
string str[N];
int temp[N];
int a[N];
map<char,int> mp;

bool cmp(string s1, string s2)
{
    int l1=s1.size(),l2=s2.size();
    for(int i=0; i<l1 && i<l2; i++){
        if(mp[s1[i]]<mp[s2[i]]) return true;
        else if(mp[s1[i]]>mp[s2[i]]) return false;
    }
    if(l1<=l2) return true;
    else return false;
}

void merge_sort(int l, int r)
{
    if(l>=r) return;
    int mid=l+r>>1;
    merge_sort(l,mid);
    merge_sort(mid+1,r);
    int k=0,i=l,j=mid+1;
    while(i<=mid && j<=r){
        if(cmp(str[a[i]],str[a[j]])) temp[k++]=a[i++];
        else temp[k++]=a[j++];
    }
    while(i<=mid) temp[k++]=a[i++];
    while(j<=r) temp[k++]=a[j++];
    for(int i=0,j=l; j<=r; i++,j++){
        a[j]=temp[i];
    }
}

int main()
{
    string s;
	cin >> s;
	for(int i=0; i<(int)s.size(); i++) mp[s[i]]=i;
	int n;
	cin >> n;
	for(int i=0; i<n; i++) cin >> str[i];
	int k;
	cin >> k;
	for(int i=0; i<n; i++) a[i]=i;
	merge_sort(0,n-1);
	//cout << str[a[k-1]] << endl;
    /*for(int i=0; i<n; i++){
        cout << str[a[i]] << endl;
        //cout << a[i] << endl;
    }*/
    //cout << cmp(str[a[3]],str[a[1]]) << endl;
    cout << str[a[k-1]] << endl;
	return 0;
}
/*
acbdefghijklmnopqrstuvwxyz
4
adjjjd
acbde
acbbb
acbde
4*/
