#include <bits/stdc++.h>
using namespace std;
char c[201000];
int x[200100];int y[200100];
int f[200100];
int find(int x){
	return x==f[x]?x:f[x]=find(f[x]);
}
int main()
{
	for(int i='a';i<='z';i++)f[i]=i;
	int n;
	cin>>n;
	int a1=0;
	int a2=0;
	int top=0;int top2=0;
	for(int i=1;i<=n;i++){
		char ch;
		cin>>ch;
		if(ch=='1'){
			char x;cin>>x;
		c[++top]=x;}
		if(ch=='2'){
			if(top>0)top--;
		}
		if(ch=='3'){
			top2++; char t1,t2;
			cin>>t1>>t2;
			x[top2]=t1;
			y[top2]=t2;
	
		} 
	}
	for(int i=top2;i>=1;i--){
		char t1=x[i];char t2=y[i];
		int u1=find(t1);int u2=find(t2);
			if(u1!=u2){
				f[u1]=u2;
			}
	}
	if(top<=0){
		printf("The final string is empty");
		return 0;
	}
	for(int i=1;i<=top;i++){
		printf("%c",find(c[i]));
	}
}
