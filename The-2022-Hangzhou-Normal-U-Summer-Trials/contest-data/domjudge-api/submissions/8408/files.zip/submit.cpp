#include <bits/stdc++.h>
using namespace std;
using ll = long long;
using T = pair<int, int>;

const int N = 200010, P = 1e9 + 7;

int n;

struct query {
    int op;
    char a, b;
} Q[N];

char s[N];

map<char, char> mp;

signed main ()
{
    cin >> n;
    int len = 0;
    for (int i = 1; i <= n; i ++ ) {
        cin >> Q[i].op;
        if (Q[i].op == 3) cin >> Q[i].a >> Q[i].b;
        if (Q[i].op == 1) cin >> Q[i].a, ++ len;
        if (Q[i].op == 2) len = max(0, len - 1);
    }
    if (!len) return cout << "The final string is empty\n", 0;

    for (char c = 'a'; c <= 'z'; c ++ ) mp[c] = c;


    s[len] = 0;

    -- len;

    int del = 0;
    for (int i = n; i >= 1; i --) {
        if (Q[i].op == 3) {
            mp[Q[i].a] = mp[Q[i].b];
        } else {
            if (Q[i].op == 2) ++ del;
            else {
                if (del) -- del;
                else {
                    if (len < 0) while(1);
                    s[len] = mp[Q[i].a];
                    -- len;
                }
            }
        }
    }
    cout << s << endl;

    return 0;
}