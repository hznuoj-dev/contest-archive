
#include <bits/stdc++.h>
using namespace std;

#define INF 0x3f3f3f3f

#define ll long long
#define endl '\n'
#define null NULL
#define ls p<<1
#define rs p<<1|1
#define fi first
#define se second
#define mp make_pair
#define pb push_back
#define vi vector<int>
#define mii map<int,int>
#define pii pair<int,int>
#define ull unsigned long long
#define pqi priority_queue<int>
#define IOS ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define ct cerr<<"Time elapsed:"<<1.0*clock()/CLOCKS_PER_SEC<<"s.\n";
#define ull unsigned long long
#define rep(i,a,b) for(int i=(a);i<=(b);i++)
inline int rd() {//�����Ż������Լӿ����ֵ�����
	char p = 0; int r = 0, o = 0;
	for (; p < '0' || p>'9'; o |= p == '-', p = getchar());
	for (; p >= '0' && p <= '9'; r = (r << 1) + (r << 3) + (p ^ 48), p = getchar());
	return o ? (~r) + 1 : r;
}
void write(int x) {
	if (x < 0) putchar('-'), x = -x;
	if (x > 9) write(x / 10);
	putchar(x % 10 + '0');
}
const int M = 52;
const int mod=1e9+7;
const double pi=acos(-1.0);
int qpow(int a,int b){
	int result=1;
	int s=a;
	while(b){
		if(b&1){
			result=(result*a)%mod;
		}
		a=(a*a)%mod;
		b/=2;
	}
	return result;
}
int gcd(int a,int b){
	if(b==0) return a;
	else{
		return gcd(b,a%b);
	}
}
char s[M][M];
int dx[4]={1,-1,0,0};
int dy[4]={0,0,1,-1};
int n;
bool check(int x,int y){
	return (x>=1&&x<=n&&y>=1&&y<=n);
}
bool check2(int x,int y){
	return s[x][y]=='*'?1:0;
}
int temp(int x1,int x2,int y1,int y2){
	return abs(x1-x2)+abs(y1-y2);
}
bool vis[M][M][M][M];
void solve()
{
	IOS;
//	freopen("1.txt","r",stdin);
//	freopen("3.txt","w",stdout);
	n=rd();
	rep(i,1,n){
		rep(j,1,n){
			scanf("%c",s[i][j]);
		}
	}
	pair<int,int> sk,tk;
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(s[i][j]=='a'){
				sk.fi=i;
				sk.se=j;
			}
			if(s[i][j]=='b'){
				tk.fi=i;
				tk.se=j;
			}
		}
	}
	queue<pair<int,int> > q1,q2;
	queue<int> p;
	q1.push(sk);
	q2.push(tk);
	p.push(0);
//	int time=40;
	
	while(!q1.empty()){
		pair<int,int> g1=q1.front();
		pair<int,int> g2=q2.front();
		int x1=g1.fi;
		int y1=g1.se;
		int x2=g2.fi;
		int y2=g2.se;
//		cout<<"x1="<<x1<<" y1="<<y1<<endl;
//		cout<<"x2="<<x2<<" y2="<<y2<<endl;
		vis[x1][y1][x2][y2]=1;
		q1.pop();
		q2.pop();
		int len=p.front();
		p.pop();
//		continue;
		if(x1==x2&&x2==y2){
			cout<<len<<endl;
			
			return ;
		}
		if(len>=200){
			cout<<"no solution"<<endl;
			return ;
		}
//		time--;
//		if(time==0) break;
		for(int i=0;i<4;i++){
			int x3,x4,y3,y4;
			if(!check(x1+dx[i],y1+dy[i])||check2(x1+dx[i],y1+dy[i])){
				x3=x1;
				y3=y1;
			}
			else{
				x3=x1+dx[i];
				y3=y1+dy[i];
			}
			
			if(!check(x2+dx[i],y2+dy[i])||check2(x2+dx[i],y2+dy[i])){
				x4=x2;
				y4=y2;
			}
			else{
				x4=x2+dx[i];
				y4=y2+dy[i];
			}
			
//			cout<<"x3="<<x3<<" y3="<<y3<<endl;
//			cout<<"x4="<<x4<<" y4="<<y4<<endl;
//			return ;
			if(temp(x1,x2,y1,y2)>=temp(x3,x4,y3,y4)&&vis[x3][y3][x4][y4]==0){
				q1.push(mp(x3,y3));
				q2.push(mp(x4,y4));
				p.push(len+1);
			}
			
		}
		
	}
	cout<<"no solution"<<endl;
	
	
}
signed main()
{
	int t;
//	cin>>t;
	t=1;
	while(t--){
	solve();
	}
}

