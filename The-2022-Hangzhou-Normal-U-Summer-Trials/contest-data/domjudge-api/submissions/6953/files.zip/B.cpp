#include <bits/stdc++.h> 
using namespace std;
string str;
string s[1050];
int c[150];
bool cmp(string a,string b)
{
	int lena=a.size();
	int lenb=b.size();
	int len=min(lena,lenb);
	for (int i=0; i<=len; i++)
		if (a[i]!=b[i]) return c[a[i]]<c[b[i]];
	return lena<lenb;
}


int main()
{
//	ios::sync_with_stdio(false); cin.tie(0); cout.tie(0);
	int ans=0;
	cin >> str;
	
	for (int i=0; i<str.size(); i++)
	{
		c[str[i]]=i+1;
	}
	int n;
	cin >> n;
	for (int i=1; i<=n; i++) cin >> s[i];
	sort(s+1,s+1+n,cmp);
	int k;
	cin >> k;
	cout << s[k];
	
	
}
