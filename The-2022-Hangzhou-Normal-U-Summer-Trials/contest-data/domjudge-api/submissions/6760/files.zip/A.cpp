#include<bits/stdc++.h>
using namespace std;
void run()
{
	string str;
	cin>>str;
	int cnt=0;
	for(int i=0;i+3<str.size();i++)
	{
		if(str[i]=='h'&&str[i+1]=='z'&&str[i+2]=='n'&&str[i+3]=='u') cnt++;
	}
	cout<<cnt;
	
	
	return;
}
int main()
{
	int T=1;
//	cin>>T;
	while(T--)
	{
		run();
	}
	
	return 0;
}
