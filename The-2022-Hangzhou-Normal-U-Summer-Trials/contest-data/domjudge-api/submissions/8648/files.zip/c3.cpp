#include <bits/stdc++.h>

#define ll long long
#define PII pair<ll, int>
#define dbg(x) cerr << #x << " = " << x << endl;

using namespace std; 

const int N = 1e5 + 10;
const int INF = 0x3f3f3f3f;         // 1061109567
const ll INFF = 0x3f3f3f3f3f3f3f3f; // 4557430888798830399
const double esp = 1e-8, pi = acos(-1.0);
const int MOD = 998244353;

ll qmi(int a, int b)
{
    ll ret = 1 % MOD;
    while (b)
    {
        if (b & 1) ret = ret * (ll)a % MOD;

        a = a * (ll)a % MOD;
        b >>= 1;
    }
    
    return ret;
}

int gcd(int a, int b)
{
    return b ? gcd(b, a % b) : a;
}

int lowbit(int x)
{
    return x & -x;
}

/////////////////////////////////////////////////////////// 

int n;
string s;

void solve()
{
    int q;
    cin >> q;

    while (q -- )
    {
        int op;
        cin >> op;

        if (op == 1)
        {
            char x;
            cin >> x;
            s += x;
        }
        else if (op == 2)
        {
            auto it = s.end();
            it --;
            s.erase(it);
        }
        else
        {
            char x, y;
            cin >> x >> y;
            for (auto &c : s) if (c == x) c = y;
        }
    }

    if (s.empty()) cout << "The final string is empty" << endl;
    else cout << s << endl;
    
}

int main()
{
    ios::sync_with_stdio(0);

    int T = 1;
    //cin >> T;
    //scanf("%d", &T);
    //init();

    while (T--)
    {
        solve();
    }

    return 0;
}
