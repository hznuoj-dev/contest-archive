#include<bits/stdc++.h>
#define ll long long
const int inf=0x3f3f3f3f;
const int maxn=1e5+10;
using namespace std;
struct node{
	int l,r;
	ll lazy;
	int fix;
	bool f;
}tree[maxn<<2];
int s;
void build(int l,int r,int p)
{
	tree[p].l=l;
	tree[p].r=r;
	tree[p].lazy=1;
	tree[p].f=0;
	tree[p].fix=0;
	if(l==r)
	{
		return ;
	}
	int mid=(l+r)>>1;
	build(l,mid,p<<1);
	build(mid+1,r,p<<1|1); 
}
inline void push_down(int p)
{
	if(tree[p].lazy==1)
	return;
	tree[p<<1].lazy*=tree[p].lazy;
	tree[p<<1|1].lazy*=tree[p].lazy;
	tree[p].lazy=1;
}
void mul(int ul,int ur,int x,int p)
{
	int l=tree[p].l;
	int r=tree[p].r;
	if(ul<=l&&ur>=r&&!tree[p].f&&tree[p].fix==s)
	{
		tree[p].lazy*=x;
		tree[p].fix++;
		return;
	}
	if(l==r&&!tree[p].f)
	{
	tree[p].lazy*=x;
	tree[p].fix++;
	return;	
	}
	else if(l==r)
	{
		
		return;
	}
	int mid=(l+r)>>1;
	push_down(p);
	if(mid>=ul)
	mul(ul,ur,x,p<<1);
	if(mid+1<=ur)
	mul(ul,ur,x,p<<1|1);
	tree[p].fix=min(tree[p<<1].fix,tree[p<<1|1].fix);
}
bool flip(int pos,int p)
{
	int l=tree[p].l;
	int r=tree[p].r;
	if(l==pos&&r==pos)
	{
		if(tree[p].f==1)
		{
		tree[p].f=0;
		return 0;	
		}
		else
		{
		tree[p].f=1;
		return 1;	
		}
	}
	int mid=(l+r)>>1;
	if(mid>=pos)
	{
		flip(pos,p<<1);
	}
	else
	{
		flip(pos,p<<1|1);
	}
	if(!tree[p<<1].f&&!tree[p<<1|1].f)
	tree[p].f=0;
	return tree[p].f;
}
bool check(int ul,int ur,int x,int p)
{
	int l=tree[p].l;
	int r=tree[p].r;
	if(ul<=l&&ur>=r&&!tree[p].f&&tree[p].lazy!=1&&tree[p].fix==s)
	{
		if(tree[p].lazy%x==0)
		return 1;
		else
		return 0;
	}
	if(l==r)
	{
		if(tree[p].lazy%x==0)
		return 1;
		else
		return 0;
	}
	int mid=(l+r)>>1;
	push_down(p);
	bool ls=1,rs=1;
	if(mid>=ul)
	{
	ls=check(ul,ur,x,p<<1);	
	}
	if(mid+1<=ur)
	{
	rs=check(ul,ur,x,p<<1|1);	
	}
	if(rs&&ls)
	return 1;
	else
	return 0;
}
void div(int ul,int ur,int x,int p)
{
	int l=tree[p].l;
	int r=tree[p].r;
	if(ul<=l&&ur>=r&&!tree[p].f)
	{
		tree[p].lazy/=x;
		tree[p].fix++;
		return;
	}
	if(l==r)
	return;
	int mid=(l+r)>>1;
	push_down(p);
	if(mid>=ul)
	div(ul,ur,x,p<<1);
	if(mid+1<=ur)
	div(ul,ur,x,p<<1|1);
	tree[p].fix=min(tree[p<<1].fix,tree[p<<1|1].fix);
}
int main()
{
	ios::sync_with_stdio(false);
	cin.tie(0);
	int n,q;
	cin>>n>>q;
	build(1,n,1);
	for(int i=1;i<=q;i++)
	{
		string op;
		cin>>op;
		if(op=="flip")
		{
			int x;
			cin>>x;
			flip(x,1);
		}
		if(op=="div")
		{
		
			int ul,ur,x;
			cin>>ul>>ur>>x;
			if(check(ul,ur,x,1))
			{
				cout<<"YES\n";
				div(ul,ur,x,1);
				s++;
			}
			else
			cout<<"NO\n";
		}
		if(op=="mul")
		{
			int ul,ur,x;
			cin>>ul>>ur>>x;
			mul(ul,ur,x,1);
			s++;
		}
	}
	return 0;
} 
 
 
