#include<bits/stdc++.h>
using namespace std;
#define ll long long
const ll N=5e5+7;
ll a[N];
ll b[N];
int main()
{
	ll n;
	cin>>n;
	cin>>a[0];	
	for(ll i=1;i<n;i++)
	{
		cin>>a[i];
		b[i]=a[i]-a[i-1];
	}
	ll q;
	cin>>q;
	ll gg;
	ll temp=0;
	ll cnt=0;
	ll flag=0;
	ll ss=0;
	while(q--)
	{
		flag=0;
		cin>>gg;
		ll l=0;
		ss=0;
		temp=0;
		ll r=n;
		ll mid=(l+r)/2;
		
		while(1)
		{
			if(gg>b[n-1])
			{
				ss=1;
				break;
			}
			mid=(l+r)/2;
			if(mid==0)
			{
				break;
			}
			if(gg>b[mid])
			{
				l=mid+1;
			}
			else if(gg<b[mid])
			{
				if(gg>=b[mid-1])
				{
					temp=mid;
					cnt=a[mid-1]+gg-a[0];
					flag=1;
					break;
				}
				else
				r=mid-1;
			}
			else
			{
				temp=mid;
				cnt=a[mid-1]+gg-a[0];
				flag=1;
				break;
			}
		}
		if(ss==1)
		{
			cout<<a[n-1]+gg-a[0]<<endl;
		}
		else if(temp==0)
		{
			cout<<n*gg<<endl;
		}
		else if(!flag)
		{
			cout<<a[n-1]+gg-a[0]<<endl;
		}
		else
		{
			cout<<cnt+gg*(n-temp)<<endl;
		}
	}
	
}
