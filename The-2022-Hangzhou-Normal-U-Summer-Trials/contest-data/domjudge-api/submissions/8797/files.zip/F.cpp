#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> PLL;
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define debug(a) cout<<#a<<'='<<a<<endl;
#define fi first
#define se second
#define pb push_back
#define all(a) a.begin(),a.end()
ll n,k;
map<int,int>mp;
void solve(){
	cin>>n>>k;
	int ans=0;
//	n=1e5;
	vector<ll>a(n,1),b(n+1,0),c(n+1,0);
	rep(i,0,n)cin>>a[i];
	rep(i,0,n)b[i+1]=b[i]+a[i];
	ll tmp=k;
	rep(i,1,n+1){
		c[i]=b[i]%k;
		mp[c[i]]++;
//		debug(c[i]);
//		debug(mp[c[i]]);
	}
	rep(i,1,n+1){
		if(c[i]==0)ans+=mp[c[i]];
		else ans+=mp[c[i]]-1;
		mp[c[i]]--;
	}
	cout<<ans<<endl;
}

int main(){
	int _=1;
//	cin>>_;
	while(_--)solve();
	return 0;
}
