#include<bits/stdc++.h>

using namespace std;

const int N = 200005;

int n;
int f[1000006];
int vis[N];

int find(int x){
	return x==f[x]?x:f[x] = find(f[x]);
}

int main()
{
	char c,b;
	int now = 0,flag = 0;
	scanf("%d",&n);
	for(int i=1;i<=1000000;++i){
		f[i]=i;
	}
	for(int i=1;i<=n;++i){
		scanf("%d",&flag);
		if(flag == 1){
			cin>>c;
			int to = c-'a'+1+n;
			f[++now] = f[to+vis[to]*27];
		}else if(flag == 3){
			cin>>c;
			cin>>b;
			int u = c-'a'+1+n;
			int v = b-'a'+1+n;
			f[u+vis[u]*27] = f[v+vis[v]*27];
			vis[u]++;
		}else{
			now = max(now-1,0);
		}
	}
	
	for(int i=1;i<=now;++i){
		int to = find(i);
		int ans = to%27-1-n+'a';
		cout<<(char)ans;
	}
	
	if(now==0){
		printf("The final string is empty");
	}
	return 0;
}
