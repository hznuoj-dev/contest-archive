#include<bits/stdc++.h>
using namespace std;
long long a[100010];
int j[100010];
int main()
{
	long long n,k,ans=0;
	cin>>n>>k;
	for(int i=0;i<n;i++)
	{
		cin>>a[i];
	}
	long long l=0,r=0,p=0;
	long long cou=1;
	while(l<n)
	{
		if(!j[l]){
		long long sum=a[l];
			while(r<n)
			{
//				for(int i=p;i<=r;i++)
//				{
//					sum+=a[i];
//				}

				if(sum%k==0)
				{
					ans+=cou;
					cou++;
					j[p]=1;
					p=r+1;
					r=p;
					sum=a[p];
				}
				else
				{
					r++;
					sum+=a[r];
				}
			}
		}
		l++;
		r=l;
		p=l;
		cou=1;
	}
	cout<<ans;
}
