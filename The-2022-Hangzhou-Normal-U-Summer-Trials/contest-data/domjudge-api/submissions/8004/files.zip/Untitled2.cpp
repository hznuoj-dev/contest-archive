#include<bits/stdc++.h>

using namespace std;

#define INF 0x3f3f3f3f3f3f3f3f
#define io ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define PI acos(-1)
#define mem(a,b) memset((a),(b),sizeof(a));

typedef long long ll;
typedef unsigned long long ull;

string s;
int n,k;
int arr[27];
struct node {
	string ss;
	string sss;
	int nuber;
}stu[1010];
bool cmp(node a,node b) {
	return a.sss<b.sss; 
}
int main() {
	cin>>s;
	cin>>n;
	getchar();
	mem(arr,0);
	for(int i=0;i<s.length();i++) {
		arr[s[i]-97]=i;
	}
	for(int i=0;i<n;i++) {
		cin>>stu[i].ss;
		for(int j=0;j<stu[i].ss.length();j++) {
			char ch=arr[stu[i].ss[j]-97]+97;
			stu[i].sss.append(1,ch);
		}
	}
	cin>>k;
	sort(stu,stu+n,cmp);
	cout<<stu[k-1].ss;
	return 0;
} 
