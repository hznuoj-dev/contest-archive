#include <stdio.h>
#include <string.h>

int main()
{
	char str[100007], s[5] = {'h', 'z', 'n', 'u'};
	int l, cnt = 0; 
	
	scanf("%s", str);
	l = strlen(str);
	for (int i = 0; i < l; i++)
	{
		if (str[i] == 'h')
		{
			int j;
			
			for (j = 0; j < 4; j++)
			{
				if (str[i + j] != s[j])
				{
					break;
				}
			}
			if (j == 4)
			{
				cnt++;
			} 
		}
	}
	printf("%d", cnt);
	
	return 0;
} 
