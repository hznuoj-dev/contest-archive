#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+50;
const int maxn=1e9+10;
ll sum[N];
ll a[N];
ll b[N];
ll f(ll x){
	ll ans=1;
	for(ll i=1;i<=x;i++){
		ans*=i;
	}
	return ans;
}
int main(){
	ios::sync_with_stdio(false);
	ll n,k;
	cin>>n>>k;
	ll c=0;
	ll ans=0;
	for(ll i=1;i<=n;i++){
		cin>>a[i];
		if(i!=1&&a[i]%k==0)
			ans++;
		sum[i]=(sum[i-1]%k+a[i]%k)%k;
		if(sum[i]==0)
			c++;
		b[sum[i]]++;
	}
//	ans+=f(c)/f(c-2)/2;
//	ans+=c-2;
	ans+=c;
	for(ll i=1;i<n;i++){
		if(i!=1&&sum[i]==0&&a[i]==0)
			ans+=(c-1);
		if(sum[i]==0&&sum[i+1]!=0){
			c--;
			if(c!=0)
				ans+=c;
		}
		else if(sum[i]==0&&sum[i+1]==0){
			c--;
		}
	}
	for(int i=1;i<=n;i++){
		if(b[sum[i]]>=2&&sum[i]!=0){
			ans+=f(b[sum[i]])/f(b[sum[i]]-2)/2;
			b[sum[i]]=0;
		}
	}
	cout<<ans<<endl;
	return 0;
}

