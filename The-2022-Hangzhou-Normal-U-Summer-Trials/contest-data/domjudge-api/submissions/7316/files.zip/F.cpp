#include<bits/stdc++.h>
using namespace std;
#define ll long long
ll a[100100];
int main()
{
	int k,l,t,ma,n;
	int i,j,ans=0;
	scanf("%d %d",&n,&ma);
	for (i=1;i<=n;i++)
	{
		scanf("%d",&k);
		a[i]=a[i-1]+k;
	}
	for (i=1;i<=n;i++)
		for (j=i;j<=n;j++)
	{
		if ( (a[j]-a[i-1])%ma==0) ans++; 
	}
	cout<<ans;
}
