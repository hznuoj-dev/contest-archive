#include<bits/stdc++.h>

using namespace std;

#define INF 0x3f3f3f3f3f3f3f3f
#define MAX 1e18
#define io ios::sync_with_stdio(false);cin.tie(0);cout.tie(0);
#define PI acos(-1)
#define mem(a,b) memset((a),(b),sizeof(a));

typedef long long ll;
typedef unsigned long long ull;

ll n,arr[500100],q,t,brr[500100];
ll ans;
set<ll>mp;
int main() {
	io;
	cin>>n;
	for(int i=1;i<=n;i++) {
		cin>>arr[i];
	}
	brr[1]=0;
	for(int i=2;i<=n;i++) {
		brr[i]=arr[i]-arr[i-1];
	}
	cin>>q;
	while(q--) {
		cin>>t;
		ans=0;
		for(int i=2;i<=n;i++) {
			if(brr[i]>t) ans+=t;
			else ans+=brr[i];
		}
		ans+=t;
		cout<<ans<<'\n';
	}
	return 0;
}
