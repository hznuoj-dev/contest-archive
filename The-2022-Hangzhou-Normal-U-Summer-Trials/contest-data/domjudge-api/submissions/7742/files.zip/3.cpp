#include<bits/stdc++.h>
#define rep(i,j,k) for(int i=j;i<=k;i++)
#define int long long
#define ll long long
const int NUM = 5e5+20;
using namespace std;
signed main(){
	ios::sync_with_stdio(false),cin.tie(0),cout.tie(0);
	int n;cin>>n;
	vector<int> a(NUM,0);
	map<int,int> b;
	vector<int> sum(NUM,0);
	for(int i=0;i<=n-1;i++){
		cin>>a[i];
		b[a[i]]=1;
	}
	int m;
	cin>>m;
	rep(i,0,m-1){
		int tmp;
		cin>>tmp;
		for(int j=0;j<=n-1;j++){
			b[a[j]+tmp]--;
		}
		int max=0;
		for(int j=0;j<=a[n-1]+tmp-1;j++){
			if(b[j]!=0){
				sum[j]=sum[j-1]+b[j];
			}
			else{
                if(j-1>0) sum[j]=sum[j-1];
                else sum[j]=0;
				continue;
			}
		}
		
        for(int j=0;j<=a[n-1]+tmp-1;j++){
			if(sum[j]){
                max++;
            }
		}
		for(int j=0;j<=a[n-1]+tmp-1;j++){
			sum[j]=0;
		}
		for(int j=0;j<=n-1;j++){
			b[a[j]+tmp-1]++;
		}
		cout<<max<<endl;
	}
	
	
	return 0;
} 
/*

3
1 3 8
3
2
4
10

*/
