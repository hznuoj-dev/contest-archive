#include<bits/stdc++.h>
#define ll long long
#define ull unsigned long long
#define moonoom ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
const ll MAXN=1e5+10;
ull p[MAXN];
ull hsh[MAXN];
int pm[30];
int cmp(string a,string b){
	for(int i=0;i<min(a.length(),b.length());i++){
		if(a[i]!=b[i]){
			return pm[a[i]-'a'+1]<pm[b[i]-'a'+1];
		}
	}
}
string word[1100];
int main(){
	
	string ss;
	cin>>ss;
	for(int i=0;i<ss.length();i++){
		pm[ss[i]-'a'+1]=i;
	}
	int n;
	cin>>n;
	
	for(int i=1;i<=n;i++){
		getchar();
		cin>>word[i];
	}
	sort(word+1,word+1+n,cmp);
	int k;
	cin>>k;
	cout<<word[k]<<endl;
	
}
