#include<iostream>
#include<algorithm>
#include<string>
#include<cstring>
using namespace std;
int main(){
	string a;
	int s[27];
	cin>>a;
	for(int i=0;i<26;i++){
		s[a[i]-'a']=i;//��ĸ��order 
	}
	int n;
	cin>>n;
	string f[1003];
	string k[1003];
	for(int i=0;i<n;i++){
		cin>>k[i]; 
		for(int j=0;j<k[i].length();j++){
			f[i]+=(char)(s[k[i][j]-'a']+'a');
		}
	}
	int nn;
	cin>>nn;
	for(int i=0;i<n;i++){
		for (int j=n-1;j>i;j--){
			if (f[j]<f[j-1]){
				string kk=f[j];f[j]=f[j-1];f[j-1]=kk;
				kk=k[j];k[j]=k[j-1];k[j-1]=kk;
			}
		} 
	} 
	cout<<k[nn-1];
	return 0;
}
