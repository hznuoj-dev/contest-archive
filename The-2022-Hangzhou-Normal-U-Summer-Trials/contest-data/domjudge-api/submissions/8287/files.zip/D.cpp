#include<bits/stdc++.h>
using namespace std;
#define endl '\n'
#define ll long long
const int N= 1e5+10;

vector<int>e[N];
int cnt[N];
int dfs(int x,int fa){
	int ans=1;
//	cout << x << ' ' << fa << endl;
	for(auto c:e[x]){
		if(c==fa)continue;
		 ans+=dfs(c,x);
	}
	cnt[x]=ans;
	return ans;
}
//void dfs1(vector<int> &v,int x,int fa){
//	if(e[x].size()==1){
//		v.push_back(x);
//	}else {
//		for(auto c:e[x]){
//			if(c==fa)continue;
//			dfs1(v,c,x);
//		}
//	}
//}
void solve(){
	int n; cin >> n;
	for(int i=1;i<n;i++){
		int u,v; cin >> u >> v;
		e[u].push_back(v);
		e[v].push_back(u);
	}
	dfs(1,0);
	int q; cin >> q;
	while(q--){
		int x; cin >> x;
		if(e[x].size()==1){
			cout << n-1 << endl;
		}else {
			vector<int>v;
			ll ans = 0;
			for(auto c:e[x]){
				if(cnt[c]>cnt[x]){
					v.push_back(cnt[c]-cnt[x]);
				}else {
					v.push_back(cnt[c]);
				}
			}
			for(int i=0;i<(int)v.size();i++){
				ans+=v[i];
				for(int j=i+1;j<(int)v.size();j++){
					ans+=1ll*v[i]*v[j];
				}
			}
			cout << ans << endl;
			

//			vector<int>v;
//			for(auto c:e[x]){
//				dfs1(v,c,x);
//			}
//			ll ans=0;
//			for(auto c:v){
//				ans+=dfs(c,0);
//			}
//			cout << ans << endl;


//			vector<int>v;
//			ll ans=0;
//			for(auto c:e[x]){
//				v.push_back(dfs(c,x));
//				ans+=v[(int)v.size()-1];
//			}
//			for(int i=0;i<(int)v.size();i++){
//				for(int j=i+1;j<(int)v.size();j++){
//					ans+=1ll*v[i]*v[j];
//				}
//			}
//			cout << ans << endl;
		}
	}
	
}
/*


*/
int main(){
	int T=1;
//	cin >> T;
	while(T--) solve();
	return 0;
}
