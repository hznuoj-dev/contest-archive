#include <bits/stdc++.h>
using namespace std;
string s,b[1010];
map <char,int> a;
int i,n,k;
int cmp(string l,string r){
	for (int i = 0; i <= min(l.size(),r.size()); i++)
		if (a[l[i]] < a[r[i]]) return 1;
	else if (a[l[i]] > a[r[i]]) return 0;
	if (l.size() < r.size()) return 1;
	else if (l.size() > r.size()) return 0;
	return 0;
}
int main ()
{
	cin >> s;
	for (int i = 0; i < s.size(); i++)
			a[s[i]]=i+1;
	cin >> n;
	for (int i = 1; i <= n; i++)	
		cin >> b[i];
	sort(b+1,b+n+1,cmp);
	cin >> k;
	cout << b[k];
}
