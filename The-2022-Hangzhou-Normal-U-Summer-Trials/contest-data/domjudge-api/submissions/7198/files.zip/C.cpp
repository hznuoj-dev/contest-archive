#include<bits/stdc++.h>

using namespace std;
const int N=5e5+7;
typedef long long ll;

int ans, n, q, t, k, a[N];
vector<int> b;
string s;
void solve() {
	cin >> n;
	a[0]=0;
	for(int i=1;i<=n;i++) cin >> a[i];
	for(int i=1;i<=n;i++) b.push_back(a[i]-a[i-1]);
	cin >> q;
	while(q--) {
		cin >> t;
		if(t==1) {
			cout << n << endl; continue;
		}
		int cnt = lower_bound(b.begin(), b.end(), t) - b.begin();
		//cout << cnt << "##" << endl;
		ll ans = (n-cnt+1)*t+a[cnt]-a[1];
		cout << ans << endl;
	}
}

int main(){
	ios :: sync_with_stdio(false); cin.tie(0); cout.tie(0); 
	int T=1;
	//cin >> T;
	while(T--)
		solve();
}
