#include<bits/stdc++.h>
#define ll long long
const int inf=0x3f3f3f3f;
const int maxn=1e5+10;
using namespace std;
char rule[500];
char back[500];
bool cmp(char a,char b)
{
	return rule[a]-rule[b];
}
string ch[2000];
int main()
{
//	ios::sync_with_stdio(false);
//	cin.tie(0);
	string a;
	cin>>a;
	for(int i=0;i<a.size();i++)
	{
	rule[a[i]]=i+'a';
	back[i+'a']=a[i];	
	}
	int n;
	cin>>n;
	for(int i=1;i<=n;i++)
	{
	cin>>ch[i];
	for(int j=0;j<ch[i].size();j++)
	ch[i][j]=rule[ch[i][j]];	
	}
	sort(ch+1,ch+n+1);
	int k;
	cin>>k;
	for(int i=0;i<ch[k].size();i++)
	{
		cout<<back[ch[k][i]];
	}
	return 0;
} 
 
 
