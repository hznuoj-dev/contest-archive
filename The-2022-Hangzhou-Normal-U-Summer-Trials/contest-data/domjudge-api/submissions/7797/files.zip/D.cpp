#include<bits/stdc++.h>
#define int long long
using namespace std;
int n,a[100005],q;
vector <char> ans;
map <char,char> mp;
char b[100005],c[100005];
char find(char k){
	if (mp[k]==k) return k;
	return mp[k]=find(mp[k]);
}
signed main(){
	cin >> q;
	for (int i=1;i<=q;++i) {
		cin >> a[i];
		if (a[i]==1) {
			cin >> b[i];ans.push_back(b[i]);
		}
		if (a[i]==2) {
			if (ans.size()!=0) ans.pop_back();
			else a[i]=4;
		}
		if (a[i]==3) cin >> b[i] >> c[i];
	}
	for (char i='a';i<='z';++i) mp[i]=i;
	ans.clear();
	
	for (int i=q;i;--i) {
		//cout << "a[" << i << "]=" << a[i] << endl;
		if (a[i]==3) mp[find(b[i])]=find(c[i]);
		if (a[i]==1) ans.push_back(find(b[i]));
		if (a[i]==2) ans.pop_back();
	}
	if (ans.size()==0) {
		cout << "The final string is empty";return 0;
	}
	for (int i=ans.size()-1;i>=0;--i) {
		cout << ans[i];
	}
	
}
