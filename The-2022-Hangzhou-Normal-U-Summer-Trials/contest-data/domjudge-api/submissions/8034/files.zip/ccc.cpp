#include<bits/stdc++.h>
using namespace std;
long long a[100010]={0},d[100010]={0};
int main(){
	int n;
	cin>>n;
	for(int i=0;i<n;i++){
		cin>>a[i];
		if(i>0)
			d[i]=a[i]-a[i-1];//1 �� n-1 
	}
	int q;
	long long t,x;
	cin>>q;
	while(q--)
	{
		int flag=-1;
		cin>>t;
		x=t-a[0];
		if(x>=d[n-1]-1)
		{
			cout<<a[n-1]+x<<endl;
			continue;
		}
		else
		{
			for(int i=1;i<n;i++){
				if(x<=d[i]-1){
					flag=i; 
					break;
				}
			}
			long long num=0;
			cout<<a[flag-1]-a[0]+(n-flag+1)*(x+1)<<endl;
		}
	}
}
