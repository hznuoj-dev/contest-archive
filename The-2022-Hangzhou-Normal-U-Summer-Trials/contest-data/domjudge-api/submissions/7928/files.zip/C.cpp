#include <bits/stdc++.h>
#define endl '\n'
#define IOS ios::sync_with_stdio(0)
using namespace std;
typedef long long ll;
const int N = 5e5 + 10;
int n, q;
ll t;
ll a[N];


int main()
{
	//IOS; cin.tie(0), cout.tie(0);
	scanf("%d", &n);
	for (int i = 1; i <= n; ++i)
	{
		scanf("%lld", &a[i]);
	}

	sort(a + 1, a + 1 + n);

	scanf("%d", &q);
	while (q--)
	{
		scanf("%lld", &t);
		ll sum = a[n] + t - 1;	//����ܵ���
		sum = sum - a[1] + 1;	//�������м�����
		ll cha = 0;
		for (int i = n - 1; i >= 1; --i)
		{
			if (a[i] + t >= a[i + 1])
				continue;
			else
				cha += a[i + 1] - (a[i] + t - 1) - 1;
		}
		ll ans = sum - cha;
		//cout << "cha: " << cha << endl;
		cout << ans << endl;
	}

	return 0;
}
