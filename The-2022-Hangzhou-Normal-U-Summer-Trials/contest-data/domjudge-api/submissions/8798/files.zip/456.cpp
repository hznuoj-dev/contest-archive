#include<bits/stdc++.h>
#define int long long
#define endl "\n"
#define xiayang cout<<"��Ӳ"<<endl;
#define FAST std::ios::sync_with_stdio(false);cin.tie(NULL);cout.tie(NULL);
using namespace std;
struct node{
	long double x,y;
}nod[3010];
long double v0,v1,v2,v3,v4;
int st,ed;
int n;
double mp[3010][3010];
signed main(){
	cin>>n;
	cin>>v1>>v2>>v3>>v4>>v0;	
	cin>>st>>ed;
	for(int i=1;i<=n;i++)cin>>nod[i].x>>nod[i].y;
	for(int i=1;i<=n;i++){
		for(int j=i+1;j<=n;j++){
			long double len=sqrt((nod[j].y-nod[i].y)*(nod[j].y-nod[i].y)+(nod[j].x-nod[i].x)*(nod[j].x-nod[i].x));
			if(nod[i].x>=1&&nod[j].x>=1){
				if(nod[i].y>=1&&nod[j].y>=1){
					mp[i][j]=mp[j][i]=len/v1;
				}
				else if(nod[i].y<=-1&&nod[j].y<=-1){
					mp[i][j]=mp[j][i]=len/v4;
				}
				else mp[i][j]=mp[j][i]=len/v0;
			}
			else if(nod[i].x<=-1&&nod[j].x<=-1){
				if(nod[i].y>=1&&nod[j].y>=1){
					mp[i][j]=mp[j][i]=len/v2;
				}
				else if(nod[i].y<=-1&&nod[j].y<=-1){
					mp[i][j]=mp[j][i]=len/v3;
				}
				else mp[i][j]=mp[j][i]=len/v0;
			}
			else mp[i][j]=mp[j][i]=len/v0;
		}
	}
	for(int i=1;i<=n;i++){
		for(int j=1;j<=n;j++){
			if(mp[st][i]+mp[i][j]<mp[st][j])mp[st][j]=mp[st][i]+mp[i][j];
		}
	} 
	printf("%0.10lf",mp[st][ed]);
}
