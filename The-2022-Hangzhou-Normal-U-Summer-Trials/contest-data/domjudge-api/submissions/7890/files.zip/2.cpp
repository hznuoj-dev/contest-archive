#include<bits/stdc++.h>

using namespace std;
#define ll long long
ll a[100005];
ll sum[100005];

bool com(ll a,ll b){
	return a<b;
}

int main()
{
	int n,k;
	scanf("%d%d",&n,&k);
	for(int i=1;i<=n;++i){
		scanf("%lld",&a[i]);
		sum[i] = sum[i-1]+a[i];
	}
	for(int i=1;i<=n;++i){
		sum[i] = sum[i]%k;
	}
	long long ans = 0;
	sort(sum+1,sum+1+n,com);
	long long pre = -1;
	long long flag = 0;
	long long flag0 = 0;
	sum[n+1] = -1;
	for(int i=1;i<=n+1;++i){
		if(sum[i] == 0){
			flag0++;
		}
		if(sum[i]!=pre){
			pre = sum[i];
			ans += flag*(flag-1)/2;
			flag = 1;
		}else{
			flag++;
		}
	}
	ans += flag0;
	printf("%lld",ans);
	return 0;
}
