#include <bits/stdc++.h>
using namespace std;
long long a[500005],num[500005],num1[500005]={0};
int main(){
    int n;
    scanf("%d",&n);
    for(int i=0;i<n;i++){
        scanf("%lld",&a[i]);
        if(i!=0){
            num[i]=a[i]-a[i-1];
        }
    }
    sort(num+1,num+n);
    num1[1]=num[1];
    for(int i=2;i<n;i++){
        num1[i]=num[i]+num1[i-1];
    }
    int k,q,mid;
    scanf("%d",&q);
    for(int a=0;a<q;a++){
        mid=lower_bound(num+1,num+n,k)-num;
        scanf("%d",&k);

        printf("%lld\n",num1[mid]+(n-mid)*k);
    }

    return 0;
}