#include <bits/stdc++.h>
#include <iostream>
#include <string>
#include <cmath>
using namespace std;
int a[200]={0};
int cmp(string s1,string s2){
	int minl=min(s1.length(),s2.length());
	for(int i=0;i<minl;i++){
		if(a[s1[i]]<a[s2[i]]) return 1;
		else if(a[s1[i]]>a[s2[i]]) return 0;
	}
	if(s1.length()<=s2.length()) return 1;
	else return 0;
}
int main(){
	string s1;
	getline(cin,s1);
	//cout<<s1<<endl;
	for(int i=0;i<s1.length();i++){
		a[s1[i]]=i;
	}
	int t;
	cin>>t;
	//cout<<t<<endl;
	getchar();
	string s[1005];
	for(int i=0;i<t;i++){
		getline(cin,s[i]);
	}
	sort(s,s+t,cmp);	
	int k;
	cin>>k;
	//cout<<k<<endl;
	cout<<s[k-1];
} 
