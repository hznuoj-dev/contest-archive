#include <bits/stdc++.h>

using namespace std;
typedef long long ll;

const int N = 1e5 + 7;

void solve() {
	string s;
	string t = "hznu";
	cin >> s;
	int ans = 0;
	for (int i = 0; i < s.size(); ++i) {
		int j;
		for (j = 0; j < 4; ++j) {
			if (s[i + j] != t[j]) break;
		}
		if (j == 4) ans++;
	}
	cout << ans;
}
int main() {
	ios::sync_with_stdio(0);
	int T = 1;
	//cin >> T;
	while (T--) solve();
	return 0;
}
