#include<bits/stdc++.h>

#define debug(x) cerr << #x << " = " << x << '\n'

using namespace std;

void solve() {
	string s;
	cin >> s, s = " " + s; 
	string t = "hznu";
	int ans = 0;
	for (int i = 1; i <= (int)s.size() - 1; ++i) {
		if (i + 3 <= (int)s.size() - 1 && s[i] == 'h' && s[i + 1] && 'z' && s[i + 2] == 'n' && s[i + 3] == 'u') ans++;
	}
	cout << ans << '\n';
}

int main() {
	ios::sync_with_stdio(false);cin.tie(nullptr);cout.tie(nullptr); 
	int t = 1;
//	cin >> t;
	while (t--) {
		solve();
	}
	return 0;
} 
