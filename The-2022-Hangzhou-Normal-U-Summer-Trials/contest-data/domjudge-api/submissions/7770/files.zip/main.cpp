#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

ll n, s, m;
ll a[maxn];
ll f[maxn];
ll jc[maxn];

ll qpow(ll x, ll p){
    ll r = 1;
    while(p > 0){
        if(p & 1) r = r * x % mode;
        x = x * x % mode;
        p /= 2;
    }
    return r;
}

ll C(ll n, ll m){
    return jc[n] * qpow(jc[m] * jc[n-m] % mode, mode - 2) % mode;
}

void solve(){
    cin >> n >> s >> m;
    ll sum = 0;
    for(ll i=1;i<=n;i++) cin >> a[i], sum += a[i];
    jc[0] = 1;
    for(ll i=1;i<=n+s+2;i++) jc[i] = jc[i-1] * i % mode;
    for(ll i=0;i<=s;i++){
        f[i] = C(i+n-1, n-1);
    }
    for(ll i=1;i<=n+s+2;i++) f[i] += f[i-1];

    for(ll i=1;i<=m;i++){
        ll x, t; cin >> x >> t;
        sum -= a[x]; a[x] = t;
        sum += t;
        if(sum > s) cout << "0\n";
        else cout << f[s - sum] << '\n';
    }

}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}