#include<bits/stdc++.h>
using namespace std;

string p[1010];
map<char, int> m;

bool cmp(string x, string y)
{
    for(int i = 0;i < min(x.size(), y.size());i++)
    {
        if(m[x[i]] < m[y[i]])
            return true;
    }
    if(x.size() < y.size())
        return true;
    else
        return false;
}

int main()
{
    string s;
    int n, k;
    cin >> s;
    for(int i = 1;i <= s.size();i++)
    {
        m[s[i]] = i;
    }
    cin >> n;
    for(int i = 1;i <= n;i++)
    {
        cin >> p[i];
    }
    cin >> k;
    sort(p + 1, p + n + 1, cmp);
    cout << p[k];
    return 0;
}