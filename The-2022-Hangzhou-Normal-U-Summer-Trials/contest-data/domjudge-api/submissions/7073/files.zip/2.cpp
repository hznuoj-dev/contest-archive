#include<iostream>
using namespace std;
const int N=1e3+10;
char s[N][N];
int a[N]={0};
int main()
{
    scanf("%s",s[0]);
    int n;
    cin>>n;
    for(int i=1;i<=n;i++) scanf("%s",s[i]);
    int k;
    cin>>k;
    for(int i=1;i<=n;i++)
    {
        for(int j=i+1;j<=n;j++)
        {
            int t=0;
            for(;s[i][t]!='\0'&&s[j][t]!='\0';t++)
            {
                if(s[i][t]==s[j][t]) continue;
                else break;
            }
            int x1=0,x2=0;
            if(s[i][t]=='\0') {a[j]++;continue;}
            else if(s[j][t]=='\0') {a[i]++;continue;}
            for(int x=0;x<26;x++)
            {
                if(s[i][t]==s[0][x])  x1=x;
                if(s[j][t]==s[0][x]) x2=x;
            }
            if(x1<x2) a[j]++;
            else a[i]++;
        }
    }
    for(int i=1;i<=n;i++)
    {
        if(a[i]==k-1) {printf("%s\n",s[i]);break;}
    }
    return 0;
}