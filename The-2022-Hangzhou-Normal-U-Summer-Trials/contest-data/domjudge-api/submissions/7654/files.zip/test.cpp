#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=5e5+10;
const int mod=1e9+7;
int n,q,k;
ll t;
ll a[maxn],sub[maxn],sum[maxn];
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cout.tie(0);
    cin>>n;
    ll maxx=0;
    for(int i=1;i<=n;i++)  
    {
        cin>>a[i];
        if(i>1)  
        {
            sub[i-1]=a[i]-a[i-1];
            maxx=max(maxx,sub[i-1]);
        }
    }
    for(int i=1;i<=n-1;i++)
    {
        if(i==1)  sum[i]=sub[i];
        else  sum[i]=sum[i-1]+sub[i];
    }
    cin>>q;
    while(q--)
    {
        cin>>t;
        if(t>=maxx)
        {
            cout<<a[n]+t-1<<"\n";
            continue;
        }
        ll ans=0;
        ll pos=upper_bound(sub+1,sub+1+n-1,t)-sub;
        // cout<<"pos="<<pos<<endl;
        // if(sub[pos]==t) pos++;
        // cout<<"pos="<<pos<<endl;
        ans=a[pos]+t-1+t*(n-1-pos+1);
        cout<<ans<<"\n";
    }
    return 0;
}










