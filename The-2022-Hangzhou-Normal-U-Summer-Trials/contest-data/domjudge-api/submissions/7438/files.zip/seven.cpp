#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;
int s1[500]={0};
int cmp(string x,string y){
	int t,p=0;
		if(x.length()<y.length()){
			return 2;
		}
		else
		if(x.length()>y.length())
		{
			return 1;
		}
	t=min(x.length(),y.length());
	for(int i=0;i<t;i++){
		if(s1[x[i]]<s1[y[i]]){
			p=1;
			break;
		}
		else
		if(s1[x[i]]>s1[y[i]])
		{
			p=2;
			break;
		}
		
	}
	if(p==1){

		if(x.length()==y.length()) 
		{
			return 2;
		}
	}
	else
	if(p==2)
	{
		if(x.length()==y.length()) 
		{
			return 1;
		}
	}
}
int main()
{
	int tt;
	cin>>tt;
	while(tt--)
	{
		
	string s,a[1009];
	cin>>s;
	for(int i=0;i<26;i++){
		s1[s[i]]=i+1;
	}
	int n,k;
	scanf("%d",&n);
	getchar();
	for(int i=0;i<n;i++){
		getline(cin,a[i]);
	} 
	scanf("%d",&k);
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(cmp(a[i],a[j])==2)
			{
				string to;
				to=a[i];
				a[i]=a[j];
				a[j]=to;
			}
		}
	}
	cout<<a[k-1];
}
	return 0;
 } 
