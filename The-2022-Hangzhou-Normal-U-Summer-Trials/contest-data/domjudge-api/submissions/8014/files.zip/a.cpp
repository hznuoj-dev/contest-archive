#include<bits/stdc++.h>
#define int long long
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
const int N = 2e5 + 10;
int a[N], b[N];
string ss;
string s[N];
int dp[N];
vector<int> v[N];
typedef pair<int,int> PII;
typedef long long ll;
const int mod = 998244353;
int n, m;
map<char, int> mp;
int gcd(int a,int b) {return b? gcd(b,a%b):a;}
bool cmp(string &s1 ,string &s2)
{
    if (s1.size() != s2.size())
    {
        return s1.size() < s2.size();
    }
    else
    {
        for(int i = 0; i < s1.size(); i ++)
        {
            if (s1[i] != s2[i])
            {
                return mp[s1[i]] < mp[s2[i]];
            }
        }
    }
    return s1 < s2;
}
void solve()
{
    cin >> ss;
    for(int i = 0; i < 26; i ++ )
    {
        mp[ss[i]] = i;
    }
    cin >> n;
    for(int i = 1; i <= n; i ++ )
    {
        cin >> s[i];
    }
    sort(s + 1, s + n + 1, cmp);
    int k;
    cin >> k;
    cout << s[k] << endl;

}
signed main()
{
    solve();
}
/*
7
qst
qrt
qrs
abce
axy
hxy
abcd
*/