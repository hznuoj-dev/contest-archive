#include<bits/stdc++.h>
using namespace std;
#define ll long long
#define pb push_back
struct op{
	int a;
	char b;
	char c;
}cz[100100];
char zm[30];
char ans[100100];
int main()
{
	int n,m,i,j,k,len=0,pd=0;
	cin>>n;
	for (i=0;i<26;i++)
		zm[i]='a'+i;
	for (i=1;i<=n;i++)
	{
		cin>>cz[i].a;
		if (cz[i].a == 3) cin>>cz[i].b>>cz[i].c;
		if (cz[i].a == 1) cin>>cz[i].b;
	}
	for (i=n;i>=1;i--)
	{
		if (cz[i].a==2) len--; else 
		if (cz[i].a==1)
		{
			if (len<=0) len++;
			if (len>0) 
			{pd++; ans[pd]=zm[cz[i].b-'a']; }
		}
		else 
		{
			zm[cz[i].b-'a']=zm[cz[i].c-'a'];
		}
	}
	if (pd<=0) cout<<"The final string is empty"; else 
	for (i=pd;i>=1;i--)
	{
		cout<<ans[i];
	}
}
