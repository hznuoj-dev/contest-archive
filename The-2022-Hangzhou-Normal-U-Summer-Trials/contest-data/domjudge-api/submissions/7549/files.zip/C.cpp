#include<bits/stdc++.h>

using namespace std;

typedef long long ll;
typedef pair<ll,ll> PLL;
#define rep(a,b,c) for(int a=b;a<c;a++)
#define per(a,b,c) for(int a=c-1;a>=b;a--)
#define debug(a) cout<<#a<<'='<<a<<endl;
#define fi first
#define se second
#define pb push_back
#define all(a) a.begin(),a.end()
ll n,q,t;
int a[500500],b[500500];

void solve(){
	cin>>n;
	rep(i,0,n)scanf("%d",&a[i]);
	rep(i,1,n)b[i]=a[i]-a[i-1];
	cin>>q;
	rep(i,0,q){
		cin>>t;
		if(n==1){
			printf("%lld\n",t);
			continue;
		}
		if(t<=b[1]){
			printf("%lld\n",n*t);
		}
		else if(t>=b[n-1]){
			printf("%lld\n",a[n-1]-a[0]+t);
		}
		else{
			int pos=upper_bound(b+1,b+n-1,t)-b-1;
			printf("%lld\n",a[pos]-a[0]+t+(n-pos-1)*t);
		}
	}
	
}

int main(){
	int _=1;
//	cin>>_;
	while(_--)solve();
	return 0;
}
