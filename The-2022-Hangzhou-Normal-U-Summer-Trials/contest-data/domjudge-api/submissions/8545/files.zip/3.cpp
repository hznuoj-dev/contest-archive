#include<bits/stdc++.h>
using namespace std;
long long a[500010];
long long b[500010];
long long c[500010]={0};
long long d[500010];
int main()
{
    int n;
    cin>>n;
    for(int i=1;i<=n;i++){
        cin>>a[i];
        d[i]=a[i];
    }
    int q;
    long long t;
    cin>>q;
    while(q--){
        cin>>t;
        memset(c,0,sizeof(c));
        b[1]=a[1]+t-1;
        long long sum=b[1]-a[1]+1;
        int k=1;
        c[k]=sum;
        k++;
        for(int i=2;i<=n;i++){
            b[i]=a[i]+t-1;
            if(a[i]<=b[i-1]){
                a[i]=a[i-1];
                k--;
                c[k]=b[i]-a[i]+1;
                k++;
            }else{
                c[k]=b[i]-a[i]+1;
                k++;
            }
        }
        long long ans=0;
        for(int i=1;i<=k;i++){
            ans+=c[i];
        }
        cout<<ans<<endl;
        for(int i=1;i<=n;i++){
            a[i]=d[i];
        }
    }
    return 0;
}