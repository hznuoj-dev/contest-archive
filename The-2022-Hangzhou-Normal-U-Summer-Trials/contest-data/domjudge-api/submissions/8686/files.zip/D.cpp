#include <bits/stdc++.h>

using namespace std;

typedef long long LL;
const int N = 1e5 + 10;

int n, k, a[N];
LL pre[N], ans[N];

unordered_map<int, int> mp;

int main()
{
    ios::sync_with_stdio(false), cin.tie(0), cout.tie(0);
    cin >> n >> k;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        a[i] = a[i] % k;
    }
    for (int i = 1; i <= n; i++)
    {
        pre[i] = (pre[i - 1] + a[i]) % k; //前缀和处理
    }
    for (int i = 1; i <= n; i++)
    {
        if (pre[i] == 0)
            ans[i]++;
        ans[i] += mp[pre[i]];
        mp[pre[i]]++;
    }
    LL sum = 0;
    for (int i = 1; i <= n; i++)
        sum += ans[i];
    cout << sum;

    return 0;
}