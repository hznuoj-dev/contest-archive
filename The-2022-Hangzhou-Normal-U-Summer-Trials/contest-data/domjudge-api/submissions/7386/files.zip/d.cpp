#include <cmath>
#include <cstdio>
#include <iostream>
#include <algorithm>
#include <cstring>
#include <queue>
#include <map>
#include <iomanip>
#include <vector>
#include <string>
#include <set>
#include <sstream>
#include <stack>
#include <deque>
#include <unordered_map>
#include <unordered_set>
#pragma warning(disable:4996)
using namespace std;
#define endl '\n'
#define ll long long
#define io_speed_up ios::sync_with_stdio(false);cin.tie(0);cout.tie(0)
map<char, int>base;
const int maxn = 1e6 + 5;
vector<int>tree[maxn];
ll siz[maxn];
ll dp[maxn];
void dfs(int now, int fa){
	siz[now] = 1;
	dp[now] = 1;
	int temp = 0;
	for(auto x : tree[now]){
		if(x == fa)continue;
		dfs(x, now);
		dp[now] = dp[now] + temp * (siz[x]);
		siz[now] += siz[x];
		temp += siz[x];
	}
}
int main(){
	io_speed_up;
	int n;
	cin >> n;
	for(int i = 1;i <n;i++){
		int x, y;
		cin >> x >> y;
		tree[x].push_back(y);
		tree[y].push_back(x);
	}
	dfs(1, 0);
	int q;
	cin >> q;
	while(q--){
		int x;
		cin >>x;
		cout << dp[x] + (siz[x] - 1) * (n - siz[x]) + n - 2 << endl;
	}
}
