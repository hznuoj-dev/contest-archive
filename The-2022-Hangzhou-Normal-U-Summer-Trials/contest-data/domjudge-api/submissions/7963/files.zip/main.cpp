#include <bits/stdc++.h>
using namespace std;
#define ll long long
const signed INF = 1e9;
const signed maxn = 1000019;
const signed mode = 1e9 + 7;

int n;

struct node{
    int opt;
    char a, b;
}q[maxn];

int s[190];

void solve(){
    cin >> n;
    for(int i=1;i<=n;i++){
        cin >> q[i].opt;
        if(q[i].opt == 1) cin >> q[i].a;
        if(q[i].opt == 3) cin >> q[i].a >> q[i].b;
    }
    string ans;
    int del = 0;
    for(int i='a';i<='z';i++) s[i] = i;

    for(int i=n;i>=1;i--){
        if(q[i].opt == 1){
            if(del) del--;
            else ans.push_back(s[q[i].a]);
        }else if(q[i].opt == 2){
            del++;
        }else{
            s[q[i].a] = s[q[i].b];
        }
    }
    reverse(ans.begin(), ans.end());
    if(ans.empty()) cout << "The final string is empty\n";
    else cout << ans << '\n';
}

signed main() {
#ifdef LOCAL
    freopen("x.in", "r", stdin);
#endif
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    cout.tie(nullptr);

    signed T = 1;
//    cin >> T;
    while(T--) solve();
    return 0;
}