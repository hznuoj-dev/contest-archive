#include<bits/stdc++.h>
using namespace std;
#define LL long long
const int N = 5e5 + 7;

LL n, q;
LL a[N], t, b[N];

int main(){
    ios::sync_with_stdio(false);
    cin.tie(0), cout.tie(0);
    cin >> n;
    for(int i = 0; i < n; i++){
        cin >> a[i];
        if(i != 0)b[i - 1] = a[i] - a[i - 1];
    }
    b[n - 1] = 0x3f3f3f3f3f3f3f3f3f3f3f3f3f;
    cin >> q;
    for(int i = 1; i <= q; i++){
        LL sum = 0;
        cin >> t;
        LL pos = upper_bound(b, b + n, t) - b;
        sum = a[pos] - 1;
        sum += 1ll * (n - pos) * t;
        cout << sum << '\n'; 
    }
}