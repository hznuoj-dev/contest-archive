#include<bits/stdc++.h>
using namespace std;
#define ll long long
	char re[30];
bool cmp(string a,string b)
{
	int cnta=0;
	int cntb=0;
	for(int i=0;i<a.size();i++)
	{
		for(int j=0;j<26;j++)
		{
			if(re[j]==a[i])
			cnta=j;
			if(re[j]==b[i])
			cntb=j;
		}
		if(cnta>cntb)
		return a>b;
		else if(cnta<cntb)
		return a<b;
	}
	
}
int main()
{

	string s[100];
	cin>>re;
	int n;
	cin>>n;
	for(int i=0;i<n;i++)
	{
		cin>>s[i];
	}
	sort(s,s+n,cmp);
	int k;
	cin>>k;
	for(int i=0;i<k;i++)
	{
		cout<<s[k]<<endl;
	}
}
