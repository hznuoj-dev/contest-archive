a = []
cha = []
n = eval(input())
a.append(0)
s = input()
for i in map(int, s.split(' ')):
    a.append(i)
cha.append(0)
cha.append(0)
maxn = 0
for i in range(2, n + 1):
    cha.append(a[i] - a[i - 1])
    maxn = max(maxn, cha[i])

k = eval(input())
ans = 0
while k > 0:
    ans = 0
    t = eval(input())
    l = 1
    r = n
    mid = (l + r) >> 1
    while l <= r:
        mid = (l + r) >> 1
        if cha[mid] < min(t, maxn):
            l = mid + 1
        elif cha[mid] > min(t, maxn):
            r = mid - 1
        else:
            l = mid
            break
    if l != n:
        while cha[l] == cha[l + 1]:
            if l == n - 1:
                l += 1
                break
            l += 1
    if cha[l] > min(t, maxn) and l != 0:
        l -= 1
    if l != 0:
        ans += a[l] - 1
    ans += (n - l + 1) * t
    print(ans)
    k -= 1
