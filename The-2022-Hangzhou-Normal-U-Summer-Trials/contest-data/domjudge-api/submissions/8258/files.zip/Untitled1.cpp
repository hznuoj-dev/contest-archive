#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll N = 2e5 + 7;
const ll mod = 1e9 + 7;
ll n, s, q, a[N], mul, sum, ans;

ll qpow(ll a, ll b){
	ll ans = 1;
	while (b){
		if (b % 2) ans = ans * a % mod;
		a = a * a % mod;
		b /= 2;
	}
	return ans;
}

int main(){
	cin >> n >> s >> q;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
		sum += a[i];
	}
	while (q--){
		ll idx, nw;
		cin >> idx >> nw;
		sum = sum - a[idx] + nw;
		a[idx] = nw;
		if (sum == s)ans = 1;
		else if (sum > s)ans = 0;
		else ans = qpow(n, s - sum) + 1;
		cout << ans << endl;
	}
} 
