#include<bits/stdc++.h>
using namespace std;
const int flg[4][2]={{1,0},{0,1},{-1,0},{0,-1}};
int main(){
	ios::sync_with_stdio(false);
	cin.tie(nullptr);cout.tie(nullptr);
	
	int n;cin>>n;
	vector mp(n,vector<char>(n));
	pair<int,int> S,T; 
	for(int i=0;i<n;i++){
		string s;cin>>s;
		for(int j=0;j<n;j++){
			if(s[j]=='a'){
				S={i,j};
			}
			if(s[j]=='b'){
				T={i,j};
			}
			if(s[j]=='*') mp[i][j]='*';
			else mp[i][j]='.';
		}
	}
	vector dst(n,vector(n,vector(n,vector<int>(n,-1))));
	auto BFS=[&](){
		queue<tuple<int,int,int,int>> q;
		q.emplace(S.first,S.second,T.first,T.second);dst[S.first][S.second][T.first][T.second]=0;
		while(!q.empty()){
			auto [sx,sy,tx,ty]=q.front();q.pop();
			auto check=[&](int x,int y)->bool{
				if(x<0||x>=n||y<0||y>=n) return 0;
				return mp[x][y]=='.';
			};
			for(int i=0;i<4;i++){
				int _sx=sx+flg[i][0],_sy=sy+flg[i][1],_tx=tx+flg[i][0],_ty=ty+flg[i][1];
				if(!check(_sx,_sy)){
					_sx=sx;_sy=sy;
				}
				if(!check(_tx,_ty)){
					_tx=tx;_ty=ty;
				}
				if(dst[_sx][_sy][_tx][_ty]!=-1) continue;
				dst[_sx][_sy][_tx][_ty]=dst[sx][sy][tx][ty]+1;
				q.emplace(_sx,_sy,_tx,_ty);
			}
		}
	};
	BFS();
	int ans=1e9;
	for(int i=0;i<n;i++)
	for(int j=0;j<n;j++)
	if(dst[i][j][i][j]!=-1) ans=min(ans,dst[i][j][i][j]);
	if(ans==1e9) cout<<"no solution\n";
	else cout<<ans<<"\n";
	return 0;
}