#include<iostream>
#include<algorithm>
#include<string>

using namespace std;

int a[26];

struct Node{
	string c;
	int num;
}node[1007];

int gcd(Node A,Node B)
{
	return A.num<B.num;
}

int main(){
	string s;
	cin>>s;
	for(int i=0;i<s.length();++i){
		a[s[i]-'a']=i+1;
	}
	int n;
	cin>>n;
	for(int i=0;i<n;++i){
		cin>>node[i].c;
		int sum=0;
		for(int j=0;j<node[i].c.length();j++){
			sum+=sum*10+a[node[i].c[j]-'a'];
		}
		node[i].num=sum;
	}
	sort(node,node+n,gcd);
	int k;
	cin>>k;
	cout<<node[k-1].c;
	return 0;
}
