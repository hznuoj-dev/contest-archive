#include<iostream>
#include<algorithm>
#include<vector>
#define int long long
using namespace std;

const int N=5e5+7;
int a[N];
int n,q;
int sum[N];

signed main()
{
    cin >> n;
    for(int i=1; i<=n; i++) cin >> a[i];
    //for(int i=1; i<=n; i++) a[i]-=(a[1]-1);
    vector<int> v;
    v.push_back(0);
    for(int i=2; i<=n; i++) v.push_back(a[i]-a[i-1]);
    //for(int i=1; i<=n; i++) cout << a[i] << endl;
    sort(v.begin(),v.end());

    for(int i=1; i<=n; i++) sum[i]=sum[i-1]+v[i];

    cin >> q;
    while(q--){
        int x;
        cin >> x;
        int p=upper_bound(v.begin(),v.end(),x)-v.begin();
        //cout << p << endl;
        int ans=0;
        ans=sum[p-1];
         //cout << "---" << ans << endl;
        ans+=x;
         //cout << "---" << ans << endl;
        ans+=(n-p)*x;
        //cout << "---" << ans << endl;
        cout << ans << endl;
    }
    //for(int i=0; i<v.size(); i++) cout << v[i] << ' ';
}
