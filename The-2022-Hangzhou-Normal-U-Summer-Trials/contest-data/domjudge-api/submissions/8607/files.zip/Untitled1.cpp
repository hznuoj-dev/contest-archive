#include<bits/stdc++.h>
using namespace std;

typedef long long ll;
const ll N = 1e5 + 7;
const ll M = 1e9 + 7;
ll n, k, a[N], cnt[N], tot, sum[N], ans;
map<ll ,ll> mp;

void get(ll x){
	if (mp.count(x) == 0)mp[x] = ++tot;
} 

int main(){
	cin >> n >> k;
	for (int i = 1; i <= n; i++){
		cin >> a[i];
		sum[i] = (sum[i - 1] + a[i] % k) % k;
	}
	mp[0] = 0;
	cnt[0] = 1;
	for (int i = 1; i <= n; i++){
		get(sum[i]);
		ans += cnt[mp[sum[i]]];
		cnt[mp[sum[i]]]++;
	}
	cout << ans;
} 
