#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
const int N=1e5+50;
const int maxn=1e9+10;
ll sum[N];
ll a[N];
ll b[N];
ll f(ll x){
	ll ans=1;
	for(ll i=1;i<=x;i++){
		ans*=i;
	}
	return ans;
}
int main(){
	ios::sync_with_stdio(false);
	ll n,k;
	cin>>n>>k;
	ll c=0;
	for(ll i=1;i<=n;i++){
		cin>>a[i];
		sum[i]=(sum[i-1]%k+a[i]%k)%k;
		if(sum[i]==0)
			c++;
		b[sum[i]]++;
	}
	ll ans=0;
	ans+=f(c)/f(c-2)/2;
	for(int i=1;i<=n;i++){
		if(b[sum[i]]>=2){
			ans+=f(b[sum[i]])/f(b[sum[i]]-2)/2;
			b[sum[i]]=0;
		}
	}
	ans+=c;
	cout<<ans<<endl;
	return 0;
}

