#include<bits/stdc++.h>
#define int long long
#define IOS ios::sync_with_stdio(0); cin.tie(0); cout.tie(0);
using namespace std;
const int N = 2e5 + 10;
int a[N];
string s[N];
typedef pair<int,int> PII;
typedef long long ll;
const int mod = 998244353;
int n, m;
int gcd(int a,int b) {return b? gcd(b,a%b):a;}
map<char, int> mp;
bool cmp(string s1, string s2)
{
    if (s1.size() != s2.size())
    {
        return s1.size() < s2.size();
    }
    for(int i = 0; i < s1.size(); i ++ )
    {
        if (s1[i] != s2[i])
        {
            return mp[s1[i]] < mp[s2[i]];
        }
    }
    return s1[0] < s2[0];
}
void solve()
{
    string ss;
    cin >> ss;
    for(int i = 0; i < ss.size(); i ++ )
    {
        mp[ss[i]] = i;
    }
    cin >> n;
    for(int i = 1; i <= n; i ++ )
    {
        cin >> s[i];
    }
    //cout << mp['d'] << " " << mp['e'] << endl;
    sort(s + 1, s + n + 1, cmp);
    int k;
    cin >> k;
    cout << s[k] << endl;
}
signed main()
{

    solve();
}
/*
7
qst
qrt
qrs
abce
axy
hxy
abcd
*/