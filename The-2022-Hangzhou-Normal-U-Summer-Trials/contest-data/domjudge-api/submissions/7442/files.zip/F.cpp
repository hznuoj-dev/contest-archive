#include<iostream>
#include<algorithm>
#include<cstdio>
using namespace std;

int main(void){
	
	long long int n, k;
	long long int temp=0;
	long long int ans=0;
	cin>>n>>k;
	long long int a[100007]={0};
	long long int sum[100007]={0};
	
	cin>>a[1];
	sum[1]=a[1];
	for(long long int i=2;i<=n;++i){
		cin>>a[i];
		sum[i]=sum[i-1]+a[i];	
	}
	
	for(long long int i=1;i<=n;++i){
		for(long long int j=i;j<=n;++j){
			temp=sum[j]-sum[i]+a[i];
			if(temp%k==0){
				//cout<<"i="<<i<<" j="<<j<<endl;
				ans++;
			}
		}
	}
	/*
	7 5
0 1 5 4 7 3 5
*/
	cout<<ans<<endl;
	
	
	return 0;
}
