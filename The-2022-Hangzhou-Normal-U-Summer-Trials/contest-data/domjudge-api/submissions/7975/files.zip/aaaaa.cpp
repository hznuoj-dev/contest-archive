#include<bits/stdc++.h>
#define rep(i,x,y) for(int i=x;i<=y;i++)
using namespace std;
using LL=long long;
const int N=1e5+10;
int n,m,k;
set<int>v[200];
char str[N];
signed main(){
	ios::sync_with_stdio(0);
	int q;cin>>q;
	int len=0;
	while(q--){
		int op;cin>>op;
		if(op==1){
			len++;
			char ch;cin>>ch;
			v[ch].insert(len);
		}
		else if(op==2){
			if(len==0)continue;
			rep(i,'a','z')v[i].erase(len);
			len--;
		}
		else{
			char x,y;cin>>x>>y;
			if(v[x].size()>v[y].size())swap(v[x],v[y]);
			for(auto ch:v[x])v[y].insert(ch);
			v[x].clear();
		}
	}
	if(len==0){
		cout<<"The final string is empty";
	}
	rep(i,'a','z'){
		for(auto x:v[i])str[x]=i;
	}
	rep(i,1,len)cout<<str[i];
}
