#include<bits/stdc++.h>
using namespace std;

int main(){
	int n=0;
	string s;
	
	cin>>s;
	
	for(int i = 0; i < s.length(); i++){
		if(s.substr(i,4)=="hznu")n++;
	}
	cout<<n;
	return 0;
}
